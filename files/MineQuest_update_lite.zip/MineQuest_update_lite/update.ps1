﻿# MineQuest 配布マップ アップデート（第106版・軽量版）
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ver = @(22, 106, 1)
$ids = @{
  "3ead45c3-35e9-4427-972e-6d4fede443c2" = "behavior_packs\MineQuest_BP"
  "6c8f2d3e-9b4a-4f6c-8d7e-2a3b4c5d6e72" = "behavior_packs\MineQuest_Items_BP"
  "5fbbfa95-59b4-407d-a71e-0b3161c520a1" = "resource_packs\MineQuest_RP"
  "4b7e1c2d-8a3f-4e5b-9c6d-1f2a3b4c5d61" = "resource_packs\MineQuest_Items_RP"
}
Write-Host "=== マインクエスト 配布マップの アップデート（第106版・軽量版）===" -ForegroundColor Yellow
foreach ($rel in $ids.Values) { if (-not (Test-Path -LiteralPath (Join-Path (Join-Path (Join-Path $here "packs") $rel) "manifest.json"))) { Write-Host "新しい パックが 見つかりません。zipを 全部 展開してから、展開した フォルダの update.bat を 実行してください。" -ForegroundColor Red; exit 1 } }
Write-Host ""
if (Get-Process -Name "Minecraft.Windows","Minecraft" -ErrorAction SilentlyContinue) {
  Write-Host "マインクラフトが 開いています。マイクラを 完全に 閉じてから、もう一度 実行してください。" -ForegroundColor Red
  exit 1
}
# ワールドの 置き場所（古い版・新しい版の 両方を さがす）
$roots = @()
$roots += Join-Path $env:LOCALAPPDATA "Packages\Microsoft.MinecraftUWP_8wekyb3d8bbwe\LocalState\games\com.mojang\minecraftWorlds"
$mb = Join-Path $env:APPDATA "Minecraft Bedrock"
if (Test-Path $mb) { $roots += Get-ChildItem -Path $mb -Recurse -Directory -Filter "minecraftWorlds" -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName } }
$worlds = @()
foreach ($r in ($roots | Select-Object -Unique)) {
  if (-not (Test-Path $r)) { continue }
  foreach ($w in Get-ChildItem -Path $r -Directory) {
    $j = Join-Path $w.FullName "world_behavior_packs.json"
    if ((Test-Path -LiteralPath $j) -and ((Get-Content -LiteralPath $j -Raw) -match "3ead45c3-35e9-4427-972e-6d4fede443c2")) { $worlds += $w }
  }
}
if ($worlds.Count -eq 0) {
  Write-Host "マインクエストの ワールドが 見つかりませんでした。" -ForegroundColor Red
  Write-Host "（マイクラで 一度でも 配布マップを 開いて いるか 確かめてください）"
  exit 1
}
Write-Host "見つかった マインクエストの ワールド:"
$i = 1
foreach ($w in $worlds) {
  $n = $w.Name; $ln = Join-Path $w.FullName "levelname.txt"
  if (Test-Path -LiteralPath $ln) { $n = (Get-Content -LiteralPath $ln -Raw -Encoding UTF8).Trim() }
  Write-Host ("  {0}. {1}  （{2}）" -f $i, $n, $w.LastWriteTime); $i++
}
Write-Host ""
$a = Read-Host "全部 アップデートしますか？ はい=y / やめる=n"
if ($a -ne "y" -and $a -ne "Y") { Write-Host "やめました。"; exit 0 }
# ---------- 第106版・軽量版: 灰都の 街を 既存の ワールドに 入れる（滅びた 世界 100000,100000） ----------
$crcT = New-Object 'UInt32[]' 256
for ($n = 0; $n -lt 256; $n++) { [UInt32]$c = $n; for ($k = 0; $k -lt 8; $k++) { if ($c -band 1) { $c = ($c -shr 1) -bxor [UInt32]2197175160 } else { $c = $c -shr 1 } }; $crcT[$n] = $c }
function Crc32c([byte[]]$b, [UInt32]$init) { [UInt32]$c = $init -bxor [UInt32]::MaxValue; foreach ($x in $b) { $c = $crcT[[int](($c -bxor $x) -band 255)] -bxor ($c -shr 8) }; return [UInt32]($c -bxor [UInt32]::MaxValue) }
function MaskCrc([UInt32]$c) { [UInt64]$m = 4294967295; [UInt64]$r = (([UInt64]$c -shr 15) -bor (([UInt64]$c -shl 17) -band $m)); return [UInt32](($r + [UInt64]2726488792) -band $m) }
function UVar([byte[]]$b, [ref]$p) { [UInt64]$r = 0; $s = 0; while ($true) { $x = $b[$p.Value]; $p.Value++; $r = $r -bor ([UInt64]($x -band 0x7F) -shl $s); $s += 7; if ($x -lt 0x80) { return $r } } }
function WVar($list, [UInt64]$n) { while ($true) { $b = [byte]($n -band 0x7F); $n = $n -shr 7; if ($n -ne 0) { [void]$list.Add([byte]($b -bor 0x80)) } else { [void]$list.Add($b); return } } }
function ReadLogRecords([byte[]]$d) {
  $recs = New-Object System.Collections.ArrayList; $p = 0; $frag = New-Object System.Collections.Generic.List[byte]
  while ($p -lt $d.Length) {
    $left = 32768 - ($p % 32768)
    if ($left -lt 7) { $p += $left; continue }
    $ln = [BitConverter]::ToUInt16($d, $p + 4); $t = $d[$p + 6]
    if ($t -eq 0 -and $ln -eq 0) { $p += $left; continue }
    $body = New-Object byte[] $ln; [Array]::Copy($d, $p + 7, $body, 0, $ln); $p += 7 + $ln
    if ($t -eq 1) { [void]$recs.Add($body) } elseif ($t -eq 2) { $frag = New-Object System.Collections.Generic.List[byte]; $frag.AddRange($body) } elseif ($t -eq 3) { $frag.AddRange($body) } elseif ($t -eq 4) { $frag.AddRange($body); [void]$recs.Add($frag.ToArray()) }
  }
  return ,$recs
}
function AddCity($worldDir, $cityDir) {
  $db = Join-Path $worldDir "db"
  $meta = Get-Content -LiteralPath (Join-Path $cityDir "city.json") -Raw | ConvertFrom-Json
  $man = (Get-Content -LiteralPath (Join-Path $db "CURRENT") -Raw).Trim(); $mp = Join-Path $db $man
  $d = [System.IO.File]::ReadAllBytes($mp)
  [UInt64]$nextf = 0; [UInt64]$last = 0
  foreach ($r in (ReadLogRecords $d)) {
    $p = 0
    while ($p -lt $r.Length) {
      $tag = UVar $r ([ref]$p)
      switch ($tag) {
        1 { $n = UVar $r ([ref]$p); $p += $n }
        2 { [void](UVar $r ([ref]$p)) } 9 { [void](UVar $r ([ref]$p)) }
        3 { $v = UVar $r ([ref]$p); if ($v -gt $nextf) { $nextf = $v } }
        4 { $v = UVar $r ([ref]$p); if ($v -gt $last) { $last = $v } }
        5 { [void](UVar $r ([ref]$p)); $n = UVar $r ([ref]$p); $p += $n }
        6 { [void](UVar $r ([ref]$p)); [void](UVar $r ([ref]$p)) }
        7 { [void](UVar $r ([ref]$p)); $f = UVar $r ([ref]$p); [void](UVar $r ([ref]$p)); $n = UVar $r ([ref]$p); $p += $n; $n = UVar $r ([ref]$p); $p += $n; if ($f + 1 -gt $nextf) { $nextf = $f + 1 } }
        default { throw "MANIFEST の 読みとりに 失敗（tag $tag）" }
      }
    }
  }
  foreach ($fi in Get-ChildItem -LiteralPath $db -File) { $b = ($fi.BaseName -split "-")[-1]; [UInt64]$num = 0; if ([UInt64]::TryParse($b, [ref]$num) -and $num + 1 -gt $nextf) { $nextf = $num + 1 } }
  $edit = New-Object System.Collections.Generic.List[byte]; [UInt64]$f = $nextf
  $files = New-Object System.Collections.Generic.List[byte]
  foreach ($e in $meta.files) {
    Copy-Item -LiteralPath (Join-Path $cityDir $e.name) -Destination (Join-Path $db ("{0:D6}.ldb" -f $f)) -Force
    $sm = New-Object byte[] ([int]($e.smallest.Length / 2)); for ($i = 0; $i -lt $sm.Length; $i++) { $sm[$i] = [Convert]::ToByte($e.smallest.Substring($i * 2, 2), 16) }
    $lg = New-Object byte[] ([int]($e.largest.Length / 2)); for ($i = 0; $i -lt $lg.Length; $i++) { $lg[$i] = [Convert]::ToByte($e.largest.Substring($i * 2, 2), 16) }
    WVar $files 7; WVar $files 0; WVar $files $f; WVar $files ([UInt64]$e.size); WVar $files ([UInt64]$sm.Length); $files.AddRange($sm); WVar $files ([UInt64]$lg.Length); $files.AddRange($lg); $f++
  }
  [UInt64]$ml = [UInt64]$meta.last; if ($last -gt $ml) { $ml = $last }
  WVar $edit 3; WVar $edit $f; WVar $edit 4; WVar $edit $ml; $edit.AddRange($files)
  $out = New-Object System.Collections.Generic.List[byte]; $out.AddRange($d); $pos = $d.Length; $left = $edit.ToArray(); $first = $true
  while ($true) {
    $room = 32768 - ($pos % 32768)
    if ($room -lt 7) { for ($i = 0; $i -lt $room; $i++) { $out.Add(0) }; $pos += $room; continue }
    $n = [Math]::Min($left.Length, $room - 7); $frag = New-Object byte[] $n; [Array]::Copy($left, 0, $frag, 0, $n)
    $rest = New-Object byte[] ($left.Length - $n); [Array]::Copy($left, $n, $rest, 0, $rest.Length); $left = $rest
    if ($first) { if ($left.Length -eq 0) { $t = 1 } else { $t = 2 } } else { if ($left.Length -eq 0) { $t = 4 } else { $t = 3 } }
    $c = MaskCrc (Crc32c $frag (Crc32c ([byte[]]@($t)) 0))
    $out.AddRange([BitConverter]::GetBytes([UInt32]$c)); $out.AddRange([BitConverter]::GetBytes([UInt16]$n)); $out.Add([byte]$t); $out.AddRange($frag)
    $pos += 7 + $n; $first = $false
    if ($left.Length -eq 0) { break }
  }
  [System.IO.File]::WriteAllBytes($mp, $out.ToArray())
  [System.IO.File]::WriteAllText((Join-Path $worldDir "mq_city.txt"), "ruinheim city 77", (New-Object System.Text.UTF8Encoding $false))
}

$cityDir = Join-Path $here "city"
$addCity = $false
if (Test-Path -LiteralPath (Join-Path $cityDir "city.json")) {
  Write-Host ""
  Write-Host "追加ストーリー「滅びた世界」の 灰都の 街（座標 100000 付近）も ワールドに 入れますか？" -ForegroundColor Yellow
  Write-Host "（新しい 配布マップには もう 入って います。前から 遊んで いる ワールド・自分の ワールド 向け）"
  $c = Read-Host "入れる=y / 入れない=n"
  if ($c -eq "y" -or $c -eq "Y") { $addCity = $true }
}
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$bk = Join-Path ([Environment]::GetFolderPath("Desktop")) ("MineQuest_バックアップ_" + $stamp)
New-Item -ItemType Directory -Path $bk -Force | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding $false
foreach ($w in $worlds) {
  Write-Host ""
  Write-Host ("[" + $w.Name + "] バックアップ中…（少し 時間が かかります）")
  $bdst = Join-Path $bk $w.Name; $k = 2; while (Test-Path -LiteralPath $bdst) { $bdst = Join-Path $bk ($w.Name + "_" + $k); $k++ }
  Copy-Item -LiteralPath $w.FullName -Destination $bdst -Recurse -Force
  Write-Host "  古い パックを 入れかえ中…"
  foreach ($rel in $ids.Values) {
    $dst = Join-Path $w.FullName $rel
    if (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
    New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path (Join-Path $here "packs") $rel) -Destination $dst -Recurse -Force
  }
  foreach ($pair in @(@("world_behavior_packs.json", @("3ead45c3-35e9-4427-972e-6d4fede443c2","6c8f2d3e-9b4a-4f6c-8d7e-2a3b4c5d6e72")), @("world_resource_packs.json", @("5fbbfa95-59b4-407d-a71e-0b3161c520a1","4b7e1c2d-8a3f-4e5b-9c6d-1f2a3b4c5d61")))) {
    $jf = Join-Path $w.FullName $pair[0]
    $list = @()
    if (Test-Path -LiteralPath $jf) { try { $raw = Get-Content -LiteralPath $jf -Raw | ConvertFrom-Json; $list = @($raw) } catch { Write-Host ("  " + $pair[0] + " が 読めないので 中止します（バックアップは 無事です）") -ForegroundColor Red; exit 1 } }
    $out = New-Object System.Collections.ArrayList
    foreach ($e in $list) { if ($e -and $e.pack_id -and ($pair[1] -notcontains $e.pack_id)) { [void]$out.Add([ordered]@{ pack_id = $e.pack_id; version = @($e.version) }) } }
    foreach ($id in $pair[1]) { [void]$out.Add([ordered]@{ pack_id = $id; version = $ver }) }
    $json = ConvertTo-Json -InputObject @($out) -Depth 5
    [System.IO.File]::WriteAllText($jf, $json, $utf8)
  }
  if ($addCity) {
    if (Test-Path -LiteralPath (Join-Path $w.FullName "mq_city.txt")) { Write-Host "  灰都の 街は もう 入って います" }
    else {
      Write-Host "  灰都の 街を 入れて います…"
      try { AddCity $w.FullName $cityDir; Write-Host "  灰都の 街を 入れました" -ForegroundColor Green }
      catch { Write-Host ("  灰都の 街を 入れられませんでした: " + $_.Exception.Message) -ForegroundColor Red; Write-Host "  （ワールドが おかしい ときは デスクトップの バックアップを もどしてください）" -ForegroundColor Red }
    }
  }
  Write-Host "  おわり" -ForegroundColor Green
}
Write-Host ""
Write-Host "アップデート 完了！ マイクラを 開いて ワールドで 遊べます。" -ForegroundColor Green
Write-Host ("バックアップは デスクトップの「MineQuest_バックアップ_" + $stamp + "」に あります。")
Write-Host "（もし おかしく なったら、その 中の フォルダを ワールドの 場所に もどせば 元どおりです）"
