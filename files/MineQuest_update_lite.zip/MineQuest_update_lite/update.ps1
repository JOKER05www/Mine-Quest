﻿# MineQuest 配布マップ アップデート（第71版・軽量版）
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ver = @(22, 71, 1)
$ids = @{
  "3ead45c3-35e9-4427-972e-6d4fede443c2" = "behavior_packs\MineQuest_BP"
  "6c8f2d3e-9b4a-4f6c-8d7e-2a3b4c5d6e72" = "behavior_packs\MineQuest_Items_BP"
  "5fbbfa95-59b4-407d-a71e-0b3161c520a1" = "resource_packs\MineQuest_RP"
  "4b7e1c2d-8a3f-4e5b-9c6d-1f2a3b4c5d61" = "resource_packs\MineQuest_Items_RP"
}
Write-Host "=== マインクエスト 配布マップの アップデート（第71版・軽量版）===" -ForegroundColor Yellow
foreach ($rel in $ids.Values) { if (-not (Test-Path -LiteralPath (Join-Path (Join-Path (Join-Path $here "packs") $rel) "manifest.json"))) { Write-Host "新しい パックが 見つかりません。zipを 全部 展開してから、展開した フォルダの update.bat を 実行してください。" -ForegroundColor Red; exit 1 } }
Write-Host ""
if (Get-Process -Name "Minecraft.Windows","Minecraft" -ErrorAction SilentlyContinue) {
  Write-Host "マインクラフトが 開いています。マイクラを 完全に 閉じてから、もう一度 実行してください。" -ForegroundColor Red
  exit 1
}
# ワールドの 置き場所（古い版・新しい版の 両方を さがす）
$roots = @()
$roots += Join-Path $env:LOCALAPPDATA "Packages\Microsoft.MinecraftUWP_8wekyb3d8bbwe\LocalState\games\com.mojang\minecraftWorlds"
$mb = Join-Path $env:APPDATA "Minecraft Bedrock"
if (Test-Path $mb) { $roots += Get-ChildItem -Path $mb -Recurse -Directory -Filter "minecraftWorlds" -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName } }
$worlds = @()
foreach ($r in ($roots | Select-Object -Unique)) {
  if (-not (Test-Path $r)) { continue }
  foreach ($w in Get-ChildItem -Path $r -Directory) {
    $j = Join-Path $w.FullName "world_behavior_packs.json"
    if ((Test-Path -LiteralPath $j) -and ((Get-Content -LiteralPath $j -Raw) -match "3ead45c3-35e9-4427-972e-6d4fede443c2")) { $worlds += $w }
  }
}
if ($worlds.Count -eq 0) {
  Write-Host "マインクエストの ワールドが 見つかりませんでした。" -ForegroundColor Red
  Write-Host "（マイクラで 一度でも 配布マップを 開いて いるか 確かめてください）"
  exit 1
}
Write-Host "見つかった マインクエストの ワールド:"
$i = 1
foreach ($w in $worlds) {
  $n = $w.Name; $ln = Join-Path $w.FullName "levelname.txt"
  if (Test-Path -LiteralPath $ln) { $n = (Get-Content -LiteralPath $ln -Raw -Encoding UTF8).Trim() }
  Write-Host ("  {0}. {1}  （{2}）" -f $i, $n, $w.LastWriteTime); $i++
}
Write-Host ""
$a = Read-Host "全部 アップデートしますか？ はい=y / やめる=n"
if ($a -ne "y" -and $a -ne "Y") { Write-Host "やめました。"; exit 0 }
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$bk = Join-Path ([Environment]::GetFolderPath("Desktop")) ("MineQuest_バックアップ_" + $stamp)
New-Item -ItemType Directory -Path $bk -Force | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding $false
foreach ($w in $worlds) {
  Write-Host ""
  Write-Host ("[" + $w.Name + "] バックアップ中…（少し 時間が かかります）")
  $bdst = Join-Path $bk $w.Name; $k = 2; while (Test-Path -LiteralPath $bdst) { $bdst = Join-Path $bk ($w.Name + "_" + $k); $k++ }
  Copy-Item -LiteralPath $w.FullName -Destination $bdst -Recurse -Force
  Write-Host "  古い パックを 入れかえ中…"
  foreach ($rel in $ids.Values) {
    $dst = Join-Path $w.FullName $rel
    if (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
    New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path (Join-Path $here "packs") $rel) -Destination $dst -Recurse -Force
  }
  foreach ($pair in @(@("world_behavior_packs.json", @("3ead45c3-35e9-4427-972e-6d4fede443c2","6c8f2d3e-9b4a-4f6c-8d7e-2a3b4c5d6e72")), @("world_resource_packs.json", @("5fbbfa95-59b4-407d-a71e-0b3161c520a1","4b7e1c2d-8a3f-4e5b-9c6d-1f2a3b4c5d61")))) {
    $jf = Join-Path $w.FullName $pair[0]
    $list = @()
    if (Test-Path -LiteralPath $jf) { try { $raw = Get-Content -LiteralPath $jf -Raw | ConvertFrom-Json; $list = @($raw) } catch { Write-Host ("  " + $pair[0] + " が 読めないので 中止します（バックアップは 無事です）") -ForegroundColor Red; exit 1 } }
    $out = New-Object System.Collections.ArrayList
    foreach ($e in $list) { if ($e -and $e.pack_id -and ($pair[1] -notcontains $e.pack_id)) { [void]$out.Add([ordered]@{ pack_id = $e.pack_id; version = @($e.version) }) } }
    foreach ($id in $pair[1]) { [void]$out.Add([ordered]@{ pack_id = $id; version = $ver }) }
    $json = ConvertTo-Json -InputObject @($out) -Depth 5
    [System.IO.File]::WriteAllText($jf, $json, $utf8)
  }
  Write-Host "  おわり" -ForegroundColor Green
}
Write-Host ""
Write-Host "アップデート 完了！ マイクラを 開いて ワールドで 遊べます。" -ForegroundColor Green
Write-Host ("バックアップは デスクトップの「MineQuest_バックアップ_" + $stamp + "」に あります。")
Write-Host "（もし おかしく なったら、その 中の フォルダを ワールドの 場所に もどせば 元どおりです）"
