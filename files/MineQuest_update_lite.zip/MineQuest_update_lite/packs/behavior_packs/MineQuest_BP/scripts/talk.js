// 第108版: 物語の 会話を フォームで 止めない。せりふは チャットと 画面下の 文字に 流れる
// 第109版: 会話の あいだは「ムービー」: プレイヤーは その場で 止まり、話す 人が 身ぶり手ぶりで 話す。
//   しゃがむ（短く）= 次の せりふ ／ しゃがんだ まま 1.5秒 = スキップ（その 場面の 会話を ぜんぶ とばす。戦いは とばさない）
import { world, system } from "@minecraft/server";
import { notice, wait, ok, barNote, hudSend, hudResend } from "./ui.js";
import { face as dFace, emote as dEmote, tears as dTears, shockJump as dJump, FACE as DFACE } from "./direct.js";
import { stageOf, speakTurn, los, setStageHooks, stageReturn, blk, passB } from "./stagecore.js";
const plain = (s) => String(s || "");
/* 第126版: 会話の 枠に 入る ように 長い 行を ページに 分ける。いちばん 小さい 画面（1280×720・GUI 2 → はば 640）で 枠の 内がわは 約 400。
   1行 380（全角 11・半角 6.5・空白 4・太字 +1）・1ページ 2行（名前 ＋ 2行 ＋ 案内 = 枠の 高さ 54 に 入る）。
   ページの 切れめは 文の 終わり（。！？…」）を 先に、行の 切れめは 空白・読点の あと を 先に さがす。色は 次の 行・ページへ 引きつぐ */
export const BOX_W = 380, BOX_L = 2;
const cwide = (c) => !(c.charCodeAt(0) < 0x100 || (c >= "\uff61" && c <= "\uff9f"));
const CLOSE = "…」』）。！？!?", AFTER = "、。！？!?…」』）,", BEFORE = "「『（";
const carry = (head) => { let o = []; for (const c of head.match(/§./g) || []) { if (c === "§r") o = []; else if (/§[klo]/.test(c)) o.push(c); else o = [c]; } return o.join(""); };   /* 色は 最後の 1つ ＋ 太字など（統合版の §m §n は 色）*/
/* s の [from, to) を はば W の 行に 折る → 行の [始め, 終わり] の 配列 */
function wrapOff(s, from = 0, to = s.length, W = BOX_W) {
  let bb = false; for (let j = 0; j < from; j++) if (s[j] === "§") { const c = s[j + 1]; if (c === "l") bb = true; else if (c === "r") bb = false; j++; }
  const out = []; let i = from; while (i < to && s[i] === " ") i++;
  while (i < to && out.length < 300) {
    let w = 0, j = i, brk = -1, bw = 0, bAt = bb, bNow = bb;
    for (; j < to; j++) {
      const c = s[j];
      if (c === "§") { const d = s[j + 1]; if (d === "l") bNow = true; else if (d === "r") bNow = false; j++; continue; }
      if (c === "\n") break;
      const k = (c === " " ? 4 : cwide(c) ? 11 : 6.5) + (bNow ? 1 : 0);
      if (w + k > W && w > 0) break;
      w += k;
      if (c === " ") { brk = j; bw = w; bAt = bNow; }
      else if ((AFTER.includes(c) && !CLOSE.includes(s[j + 1] || "")) || BEFORE.includes(s[j + 1] || "")) { brk = j + 1; bw = w; bAt = bNow; }
    }
    const hard = j < to && s[j] !== "\n", end = hard && brk > i && bw >= W * 0.45 ? brk : j;
    bb = hard && end === brk ? bAt : bNow; out.push([i, end]); i = end; if (s[i] === "\n") i++; while (i < to && s[i] === " ") i++;
  }
  return out.length ? out : [[from, from]];
}
const lineStr = (s, [x, y], first) => (first ? "" : carry(s.slice(0, x))) + s.slice(x, y).replace(/ +((?:§.)*)$/, "$1");
export function wrapBox(s, W = BOX_W) { s = String(s ?? ""); return wrapOff(s, 0, s.length, W).map((r, k) => lineStr(s, r, k === 0)); }
/* 文の 終わり（。！？」… の あと）の 位置 */
function sentences(s) {
  const cut = [0];
  for (let j = 0; j < s.length; j++) {
    const c = s[j]; if (c === "§") { j++; continue; }
    if ("。！？!?".includes(c) || (c === "…" && j > 0)) { let k = j + 1; while (k < s.length && (CLOSE.includes(s[k]) || s[k] === "§")) k += s[k] === "§" ? 2 : 1; if (k < s.length && k > cut[cut.length - 1]) { cut.push(k); j = k - 1; } }
  }
  cut.push(s.length); return cut;
}
/* 1つの せりふ → ページの 配列（各ページは "\n" で 折った 2行まで）*/
export function boxPages(s, W = BOX_W, L = BOX_L) {
  s = String(s ?? "");
  const n = (x, y) => wrapOff(s, x, y, W).length;
  if (n(0, s.length) <= L) return [wrapBox(s, W).join("\n")];
  const cut = sentences(s), pages = []; let a = 0;
  for (let k = 1; k < cut.length; k++) {
    if (n(a, cut[k]) <= L) continue;
    if (cut[k - 1] > a) { pages.push([a, cut[k - 1]]); a = cut[k - 1]; }
    for (let r = wrapOff(s, a, cut[k], W); r.length > L; r = wrapOff(s, a, cut[k], W)) { pages.push([a, r[L - 1][1]]); a = r[L][0]; }   /* 1文が 長い: 2行ずつ */
  }
  if (a < s.length) pages.push([a, s.length]);
  return pages.map(([x, y]) => wrapOff(s, x, y, W).map((r) => lineStr(s, r, false)).join("\n")).filter((t) => t.replace(/§./g, "").trim());
}
const SLOW = new Set(), SKIP = new Set(), LOCK = new Map(), LAST = new Map();   /* LAST: 最後に 会話が 終わった 時刻（4秒 あいたら 別の 場面 → スキップを 解く）*/
let FIND = null;   /* (p, who) → 話す 人の エンティティ（saga.js が 決める）*/
export function setSpeakerFinder(f) { FIND = f; }
export function clearSkip(p) { try { SKIP.delete(p.id); } catch {} }
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
const HUD = ["hotbar", "health", "hunger", "armor", "status_effects", "item_text", "paperdoll", "crosshair", "air_bubbles", "progress_bar"];
/* 第112版: ムービーの カメラ。話す 人に 寄る（肩ごし）・2人を 横から・場面の 始めは 引きの 絵。会話が 終わったら 元に もどす */
const CAM = new Set(), SHOT = new Map();
const GEN = new Map();
export function camHold(p) { try { CAM.delete(p.id); SHOT.delete(p.id); GEN.set(p.id, (GEN.get(p.id) || 0) + 1); } catch {} }   /* 第113版: 予約した カメラの 片づけを とりけす（すぐ 後の 決闘カメラ・暗転を 消さない）*/
const camOn = (p) => { try { return p.getDynamicProperty("mrpg:nocam") !== true; } catch { return false; } };
const f2 = (v) => v.toFixed(2);
/* 第123版: カメラは 置く 前に 見通しを 調べる（壁・屋台・木・ほかの 人に さえぎられる 角度は 使わない）*/
const okE = (e) => { try { return !!e && (typeof e.isValid === "function" ? e.isValid() : e.isValid !== false); } catch { return false; } };
function blocksSeg(e, a, b) {
  try { const l = e.location, dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz), n = Math.ceil(L / 0.3);
    for (let i = 1; i <= n; i++) { const t = i / n; if (L * (1 - t) < 0.5) break; const x = a.x + dx * t, y = a.y + dy * t, z = a.z + dz * t; if (Math.hypot(x - l.x, z - l.z) < 0.32 && y > l.y - 0.1 && y < l.y + 1.9) return true; } } catch {}
  return false;
}
export function camClear(p, pos, look, sp) {
  const S = stageOf(p), dim = p.dimension, C = S ? S.C : new Map();
  if (!los(dim, pos, look, C)) return false;
  for (const [a, b, c] of [[0.3, 0, 0], [-0.3, 0, 0], [0, 0, 0.3], [0, 0, -0.3], [0, 0.25, 0]]) { const k = blk(dim, pos.x + a, pos.y + b, pos.z + c, C); if (k === undefined || !passB(k)) return false; }   /* 第127版: 壁・天井に くっついた カメラ（中が 見える）を 使わない */
  for (const e of S ? [...S.ents, p] : [p]) { if (e === sp || !okE(e)) continue; if (blocksSeg(e, pos, look)) return false; }
  return true;
}
function camSet(p, pos, look, ease) {
  if (!camOn(p)) return false;
  const e = CAM.has(p.id) && ease > 0 ? `ease ${ease} in_out_sine ` : "";
  if (!cmd(p, `camera @s set minecraft:free ${e}pos ${f2(pos.x)} ${f2(pos.y)} ${f2(pos.z)} facing ${f2(look.x)} ${f2(look.y)} ${f2(look.z)}`)) return false;
  CAM.add(p.id); globalThis.__mqCamLog?.(p, pos, look); return true;
}
function camTo(p, pos, look, ease = 0.8, sp = null) {
  if (!camOn(p) || !pos || !look) return false;
  if (!camClear(p, pos, look, sp)) return false;
  return camSet(p, pos, look, ease);
}
const rot = (v, d) => { const a = (d * Math.PI) / 180, c = Math.cos(a), s = Math.sin(a); return { x: v.x * c - v.z * s, z: v.x * s + v.z * c }; };
/* 第115版: せりふの 頭の {…} で 演出を 指定する。例「{shock,!,up}ええっ！？」
   表情: shock cry rage blush closed sweat angry sad smile ／ マーク: ! ? … 汗 怒 ♥ 息 ♪ ☆ ／ カメラ: up（顔の アップ）low（下から）wide（引き）／ 動き: jump tears */
const EMO = { "!": "bang", "?": "q", "…": "dots", "汗": "sweat", "怒": "anger", "♥": "heart", "息": "sigh", "♪": "note", "☆": "spark" };
export function parseTags(l) { const m = /^\{([^}]*)\}/.exec(String(l)); if (!m) return [[], String(l)]; return [m[1].split(",").map((x) => x.trim()).filter(Boolean), String(l).slice(m[0].length)]; }
/* 第123版: 絵の 候補を 順に 試して、最初に 見通しの よい 絵を 使う
   ots: 聞く 人の 肩ごし ／ front: 話す 人の 正面 ／ two: 2人を 横から ／ close: 顔の アップ ／ low: 下から ／ wide: 引き ／ top: 上から（最後の 手） */
export function shotList(p, sp, lis, kind, side = 1) {
  const S = sp.location, L = (lis || p).location, dx = S.x - L.x, dz = S.z - L.z, n = Math.hypot(dx, dz) || 1, u = { x: dx / n, z: dz / n }, r = { x: -u.z, z: u.x };
  const H = { x: S.x, y: S.y + 1.55, z: S.z }, M = { x: (L.x + S.x) / 2, y: Math.max(L.y, S.y) + 1.3, z: (L.z + S.z) / 2 };
  const toward = (k, deg, y) => { const v = rot({ x: -u.x, z: -u.z }, deg); return { x: S.x + v.x * k, y, z: S.z + v.z * k }; };
  const sh = {
    ots: (s) => [{ x: L.x - u.x * 1.9 + r.x * 0.85 * s, y: L.y + 1.95, z: L.z - u.z * 1.9 + r.z * 0.85 * s }, H],
    front: (s) => [toward(2.5, 28 * s, H.y + 0.05), H],
    close: (s) => [toward(1.4, 14 * s, H.y + 0.02), H],
    low: (s) => [toward(2.5, 22 * s, S.y + 0.35), { x: S.x, y: S.y + 1.9, z: S.z }],
    high: (s) => [toward(2.3, 20 * s, H.y + 1.6), { x: S.x, y: H.y - 0.2, z: S.z }],
    two: (s) => [{ x: M.x + r.x * 5 * s, y: M.y + 0.6, z: M.z + r.z * 5 * s }, M],
    wide: (s) => [{ x: M.x + r.x * 7 * s - u.x * 2.5, y: M.y + 3.2, z: M.z + r.z * 7 * s - u.z * 2.5 }, M],
  };
  const base = [sh.ots(side), sh.front(side), sh.ots(-side), sh.two(side), sh.front(-side), sh.two(-side), sh.wide(side), sh.wide(-side)];
  const head = kind === "up" ? [sh.close(side), sh.close(-side), sh.front(side), sh.front(-side)] : kind === "low" ? [sh.low(side), sh.low(-side)] : kind === "high" ? [sh.high(side), sh.high(-side)] : kind === "wide" ? [sh.wide(side), sh.wide(-side), sh.two(side), sh.two(-side)] : [];
  return { list: [...head, ...base], top: [{ x: L.x - u.x * 1.2, y: L.y + 3.4, z: L.z - u.z * 1.2 }, H] };
}
const LASTSHOT = new Map();   /* 第124版: 今の 絵（ゆっくり 寄る ため）*/
function shot(p, sp, kind = null, lis = null, ease = null) {
  try {
    if (!camOn(p) || !okE(sp)) return false;
    const St = stageOf(p), side = St && (!lis || lis === p) ? St.side : 1;
    const { list, top } = shotList(p, sp, lis, kind, side);
    for (const [pos, look] of list) if (camTo(p, pos, look, ease ?? (kind ? 0.45 : 0.7), sp)) { LASTSHOT.set(p.id, { pos, look, sp, at: { ...sp.location } }); return true; }
    if (camTo(p, top[0], top[1], 0.6, sp)) return true;
    if (!CAM.has(p.id) && St) return camLast(p, top[1]);   /* 一人称（手と ホットバー）に もどさない */
  } catch {}
  return false;
}
function applyTags(p, sp, tags, T, lis) {
  let cam = false;
  for (const t of tags) {
    if (sp && DFACE[t] !== undefined) dFace(sp, t, T);
    else if (sp && EMO[t]) dEmote(sp, EMO[t]);
    else if (sp && t === "jump") dJump(sp);
    else if (sp && t === "tears") dTears(sp, T);
    else if (sp && (t === "up" || t === "low" || t === "wide" || t === "high")) cam = shot(p, sp, t, lis) || cam;
  }
  return cam;
}
/* 場面の 始めの 引きの 絵（中心の まわりを ゆっくり 回る）。saga.js などから 呼ぶ */
export async function establish(p, c, nm) {   /* 第115版: カメラは 回さない（酔う）。場所の 名前だけ 出す */
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) return;
  if (!ok(p) || !nm) return;
  if (inScene(p)) { cineCard(p, `§f― ${nm} ―`, 50); await wait(30); return; }   /* 第125版: ムービーの あいだは 章札の 形で */
  try { p.onScreenDisplay.setTitle(" ", { subtitle: `§7― §f${nm} §7―`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 15 }); } catch {}
  await wait(30);
}
/* 第115版: 地の文の あいだ、カメラで その 人や 場所を 映す（次の 会話まで そのまま）*/
/* 第115版: 好きな 角度へ カメラを 切りかえる。第123版: さえぎられる ときは 見る 所の まわりを 回して 近い 角度を さがす */
export function camAt(p, pos, look, ease = 0.6) {
  if (!pos || !look) return false;
  if (camTo(p, pos, look, ease)) return true;
  const v = { x: pos.x - look.x, z: pos.z - look.z }, dy = pos.y - look.y;
  for (const k of [1, 0.65, 0.4]) for (const d of [30, -30, 60, -60, 95, -95, 140, -140, 180]) { const w = rot(v, d); if (camTo(p, { x: look.x + w.x * k, y: look.y + dy * Math.max(0.6, k), z: look.z + w.z * k }, look, ease)) return true; }
  return false;
}
export function lookAt(p, e) { try { if (e && e.location) { shot(p, e); CUR.set(p.id, e.id); } } catch {} }
/* 第123版: 場面の 始め・戦いの あとの 引きの 絵（舞台の 後ろ 上から）*/
function estShot(p) { const S = stageOf(p); if (!S) return false; return camTo(p, S.at(-6, 3.4 * S.side, 4.4), S.at(3, 0, 1), 0) || camAt(p, S.at(-3.4, 1.8 * S.side, 2.7), S.at(3, 0, 1.2), 0) || camLast(p, S.at(3, 0, 1.2)); }   /* 第124版: 始めは 広い 引きの 絵（止まった まま）*/
/* 最後の 手: プレイヤーの 真上から（それも ふさがって いれば そのまま 置く）*/
function camLast(p, look) {
  try { const l = p.location; for (const h of [2.6, 3.6, 5, 7]) for (const b of [0.6, 0, 1.2]) { const dx = look.x - l.x, dz = look.z - l.z, n = Math.hypot(dx, dz) || 1, c = { x: l.x - (dx / n) * b, y: l.y + h, z: l.z - (dz / n) * b }; if (camTo(p, c, look, 0)) return true; }
    return camSet(p, { x: l.x, y: l.y + 3.4, z: l.z }, look, 0); } catch { return false; }
}
/* 第123版: 場面の あいだ ずっと カメラと HUD を そのままに する（会話と 会話の あいだに 手や ホットバーが 出ない）*/
const SCN = new Set(), PAUSE = new Set(), CUR = new Map(), LOGS = new Map();
globalThis.__mqScene = { has: (id) => SCN.has(id) && !PAUSE.has(id) };   /* ui.js の barNote: 場面の あいだ ほかの 下の 文字を 出さない */
/* 右上の 案内（目標・所持金）を かくす ／ もどす。場面の 会話を チャットへ まとめて 送る */
function overlays(p, on) { try { if (on) hudSend(p, "MQG", ""); else hudResend(p.id, "MQG"); } catch {} }
/* 第125版: ムービーの 画面（hud_screen.json の MQC 帯 ／ MQD 会話の 枠 ／ MQF 光・集中線 ／ MQV 紫の 暗がり ／ MQK 章札 ／ MQX 大きな 一文字）*/
const CH_T = new Map(), MOOD = new Map();
function chTimed(p, ch, text, ticks) { hudSend(p, ch, text); const k = `${p.id}:${ch}`, n = (CH_T.get(k) || 0) + 1; CH_T.set(k, n); system.runTimeout(() => { if (CH_T.get(k) === n) try { hudSend(p, ch, ""); } catch {} }, ticks); }
export function cineFx(p, kind = "s", ticks = 12) { if (!SCN.has(p.id)) return; chTimed(p, "MQF", kind, ticks); }
/* 第126版: 章札は 2.4倍（はば 92% → 小さい 画面で 1行 約 230）・大きな 文字は 5倍（1行 約 110）。入らない 行は 折る／章札に 回す */
export const cardText = (text) => String(text).split("\n").flatMap((l) => wrapBox(l, 230)).slice(0, 3).join("\n");
export function cineCard(p, text, ticks = 70) { chTimed(p, "MQK", cardText(text), ticks); }
export function cineSting(p, text, ticks = 30) { if (wrapBox(text, 110).length > 1) return cineCard(p, text, ticks); chTimed(p, "MQX", text, ticks); }
export const boxLine = (t) => { const pg = boxPages(t); return pg[0] + (pg.length > 1 ? "…" : ""); };   /* 会話の 枠に 1ページだけ 出す 文 */
/* 影の 場面: 紫の 霧と 暗がり・一瞬の 稲光（場面の 終わりで もどる）*/
export function mood(p, kind = "shadow") {
  if (!SCN.has(p.id) || MOOD.get(p.id) === kind) return;
  MOOD.set(p.id, kind); cmd(p, "fog @s push mrpg:shadow mq_shadow"); hudSend(p, "MQV", "1");
  chTimed(p, "MQF", "f", 3); try { p.playSound("ambient.weather.thunder", { volume: 0.5, pitch: 1.3 }); } catch {}
}
function moodOff(p) { if (MOOD.delete(p.id)) cmd(p, "fog @s remove mq_shadow"); hudSend(p, "MQV", ""); }
function cineOff(p) { for (const ch of ["MQC", "MQD", "MQF", "MQX"]) hudSend(p, ch, ""); }
function flushLog(p) { const L = LOGS.get(p.id); LOGS.delete(p.id); if (L && L.length) try { p.sendMessage(L.join("\n§r")); } catch {} }
export const inScene = (p) => { try { return SCN.has(p.id) && !PAUSE.has(p.id); } catch { return false; } };
export function sceneOn(p) { if (SCN.has(p.id)) { estShot(p); return; } SCN.add(p.id); CUR.delete(p.id); FOE_SEEN.delete(p.id); LASTSHOT.delete(p.id); lock(p); overlays(p, true); hudSend(p, "MQC", "1"); estShot(p); }
export function sceneOff(p) { if (!SCN.delete(p.id)) return; CUR.delete(p.id); flushLog(p); cineOff(p); moodOff(p); overlays(p, false); try { p.onScreenDisplay.setActionBar(" "); } catch {} if (PAUSE.delete(p.id)) { cmd(p, "camera @s clear"); return; } unlock(p); camHold(p); cmd(p, "camera @s clear"); }
/* 戦いの 前後（戦いは 自分の カメラと HUD を 使う）*/
export function scenePause(p) { if (!SCN.has(p.id) || PAUSE.has(p.id)) return; PAUSE.add(p.id); CUR.delete(p.id); flushLog(p); cineOff(p); if (MOOD.has(p.id)) { cmd(p, "fog @s remove mq_shadow"); hudSend(p, "MQV", ""); } unlock(p); }
export function sceneResume(p) { if (!PAUSE.delete(p.id)) return; stageReturn(p); lock(p); overlays(p, true); hudSend(p, "MQC", "1"); if (MOOD.has(p.id)) { cmd(p, "fog @s push mrpg:shadow mq_shadow"); hudSend(p, "MQV", "1"); } camHold(p); estShot(p); }
setStageHooks({ paused: (p) => PAUSE.has(p.id), on: (p, S) => { if (!S || !S.auto) sceneOn(p); }, off: (p) => sceneOff(p), idle: (p) => (LOCK.has(p.id) && !SCN.has(p.id) ? 0 : Date.now() - (LAST.get(p.id) || 0)) });
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { SCN.delete(playerId); PAUSE.delete(playerId); CUR.delete(playerId); LOCK.delete(playerId); LOGS.delete(playerId); LASTSHOT.delete(playerId); FOE_SEEN.delete(playerId); MOOD.delete(playerId); }); } catch {}
export function camFade(p) { camHold(p); if (camOn(p)) cmd(p, "camera @s fade time 0.4 0.5 0.5 color 0 0 0"); }
function lock(p) {
  const n = (LOCK.get(p.id) || 0) + 1; LOCK.set(p.id, n); if (n > 1) return;
  if (!cmd(p, "inputpermission set @s lateral_movement disabled")) { SLOW.add(p.id); try { p.addEffect("slowness", 20 * 600, { amplifier: 255, showParticles: false }); } catch {} }   /* 古い 版の マイクラだけ（足を 止める）*/
  for (const h of HUD) cmd(p, `hud @s hide ${h}`);
}
function release(p) {
  if (CAM.has(p.id)) { const g = GEN.get(p.id) || 0; system.runTimeout(() => { if (g !== (GEN.get(p.id) || 0) || LOCK.has(p.id) || !CAM.has(p.id)) return; CAM.delete(p.id); if (globalThis.__MQ_CAMON?.has(p.id)) return; SHOT.delete(p.id); cmd(p, "camera @s clear"); }, 6); }   /* すぐ 次の 会話が 始まれば カメラは そのまま */
  if (SLOW.has(p.id)) { SLOW.delete(p.id); try { p.removeEffect("slowness"); } catch {} }
  cmd(p, "inputpermission set @s lateral_movement enabled"); cmd(p, "inputpermission set @s jump enabled"); cmd(p, "hud @s reset");
}
function unlock(p) { const n = (LOCK.get(p.id) || 1) - 1; if (n > 0) { LOCK.set(p.id, n); return; } LOCK.delete(p.id); release(p); }
/* ワールドに 入りなおした とき: 会話の とちゅうで 抜けても 動けない ままに ならない */
try { world.afterEvents.playerSpawn.subscribe((ev) => { const p = ev.player; if (LOCK.has(p.id)) return; try { if (p.getEffect("slowness")?.amplifier === 255) p.removeEffect("slowness"); } catch {} if (!SCN.has(p.id)) cmd(p, "fog @s remove mq_shadow"); release(p); }); } catch {}   /* 影の 場面の 霧も のこさない */
/* せりふの 中身から しぐさを えらぶ（4 話す 5 手を ふる 6 拍手 9 喜ぶ 10 おじぎ 12 しょんぼり）*/
/* 第124版: 25 うなずく 26 首を ふる 27 腕を 組む 28 腰に 手 29 ガッツポーズ 30 額に 手 31 よろける。{nod}{no}{arms}{hips}{pump}{palm}{stagger} で 指定も できる */
const TAGACT = { nod: 25, no: 26, arms: 27, hips: 28, pump: 29, palm: 30, stagger: 31 };
const TALKV = [4, 4, 25, 4, 28, 4, 27];
function gesture(l, tags = []) {
  for (const t of tags) if (TAGACT[t]) return TAGACT[t];
  const s = plain(l);
  if (/ありがと|よろしく|すまな|ごめん|申し訳/.test(s)) return 10;
  if (tags.includes("shock")) return 31;
  if (/やったぞ|よし[！、]|勝った|いくぞ|行くぞ|まかせ/.test(s)) return 29;
  if (/やれやれ|はあ……|まったく……|頭が 痛/.test(s)) return 30;
  if (/^(ちがう|いや|だめ|ありえない)|ちがうよ|そんな はず/.test(s)) return 26;
  if (/^(うん|うむ|ええ|そうだ|わかった|なるほど)|その とおり/.test(s)) return 25;
  if (/……/.test(s) && !/！/.test(s)) return 12;
  if (/やった|すごい|ほっほ|あはは|おめでとう/.test(s)) return Math.random() < 0.5 ? 9 : 6;
  if (/おーい|やあ|じゃあな|またな|さらば/.test(s)) return 5;
  if (tags.includes("rage") || tags.includes("angry")) return 28;
  let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;   /* 話す しぐさは 行ごとに かえる */
  return TALKV[h % TALKV.length];
}
/* 相棒・モンスターの 役者: 喜ぶ 行で 小さく はねる・こわい 行で ふるえる（teleport で 軽く）*/
function monReact(p, kind) {
  const S = stageOf(p); if (!S) return;
  for (const e of S.ents) {
    if (!okE(e) || e.typeId === "mrpg:npc") continue;
    let l; try { l = { ...e.location }; } catch { continue; }
    const seq = kind === "joy" ? [[0, 0.35, 0], [0, 0.15, 0], [0, 0, 0]] : [[0.1, 0, 0], [-0.1, 0, 0], [0.08, 0, 0], [-0.08, 0, 0], [0, 0, 0]];
    seq.forEach((d, i) => system.runTimeout(() => { try { if (okE(e)) e.teleport({ x: l.x + d[0], y: l.y + d[1], z: l.z + d[2] }); } catch {} }, (i + 1) * 2));
  }
}
function face(e, p) { try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
/* 第123版: 話す 人は 相手を 向き、まわりの 人は 話す 人を 見る。カメラは 話す 人が かわった とき だけ 切りかえる */
/* 第124版: カメラの 演出（回さない）: びっくり・怒りは すばやく 寄る ／ 敵が はじめて 話す ときは 下から ／ 悲しい 行は 上から */
const FOE_SEEN = new Map();
const STRONG = (tags) => tags.some((t) => t === "shock" || t === "rage" || t === "cry" || t === "!" || t === "怒");
function stagePlay(p, sp, tags, T) {
  const lis = speakTurn(p, sp); if (!lis) face(sp, p);
  if (applyTags(p, sp, tags, T, lis)) { CUR.set(p.id, sp.id); return lis; }
  if (!inScene(p)) { if (CUR.get(p.id) !== sp.id || !CAM.has(p.id)) shot(p, sp, null, lis); CUR.set(p.id, sp.id); return lis; }
  let kind = null, ease = null;
  const foe = /^§[c45]/.test(String(sp.nameTag || "")), seen = FOE_SEEN.get(p.id) || new Set();
  if (tags.includes("shock") || tags.includes("rage")) { kind = "up"; ease = 0.15; }
  else if (foe && !seen.has(sp.id)) { kind = "low"; seen.add(sp.id); FOE_SEEN.set(p.id, seen); }
  else if (tags.includes("sad") || tags.includes("cry")) kind = "high";
  if (!kind && CUR.get(p.id) === sp.id && CAM.has(p.id)) return lis;
  shot(p, sp, kind, lis, ease); CUR.set(p.id, sp.id);
  return lis;
}
/* 長い 行の あいだ ゆっくり 寄る（ドリー）。見通しが なければ 寄らない */
function dolly(p, T) {
  const L = LASTSHOT.get(p.id); if (!L || !inScene(p)) return;
  try { if (!okE(L.sp) || !L.at || Math.hypot(L.sp.location.x - L.at.x, L.sp.location.z - L.at.z) > 0.5) return; } catch { return; }   /* 第127版: 話す 人が 動いた あとは 古い 所へ 寄らない */
  const v = { x: L.look.x - L.pos.x, y: L.look.y - L.pos.y, z: L.look.z - L.pos.z }, d = Math.hypot(v.x, v.y, v.z); if (d < 1.9) return;
  const k = Math.min(0.22, 0.6 / d), q = { x: L.pos.x + v.x * k, y: L.pos.y + v.y * k, z: L.pos.z + v.z * k };
  if (camTo(p, q, L.look, Math.max(1, (T - 10) / 20), L.sp)) LASTSHOT.set(p.id, { ...L, pos: q });
}
/* 強い 行の あとに 聞いて いる 人（旅の 仲間・あなた）の 顔へ 一瞬 切りかえる */
async function reaction(p, sp, lis) {
  if (!inScene(p) || !okE(lis) || lis === sp || SKIP.has(p.id)) return;
  if (shot(p, lis, "up", sp, 0.1)) { await wait(14); CUR.delete(p.id); }
}
/* 1行ずつ 流す。長さに 合わせて 待つ（2〜7秒）*/
async function flow(p, text, bar, sp, act, tags = [], box = null, first = true, last = true) {
  if (!ok(p) || SKIP.has(p.id)) return;
  if (!first) {} else if (inScene(p)) { const L = LOGS.get(p.id) || []; L.push(text); if (L.length > 60) L.shift(); LOGS.set(p.id, L); } else try { p.sendMessage(text); } catch {}   /* 第123版: 場面の あいだは 字幕だけ（チャットには 最後に まとめて）*/
  let sp0 = 1; try { const v = p.getDynamicProperty("mrpg:tspeed"); if (typeof v === "number") sp0 = v; } catch {}
  const T = Math.round(Math.min(120, 24 + plain(bar).replace(/§./g, "").length * 1.6) * [1.5, 1, 0.6][sp0]);
  let lis = null;
  if (sp) { try { sp.setProperty("mrpg:act", act); sp.setProperty("mrpg:mv", false); } catch {} lis = stagePlay(p, sp, first ? tags : [], T); }
  if (first && sp && inScene(p)) { const s0 = plain(bar); if (tags.some((t) => t === "smile" || t === "♪" || t === "☆") || /やった|わーい|すごい/.test(s0)) monReact(p, "joy"); else if (tags.some((t) => t === "shock" || t === "sweat" || t === "汗" || t === "cry")) monReact(p, "fear"); }
  const longLine = sp && T >= 70;
  const cin = inScene(p), head = box ? `${box[0]}§l${box[1]}§r\n` : "", full = box ? `§f${box[2]}` : `§7${plain(bar).replace(/§./g, "")}`; let shown = 0;
  if (first && cin && sp && (tags.includes("shock") || tags.includes("rage"))) cineFx(p, "s", 14);   /* 集中線 */
  /* 第111版: 自動で 進む（速さは 設定）。ジャンプか しゃがむで 次へ・しゃがみ 長押しで スキップ */

  let held = 0, jw = true, rel = false; try { rel = !p.isSneaking; } catch { rel = true; }   /* 前から しゃがんで いたら 一度 はなすまで 長押しを 数えない */
  for (let t = 0; t < T; t += 5) {
    if (!ok(p)) break;
    if (cin) { if (shown < full.length) { shown = Math.min(full.length, shown + 7); if (full[shown - 1] === "§") shown++; hudSend(p, "MQD", `${head}${full.slice(0, shown)}${shown >= full.length ? "\n§8ジャンプ: 次へ ／ しゃがみ 長押し: スキップ" : ""}`); } }   /* 第125版: 会話の 枠に 1文字ずつ */
    else if (t % 20 === 0) try { barNote(p); p.onScreenDisplay.setActionBar(`${bar}\n§8ジャンプ: 次へ ／ しゃがみ 長押し: スキップ`); } catch {}
    if (longLine && t === 10) dolly(p, T);
    let sn = false, jp = false; try { sn = p.isSneaking; jp = p.isJumping; } catch {}
    if (jp && !jw && t >= 5) break;   /* ジャンプ（押した とき）→ 次へ */
    jw = jp;
    if (!rel) { if (!sn) rel = true; await wait(5); continue; }
    if (sn) { held += 5; if (held >= 30) { SKIP.add(p.id); try { barNote(p); p.onScreenDisplay.setActionBar("§7会話を スキップ"); } catch {} break; } }
    else if (held > 0) { if (t >= 10) break; held = 0; }   /* 短く しゃがんで はなした → 次へ */
    await wait(5);
  }
  if (sp) try { const b = sp.getDynamicProperty("mrpg:act0"); sp.setProperty("mrpg:act", typeof b === "number" ? b : 0); } catch {}
  if (last && sp && lis && STRONG(tags)) await reaction(p, sp, lis);
}
export async function talk(p, who, lines, col = "§6") {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { for (const l0 of [].concat(lines)) { const l = parseTags(l0)[1]; await notice(p, who, /^§7→/.test(l) ? l : `${col}§l${who}§r\n\n§f「${l}」`); } return; }   /* 模擬テスト用 */
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (SKIP.has(p.id)) { LAST.set(p.id, Date.now()); return; }
  let sp = null; try { if (!/手紙|声|心の/.test(plain([].concat(lines)[0]))) sp = FIND ? FIND(p, who) : null; } catch {}
  lock(p);
  try {
    for (const l of [].concat(lines)) {
      if (SKIP.has(p.id)) break;
      if (/^§7→/.test(l)) { const pg = boxPages(l); for (let k = 0; k < pg.length; k++) { if (SKIP.has(p.id)) break; await flow(p, l, pg[k], null, 0, [], null, k === 0, k === pg.length - 1); } continue; }
      const [tg, l2] = parseTags(l), pg = boxPages(l2), g = gesture(l2, tg);   /* 第126版: 長い せりふは ページに 分けて 順に */
      for (let k = 0; k < pg.length; k++) { if (SKIP.has(p.id)) break; await flow(p, `${col}§l${who}§r§f「${l2}」`, `${col}${who}§f${k ? "" : "「"}${pg[k]}${k === pg.length - 1 ? "」" : ""}`, sp, g, tg, [col, who, pg[k]], k === 0, k === pg.length - 1); }
    }
  } finally { unlock(p); LAST.set(p.id, Date.now()); if (inScene(p)) hudSend(p, "MQD", ""); }
}
export async function tell(p, title, lines) {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { await notice(p, title, [].concat(lines).join("\n")); return; }
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (SKIP.has(p.id)) { LAST.set(p.id, Date.now()); return; }
  lock(p);
  try { for (const l of [].concat(lines).flatMap((x) => String(x).split("\n"))) { if (SKIP.has(p.id)) break; if (!l.replace(/§./g, "").trim()) continue; const pg = boxPages(l); for (let k = 0; k < pg.length; k++) { if (SKIP.has(p.id)) break; await flow(p, `§7${l}`, `§f${pg[k]}`, null, 0, [], null, k === 0, k === pg.length - 1); } } }
  finally { unlock(p); LAST.set(p.id, Date.now()); if (inScene(p)) hudSend(p, "MQD", ""); }
}
