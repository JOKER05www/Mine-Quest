// 第108版: 物語の 会話を フォームで 止めない。せりふは チャットと 画面下の 文字に 流れる
// 第109版: 会話の あいだは「ムービー」: プレイヤーは その場で 止まり、話す 人が 身ぶり手ぶりで 話す。
//   しゃがむ（短く）= 次の せりふ ／ しゃがんだ まま 1.5秒 = スキップ（その 場面の 会話を ぜんぶ とばす。戦いは とばさない）
import { world, system } from "@minecraft/server";
import { notice, wait, ok, barNote, hudSend, hudResend, anim } from "./ui.js";
import { face as dFace, emote as dEmote, tears as dTears, shockJump as dJump, FACE as DFACE } from "./direct.js";
import { stageOf, speakTurn, listenerOf, los, setStageHooks, stageReturn, blk, passB } from "./stagecore.js";
const plain = (s) => String(s || "");
/* 第126版: 会話の 枠に 入る ように 長い 行を ページに 分ける。いちばん 小さい 画面（1280×720・GUI 2 → はば 640）で 枠の 内がわは 約 400。
   1行 380（全角 11・半角 6.5・空白 4・太字 +1）・1ページ 2行（名前 ＋ 2行 ＋ 案内 = 枠の 高さ 54 に 入る）。
   ページの 切れめは 文の 終わり（。！？…」）を 先に、行の 切れめは 空白・読点の あと を 先に さがす。色は 次の 行・ページへ 引きつぐ */
export const BOX_W = 380, BOX_L = 2;
const cwide = (c) => !(c.charCodeAt(0) < 0x100 || (c >= "\uff61" && c <= "\uff9f"));
const CLOSE = "…」』）。！？!?", AFTER = "、。！？!?…」』）,", BEFORE = "「『（";
const carry = (head) => { let o = []; for (const c of head.match(/§./g) || []) { if (c === "§r") o = []; else if (/§[klo]/.test(c)) o.push(c); else o = [c]; } return o.join(""); };   /* 色は 最後の 1つ ＋ 太字など（統合版の §m §n は 色）*/
/* s の [from, to) を はば W の 行に 折る → 行の [始め, 終わり] の 配列 */
function wrapOff(s, from = 0, to = s.length, W = BOX_W) {
  let bb = false; for (let j = 0; j < from; j++) if (s[j] === "§") { const c = s[j + 1]; if (c === "l") bb = true; else if (c === "r") bb = false; j++; }
  const out = []; let i = from; while (i < to && s[i] === " ") i++;
  while (i < to && out.length < 300) {
    let w = 0, j = i, brk = -1, bw = 0, bAt = bb, bNow = bb;
    for (; j < to; j++) {
      const c = s[j];
      if (c === "§") { const d = s[j + 1]; if (d === "l") bNow = true; else if (d === "r") bNow = false; j++; continue; }
      if (c === "\n") break;
      const k = (c === " " ? 4 : cwide(c) ? 11 : 6.5) + (bNow ? 1 : 0);
      if (w + k > W && w > 0) break;
      w += k;
      if (c === " ") { brk = j; bw = w; bAt = bNow; }
      else if ((AFTER.includes(c) && !CLOSE.includes(s[j + 1] || "")) || BEFORE.includes(s[j + 1] || "")) { brk = j + 1; bw = w; bAt = bNow; }
    }
    const hard = j < to && s[j] !== "\n", end = hard && brk > i && bw >= W * 0.45 ? brk : j;
    bb = hard && end === brk ? bAt : bNow; out.push([i, end]); i = end; if (s[i] === "\n") i++; while (i < to && s[i] === " ") i++;
  }
  return out.length ? out : [[from, from]];
}
const lineStr = (s, [x, y], first) => (first ? "" : carry(s.slice(0, x))) + s.slice(x, y).replace(/ +((?:§.)*)$/, "$1");
export function wrapBox(s, W = BOX_W) { s = String(s ?? ""); return wrapOff(s, 0, s.length, W).map((r, k) => lineStr(s, r, k === 0)); }
/* 文の 終わり（。！？」… の あと）の 位置 */
function sentences(s) {
  const cut = [0];
  for (let j = 0; j < s.length; j++) {
    const c = s[j]; if (c === "§") { j++; continue; }
    if ("。！？!?".includes(c) || (c === "…" && j > 0)) { let k = j + 1; while (k < s.length && (CLOSE.includes(s[k]) || s[k] === "§")) k += s[k] === "§" ? 2 : 1; if (k < s.length && k > cut[cut.length - 1]) { cut.push(k); j = k - 1; } }
  }
  cut.push(s.length); return cut;
}
/* 1つの せりふ → ページの 配列（各ページは "\n" で 折った 2行まで）*/
export function boxPages(s, W = BOX_W, L = BOX_L) {
  s = String(s ?? "");
  const n = (x, y) => wrapOff(s, x, y, W).length;
  if (n(0, s.length) <= L) return [wrapBox(s, W).join("\n")];
  const cut = sentences(s), pages = []; let a = 0;
  for (let k = 1; k < cut.length; k++) {
    if (n(a, cut[k]) <= L) continue;
    if (cut[k - 1] > a) { pages.push([a, cut[k - 1]]); a = cut[k - 1]; }
    for (let r = wrapOff(s, a, cut[k], W); r.length > L; r = wrapOff(s, a, cut[k], W)) { pages.push([a, r[L - 1][1]]); a = r[L][0]; }   /* 1文が 長い: 2行ずつ */
  }
  if (a < s.length) pages.push([a, s.length]);
  return pages.map(([x, y]) => wrapOff(s, x, y, W).map((r) => lineStr(s, r, false)).join("\n")).filter((t) => t.replace(/§./g, "").trim());
}
const SLOW = new Set(), SKIP = new Set(), LOCK = new Map(), LAST = new Map();   /* LAST: 最後に 会話が 終わった 時刻（4秒 あいたら 別の 場面 → スキップを 解く）*/
let FIND = null;   /* (p, who) → 話す 人の エンティティ（saga.js が 決める）*/
export function setSpeakerFinder(f) { FIND = f; }
export function clearSkip(p) { try { SKIP.delete(p.id); } catch {} }
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
const HUD = ["hotbar", "health", "hunger", "armor", "status_effects", "item_text", "paperdoll", "crosshair", "air_bubbles", "progress_bar"];
/* 第112版: ムービーの カメラ。話す 人に 寄る（肩ごし）・2人を 横から・場面の 始めは 引きの 絵。会話が 終わったら 元に もどす */
const CAM = new Set(), SHOT = new Map();
const GEN = new Map();
export function camHold(p) { try { CAM.delete(p.id); SHOT.delete(p.id); GEN.set(p.id, (GEN.get(p.id) || 0) + 1); } catch {} }   /* 第113版: 予約した カメラの 片づけを とりけす（すぐ 後の 決闘カメラ・暗転を 消さない）*/
const camOn = (p) => { try { return p.getDynamicProperty("mrpg:nocam") !== true; } catch { return false; } };
const f2 = (v) => v.toFixed(2);
/* 第123版: カメラは 置く 前に 見通しを 調べる（壁・屋台・木・ほかの 人に さえぎられる 角度は 使わない）*/
const okE = (e) => { try { return !!e && (typeof e.isValid === "function" ? e.isValid() : e.isValid !== false); } catch { return false; } };
const lying = (e) => { try { const a = e.getProperty("mrpg:act"); return a === 8 || a === 20 || a === 21; } catch { return false; } };
function blocksSeg(e, a, b) {
  try { const l = e.location, dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz), n = Math.ceil(L / 0.3);
    for (let i = 1; i <= n; i++) { const t = i / n; if (L * (1 - t) < 0.5) break; const x = a.x + dx * t, y = a.y + dy * t, z = a.z + dz * t; if (Math.hypot(x - l.x, z - l.z) < 0.32 && y > l.y - 0.1 && y < l.y + 1.9) return true; } } catch {}
  return false;
}
export function camClear(p, pos, look, sp) {
  const S = stageOf(p), dim = p.dimension, C = S ? S.C : new Map();
  { const B = S && S.opt && S.opt.box; if (B && [pos, look].some((q) => q.x < B.x1 || q.x > B.x2 || q.y < B.y1 || q.y > B.y2 || q.z < B.z1 || q.z > B.z2)) return false; }   /* 第122版: 洞くつの 広間など、決まった 箱の 中だけ 映す */
  if (!los(dim, pos, look, C)) return false;
  for (const [a, b, c] of [[0.3, 0, 0], [-0.3, 0, 0], [0, 0, 0.3], [0, 0, -0.3], [0, 0.25, 0]]) { const k = blk(dim, pos.x + a, pos.y + b, pos.z + c, C); if (k === undefined || !passB(k)) return false; }   /* 第127版: 壁・天井に くっついた カメラ（中が 見える）を 使わない */
  for (const e of S ? [...S.ents, p] : [p]) { if (e === sp || !okE(e)) continue; if (blocksSeg(e, pos, look)) return false; }
  try { for (const q of dim.getPlayers({ location: look, maxDistance: 8 })) if (q.id !== p.id && q !== sp && blocksSeg(q, pos, look)) return false; } catch {}   /* 第124版: マルチ: ほかの 人が 間に 立って いる 角度も 使わない */
  return true;
}
const CAMN = new Map();   /* 第125版: カメラを 置いた 回数（sagaep.js が「同じ カメラは 2行まで」を 守る ため）*/
export const camN = (p) => CAMN.get(p.id) || 0;
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => CAMN.delete(playerId)); } catch {}
/* 第124版(fix2): ease は 動く 量に 合わせる（75°・12m を こえたら カット、ほかは 秒速 6m・毎秒 90° まで）*/
const angV = (v, pos, look) => { const a = { x: v.look.x - v.pos.x, y: v.look.y - v.pos.y, z: v.look.z - v.pos.z }, b = { x: look.x - pos.x, y: look.y - pos.y, z: look.z - pos.z }, na = Math.hypot(a.x, a.y, a.z) || 1, nb = Math.hypot(b.x, b.y, b.z) || 1; return (Math.acos(Math.max(-1, Math.min(1, (a.x * b.x + a.y * b.y + a.z * b.z) / (na * nb)))) * 180) / Math.PI; };
function easeFit(p, pos, look, ease) {
  const v = VIEWP.get(p.id); if (!v) return ease > 0 ? ease : 0;
  const d = Math.hypot(pos.x - v.pos.x, pos.y - v.pos.y, pos.z - v.pos.z), a = angV(v, pos, look);
  if (a > 75 || d > 12) return 0;
  if (!(ease > 0)) { if (!SCN.has(p.id) || darkNow(p) || (d <= 3 && a <= 35)) return 0; ease = 0.05; }   /* 中くらいの 切りかえは 暗転の 外なら なめらかに */
  return Math.round(Math.min(2.4, Math.max(ease, d / 6, a / 90)) * 100) / 100;
}
/* 絵が かわったか（0.8m か 8° 以上）。ドリー・同じ 絵の 撮り直しは「同じ カメラは 2行まで」の 回数に 入れない */
const bigMove = (p, pos, look) => { const v = VIEWP.get(p.id); return !v || Math.hypot(pos.x - v.pos.x, pos.y - v.pos.y, pos.z - v.pos.z) >= 0.8 || angV(v, pos, look) >= 8; };
function camSet(p, pos, look, ease) {
  if (!camOn(p)) return false;
  ease = easeFit(p, pos, look, ease); const big = bigMove(p, pos, look);
  const e = (CAM.has(p.id) || SCN.has(p.id)) && ease > 0 ? `ease ${ease} in_out_sine ` : "";   /* 第124版(cam): 暗転の あと（camHold）でも 場面の 中なら なめらかに */
  if (!cmd(p, `camera @s set minecraft:free ${e}pos ${f2(pos.x)} ${f2(pos.y)} ${f2(pos.z)} facing ${f2(look.x)} ${f2(look.y)} ${f2(look.z)}`)) return false;
  CAM.add(p.id); if (big) CAMN.set(p.id, (CAMN.get(p.id) || 0) + 1); { const v0 = VIEWP.get(p.id); if (v0 && ease > 0 && big) VIEWP0.set(p.id, { pos: v0.pos, look: v0.look, until: FTK + Math.round(ease * 20) }); else if (!(ease > 0)) VIEWP0.delete(p.id); } VIEWP.set(p.id, { pos: { ...pos }, look: { ...look } }); globalThis.__mqCamLog?.(p, pos, look); return true;
}
function camTo(p, pos, look, ease = 0.8, sp = null) {
  if (!camOn(p) || !pos || !look) return false;
  if (!camClear(p, pos, look, sp)) return false;
  return camSet(p, pos, look, ease);
}
const rot = (v, d) => { const a = (d * Math.PI) / 180, c = Math.cos(a), s = Math.sin(a); return { x: v.x * c - v.z * s, z: v.x * s + v.z * c }; };
/* 第115版: せりふの 頭の {…} で 演出を 指定する。例「{shock,!,up}ええっ！？」
   表情: shock cry rage blush closed sweat angry sad smile ／ マーク: ! ? … 汗 怒 ♥ 息 ♪ ☆ ／ カメラ: up（顔の アップ）low（下から）wide（引き）／ 動き: jump tears */
const EMO = { "!": "bang", "?": "q", "…": "dots", "汗": "sweat", "怒": "anger", "♥": "heart", "息": "sigh", "♪": "note", "☆": "spark" };
export function parseTags(l) { const m = /^\{([^}]*)\}/.exec(String(l)); if (!m) return [[], String(l)]; return [m[1].split(",").map((x) => x.trim()).filter(Boolean).flatMap((x) => (x === "surprise" ? ["shock", "!"] : x === "q" ? ["?"] : [x])), String(l).slice(m[0].length)]; }   /* 第124版(fix2): {surprise}{q} も 効く */
/* 第123版: 絵の 候補を 順に 試して、最初に 見通しの よい 絵を 使う
   ots: 聞く 人の 肩ごし ／ front: 話す 人の 正面 ／ two: 2人を 横から ／ close: 顔の アップ ／ low: 下から ／ wide: 引き ／ top: 上から（最後の 手） */
export function shotList(p, sp, lis, kind, side = 1) {
  const S = sp.location, L = (lis || p).location, dx = S.x - L.x, dz = S.z - L.z, n = Math.hypot(dx, dz) || 1, u = { x: dx / n, z: dz / n }, r = { x: -u.z, z: u.x };
  let hy = 1.55; try { const v = sp.getDynamicProperty("mrpg:hy"); if (typeof v === "number" && v > 1.55) hy = v; } catch {}   /* 第124版(cam): 大きな 魔物（魔将）は 顔の 高さと 距離を 合わせる */
  if (lying(sp)) hy = 0.45;   /* 第124版(fix2): 寝て いる・倒れた 人は 顔が 低い */
  const g = Math.max(1, hy / 1.55), H = { x: S.x, y: S.y + hy, z: S.z }, M = g > 1 ? { x: L.x + (S.x - L.x) * 0.8, y: (L.y + 1.6 + S.y + hy) / 2, z: L.z + (S.z - L.z) * 0.8 } : { x: (L.x + S.x) / 2, y: Math.max(L.y, S.y) + 1.3, z: (L.z + S.z) / 2 };
  const toward = (k, deg, y) => { const v = rot({ x: -u.x, z: -u.z }, -deg);   /* 第124版(fix2): 正面・寄りも 肩ごし・2人の 絵と 同じ 側（前は 反対側で、絵が かわる たびに 軸を こえて いた）*/ return { x: S.x + v.x * k * g, y, z: S.z + v.z * k * g }; };
  const sh = {
    ots: (s) => [{ x: L.x - u.x * 1.9 + r.x * 0.85 * s, y: L.y + 1.95, z: L.z - u.z * 1.9 + r.z * 0.85 * s }, H],
    front: (s) => [toward(2.5, 28 * s, H.y + 0.05), H],
    close: (s) => [toward(1.4, 14 * s, H.y + 0.02), H],
    low: (s) => [toward(2.5, 22 * s, S.y + 0.35), { x: S.x, y: S.y + 1.9 * g, z: S.z }],
    high: (s) => [toward(2.3, 20 * s, H.y + 1.6 * g), { x: S.x, y: H.y - 0.2, z: S.z }],
    two: (s) => [{ x: M.x + r.x * 5 * Math.max(1, g * 0.8) * s, y: M.y + 0.6, z: M.z + r.z * 5 * Math.max(1, g * 0.8) * s }, M],
    wide: (s) => [{ x: M.x + r.x * 7 * Math.max(1, g * 0.7) * s - u.x * 2.5, y: M.y + 3.2 * Math.max(1, g * 0.6), z: M.z + r.z * 7 * Math.max(1, g * 0.7) * s - u.z * 2.5 }, M],
  };
  /* 第124版(fix2): 180度ルール: 同じ 側の 絵を ぜんぶ 試してから 反対側（ふさがれた ときだけ）*/
  const base = [sh.ots(side), sh.front(side), sh.two(side), sh.wide(side), sh.ots(-side), sh.front(-side), sh.two(-side), sh.wide(-side)];
  const head = kind === "up" ? [sh.close(side), sh.front(side), sh.close(-side), sh.front(-side)] : kind === "low" ? [sh.low(side), sh.low(-side)] : kind === "high" ? [sh.high(side), sh.high(-side)] : kind === "wide" ? [sh.wide(side), sh.two(side), sh.wide(-side), sh.two(-side)] : kind === "two" ? [sh.two(side), sh.front(side), sh.two(-side), sh.front(-side)] : kind === "ots2" ? [sh.high(side), sh.close(side), sh.front(side)] : [];
  return { list: [...head, ...base], top: [{ x: L.x - u.x * 1.2, y: L.y + 3.4, z: L.z - u.z * 1.2 }, H], ring: [sh.high(side), sh.high(-side), ...[0, 60, -60, 120, -120, 180].flatMap((d) => [3, 5].map((k) => [toward(k, d, H.y + k * 0.7), H]))] };
}
const LASTSHOT = new Map();   /* 第124版: 今の 絵（ゆっくり 寄る ため）*/
const VIEWP = new Map(), VIEWP0 = new Map();   /* VIEWP0: ease で 動いて いる あいだの 前の 絵（そこにも 映る）*/   /* 第124版(cam): 今の カメラの 位置と 向き（stagecore の 歩いて 来る 所・同じ 絵の 見分け）*/
const sameView = (p, pos, look) => { const v = VIEWP.get(p.id); if (!v) return false; const a = { x: v.look.x - v.pos.x, y: v.look.y - v.pos.y, z: v.look.z - v.pos.z }, b = { x: look.x - pos.x, y: look.y - pos.y, z: look.z - pos.z }, na = Math.hypot(a.x, a.y, a.z) || 1, nb = Math.hypot(b.x, b.y, b.z) || 1; return Math.hypot(pos.x - v.pos.x, pos.y - v.pos.y, pos.z - v.pos.z) < 1.2 && (a.x * b.x + a.y * b.y + a.z * b.z) / (na * nb) > 0.96; };
/* 第124版(fix2): 180度ルール。カメラは いつも 舞台の 決まった 側（舞台の 右×side と 手前）に 置く → 話す 人が 入れかわっても 軸を こえない */
function sideOf(St, sp, L) {
  try { const S0 = sp.location, L0 = L.location, dx = S0.x - L0.x, dz = S0.z - L0.z, n = Math.hypot(dx, dz) || 1, r = { x: -dz / n, z: dx / n };
    if (!St) return String(sp.id) < String(L.id) ? 1 : -1;
    const o = St.at(0, 0), rr = St.at(0, 1), ff = St.at(1, 0), W = { x: (rr.x - o.x) * St.side - 0.5 * (ff.x - o.x), z: (rr.z - o.z) * St.side - 0.5 * (ff.z - o.z) };
    return r.x * W.x + r.z * W.z >= 0 ? 1 : -1; } catch { return 1; }
}
function shot(p, sp, kind = null, lis = null, ease = null, fresh = false) {
  try {
    if (!camOn(p) || !okE(sp)) return false;
    const St = stageOf(p); let side = sideOf(St, sp, lis || p);
    { const LS = LASTSHOT.get(p.id), v = VIEWP.get(p.id);   /* 第124版(fix2): 今 映って いる 人に 答える ときは、今の カメラと 同じ 側に 置く（軸を こえない）*/
      if (lis && lis !== p && okE(lis) && LS && LS.sp === lis && v) { const S0 = sp.location, L0 = lis.location, dx = S0.x - L0.x, dz = S0.z - L0.z, n = Math.hypot(dx, dz) || 1, cr = (dx * (v.pos.z - L0.z) - dz * (v.pos.x - L0.x)) / n; if (Math.abs(cr) > 1) side = cr > 0 ? 1 : -1; } }
    const { list, top, ring } = shotList(p, sp, lis, kind, side);
    for (const [pos, look] of list) if (!(fresh && sameView(p, pos, look)) && camTo(p, pos, look, ease ?? (kind ? 0.45 : 0.7), sp)) { LASTSHOT.set(p.id, { pos, look, sp, at: { ...sp.location } }); return true; }
    if (fresh) return false;
    for (const [pos, look] of [top, ...ring]) if (camTo(p, pos, look, 0.6, sp)) { LASTSHOT.set(p.id, { pos, look, sp, at: { ...sp.location } }); return true; }   /* 第124版(cam): 候補が ぜんぶ ふさがれば 上からの 絵（前の 絵の ままに しない）*/
    if (St) return camLast(p, top[1]);   /* 一人称（手と ホットバー）に もどさない */
  } catch {}
  return false;
}
function applyTags(p, sp, tags, T, lis) {
  let cam = false;
  for (const t of tags) {
    if (sp && DFACE[t] !== undefined) dFace(sp, t, T);
    else if (sp && EMO[t]) dEmote(sp, EMO[t]);
    else if (sp && t === "jump") dJump(sp);
    else if (sp && t === "tears") dTears(sp, T);
    else if (sp && t === "roar" && sp.typeId !== "mrpg:npc") anim(sp, "g_roar");
    else if (sp && (t === "up" || t === "low" || t === "wide" || t === "high")) cam = shot(p, sp, t, lis) || cam;
  }
  return cam;
}
/* 場面の 始めの 引きの 絵（中心の まわりを ゆっくり 回る）。saga.js などから 呼ぶ */
export async function establish(p, c, nm) {   /* 第115版: カメラは 回さない（酔う）。場所の 名前だけ 出す */
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) return;
  if (!ok(p) || !nm) return;
  if (inScene(p)) { cineCard(p, `§f― ${nm} ―`, 50); await wait(30); return; }   /* 第125版: ムービーの あいだは 章札の 形で */
  try { p.onScreenDisplay.setTitle(" ", { subtitle: `§7― §f${nm} §7―`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 15 }); } catch {}
  await wait(30);
}
/* 第115版: 地の文の あいだ、カメラで その 人や 場所を 映す（次の 会話まで そのまま）*/
/* 第115版: 好きな 角度へ カメラを 切りかえる。第123版: さえぎられる ときは 見る 所の まわりを 回して 近い 角度を さがす */
export function camAt(p, pos, look, ease = 0.6) {
  if (!pos || !look) return false;
  { const D = Math.hypot(look.x - pos.x, look.y - pos.y, look.z - pos.z); if (D > 16) { const k = 12 / D; look = { x: pos.x + (look.x - pos.x) * k, y: pos.y + (look.y - pos.y) * k, z: pos.z + (look.z - pos.z) * k }; } }   /* 第124版(fix2): 遠くを 見る 絵は 12m 先を 見る（代わりの 角度で 遠くへ 飛ばない・見通しの 点検を 軽く）*/
  try { CUR.delete(p.id); LASTSHOT.delete(p.id); } catch {}   /* 第120版: 物や 場所を 映した あとは、次の せりふで 話す 人へ 映しなおす（同じ 人が 話し続けても 扉を 映した ままに しない）*/
  if (camTo(p, pos, look, ease)) return true;
  const v = { x: pos.x - look.x, z: pos.z - look.z }, dy = pos.y - look.y;
  for (const k of [1, 0.65, 0.4]) for (const d of [30, -30, 60, -60, 95, -95, 140, -140, 180]) { const w = rot(v, d); if (camTo(p, { x: look.x + w.x * k, y: look.y + dy * Math.max(0.6, k), z: look.z + w.z * k }, look, ease)) return true; }
  return false;
}
export function lookAt(p, e) { try { if (e && e.location) { shot(p, e, null, listenerOf(p, e)); CUR.set(p.id, e.id); } } catch {} }   /* 第124版(fix2): 次の せりふと 同じ 相手で 撮る（軸を こえない）*/
/* 第124版(cam): ほかの 演出（決闘・遠い 寄り）の カメラも ここを 通す（見通しを 調べ、今の 絵として 覚える）。ease は いつも 付ける */
export function camPut(p, pos, look, ease = 0, check = true) {
  if (!camOn(p) || !pos || !look || (check && !camClear(p, pos, look, null))) return false;
  ease = easeFit(p, pos, look, ease); const big = bigMove(p, pos, look);
  const e = ease > 0 ? `ease ${ease} in_out_sine ` : "";
  if (!cmd(p, `camera @s set minecraft:free ${e}pos ${f2(pos.x)} ${f2(pos.y)} ${f2(pos.z)} facing ${f2(look.x)} ${f2(look.y)} ${f2(look.z)}`)) return false;
  CAM.add(p.id); if (big) CAMN.set(p.id, (CAMN.get(p.id) || 0) + 1); { const v0 = VIEWP.get(p.id); if (v0 && ease > 0 && big) VIEWP0.set(p.id, { pos: v0.pos, look: v0.look, until: FTK + Math.round(ease * 20) }); else if (!(ease > 0)) VIEWP0.delete(p.id); } VIEWP.set(p.id, { pos: { ...pos }, look: { ...look } }); CUR.delete(p.id); LASTSHOT.delete(p.id); return true;
}
/* 第124版(cam): 話す 人を 決まった 角度で 映す（ふさがれば 近い 角度 → 話す 人の 絵）。次の 行で 映しなおさない */
export function camShot(p, e, pos, look, ease = 0.6) {
  const r = camAt(p, pos, look, ease) || (okE(e) && shot(p, e));
  if (r && okE(e)) try { CUR.set(p.id, e.id); const v = VIEWP.get(p.id); if (v) LASTSHOT.set(p.id, { pos: v.pos, look: v.look, sp: e, at: { ...e.location } }); } catch {}
  return r;
}
/* 第123版: 場面の 始め・戦いの あとの 引きの 絵（舞台の 後ろ 上から）*/
function estShot(p) { const S = stageOf(p); if (!S) return false; return camTo(p, S.at(-6, 3.4 * S.side, 4.4), S.at(3, 0, 1), 0) || camAt(p, S.at(-3.4, 1.8 * S.side, 2.7), S.at(3, 0, 1.2), 0) || camLast(p, S.at(3, 0, 1.2)); }   /* 第124版: 始めは 広い 引きの 絵（止まった まま）*/
/* 最後の 手: プレイヤーの 真上から（それも ふさがって いれば そのまま 置く）*/
function camLast(p, look) {
  try { const l = p.location; for (const h of [2.6, 3.6, 5, 7]) for (const b of [0.6, 0, 1.2]) { const dx = look.x - l.x, dz = look.z - l.z, n = Math.hypot(dx, dz) || 1, c = { x: l.x - (dx / n) * b, y: l.y + h, z: l.z - (dz / n) * b }; if (camTo(p, c, look, CAM.has(p.id) ? 0.5 : 0)) return true; }
    { const v = VIEWP.get(p.id); if (SCN.has(p.id) && v && Math.hypot(v.pos.x - l.x, v.pos.y - l.y, v.pos.z - l.z) < 30) return false; }   /* 第124版(fix2): 場面の 中は 見通しの ない 所に 置かず、今の 絵の まま（場所が 移った あとは 置く）*/
    const S = stageOf(p), B = S && S.opt && S.opt.box; return camSet(p, { x: l.x, y: B ? Math.min(B.y2 - 0.3, l.y + 3.4) : l.y + 3.4, z: l.z }, look, CAM.has(p.id) ? 0.5 : 0); } catch { return false; }
}
/* 第123版: 場面の あいだ ずっと カメラと HUD を そのままに する（会話と 会話の あいだに 手や ホットバーが 出ない）*/
const SCN = new Set(), PAUSE = new Set(), CUR = new Map(), LOGS = new Map();
globalThis.__mqScene = { has: (id) => SCN.has(id) && !PAUSE.has(id), paused: (id) => SCN.has(id) && PAUSE.has(id) };   /* paused: 物語の 戦いの あいだ（battle.js が 終わりに 暗く する）*/   /* ui.js の barNote: 場面の あいだ ほかの 下の 文字を 出さない */
/* 右上の 案内（目標・所持金）を かくす ／ もどす。場面の 会話を チャットへ まとめて 送る */
function overlays(p, on) { try { if (on) hudSend(p, "MQG", ""); else hudResend(p.id, "MQG"); } catch {} }
/* 第125版: ムービーの 画面（hud_screen.json の MQC 帯 ／ MQD 会話の 枠 ／ MQF 光・集中線 ／ MQV 紫の 暗がり ／ MQK 章札 ／ MQX 大きな 一文字）*/
const CH_T = new Map(), MOOD = new Map();
function chTimed(p, ch, text, ticks) { hudSend(p, ch, text); const k = `${p.id}:${ch}`, n = (CH_T.get(k) || 0) + 1; CH_T.set(k, n); system.runTimeout(() => { if (CH_T.get(k) === n) try { hudSend(p, ch, ""); } catch {} }, ticks); }   /* 消す 合図の 送り直しは ui.js が する */
export function cineFx(p, kind = "s", ticks = 12) { }   /* 第120版: 集中線・白い 光は 出さない（じゃまに なる）*/
/* 第126版: 章札は 2.4倍（はば 92% → 小さい 画面で 1行 約 230）・大きな 文字は 5倍（1行 約 110）。入らない 行は 折る／章札に 回す */
export const cardText = (text) => String(text).split("\n").flatMap((l) => wrapBox(l, 230)).slice(0, 3).join("\n");
export function cineCard(p, text, ticks = 70) { chTimed(p, "MQK", cardText(text), ticks); }
export function cineSting(p, text, ticks = 30) { if (wrapBox(text, 110).length > 1) return cineCard(p, text, ticks); chTimed(p, "MQX", text, ticks); }
export const boxLine = (t) => { const pg = boxPages(t); return pg[0] + (pg.length > 1 ? "…" : ""); };   /* 会話の 枠に 1ページだけ 出す 文 */
/* 影の 場面: 紫の 霧と 暗がり・一瞬の 稲光（場面の 終わりで もどる）*/
export function mood(p, kind = "shadow") {
  if (!SCN.has(p.id) || MOOD.get(p.id) === kind) return;
  if (kind !== "shadow") return;   /* 第125版(snd): 紫の 霧と 雷は 影の 場面だけ（静かな 夜には 使わない）*/
  MOOD.set(p.id, kind); cmd(p, "fog @s push mrpg:shadow mq_shadow");
  try { p.playSound("ambient.weather.thunder", { volume: 0.5, pitch: 1.3 }); } catch {}
}
function moodOff(p) { if (MOOD.delete(p.id)) cmd(p, "fog @s remove mq_shadow"); hudSend(p, "MQV", ""); }
function cineOff(p) { for (const ch of ["MQC", "MQD", "MQF", "MQX"]) { CH_T.set(`${p.id}:${ch}`, (CH_T.get(`${p.id}:${ch}`) || 0) + 1); hudSend(p, ch, ""); } }
function flushLog(p) { const L = LOGS.get(p.id); LOGS.delete(p.id); if (L && L.length) try { p.sendMessage(L.join("\n§r")); } catch {} }
export const inScene = (p) => { try { return SCN.has(p.id) && !PAUSE.has(p.id); } catch { return false; } };
export function sceneOn(p) { if (SCN.has(p.id)) { estShot(p); return; } SCN.add(p.id); CUR.delete(p.id); FOE_SEEN.delete(p.id); LASTSHOT.delete(p.id); RUN2.delete(p.id); lock(p); overlays(p, true); fadeOn(p, "0 0.25 0.5", "0 0 0", true); estShot(p); }   /* 第124版(cam): ふつうの 画面から 場面の カメラへは 暗い 所から（手紙の 段・闘技場も）*/
export function sceneOff(p) { if (!SCN.delete(p.id)) return; CUR.delete(p.id); timeBack(p); flushLog(p); cineOff(p); moodOff(p); overlays(p, false); try { p.onScreenDisplay.setActionBar(" "); } catch {} if (!darkNow(p)) fadeOn(p, "0 0.2 0.4", "0 0 0", true);   /* 第124版(fix2): 暗い 所で 一人称へ もどす（まわりの 人が 一度に 出るのを 見せない）*/ if (PAUSE.delete(p.id)) { cmd(p, "camera @s clear"); return; } unlock(p); camHold(p); cmd(p, "camera @s clear"); }
/* 戦いの 前後（戦いは 自分の カメラと HUD を 使う）*/
export function scenePause(p) { if (!SCN.has(p.id) || PAUSE.has(p.id)) return; PAUSE.add(p.id); CUR.delete(p.id); flushLog(p); cineOff(p); if (MOOD.has(p.id)) { cmd(p, "fog @s remove mq_shadow"); hudSend(p, "MQV", ""); } unlock(p); }
export function sceneResume(p) { if (!PAUSE.delete(p.id)) return; stageReturn(p); lock(p); overlays(p, true); if (MOOD.has(p.id)) cmd(p, "fog @s push mrpg:shadow mq_shadow"); camHold(p); estShot(p); }
setStageHooks({ paused: (p) => PAUSE.has(p.id), on: (p, S) => { if (!S || !S.auto) sceneOn(p); }, off: (p) => sceneOff(p), idle: (p) => (LOCK.has(p.id) && !SCN.has(p.id) ? 0 : Date.now() - (LAST.get(p.id) || 0)), view: (p) => camPose(p), put: (p, pos, look, ease) => inScene(p) && camPut(p, pos, look, ease), fade: (p, t) => fadeOn(p, t), fadeTry, prev: (p) => { const v = VIEWP0.get(p.id); return v && v.until > FTK && SCN.has(p.id) ? v : null; } });
/* 第124版(cam): 今の 絵（場面の カメラ ／ なければ 目の 位置と 向き）*/
export function camPose(p) {
  if ((CAM.has(p.id) || SCN.has(p.id)) && VIEWP.has(p.id)) return VIEWP.get(p.id);
  try { const h = p.getHeadLocation(); let d = null; try { d = p.getViewDirection(); } catch {} if (!d) { const a = (p.getRotation().y * Math.PI) / 180; d = { x: -Math.sin(a), y: 0, z: Math.cos(a) }; } return { pos: h, look: { x: h.x + d.x * 5, y: h.y + d.y * 5, z: h.z + d.z * 5 } }; } catch { return null; }
}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { SCN.delete(playerId); PAUSE.delete(playerId); CUR.delete(playerId); LOCK.delete(playerId); LOGS.delete(playerId); LASTSHOT.delete(playerId); FOE_SEEN.delete(playerId); MOOD.delete(playerId); }); } catch {}
export function camFade(p) { camHold(p); fadeOn(p, "0.4 0.5 0.5", "0 0 0", !darkNow(p)); }   /* 場面の 区切り: かならず 暗く する（まっ暗なら 暗いまま のばす）*/
/* 第124版(fix2): 暗転を 1か所で 覚える（暗い あいだに 別の 暗転を 重ねない → ちらつかない）。t は "in hold out"（秒）*/
const FADE_END = new Map(), FADE_AT = new Map(), FADE_DK = new Map(), FADE_IN = new Map();
let FTK = 0; system.runInterval(() => { FTK++; }, 1);   /* 暗転の 時計（1tick に 1つ 進む。軽い）*/
export const fading = (p) => { try { return (FADE_END.get(p.id) || 0) > FTK; } catch { return false; } };
export const darkNow = (p) => { try { return (FADE_DK.get(p.id) || 0) > FTK; } catch { return false; } };   /* まっ暗な あいだ（暗く なりきって から 明るく なり始める まで）*/
/* 暗い 中で 人を 出す: まっ暗なら のばす ／ 明るく なりかけ・明けた 直後は false（あとで もう一度）／ ほかは 暗転 */
export function fadeTry(p, t = "0.15 0.3 0.35") { if (darkNow(p)) { fadeOn(p, t); return true; } if (FTK < (FADE_DK.get(p.id) || 0) + 15) return false; fadeOn(p, t, "0 0 0", true); return true; }
/* 役者を 下げる 前: 暗く なって いなければ 暗くする（明るく なりかけなら 終わるのを 待ってから）*/
export async function fadeHide(p, t = "0.1 0.25 0.4") {
  if (!darkNow(p)) { for (let k = 0; k < 24 && FTK < (FADE_DK.get(p.id) || 0) + 15; k++) await wait(1); fadeOn(p, t, "0 0 0", true); }   /* 明るく なりかけ・明けた 直後（0.7秒）は 待ってから（2回 ちらつかない）*/
  else fadeOn(p, t);
  for (let k = 0; k < 12 && FTK < (FADE_IN.get(p.id) || 0); k++) await wait(1);
  await wait(1);
}
export function fadeOn(p, t = "0.4 0.5 0.5", rgb = "0 0 0", force = false) {
  if (!camOn(p)) return false;
  let [i = 0, h = 0, o = 0] = String(t).trim().split(/\s+/).map(Number);
  if (!force && fading(p)) { if (!darkNow(p)) return false; i = 0; t = `0 ${h} ${o}`; }
  else if (force && i > 0 && rgb === "0 0 0" && darkNow(p)) { i = 0; t = `0 ${h} ${o}`; }   /* もう まっ暗なら 暗いまま（明るく もどさない）*/   /* まっ暗な ときは 暗いまま のばす（明るく しない）。明るく なりかけなら 重ねない */
  FADE_END.set(p.id, FTK + Math.round((i + h + o * 0.5) * 20)); FADE_AT.set(p.id, FTK); FADE_DK.set(p.id, FTK + Math.round((i + h) * 20)); FADE_IN.set(p.id, FTK + Math.round(i * 20));
  return cmd(p, `camera @s fade time ${t} color ${rgb}`);
}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { FADE_END.delete(playerId); timeBack({ id: playerId }); }); } catch {}
/* 第124版(fix2): 夜・夕ぐれの 場面は 時刻も かえる（1人で 遊んで いて 昼の とき だけ。場面の 終わりに もどす）*/
const TOD = { night: 14000, dusk: 12300 }, TODS = new Map();
export function sceneTime(p, kind) {
  const t = TOD[kind]; if (!t || TODS.has(p.id)) return;
  try { if (world.getAllPlayers().length !== 1) return; const t0 = world.getTimeOfDay(); if (t0 >= 12000 && t0 <= 23000) return; TODS.set(p.id, t0); world.setTimeOfDay(t); } catch {}
}
function timeBack(p) { const t0 = TODS.get(p.id); if (t0 === undefined) return; TODS.delete(p.id); try { world.setTimeOfDay(t0); } catch {} }
/* 第124版(fix2): 場面・章の 始まりの 引きの 絵（暗い 所から 高い 引き → ゆっくり 寄る）*/
export async function openWide(p, nm) {
  const S = stageOf(p); if (!S) return false;
  fadeOn(p, "0 0.3 0.8", "0 0 0", true); camAt(p, S.at(-10, 6 * S.side, 7.5), S.at(4, 0, 1), 0);
  if (nm) cineCard(p, `§f― ${nm} ―`, 60);
  await wait(28);
  camAt(p, S.at(-6.5, 3.6 * S.side, 4.4), S.at(3.5, 0, 1.2), 1.3); await wait(26);
  return true;
}
/* 第124版(fix2): 場面の 終わり: 引いて から 暗転（ぷつっと 一人称に もどさない）*/
export async function closeWide(p) {
  if (!inScene(p)) return; const S = stageOf(p); if (!S) return;
  if (FTK - (FADE_AT.get(p.id) ?? -1e9) < 80 || fading(p)) return;   /* 場面が 自分で 暗転して 終わった */
  camAt(p, S.at(-11, 6.5 * S.side, 8), S.at(4, 0, 1), 2.2); await wait(30);
  if (!inScene(p)) return; camFade(p); await wait(10);
}
function lock(p) {
  const n = (LOCK.get(p.id) || 0) + 1; LOCK.set(p.id, n); if (n > 1) return;
  if (!cmd(p, "inputpermission set @s lateral_movement disabled")) { SLOW.add(p.id); try { p.addEffect("slowness", 20 * 600, { amplifier: 255, showParticles: false }); } catch {} }   /* 古い 版の マイクラだけ（足を 止める）*/
  for (const h of HUD) cmd(p, `hud @s hide ${h}`);
}
function release(p) {
  if (CAM.has(p.id)) { const g = GEN.get(p.id) || 0; system.runTimeout(() => { if (g !== (GEN.get(p.id) || 0) || LOCK.has(p.id) || !CAM.has(p.id)) return; CAM.delete(p.id); if (globalThis.__MQ_CAMON?.has(p.id)) return; SHOT.delete(p.id); cmd(p, "camera @s clear"); }, 6); }   /* すぐ 次の 会話が 始まれば カメラは そのまま */
  if (SLOW.has(p.id)) { SLOW.delete(p.id); try { p.removeEffect("slowness"); } catch {} }
  cmd(p, "inputpermission set @s lateral_movement enabled"); cmd(p, "inputpermission set @s jump enabled"); cmd(p, "hud @s reset");
}
function unlock(p) { const n = (LOCK.get(p.id) || 1) - 1; if (n > 0) { LOCK.set(p.id, n); return; } LOCK.delete(p.id); release(p); }
/* 第124版: 「バグを 直す」: 残った 会話・場面の 印を 外す（呼んだ 人だけ）*/
export function talkReset(p) { try { SCN.delete(p.id); PAUSE.delete(p.id); CUR.delete(p.id); LOCK.delete(p.id); SKIP.delete(p.id); MOOD.delete(p.id); release(p); } catch {} }
/* ワールドに 入りなおした とき: 会話の とちゅうで 抜けても 動けない ままに ならない */
try { world.afterEvents.playerSpawn.subscribe((ev) => { const p = ev.player; if (LOCK.has(p.id)) return; try { if (p.getEffect("slowness")?.amplifier === 255) p.removeEffect("slowness"); } catch {} if (!SCN.has(p.id)) cmd(p, "fog @s remove mq_shadow"); release(p); }); } catch {}   /* 影の 場面の 霧も のこさない */
/* せりふの 中身から しぐさを えらぶ（4 話す 5 手を ふる 6 拍手 9 喜ぶ 10 おじぎ 12 しょんぼり）*/
/* 第124版: 25 うなずく 26 首を ふる 27 腕を 組む 28 腰に 手 29 ガッツポーズ 30 額に 手 31 よろける。{nod}{no}{arms}{hips}{pump}{palm}{stagger} で 指定も できる */
const TAGACT = { nod: 25, no: 26, arms: 27, hips: 28, pump: 29, palm: 30, stagger: 31 };
const TALKV = [4, 4, 25, 4, 28, 4, 27];
/* 第124版(fix2): 場面の ポーズ: POSE（体の 位置）は 必ず 残す。HOLD（指さし・身構え など）は 強い 気持ちの 札が ない 行だけ 残す */
const POSE = new Set([1, 2, 3, 8, 11, 15, 20, 21]), HOLD = new Set([12, 16, 17, 18, 22, 23, 24]), OVR = ["shock", "rage", "cry", "tears", ...Object.keys(TAGACT)];
function gesture(l, tags = []) {   /* 第124版(fix2): 札（気持ち）を 先に 見る。「……」は 笑顔・怒りの 行では しょんぼりに しない */
  for (const t of tags) if (TAGACT[t]) return TAGACT[t];
  const s = plain(l), has = (...k) => k.some((t) => tags.includes(t)), sm = has("smile", "♪", "☆");
  let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;   /* 話す しぐさは 行ごとに かえる */
  if (has("shock")) return 31;
  if (has("rage")) return 17;
  if (has("cry", "tears") && !sm) return 30;
  if (/ありがと|よろしく|すまな|ごめん|申し訳/.test(s)) return 10;
  if (has("sad")) return 12;
  if (/やったぞ|よし[！、]|勝った|いくぞ|行くぞ|まかせ/.test(s)) return 29;
  if (/やれやれ|はあ……|まったく……|頭が 痛/.test(s)) return 30;
  if (/^(ちがう|いや|だめ|ありえない)|ちがうよ|そんな はず/.test(s)) return 26;
  if (/^(うん|うむ|ええ|そうだ|わかった|なるほど)|その とおり/.test(s)) return 25;
  if (/やった|すごい|ほっほ|あはは|おめでとう/.test(s)) return h % 2 ? 9 : 6;
  if (/おーい|やあ|じゃあな|またな|さらば/.test(s)) return 5;
  if (/……/.test(s) && !/！/.test(s) && !sm && !has("angry")) return 12;
  if (has("angry")) return 28;
  if (sm) return [4, 25, 6][h % 3];
  return TALKV[h % TALKV.length];
}
/* 相棒・モンスターの 役者: 喜ぶ 行で 小さく はねる・こわい 行で ふるえる（teleport で 軽く）*/
function monReact(p, kind, sp = null) {   /* 第124版(fix2): 魔将・石像・話す 本人は 動かない。敵が 笑っても 喜ばない。動きは anim 1回（軽い）*/
  const S = stageOf(p); if (!S) return;
  if (kind === "joy" && /^§[c4]/.test(String((sp && sp.nameTag) || ""))) return;
  for (const e of S.ents) {
    if (!okE(e) || e.typeId === "mrpg:npc" || e === sp) continue;
    try { if (e.hasTag("mrpg_spkm") || /石/.test(String(e.nameTag || ""))) continue; } catch { continue; }
    anim(e, kind === "joy" ? "happy" : "guard");
  }
}
function face(e, p) { try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
/* 第123版: 話す 人は 相手を 向き、まわりの 人は 話す 人を 見る。カメラは 話す 人が かわった とき だけ 切りかえる */
/* 第124版: カメラの 演出（回さない）: びっくり・怒りは すばやく 寄る ／ 敵が はじめて 話す ときは 下から ／ 悲しい 行は 上から */
const FOE_SEEN = new Map();
const STRONG = (tags) => tags.some((t) => t === "shock" || t === "rage" || t === "cry" || t === "!" || t === "怒");
const moved = (p, sp) => { const L = LASTSHOT.get(p.id); try { return !L || !L.sp || L.sp.id !== sp.id || Math.hypot(sp.location.x - L.at.x, sp.location.z - L.at.z) > 0.7; } catch { return true; } };
function stagePlay(p, sp, tags, T) {
  const lis = speakTurn(p, sp); if (!lis) face(sp, p);
  const foe = /^§[c45]/.test(String(sp.nameTag || "")), seen = FOE_SEEN.get(p.id) || new Set(), first = foe && !seen.has(sp.id) && inScene(p);
  if (first) { seen.add(sp.id); FOE_SEEN.set(p.id, seen); }   /* 第124版(fix2): 札つきの 行でも「もう 見た」に する（下からの 絵を くり返さない）*/
  const lie = lying(sp); if (lie) tags = tags.map((t) => (t === "low" || t === "high" ? "up" : t));
  if (applyTags(p, sp, tags, T, lis)) { CUR.set(p.id, sp.id); return lis; }
  if (!inScene(p)) { if (CUR.get(p.id) !== sp.id || !CAM.has(p.id)) shot(p, sp, null, lis); CUR.set(p.id, sp.id); return lis; }
  let kind = null, ease = null;
  if (tags.includes("shock") || tags.includes("rage")) { kind = "up"; ease = 0; }
  else if (first) kind = lie ? "up" : "low";
  else if (tags.includes("sad") || tags.includes("cry")) kind = lie ? "up" : "high";
  if (!kind && CUR.get(p.id) === sp.id && CAM.has(p.id) && !moved(p, sp)) return lis;   /* 第120版: 同じ 人でも 動いた あとは 映しなおす */
  shot(p, sp, kind, lis, ease); CUR.set(p.id, sp.id);
  return lis;
}
/* 長い 行の あいだ ゆっくり 寄る（ドリー）。見通しが なければ 寄らない */
function dolly(p, T) {
  const L = LASTSHOT.get(p.id); if (!L || !inScene(p)) return;
  try { if (!okE(L.sp) || !L.at || Math.hypot(L.sp.location.x - L.at.x, L.sp.location.z - L.at.z) > 0.5) return; } catch { return; }   /* 第127版: 話す 人が 動いた あとは 古い 所へ 寄らない */
  const v = { x: L.look.x - L.pos.x, y: L.look.y - L.pos.y, z: L.look.z - L.pos.z }, d = Math.hypot(v.x, v.y, v.z); if (d < 1.9) return;
  const k = Math.min(0.22, 0.6 / d), q = { x: L.pos.x + v.x * k, y: L.pos.y + v.y * k, z: L.pos.z + v.z * k };
  if (camTo(p, q, L.look, Math.max(1, (T - 10) / 20), L.sp)) LASTSHOT.set(p.id, { ...L, pos: q });
}
/* 第124版(cam): 同じ 絵は 2行まで（物語の 話・saga・常世・魔神・ステージの 出来事 すべて）。3行目の 前に 絵を かえる
   話す 人: 寄り → 2人 → 反対の 肩ごし → 引き → ゆっくり 寄る ／ 地の文: 見て いる 所の まわりを 回る・寄る・引く */
const RUN2 = new Map();
function run2(p) { const n = CAMN.get(p.id) || 0; let r = RUN2.get(p.id); if (!r || r.n !== n) { r = { n, c: 0, k: r ? r.k : 0 }; RUN2.set(p.id, r); } return r; }
const SPV = ["up", "two", "ots2", "wide", "push"];
function push(p, sp) {
  const L = LASTSHOT.get(p.id); if (!L || L.sp !== sp) return false;
  const v = { x: L.look.x - L.pos.x, y: L.look.y - L.pos.y, z: L.look.z - L.pos.z }, d = Math.hypot(v.x, v.y, v.z); if (d < 2.2) return false;
  const k = Math.min(0.35, 1.4 / d), q = { x: L.pos.x + v.x * k, y: L.pos.y + v.y * k, z: L.pos.z + v.z * k };
  if (!camTo(p, q, L.look, 1.6, sp)) return false; LASTSHOT.set(p.id, { ...L, pos: q }); return true;
}
function keepFresh(p, sp, lis) {
  if (!inScene(p) || !camOn(p) || !stageOf(p)) return;
  const r = run2(p); if (r.c < 2) return;
  const n = SPV.length;
  let done = false;
  if (sp && okE(sp)) { for (let i = 0; i < n; i++) { const kd = SPV[(r.k + i) % n]; if (kd === "push" ? push(p, sp) : shot(p, sp, kd, lis && lis !== p ? lis : null, 0.6, true)) { r.k = (r.k + i + 1) % n; CUR.set(p.id, sp.id); done = true; break; } } }
  if (!done) {   /* 地の文（話す 人の 絵が どれも ふさがれば これも）: 見て いる 所の まわりを 回る・寄る・引く */
    const v = VIEWP.get(p.id), S = stageOf(p); if (!sp) CUR.delete(p.id);
    const C = []; if (v) { const o = { x: v.pos.x - v.look.x, y: v.pos.y - v.look.y, z: v.pos.z - v.look.z };
      for (const [deg, k, dy] of [[35, 1, 0], [0, 0.65, 0], [-35, 1.25, 0.8], [-60, 1, 0.3], [60, 0.8, 0.5]]) { const w = rot(o, deg); C.push([{ x: v.look.x + w.x * k, y: v.look.y + o.y * k + dy, z: v.look.z + w.z * k }, v.look, deg ? 1 : 1.8]); } }
    if (S) C.push([S.at(-7, 4.5 * S.side, 5.5), S.at(3, 0, 1), 1], [S.at(-3.5, -2.6 * S.side, 2.8), S.at(3, 0, 1.2), 1]);
    let ok2 = false; for (let i = 0; i < C.length; i++) { const [pos, look, e] = C[(r.k + i) % C.length]; if (!sameView(p, pos, look) && camTo(p, pos, look, e)) { r.k = (r.k + i + 1) % 5; ok2 = true; break; } }
    if (!ok2 && v) { const o = { x: v.pos.x - v.look.x, y: v.pos.y - v.look.y, z: v.pos.z - v.look.z }; for (const k of [0.75, 0.55, 1.2]) { const q = { x: v.look.x + o.x * k, y: v.look.y + o.y * k, z: v.look.z + o.z * k }; if (camTo(p, q, v.look, 1.4)) { ok2 = true; break; } } }   /* せまい 所: 同じ 向きで 寄る・引く */
    if (!ok2 && S) camAt(p, S.at(-3.4, 1.8 * S.side, 2.7), S.at(3, 0, 1.2), 0.8);
  }
  run2(p);
}
/* 強い 行の あとに 聞いて いる 人（旅の 仲間・あなた）の 顔へ 一瞬 切りかえる */
async function reaction(p, sp, lis, tags = []) {
  if (!inScene(p) || SKIP.has(p.id)) return;
  if (lis === p) { const S = stageOf(p); const h = S && S.ents.find((e) => okE(e) && e !== sp && e.hasTag?.("mrpg_hero")); if (h) lis = h; }   /* 第124版(fix2): 旅の 仲間を 先に（しゃべらない あなたの 顔ばかりに しない）*/
  if (!okE(lis) || lis === sp) return;
  if (lis !== p && lis.typeId === "mrpg:npc") try { dFace(lis, tags.includes("rage") || tags.includes("怒") ? "angry" : tags.includes("cry") ? "sad" : "shock", 20); } catch {}
  if (shot(p, lis, "up", sp, 0)) { await wait(18); CUR.delete(p.id); }
}
/* 1行ずつ 流す。長さに 合わせて 待つ（2〜7秒）*/
async function flow(p, text, bar, sp, act, tags = [], box = null, first = true, last = true) {
  if (!ok(p) || SKIP.has(p.id)) return;
  let sp0 = 1; try { const v = p.getDynamicProperty("mrpg:tspeed"); if (typeof v === "number") sp0 = v; } catch {}
  const T = Math.round(Math.min(120, 24 + plain(bar).replace(/§./g, "").length * 1.6) * [1.5, 1, 0.6][sp0]);
  let lis = null;
  if (sp && first) { const W = globalThis.__mqWalk; for (let i = 0; i < 60 && W && W.has(sp.id) && Date.now() - W.get(sp.id) < 5000; i++) await wait(1); }   /* 第120版: 歩いて 来る 人は 着いてから 話す（歩いて いる 所に カメラが 向いた ままに ならない）*/
  if (sp && first) lis = stagePlay(p, sp, tags, T);   /* 第124版(cam): 絵を 決めてから 行を 出す */
  keepFresh(p, sp, lis);
  if (first) globalThis.__mqLine?.(p, sp, text, tags, lis);   /* 第124版: 点検用（1行に 1回）*/
  if (!first) {} else if (inScene(p)) { const L = LOGS.get(p.id) || []; L.push(text); if (L.length > 60) L.shift(); LOGS.set(p.id, L); } else try { p.sendMessage(text); } catch {}   /* 第123版: 場面の あいだは 字幕だけ（チャットには 最後に まとめて）*/
  let keep = false;   /* 第124版(fix2): 場面の ポーズ（座る・寝る・ひざ・抱える など）は 話しても 消さない */
  if (sp) { let cur = 0; try { cur = sp.getProperty("mrpg:act") || 0; } catch {} keep = POSE.has(cur) || (HOLD.has(cur) && !tags.some((t) => OVR.includes(t))); try { if (!keep) sp.setProperty("mrpg:act", act); sp.setProperty("mrpg:mv", false); } catch {} if (!first) lis = stagePlay(p, sp, [], T); }
  run2(p).c++;   /* 第124版(fix2): 「同じ 絵は 2ページまで」（ページごとに 数える）*/
  if (first && sp && inScene(p)) { const s0 = plain(bar); if (tags.some((t) => t === "smile" || t === "♪" || t === "☆") || /やった|わーい|すごい/.test(s0)) monReact(p, "joy", sp); else if (tags.some((t) => t === "shock" || t === "sweat" || t === "汗" || t === "cry")) monReact(p, "fear", sp); }
  const longLine = sp && T >= 70;
  const cin = inScene(p), head = box ? `${box[0]}§l${box[1]}§r\n` : "", full = box ? `§f${box[2]}` : `§7${plain(bar).replace(/§./g, "")}`; let shown = 0;
  if (first && cin && sp && (tags.includes("shock") || tags.includes("rage"))) cineFx(p, "s", 14);   /* 集中線 */
  /* 第111版: 自動で 進む（速さは 設定）。ジャンプか しゃがむで 次へ・しゃがみ 長押しで スキップ */

  let held = 0, jw = true, rel = false; try { rel = !p.isSneaking; } catch { rel = true; }   /* 前から しゃがんで いたら 一度 はなすまで 長押しを 数えない */
  for (let t = 0; t < T; t += 5) {
    if (!ok(p)) break;
    if (cin) { if (shown < full.length) { shown = Math.min(full.length, shown + 7); if (full[shown - 1] === "§") shown++; hudSend(p, "MQD", `${head}${full.slice(0, shown)}${shown >= full.length ? "\n§8ジャンプ: 次へ ／ しゃがみ 長押し: スキップ" : ""}`); } }   /* 第125版: 会話の 枠に 1文字ずつ */
    else if (t % 20 === 0) try { barNote(p); p.onScreenDisplay.setActionBar(`${bar}\n§8ジャンプ: 次へ ／ しゃがみ 長押し: スキップ`); } catch {}
    if (longLine && t === 10) dolly(p, T);
    let sn = false, jp = false; try { sn = p.isSneaking; jp = p.isJumping; } catch {}
    if (jp && !jw && t >= 5) break;   /* ジャンプ（押した とき）→ 次へ */
    jw = jp;
    if (!rel) { if (!sn) rel = true; await wait(5); continue; }
    if (sn) { held += 5; if (held >= 30) { SKIP.add(p.id); try { barNote(p); p.onScreenDisplay.setActionBar("§7会話を スキップ"); } catch {} break; } }
    else if (held > 0) { if (t >= 10) break; held = 0; }   /* 短く しゃがんで はなした → 次へ */
    await wait(5);
  }
  if (sp && !keep) try { const b = sp.getDynamicProperty("mrpg:act0"); sp.setProperty("mrpg:act", typeof b === "number" ? b : 0); } catch {}
  if (last && sp && lis && STRONG(tags)) await reaction(p, sp, lis, tags);
}
export async function talk(p, who, lines, col = "§6") {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { for (const l0 of [].concat(lines)) { const l = parseTags(l0)[1]; await notice(p, who, /^§7→/.test(l) ? l : `${col}§l${who}§r\n\n§f「${l}」`); } return; }   /* 模擬テスト用 */
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (SKIP.has(p.id)) { LAST.set(p.id, Date.now()); return; }
  let sp = null; try { if (!/手紙|声|心の/.test(plain([].concat(lines)[0]))) sp = FIND ? FIND(p, who) : null; } catch {}
  lock(p);
  try {
    for (const l of [].concat(lines)) {
      if (SKIP.has(p.id)) break;
      if (/^§7→/.test(l)) { const pg = boxPages(l); for (let k = 0; k < pg.length; k++) { if (SKIP.has(p.id)) break; await flow(p, l, pg[k], null, 0, [], null, k === 0, k === pg.length - 1); } continue; }
      const [tg, l2] = parseTags(l), pg = boxPages(l2), g = gesture(l2, tg);   /* 第126版: 長い せりふは ページに 分けて 順に */
      for (let k = 0; k < pg.length; k++) { if (SKIP.has(p.id)) break; await flow(p, `${col}§l${who}§r§f「${l2}」`, `${col}${who}§f${k ? "" : "「"}${pg[k]}${k === pg.length - 1 ? "」" : ""}`, sp, g, tg, [col, who, pg[k]], k === 0, k === pg.length - 1); }
    }
  } finally { unlock(p); LAST.set(p.id, Date.now()); if (inScene(p)) hudSend(p, "MQD", ""); }
}
export async function tell(p, title, lines) {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { await notice(p, title, [].concat(lines).join("\n")); return; }
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (SKIP.has(p.id)) { LAST.set(p.id, Date.now()); return; }
  lock(p);
  try { for (const l of [].concat(lines).flatMap((x) => String(x).split("\n"))) { if (SKIP.has(p.id)) break; if (!l.replace(/§./g, "").trim()) continue; const pg = boxPages(l); for (let k = 0; k < pg.length; k++) { if (SKIP.has(p.id)) break; await flow(p, `§7${l}`, `§f${pg[k]}`, null, 0, [], null, k === 0, k === pg.length - 1); } } }
  finally { unlock(p); LAST.set(p.id, Date.now()); if (inScene(p)) hudSend(p, "MQD", ""); }
}
