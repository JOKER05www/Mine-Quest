// 第108版: 物語の 会話を フォームで 止めない。せりふは チャットと 画面下の 文字に 流れ、動きながら 聞ける（しゃがむと 早送り）
import { notice, wait, ok, barNote } from "./ui.js";
const plain = (s) => String(s || "");
/* 1行ずつ 流す。長さに 合わせて 待つ（2〜7秒）。プレイヤーが ぬけたら やめる */
async function flow(p, text, bar) {
  if (!ok(p)) return;
  try { p.sendMessage(text); } catch {}
  const len = plain(bar).replace(/§./g, "").length, T = Math.min(140, 40 + len * 2);
  for (let t = 0; t < T; t += 5) {
    if (!ok(p)) return;
    if (t % 20 === 0) try { barNote(p).setActionBar(bar); } catch {}
    let sn = false; try { sn = p.isSneaking; } catch {}
    if (sn && t >= 10) break;
    await wait(5);
  }
}
export async function talk(p, who, lines, col = "§6") {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { for (const l of [].concat(lines)) await notice(p, who, /^§7→/.test(l) ? l : `${col}§l${who}§r\n\n§f「${l}」`); return; }   /* 模擬テスト用 */
  for (const l of [].concat(lines)) {
    if (/^§7→/.test(l)) { await flow(p, l, l); continue; }
    await flow(p, `${col}§l${who}§r§f「${l}」`, `${col}${who}§f「${l}」`);
  }
}
export async function tell(p, title, lines) {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { await notice(p, title, [].concat(lines).join("\n")); return; }
  for (const l of [].concat(lines).flatMap((x) => String(x).split("\n"))) { if (!l.replace(/§./g, "").trim()) continue; await flow(p, `§7${l}`, `§f${l}`); }
}
