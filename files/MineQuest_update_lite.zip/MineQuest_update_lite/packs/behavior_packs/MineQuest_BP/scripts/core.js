// v2.0: 能力9種・攻撃の種類4つ（物理系・武系・息系・魔法系）・属性10・状態異常10・封印・行動順の逆転・反射
import { MOVES, SKILLS, SPECIES, KSP, ORDER, RANKS, RANK_MULT, ITEMS, EGGS, RECIPES4, RES_MULT, TRAITS, CATS, NATURES, FAM_MIX, FAM_MIX3, ROMAN, FAMILIES,
  STATS as D_STATS, ST_NAME as D_ST_NAME, ST_COL, EL_NAME, EL_COL, AILS, AIL_NAME, AIL_KANA, CAT_COL, KINDS, KIND_COL, RES_NAME, RANK_STAT, ITEM_EVO, LINE_INFO, COMBOS, WKIND, WEATHER, ATTR_FAM, ATTR_NAME, CRAFT_DROP, BIRD_OLD, OLD_NAMES } from "./data.js";
import { mergeGear } from "./gear.js";
export const gearOf = (m, slot) => (m.eq && m.eq[slot] && ITEMS[m.eq[slot]] ? mergeGear(m.eq[slot], m.eqr && m.eqr[slot]) : null);

export const MAXLV = 100;
export const STAT_MAX = 9999;
/* 第100版: HPだけ 上限なし（ほかの 能力は 9999 まで） */
export const capStat = (k, v) => (k === "hp" ? Math.max(1, v) : Math.max(1, Math.min(STAT_MAX, v)));
export const STATS = D_STATS;                       // hp mp atk def mat mdf spd wpn brt
export const ST_NAME = { eva: "回避", acc: "命中", ...D_ST_NAME };   // v2.9.11: 回避・命中の 名前（「undefined」と 出ていた）
export const stName = (k) => `${ST_COL[k] || "§f"}${ST_NAME[k] || k}§r`;
export const BUF_KEYS = ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"];
export const ATTACK = { name: "攻撃", kind: "attack", type: "phys", cat: "phys", target: "enemy", mp: 0, mult: 1.0, basic: true, tier: 0 };
export const STATUS_NAME = AIL_NAME;

export const rnd = (a, b) => a + Math.random() * (b - a);
export const ri = (a, b) => Math.floor(rnd(a, b + 1));
export const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const alive = (a) => a.filter((f) => f.hp > 0);
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
export const rankIdx = (sp) => RANKS.indexOf(SPECIES[sp].rank);
// v2.1: 闘魔覚醒（見た目は そのまま ランクが SS / X に）
export const rankOfM = (m) => (m && m.awk) || SPECIES[m.sp]?.rank || "F";
export const rankIdxM = (m) => RANKS.indexOf(rankOfM(m));
function weighted(obj) {
  const tot = Object.values(obj).reduce((a, b) => a + b, 0);
  let r = Math.random() * tot;
  for (const [k, v] of Object.entries(obj)) { r -= v; if (r <= 0) return k; }
  return Object.keys(obj)[0];
}

// ---- 成長（v2: 経験値・お金を 多めに）----
export const expNeed = (lv) => Math.floor(5 * lv * lv + 8);
export const spGain = (lv) => 3;   // v2.9.12: 1レベルで 3（序盤の 能力の 伸びすぎを ふせぐ）
export function totalSpAt(lv) { let s = 0; for (let l = 2; l <= lv; l++) s += spGain(l); return s; }
// v2.9.12: レベルに 見あう SPが ない 子には たりない ぶんを わたす（多い ぶんは そのまま）
export function fixSp(m) {
  if (!m || !Array.isArray(m.pts)) return 0;
  const used = m.pts.reduce((a, x) => a + (x || 0), 0) + (m.spl || 0), need = totalSpAt(m.lv || 1);
  if (used < need) { m.spl = (m.spl || 0) + need - used; return need - used; }
  return 0;
}
// v3.0: 経験値・お金を へらす（4番目の 石板の 主 Lv44 の ころに Lv80 に なって いたため。いまは Lv50 前後）
export const EXP_RATE = 0.25, GOLD_RATE = 0.4;
export const expYield = (f) => f.fled ? 0 : Math.floor((f.lv * f.lv * 3.4 + 14) * EXP_RATE * (SPECIES[f.m.sp].metalmon ? (RANK_MULT[SPECIES[f.m.sp].rank] || 1) : (RANK_MULT[SPECIES[f.m.sp].rank] || 1) ** 0.8) *   /* 第63版: 後半ほど 早く 上がりすぎた（ハガネ族は そのまま） */ (SPECIES[f.m.sp].expx || 1));
export const goldYield = (f) => Math.floor((f.lv * 12 + 10) * GOLD_RATE * (RANK_MULT[SPECIES[f.m.sp].rank] || 1) * rnd(0.85, 1.2));
// v3.0: 相手より レベルが 高すぎる 子は 経験値が へる（+3 から 1ごとに -12%・最低 10%）。低い 子は 少し ふえる（最大 1.5倍）
export const expGapMul = (myLv, foeLv) => { const d = (myLv || 1) - (foeLv || 1); return d > 2 ? Math.max(0.1, 1 - (d - 2) * 0.12) : d < 0 ? Math.min(1.5, 1 - d * 0.05) : 1; };

// ---- 性格 ----
export const rollNature = () => Math.floor(Math.random() * NATURES.length);
export function natureText(i) {
  const n = NATURES[i]; if (!n) return "?";
  return n.up ? `${n.name}§7（${ST_NAME[n.up]}↑ ${ST_NAME[n.down]}↓）` : `${n.name}§7（補正なし）`;
}

export function migrate(m) {
  if (typeof m.nat !== "number" || !NATURES[m.nat]) m.nat = rollNature();
  if (!m.id) m.id = uid();
  if (!SPECIES[m.sp]) return m;
  if (Array.isArray(m.rtr) && SPECIES[m.sp].sz === "S" && ["F", "E", "D"].includes(SPECIES[m.sp].rank) && m.rtr.some((t) => ACT_TR.includes(t))) m.rtr = m.rtr.filter((t) => !ACT_TR.includes(t));   // v3.0: F〜D の Sサイズは 2回行動なし（前の セーブも）
  if ((BIRD_OLD[m.sp] && m.nm === BIRD_OLD[m.sp]) || (OLD_NAMES[m.sp] && OLD_NAMES[m.sp].includes(m.nm)) || !m.nm) m.nm = SPECIES[m.sp].name;   // v2.9.6: 種族の 名前が かわった 子は 新しい 名前に（自分で つけた 名前は そのまま）
  if (typeof m.lv !== "number" || !(m.lv >= 1) || m.lv > 100) m.lv = Math.max(1, Math.min(100, Math.floor(Number(m.lv) || 1)));   // v2.9.12
  if (!Array.isArray(m.sk) || !m.sk.length || m.sk.some((s) => !SKILLS[s])) { const prev = (Array.isArray(m.pts) ? m.pts.reduce((a, x) => a + (x || 0), 0) : 0) + (m.spl || 0); m.sk = [...SPECIES[m.sp].skills]; m.pts = m.sk.map(() => 0); m.spl = Math.max(totalSpAt(m.lv), prev); }   // v2.9.12: 振った ぶんは もどす
  if (!Array.isArray(m.pts)) m.pts = [0, 0, 0];
  ensureSkills(m);
  if (typeof m.plus !== "number") m.plus = 0;
  if (!m.eq) m.eq = { w: null, a: null, x: null };
  for (const s of ["w", "a", "x"]) { if (m.eq[s] && typeof m.eq[s] === "object" && typeof m.eq[s].id === "string") m.eq[s] = m.eq[s].id; if (m.eq[s] && !ITEMS[m.eq[s]]) m.eq[s] = null; }   // v3.0: {id} の 形も 読む
  if (!m.bonus) m.bonus = {};
  delete m.iv;
  if (!m.tal || typeof m.tal !== "object") m.tal = rollTal();
  for (const k of STATS) if (typeof m.tal[k] !== "number") m.tal[k] = ri(0, TAL_MAX);
  if (m.lm) m.lm = Array.isArray(m.lm) ? m.lm.filter((x) => MOVES[x]) : [];
  return m;
}

// ---- サイズ ----
export const SIZE_SLOT = { S: 1, M: 2, L: 3, G: 4 }, PARTY_CAP = 4, PARTY_MAX = 4;
export const SIZE_NAME = { S: "Sサイズ", M: "Mサイズ", L: "Lサイズ", G: "Gサイズ（ギガ）" };
const SZ_MULT = { S: { hp: 0.92, mp: 1.05, spd: 1.1 }, M: { hp: 1.05, atk: 1.03, wpn: 1.03 }, L: { hp: 1.25, atk: 1.12, wpn: 1.1, def: 1.1, brt: 1.1, spd: 0.92 },
  G: { hp: 1.5, mp: 1.2, atk: 1.25, wpn: 1.2, def: 1.2, mat: 1.2, mdf: 1.15, brt: 1.2, spd: 0.9 } };
export const SZ_TARGET = { S: 0.62, M: 1.05, L: 4.4, G: 6.0 };
// v2.1: 大きい ほど レベルアップの 伸びが 大きい
export const GROW_SZ = { S: 1.0, M: 1.3, L: 1.75, G: 2.1 };   // v3.0 第63版: L を 少し 強く
export const sizeOf = (m) => m.sz || SPECIES[m.sp]?.sz || "M";
export const SKILL_N = { S: 3, M: 4, L: 5, G: 6 };
const SKILL_FB = ["up_hp0", "cheer0", "fist0", "heal0", "guardian0", "weaken0"];
export function skillPool(sp) { return [...new Set([...SPECIES[sp].skills, ...(SPECIES[sp].skx || []), ...SKILL_FB])].filter((x) => SKILLS[x]); }
// v2.7: 固有スキル（SS・X・神々）は スキル枠の ほかに 1つ
export const uniqOf = (sp) => SPECIES[sp]?.uniq || null;
export const slotN = (m) => (SKILL_N[sizeOf(m)] || 3) + (uniqOf(m.sp) ? 1 : 0) + (m.tm ? 1 : 0);   // v3.0: 闘魔覚醒で スキル枠 +1
export const TM_STAT = 1.25;
export const isUniqSk = (sk) => !!SKILLS[sk]?.uniq;
// v2.9.12: 小さく なった・小さい 種族に 進化した ときは 枠を こえた スキルを はずす（振った SPは もどす）
export function trimSkills(m, log) {
  const n = slotN(m); if (!Array.isArray(m.sk) || m.sk.length <= n) return;
  if (!Array.isArray(m.pts)) m.pts = m.sk.map(() => 0);
  while (m.sk.length > n) {
    let i = m.sk.length - 1; while (i >= 0 && isUniqSk(m.sk[i])) i--; if (i < 0) break;
    m.spl = (m.spl || 0) + (m.pts[i] || 0); const nm = SKILLS[m.sk[i]]?.name; m.sk.splice(i, 1); m.pts.splice(i, 1);
    if (log && nm) log.push(`§7スキル「${nm}」は 枠に 入らないので はずれた（振った ぶんは もどった）`);
  }
}
export function ensureSkills(m) {
  // ほかの 種族の 固有スキルは はずす（振った ぶんは もどす）
  for (let i = m.sk.length - 1; i >= 0; i--) if (isUniqSk(m.sk[i]) && SKILLS[m.sk[i]].uniq !== m.sp) { m.spl = (m.spl || 0) + ((m.pts || [])[i] || 0); m.sk.splice(i, 1); if (Array.isArray(m.pts)) m.pts.splice(i, 1); }
  const u = uniqOf(m.sp);
  if (u && SKILLS[u] && !m.sk.includes(u)) { m.sk.unshift(u); if (Array.isArray(m.pts)) m.pts.unshift(0); }
  const n = slotN(m);
  for (const s of skillPool(m.sp)) {
    if (m.sk.length >= n) break;
    if (!m.sk.includes(s)) m.sk.push(s);   // v2.9.12: スキル枠が ふえても SPは ふえない（SPは レベルと 道具だけ）
  }
  while (m.pts.length < m.sk.length) m.pts.push(0);
  return m;
}
// v2.2: 才能（0〜31）。能力ごとに きまる 生まれつきの 素質
export const TAL_MAX = 31;
export function rollTal(q = 0) { const t = {}; for (const k of STATS) { let v = ri(0, TAL_MAX); if (q > 0 && Math.random() < q) v = Math.max(v, ri(0, TAL_MAX)); t[k] = v; } return t; }
export const talMul = (v) => 0.92 + 0.16 * ((v ?? 16) / TAL_MAX);
export function talLabel(v) { return v >= 31 ? "§6天賦" : v >= 26 ? "§d秀逸" : v >= 16 ? "§a良好" : v >= 1 ? "§f平凡" : "§8無才"; }
export function talTotal(m) { return STATS.reduce((s, k) => s + ((m.tal && m.tal[k]) ?? 16), 0); }
export function talTotalLabel(m) { const t = talTotal(m), mx = TAL_MAX * STATS.length; return t >= mx * 0.8 ? "§6類まれな 才能の 持ち主！" : t >= mx * 0.65 ? "§d優秀な 才能を 持っている" : t >= mx * 0.5 ? "§a平均より 上の 才能" : "§7まだまだ これからの 才能"; }
export function inheritTal(parents) {
  const t = rollTal(); const ks = [...STATS].sort(() => Math.random() - 0.5).slice(0, parents.length >= 4 ? 5 : 3);
  for (const k of ks) t[k] = Math.max(...parents.map((p) => (p.tal && p.tal[k]) ?? ri(0, TAL_MAX)));
  return t;
}
export const hiddenOf = (m) => (m && m.ht && SPECIES[m.sp]?.ht) || null;
export function giveHidden(m, chance) { if (!m.ht && Math.random() < chance) m.ht = true; return m; }
export const BENCH_MAX = 4;   // 第68版: 裏（スタンバイ）は 表と 同じ 4枠
export const slotOf = (m) => SIZE_SLOT[sizeOf(m)] || 1;
export const partyUse = (d) => d.party.reduce((s, m) => s + slotOf(m), 0);
export const canJoin = (d, m) => partyUse(d) + (m ? slotOf(m) : 1) <= PARTY_CAP;
export const benchUse = (d) => (d.bench || []).reduce((s, m) => s + slotOf(m), 0);
export const canBench = (d, m) => benchUse(d) + (m ? slotOf(m) : 1) <= BENCH_MAX;   /* 第68版 */
/* 第69版: 表が 全員 倒れて 裏に 元気な 子が いれば 表と 裏を まるごと 入れかえる（どちらも 4枠 以内） */
export const canFight = (d) => !!d && [...(d.party || []), ...(d.bench || [])].some((m) => m && m.hp > 0);
export function promoteBench(d) {
  if (!d || !Array.isArray(d.party) || d.party.some((m) => m && m.hp > 0) || !(d.bench || []).some((m) => m && m.hp > 0)) return false;
  const t = d.party; d.party = d.bench; d.bench = t; fixParty(d);
  if (d.out && !d.party.some((m) => m.id === d.out)) d.out = null;
  return true;
}
// 枠を こえたら 後ろから 預かり所へ（v2.2: 控えは なし）
export function fixParty(d) {
  const moved = [];
  d.bench = d.bench || [];
  while (partyUse(d) > PARTY_CAP && d.party.length > 1) { const m = d.party.pop(); d.box.push(m); moved.push(m); }
  while (benchUse(d) > BENCH_MAX && d.bench.length) { const m = d.bench.pop(); d.box.push(m); moved.push(m); }   /* 第68版 */
  return moved;
}
// v2.6: 完全個体「極」＝ 才能 すべて 最大・固有特性あり・個体の 特性が すべて 相性◎
export function isKiwami(m) {
  const S = SPECIES[m.sp]; if (!S || !m.ht || !m.tal) return false;
  if (!STATS.every((k) => (m.tal[k] ?? 0) >= TAL_MAX)) return false;
  const pool = S.tpool || []; if (!pool.length || !pool.some(([, w]) => w > 1)) return true;   // 相性◎の 候補が ない 種族は 才能＋固有特性だけ
  const base = S.traits || [], w = Object.fromEntries(pool);
  const own = Array.isArray(m.rtr) ? m.rtr : [];
  const changed = own.filter((t, i) => t !== base[i]);
  return changed.length > 0 && changed.every((t) => (w[t] || 0) > 1);
}
export function addMon(d, m) {
  // v2.5.5: ランクごとに 仲間に した かず（再会の石板の 解放に つかう）
  try { const R = SPECIES[m.sp]?.rank; if (R) { d.recR = d.recR || {}; d.recI = Array.isArray(d.recI) ? d.recI : []; if (m.noRec || SPECIES[m.sp]?.hidden) { delete m.noRec; } else if (!m.id || !d.recI.includes(m.id)) { if (m.id) { d.recI.push(m.id); if (d.recI.length > 3000) d.recI.splice(0, d.recI.length - 3000); } d.recR[R] = (d.recR[R] || 0) + 1; } } } catch {}   /* 第69版: 同じ 子は 2度 数えない */
  // v2.6: かがやき図鑑・固有特性図鑑・完全個体「極」
  try { const ix = SPECIES[m.sp].idx; d.eg = d.eg || {}; const ad = (k) => { d.eg[k] = d.eg[k] || []; if (!d.eg[k].includes(ix)) d.eg[k].push(ix); };
    if (m.shiny) ad("sh"); if (m.ht) ad("htd"); if (isKiwami(m)) { m.kw = true; ad("kw"); } } catch {}
  if (canJoin(d, m)) { d.party.push(m); return "party"; }
  d.box.push(m); return "box";
}

// ---- 装備できるか（モンスターごとに 武器・防具・アクセサリーの 種類が きまっている）----
export const EQ_KIND = { w: "weapon", a: "armor", x: "acc" };
export function canEquip(m, id) {
  const it = ITEMS[id]; const sp = SPECIES[m.sp];
  if (!it || !sp) return false;
  if (m.look) return true;                                               // 相棒は なんでも 装備できる
  if (it.lfam) return it.lfam === sp.fam;                                // v2.6: 伝説の 装備は その 系統なら だれでも
  if (it.kind === "weapon") return (sp.eqw || []).includes(it.wtype);
  if (it.kind === "armor") return (sp.eqa || []).includes(it.atype) || !!m.look;
  if (it.kind === "acc") return (sp.eqx || ["ring", "neck", "charm"]).includes(it.atype) || !!m.look;
  return false;
}
export function equipText(sp) {
  const s = SPECIES[sp]; const W = { sword: "剣", club: "棍棒", axe: "斧", bow: "弓", tome: "魔本", spear: "槍", gun: "銃", dual: "二刀流", staff: "杖", claw: "爪", fan: "扇", chakram: "戦輪", whip: "鞭", odd: "呪具", katana: "刀", scythe: "鎌" }, A = { light: "軽装", heavy: "重装", robe: "法衣" }, X = { ring: "指輪", neck: "首飾り", charm: "護符" };
  return `§6武器§r ${(s.eqw || []).map((x) => W[x] || x).join("・") || "なし"}  §6防具§r ${(s.eqa || []).map((x) => A[x]).join("・")}  §6装飾§r ${(s.eqx || []).map((x) => X[x]).join("・")}`;
}

export function calcStats(m) {
  if (m && m.awk && !m.tm) m.tm = true;   // 前の 版で 闘魔覚醒した 子も 同じ 効果に
  const s = SPECIES[m.sp];
  const szm = SZ_MULT[sizeOf(m)] || {};
  const st = {};
  const pl = (1 + (m.plus || 0) / 100) * (1 + Math.min(5, m.lim || 0) * 0.04) * (m.awk && RANK_STAT[m.awk] && RANK_STAT[s.rank] ? RANK_STAT[m.awk] / RANK_STAT[s.rank] : 1) * (m.tm ? TM_STAT : 1);   // v3.0: 闘魔覚醒は さらに 能力 +25%
  const gk = GROW_SZ[sizeOf(m)] || 1;
  const nat = NATURES[m.nat] || {};
  for (const k of STATS) {
    const nm = nat.up === k ? 1.1 : nat.down === k ? 0.9 : 1;
    st[k] = Math.floor((s.base[k] + s.grow[k] * gk * (m.lv - 1)) * pl * nm * talMul(m.tal && m.tal[k]) * (szm[k] || 1) * (m.look ? 1.1 : 1)) + ((m.bonus && m.bonus[k]) || 0);
  }
  // v2.2: 配合で 受けついだ 能力（レベルが 低い うちは この 値が 下限に なる）
  if (m.inh) for (const k of STATS) if (m.inh[k] > st[k]) st[k] = m.inh[k];
  m.sk.forEach((sk, i) => { for (const e of SKILLS[sk]?.list || []) if (e.stat && m.pts[i] >= e.pt) st[e.stat] += e.val; });
  for (const slot of ["w", "a", "x"]) {
    const it = gearOf(m, slot);
    if (it) for (const k of STATS) if (it[k]) st[k] += it[k];
  }
  for (const k of STATS) st[k] = capStat(k, st[k]);
  return st;
}

export function getMoves(m) {
  const r = [];
  const sg = SPECIES[m.sp]?.sig;
  if (sg && MOVES[sg] && m.lv >= (SPECIES[m.sp].siglv || 1)) r.push(sg);
  for (const id of SPECIES[m.sp]?.ext || []) if (MOVES[id] && !r.includes(id)) r.push(id);   // v2.2: 種族の 専用技（いつでも）
  const s2 = SPECIES[m.sp]?.sig2;
  if (s2 && MOVES[s2] && m.lv >= (SPECIES[m.sp].siglv2 || 1)) r.push(s2);
  for (const id of m.lm || []) if (MOVES[id] && !r.includes(id)) r.push(id);
  // v2.7: 属性の 武器に 組みこまれた 技
  { const w = m.eq && m.eq.w && ITEMS[m.eq.w]; if (w && w.el && w.wtype) { const a = `wm_${w.el}_${w.wtype}`; if (MOVES[a] && !r.includes(a)) r.push(a); if ((w.tier || 0) >= 2 && MOVES[a + "2"] && !r.includes(a + "2")) r.push(a + "2"); } }
  m.sk.forEach((sk, i) => { for (const e of SKILLS[sk]?.list || []) if (e.move && MOVES[e.move] && m.pts[i] >= e.pt && !r.includes(e.move)) r.push(e.move); });
  return r;
}

// v3.0: 戦いで 使う 技は 6つまで（覚えた 技の 中から えらぶ。えらんで いない 枠は おまかせで うめる）
export const MSET_MAX = 6;
function autoScore(m, id) {
  const mv = MOVES[id]; if (!mv) return -1;
  const S = SPECIES[m.sp] || {}, role = S.role || (S.aff || {}).gc, ge = (S.aff || {}).ge || [];
  if (id === S.sig || id === S.sig2) return 1000;
  if ((S.ext || []).includes(id)) return 900;   /* 第67版: 種族 専用技も 優先 */
  const atk = mv.kind === "attack" || mv.kind === "drain";
  let v = (mv.tier || 0) * 10 + (mv.mult || 0) * (mv.hits || 1) * (mv.target === "enemies" ? 1.2 : 1) * 5;
  if (atk && mv.cat === role) v += 40; else if (atk) v += 10;
  if (atk && mv.el && ge.includes(mv.el)) v += 8;
  if (mv.heal || mv.revive) v += 30;
  if (mv.refl || mv.buff || mv.dispel || mv.cover || mv.norevive) v += 18;
  if (mv.ail || mv.seal || mv.death) v += 12;
  if (mv.hpcost || mv.selfko || mv.recoil) v -= 15;
  return v;
}
export function autoMoveSet(m, all = getMoves(m), keep = []) {
  const out = [...keep];
  for (const sg of [SPECIES[m.sp]?.sig, SPECIES[m.sp]?.sig2]) if (sg && all.includes(sg) && !out.includes(sg) && out.length < MSET_MAX) out.push(sg);   /* 第103版: 覚えた 固有技は おまかせで かならず 入れる */
  const rest = all.filter((id) => !out.includes(id)).sort((a, b) => autoScore(m, b) - autoScore(m, a));
  // 回復か 補助を 1つは 入れる（あれば）
  const need = [(id) => MOVES[id]?.heal || MOVES[id]?.revive, (id) => MOVES[id]?.buff || MOVES[id]?.refl || MOVES[id]?.dispel];
  for (const f of need) { if (out.length >= MSET_MAX || out.some(f)) continue; const x = rest.find(f); if (x && autoScore(m, x) > 25) { out.push(x); rest.splice(rest.indexOf(x), 1); } }
  for (const id of rest) { if (out.length >= MSET_MAX) break; out.push(id); }
  return out.slice(0, MSET_MAX);
}
export function battleMoves(m) {
  const all = getMoves(m);
  if (all.length <= MSET_MAX && !Array.isArray(m.mset)) return all;
  const chosen = Array.isArray(m.mset) ? m.mset.filter((id, i, A) => all.includes(id) && A.indexOf(id) === i).slice(0, MSET_MAX) : [];
  if (Array.isArray(m.mset) && m.msetFix && chosen.length) return chosen;   // v3.0 第63版: 空なら おまかせ。ぜんぶ 自分で えらんだ（空きも そのまま）
  return autoMoveSet(m, all, chosen);
}
const RES_ORDER = { "-1": 1.5, "0": 1, "1": 0.5, "3": 0.25, "2": 0, "4": -0.5 };
export function resOf(m) {
  const r = { ...(SPECIES[m.sp].res || {}) };
  for (const slot of ["a", "x"]) {
    const it = gearOf(m, slot);
    if (it && it.res) for (const [el, v] of Object.entries(it.res)) if (RES_ORDER[v] < RES_ORDER[r[el] ?? 0]) r[el] = v;
  }
  return r;
}
export const aresOf = (m) => ({ ...(SPECIES[m.sp].ares || {}) });

export function autoAlloc(m) {
  let guard = 0;
  while (m.spl > 0 && guard++ < 500) {
    const open = m.pts.map((_, i) => i).filter((i) => m.pts[i] < skMax(m.sk[i]));
    if (!open.length) break;
    const i = pick(open);
    const n = Math.min(m.spl, ri(1, 6), skMax(m.sk[i]) - m.pts[i]);
    m.pts[i] += n; m.spl -= n;
  }
}
// 状況に あわせて 厳選する（q: 0〜1。高いほど おすすめの 性格に なりやすい・プラス値が つく）
export function tuneMonster(m, q = 0) {
  q = Math.max(0, Math.min(1, q));
  if (Math.random() < q * 0.8 && typeof SPECIES[m.sp].rec === "number") m.nat = SPECIES[m.sp].rec;
  m.plus = (m.plus || 0) + Math.floor(q * q * 12);
  if (q > 0) { m.tal = m.tal || rollTal(); for (const k of STATS) if (Math.random() < q * 0.6) m.tal[k] = Math.max(m.tal[k], ri(0, TAL_MAX)); }
  const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  return m;
}

// ---- 技の 説明・ラベル ----
const TGN = { enemy: "敵1体", enemies: "敵全体", ally: "味方1体", allies: "味方全体", self: "自分", all: "敵味方 全員（自分以外）", rand2: "敵 ランダム2体" };
export function moveLabel(id) {
  const mv = MOVES[id] || id; if (!mv) return "";
  const c = mv.cat && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless") ? `${CAT_COL[mv.cat]}【${CATS[mv.cat]}】` : `${KIND_COL[mv.kind] || "§7"}【${KINDS[mv.kind] || "特殊"}】`;
  const atkK = mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless";
  const e = (mv.el ? `${EL_COL[mv.el]}【${EL_NAME[mv.el]}】` : atkK && mv.mult ? "§7【無属性】" : "") + (mv.el2 ? `${EL_COL[mv.el2]}【${EL_NAME[mv.el2]}】` : "");
  return `${c}${e}§r`;
}
const GOD_N = { amaterasu: "アマテラス", tsukuyomi: "ツクヨミ", susanoo: "スサノオ", takemikazuchi: "タケミカヅチ", thor: "トール", odin: "オーディン", poseidon: "ポセイドン", hades: "ハデス",
  athena: "アテナ", apollon: "アポロン", kronos: "クロノス", freya: "フレイヤ", loki: "ロキ", hephaestus: "ヘパイストス", anubis: "アヌビス" };
export function moveDesc(id, short = false) {
  const mv = MOVES[id]; if (!mv) return "";
  const what = [];
  if (mv.mult) what.push(`威力 ${Math.round(mv.mult * 100)}%${mv.hitsR ? `×${mv.hitsR[0]}〜${mv.hitsR[1]}回` : mv.hits > 1 ? `×${mv.hits}回` : ""}`);
  if (mv.dispelhit) what.push("当てた 相手の 強化を かき消す");
  if (mv.mist) what.push(`${mv.turns || 3}ターン 敵も 味方も 呪文（魔法・回復・蘇生・再誕）を 使えなく する`);
  if (mv.nocover) what.push("かばう・挑発を 無視して ねらった 相手に 当たる（盾を くだく）");
  if (mv.norevive) what.push(`${mv.turns || 4}ターン 敵を よみがえれなく する（再誕・執念・復活を 消す）`);
  if (mv.finish) what.push("倒した 敵は よみがえれない（執念・再誕を 破る）");
  if (mv.absolute) what.push("回避・反射・身代わり・防御・軽減・踏ん張り・死線の執念・再誕・返し技を すべて 無視する");
  if (mv.cover) what.push("この ラウンド 味方への 単体攻撃を 自分が 引き受ける（先制）");
  if (mv.allmp) what.push("のこりの MPを すべて 使い、使った MPに 応じた ダメージを 敵全体に（硬力は 関係なし・身を固めた 相手には 半分・跳ね返されない）");
  if (mv.reraise) what.push(`倒れても すぐ HP${Math.round(mv.reraise * 100)}%で よみがえる 誓いを かける`);
  if (mv.dispel) what.push("強化（能力の 上昇・纏い・反射・軽減・再誕・溜め・真価）だけを かき消す");
  if (mv.trboost) what.push("自分の 良い 特性の 数値を 1.5倍に（2回まで）");
  if (mv.resdown) what.push(`${mv.turns || 3}ターン 属性の 耐性を 1段 弱める`);
  if (mv.selfko) what.push("自分が 倒れる かわりに 大ダメージ");
  if (mv.heal) what.push(`HPを 回復（${mv.heal >= 5 ? "全回復に 近い" : `回復力 ${Math.round(mv.heal * 100)}%`}）`);
  if (mv.revive) what.push(`倒れた 仲間を HP${Math.round(mv.revive * 100)}%で 生き返らせる`);
  if (mv.cure) what.push("状態異常を なおす");
  if (mv.regen) what.push(`${mv.regen}ターン 毎ターン HP回復`);
  if (mv.buff) for (const [k, v] of Object.entries(mv.buff)) what.push((k === "hp" || k === "mp") && v > 0 ? `${(mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless") ? "攻撃の あと 自分の " : ""}${k === "hp" ? "HP" : "MP"}を 最大の ${Math.round((k === "hp" ? 12 : 10) * v)}% 回復` : `${(mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless") ? "攻撃の あと 自分の " : v > 0 && ["enemy", "enemies", "rand2"].includes(mv.target) ? "自分の " : ""}${ST_NAME[k]}を ${Math.abs(v)}段階 ${v > 0 ? "上げる" : "下げる"}`);
  if (mv.ail) what.push(`${AIL_NAME[mv.ail]}に する（${Math.round((mv.chance || 0.5) * 100)}%）`);
  if (mv.death && !mv.cat) what.push(`即死させる（${Math.round(mv.death * 100)}%・ボス・ハガネ・Gサイズには 効かない）`);
  if (mv.seal === "all") what.push(`すべての 攻撃の 種類を ${mv.turns || 2}ターン 封じる（${Math.round((mv.chance || 1) * 100)}%）`);
  else if (mv.seal) what.push(`${CATS[mv.seal]}を ${mv.turns || 3}ターン 封じる（${Math.round((mv.chance || 1) * 100)}%）`);
  if (mv.refl) what.push(`${[].concat(mv.refl).map((c) => CATS[c]).join("・")}を ${mv.turns || 2}ターン 跳ね返す`);
  if (mv.reflel) what.push(`${EL_NAME[mv.reflel]}属性の 技を ${mv.turns || 3}ターン 跳ね返す`);
  if (mv.elguard) what.push(`${mv.turns || 4}ターン ${EL_NAME[mv.elguard]}属性の ダメージを 半分に（軽減）`);
  if (mv.elguard2) what.push(`${mv.turns || 3}ターン ${EL_NAME[mv.elguard2]}属性の ダメージを 1/4に（激減）`);
  if (mv.catguard) what.push(`${mv.turns || 3}ターン ${CATS[mv.catguard]}の ダメージを 半分に（軽減）`);
  if (mv.catguard2) what.push(`${mv.turns || 2}ターン ${CATS[mv.catguard2]}の ダメージを 1/4に（激減）`);
  if (mv.elmark) what.push(`${mv.turns || 3}ターン 敵が ${EL_NAME[mv.elmark]}属性で 受ける ダメージ +30%`);
  if (mv.enchant) what.push(`${mv.turns || 4}ターン 通常攻撃が ${EL_NAME[mv.enchant]}属性に・${EL_NAME[mv.enchant]}の 威力 +25%`);
  if (mv.ailguard) what.push(`${mv.turns || 5}ターン ${AIL_NAME[mv.ailguard]}を ふせぐ`);
  if (mv.late) what.push(`${mv.late}ターン 遅い 順に 動ける`);
  if (mv.critup) what.push(`${mv.critup}ターン 急所ランク +2`);
  if (mv.mpgive) what.push(`MPを ${mv.mpgive[0]}〜${mv.mpgive[1]} 回復`);
  if (mv.nosealT) what.push(`${mv.nosealT}ターン 封印を ふせぐ`);
  if (mv.field === "reverse") what.push(`${mv.turns || 3}ターン「遅い 順に 動く」場に する`);
  if (mv.charge) what.push(`溜め +${mv.charge === 2 ? 2 : 1}段階（重ねると 次の 攻撃が 2→2.6→3.3→4倍）`);
  if (mv.taunt) what.push(`${mv.taunt}ターン 敵の 攻撃を ひきつける`);
  if (mv.guard) what.push("この ターン 受ける ダメージを 大きく へらす（先制）");
  if (mv.pin) what.push(`${mv.pin}ターン 敵を 逃げられなく する`);
  if (mv.mpdrain) what.push(`MPを ${mv.mpdrain[0]}〜${mv.mpdrain[1]} 吸いとる`);
  const ex = [];
  ex.push(priText(mv.guard ? Math.max(3, mv.pri || 0) : mv.pri || 0));
  if (mv.acc !== undefined && mv.acc < 100) ex.push(`命中 ${mv.acc}%`);
  if (mv.sure) ex.push("かならず 当たる");
  if (mv.critR) ex.push(`急所ランク +${mv.critR}`);
  if (mv.nocap) what.push(`味方の ダメージの 上限を ${mv.nocap}ターン なくす`);
  if (mv.capT) what.push(`敵に ${mv.capT}ターン ダメージの 上限 999を かける`);
  if (mv.weather) what.push(`天候を ${WEATHER[mv.weather]?.[0]}に する（${mv.turns || 5}ターン）: ${WEATHER[mv.weather]?.[3]}`);
  if (mv.wboost) ex.push(Object.entries(mv.wboost).map(([w, k]) => `${WEATHER[w]?.[0]}の とき 威力 ${k}倍`).join("・"));
  if (mv.nocaphit) ex.push("§6ダメージの 上限を 無視");
  if ((mv.hits || 1) > 1 && !mv.accel) ex.push(`連続で 1発ごとに 威力 ×${HIT_DECAY}`);
  if (mv.whip) ex.push("左の 敵から じゅんに 打つ（1体ごとに 威力 0.8倍）・Sサイズに 1.3倍");
  if (mv.wtype || mv.wmove) { const k = WKIND[mv.wtype || mv.wmove]; if (k) ex.push(`攻撃属性【${k.attrName}】`); }
  if (mv.rnd) ex.push("ランダムな 敵に 当たる");
  if (mv.dualstat) ex.push("物力＋武力で 威力が きまる");
  if (mv.cat === "special") ex.push(`${pstatName(mv.pstat)}が 高いほど 威力アップ`);
  if (mv.accel) ex.push(`1発ごとに 威力 +${Math.round(mv.accel * 100)}%（加速）`);
  if (mv.bleedK) ex.push(`出血が 重い（動くたび 最大HPの ${Math.round(mv.bleedK * 100)}%）`);
  if (mv.allup) ex.push(`攻撃の あと 自分の 全能力を ${mv.allup}段階 上げる`);
  if (mv.ruby) ex.push(`読み: ${mv.ruby}`);
  if (mv.norefl) ex.push("跳ね返されない");
  if (mv.mimic) what.push("最優先。この ターンに 受けた 攻撃を 覚えて、ターンの 最後に まとめて 返す（神技・自爆・ため技・反動技など 一部は まねできない）");
  if (mv.antiRefl) what.push(`みんなの 反射を 消して ${mv.turns || 3}ターン だれも 跳ね返せなく する`);
  if (mv.rest) ex.push("§c使った 次の ターンは 動けない（1回休み）");
  if (mv.solo) ex.push("§c使う ターンは 1回しか 動けない");
  else if (mv.heavy) ex.push("§c使う ターンは 行動が 1回 へる");
  if (mv.slowpow) ex.push("相手より 遅いほど 威力アップ（最大 1.8倍）");
  if (mv.el2) ex.push(`${EL_NAME[mv.el]}と ${EL_NAME[mv.el2]}の 効く ほうで 当たる`);
  if (mv.god && GOD_N[mv.god]) ex.push(`神「${GOD_N[mv.god]}」の 技`);
  if (mv.drain) ex.push(`与えた ダメージの ${Math.round(mv.drain * 100)}%を 吸収`);
  if (mv.inf) ex.push(`${AIL_NAME[mv.inf[0]]} ${Math.round(mv.inf[1] * 100)}%`);
  if (mv.death) ex.push(`即死 ${Math.round(mv.death * 100)}%`);
  if (mv.selfheal) ex.push(`攻撃の あと 自分の HPを 最大HPの ${Math.round(mv.selfheal * 100)}% 回復`);
  if (mv.mpsteal) ex.push(`与えた ダメージの ${Math.round(mv.mpsteal * 100)}%ぶん MPも 吸う`);
  if (mv.sealhit) ex.push(`${CATS[mv.sealhit[0]]}封じ ${Math.round(mv.sealhit[1] * 100)}%`);
  if (mv.debuff) ex.push(`当たると 相手の ${ST_NAME[mv.debuff[0]]}を ${Math.abs(mv.debuff[1])}段階 下げる${mv.debuff[2] !== undefined && mv.debuff[2] < 1 ? `（${Math.round(mv.debuff[2] * 100)}%）` : ""}`);
  if (mv.pierce) ex.push("守り無視");
  if (mv.crit) ex.push(`会心 +${Math.round(mv.crit * 100)}%`);
  if (mv.metalx) ex.push(`ハガネボディに ${mv.metalx[0]}〜${mv.metalx[1]}ダメージ`);
  if (mv.f === "pct") ex.push(`ハガネボディの 最大HPの ${Math.round(mv.k * 100)}%`);
  if (mv.recoil) ex.push(`反動 ${Math.round(mv.recoil * 100)}%`);
  if (mv.hpcost) ex.push(`HPを ${Math.round(mv.hpcost * 100)}% けずる`);
  if (mv.gamble) ex.push(`${Math.round(mv.gamble * 100)}%で 空振り`);
  if (mv.scrit) ex.push("当たれば かならず 会心");
  if (mv.boss) ex.push("専用技");
  if (mv.sig && SPECIES[mv.sig]) ex.push((SPECIES[mv.sig].ext || []).includes(id) ? `${SPECIES[mv.sig].name}の 専用技（いつでも 使える）` : `${SPECIES[mv.sig].name}の 固有技（Lv${SPECIES[mv.sig].sig2 === id ? SPECIES[mv.sig].siglv2 : SPECIES[mv.sig].siglv}）`);
  const tg = TGN[mv.target] || "";
  if (short) return [moveLabel(id) + "§8", tg, what[0], ex.filter((x) => !x.includes("固有技"))[0]].filter(Boolean).join(" ").slice(0, 60).replace(/§$/, "");
  return [...(mv.ruby ? [`§7${mv.ruby}`] : []), `§l§e${mv.name}§r  §9MP ${mv.mp}`, moveLabel(id), `§f${what.join("・") || "特殊な 技"}`, `§7対象: ${tg}`, ex.length ? `§7${ex.join("・")}` : ""].filter(Boolean).join("\n");
}

// v2.5.4: 個体ごとの 特性（厳選）。行動回数・系統の王・鋼の体・固有特性は そのまま
const FIXED_TR = new Set(["act2", "act23", "act34", "famking", "metal"]);
export function rollTraits(sp) {
  const S = SPECIES[sp]; const base = [...(S.traits || [])]; const pool = (S.tpool || []).filter(([t]) => TRAITS[t]);
  if (!pool.length) return null;
  const slots = base.map((t, i) => (FIXED_TR.has(t) ? -1 : i)).filter((i) => i >= 0);
  if (!slots.length) return null;
  const out = [...base]; const used = new Set(base);
  const keep = slots[Math.floor(Math.random() * slots.length)];       // 少なくとも 1つは 元の 特性を のこす
  let first = true;
  for (const i of slots) {
    if (i === keep || Math.random() < 0.4) continue;                   // 元の まま
    const cand = pool.filter(([t]) => !used.has(t));
    const syn = cand.filter(([, w]) => w > 1);
    const list = first && syn.length ? syn : cand;                     // 1つめは 元の 特性と 相性の よい もの
    if (!list.length) continue;
    const tot = list.reduce((a, [, w]) => a + w, 0); let r = Math.random() * tot, pickT = list[0][0];
    for (const [t, w] of list) { r -= w; if (r <= 0) { pickT = t; break; } }
    used.delete(out[i]); out[i] = pickT; used.add(pickT); first = false;
  }
  return out.some((t, i) => t !== base[i]) ? out : null;
}
export const baseTraits = (m) => (m && Array.isArray(m.rtr) && m.rtr.length && m.rtr.every((t) => TRAITS[t]) ? [...m.rtr] : [...(SPECIES[m.sp]?.traits || [])]);
export function makeMonster(sp, lv, auto) {
  const m = { id: uid(), sp, nm: SPECIES[sp].name, lv, exp: 0, pts: [0, 0, 0], spl: totalSpAt(lv), hp: 0, mp: 0,
    sk: [...SPECIES[sp].skills], plus: 0, eq: { w: null, a: null, x: null }, bonus: {}, nat: rollNature(), tal: rollTal() };
  const rt = rollTraits(sp); if (rt) m.rtr = rt;
  ensureSkills(m);
  if (auto) autoAlloc(m);
  const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  return m;
}
export const skMax = (sk) => SKILLS[sk]?.max || 100;   /* 第104版: 達人編・皆伝編は 150 */
export function setPoints(m, target) {
  const msgs = [];
  const oldSt = calcStats(m);
  for (let i = 0; i < m.sk.length; i++) {
    const before = m.pts[i];
    const want = Math.max(before, Math.min(skMax(m.sk[i]), Math.round(target[i])));
    const add = Math.min(want - before, m.spl);
    if (add <= 0) continue;
    m.pts[i] += add; m.spl -= add;
    for (const e of SKILLS[m.sk[i]].list) if (e.pt > before && e.pt <= m.pts[i]) msgs.push(e.move ? `§e${m.nm}は ${MOVES[e.move].name} を 覚えた！` : e.trait ? `§d${m.nm}は 特性【${TRAITS[e.trait]?.name}】を 身につけた！` : `§a${m.nm}の ${ST_NAME[e.stat]}が ${e.val} 上がった！`);
  }
  const newSt = calcStats(m);
  if (m.hp > 0) m.hp = Math.max(1, m.hp + newSt.hp - oldSt.hp); m.mp = Math.max(0, m.mp + newSt.mp - oldSt.mp);   // v2.9.11: たおれた 子は 生きかえらない
  return msgs;
}
export const allocate = (m, i, n) => { const t = [...m.pts]; t[i] += n; return setPoints(m, t); };

export const canEvolveNow = (m) => { const e = SPECIES[m.sp]?.evo; return !!(e && SPECIES[e[0]] && m.lv >= e[1]); };
export function evolve(m, log, force = false) {
  const evo = SPECIES[m.sp].evo;
  if (!evo || !SPECIES[evo[0]] || m.lv < evo[1]) return false;
  if (m.noevo && !force) { if (m.lv === evo[1]) log.push(`§7${m.nm}は 進化できるが 「進化しない」に なっている。`); return false; }
  return evolveTo(m, evo[0], log);
}
export function evolveTo(m, to, log) {
  const old = calcStats(m);
  const oldName = SPECIES[m.sp].name, renamed = m.nm === oldName;
  const hpR = old.hp ? m.hp / old.hp : 1, mpR = old.mp ? m.mp / old.mp : 1;
  const osg = SPECIES[m.sp].sig;
  if (osg && m.lv >= (SPECIES[m.sp].siglv || 1)) { m.lm = m.lm || []; if (!m.lm.includes(osg)) m.lm.push(osg); }
  m.sp = to;
  if (renamed) m.nm = SPECIES[m.sp].name;
  ensureSkills(m); trimSkills(m, log);
  const st = calcStats(m);
  m.hp = m.hp > 0 ? Math.max(1, Math.round(st.hp * hpR)) : 0;   // v2.9.12: 倒れた 子は 進化しても 倒れた まま
  m.mp = Math.round(st.mp * mpR);
  log.push(`§d${renamed ? oldName : m.nm}は ${SPECIES[m.sp].name}に 進化した！`);
  return true;
}
export function levelUp(m, log) {
  if (m.lv >= MAXLV) return false;
  const o = calcStats(m);
  m.lv++;
  const g = spGain(m.lv); m.spl += g;
  const n = calcStats(m);
  if (m.hp > 0) m.hp += n.hp - o.hp; m.mp += n.mp - o.mp;   // v2.9.12: 倒れた 子は レベルが 上がっても 倒れた まま
  log.push(`§e${m.nm}は レベル${m.lv}に 上がった！ スキルポイント+${g}`);
  const sp = SPECIES[m.sp];
  for (const [sg, sl] of [[sp.sig, sp.siglv], [sp.sig2, sp.siglv2]]) if (sg && m.lv === sl && MOVES[sg]) {
    log.push(`§6§l${m.nm}は 固有技「${MOVES[sg].name}」を 覚えた！`);
    if (Array.isArray(m.mset) && m.msetFix && !m.mset.includes(sg)) { { const can = new Set(getMoves(m)); m.mset = m.mset.filter((x) => can.has(x)); } if (m.mset.length < MSET_MAX) m.mset.push(sg); else log.push("§7（戦いで 使う 技が 6つ うまって いるので、仲間 → 技 で 入れかえると 戦いで 使える）"); }   /* 第103版: 覚えたのに 戦いで 出ない ことが あった */
  }
  return evolve(m, log);
}
export function gainExp(m, x, log) {
  const evolved = [];
  if (m.lv >= MAXLV) return evolved;
  m.exp += x;
  while (m.lv < MAXLV && m.exp >= expNeed(m.lv)) { m.exp -= expNeed(m.lv); if (levelUp(m, log)) evolved.push(m); }
  if (m.lv >= MAXLV) m.exp = 0;
  return evolved;
}

// ---- 配合 ----
export const FUSE_LV = 1;
export function mixFam(fa, fb) {
  if (fa === fb || fa === "king" || fa === "god" || fb === "king" || fb === "god") return fa;
  return FAM_MIX[[fa, fb].sort().join("|")] || fa;
}
export const BAND_NAME = ["F〜C", "B〜A", "S〜SS"];
export function bandOf(list) { const r = Math.max(...list.map((m) => rankIdx(m.sp))); return r >= 6 ? 2 : r >= 4 ? 1 : 0; }
export const mixKey = (fa, fb) => [fa, fb].sort().join("|");
export function mixPair(fa, fb, band) {
  if (fa === "king" || fa === "god" || fb === "king" || fb === "god") return [fa, fa];
  const e = FAM_MIX3[mixKey(fa, fb)];
  return e ? e[band] : [fa, fa];
}
export function mixOf2(list) {
  const band = bandOf(list), f = list.map((m) => SPECIES[m.sp].fam);
  if (list.length === 4) { const x = mixPair(f[0], f[1], band)[0], y = mixPair(f[2], f[3], band)[0]; return [...mixPair(x, y, band), band]; }
  return [...mixPair(f[0], f[1], band), band];
}
export function mixOf(list) { return mixOf2(list)[0]; }
const ROMAN_MAP = {};
ROMAN.forEach(([a, b], i) => { ROMAN_MAP[[a, b].sort().join("|")] = i; });
export function romanOf(a, b) { const i = ROMAN_MAP[[a.sp, b.sp].sort().join("|")]; return i === undefined ? -1 : i; }
function h32(str) { let h = 2166136261 >>> 0; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h; }
const POOL = {};
function famRankPool(fam, t) {
  const k = fam + ":" + t;
  if (!POOL[k]) POOL[k] = ORDER.filter((id) => { const s = SPECIES[id]; return !s.hidden && s.fam === fam && RANKS.indexOf(s.rank) === t && !s.special && !s.special4 && !s.metalmon; });
  return POOL[k];
}
function pickFrom(fam, target, key, n) {
  for (let t = target; t >= 0; t--) {
    const pool = famRankPool(fam, t);
    if (!pool.length) continue;
    const h = h32(key + "#" + fam);
    const stride = pool.length > 1 ? 1 + ((h >>> 8) % (pool.length - 1)) : 1;
    const out = [];
    for (let k = 0; out.length < Math.min(n, pool.length) && k < pool.length * 2; k++) { const id = pool[(h + k * stride) % pool.length]; if (!out.includes(id)) out.push(id); }
    return out;
  }
  return [];
}
function blood(list) {
  const ranks = list.map((m) => rankIdx(m.sp));
  const same = ranks.every((r) => r === ranks[0]);
  let target = Math.round(ranks.reduce((a, b) => a + b, 0) / ranks.length) + (same ? 1 : 0) + (list.length === 4 ? 1 : 0);
  target = Math.min(5, target);
  const key = list.map((m) => m.sp).join(",");
  const [mf, sf] = mixOf2(list), bf = SPECIES[list[0].sp].fam;
  const out = [];
  const add = (ids) => { for (const id of ids) if (!out.includes(id) && out.length < 4) out.push(id); };
  add(pickFrom(mf, target, key, mf === sf && mf === bf ? 4 : 2));
  if (sf !== mf) add(pickFrom(sf, sf === "king" ? Math.max(5, target) : target, key, 1));
  if (bf !== mf && bf !== sf) add(pickFrom(bf, target, key, 1));
  add(pickFrom(mf, target, key, 4));
  return out;
}
export const NOFUSE = new Set(["musashi", "enma"]);
let SPX = null;   // 特別配合の 早見表（親 → 生まれる 子）
export function fusionCandidates(a, b) {
  if (a.sp === "musashi" || b.sp === "musashi") return ["musashi"];   // v3.0: ムサシは ほかで 手に 入らないので、ムサシを 親に すると ムサシだけ 生まれる
  const out = [];
  if (!SPX) { SPX = {}; for (const [id, s] of Object.entries(SPECIES)) if (s.special && s.deity === undefined) (SPX[s.special[0]] = SPX[s.special[0]] || []).push(id); }
  for (const id of [...(SPX[a.sp] || []), ...(SPX[b.sp] || [])]) {
    const s = SPECIES[id]; if (out.includes(id)) continue;
    const [needA, partnerFam, minR = 4] = s.special;   // v3.0: 3つめ＝相手の 最低ランク（光竜ギドラは SS）
    const ok = (x, y) => x.sp === needA && (partnerFam === "*" || SPECIES[y.sp].fam === partnerFam) && rankIdx(y.sp) >= minR;
    if (ok(a, b) || ok(b, a)) out.push(id);
  }
  const ri_ = romanOf(a, b);
  if (ri_ >= 0 && !out.includes(ROMAN[ri_][2])) out.unshift(ROMAN[ri_][2]);
  for (const id of blood([a, b])) if (!out.includes(id) && out.length < 4) out.push(id);
  for (const x of [a.sp, b.sp]) if (!out.includes(x) && !String(x).startsWith("book_")) out.push(x);   // v2.1: 親と 同じ モンスターにも できる（魔書は ふえない）
  return out.filter((x) => !NOFUSE.has(x));   // v2.9.14: ムサシ・エンマは 配合で 作れない
}
export function fusion4Candidates(list) {
  if (list.some((m) => m.sp === "musashi")) return ["musashi"];
  const out = [];
  const have = list.map((m) => m.sp).sort().join(",");
  for (const r of RECIPES4) if ([...r.need].sort().join(",") === have) out.push(r.sp);
  for (const id of blood(list)) if (!out.includes(id) && out.length < 4) out.push(id);
  for (const m of list) if (!out.includes(m.sp) && !String(m.sp).startsWith("book_")) out.push(m.sp);   // v2.1: 親と 同じ モンスターにも できる
  return out.filter((x) => !NOFUSE.has(x));
}
// スキルを 100まで 振った 親から 配合すると 入門編→熟練編→達人編→皆伝編 に 進んで 引き継げる
export function skillUpgrades(parents) {
  const out = {};
  for (const m of parents) (m.sk || []).forEach((sk, i) => { const nx = SKILLS[sk]?.next; if (nx && SKILLS[nx] && ((m.pts || [])[i] || 0) >= 100) out[sk] = nx; });
  return out;
}
// v2.5: ロマン配合。親たちが 決まった 2つの スキルを 持っていると、配合限定の スキルが 生まれる（段は 親の 高い ほう）
export function comboSkills(parents) {
  const tier = {};
  for (const m of parents) for (const sk of m.sk || []) { const S = SKILLS[sk]; if (!S || !S.line) continue; tier[S.line] = Math.max(tier[S.line] ?? -1, S.tier || 0); }
  const out = [];
  // v2.9.12: 親の スキルが「どれか ひとつ」（配列）の 組み合わせも 見る（前は 配列の 組み合わせが 一度も 出なかった）
  const best = (x) => { const L = [].concat(x).filter((k) => k in tier); return L.length ? Math.max(...L.map((k) => tier[k])) : null; };
  for (const [id, a, b] of COMBOS) {
    const ta = best(a), tb = best(b);
    if (ta === null || tb === null) continue;
    const t = Math.min(3, Math.max(ta, tb, tier[id] ?? -1));
    if (SKILLS[`${id}${t}`]) out.push(`${id}${t}`);
  }
  return out;
}
export function fusionSkillChoices(parents, sp) {
  const up = skillUpgrades(parents);
  const inherited = parents.flatMap((m) => m.sk).map((x) => up[x] || x);
  const cb = comboSkills(parents).filter((x) => !inherited.some((y) => SKILLS[y]?.line === SKILLS[x]?.line && (SKILLS[y]?.tier || 0) >= (SKILLS[x]?.tier || 0)));
  const all = [...new Set([...cb, ...SPECIES[sp].skills, ...(SPECIES[sp].skx || []), ...inherited])].filter((x) => SKILLS[x] && !isUniqSk(x));
  // v3.0: 同じ 系統は 1つだけ（いちばん 高い 段）
  const bestOf = {};
  for (const x of all) { const ln = SKILLS[x].line; if (!ln) continue; if (!bestOf[ln] || (SKILLS[x].tier || 0) > (SKILLS[bestOf[ln]].tier || 0)) bestOf[ln] = x; }
  return all.filter((x) => !SKILLS[x].line || bestOf[SKILLS[x].line] === x);
}
export function fuse(parents, sp, skills, nat) {
  const lvSum = parents.reduce((s, m) => s + m.lv, 0);
  const plusSum = parents.reduce((s, m) => s + (m.plus || 0), 0);
  const plus = Math.floor((plusSum / parents.length) * (parents.length === 4 ? 1.2 : 1.15)) + Math.floor(lvSum / (parents.length === 4 ? 6 : 5)) + (parents.length === 4 ? 5 : 2);
  const plusC = Math.min(999, plus);   // v3.0: プラス値は 999まで
  const m = makeMonster(sp, 1, false);
  if (sp === "musashi" && parents.some((x) => x.storyMusashi)) m.storyMusashi = 1;   // v3.0: 物語の ムサシは 配合しても 物語の ムサシ
  if (parents.some((x) => x.paid || x.bred)) {   // 買った 子・育て屋の 子が まじる ときは 親の 売値の 合計までしか 売れない
    const RB = { F: 300, E: 700, D: 1500, C: 3000, B: 6500, A: 16000, S: 45000, SS: 50000, X: 50000 };
    const val = (x) => { const v = Math.floor(((RB[SPECIES[x.sp]?.rank] || 50000) * 0.35 * (1 + x.lv / 40) + (x.plus || 0) * 40) * (x.bred ? 0.15 : x.paid > 0 ? 1 : 0.25));   /* 第67版: 野生の 子は 売値 1/4 と 同じ */ return x.paid > 0 ? Math.min(v, Math.floor(x.paid * 0.5)) : v; };
    m.paid = Math.max(2, parents.reduce((a, x) => a + val(x), 0) * 2);   // monSell は paid の 半分まで
    delete m.bred;
  }
  m.sk = skills.slice(0, SKILL_N[sizeOf(m)] || 3);
  { let kn = 0; m.sk = m.sk.filter((k) => !(KSP || []).includes(k) || kn++ === 0); }   /* 第68版: 特別な 秘伝は 1つまで */
  m.pts = m.sk.map(() => 0);
  ensureSkills(m);
  const hp = parents.filter((x) => x.ht).length;
  if (hp) giveHidden(m, hp >= 2 ? 0.6 : 0.35); else giveHidden(m, 0.01);
  m.plus = plusC;
  if (parents.some((x) => x && x.sp === sp)) m.recSame = 1;   /* 第69版: 親と 同じ 種族は 再会の 数に 入れない */
  m.nat = typeof nat === "number" ? nat : rollNature();
  m.tal = inheritTal(parents);
  m.spl += Math.min(60, Math.floor(plusC / 2));
  // v2.2: 育成RPG形式の 配合。親の 能力の 一部（2体なら 合計の 1/4、4体なら 合計の 1/8）を 最初から 受けつぐ
  //       （上限は 子の Lv100の 能力の 7割5分。レベルが 上がって 自分の 能力が こえたら そちらに なる）
  const div = parents.length >= 4 ? 12 : 6;   /* 第103版: 1/4 → 1/6（4体は 1/8 → 1/12）。配合の 子が 序盤から 強すぎた */
  const lv100 = calcStats({ ...m, lv: 100, sk: [], pts: [], eq: {}, inh: null, bonus: {} });
  m.inh = {};
  for (const k of STATS) { const sum = parents.reduce((a, p) => a + (calcStats(p)[k] || 0), 0); m.inh[k] = Math.min(Math.floor(lv100[k] * 0.6), Math.floor(sum / div)); }   /* 上限 7割5分 → 6割 */
  // スキルポイントは 親の 合計の 半分を 受けつぐ（親が 振った ぶん＋のこり）
  const spSum = parents.reduce((a, p) => a + (p.pts || []).reduce((x, y) => x + y, 0) + (p.spl || 0), 0);
  const cap = (SKILL_N[sizeOf(m)] || 3) * 100;
  m.spl = Math.min(cap, m.spl + Math.floor(spSum / 2));
  const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  return m;
}
// v2.2: 魔書。親の プラス値が 25・50・75・99 以上で、子が 受けつがなかった スキル（親が 20pt 以上 振った もの）が 3つ 以上 あると 生まれる
export const BOOK_SIZES = [["book_g", 99], ["book_l", 75], ["book_m", 50], ["book_s", 25]];
export function makeBook(parents, child) {
  const maxPlus = Math.max(...parents.map((p) => p.plus || 0));
  const tier = BOOK_SIZES.find(([, th]) => maxPlus >= th);
  if (!tier || !SPECIES[tier[0]]) return null;
  const left = {};
  for (const p of parents) (p.sk || []).forEach((sk, i) => { const pt = (p.pts || [])[i] || 0; if (SKILLS[sk] && !isUniqSk(sk) && !child.sk.includes(sk) && !(SKILLS[sk].line && child.sk.some((c) => SKILLS[c] && SKILLS[c].line === SKILLS[sk].line)) && pt >= 20) left[sk] = Math.max(left[sk] || 0, pt); });
  const ids = Object.keys(left).sort((a, b) => left[b] - left[a] || (SKILLS[b].tier || 0) - (SKILLS[a].tier || 0)).filter((x, i, A) => !SKILLS[x].line || A.findIndex((y) => SKILLS[y].line === SKILLS[x].line) === i);   // 同じ 系統は 1つ
  if (ids.length < 3) return null;
  const b = makeMonster(tier[0], 1, false);
  const n = SKILL_N[SPECIES[tier[0]].sz] || 3;
  b.sk = ids.slice(0, n); b.pts = b.sk.map((k) => Math.max(10, Math.floor(left[k] / 2)));
  b.spl = 0; b.plus = child.plus || 0; b.nat = child.nat;
  b.left = ids.length;
  const st = calcStats(b); b.hp = st.hp; b.mp = st.mp;
  return b;
}

// ---- タマゴ ----
export function hatch(eggId, cap = 8, post = false) {
  const e = EGGS[eggId];
  // v2.7: 物語の 進みで 生まれる ランクに 上限（上限より 上は 上限の ランクに）
  const ri_ = (r) => RANKS.indexOf(r);
  let rank = weighted(e.ranks);
  if (ri_(rank) > cap) { const ok = Object.keys(e.ranks).filter((r) => ri_(r) <= cap); rank = ok.length ? ok.sort((a, b) => ri_(b) - ri_(a))[0] : RANKS[Math.max(0, cap)]; }
  let pool = Object.keys(SPECIES).filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && SPECIES[s].rank === rank && (e.fams ? e.fams.includes(SPECIES[s].fam) : SPECIES[s].fam !== "king" && SPECIES[s].fam !== "god"));
  if (!pool.length) pool = Object.keys(SPECIES).filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && SPECIES[s].rank === rank);
  const m = makeMonster(pick(pool), 1, false);
  tuneMonster(m, e.rainbow ? 0.6 : e.price >= 3000 ? 0.35 : 0.15);
  if (e.price > 0) m.paid = e.price;   // v2.9.12: 買った タマゴの 子は 売値の 上限が ある
  giveHidden(m, e.rainbow ? 0.08 : 0.02);
  if (post) {   // 第68版: クリア後の タマゴの 子は 特別な 秘伝を 1つ 必ず 持つ
    try { const L = (KSP || []).filter((k) => SKILLS[k]); if (L.length && !m.sk.some((k) => L.includes(k))) { let i = m.sk.length - 1; while (i >= 0 && isUniqSk(m.sk[i])) i--; const k = L[Math.floor(Math.random() * L.length)]; if (m.sk.length < slotN(m)) { m.sk.push(k); m.pts.push(0); } else if (i >= 0) { m.sk[i] = k; m.pts[i] = 0; } else { m.sk.push(k); m.pts.push(0); } m.ksp = k; } } catch {}
  }
  const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  return m;
}

// ---- バトル外で アイテムを 使う ----
/* 第69版: 実の 判定は 配合で 受けついだ 下限（inh）を 外して くらべる（下限より 低い 子にも 使える） */
const csNoInh = (m) => calcStats(m.inh ? { ...m, inh: null } : m);
/* 第103版: 回復の 道具は 決まった 量か 最大の 割合（多い ほう）。レベルが 上がっても 役に 立つ */
export const itemHp = (it, mx) => Math.max(it?.hp || 0, Math.floor((mx || 0) * (it?.pct || 0)));
export const itemMp = (it, mx) => Math.max(it?.mp || 0, Math.floor((mx || 0) * (it?.mpct || 0)));
export function useItemOn(m, id, log, cap = 8, lvCap = 999) {
  const it = ITEMS[id];
  if (!it || !m) return false;   // v3.0: ない アイテムで 止まらないように
  const st = calcStats(m);
  switch (it.kind) {
    case "heal": if (m.hp <= 0 || m.hp >= st.hp) return false; const a0 = m.hp; m.hp = Math.min(st.hp, m.hp + itemHp(it, st.hp)); log.push(`${m.nm}の HPが ${m.hp - a0} 回復した！`); return true;
    case "mpheal": if (m.mp >= st.mp) return false; const b0 = m.mp; m.mp = Math.min(st.mp, m.mp + itemMp(it, st.mp)); log.push(`${m.nm}の MPが ${m.mp - b0} 回復した！`); return true;
    case "revive": if (m.hp > 0) return false; m.hp = it.full ? st.hp : Math.floor(st.hp / 2); log.push(`${m.nm}は 生き返った！`); return true;
    case "cure": return false;
    case "seed": {
      const vb0 = JSON.stringify(calcStats(m)), b0 = JSON.stringify(csNoInh(m)), bk = { ...m.bonus }, h0 = m.hp, mp0 = m.mp;   /* 第69版: 上がらない ときは 使わない */
      const v = it.rnd ? it.rnd[0] + Math.floor(Math.random() * (it.rnd[1] - it.rnd[0] + 1)) : it.val;
      m.bonus[it.stat] = (m.bonus[it.stat] || 0) + v;
      { const sv0 = JSON.parse(vb0), st2 = calcStats(m);   /* 第69版: HP・MPは 最大が 実際に ふえた ぶんだけ（回復の 道具に ならない） */
        if (it.stat === "hp" && m.hp > 0) m.hp += Math.max(0, st2.hp - sv0.hp);   // v2.9.12: 倒れた 子は 生きかえらない
        if (it.stat === "mp") m.mp += Math.max(0, st2.mp - sv0.mp);
        m.hp = Math.min(m.hp, st2.hp); m.mp = Math.min(m.mp, st2.mp); }
      if (JSON.stringify(csNoInh(m)) === b0) { m.bonus = bk; m.hp = h0; m.mp = mp0; log.push("§7これ以上 上がらない（HP 以外の 能力は 上限 9999。装備や スキルの 上乗せで 上限なら、外すと 上がる ことも）"); return false; }
      { const vis0 = JSON.parse(vb0 || "{}"), vis1 = calcStats(m), dv = (vis1[it.stat] || 0) - (vis0[it.stat] || 0);   /* 第69版: 見える 差 */
        log.push(dv > 0 ? `§a${m.nm}の ${ST_NAME[it.stat]}が ${dv} 上がった！` : `§a${m.nm}の ${ST_NAME[it.stat]}の もとが ${v} 上がった！ §7（いまは 受けついだ 能力の ほうが 高い。レベルが 上がると 効いてくる）`); } return true;
    }
    case "lvup": { if (m.lv >= MAXLV) return false; if (m.lv >= lvCap) { log.push(`§7${m.nm}は いまの 物語の レベルの めやす（Lv${lvCap}）に 着いて いる。§f次の 石板を 封印すると 使える`); return false; } for (let i = 0; i < (it.val || 1) && m.lv < MAXLV && m.lv < lvCap; i++) { m.exp = 0; levelUp(m, log); } return true; }
    case "exp": { if (m.lv >= MAXLV) return false; let room = 0; if (m.lv < lvCap) { for (let L = m.lv; L < Math.min(lvCap, MAXLV); L++) room += expNeed(L); room = Math.max(0, room - (m.exp || 0)); } const v = it.val <= room ? it.val : room + Math.max(1, Math.floor((it.val - room) / 10));   /* 上限までは 満額・こえた 分は 1/10 */ log.push(`${m.nm}は ${v}の 経験値を えた！${v < it.val ? " §7（いまの 物語の レベルの めやすを こえて いるので 1/10）" : ""}`); gainExp(m, v, log); return true; }   /* 第103版: 経験の 道具も レベルの 上限を 守る */
    case "seedall": {
      const vb0 = JSON.stringify(calcStats(m)), b0 = JSON.stringify(csNoInh(m)), bk = { ...m.bonus }, h0 = m.hp, mp0 = m.mp;   /* 第69版 */
      const v = it.rnd ? it.rnd[0] + Math.floor(Math.random() * (it.rnd[1] - it.rnd[0] + 1)) : it.val;
      for (const k of STATS) m.bonus[k] = (m.bonus[k] || 0) + v * (k === "hp" || k === "mp" ? 2 : 1);
      { const sv0 = JSON.parse(vb0), st = calcStats(m); if (m.hp > 0) m.hp += Math.max(0, st.hp - sv0.hp); m.mp += Math.max(0, st.mp - sv0.mp); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp); }   /* 第69版: 最大が ふえた ぶんだけ */
      if (JSON.stringify(csNoInh(m)) === b0) { m.bonus = bk; m.hp = h0; m.mp = mp0; log.push("§7これ以上 上がらない（HP 以外の 能力は 上限 9999。装備や スキルの 上乗せで 上限なら、外すと 上がる ことも）"); return false; }
      { const s0 = JSON.parse(b0), s1 = csNoInh(m), up = STATS.filter((k) => (s1[k] || 0) > (s0[k] || 0));   /* 第69版: 上がった 能力だけ */
        const sv0 = JSON.parse(vb0), sv1 = calcStats(m), vu = STATS.filter((k) => (sv1[k] || 0) > (sv0[k] || 0));   /* 第69版: 見える 能力が 変わらない とき */
        if (!vu.length) log.push(`§a${m.nm}の 能力の もとが 上がった！ §7（いまは 受けついだ 能力の ほうが 高い。レベルが 上がると 効いてくる）`);
        else log.push(`§a${m.nm}の 能力が 上がった！ §f${vu.map((k) => `${ST_NAME[k]}+${(sv1[k] || 0) - (sv0[k] || 0)}`).join(" ")}${vu.length < STATS.length ? " §7（ほかは 上限か、受けついだ 能力の ほうが 高い）" : ""}`); }   /* 第69版: 見える 差を そのまま 出す */
      return true;
    }
    case "dream": { if (m.ht || !SPECIES[m.sp].ht) return false; m.ht = true; log.push(`§6◆ ${m.nm}の 固有特性「${TRAITS[SPECIES[m.sp].ht].name}」が 目覚めた！`); return true; }
    case "resize": {
      if (SPECIES[m.sp]?.deity !== undefined) { log.push("§7神の 大きさは かえられない。"); return false; }   /* 第69版: 神は いつも Gサイズ */
      if (it.to) { if (sizeOf(m) === it.to) return false; m.sz = it.to; }
      else { const order = ["S", "M", "L"]; if (sizeOf(m) === "G") return false; const i = order.indexOf(sizeOf(m)) + it.val; if (i < 0 || i > 2) return false; m.sz = order[i]; }
      ensureSkills(m); trimSkills(m, log);
      const n = calcStats(m); m.hp = m.hp > 0 ? Math.max(1, Math.min(n.hp, m.hp + Math.max(0, n.hp - st.hp))) : 0; m.mp = Math.min(m.mp, n.mp);
      log.push(`§d${m.nm}は ${SIZE_NAME[m.sz]}に なった！`);
      { const d = sizeStep(m, m.sp), a = traitFx(m.sp, m).acts, an = a ? (a[0] === a[1] ? `${a[0]}回` : `${a[0]}〜${a[1]}回`) : "1回";
        log.push(`§7行動回数: §f${an}${d ? `　§7特性の 強さ（回復・会心・回避・吸収などの 数値）: ${d > 0 ? "§a" : "§c"}×${sizeTrMul(m, m.sp).toFixed(2)}` : "　§7特性の 強さ: §fもとどおり"}`); }
      return true;
    }
    case "awaken": {
      const why = awakenBlock(m); if (why) { log.push(`§c${why}`); return false; }
      const from = rankOfM(m), S = SPECIES[m.sp];
      m.tm = 1;
      if (RANKS.indexOf(S.rank) < RANKS.indexOf("SS")) m.awk = "SS";
      const htNew = S.ht && TRAITS[S.ht] && !m.ht; if (S.ht) m.ht = true;
      const n = calcStats(m); m.hp = n.hp; m.mp = n.mp;
      log.push(`§5§l◆ 闘魔覚醒！ ◆§r §d${m.nm}は 闘魔の 力に 目覚めた！${m.awk ? `（${from}ランク → SSランクの 力）` : ""}`,
        "§f・能力が 大きく 上がった（+25%）", ...(htNew ? [`§6・固有特性「${TRAITS[S.ht].name}」が 目覚めた`] : []),
        "§f・毎ターン 1回 多く 行動できる（4回まで）", "§f・ダメージの 上限（999）が なくなった", "§f・戦いの はじめに 全能力 +1段階", "§f・スキルの 枠が 1つ ふえた");
      return true;
    }
    case "evostone": {
      if (SPECIES[m.sp]?.deity !== undefined) { log.push("§7神は 石では 進化しない。"); return false; }   /* 第69版 */
      const e = SPECIES[m.sp].ievo;
      if (!e || e[1] !== id || !SPECIES[e[0]]) { log.push("§7この モンスターは この 石では 進化しない。"); return false; }
      if (RANKS.indexOf(SPECIES[e[0]].rank) > cap) { log.push(`§7石が 光らない…… §f物語を 進めると この 進化（${SPECIES[e[0]].rank}ランク）が できる`); return false; }   // v2.9.12
      evolveTo(m, e[0], log); return true;
    }
    case "skillbook": return learnSkill(m, it.skill, null, log);
    case "plusup": { if ((m.plus || 0) >= 999) return false; m.plus = (m.plus || 0) + (it.val || 10); log.push(`§d${m.nm}の プラス値が ${it.val || 10} 上がった！（+${m.plus}）`); return true; }
    case "lvmax": { if (m.lv >= MAXLV) return false; while (m.lv < MAXLV) { m.exp = 0; levelUp(m, log); } log.splice(0, log.length, `§a${m.nm}は Lv${MAXLV}に なった！`); return true; }
    case "traitreroll": { const rt = rollTraits(m.sp); if (!rt && !m.rtr) return false; if (rt) m.rtr = rt; else delete m.rtr; log.push(`§b${m.nm}の 特性が 生まれかわった！`, ...traitIds(m).map((t) => `§7・${TRAITS[t]?.name}`)); return true; }
    case "sp": m.spl += it.val; log.push(`§b${m.nm}の スキルポイントが ${it.val} 増えた！`); return true;
    case "nature_rand": { const o = m.nat; do { m.nat = rollNature(); } while (m.nat === o); const n = calcStats(m); m.hp = Math.min(m.hp, n.hp); m.mp = Math.min(m.mp, n.mp); log.push(`§d${m.nm}の 性格が ${natureText(m.nat)}§d に かわった！`); return true; }
    case "respec": {
      const back = m.pts.reduce((a, b) => a + b, 0);
      if (!back) return false;
      m.pts = m.pts.map(() => 0); m.spl += back;
      const n = calcStats(m); m.hp = Math.min(m.hp, n.hp); m.mp = Math.min(m.mp, n.mp);
      log.push(`§b${m.nm}の スキルポイントが ${back} 戻った！`); return true;
    }
  }
  return false;
}

// ---- v2.1: 闘魔覚醒・スキル書 ----
export function awakenBlock(m) {
  const r = SPECIES[m.sp].rank;
  if (r === "X" || SPECIES[m.sp].fam === "god") return "神（Xランク）は 闘魔覚醒 できない";
  if ((m.plus || 0) < 99) return `プラス値が 99に たりない（いま +${m.plus || 0}）。配合で プラス値を 上げよう`;
  if (r === "X" || SPECIES[m.sp].fam === "god") return "神（Xランク）は 闘魔覚醒 できない";
  if (m.tm || m.awk) return "すでに 闘魔覚醒している";
  return null;
}
export const lineOf = (sk) => SKILLS[sk]?.line;
// スキルを 覚える（replaceIdx: 忘れる スキルの 番号。null なら 空きに）
export function learnSkill(m, sk, replaceIdx, log) {
  if (!SKILLS[sk]) return false;
  { const ui = m.sk.findIndex((x) => lineOf(x) && lineOf(x) === lineOf(sk));   /* 第67版: 同じ 系列の 上の 編は その場で 入れかえ（振った pt は そのまま） */
    if (ui >= 0 && (SKILLS[sk].tier || 0) > (SKILLS[m.sk[ui]]?.tier || 0)) {
      const old = m.sk[ui], before = getMoves(m); m.sk[ui] = sk;
      const after = getMoves(m), lost = before.filter((x) => !after.includes(x));
      if (Array.isArray(m.mset)) { m.mset = m.mset.filter((x) => after.includes(x)); if (m.msetFix && !m.mset.length) delete m.msetFix; }
      try { const st = calcStats(m); if (typeof m.hp === "number") m.hp = Math.min(m.hp, st.hp); if (typeof m.mp === "number") m.mp = Math.min(m.mp, st.mp); } catch {}
      log.push(`§a${m.nm}の ${SKILLS[old]?.name}が ${SKILLS[sk].name}に なった！ §7（振った ${m.pts[ui] || 0}pt は そのまま）`);
      if (lost.length) log.push(`§c使えなく なった 技: ${lost.map((x) => MOVES[x]?.name || x).join("・")}`);
      return true; } }
  if (m.sk.some((x) => lineOf(x) === lineOf(sk))) { log.push(`§7${m.nm}は もう ${LINE_INFO[lineOf(sk)]?.title || "その スキル"}を 持っている。`); return false; }
  if (isUniqSk(sk) && SKILLS[sk].uniq !== m.sp) { log.push(`§7${SKILLS[sk].name}は その モンスターだけの スキル。`); return false; }
  const n = slotN(m);
  if (replaceIdx === null || replaceIdx === undefined) {
    if (m.sk.length >= n) { log.push(`§7スキルの 枠が いっぱい（${n}）。忘れる スキルを 選んでね。`); return false; }
    m.sk.push(sk); m.pts.push(0);
  } else {
    const back = m.pts[replaceIdx] || 0; const old = m.sk[replaceIdx];
    m.sk[replaceIdx] = sk; m.pts[replaceIdx] = 0; m.spl += back;
    log.push(`§7${m.nm}は ${SKILLS[old]?.name}を 忘れた。（SP ${back} が 戻った）`);
  }
  const st = calcStats(m); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp);
  log.push(`§b${m.nm}は 「${SKILLS[sk].name}」を 覚えた！`);
  return true;
}

// ---- 特性 ----
const MERGE_OBJ = new Set(["halfbuf", "ailbrk", "contactail", "stat", "dealt", "taken", "onhit", "field", "barrierp", "startbuf", "brk", "killer", "famguard", "hurtbuf", "killbuf", "cntc", "tokidown", "tokiseal", "tokirefl", "startrefl", "startguard", "echoEl", "tokiench", "nodebK", "wspd", "wpow", "wheal", "wevade"]);
export const ACT_TR = ["act2", "act23", "act34"];
// v2.9.12: 大きさに 見あう 行動回数を かならず（M=2回・L=2〜3回・G=3〜4回。もっと 多い 特性は そのまま）
function sizeAct(ids, sz) {
  const need = { M: 0, L: 1, G: 2 }[sz]; if (need === undefined) return ids;
  const have = Math.max(-1, ...ids.map((t) => ACT_TR.indexOf(t)));
  if (have >= need) return ids;
  return [ACT_TR[need], ...ids.filter((t) => !ACT_TR.includes(t))];
}
// v3.0: 小さく した 子は 特性も へる（S=3・M=4・L=5。行動回数の 特性は べつ）
const SZ_ORD = ["S", "M", "L", "G"];
function sizeCut(ids, m, sp) {
  if (!m || !m.sz || !SPECIES[sp] || m.sz === SPECIES[sp].sz || SZ_ORD.indexOf(m.sz) >= SZ_ORD.indexOf(SPECIES[sp].sz)) return ids;
  const n = { S: 3, M: 4, L: 5 }[m.sz] || 3;
  return [...ids.filter((t) => ACT_TR.includes(t)), ...ids.filter((t) => !ACT_TR.includes(t)).slice(0, n)];
}
// v3.0: サイズの 秘薬で 大きさを かえた 子（1段階ごと: 行動回数 ±1段階、特性の 数値 ×1.15／×0.8）
export const sizeStep = (m, sp) => (m && m.sz && SPECIES[sp] && m.sp === sp ? SZ_ORD.indexOf(m.sz) - SZ_ORD.indexOf(SPECIES[sp].sz) : 0);
export const SZ_TR_UP = 1.15, SZ_TR_DOWN = 0.8;
export const sizeTrMul = (m, sp) => { const d = sizeStep(m, sp); return d > 0 ? SZ_TR_UP ** d : d < 0 ? SZ_TR_DOWN ** -d : 1; };
function sizedTraits(ids, m, sp) {
  const d = sizeStep(m, sp), own = SPECIES[sp].sz;
  if (d) {
    const lv0 = Math.max(Math.max(-1, ...ids.map((t) => ACT_TR.indexOf(t))), { M: 0, L: 1, G: 2 }[own] ?? -1);   // もとの 大きさでの 行動回数（-1 = 1回）
    const lv = Math.max(-1, Math.min(ACT_TR.length - 1, lv0 + d));
    ids = ids.filter((t) => !ACT_TR.includes(t)); if (lv >= 0) ids.unshift(ACT_TR[lv]);
  }
  ids = sizeAct(ids, (m && m.sz) || own);
  return sizeCut(ids, m, sp);
}
function addFx(fx, k, v) {
  if (MERGE_OBJ.has(k)) { for (const [a, b] of Object.entries(v)) fx[k][a] = (fx[k][a] || 0) + b; }
  else if (k === "absorb" || k === "nullify") (Array.isArray(v) ? v : [v]).forEach((x) => fx[k].includes(x) || fx[k].push(x));
  else if (k === "immune" || k === "barrier") (Array.isArray(v) ? v : [v]).forEach((x) => fx[k].add(x));
  else if (k === "sealstart") fx.sealstart.push(v);
  else if (k === "sealhit") fx.sealhit.push(v);
  else if (k === "pinch") fx.pinch = Math.max(fx.pinch || 0, v);
  else if (k === "acts") { if (!fx.acts || v[1] > fx.acts[1]) fx.acts = v; }
  else if (k === "taken_all") { for (const c of Object.keys(CATS)) fx.taken[c] = (fx.taken[c] || 0) + v; }
  else if (typeof v === "number" && typeof (fx[k] ?? 0) === "number") fx[k] = (fx[k] || 0) + v;
  else fx[k] = v;
}
// v2.4.4: 上位ランクほど 特性が 強い（数値の 効果に 倍率）
export const TRAIT_MUL = { F: 1, E: 1, D: 1, C: 1, B: 1.05, A: 1.2, S: 1.35, SS: 1.55, X: 1.75 };
const TR_SCALE = new Set(["regen", "mpregen", "lifesteal", "healboost", "crit", "critdmg", "evade", "counter", "drain", "thorns", "mpsave", "expup", "goldup"]);
function scaleTr(k, v, mul) {
  if (mul === 1) return v;
  if (["startbuf", "brk", "killbuf", "nodebK", "startrefl", "startguard", "ailbrk", "halfbuf"].includes(k)) return v;
  if (MERGE_OBJ.has(k) && v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([a, b]) => [a, typeof b === "number" ? b * mul : b]));
  if (TR_SCALE.has(k) && typeof v === "number") return k === "evade" ? Math.min(0.45, v * mul) : v * mul;
  return v;
}
// v3.0: その 子だけの 特性（固有特性・隠れた 特性・SS〜Xの 固有特性）
export function ownTraitIds(sp) { const S = SPECIES[sp] || {}; return new Set([S.ht, S.sx, `ut_${sp}`, `h_${sp}`].filter((t) => t && TRAITS[t])); }
// 闘魔覚醒の 強化: いつも 効く 数値は 1.5倍、条件つきは 段階 +1・確率 1.5倍（上限あり）
export const TM_TRAIT = 1.5;
function tmBoostTr(k, v) {
  const up = (x) => (typeof x === "number" ? (Math.abs(x) <= 1 ? Math.max(-0.9, Math.min(x < 0 ? 0 : 3, x * TM_TRAIT)) : x) : x);
  if (["halfbuf", "killbuf", "startbuf"].includes(k) && v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([a, b]) => [a, typeof b === "number" ? b + 1 : b]));
  if (k === "hurtbuf" && v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([a, b]) => [a, typeof b === "number" ? Math.min(0.9, b * TM_TRAIT) : b]));
  if (k === "pinch" && typeof v === "number") return 1 + (v - 1) * TM_TRAIT;
  if (k === "acts" || k === "startrefl" || k === "absorb" || k === "nullify" || k === "immune" || k === "barrier" || typeof v === "boolean") return v;
  if (typeof v === "number") return k === "evade" ? Math.min(0.5, v * TM_TRAIT) : up(v);
  if (v && typeof v === "object" && !Array.isArray(v)) return Object.fromEntries(Object.entries(v).map(([a, b]) => [a, up(b)]));
  return v;
}
export const traitMul = (sp) => TRAIT_MUL[SPECIES[sp]?.rank] || 1;
export function traitFx(sp, m) {
  const fx = { stat: {}, dealt: {}, taken: {}, barrierp: {}, startbuf: {}, brk: {}, killer: {}, famguard: {}, hurtbuf: {}, killbuf: {}, cntc: {}, tokidown: {}, tokiseal: {}, tokirefl: {}, startrefl: {}, startguard: {}, echoEl: {}, tokiench: {}, nodebK: {}, wspd: {}, wpow: {}, wheal: {}, wevade: {}, halfbuf: {}, ailbrk: {}, contactail: {}, absorb: [], nullify: [], immune: new Set(), barrier: new Set(), onhit: {}, field: {}, sealstart: [], sealhit: [] };
  let ids = m && m.sp === sp ? sizedTraits(baseTraits(m), m, sp) : sizeAct([...(SPECIES[sp].traits || [])], SPECIES[sp].sz);
  if (m && hiddenOf(m)) ids.push(hiddenOf(m));
  { const sx = SPECIES[sp]?.sx; if (sx && TRAITS[sx] && !ids.includes(sx) && !(m && m.noSx)) ids.push(sx); }   // v3.0: SS・Xの 固有特性は いつも（特性を 決めて ある ボスは のぞく）
  { const w = SPECIES[sp]?.wtr; if (w && TRAITS[w] && !ids.includes(w)) ids.push(w); }   // v2.9.12: 天候で 走力 2倍（潤う雨 など）
  if (m) for (const t of skillTraits(m)) if (!ids.includes(t)) ids.push(t);
  if (m && m.xtr && TRAITS[m.xtr] && !ids.includes(m.xtr)) ids.push(m.xtr);
  const mul = traitMul(m && m.sp ? m.sp : sp) * sizeTrMul(m, sp);
  const tmOwn = m && m.tm && m.sp === sp ? ownTraitIds(sp) : null;   // v3.0: 闘魔覚醒すると その 子だけの 特性が 強く なる
  { const b = TRAITS[SPECIES[sp]?.bd], rs = SPECIES[sp]?.res || {}; if (b) for (const [k, v] of Object.entries(b.fx)) addFx(fx, k, k === "taken" ? Object.fromEntries(Object.entries(v).filter(([e]) => !((rs[e] || 0) < 0))) : v); }   /* 第104版: 体質（もとの 特性とは 別わく・ランク補正なし）*/
  for (const id of ids) { const t = TRAITS[id]; if (!t) continue; const boost = tmOwn && tmOwn.has(id); for (const [k, v] of Object.entries(t.fx)) addFx(fx, k, boost ? tmBoostTr(k, scaleTr(k, v, mul)) : scaleTr(k, v, mul)); }
  if (m && m.tm && m.sp === sp) {   // v3.0: 闘魔覚醒（行動 +1・ダメージ上限なし・戦いの はじめに 全能力 +1段階）
    const [lo, hi] = fx.acts || [1, 1]; fx.acts = [Math.min(4, lo + 1), Math.min(4, hi + 1)];
    fx.nocap = true; fx.tmAura = true;
    for (const k of ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) fx.startbuf[k] = (fx.startbuf[k] || 0) + 1;
  }
  return fx;
}
// v2.5: ロマン配合の スキルを 100まで 振ると 身につく 特性
export function skillTraits(m) { const r = []; (m.sk || []).forEach((sk, i) => { for (const e of SKILLS[sk]?.list || []) if (e.trait && TRAITS[e.trait] && ((m.pts || [])[i] || 0) >= e.pt) r.push(e.trait); }); return r; }
export const traitIds = (m) => { const sp = m.sp; let ids = sizedTraits(baseTraits(m), m, sp); const w = SPECIES[sp]?.wtr; if (w && TRAITS[w] && !ids.includes(w)) ids.push(w); const sx = SPECIES[sp]?.sx; if (sx && TRAITS[sx] && !ids.includes(sx)) ids.push(sx); return ids; };   // v2.9.12: 天候の 特性は いつも（v3.0: SS・Xの 固有特性も）
export const traitNames = (sp) => [...(SPECIES[sp].traits || []), ...(SPECIES[sp].wtr ? [SPECIES[sp].wtr] : []), ...(SPECIES[sp].sx ? [SPECIES[sp].sx] : []), ...(SPECIES[sp].bd ? [SPECIES[sp].bd] : [])].map((t) => TRAITS[t]?.name).filter(Boolean);

// ---- バトル ----
// v3.0: 戦いの HPを モンスターに もどす（あとから ハガネに した 子は 1割で 戦うので 割合で もどす）
export function hpBack(f) { const full = calcStats(f.m).hp; if (f.tr && f.tr.metalBody) { const h0 = f.mhp0 > 0 ? Math.max(1, Math.ceil(f.mhp0 * 0.1)) : 0; if (f.mhp0 !== undefined && f.hp >= Math.min(h0, f.mx.hp)) return Math.max(0, Math.min(f.mhp0, full)); }   // 減って いなければ もとの HP
  if (f.tr && f.tr.metalBody) return f.hp > 0 ? Math.max(1, Math.min(full, Math.round(f.hp / Math.max(1, f.mx.hp) * full))) : 0; return Math.max(0, Math.min(f.hp, full)); }
export function fighter(m, side) {
  const st = calcStats(m);
  const tr = traitFx(m.sp, m);
  // v3.0: 道具で あとから つけた ハガネボディ（もとから ハガネ族の 子は のぞく）: HPは 1割・物理系／武系／特質系を 軽減も 反射も できない
  if (tr.metal && !SPECIES[m.sp]?.metalmon) {
    st.hp = Math.max(1, Math.floor(st.hp * 0.1)); tr.metalBody = true;
    for (const k of ["phys", "weapon", "special"]) { if ((tr.taken[k] || 0) < 0) delete tr.taken[k]; delete tr.barrierp[k]; delete tr.startrefl[k]; }
  }
  for (const [k, v] of Object.entries(tr.stat)) if (st[k] !== undefined) st[k] = capStat(k, Math.floor(st[k] * (1 + v)));
  if (sizeOf(m) === "S") tr.evade = (tr.evade || 0) + 0.06;
  let wel = null, wtype = null;
  for (const slot of ["w", "a", "x"]) {
    const it = gearOf(m, slot);
    if (!it) continue;
    if (it.immune) tr.immune.add(it.immune);
    if (slot === "w") { wtype = it.wtype || null; if (it.el) wel = it.el; }
    for (const [k, v] of Object.entries(it.fx || {})) addFx(tr, k, v);
  }
  const sp = SPECIES[m.sp];
  // v2.6: 伝説の 装備の セット効果（同じ 系統の 2つ/3つ）
  { const n = ["w", "a", "x"].filter((k) => gearOf(m, k)?.lfam === sp.fam).length;
    if (n >= 2) { const k2 = n >= 3 ? 0.2 : 0.1; addFx(tr, "dealt", { phys: k2, weapon: k2, breath: k2, magic: k2, special: k2 }); addFx(tr, "taken_all", n >= 3 ? -0.12 : -0.05); if (n >= 3) addFx(tr, "crit", 0.05); tr.legendSet = n; } }
  const atkCat = "phys";
  // v2.9: 武器の 種類で 通常攻撃が かわる（どの 能力で 戦うか・攻撃属性・全体／連続 など）
  const wk = wtype && WKIND && WKIND[wtype];
  return {
    side, m, name: m.nm, lv: m.lv, mx: st, php: st.hp, pmp: st.mp, tr, fam: sp.fam, mhp0: m.hp,
    hp: Math.max(0, Math.min(tr.metalBody ? (m.hp > 0 ? Math.max(1, Math.ceil(m.hp * 0.1)) : 0) : m.hp, st.hp)), mp: Math.max(0, Math.min(m.mp, st.mp)),
    moves: battleMoves(m), res: resTr(resOf(m), tr), ares: aresOf(m), aff: sp.aff || {},
    buf: Object.fromEntries([...BUF_KEYS, "eva", "acc"].map((k) => [k, 0])), wx: null,
    ail: {}, seal: {}, refl: {}, reflEl: {}, elg: {}, elg2: {}, catg: {}, catg2: {}, elm: {}, ailg: {}, ench: null, late: 0, critT: 0, nosealT: 0, taunt: 0, regen: 0, charge: false, guard: false,
    defend: false, angry: false, ent: null, revived: false, sturdyUsed: false, wel, wtype,
    atk: wk ? { ...ATTACK, cat: wk.cat, wdep: true, wtype, el: wel || undefined, ...wk.basic, ...(wtype === "dual" && tr.rapid ? { hits: 1, mult: 1 } : {}), type: wk.cat === "magic" ? "spell" : "phys" }
      : { ...ATTACK, cat: atkCat, el: wel || undefined, name: "攻撃" },
  };
}
// v2.5.4: 特性で 属性を 吸収・無効に
function resTr(res, tr) { const r = { ...res }; for (const e of tr.absorb || []) r[e] = 4; for (const e of tr.nullify || []) if (r[e] !== 4) r[e] = 2; return r; }
export function stat(f, k) {
  const bb = f.floorBuf ? Math.max(f.buf[k] || 0, f.floorBuf) : f.buf[k] || 0;   /* 第68版: 神の 再臨の 底上げ */
  let v = f.mx[k] * buffMul(bb);
  if (f.ail.burn && (k === "atk" || k === "wpn")) v *= 0.7;
  if (f.ail.slow && k === "spd") v *= 0.5;
  if (k === "spd" && f.wx && f.tr.wspd && f.tr.wspd[f.wx]) v *= 2;   // v2.9: 天候の 申し子
  if (f.ail.fear && (k === "atk" || k === "wpn" || k === "mat" || k === "brt")) v *= 0.8;
  return Math.max(1, Math.floor(v));
}
const foesOf = (B, f) => (f.side === "a" ? B.enemies : B.allies);
const friendsOf = (B, f) => (f.side === "a" ? B.allies : B.enemies);
// 魅了: 一時的に 相手の 味方として 動く
const realFoes = (B, f) => (f.ail.charm ? friendsOf(B, f).filter((x) => x !== f) : foesOf(B, f));   // v3.0: 魅了でも 自分は なぐらない
const realFriends = (B, f) => (f.ail.charm ? foesOf(B, f) : friendsOf(B, f));

function bar(f) {
  const n = Math.max(1, Math.ceil((f.hp / f.mx.hp) * 10));
  const c = f.hp / f.mx.hp > 0.5 ? "§a" : f.hp / f.mx.hp > 0.2 ? "§e" : "§c";
  return c + "|".repeat(n) + "§8" + "|".repeat(10 - n);
}
const AIL_COL = { poison: "§5", burn: "§c", bleed: "§4", para: "§e", freeze: "§b", sleep: "§9", slow: "§6", conf: "§d", charm: "§d", fear: "§8" };
const BUF_SHOW = ["atk", "wpn", "mat", "brt", "def", "mdf", "spd", "eva"];
const BUF_SHORT = { atk: "物", wpn: "武", mat: "魔", brt: "吹", def: "硬", mdf: "魔硬", spd: "速", eva: "避" };
// v2.5.1: 溜め（テンション）: 重ねるほど 次の 攻撃が 強い
export const TENS_K = [1, 2, 2.6, 3.3, 4];
const tags = (f) => (f.floorBuf ? " §4[再臨+3]" : "") + (f.nocapT > 0 ? " §6[解放]" : "") + (f.capT > 0 ? " §7[封限]" : "") + (f.ench && f.ench.t > 0 ? ` ${EL_COL[f.ench.el]}[纏]` : "") + (f.late > 0 ? " §7[後]" : "") + (f.critT > 0 ? " §e[会]" : "") + Object.keys(f.ail || {}).filter((k) => f.ail[k]).map((k) => ` ${AIL_COL[k]}[${AIL_NAME[k]}]`).join("") +
  Object.keys(f.seal || {}).filter((k) => f.seal[k] > 0).map((k) => ` §7[${CATS[k].replace("系", "")}封]`).join("") +
  BUF_SHOW.filter((k) => f.buf && f.buf[k]).map((k) => ` ${f.buf[k] > 0 ? "§a" : "§c"}${BUF_SHORT[k]}${f.buf[k] > 0 ? "↑" : "↓"}${Math.abs(f.buf[k])}`).join("") +
  (f.mistT > 0 ? " §8[霧]" : "") + (f.norevive > 0 ? " §8[鎖]" : "") + (f.reraise ? " §d[再誕]" : "") + (f.cover > 0 ? " §e[盾]" : "") + (f.doom ? " §4[執念]" : "") + (f.trb ? ` §6[真価${f.trb > 1 ? "×2" : ""}]` : "") +
  (f.regen ? " §a[再生]" : "") + (f.charge ? ` §6[溜×${TENS_K[f.tens || 1]}]` : "") + (f.bkT > 0 ? " §6§l[ブレイク]§r" : f.bg !== undefined ? ` §8[守${f.bg}]` : "") + (Object.values(f.refl || {}).some((x) => x > 0) ? " §b[反射]" : "") + (f.taunt > 0 ? " §c[挑]" : "");
export const fTags = (f) => tags(f);   // v2.9.12: 画面の 上の 枠でも 使う
const FC = { animal: "§a", nether: "§4", blob: "§b", beast: "§6", bird: "§e", plant: "§a", insect: "§q", aqua: "§3", golem: "§n", undead: "§7", demon: "§5", dragon: "§c", sword: "§i", king: "§g", god: "§d" };
const RCOL = { F: "§f", E: "§7", D: "§e", C: "§a", B: "§9", A: "§c", S: "§d", SS: "§6§l", X: "§5§l" };
const RTAG = (f) => { const r = SPECIES[f.m.sp]?.rank || "F"; return `${RCOL[r]}[${r}]§r`; };
export function statusText(B, log, view = "a", full = false, compact = false) {
  const mine = view === "a" ? B.allies : B.enemies;
  const theirs = view === "a" ? B.enemies : B.allies;
  const L = [];
  if (compact) {   /* 第74版: マス目の 戦いの 画面用（1体 1行・前の ターンは 3行まで） */
    const lg = (log || []).filter((x) => x !== "" && x !== undefined && x !== null).slice(-3);
    for (const x of lg) L.push(`§7${x}`);
    if (B.weather && B.weather.t > 0 && WEATHER[B.weather.w]) L.push(`§f天候 ${wxName(B.weather.w)} §7${B.weather.t >= 99 ? "ずっと" : `あと${B.weather.t}`} ${WEATHER[B.weather.w][3]}`);
    if (B.reverse > 0) L.push(`§d§l↑↓逆転の場 あと${B.reverse}ターン`);
    for (const e of alive(theirs)) L.push(`§c${B.pvp ? "相" : "敵"} ${FC[SPECIES[e.m.sp]?.fam] || "§f"}${e.name} §7Lv${e.lv}${RTAG(e)} ${bar(e)} §f${Math.ceil((e.hp / Math.max(1, e.mx.hp)) * 100)}%${tags(e)}`);
    for (const a of mine) L.push(a.hp > 0 ? `§b味 ${FC[SPECIES[a.m.sp]?.fam] || "§f"}${a.name}${a.guest ? " §e[共闘]" : ""} ${bar(a)} §fHP§a${a.hp}§7/${a.mx.hp} §fMP§b${a.mp}§7/${a.mx.mp}${tags(a)}` : `§8味 ${a.name} × 倒れ`);
    return L.join("\n");
  }
  // v2.8: 前の ターンの 出来事を いちばん 上に（1行ずつ・長い 行は 折り返しやすく）
  if (log && log.length) {
    const lg0 = log.filter((x) => x !== "" && x !== undefined && x !== null);
    const lg = !full && lg0.length > 6 ? lg0.slice(-6) : lg0;
    L.push(`§6§l━ ${full ? "戦いの きろく" : "前の ターン"} ━${!full && lg0.length > 6 ? ` §r§8（さいごの 6行）` : ""}`);
    for (const x of lg) L.push(`§8・ §r${x}`);
    L.push("");
  }
  if (B.terr && TERR_NAME[B.terr]) L.push(`§f§l地形: ${TERR_NAME[B.terr]}§r §7（${EL_NAME[B.terr]} 1.2倍）`);
  if (B.weather && B.weather.t > 0 && WEATHER[B.weather.w]) L.push(`§f§l天候: ${wxName(B.weather.w)}§r §7（${B.weather.t >= 99 ? "ずっと" : `あと ${B.weather.t}ターン`}）${WEATHER[B.weather.w][3]}`);
  L.push(`§c§l◆ ${B.pvp ? "相手" : "敵"} ◆§r${B.reverse > 0 ? `  §d§l↑↓逆転の場 あと${B.reverse}ターン` : ""}`);
  for (const e of alive(theirs)) L.push(` ${FC[SPECIES[e.m.sp]?.fam] || "§f"}${e.name} §7Lv${e.lv} ${RTAG(e)}\n   ${bar(e)} §f${Math.ceil((e.hp / Math.max(1, e.mx.hp)) * 100)}%${tags(e)}`);
  L.push("", "§b§l◆ 仲間 ◆§r");
  for (const a of mine) {
    L.push(a.hp > 0
      ? ` ${FC[SPECIES[a.m.sp]?.fam] || "§f"}${a.name} §7Lv${a.lv} ${RTAG(a)}${a.guest ? " §e[共闘]" : ""}\n   ${bar(a)} §fHP§a${a.hp}§7/${a.mx.hp} §fMP§b${a.mp}§7/${a.mx.mp}${tags(a)}`
      : ` §8${a.name}  × 倒れている`);
  }
  return L.join("\n");
}

const powOf = (f) => Math.max(stat(f, "atk"), stat(f, "wpn"), stat(f, "mat"), stat(f, "brt"));
// v2.9.6: スカウト（モンスターズ式）: 仲間が 1体ずつ 敵に 力を 見せつけ、成功率が つみあがって いく
export function scoutGain(B, a, t) {
  // 第66版: こちらの 物力・武力・魔力（その 子に いちばん 合う もの）と、相手の 硬力（物力・武力）か 魔硬力（魔力）を くらべる
  const opts = [["atk", "def"], ["wpn", "def"], ["mat", "mdf"]].map(([o, dfk]) => stat(a, o) / Math.max(1, stat(t, dfk)));
  const r = Math.max(...opts);
  const hurt = 1 + (1 - t.hp / Math.max(1, t.mx.hp)) * 0.8;          // 弱って いるほど 心が ひらく
  const g = 16 * Math.pow(r, 1.15) * hurt * Math.max(0.3, 1 - rankIdx(t.m.sp) * 0.07);
  return Math.max(1, Math.min(45, Math.round(g)));
}
// 第66版: スカウトでも 複数回 行動の 子は その 回数ぶん 見せつける（目安は 少ない ほうの 回数）
export function scoutActs(a, roll = false) { const [lo, hi] = (a.tr && a.tr.acts) || [1, 1]; let n = roll ? lo + (hi > lo && Math.random() < 0.5 ? 1 : 0) : lo; if (a.tr && a.tr.double) n = Math.max(n, 2); return Math.max(1, Math.min(5, n)); }
export function scoutExtra(B, t) {   // 特性・状態・道具（道具は 1回の スカウトで +30 まで）
  const trait = alive(B.allies).reduce((s, a) => s + (a.tr.field.scout || 0) + (a.tr.famking && SPECIES[a.m.sp].fam === SPECIES[t.m.sp].fam ? 15 : 0), 0);
  return Math.min(30, B.scoutBonus || 0) + Math.min(25, trait) + (t.ail.charm ? 20 : 0) + (t.ail.sleep || t.ail.freeze ? 6 : 0);
}
// 上限（ボス・マスター・物語より 先の ランクは きびしく）
export function scoutCap(B, t, rcap = 8) {
  let cap = 95;
  if (t.isBoss) cap = B.raid ? raidCap(rcap) : B.slab !== null && B.slab !== undefined ? 15 : 12;
  else if (t.isMaster || B.master) cap = 40;
  if (t.isBoss && B.raid) return cap;   // 第66版: レイドボスは ランクに 関係なく 進みに あわせた 上限（序盤 5%〜最終盤 100%）
  if (rankIdx(t.m.sp) > rcap + 1) cap = 0;   // v2.9.12: 物語より 2つ 以上 上の ランクは まだ 仲間に できない
  else if (rankIdx(t.m.sp) > rcap) cap = Math.min(cap, 20);
  return cap;
}
// 第66版: レイドボスの スカウト 上限は 物語の 進みで 5%（序盤）→ 100%（最終盤）。倍率も 進むほど 上がる
export const raidCap = (rc = 8) => Math.round(5 + 95 * Math.max(0, Math.min(1, (rc - 2) / 5)));   // エンディング後（7）で 100%
export function scoutMulOf(B, t, rc = 8) { return t.isBoss ? (B.raid ? 0.15 + 0.85 * Math.max(0, Math.min(1, (rc - 2) / 5)) : 0.25) : t.isMaster || B.master ? 0.6 : 1; }
// 目安（メニューに 出す）: 全員の 見せつけ ＋ おまけ
export function scoutChance(B, t, owner = null, rcap = 8) {
  if (t.angry) return 0;
  const sum = alive(B.allies).filter((a) => !owner || a.owner === owner).reduce((s, a) => s + scoutGain(B, a, t) * scoutActs(a), 0);
  return Math.round(Math.min(scoutCap(B, t, rcap), Math.max(1, (sum + scoutExtra(B, t)) * scoutMulOf(B, t, rcap))));
}
export function escapeChance(B) {
  const avg = (a) => alive(a).reduce((s, f) => s + stat(f, "spd"), 0) / Math.max(1, alive(a).length);
  const hold = alive(B.enemies).some((f) => f.tr.antiflee) ? 0.15 : 0;
  return Math.min(0.9, Math.max(0.2, 0.5 + (avg(B.allies) - avg(B.enemies)) / Math.max(40, avg(B.enemies) * 2) - hold));
}
export function fieldBonus(B, k) { return alive(B.allies).reduce((s, a) => s + (a.tr.field[k] || 0), 0); }

function pickTarget(list) {
  const al = alive(list);
  const taunt = al.filter((x) => x.tr.taunt || x.taunt > 0);
  return taunt.length && Math.random() < 0.65 ? pick(taunt) : pick(al);
}

// ================= ダメージ計算 =================
const CAT_STAT = { phys: ["atk", "def", 1], weapon: ["wpn", "def", 0.8], breath: ["brt", null, 1], magic: ["mat", "mdf", 1], special: ["spd", "def", 1] };
// v2.5: 特質系の 威力の もと（技ごとに 走力・硬力・魔硬力・HP・MP・全能力 など）
export const PSTAT_NAME = { spd: "走力", def: "硬力", mdf: "魔硬力", hp: "最大HP", mp: "最大MP", sum: "全能力", atk: "物力", mat: "魔力", wpn: "武力", brt: "吹力", hpnow: "いまの HP" };
export const pstatName = (k) => String(k || "spd").split("+").map((x) => PSTAT_NAME[x] || x).join("と ");
function pstatVal(f, k) {
  if (String(k).includes("+")) return String(k).split("+").reduce((a, x) => a + pstatVal(f, x) / 0.95, 0) / String(k).split("+").length * 1.0;
  if (k === "hp") return Math.min(STAT_MAX, f.php || f.mx.hp) * 0.34;   /* 第100版: HPで 威力が きまる 技は 9999 ぶんまで（HPを 伸ばしても 威力は 上がりすぎない） */   // v3.0: ボスの HP 倍率では 強く ならない
  if (k === "hpnow") return Math.min(STAT_MAX, f.hp) * 0.5;
  if (k === "mp") return (f.pmp || f.mx.mp) * 1.0;   // v3.0: ボスの MP 倍率でも 強く ならない
  if (k === "sum") return ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"].reduce((a, x) => a + stat(f, x), 0) / 7 * 1.0;
  if (k === "spd" && f.wx && f.tr.wspd && f.tr.wspd[f.wx]) return stat(f, k) / 2 * 0.95;   // 天候の 申し子の 走力2倍は 威力に のせない
  return stat(f, k) * 0.95;
}
const CAT_FAM = { weapon: "sword", breath: "dragon", magic: "nether" };
// バランスの 調整つまみ（K: ダメージ全体・AOE: 全体技の 1体あたり・WILD_HP: 野生の HP 倍率）
export const BAL = { SZB: { S: 1.1, M: 1.15, L: 0.85, G: 0.5 }, K: 0.45, AOE: 0.7, WILD_HP: 0.55, RK: [1.15, 1.1, 1.0, 0.95, 0.8, 0.75, 0.7, 0.66, 0.62], SZ: { S: 1.2, M: 1.25, L: 0.62, G: 0.3 }, TK: { S: 1.0, M: 1.0, L: 1.05, G: 1.5 }, WILD_R: [0.5, 0.5, 0.5, 0.6, 0.65, 0.75, 0.8, 0.85, 0.9] };
// 野生の HP 倍率（低ランクほど 少なめ）
export const wildHpK = (sid) => BAL.WILD_R[rankIdx(sid)] ?? BAL.WILD_HP;
export const AOE_K = 0.7;
// v2.1: L・G の 物理が 全体に なったときの ほかの 敵への 倍率、G の 2撃目の 倍率
// v2.2: 乱れ打ちの 1発ごとの 威力（1発目 0.6倍 → 2発目 0.48 → … 5発目 0.25）
export const RAPID_K = [0.6, 0.48, 0.384, 0.307, 0.246];
export const SIZE_HIT = { splash: 0.75, second: 0.5 };
const RES_DOWN = { "4": 2, "2": 3, "3": 1, "1": 0, "0": -1, "-1": -1 };
const resMul = (t, el, f = null) => {
  if (!el) return 1; let r = t.res[el] ?? 0;
  let n = (t.resdn > 0 ? 1 : 0) + ((f && f.tr && f.tr.brk && f.tr.brk[el]) || 0);   // v2.5.3: 妖光の帳・ブレイク特性で 耐性が 弱まる
  let extra = 1;
  for (let i = 0; i < n; i++) { if (r === -1) { extra *= 1.15; continue; } r = RES_DOWN[String(r)] ?? r; }
  return (RES_MULT[r] ?? 1) * extra;
};
const resMulMv = (t, mv, f = null) => (mv.el2 ? Math.max(resMul(t, mv.el, f), resMul(t, mv.el2, f)) : resMul(t, mv.el, f));
// v2.1: 技の 威力は レベル・得意な 攻撃の 種類・得意な 属性で 上がる
export const lvPow = (lv) => 1 + (lv || 1) * 0.003;
export const affPow = (lv) => 1.15 + (lv || 1) * 0.0015;
export function powerMul(f, mv) {
  let m = mv.basic ? 1 : lvPow(f.lv);
  if (f.aff.gc === mv.cat) m *= affPow(f.lv); else if (f.aff.bc === mv.cat) m *= 0.8;
  const els = [mv.el, mv.el2].filter(Boolean);
  if (els.some((e) => (f.aff.ge || []).includes(e))) m *= affPow(f.lv); else if (els.length && els.every((e) => f.aff.be === e)) m *= 0.8;
  if (CAT_FAM[mv.cat] === f.fam) m *= 1.2;
  return m;
}
// 図鑑・技の 説明用: その モンスターが 使ったときの 実際の 威力（%）
export function realPower(m, id) {
  const mv = MOVES[id]; if (!mv || !mv.mult) return 0;
  const sp = SPECIES[m.sp];
  let hk = 0; for (let h = 0; h < (mv.hits || 1); h++) hk += mv.accel ? 1 + mv.accel * h : HIT_DECAY ** h;
  return Math.round(mv.mult * 100 * powerMul({ lv: m.lv, aff: sp.aff || {}, fam: sp.fam }, mv) * hk);
}
// 攻撃側の 倍率（得意・不得意・特性・系統）
function dealtMul(f, t, mv, B, crit = false) {
  const mbody = t.tr.metalBody && ["phys", "weapon", "special"].includes(effCat(mv));   // v3.0: 後から つけた ハガネボディは 物理・武・特質を 軽減できない
  const phyl = mv.basic || mv.cat === "phys" || mv.cat === "weapon";
  const sr = ((phyl ? BAL.SZ : BAL.SZB)[sizeOf(f.m)] || 1) * (BAL.RK[rankIdxM(f.m)] ?? 1);
  let m = (1 + (f.tr.dealt[mv.cat] || 0) + (mv.el ? f.tr.dealt[mv.el] || 0 : 0)) * sr;
  m *= powerMul(f, mv);                                                        // レベル・得意な 種類・得意な 属性・系統
  if (mastered(f.m, mv)) m *= 1.1;                                             // v2.6: 技の極め
  m *= (t.m && BAL.TK[sizeOf(t.m)]) || 1;                                      // 大きい 体は 当たりやすい
  if (f.ench && f.ench.t > 0 && mv.el === f.ench.el) m *= 1.25;                // 纏い
  if (mv.el && t.elm && t.elm[mv.el] > 0) m *= 1.3;                            // 刻印
  if (mv.el && t.elg2 && t.elg2[mv.el] > 0) m *= 0.25;                         // 属性 激減
  else if (mv.el && t.elg && t.elg[mv.el] > 0) m *= 0.5;                       // 加護（属性 軽減）
  if (mv.absolute || crit || mbody) { /* 国崩・会心: 軽減・激減の 構えを 無視 */ } else if (mv.cat && t.catg2 && t.catg2[mv.cat] > 0) m *= 0.25;                     // 攻撃の 種類 激減
  else if (mv.cat && t.catg && t.catg[mv.cat] > 0 && !mv.absolute) m *= 0.5;                   // 攻撃の 種類 軽減
  if (mv.slowpow) { const fs = stat(f, "spd"), ts = stat(t, "spd"); if (fs < ts) m *= 1 + Math.min(0.8, (ts - fs) / ts); }
  if (f.tr.pinch && f.hp < f.mx.hp * 0.3) m *= f.tr.pinch;
  if (f.tr.bloodlust && t.hp < t.mx.hp * 0.5) m *= 1 + f.tr.bloodlust;
  if (f.tr.heavyhit && stat(f, "spd") < stat(t, "spd")) m *= 1 + f.tr.heavyhit;
  { const tk = (t.tr.taken[mv.cat] || 0) + (mv.el ? t.tr.taken[mv.el] || 0 : 0); m *= 1 + Math.max(-0.9, (crit || mbody) ? Math.max(0, tk) : tk); }   // v3.0: 軽減は 90%まで。会心は 軽減を 無視（弱点は のこる）
  if (!crit && B && friendsOf(B, t).some((x) => x !== t && x.hp > 0 && x.tr.guardian)) m *= 0.9;
  // v2.5.4: 条件つきの 特性
  const T = f.tr, U = t.tr;
  if (T.killer && T.killer[t.fam]) m *= 1 + T.killer[t.fam];
  if (!crit && U.famguard && U.famguard[f.fam]) m *= 1 - Math.min(0.8, U.famguard[f.fam]);
  if (T.vsail && Object.values(t.ail || {}).some((x) => x > 0)) m *= 1 + T.vsail;
  const aoeMv = mv.target === "enemies" || mv.target === "all";
  if (T.aoeup && aoeMv) m *= 1 + T.aoeup;
  if (T.single && mv.target === "enemy" && !mv.rnd) m *= 1 + T.single;
  if (T.multihit && ((mv.hits || 1) > 1 || mv.hitsR)) m *= 1 + T.multihit;
  if (T.priup && mv.pri > 0) m *= 1 + T.priup;
  // v2.9: 天候
  const wx = wxOf(B, f);
  if (wx) { const e = WX_EL[wx] || {}; if (mv.el && e[mv.el]) m *= e[mv.el]; if (mv.el2 && e[mv.el2] && !e[mv.el]) m *= e[mv.el2]; if (wx === "wind" && mv.cat === "breath") m *= 1.1;
    if (mv.wboost && mv.wboost[wx]) m *= mv.wboost[wx]; if (T.wpow && T.wpow[wx]) m *= 1 + T.wpow[wx]; }
  if (mv.whip && t.m && sizeOf(t.m) === "S") m *= 1.3;                          // ムチは 小さい 相手に よく 効く
  m *= attrMul(f, t, mv);                                                      // 攻撃属性 × 相手の 系統
  if (B && T.first1 && (B.turn || 1) === 1) m *= 1 + T.first1;
  if (B && T.late4 && (B.turn || 1) >= 4) m *= 1 + T.late4;
  if (U.fullguard && t.hp >= t.mx.hp) m *= 1 - U.fullguard;
  if (U.guts && t.hp < t.mx.hp * 0.3) m *= 1 - U.guts;
  if (t.m && (T.bigkill || T.smallkill)) { const z = sizeOf(t.m); if (T.bigkill && (z === "L" || z === "G")) m *= 1 + T.bigkill; if (T.smallkill && (z === "S" || z === "M")) m *= 1 + T.smallkill; }
  if (T.mpk && f.mp >= f.mx.mp * 0.8) m *= 1 + T.mpk;
  if (T.fullhpk && f.hp >= f.mx.hp) m *= 1 + T.fullhpk;
  if (B && T.fallen) m *= 1 + T.fallen * friendsOf(B, f).filter((x) => x.hp <= 0).length;
  if (B && T.allyfam) m *= 1 + T.allyfam * friendsOf(B, f).filter((x) => x !== f && x.hp > 0 && x.fam === f.fam).length;
  if (B && T.lone && friendsOf(B, f).filter((x) => x.hp > 0).length === 1) m *= 1 + T.lone;
  if (T.reckstance) m *= 1 + T.reckstance; if (U.reckstance) m *= 1 + U.reckstance * 0.6;
  if (T.careful) m *= 1 - T.careful * 0.5; if (U.careful) m *= 1 - U.careful;
  if (T.gambler) m *= rnd(0.5, 1.8);
  return Math.max(0.25 * Math.min(1, sr), m);   // v2.9.12: 下限は 体の 大きさ・ランクの 補正の あとに（大きい 子にも 軽減が 効く）
}
// v2.2: ダメージ計算を 作りなおし（モンスター育成RPGで おなじみの「攻撃力の 半分 − 守備力の 1/4」型）
//  物理系・武系: 攻撃/2 − 守り/4（守りが 高すぎても 攻撃の 1/12 は 通る。会心は 守り無視）
//  魔法系: 魔力/2 − 魔硬力/4（魔力の 1/9 は 通る）
//  息系: 吹力 × 0.29（守りでは 減らない。耐性と 軽減・激減の 技・特性だけ）。第68版: 0.45→0.29（Lv100・同じ 能力で 全体技どうしを くらべ 物理系・武系と 同じくらいに）
//  レベルが 上がると HPが 大きく 伸びるので、ダメージにも レベルの 伸び（Lv100で 約2.2倍）を かける
export const DMG = { CK: { phys: 0.72, weapon: 0.68, magic: 0.56, breath: 0.76, special: 0.62 }, LV: 0.012, BR: 0.29, BRD: 0.075, FLOOR: { phys: 1 / 12, weapon: 1 / 12, magic: 1 / 9, special: 1 / 10 } };
// v3.0: 特質系の 威力の もと ごとの 補正（物理系・武系と 同じ くらいに なる ように シミュレーションで 調整）
export const SP_K = { spd: 1.18, "def+mdf": 1.42, def: 1.3, mdf: 1.55, hp: 1.0, hpnow: 1.0, mp: 1.35, sum: 1.15, atk: 1.3, wpn: 1.3, mat: 1.22, brt: 1.45 };   // v3.0 第63版: 魔硬力・MP・体技を 本職に 近づける
export const lvDmg = (lv) => 1 + Math.max(0, (lv || 1) - 1) * DMG.LV;
function baseDamage(f, t, mv, crit) {
  const cat = mv.basic && !mv.wdep ? "phys" : (CAT_STAT[mv.cat] ? mv.cat : "phys");
  const [as, ds, dk] = CAT_STAT[cat];
  // 通常攻撃は 物力と 武力の 高い ほう（武者などは 武力で なぐる）
  let A = mv.dualstat ? (stat(f, "atk") + stat(f, "wpn")) * 0.6 : mv.basic && !mv.wdep ? Math.max(stat(f, "atk"), stat(f, "wpn") * 0.8) : cat === "special" ? pstatVal(f, mv.pstat || "spd") : stat(f, as);
  let raw;
  if (cat === "breath") { const D = crit ? 0 : ((stat(t, "def") + stat(t, "mdf")) / 2) * (mv.pierce ? 0.5 : 1); raw = Math.max(A * DMG.BR - D * DMG.BRD, A * DMG.BR * 0.4); }   /* 第103版: 息にも 守りが 少し 効く（硬力と 魔硬力の 平均 ×0.075。全体技が 多く 強すぎたので）*/
  else if (cat === "special") {
    // v2.5: 特質系: 技ごとの 能力 ÷2 − 相手の（硬力＋魔硬力）/2 ÷4。会心は 守り無視
    const D = crit ? 0 : ((stat(t, "def") + stat(t, "mdf")) / 2) * (mv.pierce ? 0.5 : 1);   // v3.0: 会心は 守りを 完全に 無視
    raw = A / 2 - D / 4;
    const floor = A * DMG.FLOOR.special * rnd(0.7, 1.1);
    if (raw < floor) raw = floor;
  }
  else {
    const pierce = Math.min(0.8, (cat === "phys" || cat === "weapon" ? f.tr.pierce || 0 : 0) + (mv.pierce ? 0.5 : 0));
    const D = crit ? 0 : stat(t, ds) * dk * (1 - pierce);   // v3.0: 会心は 守りを 完全に 無視
    raw = A / 2 - D / 4;
    const floor = A * (DMG.FLOOR[cat] || 1 / 12) * rnd(0.7, 1.1);
    if (raw < floor) raw = floor;
  }
  let d = raw * (DMG.CK[cat] || 1) * lvDmg(f.lv) * (mv.mult || 1) * rnd(0.9, 1.1) * (cat === "special" ? SP_K[String(mv.pstat || "spd")] ?? 1.15 : 1);
  if (crit) d *= cat === "magic" ? 1.75 + (f.tr.critdmg || 0) : 1.5 + (f.tr.critdmg || 0) + (cat === "phys" ? 0.2 : 0);   // v2.9: 会心 1.5倍（物理系 1.7倍）   // v2.5.3: 魔法の 会心は 魔力の 暴走（1.75倍）   // 物理系の 特質: 会心ダメージ +30%
  return d;
}
// ハガネ（鋼の体）: 会心・対ハガネ技 以外は 0〜2
// v3.0: ハガネに 効くのは 会心・物理系・武系・物力か 武力で きまる 特質系。魔法・息などは 0〜2
export const effCat = (mv) => (mv.basic && !mv.wdep ? "phys" : mv.cat);   // v3.0: 武器の 通常攻撃は 武器の 種類で
export const metalHits = (mv) => { const c = effCat(mv); return !!(c === "phys" || c === "weapon" || (c === "special" && /atk|wpn/.test(String(mv.pstat || "")))); };
function metalCap(f, t, d, mv, crit) {
  if (!t.tr.metal || crit || metalHits(mv)) return d;
  if (t.tr.metalBody && ["phys", "weapon", "special"].includes(effCat(mv))) return d;   // 後から つけた ハガネボディは 特質系も ふつうに 受ける
  let x = ri(0, 2);
  if (mv.metalx) x = ri(mv.metalx[0], mv.metalx[1]);
  if (mv.f === "pct") x = Math.max(3, Math.ceil(t.mx.hp * mv.k));
  if (f && f.tr.metalkill) x += f.tr.metalkill;
  return x;
}
// v2.9: 先制度の 表示
export const PRI_TXT = { 4: "§b先制度 +4§r（最優先）", 3: "§b先制度 +3§r", 2: "§a先制度 +2§r", 1: "§a先制度 +1§r", 0: "§7先制度 0§r", "-1": "§c先制度 -1§r（後攻）", "-2": "§c先制度 -2§r（最後）" };
export const priText = (p) => PRI_TXT[String(Math.max(-2, Math.min(4, p | 0)))];
// v2.9: 急所ランク（0〜3）。技・特性・急所ねらいで 上がる。ランク1: +8%・2: +20%・3以上: +40%
export const CRIT_STAGE = [0, 0.08, 0.2, 0.4];
export const critStage = (f, mv) => Math.min(3, (mv.critR || 0) + Math.round(f.tr.critR || 0) + (f.critT > 0 ? 2 : 0));
function critRate(f, mv) { if (mv.cat === "breath" && !mv.basic) return 0; return Math.min(0.75, (mv.cat === "weapon" ? 1 / 14 : mv.cat === "magic" ? 1 / 28 : 1 / 22) + (f.tr.crit || 0) + (mv.crit || 0) + (f.tr.pinchcrit && f.hp <= f.mx.hp * 0.25 ? f.tr.pinchcrit : 0) + CRIT_STAGE[critStage(f, mv)]); }   // v3.0: 瀕死の会心
// v2.1: 攻撃の 種類の 特質
export const CAT_TRAIT = {
  phys: "会心ダメージ +20%（1.7倍）・身を守る 相手にも 効きやすい",
  weapon: "相手の 硬力を 2割 無視・会心が 出やすい・武器の 属性が のる",
  breath: "吹力で 威力が 決まる。守り（硬力と 魔硬力の 平均）は 少しだけ 効く（属性の 耐性と 息の 軽減・激減でも 減る）・ほとんど 全体・追加効果が 1.5倍 かかりやすい",
  magic: "魔力 対 魔硬力・弱点を 突くと ダメージ さらに +20%",
  special: "技ごとに 決まった 能力（走力・硬力・魔硬力・HP など）で 威力が きまる・相手の 硬力と 魔硬力の 平均で へる・ほとんど 無属性",
};

// ================= AI =================
// v3.0 第63版: 作戦は 6つに 書きなおし（古い 作戦は 近い ものへ 読みかえる）
export const TACTICS = { sente: "先手必勝", analyze: "状況分析", karame: "搦手上手", counter: "反撃時間", backer: "後援者", nomp: "MP使うな" };
export const TAC_DESC = { sente: "攻撃技が 中心。毒や 守り下げの ついた 攻撃・弱点を つく 攻撃を 優先", analyze: "状況を 読んで 攻撃・状態異常・補助・回復を 的確に 使いわける", karame: "状態異常の 技と 弱体（デバフ）を 優先", counter: "相手の 攻撃の 種類に あわせて 反射技を 張る", backer: "後ろ盾。味方の 強化と、相手の 攻撃の 種類や 属性を 激減させる 技を 優先", nomp: "MPを 使わず、MP0の 技と ふつうの 攻撃で 攻める" };
export const TAC_ALIAS = { normal: "analyze", varied: "analyze", heal: "analyze", guard: "analyze", attack: "sente", aoe: "sente", focus: "sente", metal: "sente", status: "karame", support: "backer", buffer: "backer", healer: "backer", mpsave: "nomp" };
export const tacOf = (m) => { const t = (m && m.tac) || "analyze"; return TACTICS[t] ? t : TAC_ALIAS[t] || "analyze"; };
const TAC_W = {   // dmg, heal, revive, buff, debuff, status, guard, noise
  normal: [1, 1, 1, 0.8, 0.8, 0.8, 0.5, 0.15], attack: [1.35, 0.45, 0.6, 0.4, 0.5, 0.4, 0.2, 0.08], varied: [1, 1, 1, 1, 1, 1, 0.6, 0.45],
  heal: [0.7, 2.2, 2.2, 1, 0.7, 0.6, 1, 0.1], support: [0.7, 1.4, 1.4, 2.4, 1.6, 0.9, 0.8, 0.1], status: [0.8, 1, 1, 0.8, 1.8, 2.6, 0.5, 0.12],
  guard: [0.8, 1.4, 1.4, 1.6, 0.8, 0.6, 2.2, 0.1], nomp: [1, 1, 1, 1, 1, 1, 0.6, 0.1], metal: [1.2, 0.8, 1, 0.5, 0.5, 0.4, 0.3, 0.05],
  healer: [0.35, 3.0, 3.0, 1.1, 0.6, 0.5, 1, 0.08],
  // v3.0 第63版: 新しい 作戦
  sente: [1.3, 0.6, 0.8, 0.35, 0.7, 0.6, 0.25, 0.06], analyze: [1, 1.1, 1.2, 1.15, 1.1, 1.1, 1, 0.02], karame: [0.55, 0.9, 1, 0.6, 2.6, 3.0, 0.5, 0.06],
  counter: [0.75, 1, 1, 0.8, 0.7, 0.6, 3.2, 0.06], backer: [0.45, 1.4, 1.4, 3.6, 1.0, 0.6, 1.0, 0.06], buffer: [0.9, 1, 1, 2.6, 1.2, 0.7, 0.8, 0.1], aoe: [1.1, 1, 1, 0.7, 0.7, 0.6, 0.4, 0.12], focus: [1.15, 1, 1, 0.7, 0.7, 0.6, 0.4, 0.1], mpsave: [1, 1, 1, 0.8, 0.8, 0.8, 0.5, 0.12],
};
// v2.6: 技の極め（100回 使うと 威力 +10%・消費MP -20%）
for (const [k, v] of Object.entries(MOVES)) if (v && !v._id) try { v._id = k; } catch {}
export const MK_NEED = 100;
export const mastered = (m, mv) => !!(m && m.mk && mv && m.mk[mv._id] >= MK_NEED);
export const costOf = (f, mv) => { if (f.infMP) return 0; const c = f.tr.halfmp ? Math.ceil(mv.mp / 2) : mv.mp; return mastered(f.m, mv) ? Math.floor(c * 0.8) : c; };
export const isSpell = (mv) => !!(mv && (mv.cat === "magic" || mv.heal || mv.revive || mv.reraise || mv.regen || mv.trboost || mv.mpgive || mv.allmp));
export const sealedFor = (f, mv) => !!((mv.cat && f.seal[mv.cat] > 0 && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless")) || (f.mistT > 0 && !mv.basic && isSpell(mv)));
function willBounce(t, mv) {
  if (mv.norefl || t.noReflT > 0) return 0;
  if (t.tr.metalBody && ["phys", "weapon", "special"].includes(mv.cat)) return 0;   // v3.0: 後から つけた ハガネボディは 跳ね返せない   // v2.9.12: ハンシャ封じの霧の あいだは 跳ね返らない
  if (mv.cat && t.refl[mv.cat] > 0) return 1;
  if (mv.el && t.reflEl && t.reflEl[mv.el] > 0) return 1;
  if (mv.cat && t.tr.barrierp && t.tr.barrierp[mv.cat]) return t.tr.barrierp[mv.cat];
  const b = t.tr.barrier;
  if (b && b.size) { if (mv.el && b.has(mv.el)) return 1; if (b.has(mv.cat)) return 0.7; }
  if (mv.cat === "magic" && t.tr.reflect) return t.tr.reflect;
  return 0;
}
let AI_TURN = 0;
function estOne(f, t, mv) {
  if (mv.allmp && t && t.hp > 0) return f.mp * ALLMP_K * BAL.AOE;
  if (!t || t.hp <= 0 || !(mv.mult || mv.selfko || mv.f)) return 0;
  if (t.tr.metal && !metalHits(mv) && !(t.tr.metalBody && ["phys", "weapon", "special"].includes(effCat(mv)))) {
    const cr = (mv.scrit ? 1 - (mv.gamble || 0) : Math.min(1, critRate(f, mv))) * (mv.acc !== undefined && mv.acc < 100 ? mv.acc / 100 : 1);
    const per = mv.metalx ? (mv.metalx[0] + mv.metalx[1]) / 2 : mv.f === "pct" ? t.mx.hp * mv.k : 1;
    return (per + (f.tr.metalkill || 0)) * (mv.hits || 1) * (1 - cr) + cr * t.hp * (mv.hits || 1);
  }
  if (mv.selfko) return (f.hp * 1.5 + powOf(f)) * BAL.AOE;
  const k = resMulMv(t, mv, f);
  if (k < 0) return -baseDamage(f, t, mv, false) * 0.5;
  const sc = !!mv.scrit && !t.tr.critguard;   // v3.0 第63版: 会心無効の 相手には 会心技を 高く 見ない
  let d = baseDamage(f, t, mv, sc) * (mv.hitsR ? (mv.hitsR[0] + mv.hitsR[1]) / 2 : (mv.hits || 1)) * k * dealtMul(f, t, mv, null, sc) * (mv.target === "enemies" || mv.target === "all" ? BAL.AOE : 1);
  if (f.m && SPECIES[f.m.sp]?.combo5 && (mv.basic || mv.cat === "weapon") && !mv.rnd && mv.target === "enemy") d *= mv.basic ? 2.0 : 1.5;
  else if (f.tr.rapid && (mv.basic || mv.cat === "phys") && (mv.hits || 1) === 1 && !mv.rnd && mv.target === "enemy") d *= RAPID_K.slice(0, Math.min(5, f.tr.rapid)).reduce((a, b) => a + b, 0);
  const fsz = f.m ? sizeOf(f.m) : "M", phy = mv.basic || mv.cat === "phys" || mv.cat === "weapon";
  if (phy && fsz === "G" && !(f.tr.rapid && (mv.basic || mv.cat === "phys") && (mv.hits || 1) === 1)) d *= 1 + SIZE_HIT.second;
  // v2.9.2: 連続攻撃の 減衰と ダメージの 上限を 見積もりにも
  { const n = f.m && SPECIES[f.m.sp]?.combo5 && (mv.basic || mv.cat === "weapon") && !mv.rnd && mv.target === "enemy" ? 5 : (mv.hits || 1);
    if (n > 1 && !mv.accel) { let s2 = 0; for (let h = 0; h < n; h++) s2 += HIT_DECAY ** h; d *= s2 / n; }
    const capped = !mv.absolute && (f.capT > 0 || !enmaFree(f, t) && !(fsz === "G" || f.tr.nocap || f.nocapT > 0 || mv.nocaphit || mv.absolute || (f.tr.nocappinch && f.hp <= f.mx.hp * 0.5)));
    if (capped) d = Math.min(d, DMG_CAP * n * (f.tr.nocapch ? 1 + f.tr.nocapch : 1) * (sc ? 1.5 : 1)); }
  if (mv.acc !== undefined && mv.acc < 100) d *= mv.acc / 100;   // 命中率は 上限の あとで
  if (mv.cat === "phys" || mv.cat === "weapon") d *= 1 - (t.tr.evade || 0);
  if (t.guard) d *= 0.3; else if (t.defend) d *= 0.5;
  if (t.bkT > 0) d *= 1.3; else if (t.bg === 1 && k > 1) d *= 1.25;
  if (t.chn && t.chn.t === AI_TURN && t.chn.L.length && !t.chn.L.includes(f)) d *= 1.12;   /* 仲間が もう 攻撃した 相手を ねらうと 連携 */   /* 第104版: ブレイク中・あと1で ブレイクの 相手を ねらう */
  { const b = willBounce(t, mv); d *= b >= 1 ? -1.4 : 1 - b * 1.5; }   // v3.0 第63版: 確率で 跳ね返る ときは 期待値に 近く（v2.5.6: 跳ね返される 技は 大きく マイナス（自分が ダメージを 受ける）
  return d;
}
function scoreDamage(f, mv, foes, tgt) {
  const fsz = f.m ? sizeOf(f.m) : "M", spread = (mv.basic || mv.cat === "phys" || mv.cat === "weapon") && (fsz === "L" || fsz === "G") && !mv.rnd && !(f.tr.rapid && (mv.basic || mv.cat === "phys") && (mv.hits || 1) === 1);
  const list = mv.target === "enemies" || mv.target === "all" || spread ? alive(foes) : [tgt];
  let v = 0;
  for (const t of list) { if (!t) continue; const d = estOne(f, t, mv); v += Math.min(d, t.hp) + (d >= t.hp ? t.mx.hp * 0.35 : 0); }
  return v;
}
const ailOk = (t, a) => t.hp > 0 && !t.ail[a] && !t.tr.immune.has(a) && t.ares[a] !== 2;
// v2.2.2: x が t に 1回の 行動で 与えられる いちばん 大きい ダメージ（ターンごとに キャッシュ）
const isAtkMv = (mv) => mv && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless") && (mv.mult || mv.f);
function threatTo(B, x, t) {
  const tk = B.turn || 1;
  if (!B._th || B._th.t !== tk) B._th = { t: tk, m: new Map() };
  let row = B._th.m.get(x); if (!row) { row = new Map(); B._th.m.set(x, row); }
  if (row.has(t)) return row.get(t);
  let best = 0;
  try {
    if (!sealedFor(x, x.atk) && !(x.ail && x.ail.fear > 0)) best = estOne(x, t, x.atk);
    for (const id of x.moves || []) { const m2 = MOVES[id]; if (!isAtkMv(m2) || m2.selfko || m2.target === "all" || costOf(x, m2) > x.mp || sealedFor(x, m2)) continue; best = Math.max(best, estOne(x, t, m2)); }
  } catch {}
  const acts = x.tr && x.tr.acts ? (x.tr.acts[0] + x.tr.acts[1]) / 2 : 1;
  const disabled = x.ail && (x.ail.sleep > 0 || x.ail.freeze > 0) ? 0.25 : x.ail && x.ail.para > 0 ? 0.6 : 1;
  const v = Math.max(0, best) * acts * (1 + ((x.tr && x.tr.extra) || 0) * 0.5) * disabled;
  row.set(t, v);
  return v;
}
// v2.2.2: マスター・ボスの 戦術の 技（役割と 得意な 能力で 選ぶ）
const KIT_POOL = {};
function kitPool(key, fn) { if (!KIT_POOL[key]) KIT_POOL[key] = Object.keys(MOVES).filter((id) => { const mv = MOVES[id]; return mv && !mv.sig && !mv.god && !mv.hidden && !mv.boss && fn(mv); }).sort((a, b) => (MOVES[a].tier || 0) - (MOVES[b].tier || 0)); return KIT_POOL[key]; }
export function npcKit(f, role, k = 1) {
  if (!f || !f.m || !SPECIES[f.m.sp]) return [];
  const isSp = (f.aff && f.aff.gc) === "special", psx = SPECIES[f.m.sp].pstat || "spd";
  const mx = f.mx, main = isSp ? ({ spd: "spd", "def+mdf": "def", hp: "def" }[psx] || "spd") : ["atk", "wpn", "mat", "brt"].sort((a, b) => (mx[b] || 0) - (mx[a] || 0))[0];
  const cat = isSp ? "special" : { atk: "phys", wpn: "weapon", mat: "magic", brt: "breath" }[main];
  const tierCap = k >= 3 ? 4 : k >= 2 ? 3 : 2;
  const okT = (id) => (MOVES[id].tier || 1) <= tierCap && costOf(f, MOVES[id]) <= Math.max(8, f.mx.mp * 0.45);
  const top = (L) => { const c = L.filter(okT); if (!c.length) return null; const hi = c.filter((id) => (MOVES[id].tier || 1) >= Math.min(tierCap, Math.max(...c.map((x) => MOVES[x].tier || 1)))); return pick(hi.length ? hi : c); };
  const out = [];
  const add = (id) => { if (id && !out.includes(id) && !f.moves.includes(id)) out.push(id); };
  const selfBuff = kitPool(`b_${main}`, (mv) => !isAtkMv(mv) && mv.buff && (mv.buff[main] || 0) > 0 && Object.values(mv.buff).every((v) => v > 0) && ["self", "allies", "ally"].includes(mv.target));
  const atkDeb = kitPool(`ad_${cat}`, (mv) => isAtkMv(mv) && mv.cat === cat && mv.debuff && mv.target === "enemy");
  const deb = (st) => kitPool(`d_${st}`, (mv) => !isAtkMv(mv) && mv.buff && (mv.buff[st] || 0) < 0 && Object.values(mv.buff).every((v) => v < 0) && ["enemy", "enemies", "rand2"].includes(mv.target));
  const refl = kitPool("refl", (mv) => mv.refl && mv.target === "self");
  const heal = kitPool("heal", (mv) => mv.heal && !isAtkMv(mv) && !mv.revive);
  const spd = kitPool("b_spd", (mv) => !isAtkMv(mv) && mv.buff && (mv.buff.spd || 0) > 0 && Object.values(mv.buff).every((v) => v > 0) && ["self", "allies"].includes(mv.target));
  const ail = kitPool("ail", (mv) => !isAtkMv(mv) && mv.ail && ["sleep", "para", "freeze", "charm", "fear"].includes(mv.ail));
  if (role === "ace") {
    add(top(selfBuff)); add(top(atkDeb));
    if (k >= 2) add(top(refl));
    if (k >= 3) add(top(deb(main === "mat" ? "mdf" : "def")));
  } else {
    const r = Math.random();
    if (r < 0.34) { add(top(heal)); add(top(deb(pick(["atk", "mat", "spd"])))); }
    else if (r < 0.67) { add(top(spd)); add(top(deb(main === "mat" ? "mdf" : "def"))); }
    else { add(top(ail)); add(top(selfBuff)); }
    if (k >= 2) add(top(atkDeb));
    if (k >= 3) add(top(heal));
  }
  return out.slice(0, 1 + Math.min(3, k));
}
export function aiDecide(f, B, opt = {}) {
  const friendsAll = realFriends(B, f), friends = alive(friendsAll), foes = realFoes(B, f), live = alive(foes);
  if (!live.length) return { actor: f, kind: "defend" };
  AI_TURN = B.turn || 1;   /* 第104版: 連携を ねらう ため */
  const tac = f.aiTac || ((f.side === "a" || f.owner) && f.m ? tacOf(f.m) : "normal");   // 第63版: 味方は 6つの 作戦（古い 作戦は 読みかえ）   // v3.0: エンマは 戦う たびに 戦い方が ちがう
  const W = TAC_W[tac] || TAC_W.normal;
  let usable = f.moves.map((id) => [id, MOVES[id]]).filter(([, mv]) => mv && costOf(f, mv) <= f.mp && !sealedFor(f, mv));
  if (tac === "nomp") usable = usable.filter(([, mv]) => costOf(f, mv) === 0);
  if (opt.lite) usable = usable.filter(([, mv]) => !mv.heavy && !mv.solo);   // v3.0: 追加行動の 考えなおしでは 行動が へる 技を えらばない
  // v2.9.11: 技の 好み（◎よく使う・○使う・×使わない）。味方の モンスターだけ
  const pref = f.m && f.m.mpref && (f.side === "a" || f.owner) ? f.m.mpref : null;
  if (pref) usable = usable.filter(([id]) => pref[id] !== 0);
  const turn = B.turn || 1;
  const metalFoe = live.find((x) => x.tr.metal);
  // v2.2.2: 状況を 読む（だれが 危険か・自分は 次に 倒れそうか・戦いは 長びくか）
  const outTh = new Map(); for (const x of live) { let m = 0; for (const y of friends) m = Math.max(m, threatTo(B, x, y)); outTh.set(x, m); }
  const inc = live.reduce((a, x) => a + threatTo(B, x, f), 0);
  const danger = (inc / Math.max(1, friends.length)) * 1.5 / Math.max(1, f.hp);
  const faster = live.every((x) => stat(f, "spd") > stat(x, "spd") * 1.05);
  const ourRate = Math.max(1, friends.reduce((a, y) => a + Math.max(0, ...live.map((x) => threatTo(B, y, x))), 0));
  const T = live.reduce((a, x) => a + x.hp, 0) / ourRate;
  const longK = Math.max(0.15, Math.min(1.4, (T - 0.7) / 2));
  const doomed = danger >= 1 && !faster;
  const worst = [...live].sort((a, b) => outTh.get(b) - outTh.get(a))[0];
  const opts = [];
  const add = (v, a) => opts.push([v, a]);
  const bestTarget = (mv) => {
    if ((tac === "metal" || tac === "sente") && metalFoe) return metalFoe;   // 第63版: 先手必勝は ハガネ族を 先に ねらう
    const taunt = live.filter((x) => x.tr.taunt || x.taunt > 0);
    if (taunt.length && !f.tr.shieldbreak && Math.random() < 0.5) return pick(taunt);   // v3.0: 盾くだきの 子は 挑発に のらない
    let bt = live[0], bv = -1e9;
    for (const t of live) { const d = estOne(f, t, mv); const v = Math.min(d, t.hp) + (d >= t.hp ? t.mx.hp * 0.4 + outTh.get(t) * 0.9 : 0) + outTh.get(t) * 0.08 - t.hp * 0.02; if (v > bv) { bv = v; bt = t; } }
    return bt;
  };
  const fear = f.ail.fear > 0;
  if (!sealedFor(f, f.atk) && !fear) { const t = bestTarget(f.atk); add(scoreDamage(f, f.atk, foes, t) * W[0] * (pref && pref._atk === 0 ? 0.05 : pref && pref._atk === 2 ? 1.5 : 1) * (tac === "healer" ? 0.6 : 1), { actor: f, kind: "attack", target: t }); }
  const avgDmg = Math.max(3, Math.abs(scoreDamage(f, f.atk, foes, bestTarget(f.atk))));
  add(0, { actor: f, kind: "defend" });   // v2.5.6: どの 攻撃も 跳ね返される ときは 無理に 打たない
  const mpPen = (mv) => costOf(f, mv) * (f.mp < f.mx.mp * 0.3 ? 2.2 : 0.8) * avgDmg / Math.max(20, f.mx.mp);
  for (const [id, mv] of usable) {
    const isAtk = mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless";
    if (fear && isAtk) continue;
    let v = 0, tgt = null;
    if (isAtk && (mv.mult || mv.selfko || mv.f)) {
      tgt = mv.target === "enemy" ? bestTarget(mv) : null;
      v = scoreDamage(f, mv, foes, tgt) * W[0];
      if (mv.target === "all") v -= friends.filter((x) => x !== f).reduce((s, x) => { const d = estOne(f, x, mv); return s + Math.min(d, x.hp) * 1.6 + (d >= x.hp ? x.mx.hp * 0.8 : 0); }, 0);
      if (mv.selfko) v = f.hp < f.mx.hp * 0.25 && tac !== "heal" ? v * 0.6 : -1;
      if (mv.gamble) v *= 1 - mv.gamble;
      if (mv.recoil || mv.hpcost) v -= f.hp < f.mx.hp * 0.35 ? avgDmg * 1.2 : avgDmg * 0.2;
      if (mv.inf) v += avgDmg * 0.25 * mv.inf[1] * W[5];
      if (mv.death) v += avgDmg * 0.6 * mv.death * W[5];
      if (mv.sealhit) v += avgDmg * 0.2 * mv.sealhit[1] * W[4];
      if (mv.debuff) { const tt = tgt || live[0]; const room = tt && !tt.tr.nodebuff ? Math.min(-mv.debuff[1], BUF_MAX + (tt.buf[mv.debuff[0]] || 0)) : 0; v += avgDmg * 0.22 * room * (mv.debuff[2] ?? 1) * (mv.target === "enemies" ? live.length * 0.7 : 1) * W[4]; }
      if (mv.buff) for (const [k, d] of Object.entries(mv.buff)) if (d > 0) v += avgDmg * 0.2 * (k === "hp" ? (f.hp < f.mx.hp * 0.7 ? 1 : 0) : k === "mp" ? (f.mp < f.mx.mp * 0.5 ? 1 : 0) : Math.max(0, Math.min(d, (multiUp(mv.buff) ? MULTI_CAP : BUF_MAX) - (f.buf[k] || 0)))) * W[3];
      if (mv.drain && f.hp < f.mx.hp * 0.6) v += avgDmg * mv.drain * 0.8;
      if (mv.nocover && live.some((x) => x.cover > 0 || x.tr.taunt || x.taunt > 0)) v *= 1.4;   // v3.0: 盾を 張られて いたら 盾砕き
      if (mv.finish) { const tt = tgt || live[0]; if (tt && (tt.reraise || tt.doom || (tt.tr.undying && !tt.undyingUsed))) v += avgDmg * 1.2; }
    } else if (mv.mpdrain) {
      if (f.mp < f.mx.mp * 0.3) { v = avgDmg * 0.6; tgt = live.find((x) => x.mp > 0) || live[0]; }
    } else if (mv.revive) {
      const dead = friendsAll.find((x) => x.hp <= 0 && !x.out);
      if (dead) { v = dead.mx.hp * 0.8 * W[2]; tgt = dead; }
    } else if (mv.heal) {
      const hurt = friends.filter((x) => x.hp < x.mx.hp * 0.8).sort((a, b) => a.hp / a.mx.hp - b.hp / b.mx.hp);
      if (hurt.length) {
        const amt = f.isBoss ? Math.min(healAmt(f, mv), f.mx.hp * 0.06) : healAmt(f, mv);   /* 第67版: ボスの 回復は 1回 最大HPの 6%まで */
        const tg = mv.target === "allies" ? hurt : mv.target === "self" ? [f] : [hurt[0]];
        for (const x of tg) { const th = live.reduce((a, y) => a + threatTo(B, y, x), 0) / Math.max(1, friends.length); v += Math.min(amt, x.mx.hp - x.hp) * (x.hp < x.mx.hp * 0.35 || th * 1.3 >= x.hp ? 2.2 : 1) * (th * 1.3 >= x.hp && th < x.hp + amt ? 1.4 : 1); }
        v *= W[1]; tgt = hurt[0];
        if (f.isBoss && f.usedT === (B.turn || 1) && f.usedS && [...f.usedS].some((id) => MOVES[id]?.heal)) v *= 0.2;
        if (f.isBoss && (f.smart || 0) >= 2.5 && f.hp > f.mx.hp * 0.35) v *= 0.5;   /* 第68版: 強い ボスは 元気な うちは 回復しにくく */   /* 第67版: 同じ ターンに 回復を 重ねにくく */
      }
    } else if (mv.nocap || mv.capT) {
      // v2.9.2: 上限の 霧 … 味方が 上限に とどく ほど 強い ときだけ・敵が Gや 解放中の ときに 封限
      if (mv.nocap) { const n = friends.filter((x) => x.hp > 0 && !(x.nocapT > 1) && x.m && sizeOf(x.m) !== "G" && !x.tr.nocap).length; if (n && avgDmg >= DMG_CAP * 0.8) v = avgDmg * 0.45 * n * W[3]; }
      else { const n = live.filter((x) => !(x.capT > 1) && x.m && (sizeOf(x.m) === "G" || x.tr.nocap || x.nocapT > 0)).length; if (n) v = avgDmg * 0.9 * n * W[4]; }
    } else if (mv.weather) {
      // v2.9: 天候 … 味方の 得意な 属性が 強く なる・まだ その 天候で ない ときだけ
      const cur = B.weather && B.weather.t > 1 ? B.weather.w : null;
      if (cur !== mv.weather) { const el = { sun: "fire", rain: "water", sand: "earth", snow: "ice", storm: "thunder", wind: "wind", fog: "wood", dark: "dark", holy: "light" }[mv.weather];
        const fan = friends.filter((x) => x.hp > 0 && (((x.aff && x.aff.ge) || []).includes(el) || (x.tr.wpow && x.tr.wpow[mv.weather]) || (x.tr.wspd && x.tr.wspd[mv.weather]))).length;
        const foe = live.filter((x) => ((x.aff && x.aff.ge) || []).includes(el)).length;
        v = avgDmg * (0.35 + fan * 0.45 - foe * 0.3) * W[3]; }
    } else if (mv.cure) {
      const cand = mv.target === "self" ? [f] : friends;   // v2.9.12: 自分だけの 技は 自分を 見る
      const sick = cand.find((x) => Object.values(x.ail).some(Boolean));
      if (sick) { v = avgDmg * 1.2 * W[1]; tgt = sick; }
    } else if (mv.regen && !mv.buff) {
      const h = (mv.target === "self" ? [f] : friends).find((x) => x.hp < x.mx.hp * 0.6 && !x.regen);
      if (h) { v = avgDmg * 0.8 * W[1]; tgt = h; }
    } else if (mv.death && !isAtkMv(mv)) {   // v3.0: 即死の 技は 効く 相手が いる ときだけ
      const tg = live.filter((x) => !deathImmune(x));
      if (tg.length) { const use = mv.target === "enemies" ? tg : [tg.sort((x, y) => y.hp - x.hp)[0]]; v = use.reduce((q, x) => q + Math.min(x.hp, avgDmg * 2.5), 0) * mv.death * 0.75 * W[5]; tgt = use[0]; }
    } else if (mv.ail) {
      const tg = mv.target === "enemies" ? live : [live.find((x) => ailOk(x, mv.ail))].filter(Boolean);
      const ok_ = tg.filter((x) => ailOk(x, mv.ail));
      if (ok_.length) {
        const strong = ["sleep", "freeze", "charm", "para", "fear"].includes(mv.ail) ? 1 : 0.6;
        const bt2 = [...ok_].sort((a, b) => outTh.get(b) - outTh.get(a))[0];
        v = ok_.length * (mv.chance || 0.4) * avgDmg * strong * W[5] * (mv.target === "enemies" ? 1 : 0.6 + Math.min(1.2, outTh.get(bt2) / Math.max(1, avgDmg) * 0.5)) * Math.min(1.2, 0.5 + longK); tgt = bt2;
      }
    } else if (mv.seal) {
      const tg = (mv.target === "enemies" ? live : live.slice(0, 1)).filter((x) => mv.seal === "all" ? !x.tr.nosealed : !(x.seal[mv.seal] > 0) && !x.tr.nosealed && x.aff.gc === mv.seal);
      if (tg.length) { v = tg.length * avgDmg * 0.9 * (mv.chance || 1) * W[4]; tgt = tg[0]; }
    } else if (mv.field === "reverse") {
      if (!(B.reverse > 0)) {
        const me = alive(friendsAll).reduce((s, x) => s + stat(x, "spd"), 0) / Math.max(1, friends.length);
        const them = live.reduce((s, x) => s + stat(x, "spd"), 0) / live.length;
        if (me < them * 0.9) v = avgDmg * 1.6 * W[3];
      }
    } else if (mv.mimic) {
      v = f.mimicOn ? 0 : avgDmg * 0.4 * Math.min(3, live.length) * (f.hp < f.mx.hp * 0.3 ? 0.3 : 1); tgt = f;
    } else if (mv.antiRefl) {
      const nr = live.filter((x) => Object.values(x.refl || {}).some((q) => q > 0) || Object.values(x.reflEl || {}).some((q) => q > 0)).length;
      v = nr && !(f.noReflT > 0) ? avgDmg * 0.9 * nr : 0; tgt = f;
    } else if (mv.refl && f.noReflT > 0) {
      v = 0;
    } else if (mv.refl && f.isBoss && ([].concat(mv.refl).every((c) => (f.refl[c] || 0) > 0) || ((B.turn || 1) - (f.reflT ?? -9)) < 3)) {
      v = 0;   // v3.0: ボスは 反射を 3ターンに 1回・すでに 構えて いる ときは 使わない
    } else if (mv.refl) {
      const rs = [].concat(mv.refl);
      // v2.2: 相手が その 種類で どれだけ 痛い 攻撃を して くるかで 価値を きめる（命が あぶない ほど 反射を 優先）
      let tdmg = 0;
      for (const x of live) {
        let best = 0;
        if (rs.includes("phys") || rs.includes("weapon")) best = Math.max(best, estOne(x, f, x.atk));
        for (const id of x.moves || []) { const m2 = MOVES[id]; if (m2 && m2.mult && rs.includes(m2.cat) && costOf(x, m2) <= x.mp) best = Math.max(best, estOne(x, f, m2) * (m2.hits && !m2.rnd ? 1 : 1)); }
        tdmg += best * (rs.includes(x.aff.gc) ? 1 : 0.3) * Math.max(1, (x.tr.acts ? (x.tr.acts[0] + x.tr.acts[1]) / 2 : 1));   // v3.0: その 種類を 本当に 使いそうな 相手だけ 重く（1回の 行動で 当たるのは 一部）
      }
      const threat = live.filter((x) => rs.includes(x.aff.gc)).length;
      if ((threat || tdmg > 0) && !rs.every((c) => f.refl[c] > 0)) v = Math.max(avgDmg * 0.5 * threat, tdmg * 0.8 * (tdmg >= f.hp * 0.6 ? 1.4 : 1)) * W[6] * (mv.target === "allies" ? 1.3 : 1);
      v *= 0.45;   // v3.0: 反射ばかり 選ばない ように 控えめに
      if (Object.values(f.refl || {}).some((q) => q > 0)) v *= 0.3;   // もう 何かを 跳ね返す 構え
      if (((B.turn || 1) - (f.reflT ?? -9)) < 2) v *= 0.15;   // つづけて 使わない
    } else if (mv.catguard || mv.catguard2 || mv.elguard2) {
      const c = mv.catguard || mv.catguard2, e = mv.elguard2;
      const th = c ? live.filter((x) => x.aff.gc === c).length : live.filter((x) => (x.aff.ge || []).includes(e)).length;
      const have = c ? (mv.catguard2 ? f.catg2[c] > 0 : f.catg[c] > 0 || f.catg2[c] > 0) : f.elg2[e] > 0;
      if (th && !have) v = avgDmg * (mv.catguard2 || mv.elguard2 ? 0.5 : 0.35) * th * W[6] * (mv.target === "allies" ? 1.4 : 1);
      tgt = f;
    } else if (mv.enchant || mv.elguard || mv.elmark || mv.reflel || mv.ailguard || mv.late || mv.critup || mv.mpgive || mv.nosealT) {
      if (mv.enchant && !(f.ench && f.ench.t > 0)) v += avgDmg * ((f.aff.ge || []).includes(mv.enchant) ? 0.6 : 0.35) * W[3];
      if (mv.elguard) { const th = live.filter((x) => (x.aff.ge || []).includes(mv.elguard)).length; if (th && !(f.elg[mv.elguard] > 0)) v += avgDmg * 0.35 * th * W[6]; }
      if (mv.reflel) { const th = live.filter((x) => (x.aff.ge || []).includes(mv.reflel)).length; if (th && !(f.reflEl[mv.reflel] > 0)) v += avgDmg * 0.4 * th * W[6]; }
      if (mv.elmark) { const us = friends.filter((x) => (x.aff.ge || []).includes(mv.elmark)).length; if (us && !live.every((x) => x.elm[mv.elmark] > 0)) v += avgDmg * 0.35 * us * W[4]; }
      if (mv.ailguard && turn <= 2 && !friends.some((x) => x.ailg[mv.ailguard] > 0)) v += avgDmg * 0.15 * W[6];
      if (mv.late && !(f.late > 0) && !(B.reverse > 0)) { const them = live.reduce((s, x) => s + stat(x, "spd"), 0) / live.length; if (stat(f, "spd") < them * 0.9) v += avgDmg * 0.6 * W[3]; }
      if (mv.critup && !(f.critT > 0)) v += avgDmg * 0.45 * W[3];
      if (mv.mpgive) { const low = friends.filter((x) => x.mp < x.mx.mp * 0.3).length; if (low) v += avgDmg * 0.4 * low * W[1]; }
      if (mv.nosealT && live.some((x) => x.moves.some((id) => MOVES[id]?.seal))) v += avgDmg * 0.3 * W[6];
      if (v > 0 && mv.buff) v += avgDmg * 0.2 * Object.keys(mv.buff).length;
      if (v > 0) v *= Math.min(1.2, 0.4 + longK) * (doomed ? 0.4 : 1);
      if (v > 0 && mv.heal) v += avgDmg * 0.3;
      tgt = mv.target === "enemies" || mv.target === "enemy" ? live[0] : f;
      if (mv.mpgive && (mv.target === "ally" || mv.target === "one" || !mv.target)) { const lo = friends.filter((x) => x !== f).sort((x, y) => x.mp / Math.max(1, x.mx.mp) - y.mp / Math.max(1, y.mx.mp))[0]; if (lo) tgt = lo; else v = 0; }   // v3.0: MPを 分ける 技は 仲間に
    } else if (mv.buff) {
      const neg = Object.values(mv.buff).some((x) => x < 0);
      let ally1 = null;
      if (mv.target === "ally") { let bv = -1; for (const x of friends) { const sc = Object.entries(mv.buff).reduce((a, [k, d]) => a + Math.max(0, Math.min(d, (multiUp(mv.buff) ? MULTI_CAP : BUF_MAX) - (x.buf[k] || 0))) * (x.mx[k] || 1), 0); if (sc > bv) { bv = sc; ally1 = x; } } }
      // v2.5.1: 弱体は「その 能力で いちばん 危ない 敵」へ（物力を 下げるなら 物力で なぐって くる 敵）
      const dk = Object.entries(mv.buff).filter(([, d]) => d < 0).map(([k]) => k);
      const offK = (x) => Math.max(x.mx.atk, x.mx.wpn, x.mx.mat, x.mx.brt, 1);
      const dWorst = neg && mv.target === "enemy" && live.length ? live.reduce((a, b) => { const sc = (x) => (outTh.get(x) + avgDmg * 0.3) * dk.reduce((m, k) => m * (["atk", "wpn", "mat", "brt"].includes(k) ? Math.pow(x.mx[k] / offK(x), 2) : 1), 1); return sc(b) > sc(a) ? b : a; }) : null;
      const tg = mv.target === "enemies" ? live : mv.target === "rand2" ? live.slice(0, 2) : mv.target === "enemy" ? [dWorst || worst || live[0]] : mv.target === "allies" ? friends : mv.target === "ally" ? [ally1 || f] : [f];
      let gain = 0;
      for (const x of tg) for (const [k, d] of Object.entries(mv.buff)) {
        if (d < 0 && x.side === f.side) continue;   // v2.9.12: 自分たちが 下がる ぶんは 得では ない
        const cur = x.buf[k] || 0, room = k === "hp" || k === "mp" ? (d > 0 && (k === "hp" ? x.hp < x.mx.hp * 0.7 : x.mp < x.mx.mp * 0.5) ? d : 0) : d > 0 ? Math.max(0, Math.min(d, (multiUp(mv.buff) ? MULTI_CAP : BUF_MAX) - cur)) : x.tr.nodebuff ? 0 : Math.max(0, Math.min(-d, BUF_MAX + cur));
        // 役に立つ 能力ほど 価値が 高い（物理の 子の 物力・速さ など）。段階が 高いほど 伸びしろは 小さく みる
        const use = k === "spd" || k === "def" || k === "mdf" ? 1 : (x.side === f.side ? (x.mx[k] >= Math.max(x.mx.atk, x.mx.wpn, x.mx.mat, x.mx.brt) * 0.8 ? 1.2 : 0.35) : 1);
        v += avgDmg * 0.28 * room * use * (Math.abs(cur) >= 3 ? 0.5 : 1); gain += room;
      }
      if (!gain) v = 0;   // 上がる（下がる）ものが 何も ない 技は 使わない
      v *= Math.max(tac === "backer" || tac === "analyze" || tac === "karame" ? 0.75 : 0.2, Math.min(Math.max(longK, tac === "backer" || tac === "analyze" || tac === "karame" ? 0.75 : 0), 1.3 - turn * 0.12)) * (neg ? W[4] : W[3]);   // 第63版: 補助の 作戦は 短い 戦いでも 強化・弱体を つかう
      if (!neg && doomed && mv.target !== "allies") v *= 0.3;
      if (mv.regen) v += avgDmg * 0.3; if (mv.hpcost) v -= f.hp < f.mx.hp * 0.4 ? avgDmg : 0;
      tgt = neg && mv.target === "enemy" && (dWorst || worst) ? dWorst || worst : tg[0];
      if (mv.hpcost && f.hp < f.mx.hp * 0.55) v = -1;
    } else if (mv.charge) { const tn = f.charge ? f.tens || 1 : 0; const nt = Math.min(4, tn + (mv.charge === 2 ? 2 : 1)); if (tn < 4) v = avgDmg * (TENS_K[nt] - TENS_K[tn]) * 0.55 * W[3] * (doomed ? 0.2 : 1) - (mv.hpcost && f.hp < f.mx.hp * 0.5 ? avgDmg : 0); }
    else if (mv.dispel) { let g = 0; const tg = mv.target === "enemies" ? live : [live.reduce((a, b) => (posBuf(b) > posBuf(a) ? b : a), live[0])]; for (const x of tg) g += posBuf(x); v = g * avgDmg * 0.32 * W[4]; tgt = tg[0]; }
    else if (mv.reraise) { const tg = (mv.target === "allies" ? friends : mv.target === "self" ? [f] : [...friends].sort((a, b) => b.mx.hp - a.mx.hp)).filter((x) => !x.reraise); if (tg.length) { v = avgDmg * (mv.target === "allies" ? 0.9 * tg.length : 1.3) * Math.min(1.3, 0.5 + longK) * W[1]; tgt = tg[0]; } }
    else if (mv.mist) { const theirs = live.reduce((a, x) => a + x.moves.filter((id) => isSpell(MOVES[id])).length + (x.reraise ? 3 : 0), 0), ours = friends.reduce((a, x) => a + x.moves.filter((id) => isSpell(MOVES[id])).length, 0); if (!live.some((x) => x.mistT > 0) && theirs > ours * 1.3 + 1) v = avgDmg * 0.25 * (theirs - ours) * W[4]; }
    else if (mv.norevive) { const tg = live.filter((x) => !(x.norevive > 0) && (x.reraise || x.tr.undying || x.tr.revive || x.doom)); if (tg.length) { v = avgDmg * (tg[0].reraise || tg[0].doom ? 1.6 : 0.8) * W[4]; tgt = tg[0]; } }
    else if (mv.cover) { const weak = friends.filter((x) => x !== f && x.hp < x.mx.hp * 0.45).length; if (weak && f.hp > f.mx.hp * 0.6 && !(f.cover > 0)) v = avgDmg * 0.7 * weak * W[6]; tgt = f; }
    else if (mv.trboost) { if ((f.trb || 0) < 2 && turn <= 4 && !doomed) { const g = Object.values(f.tr.dealt).reduce((a, x) => a + Math.max(0, x), 0) + Math.max(0, -Math.min(0, ...Object.values(f.tr.taken), 0)) + (f.tr.crit || 0) * 2 + (f.tr.regen || 0) * 4 + (f.tr.evade || 0) * 2 + Object.values(f.tr.stat || {}).reduce((a, x) => a + Math.max(0, x), 0); v = avgDmg * (0.3 + Math.min(1.6, g * 2.2)) * W[3]; } tgt = f; }
    else if (mv.resdown) { const tg = live.filter((x) => !(x.resdn > 0)); if (tg.length && friendsAll.some((x) => x.moves.some((id) => MOVES[id]?.el))) v = avgDmg * 0.3 * tg.length * W[4]; tgt = tg[0]; }
    else if (mv.allmp) { if (f.mp >= f.mx.mp * 0.4) v = f.mp * ALLMP_K * BAL.AOE * live.length * W[0] * (f.hp < f.mx.hp * 0.4 || doomed || f.doom ? 1.2 : turn <= 1 ? 0.35 : 0.6); }
    else if (mv.taunt) { if (f.hp > f.mx.hp * 0.6 && friends.length > 1 && !(f.taunt > 0)) v = avgDmg * 0.4 * W[6]; }
    else if (mv.guard) { if (f.hp < f.mx.hp * 0.3) v = avgDmg * 0.5 * W[6]; }
    else if (mv.pin) { if (metalFoe && !(metalFoe.noflee > 0)) v = avgDmg * 3 * (tac === "metal" || tac === "sente" ? 2 : 1); }
    if (v > 0) {
      const aoe = mv.target === "enemies" || mv.target === "all";
      if (tac === "aoe" && isAtk) v *= aoe && live.length >= 2 ? 1.6 : 0.8;
      if (tac === "focus" && isAtk) v *= mv.target === "enemy" ? 1.4 : 0.8;
      if (tac === "buffer" && mv.buff && !isAtk) v *= turn <= 2 ? 1.6 : 1;
      // v3.0 第63版: 新しい 作戦の 好み
      if (tac === "sente" && isAtk) { const t0 = tgt || live[0]; v *= 1.15 * (mv.inf || mv.debuff || mv.sealhit ? 1.35 : 1) * (t0 && mv.el && resMulMv(t0, mv, f) > 1 ? 1.35 : 1); }
      if (tac === "karame" && isAtk && !(mv.inf || mv.debuff || mv.sealhit)) v *= 0.7;
      if (tac === "counter" && mv.refl) v *= 1.6;
      if (tac === "backer" && (mv.catguard2 || mv.elguard2 || mv.catguard || mv.elguard)) v *= 1.6;
      if (tac === "backer" && isAtk) v *= 0.8;
      if (tac === "backer" && mv.buff && !isAtk && Object.values(mv.buff).some((x) => x > 0)) v *= turn <= 3 ? 1.8 : 1.2;
      // 第65版: 攻撃や 弱体と いっしょに 全体の 強化を かき消す 技（クリア後の 石板の 主）は、かき消す ぶんも 価値に 入れる
      if ((mv.dispel && mv.buff) || (mv.dispelhit && mv.target === "enemies")) { let g = 0; for (const x of live) g += posBuf(x); v += g * avgDmg * 0.32 * Math.max(f.isBoss ? 1.3 : 0.8, W[4] || 0); }
      let pen = mpPen(mv);
      if (tac === "mpsave") pen *= f.mp < f.mx.mp * 0.5 ? 3 : 1.8;
      let vv = v - pen;
      if (pref && pref[id] === 2) vv = vv * 1.6 + avgDmg * 0.4;   // ◎ 役に 立つ ときは どんどん
      add(vv, { actor: f, kind: "move", move: id, target: tgt });
    }
  }
  if (f.hp < f.mx.hp * 0.25 || tac === "guard" || fear) add(avgDmg * 0.5 * W[6] * (f.hp < f.mx.hp * 0.25 ? 1.5 : 0.6) + (fear ? avgDmg : 0), { actor: f, kind: "defend" });
  // 次の 攻撃で 倒れるが、防御すれば 耐えられる とき（仲間が 回復できるなら なお よし）
  else if (danger >= 1 && danger < 1.9 && !faster && friends.length > 1 && friends.some((x) => x !== f && x.moves.some((id) => MOVES[id]?.heal))) add(avgDmg * 0.9 * W[6], { actor: f, kind: "defend" });
  if (!fear && !opt.pre && !(pref && pref._atk === 0)) { const tn = f.charge ? f.tens || 1 : 0; if (tn < 2) add(avgDmg * (TENS_K[tn + 1] - TENS_K[tn]) * 0.6 * W[3] * (doomed ? 0.1 : 1) * (f.smart ? 1.3 : 0.9), { actor: f, kind: "tame" }); }   /* 第104版: ためる（安全な ときに 力を ためる）*/
  const noise = W[7] * (f.smart ? Math.max(0.02, 0.25 / Math.max(1, f.smart)) : f.side === "e" && !B.pvp ? 0.45 : 0.6);   /* 第104版: 野生も 少し かしこく */   // v3.0: かしこさ（エンマは 負けるたびに 上がる）
  let best = null, bv = -1e9;
  const usedNow = f.isBoss && f.usedT === turn ? f.usedS : null;   // v3.0: ボスは 同じ ターンに 同じ 技を くりかえしにくい（技を 使いわける）
  for (const [v, a] of opts) { const vv = v * (1 + (Math.random() * 2 - 1) * noise) * (usedNow && a.kind === "move" && usedNow.has(a.move) ? 0.45 : 1) * (f.isBoss && (f.smart || 0) >= 2.5 && a.kind === "move" && a.move === f.lastMv ? 0.6 : 1); if (vv > bv) { bv = vv; best = a; } }
  if (f.side === "e" && !B.pvp && !f.owner && f.m && f.m.sp === "enma" && f.hp > 0) { const k2 = SPECIES.enma.sig2; const cd = f.isBoss && f.kuniT !== undefined && (B.turn || 1) - f.kuniT < 3;   // v3.0: ボスの 国崩は 3ターンに 1回まで
    if (cd && best && best.move === k2) { const alt = opts.filter(([, x]) => x.move !== k2).sort((x, y) => y[0] - x[0])[0]; if (alt) best = alt[1]; }
    if (f.isBoss && best && best.move === k2 && !opt.pre) f.kuniT = B.turn || 1;
    if (k2 && !cd && f.moves.includes(k2) && costOf(f, MOVES[k2]) <= f.mp && !sealedFor(f, MOVES[k2]) && !(f.ail.fear > 0) && Math.random() < (f.isBoss ? 0.35 : 0.6)) { if (!opt.pre) f.kuniT = B.turn || 1; return { actor: f, kind: "move", move: k2 }; } }
  if (best && best.kind === "move" && MOVES[best.move]?.refl && !opt.pre) f.reflT = B.turn || 1;
  if (best && best.kind === "defend" && !opt.pre && !(f.bkT > 0)) f.defend = true;
  return best || { actor: f, kind: fear ? "defend" : "attack", target: pickTarget(foes) };
}
export const enemyDecide = aiDecide;

// ================= 状態異常 =================
// v2.5: 出血は 動くたびに 最大HPの 一定割合（ふつう 8%・上位の 技ほど 重い）。ボスは 半分。ターンも 長め
export const BLEED_BASE = 0.08;
export const bleedOf = (mv) => mv.bleedK || (mv.tier >= 4 ? 0.15 : mv.tier >= 3 ? 0.12 : mv.tier >= 2 ? 0.1 : BLEED_BASE);
export const ALLMP_K = 1.5;
// v2.5.1: 強化だけを かき消す（段階の プラス・纏い・反射・軽減・再誕・溜め・真価解放）
export function posBuf(t) { return Object.values(t.buf || {}).reduce((a, v) => a + Math.max(0, v), 0) + [t.elg2, t.reflEl, t.ailg].reduce((a, o) => a + Object.values(o || {}).filter((x) => x > 0).length, 0) + (t.critT > 0 ? 1 : 0) + (t.nosealT > 0 ? 1 : 0) + (t.tens > 0 ? 1 : 0) + (t.reraise ? 3 : 0) + (t.charge ? 2 : 0) + (t.trb ? 2 * t.trb : 0) + (t.ench && t.ench.t > 0 ? 1 : 0) + Object.values(t.refl || {}).filter((x) => x > 0).length + Object.values(t.catg2 || {}).filter((x) => x > 0).length; }
export function dispel(t, log) {
  if (t.hp <= 0) return false;
  if (t.tr.nodispel) { log.push(`§7${t.name}の 強化は かき消されない！`); return false; }
  if (!posBuf(t) && !Object.values(t.catg || {}).some((x) => x > 0) && !Object.values(t.elg || {}).some((x) => x > 0)) return false;
  for (const k of Object.keys(t.buf)) if (t.buf[k] > 0) t.buf[k] = 0;
  t.ench = null; t.refl = {}; t.reflEl = {}; t.elg = {}; t.elg2 = {}; t.catg = {}; t.catg2 = {}; t.critT = 0; t.reraise = 0; t.charge = false; t.tens = 0; t.ailg = {}; t.nosealT = 0;
  if (t.trb) unboostTr(t);
  log.push(`§b${t.name}の 強化が かき消された！`);
  return true;
}
// v2.5.1: 真価解放（自分の 良い 特性を 1.5倍に。2回まで）
const TRB_SCALAR = ["crit", "critdmg", "evade", "regen", "mpregen", "lifesteal", "counter", "pierce", "healboost", "bloodlust", "heavyhit", "halfmp_ch", "multi", "echo", "autodispel", "lastrev"];
export function boostTr(t, log) {
  if ((t.trb || 0) >= 2) { log.push(`§7${t.name}の 特性は もう 最大まで 高まっている。`); return false; }
  if (!t.trb) t.tr0 = { tr: { ...t.tr, dealt: { ...t.tr.dealt }, taken: { ...t.tr.taken }, stat: { ...t.tr.stat } }, mx: { ...t.mx } };
  const k = 1.5;
  for (const [a, v] of Object.entries(t.tr.dealt)) if (v > 0) t.tr.dealt[a] = v * k;
  for (const [a, v] of Object.entries(t.tr.taken)) if (v < 0) t.tr.taken[a] = Math.max(-0.9, v * k);
  for (const a of TRB_SCALAR) if (typeof t.tr[a] === "number" && t.tr[a] > 0) t.tr[a] = a === "evade" ? Math.min(0.5, t.tr[a] * k) : t.tr[a] * k;
  if (t.tr.pinch) t.tr.pinch = 1 + (t.tr.pinch - 1) * k;
  for (const [a, v] of Object.entries(t.tr.stat || {})) if (v > 0 && t.mx[a]) { const base0 = ((t.tr0 && t.tr0.mx && t.tr0.mx[a]) || t.mx[a]) / (1 + v); const nv = capStat(a, Math.floor(base0 * (1 + v * Math.pow(k, (t.trb || 0) + 1)))); /* v2.9.12: 2回目も 上がる・上限 9999 */ if (a === "hp") t.hp = Math.min(nv, t.hp + nv - t.mx[a]); t.mx[a] = nv; }
  t.trb = (t.trb || 0) + 1;
  log.push(`§6${t.name}の 特性の 力が 引き出された！ §7（良い 特性の 数値 ×1.5${t.trb > 1 ? "・2回目" : ""}）`);
  return true;
}
function unboostTr(t) { if (!t.tr0) { t.trb = 0; return; } const hpR = t.hp / Math.max(1, t.mx.hp); t.tr = t.tr0.tr; t.mx = t.tr0.mx; t.hp = Math.max(1, Math.min(t.mx.hp, Math.round(t.mx.hp * hpR))); t.tr0 = null; t.trb = 0; }
const AIL_TURNS = { poison: [3, 5], burn: [3, 4], bleed: [3, 5], para: [2, 3], freeze: [1, 2], sleep: [2, 3], slow: [3, 4], conf: [2, 3], charm: [2, 2], fear: [2, 3] };
const AIL_MSG = { poison: "毒に おかされた", burn: "火傷を おった", bleed: "出血した", para: "体が しびれた", freeze: "凍りついた", sleep: "眠ってしまった", slow: "動きが にぶった",
  conf: "混乱した", charm: "魅了された！ 敵の 味方に なってしまった", fear: "おびえて しまった" };
let AIL_SRC = null;   // v3.0: いま 動いて いる 子（状態異常ブレイク）
export function ailChance(t, a, ch, B) {
  if (t.tr.immune.has(a)) return 0;
  let r = t.ares[a] ?? 0;
  { const bk = AIL_SRC && AIL_SRC !== t && AIL_SRC.tr && AIL_SRC.tr.ailbrk; const n = bk ? (bk[a] || bk.all || 0) : 0; for (let i = 0; i < n; i++) r = { 2: 3, 3: 1, 1: 0, 0: -1, "-1": -1 }[r] ?? r; }
  let k = { "-1": 1.5, "0": 1, "1": 0.5, "3": 0.2, "2": 0 }[String(r)] ?? 1;
  if (t.isBoss && ["sleep", "freeze", "charm", "fear", "conf"].includes(a)) k *= 0.4;
  if (a === "para" && wxOf(B, t) === "storm") k *= 1.5;   // v2.9: 雷雨は 麻痺に なりやすい
  return Math.min(1, ch * k);
}
function inflict(t, a, ch, log, fx, B, quiet = false, bk = 0) {
  if (t.hp <= 0) return false;
  if (t.ailg && t.ailg[a] > 0) { if (!quiet) log.push(`§7${t.name}は ${AIL_NAME[a]}よけの 護りで 守られている！`); return false; }
  if (t.ail[a]) { if (!quiet) log.push(`${t.name}は すでに ${AIL_NAME[a]}だ。`); return false; }
  const c = ailChance(t, a, ch, B);
  if (c <= 0) { if (!quiet) log.push(`§7${t.name}には ${AIL_NAME[a]}が 効かない！`); return false; }
  if (Math.random() >= c) { if (!quiet) log.push(`${t.name}には 効かなかった！`); return false; }
  const [lo, hi] = AIL_TURNS[a];
  t.ail[a] = ri(lo, hi);
  if (a === "bleed") t.bleedK = Math.max(BLEED_BASE, bk || 0);
  if (a === "sleep") t.ail.sleep += 0;
  fx.hit.includes(t) || fx.hit.push(t);
  log.push(`${AIL_COL[a]}${t.name}は ${AIL_MSG[a]}！ §8（${AIL_KANA[a]}）`);
  return true;
}
// v3.0: 即死の 技（ボス・ハガネ・Gサイズ・冥府の守りには 効かない。ランクが 高いほど 効きにくい）
export function deathImmune(t) { return !!(t.isBoss || t.tr.metal || (t.m && (sizeOf(t.m) === "G" || t.m.sp === "enma" || t.m.sp === "musashi")) || (t.tr.immune && t.tr.immune.has("death"))); }
function deathTry(B, f, t, ch, log, fx) {
  if (!t || t.hp <= 0) return false;
  if (deathImmune(t) || cheatInv(B, t)) { log.push(`§7${t.name}には 即死の 力が 効かない！`); return false; }
  const rk = t.m && SPECIES[t.m.sp] ? SPECIES[t.m.sp].rank : "C";
  let k = rk === "X" ? 0.3 : rk === "SS" ? 0.5 : rk === "S" ? 0.75 : 1;
  if (f && f.tr && f.tr.ailbrk && (f.tr.ailbrk.death || f.tr.ailbrk.all)) k *= 1.5;
  if (Math.random() >= ch * k) { log.push(`${t.name}は 冥府の 手を ふりはらった！`); return false; }
  log.push(`§8§l${t.name}は 冥府へ 送られた！`);
  t.hp = 0; fx.hit.includes(t) || fx.hit.push(t); (fx.dmg = fx.dmg || []).push({ t, d: 0, crit: false, weak: false });
  t.nkUsed = true;   /* 第102版: 冥府送りは 踏みとどまれない */
  ko(t, B, log, fx, false, f);
  return true;
}
function cureAll(t) { for (const k of Object.keys(t.ail)) t.ail[k] = 0; }
// v2.5.1: 能力の 段階は −6〜+6（+n: (2+n)/2 倍 → +6で 4倍／−n: 2/(2+n) 倍 → −6で 0.25倍）
export const BUF_MAX = 6;
export const buffMul = (n) => (n >= 0 ? (2 + n) / 2 : 2 / (2 - n));   // v2.5.1: （+1=1.5倍・+2=2倍・+6=4倍／−1=0.67倍・−6=0.25倍）
const BUFX = { eva: "回避", acc: "命中" };
// v2.9.12: 3つ 以上の 能力を まとめて 上げる 技は 重ねても +2段（2倍）まで（序盤から 全能力 4倍などに ならない）
const MULTI_CAP = 2;
const multiUp = (buff) => Object.values(buff || {}).filter((v) => v > 0).length >= 3;
function buffAll(t, buff, log) {   // 3つ以上 まとめて 上げる 技は +2段まで（上がらない 能力は 1行に まとめる）
  const multi = multiUp(buff), capped = [];
  // v2.9.12: まとめて 上げる 技で もう 何も 上がらない ときは 下がる ほうも 起きない（不発）
  if (multi && Object.entries(buff).every(([k, v]) => v <= 0 || (t.buf[k] || 0) >= MULTI_CAP)) { log.push(`§7${t.name}は もう この 技では 強く ならない（+${MULTI_CAP}まで）`); return; }
  for (const [k, v0] of Object.entries(buff)) {
    let v = v0;
    if (multi && v > 0) { const room = Math.max(0, MULTI_CAP - (t.buf[k] || 0)); if (!room) { capped.push(ST_NAME[k] || "能力"); continue; } v = Math.min(v, room); }
    buffOne(t, k, v, log);
  }
  if (capped.length) log.push(`§7${t.name}の ${capped.join("・")}は この 技では もう 上がらない（+${MULTI_CAP}まで）`);
}
function buffOne(t, k, v, log) {
  if (k === "hp" || k === "mp") {   // v2.9.12: HP・MPの「強化」は 段階では なく その場で 回復（前は 何も 起きなかった）
    if (v <= 0 || t.hp <= 0) return;
    const mx = t.mx[k] || 0, cur = k === "hp" ? t.hp : t.mp, add = Math.min(mx - cur, Math.max(1, Math.round(mx * (k === "hp" ? 0.12 : 0.1) * v)));
    if (add <= 0) { log.push(`${t.name}の ${k === "hp" ? "HP" : "MP"}は もう 満タンだ。`); return; }
    if (k === "hp") t.hp += add; else t.mp += add;
    log.push(`§a${t.name}の ${k === "hp" ? "HP" : "MP"}が ${add} 回復した！`); return;
  }
  if (v < 0 && (t.tr.nodebuff || (t.tr.nodebK && t.tr.nodebK[k]))) { log.push(`${t.name}の ${ST_NAME[k] || BUFX[k] || "能力"}は 下がらない！`); return; }
  const before = t.buf[k] || 0;
  t.buf[k] = Math.max(-BUF_MAX, Math.min(BUF_MAX, before + v));
  const dd = Math.abs(t.buf[k] - before);
  if (t.buf[k] === before) log.push(`${t.name}の ${ST_NAME[k] || BUFX[k] || "回避"}は もう 変わらない。`);
  else log.push(`${v > 0 ? "§a" : "§c"}${t.name}の ${ST_NAME[k] || BUFX[k] || "回避"}が ${dd >= 3 ? "ぐぐーんと " : dd === 2 ? "ぐーんと " : ""}${v > 0 ? "上がった" : "下がった"}！ §f${v > 0 ? "▲".repeat(dd) : "▼".repeat(dd)} §7（${t.buf[k] > 0 ? "+" : ""}${t.buf[k]}段階 ×${k === "eva" ? "" : buffMul(t.buf[k]).toFixed(2).replace(/0$/, "")}）`);
}
function sealOne(t, c, n, ch, log, fx) {
  if (t.hp <= 0) return;
  if (t.tr.nosealed && !(AIL_SRC && AIL_SRC.tr && AIL_SRC.tr.sealbrk)) { log.push(`§7${t.name}は 封印を うけつけない！`); return; }
  if (Math.random() >= ch) { log.push(`${t.name}には 効かなかった！`); return; }
  t.seal[c] = Math.max(t.seal[c] || 0, n);
  fx.hit.includes(t) || fx.hit.push(t);
  log.push(`§7${t.name}の ${CAT_COL[c]}${CATS[c]}§7が 封じられた！（${n}ターン）`);
}

// ================= 系統の王 =================
function famKing(B, log) {
  for (const side of [B.allies, B.enemies]) {
    const done = new Set();
    for (const k of side) {
      if (k.hp <= 0 || !k.tr.famking) continue;
      const fam = SPECIES[k.m.sp].fam;
      if (done.has(fam)) continue; done.add(fam);
      const live = side.filter((f) => f.hp > 0);
      const same = live.filter((f) => SPECIES[f.m.sp].fam === fam);
      const n = same.length;
      const up = Math.min(0.4, 0.08 * n);
      for (const f of live) {
        for (const s of BUF_KEYS) f.mx[s] = Math.min(STAT_MAX, Math.floor(f.mx[s] * (1 + up)));
        const hp0 = f.mx.hp; f.mx.hp = Math.max(hp0, Math.floor(f.mx.hp * (1 + up)));   /* 第68版: もとが 上限を こえる ボスの HPを 下げない */ f.hp = Math.min(f.mx.hp, f.hp + (f.mx.hp - hp0));
      }
      for (const f of same) {
        for (const c of Object.keys(CATS)) f.tr.taken[c] = (f.tr.taken[c] || 0) - Math.min(0.25, 0.05 * n);
        f.tr.regen = (f.tr.regen || 0) + Math.min(0.08, 0.02 * n);
        if (n >= 3) f.tr.halfmp = true;
      }
      const full = n >= 2 && n === live.length;
      if (full) k.tr.extra = Math.max(k.tr.extra || 0, 1);
      log.push(`§6§l【系統の王】§r§6 ${k.name}の もとに ${FAMILIES_NAME(fam)}が ${n}体！ 味方全員の 能力 +${Math.round(up * 100)}%${n >= 3 ? "・MP消費 半分" : ""}${full ? "・王の 行動回数 +1！" : ""}`);
    }
  }
}
const FAMILIES_NAME = (fam) => FAMILIES.find((f) => f.id === fam)?.name || "仲間";
// v2.5.1: マスターたちは 特性と 技を 組みあわせて くる（執念＋再誕・霧散の波動・千刃の舞 など）
export function applyBuilds(list, lvl = 1) {
  const L = list.filter((f) => f.hp > 0);
  const add = (f, id) => { if (MOVES[id] && !f.moves.includes(id)) f.moves.push(id); };
  for (const f of L) {
    const role = f.aff.gc || SPECIES[f.m.sp]?.role;   // v2.9.12: 得意（Lv40の 能力）を 先に
    if (f.isBoss || f.m.sp === "enma") continue;   // ボスは 組みあわせ なし（強くなりすぎるので）
    if (f.tr.undying) { const sup = L.find((x) => x !== f && !x.isBoss && x.mx.mat + x.mx.mdf >= x.mx.atk + x.mx.wpn) || f; add(sup, sup === f ? "rz_3" : "rz_1"); }
    if (lvl >= 1 && Math.random() < 0.35) { const km = { weapon: "kb_1", phys: "kb_3", magic: "mz_1", breath: "kb_4" }; if (role !== "special") add(f, km[role] || "kb_1"); }
    if (lvl >= 1 && Math.random() < 0.2) add(f, "tb_1");
    if (lvl >= 2 && Math.random() < 0.25) add(f, "ch_1");
    if (lvl >= 1 && f.mx.def > Math.max(f.mx.atk, f.mx.wpn, f.mx.mat, f.mx.brt) && L.length >= 2 && Math.random() < 0.4) add(f, "cv_1");
  }
  if (L.length >= 2 && lvl >= 1) add(L[L.length - 1], Math.random() < 0.5 ? "hd_1" : "hd_3");
  const sup = L.filter((x) => !x.isBoss && x.m.sp !== "enma");
  if (lvl >= 2 && sup.length && !L.some((x) => x.moves.includes("rz_1"))) add(sup.reduce((a, b) => (a.mx.mdf + a.mx.mat >= b.mx.mdf + b.mx.mat ? a : b)), "rz_1");
}
export function battleStart(B, log) {
  B.reverse = B.reverse || 0;
  try { famKing(B, log); } catch {}
  // v2.9: 天候（はじめの 天候 → 特性【〇〇呼び】。走力の 高い 子の 天候が 勝つ）
  if (B.wbase && !B.weather) { setWeather(B, B.wbase, B.wbaseT || 999, log, null, true); if (B.wonce) B.wbase = null; }
  for (const f of [...B.allies, ...B.enemies].filter((x) => x.hp > 0 && x.tr.wstart).sort((a, b) => stat(a, "spd") - stat(b, "spd"))) {
    log.push(`§6${f.name}の 特性【${WEATHER[f.tr.wstart]?.[0] || ""}呼び】！`); setWeather(B, f.tr.wstart, 5 + (f.tr.wlong ? 3 : 0), log, f);
  }
  B.st0 = new WeakSet();
  for (const f of [...B.allies, ...B.enemies]) fighterStart(B, f, log);
}
// v3.0: 戦いの はじめの 効果（途中参加・入れかえで 出た 子にも）
export function fighterStart(B, f, log) {
  const fx = { hit: [], healed: [], ko: [] };
  {
    if (!B.st0) B.st0 = new WeakSet();
    { const k0 = f.m || f; if (B.st0.has(k0)) return; B.st0.add(k0); }   /* 第69版: 裏との 入れかえで 2度 かからない（モンスターごと） */   // 倒れて いた 子も しるしを つける（生きかえった あとに また かからない）
    if (f.hp <= 0) return;
    if (f.tr.startchain) { const fo = (f.side === "a" ? B.enemies : B.allies).filter((x) => x.hp > 0); for (const x of fo) { x.norevive = Math.max(x.norevive || 0, f.tr.startchain); if (x.reraise) x.reraise = 0; } if (fo.length) log.push(`§8${f.name}の 特性【鎮魂の気】！ 相手は ${f.tr.startchain}ターン よみがえれない`); }   // v3.0
    if (f.tr.startall) { for (const x of ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) f.buf[x] = Math.min(BUF_MAX, (f.buf[x] || 0) + 1); log.push(`§a${f.name}の 特性【いきなり全能力】！`); }
    for (const [c, n] of Object.entries(f.tr.startrefl || {})) { f.refl[c] = n >= 99 ? 99 : c === "special" ? 1 : 3;   /* v3.0 第63版: 特質の いきなり技返しは 説明どおり 1ターン */   /* v3.0: 99は「いつも」（かき消し・霧で 消える） */ log.push(`§b${f.name}の 特性！ ${CATS[c]}を 跳ね返す 構え`); }
    for (const c of Object.keys(f.tr.startguard || {})) { f.catg[c] = 3; log.push(`§b${f.name}の 特性！ ${CATS[c]}を 軽減する 構え`); }
    if (f.tr.startregen) f.regen = Math.max(f.regen || 0, 4);
    if (f.tr.startcharge) { f.charge = true; f.tens = Math.max(f.tens || 0, 1); log.push(`§6${f.name}の 特性【いきなり溜め】！`); }
    if (f.tr.startraise && !f.reraise) { f.reraise = 0.5; log.push(`§d${f.name}の 特性【いきなり再誕】！ 再誕の誓いに つつまれた`); }
    if (f.tr.tmAura) log.push(`§5§l${f.name}の 闘魔の オーラ！`);   // v3.0: 闘魔覚醒
    const sb = Object.entries(f.tr.startbuf || {}).filter(([, v]) => v);
    if (sb.length) { for (const [k, v] of sb) f.buf[k] = Math.max(-BUF_MAX, Math.min(BUF_MAX, (f.buf[k] || 0) + v)); log.push(`§a${f.name}の 特性！ ${sb.map(([k, v]) => `${ST_NAME[k]}+${v}`).join("・")}段階で 戦いを はじめる`); }
    if (f.tr.revstart) { B.reverse = Math.max(B.reverse, f.tr.revstart); log.push(`§d§l${f.name}の 特性【逆転の場】！ ${f.tr.revstart}ターンの あいだ 遅い 順に 動く！`); }
    for (const [c, n] of f.tr.sealstart) {
      log.push(`§7${f.name}の 特性！ 相手の ${CATS[c]}を 封じる！`);
      for (const t of alive(foesOf(B, f))) sealOne(t, c, n, 0.8, log, fx);
    }
  }
}

// ---- 行動順: ふつうは 走力の 高い順。逆転の場では 低い順。【後の先】は いつも 低いほど 先 ----
export function orderKey(a, B) {
  const f = a.actor;
  // v2.9: 先制度（-2〜+4）。高い 順に 動き、同じ 先制度の なかでは 走力の 高い 順（反射は +4 で 最優先・身を守る は +3）
  const pri = priOf(a);
  const bow = f.tr.first_ch && Math.random() < f.tr.first_ch && pri < 3 ? 1 : 0;
  const s = stat(f, "spd") * rnd(0.85, 1.15);
  const rev = (B && B.reverse > 0) !== !!(f.tr.slowfirst || f.late > 0);
  return (Math.min(4, pri + bow) + 5) * 1e6 + (rev ? 5e5 - s : s);
}
export function priOf(a) {
  const f = a.actor;
  if (a.kind === "defend") return 3;
  const mv = a.kind === "move" ? MOVES[a.move] : a.kind === "attack" ? f.atk : null;
  let p = (mv && mv.pri) || 0;
  if (mv && mv.guard) p = Math.max(p, 3);
  if (f.tr.first && p < 3) p = p + 1;   // 特性【先制】: 先制度 +1
  if (f.tr.topPri) p = Math.max(p, 3.5);   // v3.0: 最優先（魔神の 姿）
  return p;
}
export function actionOrder(acts, B) {
  // 第66版: 複数回 行動は 交代制。全員の 1回目 → 全員の 2回目 …の 順に 動く（同じ 子が 続けて 動かない）
  const cnt = new Map(), layer = new Map();
  for (const a of acts) { const k = (cnt.get(a.actor) || 0) + 1; cnt.set(a.actor, k); layer.set(a, k); }
  const out = acts.map((a) => [orderKey(a, B), a]).sort((x, y) => (layer.get(x[1]) - layer.get(y[1])) || (y[0] - x[0])).map((x) => x[1]);
  // v3.0: 同じ 子の「もう一度 動ける」は、かならず 1回目の あとに
  const pos = new Map();
  out.forEach((a, i) => { const L = pos.get(a.actor) || []; L.push(i); pos.set(a.actor, L); });
  for (const [, L] of pos) { if (L.length < 2) continue; const xs = L.map((i) => out[i]); const sorted = [...xs.filter((a) => !a.extra), ...xs.filter((a) => a.extra)]; L.forEach((i, k) => { out[i] = sorted[k]; }); }
  return out;
}
// v2.1: 行動回数は 特性（2回行動・2〜3回行動・3〜4回行動）で きまる
export function rollActs(f) {
  const [lo, hi] = f.tr.acts || [1, 1];
  let n = lo + (hi > lo && Math.random() < 0.5 ? 1 : 0);
  if (f.tr.double) n = Math.max(n, 2);
  if (f.tr.extra && Math.random() < f.tr.extra) n++;
  return Math.min(5, n);
}
export function expandActions(acts, B) {
  const out = [], seen = new Map();
  const firsts = [];
  for (const a of acts) {
    const f = a.actor;
    if (f.turnActs === undefined) f.turnActs = rollActs(f);
    const k = (seen.get(f) || 0) + 1;
    if (k > f.turnActs && a.kind !== "defend") continue;
    seen.set(f, k); out.push(a);
    if (k === 1) firsts.push(a);
  }
  for (const a of firsts) {
    const f = a.actor;
    if (a.kind === "defend" && !f.isBoss) continue;   /* 第67版: ボスは 身を 守っても 残りの 行動を する */
    for (let i = seen.get(f); i < f.turnActs; i++) { const b = aiDecide(f, B, { lite: !f.isBoss, pre: true }); b.extra = true; b.aiX = true; out.push(b); }   // 仮決め（動く 直前に 決めなおす）
  }
  for (const a of acts) a.actor.turnActs = undefined;
  // v2.9.12: 強すぎる 技（ハンシャ など）を 使う ターンは 行動が 1回 へる。マネマネは その ターン 1回だけ
  const byF = new Map(); for (const a of out) { const L = byF.get(a.actor) || []; L.push(a); byF.set(a.actor, L); }
  const drop = new Set();
  for (const [f, L] of byF) {
    if (L.length < 2 || f.isBoss) continue;   // v3.0: ボスは 強い 技でも 行動が へらない
    const mvOf = (a) => (a.kind === "move" ? MOVES[a.move] : null);
    const solo = L.find((a) => mvOf(a)?.solo);
    let keep;
    if (solo) keep = 1;
    else { const hv = L.filter((a) => mvOf(a)?.heavy).length; keep = Math.max(1, L.length - hv); }
    if (keep >= L.length) continue;
    const pri = (a) => (mvOf(a)?.solo ? 0 : mvOf(a)?.heavy ? 1 : 2);
    const order = [...L].sort((x, y) => pri(x) - pri(y) || L.indexOf(x) - L.indexOf(y));
    for (const a of order.slice(keep)) { drop.add(a); if (a.kind === "defend") f.defend = false; }
    if (!L.every((a) => a.ai) && (f.owner || f.side === "a")) (B.trimNote = B.trimNote || []).push(`§7${f.name}は ${solo ? "マネマネの 構えで この ターンは 1回だけ 動く" : "強い 技を 使うので 行動が へった"}`);
  }
  return drop.size ? out.filter((a) => !drop.has(a)) : out;
}

export const masteryNeed = (id) => 12 * (((MOVES[id] && MOVES[id].tier) || 0) + 1);
function mastery(B, f, a, log) {
  if (a.kind !== "move" || f.side !== "a" || B.pvp || !f.m.id) return;
  const mv = MOVES[a.move];
  if (mv && f.m) {
    // v2.6: 技の極め
    const mm = f.m; mm.mk = mm.mk || {};
    const n0 = mm.mk[a.move] || 0;
    if (n0 < MK_NEED) { mm.mk[a.move] = n0 + 1; if (n0 + 1 === MK_NEED) log.push(`§6§l${f.name}は ${mv.name}を 極めた！ §r§6（威力 +10%・消費MP -20%）`); }
  }
  if (!mv || !mv.next || !MOVES[mv.next]) return;
  const m = f.m;
  m.mu = m.mu || {};
  m.mu[a.move] = (m.mu[a.move] || 0) + 1;
  if (m.mu[a.move] >= masteryNeed(a.move) && !f.moves.includes(mv.next)) {
    m.lm = m.lm || [];
    if (!m.lm.includes(mv.next)) m.lm.push(mv.next);
    if (!(f.noMagic && MOVES[mv.next].cat === "magic")) { if (f.moves.length < MSET_MAX) f.moves.push(mv.next); else if (f.moves.indexOf(a.move) >= 0) f.moves[f.moves.indexOf(a.move)] = mv.next; }   // v3.0: 魔法禁止の 戦いでは 増やさない（第63版: 6つ なら 入れかえ）
    if (Array.isArray(m.mset)) { const own = getMoves(m); m.mset = m.mset.filter((id) => own.includes(id) || id === mv.next); }
    if (Array.isArray(m.mset) && !m.mset.includes(mv.next) && m.mset.length < MSET_MAX) m.mset.push(mv.next);   // v3.0: 戦いで 使う 技に 空きが あれば 入れる
    log.push(`§d§l${f.name}の ${mv.name}が ${MOVES[mv.next].name}に 進化した！`);
  }
}
const NOMIMIC = (mv) => !mv || mv.recoil || mv.selfko || mv.charge || mv.mimic || mv.allmp || mv.rest || mv.hpcost || mv.god || mv.sig || mv.boss || mv.absolute || (mv.tier || 0) >= 4;
let ACT_SEQ = 0;   // v3.0: 行動ごとの 番号（エンマは 1回の 行動で 受ける ダメージに 上限）
export function runAction(B, a, log) {
  ACT_SEQ++;
  const fx0 = runAction0(B, a, log);
  // v2.9.12: マネマネの 構えの 子が 受けた 攻撃を 覚える（一部の 技は まねできない）
  try {
    if (fx0 && fx0.dmg && !a.mimicRet && fx0.mid) {
      const mv = fx0.mid === "basic" ? a.actor.atk : MOVES[fx0.mid];
      const seen = new Set();   // v2.9.12: 1回の 行動で 1体に つき 1つだけ（連続攻撃でも ふえない）
      if (!NOMIMIC(mv)) for (const x of fx0.dmg) { const t = x.t; if (t && !seen.has(t) && seen.add(t) && t.mimicOn && t.side !== a.actor.side && t.hp > 0 && t !== a.actor) { t.mimicHits.push({ mid: fx0.mid, from: a.actor }); } }
    }
  } catch {}
  if (fx0 && fx0.anim && fx0.anim !== "guard") try { mastery(B, a.actor, a, log); } catch {}
  return fx0;
}
function ko(t, B, log, fx, final = false, killer = null, absolute = false) {
  // v2.5.4: 引導（とどめ）・冥府の鎖 … 執念・再誕・復活を ゆるさない（v2.5.5: 国崩も）
  const deny = absolute || (killer && killer.tr && killer.tr.finisher) || t.norevive > 0;
  if (deny && (t.doom || t.reraise || t.tr.undying || t.tr.revive)) { if (t.doom || t.reraise || (t.tr.undying && !t.undyingUsed)) log.push(`§8${t.name}は 冥府に 引き込まれた…… よみがえれない！`); t.doom = false; t.reraise = 0; final = true; t.revived = true; }
  // v2.5.1: 死線の執念（ラウンドの 終わりまで 倒れない）
  if (!final && (t.doom || (t.tr.undying && !t.undyingUsed))) {
    if (!t.doom) { t.doom = true; t.undyingUsed = true; log.push(`§4${t.name}の 特性【死線の執念】！ ラウンドの 終わりまで 倒れない！`); }
    t.hp = Math.max(1, t.hp); return;
  }
  t.doom = false;
  if (!final && !deny && t.nkEndure && !t.nkUsed && Math.random() < t.nkEndure) { t.nkUsed = true; t.hp = 1; log.push(`§d${t.name}は 主人の ために 踏みとどまった！（なつき度）`); return; }   /* 第102版 */
  if (t.tr.revive && !t.revived) {
    t.revived = true;
    t.hp = Math.max(1, Math.floor(t.mx.hp * t.tr.revive));
    log.push(`§a${t.name}は 不思議な 力で 生き返った！`);
    fx.healed.push(t);
    return;
  }
  if (t.reraise) {
    t.hp = Math.max(1, Math.floor(t.mx.hp * t.reraise)); t.reraise = 0; t.undyingUsed = false; cureAll(t);
    log.push(`§d§l${t.name}に かけられた 再誕の誓いが 発動！ よみがえった！`);
    fx.healed.push(t); return;
  }
  cureAll(t); t.seal = {}; t.refl = {}; t.regen = 0; t.charge = false; t.tens = 0; t.taunt = 0;
  // v2.9.12: 倒れたら 能力の 段階・纏い・守りも リセット（生きかえっても 強化は のこらない）
  t.buf = Object.fromEntries([...BUF_KEYS, "eva", "acc"].map((k) => [k, 0])); t.ench = null; t.critT = 0; t.late = 0; t.mistT = 0; for (const k of ["elg", "elg2", "catg", "catg2", "ailg"]) if (t[k]) t[k] = {};
  if (t.trb) unboostTr(t), (t.hp = 0);
  fx.ko.includes(t) || fx.ko.push(t);
  if (t.tr.lastrev && B) {
    const foes = alive(foesOf(B, t));
    if (foes.length) { log.push(`§5${t.name}の 特性【最後の報い】！`); for (const x of foes) { const d = Math.max(1, Math.floor(Math.min(STAT_MAX, t.mx.hp) * 0.3 * t.tr.lastrev * (x.isBoss ? 0.5 : 1)));   /* 第100版: HP 9999 ぶんまで */ if (cheatInv(B, x)) continue; x.hp = Math.max(0, x.hp - d); log.push(`${x.name}に ${d}の ダメージ！`); (fx.dmg = fx.dmg || []).push({ t: x, d, crit: false, weak: false }); if (x.hp === 0) ko(x, B, log, fx); } }
  }
  log.push(t.side === "e" && !B.pvp ? `§6${t.name}を 倒した！` : `§c${t.name}は 力つきた…`);
  if (killer && killer.hp > 0 && killer.side !== t.side) {
    for (const [k, v] of Object.entries(killer.tr.killbuf || {})) if (v) { if (k === "all") { for (const x of ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) killer.buf[x] = Math.min(BUF_MAX, (killer.buf[x] || 0) + 1); log.push(`§a${killer.name}の 特性！ 全能力が 上がった！`); } else buffOne(killer, k, v, log); }
    if (killer.tr.killheal) { const h = Math.min(killer.mx.hp - killer.hp, Math.floor(Math.min(STAT_MAX, killer.mx.hp) * killer.tr.killheal)); if (h > 0) { killer.hp += h; log.push(`§a${killer.name}は 魂を 喰らって HPが ${h} 回復した。`); } }
  }
  for (const g of alive(friendsOf(B, t))) if (g.tr.allyheal) { for (const x of alive(friendsOf(B, t))) { const h = Math.min(x.mx.hp - x.hp, Math.floor(Math.min(STAT_MAX, x.mx.hp) * g.tr.allyheal)); if (h > 0) x.hp += h; } log.push(`§a${g.name}の 特性【弔いの祈り】！ 味方の HPが 回復した`); break; }
  for (const g of alive(friendsOf(B, t))) if (g.tr.grudge) { g.buf.atk = Math.max(g.buf.atk, Math.min(2, g.buf.atk + 1)); g.buf.wpn = Math.max(g.buf.wpn, Math.min(2, g.buf.wpn + 1)); log.push(`§c${g.name}は 怒りに もえている！`); }
}
// ダメージを 与える（d は 計算済み）
function applyDamage(B, f, t, d, mv, log, fx, opt = {}) {
  if (mv.el && resMulMv(t, mv, f) < 0) {   // 吸収（ブレイクで 破れる）
    const h = Math.min(t.mx.hp - t.hp, Math.max(1, Math.floor(d * 0.5)));
    t.hp += h; fx.healed.push(t); (fx.heal = fx.heal || []).push({ t, d: h });
    log.push(h > 0 ? `§b${t.name}は ${EL_NAME[mv.el]}を 吸収して HPが ${h} 回復した！` : `§b${t.name}は ${EL_NAME[mv.el]}を 吸収した！`);
    return 0;
  }
  d = metalCap(f, t, d, mv, opt.crit);
  // v2.9.2: ダメージの 上限（S・M・L は 999 まで。G は なし。霧・特性で はずせる）
  let capped = false;
  { const cb = f || opt.capBy; const CAPX = DMG_CAP * (opt.crit ? 1.5 : 1); if (cb && d > CAPX && capOn(cb, mv) && (cb.capT > 0 || !enmaFree(cb, t))) {   /* 封限の 霧は エンマにも 効く */ d = CAPX; capped = true; } }   // v3.0 第63版: 会心は 上限 1.5倍
  // v2.2: 当たれば 最低 1（小数は 確率で 切り上げ）
  d = d > 0 ? Math.max(1, Math.floor(Math.min(9999, d) + Math.random())) : 0;
  if (mv.absolute && f && f.isBoss && f.actCap && !enmaFree(f, t)) d = Math.min(d, 3000, f.outPct ? Math.max(500, Math.floor(t.mx.hp * 0.4)) : 3000);   // v3.0: ボスの 国崩は 1体 3000・最大HPの 4割まで
  if (f && f.outCap && t !== f && d > 0 && !mv.absolute && !enmaFree(f, t)) { if (t.ocSeq !== ACT_SEQ) { t.ocSeq = ACT_SEQ; t.ocUsed = 0; } const oc = f.outPct ? Math.min(f.outCap, Math.max(f.outFloor ?? 250, Math.floor(t.mx.hp * f.outPct))) : f.outCap; d = Math.max(0, Math.min(d, oc - t.ocUsed)); t.ocUsed += d; if (d === 0) return 0; }   // v3.0: エンマの 1回の 行動で 1体に 与える ダメージの 上限（連続技で 一気に 倒さない）   // v3.0: ボスの エンマの 国崩は 1体 3000 まで（守りは 無視）
  if (t.actCap && d > 0) { if (t.capSeq !== ACT_SEQ) { t.capSeq = ACT_SEQ; t.capUsed = 0; } d = Math.max(0, Math.min(d, t.actCap - t.capUsed)); t.capUsed += d; if (d === 0) { if (!t.capSaid || t.capSaid !== ACT_SEQ) { t.capSaid = ACT_SEQ; log.push(`§4${t.name}の 魔神の 守り！ これ いじょう ダメージを うけない`); } return 0; } }
  const cht = cheatHit(B, f || opt.capBy, t); if (cht) { d = CHEAT_DMG; capped = false; }   /* 第76版: チートブックの 一撃（踏ん張り・上限・不倒の誓いも 無視。神の 再臨だけは のこる） */
  if (mv.absolute || cht) { /* 国崩: 踏ん張り・上限も 無視 */ } else if (t.tr.sturdy && !t.sturdyUsed && t.hp === t.mx.hp && d >= t.hp) { d = t.hp - 1; t.sturdyUsed = true; log.push(`§e${t.name}は 踏ん張った！`); }
  if (!mv.absolute && !cht && t.tr.dmgcap && !t.tr.metal && d > t.mx.hp * t.tr.dmgcap * (opt.crit ? 1.5 : 1)) { d = Math.max(1, Math.floor(t.mx.hp * t.tr.dmgcap * (opt.crit ? 1.5 : 1)));   /* v3.0: 会心でも 上限の 特性は 1.5倍まで */ log.push(`§7${t.name}の 特性【${t.tr.dmgcap <= 0.3 ? "不壊の体" : "鋼の意志"}】！ ダメージを おさえた`); }
  if (!mv.absolute && !cht && t.tr.laststand && !t.lsUsed && d >= t.hp && t.hp > 1 && !(t.norevive > 0)) { d = t.hp - 1; t.lsUsed = true; log.push(`§e${t.name}の 特性【不倒の誓い】！ ふみとどまった！`); }
  if (!mv.absolute && t.tr.deityRev && (t.revN || 0) < t.tr.deityRev && d >= t.hp && t.hp > 0) d = Math.max(0, t.hp - 1);
  if (cheatInv(B, t)) d = 0;   /* 第76版: チートブックの 無敵（味方は ダメージを 受けない） */   /* 第68版: 神の 再臨の 前には 倒れない */
  const hp0 = t.hp; t.hp = Math.max(0, t.hp - d);
  if (t.hp > 0 && !t.halfUsed && t.tr.halfbuf && Object.keys(t.tr.halfbuf).length && t.hp <= t.mx.hp * 0.5) { t.halfUsed = true; log.push(`§6${t.name}の 固有特性！ 追いつめられて 力が わいた！`); for (const [k, v] of Object.entries(t.tr.halfbuf)) buffOne(t, k, v, log); }   // v3.0: HPが 半分 以下に なった とき 1回
  if (f && f.side === "a" && !B.cheat && d > (B.recDmg || 0)) { B.recDmg = d; B.recBy = f.name; }   // v2.6: 記録帳
  log.push(d > 0 ? `${t.name}に ${d}の ダメージ！${capped ? " §8［上限］" : ""}` : `${t.name}には 効かなかった！`);
  (fx.dmg = fx.dmg || []).push({ t, d, r: cht ? Math.min(d, hp0) : d, crit: !!opt.crit, weak: !!(mv.el && resMul(t, mv.el) > 1), cap: capped });
  if (!fx.hit.includes(t)) fx.hit.push(t);
  if (t.hp === 0) ko(t, B, log, fx, false, f, !!mv.absolute);
  else {
    if (t.ail.sleep && d > 0) { t.ail.sleep = 0; log.push(`${t.name}は 目を さました！`); }
    if (t.ail.freeze && mv.el === "fire") { t.ail.freeze = 0; log.push(`${t.name}の 氷が とけた！`); }
    if (t.ail.conf && d > 0 && Math.random() < 0.25) { t.ail.conf = 0; log.push(`${t.name}は 我に かえった！`); }
    if (t.tr.rage && d > 0 && t.buf.atk < 2) { t.buf.atk++; log.push(`§c${t.name}の 物力が 上がった！`); }
  }
  if (f && f.hp > 0 && f.tr.lifesteal && d > 0) { const h = Math.min(f.mx.hp - f.hp, Math.ceil(d * f.tr.lifesteal)); if (h > 0) { f.hp += h; log.push(`${f.name}の HPが ${h} 回復した。`); } }
  return cht ? Math.min(d, hp0) : d;   /* 一撃の ときは トゲ・反動・返しを 実際の 減りで 計る */
}
export const DMG_CAP = 999, HIT_DECAY = 0.88;
/* 第76版: チートブック（対戦では 効かない） */
export const CHEAT_DMG = 9999999;
const cheatOwn = (B, x) => !x.owner || !B.cheatPid || x.owner === B.cheatPid;   /* 協力戦: チートを 使った 人の 子だけ */
export function cheatInv(B, t) { return !!(B && B.cheat && B.cheat.inv && !B.pvp && t && t.side === "a" && cheatOwn(B, t)); }
export function cheatHit(B, f, t) { return !!(B && B.cheat && B.cheat.hit && !B.pvp && f && f.side === "a" && cheatOwn(B, f) && t && t.side !== "a"); }
/* 第72版: ボスの エンマは 相手の 最大HPが 9000 以上なら ダメージの 上限なし（999・1回の 行動の 上限・国崩の 上限） */
export const ENMA_FREE_HP = 9000;
export function enmaFree(f, t) { return !!(f && f.isBoss && f.enmaN !== undefined && t && t !== f && t.side !== f.side && t.mx && (t.mx.hp || 0) >= ENMA_FREE_HP); }   /* 反射・混乱で 自分に 当たる ときは ふつう */
export function capOn(f, mv) {
  if (!f || !f.m || mv.absolute) return false;
  if (f.capT > 0) return true;                                   // 封限の 霧（Gでも）
  if (sizeOf(f.m) === "G" || f.tr.nocap || f.nocapT > 0 || mv.nocaphit || mv.absolute) return false;
  if (f.tr.nocappinch && f.hp <= f.mx.hp * 0.5) return false;
  if (f.tr.nocapch && Math.random() < f.tr.nocapch) return false;
  return true;
}
export function healAmt(f, mv) { return (f.wx === "holy" ? 1.2 : 1) * (stat(f, "mat") * 0.6 + stat(f, "mdf") * 0.4 + 6) * (1 + Math.max(0, (f.lv || 1) - 1) * 0.012) * (mv.heal || 1) * (1 + (f.tr.healboost || 0)); }
// v2.9: 命中と 回避。物理系・武系（と 武器の 通常攻撃）は 技ごとの 命中率で はずれる ことが ある。
//  回避は 走力の 勝負（先制度・反射に 左右されない）: 相手より 走力が 高いほど よく かわす
export function hitInfo(f, t, mv, B) {
  const phy = mv.basic || mv.cat === "phys" || mv.cat === "weapon";
  let acc = (mv.acc ?? (mv.basic ? 97 : phy ? 95 : 100)) / 100;
  if (phy) { acc *= 1 + (f.tr.acc || 0); const a = f.buf.acc || 0; acc *= a >= 0 ? 1 + 0.1 * a : 1 / (1 - 0.15 * a); if (wxOf(B, f) === "fog") acc *= 0.8; }
  let ev = 0;
  const ghost = !phy && t.tr.mevade;
  if (phy || ghost) {
    const fs = stat(f, "spd"), ts = stat(t, "spd");
    const sp = Math.max(0, (ts - fs) / Math.max(1, ts)) * 0.15 * (t.tr.evspd ? 2 : 1);
    ev = (t.tr.evade || 0) + 0.06 * (t.buf.eva || 0) + sp;
    const w = wxOf(B, t); if (w && t.tr.wevade && t.tr.wevade[w]) ev += t.tr.wevade[w];
    if (ghost) ev *= t.tr.mevade;
  }
  return { acc: Math.max(0.3, Math.min(1, acc)), ev: Math.max(0, Math.min(0.5, ev)) };
}
function evaded(f, t, mv, B) {
  if (mv.sure || mv.absolute) return false;
  if (t.ail.sleep || t.ail.freeze || t.ail.para) return false;
  const h = hitInfo(f, t, mv, B);
  if (Math.random() >= h.acc) return "miss";
  return Math.random() < h.ev ? "evade" : false;
}

// 1体への 攻撃（反射・回避・会心・耐性・追加効果）
// ---- 第104版: 戦いの 作戦（ブレイク・連携・地形）----
export const brkMax = (t) => ({ S: 2, M: 3, L: 4, G: 5 }[t && t.m ? sizeOf(t.m) : "M"] || 3) + (t && t.isBoss ? 3 : 0);
export const TERR = { forest: "wood", cherry: "wood", mushroom: "wood", swamp: "wood", sea: "water", volcano: "fire", underworld: "fire", snow: "ice", desert: "earth", cave: "earth", sky: "wind", crystal: "light", void: "dark", ruins: "steel" };
export const TERR_NAME = { wood: "森", water: "水辺", fire: "灼熱", ice: "雪原", earth: "大地", wind: "空", light: "光の 地", dark: "闇の 地", steel: "遺跡" };
const COMBO2 = { "aqua+blob": "しぶき アタック", "animal+beast": "野生の 牙", "dragon+sword": "竜騎の 一閃", "golem+sword": "鋼の 連撃", "dragon+nether": "魔竜の 咆哮", "aqua+dragon": "海竜の うねり", "animal+blob": "ころころ 体当たり", "blob+golem": "ぷるぷる プレス", "nether+sword": "妖刀の 舞", "beast+dragon": "猛獣 竜撃", "aqua+animal": "水辺の 狩り", "beast+nether": "闇の 狩人", "golem+nether": "呪いの 鉄槌" };
function comboName(a, b) {
  const fa = SPECIES[a.m?.sp]?.fam, fb = SPECIES[b.m?.sp]?.fam; if (!fa || !fb) return null;
  if (fa === "god" || fb === "god") return "神の 采配"; if (fa === "king" || fb === "king") return "王の 号令";
  if (fa === fb) return `${SPECIES[a.m.sp].famName || ""}の 息の あった 連撃`;
  return COMBO2[[fa, fb].sort().join("+")] || null;
}
function chainOf(B, f, t, mv, log) {
  if (!B || !f || t === f || f.side === t.side || mv.gc) return 1;
  const tn = B.turn || 1; if (!t.chn || t.chn.t !== tn) t.chn = { t: tn, L: [], done: false };
  if (!t.chn.L.includes(f)) { t.chn.L.push(f); if (t.chn.L.length >= 2) log.push(`§d連携 ${t.chn.L.length}人目！ 威力 ×${Math.min(1.3, 1 + 0.1 * (t.chn.L.length - 1)).toFixed(1)}`); }
  const n = t.chn.L.length; return n >= 2 ? Math.min(1.3, 1 + 0.1 * (n - 1)) : 1;
}
function hitOne(B, f, t, mv, log, fx, aoe, splash = 1) {
  if (t.hp <= 0) return 0;
  if (t !== f && t.side !== f.side && !mv.absolute) {
    const ev = evaded(f, t, mv, B);
    if (ev) { log.push(ev === "miss" ? `§7${f.name}の 攻撃は はずれた！` : `§b${t.name}は ひらりと 身を かわした！`); (fx.miss = fx.miss || []).push({ t, ev }); return 0; }
  }
  // 反射（反射系の 技・障壁・魔法反射）
  if (t !== f && t.side !== f.side && !mv.absolute && (!mv.basic || mv.wdep || t.refl.phys > 0 || t.refl.weapon > 0)) {
    // v2.9.2: 武器の 通常攻撃は その 種類（武系・魔法系 など）で 反射を みる
    const b = willBounce(t, mv.basic && !mv.wdep ? { ...mv, cat: t.refl.phys > 0 ? "phys" : "weapon" } : mv);
    if (b > 0 && Math.random() < b) {
      log.push(`§b${t.name}は ${mv.name}を 跳ね返した！`);
      const d = baseDamage(f, f, mv, false) * resMul(f, mv.el) * (aoe ? BAL.AOE : 1) * (splash ?? 1);   // v2.9.12: 連続攻撃の 減衰なども 反射に
      if (resMul(f, mv.el) > 0) applyDamage(B, null, f, d, mv, log, fx, { capBy: f });
      return 0;
    }
  }
  const crit = !t.tr.critguard && (!!mv.scrit || Math.random() < critRate(f, mv));
  let d = baseDamage(f, t, mv, crit);
  if (f.charge) { d *= TENS_K[f.tens || 1]; }
  const k = resMulMv(t, mv, f);
  if (k === 0) { log.push(`§7${t.name}には ${EL_NAME[mv.el]}が 効かない！`); return 0; }
  if (k > 0) d *= k * (k > 1 && mv.cat === "magic" ? 1.2 : 1);
  d *= dealtMul(f, t, mv, B, crit) * (aoe ? BAL.AOE : 1) * splash;
  if (B && B.terr && mv.el === B.terr) d *= 1.2;   /* 第104版: 地形と 同じ 属性は 1.2倍 */
  if (t.bkT > 0) d *= 1.3;   /* ブレイク中は 1.3倍 */
  d *= chainOf(B, f, t, mv, log);   /* 同じ ターンに 同じ 相手を ちがう 仲間が 攻撃すると 連携 */
  const phk = mv.cat === "phys" || mv.basic;
  if (mv.absolute || crit) { /* 国崩・会心: 守りも 構えも 無視 */ } else if (t.guard) d *= phk ? 0.65 : 0.3; else if (t.defend) d *= phk ? 0.75 : 0.5;
  if (crit) log.push(mv.cat === "magic" ? "§d魔力が 暴走した！" : f.side === "a" ? "§e会心の 一撃！" : "§c痛恨の 一撃！");
  else if (k > 1) log.push("§e弱点を ついた！");
  else if (k > 0 && k <= 0.25) log.push("§7ほとんど 効いていない…");
  { const ak = attrMul(f, t, mv); if (ak >= 1.2) log.push(`§e【${ATTR_NAME[attrOf(f, mv)]}】が よく 効く！`); else if (ak <= 0.8) log.push(`§7【${ATTR_NAME[attrOf(f, mv)]}】は 効きにくい…`); }
  // カウンター（物理系・武系）
  if (t !== f && t.side !== f.side && !mv.absolute && (mv.cat === "phys" || mv.cat === "weapon" || mv.cat === "special") && t.tr.counter && Math.random() < Math.min(0.5, t.tr.counter) && t.hp > 0)   /* v3.0 第63版: 返し技は 50%まで */ {
    log.push(`§e${t.name}の 返し技！`);
    applyDamage(B, t, f, d * 0.8, mv, log, fx);
    return 0;
  }
  const dealt = applyDamage(B, f, t, k < 0 ? d : d, mv, log, fx, { crit });
  if (dealt > 0 && B && f.side === "a" && t.side === "e" && t.hp > 0 && !mv.gc && (k > 1 || crit) && !(t.bkT > 0) && !B.pvp && !B.raid && !t.enmaN && !((t.bkCool || 0) >= (B.turn || 1))) {   /* 第104版: 弱点か 会心で 守りを けずる → 0で ブレイク */
    const mx = brkMax(t); t.bg = Math.min(mx, t.bg ?? mx) - 1 - (f.tr.brkUp ? 1 : 0);
    if (t.bg <= 0) { const now = B.turn || 1; t.bkT = t.actT === now ? 2 : 1; t.bkCool = now + t.bkT + 1; t.bg = mx; log.push(`§6§l${t.name}の 守りが くずれた！ ブレイク！§r§7（1回 休み・受ける ダメージ 1.3倍）`); }
    else log.push(`§6${t.name}の 守りを けずった（のこり ${t.bg}）`);
  }
  if (dealt > 0 && B && t.chn && t.chn.L.length === 2 && !t.chn.done && t.hp > 0 && f.side !== t.side && !mv.gc && !mv.absolute && !t.tr.metal) { const nm = comboName(t.chn.L[0], t.chn.L[1]); if (nm) { t.chn.done = true; log.push(`§d§l連携技「${nm}」！`); applyDamage(B, f, t, dealt * 0.5, { ...mv, gc: true }, log, fx); } }
  if (dealt > 0 && t !== f && t.side !== f.side && !mv.gc && !mv.absolute) {
    if (t.hp > 0) for (const [k, ch] of Object.entries(t.tr.hurtbuf || {})) if (Math.random() < ch) { if (k === "all") { for (const x of ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) t.buf[x] = Math.min(BUF_MAX, (t.buf[x] || 0) + 1); log.push(`§a${t.name}は 攻撃を 受けて 全能力が 上がった！`); } else buffOne(t, k, 1, log); }
    if (crit && f.tr.critdebuff && t.hp > 0) buffOne(t, "def", -1, log);
    if (crit && f.tr.critheal) { const h = Math.min(f.mx.hp - f.hp, Math.floor(f.mx.hp * f.tr.critheal)); if (h > 0) { f.hp += h; log.push(`§a${f.name}の HPが ${h} 回復した。`); } }
    if (f.tr.mphit && f.hp > 0) f.mp = Math.min(f.mx.mp, f.mp + Math.max(1, Math.floor(dealt * f.tr.mphit)));
    if (mv.el && f.tr.echoEl && f.tr.echoEl[mv.el] && t.hp > 0 && Math.random() < f.tr.echoEl[mv.el]) { log.push(`${EL_COL[mv.el]}${f.name}の ${EL_NAME[mv.el]}の 残響！`); applyDamage(B, f, t, dealt * 0.5, { ...mv, gc: true }, log, fx); }
    if (mv.finish && t.hp > 0) { t.norevive = Math.max(t.norevive || 0, 2); }
    const cc = t.tr.cntc && mv.cat ? t.tr.cntc[mv.cat] : 0;
    if (cc && t.hp > 0 && f.hp > 0 && Math.random() < cc) { log.push(`§e${t.name}の ${CATS[mv.cat]}返し！`); applyDamage(B, t, f, dealt * 0.8, { name: "返し", cat: mv.cat, gc: true }, log, fx); }
  }
  // v3.0: さわると あぶない 体（トゲの体・毒の体など）… 物理系・武系・通常攻撃で 当てた 相手に
  if (dealt > 0 && t !== f && t.side !== f.side && f.hp > 0 && !mv.gc && !mv.absolute && (mv.basic || mv.cat === "phys" || mv.cat === "weapon")) {
    if (t.tr.thorns && !cheatInv(B, f)) { const c = Math.max(1, Math.floor(dealt * Math.min(0.5, t.tr.thorns))); f.hp = Math.max(0, f.hp - c); (fx.dmg = fx.dmg || []).push({ t: f, d: c, crit: false, weak: false }); log.push(`§6${t.name}の トゲが ささった！ ${f.name}に ${c}の ダメージ`); if (f.hp === 0) ko(f, B, log, fx, false, t); }
    if (f.hp > 0 && t.tr.contactail) for (const [ai, ch] of Object.entries(t.tr.contactail)) if (Math.random() < ch) inflict(f, ai, 1, log, fx, B, true);
  }
  if (dealt > 0 && t !== f && t.side !== f.side && t.hp > 0 && f.hp > 0 && t.tr.gcounter && !mv.gc && !mv.absolute && Math.random() < t.tr.gcounter) {
    log.push(`§6${t.name}の 特性【賭けの返し】！`);
    applyDamage(B, t, f, dealt * 1.5, { name: "賭けの返し", cat: mv.cat, gc: true }, log, fx);
  }
  if (mv.nocover && t.cover > 0 && t.side !== f.side) { t.cover = 0; log.push(`§6${t.name}の 盾が くだけた！`); }   // v3.0: 盾砕き
  if (dealt > 0 && t.hp > 0 && t.side !== f.side) {
    if (mv.inf) inflict(t, mv.inf[0], mv.inf[1] * (mv.cat === "breath" ? 1.5 : 1), log, fx, B, true, mv.inf[0] === "bleed" ? bleedOf(mv) : 0);
    if (mv.death && t.hp > 0 && !deathImmune(t)) deathTry(B, f, t, mv.death, log, fx);
    if (mv.mpsteal && f.hp > 0) { const m = Math.min(t.mp, Math.floor(dealt * mv.mpsteal)); if (m > 0) { t.mp -= m; f.mp = Math.min(f.mx.mp, f.mp + m); log.push(`§b${f.name}は MPを ${m} 吸いとった。`); } }
    if (mv.debuff && Math.random() < (mv.debuff[2] ?? 1)) buffOne(t, mv.debuff[0], mv.debuff[1], log);
    if (mv.sealhit && Math.random() < mv.sealhit[1]) sealOne(t, mv.sealhit[0], 2, 1, log, fx);
    if (mv.dispelhit) dispel(t, log);
    for (const [c, ch] of f.tr.sealhit) if (Math.random() < ch) sealOne(t, c, 2, 1, log, fx);
    if (mv.basic || mv.cat === "phys" || mv.cat === "weapon") for (const [a, ch] of Object.entries(f.tr.onhit)) if (Math.random() < ch) inflict(t, a, 1, log, fx, B, true);
  }
  if (mv.drain && dealt > 0 && f.hp > 0) { const hv = Math.min(f.mx.hp - f.hp, Math.floor(dealt * mv.drain)); if (hv > 0) { f.hp += hv; log.push(`${f.name}の HPが ${hv} 回復した。`); } }
  return dealt;
}

function runAction0(B, a, log) {
  const f = a.actor;
  AIL_SRC = f;
  const fx = { actor: f, anim: null, el: null, hit: [], ko: [], healed: [], cat: null };
  if (f.hp <= 0) return null;
  f.wx = wxOf(B, f);   // v2.9.2: 途中参加・入れかえの 子も 天候を
  if (f.bkT > 0) { f.defend = false; log.push(`§6${f.name}は ブレイクして 動けない！`); return fx; }   /* 第104版: 防御・逃げるより 先 */
  f.actT = B.turn || 1;
  if (a.extra) log.push(`§d${f.name}は もう一度 動ける！`);
  if (a.kind === "defend") { log.push(f.ail.fear ? `§8${f.name}は おびえて 逃げ回っている…` : `${f.name}は 身を まもっている。`); fx.anim = "guard"; return fx; }
  const holdF = foesOf(B, f).some((x) => x.hp > 0 && x.tr.antiflee) ? 0.35 : 1;
  if (f.side === "e" && f.tr.metal && !B.pvp && !B.master && !B.boss && !(f.noflee > 0) && Math.random() < 0.18 * holdF) {
    f.hp = 0; f.fled = true; f.out = true; f.buf = Object.fromEntries(Object.keys(f.buf).map((k) => [k, 0])); log.push(`§7${f.name}は 逃げだした！`); fx.ko.push(f); fx.anim = "guard"; return fx;
  }
  if (f.restT > 0) { log.push(`§7${f.name}は 反動で 動けない！`); return fx; }   // v2.9.12: 1回休み
  if (f.boundT && f.boundT === (B.turn || 1)) { log.push(`§4${f.name}は 魔神の 闘気に 縛られて 動けない！`); return fx; }   // v3.0: 魔神の闘気
  // 行動できない 状態異常
  if (f.ail.freeze > 0) { log.push(`§b${f.name}は 凍りついて 動けない！`); return fx; }
  if (f.ail.sleep > 0) { log.push(`§9${f.name}は 眠っている…`); return fx; }
  if (f.ail.para > 0 && Math.random() < 0.5) { log.push(`§e${f.name}は しびれて 動けない！`); return fx; }
  if (f.ail.fear > 0 && Math.random() < 0.6) { log.push(`§8${f.name}は おびえて 逃げ回っている！`); fx.anim = "guard"; return fx; }
  if (a.kind === "tame") { const n = Math.min(4, (f.charge ? f.tens || 1 : 0) + 1); f.tens = n; f.charge = true; log.push(`§6${f.name}は 力を ためた！ 溜め ${n}段階（次の 攻撃 ×${TENS_K[n]}）`); fx.anim = "guard"; return fx; }   /* 第104版: だれでも ためる */
  // 出血: 動くと ダメージ
  if (f.ail.bleed > 0 && !a.mimicRet && !cheatInv(B, f)) {
    const bk = (f.bleedK || BLEED_BASE) * (f.isBoss ? 0.5 : 1);
    const d = f.tr.metal ? 1 : Math.max(1, Math.floor(f.mx.hp * bk));
    f.hp = Math.max(0, f.hp - d); log.push(`§4${f.name}は 動いて 出血！ ${d}の ダメージ`);
    (fx.dmg = fx.dmg || []).push({ t: f, d, crit: false, weak: false });
    if (f.hp === 0) { ko(f, B, log, fx); return fx; }
  }
  const foes = realFoes(B, f), friends = realFriends(B, f);
  if (f.ail.charm > 0) log.push(`§d${f.name}は 魅了されて いる！`);
  if (f.ail.conf > 0 && Math.random() < 0.5) {
    log.push(`§d${f.name}は 混乱して いる！`);
    a = { actor: f, kind: "attack", target: pick(alive([...B.allies, ...B.enemies].filter((x) => x !== f))) || f, forced: true };
  } else if (f.ail.charm > 0 && a.kind !== "defend") {
    // 魅了: 本来の 味方を ねらう
    const d = aiDecide(f, B); a = d;
  }
  // v3.0: AIが 決めた 追加行動は、動く 直前の 状況（回復した・MPを 使った など）で 決めなおす
  if (a.aiX && !a.forced && !(f.ail.conf > 0) && !(f.ail.charm > 0)) { const d2 = aiDecide(f, B, { lite: !f.isBoss }); if (d2) a = { ...d2, extra: true, aiX: true }; }
  // v2.2: 反射が もう 張って ある のに また 反射を 選んで いたら（続けて 動く とき）、ほかの 行動に かえる
  if (a.kind === "move" && MOVES[a.move]?.refl && [].concat(MOVES[a.move].refl).every((c) => f.refl[c] > 0)) { const d2 = aiDecide(f, B); if (d2 && !(d2.kind === "move" && MOVES[d2.move]?.refl)) a = d2; }
  // v2.9: 先に 決めて おいた 行動（敵・共闘・追加行動）が、この 間に 張られた 反射に 飛びこむ ときは 考えなおす
  if ((a.extra || a.ai || (f.side === "e" && !B.pvp) || f.guest) && !a.forced && (a.kind === "attack" || a.kind === "move")) {
    const mx = a.kind === "attack" ? f.atk : MOVES[a.move];
    const fo = alive(foes);
    const bounce = (t) => (mx.basic && !mx.wdep ? t.refl.phys > 0 || t.refl.weapon > 0 : t.refl[mx.cat] > 0);
    if (mx && isAtkMv(mx) && mx.cat && !mx.absolute && fo.length && ((mx.target === "enemy" && a.target && a.target.hp > 0 && bounce(a.target)) || fo.every(bounce))) { const d2 = aiDecide(f, B); if (d2) a = { ...d2, extra: a.extra }; }
  }
  if (a.kind === "defend") { f.defend = true; log.push(`${f.name}は 身を まもっている。`); fx.anim = "guard"; return fx; }   // v3.0: 考えなおして 防御に したとき
  let mv = a.kind === "attack" ? (f.ench && f.ench.t > 0 ? { ...f.atk, el: f.ench.el } : f.atk) : MOVES[a.move];
  if (!mv) return fx;
  if (a.kind === "move") { if (f.usedT !== (B.turn || 1)) { f.usedT = B.turn || 1; f.usedS = new Set(); } f.usedS.add(a.move); } f.lastMv = a.kind === "move" ? a.move : null;   /* 第68版: 同じ 技の 連発を 減らす */
  if (f.ail.fear > 0 && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless")) { log.push(`§8${f.name}は こわくて 攻撃できない！`); return fx; }
  if (sealedFor(f, mv)) {
    log.push(f.mistT > 0 && isSpell(mv) ? `§8漆黒の霧で ${f.name}は 呪文を となえられない！` : `§7${f.name}の ${CATS[mv.cat]}は 封じられている！`);
    if (a.kind === "attack" || sealedFor(f, f.atk)) return fx;
    mv = f.atk; a = { ...a, kind: "attack" };
  }
  const cost = costOf(f, mv);
  const freeCast = f.tr.halfmp_ch && Math.random() < f.tr.halfmp_ch;
  if (!a.free && cost > f.mp) { log.push(`${f.name}は ${mv.name}を 使おうとしたが MPが 足りない！`); return fx; }
  if (!freeCast && !a.free) f.mp -= cost;
  if (f.tr.nrefl && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless") && !mv.norefl) mv = { ...mv, norefl: true };   // v2.9.12: 特性【反射やぶり】
  if (mv.rest) f.restNext = true;
  if (mv.ruby) log.push(`§7${"　".repeat(f.name.length + 2)}${mv.ruby}`);
  log.push(a.kind === "attack" ? `§f${f.name}の ${mv.name}！${mv.el ? ` ${EL_COL[mv.el]}【${EL_NAME[mv.el]}】` : ""}` : `§f${f.name}の ${mv.name}！ ${moveLabel(mv)}`);
  fx.cat = mv.cat === "weapon" ? "slash" : mv.cat === "phys" ? "martial" : mv.cat;
  const isAtk = mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless";
  fx.anim = isAtk ? (mv.selfko ? "boom" : mv.cat === "breath" ? "breath" : mv.cat === "magic" ? "cast" : mv.mpdrain ? "cast" : "attack") : mv.guard || mv.charge ? "guard" : "cast";
  fx.el = mv.el || (mv.heal || mv.revive || mv.cure || mv.regen ? "heal" : mv.ail ? "dark" : null);
  fx.mtype = mv.type; fx.tier = mv.tier ?? (a.kind === "attack" ? 0 : 1); fx.hits = mv.hits || 1;
  fx.mid = a.kind === "attack" ? "basic" : a.move;
  fx.down = !!(mv.buff && Object.values(mv.buff).some((x) => x < 0) && (mv.target === "enemies" || mv.target === "enemy"));
  // v2.9.12: マネマネ（この ターンに 受けた 攻撃を 覚えて、ターンの 最後に まとめて 返す）
  if (mv.mimic) { f.mimicOn = true; f.mimicHits = []; log.push(`§d${f.name}は 相手の 動きを じっと 見ている……（マネマネの 構え）`); fx.anim = "guard"; return fx; }
  // v2.9.12: ハンシャ封じの霧（みんなの 反射を 消して しばらく 張れなく する）
  if (mv.antiRefl) {
    for (const x of [...B.allies, ...B.enemies]) { if (x.hp <= 0) continue; x.refl = {}; x.reflEl = {}; x.noReflT = Math.max(x.noReflT || 0, mv.turns || 3); }
    log.push(`§7あたりに 重たい 霧が たちこめた！ §f${mv.turns || 3}ターン、だれも 跳ね返せない`); fx.anim = "cast"; return fx;
  }

  // 対象
  let targets = [];
  if (a.forced) targets = [a.target];
  else if (mv.target === "enemy") {
    let t = a.target && a.target.hp > 0 && foes.includes(a.target) ? a.target : pickTarget(foes);
    // v2.5.3: 身代わり（仁王の構え）: 味方への 単体攻撃を 引き受ける
    const cv = t && !mv.nocover && !f.tr.shieldbreak && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless" || mv.kind === "status") ? foes.find((x) => x !== t && x.cover > 0 && x.hp > 0 && !x.doom && !x.ail.sleep && !x.ail.freeze && !x.ail.para) : null;   // v3.0: 執念で 立って いる 子は かばえない・盾くだきは かばいを 無視
    if (cv) { log.push(`§e${cv.name}が ${t.name}を かばった！`); t = cv; }
    if (t && t.tr.parry && !mv.absolute && !mv.sig && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless") && !t.ail.sleep && !t.ail.freeze && !t.ail.para && Math.random() < t.tr.parry) {   // v3.0: 受け流し
      const os = [...alive(foes), ...alive(friends)].filter((x) => x !== t && x !== f);
      if (os.length) { const n = pick(os); log.push(`§b${t.name}は 攻撃を 受け流した！ §f${n.name}に 向かう！`); t = n; }
    }
    targets = t ? [t] : [];
  }
  else if (mv.target === "enemies") targets = alive(foes);
  else if (mv.target === "rand2") { const l = alive(foes).sort(() => Math.random() - 0.5); targets = l.slice(0, 2); }
  else if (mv.target === "all") targets = [...alive(foes), ...alive(friends).filter((x) => x !== f)];
  else if (mv.target === "self") targets = [f];
  else if (mv.target === "allies") targets = mv.revive ? friends.filter((x) => x.hp <= 0 && !x.out) : alive(friends);
  else if (mv.target === "ally") {
    if (mv.revive) targets = a.target && a.target.hp <= 0 && !a.target.out ? [a.target] : friends.filter((x) => x.hp <= 0 && !x.out).slice(0, 1);
    else { const t = a.target && a.target.hp > 0 && friends.includes(a.target) ? a.target : alive(friends).sort((x, y) => x.hp / x.mx.hp - y.hp / y.mx.hp)[0]; targets = t ? [t] : []; }
  }
  if (!targets.length) { log.push("しかし 何も おこらなかった。"); return fx; }

  // 捨て身: 先に HPを けずる
  if (mv.hpcost && !cheatInv(B, f)) { const c = Math.floor(f.mx.hp * mv.hpcost); f.hp = Math.max(1, f.hp - c); log.push(`§4${f.name}は 命を けずった！（-${c}）`); }
  if (mv.gamble && Math.random() < mv.gamble) { log.push("しかし はずれて しまった！"); return fx; }

  // ---- 攻撃 ----
  if (isAtk && mv.selfko) {
    const pow = f.hp * 1.5 + powOf(f);
    for (const t of targets) applyDamage(B, null, t, pow * rnd(0.9, 1.1) * BAL.AOE * BAL.K * 2 * (t.guard ? 0.3 : t.defend ? 0.5 : 1), mv, log, fx, { capBy: f });   // v2.9.12: 上限も 守る
    log.push(`§c${f.name}は くだけ散った！`);
    f.hp = 0; f.nkUsed = true; ko(f, B, log, fx);   // v2.9.12: 自分の 再誕・仲間の 特性も 動く（第102版: 自爆は 踏みとどまらない）
    return fx;
  }
  if (isAtk && mv.allmp) {
    const use = f.mp + (!freeCast && !a.free ? cost : 0); f.mp = 0;
    log.push(`§d§l${f.name}は のこりの 魔力 ${use}を すべて 解き放った！`);
    for (const t of targets) { const d = use * ALLMP_K * BAL.AOE * rnd(0.9, 1.1) * dealtMul(f, t, mv, B) * (t.guard ? 0.5 : 1); applyDamage(B, f, t, d, mv, log, fx); }
    return fx;
  }
  if (isAtk && (mv.mult || mv.f)) {
    let list = mv.target === "enemies" || mv.target === "all" ? targets : [targets[0]];
    const aoe = mv.target === "enemies" || mv.target === "all";
    // v2.2: エンマ・ムサシは 通常攻撃と 斬撃（武系）が 5連撃
    const c5 = !!(f.m && SPECIES[f.m.sp]?.combo5 && (mv.basic || mv.cat === "weapon") && !mv.rnd && !aoe && !a.forced && !mv.scrit && !mv.gamble);   // v3.0 第63版: 会心技・一か八かは 5連撃に しない
    let nh = c5 ? Math.max(5, mv.hits || 1) : mv.hitsR ? ri(mv.hitsR[0], mv.hitsR[1]) : (mv.hits || 1);
    if (mv.hitsR && !c5) { fx.hits = nh; log.push(`§6${nh}回 当たる！`); }
    const c5k = c5 ? ((mv.hits || 1) * (mv.basic ? 2.0 : 1.5)) / nh : 1;
    if (c5) { fx.hits = nh; log.push(`§c${f.name}の 5連撃！`); }
    // v2.1: サイズの 力。L・G は 物理系・武系・通常攻撃が 敵全体に、G は さらに 1回の 行動で 2回 攻撃（2撃目は 弱め）
    const fsz = sizeOf(f.m);
    const phy = mv.basic || mv.cat === "phys" || mv.cat === "weapon";
    // v2.2: 連続攻撃（2〜5回。1発ごとに 弱くなる）。この 特性が ある 子は 大きくても 敵1体に 集中する
    const rapN = !c5 && f.tr.rapid && (mv.basic || mv.cat === "phys") && (mv.hits || 1) === 1 && !aoe && !mv.rnd && !a.forced ? Math.max(2, Math.min(5, Math.round(f.tr.rapid))) : 0;
    let splash = false;
    if (!rapN && !aoe && !a.forced && phy && (fsz === "L" || fsz === "G") && !(f.ail.charm > 0) && !mv.rnd) {
      const others = alive(foes).filter((x) => x !== targets[0]);
      if (others.length) { list = [targets[0], ...others]; splash = true; log.push(fsz === "G" ? `§d${f.name}の ギガ攻撃！ 敵 全員を なぎはらう！` : `§6${f.name}の 大きな 体が 敵 全員を まきこむ！`); }
    }
    const passes = phy && fsz === "G" && !a.forced && !rapN ? 2 : 1;
    const rap = rapN > 0;
    if (rap) { nh = rapN; fx.hits = nh; log.push(`§6${f.name}の ${nh}回 連続攻撃！`); }
    const multi = !aoe && !splash && (mv.cat === "phys" || mv.cat === "weapon") && f.tr.multi && Math.random() < f.tr.multi;
    if (multi) log.push(`§6${f.name}の 連撃！`);
    const echo = mv.cat === "magic" && f.tr.echo && Math.random() < f.tr.echo;
    for (let gp = 0; gp < passes; gp++) {
      if (gp === 1) { if (!alive(foes).length || f.hp <= 0) break; log.push(`§d${f.name}の 2撃目！`); }
      const gk = gp === 1 ? SIZE_HIT.second : 1;
      for (let pass = 0; pass < (echo ? 2 : 1); pass++) {
        if (pass === 1) log.push(`§d${f.name}の 魔力連鎖！ もう一度 発動した！`);
        for (const t0 of list) {
          const sp = (t0 !== list[0] && !mv.whip ? SIZE_HIT.splash : 1) * gk * (mv.whip ? Math.pow(0.8, list.indexOf(t0)) : 1);   // v2.9.2: ムチは 全体技と 同じ 0.7倍から 左ほど 強い   // v2.9: ムチは 左から じゅんに 弱まる
          let t = t0;
          for (let h = 0; h < nh + (multi ? 1 : 0); h++) {
            if (mv.rnd) { t = pick(alive(foes)); if (!t) break; }
            else if (t.hp <= 0) { if (aoe || splash) break; t = pickTarget(foes); if (!t) break; }
            hitOne(B, f, t, mv, log, fx, aoe, sp * c5k * (rap ? RAPID_K[h] ?? 0.2 : 1) * (mv.accel ? 1 + mv.accel * h : !rap && h > 0 ? HIT_DECAY ** h : 1));
            if (f.hp <= 0) break;
          }
          if (f.hp <= 0) break;
        }
      }
    }
    f.charge = false; f.tens = 0;
    if (mv.recoil && !cheatInv(B, f)) { const tot = (fx.dmg || []).filter((x) => x.t !== f).reduce((s, x) => s + (x.r ?? x.d), 0); if (tot > 0 && f.hp > 0) { const c = Math.max(1, Math.floor(tot * mv.recoil)); f.hp = Math.max(1, f.hp - c); log.push(`§7${f.name}は 反動で ${c}の ダメージ！`); } }
    if (mv.buff && f.hp > 0) buffAll(f, mv.buff, log);
    if (mv.allup && f.hp > 0) { let up = false; for (const k of ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) { const cur = f.buf[k] || 0; const nv = Math.max(cur, Math.min(MULTI_CAP, cur + mv.allup)); if (nv > cur) up = true; f.buf[k] = nv; } log.push(up ? `§a${f.name}の 全能力が 上がった！ §7（全能力を 上げる 技は +${MULTI_CAP}段まで）` : `§7${f.name}の 全能力は もう 上がらない（+${MULTI_CAP}まで）`); }
    if (mv.selfheal && f.hp > 0) { const h = Math.min(f.mx.hp - f.hp, Math.floor(f.mx.hp * mv.selfheal)); if (h > 0) { f.hp += h; log.push(`§a${f.name}の HPが ${h} 回復した。`); } }
    if (mv.mpdrain && f.hp > 0) for (const t of targets) if (t.hp > 0 && t.mp > 0) { const m = Math.min(t.mp, ri(mv.mpdrain[0], mv.mpdrain[1])); t.mp -= m; f.mp = Math.min(f.mx.mp, f.mp + m); log.push(`${t.name}の MPを ${m} 吸いとった！`); }   // v3.0 第63版: 攻撃技の MP吸収も 効く
    return fx;
  }
  // ---- MP吸収 ----
  if (mv.mpdrain) {
    for (const t of targets) { const m = Math.min(t.mp, ri(mv.mpdrain[0], mv.mpdrain[1])); t.mp -= m; f.mp = Math.min(f.mx.mp, f.mp + m); fx.hit.push(t); log.push(`${t.name}の MPを ${m} 吸いとった！`); }
    return fx;
  }
  // ---- 補助・回復・状態異常・封印・反射・場 ----
  // v2.9.12: 状態異常の 技に ついた 上がる 強化は 自分に（前は 相手が 強く なって いた）
  const selfBuf = !!(mv.buff && mv.ail && (mv.target === "enemy" || mv.target === "enemies") && Object.values(mv.buff).every((v) => v > 0));
  if (selfBuf) buffAll(f, mv.buff, log);
  for (const t of targets) {
    const enemy = t.side !== f.side || (f.ail.charm > 0);
    if (mv.revive) { t.hp = Math.max(1, Math.floor(t.mx.hp * mv.revive)); cureAll(t); fx.healed.push(t); fx.revived = t; log.push(`§a${t.name}は 生き返った！`); continue; }
    if (mv.heal) { const amt = Math.min(t.mx.hp - t.hp, t.isBoss && t.side === "e" && !B.pvp ? Math.floor(t.mx.hp * 0.06) : 1e9, Math.floor(healAmt(f, mv) * rnd(0.9, 1.1) * (foesOf(B, t).some((x) => x.hp > 0 && x.tr.healcut) ? 0.5 : 1))); t.hp += amt; fx.healed.push(t); (fx.heal = fx.heal || []).push({ t, d: amt }); log.push(amt > 0 ? `${t.name}の HPが ${amt} 回復した！` : `§7${t.name}の HPは もう 満タンだ`); }
    if (mv.cure) { cureAll(t); if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`${t.name}の 体が 清められた！`); }
    if (mv.regen) { t.regen = Math.max(t.regen || 0, mv.regen); if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§a${t.name}は やさしい 光に つつまれた！`); }
    if (mv.buff && !selfBuf) { buffAll(t, mv.buff, log); for (const v of Object.values(mv.buff)) { if (v > 0 && !fx.healed.includes(t)) fx.healed.push(t); if (v < 0 && !fx.hit.includes(t)) fx.hit.push(t); } }
    if (mv.ail) inflict(t, mv.ail, mv.chance || 0.5, log, fx, B, false, mv.ail === "bleed" ? bleedOf(mv) : 0);
    if (mv.death && enemy) deathTry(B, f, t, mv.death, log, fx);
    if (mv.seal) { if (mv.seal === "all") { for (const c of Object.keys(CATS)) sealOne(t, c, mv.turns || 2, mv.chance || 1, log, fx); } else sealOne(t, mv.seal, mv.turns || 3, mv.chance || 1, log, fx); }
    if ((mv.refl || mv.reflel) && t.noReflT > 0) { log.push(`§7霧に はばまれて ${t.name}は 跳ね返す 構えが とれない！`); continue; }
    if (mv.refl) { for (const c of [].concat(mv.refl)) t.refl[c] = Math.max(t.refl[c] || 0, mv.turns || 2); fx.healed.push(t); log.push(`§b${t.name}は ${[].concat(mv.refl).map((c) => CATS[c]).join("・")}を 跳ね返す 構えを とった！`); }
    if (mv.reflel) { t.reflEl[mv.reflel] = mv.turns || 3; fx.healed.push(t); log.push(`§b${t.name}は ${EL_NAME[mv.reflel]}属性を 跳ね返す 構えを とった！`); }
    if (mv.catguard) { t.catg[mv.catguard] = mv.turns || 3; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§a${t.name}は ${CATS[mv.catguard]}の ダメージを 軽減する 構えを とった！`); }
    if (mv.catguard2) { t.catg2[mv.catguard2] = mv.turns || 2; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§b${t.name}は ${CATS[mv.catguard2]}の ダメージを 激減する 構えを とった！`); }
    if (mv.elguard2) { t.elg2[mv.elguard2] = mv.turns || 3; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`${EL_COL[mv.elguard2]}${t.name}は ${EL_NAME[mv.elguard2]}属性を 激減する 守りに つつまれた！`); }
    if (mv.elguard) { t.elg[mv.elguard] = mv.turns || 4; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`${EL_COL[mv.elguard]}${t.name}は ${EL_NAME[mv.elguard]}属性の 加護に つつまれた！`); }
    if (mv.elmark && enemy) { t.elm[mv.elmark] = mv.turns || 3; if (!fx.hit.includes(t)) fx.hit.push(t); log.push(`${EL_COL[mv.elmark]}${t.name}に ${EL_NAME[mv.elmark]}の 刻印！ ${EL_NAME[mv.elmark]}属性が 効きやすく なった`); }
    if (mv.enchant) { t.ench = { el: mv.enchant, t: mv.turns || 4 }; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`${EL_COL[mv.enchant]}${t.name}は ${EL_NAME[mv.enchant]}の 力を 纏った！`); }
    if (mv.ailguard) { t.ailg[mv.ailguard] = mv.turns || 5; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§a${t.name}は ${AIL_NAME[mv.ailguard]}よけの 護りを 得た。`); }
    if (mv.late) { t.late = mv.turns || mv.late; log.push(`§7${t.name}は どっしりと 構えた（遅い 順に 動く）`); }
    if (mv.critup) { t.critT = mv.critup; log.push(`§e${t.name}は 急所を ねらって いる！`); }
    if (mv.mpgive) { const g = Math.min(t.mx.mp - t.mp, ri(mv.mpgive[0], mv.mpgive[1])); t.mp += g; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§b${t.name}の MPが ${g} 回復した！`); }
    if (mv.nosealT) { t.nosealT = mv.nosealT; log.push(`§7${t.name}は 封印を 受けつけない 結界に 守られた。`); }
    if (mv.taunt && !enemy) { t.taunt = mv.taunt; log.push(`§c${t.name}は 敵の 注意を ひきつけた！`); }
    if (mv.guard) { t.guard = true; log.push(`${t.name}は 身を 固めた！`); }
    if (mv.charge) { t.tens = Math.min(4, (t.charge ? t.tens || 1 : 0) + (mv.charge === 2 ? 2 : 1) + (t.tr.chargeplus ? 1 : 0)); t.charge = true; fx.healed.push(t); log.push(`§6${t.name}は 気を 練って いる！ 溜め ${t.tens}段階（次の 攻撃 ×${TENS_K[t.tens]}）`); }
    if (mv.cover && !enemy) { t.cover = 1; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§e${t.name}は 仲間の 盾に なる 構えだ！（この ラウンド 味方への 単体攻撃を 引き受ける）`); }
    if (mv.norevive && enemy) { t.norevive = mv.turns || 4; if (t.reraise) t.reraise = 0; if (t.doom && !cheatInv(B, t)) { t.doom = false; t.hp = 0; log.push(`§8${t.name}の 執念が 冥府の 鎖に 断たれた！`); ko(t, B, log, fx, true, f); } if (!fx.hit.includes(t)) fx.hit.push(t); log.push(`§8${t.name}に 冥府の 鎖が からみついた！ ${t.norevive}ターン よみがえれない`); }
    if (mv.reraise && !enemy) { t.reraise = mv.reraise; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§d${t.name}は 再誕の誓いに つつまれた！（倒れても すぐ よみがえる）`); }
    if (mv.dispel) { if (dispel(t, log)) { if (!fx.hit.includes(t)) fx.hit.push(t); } else log.push(`§7${t.name}には かき消す 強化が ない。`); }
    if (mv.trboost && !enemy) boostTr(t, log);
    if (mv.resdown && enemy) { t.resdn = mv.turns || 3; if (!fx.hit.includes(t)) fx.hit.push(t); log.push(`§5${t.name}は 妖しい 光に つつまれた！ 属性の 耐性が 1段 弱まった（${t.resdn}ターン）`); }
    if (mv.nocap && !enemy) { t.nocapT = Math.max(t.nocapT || 0, mv.nocap); t.capT = 0; if (!fx.healed.includes(t)) fx.healed.push(t); log.push(`§6${t.name}の ダメージの 上限が なくなった！（${mv.nocap}ターン）`); }
    if (mv.capT && enemy) { t.capT = Math.max(t.capT || 0, mv.capT); t.nocapT = 0; if (!fx.hit.includes(t)) fx.hit.push(t); log.push(`§7${t.name}に 封限の 霧！ ダメージは 999まで（${mv.capT}ターン）`); }
    if (mv.pin && enemy) { t.noflee = Math.max(t.noflee || 0, mv.pin); fx.hit.push(t); log.push(`§b${t.name}は 足止めされた！`); }
  }
  if (mv.weather) setWeather(B, mv.weather, (mv.turns || 5) + (f.tr.wlong ? 3 : 0), log, f);
  if (mv.mist) { for (const x of [...B.allies, ...B.enemies]) if (x.hp > 0) x.mistT = mv.turns || 3; log.push(`§8§l漆黒の 霧が たちこめた！ ${mv.turns || 3}ターン だれも 呪文（魔法・回復・蘇生・再誕）を となえられない`); }
  if (mv.field === "reverse") { B.reverse = Math.max(B.reverse || 0, mv.turns || 3); log.push(`§d§l空間が ゆがんだ！ ${mv.turns || 3}ターンの あいだ 遅い 順に 動く！`); }
  return fx;
}

// ---- バトル中の 道具 ----
export function battleItem(B, id, target, log, side = "a") {
  const it = ITEMS[id];
  const mine = side === "a" ? B.allies : B.enemies, theirs = side === "a" ? B.enemies : B.allies;
  const fx = { actor: null, anim: null, el: "heal", hit: [], ko: [], healed: [] };
  const lvAvg = alive(mine).reduce((s, x) => s + x.lv, 0) / Math.max(1, alive(mine).length);
  log.push(`§f${B.pvp ? (side === "a" ? B.nameA : B.nameE) + "は" : "あなたは"} ${it.name}を 使った！`);
  switch (it.kind) {
    case "heal": { const t = target; if (!t || t.hp <= 0) { log.push("しかし 何も おこらなかった。"); break; } const a = Math.min(t.mx.hp - t.hp, itemHp(it, t.mx.hp)); t.hp += a; fx.healed.push(t); log.push(`${t.name}の HPが ${a} 回復した！`); break; }
    case "healall": for (const t of alive(mine)) { const a = Math.min(t.mx.hp - t.hp, itemHp(it, t.mx.hp)); t.hp += a; fx.healed.push(t); log.push(`${t.name}の HPが ${a} 回復した！`); } break;
    case "fullall": for (const t of alive(mine)) { t.hp = t.mx.hp; t.mp = t.mx.mp; fx.healed.push(t); } log.push("§a仲間 全員が 全回復した！"); break;
    case "mpheal": { const t = target; if (!t || t.hp <= 0) { log.push("しかし 何も おこらなかった。"); break; } const a = Math.min(t.mx.mp - t.mp, itemMp(it, t.mx.mp)); t.mp += a; fx.healed.push(t); log.push(`${t.name}の MPが ${a} 回復した！`); break; }
    case "cure": { const t = target; if (!t || t.hp <= 0) { log.push("しかし 何も おこらなかった。"); break; } if (it.cures) for (const k of it.cures) t.ail[k] = 0; else cureAll(t); fx.healed.push(t); log.push(`${t.name}の ${it.cures ? AIL_NAME[it.cures[0]] : "状態異常"}が なおった！`); break; }
    case "revive": { const t = target; if (!t || t.hp > 0 || t.out) { log.push("しかし 何も おこらなかった。"); break; } t.hp = it.full ? t.mx.hp : Math.floor(t.mx.hp / 2); cureAll(t); fx.healed.push(t); fx.revived = t; log.push(`§a${t.name}は 生き返った！`); break; }
    case "scout": B.scoutBonus = (B.scoutBonus || 0) + it.val; log.push(`§dあまい かおりが ただよう… スカウト成功率 +${it.val}%`); break;
    case "bbuff": for (const t of alive(mine)) { t.buf[it.stat] = Math.min(BUF_MAX, (t.buf[it.stat] || 0) + (it.n || 1)); fx.healed.push(t); } log.push(`仲間の ${ST_NAME[it.stat]}が 上がった！`); break;
    case "bomb": { fx.el = it.el || "fire"; for (const t of alive(theirs)) { const k = resMul(t, it.el); const d = ri(it.pow[0], it.pow[1]) * (1 + lvAvg / 6) * (k < 0 ? 0 : k); applyDamage(B, null, t, d, { cat: "phys", el: it.el, f: null }, log, fx); } break; }
    case "mpall": for (const t of alive(mine)) { const a = Math.min(t.mx.mp - t.mp, itemMp(it, t.mx.mp)); t.mp += a; fx.healed.push(t); } log.push(`§b仲間の MPが 回復した！`); break;
    case "reviveall": { const dead = mine.filter((t) => t.hp <= 0 && !t.out); for (const t of dead) { t.hp = it.full ? t.mx.hp : Math.floor(t.mx.hp / 2); fx.healed.push(t); } fx.revivedList = dead; log.push(dead.length ? `§a倒れた 仲間 ${dead.length}体が 生き返った！` : "しかし 何も おこらなかった。"); break; }
    case "curall": for (const t of alive(mine)) { cureAll(t); fx.healed.push(t); } log.push("§a仲間の 体が 清められた！"); break;
    case "bdebuff": fx.el = "dark"; for (const t of alive(theirs)) { if (t.tr.nodebuff) continue; t.buf[it.stat] = Math.max(-BUF_MAX, (t.buf[it.stat] || 0) - (it.n || 1)); if (!fx.hit.includes(t)) fx.hit.push(t); } log.push(`§d${B.pvp ? "相手" : "敵"}の ${ST_NAME[it.stat]}が 下がった！`); break;
    case "bstatus": fx.el = "dark"; for (const t of alive(theirs)) inflict(t, it.st, it.chance, log, fx, B); break;
    case "bregen": for (const t of alive(mine)) { t.regen = Math.max(t.regen || 0, it.turns || 3); fx.healed.push(t); } log.push("§a仲間は やさしい 光に つつまれた！"); break;
  }
  return fx;
}

// ---- ターンの 終わり ----
export function endOfTurn(B, log) {
  const mimicKo = [];
  // v2.9.12: マネマネ — 受けた 攻撃を まとめて 返す
  for (const f of [...B.allies, ...B.enemies]) {
    if (!f.mimicOn) continue;
    const hits = (f.mimicHits || []).slice(0, 4); f.mimicOn = false; f.mimicHits = [];
    if (f.hp <= 0) continue;
    if (f.ail.charm > 0 || f.ail.conf > 0 || f.ail.sleep > 0 || f.ail.freeze > 0) { log.push(`§7${f.name}は マネマネどころでは ない……`); continue; }
    if (!hits.length) { log.push(`§7${f.name}の マネマネ… まねる 技が なかった。`); continue; }
    log.push(`§d§l${f.name}の マネマネ！ §r§d受けた 技を まとめて 返す！`);
    for (const h of hits) {
      if (f.hp <= 0) break;
      const foes = alive(foesOf(B, f)); if (!foes.length) break;
      const tgt = h.from && h.from.hp > 0 ? h.from : pick(foes);
      try { ACT_SEQ++; const rx = runAction0(B, { actor: f, kind: h.mid === "basic" ? "attack" : "move", move: h.mid, target: tgt, forced: true, free: true, mimicRet: true }, log); if (rx && rx.ko) mimicKo.push(...rx.ko); } catch {}
    }
  }
  for (const f of [...B.allies, ...B.enemies]) {
    if (f.noReflT > 0) { f.noReflT--; if (!f.noReflT && f.side === "a") log.push(`§7霧が 晴れた。（${f.name}も また 跳ね返せる）`); }
    if (f.restT > 0) f.restT--;
    if (f.bkT > 0) f.bkT--;
    if (f.restNext) { f.restNext = false; f.restT = 1; }
  }
  B.turn = (B.turn || 1) + 1;
  // v3.0: 魔神の闘気 — つぎの ターン、ときどき 相手を 動けなく する
  for (const f of [...B.allies, ...B.enemies]) {
    if (f.hp <= 0 || !f.tr || !f.tr.majinAura) continue;
    const foes = (f.side === "a" ? B.enemies : B.allies).filter((x) => x.hp > 0);
    for (const t of foes) if (Math.random() < f.tr.majinAura * (t.isBoss ? 0.4 : 1)) { t.boundT = B.turn; log.push(`§4§l${f.name}の 魔神の闘気！ §r§c${t.name}は 動けなく なった！`); }
  }
  try { weatherTurn(B, log); } catch {}
  if (B.reverse > 0) { B.reverse--; if (!B.reverse) log.push("§d空間の ゆがみが 元に もどった。"); }
  const kos = [...mimicKo];
  // v2.5.1: 執念の 子は ラウンドの 終わりに 倒れる（再誕の誓いが あれば よみがえる）
  for (const f of [...B.allies, ...B.enemies]) if (f.doom && f.hp > 0 && !cheatInv(B, f)) { const fx = { ko: [], healed: [], hit: [] }; log.push(`§4${f.name}の 執念が 尽きた……`); f.hp = 0; ko(f, B, log, fx, true); kos.push(...fx.ko); }
  // ときどき 発動する 特性
  for (const f of [...B.allies, ...B.enemies]) {
    if (f.hp <= 0) continue;
    if (f.tr.autodispel && Math.random() < f.tr.autodispel) { const tg = alive(foesOf(B, f)).filter((x) => posBuf(x) > 0); if (tg.length) { log.push(`§b${f.name}の 特性【霧散の気】！ 冷たい 波動が 広がった！`); for (const x of tg) dispel(x, log); } }
    if (f.tr.tokiheal && Math.random() < f.tr.tokiheal) { log.push(`§a${f.name}の 特性【ときどき 癒しの風】！`); for (const x of alive(friendsOf(B, f))) { const h = Math.min(x.mx.hp - x.hp, Math.floor(Math.min(STAT_MAX, x.mx.hp) * 0.15)); if (h > 0) { x.hp += h; log.push(`§a${x.name}の HPが ${h} 回復した。`); } } }
    { const foes = alive(foesOf(B, f));
      for (const [k, ch] of Object.entries(f.tr.tokidown || {})) if (foes.length && Math.random() < ch) { const x = pick(foes); log.push(`§c${f.name}の 特性！`); buffOne(x, k, -1, log); }
      for (const [c, ch] of Object.entries(f.tr.tokiseal || {})) if (foes.length && Math.random() < ch) { const x = pick(foes); log.push(`§7${f.name}の 特性！`); sealOne(x, c, 2, 1, log, { hit: [] }); }
      for (const [c, ch] of Object.entries(f.noReflT > 0 ? {} : f.tr.tokirefl || {})) if (Math.random() < ch) { f.refl[c] = Math.max(f.refl[c] || 0, 2); log.push(`§b${f.name}の 特性！ ${CATS[c]}を 跳ね返す 構え`); }
      for (const [e, ch] of Object.entries(f.tr.tokiench || {})) if (Math.random() < ch) { f.ench = { el: e, t: 3 }; log.push(`${EL_COL[e]}${f.name}の 特性！ ${EL_NAME[e]}の 力を 纏った`); }
      if (f.tr.tokicure && Math.random() < f.tr.tokicure && Object.values(f.ail).some((x) => x > 0)) { cureAll(f); log.push(`§a${f.name}の 特性！ 状態異常が なおった`); }
      if (f.tr.tokimp && Math.random() < f.tr.tokimp) { f.mp = Math.min(f.mx.mp, f.mp + Math.floor(f.mx.mp * 0.15)); log.push(`§b${f.name}の 特性！ MPが 回復した`); }
      if (f.tr.tokicharge && Math.random() < f.tr.tokicharge && (f.tens || 0) < 4) { f.tens = Math.min(4, (f.charge ? f.tens || 1 : 0) + 1); f.charge = true; log.push(`§6${f.name}の 特性！ 力が 溜まった（${f.tens}段階）`); }
      if (f.tr.tokiregen && Math.random() < f.tr.tokiregen) { f.regen = Math.max(f.regen || 0, 3); log.push(`§a${f.name}の 特性！ 再生の 光`); }
      if (f.tr.tokieva && Math.random() < f.tr.tokieva) buffOne(f, "eva", 1, log);
      if (f.tr.tokitaunt && Math.random() < f.tr.tokitaunt) { f.taunt = Math.max(f.taunt || 0, 2); log.push(`§c${f.name}の 特性！ 敵の 注意を ひきつけた`); }
    }
    for (const [key, stx, nm] of [["tokipow", ["atk", "wpn"], "ときどき 力溜め"], ["tokiguard", ["def", "mdf"], "ときどき 守りの陣"], ["tokispd", ["spd"], "ときどき 疾風"], ["tokimag", ["mat"], "ときどき 魔力集中"]]) {
      if (f.tr[key] && Math.random() < f.tr[key]) { log.push(`§e${f.name}の 特性【${nm}】！`); const tg = key === "tokiguard" || key === "tokispd" ? alive(friendsOf(B, f)) : [f]; for (const x of tg) for (const k of stx) buffOne(x, k, 1, log); }
    }
  }
  for (const f of [...B.allies, ...B.enemies]) {
    if (f.noflee > 0) f.noflee--;
    f.defend = false; f.guard = false; f.cover = 0;
    if (f.hp <= 0) continue;
    const fx = { ko: [], healed: [], hit: [] };
    for (const [k, pct, col] of [["poison", 0.08, "§5"], ["burn", 0.05, "§c"]]) {
      if (f.ail[k] > 0 && f.hp > 0 && !cheatInv(B, f)) {
        const d = Math.max(1, Math.floor(f.mx.hp * pct));
        f.hp = Math.max(0, f.hp - d);
        log.push(`${col}${f.name}は ${AIL_NAME[k]}で ${d}の ダメージを 受けた。`);
        if (f.hp === 0) { ko(f, B, log, fx); kos.push(...fx.ko); }
      }
    }
    if (f.hp <= 0) continue;
    for (const k of Object.keys(f.ail)) if (f.ail[k] > 0) { f.ail[k]--; if (!f.ail[k]) log.push(`§7${f.name}の ${AIL_NAME[k]}が なおった。`); }
    for (const c of Object.keys(f.seal)) if (f.seal[c] > 0) { f.seal[c]--; if (!f.seal[c]) log.push(`§7${f.name}の ${CATS[c]}の 封印が とけた。`); }
    for (const c of Object.keys(f.refl)) if (f.refl[c] > 0) f.refl[c]--;
    for (const o of [f.reflEl, f.elg, f.elg2, f.catg, f.catg2, f.elm, f.ailg]) if (o) for (const c of Object.keys(o)) if (o[c] > 0) o[c]--;
    if (f.ench && f.ench.t > 0 && !--f.ench.t) log.push(`§7${f.name}の 纏いが 消えた。`);
    if (f.nocapT > 0 && !--f.nocapT) log.push(`§7${f.name}の 上限 解放が 切れた。`);
    if (f.capT > 0 && !--f.capT) log.push(`§7${f.name}の 封限が とけた。`);
    if (f.late > 0) f.late--; if (f.critT > 0) f.critT--; if (f.nosealT > 0) f.nosealT--; if (f.resdn > 0) f.resdn--; if (f.mistT > 0) f.mistT--; if (f.norevive > 0) f.norevive--;
    if (f.taunt > 0) f.taunt--;
    const rg = Math.min(0.15, (f.regen ? 0.1 : 0) + (f.tr.regen || 0));   // v3.0 第63版: 毎ターンの 回復は 15%まで
    if (f.regen) f.regen--;
    if (rg) { const h = Math.min(f.mx.hp - f.hp, Math.max(1, Math.floor(Math.min(STAT_MAX, f.mx.hp) * rg)));   /* 第100版: 割合の 回復は HP 9999 ぶんまで（HPを 伸ばして 倒せなく なる のを ふせぐ） */ if (h > 0) { f.hp += h; log.push(`§a${f.name}の HPが ${h} 回復した。`); } }
    if (f.tr.mpregen) f.mp = Math.min(f.mx.mp, f.mp + Math.max(1, Math.floor(f.mx.mp * f.tr.mpregen)));
  }
  return kos;
}

export function matDrop(e, cap = 3) {
  const r = RANKS.indexOf(SPECIES[e.m.sp].rank);
  const t = Math.min(cap, r >= 5 ? (Math.random() < 0.5 ? 2 : 1) : r >= 3 ? (Math.random() < 0.3 ? 1 : 0) : (Math.random() < 0.15 ? 1 : 0));   /* 第103版: 店で 買えない ぶん 序盤の 素材を 少し 多く */   // v2.9.12: 物語で 素材の 段も しばる
  // v2.9: クラフト素材（武器づくり用）も 落とす
  const cd = CRAFT_DROP && CRAFT_DROP[SPECIES[e.m.sp].fam];
  if (cd && Math.random() < 0.4) { const L = cd[t].length ? cd[t] : cd[0]; if (L.length) return L[Math.floor(Math.random() * L.length)]; }
  return `mat_${SPECIES[e.m.sp].fam}${t}`;
}
export const bloodCandidates = (list) => blood(list);
export { ROMAN };

// ================= v2.9: 天候 =================
// 晴れ 炎1.5・水0.5 ／ 雨 水1.5・炎0.5 ／ 砂嵐 地1.3・鉄1.2（地・鉄が 得意な 子と 物質系 いがいは 毎ターン 1/16） ／ 雪 氷1.5・炎0.8（氷が 得意な 子 いがい 1/16）
// 雷雨 雷1.5・水1.2・麻痺に なりやすい ／ 暴風 風1.5・息系1.1 ／ 霧 物理系・武系の 命中 0.8・木1.2 ／ 闇夜 闇1.5・光0.7 ／ 天光 光1.5・闇0.7・回復1.2
export const WX_EL = { sun: { fire: 1.5, water: 0.5 }, rain: { water: 1.5, fire: 0.5 }, sand: { earth: 1.3, steel: 1.2 }, snow: { ice: 1.5, fire: 0.8 }, storm: { thunder: 1.5, water: 1.2 },
  wind: { wind: 1.5 }, fog: { wood: 1.2 }, dark: { dark: 1.5, light: 0.7 }, holy: { light: 1.5, dark: 0.7 } };
export const wxOf = (B, f) => (B && B.weather && B.weather.t > 0 && !(f && f.tr && f.tr.wnone) ? B.weather.w : null);
export const wxName = (w) => (WEATHER && WEATHER[w] ? `${WEATHER[w][1]}${WEATHER[w][0]}§r` : "");
export function setWeather(B, w, turns, log, by, quiet) {
  if (!WEATHER || !WEATHER[w]) return;
  const same = B.weather && B.weather.w === w && B.weather.t > 0;
  B.weather = { w, t: Math.max(same ? B.weather.t : 0, turns) };
  B.wxFx = w;   // 画面の 演出用
  for (const x of [...B.allies, ...B.enemies]) x.wx = x.tr && x.tr.wnone ? null : w;
  if (!quiet && log) log.push(`${WEATHER[w][1]}§l${same ? "天候は" : "天候が"} ${WEATHER[w][0]}${same ? "の まま つづく" : "に なった"}！§r${WEATHER[w][1]}（${turns >= 99 ? "ずっと" : turns + "ターン"}）§7 ${WEATHER[w][3]}`);
  else if (log) log.push(`${WEATHER[w][1]}天候: ${WEATHER[w][0]}§7 … ${WEATHER[w][3]}`);
}
function weatherTurn(B, log) {
  const W = B.weather; if (!W || W.t <= 0) return;
  const w = W.w;
  for (const f of [...B.allies, ...B.enemies]) {
    if (f.hp <= 0 || f.tr.wnone) continue;
    const aff = (f.aff && f.aff.ge) || [];
    if ((w === "sand" && !(aff.includes("earth") || aff.includes("steel") || f.fam === "golem" || (f.res && (f.res.earth > 0 || f.res.steel > 0))))
      || (w === "snow" && !(aff.includes("ice") || (f.res && f.res.ice > 0)))) {
      if (f.tr.wguard || f.tr.metal || cheatInv(B, f)) continue;
      const d = Math.max(1, Math.floor(f.mx.hp / 16)); f.hp = Math.max(1, f.hp - d);
      log.push(`${WEATHER[w][1]}${f.name}は ${WEATHER[w][0]}で ${d}の ダメージ`);
    }
    if (f.tr.wheal && f.tr.wheal[w] && f.hp < f.mx.hp) { const h = Math.min(f.mx.hp - f.hp, Math.max(1, Math.floor(f.mx.hp * f.tr.wheal[w]))); f.hp += h; log.push(`§a${f.name}は ${WEATHER[w][0]}の 加護で ${h} 回復した`); }
  }
  if (W.t < 99 && --W.t <= 0) {
    log.push(`§7${WEATHER[w][0]}が おさまった。`);
    B.weather = null; for (const x of [...B.allies, ...B.enemies]) x.wx = null;
    if (B.wbase) setWeather(B, B.wbase, 999, log, null, true);
  }
}
// ================= v2.9: 攻撃属性 =================
export const attrOf = (f, mv) => { const wt = mv.basic ? f.wtype : (mv.wtype || mv.wmove); return wt && WKIND && WKIND[wt] ? WKIND[wt].attr : null; };
export function attrMul(f, t, mv) { const a = attrOf(f, mv); if (!a || !t || !ATTR_FAM || !ATTR_FAM[a]) return 1; return ATTR_FAM[a][t.fam] || 1; }

// ================= v3.0 第63版: 相性を しらべる（戦闘中の 弱点表示）=================
// 技 → 相手 の 効き目（◎ばつぐん ○ふつう △いまひとつ ×無効 吸 吸収 反反射 鋼 ハガネ）
export function hitHint(f, t, mv) {
  if (!t || !mv || !(mv.mult || mv.f || mv.basic)) return "";
  try {
    if (willBounce(t, mv) >= 1) return "§5反";
    if (t.tr.metal && !metalHits(mv) && !(t.tr.metalBody && ["phys", "weapon", "special"].includes(effCat(mv)))) return "§8鋼";
    const r = resMulMv(t, mv, f), k = r * attrMul(f, t, mv) * (mv.cat && t.catg2 && t.catg2[mv.cat] > 0 ? 0.25 : mv.cat && t.catg && t.catg[mv.cat] > 0 ? 0.5 : 1);
    if (r < 0) return "§b吸"; if (r === 0) return "§8×";
    return k >= 1.2 ? "§a◎" : k <= 0.8 ? "§7△" : "§f○";
  } catch { return ""; }
}
const _pct = (x) => `${x > 0 ? "+" : ""}${Math.round(x * 100)}%`;
export function scoutLines(t, f = null, foe = false) {
  const L = [];
  const els = Object.keys(EL_NAME);
  const by = { weak: [], half: [], none: [], abs: [] };
  for (const e of els) { const r = resMul(t, e, f); if (r < 0) by.abs.push(EL_NAME[e]); else if (r === 0) by.none.push(EL_NAME[e]); else if (r > 1) by.weak.push(EL_NAME[e]); else if (r < 1) by.half.push(EL_NAME[e]); }
  L.push(`§l${t.name}§r §7Lv${t.lv} ${SPECIES[t.m?.sp]?.rank || ""}ランク・${t.m ? sizeOf(t.m) : "?"}サイズ・${SPECIES[t.m?.sp]?.famName || ""}  ${foe ? `§fHP ${Math.ceil(t.hp / Math.max(1, t.mx.hp) * 100)}%` : `§fHP ${t.hp}/${t.mx.hp}  MP ${t.mp}/${t.mx.mp}`}`);
  L.push(`§a弱点: §f${by.weak.join("・") || "なし"}  §7半減: §f${by.half.join("・") || "なし"}${by.none.length ? `  §8無効: §f${by.none.join("・")}` : ""}${by.abs.length ? `  §b吸収: §f${by.abs.join("・")}` : ""}`);
  const cat = Object.entries(t.tr.taken || {}).filter(([k, v]) => CATS[k] && v).map(([k, v]) => `${CATS[k]}${_pct(v)}`);
  if (cat.length) L.push(`§7受ける ダメージ: §f${cat.join("・")}`);
  const now = [];
  for (const [c, n] of Object.entries(t.refl || {})) if (n > 0 && CATS[c]) now.push(`§5${CATS[c]}を 反射`);
  for (const [c, n] of Object.entries(t.reflEl || {})) if (n > 0) now.push(`§5${EL_NAME[c] || c}を 反射`);
  for (const [c, n] of Object.entries(t.catg2 || {})) if (n > 0 && CATS[c]) now.push(`§9${CATS[c]} 激減`);
  for (const [c, n] of Object.entries(t.catg || {})) if (n > 0 && CATS[c] && !(t.catg2 && t.catg2[c] > 0)) now.push(`§9${CATS[c]} 軽減`);
  for (const [c, p] of Object.entries(t.tr.barrierp || {})) if (p && CATS[c]) now.push(`§5${CATS[c]}を ${Math.round(p * 100)}%で 反射`);
  if (t.tr.metal) now.push(t.tr.metalBody ? "§8ハガネボディ（あとから）" : "§8ハガネ族（会心・物理系・武系が 効く）");
  if (t.tr.critguard) now.push("§7会心を 受けない");
  if (now.length) L.push(now.join("§r・"));
  const ail = Object.entries(t.ail || {}).filter(([, v]) => v > 0).map(([k]) => AIL_NAME[k] || k);
  if (ail.length) L.push(`§c状態異常: §f${ail.join("・")}`);
  const buf = Object.entries(t.buf || {}).filter(([, v]) => v).map(([k, v]) => `${ST_NAME[k] || k}${v > 0 ? "§a+" : "§c"}${v}§f`);
  if (buf.length) L.push(`§e能力の 段階: §f${buf.join(" ")}`);
  return L;
}
export function scoutText(B, view = "a") {
  const mine = view === "a" ? B.allies : B.enemies, theirs = view === "a" ? B.enemies : B.allies;
  const L = ["§l§c― 相手 ―"];
  for (const t of theirs.filter((x) => x.hp > 0)) L.push(...scoutLines(t, null, true), "");
  L.push("§l§a― 味方 ―");
  for (const t of mine.filter((x) => x.hp > 0)) L.push(...scoutLines(t), "");
  const order = [...B.allies, ...B.enemies].filter((x) => x.hp > 0).sort((a, b) => (b.tr.first ? 1 : 0) - (a.tr.first ? 1 : 0) || stat(b, "spd") - stat(a, "spd"));
  L.push("§l§e― 行動順の 目安（走力。技の 先制度で かわる）―", order.map((x, i) => `${i + 1}. ${(x.side === view) ? "§a" : "§c"}${x.name}§7(${stat(x, "spd")})`).join("§r  "));
  L.push("", "§7技の 効き目: §a◎ばつぐん §f○ふつう §7△いまひとつ §8×無効 §b吸 吸収 §5反 反射 §8鋼 ハガネ（ほぼ 通らない）");
  return L.join("\n");
}
export function weakBrief(B, view = "a") { try {
  const theirs = (view === "a" ? B.enemies : B.allies).filter((x) => x.hp > 0);
  return theirs.map((t) => { const w = Object.keys(EL_NAME).filter((e) => resMul(t, e) > 1).map((e) => EL_NAME[e]); return `${t.name}: ${w.length ? "§a" + w.join("・") : "§7なし"}${t.tr.metal ? " §8(ハガネ)" : ""}§r`; }).join("  ");
  } catch { return ""; } }
// v3.0 第63版: ダメージの 目安（相手の 最大HPの 何%か。乱数・会心は ふくまない）
export function estPct(f, t, mv) { try { if (!t || !mv || !(mv.mult || mv.basic)) return null; const d = Math.max(0, estOne(f, t, mv)); return Math.min(100, Math.round(d / Math.max(1, t.mx.hp) * 100)); } catch { return null; } }
