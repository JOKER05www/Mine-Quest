/* 第126版: 本の しくみ（物語 307話の 進み・案内・古い セーブの 移し替え）。書き方の 手引きは /tmp/zf/bk_api.md
   ・進み: s.bk = BKID の 位置ごとの 済み印（base32。1文字 5話）。s.bks = 見のがした（とばした・移し替えた）印。s.bkv = 移し替え済み
   ・次の 話: s.mq の あいだに 流れる 自由な 話（mq も 常世の 区も ない 話）の うち、まだの 最前（BKID の 順）。s.bkp に 覚える（毎回 O(1)）
   ・MQ の 段の 話は mqOver（saga.js の MQ_OVR）が 段の 中で 流す。常世の 区の 話は tkOver（tokoyo.js の TK_OVR）
   ・章が 書かれて いない（bkAdd が 空）あいだは 今までの 物語（saga.js の MQ・sagaep.js の 地方の 話）が そのまま 動く。印だけ 進みに 合わせて つける
   ・古い 話（第125版 ep_rX.js）を 引きとった 新しい 話が 登録されると、古い 話は 止まる（OLD2NEW か e.old。止めない ときは e.keepOld）*/
import { world, system } from "@minecraft/server";
import { BOOK, BKID, EP, OLDEP, OLD2NEW, EPXSET, MQ2BK, FLAGFIX, CHEP, GATE } from "./book.js";
import { CH, CHUI, chGet, chIs, chV, chAuto, chPick } from "./choice.js";
import { MQ, MQ_OVR, EP_HOOK, GOAL_HOOKS, SGK } from "./saga.js";
import { K as EK, EP_OFF } from "./sagaep.js";
import { qs, QS_HOOK } from "./quest.js";
import { load, save } from "./store.js";
import { busy, choose, wait, notice, confirm, barNote } from "./ui.js";
import { cineCard, closeWide, clearSkip } from "./talk.js";
import { stageBegin, stageEnd } from "./stagecore.js";
import { canFight } from "./core.js";
import { ITEMS } from "./data.js";
import { facAt, fac } from "./epfac.js";
import { RU_GATE } from "./ruinsarea.js";
import { TK_OVR } from "./tokoyo.js";
import { ruSite } from "./ruins.js";
import { STORY_EXTRA } from "./story.js";
import { PG_GATE } from "./postgame.js";
import { CAST_HOOK } from "./cast.js";

/* ---------- 表 ---------- */
const N = BKID.length, IDX = new Map(BKID.map((x, i) => [x, i]));
const BOOKC = new Map(BOOK.map((c) => [c.id, c]));
const chOf = (id) => String(id).slice(0, 3);
const isUra = (id) => id[0] === "u";
const LISTS = [[], [], []];   /* 本編・裏1〜7（地上）・裏8〜15（常世）。穴は この 中で うめる */
BKID.forEach((id, i) => LISTS[!isUra(id) ? 0 : +id.slice(1, 3) <= 7 ? 1 : 2].push(i));
const LIST_OF = new Int8Array(N); LISTS.forEach((L, k) => L.forEach((i) => (LIST_OF[i] = k)));
const CHBYEP = {}; for (const [c, ep] of Object.entries(CHEP)) (CHBYEP[ep] = CHBYEP[ep] || []).push(c);
const FIXBYEP = {}; for (const [fl, ep] of FLAGFIX) (FIXBYEP[ep] = FIXBYEP[ep] || []).push(fl);
const EPXN = new Set(["mimiDad"]); for (const L of Object.values(EPXSET)) for (const k of L) EPXN.add(k);
const CLEAR = new Set(["hakuStone", "ordoMask"]);   /* 時期が 後ろへ ずれた 印だけ、話が まだなら 移し替えで 外す（ほかの 印は 外さない）*/
const REV = {}; for (const [o, n] of Object.entries(OLD2NEW)) REV[n] = o;
const upTo = (c) => { const o = []; const k = (c[0] === "u" ? 20 : 0) + +c.slice(1); BKID.forEach((id, i) => { if (isUra(id) && 20 + +id.slice(1, 3) <= k) o.push(i); }); return o; };
const UP = { u02: upTo("u02"), u04: upTo("u04"), u07: upTo("u07"), u08: upTo("u08"), u15: upTo("u15") };
const RULAST = {}; BKID.forEach((id, i) => { const r = EP[id] && EP[id].ru; if (r && typeof r[0] === "number") RULAST[r[0]] = i; });

/* ---------- 印（base32）---------- */
const B32 = "0123456789abcdefghijklmnopqrstuv";
const str = (s, k) => (typeof s[k] === "string" && /^[0-9a-v]*$/.test(s[k]) ? s[k] : "");
const getB = (s, k, i) => { const c = str(s, k)[(i / 5) | 0]; return !!c && ((B32.indexOf(c) >> i % 5) & 1) === 1; };
function putB(s, k, i, on) {
  let b = str(s, k); const j = (i / 5) | 0; if (b.length <= j) { if (!on) return; b = b.padEnd(j + 1, "0"); }
  const v = on ? B32.indexOf(b[j]) | (1 << i % 5) : B32.indexOf(b[j]) & ~(1 << i % 5); s[k] = b.slice(0, j) + B32[v] + b.slice(j + 1);
}
export function bkHas(s, id) { const i = IDX.get(id); return i !== undefined && !!s && typeof s === "object" && getB(s, "bk", i); }
/* 済みの 印だけ（ほうび・印・だいじなものは つけない。点検・道具用）*/
export function bkSet(s, id) { const i = IDX.get(id); if (i === undefined || !s || typeof s !== "object" || getB(s, "bk", i)) return false; putB(s, "bk", i, true); delete s.bkp; return true; }
export const bkMissed = (s, id) => { const i = IDX.get(id); return i !== undefined && getB(s, "bks", i); };

/* ---------- 登録 ---------- */
export const BKE = new Map();   /* 話の id → 話（bkAdd で 登録した もの）*/
const CHREG = new Map();   /* 章 → [話の id]（空 = まだ 書かれて いない 章）*/
const FREE = {};   /* s.mq → [自由な 話の 位置]（順に）*/
let SIG = "0";
const isFree = (e) => typeof e.mq !== "number" && !(Array.isArray(e.ru) && e.ru[0] !== "walk");
export const chActive = (c) => !!(CHREG.get(c) || []).length;
export function bkOff(oldId, newId) { EP_OFF.set(oldId, (d) => { try { return bkHas(qs(d), newId); } catch { return false; } }); }
/* 話の 形: { id, n?, t, pre?, place(p) → {x, z, nm, y?, r?}, fac?, hint, syn?, F?, ans?, keys?, battles?, set?, stage?, snd?, old?, keepOld?, skip(s)?, run: async (p, d, K) => true } */
export function bkAdd(ch, list = []) {
  if (!BOOKC.has(ch)) console.warn(`[MonsterRPG] bkAdd: 章 ${ch} は 本の 表に ない`);
  const L = CHREG.get(ch) || []; CHREG.set(ch, L);
  for (const e0 of list || []) {
    const id = e0 && e0.id; if (!id || !IDX.has(id) || BKE.has(id)) { console.warn(`[MonsterRPG] bkAdd: id が ない・表に ない・2回目 ${id}`); continue; }
    if (chOf(id) !== ch) console.warn(`[MonsterRPG] bkAdd: ${id} は 章 ${ch} の 話で ない`);
    const B = EP[id] || {}, x = { c: ch, pre: B.pre, r: B.r, pl: B.pl, ...(typeof B.mq === "number" ? { mq: B.mq } : {}), ...(B.ru ? { ru: B.ru } : {}), ...e0 };
    if (!x.n) x.n = +id.slice(4); if (!x.t) x.t = B.pl || id; if (!x.hint) x.hint = `§f${B.pl || ""}へ 行こう`;
    if (typeof x.run !== "function") x.run = async () => true;
    BKE.set(id, x); L.push(id);
    const old = x.old !== undefined ? x.old : REV[id]; if (old && !x.keepOld) bkOff(old, id);   /* 古い 話を 止める（二重に 流さない）*/
    if (typeof x.mq === "number" && !MQ_OVR[x.mq]) mqOver(x.mq);   /* 段の 話: 書かなければ 順に 流すだけ */
    if (isFree(x) && typeof x.pre === "number") { const F = FREE[x.pre] || (FREE[x.pre] = []); F.push(IDX.get(id)); F.sort((a, b) => a - b); }
  }
  let h = 0; for (const id of BKE.keys()) h = (h * 31 + IDX.get(id) + 1) % 1000003; SIG = `${BKE.size}.${h}`;
}

/* ---------- 門・次の 話 ---------- */
export const tokoyoOn = () => !!RU_GATE.on;
const gateOk = (s, c) => { const g = GATE[c] || ""; return !g || (g === "ending" && !!s.ending) || (g === "tokoyo" && !!s.ending && tokoyoOn()); };
const gk = (s) => (s.ending ? 1 : 0) + (tokoyoOn() ? 2 : 0);
function nextIdx(s) {
  const m = s.mq ?? 0, g = gk(s), c = s.bkp;
  if (Array.isArray(c) && c[1] === m && c[2] === g && c[3] === SIG && (c[0] < 0 || !getB(s, "bk", c[0]))) return c[0];
  let r = -1; for (const i of FREE[m] || []) { const id = BKID[i]; if (getB(s, "bk", i) || !gateOk(s, chOf(id))) continue; r = i; break; }
  s.bkp = [r, m, g, SIG]; return r;
}
const pendingE = (s) => { if (!BKE.size) return null; const i = nextIdx(s); return i < 0 ? null : BKE.get(BKID[i]) || null; };
export function bkNext(s) { try { const e = pendingE(s); return e ? e.id : null; } catch { return null; } }
export const bkPending = (d) => { try { return pendingE(qs(d)); } catch { return null; } };
/* 常世パックが ない 人は 裏6 の あと（MQ27 = 裏7 エンマ）で 待つ。裏6・裏7 の 章が 書かれて いる か、裏6 を 終えて いる とき */
const packGate = (s) => (s.mq ?? 0) === 27 && !!s.ending && !s.enmaClear && !tokoyoOn() && (chActive("u06") || chActive("u07") || bkHas(s, "u06e8"));
const PACK_MSG = "§d続きは 追加ストーリー「常世編」で。§7（常世パックを 入れると、閻魔の 神殿へ 進める。それまで ヒロインの 石は 眠った まま）";
PG_GATE.enma = (d) => { try { return packGate(qs(d)) ? PACK_MSG : ""; } catch { return ""; } };
PG_GATE.bookCh = (c) => { for (const id of BKE.keys()) if (id.startsWith(c)) return true; return false; };   /* 第126版(I1/SB): 裏2 が 書かれて いれば カゲツは 鍔を 渡さない */
{ const od = CAST_HOOK.done; CAST_HOOK.done = (d, id) => (IDX.has(id) ? bkHas(qs(d), id) : od ? od(d, id) : true); }   /* 第126版(I1/UA): 町の 人の from に 本の 話の id も 使える */

/* ---------- 済みに する ---------- */
function setFl(s, fl) { if (EPXN.has(fl)) { if (!s.epx || typeof s.epx !== "object") s.epx = {}; s.epx[fl] = 1; } else s[fl] = 1; }
function clrFl(s, fl) { delete s[fl]; if (s.epx && typeof s.epx === "object") delete s.epx[fl]; }
/* o: { skip: とばした（見のがした 印・skip(s)・だいじなもの）, sync: 今までの 物語に 合わせた だけ（印は 今までの 物語が つける）, p, d } */
function mark(s, id, o = {}) {
  const i = IDX.get(id); if (i === undefined || !bkSet(s, id)) return false;
  const e = BKE.get(id);
  if (o.skip) { putB(s, "bks", i, true); if (e && e.skip) try { e.skip(s); } catch {} }
  const X = EPXSET[id]; if (X || (e && e.set)) { if (!s.epx || typeof s.epx !== "object") s.epx = {}; for (const k of X || []) s.epx[k] = 1; if (e && e.set) Object.assign(s.epx, e.set); }
  for (const c of CHBYEP[id] || []) chAuto(s, c);   /* 場面で えらばなかった（とばした・古い セーブ）ときは def */
  for (const fl of FIXBYEP[id] || []) if ((!o.sync || e || CLEAR.has(fl)) && !(fl === "glove" && chIs(s, "c11", "r"))) setFl(s, fl);   /* 今までの 物語に 合わせる ときは、移し替えで 外した 印（CLEAR）だけ */
  if (e && e.keys) for (const k0 of e.keys) { const k = typeof k0 === "string" ? k0 : k0 && k0.id; if (!k || !ITEMS[k] || ITEMS[k].kind !== "key") continue; if (o.p && o.d) { if (!(s.keys || []).includes(k)) try { SGK.giveKey(o.p, o.d, k); } catch {} } else if (!(s.keys || []).includes(k)) s.keys = [...(Array.isArray(s.keys) ? s.keys : []), k]; }
  if (s.bkPaid === id) delete s.bkPaid;
  if (s.bkHold && s.bkHold.id === id) delete s.bkHold;
  if (s.bkSpot && s.bkSpot.id === id) delete s.bkSpot;
  return true;
}
function started(s, i) {
  if ((s.mqHold && s.mqHold.i === i) || s.estSeen === i || s.chSeen === i || s.mqPaid === i) return true;
  const st = MQ[i]; if (st && st.seal !== undefined && Array.isArray(s.bsg) && s.bsg.includes(st.seal)) return true;
  for (const k in s) if (k.startsWith(`w_mq${i}_`)) return true;
  return false;
}
/* 済みの はずの 話（位置の 集合）。mig: 古い セーブの 移し替え（段を 始めて いれば その 段の 前の 話も）*/
function target(s, mig) {
  const T = new Set(), m = Number.isFinite(s.mq) ? s.mq : -1, go = mig && m >= 0 && started(s, m);
  for (let i = 0; i < N; i++) { const B = EP[BKID[i]]; if (!B) continue; if (typeof B.mq === "number" ? B.mq < m : B.pre < m || (go && B.pre === m)) T.add(i); }
  if (s.ending) for (const i of LISTS[0]) T.add(i);
  if (s.ep && typeof s.ep === "object" && !Array.isArray(s.ep)) for (const [r, L] of Object.entries(OLDEP)) { const n = Math.max(0, Math.min(L.length, Math.floor(Number(s.ep[r]) || 0))); for (const o of L.slice(0, n)) { const i = IDX.get(OLD2NEW[o]); if (i !== undefined && (mig || !BKE.has(BKID[i]))) T.add(i); } }
  const add = (L) => L.forEach((i) => T.add(i));
  if (s.hiltGot) add(UP.u02); if (s.musashiJoin) add(UP.u04); if (s.enmaClear) add(UP.u07);
  const r = s.ru && typeof s.ru === "object" ? s.ru : null;
  if (r) { if (r.st >= 2) add(UP.u08); if (r.st >= 4) add(UP.u15); if (Array.isArray(r.b)) for (const b of r.b) if (RULAST[b] !== undefined) T.add(RULAST[b]); }
  /* 穴なし: 後ろが 済みなら 前も（本編・裏1〜7・裏8〜15 ごと）*/
  for (const L of LISTS) { let last = -1; for (let k = L.length - 1; k >= 0; k--) if (T.has(L[k])) { last = k; break; } for (let k = 0; k < last; k++) T.add(L[k]); }
  return T;
}
/* 古い セーブ（1回だけ。s.bkv）: 進みから 済みの 話を 決め、印・選択（def）・だいじなもの を そろえる。ほうびは 出さない。s.ep・s.epx は 残す */
export function bkMigrate(s, d = null) {
  if (!s || typeof s !== "object" || s.bkv) return false;
  s.bkv = 1;
  if (!Number.isFinite(s.mq) && !s.ending) return true;   /* 新しい ゲーム */
  const T = [...target(s, true)].sort((a, b) => a - b);
  for (const i of T) mark(s, BKID[i], { skip: true });
  for (const [fl, ep] of FLAGFIX) { if (bkHas(s, ep)) { if (!(fl === "glove" && chIs(s, "c11", "r"))) setFl(s, fl); } else if (CLEAR.has(fl)) clrFl(s, fl); }
  s.bkk = syncKey(s);
  return true;
}
QS_HOOK.mig = (s, d) => bkMigrate(s, d);
/* 今までの 物語（MQ・地方の 話）が 進んだ ぶんの 印（書かれて いない 話は 印だけ。書かれた 話は 段を 越えた ときだけ とばした ことに）*/
const syncKey = (s) => { const r = s.ru && typeof s.ru === "object" ? s.ru : null; return `${s.mq ?? -1}|${s.ending ? 1 : 0}${s.hiltGot ? 1 : 0}${s.musashiJoin ? 1 : 0}${s.enmaClear ? 1 : 0}|${s.ep && typeof s.ep === "object" ? Object.values(s.ep).join(",") : ""}|${r ? `${r.st | 0}.${Array.isArray(r.b) ? r.b.length : 0}` : ""}`; };
export function bkSync(s) {
  if (!s || !s.bkv) return false; const k = syncKey(s); if (s.bkk === k) return false; s.bkk = k;
  const m = Number.isFinite(s.mq) ? s.mq : -1; let ch = false;
  for (const i of target(s, false)) {
    const id = BKID[i]; if (getB(s, "bk", i)) continue;
    const e = BKE.get(id);
    if (e) { const own = typeof e.mq === "number" ? e.mq < m : e.pre < m; if (!own && !(s.ending && LIST_OF[i] === 0)) continue; ch = mark(s, id, { skip: true }) || ch; }
    else ch = mark(s, id, { sync: true }) || ch;
  }
  return ch;
}

/* ---------- 名前・案内 ---------- */
export const chLabel = (c) => { const b = BOOKC.get(c); return !b ? "" : b.part === "ura" ? `裏${b.n}章 ${b.t}` : `第${b.n}章 ${b.t}`; };
const epLabel = (e) => `§d${e.n}話 ${e.t}§r `;
function curCh(s) {
  const e = pendingE(s); if (e) return e.c;
  for (const id of MQ2BK[s.mq ?? 0] || []) if (!bkHas(s, id)) return chOf(id);
  for (let i = N - 1; i >= 0; i--) if (getB(s, "bk", i)) return chOf(BKID[i]);
  return "b01";
}
const stepE = (s) => { for (const id of MQ2BK[s.mq ?? 0] || []) if (!bkHas(s, id)) return BKE.get(id) || null; return null; };
EP_HOOK.chapter = (d) => { const s = qs(d), c = curCh(s); return chActive(c) ? chLabel(c) : ""; };
EP_HOOK.book = (d) => {
  if (![...CHREG.values()].some((L) => L.length)) return "";   /* 章が 1つも 書かれて いない あいだは 今までの あらすじ だけ */
  const s = qs(d), cur = curCh(s), seen = new Set([cur]); for (let i = 0; i < N; i++) if (getB(s, "bk", i)) seen.add(chOf(BKID[i]));
  const L = ["§l§e章の 一覧"]; for (const b of BOOK) { if (b.part === "ura" && !s.ending) continue; const nm = chLabel(b.id); L.push(seen.has(b.id) ? `${b.id === cur ? "§a" : "§f"}${nm}${b.id === cur ? " §7（いま ここ）" : ""}` : `§8${nm.split(" ")[0]} ？？？`); }
  return L.join("\n");
};

/* ---------- 演出の 部品（K）: sagaep.js の K と SGK に、本の 部品を 足す ---------- */
const RPL = new Set();   /* 見のがした 頁を 読みかえして いる 人（ほうび・印 なし）*/
export const K = {
  ...EK,
  load, save, qs, choose, card: cineCard, wait,
  /* ほうび（1回だけ。読みかえしでは 出ない）*/
  pay(p, e, g, items = []) { if (RPL.has(p.id)) return []; const d = load(p); if (!d) return []; const s = qs(d); if (s.bkPaid === e.id || bkHas(s, e.id)) return []; const got = SGK.reward(p, d, g, items, false); s.bkPaid = e.id; save(p, d); return got; },
  reward: (p, ...a) => (RPL.has(p.id) ? [] : SGK.reward(p, ...a)),
  giveKey: (p, ...a) => (RPL.has(p.id) ? undefined : SGK.giveKey(p, ...a)),
  key(p, k) { if (RPL.has(p.id) || !ITEMS[k]) return false; const d = load(p); if (!d) return false; if (!(qs(d).keys || []).includes(k)) { SGK.giveKey(p, d, k); save(p, d); } return true; },
  setFlag: (p, k, v = 1) => (RPL.has(p.id) ? undefined : EK.setFlag(p, k, v)),
  replay: (p) => RPL.has(p.id),
  /* 選択（choice.js）*/
  pick: (p, id) => (RPL.has(p.id) ? Promise.resolve(chGet(qs(load(p) || {}), id) || (CH[id] && CH[id].def) || "") : chPick(p, id, K)),
  ch: (p, id) => { const d = load(p); return d ? chGet(qs(d), id) : ""; }, chGet, chIs, chV, CH,
  done: (p, id) => { const d = load(p); return !!d && bkHas(qs(d), id); },
  /* 場所 */
  facAt, fac: (p, key, kind, r, y0) => fac(K, p, key, kind, r, y0), ruSite,
  ep: (id) => EP[id], book: (c) => BOOKC.get(c),
  /* 段・区の 中で 話を 1つ 流す（舞台は 今の まま）*/
  play: (p, id) => stepEp(p, id),
};
Object.assign(CHUI, { load, save, qs, choose, card: cineCard, wait });

/* ---------- 流す ---------- */
async function core(p, e) {
  let done = false, later = false; SGK.MQASK.add(p.id); SGK.MQRUN.add(p.id); SGK.MQSTALE.delete(p.id); const tok = {}; SGK.MQTOK.set(p.id, tok); let stale = false;
  try { done = (await e.run(p, load(p), K)) === true; } catch (x) { if (x === SGK.LATER) later = true; else console.warn(`[MonsterRPG] bk ${e.id}: ${x} ${x?.stack || ""}`); }
  finally { stale = SGK.MQTOK.get(p.id) !== tok; if (!stale) { SGK.MQTOK.delete(p.id); SGK.MQASK.delete(p.id); SGK.MQRUN.delete(p.id); } if (!stale || !SGK.MQRUN.has(p.id)) SGK.heroTmpClean(p); }
  return { done, later, stale };
}
function finishP(p, e) { const d = load(p); if (!d) return; const s = qs(d); mark(s, e.id, { p, d }); save(p, d); if (e.id === "u06e8" && !tokoyoOn()) try { p.sendMessage(PACK_MSG); } catch {} }
/* 段・区の 中から（saga の 段の 舞台の まま）。書かれて いない 話は とばした ことに */
async function stepEp(p, id) {
  const d = load(p); if (!d) return false; const s = qs(d);
  if (bkHas(s, id)) return true;
  const e = BKE.get(id); if (!e) { mark(s, id, { skip: true }); save(p, d); return true; }
  if (RPL.has(p.id)) return (await e.run(p, d, K)) === true;
  if (s.bkSeen !== id) { s.bkSeen = id; save(p, d); }
  const ok = (await e.run(p, load(p) || d, K)) === true || qs(load(p) || d).bkPaid === id;
  if (ok) finishP(p, e);
  return ok;
}
/* MQ 段 i の run を 差しかえる。fn(p, d, K, c) → true で 段が 済む。c = { i, ids, undone, play(id), playAll(), old() }
   o.cond(p, d, K): 段の 話が もう 全部 済んで いる（古い 話を まとめた 段・移し替え）ときに 待つ 条件（マスター戦など）。なければ 今までの run
   o.spot(p, d) → { x, z, nm, key }: 段の 始まる 場所（MQ の spot と 同じ）*/
export function mqOver(i, fn = null, o = {}) {
  const st = MQ[i]; if (!st) { console.warn(`[MonsterRPG] mqOver: 段 ${i} は ない`); return; }
  const old = st.run, ids = MQ2BK[i] || [];
  MQ_OVR[i] = async (p, d, st2) => {
    const s = qs(load(p) || d), undone = ids.filter((id) => !bkHas(s, id));
    const oldRun = () => (st2 && st2.run ? st2.run : old)(p, load(p) || d);
    if (!undone.length) return o.cond ? o.cond(p, load(p) || d, K) : oldRun();   /* 場面は とばし、条件だけ */
    const c = { i, ids, undone, old: oldRun, play: (id) => stepEp(p, id), async playAll() { for (const id of ids) if (!(await stepEp(p, id))) return false; return true; } };
    const r = fn ? await fn(p, load(p) || d, K, c) : await c.playAll();
    if (r === true) { const dd = load(p); if (dd) { const ss = qs(dd); for (const id of ids) if (!bkHas(ss, id)) mark(ss, id, { skip: !BKE.has(id) }); save(p, dd); } }
    return r;
  };
  if (o.spot) { st.spot = o.spot; delete st.altv; if (st.alt) st.alt.spot = o.spot; }
}
/* 常世の 区 i（0〜14・記録塔 15）の 場面を 差しかえる。o.pre / o.post = async (p, d, K, c) → c = { i, n, info, orig }（orig() で 今の 場面）*/
export function tkOver(i, o = {}) {
  TK_OVR[i] = {
    ...(o.pre ? { pre: (p, j, orig) => o.pre(p, load(p), K, { i: j, orig }) } : {}),
    ...(o.post ? { post: (p, j, n, orig) => o.post(p, load(p), K, { i: j, n, info: n, orig }) } : {}),
  };
}
/* 1話を それだけで 流す（点検・見のがした 頁）。o.replay: ほうび・印 なし（終わったら 記録を もとに もどす）。o.at: 舞台の 場所 */
export async function bkPlay(p, id, o = {}) {
  const e = BKE.get(id); if (!e || SGK.EVT.has(p.id)) return false;
  SGK.EVT.add(p.id); busy.add(p.id);
  let res = false; const d0 = load(p), snap = o.replay && d0 ? JSON.stringify(qs(d0)) : null;
  if (o.replay) RPL.add(p.id);
  try {
    await stageBegin(p, { lazy: true, move: false });
    const at = o.at || { x: p.location.x, y: p.location.y, z: p.location.z }, fq = e.fac ? facAt(e.fac, at, 60) : null;
    await stageBegin(p, { anchor: at, move: true, noEst: true, ...(fq ? { face: fq, bshot: fq } : {}), ...(e.stage || {}) });
    const r = await core(p, e); res = r.done;
    await closeWide(p);
  } catch (x) { console.warn(`[MonsterRPG] bkPlay ${id}: ${x}`); }
  finally { try { stageEnd(p, true); } catch {} SGK.heroTmpClean(p); SGK.EVT.delete(p.id); busy.delete(p.id); try { clearSkip(p); } catch {} RPL.delete(p.id); }
  const d = load(p);
  if (d && snap) { const s0 = JSON.parse(snap); putB(s0, "bks", IDX.get(id), false); d.story = s0; save(p, d); }
  else if (d && (res || qs(d).bkPaid === id)) { res = true; finishP(p, e); }
  return res;
}
export const bkRun = bkPlay;

/* ---------- 場所 ---------- */
function spotFor(p, d, e) {
  const s = qs(d); if (s.bkSpot && s.bkSpot.id === e.id) return s.bkSpot;
  let q = null; try { q = e.place ? e.place(p) : null; } catch {}
  if (!q || !Number.isFinite(q.x) || !Number.isFinite(q.z)) q = { x: p.location.x, z: p.location.z, y: p.location.y, nm: e.pl || "" };   /* 場所が 書かれて いない 話は 今 いる 所で */
  s.bkSpot = { id: e.id, i: `bk:${e.id}`, x: Math.floor(q.x), y: Number.isFinite(q.y) ? Math.floor(q.y) : null, z: Math.floor(q.z), nm: q.nm || e.pl || "", np: 1, r: q.r || 4, ...(Number.isFinite(q.fx) ? { fx: q.fx, fz: q.fz } : {}) };
  save(p, d); return s.bkSpot;
}
function start(p, e, sp) {
  SGK.runEvt(p, async () => {
    const dd = load(p); if (!dd) return;
    if (qs(dd).bkSeen !== e.id) { qs(dd).bkSeen = e.id; save(p, dd); SGK.big(p, `§6§l${chLabel(e.c)}`, `${e.n}話 ${e.t}`, e.snd === undefined ? "ui.toast.challenge_complete" : e.snd); await wait(50); }
    const at = { x: sp.x + 0.5, y: typeof sp.y === "number" ? sp.y : p.location.y, z: sp.z + 0.5 };
    { const fq = (e.fac ? facAt(e.fac, at, 60) : null) || (Number.isFinite(sp.fx) ? { x: sp.fx, z: sp.fz } : null); await stageBegin(p, { anchor: at, move: true, noEst: true, ...(fq ? { face: fq, bshot: fq } : {}), ...(e.stage || {}) }); }
    { const dh = load(p) || dd; if (qs(dh).introDone && !qs(dh).hero && !(await SGK.heroJoin(p))) return; }
    const r = await core(p, e); if (r.stale) return;
    if (r.later) SGK.laterClean(p);
    SGK.SPAWNED.delete(p.id);
    const d2 = load(p); if (!d2) return; const s2 = qs(d2); const done = r.done || s2.bkPaid === e.id;
    const cur = pendingE(s2);
    if (cur && cur.id === e.id) { if (done) { finishP(p, e); return; } s2.bkHold = { id: e.id }; if (!r.later) s2.bkLose = { id: e.id, n: (s2.bkLose && s2.bkLose.id === e.id ? s2.bkLose.n : 0) + 1 }; save(p, d2); }
    if (!done) try { p.sendMessage("§7準備が できたら ガイドブック ＞ ストーリー ＞「物語の 戦いに 再挑戦」を えらぼう。§8（右上の 案内が 場所を 教えて くれる）"); } catch {}
  });
}
function replayStart(p, id) {
  SGK.runEvt(p, async () => {
    const e = BKE.get(id); if (!e) return; const d0 = load(p); if (!d0) return; const snap = JSON.stringify(qs(d0));
    RPL.add(p.id);
    try { SGK.big(p, `§7§l見のがした 頁`, `${chLabel(e.c)} ${e.n}話 ${e.t}`, "item.book.page_turn"); await wait(40); const at = { x: p.location.x, y: p.location.y, z: p.location.z }; await stageBegin(p, { anchor: at, move: true, noEst: true, ...(e.stage || {}) }); await core(p, e); }
    finally { RPL.delete(p.id); const d = load(p); if (d) { const s0 = JSON.parse(snap); putB(s0, "bks", IDX.get(id), false); d.story = s0; save(p, d); } }
  });
}

/* ---------- 毎秒（saga.js の step から。今までの 物語の 前に 見る）---------- */
const O = { ...EP_HOOK };   /* 第125版の 地方の 話（sagaep.js）*/
const NOTE = new Map();
EP_HOOK.step = (p, d, c) => {
  const s = qs(d);
  if (bkSync(s)) save(p, d);
  if (s.bkReplay) { const id = s.bkReplay; delete s.bkReplay; save(p, d); if (BKE.has(id) && canFight(d)) { replayStart(p, id); return 2; } }
  const e = pendingE(s);
  if (!e) {
    if (packGate(s)) { const t = Date.now(); if (t - (NOTE.get(p.id) || 0) > 30000) { NOTE.set(p.id, t); try { barNote(p).setActionBar(PACK_MSG); } catch {} } return 1; }
    return O.step ? O.step(p, d, c) : 0;
  }
  let dirty = false;
  if (!s.bkT || s.bkT.id !== e.id) { s.bkT = { id: e.id, t: Date.now() }; dirty = true; }
  if (s.bkHold && s.bkHold.id !== e.id) { delete s.bkHold; dirty = true; }
  if (s.bkPaid === e.id) { mark(s, e.id, { p, d }); save(p, d); return 1; }   /* ほうびを わたした あとで 落ちた */
  if (dirty) save(p, d);
  if (s.bkHold || !canFight(d)) return 1;
  const sp = spotFor(p, d, e); if (!sp) return 1;
  const l = p.location;
  if (Math.hypot(sp.x + 0.5 - l.x, sp.z + 0.5 - l.z) > sp.r || (typeof sp.y === "number" && Math.abs(sp.y - l.y) > 6)) { const y0 = sp.y; SGK.mqMarker(p, sp); if (y0 !== sp.y) save(p, d); return 1; }
  if (!SGK.steady(p)) return 1;
  if (typeof sp.y === "number") SGK.mqMarkerClear(sp);
  start(p, e, { ...sp });
  return 2;
};
EP_HOOK.hint = (d, full = false) => {
  const s = qs(d), e = pendingE(s); if (e) return `${full ? epLabel(e) : ""}${e.hint}`;
  if (packGate(s)) return PACK_MSG;
  const m = stepE(s); if (m && m.hint) return `${full ? epLabel(m) : ""}${m.hint}`;
  return O.hint ? O.hint(d, full) : "";
};
EP_HOOK.block = (d, k) => { const e = pendingE(qs(d)); if (e && (e.pre ?? 0) <= k) return true; return O.block ? O.block(d, k) : false; };
EP_HOOK.skip = (p, d) => { const s = qs(d), e = pendingE(s); if (!e) return O.skip ? O.skip(p, d) : false; mark(s, e.id, { skip: true, p, d }); return true; };
EP_HOOK.held = (d) => { const s = qs(d), e = pendingE(s); if (e) return !!(s.bkHold && s.bkHold.id === e.id); return O.held ? O.held(d) : false; };
EP_HOOK.retry = (p, d) => { const s = qs(d), e = pendingE(s); if (!e) return O.retry ? O.retry(p, d) : null; if (!s.bkHold || s.bkHold.id !== e.id) return null; delete s.bkHold; save(p, d); return `§aもう一度 挑む 準備が できた。§f${e.hint} §7（その 場所へ 行くと 始まる）`; };
EP_HOOK.fix = (p, d) => {
  const s = qs(d), e = pendingE(s); if (!e) return O.fix ? O.fix(p, d) : null; let sp = null; try { sp = spotFor(p, d, e); } catch {}
  return { i: s.mq ?? 0, st: { r: e.r, hint: e.hint, at: "ep" }, need: true, sp, lose: s.bkLose && s.bkLose.id === e.id ? s.bkLose.n : 0, mins: s.bkT && s.bkT.id === e.id ? Math.floor((Date.now() - s.bkT.t) / 60000) : 0, canSkip: true, post: false, ep: e.id };
};
EP_HOOK.reset = (p, d) => {
  const s = qs(d), out = [];
  if (s.bkSpot) { if (typeof s.bkSpot.y === "number") SGK.mqMarkerClear(s.bkSpot); delete s.bkSpot; out.push("物語の 話の 目印を 選びなおした"); }
  if (s.bkHold) { delete s.bkHold; out.push("「あとで」・負けて 止まって いた 物語の 話を、場所へ 行けば また 始まる ように した"); }
  delete s.bkp;
  if (O.reset) out.push(...O.reset(p, d));
  return out;
};
GOAL_HOOKS.unshift((p, d) => {
  const s = qs(d), e = pendingE(s);
  if (!e) return packGate(s) ? { text: PACK_MSG.replace(/§./g, ""), name: "", near: "", x: null, z: null, key: "bk:pack" } : null;
  let sp = null; try { sp = spotFor(p, d, e); } catch {}
  return { text: String(e.hint).replace(/§./g, "").replace(/\s+/g, " ").trim(), name: sp ? sp.nm : "", near: "§a「！」の 目印の そばで 立ち止まろう", x: sp ? sp.x + 0.5 : null, z: sp ? sp.z + 0.5 : null, key: `bk:${e.id}` };
});

/* ---------- ガイドブック「見のがした 頁」（書かれた 話だけ。ほうび・印 なし）---------- */
const missed = (s) => BKID.filter((id, i) => BKE.has(id) && getB(s, "bks", i));
STORY_EXTRA.push({
  label: "§d見のがした 頁",
  cond: (p, d) => missed(qs(d)).length > 0,
  async run(p, d) {
    const L = missed(qs(d)).slice(0, 24); if (!L.length) return;
    const i = await choose(p, "見のがした 頁", "§7とばした・前の 版で 済ませた 話を、もう一度 見る（ほうび・印は ない）", [...L.map((id) => { const e = BKE.get(id); return [`${chLabel(e.c)}\n§8${e.n}話 ${e.t}`, "textures/ui/mrpg/i_book"]; }), ["§7戻る", "textures/ui/mrpg/i_back"]]);
    if (!(i >= 0 && i < L.length)) return;
    if (!(await confirm(p, "見のがした 頁", `§f${chLabel(BKE.get(L[i]).c)} ${BKE.get(L[i]).t}\n§7（ガイドブックを 閉じると 始まる。今 いる 場所で 流れる）`, "見る", "やめる"))) return;
    const dd = load(p); if (!dd) return; qs(dd).bkReplay = L[i]; save(p, dd);
  },
});
export const __bk = { IDX, LISTS, target, mark, nextIdx, CHREG, FREE, RPL, syncKey };
