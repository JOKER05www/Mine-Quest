/* 第126版 本4「炎の幹部」（ヴォルカ火山帯・ラヴィ／スス／フォルジア）— 作業 MA
   ・古い 話 r3e1〜r3e5（ep_r3.js）を 生かす。新しい 話: 7話 すすけた 町スス（ヨネ婆の 木槌）
   ・MQ8 = b04e4 燃える 鍛冶場（ザクの 台座・爆弾班）・b04e5 六影の 鋳造所（ヴァルカ・選択 C04・セオ）— 今の 段の 場面の かわり
   ・MQ9 = b04e8 フォルジア（マスター戦の あと。母の 足袋）→ 今の 段（セオの 手紙）*/
import { bkAdd, mqOver, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facMark, facSide, facState } from "./epfac.js";
import { H4, Y, OLDE, oldRun, once, gy, at2, out } from "./bk_b01.js";
import { placeOf, townOut, bldOf } from "./storyplace.js";
import { ok } from "./ui.js";

const PL = (oid) => (p) => { const o = OLDE(oid); try { return o ? o.place(p) : null; } catch { return null; } };
const SUSU = () => bldOf("t57", ["home", "home2", "inn"], "すすけた 里 スス") || (() => { const o = townOut("t57", 0.3, "すすけた 里 スス"); return o ? { x: o.x, z: o.z, nm: "すすけた 里 スス" } : null; })();
const VALKA = (K, p, w = false) => K.npcNear(p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), w);
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);

/* ---------- 施設 ---------- */
const { F, S1 } = FAC_OPS;
/* 打ちかけの 台座（燃える 鍛冶場の 金床の 横）: 黒い 石の 台に 六つの くぼみ（五つは 形が ちがい、一つは 空っぽの 丸）*/
facAdd("b04ped", { D: [9, 12, 8], box: [-1, -3, 3, 3], H: 3, look: [1, 0, 1.2], marks: { round: [1, 0, 1.1] }, build: () => [
  F(0, -2, 0, 2, 2, 0, "polished_blackstone"), S1(1, -2, 1, "iron_trapdoor"), S1(1, -1, 1, "stone_button"), S1(0, 0, 1, "lever"),
  S1(1, 1, 1, "iron_bars"), S1(2, 2, 1, "chain"), S1(1, 0, 1, "air"), S1(-1, -3, 0, "anvil"), S1(-1, 3, 0, "blast_furnace"), S1(2, -3, 0, "campfire"), S1(2, 3, 0, "campfire"),
] });
/* 六影の 鋳造所（アジトの 炉の 間）: 黒い 石の 床・溶けた 鉄の 流れ（溶岩の 溝）・炉・梁・半分の 台座 */
facAdd("b04foundry", { D: [12, 15, 10], box: [-2, -6, 8, 6], H: 6, look: [3, 0, 1.4], marks: { ped: [4, -3, 1.1], sword: [4, 3, 0.4], beam: [6, 0, 1] }, build: () => [
  F(-1, -6, -1, 8, 6, -1, "polished_blackstone"), F(2, -1, -1, 6, 1, -1, "lava"), F(2, -1, -2, 6, 1, -2, "blackstone"),
  F(8, -6, 0, 8, 6, 4, "polished_blackstone_bricks"), S1(7, -4, 0, "blast_furnace"), S1(7, -3, 0, "blast_furnace"), S1(7, 3, 0, "blast_furnace"), S1(7, 4, 0, "magma_block"),
  F(7, -6, 5, 7, 6, 5, "dark_oak_log"), F(0, -6, 0, 0, -6, 4, "dark_oak_log"), F(0, 6, 0, 0, 6, 4, "dark_oak_log"),
  F(4, -4, 0, 5, -2, 0, "polished_blackstone"), S1(4, 3, -1, "magma_block"), S1(5, 3, -1, "magma_block"), S1(6, 0, 0, "dark_oak_log"),
  S1(3, -5, 3, 'lantern ["hanging"=true]'), S1(3, 5, 3, 'lantern ["hanging"=true]'),
] });

/* ---------- 登場人物 ---------- */
castAdd("b04yone", { nm: "ヨネ婆", role: "ススの", gobi: "だよ", skin: "baba", town: "t57", hide: (s) => !bkHas(s, "b04e7"),
  at: () => { const q = SUSU(); return q ? { x: q.x + 2, y: q.y, z: q.z } : null; },
  pre: ["{smile}すすで 顔が 黒いのは、生まれつき だよ。"],
  after: [
    [(s) => !!s.ending, ["{smile}木槌は、あの 見習いの 子に 渡したよ。……打つ 音が、焼けた 村の 鍛冶屋に 似てる だよ。"]],
    [() => true, ["{closed}灰の 降った 冬の ことは、だれも 口に しない だよ。……あたしは、忘れないように 木槌を 置いてる だよ。"]],
  ] });
castAdd("b04zak", { nm: "ザク", role: "兄弟子", gobi: "", skin: "m6_bolt", town: "t30", hide: (s) => !bkHas(s, "b04e9"),
  at: () => { const o = OLDE("r3e1"); const q = o && o.place ? (() => { try { return o.place(); } catch { return null; } })() : null; return q ? { x: q.x - 5, z: q.z + 3 } : null; },
  pre: ["{closed}……"],
  after: [
    [(s) => (s.ch || {}).c04 === "p", ["{sad}あの 台座、割れて よかった。……金の ために 打った 鉄は、軽いんだ。"]],
    [() => true, ["{sad}あの 台座は、六影が 持って いった。……俺の 打った 鉄が、どこかで 何かを する。それが こわい。"]],
  ] });

/* ---------- 1〜3話（古い r3e1〜r3e3）---------- */
const E1 = { id: "b04e1", t: "外れの 鍛冶場", F: ["F26"], battles: 0, fac: "r3smithy",
  place: PL("r3e1"),
  hint: "§fヴォルカ火山帯の §eようがんの 里 ラヴィの 外れの 鍛冶場§f へ 行こう §7（ジンの 伝言）",
  syn: "見習い鍛冶の トンボと 親方 ゲンに 会った。トンボは「きのう、字の 読めない お侍さんが、看板じゃ なくて 槌の 音で 店を 選んだッス」と 笑った。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e1", E1); } };   /* 槌の 音で 店を 選ぶ 侍 /*F26*/
const E2 = { id: "b04e2", t: "火祭りの 支度", F: ["F19", "F24"], battles: 0, fac: "r3mine",
  place: PL("r3e2"),
  hint: "§fラヴィの 外れの §e鉱山の 入口§f へ 行こう §7（トンボと 火祭りの 鉄を 掘る）",
  syn: "地方マスターの カグラが 祭りの 中止を 告げた。ゲンは ぽつりと 言った。「十二年前、灰の 降った 冬に、焼けた 村から 泣いてる 子を 一人 拾ったんでい」。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e2", E2); } };   /* 灰の 降った 冬・拾った 子 /*F19 F24*/
const E3 = { id: "b04e3", t: "火薬の におい", F: ["F22"], fac: "r3haul",
  place: PL("r3e3"),
  hint: "§fラヴィの 外れの §e鉄の 運び道§f へ 行こう §7（トンボと 祭りの 鉄を 運ぶ）",
  syn: "赤い 外套の 女が 爆弾班を 町から 追い払った。「台座の 鉄を 見に 来たら、この 有りさまだ。町で やるなと 言ったろ」。去りぎわに「祭り、やれると いいね」。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e3", E3); } };   /* 赤い 外套の 女 /*F22*/

/* ---------- 4話 燃える 鍛冶場（MQ8）---------- */
const E4 = { id: "b04e4", t: "燃える 鍛冶場", battles: 1,
  hint: "§fヴォルカ火山帯の §e町外れの 鍛冶場§f へ 行こう",
  syn: "鍛冶場が 燃えて いた。兄弟子の ザクは「台座を 半分 打っちまった」と うなだれた。打ちかけの 台座には 六つの くぼみ。五つは 形が ちがい、一つは 空っぽの 丸。六影 爆弾班の ボムを 退けると、台座は 鋳造所へ 運ばれた あとだった。",
  async run(p, d, K) {
    const y0 = Y(K, p), pq = K.fac(p, "b04ped", "b04ped", 3, y0);
    await K.open(p, "燃える 鍛冶場", "ash");
    K.sound(p, "mob.blaze.shoot", 0.8); K.shake(p, 0.3, 0.5);
    const eH = K.hero(p), eZ = K.npcNear(p, "§e兄弟子 ザク", K.PJ("m6_bolt", 8)); K.act(eZ, "kneel");
    const ped = pq || at2(K, p, 6, 0, 1);
    K.burst(p.dimension, ped, "minecraft:basic_flame_particle", 10, 1.2, 0.2);
    await K.up(p, eZ, 8);
    await K.say(p, "ザク", ["{cry,tears}……台座を、半分 打っちまった。", "{sad,up}金が 要ったんだ。……打ってる うちに、こわく なった。何に 使うか、だれも 言わねえ。"]);
    await K.push(p, ped, 26, 4, 1.4, 0.4);   /* 台座の 六つの くぼみ（台座）*/
    await K.narr(p, ["§7黒い 石の 台に、六つの くぼみ。五つは それぞれ 形が ちがう。", "§7残る 一つは……空っぽの、まるい くぼみ。"], ped);
    await K.hsay(p, H4(["{?}六つ……。何を はめる 台なの？"], ["{?}六つの くぼみ……。何を はめるの？"], ["{?}六つ。一つだけ 丸。……何を はめる。"], ["{?}六つの くぼみ……何を はめる 台なのでしょう。"]), eZ);
    const eB = K.npcNear(p, "§c六影 爆弾班 ボム", K.PJ("bandit", 9)); K.act(eB, "point");
    await K.up(p, eB, 8);
    await K.say(p, "爆弾班 ボム", ["{smile,low}台座は 参謀の 注文でね。仕上げは 鋳造所で やる。……ついでに、アンタの 石板も もらって いくよ。"]);
    if (!K.flag(p, "b04e4w")) {
      const r = await K.battle(p, K.team(["nether", "dragon"], 29, 3, 5), { name: "六影 爆弾班", arena: "爆弾班", theme: "volcano", speaker: "爆弾班 ボム", lines: { half: "……熱い……まだだ……！" } });
      if (r !== "win") { await K.sayAt(p, "§c六影 爆弾班 ボム", K.PJ("bandit", 9), "ボム", ["……石板は また 今度だ。", K.RT(p)]); return false; }
      K.setFlag(p, "b04e4w");
    }
    const eB2 = K.npcNear(p, "§c六影 爆弾班 ボム", K.PJ("bandit", 9), true);
    await K.up(p, eB2, 8);
    await K.say(p, "爆弾班 ボム", ["{sweat,汗}ちっ……ヴァルカ様に 知らせる！ 台座は もう 炉の 上だ。§e鋳造所§f まで 来て みな！"]);
    if (ok(eB2)) await out(K, p, eB2);
    const dd = K.load(p); if (dd) { K.qs(dd).ch4a = 1; K.save(p, dd); }
    await K.end(p, { bye: [eZ], card: "§7― 六影の 鋳造所へ ―" });
    return true;
  } };

/* ---------- 5話 六影の 鋳造所（MQ8。ヴァルカとの 決闘・選択 C04・セオ）---------- */
const E5 = { id: "b04e5", t: "炉の 前の 決闘", F: ["F23"], battles: 1,
  hint: "§fヴォルカ火山帯の §e六影の 鋳造所§f へ 行こう",
  syn: "鋳造所の 炉の 前で、ヴァルカが 台座を 打って いた。「迷いが 鉄に 出てる」。溶けた 鉄の 流れの 上で 決闘を した。崩れる 鋳造所で、片側に 半分の 台座、片側に 溶けた 鉄の 流れへ 落ちかける 布巻きの 刀。",
  async run(p, d, K) {
    const y0 = Y(K, p), hq = placeOf("hall", 3, true);
    let fq = null;
    if (hq) await K.moveTo(p, { x: hq.x, y: hq.y, z: hq.z }, "六影の 鋳造所");
    else { try { fq = facSide(p, K.S(p), 16, "b04foundry", "b04foundry", 3, y0); } catch {} if (fq) await K.moveTo(p, { x: fq.x, y: y0, z: fq.z }, "六影の 鋳造所", [], fq, 10); else await K.open(p, "六影の 鋳造所", "ash"); }
    const mk = (n, a, b, dy) => facMark("b04foundry", n, p.location) || at2(K, p, a, b, dy);
    const eH = K.hero(p), eV = VALKA(K, p); K.hold(eV, "hammer"); K.act(eV, "work");
    await K.pull(p, eV, 18);
    await K.narr(p, ["§7炉の 前。赤い 外套の 女が、背を 向けて 台座を 打って いる。……ラヴィの 運び道で 見た 女だ。"], eV);
    K.act(eV, "hold"); if (ok(eV) && ok(eH)) K.turn(eV, eH.location);
    await K.up(p, eV, 8);
    await K.say(p, "ヴァルカ", ["{closed}……下手な 打ち方だ。迷いが 鉄に 出てる。", "{smile,low}アタシは 六影 三の座、ヴァルカ。……台座の 仕上げの 邪魔を するなら、相手に なるよ。"]);
    await K.hsay(p, H4(["{angry,up}その 台座、何に 使うの！ ザクさん、泣いてたよ！"], ["{sad,up}……その 台座で、何を するの？"], ["{angry}台座の 使い道。言って。"], ["{angry,up}その 台座、何に お使いに なるのですか！"]), eV);
    await K.say(p, "ヴァルカ", ["{closed}知らないね。参謀の 注文さ。……知りたきゃ、勝ちな。"]);
    if (!K.flag(p, "b04e5w")) {
      await K.duel(p, "§c§l六影 三の座 ヴァルカ", "§c溶けた 鉄の 流れの 上で！", { fams: ["dragon"] });
      const r = await K.battle(p, K.team(["dragon", "nether"], 33, 3, 44, K.leadOf("dragon", 33)), { name: "六影 三の座 ヴァルカ", arena: "炎の 幹部", theme: "volcano", hpk: 6, extra: 0.4, tag: "三の座", sboss: true, speaker: "ヴァルカ", lines: { half: "……いい 火だ。", low: "ちっ……！" } });
      if (r !== "win") { await K.sayAt(p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), "ヴァルカ", ["{closed,low}……試しだ。石板は 取らないよ。出直して きな。", K.RT(p)]); return false; }
      K.setFlag(p, "b04e5w");
    }
    /* 崩れる 鋳造所 */
    K.sound(p, "random.explode", 0.9); K.shake(p, 0.9, 1.2); K.flash(p, true);
    const eV2 = VALKA(K, p, true); K.act(eV2, "kneel");
    const pd = mk("ped", 4, -3, 1.1), sw = mk("sword", 4, 3, 0.4);
    await K.at(p, mk("beam", 6, 0, 1), 12, 3, 0.6);
    await K.narr(p, ["§7梁が 落ちた。ヴァルカは 梁の 下で 動けない。"], eV2);
    await K.at(p, pd, 12, 2.6, 0.6);
    await K.narr(p, ["§7片側に、半分 打たれた 台座。六つの くぼみ。"], pd);
    K.burst(p.dimension, sw, "minecraft:lava_particle", 8, 0.6, 0.3);
    await K.push(p, sw, 20, 3, 1.4, 0.2);   /* 布巻きの 刀 /*F23*/
    await K.narr(p, ["§7もう 片側に、布を 巻いた 刀が 一本。溶けた 鉄の 流れへ、少しずつ すべって いく。"], sw);
    await K.up(p, eV2, 8);
    await K.say(p, "ヴァルカ", ["{angry}……どっちも 取れや しないよ。好きに しな。"]);
    const v = await K.pick(p, "c04");
    if (v === "p") {
      K.sound(p, "random.anvil_break", 0.9); K.burst(p.dimension, pd, "minecraft:basic_smoke_particle", 12, 0.8, 0.3);
      await K.at(p, pd, 12, 2.6, 0.6);
      await K.narr(p, ["§7あなたの 相棒が 台座に 体当たりした。台座は 割れて、六つの くぼみは 二つに 裂けた。", "§7……刀は 溶けた 鉄の 中へ 沈み、布の 燃える においが した。"], pd);
      await K.up(p, eV2, 8);
      await K.say(p, "ヴァルカ", ["{sad,…}……親父の 刀が。", "{closed}……いいさ。台座が 世に 出るより ましだ。"]);
    } else {
      await K.at(p, sw, 12, 2.6, 0.4);
      await K.narr(p, ["§7あなたは 刀の 布を つかんで 引き上げた。手の ひらが 熱い。", "§7……その 間に、爆弾班が 半分の 台座を かついで 走り去った。"], sw);
      await K.up(p, eV2, 8);
      await K.say(p, "ヴァルカ", ["{shock,…}……親父の 刀を、なんで。", "{closed}……借りが できたね。台座は ラグナへ 運ばれる。……運び道は、爆破される だろうさ。"]);
    }
    if (ok(eV2)) { K.act(eV2, 0); await out(K, p, eV2); }
    /* セオが 来る（次の 行き先）*/
    const eS = THEO(K, p);
    await K.up(p, eS, 8);
    await K.say(p, "セオ", ["{sweat,汗}はあ、はあ……ジンさんの 知らせで 追って 来ました。けがは ありませんか？", "{closed}……兵に 引きわたす とき、爆弾班が こぼして いました。命令書は いつも、古めかしい 年寄りの 字で 来ると。"]);
    await K.hsay(p, H4(["{?}年寄りの 字……？"], ["{?}年寄りの 字……。"], ["{?}年寄りの 字。"], ["{?}年寄りの 字、ですか……？"]), eS);
    await K.say(p, "セオ", ["{closed}台座の 鉄は、砂漠の 王墓の 古い 記録と 似て いる。……地図は 僕が 手配します。§eサンドリア城の 城門§f で 落ち合いましょう。"]);
    K.pay(p, E5, 6000, [["e_red", 1], ["SEED2", 2], ["tms_dragon", 1]]);
    await K.end(p, { leave: [eS], card: "§7― ラヴィの 焼けた 鍛冶場へ ―" });
    return true;
  } };

/* ---------- 6話 焼けた 鍛冶場（夜）（古い r3e4）---------- */
const E6 = { id: "b04e6", t: "鍛冶場の 夜", F: ["F22", "F24"], ans: [], battles: 1, fac: "r3smithy",
  place: PL("r3e4"),
  hint: "§fラヴィの 外れの §e焼けた 鍛冶場§f へ もどろう §7（夜、まだ 槌の 音が する）",
  syn: "夜、ヴァルカが 槌の 音を 聞きに 来た。「親父は 最後に 嘘を ついた。『この 刀は 人を 守る』って」。結びには『型』が 要り、その 型は ある 部屋に 眠って いる と いう。トンボには「もう 一度 打って みな。試しだ」。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e4", E6); } };   /* 親父の 嘘・型の ある 部屋 /*F22 F24*/

/* ---------- 7話 すすけた 町スス（新）---------- */
const E7 = { id: "b04e7", t: "ススの 木槌", F: ["F19", "F60"], battles: 0,
  place: () => SUSU(),
  hint: "§fすすけた 里 §eスス§f へ 行こう §7（焼けた 村の ことを 知る 婆さまが いる）",
  syn: "ススの ヨネ婆は、焼けた 村の 小さな 木槌を 預かって いた。木槌の そばに、灰色の 染みの ついた 紙きれ。「灰の 降った 冬の ことは、だれも 口に しない」。",
  async run(p, d, K) {
    await K.open(p, "すすけた 里 スス", "ash");
    const eH = K.hero(p), eY = K.cast(p, "b04yone"); K.hold(eY, "hammer");
    await K.up(p, eY, 8);
    await K.csay(p, "b04yone", ["{closed}ラヴィの 鍛冶場の 話かい。……焼けた 村の ことを 聞きに 来たんだね。", "{sad}灰の 降った 冬に、峠の 向こうの 鍛冶の 村が 一晩で 焼けた だよ。"], eH);
    K.act(eY, "show");
    await K.push(p, eY, 22, 3, 1.2, 1.1);   /* 小さな 木槌 /*F19*/
    await K.narr(p, ["§7ヨネ婆の 手に、子どもの 手に 合う 小さな 木槌。柄に すすの 跡。"], eY);
    await K.csay(p, "b04yone", ["{closed}焼け跡で 拾った だよ。小さな 子の 槌だね。……持ち主は、分からない だよ。"]);
    await K.hsay(p, H4(["{sad}……ゲンさんが 拾った 子と、関係 あるのかな。"], ["{sad}……ゲンさんの 拾った 子の ものかしら。"], ["{closed}……ゲンの 拾った 子。……かもしれない。"], ["{sad}……ゲンさんの 拾われた 子の ものでしょうか。"]), eY);
    const sq = at2(K, p, 3, 1.5, 0.6);
    await K.at(p, sq, 14, 2, 0.4);   /* 灰色の 染み（記録の 断片）/*F60*/
    await K.narr(p, ["§7木槌が 包んで あった 紙きれ。字の 上に、灰色の 染みが 広がって 読めない。"], sq);
    await K.csay(p, "b04yone", ["{sad}灰の 降った 冬の ことは、だれも 口に しない だよ。……あたしは、忘れないように 置いてる だよ。"], eH);
    await K.end(p, { leave: [eY], card: "§7― 鍛冶王の 城 フォルジアへ ―" });
    return true;
  } };

/* ---------- 8話 鍛冶王の 城フォルジア（MQ9。マスター戦の あと）---------- */
const E8 = { id: "b04e8", t: "炭色の 足袋", battles: 0,
  hint: "§fヴォルカ火山帯の §6地方マスター カグラ§f に 勝とう",
  syn: "カグラは 母の 形見の 炭色の 足袋を はいて 戦った。勝負の あと、カグラは 祭りを 許した。「燃やすんじゃ なく、聞いた うえで 選ぶ」。",
  async run(p, d, K) {
    await K.open(p, "鍛冶王の 城 フォルジア", "castle");
    const eH = K.hero(p), eK = K.cast(p, "r3kagura");
    await K.at(p, eK ? eK.location : at2(K, p, 4, 0), 14, 1.6, 0.2);   /* 足もとの 足袋 */
    await K.narr(p, ["§7カグラの 足もと。炭のように 黒い 足袋。……ところどころ、焼けて 固く なって いる。"], eK);
    await K.up(p, eK, 8);
    await K.csay(p, "r3kagura", ["{closed}……母の 形見よ。祭りの 夜、舞いながら 足が 炭に なった 母の。", "{smile,up}あなたの 戦い方は、相手の 音を 聞いて から 動く。……燃やすんじゃ なく、聞いた うえで 選ぶ。"], eH);
    await K.hsay(p, H4(["{smile,up}じゃあ、火祭り……！"], ["{smile}……火祭り、できるのね。"], ["{closed}……祭り、やれる。"], ["{smile,up}火祭り、開けるのですね！"]), eK);
    await K.csay(p, "r3kagura", ["{smile}ええ。鍛冶組合にも 伝えて。……母の 好きだった 舞を、今年は わたしが 舞う。"]);
    await K.end(p, { bye: [eK] });
    return true;
  } };

/* ---------- 9話 ラヴィの 火祭り（古い r3e5 ＋ C04 で ホムラの ひび）---------- */
const E9 = { id: "b04e9", t: "火祭り", battles: 0,
  place: PL("r3e5"),
  hint: "§fラヴィの §e広場§f で §6火祭り§f が 開かれる §7（そのあと サンドリアへ）",
  syn: "ラヴィで 火祭りが 開かれた。トンボは 初めての 刀『ホムラ』を あなたたちに 託した。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r3e5", E9))) return false;
    K.key(p, "k_fest3");
    await K.open(p, "ラヴィの 広場（火祭りの 夜）", "fest", "night");
    const eH = K.hero(p), eT = K.cast(p, "r3tombo"); K.hold(eT, "katana"); K.act(eT, "show");
    const v = K.ch(p, "c04");
    await K.push(p, eT, 22, 3, 1.2, 1.1);
    if (v === "s") {
      await K.narr(p, ["§7ホムラの 刃の 根もとに、細い ひびが 一本。……爆破で ひびの 入った 炉で 打った 刀だ。"], eT);
      await K.csay(p, "r3tombo", ["{sad}炉に ひびが 入ってたッス。……ひびごと、おれの 初めての 刀ッス。", "{angry,up}いつか、ちゃんと 打ち直すッス！"], eH);
    } else {
      await K.narr(p, ["§7ホムラの 刃は まっすぐで、ひび 一つ ない。"], eT);
      await K.csay(p, "r3tombo", ["{smile,☆}ひび 一つ ないッス！ 炉が 無事だった おかげッス！"], eH);
    }
    await K.end(p, { leave: [eT] });
    return true;
  } };

bkAdd("b04", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ9: 場面（b04e8）の あと、今の 段（セオの 手紙・王墓の 地図）*/
mqOver(9, async (p, d, K, c) => { if (!(await c.play("b04e8"))) return false; return c.old(); });
