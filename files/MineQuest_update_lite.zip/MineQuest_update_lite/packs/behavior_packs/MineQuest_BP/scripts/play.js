// 第103版: 自分の モンスターと あそぶ（ミニゲーム 30）
// 遊ぶ 仲間（と ライバル）が ワールドの 中で 実際に 動く。動かすのは 遊んで いる 間だけ・2体まで。終わったら すぐ 片づける
// ほうびは 1つの 遊びに つき 1日 1回だけ（はじめて 勝った とき）。記録は "mrpg:ex" の pl に 入れる
import { SPECIES, ORDER, MOVES, EL_NAME } from "./data.js";
import { load, save } from "./store.js";
import { world, system } from "@minecraft/server";
import { choose, notice, ICON, MON_ICON, sound, EXH, anim, ok, barNote } from "./ui.js";
import { TYPE, setLook, findPet, spawnPet, hooks } from "./field.js";
import { HIT_HOOKS } from "./battle.js";
import { calcStats } from "./core.js";
import { award, TITLES } from "./endgame.js";
import { exOf, exSave, dayNo, giveGold, prize, fx } from "./explore.js";
import { __bond } from "./bond.js";

const B = (t, icon) => [t, icon];
const rnd = () => Math.random();
const ri = (n) => Math.floor(rnd() * n);
const shuf = (a) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = ri(i + 1); [b[i], b[j]] = [b[j], b[i]]; } return b; };
const QUIT = -1;
const STN = { hp: "HP", atk: "物力", def: "硬力", mat: "魔力", mdf: "魔硬力", spd: "走力", wpn: "武力", brt: "吹力" };
const avgSt = (st) => (st.atk + st.def + st.mat + st.mdf + st.spd + st.wpn + st.brt) / 7 || 1;
/* 相手の 強さ: 自分の 子の 能力の 平均くらい（得意な 能力で 遊ぶと 勝ちやすい） */
const rival = (st, k) => (k === "hp" ? avgSt(st) * 4.2 : avgSt(st)) * (0.85 + rnd() * 0.3);
const edge = (st, k) => Math.max(0.6, Math.min(1.6, (st[k] || 1) / (k === "hp" ? avgSt(st) * 4.2 : avgSt(st))));   /* 得意さ 0.6〜1.6 */
const SAFE_SP = () => ORDER.filter((k) => SPECIES[k] && ["F", "E", "D", "C", "B", "A", "S"].includes(SPECIES[k].rank) && !SPECIES[k].hidden && !SPECIES[k].fuseonly && !SPECIES[k].uniq);
let SP_CACHE = null;
const spList = () => SP_CACHE || (SP_CACHE = SAFE_SP());
function seenList(d) { const s = new Set(d.seen || []), L = spList().filter((k) => s.has(SPECIES[k].idx)); return L.length >= 12 ? L : spList().filter((k) => ["F", "E", "D", "C"].includes(SPECIES[k].rank)); }
let LOW = null;
const rivalSp = () => { const L = LOW || (LOW = spList().filter((k) => ["F", "E", "D", "C"].includes(SPECIES[k].rank))); return L[ri(L.length)]; };
const rivalName = (p) => SPECIES[ST.get(p?.id)?.rv || rivalSp()]?.name || "ライバル";

// ---------- ワールドの 中の 舞台（仲間と ライバルを 動かす）----------
const ST = new Map();   /* プレイヤー → { ents, ivs, wake, me, rv, o, f, r } */
const bar = (p, m) => { try { barNote(p).setActionBar(m); } catch {} };
function groundY(dim, x, y0, z) {   /* 足もとの 高さ（上下 4ブロックだけ 見る） */
  const bx = Math.floor(x), bz = Math.floor(z), by = Math.floor(y0);
  try { for (let dy = 3; dy >= -4; dy--) { const a = dim.getBlock({ x: bx, y: by + dy, z: bz }), b = dim.getBlock({ x: bx, y: by + dy - 1, z: bz }); if (a && b && a.isAir && !b.isAir) return by + dy; } } catch {}
  return y0;
}
function stageOf(p) { return ST.get(p.id) || null; }
/* 舞台を 作る: 仲間を 前に 出す（連れ歩きは いったん しまう）。kind: "race"=横に ならぶ・"duel"=向かいあう・"solo"=1体 */
function stageUp(p, d, m, kind = "solo") {
  stageEnd(p);
  let f = { x: 0, z: 1 }; try { const v = p.getViewDirection(); const n = Math.hypot(v.x, v.z); if (n > 0.1) f = { x: v.x / n, z: v.z / n }; } catch {}
  const r = { x: -f.z, z: f.x }, L = p.location, o = { x: L.x + f.x * 3, y: L.y, z: L.z + f.z * 3 };
  const S = { ents: [], ivs: new Set(), wake: new Set(), o, f, r, dim: p.dimension, kind, rv: rivalSp(), mid: m.id, petBack: false };
  ST.set(p.id, S);
  try { const pet = findPet(p); if (pet) { S.petBack = true; pet.remove(); } } catch {}
  const at = (dx, dz) => { const x = o.x + f.x * dz + r.x * dx, z = o.z + f.z * dz + r.z * dx; return { x, y: groundY(p.dimension, x, L.y, z), z }; };
  S.at = at;
  if (kind === "race") { S.me = actor(p, S, m.sp, m, at(-1.2, 0), at(-1.2, 10), `§b${m.nm}`); S.rvE = actor(p, S, S.rv, null, at(1.2, 0), at(1.2, 10), `§c${SPECIES[S.rv].name}`); }
  else if (kind === "duel") { S.me = actor(p, S, m.sp, m, at(0, 1), at(0, 3), `§b${m.nm}`); S.rvE = actor(p, S, S.rv, null, at(0, 3), at(0, 1), `§c${SPECIES[S.rv].name}`); }
  else S.me = actor(p, S, m.sp, m, at(0, 1), { x: L.x, y: L.y, z: L.z }, `§b${m.nm}`);
  return S;
}
function actor(p, S, sp, m, pos, face, name) {
  let e; try { e = p.dimension.spawnEntity(TYPE, pos); } catch { return null; }
  try { e.addTag("mrpg_play"); setLook(e, sp, m || undefined); e.triggerEvent("mrpg:make_battle"); e.setDynamicProperty("mrpg:pown", p.id); e.teleport(pos, { facingLocation: face }); e.nameTag = name; } catch {}
  fx(p.dimension, "minecraft:villager_happy", { x: pos.x, y: pos.y + 1, z: pos.z });
  S.ents.push(e); return e;
}
export function stageEnd(p, pid) {
  const id = pid || p?.id, S = ST.get(id); if (!S) return;
  ST.delete(id);
  for (const iv of S.ivs) try { system.clearRun(iv); } catch {}
  for (const w of S.wake) try { w(); } catch {}
  for (const e of S.ents) try { if (ok(e)) e.remove(); } catch {}
  if (S.petBack && p) system.run(() => { try { const d = load(p); const m = d && d.out && [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out); if (m && !findPet(p)) spawnPet(p, m); } catch {} });
}
/* e を to へ ticks かけて 動かす（hop で はねる）。舞台が 終わったら すぐ 返す */
function go(p, e, to, ticks = 30, hop = 0, face = null) {
  const S = stageOf(p); if (!S || !ok(e)) return Promise.resolve();
  return new Promise((res) => {
    let a; try { a = { ...e.location }; } catch { return res(); }
    let t = 0, iv = null; const done = () => { S.wake.delete(done); if (iv !== null) { try { system.clearRun(iv); } catch {} S.ivs.delete(iv); } res(); };
    S.wake.add(done);
    iv = system.runInterval(() => { t++; const k = Math.min(1, t / ticks); if (!ok(e)) return done();
      const x = a.x + (to.x - a.x) * k, z = a.z + (to.z - a.z) * k, y = a.y + (to.y - a.y) * k + hop * Math.sin(Math.PI * k);
      try { e.teleport({ x, y, z }, { facingLocation: face || { x: to.x + (to.x - a.x) * 0.1 + 0.001, y: to.y, z: to.z + (to.z - a.z) * 0.1 } }); } catch {}
      if (k >= 1) done(); }, 1);
    S.ivs.add(iv);
  });
}
function pause(p, t) { const S = stageOf(p); if (!S) return Promise.resolve(); return new Promise((res) => { const done = () => { S.wake.delete(done); res(); }; S.wake.add(done); system.runTimeout(done, Math.max(1, t)); }); }
function act(p, e, name, t = 20, part = null) { if (!ok(e)) return pause(p, 1); anim(e, name); if (part) { const l = e.location; for (let k = 0; k < 6; k++) fx(e.dimension, part, { x: l.x + (rnd() - 0.5), y: l.y + 1 + rnd(), z: l.z + (rnd() - 0.5) }); } return pause(p, t); }
const react = (p, good, e = stageOf(p)?.me) => act(p, e, good ? "happy" : "hurt", 25, good ? "minecraft:heart_particle" : "minecraft:basic_smoke_particle");
const trail = (p, a, b, part = "minecraft:villager_happy") => { const S = stageOf(p); if (!S) return; for (let k = 1; k <= 8; k++) fx(S.dim, part, { x: a.x + (b.x - a.x) * k / 8, y: a.y + 1 + (b.y - a.y) * k / 8 + Math.sin(Math.PI * k / 8) * 1.5, z: a.z + (b.z - a.z) * k / 8 }); };
const home = (p) => { const S = stageOf(p); return S && ok(S.me) ? go(p, S.me, S.at(0, 1), 20, 0, S.at(0, -2)) : Promise.resolve(); };
const fwd = (p, who, dist) => { const S = stageOf(p), e = who === "rv" ? S?.rvE : S?.me; if (!S || !ok(e)) return Promise.resolve(); const l = e.location, x = l.x + S.f.x * dist, z = l.z + S.f.z * dist; return go(p, e, { x, y: groundY(S.dim, x, l.y, z), z }, 30); };
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => stageEnd(null, playerId)); } catch {}
hooks.petHold = (p) => ST.has(p.id);
/* 前に 遊んで いた ときの 子が 残って いたら 片づける（入りなおした とき・30秒ごとに 近くだけ） */
system.runInterval(() => { for (const q of world.getAllPlayers()) { let L = []; try { L = q.dimension.getEntities({ type: TYPE, tags: ["mrpg_play"], location: q.location, maxDistance: 96 }); } catch {} for (const e of L) { try { const S = ST.get(e.getDynamicProperty("mrpg:pown")); if (!S || !S.ents.some((x) => x.id === e.id)) e.remove(); } catch {} } } }, 600);
/* なぐった ときの 当たり（鬼ごっこ・かくれんぼ）。舞台の 子は 戦いに ならない */
HIT_HOOKS.unshift((p, e) => { if (!e.hasTag("mrpg_play")) return false; const S = stageOf(p); if (S && S.onHit && S.ents.some((x) => x.id === e.id)) S.onHit(e, p); return true; });
/* 読みこまれた ときに 持ち主の いない 舞台の 子を 消す（ワールドを 閉じた あと 遠くに 残った 子） */
try { world.afterEvents.entityLoad.subscribe(({ entity: e }) => { try { if (e?.typeId !== TYPE || !e.hasTag("mrpg_play")) return; const S = ST.get(e.getDynamicProperty("mrpg:pown")); if (!S || !S.ents.some((x) => x.id === e.id)) e.remove(); } catch {} }); } catch {}


// ---------- 1) 走る・力 などの きそう 遊び ----------
async function gRun(p, m, st) {   // かけっこ（走力）
  let me = 0, rv = 0, sta = 3; const rn = rivalName(p);
  for (let leg = 1; leg <= 3; leg++) {
    const c = await choose(p, `かけっこ ${leg}/3`, `§f${m.nm} §e${me | 0}m§f ／ ${rn} §c${rv | 0}m\n§fスタミナ §a${sta}§f／5\n§7全力は スタミナ 2・ふつうは 1・ためると 1 もどる`, [B("§c§l全力で 走る", ICON("i_run")), B("§lふつうに 走る", ICON("i_run")), B("§bためる §8（ゆっくり）", ICON("i_inn")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    let mul = [1.35, 1, 0.7][c]; if (c === 0) { if (sta >= 2) sta -= 2; else { mul = 0.6; sta = 0; } } else if (c === 1) { if (sta >= 1) sta--; else mul = 0.75; } else sta = Math.min(5, sta + 1);
    const a1 = 100 * edge(st, "spd") * mul * (0.9 + rnd() * 0.2), b1 = 100 * (0.95 + rnd() * 0.2); me += a1; rv += b1;
    await Promise.all([fwd(p, "me", a1 / 30), fwd(p, "rv", b1 / 30)]);
  }
  return { win: me > rv, msg: `${m.nm} ${me | 0}m ／ ${rn} ${rv | 0}m` };
}
async function rps3(p, ttl, m, st, k, names, tell) {   // 3すくみ（すもう・綱引き）: 先に 3点
  let a = 0, b = 0; const rn = rivalName(p), e = edge(st, k);
  for (let r = 1; r <= 9 && a < 3 && b < 3; r++) {
    const ai = ri(3), hint = rnd() < 0.6 ? ai : ri(3);
    const c = await choose(p, `${ttl} ${r}回目`, `§f${m.nm} §e${a}§f - §c${b}§f ${rn}\n§7${tell[hint]}\n§8（${names[0]}は ${names[2]}に 強く、${names[2]}は ${names[1]}に、${names[1]}は ${names[0]}に 強い）`, [...names.map((n) => B(`§l${n}`, ICON("i_fight"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    const w = c === ai ? (rnd() < e / (e + 1) ? 1 : -1) : (c + 1) % 3 === ai ? -1 : 1;   /* c=0 は 2 に 勝つ（0→2→1→0） */
    if (w > 0) a++; else b++;
    { const S = stageOf(p); if (S) { act(p, S.me, "atk_charge", 1); await act(p, S.rvE, "atk_charge", 12); const dd = w > 0 ? 0.8 : -0.8; await Promise.all([fwd(p, "me", dd), fwd(p, "rv", dd)]); act(p, w > 0 ? S.rvE : S.me, "hurt", 1); await pause(p, 12); } }
    await notice(p, ttl, `§f${m.nm}「${names[c]}」 vs ${rn}「${names[ai]}」\n${w > 0 ? "§a押しかえした！" : "§c押された…"}`);
  }
  return { win: a >= 3, msg: `${a} - ${b}` };
}
const gSumo = (p, m, st) => rps3(p, "すもう", m, st, "atk", ["押す", "いなす", "こらえる"], ["相手は 低く かまえた（押して きそう）", "相手は 体を 横に ひらいた（いなして きそう）", "相手は 腰を 落とした（こらえて きそう）"]);
const gTug = (p, m, st) => rps3(p, "綱引き", m, st, "wpn", ["一気に 引く", "ゆさぶる", "ふんばる"], ["相手は 綱を 強く にぎった（一気に 引きそう）", "相手は 綱を 小きざみに 動かした（ゆさぶりそう）", "相手は 足を 広げた（ふんばりそう）"]);
async function gJump(p, m, st) {   // 高とび（走力と 物力）: 3回 とんで いちばん 高い 記録
  let best = 0; const rv = Math.round(130 + 40 * rnd()), e = (edge(st, "spd") + edge(st, "atk")) / 2;
  for (let t = 1; t <= 3; t++) {
    const c = await choose(p, `高とび ${t}/3`, `§fいまの 記録 §e${best}cm§f ／ 相手の 記録 §c${rv}cm\n§7高い バーほど 成功しにくい（${m.nm}の 得意さ ${Math.round(e * 100)}%）`, [B("§l120cm §8（かんたん）", ICON("i_run")), B("§l145cm", ICON("i_run")), B("§l165cm", ICON("i_run")), B("§c§l185cm §8（むずかしい）", ICON("i_run")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 4) return QUIT;
    const h = [120, 145, 165, 185][c], okP = Math.min(0.95, [0.92, 0.7, 0.45, 0.22][c] * e), win1 = rnd() < okP;
    { const S = stageOf(p); if (S) { const bar0 = S.at(0, 5); for (let k = 0; k < 5; k++) fx(S.dim, "minecraft:villager_happy", { x: bar0.x + S.r.x * (k - 2) * 0.5, y: bar0.y + h / 60, z: bar0.z + S.r.z * (k - 2) * 0.5 }); await go(p, S.me, S.at(0, 3.5), 15); await go(p, S.me, S.at(0, win1 ? 7 : 5), 18, win1 ? h / 55 + 0.3 : h / 110); await act(p, S.me, win1 ? "happy" : "hurt", 15); await home(p); } }
    if (win1) { best = Math.max(best, h); await notice(p, "高とび", `§a${h}cm 成功！`); } else await notice(p, "高とび", `§c${h}cm は 失敗…`);
  }
  return { win: best > rv, msg: `${best}cm ／ 相手 ${rv}cm` };
}
async function gSwim(p, m, st) {   // 水泳（走力・水に 強いと 有利）
  const wet = (SPECIES[m.sp]?.res?.water || 0) > 0 ? 1.15 : 1; let me = 0, rv = 0;
  const FL = [["流れが 速い", 0], ["波が 高い", 1], ["水が 冷たい", 2]], STY = ["もぐって 泳ぐ", "大きく かく", "ゆっくり 進む"];
  for (let leg = 1; leg <= 3; leg++) {
    const f = FL[ri(3)];
    const c = await choose(p, `水泳 ${leg}/3`, `§f${m.nm} §e${me | 0}m§f ／ 相手 §c${rv | 0}m\n§b${f[0]}！§7（流れが 速い→もぐる・波が 高い→大きく かく・冷たい→ゆっくりが よい）`, [...STY.map((s) => B(`§l${s}`, ICON("i_run"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    const a1 = 50 * edge(st, "spd") * wet * (c === f[1] ? 1.3 : 0.9) * (0.9 + rnd() * 0.2), b1 = 50 * (1 + rnd() * 0.2); me += a1; rv += b1;
    { const S = stageOf(p); if (S) { for (const e of [S.me, S.rvE]) if (ok(e)) for (let k = 0; k < 4; k++) fx(S.dim, "minecraft:water_splash_particle", { x: e.location.x, y: e.location.y + 0.3, z: e.location.z }); await Promise.all([fwd(p, "me", a1 / 15), fwd(p, "rv", b1 / 15)]); } }
  }
  return { win: me > rv, msg: `${me | 0}m ／ 相手 ${rv | 0}m` };
}
async function gEat(p, m, st) {   // 早食い（HP）: 多く 食べるほど むせやすい
  let me = 0, rv = 0, skip = false; const e = edge(st, "hp");
  for (let r = 1; r <= 5; r++) {
    rv += 1 + ri(3);
    if (skip) { skip = false; await notice(p, "早食い", `§c${m.nm}は むせて 休んで いる…`); continue; }
    const c = await choose(p, `早食い ${r}/5`, `§f${m.nm} §e${me}皿§f ／ 相手 §c${rv}皿\n§7たくさん 食べると むせて 次の 回 休み（HPが 高いほど むせにくい）`, [B("§l1皿", ICON("i_shop")), B("§l3皿", ICON("i_shop")), B("§c§l5皿", ICON("i_shop")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    const n = [1, 3, 5][c]; for (let k = 0; k < n; k++) await act(p, stageOf(p)?.me, "atk_bite", 8, "minecraft:villager_happy");
    if (rnd() < [0, 0.2, 0.5][c] / e) { await act(p, stageOf(p)?.me, "hurt", 15, "minecraft:basic_smoke_particle"); skip = true; me += 1; await notice(p, "早食い", "§cむせた！"); } else me += n;
  }
  return { win: me > rv, msg: `${me}皿 ／ 相手 ${rv}皿` };
}
async function gSing(p, m, st) {   // 歌合戦（魔力）: 審査員の 気分に 合わせる
  let me = 0, rv = 0; const MOOD = [["しんみり したい", 0], ["もりあがりたい", 1], ["わらいたい", 2]], SG = ["バラード", "ロック", "おもしろい 歌"];
  for (let r = 1; r <= 3; r++) {
    const md = MOOD[ri(3)], c = await choose(p, `歌合戦 ${r}/3`, `§f${m.nm} §e${me | 0}点§f ／ 相手 §c${rv | 0}点\n§d審査員「今日は ${md[0]} 気分だ」`, [...SG.map((s) => B(`§l${s}`, ICON("i_star"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    await act(p, stageOf(p)?.me, "cast", 30, "minecraft:note_particle"); if (c === md[1]) await react(p, true);
    me += (c === md[1] ? 32 : 15) * edge(st, "mat") * (0.9 + rnd() * 0.2); rv += 22 + rnd() * 8;
  }
  return { win: me > rv, msg: `${me | 0}点 ／ 相手 ${rv | 0}点` };
}
async function gEndure(p, m, st) {   // がまんくらべ（硬力・魔硬力）: 相手より 長く、でも 倒れない
  const e = (edge(st, "def") + edge(st, "mdf")) / 2, rq = 3 + ri(5); let t = 0;
  for (;;) {
    const c = await choose(p, "がまんくらべ", `§fサウナの 温度が 上がって いく… §e${t}分§f がまんした\n§7相手は まだ がまん して いる？（${t >= rq ? "§a相手は もう 出た！" : "§c相手は まだ いる"}§7）`, [B("§c§lまだ がまんする", ICON("i_fight")), B("§l出る", ICON("i_back"))]);
    if (c < 0) return QUIT;
    if (c === 1) return { win: t >= rq, msg: `${t}分 ／ 相手 ${rq}分` };
    t++; await act(p, stageOf(p)?.me, "guard", 20, "minecraft:basic_flame_particle");
    if (rnd() < Math.max(0.02, 0.025 * t / e)) { await act(p, stageOf(p)?.me, "faint", 30); await notice(p, "がまんくらべ", `§c${m.nm}は のぼせて しまった…`); return { win: false, msg: "のぼせた" }; }
  }
}
async function gDarts(p, m, st) {   // 的あて（武力）
  let me = 0; const rv = 8 + ri(10), e = edge(st, "wpn");
  for (let t = 1; t <= 3; t++) {
    const c = await choose(p, `的あて ${t}/3`, `§fいまの 点 §e${me}§f ／ 相手 §c${rv}点\n§7まんなか 10点（当たりにくい）・内がわ 5点・外がわ 2点`, [B("§c§lまんなか", ICON("i_fight")), B("§l内がわ", ICON("i_fight")), B("§l外がわ", ICON("i_fight")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    const hit = rnd() < Math.min(0.95, [0.3, 0.6, 0.9][c] * e); if (hit) me += [10, 5, 2][c];
    { const S = stageOf(p); if (S && ok(S.me)) { const tg = S.at(0, 8), off = hit ? [0, 0.6, 1.2][c] : 2.5, land = { x: tg.x + S.r.x * off, y: tg.y + 1, z: tg.z + S.r.z * off }; for (let k = 0; k < 8; k++) fx(S.dim, "minecraft:basic_flame_particle", { x: tg.x + Math.cos(k) * 1.2 * S.r.x, y: tg.y + 1 + Math.sin(k) * 1.2, z: tg.z + Math.cos(k) * 1.2 * S.r.z }); await act(p, S.me, "atk_slash", 8); trail(p, S.me.location, land, "minecraft:critical_hit_emitter"); await pause(p, 15); fx(S.dim, hit ? "minecraft:totem_particle" : "minecraft:basic_smoke_particle", land); await pause(p, 10); } }
    await notice(p, "的あて", hit ? `§a命中！ +${[10, 5, 2][c]}点` : "§cはずれ…");
  }
  return { win: me > rv, msg: `${me}点 ／ 相手 ${rv}点` };
}
async function gBalloon(p, m, st) {   // 風船ふくらまし（吹力）: 大きく するほど 点・われたら 0
  const e = edge(st, "brt"), pop = 9 + ri(8); let sz = 0; const rv = Math.max(4, pop - 4 - ri(3));   /* 相手は われる 少し 手前（かならず 勝てる 見こみが ある） */
  for (;;) {
    const c = await choose(p, "風船ふくらまし", `§f風船の 大きさ §e${sz}§f ／ 相手 §c${rv}\n${sz >= pop - 2 ? "§cキュッ…と 音が した！" : "§7まだ 大丈夫そう"}`, [B("§l1回 ふく", ICON("i_skill")), B(`§c§l${e >= 1 ? 3 : 2}回 ふく`, ICON("i_skill")), B("§aここで やめる", ICON("i_back"))]);
    if (c < 0) return QUIT;
    if (c === 2) return { win: sz > rv, msg: `${sz} ／ 相手 ${rv}` };
    sz += c === 0 ? 1 : e >= 1 ? 3 : 2;
    { const S = stageOf(p); if (S && ok(S.me)) { await act(p, S.me, "breath", 15); const b0 = S.at(0, 2.5); for (let k = 0; k < Math.min(24, sz * 2); k++) fx(S.dim, "minecraft:basic_smoke_particle", { x: b0.x + (rnd() - 0.5) * sz / 6, y: b0.y + 1.5 + (rnd() - 0.5) * sz / 6, z: b0.z + (rnd() - 0.5) * sz / 6 }); if (sz >= pop) { fx(S.dim, "minecraft:huge_explosion_emitter", { x: b0.x, y: b0.y + 1.5, z: b0.z }); await act(p, S.me, "hurt", 20); } } }
    if (sz >= pop) { await notice(p, "風船ふくらまし", "§cパーン！ われて しまった…"); return { win: false, msg: "われた" }; }
  }
}

// ---------- 2) あたまの 遊び ----------
async function gEl(p, m) {   // 属性じゃんけん: 火は 木に、木は 水に、水は 火に 強い
  let a = 0, b = 0; const EL = ["§c火", "§b水", "§a木"];
  for (let r = 1; r <= 9 && a < 3 && b < 3; r++) {
    const ai = ri(3), c = await choose(p, `属性じゃんけん ${r}回目`, `§fあなた §e${a}§f - §c${b}§f 相手\n§7火は 木に、木は 水に、水は 火に 強い\n${rnd() < 0.5 ? `§d${m.nm}が 相手の 手を 見て いる…「${EL[ai]}§d かも」` : ""}`, [...EL.map((x) => B(`§l${x}`, ICON("i_fight"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    if (c === ai) { await notice(p, "属性じゃんけん", "§7あいこ"); continue; }
    const w = (c === 0 && ai === 2) || (c === 2 && ai === 1) || (c === 1 && ai === 0); if (w) a++; else b++;
    { const S = stageOf(p); if (S) { const PT = ["minecraft:basic_flame_particle", "minecraft:water_splash_particle", "minecraft:villager_happy"]; act(p, S.me, "cast", 1, PT[c]); await act(p, S.rvE, "cast", 20, PT[ai]); act(p, w ? S.rvE : S.me, "hurt", 1); await act(p, w ? S.me : S.rvE, "happy", 20); } }
    await notice(p, "属性じゃんけん", `${EL[c]}§f vs ${EL[ai]}§f → ${w ? "§a勝ち" : "§c負け"}`);
  }
  return { win: a >= 3, msg: `${a} - ${b}` };
}
const total = (k) => { const b = SPECIES[k]?.base || {}; return Math.round(Object.values(b).reduce((s, v) => s + v, 0) * 10); };
async function gHiLo(p, m, st, d) {   // ハイ＆ロー: 次の モンスターの 強さ（基本の 能力の 合計）は 上か 下か
  const L = seenList(d); let cur = L[ri(L.length)], n = 0;
  for (;;) {
    let nx = L[ri(L.length)]; for (let t = 0; t < 5 && total(nx) === total(cur); t++) nx = L[ri(L.length)];
    const c = await choose(p, `ハイ＆ロー（${n}連続）`, `§f今の カード: §e${SPECIES[cur].name}§f（強さ ${total(cur)}）\n§f次の モンスターは 強い？ 弱い？\n§74連続で 当てたら 勝ち`, [B("§c§l強い（ハイ）", ICON("i_fight")), B("§b§l弱い（ロー）", ICON("i_fight")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 2) return QUIT;
    const hit = total(nx) === total(cur) || (c === 0) === (total(nx) > total(cur)); await react(p, hit);
    await notice(p, "ハイ＆ロー", `§f次は §e${SPECIES[nx].name}§f（強さ ${total(nx)}）→ ${hit ? "§a当たり！" : "§cはずれ…"}`);
    if (!hit) return { win: false, msg: `${n}連続` };
    n++; cur = nx; if (n >= 4) return { win: true, msg: "4連続" };
  }
}
async function quiz5(p, ttl, mk) {   // 5問中 3問 正解で 勝ち
  let ok = 0;
  for (let q = 1; q <= 5; q++) {
    const Q = mk(); if (!Q) return QUIT;
    const c = await choose(p, `${ttl} ${q}/5`, `${Q.q}\n§7（正解 ${ok}問・5問中 3問で 勝ち）`, [...Q.a.map((x) => B(`§l${x}`, ICON("i_help"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === Q.a.length) return QUIT;
    await react(p, c === Q.k);
    if (c === Q.k) { ok++; sound(p, "random.orb", 1.4); await notice(p, ttl, "§a正解！"); } else await notice(p, ttl, `§cざんねん… 正解は §e${Q.a[Q.k]}`);
  }
  return { win: ok >= 3, msg: `5問中 ${ok}問 正解` };
}
const SZN = { S: "小さい", M: "ふつう", L: "大きい", G: "とても 大きい" };
function gZukan(p, m, st, d) {   // 図鑑クイズ
  const L = seenList(d);
  return quiz5(p, "図鑑クイズ", () => { const k = L[ri(L.length)], s = SPECIES[k], sig = (x) => `${SPECIES[x].famName}${SPECIES[x].rank}${SPECIES[x].sz}${(SPECIES[x].aff?.ge || []).join()}`, opts = shuf([k, ...shuf(L.filter((x) => x !== k && SPECIES[x].name !== s.name && sig(x) !== sig(k))).slice(0, 3)]);
    return { q: `§fこの モンスターは だれ？\n§e${s.famName || ""}・${s.rank}ランク・大きさ ${SZN[s.sz] || "ふつう"}${s.aff?.ge?.length ? `・得意な 属性 ${s.aff.ge.map((e) => EL_NAME[e]).join("・")}` : ""}`, a: opts.map((x) => SPECIES[x].name), k: opts.indexOf(k) }; });
}
function gWeak(p, m, st, d) {   // 弱点クイズ
  const L = seenList(d).filter((k) => SPECIES[k].aff?.be && EL_NAME[SPECIES[k].aff.be]); const ELS = Object.keys(EL_NAME);
  return quiz5(p, "弱点クイズ", () => { if (!L.length) return null; const k = L[ri(L.length)], be = SPECIES[k].aff.be, opts = shuf([be, ...shuf(ELS.filter((e) => e !== be)).slice(0, 3)]);
    return { q: `§e${SPECIES[k].name}§f の 弱点の 属性は？`, a: opts.map((e) => EL_NAME[e]), k: opts.indexOf(be) }; });
}
function gMoveQ(p) {   // 技の 属性クイズ
  const L = Object.keys(MOVES).filter((k) => MOVES[k].el && EL_NAME[MOVES[k].el] && !MOVES[k].boss && !MOVES[k].god && !MOVES[k].sig && MOVES[k].name), ELS = Object.keys(EL_NAME);
  return quiz5(p, "技の 属性クイズ", () => { if (!L.length) return null; const k = L[ri(L.length)], el = MOVES[k].el, opts = shuf([el, ...shuf(ELS.filter((e) => e !== el)).slice(0, 3)]);
    return { q: `§f技「§e${MOVES[k].name}§f」の 属性は？`, a: opts.map((e) => EL_NAME[e]), k: opts.indexOf(el) }; });
}
async function gPairs(p, m, st, d) {   // 神経衰弱: 12枚・めくれるのは 12回（2枚で 1回）
  const L = shuf(seenList(d)).slice(0, 6), cards = shuf([...L, ...L]), open = new Set(); let turns = 12;
  while (turns > 0 && open.size < 12) {
    const pick = [];
    for (let k = 0; k < 2; k++) {
      const btn = cards.map((c, i) => B(open.has(i) || pick.includes(i) ? `§a${SPECIES[c].name}` : `§8？ §7${i + 1}`, open.has(i) || pick.includes(i) ? MON_ICON(c) : ICON("i_help")));
      const c = await choose(p, `神経衰弱 のこり ${turns}回`, `§f同じ モンスターの カードを 2枚 そろえよう（${open.size / 2}/6 組）`, [...btn, B("§7やめる", ICON("i_back"))], true);
      if (c < 0 || c === 12) return QUIT;
      if (open.has(c) || pick.includes(c)) { k--; continue; }
      pick.push(c);
    }
    turns--;
    await react(p, cards[pick[0]] === cards[pick[1]]);
    if (cards[pick[0]] === cards[pick[1]]) { open.add(pick[0]); open.add(pick[1]); sound(p, "random.orb", 1.4); }
    else await notice(p, "神経衰弱", `§f${SPECIES[cards[pick[0]]].name} と ${SPECIES[cards[pick[1]]].name}… §cちがった`);
  }
  return { win: open.size === 12, msg: `${open.size / 2}/6 組` };
}
async function gDance(p, m) {   // ダンス（おぼえる）: 見せた 順に おどる
  const MV = ["ステップ", "ジャンプ", "ターン", "おじぎ"], DANCE_AN = ["atk_dance", "atk_jump", "atk_spin", "guard"];
  for (const len of [3, 4, 5]) {
    const seq = Array.from({ length: len }, () => ri(4));
    const S = stageOf(p), live = S && ok(S.me);
    if ((await choose(p, "ダンス", live ? `§d${m.nm}が ${len}こ おどる。§f画面を とじて よく 見て いて！\n§7（画面の 下にも 名前が 出る）` : `§d${m.nm}の おどりを おぼえよう！\n§e${seq.map((x) => MV[x]).join(" → ")}`, [B(live ? "§l見る" : "§lおぼえた", ICON("i_party")), B("§7やめる", ICON("i_back"))])) !== 0) return QUIT;
    if (live) { await pause(p, 20); for (const x of seq) { bar(p, `§d${MV[x]}`); await act(p, S.me, DANCE_AN[x], 30, "minecraft:note_particle"); await pause(p, 8); } }
    for (let i = 0; i < len; i++) {
      const c = await choose(p, `ダンス ${i + 1}/${len}`, "§f次の おどりは？", [...MV.map((x) => B(`§l${x}`, ICON("i_party"))), B("§7やめる", ICON("i_back"))]);
      if (c < 0 || c === 4) return QUIT;
      if (c !== seq[i]) { await notice(p, "ダンス", `§cまちがえた… 正しくは ${MV[seq[i]]}`); return { win: false, msg: `${len}つの 振り付けで ミス` }; }
    }
    sound(p, "random.orb", 1.4);
  }
  return { win: true, msg: "ぜんぶ おどれた" };
}
async function gNum(p, m) {   // 数あて（1〜15・4回まで）
  const ans = 1 + ri(15); let lo = 1, hi = 15;
  for (let t = 1; t <= 4; t++) {
    const c = await choose(p, `数あて ${t}/4`, `§d${m.nm}が 1〜15の 数を 思いうかべた。\n§fヒント: §e${lo}〜${hi}`, [...Array.from({ length: 15 }, (_, i) => B(i + 1 >= lo && i + 1 <= hi ? `§l${i + 1}` : `§8${i + 1}`, ICON("i_help"))), B("§7やめる", ICON("i_back"))], true);
    if (c < 0 || c === 15) return QUIT;
    const g = c + 1; if (g === ans) return { win: true, msg: `${t}回目で 当てた（${ans}）` };
    if (g < ans) lo = Math.max(lo, g + 1); else hi = Math.min(hi, g - 1);
    await notice(p, "数あて", g < ans ? "§fもっと §c大きい§f 数" : "§fもっと §b小さい§f 数");
  }
  return { win: false, msg: `正解は ${ans}` };
}
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const line3 = (b, v) => LINES.some((l) => l.every((i) => b[i] === v));
async function gTTT(p, m) {   // 三目並べ
  const b = Array(9).fill(0);
  const aiMove = () => { const free = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0); for (const v of [2, 1]) for (const i of free) { b[i] = v; const w = line3(b, v); b[i] = 0; if (w && rnd() < 0.9) return i; } if (!b[4]) return 4; return free[ri(free.length)]; };
  for (;;) {
    const c = await choose(p, "三目並べ", `§fあなたは §b青§f、${m.nm}は §c赤§f。たて・よこ・ななめに 3つ ならべたら 勝ち`, [...b.map((v, i) => B(v === 1 ? "§b§l青" : v === 2 ? `§c§l赤` : `§8${i + 1}`, v === 2 ? MON_ICON(m.sp) : ICON(v === 1 ? "i_party" : "i_help"))), B("§7やめる", ICON("i_back"))], true);
    if (c < 0 || c === 9) return QUIT;
    if (b[c]) continue;
    b[c] = 1; if (line3(b, 1)) return { win: true, msg: "3つ ならんだ！" };
    if (b.every(Boolean)) return { win: false, draw: true, msg: "引き分け" };
    b[aiMove()] = 2; if (line3(b, 2)) return { win: false, msg: `${m.nm}の 勝ち` };
    if (b.every(Boolean)) return { win: false, draw: true, msg: "引き分け" };
  }
}
async function gNim(p, m) {   // 石とり: 1〜3こ とる。最後の 1こを とったら 負け
  let n = 13 + ri(5);
  for (;;) {
    const c = await choose(p, "石とり", `§f石が §e${n}こ§f ある。1〜3こ とる。\n§c最後の 1こを とった ほうが 負け`, [B("§l1こ とる", ICON("i_help")), B("§l2こ とる", ICON("i_help")), B("§l3こ とる", ICON("i_help")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    const t = Math.min(n, c + 1); n -= t; if (n <= 0) return { win: false, msg: "最後の 1こを とった" };
    let a = (n - 1) % 4; if (a === 0 || rnd() < 0.25) a = 1 + ri(3); a = Math.min(n, a); n -= a;
    if (n <= 0) return { win: true, msg: `${m.nm}が 最後の 1こを とった` };
    await notice(p, "石とり", `§d${m.nm}は ${a}こ とった`);
  }
}

// ---------- 3) カード・ボード・あそび場 ----------
async function gCard(p, m, st, d) {   // モンスターカード: パーティの 子で 能力くらべ（3回勝負）
  const hand = d.party.slice(0, 3); let a = 0, b = 0;
  for (let r = 1; r <= 3; r++) {
    const ci = await choose(p, `カード ${r}/3`, `§fあなた §e${a}§f - §c${b}§f 相手\n§f出す カードを えらぶ`, [...hand.map((x) => B(`§l${x.nm}`, MON_ICON(x.sp))), B("§7やめる", ICON("i_back"))]);
    if (ci < 0 || ci === hand.length) return QUIT;
    const s2 = calcStats(hand[ci]), KS = ["atk", "mat", "def", "spd", "wpn"];
    const ki = await choose(p, `カード ${r}/3`, `§e${hand[ci].nm}§f で 勝負する 能力は？\n${KS.map((k) => `§f${STN[k]} ${s2[k]}`).join("・")}`, [...KS.map((k) => B(`§l${STN[k]}`, ICON("i_skill"))), B("§7やめる", ICON("i_back"))]);
    if (ki < 0 || ki === KS.length) return QUIT;
    const k = KS[ki], rv = Math.round(rival(s2, k)), rn = rivalName(p), w = s2[k] >= rv;
    if (w) a++; else b++;
    { const S = stageOf(p); if (S && ok(S.me)) { try { setLook(S.me, hand[ci].sp, hand[ci]); S.me.nameTag = `§b${hand[ci].nm}`; } catch {} await act(p, S.me, "atk_charge", 15); await act(p, S.rvE, "atk_charge", 15); await act(p, w ? S.rvE : S.me, "hurt", 1); await act(p, w ? S.me : S.rvE, "happy", 20); } }
    await notice(p, "カード", `§f${hand[ci].nm}の ${STN[k]} §e${s2[k]}§f vs ${rn} §c${rv}\n${w ? "§a勝ち！" : "§c負け…"}`);
  }
  return { win: a >= 2, msg: `${a} - ${b}` };
}
async function gSugo(p, m) {   // すごろく: 20マス、相手より 先に ゴール
  let a = 0, b = 0, rest = false; const EV = { 4: 3, 7: -2, 11: 4, 14: "rest", 17: -3 };
  for (let t = 1; t <= 12; t++) {
    let msg = "";
    if (rest) { rest = false; msg = "§c1回 休み"; }
    else {
      if ((await choose(p, `すごろく ${t}`, `§fあなた §e${a}§f／20  相手 §c${b}§f／20\n§74マス目 +3・7マス目 -2・11マス目 +4・14マス目 1回休み・17マス目 -3`, [B("§l§eサイコロを ふる", ICON("i_star")), B("§7やめる", ICON("i_back"))])) !== 0) return QUIT;
      const dv = 1 + ri(6); a = Math.min(20, a + dv); msg = `§fサイコロ §e${dv}`; const ev = EV[a];
      if (ev === "rest") { rest = true; msg += "・§c次は 休み"; } else if (ev) { a = Math.max(0, Math.min(20, a + ev)); msg += `・${ev > 0 ? `§a${ev}マス 進む` : `§c${-ev}マス もどる`}`; }
    }
    const b0 = b;
    if (a >= 20) { const S = stageOf(p); if (S && ok(S.me)) await go(p, S.me, S.at(-1.2, 13), 25, 0.8); return { win: true, msg: "先に ゴール！" }; }
    b = Math.min(20, b + 1 + ri(6)); if (EV[b] && EV[b] !== "rest") b = Math.max(0, Math.min(20, b + EV[b]));
    { const S = stageOf(p); if (S && ok(S.me)) { const P0 = (n, side) => S.at(side, 1 + n * 0.6); await Promise.all([go(p, S.me, P0(a, -1.2), 25, 0.8), go(p, S.rvE, P0(b, 1.2), 25, 0.8)]); } }
    if (b >= 20) return { win: false, msg: "相手が 先に ゴール" };
    await notice(p, "すごろく", `${msg}\n§fあなた ${a} ／ 相手 ${b}`);
  }
  return { win: a > b, msg: `${a} ／ ${b}` };
}
async function gTreasure(p, m) {   // 宝さがし: 3×3・3回 ほれる・ヒントは 近さ
  const tr = ri(9), dug = new Set(); const dist = (i) => Math.abs((i % 3) - (tr % 3)) + Math.abs(Math.floor(i / 3) - Math.floor(tr / 3));
  for (let t = 1; t <= 3; t++) {
    const c = await choose(p, `宝さがし ${t}/3`, `§d${m.nm}が においを かいで いる…\n§fどこを ほる？ §7（目の 前の 地面の 3×3。1が 左手前、9が 右おく）`, [...Array.from({ length: 9 }, (_, i) => B(dug.has(i) ? "§8ほった" : `§6${i + 1}`, ICON("i_help"))), B("§7やめる", ICON("i_back"))], true);
    if (c < 0 || c === 9) return QUIT;
    if (dug.has(c)) { t--; continue; }
    { const S = stageOf(p); if (S && ok(S.me)) { if (t === 1) for (let i = 0; i < 9; i++) fx(S.dim, "minecraft:villager_happy", (() => { const q = S.at((i % 3 - 1) * 2, 3 + Math.floor(i / 3) * 2); return { x: q.x, y: q.y + 0.3, z: q.z }; })()); const q = S.at((c % 3 - 1) * 2, 3 + Math.floor(c / 3) * 2); await go(p, S.me, q, 25); for (let k = 0; k < 3; k++) await act(p, S.me, "atk_claw", 10, "minecraft:basic_smoke_particle"); if (c === tr) { for (let k = 0; k < 10; k++) fx(S.dim, "minecraft:totem_particle", { x: q.x, y: q.y + 1, z: q.z }); await react(p, true); } } }
    dug.add(c); if (c === tr) return { win: true, msg: `${t}回目で 見つけた` };
    const dv = dist(c); await notice(p, "宝さがし", dv === 1 ? `§c${m.nm}「とても 近い！」` : dv === 2 ? `§e${m.nm}「ちょっと 近い」` : `§b${m.nm}「遠い みたい」`);
  }
  return { win: false, msg: `宝は ${tr + 1}番に あった` };
}
async function gMaze(p, m) {   // 迷路: 4×4・24歩まで
  const N = 4, wall = Array.from({ length: N * N }, () => [1, 1, 1, 1]), seen = new Set([0]), st = [0], DX = [[0, -1], [1, 0], [0, 1], [-1, 0]];   /* 北 東 南 西 */
  while (st.length) { const c = st[st.length - 1], x = c % N, y = (c / N) | 0, nb = shuf([0, 1, 2, 3]).filter((k) => { const nx = x + DX[k][0], ny = y + DX[k][1]; return nx >= 0 && ny >= 0 && nx < N && ny < N && !seen.has(ny * N + nx); }); if (!nb.length) { st.pop(); continue; } const k = nb[0], n = (y + DX[k][1]) * N + x + DX[k][0]; wall[c][k] = 0; wall[n][(k + 2) % 4] = 0; seen.add(n); st.push(n); }
  let pos = 0; const DN = ["北", "東", "南", "西"];
  for (let t = 24; t > 0; t--) {
    const x = pos % N, y = (pos / N) | 0, open = [0, 1, 2, 3].filter((k) => !wall[pos][k]);
    const c = await choose(p, `迷路 のこり ${t}歩`, `§fいま §e${x + 1}列 ${y + 1}行§f（ゴールは §a4列 4行§f）\n§7進める 方向: ${open.map((k) => DN[k]).join("・")}\n§d${m.nm}「${DN[Math.abs(3 - x) >= Math.abs(3 - y) ? 1 : 2]}の 方から 風が くる」`, [...DN.map((n, k) => B(open.includes(k) ? `§l${n}へ` : `§8${n}（かべ）`, ICON("i_run"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 4) return QUIT;
    if (wall[pos][c]) { t++; continue; }
    pos += DX[c][1] * N + DX[c][0]; if (pos === N * N - 1) return { win: true, msg: `のこり ${t - 1}歩で ゴール` };
  }
  return { win: false, msg: "歩きつかれた" };
}
const RV = { F: 1, E: 2, D: 3, C: 4, B: 5, A: 6, S: 7 };
async function g21(p, m, st, d) {   // 21: モンスターカードの ランクの 数を 足して 21に 近づける
  const L = seenList(d).filter((k) => RV[SPECIES[k].rank]), draw = () => { const k = L[ri(L.length)]; return [SPECIES[k].name, RV[SPECIES[k].rank]]; };
  if (!L.length) return QUIT;
  const me = [draw(), draw()];
  for (;;) {
    const s = me.reduce((a, c) => a + c[1], 0);
    if (s > 21) return { win: false, msg: `${s}（21を こえた）` };
    const c = await choose(p, "21", `§fあなたの カード: §e${me.map((x) => `${x[0]}(${x[1]})`).join("・")}\n§f合計 §e${s}§7（F=1 … S=7。21を こえたら 負け）`, [B("§l§eもう 1枚", ICON("i_star")), B("§lこれで 勝負", ICON("i_fight")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 2) return QUIT;
    if (c === 0) { me.push(draw()); continue; }
    let r = 0; while (r < 16) r += draw()[1];
    const win = r > 21 || s > r; return { win, draw: !win && s === r, msg: `あなた ${s} ／ ${m.nm} ${r}${r > 21 ? "（21超え）" : ""}${s === r ? "（同じ 数は 引き分け）" : ""}` };
  }
}
async function gCook(p, m) {   // 料理コンテスト: 審査員の 好みを 当てる
  const TS = ["あまい", "からい", "すっぱい", "しょっぱい"], fav = ri(4), like = ri(4), ING = [["はちみつ", 0], ["とうがらし", 1], ["レモン", 2], ["しお", 3], ["くだもの", 0], ["こしょう", 1], ["お酢", 2], ["しょうゆ", 3]];
  const pick = shuf(ING).slice(0, 6); let sc = 0;
  for (let r = 1; r <= 3; r++) {
    const c = await choose(p, `料理コンテスト ${r}/3`, `§d審査員「${TS[fav]} ものが 大好き。${TS[like]} ものも 好き」\n§f入れる 材料を えらぶ（いまの 点 §e${sc}§f）`, [...pick.map((x) => B(`§l${x[0]}`, ICON("i_shop"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === pick.length) return QUIT;
    sc += pick[c][1] === fav ? 4 : pick[c][1] === like ? 2 : 0;
    await act(p, stageOf(p)?.me, "atk_bite", 15, pick[c][1] === fav ? "minecraft:heart_particle" : "minecraft:villager_happy");
  }
  const rv = 5 + ri(4); return { win: sc > rv, msg: `${sc}点 ／ 相手 ${rv}点` };
}
async function gShow(p, m, st) {   // モンスターコンテスト: 審査員の 好みに 合わせて アピール
  const AP = [["かっこよさ", "spd"], ["かしこさ", "mat"], ["たくましさ", "atk"], ["かわいさ", "hp"]]; let me = 0, rv = 0;
  for (let r = 1; r <= 3; r++) {
    const f = ri(4), c = await choose(p, `コンテスト ${r}/3`, `§f${m.nm} §e${me | 0}点§f ／ 相手 §c${rv | 0}点\n§d審査員「${AP[f][0]}が 見たいな」\n§7${m.nm}の 得意: ${AP.map((a) => `${a[0]} ${Math.round(edge(st, a[1]) * 100)}%`).join("・")}`, [...AP.map((a) => B(`§l${a[0]}`, ICON("i_star"))), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 4) return QUIT;
    await act(p, stageOf(p)?.me, ["atk_spin", "cast", "roar", "happy"][c], 30, c === f ? "minecraft:totem_particle" : "minecraft:villager_happy");
    me += (c === f ? 30 : 12) * edge(st, AP[c][1]) * (0.9 + rnd() * 0.2); rv += 22 + rnd() * 6;
  }
  return { win: me > rv, msg: `${me | 0}点 ／ 相手 ${rv | 0}点` };
}
async function gBall(p, m, st) {   // ボール遊び: 5回 投げて 仲間が とる
  const e = edge(st, "spd"); let sc = 0; const goal = 9;
  for (let t = 1; t <= 5; t++) {
    const c = await choose(p, `ボール遊び ${t}/5`, `§f${m.nm}が とれたら 点（いま §e${sc}§f／${goal}点で 勝ち）`, [B("§lやさしく 投げる §8（1点）", ICON("i_party")), B("§l遠くへ 投げる §8（2点）", ICON("i_party")), B("§c§l高く 投げる §8（4点）", ICON("i_party")), B("§7やめる", ICON("i_back"))]);
    if (c < 0 || c === 3) return QUIT;
    const got = rnd() < Math.min(0.97, [0.95, 0.7, 0.4][c] * e);
    { const S = stageOf(p); if (S && ok(S.me)) { const q = S.at((rnd() - 0.5) * 4, [4, 7, 9][c]), P = p.location; trail(p, { x: P.x, y: P.y + 0.5 + (c === 2 ? 2 : 0), z: P.z }, q, "minecraft:snowflake_particle"); const near = S.at(0, [3, 5, 6][c]); await go(p, S.me, got ? q : near, got ? 22 : 18, c === 2 && got ? 1.2 : 0); await act(p, S.me, got ? "happy" : "hurt", 15); await home(p); } }
    if (got) { sc += [1, 2, 4][c]; await notice(p, "ボール遊び", `§a${m.nm}が キャッチ！ +${[1, 2, 4][c]}`); } else await notice(p, "ボール遊び", `§c${m.nm}は とれなかった…`);
    if (sc >= goal) return { win: true, msg: `${sc}点` };
  }
  return { win: false, msg: `${sc}点` };
}
/* 時間の ある 遊び（画面を とじて 自分で 走る）。秒数 sec の 間 tick を まわし、なぐったら 勝ち */
function realtime(p, sec, tick, title) {
  const S = stageOf(p); if (!S || !ok(S.me)) return Promise.resolve(null);
  return new Promise((res) => {
    let t = 0, iv = null, fin = false; const end = (v) => { if (fin) return; fin = true; S.onHit = null; S.wake.delete(stop); if (iv !== null) { try { system.clearRun(iv); } catch {} S.ivs.delete(iv); } res(v); };
    const stop = () => end(null); S.wake.add(stop);
    S.onHit = (e, q) => { try { if (e.id === S.me.id && Math.hypot(q.location.x - e.location.x, q.location.z - e.location.z) < 4.5) end(true); else if (e.id === S.me.id) bar(p, "§7もっと 近くで タッチしよう（4ブロック 以内）"); } catch {} };
    iv = system.runInterval(() => { t++; if (!ok(S.me)) return end(null); try { if (!p.isValid() || p.dimension.id !== S.dim.id || Math.hypot(p.location.x - S.o.x, p.location.z - S.o.z) > 48) { bar(p, `§7${title}は おしまい（はなれた）`); return end(null); } } catch { return end(null); } let msg = ""; try { msg = tick(t) || ""; } catch {} if (t % 10 === 0) bar(p, `§e${title} §fのこり ${sec - t / 20 | 0}秒 ${msg}`); if (t >= sec * 20) end(false); }, 1);
    S.ivs.add(iv);
  });
}
async function gHide(p, m) {   // かくれんぼ: 仲間が 近くに かくれる。音と けむりを たよりに さがして なぐる（60秒）
  const S = stageOf(p);
  if (!S || !ok(S.me)) return QUIT;
  if ((await choose(p, "かくれんぼ", `§f${m.nm}が かくれる！ §e60秒§f で 見つけて なぐろう。\n§7画面の 下に「あつい（近い）・つめたい（遠い）」が 出る。ときどき かくれた 場所で 緑の キラキラが 光る。見つけたら 近くで なぐる（タッチ）`, [B("§l§eはじめる", ICON("i_run")), B("§7やめる", ICON("i_back"))])) !== 0) return QUIT;
  const a = rnd() * Math.PI * 2, rr = 7 + rnd() * 7, x = S.o.x + Math.cos(a) * rr, z = S.o.z + Math.sin(a) * rr, spot = { x, y: groundY(S.dim, x, S.o.y, z), z };
  await go(p, S.me, spot, 40); try { S.me.addEffect("invisibility", 20 * 70, { showParticles: false }); S.me.nameTag = ""; } catch {}
  const r = await realtime(p, 60, (t) => { const L = p.location, dd = Math.hypot(L.x - spot.x, L.z - spot.z);
    if (t % 100 === 50) for (let k = 0; k < 5; k++) fx(S.dim, "minecraft:villager_happy", { x: spot.x + (rnd() - 0.5), y: spot.y + 1 + rnd(), z: spot.z + (rnd() - 0.5) });
    return dd < 3 ? "§c§lあつい！ すぐ そば" : dd < 6 ? "§6あたたかい" : dd < 10 ? "§eぬるい" : "§bつめたい（遠い）"; }, "かくれんぼ");
  try { S.me.removeEffect("invisibility"); S.me.nameTag = `§b${m.nm}`; } catch {}
  if (r === null) return QUIT;
  await react(p, r);
  return { win: r, msg: r ? "見つけた！" : "時間切れ…" };
}
async function gTag(p, m, st) {   // 鬼ごっこ: 仲間が にげる。40秒で つかまえて（なぐって）勝ち
  const S = stageOf(p);
  if (!S || !ok(S.me)) return QUIT;
  const v = 0.17 * Math.max(0.8, Math.min(1.3, edge(st, "spd")));   /* 1tickに 進む きょり（走る プレイヤーより 少し おそい） */
  if ((await choose(p, "鬼ごっこ", `§f${m.nm}が にげる！ §e40秒§f で 追いかけて、近くで なぐって（タッチして）つかまえよう。\n§7走力が 高い 子ほど 速い（この 子は ${Math.round(v / 0.17 * 100)}%）。はなれすぎない 広場の 中を にげる`, [B("§l§eはじめる", ICON("i_run")), B("§7やめる", ICON("i_back"))])) !== 0) return QUIT;
  const c0 = { ...S.o };
  const r = await realtime(p, 40, (t) => { if (t % 2) return; const e = S.me, l = e.location, P = p.location;
    let dx = l.x - P.x, dz = l.z - P.z; const dd = Math.hypot(dx, dz) || 1; if (dd > 9) return;   /* 遠い ときは 休む */
    dx /= dd; dz /= dd; let nx = l.x + dx * v * 2, nz = l.z + dz * v * 2;
    const cx = nx - c0.x, cz = nz - c0.z, cr = Math.hypot(cx, cz); if (cr > 12) { const sx = -cz / cr, sz = cx / cr, sgn = (sx * dx + sz * dz) >= 0 ? 1 : -1; nx = l.x + sx * sgn * v * 2 - cx / cr * 0.2; nz = l.z + sz * sgn * v * 2 - cz / cr * 0.2; }
    try { e.teleport({ x: nx, y: groundY(S.dim, nx, l.y, nz), z: nz }, { facingLocation: { x: nx + (nx - l.x), y: l.y, z: nz + (nz - l.z) } }); } catch {} }, "鬼ごっこ");
  if (r === null) return QUIT;
  await react(p, r);
  return { win: r, msg: r ? "つかまえた！" : "にげきられた" };
}

// ---------- 一覧 ----------
export const GAMES = [
  ["run", "かけっこ", "走力", gRun], ["sumo", "すもう", "物力", gSumo], ["tug", "綱引き", "武力", gTug], ["jump", "高とび", "走力・物力", gJump], ["swim", "水泳", "走力", gSwim],
  ["eat", "早食い", "HP", gEat], ["sing", "歌合戦", "魔力", gSing], ["endure", "がまんくらべ", "硬力・魔硬力", gEndure], ["darts", "的あて", "武力", gDarts], ["balloon", "風船ふくらまし", "吹力", gBalloon],
  ["el", "属性じゃんけん", "", gEl], ["hilo", "ハイ＆ロー", "", gHiLo], ["zukan", "図鑑クイズ", "", gZukan], ["weak", "弱点クイズ", "", gWeak], ["moveq", "技の 属性クイズ", "", gMoveQ],
  ["pairs", "神経衰弱", "", gPairs], ["dance", "ダンス", "", gDance], ["num", "数あて", "", gNum], ["ttt", "三目並べ", "", gTTT], ["nim", "石とり", "", gNim],
  ["card", "モンスターカード", "", gCard], ["sugo", "すごろく", "", gSugo], ["treasure", "宝さがし", "", gTreasure], ["hide", "かくれんぼ", "", gHide], ["maze", "迷路", "", gMaze],
  ["b21", "21", "", g21], ["cook", "料理コンテスト", "", gCook], ["show", "モンスターコンテスト", "", gShow], ["ball", "ボール遊び", "走力", gBall], ["tag", "鬼ごっこ", "", gTag],
];
const CATS = [["§c§lきそう\n§8能力で 勝負", 0, "i_fight"], ["§b§lあたま\n§8クイズ・パズル", 10, "i_help"], ["§a§lあそび場\n§8カード・すごろく", 20, "i_party"]];
const plOf = (p) => { const e = exOf(p); const r = e.pl && typeof e.pl === "object" ? e.pl : (e.pl = {}); if (r.d !== dayNo()) { r.d = dayNo(); r.w = {}; } r.w = r.w || {}; r.b = r.b || {}; r.n = r.n || 0; return r; };
export const goldOf = (lv) => 300 + Math.min(100, lv || 1) * 8;

async function pickMon(p, d, g) {
  if (!d.party?.length) { await notice(p, "あそぶ", "§7パーティに モンスターが いません。"); return null; }
  if (d.party.length === 1) return d.party[0];
  const c = await choose(p, g[1], `§fいっしょに 遊ぶ 仲間を えらぶ${g[2] ? `\n§7この 遊びは §e${g[2]}§7 が 高い 子が 有利` : ""}`, [...d.party.map((m) => B(`§l${m.nm} §8Lv${m.lv}`, MON_ICON(m.sp))), B("§7戻る", ICON("i_back"))]);
  return c >= 0 && c < d.party.length ? d.party[c] : null;
}
export async function playOne(p, d, gi) {
  const g = GAMES[gi]; if (!g) return;
  const m0 = await pickMon(p, d, g); if (!m0) return;
  const id = m0.id, st = calcStats(m0);
  try { if (p.getComponent("minecraft:riding")?.entityRidingOn) { await notice(p, g[1], "§7ライドから おりて から 遊ぼう。"); return; } } catch {}
  const KIND = { run: "race", swim: "race", sugo: "race", sumo: "duel", tug: "duel", el: "duel", card: "duel" };
  let myS = null; try { myS = stageUp(p, d, m0, KIND[g[0]] || "solo"); } catch (e) { console.warn(`[MonsterRPG] stage: ${e}`); }
  let r = QUIT; try { r = await g[3](p, m0, st, d); if (r && r !== QUIT && stageOf(p)) await act(p, stageOf(p).me, r.win ? "happy" : "hurt", 25, r.win ? "minecraft:totem_particle" : null); } catch (e) { console.warn(`[MonsterRPG] play ${g[0]}: ${e}`); r = QUIT; } finally { if (!myS || ST.get(p.id) === myS) stageEnd(p); }
  if (r === QUIT || !r) return;
  /* ここから await なし で 記録と ほうび（いまの データを 読みなおす） */
  const d2 = load(p); if (!d2) return;
  const m = [...d2.party, ...(d2.bench || []), ...(d2.box || [])].find((x) => x.id === id);
  const L = plOf(p), lines = [r.msg ? `§f${r.msg}` : ""];
  L.b[g[0]] = (L.b[g[0]] || 0) + (r.win ? 1 : 0);
  if (r.win) {
    sound(p, "random.levelup", 1.4); lines.unshift("§a§l勝ち！");
    if (!L.w[g[0]]) {
      L.w[g[0]] = 1; L.n++;
      lines.push(`§eきょう はじめての 勝ち！ ${giveGold(d2, goldOf(m?.lv))}`);
      if (Object.keys(L.w).length % 5 === 0) { const got = prize(p, d2, Math.min(9, Math.floor((m?.lv || 1) / 10)), 0, 1); if (got.length) lines.push(`§b${Object.keys(L.w).length}種類 勝った ほうび: ${got.join("・")}`); }
      if (L.n >= 10) award(p, d2, "pl_10", null); if (L.n >= 100) award(p, d2, "pl_100", null); if (GAMES.every((x) => L.b[x[0]] > 0)) award(p, d2, "pl_all", null);
      save(p, d2);
      if (m) try { __bond.addNk(p, m, 3, "いっしょに 遊んだ"); } catch {}
    } else lines.push("§7（ほうびは この 遊び 1日 1回。また 明日）");
  } else lines.unshift(r.draw ? "§e引き分け" : "§c負け…"), lines.push("§7また 挑戦しよう！（ほうびは 勝ったとき）");
  exSave(p, true);
  await notice(p, g[1], lines.filter(Boolean).join("\n"));
}
export async function playMenu(p, d) {
  for (;;) {
    const L = plOf(p), done = Object.keys(L.w).length;
    const c = await choose(p, "モンスターと あそぶ", `§fパーティの 仲間と ミニゲーム（30種類）。仲間が 目の 前に 出て 動くので、§eひらけた 場所§fで 遊ぼう。\n§fきょう 勝った 遊び §e${done}/30§f。それぞれ 1日 1回、はじめて 勝つと お金と きずな（5種類ごとに 道具）。`, [...CATS.map((x) => B(x[0], ICON(x[2]))), B("§e§l遊びの 記録", ICON("i_star")), B("§7戻る", ICON("i_back"))]);
    if (c < 0 || c === 4) return;
    if (c === 3) { await notice(p, "遊びの 記録", `§fその日 はじめての 勝ち（合計）: §e${L.n}回\n` + GAMES.map((g) => `${L.b[g[0]] ? "§a" : "§8"}${g[1]} ${L.b[g[0]] || 0}勝${L.w[g[0]] ? " §e（きょう 済）" : ""}`).join("\n")); continue; }
    for (;;) {
      const o = CATS[c][1], L2 = plOf(p);
      const s = await choose(p, CATS[c][0].split("\n")[0].replace(/§./g, ""), "§fあそびを えらぶ（§a済§f = きょうの ほうびは もらった）", [...GAMES.slice(o, o + 10).map((g) => B(`§l${g[1]}${L2.w[g[0]] ? " §a済" : ""}${g[2] ? `\n§8${g[2]}` : ""}`, ICON(CATS[c][2]))), B("§7戻る", ICON("i_back"))], true);
      if (s < 0 || s === 10) break;
      await playOne(p, load(p) || d, o + s);
    }
  }
}
TITLES.pl_10 = ["遊び 上手", "ミニゲームで 10回 その日 はじめての 勝ち"]; TITLES.pl_100 = ["遊びの 達人", "ミニゲームで 100回 その日 はじめての 勝ち"]; TITLES.pl_all = ["遊びの 王様", "30種類 ぜんぶの ミニゲームで 勝つ"];
EXH.play = playMenu;
export const __play = { GAMES, plOf, playOne, rival, edge };
