import * as SUI from "@minecraft/server-ui";
// バトル（野生・ボス・レイド・協力・プレイヤー対戦）
import { world, system, MolangVariableMap } from "@minecraft/server";
import { MOVES, SPECIES, ITEMS, CATS, NATURES, EL_NAME, SKILLS, SKILLBOOKS, WEATHER, EGGS, BOSS_SLAB } from "./data.js";
import {
  ri, alive, calcStats, makeMonster, expYield, goldYield, expGapMul, hpBack, gainExp, fighter, statusText, scoutChance, scoutGain, scoutExtra, scoutCap, scoutMulOf, scoutActs, raidCap, escapeChance,
  aiDecide, npcKit, actionOrder, expandActions, rollActs, TACTICS, runAction, BAL, wildHpK, battleItem, endOfTurn, battleStart, fighterStart, fieldBonus, matDrop, canJoin, addMon, sizeOf, SZ_TARGET, tuneMonster, moveDesc, moveLabel, costOf, sealedFor, giveHidden, fixParty, promoteBench, canFight, slotOf, rankIdxM, rankIdx,
  applyBuilds, fTags, hitHint, scoutText, weakBrief, estPct,
} from "./core.js";
import { wxName, STATS, TAL_MAX } from "./core.js";
import { inRuins, RU_INN } from "./ruinsarea.js";
import { load, save, mark, addRank, allMonsDeep, GOLD_MAX, isHost } from "./store.js";
import { isGear, rollGear, giveGear, gearName, capRoll } from "./gear.js";
import { WREGIONS as WR_, regionIdxAt as rIdxAt_ } from "./worldmap.js";
import { traitFx as C_traitFx, battleMoves, MSET_MAX } from "./core.js";
import { buildStage, removeStage, themeOf, addPending, dropPending, recheckStage, waitLoaded, boxFree, liveAdd, LIVE, areaLoaded } from "./stage.js";
import { TYPE, setLook, pickWild, biomeAt, wildInfo, findPet, makePetGroups, refreshPet, isSea, hooks } from "./field.js";
import { getRuin, setRuin, groundY, TOWNS, getTown } from "./structures.js";
import { masterDefeated, MASTER_TIER, recordRival, addMasterRank } from "./master.js";
import { itemDesc, autoSP } from "./menu.js";
import { tacticsAll } from "./tactics.js";
import { qs, giveSlab, RUIN_SLAB, ruinLv, slabTierOk, RUIN_NEED, rankCap, storyLootOk, wtCap, slabBossLv, CROWN, partyPower } from "./quest.js";
const BOSS_EXP = +(globalThis.process?.env?.BEXP ?? 2.2), BOSS_OEXP = +(globalThis.process?.env?.BOEXP ?? 2.6), BOSS_HPEXP = +(globalThis.process?.env?.BHEXP ?? 1.6);   // ボスの 強さの 曲線（シミュレーションで 調整）
import { rfOn } from "./postgame.js";
import { tsubaReady, tsubaTransform, musashiAct, musashiBattleStart, musashiWin } from "./majin.js";
import { rollTier, chestCmds, tierName } from "./chests.js";
const wantConfirm = (p) => { try { return p.getDynamicProperty("mrpg:noconfirm") !== true; } catch { return true; } };
import { GRID_ON, pagedGrid, bodyLines, gridBodyMax, heavy, isLite, busy, ok, wait, wait as waitT, choose, notice, confirm, anim, particle, sound, subtitle, ICON, MON_ICON, ITEM_ICON, rpgItems, takeItem, giveItem, gold, cmd, paged, meter, rankOf, seedId, barNote, clipT, BAR_T, showTitle, hudSend, TITLE_T, battleTitle, barNote as barNote2, hudBusy, hudResend } from "./ui.js";

const BOX_MAX = Infinity;   // v3.0: 預かり所は いくらでも
const SLAB_MOVES = ["sb_meteor", "sb_glacier", "sb_judge", "sb_abyss", "sb_quake", "sb_tempest", "sb_thunder", "sb_rend", "sb_crush", "sb_seal", "sb_roar", "sb_awake"];
const EL_FX = {
  fire: ["minecraft:lava_particle", "minecraft:basic_flame_particle", "mob.blaze.shoot"],
  ice: ["minecraft:snowflake_particle", "minecraft:white_smoke_particle", "random.glass"],
  wind: ["minecraft:wind_explosion_emitter", "minecraft:white_smoke_particle", "mob.breeze.wind_burst"],
  thunder: ["minecraft:electric_spark_particle", "minecraft:critical_hit_emitter", "ambient.weather.thunder"],
  dark: ["minecraft:soul_particle", "minecraft:portal_reverse_particle", "mob.wither.shoot"],
  earth: ["minecraft:explosion_particle", "minecraft:large_explosion", "dig.stone"],
  light: ["minecraft:totem_particle", "minecraft:endrod", "random.orb"],
  heal: ["minecraft:villager_happy", "minecraft:heart_particle", "random.orb"],
};
const BATTLE_ITEMS = new Set(["heal", "healall", "fullall", "mpheal", "cure", "revive", "scout", "bbuff", "bomb", "escape", "mpall", "reviveall", "curall", "bdebuff", "bstatus", "bregen"]);
const battles = new Map(); // bid -> B
const ENMA_T = new Map(), ENMA_S = new Set();
// v3.0: エンマの 技（どれも 最上位。勝たれる たびに 2つずつ ふえる）
// v3.0: 石板の 王 ヴァルグレイドの 技（固有技 2つ＋ 物理・武・息・魔法・特質・補助の 8つ）
// 第65版: クリア後の 石板の 主（王系）の 技。
// ・全体の 強化を かき消す 技 1つ（王ごとに ちがう）・固有技 2つ（王の 固有技 ＋ 物語で その 石板に いた 主の 固有技）
// ・あとは 主ごとの 性格（先手必勝・状況分析・搦手上手・反撃時間・後援者）に あわせた 技。前の 主と なるべく かぶらない
const RE_PERS = ["sente", "analyze", "karame", "counter", "backer"];
const RE_KIT = new Map();
const okMv = (v) => v && !v.sig && !v.boss && !v.god && !v.combo && !v.reraise && !v.selfko && !v.death && !v.mimic;
const isAtk = (v) => v && (v.kind === "attack" || v.kind === "drain");
function rePools(S) {
  const els = (S.aff && S.aff.ge) || [], cat = { phys: "phys", weapon: "weapon", magic: "magic", breath: "breath" }[S.role || (S.aff && S.aff.gc)] || "weapon";
  const L = (f) => Object.keys(MOVES).filter((k) => okMv(MOVES[k]) && f(MOVES[k]));
  return {
    atkS: L((v) => isAtk(v) && v.target === "enemy" && v.cat === cat && els.includes(v.el) && (v.tier || 1) >= 3),
    atkA: L((v) => isAtk(v) && v.target === "enemies" && els.includes(v.el) && (v.tier || 1) >= 3),
    prio: L((v) => isAtk(v) && (v.pri || 0) > 0 && (v.tier || 1) >= 2),
    ail: L((v) => !isAtk(v) && v.ail && ["enemy", "enemies"].includes(v.target)),
    deb: L((v) => !isAtk(v) && v.buff && Object.values(v.buff).every((x) => x < 0) && ["enemy", "enemies"].includes(v.target) && (v.tier || 1) >= 2),
    buff: L((v) => !isAtk(v) && v.buff && Object.values(v.buff).every((x) => x > 0) && ["self", "allies"].includes(v.target) && (v.tier || 1) >= 2),
    refl: L((v) => v.refl && v.target === "self"),
    heal: L((v) => v.heal && !v.revive && !isAtk(v) && ["self", "ally", "allies"].includes(v.target)),
  };
}
const RE_PLAN = { sente: ["atkS", "atkS", "atkA", "prio", "buff"], analyze: ["atkS", "atkA", "heal", "deb", "ail"], karame: ["ail", "ail", "deb", "atkS", "atkA"],
  counter: ["refl", "buff", "atkS", "atkA", "heal"], backer: ["buff", "deb", "heal", "atkA", "ail"] };
function reKit(idx, kings0, own) {
  if (idx === undefined || idx === null) return { moves: own };
  if (RE_KIT.has(idx)) return RE_KIT.get(idx);
  const kings = Array.isArray(kings0) ? kings0 : [];
  const cnt = new Map(), use = (m) => cnt.set(m, (cnt.get(m) || 0) + 1);
  for (let i = 0; i < kings.length; i++) {
    const s = kings[i]; if (!s || s === "haken" || !SPECIES[s]) continue;
    if (RE_KIT.has(i)) { for (const m of RE_KIT.get(i).moves) use(m); continue; }
    const S = SPECIES[s], tac = RE_PERS[i % RE_PERS.length], P = rePools(S), kit = [];
    const add = (m) => { if (m && MOVES[m] && !kit.includes(m)) kit.push(m); };
    const allDisp = (m) => { const v = MOVES[m]; return !!v && v.target === "enemies" && (v.dispel || v.dispelhit); };
    const sigs = [S.sig, SPECIES[(BOSS_SLAB[i] || {}).sid]?.sig].filter((m) => MOVES[m]);
    if (!sigs.some(allDisp)) add("rkd_" + s);   // 全体の 強化を かき消す 技は ちょうど 1つ
    for (const m of sigs) add(m);   // 固有技 2つ（王の 固有技 ＋ 物語で この 石板に いた 主の 固有技）
    RE_PLAN[tac].forEach((pk, j) => { const pool = P[pk] || []; if (!pool.length) return; const fresh = pool.filter((m) => !cnt.get(m) && !kit.includes(m)); const L2 = fresh.length ? fresh : pool.filter((m) => !kit.includes(m)); if (L2.length) add(L2[(i * 5 + j * 3) % L2.length]); });
    for (const m of kit) use(m);
    RE_KIT.set(i, { moves: kit, tac });
  }
  return RE_KIT.get(idx) || { moves: own };
}
// 第68版: ガチの 技構成（固有技 ＋ 性格ごとの 攻め・守り・回復・弱体を 臨機応変に）
const DISP_ALL = () => Object.keys(MOVES).filter((k) => MOVES[k].target === "enemies" && (MOVES[k].dispel || MOVES[k].dispelhit));
function gachiKit(f, tac, wantDisp) {
  const S = SPECIES[f.m.sp] || {}, P = rePools(S), kit = [];
  const add = (m) => { if (m && MOVES[m] && !kit.includes(m)) kit.push(m); };
  for (const m of [S.sig, S.sig2]) add(m);
  if (wantDisp) { const L = DISP_ALL(); const own = L.find((k) => k === "rkd_" + f.m.sp); add(own || L[Math.floor(Math.random() * L.length)]); }
  const pw = (m) => { const v = MOVES[m]; return (v.tier || 1) * 10 + (v.mult || 0) * (v.hits || 1) * (v.target === "enemies" ? 1.2 : 1) * 5 + (v.target === "enemies" ? 5 : 0); };
  for (const pk of [...RE_PLAN[tac], "atkA", "atkS", "prio", "deb"]) {   /* 第68版: 強い 技から・回復は 支援型だけ 1つ・状態異常は 段2から */
    if (kit.length >= 7) break;
    if (pk === "heal" && (tac !== "backer" || kit.some((m) => MOVES[m].heal))) continue;
    const pool = (P[pk] || []).filter((m) => !kit.includes(m) && (pk !== "ail" || (MOVES[m].tier || 1) >= 2) && (pk !== "heal" || (MOVES[m].tier || 1) >= 3)).sort((a, b) => pw(b) - pw(a));
    if (pool.length) add(pool[Math.floor(Math.random() * Math.min(3, pool.length))]);
  }
  return kit;
}
// 第68版: 手持ちの 強さ（攻め＝いちばん 高い 攻撃能力・守り＝平均）× 倍率 を、その 種族の 得意・不得意の 形で 配る
function shapeStats(f, avg, M, F) {
  const off = ["atk", "wpn", "mat", "brt"], dfk = ["def", "mdf", "spd"], nat = { ...f.mx };
  const pOff = Math.max(...off.map((k) => avg(k))), pDef = dfk.reduce((a, k) => a + avg(k), 0) / 3;
  const nTop = Math.max(1, ...off.map((k) => nat[k] || 1)), nDv = Math.max(1, dfk.reduce((a, k) => a + (nat[k] || 1), 0) / 3);
  for (const k of off) f.mx[k] = Math.min(9999, Math.max(F, Math.floor(pOff * M * Math.max(0.35, (nat[k] || 1) / nTop))));
  for (const k of dfk) f.mx[k] = Math.min(9999, Math.max(F, Math.floor(pDef * M * Math.min(1.25, Math.max(0.75, (nat[k] || 1) / nDv)))));
}
// 神ごとの 強さの 倍率（模擬戦で 勝率を ならした）
const DEITY_M = { 1: 1.85, 3: 2.15, 7: 1.9, 9: 2.0, 2: 1.8, 4: 1.8, 5: 1.55, 0: 1.6, 11: 1.6, 12: 1.6, 13: 1.6, 14: 1.7 };
const sum7 = (x) => ["atk", "wpn", "mat", "brt", "def", "mdf", "spd"].reduce((a, k) => a + (x[k] || 0), 0);
function topAvg(d) {
  const top = ((d && d.party) || []).concat((d && d.bench) || []).filter(Boolean).map((m) => { try { const c = calcStats(m), gi = SPECIES[m.sp]?.deity; if (gi !== undefined) { const k = Math.sqrt(DEITY_M[gi] ?? 1.7); for (const x of Object.keys(c)) if (typeof c[x] === "number") c[x] = c[x] / k; } return c; } catch { return null; } }).filter(Boolean).sort((a, b) => sum7(b) - sum7(a)).slice(0, 3);
  return (k) => (top.length ? top.reduce((a, x) => a + (x[k] || 0), 0) / top.length : 0);
}
// 第68版: 神の 再臨（HPが 半分 以下で 全回復・全能力を 底上げ +3。神の石板の 神と、仲間に した 神）
export function deityCheck(B, log) {
  for (const f of [...B.allies, ...B.enemies]) {
    if (!f || f.hp <= 0 || !f.tr || !f.tr.deityRev) continue;
    B.revM = B.revM || new Map(); if (f.m && B.revM.has(f.m)) f.revN = Math.max(f.revN || 0, B.revM.get(f.m));
    if ((f.revN || 0) >= f.tr.deityRev || f.hp > f.mx.hp / 2) continue;
    f.revN = (f.revN || 0) + 1; if (f.m) B.revM.set(f.m, f.revN); f.hp = f.mx.hp; f.floorBuf = 3;
    for (const k of ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) f.buf[k] = Math.max(f.buf[k] || 0, 3);
    try { for (const a of Object.keys(f.ail || {})) delete f.ail[a]; } catch {}
    log.push(`§4§l${f.name}の ${B.master && B.master.ruinsBoss >= 15 ? "邪神" : "神"}の 再臨！ §r§dHPが 全回復し、全能力が 底上げされた！（3段階より 下がらない）`);
    try { if (ok(f.ent)) { vfx(f.ent, "pillar", 0, [1, 0.8, 0.2], 2); anim(f.ent, "roar"); } } catch {}
    try { for (const x of B.players || []) { sound(x.p, "mob.enderdragon.growl", 0.8); sound(x.p, "mob.ravager.roar", 0.7); } } catch {}
  }
}
export function hakenKit() {
  const ids = Object.keys(MOVES).filter((id) => !MOVES[id].sig && !MOVES[id].combo && !MOVES[id].god && !MOVES[id].boss && !MOVES[id].mimic && !MOVES[id].hpcost && !MOVES[id].recoil && !MOVES[id].selfko && !MOVES[id].allmp && !MOVES[id].absolute);
  const atkv = (m) => (m.mult || 0) * (m.hits || 1) * (m.target === "enemies" ? 1.25 : 1) + (["dark", "steel"].includes(m.el) ? 0.3 : 0);
  const one = (f, sc = atkv) => ids.filter((id) => f(MOVES[id])).sort((a, b) => sc(MOVES[b]) - sc(MOVES[a]) || (MOVES[b].tier || 0) - (MOVES[a].tier || 0))[0];
  const atk = (m) => m.kind === "attack";
  const sumBuf = (m) => Object.values(m.buff || {}).reduce((a, v) => a + v, 0);
  const kit = [SPECIES.haken?.sig, SPECIES.haken?.sig2,
    one((m) => atk(m) && m.cat === "weapon" && m.target === "enemies"),
    one((m) => atk(m) && m.cat === "phys"),
    one((m) => atk(m) && m.cat === "breath" && ["dark", "steel", "fire"].includes(m.el)),
    one((m) => atk(m) && m.cat === "magic" && m.el === "dark"),
    one((m) => atk(m) && m.cat === "special"),
    one((m) => !atk(m) && m.buff && sumBuf(m) > 0 && Object.values(m.buff).every((v) => v > 0) && ["self", "allies"].includes(m.target) && (m.buff.wpn || m.buff.atk), sumBuf),
    one((m) => !atk(m) && m.buff && sumBuf(m) < 0 && Object.values(m.buff).every((v) => v < 0) && m.target === "enemies", (m) => -sumBuf(m)),
    one((m) => m.dispel && m.target === "enemies", (m) => m.tier || 0)];
  return [...new Set(kit.filter((id) => id && MOVES[id]))];
}
export function enmaKit(n) {
  const ids = Object.keys(MOVES).filter((id) => !MOVES[id].sig && !MOVES[id].combo && !MOVES[id].god && !MOVES[id].boss && !MOVES[id].mimic);
  const atkv = (m) => (m.mult || 0) * (m.hits || 1) * (m.target === "enemies" ? 1.25 : 1);
  const best = (f, sc = atkv, k = 1) => ids.filter((id) => f(MOVES[id])).sort((a, b) => sc(MOVES[b]) - sc(MOVES[a]) || (MOVES[b].tier || 0) - (MOVES[a].tier || 0))[0 + 0] ? ids.filter((id) => f(MOVES[id])).sort((a, b) => sc(MOVES[b]) - sc(MOVES[a]) || (MOVES[b].tier || 0) - (MOVES[a].tier || 0)).slice(0, k) : [];
  const atk = (m) => m.kind === "attack" && !m.selfko && !m.recoil;
  const sumBuf = (m) => Object.values(m.buff || {}).reduce((a, v) => a + v, 0);
  const kit = [
    ...best((m) => atk(m) && m.cat === "weapon", atkv, 2),
    ...best((m) => atk(m) && m.cat === "phys", atkv, 1),
    ...best((m) => m.refl && (m.target === "self" || m.target === "allies"), (m) => (m.target === "allies" ? 2 : 1) + (m.tier || 0), 2),
    ...best((m) => atk(m) && m.cat === "magic" && m.el === "dark", atkv, 2),
    ...best((m) => !atk(m) && !m.hpcost && m.buff && sumBuf(m) > 0 && Object.values(m.buff).every((v) => v > 0) && ["self", "allies"].includes(m.target), sumBuf, 1),
    ...best((m) => !atk(m) && m.buff && sumBuf(m) < 0 && Object.values(m.buff).every((v) => v < 0) && ["enemy", "enemies"].includes(m.target), (m) => -sumBuf(m) * (m.target === "enemies" ? 1.5 : 1), 1),
    ...best((m) => m.dispel, (m) => (m.target === "enemies" ? 2 : 1) + (m.tier || 0), 1),
    ...best((m) => atk(m) && m.cat === "breath" && (m.el === "dark" || m.el === "fire"), atkv, 1),
    ...best((m) => atk(m) && m.cat === "special" && String(m.pstat || "") === "spd", atkv, 1),
  ];
  const extra = [
    ...best((m) => atk(m) && m.cat === "weapon" && m.target === "enemies", atkv, 2), ...best((m) => atk(m) && m.cat === "magic", atkv, 3),
    ...best((m) => m.heal && !m.revive && m.target === "self", (m) => m.heal || 0, 1), ...best((m) => atk(m) && m.cat === "breath", atkv, 2),
    ...best((m) => atk(m) && m.cat === "phys" && m.target === "enemies", atkv, 2), ...best((m) => !atk(m) && m.buff && sumBuf(m) < 0 && m.target === "enemies", (m) => -sumBuf(m), 2),
    ...best((m) => atk(m) && m.cat === "special", atkv, 2),
  ].filter((id) => !kit.includes(id));
  return [...new Set([SPECIES.enma?.sig, SPECIES.enma?.sig2, ...kit, ...extra.slice(0, Math.min(extra.length, 2 * n))].filter((id) => id && MOVES[id]))];
}   // v3.0: エンマが 刀を しまう 合図（つぎの 攻撃と かさならない）
const SESS = Date.now() % 1000000000;   // v2.9.12: この ワールドを 開いた 回
// v2.9.12: 戦闘中は 画面の 下に 自分の モンスターの HP・MP・状態異常を いつも 出す（相手は 本で）
const HUD = new Set();
// v2.9.12: 画面の 上に 自分の モンスター（アイコン・名前・HP・MP・状態異常・バフ）、左に 戦いの ログ
const HSLOT = ["MQ1", "MQ2", "MQ3", "MQ4"];
const HPAD = 12;   // アイコンの 名前の 長さ（ここまで "~" で うめる）
const iconKey = (sp) => (String(sp || "").length <= HPAD && /^[a-z0-9_]+$/.test(String(sp || "")) ? String(sp) : "").padEnd(HPAD, "~");
function mineOf(B, p) {
  let mine = [...B.allies, ...B.enemies].filter((f) => f.owner === p.id && !f.out);
  if (!mine.length && (B.players || []).length <= 1) mine = B.allies.filter((f) => !f.guest && !f.out);
  return mine.slice(0, 4);
}
function slotText(f) {
  const nm = String(f.name || "").replace(/§./g, "").slice(0, 6);
  if (f.hp <= 0) return `${iconKey(f.m && f.m.sp)}§7${nm}\n§8Lv${f.lv}\n§8たおれた`;
  const r = f.hp / Math.max(1, f.mx.hp), hc = r <= 0.25 ? "§c" : r <= 0.5 ? "§e" : "§a";
  let tg = ""; try { tg = fTags(f).trim().split(/\s+/).slice(0, 6).join(" "); } catch {}   // 枠から はみ出ない ように 6つまで
  if (f.defend) tg = `§7[防] ${tg}`;
  return `${iconKey(f.m && f.m.sp)}§f${nm}\n§7Lv${f.lv}\n${hc}HP ${f.hp}/${f.mx.hp}\n${meter(f.hp, f.mx.hp, 8, hc)}\n§bMP ${f.mp}/${f.mx.mp}${tg ? "\n" + tg : ""}`;
}
export function pushHud(B) {
  for (const x of B.players || []) {
    const p = x.p; if (!ok(p)) continue;
    hudSend(p, "MQG", "");   // 戦いの あいだは 右上の 案内を かくす（上の 枠と かさならない ように）
    let nh = false; try { nh = p.getDynamicProperty("mrpg:nohud") === true; } catch {}
    const mine = nh ? [] : mineOf(B, p);
    HSLOT.forEach((ch, i) => hudSend(p, ch, mine[i] ? slotText(mine[i]) : ""));
    hudSend(p, "MQL", nh ? "" : (LOGR.get(p.id) || []).join("\n"));
  }
}
export function hudClear(p, again = 3) {
  try { LOGR.delete(p.id); } catch {}
  if (!ok(p)) return;
  try { if (again >= 2 && Date.now() >= (TITLE_T.get(p.id) || 0)) p.onScreenDisplay.clearTitle?.(); } catch {}   /* v2.9.12: まんなかの 文字を のこさない（あとから 出した タイトルは 消さない） */
  for (const ch of [...HSLOT, "MQL", "MQT", "MQS"]) { hudResend(p.id, ch); hudSend(p, ch, ""); }
  // 合図が とどかない ことが あるので 少し あとに もう一度（その とき 戦って いなければ）
  if (again > 0) { const pid = p.id; system.runTimeout(() => { try { if (!ok(p) || [...battles.values(), ...HUD].some((B) => !B.ended && (B.players || []).some((x) => x.p && x.p.id === pid))) return; hudClear(p, again - 1); } catch {} }, 60); }
}
// 左の ログ（さいごの 6行）
const LOGR = new Map();
const barSet = (p, b) => { if (b) try { barNote2(p).setActionBar(b); } catch {} };
export const PVPSIDE = new Map();   // 対戦で 青コーナー（e側）の 人
const cutV = (t, n) => { const s = String(t); let k = 0, i = 0; for (; i < s.length; i++) { if (s[i] === "§") { i++; continue; } if (++k > n) break; } return i < s.length ? s.slice(0, i).replace(/§$/, "") + "§r…" : s; };
function logPush(p, lines) {
  let a = LOGR.get(p.id); if (!a) LOGR.set(p.id, (a = []));
  for (const l of lines) { const t = String(l).trim(); if (t) a.push("§l" + cutV(t, 18).replace(/§r/g, "§r§l")); }   // v2.9.12: 太字で 見やすく
  while (a.length > 6) a.shift();
}
system.runInterval(() => {
  for (const B of HUD) {
    const gone = B.ended || (B.allies.length && B.allies.every((f) => !ok(f.ent)) && B.enemies.every((f) => !ok(f.ent)));
    if (gone) { HUD.delete(B); for (const x of B.players || []) hudClear(x.p); continue; }
    pushHud(B);
  }
}, 10);
// v2.6: やりこみの 戦いで 使う 仮の パーティ（コピー）と、戦いが 終わった ときの 通知
export const CH_PARTY = new Map();
export const battleHooks = [];
export const WX_HOOK = { f: null };
let nextBid = (Date.now() % 1000000) * 10 + 1;   // v2.9.12: 読みこみ 直しで 番号が かぶらない

function placeLine(center, perp, n, gap) {
  return Array.from({ length: n }, (_, i) => {
    const o = (i - (n - 1) / 2) * gap;
    return { x: center.x + perp.x * o, y: center.y, z: center.z + perp.z * o };
  });
}
function summonFighter(p, f, pos, face, temps, pet, bid) {
  let e;
  if (pet) { e = pet; e.triggerEvent("mrpg:make_battle"); }
  else {
    e = p.dimension.spawnEntity(TYPE, pos);
    e.addTag("mrpg_battle"); setLook(e, f.lookAs || f.m.sp, f.lookAs ? { ...f.m, look: null, tint: null } : f.m); e.triggerEvent("mrpg:make_battle");
    temps.push(e);
  }
  if (bid) e.setDynamicProperty("mrpg:bid", bid); else try { e.setDynamicProperty("mrpg:sess", SESS); } catch {}   // v2.9.12: 対戦・模擬戦の 子にも 印
  try { e.teleport(pos, { facingLocation: face }); } catch {}
  f.home = { x: pos.x, y: pos.y, z: pos.z }; f.face = { x: face.x, y: face.y, z: face.z };
  e.nameTag = `${f.side === "a" ? "§b" : "§c"}${f.name} Lv${f.lv} ${rankOf(f.m.sp)}`;
  f.ent = e;
  if (f.hp <= 0) { anim(e, "faint", true); try { e.addEffect("invisibility", 20 * 3600, { showParticles: false }); f.dust = true; } catch {} }   // v2.9.12: 倒れた 子は 見えない まま
}

// v2.6: 表示の 立てなおし（モンスターが 映らない・別の 場所に いる ときに 呼ぶ）
function fixView(B, full) {
  const PL = B.players || [];
  const P0 = PL[0]?.p;
  for (const f of [...B.allies, ...B.enemies]) {
    if (f.out || !f.home) continue;
    const owner = PL.find((x) => x.p.id === f.owner)?.p || P0;
    if (!ok(f.ent)) {
      if (!owner) continue;
      try { const wasHp = f.hp; summonFighter(owner, f, f.home, f.face || B.center || f.home, B.temps, null, B.bid); if (wasHp <= 0) anim(f.ent, "faint", true); } catch {}
      continue;
    }
    try {
      const l = f.ent.location, far = Math.hypot(l.x - f.home.x, l.z - f.home.z) > 1.5 || Math.abs(l.y - f.home.y) > 2.5;
      // とどいて いない ときは もう一度、とどいて いても 少し ゆらして 見え方を 送りなおす
      f.ent.teleport(far ? f.home : { x: f.home.x, y: f.home.y + 0.01, z: f.home.z }, { facingLocation: f.face || B.center || f.home });
      if (full || far) setLook(f.ent, f.lookAs || f.m.sp, f.lookAs ? { ...f.m, look: null, tint: null } : f.m);
    } catch {}
  }
  if (full && B.stage) recheckStage(B.stage).catch(() => {});
}
// ---------- 演出 ----------
const RGB = { fire: [1, 0.42, 0.1], water: [0.25, 0.5, 1], wood: [0.35, 0.85, 0.3], steel: [0.78, 0.8, 0.86], ice: [0.55, 0.88, 1], wind: [0.45, 1, 0.6], thunder: [1, 0.95, 0.3], dark: [0.62, 0.28, 1], earth: [0.8, 0.58, 0.32],
  light: [1, 0.95, 0.68], heal: [0.45, 1, 0.55], none: [1, 1, 1], slash: [0.8, 0.95, 1], martial: [1, 0.72, 0.3], dance: [1, 0.5, 0.88],
  special: [1, 0.38, 0.62], sp_spd: [0.45, 0.95, 1], sp_guard: [0.82, 0.84, 0.95], sp_hp: [1, 0.62, 0.28], breath: [1, 0.62, 0.3], magic: [0.7, 0.75, 1], buff: [1, 0.85, 0.35], debuff: [0.7, 0.35, 1], crit: [1, 1, 0.75] };
const hOf = (f) => Math.max(0.4, Math.min(6, (SPECIES[f.m.sp].mh || 1) * 0.55));
const HEAVY = new Set(["sparks", "smoke", "shards", "aura", "notes", "rise", "flames", "swirl", "star"]);
function vfx(e, id, dy = 1, col = RGB.none, scale = 1, extra) {
  if (!ok(e)) return;
  if (isLite() && HEAVY.has(id)) return;
  try {
    const m = new MolangVariableMap();
    m.setColorRGB("variable.color", { red: col[0], green: col[1], blue: col[2] });
    m.setFloat("variable.scale", scale);
    if (extra) extra(m);
    const l = e.location;
    e.dimension.spawnParticle(`mrpg:${id}`, { x: l.x, y: l.y + dy, z: l.z }, m);
  } catch {}
}
function shake(e, power = 0.25, time = 0.3) { if (ok(e) && !isLite()) cmd(e, `camerashake add @a[r=28] ${power} ${time} positional`); }
function stream(a, t, col, sc) {
  if (!ok(a.ent) || !ok(t.ent)) return;
  const p = a.ent.location, q = t.ent.location;
  const dx = q.x - p.x, dy = (q.y + hOf(t)) - (p.y + hOf(a)), dz = q.z - p.z;
  const dist = Math.max(0.5, Math.hypot(dx, dy, dz));
  vfx(a.ent, "stream", hOf(a), col, sc, (m) => {
    try { m.setVector3("variable.dir", { x: dx / dist, y: dy / dist, z: dz / dist }); } catch {}
    m.setFloat("variable.dist", dist);
  });
}
// v2.2: エンマ・ムサシの 専用モーション（[当たるまでの 間, 当たる 回数, 回数の 間]）
const GPRE = { g_stomp: 11, g_sweep: 12, g_charge: 10, g_roar: 16, g_breath: 11 };
const SPX = { enma_combo5: [7, 5, 4], enma_majin: [11, 8, 3], enma_kuni: [32, 1, 0], musashi_combo5: [7, 5, 4], musashi_sig: [11, 2, 3] };
const WPA = new Set(["sword", "spear", "axe", "gun", "dual", "bow", "tome", "club", "whip", "claw", "katana", "scythe", "fan", "staff", "chakram", "odd"]);
const CWP_T = { 1: "sword", 2: "spear", 3: "axe", 4: "gun", 5: "dual", 6: "bow", 7: "tome", 8: "club", 9: "whip", 10: "claw", 11: "katana", 12: "scythe", 13: "fan", 14: "staff", 15: "chakram", 16: "odd" };
const WP_ANIM = { axe: "wp_smash", club: "wp_smash", whip: "wp_whip", claw: "wp_claw", katana: "wp_iai", scythe: "wp_scythe", fan: "wp_fan", staff: "wp_staff", chakram: "wp_throw", odd: "wp_odd" };
function motionOf(fx) {
  const a = fx.actor;
  const sp0 = a && a.m ? SPECIES[a.m.sp] : null;
  const tier = fx.tier || 0;
  const sp = a && a.m ? SPECIES[a.m.sp] : null;
  // v2.6.5: 相棒は 持っている 武器に あわせた 攻撃
  // v2.7: 腕の ある モンスターは 装備した 武器に あわせた 攻撃（相棒は 見た目で えらんだ 武器でも）
  // v3.0: 武器の 動きは 通常攻撃と 武系の 技だけ（物理系・特質系・魔法系は それぞれの 動き）
  if ((fx.mid === "basic" || fx.cat === "slash") && (fx.anim === "attack" || (fx.anim === "cast" && fx.mid === "basic")) && a && a.m && !(sp0 && sp0.anim)) {
    const armed = a.m.look ? a.m.look.cb !== 5 : !!(sp0 && sp0.armed);
    const wt = (WPA.has(a.wtype) && a.wtype) || (a.m.look ? CWP_T[a.m.look.cwp || 0] : null);
    if (wt && armed) return WP_ANIM[wt] || `wp_${wt}`;
  }
  // v2.2: 巨大モンスター（L・G）は 体ぜんたいを 使う 派手な 動き
  const gsz = a && a.m ? sizeOf(a.m) : "M";
  if (sp && !sp.anim && !sp.ma && (gsz === "L" || gsz === "G")) {
    if (fx.anim === "attack") {
      if (fx.cat === "slash") return "g_sweep";                                                   // 武系: なぎはらう
      if (fx.cat === "special") { const k = spKind(fx); return k === "other" ? "atk_special" : `atk_sp_${k}`; }   // 特質系
      return (fx.hits || 1) >= 2 || tier >= 2 ? "g_stomp" : ["g_stomp", "g_charge"][Math.floor(Math.random() * 2)];   // 物理系: ふみつけ・突進
    }
    if (fx.anim === "breath") return "g_breath";
    if (fx.anim === "cast" && fx.cat === "magic") return "atk_magic";                         // 魔法系の 攻撃
    if (fx.anim === "cast" || fx.anim === "guard" || fx.anim === "dance") return "g_roar";
  }
  if (sp && sp.anim && fx.anim === "attack") {
    if (sp.sig2 && fx.mid === sp.sig2) return `${sp.anim}_kuni`;
    if (fx.mid === sp.sig) return sp.anim === "enma" ? "enma_majin" : "musashi_sig";
    if (fx.mid === "basic" || fx.cat === "slash") return `${sp.anim}_combo5`;
  }
  // v3.0: 1体ごとの 攻撃モーション（物理系・武系・息系・魔法系・特質系で ちがう 動き）
  if (sp && sp.ma) {   // ムサシ・エンマも 必殺技・武系 いがいは 自分の 動き
    const ck = fx.anim === "breath" ? "breath" : fx.anim === "cast" && fx.cat === "magic" && fx.mid !== "basic" ? "magic" : fx.anim === "attack" ? ({ slash: "weapon", martial: "phys", special: "special", magic: "magic", breath: "breath" }[fx.cat] || "phys") : null;
    if (ck) return `m_${a.m.sp}_${ck}`;
  }
  if (fx.anim === "attack") {
    if (fx.cat === "special") { const k = spKind(fx); return k === "other" ? "atk_special" : `atk_sp_${k}`; }   // 特質系
    if (fx.cat === "slash") return (fx.hits || 1) >= 2 ? "atk_slash3" : tier >= 2 ? "atk_slash2" : "atk_slash";   // 武系
    if ((fx.hits || 1) >= 2) return "atk_combo";                                                // 物理系の 連続
    if (fx.mid !== "basic" && fx.cat === "magic") return "atk_magic";
    if (tier >= 2) return "atk_big";
    return `atk_${SPECIES[a.m.sp].motion}`;
  }
  if (fx.anim === "cast") {
    if (fx.cat === "magic" && fx.mid !== "basic") return "atk_magic";   // v3.0: 魔法系の 攻撃呪文
    if (fx.mtype === "buff" || fx.mtype === "regen") return "power";
    return tier >= 2 ? "cast2" : "cast";
  }
  if (fx.anim === "guard" && fx.mtype === "charge") return "power";
  return fx.anim === "dance" ? "atk_dance" : fx.anim;
}
// v3.0: 特質技の 演出は 威力の もと（走力・守り・体力）で かえる
const spKind = (fx) => { const ps = String((MOVES[fx.mid] || {}).pstat || "spd"); return ps.includes("hp") ? "hp" : ps.includes("def") || ps.includes("mdf") ? "guard" : ps === "spd" ? "spd" : "other"; };
function hitFx(t, fx, col, sc, crit) {
  const h = hOf(t), e = t.ent;
  const tier = fx.tier || 0;
  if (fx.mtype === "status") { vfx(e, "smoke", h, col, sc); vfx(e, "swirl", 0.2, col, sc); return; }
  if (fx.mtype === "buff") { vfx(e, fx.down ? "arrows_down" : "arrows_up", 0.2, fx.down ? RGB.debuff : RGB.buff, 1); return; }
  if (fx.anim === "attack" || fx.anim === "boom") {
    if (fx.anim === "boom") { vfx(e, "boom", h, RGB.fire, 1.6); vfx(e, "shock", 0.1, RGB.fire, 1.5); vfx(e, "smoke", h, [0.4, 0.4, 0.4], 1.4); return; }
    if (fx.cat === "slash") {
      vfx(e, "slash", h, fx.el ? RGB[fx.el] : RGB.slash, sc * 1.2);
      if (crit || tier >= 2) vfx(e, "xslash", h, crit ? RGB.crit : RGB.slash, sc);
      vfx(e, "sparks", h, RGB.slash, sc * 0.8);
    } else if (fx.cat === "special") {
      const k = spKind(fx);
      if (k === "spd") { vfx(e, "xslash", h, RGB.sp_spd, sc * 1.1); vfx(e, "swirl", 0.2, RGB.sp_spd, sc); vfx(e, "sparks", h, RGB.sp_spd, sc * 0.9); }
      else if (k === "guard") { vfx(e, "impact", h, RGB.sp_guard, sc * 1.3); vfx(e, "shock", 0.1, RGB.sp_guard, sc * 1.5); vfx(e, "sparks", h, [1, 0.9, 0.5], sc); }
      else if (k === "hp") { vfx(e, "shock", 0.1, RGB.sp_hp, sc * 1.8); vfx(e, "smoke", 0.2, [0.55, 0.5, 0.45], sc * 1.5); vfx(e, "impact", h, RGB.sp_hp, sc * 1.2); }
      else { vfx(e, "boom", h, RGB.special, sc * 1.2); vfx(e, "shock", 0.1, RGB.special, sc * 1.3); vfx(e, "sparks", h, RGB.special, sc); }
    } else {
      vfx(e, "impact", h, fx.el ? RGB[fx.el] : RGB.martial, sc);
      vfx(e, "sparks", h, fx.el ? RGB[fx.el] : RGB.martial, sc * 0.9);
      if (tier >= 2 || crit) vfx(e, "shock", 0.1, RGB.martial, sc * 1.3);
    }
    if (fx.el && fx.el !== "heal") elementFx(e, h, fx.el, sc * 0.7);
    if (crit) vfx(e, "star", h + 0.2, RGB.crit, 1.4), vfx(e, "impact", h, RGB.crit, 1.5);
    return;
  }
  if (fx.anim === "breath") {
    elementFx(e, h, fx.el || "fire", sc);
    if (!fx.el || fx.el === "fire") vfx(e, "boom", h, RGB.fire, sc);
    return;
  }
  if (fx.anim === "dance") { vfx(e, "notes", 0.3, RGB.dance, sc); vfx(e, "sparks", h, RGB.dance, sc); return; }
  // 呪文
  elementFx(e, h, fx.el, sc);
}
function elementFx(e, h, el, sc) {
  const col = RGB[el] || RGB.magic;
  switch (el) {
    case "fire": vfx(e, "boom", h, col, sc); vfx(e, "flames", 0.1, col, sc); break;
    case "ice": vfx(e, "shards", h, col, sc); vfx(e, "pillar", 0, col, sc * 0.8); break;
    case "thunder": vfx(e, "bolt", 0, col, sc); vfx(e, "sparks", h, col, sc); break;
    case "wind": vfx(e, "swirl", 0.2, col, sc); vfx(e, "slash", h, col, sc); vfx(e, "swirl", h, col, sc * 0.7); break;
    case "dark": vfx(e, "pillar", 0, col, sc); vfx(e, "smoke", h, [0.3, 0.15, 0.45], sc); break;
    case "earth": vfx(e, "shock", 0.1, col, sc * 1.3); vfx(e, "shards", h * 0.6, col, sc); vfx(e, "impact", h, col, sc); break;
    case "light": vfx(e, "pillar", 0, col, sc); vfx(e, "rise", 0.1, col, sc); vfx(e, "star", h, col, sc); break;
    case "water": vfx(e, "swirl", 0.2, col, sc); vfx(e, "shards", h, col, sc * 0.8); vfx(e, "impact", h, col, sc); break;
    case "wood": vfx(e, "rise", 0.1, col, sc); vfx(e, "swirl", h * 0.6, col, sc * 0.8); vfx(e, "sparks", h, col, sc); break;
    case "steel": vfx(e, "xslash", h, col, sc); vfx(e, "sparks", h, col, sc); vfx(e, "impact", h, col, sc * 0.8); break;
    default: vfx(e, "impact", h, col, sc); vfx(e, "sparks", h, col, sc);
  }
}
const SND = { water: "random.splash", wood: "dig.grass", steel: "random.anvil_land", fire: "mob.blaze.shoot", ice: "random.glass", wind: "mob.breeze.wind_burst", thunder: "ambient.weather.thunder", dark: "mob.wither.shoot",
  earth: "dig.stone", light: "random.orb", heal: "random.orb" };
// v1.7: カメラワーク（攻撃する モンスターの うしろから 相手を 見る）
const camOn = (p) => { try { return p.getDynamicProperty("mrpg:nocam") !== true; } catch { return false; } };
const f2 = (v) => v.toFixed(2);
// v1.7: カメラは 攻撃した モンスターに 寄せる（肩ごしに 相手が 奥に 見える 構図）
// mode: "aim"=技を 出す 前（攻撃側の ななめ後ろ）／"hit"=踏み込んで 当たる 瞬間（横から 2体を 近くで）
// v2.2: カメラ。2体が かならず 画面に 入る きょりを 計算する（巨大モンスターでも 見切れない）
const trueH = (f) => Math.max(0.8, (SPECIES[f.m.sp].mh || 1) * (f.m.sz && f.m.sz !== SPECIES[f.m.sp].sz ? ({ S: 0.6, M: 1, L: 3, G: 5 }[f.m.sz] || 1) / ({ S: 0.6, M: 1, L: 3, G: 5 }[SPECIES[f.m.sp].sz] || 1) : 1));
function camFocus(players, a, t, mode = "aim") {
  if (!a || !ok(a.ent)) return;
  const A = a.ent.location, T = t && ok(t.ent) ? t.ent.location : null;
  if (!T) return;
  let dx = T.x - A.x, dz = T.z - A.z; const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L;
  const ha = trueH(a), ht = trueH(t), H = Math.max(ha, ht), baseY = Math.min(A.y, T.y);
  const mx = (A.x + T.x) / 2, mz = (A.z + T.z) / 2;
  // 横幅（2体の きょり）と 高さ（大きい ほう）の 両方が 入る きょり
  const fit = Math.max(L * 0.62, H * 0.82) + 1.6;   // v2.5.6: もっと 近く
  let pos, look, ease;
  if (mode === "giant" || (mode === "aim" && ha >= 3.5 && ha > ht * 1.6)) {
    // 巨大な 攻撃側: 相手の うしろ 低い 位置から 見上げる（迫力・相手も 手前に 入る）
    const back = 1.6 + ht * 0.55 + H * 0.18, side = 1.4 + H * 0.14;
    pos = { x: T.x + dx * back - dz * side, y: baseY + 0.7 + ht * 0.55, z: T.z + dz * back + dx * side };
    look = { x: A.x - dx * 0.5, y: A.y + ha * 0.42, z: A.z - dz * 0.5 };
    ease = 0.35;
  } else if (mode === "hit") {
    // 2体の まんなかを 真横から（相手の がわへ すこし よせる）
    const v = { x: -dz * 0.95 + dx * 0.3, z: dx * 0.95 + dz * 0.3 }, n = Math.hypot(v.x, v.z);
    pos = { x: mx + (v.x / n) * fit, y: baseY + 0.9 + H * 0.3, z: mz + (v.z / n) * fit };
    look = { x: mx + dx * L * 0.12, y: baseY + 0.4 + H * 0.33, z: mz + dz * L * 0.12 };
    ease = 0.18;
  } else {
    // 攻撃側の ななめ うしろ（攻撃側が 手前、相手が 奥）。大きい 相手なら 引いて 見上げる
    const v = { x: -dx * 0.62 - dz * 0.78, z: -dz * 0.62 + dx * 0.78 };
    const far = Math.max(fit * 0.75, 1.8 + ha * 0.95);
    pos = { x: mx + v.x * far, y: baseY + 1 + Math.max(ha * 0.55, H * 0.26), z: mz + v.z * far };
    look = { x: mx + dx * L * 0.15, y: baseY + 0.4 + H * 0.3, z: mz + dz * L * 0.15 };
    ease = 0.3;
  }
  for (const p of players) if (camOn(p)) { CAMON.add(p.id); const dm = DOMEB.get(p.id); if (dm) pos = clampDome(pos, dm); cmd(p, `camera @s set minecraft:free ease ${ease} in_out_sine pos ${f2(pos.x)} ${f2(pos.y)} ${f2(pos.z)} facing ${f2(look.x)} ${f2(look.y)} ${f2(look.z)}`); }
}
// v2.9: ドームの 中に カメラを おさめる（かべや 天井に めりこまない）
export const DOMEB = new Map();
function clampDome(pos, dm) {
  let dx = pos.x - dm.cx, dz = pos.z - dm.cz; const L = Math.hypot(dx, dz);
  const lim = dm.r - 1.2;
  if (L > lim) { dx *= lim / L; dz *= lim / L; }
  const L2 = Math.hypot(dx, dz), hmax = dm.fy + (L2 < dm.r * 0.55 ? dm.top - dm.fy - 1.5 : Math.max(3, (dm.top - dm.fy) * Math.sqrt(Math.max(0, 1 - (L2 / (dm.r + 1)) ** 2)) - 1.5));
  return { x: dm.cx + dx, y: Math.max(dm.fy + 0.6, Math.min(pos.y, hmax)), z: dm.cz + dz };
}
// v2.8: カメラが 戻らず 詰む ことが ないように（戦いが 終わったら かならず 戻す・番人つき）
export const CAMON = new Set();
export function camClear(players) { for (const p of players) { try { CAMON.delete(p.id); } catch {} try { cmd(p, "camera @s clear"); } catch {} } }
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (!CAMON.has(p.id)) continue;
    const inB = [...battles.values()].some((B) => !B.ended && (B.players.some((x) => x.p.id === p.id) || (B.pvpIds && B.pvpIds.includes(p.id))));
    if (!inB && !busy.has(p.id)) camClear([p]);
  }
}, 40);
// ---------- v3.0 第63版: 上空の 戦い（もどる 場所の 記録・落下ふせぎ・入りなおし）----------
// v3.0 第63版: いちばん 近い 町（宿屋）へ
export function innTp(q) {
  try {
    if (!ok(q)) return; const l = q.location;
    if (inRuins(l) && RU_INN.tp && RU_INN.tp(q)) { q.addEffect("slow_falling", 100, { showParticles: false }); return; }   /* 第76版: 滅びた 世界では キャンプへ */
    let best = null, bd = 1e9; for (const t of TOWNS) { const g = getTown(t.id); if (!g || !g.built) continue; const dd = Math.hypot(g.x - l.x, g.z - l.z); if (dd < bd) { bd = dd; best = g; } }
    q.addEffect("slow_falling", 100, { showParticles: false });
    if (best) q.teleport({ x: best.x + 2.5, y: best.y + 0.2, z: best.z + 2.5 }, { dimension: world.getDimension("overworld") });
    else { const s = world.getDefaultSpawnLocation(); q.teleport({ x: s.x + 0.5, y: (s.y > 300 ? 80 : s.y) + 0.2, z: s.z + 0.5 }, { dimension: world.getDimension("overworld") }); }
    try { q.playSound("random.levelup", { pitch: 0.8, volume: 0.6 }); } catch {}
  } catch {}
}
export function skyMark(B, q, pos) { B.retPos = B.retPos || {}; if (!B.retPos[q.id]) { B.retPos[q.id] = { ...pos, dim: q.dimension.id }; try { q.setDynamicProperty("mrpg:bret", JSON.stringify(B.retPos[q.id])); } catch {} } }
export function skyBack(q, B, pet) {
  const r = B && B.retPos && B.retPos[q.id]; if (!r) return; delete B.retPos[q.id];
  try { if (!ok(q)) return; q.addEffect("slow_falling", 100, { showParticles: false }); q.teleport({ x: r.x, y: r.y + 0.1, z: r.z }, { dimension: world.getDimension(r.dim) }); } catch {}
  try { q.setDynamicProperty("mrpg:bret", undefined); } catch {}
  try { if (pet && ok(pet)) pet.teleport({ x: r.x + 1, y: r.y + 0.1, z: r.z }, { dimension: world.getDimension(r.dim) }); } catch {}
}
system.runInterval(() => {   // 上空の 戦いで 足場から 落ちたら ステージに もどす（戦いが ある ときだけ）
  if (!battles.size) return;
  for (const B of battles.values()) {
    if (B.ended || B.skyY === undefined) continue;
    for (const x of B.players) { try { const q = x.p; if (!ok(q)) continue; const l = q.location; if (l.y < B.skyY - 3 || l.y > B.skyY + 40) { const P = B.pPos || B.center; q.addEffect("slow_falling", 60, { showParticles: false }); q.teleport({ x: P.x, y: B.skyY + 0.2, z: P.z }); } } catch {} }
    for (const f of [...B.allies, ...B.enemies]) { try { if (f.hp > 0 && f.ent && ok(f.ent) && f.ent.location.y < B.skyY - 3) { const h = f.home || B.center; if (h) f.ent.teleport({ x: h.x, y: B.skyY + 0.1, z: h.z }); } } catch {} }
  }
}, 10);
world.afterEvents.playerSpawn.subscribe(({ player }) => {
  let n = 0;
  const chk = () => { try { if (!ok(player)) return; const v = player.getDynamicProperty("mrpg:bret"); if (typeof v !== "string") return;
    if (inBattle(player) && n++ < 90) { player.addEffect("slow_falling", 60, { showParticles: false }); system.runTimeout(chk, 20); return; }   // 古い 戦いが 終わるまで 待つ（その あいだは ゆっくり 落ちる）
    const r = JSON.parse(v); player.setDynamicProperty("mrpg:bret", undefined); player.addEffect("slow_falling", 100, { showParticles: false }); player.teleport({ x: r.x, y: r.y + 0.1, z: r.z }, { dimension: world.getDimension(r.dim) }); } catch {} };
  system.runTimeout(chk, 30);
});   // 戦いの とちゅうで ぬけて 入りなおしたら もとの 場所へ
world.afterEvents.playerSpawn.subscribe(({ player }) => { system.runTimeout(() => { if (!busy.has(player.id)) { try { player.runCommand("camera @s clear"); } catch {} CAMON.delete(player.id); } }, 20); });
// 踏み込み（相手の ほうへ 近づいて 攻撃し、もとの 場所へ もどる）
async function lunge(a, t, ratio = 0.45) {
  if (!a || !t || !ok(a.ent) || !ok(t.ent) || a === t) return null;
  const A = { ...a.ent.location }, T = t.ent.location;
  const gap = Math.max(1.2, (hOf(a) + hOf(t)) * 0.6);
  const dist = Math.hypot(T.x - A.x, T.z - A.z);
  const go = Math.max(0, Math.min(dist - gap, dist * ratio + 1));
  if (go < 0.5) return null;
  const dx = (T.x - A.x) / dist, dz = (T.z - A.z) / dist;
  for (let i = 1; i <= 3; i++) { try { a.ent.teleport({ x: A.x + dx * go * i / 3, y: A.y, z: A.z + dz * go * i / 3 }, { facingLocation: T }); } catch {} await waitT(1); }
  return A;
}
function backTo(a, A, face) { if (A && ok(a.ent)) try { a.ent.teleport(A, face && ok(face.ent) ? { facingLocation: face.ent.location } : undefined); } catch {} }
function sfx(players, id, pitch = 1) { for (const p of players) try { p.playSound(id, { pitch, volume: 1 }); } catch {} }
// v1.7: バトルの 速さ（設定）と ダメージの 数字
// ワールドを 開いた とき、前回 のこった 数字を 消す
system.runTimeout(() => { for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) { try { for (const e of world.getDimension(id).getEntities({ type: "mrpg:popup" })) e.remove(); } catch {} } }, 80);
const SPEED_K = [1.7, 1.3, 0.85];
function speedK(players) { let v = 1; try { const x = players[0]?.getDynamicProperty("mrpg:bspeed"); if (typeof x === "number") v = x; } catch {} return SPEED_K[v] ?? 1.3; }
function popup(e, text, dy = 0) {
  if (!ok(e)) return;
  let pe;
  try { const l = e.location; pe = e.dimension.spawnEntity("mrpg:popup", { x: l.x + (Math.random() - 0.5) * 0.6, y: l.y + dy, z: l.z + (Math.random() - 0.5) * 0.6 }); pe.nameTag = text; } catch { return; }
  // 軽量モード: 動かさず 1.5秒で 消す（teleport を へらす）
  if (isLite()) { system.runTimeout(() => { if (ok(pe)) try { pe.remove(); } catch {} }, 30); return; }
  let n = 0;
  const id = system.runInterval(() => {
    n++;
    if (!ok(pe) || n > 16) { system.clearRun(id); if (ok(pe)) try { pe.remove(); } catch {} return; }
    try { const l = pe.location; pe.teleport({ x: l.x, y: l.y + (n < 6 ? 0.18 : 0.05), z: l.z }); } catch {}
  }, 2);
}
function damagePopups(fx) {
  if (heavy() >= 2) return;   // v1.7: とても 重いときは 数字を 出さない（字幕には 出る）
  const k = new Map();
  // 軽量モード: 同じ 相手への 連続ヒットは 合計 1つに まとめる
  if ((isLite() && (fx.dmg || []).length > 1) || (fx.dmg || []).length > 6) {   // v2.9.7: 数字が 多い ときは 相手ごとに 合計 1つ（カクつき 対策）
    const sum = new Map();
    for (const x of fx.dmg) { if (!x.t) continue; const o = sum.get(x.t) || { t: x.t, d: 0, crit: false, weak: false }; o.d += x.d; o.crit ||= x.crit; o.weak ||= x.weak; sum.set(x.t, o); }
    fx = { ...fx, dmg: [...sum.values()] };
  }
  for (const x of (fx.miss || []).slice(0, 4)) { const t = x.t; if (t && ok(t.ent)) popup(t.ent, x.ev === "miss" ? "§7§lMISS" : "§b§lかわした！", hOf(t) * 1.6 + 0.6); }
  for (const x of fx.dmg || []) {
    const t = x.t; if (!t || !ok(t.ent)) continue;
    const i = k.get(t) || 0; k.set(t, i + 1);
    const col = x.crit ? "§e§l" : x.weak ? "§6§l" : t.side === "a" ? "§c§l" : "§f§l";
    popup(t.ent, `${col}${x.d}${x.crit ? " 会心！" : x.weak ? " 弱点！" : ""}`, hOf(t) * 1.6 + 0.6 + i * 0.45);
  }
  for (const x of fx.heal || []) if (x.t && ok(x.t.ent)) popup(x.t.ent, `§a§l+${x.d}`, hOf(x.t) * 1.6 + 0.6);
}
// v2.9.12: 戦闘中は ガイドブックを 使うと 行動の 画面が 開く。待って いる あいだは 画面の 下に 小さく 案内
export const BOOKWAIT = new Map();
// v2.9.12: 演出の とちゅうで 本を 使ったら おぼえて おく（自分の 番に なったら すぐ 開く）
export function bookEarly(p) {
  for (const B of battles.values()) if (!B.ended && (B.players || []).some((x) => x.p.id === p.id)) { (B.earlyTap = B.earlyTap || {})[p.id] = Date.now(); try { p.onScreenDisplay.setActionBar("§7自分の 番に なったら 行動の 画面を 開きます"); BAR_T.set(p.id, Date.now()); } catch {} return true; }
  return false;
}
function hasBook(p) {
  try { const o = p.getComponent("minecraft:equippable")?.getEquipment("Offhand"); if (o?.typeId === "mrpg:monster_book") return true; } catch {}
  try { const c = p.getComponent("minecraft:inventory")?.container; for (let i = 0; c && i < c.size; i++) if (c.getItem(i)?.typeId === "mrpg:monster_book") return true; } catch { return true; }
  return false;
}
export async function waitBook(p, B, gen) {
  if (globalThis.__MQ_TEST) return "open";   // 模擬テストでは すぐ 開く
  if (!ok(p)) return "gone";
  B.bookTurn = B.bookTurn || {};
  if (B.bookTurn[p.id] === (B.turn || 1)) return "open";   // 同じ ターンに 2回目（模擬戦の 両方 指示 など）は すぐ
  if (B.earlyTap && B.earlyTap[p.id] && Date.now() - B.earlyTap[p.id] < 15000) { delete B.earlyTap[p.id]; B.bookTurn[p.id] = B.turn || 1; pushHud(B); return "open"; }   // 演出中に 本を 使って いたら すぐ
  if (!hasBook(p)) {
    let full = true; try { const c = p.getComponent("minecraft:inventory")?.container; full = !c || c.emptySlotsCount === 0; } catch {}
    if (full) { B.bookTurn[p.id] = B.turn || 1; return "open"; }   // 本を 持てない ときは すぐ 画面を 出す（待ちっぱなしに しない）
    try { giveItem(p, "mrpg:monster_book", 1); } catch {}
  }
  let res; const pr = new Promise((r) => { res = r; }); BOOKWAIT.set(p.id, res);
  pushHud(B);
  try { p.onScreenDisplay.setActionBar("§e＞ ガイドブックを 使って 行動を えらぶ"); BAR_T.set(p.id, Date.now()); } catch {}
  let t = 0;
  const h = system.runInterval(() => {
    t++;
    if (!ok(p)) { res("gone"); return; }
    if (B.cmdGen[p.id] !== gen || B.ended) { res("stale"); return; }
    // v2.9.12: 戦いの 場所から はなれたら 逃げた ことに（無敵の まま 歩きまわれない ように）
    try { const c = B.center; if (c && (p.dimension.id !== (B.dim?.id || p.dimension.id) || Math.hypot(p.location.x - c.x, p.location.z - c.z) > 40)) { try { p.sendMessage("§7戦いの 場所から はなれたので 戦いを ぬけた。"); } catch {} res("gone"); return; } } catch {}
    try { p.onScreenDisplay.setActionBar("§e＞ ガイドブックを 使って 行動を えらぶ"); BAR_T.set(p.id, Date.now()); } catch {}
  }, 20);
  const r = await pr; system.clearRun(h); if (BOOKWAIT.get(p.id) === res) BOOKWAIT.delete(p.id);
  if (r === "open") B.bookTurn[p.id] = B.turn || 1;
  return r === "open" ? "open" : r === "gone" ? "gone" : "stale";
}
// v3.0: できごとの 色分け（ダメージ＝赤・回復＝緑・強化＝水色・弱体＝紫・状態異常＝ピンク・倒れた＝金・ミス＝灰）
const ACOL = /毒|火傷|出血|麻痺|凍結|睡眠|眠っ|鈍足|混乱|魅了|恐怖|ドクケ|ヤケド|シビレ|ネムリ|マドイ|ミイリ|オビエ/;
export function colorLine(t) {
  let s = String(t);
  s = s.replace(/(\d+)(\s*)(の ダメージ|ダメージ)/g, "§c§l$1§r§c$2$3§r");
  s = s.replace(/(HP|ＨＰ)が(\s*)(\d+)(\s*)(回復)/g, "§a$1が$2§l$3§r§a$4$5§r");
  s = s.replace(/(MP|ＭＰ)が(\s*)(\d+)(\s*)(回復)/g, "§9$1が$2§l$3§r§9$4$5§r");
  s = s.replace(/(倒れた|やっつけた|たおした)/g, "§6§l$1§r");
  s = s.replace(/(上がった|アップ)/g, "§b$1§r").replace(/(下がった|ダウン)/g, "§d$1§r");
  s = s.replace(/(会心の 一撃|会心|弱点)/g, "§e§l$1§r").replace(/(ミス|かわした|きかない|効かない)/g, "§7$1§r");
  if (ACOL.test(s)) s = s.replace(ACOL, (m) => `§5${m}§r`);
  return s;
}
export async function playFx(players, fx, lines) {
  if (!lines.length) return;
  lines = lines.map(colorLine);
  // v2.9.12: 自分（青）・味方（緑）・敵（赤）で 色分け。見る 人ごとに きめる
  const sideOf = (p) => { const a = fx && fx.actor; if (!a) return "n"; if (a.owner === p.id || (!a.owner && a.side === (PVPSIDE.get(p.id) || "a"))) return "me"; return a.side === (PVPSIDE.get(p.id) || "a") ? "ally" : "foe"; };
  const MARK = { me: ["§b→ ", "§b｜§r"], ally: ["§a→ ", "§a｜§r"], foe: ["§c← ", "§c｜§r"], n: ["§7・", "§7・§r"] };
  const tint = (p) => { const m = MARK[sideOf(p)]; let first = true; return lines.filter((x) => String(x).trim()).map((x) => { const r = (first ? m[0] : m[1]) + String(x).trim(); first = false; return r; }); };
  for (const p of players) {
    const tl = tint(p);
    logPush(p, tl);   // v2.9.12: 戦いの できごとは 画面の 左に
    let ch = false; try { ch = p.getDynamicProperty("mrpg:chatlog") === true || p.getDynamicProperty("mrpg:nohud") === true; } catch {}   // 枠を けして いる ときは チャットへ
    if (ch) try { p.sendMessage(tl.join("\n")); } catch {}   // 設定で チャットにも
  }
  const K = speedK(players);
  const wait = (n) => waitT(Math.round(n * K));
  // v2.8: 技の 名前を 大きく・結果は 行ごとに（長い 文は 切って 見切れない ように）
  // v2.9.11: 色コード（§x）を 数えずに 見える 文字で 29文字に 切る（「§…」の ように 色コードが 切れて 出ない）
  const cut = (t) => { const s = String(t); let n = 0, i = 0; for (; i < s.length; i++) { if (s[i] === "§") { i++; continue; } if (++n > 29) break; } return i < s.length ? s.slice(0, i).replace(/§$/, "") + "§r…" : s; };
  const mvName = fx && fx.mvName ? fx.mvName : fx && fx.mid ? (fx.mid === "basic" ? (fx.actor && fx.actor.atk && fx.actor.atk.name) || "攻撃" : MOVES[fx.mid]?.name) : null;
  for (const p of players) {
    const sd = sideOf(p), colT = sd === "me" ? "§b§l" : sd === "ally" ? "§a§l" : sd === "foe" ? "§c§l" : "§f§l";
    battleTitle(p, mvName ? `${colT}${mvName}` : "", cut(lines[0]), mvName ? 40 : 46);   // v2.9.12: 画面の まんなか（専用の 場所）
    // v2.9.12: できごとは チャットへ（画面の 下は 自分の モンスターの 状態）
  }
  if (!fx || !fx.anim) { await wait(28); return; }
  const a = fx.actor;
  const tier = fx.tier || 0, big = tier >= 2;
  const sc = 1 + tier * 0.3;
  const col = RGB[fx.el] || RGB[fx.cat] || RGB.none;
  const crit = (fx.dmg || []).some((x) => x.crit) || lines.some((l) => /会心の 一撃|いちげき/.test(String(l).replace(/§./g, "")));
  const tgt0 = fx.hit[0] || fx.healed[0] || null;
  const physLike = fx.anim === "attack" || fx.anim === "dance";
  if (a && tgt0 && tgt0 !== a) camFocus(players, a, tgt0, "aim");
  let home = null;
  const mo = a ? motionOf(fx) : null, spx = SPX[mo] || null;
  // v3.0: エンマは 抜刀して 斬る（攻撃の あいだだけ 抜き身）・厄王ヴァルグレイドは 瞬間移動して 2連続で 斬る
  const isEnma = a && (a.m?.sp === "enma" || a.lookAs === "enma") && physLike && fx.hit.length;
  const isHaken = a && a.m?.sp === "haken" && physLike && fx.hit.length && fx.hit[0] !== a;
  const nmEnma = isEnma && a.ent && ok(a.ent) && (() => { try { return a.ent.hasTag("mrpg_nightmare"); } catch { return false; } })();   // v3.0: 悪夢の エンマは はじめから 抜き身（鍔なし）
  if (nmEnma) { try { a.ent.setProperty("mrpg:form", 2); } catch {} vfx(a.ent, "aura", 0, [0.7, 0.02, 0.08], 1.2); vfx(a.ent, "slash", hOf(a) * 0.6, [0.95, 0.15, 0.2], 1.1); }
  else if (isEnma && a.ent && ok(a.ent)) {   // v3.0: 左の 腰の 鞘から 抜いて 斬る（ふだんは 納めた まま）
    const sheathing = ENMA_S.has(a.ent.id); ENMA_T.set(a.ent.id, {}); ENMA_S.delete(a.ent.id);   // 納刀の 予定を とりけす
    let drawn = false; try { drawn = a.ent.getProperty("mrpg:form") === 0 && !sheathing; } catch {}
    if (!drawn) { anim(a.ent, "enma_draw"); for (const p of players) sound(p, "item.trident.riptide_1", 0.8); await waitT(6); }
    try { a.ent.setProperty("mrpg:form", 0); } catch {}
    vfx(a.ent, "aura", 0, [0.7, 0.02, 0.08], 1.2); vfx(a.ent, "slash", hOf(a) * 0.6, [0.95, 0.15, 0.2], 1.1);
  }
  if (isHaken) {
    try {
      const t0 = fx.hit[0], tl = t0.ent.location, al = a.ent.location;
      home = { ...al };
      vfx(a.ent, "smoke", 0.5, [0.15, 0.05, 0.08], 1.4); for (const p of players) sound(p, "mob.endermen.portal", 0.7);
      const dx = al.x - tl.x, dz = al.z - tl.z, dd = Math.max(0.1, Math.hypot(dx, dz)), r = 1.6 + hOf(t0) * 0.3;
      a.ent.teleport({ x: tl.x + (dx / dd) * r, y: tl.y, z: tl.z + (dz / dd) * r }, { facingLocation: tl });
      vfx(a.ent, "smoke", 0.5, [0.15, 0.05, 0.08], 1.4);
      for (let k = 0; k < 2; k++) { vfx(t0.ent, "xslash", hOf(t0) * 0.7, [0.95, 0.15, 0.2], 1.4 + k * 0.3); vfx(t0.ent, "sparks", hOf(t0) * 0.7, [1, 0.6, 0.3], 1.2); }
    } catch {}
  }
  if (a && !isHaken && physLike && fx.hit.length && fx.hit[0] !== a && (fx.cat !== "special" || spKind(fx) !== "other") && mo !== "enma_kuni" && !["wp_bow", "wp_gun", "wp_tome"].includes(mo)) {   // 飛び道具・魔本は その場から
    sfx(players, "mrpg.dash", 0.9 + Math.random() * 0.3);
    home = await lunge(a, fx.hit[0], fx.hit.length > 1 ? 0.3 : 0.5);
    if (home) camFocus(players, a, fx.hit[0], "hit");   // 踏み込んだら 当たる ところを 近くで
  }
  if (a) {
    anim(a.ent, mo);
    if (mo === "enma_kuni") { for (const p of players) { sound(p, "mob.warden.sonic_charge", 0.7); } }
    if (mo === "enma_majin") { for (const p of players) sound(p, "mob.wither.spawn", 1.4); }
    // v2.2: 巨大モンスターの ため（オーラ・地ひびき・咆哮）
    const bigMA = mo && mo.startsWith("m_") && a.m && ["L", "G"].includes(sizeOf(a.m)) && (fx.anim === "attack" || fx.anim === "breath");
    if (GPRE[mo] || bigMA) {
      const hh = hOf(a), gk = sizeOf(a.m) === "G" ? 1.5 : 1.1;
      vfx(a.ent, "aura", 0, fx.el ? RGB[fx.el] || RGB.martial : RGB.martial, 2.2 * gk); vfx(a.ent, "shock", 0.1, [0.9, 0.8, 0.6], 2.4 * gk); vfx(a.ent, "smoke", 0.2, [0.55, 0.5, 0.45], 2.2 * gk);
      if (mo === "g_roar" || mo === "g_breath") { vfx(a.ent, "orb", hh * 1.5, RGB[fx.el] || RGB.special, 2.2 * gk); vfx(a.ent, "pillar", 0, RGB[fx.el] || RGB.special, 1.6 * gk); }
      for (const p of players) { sound(p, mo === "g_roar" ? "mob.enderdragon.growl" : "mob.ravager.roar", 0.7); }
      shake(a.ent, 0.25 * gk, 0.5);
      if (mo !== "g_charge") camFocus(players, a, tgt0 && tgt0 !== a ? tgt0 : null, "giant");
    }
    if (fx.anim === "cast") sfx(players, fx.mtype === "heal" || fx.mtype === "revive" || fx.mtype === "cure" ? "mrpg.heal" : "mrpg.cast", big ? 0.85 : 1);
    if (fx.anim === "dance") sfx(players, "mrpg.dance", 1);
    if (fx.anim === "breath") sfx(players, "mrpg.breath", big ? 0.8 : 1);
    if (fx.anim === "cast") {
      vfx(a.ent, "circle", 0.05, col, sc);
      vfx(a.ent, "orb", hOf(a) * 1.4 + 0.4, col, sc * 0.9);
      if (big) vfx(a.ent, "aura", 0, col, sc);
      for (const p of players) sound(p, "mob.evocation_illager.cast_spell", big ? 0.8 : 1.1);
    } else if (fx.cat === "special" && spKind(fx) !== "other") {
      const k = spKind(fx), c = RGB["sp_" + k];
      if (k === "spd") { vfx(a.ent, "swirl", 0.1, c, sc); vfx(a.ent, "smoke", 0.1, [0.85, 0.95, 1], sc * 0.8); sfx(players, "mrpg.dash", 1.3); }
      else if (k === "guard") { vfx(a.ent, "aura", 0, c, sc); vfx(a.ent, "circle", 0.05, c, sc * 1.1); for (const p of players) sound(p, "random.anvil_land", 0.7); }
      else { vfx(a.ent, "aura", 0, c, sc * 1.2); vfx(a.ent, "shock", 0.1, c, sc * 1.4); for (const p of players) sound(p, "mob.ravager.roar", 0.9); }
    } else if (fx.cat === "special" || fx.anim === "boom") {
      vfx(a.ent, "aura", 0, RGB.special, sc); vfx(a.ent, "pillar", 0, RGB.special, sc * 0.8);
      for (const p of players) sound(p, "beacon.activate", 1.3);
    } else if (fx.anim === "dance") {
      vfx(a.ent, "notes", 0.3, RGB.dance, sc); vfx(a.ent, "circle", 0.05, RGB.dance, sc * 0.8);
    } else if (fx.anim === "guard") {
      vfx(a.ent, fx.mtype === "charge" ? "aura" : "shock", 0.1, fx.mtype === "charge" ? RGB.martial : [0.6, 0.8, 1], 0.8);
    } else if (fx.anim === "breath") {
      vfx(a.ent, "orb", hOf(a) * 1.3, col, sc * 0.7);
    } else if (fx.anim === "attack" && big) {
      vfx(a.ent, "aura", 0, fx.el ? RGB[fx.el] : RGB.martial, 0.8);
    }
  }
  if (spx) await wait(spx[0]); else if (GPRE[mo]) await wait(GPRE[mo]); else await wait(fx.anim === "attack" ? (big ? 13 : fx.hits >= 2 ? 6 : 9) : fx.anim === "dance" ? 18 : fx.anim === "cast" ? (big ? 24 : 16) : fx.anim === "breath" ? 9 : 14);
  if (fx.anim === "breath" && a) {
    for (const t of fx.hit.slice(0, 3)) stream(a, t, col, sc);
    for (const p of players) sound(p, "mob.enderdragon.flap", 0.8);
    await wait(9);
  }
  const reps = isHaken ? 2 : isEnma ? Math.max(3, Math.min(4, fx.hits || 1)) : spx ? spx[1] : fx.anim === "attack" ? Math.min(3, fx.hits || 1) : 1;
  if (mo === "enma_kuni") { for (const p of players) sound(p, "mob.warden.sonic_boom", 0.8); for (const t of fx.hit) shake(t.ent, 0.6, 0.6); }
  // v2.2: 巨大モンスターの 着弾（地面が 割れる・衝撃波・土けむり）
  if (GPRE[mo] && fx.hit.length) {
    const gk = sizeOf(a.m) === "G" ? 1.6 : 1.15;
    vfx(a.ent, "shock", 0.05, [1, 0.85, 0.5], 3.6 * gk); vfx(a.ent, "smoke", 0.1, [0.5, 0.45, 0.4], 3 * gk);
    for (const t of fx.hit) { vfx(t.ent, "boom", hOf(t) * 0.6, RGB[fx.el] || RGB.fire, 1.3 * gk); vfx(t.ent, "shock", 0.05, RGB[fx.el] || [1, 0.8, 0.5], 2 * gk); vfx(t.ent, "sparks", hOf(t) * 0.7, RGB[fx.el] || RGB.martial, 1.6 * gk); }
    shake(a.ent, 0.55 * gk, 0.7);
    for (const p of players) { sound(p, "random.explode", 0.7); sound(p, "mob.irongolem.hit", 0.6); }
  }
  for (let r = 0; r < reps; r++) {
    if (isEnma) for (const t of fx.hit.slice(0, 4)) { try { vfx(t.ent, "xslash", hOf(t) * 0.7, [0.75, 0.02, 0.06], 1.5); vfx(t.ent, "slash", hOf(t) * 0.8, [0.12, 0.0, 0.02], 1.7); vfx(t.ent, "sparks", hOf(t) * 0.7, [1, 0.2, 0.2], 1); t.ent.dimension.spawnParticle("mrpg:enma_slash", { x: t.ent.location.x, y: t.ent.location.y + hOf(t) * 0.7, z: t.ent.location.z }); } catch {} }
    if (fx.hit.length) {
      const metalPing = (fx.dmg || []).some((x) => x.t.tr && x.t.tr.metal && x.d <= 2 && !x.crit);
      const id = crit && r === reps - 1 ? "mrpg.crit" : metalPing ? "mrpg.metal" : fx.cat === "slash" ? (big ? "mrpg.slash_big" : "mrpg.slash") : physLike ? (big ? "mrpg.punch_big" : "mrpg.punch") : fx.anim === "cast" || fx.anim === "breath" ? "mrpg.spellhit" : null;
      if (id) sfx(players, id, 0.92 + Math.random() * 0.16);
      if (crit && r === reps - 1) sfx(players, fx.cat === "slash" ? "mrpg.slash_big" : "mrpg.punch_big", 1);
    }
    for (const t of fx.hit) {
      anim(t.ent, big || crit ? "hurt_big" : "hurt");
      hitFx(t, fx, col, sc, crit && r === reps - 1);
    }
    if (reps > 1 && r < reps - 1) await wait(spx ? spx[2] : 5);
  }
  damagePopups(fx);
  if (fx.hit.length && (big || crit || fx.cat === "special" || fx.anim === "boom")) shake(fx.hit[0].ent, big || fx.anim === "boom" ? 0.45 : 0.25, big ? 0.45 : 0.3);
  for (const p of players) {
    if (fx.hit.length && fx.el && SND[fx.el] && fx.anim !== "attack") sound(p, SND[fx.el], big ? 0.8 : 1);
    if (fx.hit.length && fx.cat === "special") sound(p, "random.explode", 1.2);
    if (fx.healed.length) sound(p, fx.mtype === "buff" ? "random.levelup" : "random.orb", 1.4);
  }
  for (const t of fx.healed) {
    if (fx.mtype === "buff" || fx.mtype === "charge") vfx(t.ent, "arrows_up", 0.2, RGB.buff, 1);
    else { vfx(t.ent, "rise", 0.1, RGB.heal, 1); vfx(t.ent, "circle", 0.05, RGB.heal, 0.8); }
  }
  if (fx.anim === "boom" && a) { vfx(a.ent, "boom", hOf(a), RGB.fire, 2); shake(a.ent, 0.6, 0.6); for (const p of players) sound(p, "random.explode"); }
  if (fx.revived) { standUp(fx.revived); vfx(fx.revived.ent, "pillar", 0, RGB.light, 1); }
  for (const r of fx.revivedList || []) { standUp(r); vfx(r.ent, "pillar", 0, RGB.light, 1); }
  await wait(big ? 16 : 12);
  if (home) { await wait(4); if (isHaken) { try { vfx(a.ent, "smoke", 0.5, [0.15, 0.05, 0.08], 1.4); } catch {} } backTo(a, home, fx.hit[0]); }
  if (isEnma && !nmEnma && a.ent && ok(a.ent)) {   // 斬り終えたら 鞘へ（技の 動きが 終わってから）
    const tk = {}, ent = a.ent, eid = ent.id; ENMA_T.set(eid, tk);
    const rest = { enma_combo5: 22, enma_majin: 30, enma_kuni: 36 }[mo] || 6;
    system.runTimeout(() => { try { if (ENMA_T.get(eid) !== tk || !ok(ent)) { ENMA_T.delete(eid); return; } if (a.hp <= 0) { ENMA_T.delete(eid); return; } ENMA_S.add(eid); anim(ent, "enma_sheathe"); system.runTimeout(() => { try { if (ENMA_T.get(eid) === tk && ok(ent)) ent.setProperty("mrpg:form", 1); } catch {} ENMA_S.delete(eid); if (ENMA_T.get(eid) === tk) ENMA_T.delete(eid); }, 7); } catch {} }, rest);
  }   // 斬り終えたら 鞘へ
  if (fx.ko.length) sfx(players, "mrpg.ko", 1);
  for (const t of fx.ko) koFx(t);
  if (fx.ko.length) await wait(12);
}
// v2.8: 頭の 上の 名前に HPバー（攻撃の 瞬間を 見のがしても ひと目で わかる）
const HPB = 10;
export function hpTag(f) {
  if (!f || !ok(f.ent)) return;
  if (f.hp > 0 && f.dust) standUp(f);   // v2.9.12: 生きかえったら 姿を もどす（どの 方法でも）
  const r = Math.max(0, Math.min(1, f.hp / Math.max(1, f.mx.hp))), n = f.hp > 0 ? Math.max(1, Math.round(r * HPB)) : 0;
  const col = r > 0.5 ? "§a" : r > 0.25 ? "§e" : "§c";
  const nm = `${f.side === "a" ? "§b" : "§c"}${f.name} §7Lv${f.lv}`;
  const ail = Object.keys(f.ail || {}).filter((k) => f.ail[k] > 0).length ? " §d●" : "";
  try { f.ent.nameTag = f.hp > 0 ? `${nm}${ail}\n${col}${"|".repeat(n * 2)}§8${"|".repeat((HPB - n) * 2)} §f${Math.ceil(r * 100)}%` : `${nm}\n§8× たおれた`; } catch {}
}
export function hpTags(B) { for (const f of [...B.allies, ...B.enemies]) hpTag(f); }
function koFx(t) {
  const h = hOf(t);
  vfx(t.ent, "boom", h, [1, 0.8, 0.5], 1.2); vfx(t.ent, "smoke", h, [0.6, 0.6, 0.6], 1.2); vfx(t.ent, "shock", 0.1, RGB.none, 1);
  if (t.isBoss) { shake(t.ent, 0.7, 0.8); vfx(t.ent, "pillar", 0, RGB.light, 2); }
  anim(t.ent, "faint", true);
  // v2.9.12: 横たわった あと 塵に なって 消える（起き上がって 見えない ように）。生きかえると また 見える
  const e = t.ent;
  system.runTimeout(() => { try { if (t.hp > 0 || !ok(e)) return; anim(e, "faint", true); vfx(e, "smoke", 0.3, [0.75, 0.7, 0.62], 1.4); particle(e, "minecraft:white_smoke_particle", 0.4); { const BB = [...battles.values(), ...HUD].find((B) => (B.allies || []).includes(t) || (B.enemies || []).includes(t)); if (!BB || BB.ended) return; } e.addEffect("invisibility", 20 * 3600, { showParticles: false }); t.dust = true; } catch {} }, 22);
}
// 生きかえった・戦いが 終わった ときに 姿を もどす
export function standUp(f) { const e = f && f.ent ? f.ent : f; if (!ok(e)) return; try { e.removeEffect("invisibility"); } catch {} anim(e, "reset"); if (f && f.ent) f.dust = false; }
export function heartFx(e) { vfx(e, "hearts", 1, [1, 0.45, 0.6], 1); vfx(e, "rise", 0.1, [1, 0.7, 0.8], 1); }
export function levelFx(e) { vfx(e, "rise", 0.1, [1, 0.9, 0.4], 1.2); vfx(e, "pillar", 0, [1, 0.9, 0.5], 0.7); }

// v1.7: 作戦（オートで 戦う ときの 方針。モンスターごとに 保存）
// v3.0: 戦いの 決まり（魔法禁止 など）で 使えない 技を のぞく（はじめと 作戦で かえた ときの 両方で 使う）
function ruleMoves(B, moves) { return B && B.master && B.master.rules && B.master.rules.nomagic ? moves.filter((id) => MOVES[id]?.cat !== "magic") : moves; }
async function tacticsMenu(p, mine, B) {
  // v2.9.11: 方針と 技の 好み（◎○×）
  await tacticsAll(p, mine.filter((f) => f.m).map((f) => f.m), () => {
    try { if (!p.isValid) return; const d = load(p); if (!d) return; const L = allMonsDeep(d);
      for (const f of mine) { const x = f.m && L.find((y) => y.id === f.m.id); if (x && x !== f.m) for (const k of ["mset", "msetFix", "tac", "mpref"]) { if (f.m[k] === undefined) delete x[k]; else x[k] = f.m[k]; } }
      save(p, d); } catch {} }, "作戦");
  for (const f of mine) if (f.m && !f.lookAs && !f.guest) f.moves = ruleMoves(B, battleMoves(f.m));   // v3.0: 戦いの とちゅうでも 使う 技を かえられる
}
// ---------- コマンド選択 ----------
// v3.0 第63版: 技の 効き目（相手ごと）
function hintOf(f, mv, theirs) { if (!mv || !(mv.mult || mv.f || mv.basic) || mv.target === "self" || mv.target === "ally" || mv.target === "allies") return ""; const h = alive(theirs).map((t) => hitHint(f, t, mv)).filter(Boolean); return h.length ? ` §8[${h.join("§8 ")}§8]` : ""; }
async function chooseTarget(p, B, list, t, view, actor = null, mv = null) {
  if (list.length === 1) return list[0];
  const sel = await choose(p, t, statusText(B, [], view, false, GRID_ON), [...list.map((f) => [`${f.name}${(view === "a") === (f.side === "a") ? ` §8HP${f.hp}/${f.mx.hp}` : ` §8HP${Math.ceil(f.hp / Math.max(1, f.mx.hp) * 100)}%`}${actor && mv && f.side !== actor.side ? " " + hitHint(actor, f, mv) + ((x) => (x === null ? "" : ` §7約${x}%`))(estPct(actor, f, mv)) : ""}`, MON_ICON(f.m.sp)]), ["§7戻る", ICON("i_back")]], GRID_ON);   /* 第75版: 戦いの 画面は マス目（スクロール なし） */
  return sel < 0 || sel >= list.length ? null : list[sel];
}
// v2.9.9: おまかせに なった あとの 古い 画面は 何も しないで おわる
const staleOf = (p, B) => { const g0 = B.cmdGen && B.cmdGen[p.id]; return () => B.ended || !!(B.cmdGen && B.cmdGen[p.id] !== g0); };
async function chooseAction(p, B, f, view, nth = "") {
  const mine = view === "a" ? B.allies : B.enemies, theirs = view === "a" ? B.enemies : B.allies;
  const stale = staleOf(p, B);
  let note = "";
  for (;;) {
    if (stale()) return null;
    const cost = (mv) => costOf(f, mv);
    let rec = null; { const t0 = f.aiTac; try { f.aiTac = "analyze"; rec = aiDecide(f, B, { pre: true }); } catch {} f.aiTac = t0; }   // v3.0 第63版: おすすめの 技（★）
    const star = (id) => (rec && rec.kind === "move" && rec.move === id ? "§6★" : "");
    if (!f.isBoss && !f.lookAs && f.m && f.moves.length > MSET_MAX) f.moves = f.moves.slice(0, MSET_MAX);   // 第65版: 戦いで 使える 技は 6つまで（念のため）
    const head0 = [note || `§e${f.name}§rは どうする？${nth ? " §d（2回行動）" : ""}  §bMP${f.mp}`], bodyC = statusText(B, head0, view, false, true), gm = GRID_ON && bodyLines(bodyC) <= gridBodyMax(f.moves.length + 3);   /* 第75版: 技が 少なくても マス目（スクロール なし） */   /* 第74版: マス目に なる ときだけ 短い 戦況・技の 名前の 前で 改行 */
    const mlab = (id) => gm ? moveLabel(id).replace("§7【無属性】", "") + "\n" : moveLabel(id);
    const items = f.moves.map((id) => { const mv = MOVES[id]; const no = f.mp < cost(mv) || sealedFor(f, mv); return [`${star(id)}${mlab(id)}${no ? "§8" : "§l"}${mv.name}§r ${f.mp < cost(mv) ? "§c" : "§9"}MP${cost(mv)}${sealedFor(f, mv) ? " §7[封]" : ""}${hintOf(f, mv, theirs)}\n§8${moveDesc(id, true).replace(/§./g, "").replace(/^【[^】]*】(【[^】]*】)?/, "").trim()}`, ICON(mv.heal || mv.revive || mv.cure ? "i_party" : mv.kind === "support" || mv.kind === "reflect" ? "i_skill" : "i_spell")]; });
    const ab = f.atk;
    const r = await paged(p, `${f.name}の 行動${nth}`, gm ? bodyC : statusText(B, head0, view), items, 6,
      [[`${rec && rec.kind === "attack" ? "§6★" : ""}${mlab(ab)}§l${ab.name}${sealedFor(f, ab) ? " §7[封]" : ""}${hintOf(f, ab, theirs)}`, ICON("i_fight")], [`${rec && rec.kind === "defend" ? "§6★" : ""}防御`, ICON("i_guard")]], null, gm);   /* 第74版: 技も マス目に（説明が 長い ときは 縦） */   /* 第70版: 戦いの 技は 説明が 大事なので 縦ならびの まま */
    note = "";
    if (r === -1 || stale()) return null;
    const sel = r === -2 ? 0 : r === -3 ? -9 : r + 1;
    if (sel === 0) {
      if (sealedFor(f, f.atk)) { note = `§7${f.name}の 攻撃は 封じられている！`; continue; }
      const t = await chooseTarget(p, B, alive(theirs), "誰を 攻撃する？", view, f, f.atk);
      if (stale()) return null;
      if (t) return { actor: f, kind: "attack", target: t, manual: true };
      continue;
    }
    if (sel === -9) { f.defend = true; return { actor: f, kind: "defend", manual: true }; }
    const id = f.moves[sel - 1];
    const mv = MOVES[id];
    if (f.mp < cost(mv)) { note = "§cMPが 足りない！"; continue; }
    if (sealedFor(f, mv)) { note = `§7${mv.name}は 封じられている！`; continue; }
    let target = null;
    if (mv.target === "enemy") { target = await chooseTarget(p, B, alive(theirs), `${mv.name}を 誰に？`, view, f, mv); if (stale()) return null; if (!target) continue; }
    else if (mv.target === "ally") {
      const list = mv.revive ? mine.filter((a) => a.hp <= 0 && !a.out) : alive(mine);
      if (!list.length) { note = "§c倒れている 仲間は いない。"; continue; }
      target = await chooseTarget(p, B, list, `${mv.name}を 誰に？`, view);
      if (stale()) return null;
      if (!target) continue;
    }
    if (wantConfirm(p)) {
      const yes = await confirm(p, mv.name, [moveDesc(id), "", `§f${f.name} §7（MP ${f.mp} → ${f.mp - cost(mv)}）`, target ? `§f相手: §e${target.name}` : "", "", "§fこの 技を 使いますか？"].join("\n"), "使う", "やめる");
      if (stale()) return null;
      if (!yes) continue;
    }
    return { actor: f, kind: "move", move: id, target, manual: true };
  }
}
async function chooseItem(p, B, view, allowScout) {
  const have = Object.entries(rpgItems(p)).filter(([id]) => BATTLE_ITEMS.has(ITEMS[id].kind) && (allowScout || ITEMS[id].kind !== "scout"));
  if (!have.length) { await notice(p, "道具", "バトルで 使える 道具を もっていない。"); return null; }
  const stale = staleOf(p, B);
  for (;;) {
  if (stale()) return null;
  const sel = await choose(p, "道具", statusText(B, ["どの 道具を 使う？"], view, false, GRID_ON), [...have.map(([id, n]) => [`${ITEMS[id].name} §8×${n}\n§8${clipT(itemDesc(id), 26)}`, ITEM_ICON(id)]), ["§7戻る", ICON("i_back")]], GRID_ON);   /* 第75版: 戦いの 画面は マス目（スクロール なし） */
  if (sel < 0 || sel >= have.length || stale()) return null;
  const id = have[sel][0], k = ITEMS[id].kind;
  const mine = view === "a" ? B.allies : B.enemies;
  let target = null;
  if (["heal", "mpheal", "cure"].includes(k)) target = await chooseTarget(p, B, alive(mine), `${ITEMS[id].name}を 誰に？`, view);
  if (k === "revive") { const dead = mine.filter((a) => a.hp <= 0); if (!dead.length) { await notice(p, "道具", "倒れている 仲間は いない。"); return null; } target = await chooseTarget(p, B, dead, "誰に 使う？", view); }
  if (stale()) return null;
  if (["heal", "mpheal", "cure", "revive"].includes(k) && !target) continue;
  if (wantConfirm(p)) {
    const yes = await confirm(p, ITEMS[id].name, [`§l§e${ITEMS[id].name}§r §8×${have[sel][1]}`, `§f${itemDesc(id)}`, target ? `§f相手: §e${target.name}` : "", "", "§fこの 道具を 使いますか？"].join("\n"), "使う", "やめる");
    if (stale()) return null;
    if (!yes) continue;
  }
  return { id, target };
  }
}
// 1ターン分のコマンド。owner を指定すると その人の モンスターだけ 指示する
// 第68版: 入れかわった ターンの 子は 指示しない
const actable = (B, L) => alive(L).filter((f) => f.swapT !== (B.turn || 1));
async function commandPhase(p, B, view, log, pvp, owner) {
  const side = view === "a" ? B.allies : B.enemies;
  let mine = owner ? side.filter((f) => f.owner === owner) : side;
  // v2.9.6: おまかせに なった 古い 画面は 自分で おわる（つぎの ターンの 画面と かさならない）
  B.cmdGen = B.cmdGen || {}; const gen = B.cmdGen[p.id] = (B.cmdGen[p.id] || 0) + 1;
  let opened = false;
  for (;;) {
    if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
    mine = owner ? side.filter((f) => f.owner === owner) : side;
    // v2.9.11: ずっと オート（しゃがむと とめる）
    B.autoAll = B.autoAll || {};
    if (B.autoAll[p.id]) {
      let sneak = false; try { sneak = !!p.isSneaking; } catch {}
      if (sneak) { B.autoAll[p.id] = false; try { p.sendMessage("§eずっと オートを やめた。"); } catch {} }
      else { await new Promise((r) => system.runTimeout(r, 10)); if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true }; return { acts: actable(B, mine).map((f) => ({ ...aiDecide(f, B), ai: true })) }; }
    }
    const title = pvp ? "対戦" : B.boss ? (B.raid ? "レイドバトル" : "ボスバトル") : B.players && B.players.length > 1 ? "協力バトル" : "バトル";
    B.lastActs = B.lastActs || {};
    const key = owner || view;
    const prev = (B.lastActs[key] || []).filter((a) => a.actor.hp > 0);
    const btnsTop = pvp
      ? [["§l戦う", ICON("i_fight")], ["オートで 戦う", ICON("i_skill")], ["道具", ICON("i_item")], ["§cこうさんする", ICON("i_close")]]
      : [["§l戦う", ICON("i_fight")], ["オートで 戦う", ICON("i_skill")], ["道具", ICON("i_item")], ["スカウト", ICON("i_scout")], B.boss || B.master ? ["§cこうさんする\n§8お金は へらない", ICON("i_close")] : ["逃げる", ICON("i_run")]];
    if (prev.length) btnsTop.splice(1, 0, [`§2前と 同じ\n§8${prev.map((a) => a.kind === "move" ? MOVES[a.move].name : a.kind === "attack" ? "攻撃" : "防御").join("・").slice(0, 24)}`, ICON("i_party")]);
    const px = !pvp && B.players ? B.players.find((y) => y.p.id === p.id) : null;
    const benchOk = px ? benchCands(B, px) : [];   // 第68版: 裏（スタンバイ）
    const benchIdx = benchOk.length ? btnsTop.length : -1;   // 逃げるの すぐ 下に
    if (benchOk.length) btnsTop.push([`§b表と 裏を 入れかえ §8（裏 ${benchOk.length}体）\n§8倒れた 子とも 交代できる・出た 子は この ターン 動けない`, ICON("i_party")]);
    const autoIdx = btnsTop.length; btnsTop.push(["§2ずっと オート §8（しゃがむと とまる）", ICON("i_skill")]);
    const tacIdx = btnsTop.length; btnsTop.push(["§6作戦 §8（方針・技の 好み）", ICON("i_help")]);
    const fixIdx = btnsTop.length; btnsTop.push(["§7表示を なおす §8（背景・モンスターが 見えない とき）", ICON("i_back")]);
    const statIdx = btnsTop.length; btnsTop.push(["§b戦況・ログを 見る §8（HP・できごと）", ICON("i_zukan")]);
    const scIdx = btnsTop.length; btnsTop.push(["§d弱点・相性を しらべる §8（属性・反射・行動順）", ICON("i_zukan")]);   // v3.0 第63版   // v2.9.12: 戦況は 別の ページに
    let tsubaIdx = -1; try { if (!pvp && view === "a" && tsubaReady(p, load(p), mine)) { tsubaIdx = btnsTop.length; btnsTop.push(["§4§l魔神の鍔を 使う §8（ムサシが エンマに 顕現）", ICON("i_fight")]); } } catch {}   // v2.9.14
    const foesNow = alive(view === "e" ? B.allies : B.enemies);
    // v2.9.12: 本には 相手の HPの 残り（バー と %）と 状態異常・バフ。自分の モンスターは 画面の 上
    const foeLine = (x) => { const r = x.hp / Math.max(1, x.mx.hp), c = r <= 0.25 ? "§c" : r <= 0.5 ? "§e" : "§a"; let tg = ""; try { tg = fTags(x).trim().replace(/\s+/g, " "); } catch {} return `§c▲§f${String(x.name).replace(/§./g, "").slice(0, 8)} ${meter(x.hp, x.mx.hp, 10, c)} ${c}${Math.max(1, Math.round(r * 100))}%${tg ? `\n   ${tg}` : ""}`; };
    const brief = `§7ターン ${B.turn || 1}\n${foesNow.slice(0, 6).map(foeLine).join("\n")}\n§8くわしい できごとは「戦況・ログを 見る」`;
    // v2.9.12: 行動は ガイドブックを 使って えらぶ（勝手に 画面が 開かない）
    if (!opened) {
      const w = await waitBook(p, B, gen);
      if (w === "gone") return { acts: [], leave: true, surrender: !!pvp };   // ぬけた 人は 戦いから はずす（対戦なら こうさん）
      if (w === "stale" || B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
      opened = true;
    }
    let top = await choose(p, title, `${brief}\n§d弱点 §r${weakBrief(B, view) || "§7なし"}`, btnsTop);   // v3.0 第63版: 相手の 弱点を いつも 表示
    if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };   // v2.9.9
    if (top < 0) { opened = false; if (B.bookTurn) delete B.bookTurn[p.id]; continue; }   // 閉じたら また 本を 使うまで まつ
    if (benchIdx >= 0 && top === benchIdx) {
      const outs = mine.filter((f) => !f.out && f.owner === p.id && f.m && !f.guest && !f.lookAs);
      const o = await choose(p, "ひっこめる 仲間", "§7ひっこめる 仲間を 選んでください（入れかわった 子は この ターン 動けない）", [...outs.map((f) => [`${f.name} §8${f.hp <= 0 ? "§cたおれた" : `HP${f.hp}/${f.mx.hp}`}`, MON_ICON(f.m.sp)]), ["§7戻る", ICON("i_back")]]);
      if (o < 0 || o >= outs.length) continue;
      if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
      const room = BENCH_FIELD - fieldSlots(B, p.id) + slotOf(outs[o].m), cands = benchCands(B, px).filter((m) => slotOf(m) <= room);
      if (!cands.length) { await notice(p, "表と 裏を 入れかえ", `§c${outs[o].name}の かわりに 出せる 裏の 子が いません。§r\n§7（表の 枠は 4まで。S=1 M=2 L=3 G=4）`); continue; }
      const k = await choose(p, "くりだす 裏の 仲間", `§7${outs[o].name}と 入れかえる 子を 選んでください`, [...cands.map((m) => [`${m.nm} §8Lv${m.lv} HP${m.hp}/${calcStats(m).hp} ${sizeOf(m)}`, MON_ICON(m.sp)]), ["§7戻る", ICON("i_back")]]);
      if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
      if (k < 0 || k >= cands.length) continue;
      if (!B.allies.includes(outs[o]) || !benchCands(B, px).includes(cands[k])) continue;
      const bl = []; benchIn(B, px, outs[o], cands[k], bl, false); log.push(...bl);
      try { pushHud(B); } catch {}
      await playFx([p], null, bl);
      continue;
    }
    if (top === autoIdx) { B.autoAll[p.id] = true; try { p.sendMessage("§2ずっと オートに した。§7しゃがむ（スニーク）と つぎの ターンで とまる"); } catch {} return { acts: actable(B, mine).map((f) => ({ ...aiDecide(f, B), ai: true })) }; }
    if (top === tsubaIdx && tsubaIdx >= 0) {
      const f = mine.find((x) => x.m && x.m.sp === "musashi" && x.hp > 0 && x.hp <= x.mx.hp * 0.5 && !x.lookAs);
      if (!f) { await notice(p, "魔神の鍔", "§7鍔は 静かだ……。§fムサシの HPが 半分 以下の ときに 使える。"); continue; }   // v3.0: HP 半分 以下の ときだけ
      if (f) { const L = []; tsubaTransform(f, L); log.push(...L); try { hpTag(f); } catch {} try { if (ok(f.ent)) { setLook(f.ent, "enma", { ...f.m, look: null, tint: null }); particle(f.ent, "minecraft:totem_particle", 1.5); vfx(f.ent, "pillar", 0, [0.8, 0.05, 0.1], 2); sound(p, "mob.wither.spawn", 0.8); } } catch {} await notice(p, "魔神の鍔", L.join("\n")); }
      continue;
    }
    if (top === tacIdx) { await tacticsMenu(p, mine, B); if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true }; continue; }
    if (top === scIdx) { await notice(p, "弱点・相性", scoutText(B, view)); if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true }; continue; }
    if (top === statIdx) { await notice(p, "戦況", statusText(B, log, view)); if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true }; continue; }
    if (top === fixIdx) { fixView(B, true); try { p.sendMessage("§7表示を なおしました。まだ 見えない ときは 設定の「バトルの ステージ」を 切りかえてみてね。"); } catch {} continue; }
    if (prev.length) {
      if (top === 1) {
        const theirs = view === "a" ? B.enemies : B.allies, mineAll = view === "a" ? B.allies : B.enemies;
        const acts = [];
        for (const a of prev) {
          const b = { ...a };
          if (b.kind === "move" && (!b.actor.moves.includes(b.move) || b.actor.mp < costOf(b.actor, MOVES[b.move]) || sealedFor(b.actor, MOVES[b.move]))) { acts.push(aiDecide(b.actor, B)); continue; }
          if (b.kind === "defend") b.actor.defend = true;
          if (b.target && b.target.hp <= 0 && !(b.kind === "move" && MOVES[b.move].revive)) {
            const pool = alive(b.target.side === b.actor.side ? mineAll : theirs);
            if (!pool.length) { acts.push(aiDecide(b.actor, B)); continue; }
            b.target = pool[Math.floor(Math.random() * pool.length)];
          }
          if (b.kind === "move" && MOVES[b.move].revive && (!b.target || b.target.hp > 0)) { acts.push(aiDecide(b.actor, B)); continue; }
          acts.push(b);
        }
        return { acts };
      }
      if (top > 1) top--;
    }
    if (top === 0) {
      if (!actable(B, mine).length) return { acts: [] };
      const acts = [];
      let back = false;
      for (const f of actable(B, mine)) {
        if (f.rollT !== B.turn || f.rollN === undefined) { f.rollN = rollActs(f); f.rollT = B.turn; }   // v3.0: もどっても 行動回数は 引き直さない
        f.turnActs = f.rollN;
        const n = f.turnActs;
        const a = await chooseAction(p, B, f, view, n > 1 ? `（1回目／${n}回行動）` : "");
        if (!a) { back = true; break; }
        acts.push(a);
        for (let i = 2; i <= n && a.kind !== "defend"; i++) {
          const b = await chooseAction(p, B, f, view, `（${i}回目／${n}回行動）`);
          if (!b) { back = true; break; }
          b.extra = true; acts.push(b);
        }
        if (back) break;
      }
      if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
      if (back) { for (const g of mine) g.defend = false; continue; }
      B.lastActs[key] = acts;
      return { acts };
    }
    if (top === 1) return { acts: actable(B, mine).map((f) => ({ ...aiDecide(f, B), ai: true })) };
    if (top === 2) { if (B.master && B.master.rules && B.master.rules.noitem) { await notice(p, "道具", "§cこの 戦いでは 道具を 使えない！（縛り）"); continue; } const it = await chooseItem(p, B, view, !pvp && !(B.master && B.master.arena) && !B.tmap && !B.dgElite && (B.nushi === null || B.nushi === undefined)); if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true }; if (it && ITEMS[it.id]?.kind === "escape" && (B.boss || B.master || pvp)) { await notice(p, "道具", pvp ? "§c対戦では 使えない！" : B.master ? "§cマスターとの 勝負からは 逃げられない！" : "§cボスからは 逃げられない！"); continue; } if (it) return { item: it, acts: [] }; continue; }
    if (pvp) { if (await confirm(p, "こうさん", "こうさんしますか？")) return { surrender: true, acts: [] }; continue; }
    if (top === 3) {
      const dd = load(p), why = scoutBlock(B, dd);
      if (why) { await notice(p, "スカウト", why); if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true }; continue; }
      const tg = await pickScout(B, p, dd);
      if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
      if (!tg) continue;   // やめたら 行動を えらび なおす（ターンを なくさない）
      return { scout: true, target: tg, acts: [] };
    }
    if (B.boss || B.master) {   // こうさんの 確認も ここで（「続ける」なら えらび なおし）
      const yes = await confirm(p, "こうさん", "§fこの 戦いを あきらめますか？\n§7お金は へりません。仲間は HP1で もどり、あとで もう一度 挑めます。", "こうさんする", "続ける");
      if (B.cmdGen[p.id] !== gen || B.ended) return { acts: [], stale: true };
      if (!yes) continue;
      return { run: true, sure: true, acts: [] };
    }
    return { run: true, acts: [] };
  }
}

// ---------- 野生・ボス・レイド（協力対応） ----------
// ---------- 気泡の ドーム（海の バトル）----------
function domeCmd(dim, c) { try { if (typeof dim.runCommand === "function") dim.runCommand(c); else dim.runCommandAsync(c); } catch {} }
async function buildDome(B, p, wild, d) {
  const dim = p.dimension, P = p.location, E = wild.location;
  const big = (m) => ["L", "G"].includes(sizeOf(m));
  const huge = d.party.some(big) || ["L", "G"].includes(SPECIES[wildInfo(wild).sid]?.sz);
  const R = Math.min(20, 11 + d.party.length + (huge ? 6 : 0));
  const H = huge ? Math.max(12, Math.round(R * 0.8)) : Math.max(9, Math.round(R * 0.7));
  const cx = Math.floor((P.x + E.x) / 2), cz = Math.floor((P.z + E.z) / 2), fy = Math.floor(P.y);
  const x1 = cx - R - 2, x2 = cx + R + 2, z1 = cz - R - 2, z2 = cz + R + 2, y1 = fy - 1, y2 = fy + H + 2;
  // v2.9.6: ほかの 戦いの ドーム・ステージと 重なる ときは 作らない（もとに もどらない ガラスが のこるため）
  { const box = { dim: dim.id, x1, x2, z1, z2 }, others = [...battles.values()].filter((o) => o !== B && !o.ended).flatMap((o) => [o.resv, o.dome && { dim: o.dome.dim.id, x1: o.dome.x1, x2: o.dome.x2, z1: o.dome.z1, z2: o.dome.z2 }]).filter(Boolean);
    if (!boxFree(box, others)) return; B.resv = box; }   // v2.9.12: 四角どうしで しらべる
  const name = `mrpg_dome_${B.bid}`;
  domeCmd(dim, `structure save ${name} ${x1} ${y1} ${z1} ${x2} ${y2} ${z2} false disk true`);
  B.dome = { name, x1, y1, z1, x2, z2, y2, dim };
  addPending(B.dome); liveAdd(B.dome);
  B.floorY = fy;
  B.center = { x: E.x, y: fy, z: E.z };
  const cmds = [];
  for (let dy = 0; dy <= H + 1; dy++) {
    const ro = (R + 1) * Math.sqrt(Math.max(0, 1 - (dy / (H + 1)) ** 2));
    const rin = dy < H ? R * Math.sqrt(Math.max(0, 1 - (dy / H) ** 2)) : -1;
    for (let z = -Math.floor(ro); z <= Math.floor(ro); z++) {
      const xo = Math.floor(Math.sqrt(Math.max(0, ro * ro - z * z)));
      cmds.push(`fill ${cx - xo} ${fy + dy} ${cz + z} ${cx + xo} ${fy + dy} ${cz + z} glass`);
      if (rin >= 0 && Math.abs(z) <= rin) { const xi = Math.floor(Math.sqrt(Math.max(0, rin * rin - z * z))); cmds.push(`fill ${cx - xi} ${fy + dy} ${cz + z} ${cx + xi} ${fy + dy} ${cz + z} air`); }
    }
  }
  // たいらな 床と あかり
  for (let z = -R - 1; z <= R + 1; z++) {
    const xo = Math.floor(Math.sqrt(Math.max(0, (R + 1) ** 2 - z * z)));
    cmds.push(`fill ${cx - xo} ${fy - 1} ${cz + z} ${cx + xo} ${fy - 1} ${cz + z} ${Math.abs(z) % 6 === 0 ? "prismarine_bricks" : "sandstone"}`);
  }
  for (let a = 0; a < 8; a++) { const x = Math.round(cx + Math.cos(a * Math.PI / 4) * (R - 1)), z = Math.round(cz + Math.sin(a * Math.PI / 4) * (R - 1)); cmds.push(`setblock ${x} ${fy - 1} ${z} sea_lantern`); }
  for (let i = 0; i < cmds.length; i++) { domeCmd(dim, cmds[i]); if (i % 90 === 89) await wait(1); }
  try { p.teleport({ x: P.x, y: fy, z: P.z }); } catch {}
  try { wild.teleport({ x: E.x, y: fy, z: E.z }); } catch {}
  for (const q of world.getAllPlayers()) if (q.dimension.id === dim.id && Math.hypot(q.location.x - cx, q.location.z - cz) < R + 20) q.sendMessage("§bまわりの 海が 気泡の ドームに つつまれた！");
}
async function removeDome(B) {
  const { name, x1, y1, z1, dim } = B.dome;
  await wait(10);
  LIVE.delete(name);
  if (!areaLoaded(dim, B.dome)) { B.dome = null; return; }   // v2.9.12: 読みこまれて いない ときは あとで もどす
  domeCmd(dim, `structure load ${name} ${x1} ${y1} ${z1} 0_degrees none false true`);
  domeCmd(dim, `structure delete ${name}`);
  dropPending(name);
  B.dome = null;
}
// 海の バトル: 水中呼吸と 暗視
function seaFx(p, on) {
  try {
    if (on) { p.addEffect("water_breathing", 20 * 3600, { amplifier: 0, showParticles: false }); p.addEffect("night_vision", 20 * 3600, { amplifier: 0, showParticles: false }); }
    else { p.removeEffect("water_breathing"); p.removeEffect("night_vision"); }
  } catch {}
}
// 味方・敵が ひとめで 分かるように: あしもとの わ と 名前の HPゲージ
// v2.2: 能力の 段階を 名前の 下に（物↑2 速↓1 など）
const BUF_AB = { atk: "物", def: "硬", mat: "魔", mdf: "護", spd: "速", wpn: "武", brt: "息", eva: "避", acc: "命" };
const bufTag = (f) => { const l = Object.entries(f.buf || {}).filter(([k, v]) => v && BUF_AB[k]).map(([k, v]) => `${v > 0 ? "§a" : "§c"}${BUF_AB[k]}${v > 0 ? "↑" : "↓"}${Math.abs(v)}`); return l.length ? "\n" + l.join(" ") : ""; };
const tagOf = (f) => f.hp <= 0 ? `§8× ${f.name}` : bufTag(f) === "" ? tagOf0(f) : tagOf0(f) + bufTag(f);
const tagOf0 = (f) => f.side === "a"
  ? `§b▼ 味方 §f${f.name} §7Lv${f.lv} ${rankOf(f.m.sp)}\n${meter(f.hp, f.mx.hp, 10, "§a", "§8")} §f${f.hp}`
  : `§c▼ 敵 §f${f.name} §7Lv${f.lv} ${rankOf(f.m.sp)}${f.isBoss ? " §4【ボス】" : ""}\n${meter(f.hp, f.mx.hp, 10, "§c", "§8")}`;
let markTick = 0;
// v2.5.6: 戦闘中は まわりの プレイヤーと NPCを 透明に（じゃまに ならないように）
function hideAround(B) {
  const c = B.center; if (!c || !B.dim) return;
  B.hidden = B.hidden || new Set();
  try {
    for (const e of B.dim.getEntities({ location: c, maxDistance: 30 })) {
      if (!(e.typeId === "minecraft:player" || e.typeId === "mrpg:npc")) continue;
      if (e.typeId === "mrpg:npc" && e.hasTag("mrpg_saga")) continue;   // v2.9.13: ほかの 人の 物語の 人物は 消さない
      if (e.typeId === "minecraft:player" && !B.players.some((x) => x.p.id === e.id) && (busy.has(e.id) || [...battles.values()].some((o) => o !== B && !o.ended && o.players.some((x) => x.p.id === e.id)))) continue;
      if (!B.hiddenIds?.has(e.id) && e.getEffect?.("invisibility")) continue;   // もともと 透明なら さわらない（あとで 外さない）
      try { e.addEffect("invisibility", 60, { amplifier: 0, showParticles: false }); B.hidden.add(e); (B.hiddenIds = B.hiddenIds || new Set()).add(e.id); } catch {}
    }
  } catch {}
}
function unhide(B) { for (const e of B.hidden || []) if (ok(e)) try { e.removeEffect("invisibility"); } catch {} }
system.runInterval(() => { for (const B of battles.values()) if (!B.ended) hideAround(B); }, 20);
system.runInterval(() => {
  markTick++;
  for (const B of battles.values()) {
    if (B.ended) continue;
    if (isLite() && markTick % 3) continue;   // 軽量モードでは 回数を 1/3に
    for (const f of [...B.allies, ...B.enemies]) {
      if (!ok(f.ent)) continue;
      try { f.ent.nameTag = tagOf(f); } catch {}
      if (f.hp > 0) vfx(f.ent, "circle", 0.05, f.side === "a" ? [0.25, 0.6, 1] : [1, 0.25, 0.25], ({ S: 0.7, M: 0.9, L: 2.6, G: 3.6 })[sizeOf(f.m)] || 1);
    }
  }
}, 24);
export function battleOf(e) {
  const bid = e.getDynamicProperty("mrpg:bid");
  return typeof bid === "number" ? battles.get(bid) : null;
}
export const HIT_HOOKS = [];   /* 第76版: (p, e) => true なら そちらで 戦いを 始める */
export async function onHitMonster(p, e) {
  if (!ok(e) || e.hasTag("mrpg_pet")) return;
  for (const h of HIT_HOOKS) { try { if (h(p, e)) return; } catch {} }
  try { const h = e.getComponent("minecraft:health"); if (h) h.resetToMaxValue(); } catch {}   // v2.9.12: なぐった ダメージを のこさない（ボスが 消えない ように）
  if (e.hasTag("mrpg_battle")) { const B = battleOf(e); if (B) joinBattle(p, B); return; }
  await startBattle(p, e);
}
function addPlayer(B, p, d) {
  if (B.domeB) DOMEB.set(p.id, B.domeB);
  const pl0 = B.players.length === 0 && B.pPos ? B.pPos : p.location;
  const P = B.floorY !== undefined ? { ...pl0, y: B.floorY } : pl0, E = B.center;
  let dx = E.x - P.x, dz = E.z - P.z;
  const len = Math.hypot(dx, dz) || 1; dx /= len; dz /= len;
  const perp = { x: -dz, z: dx };
  const chp = B.master && B.master.ch ? CH_PARTY.get(p.id) : null;
  const pet = d.out && !chp ? findPet(p) : null;
  const fs = (chp || d.party).filter((m) => !chp || m.hp > 0).map((m) => { const f = fighter(m, "a"); f.owner = p.id; return f; });
  for (const f of fs) { f.moves = ruleMoves(B, f.moves); if (B.master && B.master.rules && B.master.rules.nomagic) f.noMagic = true; }
  // 仲間は プレイヤーの 左右に ならべて、敵への 見とおしを あける
  const W = { S: 1.5, M: 2.0, L: 4.8, G: 6.8 };
  let accR = 1.0, accL = 1.0;
  const pos = fs.map((f, i) => {
    const w = W[sizeOf(f.m)] || 2;
    const right = i % 2 === 0;
    const o = (right ? accR : accL) + w / 2;
    if (right) accR += w; else accL += w;
    const sgn = right ? 1 : -1;
    return { x: P.x + dx * 1.2 + perp.x * o * sgn, y: P.y, z: P.z + dz * 1.2 + perp.z * o * sgn };
  });
  fs.forEach((f, i) => summonFighter(p, f, pos[i], E, B.temps, pet && f.m.id === d.out ? pet : null, B.bid));
  B.allies.push(...fs);
  B.players.push({ p, pid: p.id, d, pet, joinTurn: B.turn || 1 });
  busy.add(p.id);
  p.addEffect("resistance", 20 * 3600, { amplifier: 255, showParticles: false });
  p.addEffect("fire_resistance", 20 * 3600, { amplifier: 0, showParticles: false });
  if (B.sea) seaFx(p, true);
  if (!(B.master && B.master.dream)) for (const f of B.enemies) mark(d.seen, f.m.sp);   /* 第69版: 悪夢の 相手は 図鑑に のせない */
}
// 第68版: 裏（スタンバイ）。場に 出せる 子 = 表と 裏の 中で 元気で、いま 場に いない 子
const BENCH_FIELD = 4;
function fieldSlots(B, pid) { return B.allies.filter((f) => f.owner === pid && !f.out && f.m && !f.guest).reduce((s, f) => s + slotOf(f.m), 0); }
function benchCands(B, x) {
  try {
    if (!x || !x.d || B.pvp || B.spar || (B.master && (B.master.ch || B.master.rules || B.master.scripted || B.master.dream || B.master.ghost))) return [];   /* やりこみ戦・縛り・台本の 戦いでは 裏は 出ない */
    const onField = new Set(B.allies.filter((f) => f.m && !f.out).map((f) => f.m));
    return [...(x.d.party || []), ...(x.d.bench || [])].filter((m) => m && SPECIES[m.sp] && (m.hp ?? 1) > 0 && !onField.has(m) && !(B.deadM && B.deadM.has(m)) && !(B.master && B.master.enma && m.sp === "musashi"));
  } catch { return []; }
}
// v1.7: 控え（裏の パーティ）を バトルに 出す
function benchIn(B, x, outF, m, log, auto) {
  const { p, d } = x;
  const f = fighter(m, "a"); f.owner = p.id;
  try { f.moves = ruleMoves(B, f.moves); if (B.master && B.master.rules && B.master.rules.nomagic) f.noMagic = true; } catch {}
  if (!auto) f.swapT = B.turn || 1;   // 第68版: 入れかわった 子は この ターン 動けない（自動で 出た 子は 次の ターンから 動ける）
  if (B.revM && B.revM.has(m)) f.revN = B.revM.get(m);
  x.benchUsed = x.benchUsed || new Set(); x.benchUsed.add(m.id);
  if (outF && outF.hp <= 0) { B.deadM = B.deadM || new Set(); B.deadM.add(outF.m); }   // 倒れた 子は この 戦いでは もう 出せない
  let pos = outF && outF.home ? { ...outF.home } : outF && ok(outF.ent) ? { ...outF.ent.location } : { ...p.location };
  if (outF) {
    outF.m.hp = hpBack(outF); outF.m.mp = Math.min(outF.mp, calcStats(outF.m).mp);   /* 第69版 */
    outF.out = true;
    if (ok(outF.ent)) {
      if (outF.ent === x.pet) { standUp(x.pet); try { x.pet.teleport({ x: p.location.x - 1.5, y: p.location.y, z: p.location.z - 1.5 }); } catch {} }
      else { particle(outF.ent, "minecraft:white_smoke_particle"); try { outF.ent.remove(); } catch {} }
    }
    const i = B.allies.indexOf(outF); if (i >= 0) B.allies.splice(i, 1);
  }
  summonFighter(p, f, pos, (outF && outF.face) || B.center || p.location, B.temps, null, B.bid);
  B.allies.push(f); try { fighterStart(B, f, log); } catch {}
  vfx(f.ent, "pillar", 0, [0.4, 0.8, 1], 1);
  log.push(auto ? `§b裏から ${f.name}が 飛び出した！` : `§b${outF ? outF.name + "を ひっこめて " : ""}${f.name}を くりだした！ §7（この ターンは 動けない）`);
  return f;
}
// 第68版: 表が 全員 倒れたら 裏の 子が 自動で 出る（枠 4まで）
function benchAuto(B, log) {
  for (const x of B.players || []) {
    try {
      if (!ok(x.p) || !x.d) continue;
      const own = B.allies.filter((f) => f.owner === x.p.id && !f.out && f.m && !f.guest);
      if (!own.length || own.some((f) => f.hp > 0)) continue;
      let cands = benchCands(B, x);
      for (const outF of own) {
        const room = BENCH_FIELD - fieldSlots(B, x.p.id) + slotOf(outF.m);
        const m = cands.find((c) => slotOf(c) <= room); if (!m) continue;
        benchIn(B, x, outF, m, log, true); cands = cands.filter((c) => c !== m);
      }
      // 枠が 空いて いれば もっと 出す
      for (const m of cands) { if (slotOf(m) <= BENCH_FIELD - fieldSlots(B, x.p.id)) benchIn(B, x, null, m, log, true); }
    } catch (e) { console.warn(`[MonsterRPG] benchAuto: ${e}`); }
  }
}
// v3.0: 戦いの 場に 入りこんだ 関係ない モンスター: 野生は 消す・だれかの 連れ歩きは 場の 外へ 動かす
const SHOO_SKIP = ["mrpg_battle", "mrpg_boss", "mrpg_npc", "mrpg_raid", "mrpg_slab", "mrpg_masterteam", "mrpg_temp", "mrpg_preview", "mrpg_dg", "mrpg_tmap", "mrpg_musashi", "mrpg_master", "mrpg_navi", "mrpg_giant", "mrpg_lost", "mrpg_bounty"];
const SLAB_ORDER = [0, 2, 4, 6, 8, 10, 12, 13];
export function expCapLv(d) { const s = (d && d.story) || {}; if (s.ending || s.enmaClear) return 999; const bs = s.bs || []; const nx = SLAB_ORDER.find((i) => !bs.includes(i)); return nx === undefined ? 999 : slabBossLv(nx) + 2; }
function shoo(B) {
  if (!B || !B.center || !B.dim || B.pvp) return;
  const r = B.shooR || 12;
  let L = []; try { L = B.dim.getEntities({ type: TYPE, location: B.center, maxDistance: r }); } catch { return; }
  const mine = new Set([...B.allies, ...B.enemies].map((f) => { try { return f.ent && f.ent.id; } catch { return null; } }).filter(Boolean));
  for (const e of L) {
    try {
      if (!ok(e) || mine.has(e.id) || SHOO_SKIP.some((t) => e.hasTag(t))) continue;
      { const ob = e.getDynamicProperty("mrpg:bid"); if (typeof ob === "number" && battles.has(ob)) continue; }   // ほかの 戦いで 戦って いる 連れ歩きは さわらない
      if (e.hasTag("mrpg_pet") || e.hasTag("mrpg_rare") || e.hasTag("mrpg_shiny")) { const l = e.location, dx = l.x - B.center.x, dz = l.z - B.center.z, dd = Math.max(0.5, Math.hypot(dx, dz)); e.teleport({ x: B.center.x + (dx / dd) * (r + 6), y: l.y + 1, z: B.center.z + (dz / dd) * (r + 6) }); }
      else e.remove();
    } catch {}
  }
}
// v3.0: 野生の ハガネ族の HP（ハガネ族の 中の ランクで 2〜8）
const METAL_RK = (() => { const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"]; const ids = Object.keys(SPECIES).filter((k) => SPECIES[k].metalmon).map((k) => RK.indexOf(SPECIES[k].rank)); return [Math.min(...ids), Math.max(...ids)]; })();
export function metalWildHp(sid) { const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"]; const r = RK.indexOf(SPECIES[sid]?.rank); const [lo, hi] = METAL_RK; return hi > lo ? Math.round(2 + 6 * (r - lo) / (hi - lo)) : 2; }
// v3.0: テストから 途中参加と 留守の 結果を 呼べる 入口（ゲームの 中では 使わない）
export const TEST_HOOKS = { joinBattle: (p, B) => joinBattle(p, B), battles: () => [...battles.values()], away: () => AWAY };
const JOIN_HINT = new Map();
// v3.0 第63版: マルチプレイの「共闘する」（どこからでも。終われば もとの 場所へ）
const COOP_WAIT = new Set();
export function coopList(p) { return [...battles.values()].filter((B) => !B.ended && !B.result && !B.pvp && !B.dg && !(B.master && B.master.arena) && B.players.length && !B.players.some((x) => x.p.id === p.id) && B.players.every((x) => ok(x.p))); }
export function coopJoin(p, B) {
  if (!B || B.ended) return "§7その 戦いは もう 終わった。";
  if ([...battles.values()].some((o) => !o.ended && o.players.some((x) => x.p.id === p.id))) return "§7いまは ほかの 戦いの 最中です。";
  try { if (typeof p.getDynamicProperty("mrpg:dg") === "string") return "§7石板の 中からは 共闘できない。§8（ガイドブックで 脱出してから）"; } catch {}   // 第69版: 石板の 進み具合を 消さない
  const d = load(p); if (!canFight(d)) return "§c戦える 仲間が いない！";
  const P = B.pPos || B.center; if (!P) return "§7その 戦いには 入れない。";
  skyMark(B, p, { x: p.location.x, y: p.location.y, z: p.location.z });
  const y = B.skyY !== undefined ? B.skyY : P.y;
  try { p.addEffect("slow_falling", 100, { showParticles: false }); p.addEffect("resistance", 100, { amplifier: 4, showParticles: false }); p.teleport({ x: P.x + 1.5, y: y + 0.2, z: P.z + 1.5 }, { dimension: B.dim, facingLocation: B.center }); } catch {}
  COOP_WAIT.add(p.id);
  system.runTimeout(() => { COOP_WAIT.delete(p.id); if (!ok(p)) { busy.delete(p.id); return; }   /* 第69版: 移動中に 抜けた */ if (B.ended) { skyBack(p, B, null); return; } busy.delete(p.id); joinBattle(p, B, true); if (!B.joinQueue.includes(p) && !B.players.some((x) => x.p.id === p.id)) skyBack(p, B, null); }, 10);
  return null;
}
function joinBattle(p, B, coop = false) {
  if ((!coop && COOP_WAIT.has(p.id)) || B.joinQueue.some((q) => q.id === p.id)) return;   // 第63版: 共闘の 移動中・2回 さんせんを ふせぐ
  if (busy.has(p.id) && !B.players.some((x) => x.p.id === p.id) && !B.ended && !inBattle(p)) { const t = system.currentTick; if ((JOIN_HINT.get(p.id) || -999) < t - 100) { JOIN_HINT.set(p.id, t); try { p.sendMessage("§7画面を 閉じてから 殴ると 協力バトルに 入れます。"); } catch {} } return; }   // v3.0 第63版
  if (busy.has(p.id) || B.players.some((x) => x.p.id === p.id) || B.ended) return;
  if ([...battles.values()].some((o) => o !== B && !o.ended && (o.players.some((x) => x.p.id === p.id) || o.joinQueue.some((q) => q.id === p.id)))) return;   // ほかの 戦いの 最中（待ちも）は 入れない
  // v2.5: 物語の 戦い（闘技場・城・石板・エンマ など）と 石板の 中は その人だけの もの
  if ((B.master && B.master.arena) || B.dg) { p.sendMessage(`§7これは ${B.players[0]?.p.name || "ほかの 人"}の ${B.master && B.master.mimic ? "ハコダマシとの" : "物語の"} 戦いだ。手出しは できない。`); return; }
  // v2.9.12: 遠くからは 入れない（同じ 世界で 32ブロック いない）
  try { if (!coop && (p.dimension.id !== (B.dim && B.dim.id) || Math.hypot(p.location.x - B.center.x, p.location.z - B.center.z) > 32)) { p.sendMessage("§7もっと 近くに 来ないと 協力できない。§8（ガイドブック ＞ マルチプレイ ＞「共闘する」なら どこからでも）"); return; } } catch { return; }
  const d = load(p);
  if (promoteBench(d)) save(p, d);   /* 第69版 */
  if (!d || !d.party.some((m) => m.hp > 0)) { p.sendMessage("§c戦える 仲間が いない！"); return; }
  B.joinQueue.push(p);
  busy.add(p.id);
  // v2.9.12: 1分 たっても 入れなければ ぬける（待たされっぱなしに しない）
  system.runTimeout(() => { if (B.ended) return; const i = B.joinQueue.indexOf(p); if (i >= 0) { B.joinQueue.splice(i, 1); busy.delete(p.id); skyBack(p, B, null); try { p.sendMessage("§7協力バトルに 入れなかった（相手が 動かない）。"); } catch {} } }, 1200);
  for (const x of B.players) x.p.sendMessage(`§b${p.name}が 協力バトルに さんせんする！`);
  p.sendMessage("§b協力バトルに さんせん！ 次の ターンから 戦えます（その前に 戦いが 終わると ほうびは なし）。");
}

async function startBattle0(p, wild) {
  // v2.5.6: はじめられなかった 理由を かえす（石板の エンカウントで やりなおせるように）
  if (busy.has(p.id) || COOP_WAIT.has(p.id)) return "_busy";
  if ([...battles.values()].some((B) => !B.ended && B.players.some((x) => x.p.id === p.id))) return "_busy";   // v2.9.13: 2つの 戦いに 同時に 入らない
  if (!ok(wild)) return "_invalid";
  if (wild.hasTag("mrpg_pet") || wild.hasTag("mrpg_battle")) return "_taken";
  // v2.9.13: もう 越えた 遺跡の ボスには 自分からは 挑めない（まだの 人が 挑んで、そこに 加わる のは よい）
  try { if (wild.hasTag("mrpg_boss") && !wild.hasTag("mrpg_raid")) { const key = wild.getDynamicProperty("mrpg:site"); const r = key ? getRuin(key) : null; if (r && r.cleared && (r.by || []).includes(p.id)) { p.sendMessage("§7この 遺跡は もう 越えている。§fまだ 越えて いない 仲間が 挑めば、その 戦いに 加われる。"); return "_cleared"; } } } catch {}
  const d = load(p);
  if (!d) { p.sendMessage("§eガイドブックを 使って 最初の 仲間を えらぼう！"); return "_nodata"; }
  if (promoteBench(d)) { save(p, d); p.sendMessage("§b表が 全員 倒れて いたので 裏と 入れかえた。"); }   /* 第69版 */
  if (!d.party.some((m) => m.hp > 0)) { p.sendMessage("§c戦える 仲間が いない！ 宿屋で 回復 しよう。"); return "_noparty"; }
  const boss = wild.hasTag("mrpg_boss"), raid = wild.hasTag("mrpg_raid");
  const slabT = wild.getDynamicProperty("mrpg:slab");
  const slab = boss && typeof slabT === "number" ? slabT : null;
  const nushiT = wild.getDynamicProperty("mrpg:nushi"), nushi = boss && typeof nushiT === "number" ? nushiT : null;
  let master = null, team = null;
  if (wild.hasTag("mrpg_masterteam")) { try { master = JSON.parse(wild.getDynamicProperty("mrpg:mref")); team = JSON.parse(wild.getDynamicProperty("mrpg:team")); } catch { master = null; } }
  const nameTag0 = wild.nameTag;
  const bid = nextBid++;
  const B = { bid, allies: [], enemies: [], players: [], temps: [], joinQueue: [], boss, raid, slab, master, center: { ...wild.location }, dim: p.dimension };
  B.cheat = d.cheat && (d.cheat.inv || d.cheat.hit) && isHost(p) && !(master && (master.ch || master.ghost)) ? { inv: !!d.cheat.inv, hit: !!d.cheat.hit } : null; B.cheatPid = p.id;   /* 大会・ランク・ゴーストでは 効かない */   /* 第76版: チートブック */
  if (B.cheat) p.sendMessage(`§dチートブック: ${B.cheat.inv ? "味方 無敵 " : ""}${B.cheat.hit ? "一撃 9999999" : ""}`);
  B.dgElite = wild.hasTag("mrpg_dg") && wild.hasTag("mrpg_rare");
  B.nushi = nushi; B.tmap = wild.hasTag("mrpg_tmap"); try { B.tmapOwner = wild.getDynamicProperty("mrpg:towner"); } catch {} B.phantom = wild.hasTag("mrpg_phantom"); B.voidIsle = wild.hasTag("mrpg_void"); B.bounty = wild.hasTag("mrpg_bounty"); try { B.envr = wild.getDynamicProperty("mrpg:envr"); B.bri = wild.getDynamicProperty("mrpg:bri"); } catch {}   /* 第101版: 賞金首・環境の レア */
  B.sea = isSea(p.dimension, wild.location) || isSea(p.dimension, p.location);
  battles.set(bid, B); HUD.add(B);
  busy.add(p.id);
  try {
    try { const r = p.getComponent("minecraft:riding")?.entityRidingOn; if (r) r.getComponent("minecraft:rideable")?.ejectRider(p); } catch {}
    let { sid, lv, q, shiny } = wildInfo(wild);
    // v2.2.2: 遺跡の ボスは 物語の 進みに あわせて 強くなる
    const siteKey = boss && !raid && slab === null ? wild.getDynamicProperty("mrpg:site") : null;
    if (siteKey) { const lv2 = ruinLv(d, lv); if (lv2 !== lv) { lv = lv2; try { wild.setDynamicProperty("mrpg:lv", lv); } catch {} } }
    // v2.2.2: 石板の 中（ダンジョン）では 専用の 戦いの 間で 戦う
    let dg = null; try { const v = p.getDynamicProperty("mrpg:dg"); dg = typeof v === "string" ? JSON.parse(v) : null; } catch {}
    wild.addTag("mrpg_battle");
    wild.triggerEvent("mrpg:make_battle");
    wild.setDynamicProperty("mrpg:bid", bid);
    // 海の バトル: 気泡の ドームを 作る（床は たいら。終わったら もとに 戻す）
    if (B.sea) await buildDome(B, p, wild, d);
    // v1.7: 味方と 敵を はっきり はなす（約10ブロック）＋ フィールドごとの 背景・マスター戦は 闘技場
    const inSky = typeof p.getDynamicProperty("mrpg:ret") === "string";
    if (dg && !B.sea) {
      const A = { x: dg.bx + 0.5, y: dg.by, z: dg.bz - dg.bd + 0.5 }, E0 = { x: dg.bx + 0.5, y: dg.by, z: dg.bz + dg.bd + 0.5 };
      B.dgRet = { x: p.location.x, y: p.location.y, z: p.location.z }; B.wildRet = { x: wild.location.x, y: wild.location.y, z: wild.location.z }; B.dg = true;
      try { p.teleport(A, { facingLocation: { x: E0.x, y: E0.y + 1, z: E0.z } }); } catch {}
      // v2.6: 戦いの 間が 読みこまれるまで 待つ（遠い 部屋だと 敵が とどかず 映らない ことが あった）
      await waitLoaded(p.dimension, [A, E0], 40);
      try { wild.teleport(E0, { facingLocation: A }); } catch {}
      B.center = E0; B.pPos = A;
    } else if (!B.sea && !inSky) {
      const P0 = p.location, W0 = wild.location;
      let ux = W0.x - P0.x, uz = W0.z - P0.z; const l0 = Math.hypot(ux, uz) || 1; ux /= l0; uz /= l0;
      const bigE = ["L", "G"].includes(SPECIES[sid]?.sz) ? 3 : 0, bigA = d.party.some((m) => ["L", "G"].includes(sizeOf(m))) ? 2 : 0;
      const D = 9 + (bigE ? 1.5 : 0) + (bigA ? 1 : 0);   // v2.2: 巨大でも はなれすぎない
      let fy = Math.floor(P0.y);
      // v2.9.2: ライド中・飛行中に はじまったら 地面の 高さに（ドームが 宙に できない ように）
      try { const gy = groundY(p.dimension, P0.x, P0.z, Math.floor(P0.y)); if (typeof gy === "number" && gy < fy) fy = gy; } catch {}
      // v1.7: 軽量モード・重いときは ステージを 作らない（処理速度 優先）
      const wantStage = p.getDynamicProperty("mrpg:nostage") !== true;   // v2.6: 町の 中でも 背景を 作る（終われば もとに 戻る）
      // v3.0 第63版: 戦いは 下から 見えない 上空で（いまの 場所の 背景で）。地面を こわさない・終われば もとの 場所へ
      let sky = false; const gfy = fy;
      if (wantStage && p.dimension.id !== "minecraft:nether") { let hi = 319; try { hi = p.dimension.heightRange.max - 1; } catch {} const sy = Math.min(hi - 28, 290); if (sy > fy + 60) { fy = sy; sky = true; } }
      if (wantStage) {
        // v2.5.10: ボスは ボス固有の フィールド（銅=遺跡・銀=神殿・金=火山・虹=天空・レイド=魔界・遺跡の ボス=遺跡）
        const theme = master ? (master.theme || "arena") : slab !== null ? ["ruins", "shrine", "volcano", "sky"][Math.max(0, Math.min(3, slab))] : raid ? "hell" : boss && nushi === null ? "ruins" : themeOf(biomeAt(p.dimension, P0), p.dimension.id, (() => { try { return WR_[rIdxAt_(P0)]?.id; } catch { return null; } })());
        const C = { x: P0.x + ux * D / 2, z: P0.z + uz * D / 2 };
        B.theme = theme;
        // v2.9.2: ほかの 戦いの ステージと 重なる ときは ドームを 作らない（もとに もどらない ブロックが 残るため）
        // v2.9.12: 保存する 四角どうしで 重なりを しらべる（作りはじめる 前に 予約して 同時に 始まっても 重ならない）
        const R0 = Math.ceil(D / 2 + 6), dimId = p.dimension.id, cxI = Math.floor(C.x), czI = Math.floor(C.z);
        const boxOf = (o) => ({ dim: dimId, x1: cxI - o, x2: cxI + o, z1: czI - o, z2: czI + o });
        const others = [...battles.values()].filter((o) => o !== B && !o.ended).flatMap((o) => [o.resv, o.dome && { dim: o.dome.dim.id, x1: o.dome.x1, x2: o.dome.x2, z1: o.dome.z1, z2: o.dome.z2 }]).filter(Boolean);
        const bD = boxOf(R0 + (isLite() ? 7 : 10) + 1), bN = boxOf(R0 + (!!master && !master.theme ? 6 : 3));
        const clash = !boxFree(bD, others), clash2 = !boxFree(bN, others);
        B.resv = !clash ? bD : !clash2 ? bN : null;
        if (!clash2) { try { B.stage = await buildStage(p.dimension, C.x, fy, C.z, R0, theme, { lite: isLite(), stands: !!master && !master.theme, dome: !clash }); } catch {} }
        if (sky && !B.stage) { sky = false; fy = gfy; if (!clash2) { try { B.stage = await buildStage(p.dimension, C.x, fy, C.z, R0, theme, { lite: isLite(), stands: !!master && !master.theme, dome: !clash }); } catch {} } }   // 上空に 作れない ときは 地面で
        if (sky) { B.skyY = fy; B.wildRet = { x: W0.x, y: W0.y, z: W0.z }; skyMark(B, p, { x: P0.x, y: P0.y, z: P0.z }); try { p.addEffect("slow_falling", 60, { showParticles: false }); } catch {} }
        if (B.stage && B.stage.dome) { B.domeB = { bid, cx: B.stage.cx + 0.5, cz: B.stage.cz + 0.5, fy: fy, r: B.stage.dome.r, top: B.stage.dome.top }; DOMEB.set(p.id, B.domeB); }
        try { p.teleport({ x: P0.x, y: fy, z: P0.z }, { facingLocation: { x: P0.x + ux * D, y: fy + 1, z: P0.z + uz * D } }); } catch {}
        B.pPos = { x: P0.x, y: fy, z: P0.z };
        B.shooR = R0 + 4;
      }
      try { wild.teleport({ x: P0.x + ux * D, y: wantStage ? fy : W0.y, z: P0.z + uz * D }, { facingLocation: P0 }); } catch {}
      B.center = { x: P0.x + ux * D, y: wantStage ? fy : W0.y, z: P0.z + uz * D };
    }
    const pl0 = B.pPos || p.location;   // v2.6: テレポート直後の p.location は 古い ことが あるので 自分で 覚えた 位置を 使う
    const P = B.floorY !== undefined ? { ...pl0, y: B.floorY } : pl0, E = B.floorY !== undefined ? { ...wild.location, y: B.floorY } : B.center || wild.location;
    let dx = E.x - P.x, dz = E.z - P.z;
    const len = Math.hypot(dx, dz) || 1; dx /= len; dz /= len;
    const perp = { x: -dz, z: dx };
    const biome = biomeAt(p.dimension, P);
    let count = 1 + (Math.random() < 0.45 ? 1 : 0) + (Math.random() < 0.2 ? 1 : 0);
    // v2.2.3: 石板の 中の エンカウントは その 世界の 仲間と いっしょに 出る
    let wpool = null; try { const v = wild.getDynamicProperty("mrpg:pool"); if (typeof v === "string") wpool = JSON.parse(v); } catch {}
    if (boss) count = raid || slab !== null || nushi !== null || B.tmap || B.bounty ? 1 : 3;   // v2.5.10: 銅〜虹の 石板ボスは お供なし（v2.6: 地方の 主・宝の 番人も）
    // 状況に よって 厳選済みの 個体が 出る（遠いほど・ボスほど・マスターほど）
    const bq = boss ? (slab !== null ? q : raid ? 0.8 : 0.6) : q;
    const htc = master ? 0.1 : slab !== null ? 0.35 : boss ? 0.25 : wild.hasTag("mrpg_rare") ? 0.15 : 0.03;
    const ruw = wild.hasTag("mrpg_ruinw"); B.ruins = ruw;   /* 第76版: 滅びた 世界の 野生（才能 全開・かくれ特性・強化 +60） */
    const mk = (s2, l2, q2, sh, pl) => { const m = giveHidden(tuneMonster(makeMonster(s2, l2, true), q2), sh || ruw ? 1 : htc); if (ruw) { m.tal = Object.fromEntries(STATS.map((k) => [k, TAL_MAX])); m.plus = Math.max(m.plus || 0, 60); const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } if (pl) { m.plus = pl; const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } if (sh) { m.shiny = true; m.plus = (m.plus || 0) + 5; const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } return m; };
    const ghostM = (t) => { const m = JSON.parse(JSON.stringify(t.m)); if (t.lv) m.lv = t.lv; m.eq = m.eq || { w: null, a: null, x: null }; const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; return m; };
    const main = fighter(team && team[0].m ? ghostM(team[0]) : mk(team ? team[0].sid : sid, team ? team[0].lv : lv, team ? team[0].q : bq, shiny, team ? team[0].plus : 0), "e");
    if (master && master.dream) { main.m.nm = "？？？"; main.name = "？？？"; }   /* 第69版: 悪夢の 相手の 名前を かくす */
    // 石板ボス・星冠王は 専用技を 使う
    if (slab !== null) { const pool = SLAB_MOVES.slice(); for (let i = 0; i < 2 + (slab >= 2 ? 1 : 0); i++) main.moves.push(pool.splice(ri(0, pool.length - 1), 1)[0]); }
    if (master && master.final) { main.moves.push("fb_crown", "fb_genesis", "fb_zero"); main.mx.hp = Math.min(9999, main.mx.hp * 2); main.hp = main.mx.hp; main.mx.mp = main.mp = main.mx.mp * 2; main.isBoss = true; main.name = `【星冠王】${main.name}`; }
    // v2.2.2: 石板の 主・終の遺跡の 墓守・遺跡の ボス（物語の 進みで 強く）
    if (master && master.bslab !== undefined) { const k = (master.bslab <= 8 ? 2.4 : 2.0) + master.bslab * 0.05;   if (master.bslab <= 6) for (const st of ["atk", "wpn", "mat", "brt"]) main.mx[st] = Math.min(main.mx[st], Math.floor(main.mx.hp * 0.6));   /* v3.0: 序盤の 主は 一撃で 倒しきらない */   /* v3.0: HPは あとで ヴァルグレイドを 基準に きめる */ void k; main.mx.mp = main.mp = main.mx.mp * 3; main.tr.extra = Math.max(main.tr.extra || 0, 0.35 + master.bslab * 0.015);   /* 第63版: 強化 */ main.isBoss = true; main.name = `【石板の主】${main.name}`; }
    if (master && master.ruinFinal) { main.mx.hp = Math.min(9999, Math.floor(main.mx.hp * 2.8)); main.hp = main.mx.hp; main.mx.mp = main.mp = main.mx.mp * 3; main.tr.extra = Math.max(main.tr.extra || 0, 0.5); main.isBoss = true; main.name = `【墓守】${main.name}`; }
    // v2.2: 裏ボス エンマ（閻魔の祭壇）
    // v2.4.2: 王系・神系なしの Lv100 パーティでも 倒せるように 調整（シミュレーションで 確認）。HPは 高く、1撃は 抑えめ・すばやさ 控えめ・追加行動なし
    if (master && master.enma) {   // v3.0: 真の 裏ボス エンマ（勝つたびに 能力 +500・HP +1000、技も 増えて かしこく なる）
      const n = Math.max(0, master.enmaN || 0), up = 500 * n;
      Object.assign(main.mx, { hp: 20000 + 1000 * n, mp: 99999, atk: 5000 + up, wpn: 5000 + up, def: 5000 + up, mat: 5000 + up, mdf: 5000 + up, brt: 5000 + up, spd: 5000 + up });
      main.m.noSx = true; try { main.tr = C_traitFx(main.m.sp, main.m); } catch {}   /* ボスの エンマは 指定の 特性 5つ */
      main.hp = main.mx.hp; main.mp = main.mx.mp; main.php = main.mx.hp; main.infMP = true; main.tr.nocap = false; main.isBoss = true; main.enmaN = n;   // 1撃は 999 まで（国崩だけ 例外）
      // ボスの 特性（強い もの 5つ）: 3〜4回行動・先手・魔神の闘気・超再生・会心無効
      Object.assign(main.tr, { acts: [3, 4], first: true, majinAura: 0.15, regen: Math.max(main.tr.regen || 0, 0.01), critguard: true });
      main.bossTraits = ["3〜4回行動", "先手", "魔神の闘気", "超再生", "会心無効"];
      main.actCap = 1800; main.outCap = 1500; main.outPct = 0.28;   // v3.0: 1回の 行動で 1体に 与える ダメージは 相手の 最大HPの 28%（最大1500）まで   // 魔神の 守り: 1回の 行動で 受ける ダメージは 1800 まで（連続技で 一気に 削られない）
      main.aiTac = ["attack", "varied", "support", "buffer", "status", "normal"][Math.floor(Math.random() * 6)];   // 戦う たびに 戦い方が ちがう
      main.moves = [...new Set([...main.moves, ...enmaKit(n)])].filter((id) => MOVES[id] && !MOVES[id].hpcost && !MOVES[id].recoil && !MOVES[id].selfko && MOVES[id].kind !== "reckless" && !(MOVES[id].heal && MOVES[id].kind !== "drain") && !MOVES[id].revive && !MOVES[id].allmp);   // 回復技は もたない（倒せる ように）
    }
    // v2.6: やりこみの 強敵（塔の 番人・週替わり・地方の 主 など）
    if (master && master.hpk) { main.mx.hp = Math.min(9999, Math.floor(main.mx.hp * master.hpk)); main.hp = main.mx.hp; main.mx.mp = main.mp = main.mx.mp * 3; main.tr.extra = Math.max(main.tr.extra || 0, master.extra || 0.3); main.isBoss = true; if (master.tag) main.name = `【${master.tag}】${main.name}`; }
    if (nushi !== null) { main.mx.hp = Math.min(9999, Math.floor(main.mx.hp * 2)); main.hp = main.mx.hp; main.name = main.name.replace("【ボス】", "【主】"); }
    if (boss) {
      const k = raid ? 6 : 3;
      main.mx.hp = Math.min(9999, main.mx.hp * k); main.hp = main.mx.hp;
      for (const s of ["atk", "def", "mat", "mdf", "wpn", "brt", "spd"]) main.mx[s] = Math.floor(main.mx[s] * 1.15);
      main.mx.mp = main.mp = main.mx.mp * 3;
      main.tr.extra = Math.max(main.tr.extra || 0, 0.5);
      main.isBoss = true;
      main.name = `【ボス】${main.name}`;
    }
    if (B.bounty) main.name = main.name.replace("【ボス】", "【賞金首】");   /* 第101版 */
    if (nushi !== null) main.name = main.name.replace("【ボス】", "【主】");   /* 第101版: 前は 【ボス】の 前に 置きかえて いて 効いて いなかった */
    if (master && (master.re || master.kingK) && team && team[0].sz) main.m.sz = team[0].sz;   // 第65版: 再戦の 石板の 主は Gサイズ
    B.enemies.push(main);
    if (team) for (const t of team.slice(1)) { const u = B.enemies.reduce((x, e) => x + slotOf(e.m), 0); if (u + ({ S: 1, M: 2, L: 3, G: 4 }[t.m ? sizeOf(t.m) : t.sz || SPECIES[t.sid]?.sz] || 2) > 4) continue; const mm = t.m ? ghostM(t) : mk(t.sid, t.lv, t.q, false, t.plus); if (t.sz && !t.m) mm.sz = t.sz; B.enemies.push(fighter(mm, "e")); }
    else for (let i = 1; i < count; i++) {
      const s2 = wpool ? (wpool.length ? wpool[Math.floor(Math.random() * wpool.length)] : null) : Math.random() < 0.5 && !boss && !SPECIES[sid]?.metalmon ? sid : pickWild(biome, lv);   // v3.0 第63版: ハガネ族の お供は 同じ 種類に しない
      if (!s2) break;
      const used = B.enemies.reduce((a, e) => a + slotOf(e.m), 0);
      if (!boss && used + ({ S: 1, M: 2, L: 3, G: 4 }[SPECIES[s2]?.sz] || 2) > 4) continue;   // v2.1: 敵も 4枠まで
      B.enemies.push(fighter(mk(s2, Math.max(1, lv + ri(boss ? -4 : -1, boss ? -2 : 1)), boss ? Math.max(0.3, bq - 0.3) : q * 0.6), "e"));
    }
    // v2.5.1: マスター・物語の 相手は 特性と 技を 組みあわせて くる
    // v2.5.4: 物語・野生の 敵は 再誕の誓いを 使わない（執念＋再誕で 詰まないように）
    const stripRR = () => { for (const f of B.enemies) { f.moves = f.moves.filter((id) => !MOVES[id]?.reraise); f.tr.startraise = false; } };
    if (master && !master.ghost && !master.easy) try { applyBuilds(B.enemies, master.final || master.enma || master.kengo || master.hpk || master.bslab !== undefined ? 2 : (master.tier ?? 1)); } catch {}
    stripRR();
    // v3.0: 物語の ボスの 能力は 石板の 王 ヴァルグレイド（HP9999・物力999・武力999・硬力750・魔硬力700・走力500・吹力800）を 基準に、ボスの レベルで きめる
    if (master && !master.enma && !master.dream && (master.bslab !== undefined || master.final || master.kengo || master.rmaster || master.ruinFinal)) {
      const main0 = B.enemies[0];
      const crown = (master.bslab === CROWN || master.crownRe) && main0.m.sp === "haken";
      if (crown) {   // 石板の 王
        if (master.re) Object.assign(main0.mx, { hp: 25000, mp: 9999, atk: 2000, wpn: 2000, def: 2000, mdf: 2000, spd: 2000, brt: 2000, mat: 2000 });   // 第65版: クリア後の 石板の 王
        else Object.assign(main0.mx, { hp: 9999, mp: 9999, atk: 999, wpn: 999, def: 750, mdf: 700, spd: 500, brt: 800, mat: 700 });
        main0.hp = main0.mx.hp; main0.php = main0.mx.hp; main0.mp = main0.mx.mp; main0.infMP = !master.re; main0.isBoss = true; main0.fixedKit = true;
        main0.m.noSx = true; try { main0.tr = C_traitFx(main0.m.sp, main0.m); } catch {}   /* 特性は 指定の 4つ（SS・Xの 固有特性は つけない） */
        Object.assign(main0.tr, { acts: [2, 3], extra: 0, critguard: true, laststand: true, autodispel: Math.max(main0.tr.autodispel || 0, 0.3) });
        main0.bossTraits = ["2〜3回行動", "急所隠し（会心を 受けない）", "不倒の誓い", "霧散の気（ときどき 強化を かき消す）"];
        main0.moves = hakenKit();
        main0.smart = 2.5;
      } else {
        const KB = master.kengo ? 1 : master.final ? 0.95 : master.bslab !== undefined ? 0.95 : master.rmaster ? 0.9 : 0.9;   /* 配下が いる 石板の 主・地方マスターは 少し 下げる */
        const LC = slabBossLv(CROWN), fr = Math.min(1, Math.pow(Math.max(1, main0.lv) / LC, BOSS_EXP)) * KB;
        const BB = { atk: 999, wpn: 999, mat: 700, brt: 800, def: 750, mdf: 700, spd: 500 };
        const off = ["atk", "wpn", "mat", "brt"], top = Math.max(...off.map((k) => main0.mx[k] || 1)), nat = { ...main0.mx };   /* 序盤は もとの 能力より 下げない */
        const dv = (main0.mx.def + main0.mx.mdf + main0.mx.spd) / 3 || 1;
        const fo = Math.min(1, Math.pow(Math.max(1, main0.lv) / LC, BOSS_OEXP)) * KB;   /* 攻撃は 序盤ほど ひかえめ */
        for (const k of off) main0.mx[k] = Math.max(Math.floor((nat[k] || 1) * 0.95), Math.floor(999 * fo * Math.max(0.35, (nat[k] || 1) / top)));
        for (const k of ["def", "mdf", "spd"]) main0.mx[k] = Math.max(Math.floor((nat[k] || 1) * 1.05), Math.floor(BB[k] * fr * Math.min(1.2, Math.max(0.8, (nat[k] || 1) / dv))));
        main0.mx.hp = Math.min(9999, Math.max(Math.floor((nat.hp || 50) * (master.bslab !== undefined ? 2.1 : master.rmaster ? 1.4 : 1.0)), Math.floor(9999 * Math.pow(fr, BOSS_HPEXP)))); main0.hp = main0.mx.hp; main0.php = main0.mx.hp;
        main0.mx.mp = Math.min(999, Math.max(main0.mx.mp, Math.floor(999 * fr))); main0.mp = main0.mx.mp; main0.isBoss = true;
        { const soft = 1;   /* 第63版: 石板の 主は 弱めない（簡単すぎた） */   /* シミュレーションで 勝ちにくかった 主だけ 少し 下げる */
          if (soft < 1) { for (const st of ["atk", "wpn", "mat", "brt", "hp"]) main0.mx[st] = Math.max(1, Math.floor(main0.mx[st] * soft)); main0.hp = main0.mx.hp; main0.php = main0.mx.hp; } }
        for (const f of B.enemies.slice(1)) { const kk = master.bslab !== undefined ? 1.2 : 1.1; for (const st of ["atk", "wpn", "mat", "brt", "def", "mdf", "spd"]) f.mx[st] = Math.min(9999, Math.floor(f.mx[st] * kk)); f.mx.hp = Math.min(9999, Math.floor(f.mx.hp * (kk + 0.05))); f.hp = f.mx.hp; f.php = f.mx.hp; }
        main0.tr.extra = Math.max(main0.tr.extra || 0, master.final || master.kengo ? 0.45 : master.rmaster ? 0.35 : 0.25);
        if (master.re) {   // 第65版: クリア後の 石板の 主
          const avg = topAvg(d);   /* 第69版: 表と 裏の 上位3体（神は 割りもどし） */
          main0.mx.hp = 15000; main0.mx.mp = 5000; main0.hp = main0.mx.hp; main0.php = main0.mx.hp; main0.mp = main0.mx.mp;
          for (const k of ["atk", "wpn", "mat", "brt", "def", "mdf", "spd"]) main0.mx[k] = Math.min(9999, Math.max(1200, Math.floor(avg(k) * 1.6)));   /* 手持ちの 上位3体の 平均の 1.6倍（最低 1200） */
          main0.fixedKit = true; try { const K = reKit(master.reIdx, master.reKings, main0.moves); if (K.moves && K.moves.length >= 5) main0.moves = [...K.moves]; if (K.tac) main0.aiTac = K.tac; } catch {} main0.smart = 2.5;   // 技と 性格は 主ごとに ちがう
          main0.tr.extra = Math.max(main0.tr.extra || 0, 0.45);
        }
        // v3.0 第63版: クリア後の 主（星冠王の 再戦・剣豪・墓守）は HP 上限 2万・プラス値（勝った 回数）で 強く
        if (!master.re && ((master.final || master.kengo || master.ruinFinal) && master.rematch)) { const pk = 1 + Math.min(1, (main0.m.plus || 0) / 60); main0.mx.hp = Math.min(20000, Math.floor(main0.mx.hp * 1.6 * pk)); main0.hp = main0.mx.hp; main0.php = main0.mx.hp; if (pk > 1) for (const st of ["atk", "wpn", "mat", "brt", "def", "mdf"]) main0.mx[st] = Math.min(9999, Math.floor(main0.mx[st] * (1 + (pk - 1) * 0.4))); }
        // v3.0: 手持ちが すすめる レベルより ずっと 高い ときは ボスも 少し 強く（一方的に ならない ように。最大 +45%）
        try { const P = partyPower(d), over = P.lv - (main0.lv + 1) - 4; if (over > 0 && !master.kengo && !master.re) { const ok2 = 1 + Math.min(0.45, over * 0.02); for (const f of B.enemies) { for (const st of ["atk", "wpn", "mat", "brt", "def", "mdf", "spd"]) f.mx[st] = Math.min(9999, Math.floor(f.mx[st] * ok2)); f.mx.hp = Math.max(f.mx.hp, Math.min(9999, Math.floor(f.mx.hp * ok2))); f.hp = f.mx.hp; f.php = f.mx.hp; } B.overK = ok2; } } catch {}
      }
    }
    // 第68版: 神の石板の 神（Gサイズ・手持ちに 合わせた 強さ・最低 1200・HP 2万（ゲゼラ 3万））
    if (master && master.deity !== undefined && master.deity !== null && B.enemies[0]) {
      const main0 = B.enemies[0], gz = master.deity === 14, avg = topAvg(d);
      main0.m.sz = "G";
      main0.mx.hp = gz ? 30000 : 20000; main0.mx.mp = 9999;
      shapeStats(main0, avg, DEITY_M[master.deity] ?? 1.7, gz ? 1500 : 1200);
      main0.hp = main0.mx.hp; main0.php = main0.mx.hp; main0.mp = main0.mx.mp; main0.infMP = true; main0.isBoss = true; main0.fixedKit = true; main0.smart = 2.5;
      Object.assign(main0.tr, { acts: [2, 3], critguard: true, laststand: true, deityRev: gz ? 2 : 1, autodispel: Math.max(main0.tr.autodispel || 0, 0.25) });
      main0.tr.extra = Math.max(main0.tr.extra || 0, 0.4);
      try { main0.moves = gachiKit(main0, RE_PERS[master.deity % RE_PERS.length], true); main0.aiTac = RE_PERS[master.deity % RE_PERS.length]; } catch {}
      main0.bossTraits = ["2〜3回行動", "急所隠し", "不倒の誓い", `神の 再臨（HP半分で 全回復・全能力 底上げ${gz ? "・2回" : ""}）`];
      try { globalThis.__MQ_DEITY_LAST = globalThis.__MQ_DEITY_LAST || new Map(); globalThis.__MQ_DEITY_LAST.set(p.id, { gi: master.deity, mx: { ...main0.mx } }); } catch {}
    }
    // 第76版: 追加ストーリー「滅びた世界」の 邪神の 配下（0〜14）と 邪神（15）。HP 2万〜・ほかの 能力 2500〜（邪神は 6万・4000〜）
    if (master && master.ruinsBoss !== undefined && master.ruinsBoss !== null && B.enemies[0]) {
      const i = master.ruinsBoss | 0, fin = i >= 15, main0 = B.enemies[0], avg = topAvg(d);
      main0.m.sz = "G";
      const re = fin && !!master.ruinsRe;   /* 第78版: 邪神の 再戦は 少し 強い */
      main0.mx.hp = fin ? (re ? 70000 : 60000) : 20000 + i * 1500; main0.mx.mp = 9999;
      shapeStats(main0, avg, fin ? (re ? 1.45 : 1.3) : 1.5 + i * 0.03, fin ? (re ? 3100 : 2800) : 2500 + i * 100);   /* 第77版: 邪神は 強い パーティで 勝てる ように 少し 下げた */
      if (master.ruinsWeak) main0.mx.hp = Math.round(main0.mx.hp * (1 - 0.1 * Math.min(2, master.ruinsWeak | 0)));   /* 第95版: 弱点を 突いた 回数 */
      main0.hp = main0.mx.hp; main0.php = main0.mx.hp; main0.mp = main0.mx.mp; main0.infMP = true; main0.isBoss = true; main0.fixedKit = true; main0.smart = 2;
      Object.assign(main0.tr, { acts: fin ? [2, 3] : [2, 3], critguard: true, laststand: true, autodispel: Math.max(main0.tr.autodispel || 0, 0.2) });
      if (fin) main0.tr.deityRev = 1;   /* 第77版: 再臨は 1回（2回だと 強い パーティでも ほぼ 勝てなかった） */
      main0.tr.extra = Math.max(main0.tr.extra || 0, fin ? 0.5 : 0.35);
      try { main0.moves = gachiKit(main0, RE_PERS[i % RE_PERS.length], true); main0.aiTac = RE_PERS[i % RE_PERS.length]; } catch {}
      if (master.bossName) { main0.name = master.bossName; main0.m.nm = master.bossName; }
      main0.bossTraits = fin ? ["2〜3回行動", "急所隠し", "不倒の誓い", "邪神の 再臨（HP半分で 全回復・1回）"] : ["2〜3回行動", "急所隠し", "不倒の誓い"];
    }
    // 第68版: 地方の 王（クリア後）: 全員 SS・HP 1万5千 以上・能力 1200 以上・勝つほど 強く
    if (master && master.kingK && B.enemies.length) {
      const w = master.kingK.wins || 0, avg = topAvg(d), K = 1.55 * (1 + 0.07 * Math.min(20, w));
      let disp = false;
      B.enemies.forEach((f, j) => {
        f.mx.hp = Math.min(60000, 15000 + 2500 * w + (j === 0 ? 5000 : 0)); f.mx.mp = 5000;
        shapeStats(f, avg, K, 1200);
        if (B.enemies.length === 1) { f.mx.hp = Math.min(60000, Math.floor(f.mx.hp * 1.5)); Object.assign(f.tr, { acts: [2, 3], critguard: true, laststand: true }); }   /* 王 1体（G）の ときは 手数と 守り */
        f.hp = f.mx.hp; f.php = f.mx.hp; f.mp = f.mx.mp; f.isBoss = true; f.fixedKit = true; f.smart = 2.5;
        const tac = RE_PERS[(master.kingK.i + j) % RE_PERS.length];
        try { const kit = gachiKit(f, tac, !disp && (j === 0 || SPECIES[f.m.sp]?.fam === "king")); if (kit.some((m) => MOVES[m]?.target === "enemies" && (MOVES[m].dispel || MOVES[m].dispelhit))) disp = true; f.moves = kit; f.aiTac = tac; } catch {}
        f.tr.extra = Math.max(f.tr.extra || 0, 0.3);
      });
    }
    // 第67版: 物語の ボスは 1回の 行動で 1体に 最大HPの 半分までしか 与えない（初手で 全滅しにくく。再戦・剣豪・エンマは のぞく）
    if (!B.raid && (master ? ((master.bslab !== undefined && !master.re) || (master.final && !master.rematch) || master.rmaster || (master.hpk && !master.ch) || (master.ruinFinal && !master.rematch)) : (boss && slab !== null))) for (const e of B.enemies) if (e.isBoss && !e.outCap) { e.outCap = 9999; e.outPct = 0.5; e.outFloor = 1; }
    // v2: 野生の HPは 少なめ（テンポ よく）。ボス・マスター・石板は そのまま
    if (!boss && !master) for (const e of B.enemies) { e.mx.hp = Math.max(1, Math.floor(e.mx.hp * wildHpK(e.m.sp))); e.hp = Math.min(e.hp, e.mx.hp); }
    const nc = {}, used = {};
    for (const e of B.enemies) nc[e.name] = (nc[e.name] || 0) + 1;
    for (const e of B.enemies) if (nc[e.name] > 1) { used[e.name] = (used[e.name] || 0) + 1; e.name += "ABC"[used[e.name] - 1]; }
    const big = Math.max(...B.enemies.map((f) => ({ S: 1.6, M: 2.4, L: 5.2, G: 7.2 })[sizeOf(f.m)] || 2.6));
    // 大きな 敵は 少し 後ろに さげて、プレイヤーと かさならないように
    const back = Math.max(0, big / 2 - 2.5);
    const E2 = { x: E.x + dx * back, y: E.y, z: E.z + dz * back };
    const ePos = placeLine(E2, perp, B.enemies.length, Math.max(boss ? 3.5 : 2.6, big));
    if (master) for (const f of B.enemies) f.isMaster = true;
    // v2.2.2: マスター・主・ボスは 戦術の 技を もち、かしこく 戦う
    if ((master && !master.ghost && !master.easy) || boss || slab !== null) {   // v2.9.13: easy＝はじめの 戦い（戦術の 技を もたない）
      const k = B.ruins ? 3 : master ? (master.final || master.enma || master.ruinFinal || (master.bslab !== undefined && master.bslab >= 20) || master.kengo ? 3 : master.bslab !== undefined ? 1 + Math.floor(master.bslab / 10) : master.arena ? 2 : master.tier || 0) : raid ? 3 : slab !== null ? 1 + Math.min(2, slab) : 1;
      B.enemies.forEach((f, i) => { if (master && master.enma) { f.smart = 1 + 0.75 * (f.enmaN || 0); return; } if (f.fixedKit) return; for (const id of npcKit(f, i === 0 ? "ace" : "sup", k)) if (!f.moves.includes(id)) f.moves.push(id); f.smart = master ? (master.final || master.kengo || master.bslab !== undefined || master.rmaster ? 2 : 1) : 0.6; });
      stripRR();
    }
    // v3.0: 野生の ハガネ族は HPが とても 少ない（いちばん 下の コガネコロは 2・いちばん 上の ランクは 8）
    if (!master && !boss && !raid) for (const f of B.enemies) { const S = SPECIES[f.m.sp]; if (!S || !S.metalmon) continue; const hp = metalWildHp(f.m.sp); f.mx = { ...f.mx, hp }; f.php = hp; f.hp = hp; }
    if (globalThis.__bossProbe) { globalThis.__bossProbe(B); throw new Error("__probe"); }   // ガイドの ボス表を 作る ときだけ（ゲームでは 使わない）
    const allyCenter = { x: P.x + dx * 2.2, y: P.y, z: P.z + dz * 2.2 };
    B.enemies.forEach((f, i) => {
      if (i === 0) { f.ent = wild; f.wild = true; wild.nameTag = `§c${f.m.shiny ? "§e★§c" : ""}${f.name} Lv${f.lv} ${rankOf(f.m.sp)}`; const h = B.enemies.length > 1 ? ePos[0] : B.center || wild.location; f.home = { x: h.x, y: h.y, z: h.z }; f.face = allyCenter; try { wild.teleport(h, { facingLocation: allyCenter }); } catch {} }
      else summonFighter(p, f, ePos[i], allyCenter, B.temps, null, bid);
    });
    // v2.9: はじめの 天候（闘技場は いつも 晴れ）
    try { const th = B.theme || (master ? master.theme || "arena" : themeOf(biome, p.dimension.id, (() => { try { return WR_[rIdxAt_(p.location)]?.id; } catch { return null; } })())); B.wbase = natWeather(B, p, th, master, inSky); if (B.wbase === "sun" && (inSky || th === "arena")) { B.wbaseT = 8; B.wonce = true; } } catch {}
    addPlayer(B, p, d);
    // v2.8: 物語の 共闘（NPCの 仲間が いっしょに 戦う。動きは 自動）
    if (master && Array.isArray(master.guests)) master.guests.forEach((g, i) => {
      try {
        const f = fighter(mk(g.sid, g.lv, 0.8, false, g.plus || 0), "a");
        f.guest = true; f.owner = "npc"; f.name = `${g.owner || "なかま"}の ${f.name}`; f.smart = 1;
        const o = 3.2 + i * 2.4, sg = i % 2 ? -1 : 1;
        const pos = { x: P.x - dx * 1.6 + perp.x * o * sg, y: P.y, z: P.z - dz * 1.6 + perp.z * o * sg };
        summonFighter(p, f, pos, E, B.temps, null, bid);
        B.allies.push(f);
      } catch (e) { console.warn(`[MonsterRPG] guest: ${e}`); }
    });
    sound(p, boss ? "mob.enderdragon.growl" : master ? "raid.horn" : "mob.wither.spawn", 1.6);
    await wait(4); fixView(B, false);   // v2.6: 出そろったか 確かめて、ずれた子・消えた子を 立てなおす
    await wait(6); fixView(B, false);
    await wildLoop(B);
  } catch (err) {
    console.warn(`[MonsterRPG] battle error: ${err} ${err?.stack || ""}`);
  } finally {
    B.ended = true;
    battles.delete(bid);
    for (const id of [...B.players.map((x) => x.p.id), p.id]) if (DOMEB.get(id)?.bid === bid) DOMEB.delete(id);
    camClear(B.players.map((x) => x.p).concat(B.joinQueue || []));
    const cap = (pr) => Promise.race([pr, new Promise((r) => system.runTimeout(r, 240))]);   // v2.8: 片づけが 止まっても 12秒で 先へ
    if (B.retPos) for (const x of [...B.players, ...(B.joinQueue || []).map((q) => ({ p: q }))]) skyBack(x.p, B, x.pet);   // 第63版: 上空から もとの 場所へ（ステージを 消す 前に）
    if (B.retPos && B.retPos[p.id]) skyBack(p, B, null);
    if (B.innTo) for (const x of B.players) if (B.innTo.has(x.p.id)) innTp(x.p);
    if (B.dome) { try { await cap(removeDome(B)); } catch {} }
    if (B.stage) { try { await cap(removeStage(B.stage)); } catch {} }
    camClear(B.players.map((x) => x.p).concat(B.joinQueue || []));
    unhide(B);
    if (B.dgRet && B.result !== "lose") { try { p.teleport(B.dgRet); } catch {} }
    if (B.wildRet && ok(wild) && !(B.result === "win" || B.result === "scout")) { try { wild.teleport(B.wildRet); } catch {} }
    for (const e of B.temps) if (ok(e)) { particle(e, "minecraft:white_smoke_particle"); try { e.remove(); } catch {} }
    const won = B.result === "win" || B.result === "scout";
    if (won) musashiWin(B);
    if (ok(wild)) {
      if (raid && !won) { particle(wild, "minecraft:white_smoke_particle"); try { wild.remove(); } catch {} for (const x of B.players) try { x.p.sendMessage("§5レイドボスは 闇に 消えた……"); } catch {} }   // 第63版: レイドボスは 負けたら 消える
      else if (boss && !won && !master && slab === null) {
        wild.removeTag("mrpg_battle"); wild.setDynamicProperty("mrpg:bid", undefined);
        wild.nameTag = nameTag0;
        standUp(wild);
        // v3.0: 負けた あと 遺跡の ボスが 地面に うまって 見えなく なる → 足もとが うまって いたら 上へ 出す（ステージが もどった あとにも もう一度）
        const lift = () => { try { if (!ok(wild)) return; const l = wild.location, dim = wild.dimension, x = Math.floor(l.x), z = Math.floor(l.z); let y = Math.floor(l.y + 0.05);
          const solid = (yy) => { try { const b = dim.getBlock({ x, y: yy, z }); return !!b && !b.isAir && !b.isLiquid && !/short_grass|tall_grass|tallgrass|seagrass|fern|flower|snow_layer|bush|tulip|poppy|dandelion|roots|carpet|torch|lily|orchid|allium|bluet|daisy|cornflower|vine|petals|azalea|sapling/.test(b.typeId); } catch { return false; } };
          if (wild.hasTag?.("mrpg_battle") || (!solid(y) && !solid(y + 1))) return;
          for (let k = 1; k <= 24; k++) if (!solid(y + k) && !solid(y + k + 1)) { wild.teleport({ x: l.x, y: y + k, z: l.z }); return; } } catch {} };
        lift(); system.runTimeout(lift, 40); system.runTimeout(lift, 120);
      } else { particle(wild, "minecraft:white_smoke_particle"); try { wild.remove(); } catch {} }
    }
    const jq = B.joinQueue.map((q) => ({ p: q })); B.joinQueue = [];
    for (const x of [...B.players, ...jq]) try { hudClear(x.p); } catch {}   // v2.9.12: 終わったら かならず 枠と ログを 消す   // v2.9.12: 待ちの 人の タイマーが あとで busy を 消さない ように
    for (const x of [...B.players, ...jq]) {
      const q = x.p;
      busy.delete(q.id);   // v2.9.6: 先に はずす
      if (!ok(q)) continue;
      try {
        if (x.pet && ok(x.pet)) { standUp(x.pet); const m = x.d.party.find((mm) => mm.id === x.d.out); if (m) makePetGroups(x.pet, m.sp, m); }
        if (x.d) { save(q, x.d); if (x.d.out) refreshPet(q, x.d); }
        q.removeEffect("resistance"); q.removeEffect("fire_resistance");
        if (B.sea) seaFx(q, false);
      } catch {}
    }
    if (![...battles.values()].some((b2) => b2.players.some((y) => y.p.id === p.id))) busy.delete(p.id);
  }
  return B.result;
}

// v2.8: 物語の 相手の ひとこと（HPが 半分・のこり わずか）
async function storyLines(B, names, log) {
  const L = B.master && B.master.lines, m0 = B.enemies[0];
  if (!L || !m0 || m0.hp <= 0) return;
  const who = B.master.speaker || B.master.name || m0.name;
  for (const [k, th] of [["half", 0.5], ["low", 0.22]]) {
    if (!L[k] || (B.saidL || (B.saidL = {}))[k] || m0.hp > m0.mx.hp * th) continue;
    B.saidL[k] = true;
    const line = `§c§l${who}§r§f「${L[k]}」`;
    for (const p of names()) battleTitle(p, "", `§f「${L[k].slice(0, 26)}${L[k].length > 26 ? "…" : ""}」`, 60);
    await playFx(names(), null, [line]); log.push(line);
  }
}
// v2.9: 負けイベント（物語で かならず 負ける 戦い）。決まった ターンが すぎると 増援などで 全滅する
async function scriptedLose(B, log) {
  const names = () => B.players.map((x) => x.p);
  const S = B.master.scripted || {};
  for (const p of names()) { sound(p, "raid.horn", 0.8); sound(p, "mob.wither.spawn", 0.6); }
  await playFx(names(), null, S.lines || ["§c§l敵の 増援が あらわれた！"]);
  for (const f of alive(B.allies)) { f.hp = 0; koFx(f); }
  hpTags(B);
  await playFx(names(), null, ["§7……仲間たちは 力尽きた。"]);
  log.push(...(S.lines || []));
  B.result = "lose";
}
// v2.8: 悪夢（閻魔の神殿）: こちらは 何も できず、先手で 斬られる。かならず 負ける 強制戦闘
async function dreamLoop(B, log) {
  const names = () => B.players.map((x) => x.p);
  const boss = B.enemies[0];
  for (const p of names()) { sound(p, "mob.warden.heartbeat", 1); sound(p, "mob.wither.spawn", 0.5); }
  await playFx(names(), null, ["§4§l…………", "§7白い 髪の 男が、鍔の ない 抜き身の 刀を 下げて こちらを 見ている。"]);
  await playFx(names(), null, ["§c体が 動かない！", "§7手も 足も 出ない……！ 仲間たちも すくんで しまった！"]);
  for (const f of alive(B.allies)) { anim(f.ent, "hurt"); }
  await waitT(10);
  const sig = SPECIES[boss.m.sp]?.sig;
  const lines = [];
  const fx = runAction(B, { actor: boss, kind: "move", move: sig && MOVES[sig] ? sig : "basic", target: alive(B.allies)[0] }, lines);
  { const mn = sig && MOVES[sig] ? MOVES[sig].name : null; if (mn) for (let i = 0; i < lines.length; i++) lines[i] = String(lines[i]).split(mn).join("鍔の ない 刀の 一閃"); if (fx && mn) fx.mvName = "鍔の ない 刀の 一閃"; }   /* 第69版: 技の 名前も かくす（画面中央も） */
  if (fx) await playFx(names(), fx, lines.length ? lines : ["§4……"]);
  const rest = alive(B.allies);
  if (rest.length) {
    for (const f of rest) { f.hp = 0; koFx(f); }
    await playFx(names(), null, ["§4§l斬撃の 余波が すべてを 呑みこんだ……", "§7何が 起きたのか、わからなかった。"]);
  }
  hpTags(B);
  log.push("§4……");
  B.result = "lose";
  await finish(B, log);
}
async function wildLoop(B) {
  const names = () => B.players.map((x) => x.p);
  let log = [[...new Set(B.enemies.map((e) => e.m.nm))].join("と ") + "が 現れた！"];
  if (B.boss) log.unshift(B.bounty ? "§c§l賞金首が あらわれた！" : B.slab !== null && B.slab !== undefined ? "§d§l石板の 力で ボスが よみがえった！" : B.raid ? "§d§lレイドボスが たちはだかる！" : "§4§l遺跡の ボスが めをさました！");
  if (B.master) log = [B.master.arena ? `§e§l【${B.master.arena}】§r§b ${B.master.name}が 現れた！` : `§b§l${B.master.rival ? "リベンジに きた " : ""}${MASTER_TIER[B.master.tier]}の ${B.master.name}が 勝負を しかけてきた！`, `§b${B.master.name}は ${B.enemies.map((e) => e.m.nm).join("・")}を くりだした！`];
  if (B.enemies.some((e) => e.m.shiny)) log.push("§e★ かがやく モンスターだ！ スカウトの チャンス！");
  if (B.enemies.some((e) => e.m.ht && !e.m.shiny)) log.push("§6◆ 固有特性を もつ モンスターが いる…！");
  battleStart(B, log); musashiBattleStart(B);
  B.result = null;
  hpTags(B);
  wxShow(B);
  if (B.master && B.master.dream) { await dreamLoop(B, log); return; }
  const mine = () => alive(B.allies.filter((x) => !x.guest)).length;
  while (!B.result) {
    // 途中参加
    shoo(B);   // v3.0: 戦いに 関係ない モンスターを 場の 外へ（ターンの はじめに 1回）
    // v3.0 第63版: 野生の ハガネ族は ターンの はじめに 逃げる ことが ある（動く 前に 倒されて「逃げやすい」が 起きなかった）
    if (!B.master && !B.boss && !B.raid && !B.pvp) { const hold = B.allies.some((x) => x.hp > 0 && x.tr.antiflee) ? 0.35 : 1;
      for (const f of B.enemies) if (f.hp > 0 && f.tr.metal && SPECIES[f.m.sp]?.metalmon && !(f.noflee > 0) && Math.random() < 0.2 * hold) { f.hp = 0; f.fled = true; f.out = true; log.push(`§7${f.name}は 逃げだした！`); try { if (f.ent && !f.wild && f.ent.isValid()) f.ent.remove(); } catch {} }
      if (!alive(B.enemies).length) { B.result = "win"; break; } }
    while (B.joinQueue.length) {
      const q = B.joinQueue.shift();
      try { busy.delete(q.id); } catch {}
      if (!ok(q)) continue;   // v2.9.12: 待って いる あいだに ぬけた 人で 戦いが 止まらない ように
      let d = null; try { d = load(q); } catch {}
      if (ok(q) && d) { try { addPlayer(B, q, d); } catch (e) { console.warn(`[MonsterRPG] join: ${e}`); continue; } log.push(`§b${q.name}が さんせんした！`); for (const f of B.allies) try { fighterStart(B, f, log); } catch {} }
    }
    // 全員のコマンド
    const cmds = await Promise.all(B.players.map(async (x) => {
      try {
        const pr = commandPhase(x.p, B, "a", log, false, x.p.id);
        if (B.players.length < 2) return [x, await pr];
        // v2.9.6: 協力バトルで 90秒 えらばない 人は おまかせ（ほかの 人を 待たせない）
        const auto = new Promise((r) => system.runTimeout(() => r({ auto: true }), 1800));
        let c = await Promise.race([pr, auto]);
        if (c && c.auto) {
          B.cmdGen[x.p.id] = (B.cmdGen[x.p.id] || 0) + 1;   // 古い 画面を むこうに する
          try { SUI.uiManager?.closeAllForms(x.p); } catch {}
          for (const f of B.allies) if (f.owner === x.p.id) f.defend = false;   // v2.9.9: えらび かけの 防御は 取りけす
          c = { auto: true, acts: alive(B.allies).filter((f) => f.owner === x.p.id).map((f) => ({ ...aiDecide(f, B), ai: true })) };
        }
        if (c && c.auto) log.push(`§7${x.p.name}の 仲間は じぶんで 考えて 動いた（おまかせ）`);
        return [x, c];
      }
      catch { return [x, { leave: true, acts: [] }]; }
    }));
    log = [];
    let acts = [];
    for (const [x, c] of cmds) {
      if (c.leave) { leave(B, x, log); continue; }
      acts.push(...c.acts);
      if (c.item) {
        if (ITEMS[c.item.id].kind === "escape" && (B.boss || B.master)) { log.push(B.master ? "§cマスターとの 勝負からは 逃げられない！" : "§cボスからは 逃げられない！"); continue; }   // v2.9.6: 使えない ときは へらさない
        { const it = ITEMS[c.item.id], tg = c.item.target, fr = B.allies.filter((f) => f.owner === x.p.id || !f.owner);   /* v3.0 第63版: 効かない 道具は へらさない */
          const need = (f) => !!f && f.hp > 0 && ((it.kind === "heal" || it.kind === "healall") ? f.hp < f.mx.hp : (it.kind === "mpheal" || it.kind === "mpall") ? f.mp < f.mx.mp : (it.kind === "cure" || it.kind === "curall") ? Object.values(f.ail || {}).some((v) => v) : it.kind === "fullall" ? f.hp < f.mx.hp || f.mp < f.mx.mp : true);
          const known = ["heal", "healall", "mpheal", "mpall", "cure", "curall", "fullall"].includes(it.kind);
          if (known && !(tg && typeof tg === "object" && "hp" in tg ? need(tg) : fr.some(need))) { log.push(`§7${it.name}は いま 使っても 効果が ない。（へらなかった）`); continue; } }
        if (!takeItem(x.p, `mrpg:${c.item.id}`)) { log.push(`§c${ITEMS[c.item.id].name}が 見つからない！`); continue; }   // v2.9.9: 手ばなした 道具は 使えない
        if (ITEMS[c.item.id].kind === "escape") {
          log.push(`${x.p.name}は ${ITEMS[c.item.id].name}を なげた！`);
          leave(B, x, log); continue;
        }
        const lines = [];
        const fx = battleItem(B, c.item.id, c.item.target, lines);
        if (B.players.length > 1) lines[0] = lines[0].replace("あなたは", `${x.p.name}は`);
        await playFx(names(), fx, lines); log.push(...lines);
      } else if (c.scout) {
        const sr = await scout(B, x, log, c.target || null);
        if (sr === "noop") acts.push(...actable(B, B.allies).filter((f) => f.owner === x.p.id).map((f) => ({ ...aiDecide(f, B), ai: true })));   // 話を 聞かない 相手なら ターンを むだに しない
        if (B.scoutWin) { B.result = "scout"; break; }
      } else if (c.run) {
        // v2.5.4: 逃げられない 戦いは こうさん できる（お金は へらない・物語は そのまま もう一度 挑める）
        if (B.boss || B.master) {
          const cf = c.sure ? Promise.resolve(true) : confirm(x.p, "こうさん", "§fこの 戦いを あきらめますか？\n§7お金は へりません。仲間は HP1で もどり、あとで もう一度 挑めます。", "こうさんする", "続ける").catch(() => false);
          if (!(await (B.players.length > 1 ? Promise.race([cf, new Promise((r) => system.runTimeout(() => r(false), 600))]) : cf))) continue;
          log.push(`§7${B.players.length > 1 ? x.p.name + "は " : ""}こうさんした……`); await playFx(names(), null, log.slice(-1));
          if (B.players.length > 1) { x.surrender = true; leave(B, x, log); continue; }
          B.surrender = true; B.result = "lose"; break;
        }
        if (Math.random() < escapeChance(B)) { log.push(`${B.players.length > 1 ? x.p.name + "は " : ""}うまく 逃げきれた！`); await playFx([x.p], null, log.slice(-1)); leave(B, x, log); }
        else { log.push("§cしかし まわりこまれてしまった！"); await playFx(names(), null, log.slice(-1)); }
      }
    }
    if (B.result) break;
    if (!B.players.length) { B.result = "escape"; break; }
    if (!alive(B.enemies).length) { B.result = B.scouted ? "scout" : "win"; break; }
    for (const e of alive(B.enemies)) acts.push(aiDecide(e, B));
    for (const g of alive(B.allies).filter((x) => x.guest)) acts.push(aiDecide(g, B));
    acts = expandActions(acts, B); if (B.trimNote && B.trimNote.length) { const tl = B.trimNote.splice(0); try { await playFx(names(), null, tl); } catch {} log.push(...tl); }
    for (const a of actionOrder(acts, B)) {
      if (a.actor && a.actor.swapT === (B.turn || 1)) continue;   // 第68版: 入れかわった 子は この ターン 動けない
      if (!B.allies.includes(a.actor) && !B.enemies.includes(a.actor)) continue;
      const lines = [];
      const fx = runAction(B, a, lines);
      if (!fx) continue;
      await playFx(names(), fx, lines);
      log.push(...lines);
      musashiAct(B, a, fx);   // v2.9.14: ムサシの ひとこと
      { const dl = []; deityCheck(B, dl); if (dl.length) { await playFx(names(), null, dl); log.push(...dl); } }   // 第68版
      hpTags(B);
      wxShow(B);
      await storyLines(B, names, log);
      if (!alive(B.enemies).length) { if (B.master && B.master.scripted) { await scriptedLose(B, log); break; } B.result = "win"; break; }
      if (!mine()) { const bl = []; benchAuto(B, bl); if (bl.length) { await playFx(names(), null, bl); log.push(...bl); break; } B.result = "lose"; break; }
    }
    if (B.result) break;
    const lines = [];
    const kos = endOfTurn(B, lines);
    try { deityCheck(B, lines); } catch {}   // 第68版
    if (lines.length) { await playFx(names(), null, lines); for (const t of kos) koFx(t); log.push(...lines); }
    hpTags(B);
    wxShow(B);
    { const bl = []; benchAuto(B, bl); if (bl.length) { await playFx(names(), null, bl); log.push(...bl); } }
    if (B.master && B.master.scripted && !B.result && (!alive(B.enemies).length || (B.turn || 1) > (B.master.scripted.turns || 3))) { await scriptedLose(B, log); break; }
    if (!alive(B.enemies).length) B.result = "win";
    else if (!mine()) B.result = "lose";
    // v2.5.4: 逃げられない 戦いが 長引いたら 時間切れ（詰まないように）
    else if ((B.boss || B.master) && (B.turn || 1) > 40) { log.push("§7§l時間切れ！ §r§7両者 決着が つかなかった……（お金は へらない）"); B.timeup = true; B.result = "lose"; }
    else if (!B.pvp && !B.spar && !B.raid && (B.turn || 1) > 80) { log.push("§7§l長引いたので 相手は 去って いった……"); B.result = "escape"; }   /* 第67版: 野生の 戦いが 終わらない のを ふせぐ */
  }
  await finish(B, log);
}

function leave(B, x, log) {
  const i = B.players.indexOf(x);
  if (i < 0) return;
  if (B.retPos && B.retPos[x.p.id]) skyBack(x.p, B, x.pet);   // 第63版
  try { if (DOMEB.get(x.p.id)?.bid === B.bid) DOMEB.delete(x.p.id); } catch {}
  B.players.splice(i, 1);
  hudClear(x.p);
  for (const f of B.allies.filter((f) => f.owner === x.p.id)) {
    f.m.hp = f.hp > 0 || x.surrender ? Math.max(1, hpBack(f)) : 0; f.m.mp = Math.min(f.mp, calcStats(f.m).mp);   // v2.9.12: 抜けた 子は HP1で のこる
    if (ok(f.ent) && f.ent !== x.pet) { particle(f.ent, "minecraft:white_smoke_particle"); try { f.ent.remove(); } catch {} }
  }
  B.allies = B.allies.filter((f) => f.owner !== x.p.id);
  if (x.pet && ok(x.pet)) { standUp(x.pet); const m = x.d.party.find((mm) => mm.id === x.d.out); if (m) makePetGroups(x.pet, m.sp, m); }
  busy.delete(x.p.id);   // v2.9.6: 先に はずす（ぬけた 人の セーブで 止まっても のこらない）
  if (ok(x.p)) { try { if (!(B.master && B.master.enma)) promoteBench(x.d); if (x.d.out && !x.d.party.some((m) => m.id === x.d.out)) x.d.out = null; save(x.p, x.d); } catch {} try { if (x.d && x.d.out) refreshPet(x.p, x.d); } catch {} try { x.p.removeEffect("resistance"); x.p.removeEffect("fire_resistance"); } catch {} if (B.sea) try { seaFx(x.p, false); } catch {} }
  else if (!B.spar && !B.pvp) try { awayKeep(x, B, ["§7戦いの とちゅうで ぬけた。", ...(B.enemies.some((e) => e.scouted) ? ["§aスカウトした 仲間は 連れて かえった。"] : [])]); } catch {}   // disconnect: スカウトした 子・HPを もどって きた ときに セーブ
  if (B.players.length) log.push(`${x.p.name}は バトルから はなれた。`);
}

// v2.9.6: スカウト（モンスターズ式）。仲間が 1体ずつ 力を 見せつけて 成功率を ためていき、最後に 判定
// v2.9.12: スカウトできない 戦い（えらぶ 前に 知らせて ターンを むだに しない）
function scoutBlock(B, d) {
  if (B.master && B.master.arena) return B.master.mimic ? "§cハコダマシは スカウトできない！" : "§c物語の 戦いでは スカウトできない！";
  if (B.nushi !== null && B.nushi !== undefined) return "§c地方の 主は スカウトできない！";
  if (B.tmap) return "§c宝の 番人は スカウトできない！";
  if (B.bounty) return "§c賞金首は スカウトできない！";
  if (B.dgElite) return "§c石板の 番人（猛者）は スカウトできない！";
  if (d && d.box.length >= BOX_MAX) return "§c預かり所が いっぱいで スカウトできない！";
  return null;
}
// 第67版: スカウトの 相手が 仲間に した ことが あるか（化けて いる 相手は 出さない）
const ownMark = (d, e) => { try { if (e.lookAs || !e.m || !SPECIES[e.m.sp]) return ""; return Array.isArray(d.own) && d.own.includes(SPECIES[e.m.sp].idx) ? "§a●§r " : "§6NEW!§r "; } catch { return ""; } };
async function pickScout(B, p, d) {
  const rc = (() => { try { return rankCap(d); } catch { return 8; } })();
  const cand = alive(B.enemies);
  const s = await choose(p, "スカウト", statusText(B, ["誰を スカウトする？", "§7仲間が 1体ずつ 力を 見せつけて 成功率を ためる。弱らせる・眠らせる・魅了・道具で あがる", "§7ボス・レイドは むずかしい。物語の 上限より 2つ 以上 上の ランクは まだ 仲間に できない"]),
    [...cand.map((e) => [`${ownMark(d, e)}${e.name}\n§8目安 ${pityChance(B, e, p.id, rc, d)}%${e.angry ? " §cおこっている" : e.ail.charm ? " §d魅了中" : ""}`, MON_ICON(e.m.sp)]), ["§7やめる", ICON("i_back")]]);
  return s >= 0 && s < cand.length ? cand[s] : null;
}
// 第63版: 目安にも あきらめない 気持ちを 足す
function pityChance(B, e, owner, rc, d) { const base = scoutChance(B, e, owner, rc); if (!d || !d.spity || e.angry || rankIdx(e.m.sp) > rc + 1) return base; const pv = Math.min(24, d.spity[e.m.sp] || 0); return Math.round(Math.min(scoutCap(B, e, rc), base + pv)); }
async function scout(B, x, log, tPre = null) {
  const n0 = log.length;
  const { p, d } = x;
  const P = () => B.players.map((y) => y.p);
  if (B.master && B.master.arena) { log.push(B.master.mimic ? "§cハコダマシは スカウトできない！" : "§c物語の 戦いでは スカウトできない！"); await playFx(P(), null, log.slice(-1)); return; }
  if (B.nushi !== null && B.nushi !== undefined) { log.push("§c地方の 主は スカウトできない！"); await playFx(P(), null, log.slice(-1)); return; }
  if (B.tmap) { log.push("§c宝の 番人は スカウトできない！"); await playFx(P(), null, log.slice(-1)); return; }
  if (B.bounty) { log.push("§c賞金首は スカウトできない！"); await playFx(P(), null, log.slice(-1)); return; }
  if (B.dgElite) { log.push("§c石板の 番人（猛者）は スカウトできない！"); await playFx(P(), null, log.slice(-1)); return; }
  if (d.box.length >= BOX_MAX) { log.push("§c預かり所が いっぱいで スカウトできない！"); return; }
  const rc = (() => { try { return rankCap(d); } catch { return 8; } })();
  const cand = alive(B.enemies);
  const coopWait = (pr, dflt) => B.players.length > 1 ? Promise.race([pr.catch(() => dflt), new Promise((r) => system.runTimeout(() => r(dflt), 600))]) : pr.catch(() => dflt);
  let t = tPre && cand.includes(tPre) ? tPre : null;
  if (!t) {
    const s = await coopWait(choose(p, "スカウト", statusText(B, ["誰を スカウトする？", "§7仲間が 1体ずつ 力を 見せつけて 成功率を ためる。弱らせる・眠らせる・魅了・道具で あがる", "§7ボス・レイドは むずかしい。物語の 上限より 2つ 以上 上の ランクは まだ 仲間に できない"]),
      [...cand.map((e) => [`${ownMark(d, e)}${e.name}\n§8目安 ${pityChance(B, e, p.id, rc, d)}%${e.angry ? " §cおこっている" : e.ail.charm ? " §d魅了中" : ""}`, MON_ICON(e.m.sp)]), ["§7やめる", ICON("i_back")]]), -1);
    if (s < 0 || s >= cand.length) return;
    t = cand[s];
  }
  if (!ok(p)) return;
  if (B.raid && t.isBoss && t.raidTry && t.raidTry.has(p.id)) { log.push(`§c${t.name}は ${p.name}には もう 心を 閉ざして いる。`); await playFx(P(), null, log.slice(-1)); return "noop"; }
  if (t.angry) { log.push(`§c${t.name}は おこっていて 話を 聞かない！`); await playFx(P(), null, log.slice(-1)); return "noop"; }
  // 1体ずつ 見せつける
  const mine = alive(B.allies).filter((f) => f.owner === p.id);
  let sum = 0;
  for (const a of mine) {
    const n = scoutActs(a, true);   // 第66版: 複数回 行動の 子は その 回数ぶん
    for (let k = 0; k < n; k++) {
      const g = scoutGain(B, a, t); sum += g;
      anim(a.ent, `atk_${SPECIES[a.m.sp]?.motion || "slam"}`); popup(t.ent, `§d+${g}%`, 1.2);
      await playFx(P(), null, [`${a.name}${k ? `（${k + 1}回目）` : ""}は ${t.name}に 力を 見せつけた！ §dスカウト率 ${Math.round(sum * scoutMulOf(B, t, rc))}%`]);
    }
  }
  // v3.0 第63版: 失敗する たびに 次の 率が 上がる（同じ 種族・戦いを またいで +3%ずつ・最大 +24%。仲間に すると もどる）
  d.spity = d.spity || {}; const pity = rankIdx(t.m.sp) > rc + 1 ? 0 : Math.min(24, d.spity[t.m.sp] || 0);
  const ex = scoutExtra(B, t) + pity;
  const ch = Math.round(Math.min(scoutCap(B, t, rc), Math.max(1, (sum + ex - pity) * scoutMulOf(B, t, rc) + pity)));   // あきらめない 気持ちは 倍率の 外（表示どおり）
  const capNote = t.isBoss ? (B.raid ? `§7（レイドボスの 上限 ${raidCap(rc)}%・物語が 進むほど 上がる）` : "§7（ボスは 心を ひらきにくい）") : rankIdx(t.m.sp) > rc ? "§7（まだ この ランクは 手に おえない）" : "";
  await playFx(P(), null, [`§dスカウト率 ${ch}%${ex - pity ? ` §7（道具・特性など +${ex - pity}）` : ""}${pity ? ` §b（あきらめない 気持ち +${pity}）` : ""} ${capNote}`]);
  if (Math.random() * 100 < ch) {
    const nm = t.m; nm.id = nm.id || String(Date.now()); const st = calcStats(nm); nm.hp = st.hp; nm.mp = st.mp;
    nm.nm = SPECIES[nm.sp].name;
    addMon(d, nm);
    mark(d.own, nm.sp); if (d.spity) delete d.spity[nm.sp];
    anim(t.ent, "happy"); particle(t.ent, "minecraft:heart_particle", 1.5); heartFx(t.ent); sound(p, "random.levelup");
    const lines = [`§e${nm.nm}が 仲間に なりたそうに こちらを 見ている！`, `§e${nm.nm}が ${p.name}の 仲間に なった！${d.party.includes(nm) ? "" : "（預かり所へ）"}`];
    await playFx(P(), null, lines);
    log.push(...lines);
    t.hp = 0; t.scouted = true; t.out = true; B.scouted = true;   // out: 敵が 生きかえらせない
    // ふつうの 野生は その場で 勝ち。ボス戦・マスター戦は 仲間に した 子だけ ぬけて 戦いは つづく
    if (!B.boss && !B.master) B.scoutWin = true;
    if (t.isBoss) { B.bossScouted = true; B.scoutWin = true; }
    if (ok(t.ent) && t.ent !== B.enemies[0].ent) try { t.ent.remove(); } catch {}
    return;
  }
  log.push("しかし スカウトは 失敗した。");
  if (B.raid && t.isBoss) { (t.raidTry = t.raidTry || new Set()).add(p.id); log.push(`§c${t.name}は ${p.name}に 心を 閉ざした……（レイドボスの スカウトは 1人 1回）`); await playFx(P(), null, log.slice(n0)); return; }   // 第66版
  if (pity < 24 && !(rankIdx(t.m.sp) > rc + 1)) { d.spity[t.m.sp] = Math.min(24, (d.spity[t.m.sp] || 0) + 3); log.push(`§b次は スカウト率 +${d.spity[t.m.sp]}%（あきらめない 気持ち）`); }
  if (Math.random() < 0.15) { t.angry = true; log.push(`§c${t.name}は おこってしまった！ もう スカウトできない。`); anim(t.ent, "atk_jump"); }
  await playFx(P(), null, log.slice(n0));
}

async function finish(B, log) {
  for (const f of B.allies) { const st = calcStats(f.m); f.m.hp = hpBack(f); f.m.mp = Math.min(f.mp, st.mp); }
  { // v3.0: 終わる まぎわに ぬけた 人は ここで 外す（道具は わたせない ため ほうびは なし。仲間の ようすだけ もどって きた ときに セーブ）
    const gone = B.players.filter((x) => !ok(x.p));
    if (gone.length) { B.players = B.players.filter((x) => ok(x.p)); for (const x of gone) { for (const f of B.allies) if (f.owner === x.pid) f.m.hp = Math.max(1, f.m.hp); awayKeep(x, B, [B.result === "win" ? "§7仲間が 戦いを 終わらせた。" : "§7戦いは 終わって いた。", "§7（とちゅうで ぬけたので ごほうびは ありません）"]); } }
  }
  const defeated = B.enemies.filter((e) => !e.scouted && !e.fled && (B.result !== "scout" || e.hp <= 0));
  log.push("");
  if ((B.result === "win" || B.result === "scout") && B.master && B.master.ch) {
    // v2.6: やりこみの 戦い（ほうびは やりこみ側で。経験値・落とし物なし）
    for (const f of alive(B.allies)) anim(f.ent, "happy");
    log.push("§6§l勝利！");
    for (const x of B.players) { sound(x.p, "random.levelup", 1.2); x.plog = []; }
    await wait(10);
  } else if (B.result === "win" || B.result === "scout") {
    for (const f of alive(B.allies)) anim(f.ent, "happy");
    const n = B.players.length;
    const mt = B.master ? B.master.tier : -1;
    const exp = Math.floor(defeated.reduce((s, e) => s + expYield(e) * (e.isBoss ? 4 : 1), 0) * (1 + fieldBonus(B, "exp")) * (B.master ? 1.5 : 1));
    const foeLv = defeated.length ? Math.max(...defeated.map((e) => e.lv || 1)) : 1;   // v3.0: いちばん 強い 相手の レベルで くらべる
    const g = Math.floor(defeated.reduce((s, e) => s + goldYield(e) * (e.isBoss ? 6 : 1), 0) * (1 + fieldBonus(B, "gold")) * (B.master ? (B.master.cupRe ? 1 : 2 + mt) : 1));
    log.push(defeated.length ? `§6まものたちを やっつけた！ 経験値 ${exp}${n > 1 ? "（ひとりずつ）" : ""}` : "§6バトルが 終わった！");
    for (const x of B.players) {
      const { p, d } = x;
      // v3.0 第63版: 次の 石板の 主の Lv+2 より 上の 子は 経験値 1割（地方の 奥や ハガネ狩りで 上がりすぎない）
      const cap = expCapLv(d), eg = (lv) => (lv > cap ? 0.1 : expGapMul(lv, Math.min(foeLv, cap)));
      sound(p, "random.levelup", 1.2);
      d.gold += g; d.stats.wins++;
      const plog = [];
      if (g && d.gold >= GOLD_MAX) plog.push("§6お金が 上限（99,999,999）に 達した。§7これ以上は ふえない");   // 第63版
      if (g) plog.push(`§e${p.name}は ${gold(g)} を 手に入れた！`);
      // v2.9.10: 預かり所の 仲間にも 経験値（v3.0: 半分。設定で オフに できる）
      if (exp > 0 && d.box.length && p.getDynamicProperty("mrpg:noboxexp") !== true) {
        const bl = []; let up = 0;
        let spg = 0;
        for (const m of d.box.filter((m) => m.hp > 0 && !B.enemies.some((e) => e.m === m))) { const lv0 = m.lv, sp0 = m.spl || 0; for (const e of gainExp(m, Math.floor(exp * 0.5 * eg(m.lv)), bl)) { mark(d.own, e.sp); mark(d.seen, e.sp); } if (m.lv > lv0) { up++; spg += Math.max(0, (m.spl || 0) - sp0); } }
        if (up) plog.push(`§b預かり所の 仲間にも 経験値が 入った！ §7（${up}体が レベルアップ・§6スキルポイント 合計 +${spg}§7）`);
        const ev = bl.filter((l) => l.includes("進化") || l.includes("固有技")); plog.push(...ev.slice(0, 4)); if (ev.length > 4) plog.push(`§7…ほか ${ev.length - 4}件`);
      }
      for (const f of B.allies.filter((f) => f.owner === p.id && f.hp > 0)) {
        for (const m of gainExp(f.m, Math.floor(exp * eg(f.m.lv)), plog)) {
          mark(d.own, m.sp); mark(d.seen, m.sp);
          if (ok(f.ent)) { setLook(f.ent, m.sp, m); particle(f.ent, "minecraft:totem_particle", 1.5); levelFx(f.ent); anim(f.ent, "happy"); }
        }
      }
      // v2.9.13: 倒れた 仲間にも 半分の 経験値（倒れた ままで 回復は しない）
      const half = Math.floor(exp / 2);
      { // 第68版: 場に 出なかった 裏（スタンバイ）・ひっこめた 子にも 半分
        const onF = new Set(B.allies.filter((f) => f.owner === p.id && !f.out).map((f) => f.m));
        const rest = [...d.party, ...(d.bench || [])].filter((m) => m && m.hp > 0 && !onF.has(m));
        let un = 0; for (const m of rest) { const lv0 = m.lv; for (const e of gainExp(m, Math.floor(half * eg(m.lv)), plog)) { mark(d.own, e.sp); mark(d.seen, e.sp); } if (m.lv > lv0) un++; }
        if (rest.length && half > 0) plog.push(`§b裏の 仲間にも 経験値 ${half}（半分）${un ? `・§b${un}体が レベルアップ` : ""}`);
      }
      if (half > 0) {
        const down = B.allies.filter((f) => f.owner === p.id && f.hp <= 0 && !f.out && (d.party.includes(f.m) || (d.bench || []).includes(f.m)));
        for (const m of B.deadM || []) if ((d.party.includes(m) || (d.bench || []).includes(m)) && !down.some((f) => f.m === m)) down.push({ m });   // 第68版: 倒れて ひっこめた 子にも
        let dn = 0;
        for (const f of down) { const lv0 = f.m.lv; for (const m of gainExp(f.m, Math.floor(half * eg(f.m.lv)), plog)) { mark(d.own, m.sp); mark(d.seen, m.sp); } if (f.m.lv > lv0) dn++; }
        if (down.length) plog.push(`§7倒れた 仲間にも 経験値 ${half}（半分）${dn ? `・§b${dn}体が レベルアップ` : ""}`);
      }
      // v2.9.11: レベルアップで SPを 自動で 振る（設定）
      try { const mode = p.getDynamicProperty("mrpg:autosp"); if (mode) { const r = autoSP(d, mode); if (r.length) plog.push(`§bSPを 自動で 振った（${r.length}体）`); } } catch {}
      // v2.1: どの モンスターも かならず 2〜3個 落とす（素材・道具・お金・スキル書・スキルの 巻物）
      const got = {}; let pick_g = 0;
      const rcD = (() => { try { return rankCap(d); } catch { return 8; } })();
      B.wtc = wtCap(rcD);
      for (const e of defeated) {
        if (B.master && B.master.enma) continue;   // v3.0: エンマは 道具を 落とさない（鍔が もどるだけ）
        for (const dr of rollDrops(e, B)) {
          if (dr.gold) { pick_g += dr.gold; continue; }
          const id = dr.id; if (!id || !ITEMS[id]) continue;
          if (!storyLootOk(ITEMS[id], EGGS[id]?.ranks, rcD)) { pick_g += Math.max(5, Math.floor(goldYield(e) * 0.4)); continue; }   // v2.9.12: 物語より 先の 品は お金に かわる
          if (isGear(id)) { const gr = capRoll(p, id, rollGear(id, e.isBoss ? "boss" : "find")); giveGear(p, id, gr); plog.push(`§a${e.m.nm}は ${gearName(id, gr)}§aを 落としていった！`); continue; }
          got[id] = (got[id] || 0) + 1;
        }
      }
      if (pick_g) { d.gold += pick_g; plog.push(`§e落ちていた ${gold(pick_g)} を ひろった！`); }
      const gl = [];
      for (const [id, k] of Object.entries(got)) {
        giveItem(p, `mrpg:${id}`, k);
        const it = ITEMS[id];
        gl.push(`${it.kind === "skillbook" ? "§d" : it.kind === "sp" ? "§b" : it.kind === "material" ? "§3" : it.kind === "awaken" || it.kind === "evostone" ? "§6§l" : "§a"}${it.name}${k > 1 ? `×${k}` : ""}§r`);
      }
      if (gl.length) plog.push(`§a落とし物: ${gl.join("§7・")}`);
      // 特別な 報酬（石板・王のタマゴ・神のタマゴ）
      const rare = [];
      const roll = (id, ch) => { if (ITEMS[id] && Math.random() < ch && storyLootOk(ITEMS[id], EGGS[id]?.ranks, rcD)) rare.push(id); };   // v2.9.12: 特別な ほうびも 物語で しばる
      const hasSlab = B.slab !== null && B.slab !== undefined;
      if (!d.stats) d.stats = {};
      if (B.master && B.master.arena) {
        // 闘技場の 報酬は story.js で
      } else if (B.master) {
        d.stats.masters = (d.stats.masters || 0) + 1;
        roll(["sl0", "sl1", slabTierOk(d, 2) ? "sl2" : "sl1"][mt], [0.15, 0.3, 0.6][mt]);
        if (mt === 2) { roll("e_king", 0.005); roll("e_god", 0.001); }
        roll("i_dream", [0.005, 0.015, 0.04][mt]); roll("i_awaken", [0.003, 0.01, 0.03][mt]); roll(seedId(2), [0, 0.01, 0.04][mt]);
        const pt = [1, 2, 4][mt] + (B.master.rival ? 1 : 0);
        d.mpt = (d.mpt || 0) + pt;
        recordRival(d, B.master, true);
        addMasterRank(p.name, d);
        plog.push(`§b${B.master.name}に 勝った！ §eマスターポイント +${pt}§7（ごうけい ${d.mpt}pt・マスター 勝利 ${d.stats.masters}かい）`);
      } else if (hasSlab) {
        d.stats.slabs = (d.stats.slabs || 0) + 1;
        if (B.slab < 3 && slabTierOk(d, B.slab + 1)) roll(`sl${B.slab + 1}`, 0.1);
        if (B.slab === 2) roll("e_king", 0.01);
        if (B.slab === 3) { roll("e_king", 0.03); roll("e_god", 0.005); }
        roll("i_dream", 0.03 + B.slab * 0.02); roll("z_tog", 0.01 + B.slab * 0.015); roll("i_awaken", 0.01 + B.slab * 0.015);
      } else if (B.raid) { roll("e_king", 0.02); roll("e_god", 0.003); roll("i_dream", 0.04); roll("i_awaken", 0.02); roll("z_tog", 0.05); roll("z_tol", 0.08); roll(seedId(3), 0.1); roll(seedId(4), 0.01); }
      else if (B.boss) { roll("e_king", 0.01); roll("i_dream", 0.02); roll(seedId(3), 0.25); roll(seedId(2), 0.5); }
      for (const id of rare) {
        giveItem(p, `mrpg:${id}`);
        const big = id === "e_king" || id === "e_god" || id === "i_dream" || id === "i_awaken";
        plog.push(`${big ? "§6§l◆ " : "§d"}${ITEMS[id].name}を 手に入れた！${big ? " ◆" : ""}`);
        if (big) { for (const q of world.getAllPlayers()) q.sendMessage(`§6§l＊ ${p.name}が ${ITEMS[id].name}を 手に入れた！ ＊`); sound(p, "ui.toast.challenge_complete", 1); }
      }
      if (d.party.some((m) => m.spl > 0)) plog.push("§bスキルポイントが あるよ。ガイドブックから 振り分けよう。");
      for (const m of fixParty(d)) plog.push(`§e${m.nm}は 大きくなって パーティの 枠（4）に 入らないので 預かり所へ 移った。`);
      x.plog = plog;
    }
    if (B.master && !B.master.arena) { try { masterDefeated(B.master.npc, B.dim, B.players[0]?.p.name || ""); } catch {} }
    if (B.boss && !B.raid) {
      const key = B.enemies[0].ent?.getDynamicProperty?.("mrpg:site");
      if (key) {
        const r = getRuin(key);
        if (r) {
          // v2.5: マルチでも 遺跡の 進みは ひとりずつ（倒した 人を おぼえる）
          const by0 = r.by || [];
          // v2.9.7: 戦いの 終わりかけ（のこり 2ターン 未満）に 入った 人は 遺跡を 越えた ことに ならない
          const fair = (x) => (B.turn || 1) - (x.joinTurn || 1) >= 2 || (x.joinTurn || 1) <= 1;
          const fresh = B.players.some((x) => fair(x) && !by0.includes(x.p.id));   // v2.9.13: まだ 越えて いない 人が 勝った ときだけ 宝箱（同じ 遺跡を 何度も まわる ズルを ふせぐ）
          r.cleared = true; r.by = [...new Set([...by0, ...B.players.filter(fair).map((x) => x.p.id)])]; setRuin(key, r);
          if (fresh) { const ct = rollTier(6, 0); try { for (const c of chestCmds(Math.floor(r.x), r.y + 1, Math.floor(r.z), ct, B.dim.id)) cmd(B.players[0].p, c); } catch {}
          log.push(`§6さいだんに ${tierName(ct)}§6 が 現れた！`); } else log.push("§7（もう 越えた 遺跡なので さいだんの 宝箱は 出ない）");
          // v2.2.2: 遺跡を 越えた かず・石板・終の遺跡
          for (const x of B.players) {
            if (by0.includes(x.p.id)) { (x.plog = x.plog || []).push("§7（この 遺跡は もう 越えている）"); continue; }
            if (!fair(x)) { (x.plog = x.plog || []).push("§7（さいごの ほうで 加わったので、この 遺跡を 越えた ことには ならない）"); continue; }
            const s = qs(x.d); s.ruins++;
            (x.plog = x.plog || []).push(`§e§l星の かけらを 手に入れた！ §r§e（${Math.min(s.ruins, RUIN_NEED)}/${RUIN_NEED}）§7ノクス団より 先に 集めよう。8つで 終の遺跡が 開く`);   /* v2.9.13: 遺跡の ボスの 意味 */
                       const bsl = giveSlab(x.p, x.d, RUIN_SLAB[s.ruins]);
            if (bsl) (x.plog = x.plog || []).push(`§d§l遺跡の 奥に 古い 石板が 眠っていた……「${bsl.name}」`);
            if (s.ruins === RUIN_NEED) {
              const a = rfOn();
              if (a) try { x.p.setDynamicProperty("mrpg:navi", JSON.stringify({ name: "終の遺跡", x: a.x, z: a.z, dim: "minecraft:overworld" })); } catch {}
              (x.plog = x.plog || []).push("§6§l遺跡を 8つ 越えた！ §r§6ネクロス冥府領に §l終の遺跡§r§6 が 現れた。§7（コンパスが 案内する）");
            }
          }
        }
      }
    }
    await wait(20);
  } else if (B.result === "lose") {
    for (const x of B.players) {
      for (const m of [...x.d.party, ...(x.d.bench || [])]) m.hp = Math.max(1, m.hp);
      if (B.master) recordRival(x.d, B.master, false);
      if (B.dg && !B.master) try { x.p.setDynamicProperty("mrpg:dgout", true); } catch {}
      if (B.master && B.master.arena) { x.plog = []; continue; }
      const lost = B.surrender || B.timeup ? 0 : Math.floor(x.d.gold / 2);
      x.d.gold -= lost;
      x.plog = [`§c${x.p.name}は ${gold(lost)} を 落としてしまった…`];
      // v3.0 第63版: 野生・ボス・レイドに 負けたら 近くの 町の 宿屋へ（全回復）。物語の 戦いと 石板の 中は のぞく
      if (!B.master && !B.dg && !B.surrender && !B.timeup) { for (const m of [...x.d.party, ...(x.d.bench || [])]) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } B.innTo = B.innTo || new Set(); B.innTo.add(x.p.id); x.plog.push("§a近くの 町の 宿屋で 目を さました。§7（仲間は 全回復）"); }
    }
    log.push("§c仲間は 全滅した…", B.master && B.master.arena ? "§7（この 戦いでは お金は へらない）" : B.dg ? "§7石板の 外へ はじき出される……" : (B.innTo ? "§a近くの 町の 宿屋に はこばれた。" : "仲間は HP1で めをさました。宿屋で 回復しよう。"));
  }
  for (const h of battleHooks) for (const x of B.players) { try { h(B, x); } catch (e) { console.warn(`[MonsterRPG] hook: ${e}`); } }
  camClear(B.players.map((x) => x.p));   // v2.8: 結果の 画面より 先に カメラを 戻す
  if (B.master && B.master.dream) { for (const f of B.allies) { const st = calcStats(f.m); f.m.hp = st.hp; f.m.mp = st.mp; } for (const x of B.players) { if (ok(x.p)) try { save(x.p, x.d); } catch {} } return; }   // v2.9.12: 悪夢なので 仲間は 元気な まま（とちゅうで ぬけても 倒れた ままに ならない）
  await Promise.all(B.players.map(async (x) => {
    try { if (!(B.master && B.master.enma) && promoteBench(x.d) && ok(x.p)) x.p.sendMessage("§b表が 全員 倒れたので 裏と 入れかえた。"); } catch {}   /* 第69版 */
    if (x.d.out && !x.d.party.some((m) => m.id === x.d.out)) x.d.out = null;
    if (!ok(x.p)) { awayKeep(x, B, [...log.slice(-10), ...(x.plog || [])]); return; }   // v3.0: ぬけて いた 人は もどって きた ときに 結果を わたす
    save(x.p, x.d);
    // v2.9.9: 協力バトルで 1人が 結果の 画面を 開いた ままでも ほかの 人を 待たせない（最大 20秒）
    const nt = notice(x.p, "バトル 終了", statusText(B, [...log, ...(x.plog || [])], "a", true)).catch(() => {});
    if (B.players.length > 1) await Promise.race([nt, new Promise((r) => system.runTimeout(r, 400))]); else await nt;
  }));
  try { await riseJoin(B, defeated); } catch (e) { console.warn(`[MonsterRPG] rise: ${e}`); }
}
// v3.0: 戦いの とちゅうで ぬけた 人の 結果（ワールドが 開いて いる あいだ だけ 覚えて おき、もどって きたら セーブして 見せる）
const AWAY = new Map();
function awayKeep(x, B, lines) {
  let id = x.pid; try { id = id || x.p.id; } catch {} if (!id) return;
  const back = world.getAllPlayers().find((q) => q.id === id);
  if (back && ok(back)) return;   // もう もどって きて いる（古い データで 上書き しない）
  AWAY.set(id, { d: x.d, res: B.result, lines: lines.slice(-24), t: Date.now() });
}
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => {
  if (!initialSpawn) return; let id; try { id = p.id; } catch { return; } const a = AWAY.get(id); if (!a) return; AWAY.delete(id); if (Date.now() - (a.t || 0) > 3600000) return;   // 1時間より 古い ものは 使わない
  let snap0 = null; try { snap0 = JSON.stringify(load(p)); } catch {}   /* 第69版: もどった あとに 新しく 保存されて いたら 上書き しない */
  system.runTimeout(async () => {
    if (!ok(p)) { AWAY.set(id, a); return; }
    let same = true; try { same = JSON.stringify(load(p)) === snap0; } catch {}
    if (!same) { try { p.sendMessage("§7留守の あいだの 戦いの 結果は、もどった あとの 記録を 守る ため 反映しなかった。"); } catch {} return; }
    try { save(p, a.d); } catch (e) { console.warn(`[MonsterRPG] away save: ${e}`); return; }
    const head = a.res === "win" ? "§a留守の あいだに 仲間が 戦いに 勝った！" : a.res === "lose" ? "§c留守の あいだに 戦いに 負けて いた…" : "§7留守の あいだに 戦いが 終わって いた。";
    try { await notice(p, "留守の あいだの 戦い", [head, "", ...a.lines].join("\n")); } catch { try { p.sendMessage(head); } catch {} }
  }, 20);
}); } catch {}
// v2.9.12: 倒した モンスターが ときどき 起き上がって 仲間に なりたがる（ランクが 高いほど まれ）
export const RISE_RATE = { F: 0.12, E: 0.1, D: 0.08, C: 0.06, B: 0.045, A: 0.03, S: 0.018, SS: 0.008, X: 0.003 };
async function riseJoin(B, defeated) {
  if (B.result !== "win" || B.master || B.boss || B.raid || B.pvp || B.dg || B.dgElite || B.tmap || (B.slab !== null && B.slab !== undefined) || (B.nushi !== null && B.nushi !== undefined)) return;
  const x = B.players.find((y) => ok(y.p)); if (!x) return;
  const p = x.p; let d = load(p); if (!d) return;
  const rc = (() => { try { return rankCap(d); } catch { return 8; } })();
  for (const e of defeated) {
    if (!e || e.isBoss || e.guest || e.scouted || !e.m || !SPECIES[e.m.sp] || SPECIES[e.m.sp].hidden) continue;
    const rk = SPECIES[e.m.sp].rank;
    if (rankIdx(e.m.sp) > rc) continue;   // 物語の 上限より 上の ランクは 起き上がらない
    if (Math.random() >= (RISE_RATE[rk] || 0)) continue;
    if (ok(e.ent)) { standUp(e); anim(e.ent, "happy"); heartFx(e.ent); particle(e.ent, "minecraft:heart_particle", 1.5); }
    sound(p, "random.levelup", 1.3);
    if (d.box.length >= BOX_MAX && !canJoin(d, e.m)) { await notice(p, "仲間に なりたそうだ", `§d${e.name}が 起き上がり、仲間に なりたそうに こちらを 見ている……\n§c預かり所が いっぱいで 仲間に できない。`).catch(() => {}); return; }
    const ask0 = confirm(p, "仲間に なりたそうだ", `${ownMark(d, e)}§d${e.name}§fが 起き上がり、§d仲間に なりたそうに§f こちらを 見ている！\n§7ランク${rk}・Lv${e.lv}\n\n§f仲間に しますか？`, "仲間に する", "やめる").catch(() => false);
    /* v2.9.12: いっしょに 戦った 仲間を 待たせすぎない（20秒で やめる あつかい） */
    const yes = B.players.length > 1 ? await Promise.race([ask0, new Promise((res) => system.runTimeout(() => { try { SUI.uiManager?.closeAllForms(p); } catch {} res(false); }, 400))]) : await ask0;
    if (!yes || !ok(p)) { if (ok(e.ent)) anim(e.ent, "faint", true); return; }
    d = load(p); if (!d || (d.box.length >= BOX_MAX && !canJoin(d, e.m))) return;
    const nm = JSON.parse(JSON.stringify(e.m)); nm.id = `${Date.now()}${Math.floor(Math.random() * 1000)}`; nm.nm = SPECIES[nm.sp].name; nm.eq = { w: null, a: null, x: null }; nm.eqr = {};
    const st = calcStats(nm); nm.hp = st.hp; nm.mp = st.mp;
    addMon(d, nm); mark(d.own, nm.sp); mark(d.seen, nm.sp); save(p, d);
    try { p.sendMessage(`§e${nm.nm}が 仲間に なった！${d.party.includes(nm) ? "" : "（預かり所へ）"}`); } catch {}
    return;   // 1回の 戦いで 1体まで
  }
}

const DROP_W = { mat: 30, item: 26, gold: 16, book: 14, sp: 14 };
export function rollDrops(e, B) {
  const r = Math.min(8, rankIdxM(e.m));
  const n = e.isBoss ? 4 : 2 + (Math.random() < 0.5 ? 1 : 0);
  const out = [];
  const tot = Object.values(DROP_W).reduce((a, b) => a + b, 0);
  for (let i = 0; i < n; i++) {
    let x = Math.random() * tot, kind = "mat";
    for (const [k, w] of Object.entries(DROP_W)) { x -= w; if (x <= 0) { kind = k; break; } }
    if (kind === "mat") out.push({ id: matDrop(e, B && typeof B.wtc === "number" ? B.wtc : 3) });
    else if (kind === "gold") out.push({ gold: Math.max(5, Math.floor(goldYield(e) * 0.4)) });
    else if (kind === "sp") out.push({ id: r >= 7 && Math.random() < 0.04 ? "g_sp4" : r >= 6 && Math.random() < 0.15 ? "g_sp3" : r >= 3 && Math.random() < 0.35 ? "g_sp2" : "g_sp" });
    else if (kind === "book") {
      const god = SPECIES[e.m.sp].fam === "god" ? 0.25 : r >= 6 ? 0.04 : 0;
      const t = Math.random() < god ? 3 : r >= 4 && Math.random() < 0.25 ? 2 : 1;
      // 第66版: 専門の スキル書（強化・弱体・反射・耐性・物理系・武系・特質系・魔法系）。強い 子ほど 上の 段（SS・Xは まれに 皆伝）
      if (Math.random() < 0.35) { const ts = r >= 7 && Math.random() < 0.08 ? 4 : r >= 6 && Math.random() < 0.3 ? 3 : r >= 4 && Math.random() < 0.35 ? 2 : 1; const sp = SKILLBOOKS.filter((id) => ITEMS[id] && ITEMS[id].spec && ITEMS[id].tier === ts); if (sp.length) { out.push({ id: sp[Math.floor(Math.random() * sp.length)] }); continue; } }
      const pool = SKILLBOOKS.filter((id) => ITEMS[id] && ITEMS[id].tier === t && !ITEMS[id].spec);
      if (pool.length) out.push({ id: pool[Math.floor(Math.random() * pool.length)] });
    } else {
      const fam = SPECIES[e.m.sp].fam;
      if (Math.random() < 0.05 && ITEMS[`ev_${fam}`]) out.push({ id: `ev_${fam}` });
      else if (r >= 6 && Math.random() < 0.01) out.push({ id: "i_awaken" });
      else {
        // v2.4.4: 強い 敵は 能力の 実（大・秘果・神果）を 落とすことが ある
        const sd = r >= 7 && Math.random() < 0.003 ? 4 : r >= 6 && Math.random() < 0.015 ? 3 : r >= 5 && Math.random() < 0.06 ? 2 : 0;
        out.push({ id: sd ? seedId(sd) : dropFor(e, e.isBoss) });
      }
    }
  }
  return out;
}
function dropFor(e, boss) {
  const r = Math.min(7, ["F", "E", "D", "C", "B", "A", "S", "SS", "X"].indexOf(SPECIES[e.m.sp].rank));
  const maxTier = boss ? 3 : r <= 1 ? 0 : r <= 3 ? 1 : r <= 5 ? 2 : 3;
  const pool = Object.entries(ITEMS).filter(([id, it]) => (!it.noshop && (it.kind !== "talent" || boss || it.mode === "one") && (it.tier ?? 0) <= maxTier && !["egg", "slab", "dream", "skillbook", "sp", "awaken", "evostone", "material", "treasure", "rod"].includes(it.kind)) || id === "e_white" || (id === "e_bronze" && r >= 2) || (["e_red", "e_blue", "e_black", "e_green"].includes(id) && (r >= 4 || boss)) || (id === "e_silver" && boss) || (id === "e_rainbow" && boss && r >= 6));
  const weights = pool.map(([id, it]) => it.kind === "material" ? 0 : (["weapon", "armor", "acc"].includes(it.kind) ? 0.07 : 1) * (boss ? (it.tier >= 2 ? 6 : 1) : ["heal", "cure", "money"].includes(it.kind) ? 10 : it.kind === "seed" || it.kind === "lvup" ? 1 : it.kind === "egg" ? 2 : 3));
  let x = Math.random() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < pool.length; i++) { x -= weights[i]; if (x <= 0) return pool[i][0]; }
  return "c_herb";
}

// ---------- プレイヤー対戦 ----------
// v2.6: ルール（lv50: Lv50に そろえる / nodup: 同じ 種族なし / notop: SS・X なし）
export function applyRules(list, rules) {
  let L = list.map((m) => JSON.parse(JSON.stringify(m)));
  if (rules && rules.notop) L = L.filter((m) => !["SS", "X"].includes(SPECIES[m.sp]?.rank));
  if (rules && rules.nodup) { const seen = new Set(); L = L.filter((m) => (seen.has(m.sp) ? false : (seen.add(m.sp), true))); }
  if (rules && rules.lv50) for (const m of L) { m.lv = 50; if (SPECIES[m.sp]?.deity !== undefined) m.bonus = {}; }   /* 第69版: Lv50 ルールでは 神の 能力の 上乗せを 外す */
  for (const m of L) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; }
  return L;
}
async function startPvp0(pa, pb, rules) {
  const da = load(pa), db = load(pb);
  if (!da || !db) return;
  if ([...battles.values()].some((b) => b.players.some((y) => y.p.id === pa.id || y.p.id === pb.id))) { try { pa.sendMessage("§cどちらかが ほかの 戦いの 最中です。"); } catch {} return; }
  busy.add(pa.id); busy.add(pb.id); PVPSIDE.set(pb.id, "e");
  const temps = [];
  for (const p of [pa, pb]) try { p.addEffect("resistance", 20 * 3600, { amplifier: 255, showParticles: false }); } catch {}
  try {
    const A = pa.location, Bp = pb.location;
    let dx = Bp.x - A.x, dz = Bp.z - A.z;
    const len = Math.hypot(dx, dz) || 1; dx /= len; dz /= len;
    const perp = { x: -dz, z: dx };
    const mid = { x: (A.x + Bp.x) / 2, y: A.y, z: (A.z + Bp.z) / 2 };
    const ta = applyRules(da.party, rules), tb = applyRules(db.party, rules);
    if (!ta.length || !tb.length) { for (const p of [pa, pb]) p.sendMessage("§cルールに あう モンスターが いないので 対戦できない。"); return; }
    const B = { allies: ta.map((m) => fighter(m, "a")), enemies: tb.map((m) => fighter(m, "e")), pvp: true, nameA: pa.name, nameE: pb.name };
    for (const f of [...B.allies, ...B.enemies]) { f.mx = { ...f.mx, hp: Math.max(f.mx.hp, Math.min(9999, f.mx.hp * 2)) };   /* 第100版: 1万を こえる 子は そのまま */ f.hp = f.mx.hp; }   // v3.0 第63版: 対戦は HP 2倍（1ターンで 決まらない ように。HPは もどさない）
    B.players = [{ p: pa }, { p: pb }]; B.temps = temps; HUD.add(B);   // v2.7: 対戦でも「表示を なおす」が 使えるように
    for (const f of B.allies) f.owner = pa.id; for (const f of B.enemies) f.owner = pb.id;
    for (const f of [...B.allies, ...B.enemies]) { f.hp = f.mx.hp; f.mp = f.mx.mp; f.keep = true; }
    const ac = { x: mid.x - dx * 2.5, y: mid.y, z: mid.z - dz * 2.5 }, ec = { x: mid.x + dx * 2.5, y: mid.y, z: mid.z + dz * 2.5 };
    placeLine(ac, perp, B.allies.length, 2.2).forEach((pos, i) => summonFighter(pa, B.allies[i], pos, ec, temps));
    placeLine(ec, perp, B.enemies.length, 2.2).forEach((pos, i) => summonFighter(pb, B.enemies[i], pos, ac, temps));
    for (const f of B.enemies) f.ent.nameTag = `§c${f.name} Lv${f.lv} ${rankOf(f.m.sp)}`;
    const both = [pa, pb];
    let log = [`§l${pa.name} と ${pb.name} の 対戦が はじまった！`];
    battleStart(B, log);
    let winner = null;
    while (!winner) {
      // v2.9.12: 対戦でも 90秒 えらばない 人は おまかせ（相手を 待たせつづけない）
      const pvpCmd = async (pl, side) => {
        const pr = commandPhase(pl, B, side, log, true);
        const auto = new Promise((r) => system.runTimeout(() => r({ auto: true }), 1800));
        const c = await Promise.race([pr, auto]);
        if (!c || !c.auto) return c;
        B.cmdGen[pl.id] = (B.cmdGen[pl.id] || 0) + 1;
        try { SUI.uiManager?.closeAllForms(pl); } catch {}
        const mine = side === "a" ? B.allies : B.enemies;
        for (const f of mine) f.defend = false;
        log.push(`§7${pl.name}は 時間切れ（おまかせ）`);
        return { auto: true, acts: alive(mine).map((f) => ({ ...aiDecide(f, B), ai: true })) };
      };
      const [ca, cb] = await Promise.all([pvpCmd(pa, "a"), pvpCmd(pb, "e")]);
      log = [];
      if (ca.surrender && cb.surrender) { winner = "draw"; log.push("§7ふたりとも いなくなった"); break; }   /* 第69版 */
      if (ca.surrender || cb.surrender) { winner = ca.surrender ? pb : pa; log.push(`${(ca.surrender ? pa : pb).name}は こうさんした！`); break; }
      for (const [c, side, pl] of [[ca, "a", pa], [cb, "e", pb]]) if (c.item) {
        if (!takeItem(pl, `mrpg:${c.item.id}`)) { log.push(`§c${pl.name}の ${ITEMS[c.item.id].name}が 見つからない！`); continue; }
        const lines = []; const fx = battleItem(B, c.item.id, c.item.target, lines, side);
        await playFx(both, fx, lines); log.push(...lines);
      }
      const acts = expandActions([...ca.acts, ...cb.acts], B);
      if (B.trimNote && B.trimNote.length) { const tl = B.trimNote.splice(0); try { await playFx(both, null, tl); } catch {} log.push(...tl); }
      for (const a of actionOrder(acts, B)) {
      if (a.actor && a.actor.swapT === (B.turn || 1)) continue;   // 第68版: 入れかわった 子は この ターン 動けない
        const lines = [];
        const fx = runAction(B, a, lines);
        try { deityCheck(B, lines); } catch {}   // 第68版
        if (!fx) continue;
        await playFx(both, fx, lines);
        log.push(...lines);
        if (!alive(B.enemies).length || !alive(B.allies).length) break;
      }
      if (alive(B.enemies).length && alive(B.allies).length) {
        const lines = []; endOfTurn(B, lines);
        if (lines.length) { await playFx(both, null, lines); log.push(...lines); }
      }
      if (!alive(B.enemies).length && !alive(B.allies).length) { winner = "draw"; break; }   // v2.9.12: 相打ちは 引き分け
      if (!alive(B.enemies).length) winner = pa;
      else if (!alive(B.allies).length) winner = pb;
      if (!winner && (B.turn || 1) > 60) { winner = "draw"; log.push("§7§l時間切れ！ 60ターンで 決着が つかなかった"); break; }   // v2.9.12: 対戦にも 上限
    }
    B.ended = true;   // v2.9.12: 古い 画面を 無効に
    if (winner === "draw") {
      log.push("", "§e§l相打ち！ 引き分け", "§7どちらにも しょうきんは なし。");
      await Promise.all([ok(pa) ? notice(pa, "対戦 終了", statusText(B, log, "a", true)).catch(() => {}) : null, ok(pb) ? notice(pb, "対戦 終了", statusText(B, log, "e", true)).catch(() => {}) : null]);   /* 第69版 */
      return;
    }
    const prize = 300;
    const loser = winner === pa ? pb : pa;
    const dw = (ok(winner) && load(winner)) || (winner === pa ? da : db);   /* v2.9.14: 試合中に 届いた お金などを 消さない ように 読みなおす */
    // v2.9.12: しょうきんは 1日 5回まで・すぐ こうさんした 試合は なし（2人で お金を ふやせない ように）
    const today = new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 10); /* 日本の 日づけ */ if (!dw.pvpd || dw.pvpd.day !== today) dw.pvpd = { day: today, n: 0 };
    const paid = (B.turn || 1) >= 2 && dw.pvpd.n < 5; if (paid) { dw.pvpd.n++; dw.gold += prize; } dw.stats.pvp++;
    addRank(winner.name, true); addRank(loser.name, false);
    if (ok(winner)) try { save(winner, dw); } catch {}   /* v2.9.14: 勝った 人の ほうびだけ 保存 */
    for (const p of both) if (ok(p)) sound(p, "random.levelup");
    log.push("", `§6§l${winner.name} の 勝利！`, paid ? `§e${winner.name}は しょうきん ${gold(prize)} を 手に入れた！` : "§7（しょうきんは 1日 5回まで・2ターン 以上 戦った 試合だけ）", "§7対戦では HPや MPは 減りません。");
    await Promise.all([ok(pa) ? notice(pa, "対戦 終了", statusText(B, log, "a", true)).catch(() => {}) : null, ok(pb) ? notice(pb, "対戦 終了", statusText(B, log, "e", true)).catch(() => {}) : null]);
  } catch (err) {
    console.warn(`[MonsterRPG] pvp error: ${err}`);
  } finally {
    for (const e of temps) if (ok(e)) { particle(e, "minecraft:white_smoke_particle"); try { e.remove(); } catch {} }
    for (const p of [pa, pb]) { busy.delete(p.id); hudClear(p); try { p.removeEffect("resistance"); } catch {} }
    PVPSIDE.delete(pb.id);
  }
}

// ---------- v1.7: 模擬戦（自分の モンスター どうし）----------
// mode: "manual"=チームAを 指示（Bは オート） / "both"=両方 指示 / "watch"=観戦（両方 オート。しゃがむと 中断）
// 報酬・経験値なし。HP・MPは 減らない（コピーで 戦う）
async function startSpar0(p, teamA, teamB, mode, pos, opt = {}) {
  if (busy.has(p.id)) return null;
  busy.add(p.id);
  const temps = [];
  let winner = null;
  try { p.addEffect("resistance", 20 * 3600, { amplifier: 255, showParticles: false }); } catch {}
  try {
    const clone = (m) => JSON.parse(JSON.stringify(m));
    const B = { allies: teamA.map((m) => fighter(clone(m), "a")), enemies: teamB.map((m) => fighter(clone(m), "e")), pvp: true, spar: true, nameA: "チームA", nameE: "チームB", players: [], temps };
    if (opt.bet) { B.wbase = "sun"; B.wbaseT = 8; B.wonce = true; for (const f of [...B.allies, ...B.enemies]) f.smart = 1; }   // v2.9.3: 闘技場の 賭けは 晴れから
    for (const f of [...B.allies, ...B.enemies]) { f.hp = f.mx.hp; f.mp = f.mx.mp; f.keep = true; }
    const P = pos?.player || p.location;
    const ac = pos?.a || { x: P.x, y: P.y, z: P.z + 3 }, ec = pos?.b || { x: P.x, y: P.y, z: P.z + 15 };
    let dx = ec.x - ac.x, dz = ec.z - ac.z; const len = Math.hypot(dx, dz) || 1; dx /= len; dz /= len;
    const perp = { x: -dz, z: dx };
    const gapOf = (fs) => Math.max(2.4, ...fs.map((f) => ({ S: 1.8, M: 2.4, L: 4.8, G: 6.6 })[sizeOf(f.m)] || 2.4));
    placeLine(ac, perp, B.allies.length, gapOf(B.allies)).forEach((q, i) => summonFighter(p, B.allies[i], q, ec, temps));
    placeLine(ec, perp, B.enemies.length, gapOf(B.enemies)).forEach((q, i) => summonFighter(p, B.enemies[i], q, ac, temps));
    for (const f of B.allies) f.ent.nameTag = `§b${opt.bet ? "赤コーナー" : "A"}:${f.name} Lv${f.lv} ${rankOf(f.m.sp)}`;
    for (const f of B.enemies) f.ent.nameTag = `§c${opt.bet ? "青コーナー" : "B"}:${f.name} Lv${f.lv} ${rankOf(f.m.sp)}`;
    B.players = [{ p }]; hpTags(B); HUD.add(B); hudSend(p, "MQG", "");
    B.center = ec;
    const pl = [p];
    let log = [opt.bet ? `§l§6モンスター闘技場！§r §e${B.allies[0].name} §fvs §c${B.enemies[0].name}` : "§l§e模擬戦 スタート！§r §7（報酬なし・HPは 減りません）"];
    battleStart(B, log);
    sound(p, "raid.horn", 1.2);
    for (let turn = 1; !winner && turn <= 60; turn++) {
      let actsA, actsB;
      if (mode === "watch") {
        for (const x of pl) battleTitle(x, "", `§e${opt.bet ? "闘技場" : "模擬戦"} ${turn}ターン目`, 40), barSet(x, opt.bet ? `§f${B.allies[0].name} §7HP${B.allies[0].hp} §fvs ${B.enemies[0].name} §7HP${B.enemies[0].hp}` : "§7しゃがむと 中断");
        await waitT(16);
        try { if (!opt.bet && p.isSneaking) { winner = "stop"; break; } } catch {}
        actsA = alive(B.allies).map((f) => aiDecide(f, B)); actsB = alive(B.enemies).map((f) => aiDecide(f, B));
      } else {
        const ca = await commandPhase(p, B, "a", log, true);
        if (ca.surrender) { winner = "stop"; break; }
        let cb;
        if (mode === "both") { cb = await commandPhase(p, B, "e", log, true); if (cb.surrender) { winner = "stop"; break; } }
        else cb = { acts: alive(B.enemies).map((f) => aiDecide(f, B)) };
        log = [];
        for (const [c, side] of [[ca, "a"], [cb, "e"]]) if (c.item) {
          // 模擬戦では 道具は 減らない
          const lines = []; const fx = battleItem(B, c.item.id, c.item.target, lines, side);
          await playFx(pl, fx, lines); log.push(...lines);
        }
        actsA = ca.acts; actsB = cb.acts;
      }
      log = [];
      const acts = expandActions([...actsA, ...actsB], B);
      if (B.trimNote && B.trimNote.length) { const tl = B.trimNote.splice(0); try { await playFx(pl, null, tl); } catch {} log.push(...tl); }
      for (const a of actionOrder(acts, B)) {
      if (a.actor && a.actor.swapT === (B.turn || 1)) continue;   // 第68版: 入れかわった 子は この ターン 動けない
        const lines = [];
        const fx = runAction(B, a, lines);
        try { deityCheck(B, lines); } catch {}   // 第68版
        if (!fx) continue;
        await playFx(pl, fx, lines);
        log.push(...lines);
        if (opt.bet) hpTags(B);
        if (!alive(B.enemies).length || !alive(B.allies).length) break;
      }
      if (alive(B.enemies).length && alive(B.allies).length) {
        const lines = []; const kos = endOfTurn(B, lines);
        if (lines.length) { await playFx(pl, null, lines); for (const t of kos) koFx(t); log.push(...lines); }
      }
      if (!alive(B.enemies).length) winner = "A";
      else if (!alive(B.allies).length) winner = "B";
    }
    if (opt.bet) { opt.result = { winner, turns: B.turn || 1 }; }
    else {
    const res = winner === "A" ? "§b§lチームA の 勝ち！" : winner === "B" ? "§c§lチームB の 勝ち！" : winner === "stop" ? "§7模擬戦を 中断した。" : "§7時間切れ（引き分け）";
    sound(p, winner === "A" || winner === "B" ? "random.levelup" : "random.click");
    log.push("", res, "§7模擬戦では HP・MP・経験値は 変わりません。");
    await notice(p, "模擬戦 終了", statusText(B, log, "a", true));
    }
  } catch (err) {
    console.warn(`[MonsterRPG] spar error: ${err} ${err?.stack || ""}`);
  } finally {
    for (const e of temps) if (ok(e)) { particle(e, "minecraft:white_smoke_particle"); try { e.remove(); } catch {} }
    camClear([p]);
    hudClear(p);
    busy.delete(p.id);
    try { p.removeEffect("resistance"); } catch {}
  }
  return winner;
}

// ================= v2.9: 天候 =================
let WORLD_WX = "";
try { world.afterEvents.weatherChange.subscribe((ev) => { try { WORLD_WX = String(ev.newWeather || ""); } catch {} }); } catch {}
function natWeather(B, p, theme, master, inSky) {
  if (master && master.weather) return master.weather;
  if (inSky || theme === "arena") return "sun";   // 闘技場は かならず 晴れから はじまる
  if (!master && !B.boss && !B.dg && WX_HOOK.f) { let w2 = null; try { w2 = WX_HOOK.f(p); } catch {} if (w2) return w2; }   /* 第101版: 地方の 異常気象（空・闘技場は のぞく） */
  let w = WORLD_WX; try { if (typeof p.dimension.getWeather === "function") w = String(p.dimension.getWeather()); } catch {}
  const r = Math.random(), T = String(theme || ""), ow = p.dimension.id === "minecraft:overworld";
  if (ow && /thunder/i.test(w)) return "storm";
  if (ow && /rain/i.test(w)) return ["snow", "icepeak"].includes(T) ? "snow" : ["desert", "badlands"].includes(T) ? "sand" : "rain";
  if (["desert", "badlands"].includes(T)) return r < 0.45 ? "sand" : r < 0.7 ? "sun" : null;
  if (["snow", "icepeak"].includes(T)) return r < 0.55 ? "snow" : null;
  if (["swamp", "darkforest", "lush", "mushroom", "jungle"].includes(T)) return r < 0.4 ? "fog" : null;
  if (["nether", "crimson", "warped", "basalt", "volcano"].includes(T)) return r < 0.45 ? "sun" : null;
  if (["soulvalley", "deepdark", "hell", "end", "endcity"].includes(T)) return r < 0.5 ? "dark" : null;
  if (["sky", "shrine"].includes(T)) return r < 0.35 ? "holy" : r < 0.5 ? "wind" : null;
  if (["mountain", "savanna"].includes(T)) return r < 0.35 ? "wind" : null;
  if (["ruins", "beach"].includes(T)) return r < 0.4 ? "rain" : null;
  let night = false; try { const t = world.getTimeOfDay(); night = t > 13000 && t < 23000; } catch {}
  if (ow && night) return r < 0.3 ? "dark" : null;
  return r < 0.22 ? "sun" : r < 0.3 ? "wind" : null;
}
// 天候の 演出（ふりつづける 粒・かわった ときの 大きな 文字）
const WXP = {
  sun: [["wx_mote", [1, 0.85, 0.35], { vy: 1, spd: 0.8, scale: 1.4 }]], rain: [["wx_fall", [0.55, 0.7, 1], { vy: -1, spd: 15 }]],
  storm: [["wx_fall", [0.5, 0.6, 0.9], { vx: 0.3, vy: -1, spd: 18 }], ["wx_mote", [1, 1, 0.5], { vy: 0.2, spd: 0.3, scale: 0.8 }]],
  snow: [["wx_flake", [0.95, 0.97, 1], { vy: -1, spd: 1.8, scale: 1.3 }]], sand: [["wx_flake", [0.9, 0.75, 0.45], { vx: 1, vy: -0.15, spd: 7, scale: 0.9 }]],
  wind: [["wx_fall", [0.75, 1, 0.8], { vx: 1, vy: 0, vz: 0.25, spd: 16, scale: 0.8 }]], fog: [["wx_fog", [0.85, 0.88, 0.9], { vy: 0.05, spd: 0.25, scale: 1.2 }]],
  dark: [["wx_mote", [0.55, 0.25, 0.85], { vy: 0.4, spd: 0.5, scale: 1.2 }], ["wx_fog", [0.15, 0.08, 0.25], { vy: 0, spd: 0.15, scale: 1 }]],
  holy: [["wx_fall", [1, 0.97, 0.75], { vy: -1, spd: 4, scale: 1.6 }], ["wx_mote", [1, 1, 0.85], { vy: 1, spd: 0.6, scale: 1 }]],
};
function wxParticles(B) {
  const W = B.weather; if (!W || W.t <= 0 || !B.players.length) return;
  const c = B.stage ? { x: B.stage.cx + 0.5, y: B.stage.fy, z: B.stage.cz + 0.5 } : B.center; if (!c) return;
  const top = B.stage && B.stage.dome ? Math.min(B.stage.dome.top - 2, c.y + 11) : c.y + 10;
  for (const [id, col, v] of WXP[W.w] || []) {
    try {
      const m = new MolangVariableMap();
      m.setColorRGB("variable.color", { red: col[0], green: col[1], blue: col[2] });
      for (const k of ["vx", "vy", "vz", "spd", "scale"]) if (v[k] !== undefined) m.setFloat(`variable.${k}`, v[k]);
      B.dim.spawnParticle(`mrpg:${id}`, { x: c.x, y: id === "wx_fog" || id === "wx_mote" ? c.y + 1.5 : top, z: c.z }, m);
    } catch {}
  }
}
system.runInterval(() => { for (const B of battles.values()) if (!B.ended && B.weather) { if (isLite() && (system.currentTick % 60) >= 30) continue; wxParticles(B); } }, 30);
function wxShow(B) {
  if (!B.wxFx) return;
  const w = B.wxFx; B.wxFx = null;
  const W = WEATHER[w]; if (!W) return;
  for (const x of B.players) { const p = x.p; battleTitle(p, `${W[1]}§l${W[0]}`, `§f${W[3]}`, 40);   // v2.9.13: 「晴 晴れ」の ように 2回 出て いたので 名前だけに
    try { p.playSound(w === "storm" ? "ambient.weather.thunder" : w === "rain" ? "ambient.weather.rain" : "random.orb", { volume: 0.8, pitch: w === "sun" || w === "holy" ? 1.3 : 0.9 }); } catch {} }
  wxParticles(B);
}

// v2.9.12: 読みこみ 直し・ぬけた あとに のこった 戦いの あとしまつ
system.runInterval(() => {
  const live = new Set([...battles.keys()]);
  for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
    let L = []; try { L = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_battle"] }); } catch {}
    for (const e of L) {
      let bid; try { bid = e.getDynamicProperty("mrpg:bid"); } catch {}
      if (e.hasTag("mrpg_preview") || e.hasTag("mrpg_pet")) continue;
      if (typeof bid !== "number") { let ss; try { ss = e.getDynamicProperty("mrpg:sess"); } catch {} if (typeof ss === "number" && ss !== SESS) try { e.remove(); } catch {} continue; }   // 前に 開いた ときの 対戦・模擬戦の のこり
      if (live.has(bid)) continue;
      try {
        if (e.hasTag("mrpg_boss")) { e.removeTag("mrpg_battle"); e.setDynamicProperty("mrpg:bid", undefined); }
        else if (!e.hasTag("mrpg_pet")) e.remove();
      } catch {}
    }
  }
}, 600);
// v2.9.12: 戦いの 外で 透明の ままの 連れ歩き・ボスを もとに もどす（倒れて 塵に なった あと 読みこみ 直した とき など）
system.runInterval(() => {
  const live = new Set(); for (const B of new Set([...battles.values(), ...HUD])) if (!B.ended) for (const f of [...(B.allies || []), ...(B.enemies || []), ...(Array.isArray(B.temps) ? B.temps : [])]) { const en = f && (f.ent || f); if (en && en.id) try { live.add(en.id); } catch {} }   /* v2.9.12: 対戦・模擬戦の 子も さわらない */
  const dims = new Set(world.getAllPlayers().map((q) => { try { return q.dimension.id; } catch { return null; } }).filter(Boolean));   // 第69版: プレイヤーの いる 場所だけ
  for (const id of dims) {
    let L = []; try { L = world.getDimension(id).getEntities({ type: TYPE }); } catch {}
    for (const e of L) { try { if (live.has(e.id) || e.hasTag("mrpg_preview")) continue; if (e.getEffect("invisibility")) { e.removeEffect("invisibility"); anim(e, "reset"); } } catch {} }
  }
}, 200);
// v2.9.12: 戦って いない のに 戦い用の 長い 効果（無敵・水中呼吸・暗視など）が のこって いたら 外す
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try {
      if (busy.has(p.id) || [...battles.values()].some((B) => !B.ended && B.players.some((x) => x.p.id === p.id))) continue;
      if (hudBusy(p.id)) hudClear(p);   // v2.9.12: 戦いが 終わったのに のこった ログ・枠を 消す
      const r = p.getEffect("resistance"); if (r && r.amplifier >= 200) p.removeEffect("resistance");
      for (const id of ["fire_resistance", "water_breathing", "night_vision"]) { const e = p.getEffect(id); if (e && e.duration > 20 * 1800) p.removeEffect(id); }
    } catch {}
  }
}, 100);
world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => {
  if (!initialSpawn) return;
  system.runTimeout(() => { try { if (!busy.has(p.id)) { p.removeEffect("resistance"); p.removeEffect("water_breathing"); p.removeEffect("fire_resistance"); } } catch {} }, 40);   // 戦いの とちゅうで ぬけた ときの 無敵を 消す
});

// v2.9.13: 「バグを 直す」用: いま 戦いの 中か
// 戦いの 準備・本番・片づけの あいだ（対戦・模擬戦も）を 数える
const FLOW = new Map();
const flowIn = (ids) => { for (const id of ids) FLOW.set(id, (FLOW.get(id) || 0) + 1); };
const flowOut = (ids) => { for (const id of ids) { const n = (FLOW.get(id) || 1) - 1; if (n <= 0) FLOW.delete(id); else FLOW.set(id, n); } };
export async function startBattle(p, wild) { const ids = [p.id]; flowIn(ids); try { return await startBattle0(p, wild); } finally { flowOut(ids); } }
export async function startPvp(pa, pb, rules) {
  const ids = [pa.id, pb.id]; flowIn(ids); busy.add(pa.id); busy.add(pb.id);   // 第63版: 始まるまで ほかの 戦いや 画面を 開かせない
  // v3.0 第63版: 遠くの 相手とも 対戦できる（相手を 目の前に 呼び、終われば もとの 場所へ）
  let back = null;
  try { const A = pa.location, Bq = pb.location; if (pa.dimension.id !== pb.dimension.id || Math.hypot(A.x - Bq.x, A.z - Bq.z) > 24) { back = { x: Bq.x, y: Bq.y, z: Bq.z, dim: pb.dimension.id }; const r = (pa.getRotation().y * Math.PI) / 180; const to = { x: A.x, y: A.y, z: A.z };   /* 自分の いる 場所へ（壁や 崖に うまらない。並びは 対戦の 開始で ととのえる） */ void r; pb.addEffect("slow_falling", 100, { showParticles: false }); pb.teleport(to, { dimension: pa.dimension, facingLocation: A }); pb.setDynamicProperty("mrpg:bret", JSON.stringify(back)); await wait(10); } } catch {}
  busy.delete(pa.id); busy.delete(pb.id);   // startPvp0 が 自分で つける
  try { return await startPvp0(pa, pb, rules); } finally { flowOut(ids); busy.delete(pb.id); if (back) { try { if (ok(pb)) { pb.addEffect("slow_falling", 100, { showParticles: false }); pb.teleport({ x: back.x, y: back.y + 0.1, z: back.z }, { dimension: world.getDimension(back.dim) }); pb.setDynamicProperty("mrpg:bret", undefined); } } catch {} } }
}
export async function startSpar(p, teamA, teamB, mode, pos, opt = {}) { const ids = [p.id]; flowIn(ids); try { return await startSpar0(p, teamA, teamB, mode, pos, opt); } finally { flowOut(ids); } }
export function inBattle(p) {
  if (FLOW.has(p.id) || COOP_WAIT.has(p.id)) return true;
  for (const B of HUD) if (B.players.some((x) => x.p && x.p.id === p.id) || (B.pvpIds && B.pvpIds.includes(p.id))) return true;
  for (const B of battles.values()) if (B.players.some((x) => x.p && x.p.id === p.id) || (B.joinQueue || []).some((q) => q && q.id === p.id)) return true;
  return false;
}
// 戦いに 出て いる 子（連れ歩きも）の entity id
export function liveEntityIds() { const s = new Set(); for (const B of [...battles.values(), ...HUD]) for (const f of [...(B.allies || []), ...(B.enemies || [])]) try { if (f.ent) s.add(f.ent.id); } catch {} for (const B of [...battles.values(), ...HUD]) for (const e of B.temps || []) try { s.add(e.id); } catch {} return s; }
export function liveBattleIds() { const s = new Set(); for (const [id, B] of battles) if (!B.ended) s.add(id); return s; }

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { LOGR.delete(playerId); JOIN_HINT.delete(playerId); CH_PARTY.delete(playerId); } catch {} }); } catch {}
