/* 第125版: 世界が 滅びかける（第126版: 本14-6 で 幼なじみが 影の槍に 貫かれた あと 〜 終章）
   ■ 時期（cast.js の doomed・doomKnown・calmed・shunTown）
     doomed     = heroDead（本14-6）かつ ending 前。空が 暗く、赤い 月、灰が 降る（その 人にだけ。霧は fog @s・粒は その 人の まわりだけ）
     doomKnown  = 本16-1 の 声（voice）〜 本18-8（ルミナで 名を 三度 呼ぶ）。町の 人に 影が 取り憑き、石に なる。本18-8 で 石の 人は 戻る（calmDawn）
     迫害       = 本9〜本18-8。ノクト・グレイヴ・スノウ・ルミナ（cast.js SHUN）で 張り紙と 閉じた 店（道具屋・宿は 開く）
   ■ 町（その 人が いる 町だけ。重くしない）
     ・黒い もやの 人（うわごと）→ しばらくして 取り憑かれる（目が 黒く 光り、ふらふら 追って くる）→ さらに しばらくで 石に なる
     ・もやの 人に 話しかけると 持ちこたえる。町の 人の モンスターが 主人を 守る ことも ある
     ・石に なった 人は 記録 s.dm.st[町] に 残る（町ごとに 4人まで）。話しかけて「記録のインク」で 手帳に 名前を 書くと 戻る
     ・石に なったのが 店の 主人なら その 店は 閉まる（武器・防具・タマゴ・モンスター・釣り。道具屋・宿・預かり屋・案内人・闘技場は 閉めない ＝ どの 町も 全部は 閉まらない）
       戻すと 開き、お礼で しばらく 2割 安い。宿は 開いて いるが 2倍
     ・旅の 僧侶（無料の 祈り・インクを 少し 売る）。ミミは パンを 配る
     ・忘れ草の香（町で 使う）: その 町では しばらく 取り憑かれない ／ 影払いの鈴: 近くの 取り憑かれた 人が 止まる
   ■ 逃げる 場面: ルミナの 大通り（物語。r10c2 の あと、北の 門の 鐘まで）・ミラージュの 市場（t6）・ソウラの 川べり（t26）は より道
     つかまったら 入口へ もどる だけ（負けに しない）。鐘を 鳴らすと その 町の 影が 引く
   ■ 終章の あと（ending）: 空が 晴れ、戻して いない 人も 全員 戻る（記録を 消し、石像を 片づける）
   ■ マルチ: 出す 人と 石像は 持ち主（mrpg:dmown）だけの もの。記録・店・宿は その 人の セーブだけで 決まる */
import { world, system, MolangVariableMap } from "@minecraft/server";
import { ok, busy, choose, notice, confirm, ICON, setJob, sound, giveItem, takeItem, countItem, gold, EXH, showTitle, anim } from "./ui.js";
import { load, save } from "./store.js";
import { qs } from "./quest.js";
import { TOWNS, getTown, townPos, groundY } from "./structures.js";
import { CAST, doomed, shadowLive as doomKnown, calmed, shunned, shunTown, castTag, castJob, __cast } from "./cast.js";   /* 第126版(S5): この ファイルの doomKnown は「影が 宿って いる 間」（本16-1〜本18-8）*/
import { NPC_HOOKS } from "./npchook.js";
import { battleHooks, inBattle } from "./battle.js";
import { inScene, cineCard, camClear, camPut } from "./talk.js";
import { epAdd, epPending } from "./sagaep.js";
import { SGK } from "./saga.js";
import { calcStats } from "./core.js";
import { PSKIN } from "./skinjobs.js";
import { TYPE as MON, setLook } from "./field.js";
import { SPECIES, ORDER } from "./data.js";

const OW = () => world.getDimension("minecraft:overworld");
const tick = () => system.currentTick || 0;
const rm = (e) => { if (ok(e)) try { e.remove(); } catch {} };
const PJ = (k, d) => (PSKIN[k] ? PSKIN[k][0] : d);
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
const bar = (p, t) => { try { p.onScreenDisplay.setActionBar(t); } catch {} };
const pt = (n, q, m) => { try { if (m) OW().spawnParticle(n, q, m); else OW().spawnParticle(n, q); } catch {} };
const col = (r, g, b, o = {}) => { try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: r, green: g, blue: b }); for (const k in o) m.setFloat(`variable.${k}`, o[k]); return m; } catch { return null; } };
const sd = (s) => { if (!s.dm || typeof s.dm !== "object") s.dm = {}; return s.dm; };
export const DM_CLOSE = [0, 1, 4, 11, 14];   /* 閉まる ことが ある 店（道具屋 3・宿 2 などは 閉めない）*/
const SHOPN = { 0: "武器屋", 1: "防具屋", 4: "タマゴ屋", 11: "モンスター屋", 14: "釣り屋" };
const MAXST = 4;
let SEQ = 0;
/* 町（建って いる 町の 中心から 46マス）*/
export function townIn(loc, r = 46) {
  for (const t of TOWNS) { const g = getTown(t.id); if (g && g.built && Math.hypot(loc.x - g.x, loc.z - g.z) <= r) return { t, c: { x: g.x, y: g.y, z: g.z } }; }
  return null;
}
const gy = (x, z, y0) => { try { const y = groundY(OW(), Math.floor(x), Math.floor(z), Math.floor(y0) + 4); return typeof y === "number" && Math.abs(y - y0) < 9 ? y : null; } catch { return null; } };
/* その 人の 進み */
const sOf = (p) => { const d = load(p); return d ? qs(d) : null; };
export const isDoom = (p) => { const s = sOf(p); return !!s && doomed(s); };
export const isKnown = (p) => { const s = sOf(p); return !!s && doomKnown(s); };
/* 第124版: 滅びかけ 前の 人が 近くに いる（その 人には 終盤の 出来事を 見せない）*/
const preNear = (p) => { try { const l = p.location; for (const q of world.getAllPlayers()) if (q.id !== p.id && Math.hypot(q.location.x - l.x, q.location.z - l.z) < 64 && !isDoom(q)) return true; } catch {} return false; };
const busyP = (p) => { try { return busy.has(p.id) || inBattle(p) || inScene(p) || SGK.EVT.has(p.id); } catch { return true; } };
/* 町の 人の 名前（取り憑かれる 人）*/
const FN = ["ハンス", "マルタ", "ペトラ", "オスカー", "リナ", "ヨハン", "エマ", "トビ", "グレタ", "ニコ", "フリーダ", "カール", "ミナ", "ルッツ", "アンナ", "ボリス"];
const FR = ["粉屋の", "花売りの", "大工の", "洗たく屋の", "羊飼いの", "仕立て屋の", "郵便屋の", "ランプ屋の"];
const FSK = ["m6_paolo", "m6_genzo", "m6_kenta", "m6_otis", "m6_basil", "m6_tomas", "m6_mason", "m6_felix", "mimosa", "moka", "rosa", "hanna", "sayo", "m6_gramps"];
const MUT = ["……しって しまった……しって しまった……", "……きこえる……だれかの 声が……頭の 中で……", "……王冠……鍵……ああ、わすれたい……", "……こわい……目を とじても、文字が 見える……", "……だれか……わたしの 名前を……よんで……"];
/* ---------- 記録（石に なった 人）---------- */
export function stones(s, tid) { const m = sd(s).st || {}; return Array.isArray(m[tid]) ? m[tid] : []; }
export function closedShops(s, tid) { if (!doomed(s)) return []; return stones(s, tid).filter((x) => typeof x.k === "number" && x.k >= 0).map((x) => x.k); }
export function shopClosed(s, tid, job) { return DM_CLOSE.includes(job) && closedShops(s, tid).includes(job); }
const guarded = (s, tid) => { const m = sd(s); return (m.kou && m.kou[tid] > Date.now()) || !!(m.bell && m.bell[tid]); };
/* ---------- 空（暗い・赤い 月・灰・音の ない 雷）---------- */
const FOG = new Set();
const fogOn = (p) => { if (!FOG.has(p.id)) { cmd(p, "fog @s push mrpg:ruins_red mq_doom"); FOG.add(p.id); } };
const fogOff = (p) => { if (FOG.delete(p.id)) cmd(p, "fog @s remove mq_doom"); };
function sky(p, k) {
  const l = p.location;
  try { for (const q of world.getAllPlayers()) if (q.id !== p.id && Math.hypot(q.location.x - l.x, q.location.z - l.z) < 40 && !isDoom(q)) return; } catch {}
  let tod = 6000; try { tod = world.getTimeOfDay(); } catch {}
  const night = tod > 12500 && tod < 23500;
  if (night || k % 2 === 0) pt("mrpg:orb", { x: l.x + 30, y: l.y + 36, z: l.z - 22 }, col(night ? 0.85 : 0.55, 0.07, 0.05, { scale: night ? 10 : 7 }));
  if (k % 4 === 0) pt("mrpg:wx_mote", { x: l.x, y: l.y + 7, z: l.z }, col(0.45, 0.42, 0.42, { vx: 0.15, vy: -1, vz: 0, spd: 0.7, scale: 1.1 }));
  if (k % 240 === 120 && !busyP(p) && Math.random() < 0.6) { cmd(p, "camera @s fade time 0.03 0.05 0.35 color 90 25 25"); sound(p, "ambient.weather.thunder", 0.8, 0.25); }
}
/* ---------- 町の 人（もや → 取り憑き → 石）---------- */
const MINE = new Map();   /* p.id → Map(e.id → { e, st: "moya"|"tsuki"|"stone"|"run", t, nm, ri, g }) */
const mine = (p) => { let m = MINE.get(p.id); if (!m) { m = new Map(); MINE.set(p.id, m); } return m; };
const FREEZE = new Map();
function spawnFolk(p, at, nm, sk, kind) {
  try {
    const e = OW().spawnEntity("mrpg:npc", at); setJob(e, PJ(sk, 8));
    e.addTag("mrpg_npc"); e.addTag("mrpg_dm"); e.addTag(`mrpg_dm_${kind}`); e.setDynamicProperty("mrpg:dmown", p.id); e.setDynamicProperty("mrpg:dmnm", nm); e.nameTag = "";   /* 第124版: 名札は 出さない（ほかの 人に ネタバレ しない）。名前は 持ち主だけに 右下の 文字で */
    try { e.teleport(at, { facingLocation: p.getHeadLocation() }); } catch {}
    return e;
  } catch { return null; }
}
function ring(p, c, r0, r1) {
  for (let k = 0; k < 6; k++) { const a = Math.random() * Math.PI * 2, r = r0 + Math.random() * (r1 - r0), x = p.location.x + Math.cos(a) * r, z = p.location.z + Math.sin(a) * r; if (c && Math.hypot(x - c.x, z - c.z) > 44) continue; const y = gy(x, z, p.location.y); if (y !== null) return { x: Math.floor(x) + 0.5, y, z: Math.floor(z) + 0.5 }; }
  return null;
}
function newMoya(p, T) {
  const at = ring(p, T.c, 9, 15); if (!at) return;
  const nm = `${FR[SEQ % FR.length]} ${FN[(SEQ * 7 + 3) % FN.length]}`; SEQ++;
  const e = spawnFolk(p, at, nm, FSK[SEQ % FSK.length], "moya"); if (!e) return;
  const o = { e, st: "moya", t: tick() + 600, nm, tid: T.t.id, g: null };
  if (Math.random() < 0.35) {   /* 主人を 守る モンスター */
    try { const g = OW().spawnEntity("mrpg:monster", { x: at.x + 1, y: at.y, z: at.z + 0.6 }); g.addTag("mrpg_temp"); g.addTag("mrpg_dm"); g.setDynamicProperty("mrpg:dmown", p.id); try { g.triggerEvent("mrpg:make_battle"); } catch {} g.nameTag = `§a${nm.split(" ").pop()}の モンスター`; o.g = g; o.t += 300; } catch {}
  }
  mine(p).set(e.id, o);
}
function toTsuki(p, o) { o.st = "tsuki"; o.t = tick() + 400; try { o.e.setProperty("mrpg:mv", true); } catch {} sound(p, "mob.wither.ambient", 0.35); }
/* 第125版: 物語で 石に なった 人を 記録に 残す（町に 石像が 立ち、インクで 戻せる）*/
function stoneRec(p, tid, nm, sk, a) {
  if (!a || !Number.isFinite(a.x) || !Number.isFinite(a.z)) return;
  const d = load(p); if (!d) return; const s = qs(d), L = stones(s, tid); if (L.some((r) => r.n === nm) || L.length >= MAXST) return;
  const y0 = Number.isFinite(a.y) ? a.y : 70; let y = null; try { y = groundY(OW(), Math.floor(a.x), Math.floor(a.z), Math.floor(y0) + 12); } catch {}
  const m = sd(s); m.st = m.st || {}; m.st[tid] = [...L, { n: nm, k: -1, x: Math.floor(a.x), y: typeof y === "number" ? y : Math.floor(y0), z: Math.floor(a.z), sk }]; save(p, d);
}
function toStone(p, o, s, d) {
  const L = stones(s, o.tid); if (L.length >= MAXST) { rm(o.e); mine(p).delete(o.e.id); return; }
  const cl = closedShops(s, o.tid), free = DM_CLOSE.filter((j) => !cl.includes(j));
  const k = cl.length < 2 && free.length && Math.random() < 0.5 ? free[Math.floor(Math.random() * free.length)] : -1;
  const nm = k >= 0 ? `${SHOPN[k]}の ${o.nm.split(" ").pop()}` : o.nm;
  const l = o.e.location, rec = { n: nm, k, x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z), sk: FSK[(nm.length * 3) % FSK.length] };
  const m = sd(s); m.st = m.st || {}; m.st[o.tid] = [...L, rec]; save(p, d);
  for (let i = 0; i < 6; i++) pt(i % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", { x: l.x + (Math.random() - 0.5), y: l.y + i * 0.35, z: l.z + (Math.random() - 0.5) });
  sound(p, "dig.stone", 0.7);
  try { o.e.setProperty("mrpg:mv", false); o.e.setProperty("mrpg:act", 24); o.e.removeTag("mrpg_dm_tsuki"); o.e.addTag("mrpg_dm_st"); o.e.setDynamicProperty("mrpg:dmrec", `${o.tid}|${nm}`); } catch {}
  o.st = "stone"; o.nm = nm;
  try { showTitle(p, "§7§l石に なった", { subtitle: `§f${nm}${k >= 0 ? `　§c${SHOPN[k]}が 閉まった` : ""}`, fadeInDuration: 4, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  try { p.sendMessage(`§7${nm}が 石に なって しまった。§f話しかけて 名前を 呼び、§e記録のインク§f で 手帳に 書けば 戻せる`); } catch {}
}
function stepFolk(p, s, d, T) {
  const M = mine(p), now = tick(), fr = (FREEZE.get(p.id) || 0) > now;
  for (const [id, o] of M) {
    if (!ok(o.e)) { M.delete(id); rm(o.g); continue; }
    const l = o.e.location, dist = Math.hypot(l.x - p.location.x, l.z - p.location.z);
    if (dist > 60 || (T && o.tid !== T.t.id && o.st !== "stone")) { rm(o.e); rm(o.g); M.delete(id); continue; }
    if (o.st === "moya") {
      pt("mrpg:shadow_smoke", { x: l.x, y: l.y + 2.3, z: l.z }, col(0, 0, 0, { scale: 0.45 }));
      if (dist < 6 && now % 40 < 10) bar(p, `§8${o.nm}: §7${MUT[(Math.floor(now / 40) + o.nm.length) % MUT.length]}`);
      if (o.g && ok(o.g) && now % 20 < 10) pt("minecraft:villager_angry", { x: o.g.location.x, y: o.g.location.y + 1.2, z: o.g.location.z });
      if (now > o.t) {
        if (o.g && ok(o.g)) {   /* モンスターが 影を ふりはらって 主人を 守りきる */
          for (let i = 0; i < 5; i++) pt("minecraft:totem_particle", { x: l.x, y: l.y + 1 + i * 0.2, z: l.z });
          bar(p, `§a${o.g.nameTag.replace(/§./g, "")}が、主人の 前に 立ちはだかって 影を ふりはらった！`); sound(p, "random.levelup", 0.6);
          rm(o.e); rm(o.g); M.delete(id); continue;
        }
        if (guarded(s, o.tid)) { rm(o.e); M.delete(id); continue; }
        toTsuki(p, o);
      }
    } else if (o.st === "tsuki") {
      if (dist < 6 && now % 40 < 10) bar(p, `§8取り憑かれた ${o.nm}`);
      if (now % 20 < 10) pt("minecraft:soul_particle", { x: l.x, y: l.y + 1.65, z: l.z });
      if (now > o.t) { toStone(p, o, s, d); continue; }
      if (fr || dist < 1.2) {
        if (!fr && dist < 1.2) { try { p.applyKnockback((p.location.x - l.x) / (dist || 1), (p.location.z - l.z) / (dist || 1), 0.9, 0.3); p.addEffect("slowness", 30, { amplifier: 1, showParticles: false }); } catch {} bar(p, "§c取り憑かれた 人に つかまれた！ §7（ふりほどいた。はなれよう）"); }
        continue;
      }
      if (dist < 24) {
        const k = Math.min(0.55, dist - 1), nx = l.x + ((p.location.x - l.x) / dist) * k, nz = l.z + ((p.location.z - l.z) / dist) * k;
        let y = l.y; if (now % 8 < 4) { const g = gy(nx, nz, l.y); if (g !== null && Math.abs(g - l.y) <= 1.2) y = g; else continue; }
        try { o.e.teleport({ x: nx, y, z: nz }, { facingLocation: p.getHeadLocation() }); } catch {}
      }
    }
  }
}
/* 石像（記録から その 町だけ 出す）*/
function stepStatues(p, s, T) {
  const M = mine(p), L = stones(s, T.t.id), have = new Set([...M.values()].filter((o) => o.st === "stone" && o.tid === T.t.id).map((o) => o.nm));
  let n = 0;
  for (const r of L) {
    if (have.has(r.n) || n >= MAXST) continue;
    if (Math.hypot(r.x - p.location.x, r.z - p.location.z) > 40) continue;
    const e = spawnFolk(p, { x: r.x + 0.5, y: r.y, z: r.z + 0.5 }, r.n, r.sk || "m6_paolo", "st"); if (!e) continue;
    try { e.setProperty("mrpg:act", 24); e.setDynamicProperty("mrpg:dmrec", `${T.t.id}|${r.n}`); } catch {}
    M.set(e.id, { e, st: "stone", t: 0, nm: r.n, tid: T.t.id }); n++;
  }
  for (const o of M.values()) if (o.st === "stone" && ok(o.e) && tick() % 60 < 10) { const l = o.e.location; if (Math.hypot(l.x - p.location.x, l.z - p.location.z) < 4) bar(p, `§7石に なった ${o.nm} §8（話しかけると 戻せる かも）`); pt("minecraft:falling_dust_dragon_egg_particle", { x: l.x, y: l.y + 2, z: l.z }); }
}
function clearMine(p, all = true) { const M = MINE.get(p.id); if (!M) return; for (const [id, o] of M) { if (all || o.st !== "stone") { rm(o.e); rm(o.g); M.delete(id); } } }
/* 町に 入る ときの 短い 引きの 絵（暗い 空と 逃げる 人）。町ごとに 10分に 1回 */
const SEEN = new Map();
function townShot(p, T) {
  const k = `${p.id}:${T.t.id}`, now = Date.now(); if ((SEEN.get(k) || 0) > now) return; SEEN.set(k, now + 600000);
  const c = T.c, run = [];
  if (!preNear(p)) for (let i = 0; i < 2; i++) { const q = ring(p, c, 5, 9); if (!q) continue; const e = spawnFolk(p, q, "町の 人", FSK[(i + T.t.id.length) % FSK.length], "run"); if (e) { try { e.setProperty("mrpg:mv", true); } catch {} run.push(e); } }
  const P = p.location, from = { x: c.x + (P.x - c.x) * 0.3, y: c.y + 22, z: c.z + (P.z - c.z) * 0.3 + 14 };
  { const lk = { x: c.x, y: c.y + 2, z: c.z }; let f0 = null; for (const h of [22, 16, 11]) { const q = { ...from, y: c.y + h }; if (camClear(p, q, lk, null)) { f0 = q; break; } }   /* 第124版(cam): 見通しを 調べる（talk の 絵として 覚える）・暗転で 入る */
    if (f0) { cmd(p, "camera @s fade time 0 0.2 0.5 color 0 0 0"); camPut(p, f0, lk, 0, false); const f1 = { x: f0.x, y: f0.y - 8, z: f0.z - 6 }; camPut(p, f1, { x: P.x, y: P.y + 1, z: P.z }, 2.4) || camPut(p, f0, { x: P.x, y: P.y + 1, z: P.z }, 2.4); } }
  try { showTitle(p, `§7― ${T.t.name} ―`, { subtitle: "§8空は 暗く、店は 扉を 閉ざし、人々は 逃げまどう", fadeInDuration: 6, stayDuration: 44, fadeOutDuration: 12 }); } catch {}
  sound(p, "ambient.weather.thunder", 0.8, 0.3);
  let n = 0; const id = system.runInterval(() => {
    n++;
    for (const e of run) if (ok(e)) { const l = e.location, dx = l.x - c.x, dz = l.z - c.z, L = Math.hypot(dx, dz) || 1; try { e.teleport({ x: l.x + (dx / L) * 0.45, y: l.y, z: l.z + (dz / L) * 0.45 }, { facingLocation: { x: l.x + dx, y: l.y + 1.5, z: l.z + dz } }); } catch {} }
    if (n >= 15 || !ok(p) || inBattle(p) || inScene(p)) { system.clearRun(id); if (ok(p) && !inScene(p) && !inBattle(p)) { cmd(p, "camera @s fade time 0.2 0.1 0.3 color 0 0 0"); system.runTimeout(() => { for (const e of run) rm(e); if (ok(p) && !inScene(p) && !inBattle(p)) cmd(p, "camera @s clear"); }, 4); } else for (const e of run) rm(e); }
  }, 4);
}
/* ---------- 逃げる 場面（鐘まで）---------- */
const CHS = new Map();   /* p.id → { tid, st, bl, foes: [], c, story } */
const CHASE_T = { t0: "ルミナの 大通り", t6: "ミラージュの 市場", t26: "ソウラの 川べり" };
export const lumBell = () => { try { return SGK.garoSpot(); } catch { return null; } };
export const lumStart = () => { const g = getTown("t0"); const t = TOWNS.find((u) => u.id === "t0"); const c = g && g.built ? g : t ? townPos(t) : null; return c ? { x: Math.floor(c.x), y: null, z: Math.floor(c.z) + 40, nm: "ルミナの 南の 入口" } : null; };
function bellPost(q) { const y = gy(q.x, q.z, q.y ?? 64); if (y === null) return; try { OW().runCommand(`setblock ${Math.floor(q.x) + 2} ${y} ${Math.floor(q.z)} cobblestone_wall keep`); OW().runCommand(`setblock ${Math.floor(q.x) + 2} ${y + 1} ${Math.floor(q.z)} bell keep`); } catch {} }
function chaseStart(p, tid, st, bl, story = false) {
  if (CHS.has(p.id)) return;
  CHS.set(p.id, { tid, st, bl, foes: [], story, t0: tick() });
  bellPost(bl);
  try { showTitle(p, `§c§l${CHASE_T[tid] || "影の 町"}`, { subtitle: "§f取り憑かれた 人を よけて §e鐘§f まで 走ろう §7（つかまっても 入口に もどる だけ）", fadeInDuration: 6, stayDuration: 70, fadeOutDuration: 14 }); } catch {}
  sound(p, "mob.wither.ambient", 0.6);
}
function chaseEnd(p, ok2 = false) { const C = CHS.get(p.id); if (!C) return; for (const e of C.foes) rm(e); CHS.delete(p.id); if (ok2) return; }
function chaseStep(p) {
  const C = CHS.get(p.id); if (!C) return;
  if (inBattle(p) || inScene(p)) { for (const e of C.foes) rm(e); C.foes = []; return; }
  const P = p.location, db = Math.hypot(P.x - C.bl.x, P.z - C.bl.z), ds = Math.hypot(P.x - C.st.x, P.z - C.st.z);
  if (db < 3.5) {
    for (const e of C.foes) rm(e); C.foes = [];
    if (C.story) return;
    chaseEnd(p, true); bellWin(p, C.tid); return;
  }
  if (db > 140 && ds > 90) { chaseEnd(p); bar(p, "§7町から はなれた。（また 来れば 鐘まで 走れる）"); return; }
  C.foes = C.foes.filter(ok);
  const now = tick(), fr = (FREEZE.get(p.id) || 0) > now;
  if (now % 20 < 4 && preNear(p)) { for (const e of C.foes) rm(e); C.foes = []; return; }   /* 第124版: 滅びかけ 前の 人が 近くに いる ときは 追って くる 人を 出さない（ネタバレ）*/
  if (C.foes.length < 5 && now % 20 < 4 && !fr) {
    const dx = C.bl.x - P.x, dz = C.bl.z - P.z, L = Math.hypot(dx, dz) || 1, k = 7 + Math.random() * 9, sd2 = (Math.random() - 0.5) * 10;
    const x = P.x + (dx / L) * k - (dz / L) * sd2, z = P.z + (dz / L) * k + (dx / L) * sd2, y = gy(x, z, P.y);
    if (y !== null) { const e = spawnFolk(p, { x, y, z }, `${FR[SEQ % FR.length]} ${FN[SEQ % FN.length]}`, FSK[SEQ % FSK.length], "tsuki"); SEQ++; if (e) { try { e.setProperty("mrpg:mv", true); e.addTag("mrpg_dm_chase"); } catch {} C.foes.push(e); } }
  }
  for (const e of C.foes) {
    const l = e.location, dist = Math.hypot(l.x - P.x, l.z - P.z);
    if (dist > 30) { rm(e); continue; }
    if (now % 20 < 4) pt("minecraft:soul_particle", { x: l.x, y: l.y + 1.65, z: l.z });
    if (fr) continue;
    if (dist < 1.3) {   /* つかまった → 入口へ（負けでは ない）*/
      C.n = (C.n || 0) + 1; for (const f of C.foes) rm(f); C.foes = [];
      cmd(p, "camera @s fade time 0.2 0.4 0.4 color 0 0 0");
      system.runTimeout(() => { try { const y = gy(C.st.x, C.st.z, C.st.y ?? P.y) ?? P.y; p.teleport({ x: C.st.x + 0.5, y, z: C.st.z + 0.5 }, { facingLocation: { x: C.bl.x, y: y + 1, z: C.bl.z } }); } catch {} }, 8);
      try { showTitle(p, "§cつかまった！", { subtitle: "§7入口に もどされた。もう一度 鐘を めざそう（負けでは ない）", fadeInDuration: 4, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
      return;
    }
    const k = Math.min(0.62, dist - 1), nx = l.x + ((P.x - l.x) / dist) * k, nz = l.z + ((P.z - l.z) / dist) * k;
    let y = l.y; if (now % 8 < 4) { const g = gy(nx, nz, l.y); if (g === null || Math.abs(g - l.y) > 1.2) continue; y = g; }
    try { e.teleport({ x: nx, y, z: nz }, { facingLocation: p.getHeadLocation() }); } catch {}
  }
  if (now % 40 < 4) bar(p, `§e鐘まで あと ${Math.floor(db)}マス${C.n ? `  §7（つかまった ${C.n}回）` : ""}`);
}
const BELLW = { t6: ["セリーヌ", "ですわ", "{smile}鐘の 音……！ 影が 市場から 引いて いきますわ！"], t26: ["ユラ", "なのです", "{smile}鐘の 音なのです……！ 川の 灯りが、もどって きたのです"] };
function bellWin(p, tid) {
  const d = load(p); if (!d) return; const s = qs(d), m = sd(s); m.bell = m.bell || {}; const first = !m.bell[tid]; m.bell[tid] = 1;
  if (first) { giveItem(p, "mrpg:dm_ink", 2); giveItem(p, "mrpg:dm_kou", 1); d.gold += 3000; }
  save(p, d); clearMine(p, false);
  sound(p, "block.bell.hit", 1); system.runTimeout(() => sound(p, "block.bell.hit", 0.9), 14); system.runTimeout(() => sound(p, "block.bell.hit", 0.8), 28);
  for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; pt("minecraft:totem_particle", { x: p.location.x + Math.cos(a) * 3, y: p.location.y + 1.5, z: p.location.z + Math.sin(a) * 3 }); }
  try { showTitle(p, "§e§l鐘が 鳴った！", { subtitle: "§f影が この 町から 引いて いく", fadeInDuration: 6, stayDuration: 60, fadeOutDuration: 14 }); } catch {}
  const w = BELLW[tid], c = w && Object.values(CAST).find((x) => x.nm === w[0]);
  try { if (w) p.sendMessage(`${c ? c.col : "§e"}${w[0]}§f「${w[2].replace(/^\{[^}]*\}/, "")}」`); if (first) p.sendMessage("§a記録のインク×2・忘れ草の香・3000G を 受けとった"); } catch {}
}
/* ---------- 町の 外: 地面の 黒い ひび・夜に 遠くを 横切る 影の 群れ（見た目だけ。近くの 一人ぶん）---------- */
const PACK = new Map();
const SHSP = () => ORDER.filter((x) => SPECIES[x] && SPECIES[x].fam === "nether" && !SPECIES[x].hidden && SPECIES[x].sz !== "L").slice(0, 6);
function outside(p, k) {
  const l = p.location;
  if (k % 12 === 6) { const a = Math.random() * Math.PI * 2, r = 6 + Math.random() * 5, x0 = l.x + Math.cos(a) * r, z0 = l.z + Math.sin(a) * r, y = gy(x0, z0, l.y); if (y !== null) for (let i = 0; i < 5; i++) pt(i % 2 ? "minecraft:soul_particle" : "mrpg:shadow_smoke", { x: x0 + Math.cos(a + 1.57) * (i - 2) * 0.7, y: y + 0.1, z: z0 + Math.sin(a + 1.57) * (i - 2) * 0.7 }, i % 2 ? undefined : col(0, 0, 0, { scale: 0.35 })); }
  let tod = 6000; try { tod = world.getTimeOfDay(); } catch {}
  const night = tod > 12500 && tod < 23500, L = PACK.get(p.id);
  if (L) {
    L.n++; for (const g of L.e) if (ok(g)) { const q = g.location; try { g.teleport({ x: q.x + L.dx * 0.5, y: q.y, z: q.z + L.dz * 0.5 }, { facingLocation: { x: q.x + L.dx * 4, y: q.y + 1, z: q.z + L.dz * 4 } }); } catch {} if (L.n % 2) pt("mrpg:shadow_smoke", { x: q.x, y: q.y + 0.6, z: q.z }, col(0, 0, 0, { scale: 0.6 })); }
    if (L.n > 24) { for (const g of L.e) rm(g); PACK.delete(p.id); }
    return;
  }
  if (!night || k % 90 !== 45 || Math.random() > 0.4 || busyP(p)) return;
  const sp = SHSP(); if (!sp.length) return;
  const a = Math.random() * Math.PI * 2, dx = Math.cos(a + 1.57), dz = Math.sin(a + 1.57), E = [];
  for (let i = 0; i < 3; i++) { const x = l.x + Math.cos(a) * 20 - dx * 6 + i * 1.6, z = l.z + Math.sin(a) * 20 - dz * 6 + i * 1.2, y = gy(x, z, l.y); if (y === null) continue;
    try { const g = OW().spawnEntity(MON, { x, y, z }); g.addTag("mrpg_temp"); g.addTag("mrpg_dm"); g.setDynamicProperty("mrpg:dmown", p.id); setLook(g, sp[(i + k) % sp.length]); g.nameTag = ""; try { g.setProperty("mrpg:mv", true); } catch {} E.push(g); } catch {} }
  if (E.length) { PACK.set(p.id, { e: E, dx, dz, n: 0 }); bar(p, "§8……遠くを、影の 群れが 横切って いく。野生の モンスターたちが 息を ひそめて いる。"); sound(p, "mob.wither.ambient", 1, 0.25); }
}
/* ---------- 毎 10tick ---------- */
let K10 = 0;
const LASTT = new Map();
function loop() {
  K10++;
  let P = []; try { P = world.getAllPlayers(); } catch { return; }
  for (const p of P) {
    try {
      if (!ok(p) || p.dimension.id !== "minecraft:overworld") { fogOff(p); continue; }
      const d = load(p); if (!d) continue; const s = qs(d);
      if (K10 % 4 === 0 && shunned(s)) shunStep(p, s);   /* 第126版(S5): 迫害の 町（本9〜本18）*/
      if (!doomed(s)) { fogOff(p); if (MINE.has(p.id)) clearMine(p); if (PACK.has(p.id)) { for (const g of PACK.get(p.id).e) rm(g); PACK.delete(p.id); } if (CHS.has(p.id)) chaseEnd(p); if (s.ending && s.epx && s.epx.voice && !(s.dm && s.dm.over) && !busyP(p)) dawn(p, d); continue; }
      fogOn(p); sky(p, K10);
      if (!doomKnown(s)) {   /* 第126版(S5): 本18-8 で 名を 三度 呼んだ あとは 町に 影が 宿らない。石の 人は その 声で 戻る（決まり四）*/
        if (MINE.has(p.id) && K10 % 6 === 0) clearMine(p); if (CHS.has(p.id)) chaseEnd(p);
        if (calmed(s) && s.epx && s.epx.voice && !(s.dm && s.dm.calm) && !busyP(p)) calmDawn(p, d);
        continue;
      }
      const T = townIn(p.location);
      if (CHS.has(p.id)) { }
      else if (T && CHASE_T[T.t.id] && T.t.id !== "t0" && !(s.dm && s.dm.bell && s.dm.bell[T.t.id]) && !busyP(p) && Math.hypot(p.location.x - T.c.x, p.location.z - T.c.z) < 38) {
        const st = { x: Math.floor(p.location.x), y: Math.floor(p.location.y), z: Math.floor(p.location.z) }, dx = T.c.x - st.x, dz = T.c.z - st.z, L = Math.hypot(dx, dz) || 1;
        let bl = null; const bk = `mrpg:dmbell:${T.t.id}`; try { bl = JSON.parse(world.getDynamicProperty(bk) || "null"); } catch {}   /* 第124版: 鐘の 場所は 町ごとに 1つ（ワールドに 記録）*/
        if (!bl || typeof bl.x !== "number") { bl = { x: Math.floor(T.c.x + (dx / L) * 26), y: Math.floor(T.c.y), z: Math.floor(T.c.z + (dz / L) * 26) }; try { world.setDynamicProperty(bk, JSON.stringify(bl)); } catch {} }
        const k = `${p.id}:ch:${T.t.id}`; if ((SEEN.get(k) || 0) < Date.now()) { SEEN.set(k, Date.now() + 60000); chaseStart(p, T.t.id, st, bl); }
      } else if (T && T.t.id === "t0" && s.epx && s.epx.lchase && !s.epx.lbell) { const e = epPending(d); if (e && e.id === "r10c3") { const st = lumStart(), bl = lumBell(); if (st && bl) chaseStart(p, "t0", st, bl, true); } }
      const prev = LASTT.get(p.id); LASTT.set(p.id, T ? T.t.id : null);
      if (!T) { if (MINE.has(p.id) && K10 % 6 === 0) clearMine(p); outside(p, K10); continue; }
      if (PACK.has(p.id)) { for (const g of PACK.get(p.id).e) rm(g); PACK.delete(p.id); }
      if (prev !== T.t.id && !busyP(p) && !CHS.has(p.id)) townShot(p, T);
      if (CHS.has(p.id)) continue;
      { let sc = false; try { sc = inScene(p) || inBattle(p) || SGK.EVT.has(p.id); } catch {} if (sc) { if (K10 % 6 === 0) clearMine(p, false); continue; } if (busy.has(p.id)) continue; }
      if (preNear(p)) { if (MINE.has(p.id)) clearMine(p); continue; }
      stepStatues(p, s, T);
      stepFolk(p, s, d, T);
      if (K10 % 20 === 0 && !busyP(p) && !guarded(s, T.t.id) && stones(s, T.t.id).length < MAXST) { const live = [...mine(p).values()].filter((o) => o.st !== "stone").length; if (live < 3) newMoya(p, T); }
      if (K10 % 30 === 0 || prev !== T.t.id) monk(p, T);
    } catch (e) { if (K10 % 600 === 1) console.warn(`[MonsterRPG] collapse: ${e}`); }
  }
}
system.runInterval(loop, 10);
system.runInterval(() => { if (!CHS.size) return; for (const [pid, C] of CHS) { const p = world.getEntity(pid); if (!p || !ok(p)) { for (const e of C.foes) rm(e); CHS.delete(pid); continue; } try { chaseStep(p); } catch {} } }, 4);
/* 持ち主の いない 町の 人・石像を 片づける（30秒ごと）*/
function sweep() {
  try { const own = new Set(); for (const M of MINE.values()) for (const o of M.values()) { if (ok(o.e)) own.add(o.e.id); if (ok(o.g)) own.add(o.g.id); } for (const C of CHS.values()) for (const e of C.foes) if (ok(e)) own.add(e.id); for (const e of MONK.values()) if (ok(e)) own.add(e.id); for (const e of CRAFTERS.values()) if (ok(e)) own.add(e.id); for (const L of PACK.values()) for (const g of L.e) if (ok(g)) own.add(g.id);
    for (const e of OW().getEntities({ tags: ["mrpg_dm"] })) if (!own.has(e.id) && !e.hasTag("mrpg_dm_run")) rm(e); } catch {}
}
system.runInterval(sweep, 600);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { const M = MINE.get(playerId); if (M) for (const o of M.values()) { rm(o.e); rm(o.g); } MINE.delete(playerId); const C = CHS.get(playerId); if (C) for (const e of C.foes) rm(e); CHS.delete(playerId); FOG.delete(playerId); LASTT.delete(playerId); rm(MONK.get(playerId)); MONK.delete(playerId); const PK = PACK.get(playerId); if (PK) for (const g of PK.e) rm(g); PACK.delete(playerId); for (const [k, e] of CRAFTERS) if (k.startsWith(`${playerId}:`)) { rm(e); CRAFTERS.delete(k); } }); } catch {}
try { world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => { if (initialSpawn) FOG.delete(player.id); }); } catch {}
/* 終章の あと: 空が 晴れ、石に なった 人が みんな 戻る */
function dawn(p, d) {
  const s = qs(d), m = sd(s), n = Object.values(m.st || {}).reduce((a, L) => a + (Array.isArray(L) ? L.length : 0), 0);
  m.st = {}; m.over = 1; save(p, d); clearMine(p); fogOff(p);
  try { showTitle(p, "§e§l空が 晴れた", { subtitle: n ? "§fけさの 影で 石に なった 人たちが、戻って きた" : "§f世界に、朝が もどって きた", fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
  sound(p, "random.levelup", 0.8);
}
/* 第126版(S5): 本18-8 の あと（空は まだ 暗い）。影で 石に なった 町の 人が 戻り、閉まった 店が 開く */
function calmDawn(p, d) {
  const s = qs(d), m = sd(s), n = Object.values(m.st || {}).reduce((a, L) => a + (Array.isArray(L) ? L.length : 0), 0);
  m.st = {}; m.calm = 1; save(p, d); clearMine(p);
  if (n) { try { showTitle(p, "§e§l名が 届いた", { subtitle: "§fルミナで 呼ばれた 名の 声が、各地の 石の 人を 呼び戻した", fadeInDuration: 10, stayDuration: 70, fadeOutDuration: 20 }); } catch {} sound(p, "random.levelup", 0.6); }
}
/* 第126版(S5): 迫害の 町（cast.js の SHUN）。町に 入った とき 1回だけ 張り紙・閉じた 門を 見せる（10分に 1回まで）*/
const SHN = new Map();
function shunStep(p, s) {
  if (busyP(p)) return;
  const T = townIn(p.location), id = T ? T.t.id : null, W = id ? shunTown(s, id) : null;
  if (!W) { if (!id) SHN.delete(p.id); return; }
  const k = `${p.id}:${id}`, now = Date.now(); if (SHN.get(p.id) === id || (SEEN.get(k) || 0) > now) return;
  SHN.set(p.id, id); SEEN.set(k, now + 600000);
  try { showTitle(p, `§7― ${T.t.name} ―`, { subtitle: `§8${W.why}`, fadeInDuration: 6, stayDuration: 50, fadeOutDuration: 12 }); } catch {}
  bar(p, "§7町の 人が 目を そらし、戸を 閉めた。§8（武器・防具・タマゴ・モンスター・釣りの 店は 売って くれない。道具屋と 宿は 開いて いる）");
  sound(p, "random.door_close", 0.8, 0.8);
}
/* ---------- 旅の 僧侶（無料の 祈り・インクを 少し 売る）---------- */
const MONK = new Map();
function monk(p, T) {
  let e = MONK.get(p.id); if (e && ok(e) && Math.hypot(e.location.x - p.location.x, e.location.z - p.location.z) < 60) return; rm(e);
  const q = { x: T.c.x + 7, z: T.c.z + 7 }, y = gy(q.x, q.z, T.c.y); if (y === null) return;
  try { e = OW().spawnEntity("mrpg:npc", { x: q.x + 0.5, y, z: q.z + 0.5 }); setJob(e, PJ("m6_brother", 8)); e.addTag("mrpg_npc"); e.addTag("mrpg_dm"); e.addTag("mrpg_dm_monk"); e.setDynamicProperty("mrpg:dmown", p.id); e.nameTag = "§e旅の 僧侶"; MONK.set(p.id, e); } catch {}
}
const today = () => Math.floor((Date.now() + 9 * 3600000) / 86400000);   /* explore.js の dayNo と 同じ */
async function monkTalk(p) {
  const d = load(p); if (!d) return; const s = qs(d), m = sd(s);
  const pr = (m.pray || 0) > Date.now(), b = m.buy && m.buy.d === today() ? m.buy.n : 0;
  const c = await choose(p, "旅の 僧侶", "§f「影が 世界を おおっても、名を 呼ぶ 声は 消えません。……わたしに できる ことを しましょう」", [[pr ? "§8祈りを うける（少し 休んで から）" : "§l祈りを うける §a（無料）\n§7仲間の HPと MPが 全回復", ICON("i_inn")], [b >= 3 ? "§8記録のインク（今日は もう ない）" : `記録のインクを 買う §e500\n§7今日 あと ${3 - b}こ`, ICON("i_shop")], ["話を 聞く", ICON("i_help")], ["§7戻る", ICON("i_back")]]);
  const d2 = load(p); if (!d2) return; const s2 = qs(d2), m2 = sd(s2);
  if (c === 0 && !pr) { for (const x of [...d2.party, ...(d2.bench || [])]) { const st = calcStats(x); x.hp = st.hp; x.mp = st.mp; } m2.pray = Date.now() + 300000; save(p, d2); sound(p, "random.levelup", 0.7); await notice(p, "旅の 僧侶", "§f「……どうか、あなたの 旅に 光を」\n§a仲間が 全回復した。"); }
  else if (c === 1 && b < 3) { if (d2.gold < 500) { await notice(p, "旅の 僧侶", "§cお金が たりません。"); return; } d2.gold -= 500; m2.buy = { d: today(), n: b + 1 }; save(p, d2); giveItem(p, "mrpg:dm_ink", 1); sound(p, "random.orb"); await notice(p, "旅の 僧侶", "§f「石に なった 人の 名を、どうか 呼んで あげて ください」\n§a記録のインクを 手に 入れた。"); }
  else if (c === 2) await notice(p, "旅の 僧侶", ["§f「空から 声が して、みんなが 知って しまった。……影は、知った 者の 心に 宿るのです」", "§f「石に なった 人には、話しかけて 名前を 呼び、§e記録のインク§f で 手帳に 書いて あげて ください。影が はがれます」", "§f「インクは、ほたるの 里 §eルミエ§f の 薬師見習いの 子が 作って いる と 聞きます。§e影のしずく§f を 持って いけば……」", "§f「町の 広場で §e忘れ草の香§f を たけば、その 町の 人は しばらく 影の 話を 忘れられます」"].join("\n"));
}
/* ---------- 町の 職人（交換）。ほかの 担当の 人物（CAST の 名前）に 話しかけると 出る。いなければ その 町に 職人を 出す ---------- */
const CRAFT = {
  "ピピ": { tid: "t17", role: "薬師見習い", gobi: "なのだ", skin: "m6_pip", say: "{smile}ほたる苔と 影のしずくを 煮つめると、インクが できるのだ！ ……石に なった 人の 名前を 書く ための インクなのだ", give: "dm_ink", need: [["dm_drop", 2]] },
  "ハッカ婆": { tid: "t17", role: "里長", gobi: "ですのう", skin: "baba", say: "{closed}忘れ草は、つらい 記憶を 少しの 間 ねむらせる 草ですのう。……影の 話も、ねむらせて しまいましょう", give: "dm_kou", need: [["dm_drop", 1], ["c_herbs", 1]] },
  "トンボ": { tid: "t30", role: "鍛冶見習い", gobi: "ッス", skin: "tetsu", say: "{angry}影の 鍵の 打ち方を、親方と まねして みたッス！ 鳴らすと 影が すくむ 鈴ッス！", give: "dm_bell", need: [["dm_drop", 1], ["minecraft:iron_ingot", 3]] },
  "ゲン": { tid: "t30", role: "親方", gobi: "でい", skin: "m6_bolt", say: "{closed}鉄を 三つ 持って きな。トンボと 二人で 鈴を 打って やるでい。……泣いてる ひまは ねえんでい", give: "dm_bell", need: [["dm_drop", 1], ["minecraft:iron_ingot", 3]] },
};
const iid = (id) => (id.includes(":") ? id : `mrpg:${id}`);
const inm = (id) => ({ dm_drop: "影のしずく", c_herbs: "癒しの花束", "minecraft:iron_ingot": "鉄インゴット", dm_ink: "記録のインク", dm_kou: "忘れ草の香", dm_bell: "影払いの鈴" })[id] || id;
export async function craftTalk(p, nm, e = null, castId = null) {
  const R = CRAFT[nm]; if (!R) return false;
  const have = R.need.map(([id, n]) => [id, n, countItem(p, iid(id))]), can = have.every(([, n, h]) => h >= n);
  const c = await choose(p, `${R.role} ${nm}`, [`§e${nm}§f「${R.say.replace(/^\{[^}]*\}/, "")}」`, "", `§f作れる もの: §e${inm(R.give)}`, `§7いる もの: ${have.map(([id, n, h]) => `${h >= n ? "§a" : "§c"}${inm(id)} ${h}/${n}`).join("§7・")}`].join("\n"), [[can ? `§l${inm(R.give)}を 作って もらう` : "§8材料が たりない", ICON("i_shop")], ["話を 聞く", ICON("i_help")], ["§7戻る", ICON("i_back")]]);
  if (c === 0 && can) { if (!R.need.every(([id, n]) => countItem(p, iid(id)) >= n)) { await notice(p, nm, "§c材料が たりない……"); return true; } const got = []; for (const [id, n] of R.need) { if (!takeItem(p, iid(id), n)) { for (const [j, m] of got) giveItem(p, iid(j), m); return true; } got.push([id, n]); }   /* 第124版: 全部 とれなければ 返す */
    giveItem(p, iid(R.give), 1); sound(p, "random.anvil_use", 0.6); await notice(p, nm, `§a${inm(R.give)}を 手に 入れた！`); }
  else if (c === 1) { if (castId && e && __cast.castTalk) { busy.delete(p.id); try { await __cast.castTalk(p, e, castId); } finally { busy.add(p.id); } } else await notice(p, nm, `§f「${R.say.replace(/^\{[^}]*\}/, "")}」`); }
  return true;
}
const CRAFTERS = new Map();
function crafters(p, T) {
  for (const [nm, R] of Object.entries(CRAFT)) {
    if (R.tid !== T.t.id || Object.values(CAST).some((c) => c.nm === nm && c.town)) continue;
    const k = `${p.id}:${nm}`; let e = CRAFTERS.get(k); if (e && ok(e)) continue;
    const i = Object.keys(CRAFT).indexOf(nm), q = { x: T.c.x - 8 + i * 2.5, z: T.c.z + 9 }, y = gy(q.x, q.z, T.c.y); if (y === null) continue;
    try { e = OW().spawnEntity("mrpg:npc", { x: q.x, y, z: q.z }); setJob(e, PJ(R.skin, 8)); e.addTag("mrpg_npc"); e.addTag("mrpg_dm"); e.addTag("mrpg_dm_craft"); e.setDynamicProperty("mrpg:dmown", p.id); e.setDynamicProperty("mrpg:dmnm", nm); e.nameTag = `§e${R.role} ${nm}`; CRAFTERS.set(k, e); } catch {}
  }
}
const craftOff = (pid) => { for (const [k, e] of CRAFTERS) if (k.startsWith(`${pid}:`)) { rm(e); CRAFTERS.delete(k); } };
system.runInterval(() => { try { for (const p of world.getAllPlayers()) { const s = sOf(p); const T = s && doomKnown(s) ? townIn(p.location) : null; if (T && (T.t.id === "t17" || T.t.id === "t30")) crafters(p, T); else craftOff(p.id); } } catch {} }, 200);
/* ---------- 話しかける ---------- */
/* 第124版: ミミの パンは 1日 1回（ワールドを 開きなおしても のこる）*/
async function restore(p, e) {
  let rec = ""; try { rec = String(e.getDynamicProperty("mrpg:dmrec") || ""); } catch {}
  const [tid, nm] = rec.split("|"); if (!tid || !nm) return;
  const has = countItem(p, "mrpg:dm_ink");
  const c = await choose(p, `石に なった ${nm}`, [`§7冷たい 石の 顔。目だけが、まだ 何かを 見て いる ような 気が する。`, "", `§f旅の 手帳に §e${nm}§f の 名前を 書けば、影が はがれる かも しれない。`, `§7記録のインク: ${has ? `§a${has}こ` : "§cない（ルミエの ピピ・旅の 僧侶）"}`].join("\n"), [[has ? `§l名前を 呼んで、手帳に 書く\n§7記録のインクを 1つ 使う` : "§8インクが ない", ICON("i_zukan")], ["§7そっと して おく", ICON("i_back")]]);
  if (c !== 0 || !has) return;
  if (!takeItem(p, "mrpg:dm_ink", 1)) return;
  const d = load(p); if (!d) return; const s = qs(d), m = sd(s), L = stones(s, tid), r = L.find((x) => x.n === nm);
  m.st = m.st || {}; m.st[tid] = L.filter((x) => x !== r); m.back = (m.back || 0) + 1; s.techo = [...new Set([...(s.techo || []), nm])];
  if (nm === "パン屋の 親方") { s.epx = s.epx || {}; s.epx.mimiDad = 1; }
  if (r && r.k >= 0) { m.thx = m.thx || {}; m.thx[tid] = Date.now() + 600000; }
  save(p, d);
  sound(p, "item.book.page_turn", 1);
  const l = e.location;
  for (let i = 0; i < 10; i++) pt(i % 2 ? "minecraft:villager_happy" : "minecraft:totem_particle", { x: l.x + Math.cos(i) * 0.7, y: l.y + 0.2 + i * 0.2, z: l.z + Math.sin(i) * 0.7 });
  try { e.nameTag = `§f${nm}`; e.setProperty("mrpg:act", 0); e.removeTag("mrpg_dm_st"); } catch {}
  const M = MINE.get(p.id); if (M) M.delete(e.id);
  sound(p, "random.levelup", 0.8);
  await notice(p, nm, [`§7あなたは 手帳に「§f${nm}§7」と 書いた。`, "§7石の ひびから 光が こぼれ、色が もどって いく。", "", `§f${nm}「……あれ？ わたし……名前を、呼ばれた 気が して……」`, `§f${nm}「……ありがとう。あなたの 手帳に、わたしの 名前が あるんだね」`, ...(r && r.k >= 0 ? ["", `§a${SHOPN[r.k]}が また 開いた！ §7（お礼で しばらく 2割 安い）`] : [])].join("\n"));
  system.runTimeout(() => rm(e), 40);
}
NPC_HOOKS.unshift((p, e) => {
  if (e.typeId !== "mrpg:npc") return false;
  let own = null; try { own = e.getDynamicProperty("mrpg:dmown"); } catch {}
  if (e.hasTag("mrpg_dm")) {
    if (own !== p.id) { bar(p, "§7……（ほかの 人の 旅の 中の 人の ようだ）"); return true; }
    if (busy.has(p.id)) return true;
    const run = (f) => { busy.add(p.id); system.run(async () => { try { await f(); } catch {} finally { busy.delete(p.id); } }); return true; };
    if (e.hasTag("mrpg_dm_st")) return run(() => restore(p, e));
    if (e.hasTag("mrpg_dm_monk")) return run(() => monkTalk(p));
    if (e.hasTag("mrpg_dm_craft")) { let nm = ""; try { nm = String(e.getDynamicProperty("mrpg:dmnm") || ""); } catch {} return run(() => craftTalk(p, nm)); }
    const M = MINE.get(p.id), o = M && M.get(e.id);
    if (o && o.st === "moya") { o.t = Math.max(o.t, tick()) + 600; for (let i = 0; i < 4; i++) pt("minecraft:villager_happy", { x: e.location.x, y: e.location.y + 1 + i * 0.3, z: e.location.z }); bar(p, `§f${o.nm}: §7「……あ……あなたの 声で、少し 楽に なった……」 §8（持ちこたえた）`); sound(p, "random.pop", 0.6); return true; }
    if (o && o.st === "tsuki") { o.t2 = tick(); try { e.applyKnockback((e.location.x - p.location.x), (e.location.z - p.location.z), 0.6, 0.2); } catch {} bar(p, `§8${o.nm}: §7「……シッテ……シマッタ……」`); return true; }
    return true;
  }
  if (!e.hasTag("mrpg_cast") && !e.hasTag("mrpg_saga")) {   /* 第126版(S5): 迫害の 町では 店が 売って くれない（道具屋・宿は 開いて いる）*/
    let tid = null, job = -1; try { tid = e.getDynamicProperty("mrpg:town"); job = e.getProperty("mrpg:job"); const jd = e.getDynamicProperty("mrpg:jobd"); if (typeof jd === "number") job = jd; } catch {}
    if (typeof tid === "string" && DM_CLOSE.includes(job)) { const s = sOf(p), W = s && shunTown(s, tid); if (W) { system.run(() => { notice(p, `${SHOPN[job]}（戸が 閉まって いる）`, ["§f「……石板の 子には、売れないよ。悪く 思わないで くれ」", "", `§7${W.why}。`, "§8（道具屋と 宿は 開いて いる）"].join("\n")).catch(() => {}); }); return true; } }
  }
  if (!isKnown(p)) return false;
  if (e.hasTag("mrpg_cast")) {
    let id = null; try { id = e.getDynamicProperty("mrpg:cast"); } catch {} const c = id && CAST[id]; if (!c) return false;
    if (CRAFT[c.nm]) { if (busy.has(p.id)) return true; busy.add(p.id); system.run(async () => { try { await craftTalk(p, c.nm, e, id); } catch {} finally { busy.delete(p.id); } }); return true; }
    if (c.nm === "ミミ") { let k = 0; try { k = p.getDynamicProperty("mrpg:mimi"); } catch {} if (k !== today()) { try { p.setDynamicProperty("mrpg:mimi", today()); } catch {} giveItem(p, "mrpg:gift_bread", 2); bar(p, "§eミミ§f「パン、配ってるんだよっ！ ……あなたにも、はいっ！」 §a（やきたて パン×2）"); sound(p, "random.pop", 0.8); } return false; }
    return false;
  }
  let tid = null, job = -1; try { tid = e.getDynamicProperty("mrpg:town"); job = e.getProperty("mrpg:job"); const jd = e.getDynamicProperty("mrpg:jobd"); if (typeof jd === "number") job = jd; } catch {}
  if (typeof tid === "string" && DM_CLOSE.includes(job) && !e.hasTag("mrpg_saga")) {
    const s = sOf(p); if (s && shopClosed(s, tid, job)) { const r = stones(s, tid).find((x) => x.k === job); system.run(() => { notice(p, `${SHOPN[job]}（閉まって いる）`, [`§7店の 戸に、板が 打ちつけて ある。`, `§f「${r ? r.n : "主人"}が 石に なって しまいました。店は しばらく 休みます」`, "", "§7石に なった 人に 話しかけ、§e記録のインク§7 で 手帳に 名前を 書けば 戻せる。", "§7（道具屋・宿屋は 開いて いる）"].join("\n")).catch(() => {}); }); return true; }
  }
  if (e.hasTag("mrpg_walker") && !e.hasTag("mrpg_trouble")) {
    const W = ["……家に かぎを かけた。でも 影に かぎなんて、意味が ないのかも しれない。", "広場で 祈って いるの。……名前を 呼んで くれる 人が いれば、石に ならないって。", "……店は 閉めたよ。売る 物より、守る 人の ほうが 大事だからね。", "荷物を まとめて 逃げる 人も いる。……でも、どこへ 逃げれば いいんだろう。", "あの 声は、だれの 声だったんだろう。……とても、悲しい 声だった。", "うちの 子が ね、モンスターを ぎゅっと 抱いて 寝るの。……あの子たちは 影を こわがらないから。"];
    const i = (Math.floor(Date.now() / 60000) + String(e.id).length) % W.length; bar(p, `§7町の 人: §f${W[i]}`); return true;
  }
  return false;
});
/* ---------- 道具 ---------- */
EXH.doom = async (p, d, id) => {
  const s = qs(d), T = townIn(p.location), m = sd(s);
  if (id === "dm_ink") { await notice(p, "記録のインク", "§f石に なった 人に 話しかけて、名前を 呼ぶ ときに 使う。\n§7（影の 侵食で 石に なった 人だけ 戻せる）"); return; }
  if (id === "dm_drop") { await notice(p, "影のしずく", "§fほたるの 里 §eルミエ§f の §eピピ§f に 2つで 記録のインクに、§eハッカ婆§f に 忘れ草の香に、ようがんの 里 §eラヴィ§f の §eトンボと ゲン§f に 影払いの鈴に して もらえる。"); return; }
  if (id === "dm_kou") {
    if (!doomKnown(s) || !T) { await notice(p, "忘れ草の香", "§7町の 中で 使うと、その 町の 人が しばらく 影の 話を 忘れる。\n§8（今は 使う 時では ない）"); return; }
    if (m.kou && m.kou[T.t.id] > Date.now()) { await notice(p, "忘れ草の香", "§7この 町では もう 香りが ただよって いる。"); return; }
    if (!(await confirm(p, "忘れ草の香", `§e${T.t.name}§f の 広場の 香炉で たく？\n§7（20分の あいだ、この 町の 人は 取り憑かれない）`, "たく", "やめる"))) return;
    if (!takeItem(p, "mrpg:dm_kou", 1)) return;
    const d2 = load(p); if (!d2) return; const m2 = sd(qs(d2)); m2.kou = m2.kou || {}; m2.kou[T.t.id] = Date.now() + 1200000; save(p, d2);
    clearMine(p, false);
    for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; pt("minecraft:villager_happy", { x: T.c.x + Math.cos(a) * 4, y: T.c.y + 1.4, z: T.c.z + Math.sin(a) * 4 }); }
    sound(p, "random.levelup", 0.6); try { showTitle(p, "§a§l忘れ草の 香り", { subtitle: `§f${T.t.name}に、やさしい 香りが ひろがった`, fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {}
    return;
  }
  if (id === "dm_bell") {
    const near = [...(MINE.get(p.id) || new Map()).values()].some((o) => o.st === "tsuki" && ok(o.e) && Math.hypot(o.e.location.x - p.location.x, o.e.location.z - p.location.z) < 14) || CHS.has(p.id);
    if (!near) { await notice(p, "影払いの鈴", "§7近くに 取り憑かれた 人が いる ときに 使うと、しばらく 止まる。\n§8（今は 使う 時では ない）"); return; }
    if (!takeItem(p, "mrpg:dm_bell", 1)) return;
    FREEZE.set(p.id, tick() + 200); sound(p, "block.bell.hit", 1.4); sound(p, "random.orb", 0.5);
    for (let i = 0; i < 14; i++) { const a = (i / 14) * Math.PI * 2; pt("minecraft:endrod", { x: p.location.x + Math.cos(a) * 5, y: p.location.y + 1.2, z: p.location.z + Math.sin(a) * 5 }); }
    bar(p, "§b影払いの鈴が 鳴った！ §f取り憑かれた 人が すくんで 止まった（10秒）");
    return;
  }
};
/* 宿は 2倍・お礼の 店は 2割 安い（menu.js が 聞く）*/
EXH.innK = (d) => { try { return doomKnown(qs(d)) ? 2 : 1; } catch { return 1; } };
EXH.shopK = (p, t) => { try { const s = sOf(p); if (!s || !doomed(s) || !t) return 1; const m = sd(s); return m.thx && m.thx[t.id] > Date.now() ? 0.8 : 1; } catch { return 1; } };
/* 影のしずく: 滅びかけの あいだ、野生に 勝つと ときどき（夜は よく）*/
battleHooks.push((B, x) => {
  const { p } = x; if (!p || !ok(p) || B.master || B.pvp || B.dg) return;
  const won = B.result === "win" || B.result === "scout"; if (!won) return;
  const s = qs(x.d); if (!doomKnown(s)) return;
  let tod = 6000; try { tod = world.getTimeOfDay(); } catch {}
  if (Math.random() < (tod > 12500 && tod < 23500 ? 0.7 : 0.35)) { giveItem(p, "mrpg:dm_drop", 1); (x.plog = x.plog || []).push("§5影のしずく§f を 手に 入れた"); }
});
export const __dm = { PACK, outside, MINE, CHS, FREEZE, FOG, MONK, CRAFTERS, loop, sweep, chaseStart, chaseEnd, chaseStep, bellWin, toStone, toTsuki, newMoya, restore, craftTalk, dawn, townIn, stones, closedShops, shopClosed, lumStart, lumBell, SEEN, clearMine, monkTalk, LASTT, crafters };

/* =====================================================================
   物語の 場面（第11章の 頭・終章の 前）。ep_r10.js と 同じ 地方（10）に 足す
   ===================================================================== */
const zeph = () => { const t = TOWNS.find((u) => u.id === "t55"); if (!t) return null; const g = getTown("t55"); return g && g.built ? { x: g.x, y: g.y, z: g.z } : townPos(t); };
export const ZEPH_OUT = () => { const c = zeph(); return c ? { x: Math.floor(c.x) - 44, z: Math.floor(c.z) + 6, nm: "ゼファーの 外れ（風の 塔の 下）" } : null; };
const lumC = () => { const g = getTown("t0"); const t = TOWNS.find((u) => u.id === "t0"); return g && g.built ? g : t ? townPos(t) : null; };
/* 登場人物の 呼び出し（ほかの 担当が 登録した 人が いれば その 人。いなければ 同じ 名前・語尾で 出す）*/
const FB = { "ピピ": ["薬師見習い", "m6_pip"], "ハッカ婆": ["里長", "baba"], "ドルフ": ["自警団長", "m6_ivan"], "トキ婆": ["語り部", "tsubaki"], "トンボ": ["鍛冶見習い", "tetsu"], "ゲン": ["親方", "m6_bolt"], "セリーヌ": ["商家の", "tia"], "イザク": ["脱獄の 名人", "isak"], "ザザ": ["網元", "m6_umi"], "ユラ": ["墓守の", "sakura"], "シロウ": ["山案内人", "m6_eirik"], "ミミ": ["パン屋の", "mimi"], "ゴンザ": ["門番", "m6_takeru"], "ノルじい": ["牧場の", "m6_gramps"], "シズク": ["竜の 巫女", "sakuya"], "カザミ翁": ["塔守", "m6_sage"], "商家の 主人": ["", "m6_hector"], "ドンゴ": ["もと 六影の 下っぱ", "noxa"], "チョロ": ["もと 六影の 下っぱ", "noxb"], "ガロ": ["もと 班長", "garo"], "ベリル": ["", "beryl"] };
const castOf = (nm) => Object.values(CAST).filter((c) => c.nm === nm).pop() || null;   /* 第125版: 同じ 名前は あとの 章の 人（イザクは ソウラ）*/
function who(K, p, nm, walk = true) { const c = castOf(nm); if (c) return K.cast(p, c.id, !walk); const f = FB[nm] || ["", 8]; return K.npcNear(p, `§e${f[0] ? `${f[0]} ` : ""}${nm}`, PJ(f[1], 8), !walk); }
const wsay = (K, p, nm, L, lis = null) => { const c = castOf(nm); return c ? K.csay(p, c.id, L, lis) : K.say(p, nm, L, lis); };
const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
const setFlagD = (p, k) => { const d = load(p); if (!d) return; const s = qs(d); s.epx = s.epx || {}; s.epx[k] = 1; save(p, d); };
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* b の そば k マス（a の 側）*/
const fade = async (K, p, c = "0 0 0") => { K.cmd(p, `camera @s fade time 0.35 0.5 0.45 color ${c}`); await K.wait(12); };
/* 世界の 今（影の 声が 世界を つないだ 一瞬に 見えた 各地の 様子）*/
const NOW = [
  ["始まりの町 ルミナ", "ゴンザ", "ミミ", "{angry,up}門は 閉めぬでござる！ 逃げて くる 人が いるかぎり、拙者は ここに 立つでござる！", "{smile,tears,up}パン、まだ あるよっ！ 泣いてる 子から 先に 取ってっ……だよっ！", "guard", "hold"],
  ["ほたるの 里 ルミエ", "ピピ", "ハッカ婆", "{angry}薬を 煮る 火は、ぜったい 消さないのだ！ ほたるが いなくても、ピピが 灯りに なる 番なのだ！", "{closed}……ピピや、手を やすめなされ。……いや、やすまん 子ですのう", "hold", "hold"],
  ["ようがんの 里 ラヴィ", "トンボ", "ゲン", "{angry}親方！ 鉄が 足りないッス！ でも 打つッス！", "{sad,up}……泣くんじゃ ねえ、トンボ。打つ 手が 鈍るでい", "raise", "point"],
  ["オアシスの 村 ミラージュ", "セリーヌ", "ガルム", "{sad,tears,up}お父さま……！ ……いいえ、泣くのは あとですわ。倉の 水と 麦を、ぜんぶ 配りなさい！", "{sad,up}……セリーヌ嬢が 泣かぬなら、衛兵長も 泣いて おる ひまは ないのである", "kneel", "guard", ["ハリド", "m6_samir", "t6", "r4papa"]],
  ["ひかりごけの 村 グロウ", "ガロ", "ガンテツ", "{angry,up}……古い 坑道の 戸は、オレが 閉める！ ゴウの やつも 水晶宮で 踏んばってる。負けて られっかよ！", "{smile,tears,up}……ガロ。おめえの おやじの 坑夫帽、よう 似合うべ", "guard", "hold"],
  ["さんごの 町 コラリア", "ザザ", "", "{angry,up}船を 出すっぺ！ 海の 上なら、影の 声も とどかねえっぺ！", "", "point", 0],
  ["たましいの 町 ソウラ", "ユラ", "イザク", "{sad}……石に なった 人の 名前を、灯籠に 書いて いる ところ なのです", "{sweat,汗}あっしも 書くでやんす。……字が へたでも、名前は 名前でやんす", "kneel", "hold"],
];
const C1 = { id: "r10c1", n: 1, t: "空の 声", snd: "item.book.page_turn", at: 0, ord: 0, place: ZEPH_OUT,
  hint: "§fセレスティア天空郷の §eかぜの 塔の 町 ゼファー§f の 外れへ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "ゼファーの 外れに 着いた とき、空から セオの 声が 響いた。影は セオの「記録の 力」を 使い、影の 鍵と 王冠の 石板の 真実を、世界中の 人の 頭に 読み聞かせた。人々は 頭を 抱えて うずくまり、空は 暗く、赤い 月が 出た。影の 声が 世界を つないだ 一瞬、あなたには 各地で 人々が 戦う 姿が 見えた。",
  set: { voice: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), voice: 1 }; },
  async run(p, d, K) {
    await K.open(p, "ゼファーの 外れ", "ash");
    K.mood(p, "shadow"); K.sound(p, "ambient.weather.thunder", 0.6);
    const eR = REI(K, p); K.act(eR, "hold");
    await K.say(p, "レイ", ["{closed}……来たか。一人で 歩かせる 道じゃ ねえ。", "{closed}竜は 雲の 島の 端に 置いて きた。天空郷で いちばん 風が 当たる 所だって 聞いた。", "{sad}……なのに 今朝から、風が 止まってる。", "{sad}あいつの 手帳、ちゃんと 持ってるか。……なら、いい。"]);
    const eA = K.npcNear(p, "§7旅の 商人", PJ("m6_samir", 8)); K.act(eA, "hold");
    await K.say(p, "旅の 商人", ["{smile}おや、旅の 人かい。ゼファーは 風車の 町さ。今日は 風が 止まって いるけど……", "{sad,…}……影で 石に なった 人も、名を 呼んで 記録の インクで 書けば 戻るって、昔 聞いた ことが あるよ。お守りに 持ち歩く 人も いる。"]);   /* 第125版(ce): インクの 話の 出どころ（1話の レイ）*/
    /* 空から 声 */
    K.cmd(p, "stopsound @s"); K.shake(p, 0.4, 2); K.flash(p, false);
    try { p.addEffect("darkness", 120, { amplifier: 0, showParticles: false }); } catch {}
    const S = K.S(p), sky = S ? S.at(4, 0, 14) : K.fwd(p, 6, 0, 14);
    await K.at(p, sky, 16, 10, 0);
    K.big(p, "§5§l声", "§f空の 上から、静かな 声が 降って くる", "mob.wither.ambient");
    await K.say(p, "セオの 声", ["{closed,low}……記録を、読み上げる。", "{closed}『影の 鍵は 六つ。千年前の 影から 打たれた。王冠の 石板の 奥に、王が 眠る――』"]);
    K.act(eA, "kneel"); K.re(eA, "shock", "!");
    await K.push(p, eA, 22, 4.2, 1.7);
    await K.say(p, "旅の 商人", ["{shock,!,up}……っ、頭の 中に、文字が……！ やめて くれ、知りたく ない……！"]);
    K.act(eR, "guard");
    await K.say(p, "レイ", ["{angry,!,up}セオ！！ ……いや、ちがう。あれは あいつの 声を 使った、影だ！"]);
    await K.say(p, "セオの 声", ["{closed,low}『――影は、知る 者に 宿る』。……これで、みんなが 知った。"]);
    K.boom(p.dimension, sky); K.sound(p, "mob.wither.spawn", 0.6); K.shake(p, 0.7, 1);
    await K.at(p, sky, 14, 14, 0);
    await K.narr(p, ["§7空が、昼のまま 暗く なった。", "§c赤い 月§7が、雲の すき間に うっすらと 浮かんだ。灰の ような 粒が、音も なく 降りはじめる。"]);
    try { p.removeEffect("darkness"); } catch {}
    /* 世界の 今 */
    await K.say(p, "レイ", ["{shock,…,up}……おい。今、何か 見えたか。……頭の 中に、遠くの 町が……", "{sweat}……頭は 痛え。でも、入って こない。……肩に、竜の 羽の 石の 粉が まだ ついてる。あいつが 守って くれてる 気が する。"]);
    await K.narr(p, ["§7影の 声が 世界を つないだ 一瞬。", "§7あなたの 目に、遠い 町の 様子が 流れこんで きた。"]);
    for (const [town, a, b, la, lb, ga, gb, vic] of NOW) {
      await fade(K, p);
      const ev = vic ? K.npcNear(p, `§f${vic[0]}`, PJ(vic[1], 8)) : null;
      const e1 = who(K, p, a), e2 = b ? who(K, p, b) : null; K.act(e1, ga); K.act(e2, gb);
      K.ambient(p, "ash", S ? S.Cn : p.location);
      await K.narr(p, [`§7― ${town} ―`], ok(e1) ? e1 : null);   /* 第124版(fix2): その 町の 人に 寄せる（遠くの レイを 映さない）*/
      if (ok(ev)) {   /* 寄りで 一人ずつ 石に なって いく 町の 人を 見せる */
        K.act(ev, "up"); await K.push(p, ev, 22, 4.2, 1.7);
        await K.say(p, vic[0], ["{sad,low}……セリーヌ……にげ……な、さい……"]);
        for (let k = 0; k < 6 && ok(ev); k++) { K.burst(p.dimension, ev.location, k % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.6, k * 0.35); await K.wait(3); }
        K.sound(p, "dig.stone", 0.7); try { if (!preNear(p)) ev.nameTag = `§7石に なった ${vic[0]}`; } catch {}
        if (vic[2]) { let a = null; try { a = CAST[vic[3]] && CAST[vic[3]].at && CAST[vic[3]].at(); } catch {} stoneRec(p, vic[2], vic[0], vic[1], a); }   /* 第125版: 石の 父は 町に 残る（インクで 戻せる）*/
      }
      await wsay(K, p, a, [la]);
      if (b) await wsay(K, p, b, [lb], e1);
      let ePc = null;
      if (a === "ガロ") {   /* 第124版(合議): ピコの 結末。眠った まま、屋根の 下に いる */
        ePc = K.npcNear(p, "§d手下 ピコ", PJ("pico", 9), true); K.act(ePc, "down");
        await K.narr(p, ["§7ガロの 後ろの 寝床で、眠った ままの ピコが 小さく 口を 動かした。"], ok(ePc) ? ePc : null);
        await K.say(p, "ピコ", ["{closed,…}……兄ちゃん……。ここ、屋根が ある……。"]);
        await wsay(K, p, "ガロ", ["{sad,up}……ああ。おやじの 家だ。もう 外では 寝かせねえ。"]);
      }
      await K.bye(p, e1, e2, ev, ePc);
    }
    await fade(K, p);
    await K.narr(p, ["§7……町の 灯りは、どこも 消えて いなかった。", "§7みんな、それぞれの 場所で、できる ことを 続けて いた。"]);
    const eR2 = REI(K, p, true); K.act(eR2, "up");
    await K.push(p, eR2, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{closed,up}……見えたか。みんな、まだ 立ってる。"]);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……さっきの こえ。セオの こえ、ないてた。"]); K.rmCine(g); }
    await K.say(p, "レイ", ["{shock,…}……泣いてた？ ……影が しゃべらせてる だけじゃ、ないのか。", "{closed,low}あいつ、まだ どこかで 抵抗 してるのかも しれねえ。", "{angry,up}……決めた。オレたちも 止まらない。風の 町へ 行こう。"], eR2);
    K.act(eR2, 0);
    K.pay(p, C1, 0, [["dm_ink", 2]]);
    try { p.sendMessage("§7（灰の 中に、だれかが 落とした §e記録のインク§7 が 2つ あった。……使い道は、風の 町で わかる）"); } catch {}   /* 第124版(合議):【だいじな ことが わかった】は 塔守の 話（ep_r10 フウタが 戻った あと）へ 移した */
    await K.end(p, { leave: [eR2, eA], card: "§7→ かぜの 塔の 町 ゼファーへ（右上の 案内）", kind: "ash" });
    return true;
  } };
/* 終章の 前: ルミナの 鐘（大通りを 北の 門の 鐘まで 走る）*/
const C2 = { id: "r10c2", n: 8, t: "ルミナの 鐘", snd: "item.book.page_turn", at: 1, ord: 1, place: lumStart,
  hint: "§f§e始まりの町 ルミナ§f の §e南の 入口§f へ もどろう §7（右上の 案内。ゴンザが「みんなが 待って いる」と 言った）",
  syn: "ルミナに もどると、大通りは 取り憑かれた 人で あふれて いた。パン屋の ミミの 父さんが、ミミの 目の 前で 石に なった。町の 子の 小さな モンスターが、主人を かばって 影の 前に 立ちはだかった。ノルじいは「北の 門の 鐘を 鳴らせば、影は しばらく 引く」と 言った。",
  set: { lchase: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), lchase: 1 }; },
  async run(p, d, K) {
    await K.open(p, "ルミナの 南の 入口", "ash");
    K.sound(p, "mob.villager.no", 0.8); K.mood(p, "shadow");
    const eM = who(K, p, "ミミ"); K.act(eM, "hold");
    await wsay(K, p, "ミミ", ["{cry,!,up}来て くれたっ……！ お父さんが、お父さんが 変なんだよっ……！"]);
    const eF = K.npcNear(p, "§8パン屋の 親方", PJ("m6_paolo", 8)); K.act(eF, "kneel");
    for (let i = 0; i < 3 && ok(eF); i++) { K.burst(p.dimension, eF.location, "minecraft:soul_particle", 5, 0.5, 1.6); await K.wait(4); }
    await K.push(p, eF, 22, 4.2, 1.7);
    await K.say(p, "パン屋の 親方", ["{sad,low}……ミミ……はなれて ろ……頭の 中で、声が……", "{closed}……焼きたての パン……みんなに……くばって……"]);
    for (let k = 0; k < 6 && ok(eF); k++) { K.burst(p.dimension, eF.location, k % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.6, k * 0.35); await K.wait(4); }
    K.sound(p, "dig.stone", 0.7); try { if (eF && !preNear(p)) eF.nameTag = "§7石に なった パン屋の 親方"; } catch {}
    { const q = nearPt(eM, eF, 0.8); if (q) await K.go(eM, q, 8, true); } K.act(eM, "kneel");
    await K.two(p, eM, eF, 12);
    await wsay(K, p, "ミミ", ["{cry,tears,up}お父さんっ……！！ ……やだよっ、石なんて、やだよっ……！"]);
    const eN = who(K, p, "ノルじい"); K.act(eN, "hold");
    await wsay(K, p, "ノルじい", ["{closed}……ミミ。名前を 呼んで やるんじゃよ。石に なっても、名前は 届くんじゃよ。"], eM);
    if (countItem(p, "mrpg:dm_ink") > 0 && takeItem(p, "mrpg:dm_ink", 1)) {   /* インクが あれば その場で 戻す */
      K.sound(p, "item.book.page_turn", 1);
      await K.narr(p, ["§7あなたは 手帳を 開き、§e記録のインク§7 で §fパン屋の 親方 ハインツ§7 と 書いた。", "§7……石の 表面に ひびが 走り、光が こぼれた。"], eF);
      for (let k = 0; k < 6 && ok(eF); k++) { K.burst(p.dimension, eF.location, k % 2 ? "minecraft:villager_happy" : "minecraft:totem_particle", 6, 0.6, k * 0.3); await K.wait(3); }
      try { if (ok(eF)) eF.nameTag = "§fパン屋の 親方"; } catch {} K.act(eF, "up"); K.sound(p, "random.levelup", 0.7);
      await K.say(p, "パン屋の 親方", ["{shock,…,up}……ミミ？ ……おれは、いったい……"]);
      { const q = nearPt(eM, eF, 0.7); if (q) await K.go(eM, q, 6, true); } K.act(eM, 23); K.act(eF, 23); await K.two(p, eM, eF, 10);
      await wsay(K, p, "ミミ", ["{cry,smile,tears,up}お父さんっ……！ よかった……よかったよっ……！"], eF);
      await K.say(p, "パン屋の 親方", ["{smile}……名前を、呼ばれた 気が した。……さあ、パンを 焼こう。町の みんなの ぶんだ"]);
      setFlagD(p, "mimiDad");
    } else {
      await K.narr(p, ["§7あなたは 手帳を 開いて、§fパン屋の 親方 ハインツ§7 と 書いた。", "§7……でも インクが 足りず、字は うすく にじんで 消えた。"], eF);
      await wsay(K, p, "ミミ", ["{cry,angry,up}……インク、さがして くるよっ。お父さんの 名前、ぜったい 書いて もらうんだよっ！"]);
      if (ok(eF)) stoneRec(p, "t0", "パン屋の 親方", "m6_paolo", eF.location);   /* 第125版: 石の 親方は 町に 残る */
    }
    /* 町の 子の モンスターが 主人を 守る */
    const kid = K.npcNear(p, "§f町の 子 ルカ", PJ("taro", 9)); K.act(kid, "kneel");
    const sm = K.monEnt(p, K.fwd(p, 4, 2), K.wildSp("animal"), "§aルカの モンスター");
    await K.shadowFlow(p, K.fwd(p, 12, 4), kid ? kid.location : K.fwd(p, 4), 12);
    if (sm) { K.burst(p.dimension, sm.location, "minecraft:villager_angry", 4, 0.4, 1); K.sound(p, "mob.wolf.growl", 1.2); anim(sm, "atk_bite"); await K.push(p, sm, 22, 4.2, 1.7); }
    await K.say(p, "町の 子 ルカ", ["{shock,!,up}……モコ！？ だめだよ、影の 前に 出たら……！"]);
    K.flash(p, true); K.burst(p.dimension, sm ? sm.location : p.location, "minecraft:totem_particle", 10, 1, 1); anim(sm, "guard");
    await K.narr(p, ["§7小さな モンスターは 一歩も 引かず、影に 向かって 吠えつづけた。", "§7影は ためらう ように ゆらぎ、少しだけ 後ろへ さがった。"], sm);
    await wsay(K, p, "ノルじい", ["{smile,up}……モンスターは、影の 言葉を 知らん。だから 影に 取り憑かれんのじゃよ。", "{closed}……知った だけでは 宿らん。知って、欲しがった 者に 宿るんじゃよ。", "{angry}よう 聞け。§e北の 門の 鐘§f を 鳴らせば、影は しばらく 引く。昔から そう 決まって おるんじゃよ。", "{closed,low}あの 鐘は、四十年前、オルドと 星の 好きな 若いのが 吊ったんじゃよ。『名を 呼べん ときは、鳴らせ』と 言うてな。"]);
    await wsay(K, p, "ミミ", K.flag(p, "mimiDad") ? ["{smile,tears,up}……あたし、お父さんと いっしょに パンを 配るよっ。……だから、鐘、おねがいだよっ！"] : ["{cry,angry,up}……あたし、パンを 配るよっ。お父さんの かわりに。……だから、鐘、おねがいだよっ！"]);
    K.rmCine(sm);
    K.pay(p, C2, 0, [["dm_bell", 1]]);
    try { p.sendMessage("§fノルじいが §e影払いの鈴§f を もう 一つ くれた §7（取り憑かれた 人が 近い ときに 使うと、しばらく 止まる）"); } catch {}
    await K.end(p, { leave: [eN, kid], bye: [eM, eF], card: "§c→ 大通りを ぬけて、北の 門の 外の §e鐘§c まで 走れ！\n§7（つかまっても 入口に もどる だけ）", kind: "ash" });
    return true;
  } };
/* 終章の 前: 鐘を 鳴らす → 各地の 人が 集まって 送り出す */
const SEND = [
  ["ピピ", "{smile,☆}インク、いっぱい 作って おいたのだ！ ……かならず 帰って くる 約束なのだ！"],
  ["ハッカ婆", "{closed}森の ほたるも、あなたの 帰りを 待って おりますのう"],
  ["ドルフ", "{smile}帰って きたら、井戸の 水で 乾杯だぜ"],
  ["トンボ", "{smile,!}親方と 打った 鈴ッス！ 鳴らしたら、おれたちの 声だと 思って ほしいッス！"],
  ["ゲン", "{sad,tears}……火の粉が、きれいでい。トンボの 鈴が、よう 鳴っとる"],
  ["セリーヌ", "{smile}お代は 帰って から いただきますわ。……だから、必ず"],
  ["ザザ", "{smile,♪}船は いつでも 出せるっぺ。帰りの 海は、凪に して おくっぺ"],
  ["ユラ", "{closed}あなたの 名前は、灯籠に 書かないのです。……書く 必要が ない から なのです"],
  ["シロウ", "{smile}山道は 開けて おいたべさ。迷ったら、雷を 目印に するべさ"],
  ["シズク", "{closed}竜の 鱗は、今も くもって おりません。……行って らっしゃいませ"],
  ["カザミ翁", "{smile}風は、もう 一度 吹くじゃて。……背中を 押して やるじゃて"],
];
const C3 = { id: "r10c3", n: 9, t: "旅立ちの 道", at: 1, ord: 2, place: () => { const g = lumBell(); return g ? { x: g.x, z: g.z, nm: "ルミナの 北の 門の 外（鐘）" } : null; },
  hint: "§f取り憑かれた 人を よけて、ルミナの §e北の 門の 外の 鐘§f まで 走ろう §7（つかまっても 南の 入口に もどる だけ。鐘の そばで 立ち止まる）",
  syn: "北の 門の 外の 鐘を 鳴らすと、ルミナの 影が 引いた。門の 外には、旅で 出会った 人たちが 各地から 集まって いた。ゴンザ、ミミ、ノルじい、そして 遠い 町の 人たちが 一人ずつ 声を かけた。もと 六影の 下っぱ ドンゴと チョロは、町を 守ると 言った。あなたは 王冠の 石板へ 向かう。",
  set: { lbell: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), lbell: 1 }; },
  async run(p, d, K) {
    chaseEnd(p, true);
    if (CHS.has(p.id)) CHS.delete(p.id);
    await K.open(p, "ルミナの 北の 門の 外", "ash");
    const S = K.S(p), bl0 = lumBell(), bq = bl0 && S && Math.hypot(bl0.x + 2 - S.P.x, bl0.z - S.P.z) < 20 ? { x: Math.floor(bl0.x) + 2.5, y: Math.floor(S.P.y), z: Math.floor(bl0.z) + 0.5 } : S ? S.at(3, 2.5, 0) : K.fwd(p, 3, 2.5);   /* 第125版(fac): 鐘の 柱を 映す */
    await K.at(p, bq, 14, 3, 1.2);
    for (let i = 0; i < 3; i++) { K.sound(p, "block.bell.hit", 1 - i * 0.1); K.burst(p.dimension, bq, "minecraft:totem_particle", 10, 1 + i, 1); K.shake(p, 0.2, 0.3); await K.wait(12); }
    K.big(p, "§e§l鐘", "§f鐘の 音が、ルミナの 空に 広がって いく", "random.levelup");
    K.flash(p, true);
    await K.narr(p, ["§7鐘の 音が 三度 鳴ると、町の 影が すうっと 引いて いった。", "§7暗い 空に、ほんの 少しだけ 光の すじが 差した。"], bq);
    const eG = K.cast(p, "gonza"); K.act(eG, "hold"); K.hold(eG, "spear");
    await K.csay(p, "gonza", ["{smile,up}……鳴らしたでござるな。", "{smile,tears,up}門の 外を、見て ほしいでござる。"]);
    await K.wide(p, 16);
    await K.narr(p, ["§7北の 門の 外の 道に、たくさんの 人が 立って いた。", "§7遠い 町から、灰の 降る 道を 歩いて 来た 人たち だった。"]);
    const eM = who(K, p, "ミミ"); K.act(eM, "hold"); K.hold(eM, "basket");
    await wsay(K, p, "ミミ", ["{smile,tears,up}みんなね、あなたを 送り出しに 来たんだよっ。……手紙も 何も 出して ないのに、だよっ！"]);
    let i = 0;
    for (const [nm, ln] of SEND) {
      if (i % 3 === 0) await fade(K, p, "20 10 10");
      const e = who(K, p, nm); K.act(e, i % 2 ? "raise" : "hold");
      await wsay(K, p, nm, [/[{,]up[,}]/.test(ln) ? ln : ln.replace(/^\{/, "{up,")]);
      K.act(e, 0); await K.bye(p, e); i++;
    }
    /* 第125版: すべてが つながる（八年前の 収穫祭の 袖の 女の子）*/
    await fade(K, p);
    const eB = who(K, p, "ベリル"); K.act(eB, "hold"); K.hold(eB, "notebook");
    await K.low(p, eB, 12);
    await wsay(K, p, "ベリル", ["{closed}……わたしも、来たの。", "{sad,up}竜祭りの 夜、広場の 端で 聞いてたの。あの 子が『名前を 書いた 人は、みんな 帰る 場所を 持ってる』って。"]);
    const eMb = who(K, p, "ミミ"); K.re(eMb, "shock", "!");
    await K.push(p, eMb, 22, 4.2, 1.7);
    await wsay(K, p, "ミミ", ["{shock,…,up}……その 台本の 表紙……。", "{shock,tears,up}……ベリルちゃん？"], eB);
    await K.push(p, eB, 22, 4.2, 1.7);
    await wsay(K, p, "ベリル", ["{shock,…,up}……パンを、半分こ した……。", "{cry,tears,up}八年前の、収穫祭の 子……覚えて、たの？"]);
    await wsay(K, p, "ミミ", ["{cry,smile,tears,up}名前、やっと 思い出したんだよっ！ ……友だちに なろうねって、約束したんだよっ！"], eB);
    await wsay(K, p, "ベリル", ["{sad,…}……わたしも、あなたの 名前を 忘れてた。", "{sad,up}パンの 味だけ 覚えてて……ずっと、だれの パンだったか 思い出せなかった。"], eMb);
    await wsay(K, p, "ミミ", ["{smile,tears,up}……おあいこ だよっ。", "{smile,up}今度は 忘れない ように、会う たびに 名前を 呼ぶんだよっ。……ベリルちゃん！"], eB);
    await wsay(K, p, "ベリル", ["{smile,tears,up}……ミミ。"], eMb);
    K.act(eB, "hold"); K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7ベリルは 一座の 台本を 開いた。自分の 名前の 下に、小さく §fミミ§7 と 書いた。", "§7……白紙だった 台本の 頁に、はじめての 友だちの 名前が 加わった。"], eB);
    await wsay(K, p, "ベリル", ["{smile,tears,up}……いって らっしゃい。……一度、言って みたかったの。"]);
    setFlagD(p, "berylFriend");
    K.act(eB, 0); await K.leave(eB, p, 9, false);
    await fade(K, p);
    const eD = who(K, p, "ドンゴ"), eC = who(K, p, "チョロ"); K.act(eD, "guard"); K.act(eC, "guard");
    await wsay(K, p, "ドンゴ", ["{sweat,汗}……へっ。おれたちも 来て やったぜ。……六影の 名前は、もう 使わねえ。"]);
    await wsay(K, p, "チョロ", ["{smile,tears,up}町は おいらたちが 守るっす！ ……兄貴にも、そう 言われたっす！"]);
    await K.bye(p, eD, eC);
    const eN = who(K, p, "ノルじい"); K.act(eN, "hold");
    await wsay(K, p, "ノルじい", ["{closed}……オルドは、闘技場の 方へ 行った きり じゃよ。あやつ、何を 考えて おるのか。", "{smile,up}じゃが、わしには わかる。……あやつも、おまえさんを 待って おるんじゃよ。"]);
    const eR = REI(K, p); K.act(eR, "hold");
    await K.say(p, "レイ", ["{closed}……すげえ 数だな。おまえ、こんなに 人を 助けて きたのか。", "{smile,up}あいつの 手帳には、ここに いる 全員の 名前が 書いて あるんだぜ。"]);
    const dr = qs(load(p) || d).epx || {};
    if (dr.dream !== undefined) await wsay(K, p, "ミミ", [["{smile,♪,up}旅が 終わったら 牧場で のんびり したいって、あの子が 言ってたよっ。……ちゃんと 帰って くるんだよっ！", "{smile,☆,up}旅が 終わったら また 旅に 出るって、あの子が 言ってたよっ。……その 前に、ちゃんと 帰って くるんだよっ！", "{smile,tears,up}旅が 終わったら みんなに 会いに 行くって、あの子が 言ってたよっ。……みんな、ここに いるよっ！"][dr.dream] || "{smile,up}帰って くるんだよっ！"]);
    K.act(eM, "hold"); K.hold(eM, "basket");
    await wsay(K, p, "ミミ", ["{smile,tears,up}はい、はちみつパン。……収穫祭の 約束、まだ 一つ 残ってるんだよっ。"]);
    await K.give(eM, null, "basket");
    /* 第125版(ce): 風の 町の 決まり「名は 三度 呼べ」→ 町じゅうが あなたの 名を 三度 呼ぶ（章の 問い「帰る 場所は、まだ あるか」の 答え）*/
    const eKz = who(K, p, "カザミ翁"); K.act(eKz, "hold");
    await wsay(K, p, "カザミ翁", ["{smile,up}風の 町では、旅立つ 者の 名も 三度 呼ぶんじゃて。……帰り道を、迷わんように。"]);
    await wsay(K, p, "ミミ", ["{smile,tears,up}せーので 呼ぶよっ！"], eKz);
    await K.narr(p, [`§f「${p.name}！」`], eM);
    await K.narr(p, [`§f「${p.name}！！」`], eG);
    await K.wide(p, 10);
    await K.narr(p, [`§f「${p.name}――！！」`, "§7門の 外の みんなの 声が、三度、あなたの 名前を 呼んだ。"]);
    if (ok(eR)) await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{smile,tears,up}……帰る 場所、あるじゃねえか。"]);
    await K.bye(p, eKz);
    K.pay(p, C3, 5000, [["gift_bread", 3], ["dm_ink", 3], ["dm_bell", 1]]);
    for (const e of [eG, eM, eN, eR]) K.act(e, "raise");
    K.ambient(p, "fest", S ? S.Cn : p.location); K.sound(p, "firework.blast", 0.7);
    await K.csay(p, "gonza", ["{smile,tears,up}いって らっしゃいでござる！！ 門は、いつでも 開けて 待って おるでござる！！"]);
    await K.wide(p, 20);
    K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 0 0 0"); await K.wait(10);
    await K.end(p, { leave: [eN, eR], bye: [eG, eM], card: "§f― 第18章 ルミナの 門 おわり ―\n§7→ ルミナの 闘技場で カップを 勝ちぬき、王冠の 石板へ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };
epAdd(10, [C1, C2, C3]);
