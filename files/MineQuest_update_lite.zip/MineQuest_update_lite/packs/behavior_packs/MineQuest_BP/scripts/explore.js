// 第101版: 探索（地形を 生かした 遊び）
// 秘境（崖の上の巣・沖の 漂流島・地底の 空洞・空の 浮島）・展望台・古代の 石碑・秘湯・釣りの 名所・踏破率・探索手帳・探索ランク
// 採集ポイント・地方の 素材・化石・環境の レア・賞金首と 足あと・迷子の モンスター・うわさ・流れ星・光の柱・異常気象・ライドの 熟練度・なぞの 地図
// 軽く: 2秒に 1回だけ、プレイヤーごとに 近くを 少し 見る。プレイヤーの 記録は "mrpg:ex"（小さな JSON・ふだんの セーブとは 別）
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES, ORDER } from "./data.js";
import { WREGIONS, regionIdx, landSites, LAYOUT, ensureLayout, regionLv } from "./worldmap.js";
import { TOWNS, getTown, surfaceY, building } from "./structures.js";
import { load, save } from "./store.js";
import { busy, ok, choose, notice, confirm, paged, ICON, giveItem, takeItem, countItem, sound, barNote, showTitle, gold, seedId, EXH } from "./ui.js";
import { hooks, TYPE, setLook, setSpeed, findPet } from "./field.js";
import { battleHooks, HIT_HOOKS, WX_HOOK } from "./battle.js";
import { FISH_HOOK } from "./fishing.js";
import { makeMonster, addMon, calcStats } from "./core.js";
import { rankCap, rIdx, storyLootOk, RANK_LBL } from "./quest.js";
import { openUpTo } from "./saga.js";
import { award, TITLES } from "./endgame.js";
import { chestCmds, rollTier } from "./chests.js";

const OW = "minecraft:overworld";
const B = (t, icon) => [t, icon];
const rnd = () => Math.random();
const pickA = (a) => a[Math.floor(rnd() * a.length)];
const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const sp0 = () => { try { const s = world.getDefaultSpawnLocation(); return { x: s.x, z: s.z }; } catch { return { x: 0, z: 0 }; } };
const DIRS = ["北", "北東", "東", "南東", "南", "南西", "西", "北西"];
const dirTo = (a, b) => DIRS[Math.round(((Math.atan2(b.x - a.x, -(b.z - a.z)) * 180) / Math.PI + 360) % 360 / 45) % 8];
const hd = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const run = (dim, c) => { try { dim.runCommand(c); } catch {} };
const fx = (dim, id, l) => { try { dim.spawnParticle(id, l); } catch {} };
const dayNo = () => Math.floor((Date.now() + 9 * 3600000) / 86400000);   // 日本の 日づけで 1日
const nowT = () => Date.now();
// コンパスの 目的地（物語・宝の しるし）を 一時的に かりて、終わったら もどす
const NAVI_K = "mrpg:navi";
/* 元の 目的地は 記録（ex）に 1つだけ。だれかが 書きかえて いたら もどさない */
function naviPush(p, v) { const x = exOf(p); let old; try { old = p.getDynamicProperty(NAVI_K); } catch {} if (x.nvO === undefined) x.nvO = typeof old === "string" ? old : null; x.nvP = JSON.stringify(v); try { p.setDynamicProperty(NAVI_K, x.nvP); } catch {} exSave(p); }
function naviPop(p) {
  const x = exOf(p); if (x.nvO === undefined) return;
  if (EVT.has(p.id) || (x.rm && x.rm.nv)) return;   /* まだ ほかの 案内中 */
  let cur; try { cur = p.getDynamicProperty(NAVI_K); } catch {}
  if (cur === x.nvP) try { p.setDynamicProperty(NAVI_K, x.nvO || undefined); } catch {}
  delete x.nvO; delete x.nvP; exSave(p);
}

// ---------- プレイヤーの 探索の 記録 ----------
const EXK = "mrpg:ex", EXC = new Map(), DIRTY = new Set();
export function exOf(p) {
  if (EXC.has(p.id)) return EXC.get(p.id);
  let alive = false; try { alive = p.isValid(); } catch {}
  let e = null, okR = alive, s0; try { s0 = p.getDynamicProperty(EXK); } catch { okR = false; }
  try { if (typeof s0 === "string") e = JSON.parse(s0); } catch { e = null; }   /* こわれた 記録は 空から（保存は する） */
  if (!e || typeof e !== "object") e = {};
  for (const k of ["v", "f", "t", "b", "r", "rd", "cl"]) if (!e[k] || typeof e[k] !== "object" || Array.isArray(e[k])) e[k] = {};
  e.pt = Math.max(0, +e.pt || 0);
  if (okR) EXC.set(p.id, e); else e.tmp = 1;   /* 抜けた 人は 読めない ので 覚えない（空で 上書き しない） */
  return e;
}
function exSave(p, now = false) { DIRTY.add(p.id); if (now) exFlush(p); }
function exFlush(p) { const e = EXC.get(p.id); if (!e || e.tmp) return; try { p.setDynamicProperty(EXK, JSON.stringify(e)); DIRTY.delete(p.id); } catch {} }
export function exReset(p) { EXC.delete(p.id); DIRTY.delete(p.id); try { p.setDynamicProperty(EXK, undefined); } catch {} }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { EXC.delete(playerId); DIRTY.delete(playerId); LASTP.delete(playerId); SEEN.delete(playerId); EVT.delete(playerId); FOSSIL_T.delete(playerId); }); } catch {}   /* 記録は 30秒ごと・大事な ときは すぐ 書く */

// ---------- 探索ランク ----------
export const RANKS_X = [[0, "見習い"], [60, "駆け出し"], [180, "旅人"], [400, "探検家"], [750, "冒険家"], [1200, "開拓者"], [1800, "踏破者"], [2600, "伝説の 探検家"]];
export const xRank = (pt) => { let r = 1; RANKS_X.forEach(([n], i) => { if (pt >= n) r = i + 1; }); return r; };
export const PERKS = [[2, "採集で ときどき 2こ 手に入る"], [3, "なぞの 地図の ヒントが くわしく なる"], [4, "秘境の 100m 以内で 気配が わかる"], [5, "採集ポイントが 出やすい"], [6, "ライドが 5% 速い"], [7, "流れ星・光の柱の 宝箱が 1段 よく なる"], [8, "色違いが 少し 出やすい"]];
TITLES.ex_r4 = ["探検家", "探索ランク 4"]; TITLES.ex_r8 = ["伝説の 探検家", "探索ランク 8"]; TITLES.ex_env = ["空と 大地を 知る者", "環境の レア 10種 すべて"];
TITLES.ex_bounty10 = ["賞金稼ぎ", "賞金首を 10回 倒す"];
WREGIONS.forEach((R, i) => { TITLES[`ex_${i}`] = [`${R.short}の 踏破者`, `${R.name}を 踏破する`]; });
function addPt(p, e, n, log) {
  const r0 = xRank(e.pt); e.pt += n; const r1 = xRank(e.pt);
  if (r1 > r0) {
    const msg = `§a§l探索ランク ${r1}「${RANKS_X[r1 - 1][1]}」に 上がった！${PERKS.find((x) => x[0] === r1) ? `§r§a 特典: ${PERKS.find((x) => x[0] === r1)[1]}` : ""}`;
    if (log) log.push(msg); else try { p.sendMessage(msg); sound(p, "random.levelup", 1.2); } catch {}
    if (r1 >= 4 || r1 >= 8) { const d = load(p); if (d) { if (r1 >= 4) award(p, d, "ex_r4", log); if (r1 >= 8) award(p, d, "ex_r8", log); if (!log) save(p, d); } }
  }
}

// ---------- ほうび ----------
const PRIZE = [["c_fruit", "c_revive", "f_exp1k", "g_sp", "c_water2"], ["c_drop", "f_exp3k", "lv_1", "g_sp2", "rf_1", "c_fairy"], ["f_exp10k", "lv_3", "rf_2", "g_sp2", "i_tal1", "c_revive2"], ["f_exp30k", "lv_5", "g_sp3", "i_tal1", "rf_2", "i_inherit"]];
function prize(p, d, i, g, n = 1) {
  const t = Math.max(0, Math.min(3, Math.floor(i / 3) + g)), cap = d ? rankCap(d) : 8, out = [];
  const L = PRIZE[t].filter((id) => ITEMS[id] && storyLootOk(ITEMS[id], null, cap));
  for (let k = 0; k < n && L.length; k++) { const id = pickA(L); giveItem(p, `mrpg:${id}`, 1); out.push(`§b${ITEMS[id].name}`); }
  return out;
}
function giveGold(d, n) { d.gold = Math.min(99999999, (d.gold || 0) + n); return gold(n); }

// ---------- 秘境などの 場所（地方ごとに 1回だけ 計算・ワールドごとに 同じ）----------
export const KINDS = {
  tower: { n: "展望台", h: "高い 塔。てっぺんに 登ると まわりの 秘境が 見える" },
  stele: { n: "古代の 石碑", h: "地方の 古い 言い伝えが きざまれた 石" },
  nest: { n: "崖の上の巣", h: "切り立った 岩の 上。§eよじ登り・飛行§fで 行ける", secret: 1 },
  isle: { n: "沖の 漂流島", h: "水の 上の 小さな 島。§e海・浮遊§fで 行ける", secret: 1 },
  hollow: { n: "地底の 空洞", h: "地面の 20ブロック 下。§e掘り進み§fで 行ける", secret: 1 },
  sky: { n: "空の 浮島", h: "空高くに 浮かぶ 島。§e飛行§fで 行ける", secret: 1 },
  spring: { n: "秘湯", h: "つかると 仲間が 元気に なる 温泉" },
  fish: { n: "釣りの 名所", h: "ここで 釣ると 1段 上の 竿と 同じに なる" },
};
const SECRET = ["nest", "isle", "hollow", "sky"];
const kindsOf = (i) => { const s = WREGIONS[i].style; return ["tower", "stele", ...SECRET, ...(["snow", "volcano", "crystal"].includes(s) ? ["spring"] : []), ...(s === "sky" ? [] : ["fish"])]; };
const SPOTS = new Map();   // "layout:i" -> [{k, ox, oz}]
function spotPlan(i) {
  if (!LAYOUT.ok) ensureLayout();
  const key = `${LAYOUT.v}:${i}`; if (SPOTS.has(key)) return SPOTS.get(key);
  const R = WREGIONS[i], s = sp0(), av = [];
  for (const t of TOWNS) av.push([t.dx, t.dz, 110]);
  WREGIONS.forEach((Q) => { const a = Q.castle.at || Q.c; av.push([a[0], a[1], 80]); });
  for (let k = 0; k < WREGIONS.length; k++) try { for (const L of landSites(k)) av.push([L.x - s.x, L.z - s.z, 70]); } catch {}   /* となりの 地方の ステージも よける */
  const out = [];
  for (const k of kindsOf(i)) {
    let best = null, bv = -Infinity;   /* よけたい 場所に 近くても いちばん ましな 所に 置く */
    const h = hash(`${k}:${i}`);
    for (let gx = -R.r; gx <= R.r; gx += 18) for (let gz = -R.r; gz <= R.r; gz += 18) {
      const x = R.c[0] + gx + (h % 7) - 3, z = R.c[1] + gz + ((h >> 3) % 7) - 3;
      if (Math.hypot(gx, gz) > R.r * 0.92 || regionIdx(x, z) !== i) continue;
      let m = 1e9;
      for (const [ax, az, r] of av) m = Math.min(m, Math.hypot(ax - x, az - z) - r);
      for (const o of out) m = Math.min(m, Math.hypot(o.ox - x, o.oz - z) - 45);
      const v = m + ((h ^ hash(`${gx},${gz}`)) % 9);   // 同じ くらいなら 地方ごとに ばらける
      if (v > bv) { bv = v; best = { k, ox: Math.round(x), oz: Math.round(z) }; }
    }
    if (best) out.push(best);
  }
  SPOTS.set(key, out); return out;
}
// 作った 場所の 記録（ワールド）
const SKEY = (i, k) => `mrpg:exs:${i}:${k}`, SMEM = new Map();
export function spotInfo(i, k) {
  const key = SKEY(i, k); if (SMEM.has(key)) return SMEM.get(key);
  let v = null; try { const s = world.getDynamicProperty(key); if (typeof s === "string") v = JSON.parse(s); } catch {}
  SMEM.set(key, v); return v;
}
function setSpot(i, k, v) { SMEM.set(SKEY(i, k), v); try { world.setDynamicProperty(SKEY(i, k), JSON.stringify(v)); } catch {} }
export function spotsOf(i) { const s = sp0(); return spotPlan(i).map((q) => ({ ...q, i, x: Math.floor(s.x + q.ox), z: Math.floor(s.z + q.oz), info: spotInfo(i, q.k) })); }

// 地方の 岩の 色
const ROCK = { volcano: "blackstone", desert: "sandstone", snow: "stone", crystal: "calcite", dark: "deepslate", sky: "quartz_block", castle: "cobblestone", port: "stone", forest: "mossy_cobblestone", village: "stone" };
// 近くの 水（読みこめない 所が あれば "wait"）
function findWater(dim, x, z, r = 32) {
  let miss = false;
  for (let rr = 0; rr <= r; rr += 8) for (let a = 0; a < 8; a++) {
    const X = Math.floor(x + Math.cos((a * Math.PI) / 4) * rr), Z = Math.floor(z + Math.sin((a * Math.PI) / 4) * rr);
    let t; try { t = dim.getTopmostBlock({ x: X, z: Z }); } catch { miss = true; }
    if (t && /water/.test(t.typeId)) return { x: X, y: t.location.y, z: Z };
    if (rr === 0) break;
  }
  return miss ? "wait" : null;
}
// プレイヤーが 作った ものが ないか（作る 前に 1回だけ・9点 × 5段）
const BUILT = /planks|glass|brick|wool|door|bed$|_bed|chest|barrel|_slab|_stairs|crafting|furnace|farmland|torch|lantern|fence|carpet|concrete|terracotta_|bookshelf|ladder|sign|rail|hopper|anvil|shulker|smooth_stone|quartz_block|cut_copper|copper_block/;
function playerBuilt(dim, x, y, z, r = 3) {
  for (const dx of [-r, 0, r]) for (const dz of [-r, 0, r]) for (let dy = -1; dy <= 3; dy++) {
    let b; try { b = dim.getBlock({ x: x + dx, y: y + dy, z: z + dz }); } catch { return "wait"; }
    if (!b) return "wait";   /* 読みこめない → 今は 作らない（あとで もう一度） */
    if (BUILT.test(b.typeId)) return true;
  }
  return false;
}
// 水・溶岩の 上を さけた 地面（まわり 4か所も 試す）
function dryAt(dim, x, z) {
  for (const [dx, dz] of [[0, 0], [12, 0], [-12, 0], [0, 12], [0, -12]]) {
    let t; try { t = dim.getTopmostBlock({ x: x + dx, z: z + dz }); } catch { return null; }
    if (!t) return null;
    if (t.isLiquid || /water|lava/.test(t.typeId)) continue;
    const y = surfaceY(dim, x + dx, z + dz); if (y === null) return null;
    return { x: x + dx, z: z + dz, y };
  }
  return "wet";
}
// 1か所 作る（コマンドは 10こ 以下）。読みこめて いなければ false（あとで もう一度）
function buildSpot(dim, i, q) {
  const { k, x, z } = q, st = WREGIONS[i].style, rock = ROCK[st] || "stone";
  try { if (hooks.noDig && hooks.noDig({ x, y: 64, z }, dim)) { setSpot(i, k, { x, y: 0, z, skip: 1 }); return true; } } catch {}
  const skip = () => { setSpot(i, k, { x, y: 0, z, skip: 1 }); return true; };
  let gy, X0 = x, Z0 = z;
  if (k === "isle" || k === "fish") { gy = surfaceY(dim, x, z); if (gy === null) return false; }
  else { const g = dryAt(dim, x, z); if (g === null) return false; if (g === "wet") return skip(); X0 = g.x; Z0 = g.z; gy = g.y; }
  return buildAt(dim, i, k, X0, Z0, gy, rock, skip);
}
function buildAt(dim, i, k, x, z, gy, rock, skip) {
  const hy0 = k === "hollow" ? Math.max(-50, gy - 20) : k === "sky" ? Math.min(300, gy + 45) : gy;
  try { if (hooks.inTown({ x, z }, dim.id) || (hooks.noDig && hooks.noDig({ x, y: gy, z }, dim))) return skip(); } catch {}   /* ずらした 先も 町・城を さける */
  if (k !== "isle" && k !== "fish") { const pb = playerBuilt(dim, x, k === "hollow" || k === "sky" ? hy0 : gy, z, k === "spring" || k === "nest" ? 3 : 2); if (pb === "wait") return false; if (pb) return skip(); }   /* 人の 建物が ある 所には 作らない */
  const C = [];
  let info = { x, y: gy, z };
  if (k === "tower") {
    C.push(`fill ${x - 1} ${gy - 3} ${z - 1} ${x + 1} ${gy + 20} ${z + 1} stone_bricks`);
    C.push(`fill ${x} ${gy} ${z + 2} ${x} ${gy + 20} ${z + 2} ladder ["facing_direction"=3]`);
    C.push(`fill ${x - 2} ${gy + 21} ${z - 2} ${x + 2} ${gy + 21} ${z + 2} spruce_planks`);
    C.push(`fill ${x - 2} ${gy + 22} ${z - 2} ${x + 2} ${gy + 22} ${z + 2} spruce_fence`);
    C.push(`fill ${x - 1} ${gy + 22} ${z - 1} ${x + 1} ${gy + 26} ${z + 1} air`);
    C.push(`setblock ${x} ${gy + 22} ${z + 2} air`, `setblock ${x} ${gy + 21} ${z + 2} ladder ["facing_direction"=3]`);
    C.push(`setblock ${x} ${gy + 22} ${z} lantern`);
    info = { x, y: gy + 22, z };
  } else if (k === "stele") {
    C.push(`fill ${x - 1} ${gy - 1} ${z - 1} ${x + 1} ${gy - 1} ${z + 1} mossy_cobblestone`, `fill ${x} ${gy} ${z} ${x} ${gy + 2} ${z} chiseled_stone_bricks`, `setblock ${x} ${gy + 3} ${z} lantern`);
  } else if (k === "nest") {
    C.push(`fill ${x - 2} ${gy - 3} ${z - 2} ${x + 2} ${gy + 15} ${z + 2} ${rock}`, `fill ${x - 1} ${gy + 16} ${z - 1} ${x + 1} ${gy + 16} ${z + 1} hay_block`, `fill ${x - 1} ${gy + 17} ${z - 1} ${x + 1} ${gy + 19} ${z + 1} air`);
    C.push(...chestCmds(x, gy + 17, z, rollTier(4, Math.floor(i / 3)), dim.id));
    info = { x, y: gy + 17, z };
  } else if (k === "isle" || k === "fish") {
    let w = findWater(dim, x, z);
    if (w === "wait") return false;
    try { if (w && (hooks.inTown(w, dim.id) || (hooks.noDig && hooks.noDig(w, dim)) || playerBuilt(dim, w.x, w.y, w.z, 2) === true)) w = null; } catch {}   /* 町・城・人の 建物の そばの 水は 使わない */
    if (!w) return skip();   // 水が ない 所は なし（地方の 踏破にも 数えない）
    if (k === "isle") {
      C.push(`fill ${w.x - 2} ${w.y - 4} ${w.z - 2} ${w.x + 2} ${w.y} ${w.z + 2} sand`, `fill ${w.x - 1} ${w.y + 1} ${w.z - 1} ${w.x + 1} ${w.y + 1} ${w.z + 1} grass_block`, `fill ${w.x - 2} ${w.y + 2} ${w.z - 2} ${w.x + 2} ${w.y + 5} ${w.z + 2} air`);
      C.push(...chestCmds(w.x, w.y + 2, w.z, rollTier(4, Math.floor(i / 3)), dim.id));
      info = { x: w.x, y: w.y + 2, z: w.z };
    } else {
      C.push(`setblock ${w.x} ${w.y} ${w.z} oak_planks`, `fill ${w.x} ${w.y + 1} ${w.z} ${w.x} ${w.y + 2} ${w.z} oak_fence`, `setblock ${w.x} ${w.y + 3} ${w.z} lantern`);
      info = { x: w.x, y: w.y + 1, z: w.z };
    }
  } else if (k === "hollow") {
    const hy = Math.max(-50, gy - 20);
    C.push(`fill ${x - 2} ${hy - 1} ${z - 2} ${x + 2} ${hy - 1} ${z + 2} moss_block`, `fill ${x - 2} ${hy} ${z - 2} ${x + 2} ${hy + 3} ${z + 2} air`, `setblock ${x} ${hy + 4} ${z} glowstone`);
    C.push(...chestCmds(x, hy, z, rollTier(5, Math.floor(i / 3)), dim.id));
    info = { x, y: hy, z };
  } else if (k === "sky") {
    const sy = Math.min(300, gy + 45);
    C.push(`fill ${x - 2} ${sy - 2} ${z - 2} ${x + 2} ${sy - 1} ${z + 2} dirt`, `fill ${x - 3} ${sy} ${z - 3} ${x + 3} ${sy} ${z + 3} grass_block`, `fill ${x - 1} ${sy - 3} ${z - 1} ${x + 1} ${sy - 3} ${z + 1} dirt`);
    C.push(`setblock ${x + 2} ${sy + 1} ${z + 2} poppy`, `setblock ${x - 2} ${sy + 1} ${z + 2} dandelion`, ...chestCmds(x, sy + 1, z, rollTier(5, Math.floor(i / 3)), dim.id));
    info = { x, y: sy + 1, z };
  } else if (k === "spring") {
    C.push(`fill ${x - 3} ${gy} ${z - 3} ${x + 3} ${gy + 3} ${z + 3} air`, `fill ${x - 3} ${gy - 2} ${z - 3} ${x + 3} ${gy - 1} ${z + 3} stone_bricks`, `fill ${x - 2} ${gy - 1} ${z - 2} ${x + 2} ${gy - 1} ${z + 2} water`, `setblock ${x + 3} ${gy} ${z + 3} campfire`);
    info = { x, y: gy - 1, z };
  }
  for (const c of C) run(dim, c);
  setSpot(i, k, { ...info, ok: 1 });
  return true;
}

// ---------- 踏破率（32ブロックの マス）----------
const CELL = 32, TOTAL = new Map();
function cellOf(i, loc) {
  const R = WREGIONS[i], s = sp0(), N = Math.ceil((2 * R.r) / CELL);
  const gx = Math.floor((loc.x - s.x - R.c[0] + R.r) / CELL), gz = Math.floor((loc.z - s.z - R.c[1] + R.r) / CELL);
  if (gx < 0 || gz < 0 || gx >= N || gz >= N) return -1;
  return gz * N + gx;
}
function cellOk(i, c) { const R = WREGIONS[i], N = Math.ceil((2 * R.r) / CELL), gx = c % N, gz = Math.floor(c / N); const x = R.c[0] - R.r + (gx + 0.5) * CELL, z = R.c[1] - R.r + (gz + 0.5) * CELL; return Math.hypot(x - R.c[0], z - R.c[1]) <= R.r && regionIdx(x, z) === i; }
function totalCells(i) { const key = `${LAYOUT.v}:${i}`; if (TOTAL.has(key)) return TOTAL.get(key); const R = WREGIONS[i], N = Math.ceil((2 * R.r) / CELL); let n = 0; for (let c = 0; c < N * N; c++) if (cellOk(i, c)) n++; TOTAL.set(key, Math.max(1, n)); return Math.max(1, n); }
const bitGet = (a, c) => !!(a && (a[c >> 5] >>> (c & 31)) & 1);
function bitCount(a) { let n = 0; for (const v of a || []) { let x = v >>> 0; while (x) { x &= x - 1; n++; } } return n; }
export function explored(e, i) { return Math.min(100, Math.floor((bitCount(e.v[i]) / totalCells(i)) * 100)); }

// ---------- 異常気象（地方ごと・5分）----------
const WXK = {
  forest: ["濃霧", "fog", "minecraft:white_smoke_particle"], castle: ["荒野の 突風", "wind", "minecraft:basic_smoke_particle"], volcano: ["噴火の 熱波", "sun", "minecraft:lava_particle"],
  desert: ["砂嵐", "sand", "minecraft:basic_smoke_particle"], crystal: ["結晶の 共鳴", "holy", "minecraft:enchanting_table_particle"], port: ["海の 嵐", "storm", "minecraft:water_splash_particle"],
  dark: ["冥府の 霧", "dark", "minecraft:soul_particle"], snow: ["吹雪", "snow", "minecraft:snowflake_particle"], sky: ["天光の 日", "holy", "minecraft:totem_particle"],
};
const WXS = new Map();   // i -> end time
export function wxOf(i) { const t = WXS.get(i); if (!t || t < nowT()) return null; const k = WXK[WREGIONS[i]?.style]; return k ? { name: k[0], w: k[1], pt: k[2], end: t } : null; }
function wxTick() { const n = nowT(); WREGIONS.forEach((R, i) => { if (!WXK[R.style]) return; const t = WXS.get(i); if (t && t > n) return; if (t && t <= n) { WXS.delete(i); return; } if (rnd() < 0.3) WXS.set(i, n + 5 * 60000); }); }
const regAtLoc = (loc) => { const s = sp0(); return regionIdx(loc.x - s.x, loc.z - s.z); };
WX_HOOK.f = (p) => { if (p.dimension.id !== OW) return null; const w = wxOf(regAtLoc(p.location)); return w && rnd() < 0.75 ? w.w : null; };

// ---------- 環境の レア（10種）----------
export const ENVR = [
  { id: "peak", n: "山頂の 風の 子", c: "標高 115 より 高い 地上", el: "wind" },
  { id: "deep", n: "地底の 石の 子", c: "Y-10 より 深い 地下", el: "earth", fam: "golem" },
  { id: "dsrain", n: "砂漠の 雨の 子", c: "サンドリア砂漠に 雨が ふる とき", el: "water", reg: 4, w: "rain" },
  { id: "snight", n: "雪夜の 子", c: "フロストヘイム雪山の 夜", el: "ice", reg: 8, night: 1 },
  { id: "vnight", n: "火山の 夜の 竜", c: "ヴォルカ火山帯の 夜", el: "fire", fam: "dragon", reg: 3, night: 1 },
  { id: "seadawn", n: "夜明けの 海の 子", c: "夜明けの 海の 上", el: "water", fam: "aqua", sea: 1, dawn: 1 },
  { id: "frain", n: "森の 雨の 子", c: "シルヴァ大森林に 雨が ふる とき", el: "wood", reg: 1, w: "rain" },
  { id: "cmoon", n: "満月の 結晶の 子", c: "クリスタリアの 満月の 夜", el: "light", reg: 5, night: 1, moon: 0 },
  { id: "nnew", n: "新月の 冥府の 子", c: "ネクロス冥府領・終焉の地の 新月の 夜", el: "dark", reg: [7, 9], night: 1, moon: 4 },
  { id: "sstorm", n: "雷雨の 天空の 子", c: "セレスティア天空郷の 雷雨", el: "thunder", reg: 10, w: "thunder" },
];
let WORLD_W = ""; try { world.afterEvents.weatherChange.subscribe((ev) => { try { const w = String(ev.newWeather || ""); if (/rain|thunder/i.test(WORLD_W) && !/rain|thunder/i.test(w)) AFTER_RAIN.t = nowT(); WORLD_W = w; } catch {} }); } catch {}
const AFTER_RAIN = { t: 0 };
const ENV_SID = new Map();
export function envSid(r, lv = 50) {
  const rk = lv >= 55 ? "S" : "A", key = `${r.id}:${rk}`; if (ENV_SID.has(key)) return ENV_SID.get(key);
  const ok1 = (S) => !S.hidden && !S.fuseonly && !S.metalmon && S.fam !== "king" && S.fam !== "god" && (S.aff?.ge || [])[0] === r.el;
  let L = ORDER.filter((s) => ok1(SPECIES[s]) && SPECIES[s].rank === rk && (!r.fam || SPECIES[s].fam === r.fam));
  if (!L.length) L = ORDER.filter((s) => ok1(SPECIES[s]) && SPECIES[s].rank === rk);
  const sid = L.length ? L[hash(r.id) % L.length] : null; ENV_SID.set(key, sid); return sid;
}
function envNow(e) {
  const L = e.location, i = regAtLoc(L);
  let t = 0; try { t = world.getTimeOfDay(); } catch {}
  let moon = -1; try { moon = world.getMoonPhase(); } catch {}
  let w = WORLD_W; try { if (typeof e.dimension.getWeather === "function") w = String(e.dimension.getWeather()); } catch {}
  const night = t > 13000 && t < 23000, dawn = t >= 22800 || t < 1000, sea = e.hasTag("mrpg_sea");
  return ENVR.filter((r) => {
    if (r.id === "peak") return L.y >= 115 && !sea;
    if (r.id === "deep") return L.y < -10;
    if (r.reg !== undefined && !(Array.isArray(r.reg) ? r.reg.includes(i) : r.reg === i)) return false;
    if (r.w === "rain" && !/rain|thunder/i.test(w)) return false;
    if (r.w === "thunder" && !/thunder/i.test(w)) return false;
    if (r.night && !night) return false;
    if (r.moon !== undefined && moon !== r.moon) return false;
    if (r.sea && !sea) return false;
    if (r.dawn && !dawn) return false;
    return true;
  });
}
let CUR_WX = false, CUR_R8 = false;
system.run(() => {
  const prevO = hooks.override, prevS = hooks.shinyRate;
  hooks.override = (e, lv, sid) => {
    let r0 = null; try { r0 = prevO ? prevO(e, lv, sid) : null; } catch {}
    CUR_WX = false; CUR_R8 = false;
    try { const L0 = e.location; CUR_R8 = world.getAllPlayers().some((q) => q.dimension.id === e.dimension.id && hd(q.location, L0) < 64 && xRank(exOf(q).pt) >= 8); } catch {}
    if (e.dimension.id !== OW) return r0;
    const wx = wxOf(regAtLoc(e.location)); CUR_WX = !!wx;
    if (r0) return r0;
    const L = envNow(e); if (!L.length || rnd() > (wx ? 0.1 : 1 / 30)) return null;
    const r = pickA(L), s = envSid(r, lv); if (!s) return null;
    try { e.setDynamicProperty("mrpg:envr", r.id); } catch {}
    return { sid: s, lv: Math.min(100, lv + 3), q: 0.7, tags: ["mrpg_rare", "mrpg_envr"], msg: `§b§l${r.c}… §r§b${r.n}「§f${SPECIES[s].name}§b」の 気配が する！` };
  };
  hooks.shinyRate = (sid) => { let r = 1 / 250; try { r = prevS ? prevS(sid) : r; } catch {} return r * (CUR_WX ? 2 : 1) * (CUR_R8 ? 1.5 : 1); };
  FISH_HOOK.bonus = (p) => { if (p.dimension.id !== OW) return 0; const i = regAtLoc(p.location); return spotsOf(i).some((q) => q.k === "fish" && q.info && q.info.ok && hd(q.info, p.location) < 20) ? 1 : 0; };
});

// ---------- 賞金首 ----------
const EPI = ["片目の", "赤たてがみの", "岩くだきの", "夜鳴きの", "千年の", "はぐれ", "傷だらけの", "黒爪の", "嵐呼びの", "白牙の"];
export function bountyOf(i, day = dayNo()) {
  const R = WREGIONS[i], h = hash(`b${day}:${i}`), lv = Math.min(100, R.lv[1] + 5);
  const rk = lv < 25 ? "B" : lv < 45 ? "A" : lv < 70 ? "S" : "SS";
  const fams = Object.keys(R.fams || {}); const fam = fams.length ? fams[h % fams.length] : "beast";
  let L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && S.wild && S.rank === rk && S.fam === fam; });
  if (!L.length) L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && S.wild && S.rank === rk; });
  const sid = L[(h >> 4) % L.length];
  return { i, sid, lv, epi: EPI[(h >> 9) % EPI.length], gold: 2500 * (i + 1) };
}
const BOUNTY = new Map();   // i -> { id, t }
function bountyDone(e, i) { const b = e.b[dayNo()]; return Array.isArray(b) && b.includes(i); }
function spawnBounty(p, i) {
  const bo = bountyOf(i); if (!bo.sid) return;
  for (let k = 0; k < 6; k++) {
    const a = rnd() * Math.PI * 2, r = 40 + rnd() * 18, x = Math.floor(p.location.x + Math.cos(a) * r), z = Math.floor(p.location.z + Math.sin(a) * r);
    if (regAtLoc({ x, z }) !== i || hooks.inTown({ x, z }, OW)) continue;
    const y = surfaceY(p.dimension, x, z); if (y === null) continue;
    let e; try { e = p.dimension.spawnEntity(TYPE, { x: x + 0.5, y, z: z + 0.5 }); } catch { continue; }
    setLook(e, bo.sid); e.addTag("mrpg_boss"); e.addTag("mrpg_bounty"); try { e.setDynamicProperty("mrpg:bri", i); } catch {}
    try { e.setDynamicProperty("mrpg:lv", bo.lv); e.setDynamicProperty("mrpg:q", 0.8); e.setDynamicProperty("mrpg:rt", Date.now()); e.triggerEvent("mrpg:keep"); } catch {}
    e.nameTag = `§c§l【賞金首】§r§f${bo.epi}${SPECIES[bo.sid].name} §7Lv${bo.lv}`;
    BOUNTY.set(i, { id: e.id, t: nowT(), x, z });
    try { p.sendMessage(`§c§l大きな 足あとが ある…§r§c ${bo.epi}${SPECIES[bo.sid].name}（賞金首）が 近い！ §7${dirTo(p.location, { x, z })}・約${Math.round(hd(p.location, { x, z }))}m`); p.playSound("mob.wither.ambient", { pitch: 0.7, volume: 0.6 }); } catch {}
    return;
  }
}
function bountyAlive(i) {
  const b = BOUNTY.get(i); if (!b) return null;
  let e = null; try { e = world.getEntity(b.id); } catch {}
  if (!e || !e.isValid()) { BOUNTY.delete(i); return null; }
  if (nowT() - b.t > 6 * 60000 && !e.hasTag("mrpg_battle")) { try { e.remove(); } catch {} BOUNTY.delete(i); return null; }
  return e;
}

// ---------- 迷子・流れ星・光の柱・採集ポイント（その場かぎり）----------
const LOST = new Map();    // pid -> { id, t }
const EVT = new Map();     // pid -> { kind, x, y, z, t }
const NODES = new Map();   // "x,y,z" -> { i, t, pid }
const NODE_B = "minecraft:amethyst_cluster", TOPN = new Map();
function groundNear(p, r0, r1, top) {
  for (let k = 0; k < 5; k++) {
    const a = rnd() * Math.PI * 2, r = r0 + rnd() * (r1 - r0), x = Math.floor(p.location.x + Math.cos(a) * r), z = Math.floor(p.location.z + Math.sin(a) * r);
    if (hooks.inTown({ x, z }, OW)) continue;
    let t; try { t = p.dimension.getTopmostBlock({ x, z }); } catch { continue; }
    if (!t || t.isLiquid || /water|lava|leaves|log|grass$|short_grass|tallgrass|fern|flower|tulip|orchid|allium|bluet|daisy|poppy|dandelion|bush|snow_layer|wheat|carrot|potato|beetroot|sapling|vine|lily|cactus|bamboo|mushroom|torch|carpet|rail|slab|stairs|fence|wall/.test(t.typeId.replace("grass_block", "grassblock"))) continue;
    if (BUILT.test(t.typeId)) continue;   /* 家の 屋根の 上には 出さない */
    const y = t.location.y + 1; if (Math.abs(y - p.location.y) > 24) continue;
    if (top !== undefined && regAtLoc({ x, z }) > top) continue;   /* まだ 開いて いない 地方には 出さない */
    return { x, y, z };
  }
  return null;
}
const isNode = (k) => NODES.has(k);
function placeNode(p, i) {
  let mine = 0; for (const v of NODES.values()) if (v.pid === p.id && nowT() - v.t < 4 * 60000) mine++;
  if (mine >= 2) return;
  const g = groundNear(p, 10, 24, TOPN.get(p.id)); if (!g) return;
  try { const b = p.dimension.getBlock(g); if (!b || !b.isAir) return; } catch { return; }
  run(p.dimension, `setblock ${g.x} ${g.y} ${g.z} amethyst_cluster`);
  NODES.set(`${g.x},${g.y},${g.z}`, { i, t: nowT(), pid: p.id, ...g });
  try { barNote(p).setActionBar(`§d近くで 何かが 光っている… §7（${dirTo(p.location, g)}）`); } catch {}
}
function cleanNodes() {
  const n = nowT();
  for (const [k, v] of NODES) if (n - v.t > 4 * 60000) {
    let b = null; try { b = world.getDimension("overworld").getBlock(v); } catch {}
    if (b && b.typeId === NODE_B) run(world.getDimension("overworld"), `setblock ${v.x} ${v.y} ${v.z} air`);
    if (b || n - v.t > 60 * 60000) NODES.delete(k);   /* 読みこめない ときは 記録を 残して あとで 消す */
  }
}
const FOSSIL_B = /^minecraft:(sand|red_sand|sandstone|red_sandstone|.*terracotta|coarse_dirt|gravel|clay)$/;
const FOSSIL_T = new Map();
try {
  world.afterEvents.playerBreakBlock.subscribe((ev) => {
    const p = ev.player, b = ev.block; if (!p || !b || b.dimension.id !== OW) return;
    const L = b.location, key = `${L.x},${L.y},${L.z}`;
    if (NODES.has(key)) {
      const v = NODES.get(key); NODES.delete(key);
      const id = MATS[v.i]; if (!id) return;
      const e = exOf(p), n = xRank(e.pt) >= 2 && rnd() < 0.2 ? 2 : 1;
      giveItem(p, `mrpg:${id}`, n); addPt(p, e, 2); exSave(p);
      try { barNote(p).setActionBar(`§d${ITEMS[id].name} §fを ${n}こ 手に入れた！`); sound(p, "random.orb", 1.4); } catch {}
      return;
    }
    const id0 = ev.brokenBlockPermutation?.type?.id || "";
    const i = regAtLoc(L), deep = L.y < 0 && /deepslate|tuff/.test(id0);
    if (!deep && !((i === 2 || i === 4) && FOSSIL_B.test(id0))) return;
    const t = FOSSIL_T.get(p.id) || 0; if (nowT() - t < 15000) return;   // 掘りつづけて 集めすぎない
    const ex = exOf(p), dn = dayNo(); if (!ex.fd || ex.fd[0] !== dn) ex.fd = [dn, 0]; if (ex.fd[1] >= 12) return;   /* 1日 12こ まで（砂を 置いて こわす くり返しで 集めすぎない） */
    const r = rnd();
    const got = r < 1 / 1200 ? "x_fossil2" : r < 1 / 70 ? "x_fossil" : null; if (!got) return;
    FOSSIL_T.set(p.id, nowT()); ex.fd[1]++;
    giveItem(p, `mrpg:${got}`, 1); const e = exOf(p); e.fo = (e.fo || 0) + 1; addPt(p, e, got === "x_fossil2" ? 10 : 3); exSave(p);
    try { p.sendMessage(`§6§l${got === "x_fossil2" ? "大きな" : ""}化石を 掘りあてた！§r §f${ITEMS[got].name}`); sound(p, "random.levelup", 1.6); } catch {}
  });
} catch {}
export const MATS = ["x_arca", "x_silva", "x_ruins", "x_volka", "x_sand", "x_crys", "x_mari", "x_necro", "x_frost", "x_ragna", "x_celes"];

// 迷子の モンスター: なぐると 戦わずに 話せる
function spawnLost(p, i, d) {
  const g = groundNear(p, 14, 24, openUpTo(d)); if (!g) return;
  const lv = Math.max(1, Math.min(100, regionLv(g) - 2)), cap = rankCap(d);
  const rk = Math.min(cap, lv < 20 ? 2 : lv < 45 ? 3 : 4);   /* D〜B（売って もうけにくい） */
  const fams = Object.keys(WREGIONS[i].fams || {});
  let L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && S.wild && rIdx(s) === rk && fams.includes(S.fam); });
  if (!L.length) L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && S.wild && rIdx(s) === rk; });
  if (!L.length) return;
  const sid = pickA(L);
  let e; try { e = p.dimension.spawnEntity(TYPE, { x: g.x + 0.5, y: g.y, z: g.z + 0.5 }); } catch { return; }
  setLook(e, sid); e.addTag("mrpg_lost");
  try { e.setDynamicProperty("mrpg:lv", lv); e.setDynamicProperty("mrpg:lost", p.id); e.setDynamicProperty("mrpg:rt", Date.now()); e.addTag("mrpg_keep"); e.triggerEvent("mrpg:keep"); } catch {}   /* 5分 だれも 近くに いなければ field.js が 片づける */
  e.nameTag = `§b？ 迷子の ${SPECIES[sid].name} §7Lv${lv}`;
  LOST.set(p.id, { id: e.id, t: nowT() });
  try { p.sendMessage(`§b迷子の ${SPECIES[sid].name}が さみしそうに している… §7（${dirTo(p.location, g)}・なぐると 話しかけられる）`); } catch {}
}
HIT_HOOKS.push((p, e) => {
  if (!e.hasTag("mrpg_lost")) return false;
  if (busy.has(p.id)) return true;
  busy.add(p.id);
  system.run(async () => {
    try {
      if (!e.isValid()) return;
      let sid; try { sid = e.getDynamicProperty("mrpg:sid"); } catch {}
      let lv = 5; try { lv = e.getDynamicProperty("mrpg:lv") || 5; } catch {}
      if (!e.isValid()) return;
      let own; try { own = e.getDynamicProperty("mrpg:lost"); } catch {}
      if (own && own !== p.id) { await notice(p, "迷子の モンスター", "§7この 子は ほかの 人に なついて いる みたいだ。"); return; }
      if (!SPECIES[sid]) return;
      const yes = await confirm(p, "迷子の モンスター", `§f${SPECIES[sid].name}（Lv${lv}・ランク${SPECIES[sid].rank}）が こちらを 見ている。\n§7帰る 場所が ないらしい……。`, "仲間に する", "そっと しておく");
      if (!yes || !e.isValid() || e.hasTag("mrpg_done")) return;
      const d = load(p); if (!d) return;
      e.addTag("mrpg_done");
      const m = makeMonster(sid, lv, true); const where = addMon(d, m); save(p, d);
      try { e.remove(); } catch {}
      LOST.delete(p.id);
      const x = exOf(p); x.lo = (x.lo || 0) + 1; addPt(p, x, 10); exSave(p);
      sound(p, "random.levelup", 1.3);
      await notice(p, "迷子の モンスター", `§a${SPECIES[sid].name}が 仲間に なった！ §7（${where === "party" ? "パーティ" : "預かり所"}へ）`);
    } finally { busy.delete(p.id); }
  });
  return true;
});

// 流れ星・光の柱
function startEvt(p, kind) {
  const g = groundNear(p, 40, 60, TOPN.get(p.id)); if (!g) return;
  const v = { kind, ...g, t: nowT() }; EVT.set(p.id, v);
  naviPush(p, { name: kind === "star" ? "流れ星" : "光の柱", x: g.x, z: g.z, dim: OW });
  try { showTitle(p, kind === "star" ? "§e§l流れ星が 落ちた！" : "§a§l光の柱が 立った！", { subtitle: `§f${dirTo(p.location, g)}・約${Math.round(hd(p.location, g))}m`, fadeInDuration: 6, stayDuration: 40, fadeOutDuration: 10 }); sound(p, kind === "star" ? "random.orb" : "random.levelup", 0.6); } catch {}
  if (kind === "star") for (let k = 0; k < 10; k++) fx(p.dimension, "minecraft:totem_particle", { x: g.x + k * 2, y: g.y + 4 + k * 4, z: g.z });
}
function evtTick(p, d, e) {
  const v = EVT.get(p.id); if (!v) { if (e.nvO !== undefined) naviPop(p); return; }   /* 抜けて もどった ときも 元に もどす */
  if (nowT() - v.t > 5 * 60000) { EVT.delete(p.id); naviPop(p); return; }
  for (let k = 0; k < 6; k++) fx(p.dimension, v.kind === "star" ? "minecraft:totem_particle" : "minecraft:villager_happy", { x: v.x + 0.5, y: v.y + k * 3, z: v.z + 0.5 });
  if (hd(p.location, v) > 3 || Math.abs(p.location.y - v.y) > 6) return;
  EVT.delete(p.id);
  const i = regAtLoc(v), up = xRank(e.pt) >= 7 ? 1 : 0;
  for (const c of chestCmds(v.x, v.y, v.z, rollTier(3 + up, Math.floor(i / 3)), OW)) run(p.dimension, c);
  const L = prize(p, d, i, 0, 1); const g = giveGold(d, 300 * (i + 1)); save(p, d);
  e.st = (e.st || 0) + 1; addPt(p, e, 8); exSave(p);
  naviPop(p);
  try { p.sendMessage(`§e${v.kind === "star" ? "星の 落ちた 場所に" : "光の 柱の 下に"} 宝箱が あった！ §f${g} ${L.join(" ")}`); sound(p, "random.chestopen"); } catch {}
}

// ---------- なぞの 地図 ----------
function terrainWord(dim, x, z) {
  let t; try { t = dim.getTopmostBlock({ x, z }); } catch { return null; }
  if (!t) return null; const id = t.typeId;
  return /water/.test(id) ? "水べ" : /sand/.test(id) ? "砂地" : /snow|ice/.test(id) ? "雪の 上" : /leaves|log/.test(id) ? "木の 下" : /stone|deepslate|basalt|blackstone|calcite|tuff|andesite|granite|diorite/.test(id) ? "岩場" : /grass/.test(id) ? "草地" : "土の 上";
}
function nearTown(loc) { let best = null, bd = 1e9; for (const t of TOWNS) { const g = getTown(t.id); if (!g || !g.built) continue; const dd = hd(g, loc); if (dd < bd) { bd = dd; best = { t, g, dd }; } } return best; }
export async function useRmap(p, d) {
  const e = exOf(p);
  if (e.rm) { await notice(p, "なぞの 地図", rmapHint(p, e)); return; }
  if (p.dimension.id !== OW) { await notice(p, "なぞの 地図", "§7この 地図は 地上の ものだ。"); return; }
  if (!(await confirm(p, "なぞの 地図", "§f地図を ひらきますか？\n§7どこかの 宝の 場所が ことばで 書かれている（250〜450m 先）。コンパスは 近くまで 使えない。", "ひらく", "やめる"))) return;
  let tg = null; const top = openUpTo(d);
  for (let k = 0; k < 12 && !tg; k++) { const a = rnd() * Math.PI * 2, r = 250 + rnd() * 200, x = Math.floor(p.location.x + Math.cos(a) * r), z = Math.floor(p.location.z + Math.sin(a) * r); if (regAtLoc({ x, z }) <= top && !hooks.inTown({ x, z }, OW)) tg = { x, z }; }
  if (!tg) { await notice(p, "なぞの 地図", "§7地図が かすれて 読めない……（別の 場所で もう一度）"); return; }
  if (!takeItem(p, "mrpg:x_rmap")) return;
  e.rm = { ...tg, t: nowT() }; exSave(p, true);
  await notice(p, "なぞの 地図", rmapHint(p, e));
}
function rmapHint(p, e) {
  const T = e.rm, nt = nearTown(T), R = WREGIONS[regAtLoc(T)], dd = Math.round(hd(p.location, T));
  const L = [`§6地図の ことば: §f「${R ? R.name : "どこか"}の ${nt ? `${nt.t.name}から ${dirTo(nt.g, T)}へ 約${Math.round(nt.dd / 50) * 50}m` : "どこか"}」`];
  if (xRank(e.pt) >= 3) L.push(`§7（探索ランクの 特典: いまの 場所から ${dirTo(p.location, T)}）`);
  if (dd < 150) L.push(`§e宝が 近い…${(() => { const w = terrainWord(p.dimension, T.x, T.z); return w ? ` 地面は 「${w}」らしい` : ""; })()}`);
  L.push("§740m まで 近づくと コンパスが 反応する。着くと 宝箱。");
  return L.join("\n");
}
function rmapTick(p, d, e) {
  const T = e.rm; if (!T || p.dimension.id !== OW) return;
  const dd = hd(p.location, T);
  if (dd < 40 && !T.nv) { T.nv = 1; naviPush(p, { name: "なぞの 宝", x: T.x, z: T.z, dim: OW }); exSave(p); try { barNote(p).setActionBar("§6地図が 光った！ 宝は すぐ そこだ"); } catch {} }
  if (dd < 40) { let y = p.location.y; try { const t = p.dimension.getTopmostBlock({ x: T.x, z: T.z }); if (t) y = t.location.y + 1; } catch {} fx(p.dimension, "minecraft:villager_happy", { x: T.x + 0.5, y: y + 1, z: T.z + 0.5 }); }
  if (dd > 3) return;
  let y = Math.floor(p.location.y); try { const t = p.dimension.getTopmostBlock({ x: T.x, z: T.z }); if (t && !t.isLiquid) y = t.location.y + 1; } catch {}
  e.rm = null; naviPop(p); e.rmn = (e.rmn || 0) + 1; addPt(p, e, 12); exSave(p, true);
  const i = regAtLoc(T);
  for (const c of chestCmds(T.x, y, T.z, rollTier(5, Math.floor(i / 4)), OW)) run(p.dimension, c);
  const L = prize(p, d, i, 1, 1); const g = giveGold(d, 400 * (i + 1)); save(p, d);
  try { p.sendMessage(`§6§lなぞの 宝を 見つけた！§r §f${g} ${L.join(" ")}`); sound(p, "random.chestopen"); } catch {}
}

// ---------- 秘境の 発見 ----------
const LORE = [
  "はじまりの 草原には 最初の 魔物使いが 眠る。かれは 一匹の スライムと 世界を 歩いた。",
  "森の 古木は 千年 生きる。根の 下には 森の 声を 聞く 者の 道具が 埋まって いる。",
  "荒野の 城は もとは 一つの 国だった。歯車は いまも 地の 下で まわって いる。",
  "火山の 鍛冶師は 竜の 炎で 刃を きたえた。溶岩石は その 火の なごり。",
  "砂の 下には 古い 竜の 骨が ある。掘る 者には 古代の 魔物が 目を さます。",
  "結晶は 月の 光を ためる。満月の 夜には 結晶の 子が 生まれる と いう。",
  "島の 民は 潮を 読み、真珠に 願いを こめた。夜明けの 海には 願いの 子が 泳ぐ。",
  "冥府の 灯は 迷った 魂を 送る 火。新月の 夜は 灯が いちばん 強く なる。",
  "雪山の 頂には 氷の 王が いた。吹雪の 夜は 王の 子らが 山を 歩く。",
  "終わりの 地には 灰が 降る。灰の 中から 新しい 芽が 出る ことも ある。",
  "天空の 島は 地上から 飛びたった 大地。羽を もつ 者だけが その 道を 知る。",
];
function discover(p, d, e, q, log) {
  const key = `${q.i}.${q.k}`; if (e.f[key]) return;
  e.f[key] = 1;
  const K = KINDS[q.k], R = WREGIONS[q.i];
  const msg = [];
  if (q.k === "tower") {
    e.t[q.i] = 1; addPt(p, e, 15);
    msg.push(`§a§l${R.short}の 展望台に 登った！`, `§fまわりの 秘境が 探索手帳に のった（コンパスで 案内できる）`, `§7この 展望台へは 探索手帳から ワープできる`);
  } else if (q.k === "stele") {
    addPt(p, e, 8); const sd = seedId(1); if (ITEMS[sd]) giveItem(p, `mrpg:${sd}`, 1);
    msg.push(`§6§l古代の 石碑`, `§f「${LORE[q.i] || ""}」`, ITEMS[sd] ? `§b${ITEMS[sd].name} を ひろった` : "");
  } else if (q.k === "spring") { addPt(p, e, 5); msg.push(`§b§l秘湯を 見つけた！`, "§f湯に つかると 仲間が 元気に なる（3分ごと）"); }
  else if (q.k === "fish") { addPt(p, e, 5); msg.push(`§b§l釣りの 名所を 見つけた！`, "§fここ（20m 以内）で 釣ると 1段 上の 竿と 同じに なる"); }
  else {
    addPt(p, e, 12); const L = prize(p, d, q.i, 1, 1); const g = giveGold(d, 600 * (q.i + 1)); save(p, d);
    msg.push(`§d§l秘境「${K.n}」を 見つけた！`, `§f${g} ${L.join(" ")}`, "§7宝箱も 開けて みよう（宝箱は ワールドに 1つ）");
  }
  exSave(p, true);
  try { showTitle(p, `§l${K.n}`, { subtitle: `§f${R.name}`, fadeInDuration: 6, stayDuration: 40, fadeOutDuration: 10 }); sound(p, "random.levelup", 1.1); } catch {}
  for (const m of msg) if (m) try { p.sendMessage(m); } catch {}
  checkDone(p, d, e, q.i);
}
export function regionDone(e, i) { const keys = kindsOf(i).filter((k) => k === "tower" || k === "stele" || SECRET.includes(k)); return explored(e, i) >= 70 && keys.every((k) => e.f[`${i}.${k}`] || (spotInfo(i, k) && spotInfo(i, k).skip)); }
function checkDone(p, d, e, i) { if (regionDone(e, i) && !e.cl[i] && !e.cln?.[i]) { e.cln = e.cln || {}; e.cln[i] = 1; exSave(p); try { p.sendMessage(`§a§l${WREGIONS[i].name}を 踏破した！ §r§a探索手帳で ごほうびを 受けとれる`); } catch {} } }

// ---------- 戦いの あと（賞金首・環境の レア）----------
battleHooks.push((B, x) => {
  const { p, d } = x; const log = (x.plog = x.plog || []);
  try { if (!p.isValid()) return; } catch { return; }
  const won = B.result === "win" || B.result === "scout" || B.scouted;
  if (!won) return;
  const e = exOf(p);
  if (B.bounty && B.result === "win") {
    const i = typeof B.bri === "number" ? B.bri : regAtLoc(B.center || p.location);
    if (WREGIONS[i] && i <= openUpTo(d) && !bountyDone(e, i)) {
      const day = dayNo(); for (const k of Object.keys(e.b)) if (+k < day - 1) delete e.b[k];
      e.b[day] = [...(e.b[day] || []), i]; e.bn = (e.bn || 0) + 1;
      const bo = bountyOf(i);
      log.push(`§c§l賞金首を 倒した！ §r§e${giveGold(d, bo.gold)}`, ...prize(p, d, i, 2, 1).map((s) => `§f手配書の ほうび: ${s}`));
      addPt(p, e, 20, log); if (e.bn >= 10) award(p, d, "ex_bounty10", log);
      BOUNTY.delete(i); exSave(p, true);
    }
  }
  if (B.envr && ENVR.some((r) => r.id === B.envr) && !e.r[B.envr]) {
    e.r[B.envr] = 1; addPt(p, e, 15, log);
    log.push(`§b§l環境の レアを 記録した！ §r§b（${Object.keys(e.r).length}/${ENVR.length}）`);
    if (ENVR.every((r) => e.r[r.id])) award(p, d, "ex_env", log);
    exSave(p, true);
  }
});

// ---------- ライドの 熟練度 ----------
export const RIDE_LV = [500, 1500, 3500, 7000, 12000];
export const rideLv = (m) => RIDE_LV.filter((n) => m >= n).length;
hooks.rideMul = (e, m) => {
  let pid; try { pid = e.getDynamicProperty("mrpg:owner"); } catch {}
  const p = pid && world.getAllPlayers().find((q) => q.id === pid); if (!p || !m) return 1;
  const x = exOf(p); return 1 + rideLv(x.rd[m.id] || 0) * 0.04 + (xRank(x.pt) >= 6 ? 0.05 : 0);
};
const LASTP = new Map();
function rideTick(p, e) {
  let r = null; try { r = p.getComponent("minecraft:riding")?.entityRidingOn; } catch {}
  if (!r || !r.hasTag || !r.hasTag("mrpg_pet")) { LASTP.delete(p.id); return; }
  let mid; try { mid = r.getDynamicProperty("mrpg:mid"); } catch {}
  if (!mid) return;
  const L = p.location, last = LASTP.get(p.id); LASTP.set(p.id, { x: L.x, z: L.z, mid });
  if (!last || last.mid !== mid) return;
  const dd = hd(L, last); if (dd < 0.5 || dd > 80) return;
  const m0 = e.rd[mid] || 0, m1 = m0 + dd; e.rd[mid] = Math.round(m1); exSave(p);
  if (rideLv(m1) > rideLv(m0)) {
    let sid; try { sid = r.getDynamicProperty("mrpg:sid"); } catch {}
    const d = load(p); const m = d && [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === mid);
    try { if (sid && m) setSpeed(r, sid, ((SPECIES[sid].traits || []).includes("ride_fast") ? 1.3 : 1) * hooks.rideMul(r, m)); } catch {}
    try { p.sendMessage(`§a§lライドの 熟練度が ${rideLv(m1)} に 上がった！ §r§a（速さ +${rideLv(m1) * 4}%）`); sound(p, "random.levelup", 1.5); } catch {}
  }
}

// ---------- 見はり（2秒ごと）----------
let tk = 0, buildBusy = false;
const SEEN = new Map();   // pid -> { i, wx, hint:Set }
system.runInterval(() => {
  tk++;
  if (tk % 150 === 1) wxTick();
  if (tk % 30 === 0) cleanNodes();
  if (tk % 150 === 75) { try { for (const b of world.getDimension("overworld").getEntities({ type: TYPE, tags: ["mrpg_bounty"], excludeTags: ["mrpg_battle"] })) { const t = b.getDynamicProperty("mrpg:rt"); if (typeof t !== "number" || nowT() - t > 6 * 60000) b.remove(); } } catch {} }   /* 入りなおした あとに 残った 賞金首を 片づける */
  for (const p of world.getAllPlayers()) {
    try {
      if (tk % 15 === 0 && DIRTY.has(p.id)) exFlush(p);   /* 30秒ごとに 書く（町・画面の 中でも） */
      if (p.dimension.id !== OW || busy.has(p.id)) continue;
      if (hooks.noSpawn && hooks.noSpawn(p)) continue;
      const d = load(p); if (!d || !d.party) continue;
      const e = exOf(p), L = p.location, i = regAtLoc(L);
      const top = openUpTo(d); TOPN.set(p.id, top);
      if (i > top) continue;   // まだ 開いて いない 地方
      const sn = SEEN.get(p.id) || { i: -1, wx: null, hint: new Set() }; SEEN.set(p.id, sn);
      // 踏破率
      const c = cellOf(i, L);
      if (c >= 0 && cellOk(i, c)) { const a = (e.v[i] = Array.isArray(e.v[i]) ? e.v[i] : []); while (a.length <= c >> 5) a.push(0); if (!bitGet(a, c)) { a[c >> 5] = (a[c >> 5] | (1 << (c & 31))) >>> 0; addPt(p, e, 1); exSave(p); if (bitCount(a) % 10 === 0) { checkDone(p, d, e, i); exSave(p, true); } } }
      // 地方に 入った・異常気象
      const wx = wxOf(i);
      if (sn.i !== i || (wx && sn.wx !== wx.end)) { sn.i = i; sn.wx = wx ? wx.end : null; try { barNote(p).setActionBar(`§f${WREGIONS[i].name} §7踏破 ${explored(e, i)}%${wx ? `  §e§l異常気象: ${wx.name}§r§7（レア・色違いが 出やすい）` : ""}`); } catch {} }
      if (wx && tk % 2 === 0) for (let k = 0; k < 3; k++) fx(p.dimension, wx.pt, { x: L.x + (rnd() - 0.5) * 12, y: L.y + 2 + rnd() * 3, z: L.z + (rnd() - 0.5) * 12 });
      // 秘境・展望台・石碑
      for (const q of spotsOf(i)) {
        const dd = hd(L, q);
        if (!q.info) { if (dd < 72 && !buildBusy && !building()) { buildBusy = true; try { buildSpot(p.dimension, i, q); } finally { buildBusy = false; } } continue; }
        if (q.info.skip) continue;
        const I = q.info, dh = hd(L, I);
        if (q.k === "spring") { if (dh < 3.5 && Math.abs(L.y - I.y) < 2.5 && (p.dimension.getBlock({ x: Math.floor(L.x), y: Math.floor(L.y), z: Math.floor(L.z) })?.typeId || "").includes("water")) { if (!e.f[`${i}.spring`]) discover(p, d, e, q); if (nowT() - (e.hs || 0) > 180000) { e.hs = nowT(); exSave(p, true); for (const m of d.party) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } save(p, d); try { p.sendMessage("§b§lぽかぽか… §r§b仲間の HPと MPが 全回復した！"); sound(p, "random.splash", 1.4); } catch {} } } continue; }
        if (e.f[`${i}.${q.k}`]) continue;
        const near = q.k === "tower" ? dh < 4 && L.y >= I.y - 1.5 : q.k === "fish" ? dh < 6 : dh < 4 && Math.abs(L.y - I.y) < 5;
        if (near) { discover(p, d, e, q); continue; }
        if (KINDS[q.k].secret && dh < 100 && xRank(e.pt) >= 4 && !sn.hint.has(q.k + i)) { sn.hint.add(q.k + i); try { barNote(p).setActionBar(`§d何かの 気配が する… §7（${dirTo(L, I)}・${KINDS[q.k].n}？）`); } catch {} }
      }
      // ライド・なぞの 地図・流れ星
      rideTick(p, e);
      rmapTick(p, d, e);
      evtTick(p, d, e);
      // 少しずつ 起きる こと（プレイヤーごとに ずらす）
      const ph = (tk + (hash(p.id) % 30)) % 30;
      if (ph === 0 && rnd() < (xRank(e.pt) >= 5 ? 0.7 : 0.5)) placeNode(p, i);
      if (ph === 10) {
        if (!bountyDone(e, i) && !bountyAlive(i) && rnd() < 0.25) spawnBounty(p, i);
        else { const b = bountyAlive(i); if (b && hd(L, b.location) > 12 && hd(L, b.location) < 90) { const v = { x: b.location.x - L.x, z: b.location.z - L.z }, n = Math.hypot(v.x, v.z) || 1; for (let k = 1; k <= 5; k++) fx(p.dimension, "minecraft:basic_smoke_particle", { x: L.x + (v.x / n) * k * 2, y: L.y + 0.1, z: L.z + (v.z / n) * k * 2 }); } }
      }
      if (ph === 20) {
        const lo = LOST.get(p.id);
        if (lo && nowT() - lo.t > 3 * 60000) { try { const x = world.getEntity(lo.id); if (x && !x.hasTag("mrpg_done")) x.remove(); } catch {} LOST.delete(p.id); }
        else if (!lo && rnd() < 0.05) spawnLost(p, i, d);
        if (!EVT.has(p.id)) {
          let t = 0; try { t = world.getTimeOfDay(); } catch {}
          if (t > 13000 && t < 23000 && rnd() < 0.07) startEvt(p, "star");
          else if (nowT() - AFTER_RAIN.t < 120000 && rnd() < 0.5) { AFTER_RAIN.t = 0; startEvt(p, "pillar"); }
          else if (t < 12000 && rnd() < 0.02) startEvt(p, "pillar");
        }
      }
    } catch (err) { if (tk % 300 === 0) console.warn(`[MonsterRPG] explore: ${err}`); }
  }
}, 40);

// ---------- 化石の 復元 ----------
export async function useFossil(p, d) {
  if (!(await confirm(p, "古代の 化石", "§f化石を 復元しますか？\n§7古代の 竜系・物質系の モンスターが 目を さます（ランクは 物語の 進みまで）。", "復元する", "やめる"))) return;
  const cap = rankCap(d), w = [[3, 30], [4, 35], [5, 25], [6, 10]].filter(([r]) => r <= cap);
  if (!w.length) { await notice(p, "古代の 化石", "§7まだ 化石の 力を 引き出せない……（物語を 進めよう）"); return; }
  let x = rnd() * w.reduce((a, b) => a + b[1], 0), rk = w[0][0]; for (const [r, n] of w) { x -= n; if (x < 0) { rk = r; break; } }
  const L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && (S.fam === "dragon" || S.fam === "golem") && rIdx(s) === rk; });
  if (!L.length) return;
  if (!takeItem(p, "mrpg:x_fossil2")) return;
  const m = makeMonster(pickA(L), 5, true); m.plus = Math.max(m.plus || 0, 10);
  const where = addMon(d, m); save(p, d);
  const e = exOf(p); addPt(p, e, 5); exSave(p, true);
  sound(p, "random.levelup", 0.9);
  await notice(p, "古代の 化石", `§6§l${SPECIES[m.sp].name}§r§6（ランク${SPECIES[m.sp].rank}）が よみがえった！ §7（+10・${where === "party" ? "パーティ" : "預かり所"}へ）`);
}

// ---------- 探索手帳 ----------
const matLine = (p) => MATS.map((id, i) => `§f${ITEMS[id]?.name || id} §e${countItem(p, `mrpg:${id}`)}`).join("§7・");
export async function exploreMenu(p, d) {
  for (;;) {
    const e = exOf(p), r = xRank(e.pt), nx = RANKS_X[r];
    const top = Math.min(openUpTo(d), WREGIONS.length - 1);
    const all = WREGIONS.slice(0, top + 1).reduce((a, _, i) => a + explored(e, i), 0) / (top + 1);
    const body = [`§a探索ランク ${r}「${RANKS_X[r - 1][1]}」 §7${e.pt}pt${nx ? `（次まで ${nx[0] - e.pt}）` : ""}`, `§f開いて いる 地方の 踏破率 §e${Math.floor(all)}%`,
      `§f見つけた 秘境 §e${Object.keys(e.f).filter((k) => KINDS[k.split(".")[1]]?.secret).length}§f・環境の レア §e${Object.keys(e.r).length}/${ENVR.length}§f・賞金首 §e${e.bn || 0}回`].join("\n");
    const s = await choose(p, "探索手帳", body, [B("§l地方の 記録\n§8踏破率・秘境・案内", ICON("i_zukan")), B("§c§l賞金首の 手配書\n§8今日の 賞金首", ICON("i_fight")), B("§l今日の うわさ\n§8異常気象・レアの ヒント", ICON("i_help")),
      B("§d§l素材の 交換\n§8地方の 素材・化石", ICON("i_shop")), B("§b§l展望台へ ワープ", ICON("i_run")), B("§l環境の レア\n§8出る 条件", ICON("i_zukan")), B("§l探索ランクの 特典", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    if (s === 0) await regionList(p, d);
    else if (s === 1) await bountyBoard(p, d);
    else if (s === 2) await rumor(p, d);
    else if (s === 3) await exchange(p, d);
    else if (s === 4) await towerWarp(p, d);
    else if (s === 5) await notice(p, "環境の レア", ENVR.map((r) => { const s2 = envSid(r); return `${e.r[r.id] ? "§a○" : "§7・"} §f${r.n}${e.r[r.id] && s2 ? `（${SPECIES[s2].name}）` : ""}\n  §7条件: ${r.c}`; }).join("\n") + "\n§8異常気象の ときは 出やすい。倒すか スカウトで 記録");
    else if (s === 6) await notice(p, "探索ランクの 特典", [RANKS_X.map(([n, nm], i) => `${i + 1 <= r ? "§a" : "§7"}${i + 1}. ${nm} §8${n}pt`).join("\n"), "", ...PERKS.map(([k, t]) => `${r >= k ? "§a○" : "§7・"} ランク${k}: ${t}`), "", "§7ポイント: 新しい 場所を 歩く・秘境・石碑・採集・化石・賞金首・流れ星・迷子 など"].join("\n"));
    else return;
  }
}
async function regionList(p, d) {
  const e = exOf(p), top = Math.min(openUpTo(d), WREGIONS.length - 1);
  const L = WREGIONS.slice(0, top + 1).map((R, i) => B(`${R.col || "§f"}§l${R.name}\n§8踏破 ${explored(e, i)}% ${e.cl[i] ? "§a★踏破" : e.t[i] ? "§b展望台○" : ""}`, ICON("i_walk")));
  const k = await paged(p, "地方の 記録", "§7地方を えらぶ", L, 8); if (k < 0) return;
  await regionPage(p, d, k);
}
async function regionPage(p, d, i) {
  for (;;) {
    const e = exOf(p), R = WREGIONS[i], S = spotsOf(i).filter((q) => !(q.info && q.info.skip));
    const lines = [`§f踏破率 §e${explored(e, i)}%`, `§f素材: ${ITEMS[MATS[i]]?.name}（光る 採集ポイントを こわす）`, ""];
    const btn = [], act = [];
    for (const q of S) {
      const got = !!e.f[`${i}.${q.k}`], seen = got || e.t[i] || !KINDS[q.k].secret;
      lines.push(`${got ? "§a○" : "§7・"} §f${seen ? KINDS[q.k].n : "？？？"} §8${seen ? KINDS[q.k].h : "展望台に 登ると わかる"}`);
      if (seen && !got) { btn.push(B(`§lコンパスで 案内: ${KINDS[q.k].n}`, ICON("i_run"))); act.push(q); }
    }
    const done = regionDone(e, i);
    lines.push("", done ? (e.cl[i] ? "§a★ 踏破の ごほうびは 受けとった" : "§a§l★ 踏破した！ ごほうびを 受けとれる") : "§7踏破の 条件: 踏破率 70%・展望台・石碑・秘境 4つ（作れなかった 所は のぞく）");
    if (done && !e.cl[i]) { btn.push(B("§a§l踏破の ごほうびを 受けとる", ICON("i_shop"))); act.push("claim"); }
    btn.push(B("§7戻る", ICON("i_back"))); act.push(null);
    const k = await choose(p, R.name, lines.join("\n"), btn);
    const a = act[k]; if (!a) return;
    if (a === "claim") {
      const e2 = exOf(p); if (e2.cl[i] || !regionDone(e2, i)) continue;
      const d2 = load(p); if (!d2) return;
      e2.cl[i] = 1; addPt(p, e2, 50); exSave(p, true);
      const log = [`§a§l${R.name} 踏破の ごほうび`, `§e${giveGold(d2, 10000 * (i + 1))}`, ...prize(p, d2, i, 2, 2)];
      award(p, d2, `ex_${i}`, log); save(p, d2); sound(p, "random.levelup", 1);
      await notice(p, "踏破の ごほうび", log.join("\n"));
      continue;
    }
    const I = a.info || a;
    try { p.setDynamicProperty("mrpg:navi", JSON.stringify({ name: KINDS[a.k].n, x: I.x, z: I.z, dim: OW })); } catch {}
    await notice(p, KINDS[a.k].n, `§fコンパスが ${KINDS[a.k].n}を 指すように なった。\n§7${KINDS[a.k].h}`);
    return;
  }
}
async function bountyBoard(p, d) {
  const e = exOf(p), top = Math.min(openUpTo(d), WREGIONS.length - 1);
  const L = [];
  for (let i = 0; i <= top; i++) { const b = bountyOf(i); if (!b.sid) continue; L.push(`${bountyDone(e, i) ? "§a○ 討伐ずみ" : "§c手配中"} §f${b.epi}${SPECIES[b.sid].name} §7Lv${b.lv}・${WREGIONS[i].short}・§e${b.gold.toLocaleString()}`); }
  await notice(p, "賞金首の 手配書", `§7毎日 かわる。その 地方を 歩くと 大きな 足あと（けむり）が 見つかる。\n§7賞金首は スカウトできない。1日 1回ずつ ほうび。\n\n${L.join("\n")}`);
}
async function rumor(p, d) {
  const e = exOf(p), top = Math.min(openUpTo(d), WREGIONS.length - 1), h = hash(`r${dayNo()}`);
  const L = ["§6今日の うわさ"];
  const ws = WREGIONS.map((R, i) => [i, wxOf(i)]).filter(([i, w]) => w && i <= top);
  L.push(ws.length ? `§f「${ws.map(([i, w]) => `${WREGIONS[i].short}で ${w.name}`).join("・")}が 起きて いる らしい」` : "§f「いまは どこも 天気が おだやかだ」");
  const r = ENVR[h % ENVR.length]; L.push(`§f「${r.c}には めずらしい 子が 出る と 聞いた」`);
  const bi = h % (top + 1), bo = bountyOf(bi); if (bo.sid) L.push(`§f「${WREGIONS[bi].short}で ${bo.epi}${SPECIES[bo.sid].name}を 見た 人が いる」`);
  const miss = []; for (let i = 0; i <= top; i++) for (const k of SECRET) if (!e.f[`${i}.${k}`]) miss.push([i, k]);
  if (miss.length) { const [i, k] = miss[h % miss.length]; L.push(`§f「${WREGIONS[i].short}の どこかに ${KINDS[k].n}が ある。${KINDS[k].h.replace(/§./g, "")}」`); }
  L.push("§f「雨が やんだ あとは 光の柱が 立つ ことが ある。夜には 流れ星も」");
  await notice(p, "うわさ", L.join("\n"));
}
const EXR = [
  { n: "化石の かけら ×8 → 古代の 化石", need: [["x_fossil", 8]], give: ["x_fossil2", 1] },
  { n: "同じ 地方の 素材 ×10 → なぞの 地図", same: 10, give: ["x_rmap", 1] },
  { n: "素材 3種 ×3 → 鍛冶の槌", kinds: [3, 3], give: ["rf_1", 1] },
  { n: "素材 ×20（どれでも）→ 経験の結晶 ×3", any: 20, give: ["f_exp1k", 3] },
  { n: "全11種 ×2 → 名匠の槌", kinds: [11, 2], give: ["rf_2", 1] },
  { n: "全11種 ×5 → 昇格の砥石", kinds: [11, 5], give: ["rf_4", 1] },
];
function exPay(p, x) {
  const have = MATS.map((id) => [id, countItem(p, `mrpg:${id}`)]);
  if (x.need) { if (!x.need.every(([id, n]) => countItem(p, `mrpg:${id}`) >= n)) return false; return x.need.every(([id, n]) => takeItem(p, `mrpg:${id}`, n)); }
  if (x.same) { const h = have.filter(([, n]) => n >= x.same).sort((a, b) => b[1] - a[1])[0]; return !!h && takeItem(p, `mrpg:${h[0]}`, x.same); }
  if (x.kinds) { const [k, n] = x.kinds; const h = have.filter(([, c]) => c >= n).sort((a, b) => b[1] - a[1]).slice(0, k); if (h.length < k) return false; return h.every(([id]) => takeItem(p, `mrpg:${id}`, n)); }
  if (x.any) { let left = x.any; if (have.reduce((a, b) => a + b[1], 0) < left) return false; for (const [id, c] of have.sort((a, b) => b[1] - a[1])) { const t = Math.min(c, left); if (t > 0 && takeItem(p, `mrpg:${id}`, t)) left -= t; if (left <= 0) break; } return left <= 0; }
  return false;
}
async function exchange(p, d) {
  for (;;) {
    const k = await choose(p, "素材の 交換", `§7持って いる 素材:\n${matLine(p)}\n§f化石の かけら §e${countItem(p, "mrpg:x_fossil")}`, [...EXR.map((x) => B(`§l${x.n}`, ICON("i_shop"))), B("§7戻る", ICON("i_back"))]);
    const x = EXR[k]; if (!x) return;
    const it = ITEMS[x.give[0]]; if (!it) continue;
    if (!exPay(p, x)) { await notice(p, "素材の 交換", "§7素材が たりない。"); continue; }
    giveItem(p, `mrpg:${x.give[0]}`, x.give[1]); sound(p, "random.anvil_use", 1.2);
    await notice(p, "素材の 交換", `§a${it.name} ×${x.give[1]} を 手に入れた！`);
  }
}
async function towerWarp(p, d) {
  const e = exOf(p), L = Object.keys(e.t).map(Number).filter((i) => WREGIONS[i] && spotInfo(i, "tower")?.ok);
  if (!L.length) { await notice(p, "展望台へ ワープ", "§7まだ 登った 展望台が ない。\n§7地方の 展望台（高い 石の 塔）の てっぺんに 登ると ワープできる。"); return; }
  const k = await paged(p, "展望台へ ワープ", "§fどこの 展望台へ？", L.map((i) => B(`§l${WREGIONS[i].name}の 展望台`, ICON("i_run"))), 8);
  if (k < 0) return;
  const I = spotInfo(L[k], "tower"); const pet = findPet(p);
  try { p.teleport({ x: I.x + 0.5, y: I.y + 0.2, z: I.z + 0.5 }, { dimension: world.getDimension("overworld") }); } catch { return; }
  if (pet) try { pet.teleport(p.location, { dimension: p.dimension }); } catch {}
  sound(p, "mob.endermen.portal");
}
Object.assign(EXH, { menu: (p, d) => exploreMenu(p, d), rmap: (p, d) => useRmap(p, d), fossil: (p, d) => useFossil(p, d), reset: (p) => exReset(p) });
// テスト用
export const __ex = { spawnBounty, spawnLost, placeNode, startEvt, spotPlan, buildSpot, cellOf, cellOk, totalCells, envNow, prize, exPay, EXR, WXS, NODES, BOUNTY, EVT, LOST, discover, regAtLoc, kindsOf };
