/* 第125版: 第9地方 フロストヘイム（らいうんの 里 サンダ・氷雷の 城 ヘイムダル）の 5話
   1話 雷雲の 里（雷祭りの やぐら）→ 2話 雪崩の 救助（山道）→ 3話 ふたつの 声（雷神の 祠）
   → 4話 双子と 仮面の 戦士（今の 段: 雪崩の 中の 六影・ロウと ルウ・アルゴが 双子を 連れ去る・手袋）→ 5話 シデン（地方マスター・今の 段）→ 5話 つづき 雷祭り（やぐら）
   ・今の 段に ある こと（雪崩の 中の 六影との 戦い・双子の 名乗り・手袋・「知りすぎたら、参謀さんが 危ない」・アルゴの 名乗り）は ここでは くり返さない
   ・登場人物の キーは「r8_」を つける。ロウ・ルウ・アルゴは クリア後だけ 里に 立つ */
import { epAdd } from "./sagaep.js";
import { castAdd, doomed, doomKnown } from "./cast.js";
import { townOut, placeOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, groundY } from "./structures.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load, save } from "./store.js";
import { ok } from "./ui.js";
import { fac, facMark, facState } from "./epfac.js";

/* ---------- 場所 ---------- */
const SANDA = (TOWNS.find((t) => /サンダ/.test(t.name)) || { id: "t68" }).id;
const tc = () => { const t = TOWNS.find((u) => u.id === SANDA); if (!t) return null; const q = getTown(SANDA); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const memo = (f) => { let v = null; return () => v || (v = f()); };
const YAGURA = memo(() => { const o = townOut(SANDA, 0.9, "雷祭りの やぐら"); return o ? { x: o.x, z: o.z, nm: "サンダの 外れの 雷祭りの やぐら" } : null; });
const HOKORA = memo(() => { const o = townOut(SANDA, -0.9, "雷神の 祠"); return o ? { x: o.x, z: o.z, nm: "サンダの 裏山の 雷神の 祠" } : null; });
const ROAD = memo(() => { const o = placeOf("road", 8); return o ? { x: o.x, z: o.z, nm: "サンダへの 山道（雪崩の あと）" } : null; });
const near = (f, dx, dz) => () => { const q = f(), c = tc(); return q ? { x: q.x + dx, y: c && typeof c.y === "number" ? c.y : undefined, z: q.z + dz } : null; };
/* クリア後だけ 立つ 人（だれかが エンディングを 見た ワールド）。30秒に 1回だけ しらべる */
let EQ = { t: -1e9, v: false };
const anyEnd = () => { const n = Date.now(); if (n - EQ.t < 30000) return EQ.v; EQ.t = n; let v = false; try { for (const p of world.getAllPlayers()) { const d = load(p); if (d && qs(d).ending) { v = true; break; } } } catch {} EQ.v = v; return v; };
const endAt = (dx, dz) => { const f = near(YAGURA, dx, dz); return () => (anyEnd() ? f() : null); };

/* ---------- 登場人物 ---------- */
const ex = (s) => s.epx || {};
const back = (s) => !!s.ending && !(s.heroDead && !s.heroBack);
castAdd("r8_shirou", { nm: "シロウ", role: "山案内人", gobi: "だべさ", skin: "m6_eirik", town: SANDA, from: "r8e1", at: near(YAGURA, 3, 2),
  pre: ["{smile}山の ことなら、おらに 聞くべさ！"],
  after: [
    [back, ["{smile,☆}双子が 帰って きたべさ！ 手袋の もう 片っぽ、おっかあの 編み方で 編んだべさ。", "{smile}今年の 雷祭りは、あの 二人が 太鼓を たたくべさ！"]],
    [(s) => !!s.ending, ["{sad}……あんたの 相棒さんの 分も、太鼓を たたいたべさ。", "{closed}山では、帰って くるまでが 案内だべさ。……まだ、案内は 終わって ないべさ。"]],
    [doomKnown, ["{angry,up}里の もんは、おらが 山小屋に 逃がしたべさ！", "{closed}雷太鼓は 毎晩 たたくべさ。影は、大きな 音が きらいだべさ。"]],
    [doomed, ["{sad,…}……聞いたべさ。あの 子が……", "{cry,up}あの 子が 手袋を 見せて くれた 夜、おら 泣いたべさ。……今度は あんたが 泣く 番だべさ。泣いて いいべさ。"]],
    [(s) => !!ex(s).thunder8, ["{smile}雷祭り、来て くれて ありがとだべさ！ 山道も ぜんぶ 開いたべさ。", "{closed}あの 手袋……いつか 二人に 返して やって けろだべさ。"]],
    [(s) => !!s.rouDead, ["{sad}……雪山で、なんか あったべさ？ 顔が 雪より 白いべさ。"]],
    [() => true, ["{smile}雷石を とりに 行く 日は、おらが 案内するべさ！"]],
  ] });
castAdd("r8_zuzu", { nm: "ズズ", role: "雪かき係の", gobi: "ずびっ", skin: "noxa", town: SANDA, from: "r8e2", at: near(YAGURA, -4, 3),
  pre: ["{sweat,汗}……な、なんでも ない。……ずびっ。"],
  after: [
    [back, ["{smile}……ずびっ。今も 里の 雪かき係だ。", "{smile,♪}双子の 子たちに、雪だるまの 作り方を 教えた。……ずびっ。"]],
    [(s) => !!s.ending, ["{sad}……あんたの 相棒さんに、礼を 言いそびれた。……ずびっ。", "{closed}雪の 中から 掘りだして くれたんだ。……忘れない。ずびっ。"]],
    [doomKnown, ["{angry}六影の 名前で 悪さを してる 連中、オレが 止めて 回ってる。……ずびっ。"]],
    [doomed, ["{sad}……あの 人が、オレを 雪の 中から 掘りだして くれたんだ。……ずびっ。", "{cry}なのに、なんで あの 人が……ずびっ。"]],
    [(s) => !!ex(s).thunder8, ["{smile}太鼓、たたかせて もらった。……生まれて はじめて、えらいって 言われた。ずびっ。"]],
    [() => true, ["{sweat,汗}……山道の 雪かき、まだ 半分だ。……ずびっ。"]],
  ] });
castAdd("r8_rou", { nm: "ロウ", role: "", col: "§9", gobi: "だよ", skin: "rou", town: SANDA, from: "r8e6", end: 1, at: endAt(6, -2),
  pre: ["{closed}……こんにちは。"],
  after: [
    [back, ["{smile}シロウさんが、手袋の もう 片っぽを 編んで くれたんだ。", "{smile,♪}ルウと、また 手を つないで 歩けるよ。"]],
    [(s) => !!s.ending, ["{sad}……あの お姉さんに、ありがとうって 言えなかった。", "{closed}だから、あなたに 言うよ。……ありがとう。"]],
    [() => true, ["{closed}……ここは、ボクたちの 生まれた 里だよ。"]],
  ] });
castAdd("r8_ruu", { nm: "ルウ", role: "", col: "§d", gobi: "だもん", skin: "ruu", town: SANDA, from: "r8e6", end: 1, at: endAt(7, -1),
  pre: ["{smile}……なに？ ロウなら、そこに いるでしょ。"],
  after: [
    [back, ["{smile}この 里の 雪、思ってたより あったかいんだもん。", "{blush}……兄ちゃんの 手袋、ちょっと 大きいけど。"]],
    [(s) => !!s.ending, ["{sad}……あなたの こと、ずっと 心配 してたんだもん。"]],
    [() => true, ["{smile}ロウと いっしょなら、どこでも 平気だもん。"]],
  ] });
castAdd("r8_argo", { nm: "アルゴ", role: "仮面の", col: "§7", gobi: "", skin: "argo", town: SANDA, from: "r8e6", end: 1, at: endAt(9, -3),
  pre: ["{closed}…………。"],
  after: [
    [back, ["{closed}…………。", "（仮面の 下で、少しだけ 笑った 気が した）"]],
    [(s) => !!s.ending, ["{closed,low}…………守れなかった。", "（それきり、何も 言わなかった。仮面の 割れ目が、また 少し ふえて いた）"]],
    [() => true, ["{closed}…………。"]],
  ] });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
const once = (k) => { try { if (world.getDynamicProperty(k)) return false; world.setDynamicProperty(k, 1); return true; } catch { return false; } };
const toward = (e, q, k, s = 0) => { const A = e.location, dx = A.x - q.x, dz = A.z - q.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n; return { x: q.x + ux * k - uz * s, y: A.y, z: q.z + uz * k + ux * s }; };   /* 第125版(rs2): q の 手前 k・横 s */
const snow = (K, p, q, n = 8, r = 1.4) => { if (!q) return; K.burst(p.dimension, q, "minecraft:white_smoke_particle", n, r, 0.3); K.burst(p.dimension, q, "minecraft:snowflake_particle", n, r * 0.8, 1.2); };
const spark = (K, p, q, n = 8) => { if (!q) return; K.burst(p.dimension, q, "minecraft:electric_spark_particle", n, 0.8, 1); K.burst(p.dimension, q, "minecraft:endrod", 4, 0.5, 1.6); };
/* 雷の 落ちる 音と 光（天気は かえない。ワールドに 火を つけない）*/
const thunder = (K, p, q, big = false) => { K.sound(p, "ambient.weather.thunder", big ? 1 : 0.5); if (big) { K.flash(p, true); K.shake(p, 0.6, 0.5); } spark(K, p, q, big ? 14 : 6); };
/* やぐら: 雷太鼓の 柱（柵と 避雷針）。ワールドに 1回 */
function yagura(K, p, y0) {
  const S = K.S(p); if (!S || !once("mrpg:epdeco:r8yagura")) return null;
  const q = S.at(9, 0), x = Math.floor(q.x), z = Math.floor(q.z); let y = null; try { y = groundY(p.dimension, x, z, y0 + 6); } catch {}
  if (typeof y !== "number" || Math.abs(y - y0) > 3) return null;
  for (let h = 0; h < 3; h++) K.cmd(p, `setblock ${x} ${y + h} ${z} spruce_fence keep`); K.cmd(p, `setblock ${x} ${y + 3} ${z} lightning_rod keep`);
  for (const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) K.cmd(p, `setblock ${x + a} ${y} ${z + b} hay_block keep`);
  const R = { x: x + 0.5, y: y + 3, z: z + 0.5 }; try { world.setDynamicProperty("mrpg:epdeco:r8yaguraat", JSON.stringify(R)); } catch {}   /* 第124版: 建てた 場所を 記録（あとの 場面と ほかの 人も ここを 見る）*/
  return R;
}
/* 第125版(fac): 雷祭りの やぐら（4本の 柱・高い 台・手すり・台の 上に 避雷針と 灯り）。前の 版の 1本柱を まん中に して 建てる（ワールドに 1回）*/
function yaguraUp(K, p) {
  let A = null; try { A = JSON.parse(world.getDynamicProperty("mrpg:epdeco:r8yaguraat") || "null"); } catch {}
  if (!A || typeof A.x !== "number" || Math.hypot(A.x - p.location.x, A.z - p.location.z) > 48 || !once("mrpg:epdeco:r8yagura2")) return;
  const x = Math.floor(A.x), y = Math.floor(A.y) - 3, z = Math.floor(A.z);
  for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) { let g = null; try { g = groundY(p.dimension, x + a, z + b, y + 4); } catch {} const g0 = typeof g === "number" && g < y && g >= y - 4 ? g : y; K.cmd(p, `fill ${x + a} ${g0} ${z + b} ${x + a} ${y + 4} ${z + b} spruce_log`); }
  K.cmd(p, `fill ${x - 2} ${y + 5} ${z - 2} ${x + 2} ${y + 5} ${z + 2} spruce_planks`);
  K.cmd(p, `fill ${x - 2} ${y + 6} ${z - 2} ${x + 2} ${y + 6} ${z + 2} spruce_fence`); K.cmd(p, `fill ${x - 1} ${y + 6} ${z - 1} ${x + 1} ${y + 6} ${z + 1} air`);
  K.cmd(p, `setblock ${x} ${y + 6} ${z} lightning_rod`);
  for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) K.cmd(p, `setblock ${x + a} ${y + 7} ${z + b} lantern`);
  for (const a of [-2, 2]) K.cmd(p, `fill ${x + a} ${y + 3} ${z - 1} ${x + a} ${y + 3} ${z + 1} spruce_planks`);   /* 柱を つなぐ 横木 */
  try { world.setDynamicProperty("mrpg:epdeco:r8yaguraat", JSON.stringify({ x: A.x, y: y + 6, z: A.z })); } catch {}   /* 雷は 台の 上の 避雷針へ */
}
const rod = (K, p, y0) => { try { const A = JSON.parse(world.getDynamicProperty("mrpg:epdeco:r8yaguraat") || "null"); if (A && typeof A.x === "number" && Math.hypot(A.x - p.location.x, A.z - p.location.z) < 40) return A; } catch {} const S = K.S(p); if (!S) return null; const q = S.at(9, 0); return { x: Math.floor(q.x) + 0.5, y: y0 + 3, z: Math.floor(q.z) + 0.5 }; };

/* ---------- 1話 雷雲の 里（雷祭りの 支度・山案内人 シロウ・ふさがった 山道）---------- */
const E1 = { id: "r8e1", n: 1, t: "雷雲の 里", at: 0, ord: 0, place: YAGURA,
  hint: "§fらいうんの 里 §eサンダの 外れの 雷祭りの やぐら§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "雷雲の 下の 里 サンダは、雷祭りの 支度の さいちゅう。山案内人の シロウは、雪崩で 里への 山道が ふさがり、祭りに 要る 雷石も 取りに 行けないと こまって いた。シロウの 父は、雪崩で 旅人を かばって 帰らなかった。「山では、帰って くるまでが 案内だべさ」。シロウは 昔 この 里に いた、手袋を 片っぽずつ はめた 双子の 話も した。",
  set: { met8: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "r8fest", 1, c, y0); yagura(K, p, y0); yaguraUp(K, p);
    await K.open(p, "らいうんの 里 サンダ（雷祭りの やぐら）", "day");
    thunder(K, p, rod(K, p, y0));
    snow(K, p, K.fwd(p, 6, 2), 10, 3);
    const eH = K.hero(p);
    K.act(eH, "hold");
    await K.hsay(p, K.V(["{sad,…}……雪、つめたいね。", "{closed}セオさんの いない 旅、なんだか 足音が ひとつ 足りない 気が する。"], ["{sad,…}……雪が、つめたいわね。", "{closed}セオさんの いない 旅。足音が、ひとつ 足りないの。"], ["{closed,…}……雪。", "{closed}足音が、ひとつ 足りない。"], ["{sad,…}……雪が、冷たいですね。", "{closed}セオさんの いない 旅……足音が、ひとつ 足りません。"]));
    K.act(eH, 0);
    const eS = K.cast(p, "r8_shirou"); K.act(eS, "raise");
    await K.csay(p, "r8_shirou", ["{smile,!}おーい！ そこの 旅の 人ー！ 雪の 中で 立ちんぼは、こごえるべさ！"], eH);
    K.act(eS, "hold"); K.hold(eS, "hammer");
    await K.csay(p, "r8_shirou", ["{smile}おら シロウ。この 里の 山案内人だべさ。", "{smile,♪}今は 雷祭りの 支度で、てんてこまい だべさ。"]);
    { const R0 = rod(K, p, y0); if (ok(eS) && R0) { await K.walkCam(p, eS, { x: R0.x - 1.6, y: y0, z: R0.z }, 16); K.act(eS, "work"); K.sound(p, "random.anvil_use", 0.6, 0.5); } }   /* 第125版(rs2): やぐらの 柱へ もどって 槌を ふるう */
    await K.ots(p, eS, eH, 8);   /* 第125版(rs2): 槌を 止めた シロウの 肩ごしに 幼なじみ */
    await K.hsay(p, K.V(["{?}雷祭り？"], ["{?}雷祭り？"], ["{?}……雷祭り。"], ["{?}雷祭り、ですか？"]));
    await K.csay(p, "r8_shirou", ["{smile}冬の いちばん 寒い 晩に、やぐらで 雷太鼓を たたくべさ。", "{closed}裏山の 祠の 雷石を 太鼓に のせて たたくと、はじめの 雷が 鳴って……ぶあつい 雪雲が 割れるべさ。"], eH);
    K.act(eS, "point");
    await K.at(p, rod(K, p, y0), 14, 6, 0.5);
    await K.csay(p, "r8_shirou", ["{sad,…}……けど、今年は だめかも しれねえべさ。", "{sad,up}三日前に 雪崩が あって、里への 山道が ふさがったべさ。旅の 人が 何人か、まだ 着かねえべさ。"]);
    K.act(eS, 0);
    /* シロウが あなたの 顔を のぞきこむ */
    if (ok(eS) && ok(eH)) { const q = eH.location; await K.go(eS, { x: q.x + 1.3, y: q.y, z: q.z + 0.4 }, 12); }
    await K.approach(p, eS, eH, 1.9); await K.push(p, eS, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "r8_shirou", ["{?}……あんた、顔が 雪より 白いべさ。なんか あったべさ？"], eH);
    await K.push(p, eH, 22, 4.2, 1.7);
    await K.hsay(p, K.V(["{sad,up}……ずっと 一緒に 旅してた 人が、いなく なっちゃって。", "{closed,up}『ごめん』って 言って、行っちゃった。"], ["{sad,up}……ずっと 一緒だった 人が、いなく なったの。", "{closed,up}『ごめん』って、それだけ 言って。"], ["{closed,up}……仲間が、いなく なった。", "{closed,up}『ごめん』とだけ 言って。"], ["{sad,up}……ずっと ご一緒だった 方が、いなく なって しまって。", "{closed,up}『ごめん』と、それだけ おっしゃって。"]));
    K.act(eS, "kneel");
    await K.memory(p, eS, "§7―― 昔　サンダへの 山道", ["§7吹雪の 山道。雪崩の 前に 両手を 広げて 立つ、山案内人の 背中。"]);   /* 第125版(rs): 回想の 札 */
    await K.csay(p, "r8_shirou", ["{closed}……おらの おっとうも、山案内人 だったべさ。", "{sad,up}雪崩で 旅の 人を かばって……帰って こなかったべさ。"]);
    await K.csay(p, "r8_shirou", ["{smile,up}おっとうの 口ぐせ、教えて やるべさ。『山では、帰って くるまでが 案内だべさ』。", "{smile}……あんたの 旅も、その 人が 帰って くるまでが 旅だべさ。な？"], eH);
    K.act(eS, 0);
    await K.hsay(p, K.V(["{smile,tears,up}……帰って くるまでが、旅。……うん。"], ["{smile,tears,up}……帰って くるまでが、旅。……そうね。"], ["{closed,up}……帰って くるまでが、旅。"], ["{smile,tears,up}……帰って くるまでが、旅。……はい。"]));
    /* 双子の 話（伏線）*/
    K.act(eS, "hold"); K.hold(eS, "glove");
    await K.csay(p, "r8_shirou", ["{smile}ほれ、里の 手袋だべさ。おっかあが 編んだべさ。……手が かじかむと、太鼓も たたけねえべさ。"], eH);
    await K.give(eS, eH, "glove"); await K.push(p, eH, 16, 3.4, 1.0);   /* 第125版(rs2): 受け取った 手袋の 寄り */
    if (ok(eS)) K.turn(eS, K.fwd(p, 20, -8, 6));   /* 第125版(rs): 山を 見上げて 背を 向ける */
    await K.csay(p, "r8_shirou", ["{closed,…}……そういや、昔 この 里に、双子が 生まれたべさ。", "{sad}年寄りが『双子は 不吉だ』って 騒いでな。……ある 冬の 夜、二人とも、いなく なったべさ。"]);
    K.turn(eS); await K.memory(p, eS, "§7―― 昔　らいうんの 里", ["§7片っぽずつ 手袋を はめた 小さな 二人が、あいた 手を つないで 雪の 道を 歩いて いく。"]);
    await K.csay(p, "r8_shirou", ["{sad,up}おっかあの 手袋を、片っぽずつ はめて……あいた 手で、いつも 手ぇ つないでたべさ。", "{closed}白い 子と 黒い 子。……生きて たら、あんたくらいの 年だべさ。"]);
    K.act(eS, 0);
    await K.csay(p, "r8_shirou", ["{smile,arms}よし！ あした、山道の 雪崩を 掘りに 行くべさ。手伝って くれるべさ？"], eH);
    await K.hsay(p, K.V(["{smile,nod}うん！ 掘る！"], ["{smile,nod}ええ。お手伝い するわ。"], ["{closed,nod}……行く。"], ["{smile,nod}はい、お手伝い します。"]));
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    K.pay(p, E1, 300, [["mei_frost", 1]]);
    await K.end(p, { leave: [eS], card: "§7→ §eサンダへの 山道§7 で 雪崩の 救助（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 2話 雪崩の 救助（山道。旅人と 雪の 主の 子・雪に うまった 六影の 下っぱ）---------- */
const E2 = { id: "r8e2", n: 2, t: "雪崩の 救助", at: 0, ord: 1, place: ROAD, fac: "r8snow",
  hint: "§fサンダと 氷雷の 城の あいだ §eサンダへの 山道§f へ 行こう §7（雪崩に うまった 人を 助ける。右上の 案内）",
  syn: "山道の 雪崩から、旅の 行商人を 掘りだした。気が 立った 雪の 主は、雪の 下の 子どもたちを 守って いたのだった。雪の 中には、六影の 下っぱ ズズも うまって いた。山道を 爆薬で ふさいだのは ズズだった。「雪山の 上で、えらい 人が 何かを 守ってる。だれも 近づけるな」と 命じられて いた。シロウは「山では、敵も 味方も ねえべさ」と ズズを 背負い、ズズは 六影を やめて 雪かきを 手伝うと 決めた。",
  set: { met8: 1, zuzu8: 1 },
  async run(p, d, K) {
    fac(K, p, "r8snow", "snowpile", 8, Y(K, p));   /* 第125版(fac): 道を ふさぐ 雪の 山と 折れた 木 */
    await K.open(p, "サンダへの 山道（雪崩の あと）", "day");
    const mound = facMark("r8snow", "mound", p.location) || K.fwd(p, 7, 2.5);
    snow(K, p, mound, 12, 2.5);
    const eH = K.hero(p), eS = K.cast(p, "r8_shirou");
    await K.csay(p, "r8_shirou", ["{closed}……しっ。声が するべさ。"], eH);
    K.sound(p, "mob.villager.hit", 0.7, 0.4);
    await K.at(p, mound, 14, 5, 0.6);
    await K.say(p, "雪の 下の 声", ["{sad}……た……すけ……て……"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{shock,!,up}いた！ 雪の 下！ 掘ろう、シロウさん！"], ["{shock,!,up}雪の 下よ！ 掘りましょう！"], ["{shock,!,up}……下に いる。掘る。"], ["{shock,!,up}雪の 下です！ 掘りましょう！"]));
    { const g0 = ok(eS) ? K.go(eS, toward(eS, mound, 4.2, -1.3), 14) : null; if (ok(eH)) await K.walkCam(p, eH, toward(eH, mound, 4, 1.3), 14); await g0; }   /* 第125版(rs2): 二人で 雪の 山へ かけよる */
    K.act(eH, "kneel"); K.act(eS, "kneel");
    for (let k = 0; k < 3; k++) { snow(K, p, mound, 8, 1.2); K.sound(p, "dig.snow", 1); await K.wait(6); }
    await K.narr(p, ["§7あなたと シロウは、手で 雪を かいた。指先の 感覚が なくなっても、かいた。", "§7……雪の 下から、手袋の 指先が 見えた。"], mound);
    await K.at(p, mound, 12, 2.2, 0.2);   /* 第125版(rs2): 雪から 出た 指先の 寄り */
    K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 240 245 255"); await K.wait(8);
    const eT = K.npcNear(p, "§f旅の 行商人", K.PJ("m6_hector", 9), true); K.act(eT, "down");
    K.act(eH, 0); K.act(eS, 0);
    await K.say(p, "旅の 行商人", ["{sad,…}……あ、ありがてえ……三日、雪の 中で……", "{sweat,汗,up}……で、でも、気を つけろ。あの 主が、まだ 近くに……！"], eH);
    /* 雪の 主 */
    const big = K.fwd(p, 9, -3), eB = K.monEnt(p, big, K.wildSp("beast", "L"), "§b雪の 主");
    K.sound(p, "mob.polarbear.warning", 1); K.shake(p, 0.5, 0.5); snow(K, p, big, 10, 2);
    if (ok(eB)) await K.at(p, eB.location, 14, 6, 1.6);
    await K.csay(p, "r8_shirou", ["{shock,!,up}雪の 主だべさ！ 雪崩で 気が 立ってるべさ！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,up}……ごめんね。ちょっとだけ、しずかに して もらう！"], ["{angry,up}……ごめんなさい。少しだけ、おとなしく して。"], ["{angry,up}……しずめる。"], ["{angry,up}……申し訳 ありません。少しだけ、おしずまり ください！"]));
    if (!K.flag(p, "r8e2w")) {
      K.rmCine(eB);
      const r = await K.battle(p, K.bossOne(["beast", "aqua"], 60, 12), { name: "雪崩で 気が 立った 雪の 主", arena: "雪崩の 救助", theme: "snow", hpk: 2, speaker: "雪の 主", lines: { half: "……グルル……", low: "……クゥン……" } });
      if (r !== "win") return lose(K, p, "§e山案内人 シロウ", K.PJ("m6_eirik", 9), "シロウ", "{sweat,汗}いったん 下がるべさ！ 雪の 主は、山の 神さまの 使いだべさ……！");
      K.setFlag(p, "r8e2w");
    } else K.rmCine(eB);
    /* 主は 逃げない。雪の 下の 子どもを 守って いた */
    const eB2 = K.monEnt(p, K.fwd(p, 8, -3), K.wildSp("beast", "L"), "§b雪の 主");
    K.sound(p, "mob.polarbear_baby.idle", 1);
    await K.hsay(p, K.V(["{?}……逃げない。……あっ、足もとの 雪の 下！ 小さい 声が する！"], ["{?}……逃げないわ。……足もとの 雪の 下から、小さな 声。"], ["{?}……逃げない。下に、何か いる。"], ["{?}……逃げません。……足もとの 雪の 下から、小さな 声が。"]));
    const kq = K.fwd(p, 6, -2);
    snow(K, p, kq, 8, 1); K.sound(p, "dig.snow", 1);
    const eK1 = K.monEnt(p, kq, K.wildSp("beast"), ""), eK2 = K.monEnt(p, K.fwd(p, 6, -0.8), K.wildSp("beast"), "");
    K.burst(p.dimension, kq, "minecraft:heart_particle", 4, 0.6, 0.8);
    if (ok(eK1)) await K.approach(p, eK1, eH, 1.9); await K.push(p, eK1, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.hsay(p, K.V(["{sad,tears,up}……守ってたんだ。この 子たちを。……ごめんね。"], ["{sad,tears,up}……この 子たちを、守って いたのね。……ごめんなさい。"], ["{sad,up}……守ってたのか。……悪かった。"], ["{sad,tears,up}……この 子たちを、お守りに なって いたのですね。……ごめんなさい。"]));
    const run = []; for (const e of [eB2, eK1, eK2]) if (ok(e)) run.push((async () => { const q = K.away(e, p, 10); if (q) await K.go(e, q, 22); K.rmCine(e); })());
    await K.pull(p, K.S(p) && K.S(p).Cn, 34); await Promise.all(run);
    await K.csay(p, "r8_shirou", ["{smile,up}……山の 神さまの 使いが、ありがとって 言ってたべさ。"], eH);
    /* 雪の 中の 下っぱ */
    await K.csay(p, "r8_shirou", ["{shock,!}……待つべさ。まだ 一人、うまってるべさ！"]);
    K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 240 245 255"); await K.wait(8);
    const eZ = K.cast(p, "r8_zuzu", true); K.act(eZ, "down");
    await K.low(p, eZ, 12);
    await K.hsay(p, K.V(["{shock,…}……この 外套の 印。六影の……"], ["{shock,…}……この 印。六影ね。"], ["{closed,…}……六影の 印。"], ["{shock,…}……この 印は、六影の……"]));
    await K.csay(p, "r8_zuzu", ["{sad,…}……さむ……い……ずびっ。"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,…}……どう しよう。この 人、六影だよ。"], ["{sad,…}……どう しましょう。六影の 人よ。"], ["{closed}……六影だ。"], ["{sad,…}……どう いたしましょう。六影の 方です。"]));
    K.act(eS, "hold");
    await K.push(p, eS, 22, 4.2, 1.7);
    await K.csay(p, "r8_shirou", ["{angry,up}山では、敵も 味方も ねえべさ。", "{smile,up}こごえてる もんは、みんな 客だべさ。……おっとうなら、そう 言うべさ。"], eH);
    K.act(eH, 0);
    if (ok(eS) && ok(eZ)) { const q = eZ.location; await K.go(eS, { x: q.x + 1, y: q.y, z: q.z }, 10); K.act(eS, "kneel"); }
    K.burst(p.dimension, ok(eZ) ? eZ.location : null, "minecraft:basic_flame_particle", 6, 0.6, 0.6); K.sound(p, "fire.ignite", 0.8);
    await K.narr(p, ["§7シロウは 火を おこし、自分の 外套で 男を くるんだ。", "§7しばらく して、男の 指が 動いた。"], eZ);
    K.act(eS, 0); K.act(eZ, "kneel");
    await K.ots(p, eH, eZ, 8);   /* 第125版(rs2): 幼なじみの 肩ごしに、起きあがる ズズ */
    await K.csay(p, "r8_zuzu", ["{sad,up}……なんで、助けた。……オレが、やったんだ。……ずびっ。", "{cry,tears,up}上の 命令で、山道に 爆薬を しかけた。……人が いるなんて、知らなかった。……ずびっ。"], eH);
    await K.hsay(p, K.V(["{angry,up}命令って、だれの？"], ["{angry,up}……だれの 命令なの？"], ["{angry,up}だれの 命令だ。"], ["{angry,up}どなたの ご命令ですか？"]));
    await K.csay(p, "r8_zuzu", ["{sweat,汗}……知らない。オレみたいな 下っぱは、何も 教えて もらえない。……ずびっ。", "{closed}ただ……『雪山の 上で、えらい 人が 何かを 守ってる。だれも 山に 近づけるな』って。"]);
    await K.say(p, "旅の 行商人", ["{closed}……あんたも 雪の 中で、わしらと 同じ ように 震えてたね。"], eZ);
    K.act(eZ, "kneel"); await K.up(p, eZ, 12);
    await K.csay(p, "r8_zuzu", ["{cry,tears,palm}……オレ、六影 やめる。……ずびっ。", "{sad,up}こんな ことを する ために、入ったんじゃ ない。"]);
    await K.csay(p, "r8_shirou", ["{smile,arms}なら、雪かきを 手伝うべさ。山道を 開けるまでが、つぐないだべさ！"], eZ);
    await K.csay(p, "r8_zuzu", ["{smile,tears,nod,up}……おう。……ずびっ。"]);
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    K.pay(p, E2, 500, [["c_herbs", 2], ["mei_frost", 1]]);
    await K.end(p, { leave: [eS, eZ], bye: [eT], card: "§7→ 裏山の §e雷神の 祠§7 へ。雷祭りの 雷石を とりに 行こう（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 3話 ふたつの 声（雷神の 祠。吹雪の 中の 二つの 子どもの 声・雷石・白い 仮面）---------- */
const E3 = { id: "r8e3", n: 3, t: "ふたつの 声", at: 0, ord: 2, place: HOKORA, fac: "r8hokora",
  hint: "§fサンダの 裏山 §e雷神の 祠§f へ 行こう §7（雷祭りの 雷石を とりに 行く。右上の 案内）",
  syn: "吹雪の 中、ふたつの 声が 聞こえた。「帰って。来ちゃ だめ」「止まって。その 先は 下が 空っぽ だよ」。あなたが 足を 止めた とたん、目の 前の 雪庇が 崩れ落ちた。雪の 上には、ぴったり ならんだ 小さな 足あとが 二つ。祠の 雷石を 狙う 下っぱを 追いはらうと、白い 仮面の 戦士が 吹雪から 現れ、ひと言「……帰れ」と だけ 言って、声の した ほうへ 消えた。",
  set: { met8: 1, stone8: 1 },
  async run(p, d, K) {
    const FQ = fac(K, p, "r8hokora", "shrine", 8, Y(K, p));   /* 第125版(fac): 石の 台・木の 社・避雷針・鳥居・供え物の 祠 */
    fac(K, p, "r8cliff", "cornice", 8, Y(K, p));   /* 第125版(tp): 祠の 手前の 雪の 崖（張り出した 雪庇の 下は 4マス 下の 谷）*/
    const EDGE = facMark("r8cliff", "edge", p.location), LIP = facMark("r8cliff", "lip", p.location);
    await K.open(p, "雷神の 祠（ふぶき）", "snow");
    K.mood(p, "shadow");
    if (FQ) await K.at(p, FQ, 14, 8, 1.6);
    snow(K, p, K.fwd(p, 5, 0), 14, 4);
    const eH = K.hero(p), eS = K.cast(p, "r8_shirou");
    if (ok(eS)) await K.walkCam(p, eS, K.fwd(p, 2.6, -1.4), 14);   /* 第125版(rs2): シロウが 先に 立って 吹雪の 中を 歩く */
    await K.csay(p, "r8_shirou", ["{sweat,汗}……吹雪が ひどく なって きたべさ。おらの 背中から はなれるでねえべさ。"], eH);
    if (ok(eH)) { const q = EDGE ? { x: EDGE.x - (EDGE.x - p.location.x) * 0.25, y: EDGE.y, z: EDGE.z - (EDGE.z - p.location.z) * 0.25 } : K.fwd(p, 3.5, 0.5); if (q) await K.walkCam(p, eH, q, 18); }   /* 第125版(tp): 崖の ふちへ 歩いて いく */
    /* 吹雪の 中の ふたつの 声 */
    K.sound(p, "note.chime", 1, 0.4);
    await K.say(p, "とがった 声", ["{angry}……帰って。ここから 先は、来ちゃ だめなんだもん。"], eH);
    await K.say(p, "しずかな 声", ["{closed}……止まって。その 先の 雪、下が 空っぽ だよ。"], eH);
    await K.push(p, eH, 22, 4.2, 1.7);
    await K.hsay(p, K.V(["{shock,?,up}……二つの 声？", "{closed}一人は 追いかえそうと して、一人は 止めて くれた。……止まる！"], ["{shock,?,up}……声が 二つ？", "{closed}『帰って』と『止まって』。……止まるわ。"], ["{closed,?,up}……声が 二つ。", "{closed}追いかえす 声と、止める 声。……止まる。"], ["{shock,?,up}……お声が 二つ……？", "{closed}『帰って』と、『止まって』。……止まります！"]));
    K.act(eH, "guard");
    const cliff = LIP || K.fwd(p, 6.5, 0.5);
    if (LIP) facState("r8cliff", 1);   /* 第125版(tp): 張り出した 雪が 本当に 崩れ落ちる */
    K.sound(p, "random.explode", 0.5); K.shake(p, 0.7, 0.7); snow(K, p, cliff, 16, 2.4);
    await K.at(p, cliff, 16, 5, 0.2);
    await K.csay(p, "r8_shirou", ["{shock,!,up}せ、雪庇が 落ちたべさ……！ あと 一歩 出てたら……！"]);
    K.act(eH, 0);
    await K.hsay(p, K.V(["{shock,?,up}……だれ！？ どこに いるの！"], ["{shock,?,up}……だれ？ どこに いるの？"], ["{angry,?}……だれだ。どこに いる。"], ["{shock,?,up}……どなたですか！？ どこに いらっしゃるの！"]));
    await K.narr(p, ["§7返事は ない。吹雪の 音だけ。", "§7雪の 上に、小さな 足あとが 二つ。ぴったり ならんで、山の 上へ つづいて いる。"], cliff);
    K.act(eS, "kneel");
    await K.push(p, eS, 22, 4.2, 1.7);
    await K.csay(p, "r8_shirou", ["{shock,…}……子どもの 声が 二つ……。昔の 双子も、いつも 二人で 一つの ことを しゃべってたべさ……", "{closed,up}……まさか、な。"]);
    K.act(eS, 0);
    /* 祠と 雷石。下っぱが ねらう */
    const ston = facMark("r8hokora", "stone", p.location) || K.fwd(p, 7, -3);
    spark(K, p, ston, 10); K.sound(p, "random.orb", 0.6);
    await K.at(p, ston, 14, 4, 0.8);
    await K.narr(p, ["§7祠の 奥に、青白く 光る §e雷石§7 が ある。ぱちぱちと、小さな 雷が はじけて いる。"], ston);
    const eG1 = K.npcNear(p, "§c六影の 下っぱ ガガ", K.PJ("noxa", 9)), eG2 = K.npcNear(p, "§c六影の 下っぱ ゾゾ", K.PJ("noxb", 9));
    K.act(eG1, "point");
    await K.say(p, "ガガ", ["{angry,low}おっと、そこまでだ。その 石は オレたちが いただく。", "{angry}雷祭りなんか やらせねえ。山に 人が 来たら、上の 人に 叱られるんだよ。"], eH);
    await K.csay(p, "r8_shirou", ["{angry,怒,up}ズズの 仲間だべさ？ あいつは もう 足を 洗ったべさ！"]);
    await K.say(p, "ゾゾ", ["{shock,!}ズズが？ ……あの 泣き虫が？"]);
    await K.say(p, "ガガ", ["{angry,!}知るか！ やっちまえ！"]);
    if (!K.flag(p, "r8e3w")) {
      const r = await K.battle(p, K.team(["beast", "golem", "aqua"], 60, 3, 16), { name: "祠を 荒らす 下っぱ", arena: "雷神の 祠", theme: "snow", speaker: "ガガ", lines: { half: "さ、寒い……手が かじかむ……！", low: "ひいっ、雪が 目に……！" } });
      if (r !== "win") return lose(K, p, "§c六影の 下っぱ ガガ", K.PJ("noxa", 9), "ガガ", "……へっ。石は あとで いただくぜ。");
      K.setFlag(p, "r8e3w");
    }
    const eG1b = K.npcNear(p, "§c六影の 下っぱ ガガ", K.PJ("noxa", 9), true), eG2b = K.npcNear(p, "§c六影の 下っぱ ゾゾ", K.PJ("noxb", 9), true); K.act(eG1b, "kneel"); K.act(eG2b, "recoil");
    /* 音が 消えて、白い 仮面が 吹雪から */
    K.cmd(p, "stopsound @s");
    const eA = K.npcNear(p, "§7白い 仮面の 戦士", K.PJ("argo", 10)); K.act(eA, "hold");
    snow(K, p, ok(eA) ? eA.location : null, 10, 1.4);
    await K.low(p, eA, 18);
    await K.say(p, "ゾゾ", ["{shock,!,up}ひっ……！ し、白い 仮面……！ ろ、六の……"]);
    await K.say(p, "ガガ", ["{sweat,汗,up}ば、ばか、名前を 言うな！ 逃げろーっ！"]);
    await Promise.all([K.leave(eG1b, p, 12, true), K.leave(eG2b, p, 12, true)]);
    await K.up(p, eA, 14);
    await K.say(p, "白い 仮面の 戦士", ["{closed,low}…………帰れ。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}……あなた、だれ！？ さっきの 声と、知り合いなの！？"], ["{angry,!,up}……あなたは だれ？ さっきの 声と、関係が あるの！？"], ["{angry,up}……だれだ。さっきの 声と 関係あるのか。"], ["{angry,!,up}……あなたは どなたですか！？ さっきの 声と、お知り合い なのですか！？"]));
    K.act(eA, 0); K.re(eA, "closed", "…");
    await K.say(p, "白い 仮面の 戦士", ["{closed,low}……山の 上の 子らに、近づくな。", "{closed,low}……知りすぎるな。"], eH);
    await K.ots(p, eA, eS, 8);   /* 第125版(rs2): 仮面の 肩ごしに シロウ（だれに 言うか）*/
    await K.csay(p, "r8_shirou", ["{shock,…,up}……『山の 上の 子ら』……？ あんた、あの 子たちの 何だべさ！"], eA);
    if (ok(eA)) { K.turn(eA, cliff); await K.at(p, cliff, 12, 6, 2); }   /* 第125版(rs2): 答えず、足あとの 先の 山を 見る */
    await K.narr(p, ["§7仮面の 戦士は 答えず、足あとの つづく 山の 上を、しばらく 見て いた。", "§7それから、吹雪の 中へ 歩いて 消えた。"], eA);
    await K.leave(eA, p, 12, false);
    await K.csay(p, "r8_shirou", ["{sweat,汗}……息が 止まるかと 思ったべさ。"]);
    /* 雷石を とる */
    if (ok(eH) && ston) { await K.go(eH, ston, 12); K.act(eH, "kneel"); }
    thunder(K, p, ston, true);
    K.act(eH, "raise"); K.hold(eH, "orb");
    await K.up(p, eH, 12);
    await K.hsay(p, K.V(["{smile,☆,up}雷石、とれた！ ……あったかい。雷なのに。"], ["{smile,up}雷石……とれたわ。ふしぎね、あたたかい。"], ["{smile,up}……とれた。あたたかい。"], ["{smile,up}雷石、お預かり しました。……あたたかい です。"]));
    K.act(eH, 0);
    await K.csay(p, "r8_shirou", ["{smile}これで 雷祭りが できるべさ！", "{closed,up}……けど、あんた。山の 上へ 行くんだべさ？ あの 声と、あの 仮面の ほうへ。"], eH);
    await K.hsay(p, K.V(["{closed,nod}……うん。行かなきゃ いけない 気が する。"], ["{closed,nod}……ええ。行かなきゃ いけない 気が するの。"], ["{closed,nod}……行く。"], ["{closed,nod}……はい。行かねば ならない 気が します。"]));
    await K.csay(p, "r8_shirou", ["{smile,up}山では、帰って くるまでが 案内だべさ。……雷祭りの 晩には、ぜったい 帰って くるべさ。"]);
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    K.pay(p, E3, 600, [["mei_frost", 1], ["c_herbs", 2]]);
    await K.end(p, { leave: [eS], card: "§7→ §9フロストヘイム雪山の 大地§7 へ（足あとの つづく 山の 上。右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 5話 つづき 雷祭り（シデンの あと。双子の 手袋・雷太鼓）---------- */
const E6 = { id: "r8e6", n: 5, t: "雷祭り", at: 2, ord: 0, place: YAGURA,
  hint: "§fらいうんの 里 §eサンダの 雷祭りの やぐら§f へ もどろう §7（雷祭りの 晩。右上の 案内。そのあと 終焉の地 ラグナへ）",
  syn: "山道が 開き、サンダで 雷祭りが 開かれた。あなたが 雪山で 拾った 片っぽの 手袋を 見せると、シロウは「おっかあの 編み目だべさ」と 泣いた。昔 いなく なった 双子は、生きて いた。ロウと ルウ。シロウは「二人 そろって 帰って きたら、もう 片っぽを 編んで やるべさ」と 言い、あなたは 手袋を 返す 約束を した。雷石を のせた 太鼓が 鳴ると、雷が 雪雲を 割り、星が 見えた。",
  set: { thunder8: 1, met8: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), thunder8: 1 }; },
  fx: { xp: [SANDA, 160], fest: SANDA },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "r8fest", 2, c, y0); yagura(K, p, y0); yaguraUp(K, p);
    { const dd = load(p); if (dd && !qs(dd).glove) { qs(dd).glove = 1; save(p, dd); } }   /* 古い セーブ: 雪山で 拾った 手袋 */
    await K.open(p, "らいうんの 里 サンダ（雷祭りの 晩）", "fest", "night");
    K.sound(p, "note.bd", 1); await K.wait(6); K.sound(p, "note.bd", 1);
    const eH = K.hero(p), eR = REI(K, p), eS = K.cast(p, "r8_shirou");
    K.act(eS, "raise");
    await K.csay(p, "r8_shirou", ["{smile,☆,jump}来たべさ！ 山道は ぜんぶ 開いたべさ！ 今夜は 雷祭りだべさ！"], eH);
    const eZ = K.cast(p, "r8_zuzu"); K.act(eZ, "hold");
    await K.csay(p, "r8_zuzu", ["{smile,汗}……オレ、太鼓を たたく 係に なった。……ずびっ。"]);
    await K.say(p, "レイ", ["{smile}……祭りか。ガキの ころ、じいちゃんと 行った 収穫祭 いらいだな。"], eZ);
    K.act(eZ, 0); K.act(eS, 0);
    /* 片っぽの 手袋 */
    K.act(eH, "show"); K.hold(eH, "glove");
    if (ok(eH) && ok(eS)) await K.approach(p, eH, eS, 1.6);   /* 第125版(rs): シロウの 前へ 歩み寄る */
    await K.ots(p, eS, eH, 8);
    await K.hsay(p, K.V(["{closed}……シロウさん。見て ほしい ものが あるの。", "{sad,up}雪山で、拾ったんだ。……右手の 手袋。"], ["{closed}……シロウさん。見て ほしい ものが あるの。", "{sad,up}雪山で 拾ったの。右手の 手袋よ。"], ["{closed}……シロウ。これ。", "{sad,up}雪山で 拾った。右手の 手袋。"], ["{closed}……シロウさん。見て いただきたい ものが あります。", "{sad,up}雪山で 拾いました。右手の 手袋です。"]));
    await K.push(p, eH, 22, 4.2, 1.7);
    await K.narr(p, ["§7白と 黒の 毛糸で 編まれた、小さな 手袋。", "§7指先が すりきれて いる。何年も、何年も、はめて いた あと。"], eH);
    K.act(eS, "kneel");
    await K.push(p, eS, 22, 4.2, 1.7);
    await K.csay(p, "r8_shirou", ["{shock,!,up}……この 編み目……おっかあの だべさ……！"]);
    await K.past(p, "§7―― 昔　らいうんの 里の 冬"); await K.at(p, K.fwd(p, 9, 4, 0.5), 14, 7, 1.4);   /* 第125版(rs2): 双子が いた ころの 里の 雪道（回想の 札）*/
    await K.csay(p, "r8_shirou", ["{cry,tears,up}あの 双子の……右手の ほうだべさ……！ どこで……あの 子たちは……！"], eH);
    K.act(eH, 0);
    await K.hsay(p, K.V(["{sad,up}……生きてる。ロウと ルウって いう 名前。", "{closed,up}二人で 手を つないで、いつも 一緒に いた。……仮面の 人に、連れて いかれちゃったけど。"], ["{sad,up}……生きてるわ。ロウと ルウ。", "{closed,up}二人で 手を つないで、ずっと 一緒だった。……仮面の 人に、連れて いかれて しまったけど。"], ["{closed,up}……生きてる。ロウと ルウ。", "{closed,up}ずっと 手を つないでた。……仮面の 戦士に、連れて いかれた。"], ["{sad,up}……生きて います。ロウと ルウという お名前です。", "{closed,up}お二人で 手を つないで、ずっと ご一緒でした。……仮面の 方に、連れて いかれましたが。"]));
    await K.csay(p, "r8_shirou", ["{cry,smile,up}……生きてた。生きてた だけで、十分だべさ……", "{smile,tears,up}名前、もらったんだべさ。ロウと ルウ。……いい 名前だべさ。"]);
    K.act(eS, "up");
    await K.csay(p, "r8_shirou", ["{closed,up}いつか 二人 そろって 帰って きたら、もう 片っぽ……おっかあの 編み方で、おらが 編んで やるべさ。", "{smile,up}だから その 手袋、あんたが 持ってて けろだべさ。……二人に、返して やって けろだべさ。"], eH);
    K.act(eH, "hold");
    await K.hsay(p, K.V(["{smile,tears,up}……うん。わたしが 返す。ぜったい。約束！"], ["{smile,tears,up}……ええ。わたしが 返すわ。約束よ。"], ["{closed,up}……返す。約束する。"], ["{smile,tears,up}……はい。わたしが お返し します。約束です。"]));
    K.act(eH, 0); K.act(eS, 0);
    if (ok(eR) && ok(eH)) await K.approach(p, eR, eH, 2);   /* 第125版(rs2): レイが 二人の そばへ 歩み寄る */
    await K.say(p, "レイ", ["{closed,up}……証人に なって やる。……約束は、守れよ。"], eH);
    K.hold(eH); K.hold(eR, "letter"); K.act(eR, "hold"); await K.push(p, eR, 18, 3.6, 1.3);   /* 第125版(rs2): 手紙を 開く レイへ ゆっくり 寄る */
    await K.say(p, "レイ", ["{sad,…}……じいちゃんの 手紙。『わしも 行く』か。", "{closed,up}あの 人、本気だ。……オレたちが 先に 行かないと。"]);
    /* 雷太鼓 */
    const R = rod(K, p, y0);
    K.act(eS, "raise"); K.act(eZ, "raise");
    if (ok(eS) && R) await K.walkCam(p, eS, { x: R.x - 1.4, y: y0, z: R.z }, 16);   /* 第125版(rs): シロウが やぐらの 下へ 歩き 雷石を かかげる */
    if (ok(eZ) && R) K.go(eZ, { x: R.x + 1.4, y: y0, z: R.z }, 16);   /* ズズは 太鼓の 前へ */
    await K.csay(p, "r8_shirou", ["{angry,up}さあ、雷石を のせるべさ！ ズズ、たたけーっ！"]);
    for (let k = 0; k < 4; k++) { K.sound(p, "note.bd", 1); K.shake(p, 0.15, 0.2); spark(K, p, R, 4); await K.wait(5); }
    await K.at(p, R, 12, 6, 2);
    thunder(K, p, R, true);
    await K.narr(p, ["§7太鼓が 三度 鳴った とき、空から 白い 雷が 落ちて きた。", "§7ぶあつい 雪雲が、まん中から 割れて いく。……その 向こうに、星が 見えた。"], R);
    K.act(eS, 0); K.act(eZ, 0);
    await K.csay(p, "r8_zuzu", ["{smile,tears,up}……ずびっ。オレ、生まれて はじめて、えらいって 言われた。"]);
    /* 祭りの 輪 */
    for (const e of [eS, eZ, eH, eR]) K.act(e, 9);
    K.ambient(p, "fest", { x: p.location.x, y: y0, z: p.location.z }); K.sound(p, "note.pling", 0.8);
    const g = K.palEnt(p); if (g) K.burst(p.dimension, g.location, "minecraft:note_particle", 5, 0.5, 1);
    await K.pull(p, K.S(p) && K.S(p).Cn, 34);
    K.ambient(p, "fest", { x: p.location.x, y: y0, z: p.location.z }); thunder(K, p, R);
    for (const e of [eS, eZ, eH, eR]) K.act(e, 0);
    K.rmCine(g);
    K.act(eS, "hold"); K.hold(eS, "potion");
    await K.csay(p, "r8_shirou", ["{smile,♪}ほれ、サンダの 雪どけ ジャムだべさ。旅の おともに するべさ！"], eH);
    await K.give(eS, eH, "potion");
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    const got = K.pay(p, E6, 900, [["mei_frost", 2], ["e_blue", 1]]);
    if (got.length) K.big(p, "§b§l雷祭りの おみやげ", `§e${got.join("・")}`);
    K.act(eS, 0);
    await K.csay(p, "r8_shirou", ["{smile,up}山では、帰って くるまでが 案内だべさ。……いって らっしゃい だべさ！"]);
    await K.hsay(p, K.V(["{smile,tears,up}……いって きます！"], ["{smile,tears,up}……いって きます。"], ["{smile,up}……いって きます。"], ["{smile,tears,up}……いって まいります！"]));
    await K.end(p, { leave: [eR], bye: [eS, eZ], card: "§f― 第9章 雪山の 双子 おわり ―\n§7→ 次は §5終焉の地 ラグナ§7 へ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(8, [E1, E2, E3, E6], { steps: { 0: [4, "双子と 仮面の 戦士"], 1: [5, "シデンと 手紙"] } });
