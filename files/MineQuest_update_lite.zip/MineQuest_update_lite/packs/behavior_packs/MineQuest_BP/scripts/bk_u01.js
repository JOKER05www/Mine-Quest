/* 第126版 裏1「空っぽの石」（ラグナ・エンド）— 作業 UA
   ムサシが 裏1 から 会話の 相手（/tmp/zf/musashi_design.md）。主人公は 話さない。幼なじみは 石（魂が ない）。
   この ファイルの 頭に 裏1〜7 で 使う 共通の 部品（UA）を 置く（bk_u02〜u07 が import する）*/
import { bkAdd, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, fac, facMark, facFront } from "./epfac.js";
import { TOWNS, getTown, townPos } from "./structures.js";
import { bldOf, townOut, placeOf } from "./storyplace.js";
import { HAKU_SP } from "./stage2.js";
import { ok } from "./ui.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
const { F, S1 } = FAC_OPS;

/* ================= 共通の 部品（裏1〜7）================= */
const near = (a, b, k) => { const A = a.location || a, B = b.location || b, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };
const tc = (tid) => { const t = TOWNS.find((u) => u.id === tid); if (!t) return null; const q = getTown(tid); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const PLQ = {};
export const UA = {
  near, tc, HAKU_SP,
  /* 町の 建物の 前（なければ 町の 外れ）*/
  bld: (tid, kinds, nm, turn = 0.5) => () => { const b = bldOf(tid, kinds, nm); if (b) return b; const o = townOut(tid, turn, nm); return o ? { ...o, nm } : null; },
  /* 町の 外れ（1回 決めたら おぼえる）*/
  out: (key, tid, turn, nm) => () => { if (PLQ[key]) return PLQ[key]; const o = townOut(tid, turn, nm); return (PLQ[key] = o ? { x: o.x, z: o.z, nm } : null); },
  place: (kind, r, nm) => () => { const q = placeOf(kind, r); return q ? { ...q, nm: nm || q.nm } : null; },
  Y: (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); },
  /* ムサシ（腰に 聞き槌）。名を 聞く 前は「知らない 侍」*/
  mu: (K, p, walk = true, nm = "§cムサシ") => { const e = K.npcNear(p, nm, K.PJ("musashi", 19), !walk); K.hold(e, "hammer"); return e; },
  /* 聞き槌で 一度「コン」。人と 生き物は 叩かない（耳を 寄せる）*/
  async tap(K, p, e, q = null) {
    if (!ok(e)) return; if (q) await K.approach(p, e, q, 1.4, 10);
    K.act(e, "raise"); await K.wait(5); K.act(e, "hold");
    K.sound(p, "random.anvil_land", 0.2); K.sound(p, "note.bell", 0.7);
    try { const l = q && q.x !== undefined ? q : e.location; K.burst(p.dimension, { x: l.x, y: (l.y ?? e.location.y) + 1, z: l.z }, "minecraft:basic_crit_particle", 5, 0.3, 0.4); } catch {}
    await K.wait(10); K.act(e, 0);
  },
  async ear(K, p, e, q) { if (!ok(e)) return; if (q) await K.approach(p, e, q, 1.2, 10); K.act(e, "kneel"); await K.wait(14); K.act(e, 0); },
  /* 幼なじみの 石（魂の ない 体）*/
  heroKey: (p) => { try { return qs(load(p)).hero || "hero_rio"; } catch { return "hero_rio"; } },
  stone(K, p, q, nm) { const e = K.npcNear(p, nm || `§7${K.HN(p)}の 石`, K.PJ(UA.heroKey(p), 9), true); if (!ok(e)) return e; try { if (q) e.teleport({ x: q.x, y: q.y ?? e.location.y, z: q.z }); e.setProperty("mrpg:mv", false); } catch {} K.act(e, "kneel"); return e; },
  /* 石の 人（サヤ・ピコ・錠の 座の 人）*/
  statue(K, p, q, nm, job) { const e = K.npcNear(p, nm, job, true); if (!ok(e)) return e; try { if (q) e.teleport({ x: q.x, y: q.y ?? e.location.y, z: q.z }); e.setProperty("mrpg:mv", false); } catch {} return e; },
  /* C20=o: 裏の 各章の 終わりに 一枚（沈んだ 神殿の 前に 座る ゼファード）*/
  async zeph(K, p) {
    if (K.ch(p, "c20") !== "o") return;
    await K.past(p, "§7―― そのころ");
    await K.narr(p, ["§7沈んだ 神殿の 前の 岩に、§fゼファード§7 が 座って いる。", "§8手首の 紐を 指で なぞり、海の 底の 石の 人を、ただ 見おろして いる。"]);
  },
  done: (s, id) => bkHas(s, id),
};

/* ---------- 施設（裏1）---------- */
facAdd("u_scalegrave", { D: [10, 12, 9], box: [-1, -4, 6, 4], H: 6, look: [3, 0, 2], marks: { stone: [2, -2, 0], grave: [4, 0, 1] }, build: () => [   /* エンドの 鱗の 墓標（竜の 鱗の 形の 石柱・石畳・灯り）*/
  F(0, -3, -1, 6, 3, -1, "end_stone_bricks"), F(3, -1, 0, 5, 1, 0, "purpur_block"), F(4, 0, 1, 4, 0, 4, "purpur_pillar"), F(4, -1, 2, 4, 1, 3, "purpur_block"), S1(4, 0, 5, "end_rod"),
  S1(1, -3, 0, "end_rod"), S1(1, 3, 0, "end_rod"), S1(5, -3, 0, "end_stone_brick_wall"), S1(5, 3, 0, "end_stone_brick_wall"),
] });
facAdd("u_boat", { D: [9, 11, 8], box: [-1, -5, 7, 5], H: 5, look: [3, 0, 1], marks: { deck: [3, 0, 1] }, build: () => [   /* 港の 海と 桟橋と 小舟（帆柱・ともし火）*/
  F(0, -5, -1, 7, 5, -1, "water"), F(0, -5, -2, 7, 5, -2, "sand"), F(0, -5, 0, 0, -3, 0, "spruce_fence"), F(0, -2, -1, 1, 2, -1, "spruce_planks"),
  F(2, -1, 0, 5, 1, 0, "spruce_planks"), F(2, -2, 1, 5, -2, 1, "spruce_slab"), F(2, 2, 1, 5, 2, 1, "spruce_slab"), S1(6, 0, 1, "spruce_slab"),
  F(4, 0, 1, 4, 0, 4, "spruce_fence"), F(4, 1, 3, 4, 1, 4, "white_wool"), S1(2, 0, 1, "lantern"),
] });
facAdd("u_lockseat", { D: [10, 12, 9], box: [-1, -4, 7, 4], H: 5, look: [5, 0, 1], marks: { seat: [5, 0, 1] }, build: () => [   /* 闘技場の 下（錠の 座）: 石の 床・壁・天井の 床の 格子・石の 椅子 */
  F(0, -4, -1, 7, 4, -1, "deepslate_tiles"), F(7, -4, 0, 7, 4, 4, "polished_deepslate"), F(1, -4, 0, 6, -4, 4, "polished_deepslate"), F(1, 4, 0, 6, 4, 4, "polished_deepslate"),
  F(3, -2, 5, 7, 2, 5, "iron_bars"), S1(5, 0, 0, "polished_blackstone_stairs"), F(6, -1, 0, 6, 1, 2, "polished_blackstone"),
  S1(2, -3, 0, "soul_lantern"), S1(2, 3, 0, "soul_lantern"),
] });

/* ---------- 町の 人 ---------- */
castAdd("u_shizuku", { nm: "シズク", role: "竜の 巫女", gobi: "ございます", skin: "sakuya", town: "t27", at: () => { const q = bldOf("t27", ["home", "home2", "home3"]); return q ? { x: q.x + 2, z: q.z } : null; },
  hide: (s) => !bkHas(s, "u01e4"),
  after: [
    [(s) => !!s.heroBack, ["{smile,tears}……竜が、お二人の 名を 覚えて おりました。お帰りなさいませ。"]],
    [(s) => bkHas(s, "u07e7"), ["{closed}帳に 名が なかった と。……手帳の 最後の 頁は、正しゅう ございました。"]],
    [() => true, ["{closed}石は 毎朝 わたくしが 拭いて おります。……鳴る 音は、きのうと 同じで ございます。"]],
  ] });
castAdd("u_fisher", { nm: "ウミオ", role: "漁師", gobi: "", skin: "m6_umi", town: "t27", at: () => { const q = bldOf("t27", ["harbor"]); return q ? { x: q.x + 1, z: q.z + 2 } : null; },
  hide: (s) => !bkHas(s, "u01e6"),
  after: [[() => true, ["{smile}あの 侍、また 魚の 舟に 乗ろうと しなかったか？ ……耳は いいのに、札は 読めねえんだな。"]]] });

const TID = "t27";
const GRAVE = UA.out("grave", TID, 0.4, "エンドの 鱗の 墓標");
const SHZ = UA.bld(TID, ["home", "home2", "home3"], "エンドの シズクの 家");
const DRAGON = UA.out("dragon", TID, -0.5, "エンドの 竜の 石像の 丘");
const PORT = UA.bld(TID, ["harbor"], "エンドの 港", 1.6);
const UNDER = UA.out("under", "t0", 0.2, "ルミナの 闘技場の 下");
const RANCH = UA.place("ranch", 0, "オルドの 牧場");
const DRSP = (K) => (K.wildSp ? K.wildSp("dragon", "L") : "hdra12");
const graveSet = (K, p) => fac(K, p, "u_scalegrave", "u_scalegrave", 9, UA.Y(K, p));
function heroAt(K, p) { const m = facMark("u_scalegrave", "stone", p.location); if (m) return m; const S = K.S(p); return S ? S.at(4, -1.5) : null; }

/* ================= 裏1 ================= */
bkAdd("u01", [
  { id: "u01e1", t: "鱗の 墓標の 朝", place: GRAVE, fac: "u_scalegrave", F: ["F48"], battles: 0,
    hint: "§fラグナの §eさいはての 村 エンド§f の §e鱗の 墓標§f へ 行こう §7（幼なじみの 石が 眠る 場所。右上の 案内）",
    syn: "朝、エンドの 鱗の 墓標。知らない 侍が、幼なじみの 石を 手のひらほどの 槌で 一度だけ 叩き、耳を 寄せた。「……中が、空っぽだ。けど、まだ 鳴ってる」。かばんの コンパスの 針は、石の そばで 回りつづけて いた。",
    async run(p, d, K) {
      const G = graveSet(K, p), eS = UA.stone(K, p, heroAt(K, p));
      await K.open(p, "エンドの 鱗の 墓標", "day");
      if (G) await K.at(p, G, 14, 6, 1.8);
      if (ok(eS)) await K.push(p, eS, 24, 4.5, 2);
      await K.narr(p, [`§7竜の 鱗の 形を した 墓標の 横に、§f${K.HN(p)}§7 の 石が ある。`, "§8胸に 小さな 穴。……朝の 光が、その 穴を 通りぬけて いく。"], eS);
      /*F48*/ K.sound(p, "block.amethyst_block.chime", 0.5);
      await K.narr(p, ["§7かばんの 中で、§fコンパス§7 の 針が くるくる 回って いる。", "§8石の そばに 来ると、針は 一度も 止まらない。"]);
      const eM = UA.mu(K, p, true, "§7知らない 侍");
      await K.walkCam(p, eM, near(eM, eS || p, 1.6), 22);
      await K.up(p, eM, 10);
      await UA.tap(K, p, eM, eS ? eS.location : null);
      await UA.ear(K, p, eM, null);
      await K.say(p, "知らない 侍", ["{closed}……中が、空っぽだ。", "{shock}けど、まだ 鳴ってる。"], eS);
      if (ok(eS)) await K.push(p, eS, 18, 3, 1.4);
      await K.say(p, "知らない 侍", ["{closed}……澄んだ 音だ。割れた 石は、こんな 音 しねえ。"], eM);
      K.pay(p, this, 300, [["c_fruit", 2]]);
      await K.end(p, { bye: [eS], leave: [eM], card: "§7→ 侍は 墓標の 前から 動かない（もう一度 墓標へ）" });
      return true;
    } },
  { id: "u01e2", t: "二回 鳴いた", place: GRAVE, fac: "u_scalegrave", battles: 0,
    hint: "§fエンドの §e鱗の 墓標§f の 前で、侍と 話そう",
    syn: "侍は「ムサシ」と 名乗った。主人公が 黙って いると「しゃべらねえのか。じゃあ、そいつに 聞く」と 相棒に 聞いた。相棒が 二回 鳴くと「……二回 鳴いた。よし、覚えた」。……違う。",
    async run(p, d, K) {
      graveSet(K, p); const eS = UA.stone(K, p, heroAt(K, p));
      await K.open(p, "エンドの 鱗の 墓標", "day");
      const eM = UA.mu(K, p, true, "§7知らない 侍");
      await K.up(p, eM, 10);
      await K.say(p, "知らない 侍", ["{closed}……ムサシだ。クロガネの 鍛冶の 家の、末っ子。"], eS);
      try { eM.nameTag = "§cムサシ"; } catch {}
      await K.say(p, "ムサシ", ["{?}で、おまえは？"], eM);
      await K.narr(p, ["§7…………。"], eM);
      await K.say(p, "ムサシ", ["{sweat}しゃべらねえのか。……じゃあ、そいつに 聞く。"], eM);
      const pal = K.palEnt(p);
      if (ok(pal)) { await K.up(p, pal, 8); K.sound(p, "mob.cat.meow", 0.8); await K.wait(8); K.sound(p, "mob.cat.meow", 0.8); await K.wait(8); }
      await K.say(p, "ムサシ", ["{smile,up}……二回 鳴いた。よし、覚えた。", "{smile}おまえは「二回」だ。"], pal || eM);
      if (ok(pal)) { K.act(pal, "no"); await K.wait(8); }
      await K.say(p, "ムサシ", ["{sweat,汗}……違うのか。首を 振るなよ。", "{closed}本人の 口から 聞くまで、名前は 呼ばねえ。……それが 俺の 掟だ。"], pal || eM);
      await K.end(p, { bye: [eS, pal], leave: [eM], card: "§7ムサシ が 旅の 連れに なった" });
      return true;
    } },
  { id: "u01e3", t: "寝ぼすけの 言伝", place: GRAVE, fac: "u_scalegrave", F: ["F25"], battles: 0,
    hint: "§fエンドの §e鱗の 墓標§f の 前で、ムサシの 用を 聞こう",
    syn: "ムサシは 言伝を 持って いた。「闘技場の 上の 寝ぼすけの 言伝だ。『鍔が 泣きだした。六つ目を 連れて 来い』」。六つ目 ── 祭壇を 開けた 主人公の ことだ。",
    async run(p, d, K) {
      graveSet(K, p); const eS = UA.stone(K, p, heroAt(K, p));
      await K.open(p, "エンドの 鱗の 墓標", "day");
      const eM = UA.mu(K, p, true);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{closed}言伝が ある。ルミナの 闘技場の、客席の いちばん 上で 寝てる じいさんからだ。", "{sweat}……寝ぼすけの くせに、言う ことだけは はっきりしてやがる。"], eS);
      /*F25*/ await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{angry,low}『鍔が 泣きだした。§e六つ目§f を 連れて 来い』。", "{?}六つ目ってのは、祭壇を 開けた やつの ことだろ。……おまえだ。"], eM);
      await K.say(p, "ムサシ", ["{closed}字は 読めねえ。だから 言われた 言葉を、一字も 変えずに 持って きた。", "{smile}……今、うなずいたな。よし。"], eS);
      await K.end(p, { leave: [eM], bye: [eS], card: "§7→ ムサシ「その 前に、ここの 巫女に 用が ある。おまえの 手帳の ことだ」" });
      return true;
    } },
  { id: "u01e4", t: "声で 読む 頁", place: SHZ, battles: 0,
    hint: "§fエンドの §eシズクの 家§f へ 行こう §7（セオの 手帳を 読んで もらう）",
    syn: "シズクの 家。ムサシ「俺は 字が 読めねえ。声で 読んで くれ」。シズクが セオの 手帳の 最後の 頁を 読んだ。『魂の 帳に 名が なければ、呼び戻せる』。",
    async run(p, d, K) {
      await K.open(p, "エンドの シズクの 家", "day");
      const eZ = K.cast(p, "u_shizuku"), eM = UA.mu(K, p, true);
      await K.up(p, eZ, 10);
      await K.csay(p, "u_shizuku", ["{closed}……鱗の 墓標の 前で、毎朝 お見かけ いたします。", "{?}今日は、お連れさまが ございますのね。"], eM);
      await K.say(p, "ムサシ", ["{closed}こいつの 手帳。眼鏡の 学者が、最後に 投げて よこした やつだ。", "{sad}俺は 字が 読めねえ。……声で 読んで くれ。"], eZ);
      K.sound(p, "item.book.page_turn", 1); K.act(eZ, "hold"); K.hold(eZ, "book");
      await K.push(p, eZ, 20, 3.5, 1.2);
      await K.csay(p, "u_shizuku", ["{closed}……最後の 頁で ございます。", "{up}『魂の 帳に 名が なければ、呼び戻せる』。"], eM);
      await K.say(p, "ムサシ", ["{shock,!}……もう一回。"], eZ);
      await K.csay(p, "u_shizuku", ["{closed}『名が なければ、呼び戻せる』。"], eM);
      await K.say(p, "ムサシ", ["{closed}……今のは、書いた やつの 声で 聞こえた。なら 本物だ。"], eZ);
      await K.csay(p, "u_shizuku", ["{sad}魂の 帳が どこに あるかは、書いて ございません。", "{closed}竜も 知りません。……竜は、生きて いる 者の 名しか 覚えませんので。"], eM);
      await K.say(p, "ムサシ", ["{closed}だったら、帳の ある 場所を さがす。", "{smile}……手帳、しまっとけ。おまえが 持ってる 頁だ。"], eZ);
      K.pay(p, this, 400, [["c_fruit", 2]]);
      await K.end(p, { leave: [eM], bye: [eZ], card: "§7→ ムサシ「……あの 石の 竜も、叩いて みてえ」" });
      return true;
    } },
  { id: "u01e5", t: "寝てる 音", place: () => { const f = facFront("r9look", 6); return f ? { x: f.x, y: f.y, z: f.z, nm: "エンドの 竜の 見晴らし台（竜の 石像）" } : DRAGON(); }, fac: "r9look", battles: 0,   /* 第126版(PV): 竜の 石は 見晴らし台に 運ばれた（本14-9）。何も ない 丘では しない */
    hint: "§fエンドの §e竜の 見晴らし台§f へ 行こう §7（レイの 竜が 石に なった 場所）",
    syn: "ムサシは レイの 竜の 石を 叩いた。鈍い 音。「こっちは、中に 誰か いる。寝てる 音だ」。幼なじみの 石と 聞き比べて、ムサシは 黙った。",
    async run(p, d, K) {
      fac(K, p, "r9look", "lookout", 9, UA.Y(K, p));
      const S = K.S(p), eD = K.monEnt(p, S ? S.at(5, 0) : K.fwd(p, 5), DRSP(K), "§7レイの 竜の 石像");
      try { eD && eD.setProperty("mrpg:mv", false); } catch {}
      await K.open(p, "エンドの 竜の 見晴らし台（竜の 石像）", "day");
      if (ok(eD)) await K.push(p, eD, 22, 7, 2.6);
      await K.narr(p, ["§7翼を 広げた まま 石に なった 竜。§f祭壇で、レイと あなたを かばった 竜だ。"], eD);
      const eM = UA.mu(K, p, true);
      await UA.tap(K, p, eM, eD ? eD.location : null);
      K.sound(p, "dig.stone", 0.6);
      await K.say(p, "ムサシ", ["{shock}……鈍い。", "{closed}こっちは、中に 誰か いる。……寝てる 音だ。"], eD);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{sad,…}さっきの 石は、澄んでた。空っぽの 澄み方だ。"], eD);
      K.act(eM, "kneel"); await K.wait(10);
      await K.narr(p, ["§7ムサシは 竜の 足に 手のひらを 当てた まま、しばらく 何も 言わなかった。"], eM);
      K.act(eM, 0);
      await K.say(p, "ムサシ", ["{closed}……中身が どっかに 行ってるなら、取りに 行きゃ いい。", "{up}寝てる ほうは、起きるまで 待てる。"], eD);
      await K.end(p, { leave: [eM], bye: [eD], card: "§7→ ムサシ「港へ 行くぞ。ルミナへ 帰る 舟を さがす」" });
      return true;
    } },
  { id: "u01e6", t: "魚の 舟", place: PORT, battles: 0,
    hint: "§fエンドの §e港§f へ 行こう §7（ルミナへ 帰る 舟を さがす）",
    syn: "港で ムサシは 札では なく 波止場の 音で 舟を 選んだ。「この 舟は 軽い 音だ。速え」。漁師「それは 魚の 舟だ」。",
    async run(p, d, K) {
      const B = fac(K, p, "u_boat", "u_boat", 9, UA.Y(K, p));
      await K.open(p, "エンドの 港", "day");
      if (B) await K.at(p, B, 14, 6, 1.6);
      const eM = UA.mu(K, p, true);
      await UA.tap(K, p, eM, B);
      await K.say(p, "ムサシ", ["{smile,up}……軽い 音だ。この 舟、速え。", "{smile}札？ 読めねえ。舟は 叩きゃ わかる。"], eM);
      const eF = K.cast(p, "u_fisher");
      await K.up(p, eF, 8);
      await K.csay(p, "u_fisher", ["{sweat,汗}おい、そりゃ 魚の 舟だ。", "{closed}人の 乗る 舟は、札に『ルミナ行き』って 書いて あるだろ。"], eM);
      await K.say(p, "ムサシ", ["{sweat}……魚くせえ 音だとは 思った。", "{closed}じゃあ、その 札の 舟だ。……おまえ、今 笑ったな？"], eF);
      await K.end(p, { leave: [eF, eM], card: "§7→ 夜の 舟で ルミナへ（港で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u01e7", t: "石の 娘の 音", place: PORT, F: ["F41"], battles: 0,
    hint: "§fエンドの §e港§f から 夜の 舟に 乗ろう",
    syn: "夜の 海の 上。ムサシが 話した。子どもの ころ、工房の 奥の 石の 娘が 毎晩 澄んで 鳴り、槌で 叩き返して 寝た。「……さっきの 石と、同じ 音だった」。",
    async run(p, d, K) {
      const B = fac(K, p, "u_boat", "u_boat", 9, UA.Y(K, p));
      await K.open(p, "エンドの 港（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      if (B) { await K.walkCam(p, eM, near(p, B, 0.5), 18); await K.at(p, B, 14, 7, 2.2); }
      await K.narr(p, ["§7舟は 夜の 海へ 出た。§8波の 音だけが する。"], eM);
      await K.up(p, eM, 10);
      /*F41*/ await K.say(p, "ムサシ", ["{closed}……ガキの ころ、うちの 工房の 奥に、石の 娘が いた。", "{closed}毎晩、澄んで 鳴るんだ。リン、リンって。"], B ? null : eM);
      await K.say(p, "ムサシ", ["{smile,…}だから 俺は 槌で 叩き返して、寝た。……毎晩だ。"], eM);
      await K.push(p, eM, 18, 3, 1.5);
      await K.say(p, "ムサシ", ["{sad,…}……さっきの 墓標の 石と、同じ 音だった。", "{closed}一つ、二つ、三つ……。"], eM);
      await K.narr(p, ["§7ムサシは 小さな 声で 何かを 数えて、そのまま 黙った。"], eM);
      await K.end(p, { leave: [eM], kind: "night", card: "§7→ 夜が 明ける ころ、舟は ルミナに 着く" });
      return true;
    } },
  { id: "u01e8", t: "待ってる 音", place: UNDER, fac: "u_lockseat", battles: 0,
    hint: "§fルミナの §e闘技場の 下§f へ 行こう §7（錠の 座の 石）",
    syn: "闘技場の 下、錠の 座。石に なった 人が 座って いる。ムサシは 叩かずに、耳だけ 寄せた。「……待ってる 音だ」。",
    async run(p, d, K) {
      const o = K.ch(p, "c20") === "o", L = fac(K, p, "u_lockseat", "u_lockseat", 0, UA.Y(K, p)), sq = facMark("u_lockseat", "seat", p.location) || L;
      const eZ = UA.statue(K, p, sq, o ? "§7オルドの 石" : "§7ゼファードの 石", K.PJ(o ? "ordo" : "zephard", 8));
      await K.open(p, "ルミナの 闘技場の 下（錠の 座）", "dusk");
      if (ok(eZ)) await K.push(p, eZ, 24, 6, 2);
      await K.narr(p, ["§7天井の 床の 格子から、闘技場の 歓声が 細く 落ちて くる。", `§7錠の 座に、§f${o ? "オルド" : "ゼファード"}§7 が 石に なって 座って いる。`], eZ);
      const eM = UA.mu(K, p, true);
      await K.approach(p, eM, eZ || L, 1.6, 14);
      await K.say(p, "ムサシ", ["{closed}……叩かねえ。人だからな。"], eZ);
      await UA.ear(K, p, eM, null);
      await K.say(p, "ムサシ", ["{sad,…}……待ってる 音だ。", o ? "{closed}牧場の じいさんだろ。……座ってても、孫の 足音を 数えてる。" : "{closed}二十年 座ってた 音だ。……まだ、座ってる つもりで いやがる。"], eZ);
      await K.end(p, { leave: [eM], bye: [eZ], card: "§7→ オルドの 牧場へ" });
      return true;
    } },
  { id: "u01e9", t: "牧場の 石", place: RANCH, F: ["F18"], battles: 0,
    hint: "§fルミナの 外れの §eオルドの 牧場§f へ 行こう",
    syn: "牧場には、石に なった ピコと ハク。座＝ゼ なら オルドが 小屋の 掃除を して いる。座＝オ なら レイが 祖父の 代わりに 干し草を 運んで いる。",
    async run(p, d, K) {
      const o = K.ch(p, "c20") === "o", S = K.S(p);
      const eH = K.monEnt(p, S ? S.at(5, -2) : K.fwd(p, 5, -2), HAKU_SP, "§7ハクの 石"), eP = UA.statue(K, p, S ? S.at(5, 1) : null, "§7ピコの 石", K.PJ("pico", 9));
      try { eH && eH.setProperty("mrpg:mv", false); } catch {}
      await K.open(p, "オルドの 牧場", "day");
      /*F18*/ if (ok(eH)) await K.push(p, eH, 20, 6, 1.8);
      await K.narr(p, ["§7牧場の すみ。石の §fハク§7 が、石の §fピコ§7 の 前に 体を 丸めて いる。", "§8ピコの 頭には、まだ 何も のって いない。"], eH);
      const eM = UA.mu(K, p, true);
      let eR, who;
      if (!o) {
        who = "オルド"; eR = K.npcNear(p, "§eオルド", K.PJ("ordo", 8)); K.act(eR, "work");
        await K.up(p, eR, 10);
        await K.say(p, "オルド", ["{closed}……来たか。小屋の 掃除じゃ。ハクが 起きた とき、汚れて おったら 怒るでな。", "{smile}その 侍は？ ……ほう、クロガネの 末っ子か。"], eM);
      } else {
        who = "レイ"; eR = K.npcNear(p, "§bレイ", 17); K.act(eR, "work");
        await K.up(p, eR, 10);
        await K.say(p, "レイ", ["{closed}……じいちゃんの 代わりだ。干し草、運ばねえと ハクが すねる。", "{sad}石でも、すねる 顔は するんだ。……知ってるか？"], eM);
      }
      await UA.ear(K, p, eM, eH ? eH.location : null);
      await K.say(p, "ムサシ", ["{smile,…}……こっちも、寝てる 音だ。", "{closed}起きる 音は、まだ 聞こえねえ。……けど、腹は 減ってる 音だ。"], eR);
      await K.say(p, who, o ? ["{smile,…}……そうか。じゃあ、毎日 運ぶ。"] : ["{smile}ほっほ。……ならば 毎日 掃除じゃ。"], eM);
      K.pay(p, this, 600, [["c_fruit", 3]]);
      await UA.zeph(K, p);
      await K.end(p, { leave: [eM, eR], bye: [eH, eP], card: "§7→ ムサシ「闘技場の 寝ぼすけに 会う。……鍔が 泣いてる らしい」" });
      return true;
    } },
]);
