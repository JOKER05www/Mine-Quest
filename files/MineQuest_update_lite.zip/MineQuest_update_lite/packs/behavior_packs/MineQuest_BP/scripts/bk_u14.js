/* 第126版 裏14「城壁と 王宮」（常世・上の 区）— 作業 UB
   区8（二冠 ギレンドドロス・城壁）: 1話 向かい合う → 後: 勝った 一拍 → 2話（詩人ユキノ）
   区9（一冠 ベルガ・王宮）: 3話 前 → 4話 向かい合う → 後: 勝った 一拍 → 5話（王妃セレネ・「記録の 神」と 呼び直す）→ 6話（王の 魂）
     → 7話（場面が とぶ: アルカトラス城の 封印庫）→ 8・9話（塔の 下の セオ。C08 で 変わる）*/
import { K } from "./bkeng.js";
import { U } from "./bk_u08.js";
import { SGK } from "./saga.js";
import { act, hold, fx, fade, PJ } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
import { ruSite } from "./ruins.js";
const { F, S1, ok } = U;
const V = (g, o, c, t) => ({ g, o, c, t });

facAdd("u14wall", { D: [10, 12, 14], box: [0, -5, 6, 5], H: 5, look: [2, 0, 2], marks: { wall: [1, 0, 2], gate: [1, 0, 1] },
  build: () => [F(1, -5, 0, 1, -1, 4, "stone_bricks"), F(1, 1, 0, 1, 5, 4, "stone_bricks"), F(3, -5, 0, 3, -2, 4, "deepslate_bricks"), F(3, 2, 0, 3, 5, 4, "deepslate_bricks"), F(5, -5, 0, 5, -3, 4, "polished_blackstone_bricks"), F(5, 3, 0, 5, 5, 4, "polished_blackstone_bricks")] });
facAdd("u14throne", { D: [11, 13, 15], box: [0, -4, 7, 4], H: 5, look: [5, 0, 1.5], marks: { throne: [6, 0, 1.4], ped: [3, 2, 1.2], yard: [1, 0, 0.5] },
  build: () => [F(0, 0, 0, 5, 0, 0, "red_carpet"), F(6, -1, 0, 7, 1, 0, "quartz_block"), S1(6, 0, 1, "quartz_stairs"), F(7, -1, 1, 7, 1, 3, "quartz_pillar"), S1(3, 2, 0, "chiseled_quartz_block"), S1(3, 2, 1, "chiseled_quartz_block"), ...[-3, 3].flatMap((b) => [F(1, b, 0, 1, b, 2, "quartz_pillar"), F(4, b, 0, 4, b, 2, "quartz_pillar")])] });
facAdd("u14vault", { D: [9, 11, 13], box: [0, -3, 4, 3], H: 4, look: [3, 0, 1.2], marks: { slab: [3, 0, 1.4], door: [0, 0, 1], mural: [4, 2, 2] },
  build: () => [F(0, -3, 0, 4, 3, 3, "deepslate_tiles"), F(1, -2, 0, 3, 2, 2, "air"), F(0, -1, 0, 0, 1, 2, "air"), F(0, -1, 0, 0, 1, 0, "iron_bars"), S1(3, 0, 0, "chiseled_deepslate"), S1(3, 0, 1, "lodestone"), S1(3, 2, 2, "chiseled_stone_bricks")] });
facAdd("u14chain", { D: [10, 12, 14], box: [0, -3, 3, 3], H: 6, look: [2, 0, 1.2], marks: { desk: [2, 0, 1.1], chain: [3, 0, 3] },
  build: () => [F(3, -3, 0, 3, 3, 5, "polished_deepslate"), F(2, -1, 1, 2, -1, 5, "chain"), F(2, 1, 1, 2, 1, 5, "chain"), S1(2, 0, 0, "lectern"), F(1, -2, 0, 1, 2, 0, "purple_carpet"), S1(2, -2, 0, "amethyst_cluster")] });

/* ---- 区8: ギレンドドロス ---- */
const fight8 = U.fight(8, async (p, C) => {
  await K.open(p, "常世 ― 城壁の 区");
  const w = K.fac(p, "u14wall", "u14wall", 99, U.y0(p)), wq = facMark("u14wall", "wall", p.location) || w;
  if (wq) await K.at(p, wq, 18, 8, 2);
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  await U.rec(p, C, 8, ["§7『詩人 ユキノ。辞世の 句「とけたなら / 春と 呼んでね / 名を 呼んで」』", "§8城壁は 三重。どれも 内側から 閉ざされて いる。"], "yuki", "up");
  await U.lesson(p, C, 8, mu);
  const e = U.boss(p, C, 8, 11, 0); await U.bossIn(p, e, 8);
  /*F38 回: 王墓で 見た 鬼王の 碑の 王 */
  await U.say(p, "ギレンドドロス", ["{closed}三重の 壁。三重の 鎧。……何ものも、ここへは 入れぬ", "{sad,up}わたしは 永遠を 願った。こわれぬ 城を。……永遠とは、こわれぬ ことだ"], mu);
  await U.H(p, V(["{shock,!}……王墓の 壁の 碑、『こわれぬ 城を 願いし 鬼王』。……あなたの こと？"], ["{shock,!}……王墓の 碑の『こわれぬ 城を 願いし 鬼王』……あなた なのね"], ["{shock,!}……王墓の 碑の 鬼王。おまえか"], ["{shock,!}……王墓の 碑に あった『こわれぬ 城を 願いし 鬼王』……あなた ですか"]), e);
  await U.M(p, mu, ["{angry,怒}壊れねえ もんなんか ねえよ。……鍛冶屋の 息子が 言うんだ、間違いねえ。"], "guard");
  await U.say(p, "ギレンドドロス", ["{angry,!,low,roar}ならば、こわして みよ"]);
}, async (p, C) => {
  const w = K.fac(p, "u14wall", "u14wall", 99, U.y0(p)), gq = facMark("u14wall", "gate", p.location) || w;
  const e = U.boss(p, C, 8, 7, 0); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "ギレンドドロス", ["{closed,up}……とけて しまえば、春が 来るのだな"]);
  if (ok(e)) await fade(e, "minecraft:white_smoke_particle");
  K.sound(p, "random.door_open", 0.8, 0.5); if (gq) await K.at(p, gq, 14, 6, 1);
  await U.narr(p, ["§7三重の 城壁が、内側から ひらいた。"]);
});
/* ---- 区9: ベルガ ---- */
const fight9 = U.fight(9, async (p, C) => {
  await K.open(p, "常世 ― 王宮の 玉座");
  const t = K.fac(p, "u14throne", "u14throne", 99, U.y0(p)), th = facMark("u14throne", "throne", p.location) || t;
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  const e = U.boss(p, C, 9, 10, 0); await U.bossIn(p, e, 9);
  /* 敵の 正しさ: 鎖の 端を 自分の 手首に 巻いて いる */
  if (ok(e)) { const l = e.location; for (let k = 0; k < 8; k++) try { p.dimension.spawnParticle("minecraft:soul_particle", { x: l.x + 1, y: l.y + 1 + k * 0.3, z: l.z }); } catch {} await K.low(p, e, 12); }
  await U.narr(p, ["§7主の 手首に、鎖の 端が 何重にも 巻きつけて あった。§8鎖の 先は、玉座の 奥へ 続いて いる。"], e);
  await U.say(p, "ベルガ", ["{angry,low}ひざまずけ。", "{closed,up}わたしは 王の 声。……王が 黙った 千年、わたしが 命じて きた。王を 怪物と 書かせぬ ために"], mu);
  await U.M(p, mu, ["{angry,!}王の 声？ ……王様を どこに やりやがった"], "guard");
  await U.say(p, "ベルガ", ["{rage,!,roar}答える 義理は ない。命令だ。§cひざまずけ"]);
}, async (p, C) => {
  K.fac(p, "u14throne", "u14throne", 99, U.y0(p));
  const e = U.boss(p, C, 9, 7, 0); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "ベルガ", ["{shock,…,up}……命令が、とどかない。……王よ、わたしは"]);
  const ks = [C.npc("", PJ("stoneknight", 8), 5, -2, 0, "veil"), C.npc("", PJ("ruinguard", 8), 5.4, 0, 0, "veil"), C.npc("", PJ("mira", 8), 5, 2, 0, "veil")];
  for (const x of ks) act(x, "kneel"); await K.wide(p, 14);
  for (const x of ks) act(x, "up");
  await U.narr(p, ["§7王宮の 百の 石が、一度だけ 顔を 上げた。§8そして、ひざまずくのを やめて 消えた。"]);
  for (const x of ks) if (ok(x)) await fade(x, "minecraft:endrod");
  if (ok(e)) await fade(e, "minecraft:soul_particle");
});
const TOWER = () => { const q = ruSite(15); return q ? { x: q.x + 0.5, z: q.z + 26.5 } : null; };

U.reg("u14", [
  { id: "u14e1", t: "こわれぬ 城", free: false, F: ["F38"], run: fight8, syn: "城壁の 区。二冠ギレンドドロス「永遠とは、こわれぬ ことだ」。王墓の 碑の 鬼王だった。" },
  { id: "u14e2", t: "春と 呼んでね", free: false,
    syn: "城壁が ひらき、詩人 ユキノの 石が とけた。「とけたなら、春と 呼んでね。名を 呼んで」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 城壁の 区（ひらいた 門）");
        K.fac(p, "u14wall", "u14wall", 99, U.y0(p));
        const yk = C.npc("§fユキノ", PJ("yuki", 8), 4.4, 0.6, 0, "veil"); act(yk, "up");
        if (ok(yk)) { await K.push(p, yk, 20, 4, 1.6, 1.5); fx(p.dimension, "minecraft:snowflake_particle", yk.location, 10, 1); }
        await U.narr(p, ["§7空を 見上げた 詩人の 石に、ひびが 入った。§8……灰色が、雪の ように とけて 落ちる。"], yk);
        await U.say(p, "ユキノ", ["{smile,closed,up}……とけたなら、春と 呼んでね。", "{smile,tears}名を 呼んで。"]);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        await U.H(p, V(["{smile,tears}……ユキノさん。……春だよ"], ["{smile,tears}……ユキノさん。……春よ"], ["{smile,tears}……ユキノ。春だ"], ["{smile,tears}……ユキノさん。……春です"]), yk);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……ユキノ。……今、本人が 名乗った。呼んだぞ。"], "nod");
        if (ok(yk)) { act(yk, "bow"); fx(p.dimension, "minecraft:snowflake_particle", yk.location, 12, 1); await SGK.bye(p, yk); }
        await U.end(p, C, { card: "§7→ 一冠の §e王宮の 区§7 へ（右上の 案内）" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u14e3", t: "百の ひざまずく 石", free: false,
    syn: "王宮の 区の 前庭に、ひざまずいた 形の 石が 百も 並んで いた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 王宮の 区の 前庭");
        const t = K.fac(p, "u14throne", "u14throne", 99, U.y0(p)), yd = facMark("u14throne", "yard", p.location) || t;
        const ks = [C.npc("", PJ("stoneknight", 8), 6, -2.4, 0, "veil"), C.npc("", PJ("ruinguard", 8), 6.4, -0.8, 0, "veil"), C.npc("", PJ("stoneknight", 8), 6, 0.8, 0, "veil"), C.npc("", PJ("ruinguard", 8), 6.4, 2.4, 0, "veil")];
        for (const x of ks) act(x, "kneel");
        await K.wide(p, 18);
        await U.narr(p, ["§7前庭に、ひざまずいた 形の 石が 並んで いた。§8……十、二十……百。みんな、玉座の 方へ 頭を 下げて いる。"], yd);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        await U.rec(p, C, 9, ["§7『王妃の 侍女 ミラ。王妃さまは 祈って いた。「あの 一日が、永遠に 続きますように」と』", "§8玉座の 前には、ひざまずいた 形の 石が 百も 並んで いた。"], "mira", "kneel");
        await U.H(p, V(["{sad}……王妃さまが『あの 一日が 永遠に』って 祈ったんだって"], ["{sad}……王妃さまが『あの 一日が 永遠に』と 祈られたのね"], ["{sad}……王妃が『あの 一日が 永遠に』と 祈った"], ["{sad}……王妃さまが『あの 一日が 永遠に』と 祈られたそうです"]), mu);
        await U.tap(p, mu);
        await U.M(p, mu, ["{closed}……この 石だけ、三千年じゃ ねえ。……千年の 音だ。", "{?}……都の 上に、もう 一枚 重ねて 綴じてあるのか。"], "hold");
        await U.lesson(p, C, 9, mu);
        await U.end(p, C, { card: "§7→ 玉座の 間へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u14e4", t: "王の 声", free: false, run: fight9, syn: "一冠ベルガ（王の 声）との 戦い。鎖の 端を 自分の 手首に 巻いて いた。" },
  { id: "u14e5", t: "楽しかった、のね", free: false, ans: [],
    syn: "王の 魂の 両手は、鍵穴の 形に 組まれて いた。王妃セレネ「あの 一日は、楽しかった、のね。わたしも」。記録の 民の 血を ひく 王妃は、人々が「邪神」と 呼ぶ 神を「記録の 神」と 呼んだ。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 王宮の 玉座");
        const t = K.fac(p, "u14throne", "u14throne", 99, U.y0(p)), th = facMark("u14throne", "throne", p.location) || t;
        if (th) await K.at(p, th, 14, 5, 1);
        const vg = C.npc("§6王 ヴァルグレイドの 魂", PJ("arca13", 15), 5, 1.4, 0, "smoke"); act(vg, "hold");
        if (ok(vg)) { await K.push(p, vg, 18, 3, 1.5, 1.2); fx(p.dimension, "minecraft:totem_particle", vg.location, 8, 0.6); }
        await U.narr(p, ["§7玉座の 前に、王の 魂が 立って いた。§f両手が、§e鍵穴の 形§f に 組まれて いる。"], vg);
        const se = C.npc("§d王妃 セレネの 魂", PJ("selene", 8), 7, -1.4, 0, "smoke"); act(se, 0);
        if (ok(se) && ok(vg)) { const b = vg.location; await K.walkCam(p, se, { x: b.x - 1.2, y: b.y, z: b.z }, 24); }
        await U.say(p, "王妃 セレネ", ["{sad,?,up}……あなた。まだ、そこに いるの？"], vg);
        await U.say(p, "ヴァルグレイドの 魂", ["……ああ。ここに いる。……セレネ。あの 一日は、楽しかった"], se);
        await K.two(p, se, vg, 10);
        await U.say(p, "王妃 セレネ", ["{smile,tears,up}……そう。楽しかった、のね。", "{smile,closed}わたしも。"]);
        /* 00 §16: 記録の 民の 末裔（王妃の 血筋）が「記録の 神」と 呼び直す */
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, se, 8);
        await U.say(p, "王妃 セレネ", ["{closed}……人は あの 方を『邪神』と 呼ぶのね。名の ない、邪な 神と", "{sad,up}わたしの 一族は、ずっと 昔から『記録の 神』と お呼びして いたの。何もかも 書き留めて、誰も 失わない ように して くださる 神さま"], mu);
        await U.say(p, "王妃 セレネ", ["{sad}……あの 夜、わたしが 祈った。『あの 一日が、永遠に』。記録の 神は、その とおりに 書き留めて くださった。……だから 王宮の 一日は、ここに ある"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{shock,…}……記録の 神。……書いて 閉じこめる 神か。", "{closed}……そいつが、塔の 上の 字を 書かせてる 奴なんだな。"], "hold");
        if (ok(se)) await fade(se, "minecraft:white_smoke_particle");
        await U.end(p, C, { leave: [mu], card: "§7→ 王の 魂が、台座の 文を 指さした" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u14e6", t: "錠に なった 王", free: false, F: ["F01", "F15"], ans: ["qu131"],
    syn: "台座の 欠けた 文の 残りは『名を 呼ぶ 声には 宿れぬ』。王の 魂「わたしが、錠に なった。……アルディス、すまなかった」。千年前の 王は 怪物では なく、自ら 錠に なった 王だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 王宮の 玉座");
        const t = K.fac(p, "u14throne", "u14throne", 99, U.y0(p)), ped = facMark("u14throne", "ped", p.location) || t;
        const vg = C.npc("§6王 ヴァルグレイドの 魂", PJ("arca13", 15), 4.6, 1.4, 0, "veil"); act(vg, "point");
        if (ped) await K.push(p, ped, 18, 3, 1.3, 0.4);
        /*F15 回: 台座の 文の 残り */
        await U.narr(p, ["§7台座の 欠けた 文。§8廃都で 見た『影は 知る……に 宿る。……は……に 宿れぬ』の、続きの 欠片。"], ped);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        await U.H(p, V(["{closed}……読むね。『影は 知る 者に 宿る。§e名を 呼ぶ 声には 宿れぬ§f』"], ["{closed}……読むわね。『影は 知る 者に 宿る。§e名を 呼ぶ 声には 宿れぬ§f』"], ["{closed}……『影は 知る 者に 宿る。§e名を 呼ぶ 声には 宿れぬ§f』"], ["{closed}……お読みします。『影は 知る 者に 宿る。§e名を 呼ぶ 声には 宿れぬ§f』"]), vg);
        if (ok(vg)) { act(vg, "kneel"); await K.up(p, vg, 12); }
        /*F01 回: 王は 心を 呑む 怪物では なく、自ら 錠に なった */
        await U.say(p, "ヴァルグレイドの 魂", ["……石板の 王と 呼ばれた 者だ。千年前、わたしは 知りすぎて、影に 宿られた。", "……飲まれきる 前に、わたしは 自ら 錠に なった。王冠の 下の 錠に。……それを 斬って 閉じたのが、友の §6アルディス§f だ"]);
        await U.say(p, "ヴァルグレイドの 魂", ["{sad,up}人々は 彼の 名を 壁画から 削った。王殺しの 裏切り者と して。……アルディス。すまなかった"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……『名を 呼ぶ 声には 宿れぬ』か。……ほらな。書くより、呼ぶ ほうが 届く。"], "hold");
        await U.E(p, mu, ["……書き記せ、とも 王は 言う"]);
        await U.say(p, "ヴァルグレイドの 魂", ["{up}大切な 者が 名を 呼び、書き記せば、影は 魂を つかめなく なる。……覚えて おけ。最後に 要る"]);
        await U.M(p, mu, ["{closed}そっちは お前と、手帳の 持ち主の 仕事だ。"]);
        U.flag(p, "valgreid");
        if (ok(vg)) { act(vg, "up"); await fade(vg, "minecraft:endrod"); }
        await U.narr(p, ["§7王の 魂は、光に なって 空へ のぼった。§8……千年ぶりに、空の 色を 見に 行った ようだった。"]);
        await U.end(p, C, { card: "§7→ そのころ、遠くで" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u14e7", t: "器の 石板", free: false, F: ["F61"],
    syn: "（場面が とぶ）アルカトラス城の 封印庫。衛兵の 子トトが 見張る 中、虚神ゲゼラの 器の 石板が 一度だけ 光った。王の 捨てた 怒りが、中身の ない 器の 中で 何かを 待って いる。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        K.flash(p, false); await K.wait(8);
        K.card(p, "§7― そのころ、アルカトラス城の 封印庫 ―", 80);
        await K.open(p, "アルカトラス城の 封印庫", "night");
        const v = K.fac(p, "u14vault", "u14vault", 0, U.y0(p)), sl = facMark("u14vault", "slab", p.location) || v;
        const tt = C.npc("§eトト", PJ("taro", 8), 3.6, -1.2, 0, "walk"); act(tt, "guard"); hold(tt, "spear");
        if (ok(tt)) await K.up(p, tt, 12);
        await U.narr(p, ["§7衛兵の 子 トトが、小さな 槍を 抱えて 封印庫の 番を して いた。"], tt);
        /*F61 強: 器の 石板が 一度だけ 光る */
        if (sl) { await K.push(p, sl, 22, 3, 1.4, 0.6); fx(p.dimension, "minecraft:portal_reverse_particle", sl, 14, 0.8); K.sound(p, "beacon.power", 0.5); K.flash(p); }
        await U.narr(p, ["§5……器の 石板が、一度だけ 静かに 光った。", "§8王の 捨てた 怒りが、中身の ない 器の 中で、何かを 待って いる。"]);
        await U.say(p, "トト", ["{shock,!,jump}……い、今 光った！ ……見てた！ ちゃんと 見てたぞ！"]);
        await U.say(p, "トト", ["{angry,汗}……ぼくが 番だ。父ちゃんの 代わりに、ぼくが 番なんだ。"]);
        U.flag(p, "gezGlow");
        await U.end(p, C, { card: "§7→ 常世。街の 真ん中の §e記録塔の 下§7 へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u14e8", t: "紫の インク", free: false, ans: ["qu101", "qu121", "qb202"],
    syn: "記録塔の 下で、鎖に つながれた セオが、紫の インクで 名前を 書き続けて いた。手は 止まらない。「僕は、ここに いる 資格なんて ない」。紫の 字を 書いて いたのは、神に 書かされて いる セオだった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        { const q = TOWER(); if (q && U.inR(p) && Math.hypot(q.x - p.location.x, q.z - p.location.z) > 24) await K.moveTo(p, q, "記録塔の 下"); }
        await K.open(p, "常世 ― 記録塔の 下", "ash");
        const c = K.fac(p, "u14chain", "u14chain", 99, U.y0(p)), dk = facMark("u14chain", "desk", p.location) || c;
        if (c) await K.at(p, facMark("u14chain", "chain", p.location) || c, 16, 6, 1);
        const th = C.npc("§aセオ", 18, 4.4, 0.4, 0, "veil"); act(th, "work"); hold(th, "brush");
        if (ok(th)) { await K.push(p, th, 22, 3, 1.4, 1.2); fx(p.dimension, "minecraft:portal_reverse_particle", th.location, 8, 0.5); }
        await U.narr(p, ["§7鎖に つながれた 男が、書見台に 向かって いた。§f……セオだ。", "§8左手の 中指が、紫の インクで 黒く 染まって いる。手は 止まらない。名前を、名前を、名前を。"], th);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        await U.H(p, V(["{shock,…,up}……セオさん。……わたしの 名前、あの 手が 書いてたんだ"], ["{shock,…,up}……セオさん。……わたしの 名前、あの 手が 書いて いたのね"], ["{shock,…,up}……セオ。……わたしの 名前を 書いてたのは、あの 手"], ["{shock,…,up}……セオさん。……わたしの 名前は、あの 手が 書いて いたのですね"]), th);
        await U.say(p, "セオ", ["{closed,…}……来て、しまったのか。", "{cry,tears,up}……書かされて いるんじゃ ない。僕が 覚えて いる 名前を、影が 僕の 手で 書いて いく。……一つも 忘れられない から"], so);
        await U.say(p, "セオ", ["{sad,low}僕は、ここに いる 資格なんて ない。……君の 大事な 人を、この 手で"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{angry,…}……書けるのに、呼べねえ 奴って、お前か。"], "guard");
        await U.end(p, C, { card: "§7→ 名前を、呼ぶ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u14e9", t: "三度 呼ぶ", free: false, F: ["F20"],
    syn: "主人公と、幼なじみの 魂と、ムサシが セオの 名を 呼んだ。手が 止まった。「……待つよ。塔の 上で」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 記録塔の 下", "ash");
        K.fac(p, "u14chain", "u14chain", 99, U.y0(p));
        const th = C.npc("§aセオ", 18, 4.4, 0.4, 0, "veil"); act(th, "work"); hold(th, "brush");
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, th, 10);
        const y = K.ch(p, "c08") === "y";
        if (y) {
          /* C08 y: セオは 声を 知らない。番人と 戦って から 三度 */
          await U.narr(p, ["§7名を 呼んだ。§8……手は、止まらなかった。", "§7書きつけた 名前の 影が 起き上がり、塔の 番人の 形に なった。"], th);
          const g = C.mon(K.wildSp("nether", "L"), 6, -1.5, 0, "smoke"); if (ok(g)) try { g.nameTag = "§8記録塔の 番人"; g.addTag("mrpg_spkm"); g.setDynamicProperty("mrpg:spk", "記録塔の 番人"); } catch {}
          const r = await K.battle(p, K.bossOne(["nether", "golem"], 92, 50, 2), { name: "記録塔の 番人", arena: "記録塔の 下", theme: "hell", hpk: 3, speaker: "記録塔の 番人", lines: { half: "……ナマエ……カケ……", low: "……ヨバレ……タ……" } });
          if (r !== "win") { await U.say(p, "ムサシ", ["{sweat,汗}……下がるぞ。また 来る", K.RT(p)]); return false; }
          if (ok(g)) await fade(g, "minecraft:soul_particle");
        }
        /*F20 強: 名を 呼ばれて 手が 止まる */
        const nm = U.nm(p);
        await U.narr(p, [`§f……セオの 名前を、呼んだ。`], th);
        await U.H(p, V(["{angry,!,up}セオさん！"], ["{angry,!,up}セオさん！"], ["{angry,!,up}セオ！"], ["{angry,!,up}セオさん！"]), th);
        await U.M(p, mu, ["{rage,怒,up}……セオ！"], "raise");
        if (ok(th)) { hold(th, 0); act(th, "up"); await K.up(p, th, 12); }
        await U.narr(p, [y ? "§7三度目で、手が 止まった。" : "§7一度目で、手が 止まった。§8……その 声を、知って いたから。"], th);
        await U.say(p, "セオ", y ? ["{shock,…,up}……そうか。まだ、呼んで くれるのか。", "{closed,tears}……待つよ。塔の 上で"] : ["{shock,…,up}……その 声。灯籠に、僕の 名前を 書いて くれた 声だ。", "{closed,tears}……待つよ。塔の 上で"]);
        U.flag(p, "theoSoul");
        if (ok(th)) await fade(th, "minecraft:basic_smoke_particle");
        await U.narr(p, ["§8鎖は、塔の 上へ 続いて いた。"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……上に 行けば、全部 鳴る。", "{closed}門の 番兵も 残ってる。片づけて、上だ。"], "hold");
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 石門の 番兵を 倒し、§e記録塔§7 の 上へ" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(8, ["u14e1"], ["u14e2"]);
U.ward(9, ["u14e3", "u14e4"], ["u14e5", "u14e6", "u14e7", "u14e8", "u14e9"]);
