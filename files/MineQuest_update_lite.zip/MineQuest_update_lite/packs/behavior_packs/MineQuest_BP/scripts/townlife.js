// 第113版: 町の くらし（掲示板・お祭り・雨・広場の 出し物・店の 呼びこみ・相棒への 反応・頼みごと・落とし物・
// いっしょに 過ごす 50種・町の 事件 5種）。どれも 1秒ごとに 少しずつ（プレイヤーごとに 順番に）動く
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, RANKS } from "./data.js";
import { load, save } from "./store.js";
import { busy, choose, ICON, sound, barNote, ok, giveItem, takeItem, countItem, gold } from "./ui.js";
import { NPC_HOOKS } from "./npchook.js";
import { relOf, setRel, CHATX, rumorLine } from "./chat.js";
import { __walk, BUSYW, claimWalker, standY, rainNow, slotNow, festNow, LIFE, dressCitizen } from "./citylife.js";
import { MQ } from "./saga.js";
import { findPet, setLook, TYPE } from "./field.js";
import { HIT_HOOKS } from "./battle.js";
import { giveGold } from "./explore.js";
import { TOWNS } from "./structures.js";

const OW = () => world.getDimension("overworld");
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const hashS = (t) => { let h = 7; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
const day = () => Math.floor(Date.now() / 86400000);
const nmOf = (e) => { try { return String(e.nameTag || "").replace(/§./g, "").trim() || "町の 人"; } catch { return "町の 人"; } };
const say = (p, who, t) => { try { p.sendMessage(`§e${who}§f「${t}」`); } catch {} };
const msg = (p, t) => { try { p.sendMessage(t); } catch {} };
const bar = (p, t) => { try { barNote(p).setActionBar(t); } catch {} };
const act = (e, a) => { try { if (ok(e)) e.setProperty("mrpg:act", a); } catch {} };
const fx = (e, id, dy = 2.1) => { try { const l = e.location; e.dimension.spawnParticle(id, { x: l.x, y: l.y + dy, z: l.z }); } catch {} };
const fxAt = (l, id) => { try { OW().spawnParticle(id, l); } catch {} };
const faceTo = (e, p) => { try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} };
const heartStr = (a) => (a >= 30 ? "§d♥♥♥" : a >= 12 ? "§d♥♥§7♥" : a >= 4 ? "§d♥§7♥♥" : "§7♥♥♥");
const players = () => world.getAllPlayers().filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
function addAff(p, nm, n) { const R = relOf(p, nm); R.a = Math.max(-20, Math.min(100, (R.a || 0) + n)); setRel(p, nm, R); return R.a; }
/* 1日の 回数（プレイヤーごと）*/
function cap(p, k, max, use = false) { let v = {}; try { v = JSON.parse(p.getDynamicProperty("mrpg:tlc") || "{}"); } catch {} if (v.d !== day()) v = { d: day() }; const n = v[k] || 0; if (n >= max) return false; if (use) { v[k] = n + 1; try { p.setDynamicProperty("mrpg:tlc", JSON.stringify(v)); } catch {} } return true; }
const jget = (p, k) => { try { return JSON.parse(p.getDynamicProperty(k) || "null"); } catch { return null; } };
const jset = (p, k, v) => { try { p.setDynamicProperty(k, v === null ? undefined : JSON.stringify(v)); } catch {} };
export const areaAt = (loc) => { for (const A of __walk.areas()) if (hv(loc, A) < A.r) return A; return null; };
const townName = (A) => (TOWNS.find((t) => t.id === A.id) || {}).name || (A.id.startsWith("c") ? "城下町" : "町");
const plazaOf = (A) => __walk.spotsOf(A).find((q) => q.k === "plaza");
const nodesOf = (A) => { if (A._n) return A._n; const L = []; for (const R of A.w) for (const P of R) L.push({ x: A.x + P[0] + 0.5, y: A.y + P[1], z: A.z + P[2] + 0.5 }); return (A._n = L); };
export const isKid = (nm) => /子ども|少年|少女|坊や|ちびっこ|迷子/.test(nm);
const DIRN = (from, to) => { const a = (Math.atan2(to.x - from.x, -(to.z - from.z)) * 180) / Math.PI; return ["北", "北東", "東", "南東", "南", "南西", "西", "北西"][Math.round(((a + 360) % 360) / 45) % 8]; };

// ---------- 遊んで いる 人の 印（ぬけても 必ず 消す）----------
const HOLD = new Map();   /* NPC id → { e, until } */
export function busyOn(e, sec = 15) { try { if (!ok(e) || e.hasTag("mrpg_busyw")) return false; e.addTag("mrpg_busyw"); BUSYW.add(e.id); claimWalker(e.id); try { e.setProperty("mrpg:mv", false); } catch {} HOLD.set(e.id, { e, until: Date.now() + sec * 1000 }); return true; } catch { return false; } }
export function busyOff(e) { try { HOLD.delete(e.id); BUSYW.delete(e.id); if (ok(e)) { e.removeTag("mrpg_busyw"); e.setProperty("mrpg:act", 0); } } catch {} }

// ---------- 物語の 進みぐあい（会話の うわさ・出来事に 使う）----------
const SC = new Map();
CHATX.story = (p) => {
  const c = SC.get(p.id); if (c && Date.now() - c.t < 10000) return c.v;
  let v = { ch: 0, f: {} };
  try { const d = load(p), s = (d && d.story) || {}, r = (MQ[s.mq ?? 0] || {}).r ?? 0, ch = s.ending || r >= 99 ? 11 : Math.max(0, Math.min(10, r)); v = { ch, f: { ending: !!s.ending, nagiDead: !!s.nagiDead, rouDead: !!s.rouDead, twinsBack: !!s.twinsBack, hakuStone: !!(s.hakuStone || s.ch10b), stoneBack: !!(s.stoneBack || (s.ru && s.ru.st >= 4)), kagetsuDead: !!s.kagetsuDead, shellLost: !!s.shellLost && ch === 6 } }; } catch {}
  SC.set(p.id, { t: Date.now(), v }); if (SC.size > 50) SC.delete(SC.keys().next().value); return v;
};

// ---------- 立ち話（近くに いると 聞こえる）----------
const PAIRS = [["今日の 市場、野菜が 安かったよ", "ほんと？ あとで 行こうかな"], ["昨日 カフェで 新しい ケーキを 食べたの", "えー、ずるい！ 今度 連れてって"], ["うちの 子、また 背が のびたんだ", "早いねえ"], ["最近 夜が 冷えるね", "毛布、もう 一枚 出さなきゃ"], ["港に 大きな 魚が 上がったって", "見に 行こうよ！"], ["協会の 依頼、また 増えてたよ", "冒険者さんは 大変だね"], ["今度の お祭り、何を 着ていく？", "まだ 決めて ないんだ"]];
const PCD = new Map();
LIFE.pair = (a, b) => {
  for (const p of players()) {
    if (hv(p.location, a) > 10 || Date.now() - (PCD.get(p.id) || 0) < 20000) continue;
    PCD.set(p.id, Date.now());
    const [l1, l2] = Math.random() < 0.35 ? [rumorLine(p), pick(["へえ、そうなの？", "こわいねえ", "ほんとに？"])] : pick(PAIRS);
    bar(p, `§7${nmOf(a.e)}「${l1}」 ${nmOf(b.e)}「${l2}」`); break;
  }
};

// ---------- 掲示板（町に 入ったら 1日 1回）----------
const PA = new Map(), BOARD = new Map();
function board(p, A) {
  const k = `${p.id}:${A.id}`; if (BOARD.get(k) === day()) return; BOARD.set(k, day()); if (BOARD.size > 200) BOARD.clear();
  const sl = slotNow(), L = [`§6§l【${townName(A)} 掲示板】`];
  if (festNow(A)) L.push("§e・今日は お祭り！ 広場で 踊りと 屋台が 出ています");
  else L.push({ morning: "§f・朝市は 広場で。朝の うちが いちばん 新鮮", day: "§f・港では 釣り人が 腕を きそって います", noon: "§f・お昼は カフェと 食堂が にぎわいます", evening: "§f・夕方からは 宿の 食堂で 乾杯を", night: "§f・夜は 静かに。花火の 夜も あるかも？" }[sl]);
  if (rainNow()) L.push("§b・雨の 日は 屋根の 下で 雨宿りを");
  L.push(`§7・うわさ: ${rumorLine(p)}`, "§a・町の 人の 頼みごと・落とし物は 話しかけて 聞いてね");
  for (const l of L) msg(p, l);
}

// ---------- 相棒が 通ると 町の 人が 反応 ----------
const PETL = ["わあ、かわいい 子！", "いい 毛なみだね", "おっ、強そうな 相棒だ", "ふふ、こっちを 見てる", "なでても いい？", "仲よしなんだね"];
const PETC = new Map(), PRC = new Map();
function petOf(p) { const c = PETC.get(p.id); if (c && Date.now() - c.t < 10000) return ok(c.e) ? c.e : null; let e = null; try { e = findPet(p); } catch {} PETC.set(p.id, { e, t: Date.now() }); return e; }
function petReact(p) {
  const pet = petOf(p); if (!pet || Date.now() - (PRC.get(p.id) || 0) < 20000) return;
  let pl; try { pl = pet.location; } catch { return; }
  for (const s of __walk.W.values()) {
    if (s.mode !== "walk" || s.home || hv(s, pl) > 4 || Date.now() - (PRC.get(s.e.id) || 0) < 60000) continue;
    PRC.set(p.id, Date.now()); PRC.set(s.e.id, Date.now()); if (PRC.size > 300) PRC.clear();
    s.mode = "talk"; s.wait = 30; s.cyc = [6, 5, 6];
    try { s.e.setProperty("mrpg:mv", false); s.e.setProperty("mrpg:act", 6); s.e.teleport(s.e.location, { facingLocation: { x: pl.x, y: pl.y + 1, z: pl.z } }); } catch {}
    fx(s.e, "minecraft:heart_particle"); bar(p, `§e${nmOf(s.e)}§f「${pick(PETL)}」`); return;
  }
}

// ---------- 店の 呼びこみ ----------
const SHOPL = [[/武器屋/, ["切れ味 ばつぐんの 剣、そろってるよ！", "旅の おともに 一本 どうだい！"]], [/防具屋/, ["丈夫な 鎧で 安心の 旅を！", "盾も 見て いって！"]], [/道具屋/, ["薬草、まとめ買いが お得だよ！", "旅の 道具なら なんでも あるよ"]], [/タマゴ屋/, ["何が 生まれるかは お楽しみ！", "新しい タマゴが 入ったよ！"]], [/宿屋/, ["ふかふかの ベッド、空いてるよ！", "ひと休み していきな！"]], [/モンスター屋/, ["かわいい 子が 待ってるよ！"]], [/釣り/, ["今日は よく 釣れる 日だよ！", "えさ、安くしとくよ！"]]];
const MORNC = ["朝市だよ〜！ 朝いちばんの 品だよ！", "おはよう！ 朝は おまけ つけちゃう！"];
const CALL = new Map();
function shopCall(p) {
  let L = []; try { L = OW().getEntities({ type: "mrpg:npc", tags: ["mrpg_npc"], location: p.location, maxDistance: 10 }); } catch {}
  for (const e of L) {
    let nm; try { if (hv(e.location, p.location) > 10) continue; nm = nmOf(e); } catch { continue; }
    const S = SHOPL.find(([re]) => re.test(nm)); if (!S) continue;
    const k = p.id + e.id; if (Date.now() - (CALL.get(k) || 0) < 150000) continue; CALL.set(k, Date.now()); if (CALL.size > 300) CALL.clear();
    act(e, 5); system.runTimeout(() => act(e, 0), 40);
    bar(p, `§e${nm}§f「${slotNow() === "morning" ? pick(MORNC) : pick(S[1])}」`); return;
  }
}

// ---------- 広場の 出し物（大道芸・追いかけっこ・お祭りの 踊りの 輪）----------
const SCN = new Map(), PERF = new Set();
function plazaScene(A) {
  if (Date.now() - (SCN.get(A.id) || 0) < 40000) return; const P = plazaOf(A); if (!P) return;
  const L = [...__walk.W.values()].filter((s) => s.a === A.id && s.mode === "walk" && !s.lead && !s.home && ok(s.e) && hv(s, P) < 18);
  if (!L.length) return; SCN.set(A.id, Date.now());
  const set = (s, mode, wait, cyc, a0) => { s.mode = mode; s.wait = wait; s.cyc = cyc; s.tg = null; try { s.e.setProperty("mrpg:mv", mode === "play"); s.e.setProperty("mrpg:act", a0); } catch {} };
  const kind = festNow(A) ? "ring" : pick(["perf", "chase", rainNow() ? "perf" : "chase"]);
  if (kind === "ring") { L.slice(0, 4).forEach((s, i) => { set(s, "play", 100, [7, 9, 7, 6], 7); s.orb = { x: P.x, z: P.z, r: 3, a: (i * Math.PI) / 2, v: 0.1 }; }); return; }
  if (kind === "chase" && L.length >= 2 && !rainNow()) { L.slice(0, 2).forEach((s, i) => { set(s, "play", 80, [9, 14], 9); s.orb = { x: P.x, z: P.z, r: 4, a: i * 1.3, v: 0.22 }; }); for (const p of players()) if (hv(p.location, P) < 20) bar(p, "§7広場で 町の 人たちが 追いかけっこを している"); return; }
  const s0 = L[0]; set(s0, "perf", 120, [7, 6, 10, 9], 7); PERF.add(s0.e.id);
  for (const s of L.slice(1, 3)) { set(s, "watch", 100, [6, 6, 9], 6); try { s.e.teleport(s.e.location, { facingLocation: { x: s0.x, y: s0.y + 1.5, z: s0.z } }); } catch {} }
  for (const p of players()) if (hv(p.location, P) < 20) bar(p, `§e大道芸人 ${nmOf(s0.e)}§f「さあさあ、ごらんあれ！」`);
}
function perfTick() {
  for (const id of PERF) {
    const s = __walk.W.get(id); if (!s || s.mode !== "perf") { PERF.delete(id); continue; }
    fx(s.e, "minecraft:villager_happy");
    for (const p of players()) if (hv(p.location, s) < 16) try { p.playSound("note.harp", { pitch: pick([0.8, 1, 1.2, 1.5]), volume: 0.4 }); } catch {}
  }
}

// ---------- 頼みごと（届けもの・探しもの）と 落とし物 ----------
const FETCH = [["minecraft:bread", "パン", 2], ["minecraft:apple", "りんご", 3], ["minecraft:wheat", "小麦", 5], ["minecraft:poppy", "ポピーの 花", 3], ["minecraft:cookie", "クッキー", 4], ["minecraft:egg", "たまご", 3], ["minecraft:string", "糸", 4], ["minecraft:paper", "紙", 3], ["minecraft:cooked_cod", "焼き魚", 1], ["minecraft:sugar_cane", "サトウキビ", 4]];
const SPOTJ = { inn: "宿屋", cafe: "カフェ", diner: "食堂", plaza: "広場の 噴水", harbor: "港" };
const LOSTW = ["ハンカチ", "家の 鍵", "手紙", "髪かざり", "お守り", "手袋", "小銭入れ", "日記帳"];
export const hasReq = (nm) => !isKid(nm) && hashS(nm + day()) % 3 === 0;
function reqCheck(p) {
  const r = jget(p, "mrpg:treq"); if (!r) return;
  if (Date.now() - (r.t || 0) > 15 * 60000) { jset(p, "mrpg:treq", null); msg(p, `§7（${r.nm}さんの 頼みごとは 期限が 切れた）`); return; }
  if (r.k !== "deliv" || hv(p.location, r) > 3 || Math.abs(p.location.y - r.y) > 6) return;
  jset(p, "mrpg:treq", null);
  const d = load(p); const g = d ? giveGold(d, 250) : ""; if (d) save(p, d);
  const a = addAff(p, r.nm, 4); sound(p, "random.levelup", 1.2);
  msg(p, `§a包みを ${SPOTJ[r.sk] || "とどけ先"}に 届けた！ §f${r.nm}さんからの お礼 ${g}  ${heartStr(a)}`);
}
const LOST = new Map();   /* pid → { x,y,z,w,t } */
function lostTick(p, A) {
  const L = LOST.get(p.id);
  if (L) {
    if (Date.now() - L.t > 300000) { LOST.delete(p.id); return; }
    const dd = hv(p.location, L);
    if (dd < 20) fxAt({ x: L.x, y: L.y + 0.3, z: L.z }, "minecraft:villager_happy");
    if (dd < 1.8) { LOST.delete(p.id); jset(p, "mrpg:tlost", L.w); sound(p, "random.pop", 1); msg(p, `§e落とし物を 拾った: §f${L.w}§7（町の 人に 話しかけて 届けよう）`); }
    return;
  }
  if (jget(p, "mrpg:tlost") || Math.random() > 1 / 90 || !cap(p, "lost", 3)) return;
  const N = nodesOf(A).filter((q) => { const d = hv(q, p.location); return d > 6 && d < 25; }); if (!N.length) return;
  const q = pick(N); LOST.set(p.id, { x: q.x, y: q.y, z: q.z, w: pick(LOSTW), t: Date.now() });
  bar(p, "§7足もとの 先で 何かが きらりと 光った……");
}
/* 町の 人の メニューに 足す 項目（social.js が 使う）*/
export function extraOpts(p, e) {
  const nm = nmOf(e), O = [], r = jget(p, "mrpg:treq"), lost = jget(p, "mrpg:tlost");
  if (lost) O.push({ t: `落とし物（${lost}）を 届ける`, ic: "i_star", run: () => { jset(p, "mrpg:tlost", null); cap(p, "lost", 3, true); const d = load(p); const g = d ? giveGold(d, 150) : ""; if (d) save(p, d); const a = addAff(p, nm, 3); act(e, 10); fx(e, "minecraft:heart_particle"); say(p, nm, `あっ、それ 探してた 人が いたよ！ 渡して おくね。ありがとう`); msg(p, `§a${g}  ${heartStr(a)}`); system.runTimeout(() => act(e, 0), 40); } });
  if (r && r.k === "fetch" && r.nm === nm) O.push({ t: `頼まれた ${r.name}を わたす（${countItem(p, r.it)}/${r.n}）`, ic: "i_bag", run: () => {
    if (countItem(p, r.it) < r.n) { say(p, nm, `${r.name}、${r.n}こ お願いね。急がなくて いいよ`); return; }
    takeItem(p, r.it, r.n); jset(p, "mrpg:treq", null); const d = load(p); const g = d ? giveGold(d, 200 + 50 * r.n) : ""; if (d) save(p, d);
    const a = addAff(p, nm, 5); act(e, 9); fx(e, "minecraft:heart_particle"); sound(p, "random.levelup", 1.2); say(p, nm, "助かったよ！ これ、お礼ね"); msg(p, `§a頼みごと 完了！ ${g}  ${heartStr(a)}`); system.runTimeout(() => act(e, 0), 40);
  } });
  else if (!r && hasReq(nm) && cap(p, "req", 3)) O.push({ t: "§a頼みごとを 聞く", ic: "i_help", run: () => {
    const A = areaAt(e.location) || areaAt(p.location); cap(p, "req", 3, true);
    const S = A ? __walk.spotsOf(A).filter((q) => hv(q, e.location) > 12) : [];
    if (S.length && Math.random() < 0.5) { const q = pick(S); jset(p, "mrpg:treq", { k: "deliv", nm, sk: q.k, x: q.x, y: q.y, z: q.z, t: Date.now() }); say(p, nm, `この 包みを ${SPOTJ[q.k]}まで 届けて くれない？ ${A ? DIRN(e.location, q) + "の ほうだよ" : ""}`); msg(p, `§a頼みごと: §f${SPOTJ[q.k]}へ 包みを 届ける §7（着けば 完了・15分）`); }
    else { const [it, name, n] = pick(FETCH); jset(p, "mrpg:treq", { k: "fetch", nm, it, name, n, t: Date.now() }); say(p, nm, `${name}を ${n}こ 持ってきて くれないかな。困ってるんだ`); msg(p, `§a頼みごと: §f${name} ×${n} を ${nm}さんに §7（手に 入ったら 話しかけて わたす・15分）`); }
    act(e, 10); system.runTimeout(() => act(e, 0), 40);
  } });
  return O;
}

// ---------- いっしょに 過ごす（50種）----------
/* a=必要な 仲よし、w=時間（morning/day/noon/evening/night）、rain/fest/pet/adult、act=しぐさの 順、fx=粒、s=音、l=せりふ、g=おこづかい、it=もらえる 物、ex=特別な 動き */
const H = "minecraft:heart_particle", V = "minecraft:villager_happy", T = "minecraft:totem_particle", N = "minecraft:endrod", C = "minecraft:critical_hit_emitter";
export const INTER = [
  { id: "photo", n: "写真を とる", act: [5, 10], fx: V, s: "random.click", l: ["はい、ポーズ！", "……パシャッ！ いい 写真が とれたね"], ex: "photo" },
  { id: "meal", n: "カフェで いっしょに 食べる", a: 4, act: [2, 3, 2], fx: V, s: "random.eat", l: ["ここの パン、焼きたてなんだ", "ん〜、おいしい！ いっしょに 食べると いいね"] },
  { id: "train", n: "いっしょに 特訓する", act: [9, 14, 9], fx: C, s: "random.orb", l: ["よし、まずは 走りこみから！", "はあ、はあ……いい 汗 かいたね！"] },
  { id: "fortune", n: "占って もらう", act: [11, 4], fx: "minecraft:portal_reverse_particle", s: "random.orb", l: ["（じっと 手のひらを 見つめる）……"], ex: "fortune" },
  { id: "rps", n: "じゃんけん", act: [9, 6], fx: V, s: "random.pop", l: [], ex: "rps" },
  { id: "road", n: "道を たずねる", act: [5, 4], fx: V, s: "random.pop", l: [], ex: "road" },
  { id: "pcomp", n: "相棒を ほめて もらう", pet: 1, act: [6, 9], fx: H, s: "random.orb", l: ["いい 目を してるね、この 子", "{p}さんが 大事に してるのが わかるよ"], pfx: 1 },
  { id: "ppat", n: "相棒を なでて もらう", pet: 1, a: 4, act: [4, 6], fx: H, s: "random.orb", l: ["よしよし……ふわふわだね", "ふふ、気持ちよさそう"], pfx: 1 },
  { id: "pgift", n: "相棒から 贈り物を わたす", pet: 1, a: 4, act: [10, 9], fx: H, s: "random.levelup", l: ["え、この 子から？ ……わあ、きれいな 石！", "ありがとう。宝物に するね"], pfx: 1 },
  { id: "hide", n: "かくれんぼ", act: [9], fx: V, s: "random.pop", l: [], ex: "hide" },
  { id: "story", n: "本を 読んで もらう", act: [11, 11, 4], fx: V, s: "random.orb", l: ["むかし むかし、空に 浮かぶ 島が あったんだって", "島には 歌う モンスターが いて……", "……おしまい。続きは また 今度ね"] },
  { id: "shop", n: "店の 手伝いを する", act: [4, 5, 10], fx: V, s: "random.orb", l: ["助かる！ この 箱を 運んで くれる？", "いらっしゃいませ〜！", "おかげで 早く 終わったよ。これ、お駄賃"], g: 120 },
  { id: "fish", n: "釣り勝負", act: [1, 1, 9], fx: "minecraft:water_splash_particle", s: "random.splash", l: [], ex: "fish" },
  { id: "cook", n: "いっしょに 料理する", a: 4, act: [4, 2, 9], fx: "minecraft:campfire_smoke_particle", s: "random.fizz", l: ["まずは 小麦を こねて……", "焼けた！ いい におい！", "はい、半分 どうぞ"], it: ["minecraft:bread", 1] },
  { id: "dance", n: "いっしょに 踊る", a: 4, act: [7, 7, 9], fx: V, s: "note.harp", l: ["ステップは こう！ ワン、ツー！", "あはは、上手 上手！"] },
  { id: "star", n: "星を ながめる", w: ["night"], a: 4, act: [1, 1, 4], fx: N, s: "random.orb", l: ["見て、あの 星 すごく 明るい", "星座の 名前、ひとつ 教えて あげる", "……きれいだね"] },
  { id: "five", n: "ハイタッチ", act: [9, 6], fx: C, s: "random.pop", l: ["いえーい！", "ナイス ハイタッチ！"] },
  { id: "sing", n: "歌を 歌う", act: [7, 4], fx: V, s: "note.flute", l: ["ら〜ら〜♪", "ふふ、声が そろったね"] },
  { id: "quiz", n: "なぞなぞ", act: [4, 6], fx: V, s: "random.pop", l: [], ex: "quiz" },
  { id: "face", n: "にらめっこ", act: [14, 6], fx: V, s: "random.pop", l: ["にらめっこしましょ、笑うと 負けよ……", "……ぷっ！ あはは、負けた〜！"] },
  { id: "arm", n: "腕相撲", a: 4, act: [14, 9], fx: C, s: "random.anvil_land", l: ["ぐぐぐ……！", "……まいった！ 力持ちだね"] },
  { id: "shoulder", n: "肩たたき", act: [1, 10], fx: V, s: "random.pop", l: ["あ〜、そこ そこ……", "体が 軽く なったよ。ありがとう"] },
  { id: "plant", n: "花を 植える", act: [4, 6], fx: V, s: "dig.grass", l: ["ここに 植えようか", "春には 咲くかな。楽しみだね"] },
  { id: "tour", n: "町を 案内して もらう", act: [5, 4, 5], fx: V, s: "random.pop", l: [], ex: "tour" },
  { id: "lore", n: "昔話を 聞く", a: 4, act: [11, 4], fx: "minecraft:portal_reverse_particle", s: "random.orb", l: ["昔、十五枚の 石板が あったって 話、知ってる？", "おばあちゃんが よく 話して くれたんだ"] },
  { id: "toast", n: "乾杯する", w: ["evening", "night"], act: [13, 13, 6], fx: V, s: "random.glass", l: ["それじゃ……", "かんぱーい！", "今日も おつかれさま！"] },
  { id: "tea", n: "お茶を いれて もらう", act: [3, 3], fx: "minecraft:campfire_smoke_particle", s: "random.drink", l: ["はい、熱いから 気を つけてね", "ほっと するでしょ？"] },
  { id: "draw", n: "似顔絵を 描いて もらう", a: 4, act: [11, 4, 6], fx: V, s: "random.click", l: ["動かないでね……", "できた！ ……ちょっと 似てない？ ふふ"] },
  { id: "magic", n: "手品を 見せて もらう", act: [5, 10], fx: T, s: "random.orb", l: ["この 手の 中に コインが…… はいっ！", "消えた！ ……どこに いったと 思う？"] },
  { id: "shiri", n: "しりとり", act: [4, 4, 6], fx: V, s: "random.pop", l: ["りんご！", "……ゴリラ、じゃなくて ごはん！ あっ、『ん』だ……", "負けちゃった〜"] },
  { id: "walk", n: "いっしょに 散歩する", act: [14, 5], fx: V, s: "random.pop", l: ["風が 気持ちいいね", "たまには のんびり 歩くのも いいよね"] },
  { id: "stretch", n: "ストレッチ", act: [9, 14], fx: V, s: "random.pop", l: ["いち、に、さん、し……", "うーん、のびる〜！"] },
  { id: "cheer", n: "応援して もらう", act: [9, 9, 6], fx: C, s: "random.levelup", l: ["フレー、フレー、{p}さん！", "次の 戦いも ぜったい 勝てるよ！"] },
  { id: "worry", n: "悩みを 聞いて もらう", a: 4, act: [4, 10], fx: H, s: "random.orb", l: ["うん、うん……", "ひとりで 抱えなくて いいんだよ。いつでも 話して"] },
  { id: "tip", n: "豆知識を 教わる", act: [4, 5], fx: V, s: "random.orb", l: [], ex: "tip" },
  { id: "tongue", n: "早口言葉", act: [4, 6], fx: V, s: "random.pop", l: ["なまむぎ なまごめ なま……なまたまごっ！", "あはは、かんじゃった！"] },
  { id: "letter", n: "手紙を 書く 手伝い", a: 4, act: [11, 10], fx: V, s: "random.click", l: ["遠くの 家族に 出す 手紙なんだ", "字が きれいに 書けた。ありがとう"] },
  { id: "groom", n: "相棒の お手入れ", pet: 1, act: [4, 6], fx: H, s: "random.orb", l: ["ブラシ、かけて あげるね", "ぴかぴかに なった！"], pfx: 1 },
  { id: "pshow", n: "相棒の 技を 見せる", pet: 1, act: [6, 9], fx: C, s: "random.explode", l: ["わっ！ すごい 迫力！", "いい 技だね。いっぱい 練習したんだ"], pfx: 1 },
  { id: "shelter", n: "いっしょに 雨宿り", rain: 1, act: [14, 4], fx: "minecraft:water_splash_particle", s: "random.pop", l: ["急に 降って きたね", "止むまで ここで 話してようか"] },
  { id: "exer", n: "朝の 体操", w: ["morning"], act: [9, 14, 9], fx: V, s: "random.pop", l: ["腕を 大きく 回して〜", "朝の 体操、気持ちいいでしょ"] },
  { id: "sunset", n: "夕日を ながめる", w: ["evening"], a: 12, act: [1, 4], fx: N, s: "random.orb", l: ["空が 赤く 染まってる……", "{p}さんと 見られて よかった"] },
  { id: "hand", n: "手を つなぐ", a: 30, adult: 1, act: [14, 10], fx: H, s: "random.orb", l: ["……え、手？ ……うん", "……あったかいね"] },
  { id: "swap", n: "プレゼント交換", a: 12, act: [10, 9], fx: H, s: "random.levelup", l: ["せーので 交換ね。せーの！", "わあ、ありがとう！ 私からは これ"], it: "swap" },
  { id: "promise", n: "また 会う 約束", a: 20, adult: 1, act: [10, 5], fx: H, s: "random.orb", l: ["……今度の お祭り、いっしょに 行こうね", "約束だよ"] },
  { id: "whistle", n: "口笛を 教わる", act: [4, 6], fx: V, s: "note.flute", l: ["こう、くちびるを すぼめて……", "ほら、鳴った！"] },
  { id: "treasure", n: "宝さがしゲーム", act: [9, 4, 6], fx: T, s: "random.orb", l: ["この 町の どこかに 小さな 宝を 隠したんだ", "……見つけた！ はい、どうぞ"], g: 100 },
  { id: "bento", n: "お弁当を 作って もらう", a: 12, act: [10, 9], fx: H, s: "random.eat", l: ["旅の 途中で 食べてね", "感想、聞かせてね"], it: ["minecraft:cooked_chicken", 1] },
  { id: "secret", n: "ひみつを 教えて もらう", a: 30, act: [4, 10], fx: H, s: "random.orb", l: [], ex: "secret" },
  { id: "stall", n: "屋台で 買い食い", fest: 1, act: [2, 9], fx: T, s: "random.eat", l: ["お祭りの 屋台って、なんで こんなに おいしいんだろ", "次は 金魚すくい……じゃなくて 魚すくい しよう！"], it: ["minecraft:cookie", 2] },
];
const FORT = ["大吉！ 今日は 何を しても うまく いくよ", "中吉。思わぬ 出会いが あるかも", "小吉。落とし物に 注意", "吉。相棒と 長く 歩くと いい 日", "末吉。夕方から 運が 上向くよ", "大吉！ 今日 勝負すると 勝てるかも"];
const QUIZ = [["上は 洪水、下は 大火事。なーんだ？", ["お風呂", "火山", "雨"], 0], ["パンは パンでも 食べられない パンは？", ["フライパン", "あんパン", "食パン"], 0], ["使うと へって、休むと ふえる ものは？", ["体力", "お金", "時間"], 0]];
const TIPS = ["相手の 系統を 見ると、勝負の 半分は 決まるよ", "雨の 日は 水の 技が 強く なるって 言われてる", "宿屋で 休むと 仲間の 元気が もどるよ", "配合で 生まれた 子は 両方の 親に 少しずつ 似るんだ", "朝の 港では よく 魚が 釣れるよ"];
const SWAP = ["minecraft:cookie", "minecraft:apple", "minecraft:poppy", "minecraft:paper"];
const condOk = (p, e, I, A) => {
  const nm = nmOf(e);
  if (I.adult && isKid(nm)) return null;
  if (I.w && !I.w.includes(slotNow())) return "時間が ちがう";
  if (I.rain && !rainNow()) return "雨の 日だけ";
  if (I.fest && !festNow(A)) return "お祭りの 日だけ";
  if (I.pet && !petOf(p)) return "相棒を 出して いる ときだけ";
  if ((relOf(p, nm).a || 0) < (I.a || 0)) return I.a >= 30 ? "♥♥♥ から" : I.a >= 12 ? "♥♥ から" : "♥ から";
  return "";
};
const EX = {
  photo: (p) => { try { p.onScreenDisplay.setTitle("§f§lパシャッ！", { fadeInDuration: 0, stayDuration: 10, fadeOutDuration: 10 }); } catch {} return null; },
  fortune: () => ({ l: ["（じっと 手のひらを 見つめる）……", pick(FORT)] }),
  rps: async (p) => { const H3 = ["グー", "チョキ", "パー"], c = await choose(p, "じゃんけん", "§fじゃんけん……", H3.map((x) => [x, ICON("i_help")])); if (c === undefined || c === null || c < 0 || c > 2) return false; const n = Math.floor(Math.random() * 3), r = (c - n + 3) % 3; return { l: [`じゃんけん ぽん！ （${H3[n]}）`, r === 0 ? "あいこ！ 気が 合うね" : r === 2 ? "わあ、負けた〜！ 強いね" : "やった、私の 勝ち！"], bonus: r === 2 ? 1 : 0 }; },
  road: (p, e) => { const A = areaAt(e.location); if (!A) return { l: ["ここは 町の 外だね。道なりに 行けば 何か あるよ"] }; const L = __walk.spotsOf(A).filter((q) => q.k !== "plaza").slice(0, 3).map((q) => `${SPOTJ[q.k] || "店"}は ${DIRN(e.location, q)}の ほう`); return { l: [L.length ? L.join("、") + "だよ" : "広場は すぐ そこ。噴水が 目じるしだよ", "迷ったら 広場に もどると いいよ"] }; },
  fish: () => { const a = 10 + Math.floor(Math.random() * 50), b = 10 + Math.floor(Math.random() * 50); return { l: ["よーし、釣り勝負！ ……えいっ！", `私は ${b}cm！ {p}さんは ${a}cm`, a > b ? "負けた〜！ 次は 負けないよ" : a === b ? "引き分け！" : "ふふ、私の 勝ち！"], bonus: a > b ? 1 : 0 }; },
  quiz: async (p) => { const [q, L, k] = pick(QUIZ), c = await choose(p, "なぞなぞ", `§f${q}`, L.map((x) => [x, ICON("i_help")])); if (c === undefined || c === null || c < 0) return false; return { l: [q, c === k ? `せいかい！ 答えは『${L[k]}』` : `ざんねん！ 答えは『${L[k]}』でした`], bonus: c === k ? 1 : 0 }; },
  tour: (p, e) => { const A = areaAt(e.location); return { l: [`ようこそ、${A ? townName(A) : "この あたり"}へ！`, A && festNow(A) ? "今日は お祭り！ 広場に 行って みて" : "朝は 広場の 市場、お昼は カフェ、夜は 宿の 食堂が にぎやかだよ", "いい 町でしょ？"] }; },
  tip: () => ({ l: ["ひとつ 教えて あげる", pick(TIPS)] }),
  secret: (p, e) => ({ l: ["……ここだけの 話だよ", rumorLine(p, nmOf(e))] }),
  hide: (p, e) => {
    const A = areaAt(e.location); if (!A) return { l: ["ここだと 隠れる 場所が ないなあ"] };
    const Ns = nodesOf(A).filter((q) => { const d = hv(q, e.location); return d > 8 && d < 22; }); if (!Ns.length) return { l: ["いい 隠れ場所が ないや"] };
    const q = pick(Ns); HIDE.set(p.id, { e, x: q.x, y: q.y, z: q.z, t: Date.now(), nm: nmOf(e) }); const h = HOLD.get(e.id); if (h) h.until = Date.now() + 60000;
    system.runTimeout(() => { try { if (ok(e) && HIDE.has(p.id)) e.teleport({ x: q.x, y: q.y, z: q.z }); } catch {} }, 40);
    return { l: ["かくれんぼ？ いいよ！ 10 数えてね……", "§7（足音が 遠ざかって いく）"], keep: 1 };
  },
};
const HIDE = new Map();
const ICAP = 30;
export async function interMenu(p, e) {
  const nm = nmOf(e), A = areaAt(e.location);
  const L = INTER.map((I) => [I, condOk(p, e, I, A)]).filter(([, w]) => w !== null);
  const c = await choose(p, `${nm}と 過ごす`, `§f何を して 過ごす？ §7（同じ 遊びで 仲よしが ふえるのは 1日 1回）`, [...L.map(([I, w]) => [w ? `§8${I.n}（${w}）` : I.n, ICON(I.pet ? "i_party" : "i_star")]), ["§7やめる", ICON("i_back")]]);
  if (c === undefined || c === null || c < 0 || !L[c]) return;
  const [I, w] = L[c]; if (w) { say(p, nm, w === "相棒を 出して いる ときだけ" ? "相棒は どこ？ いっしょの ときに また 来てね" : "それは また 今度ね"); return; }
  await doInter(p, e, I);
}
export async function doInter(p, e, I) {
  const nm = nmOf(e);
  if (!cap(p, "ia", ICAP)) { say(p, nm, "今日は もう たくさん 遊んだね。また 明日！"); return false; }
  if (!busyOn(e, 20)) { say(p, nm, "ごめんね、今 ほかの 人と 遊んでる ところなんだ"); return false; }
  cap(p, "ia", ICAP, true); faceTo(e, p);
  let X = null; try { X = EX[I.ex] ? await EX[I.ex](p, e, I) : null; } catch { X = null; }
  if (X === false) { busyOff(e); return false; }
  const L = (X && X.l) || I.l, pet = I.pfx ? petOf(p) : null;
  L.forEach((t, i) => system.runTimeout(() => {
    if (!ok(e)) return; act(e, I.act[i % I.act.length]); fx(e, I.fx); if (pet && ok(pet)) fx(pet, H, 1.4);
    try { p.playSound(I.s, { volume: 0.6 }); } catch {} say(p, nm, t.replace(/\{p\}/g, p.name));
  }, i * 40));
  if (!(X && X.keep)) system.runTimeout(() => busyOff(e), L.length * 40 + 30);
  /* ごほうび（同じ 人・同じ 遊びは 1日 1回）*/
  const R = relOf(p, nm); if (!R.iz || R.iz.d !== day()) R.iz = { d: day(), l: "" };
  const first = !R.iz.l.split(",").includes(I.id); if (first) { R.iz.l = (R.iz.l ? R.iz.l + "," : "") + I.id; if (R.iz.l.length > 400) R.iz.l = I.id; } setRel(p, nm, R);
  if (first) {
    const a = addAff(p, nm, (I.aff || 2) + ((X && X.bonus) || 0)); let extra = "";
    if (I.g && cap(p, "ig", 5, true)) { const d = load(p); if (d) { extra = " " + giveGold(d, I.g); save(p, d); } }
    if (I.it) { const [id, n] = I.it === "swap" ? [pick(SWAP), 1] : I.it; try { giveItem(p, id, n); extra += " §7（もらった）"; } catch {} }
    system.runTimeout(() => msg(p, `§7（${I.n}: ${heartStr(a)}§7 仲よし アップ${extra}§7）`), L.length * 40 + 10);
  }
  return true;
}
function hideTick() {
  for (const [pid, h] of HIDE) {
    const p = world.getAllPlayers().find((x) => x.id === pid);
    const gone = !p || !ok(h.e), late = Date.now() - h.t > 50000;
    if (gone || late) { HIDE.delete(pid); if (ok(h.e) && p && late) { say(p, h.nm, "ここだよ〜！ 見つけられなかったね"); act(h.e, 6); } system.runTimeout(() => busyOff(h.e), 40); continue; }
    if (Date.now() - h.t < 3000) continue;
    if (hv(p.location, h) < 2.5) { HIDE.delete(pid); act(h.e, 6); fx(h.e, V); sound(p, "random.levelup", 1.3); say(p, h.nm, "見つかっちゃった！ さすがだね"); addAff(p, h.nm, 2); system.runTimeout(() => busyOff(h.e), 40); }
    else bar(p, `§eかくれんぼ §f${h.nm}を さがそう §7（${50 - Math.floor((Date.now() - h.t) / 1000)}秒）`);
  }
}

// ---------- 町の 事件（5種）----------
const EVN = { runaway: "暴れモンスター", thief: "どろぼう", lostpet: "迷子の モンスター", caravan: "行商キャラバン", fire: "花火の 夜" };
const EV = new Map();   /* pid → { k, A, ents:[{e,x,y,z}], t, end, ... } */
const LIVE = () => { const S = new Set(); for (const v of EV.values()) for (const r of v.ents) S.add(r.id); return S; };
const lowMon = () => { const L = ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.special && !S.special4 && !S.metalmon && RANKS.indexOf(S.rank) <= 1 && !["king", "god"].includes(S.fam); }); return L.length ? pick(L) : ORDER[0]; };
function spawnEv(kind, at) {
  let e = null;
  try {
    if (kind === "mon") { const sid = lowMon(); e = OW().spawnEntity(TYPE, at); e.addTag("mrpg_temp"); e.addTag("mrpg_tlev"); setLook(e, sid, null); try { e.triggerEvent("mrpg:make_battle"); } catch {} e.nameTag = `§c${SPECIES[sid]?.name || "モンスター"}`; }
    else { e = OW().spawnEntity("mrpg:npc", at); dressCitizen(e); e.addTag("mrpg_tlev"); }
  } catch { try { e && e.remove(); } catch {} return null; }
  return { e, id: e.id, x: at.x, y: at.y, z: at.z };
}
function evStart(p, A) {
  const P = plazaOf(A); if (!P) return;
  const night = slotNow() === "night", Ns = nodesOf(A).filter((q) => { const d = hv(q, p.location); return d > 8 && d < 30; }); if (!Ns.length) return;
  const k = night && Math.random() < 0.5 ? "fire" : pick(["runaway", "thief", "lostpet", "caravan"]);
  const V0 = { k, A, ents: [], t: Date.now(), end: Date.now() + (k === "caravan" ? 150000 : 70000), P, bought: new Set() };
  if (k === "runaway" || k === "thief" || k === "lostpet") { const q = pick(Ns), r = spawnEv(k === "thief" ? "npc" : "mon", { x: q.x, y: q.y, z: q.z }); if (!r) return; if (k === "thief") try { r.e.nameTag = "§cどろぼう"; } catch {} V0.ents.push(r); }
  if (k === "caravan") for (const dx of [-1.5, 1.5]) { const r = spawnEv("npc", { x: P.x + dx, y: P.y, z: P.z + 3 }); if (r) { try { r.e.nameTag = `§6行商キャラバン ${nmOf(r.e).split(" ").pop()}`; r.e.setProperty("mrpg:act", 5); } catch {} V0.ents.push(r); } }
  EV.set(p.id, V0); cap(p, "ev", 3, true); sound(p, "note.pling", 1);
  msg(p, { runaway: "§c§l町の 事件！ §fモンスターが 町で 暴れて いる！ 近づいて（たたいて）しずめよう §7（70秒）", thief: "§c§l町の 事件！ §fどろぼうが 逃げて いる！ 追いかけて つかまえよう §7（70秒）", lostpet: "§e§l町の 事件！ §f迷子の モンスターが いる。見つけて 広場の 噴水まで 連れて いこう §7（70秒）", caravan: "§6§l行商キャラバンが 来た！ §f広場で 珍しい 品を 安く 売って いる §7（しばらくの 間）", fire: "§d§l花火の 夜！ §f広場で 花火が 上がって いる。見に 行こう §7（70秒）" }[k]);
}
function evEnd(pid, good, p) {
  const V0 = EV.get(pid); if (!V0) return; EV.delete(pid);
  for (const r of V0.ents) { try { if (ok(r.e)) { r.e.dimension.spawnParticle("minecraft:villager_happy", r.e.location); r.e.remove(); } } catch {} }
  if (!p) return;
  if (good) { const d = load(p); const g = d ? giveGold(d, V0.k === "fire" ? 200 : 400) : ""; if (d) save(p, d); sound(p, "random.levelup", 1); msg(p, `§a${EVN[V0.k]}: 解決！ §f町の 人から お礼 ${g}`); }
  else if (V0.k !== "caravan") msg(p, `§7${EVN[V0.k]}は おさまった……`);
  else msg(p, "§7行商キャラバンは 次の 町へ 旅立って いった");
}
function evMove(V0, p) {
  const l = p.location;
  for (const r of V0.ents) {
    if (!ok(r.e)) continue; const d = hv(r, l);
    if (V0.k === "lostpet") {
      if (!V0.follow) { if (d < 2.5) { V0.follow = 1; msg(p, "§eモンスターが ついて きた！ §f広場の 噴水へ 連れて いこう"); } continue; }
      if (d > 2) { const k = Math.min(1, 0.5 / d), nx = r.x + (l.x - r.x) * k, nz = r.z + (l.z - r.z) * k, ny = standY(nx, nz, r.y); r.x = nx; r.z = nz; r.y = ny === null || ny === undefined ? l.y : ny; try { r.e.teleport({ x: r.x, y: r.y, z: r.z }, { facingLocation: { x: l.x, y: l.y + 1, z: l.z } }); } catch {} }
      continue;
    }
    if (V0.k === "caravan") continue;
    if (d < 1.8) { V0.caught = 1; continue; }
    if (d < 10) {
      const sp = V0.k === "thief" ? 0.55 : 0.45, ax = (r.x - l.x) / (d || 1), az = (r.z - l.z) / (d || 1);
      for (const [cx, cz] of [[ax, az], [ax - az * 0.8, az + ax * 0.8], [ax + az * 0.8, az - ax * 0.8], [-az, ax], [az, -ax]]) {
        const n = Math.hypot(cx, cz) || 1, nx = r.x + (cx / n) * sp, nz = r.z + (cz / n) * sp, ny = standY(nx, nz, r.y);
        if (ny === null || hv({ x: nx, z: nz }, V0.A) > V0.A.r - 4) continue; r.x = nx; r.z = nz; if (ny !== undefined) r.y = ny; break;
      }
      try { r.e.teleport({ x: r.x, y: r.y, z: r.z }, { facingLocation: { x: 2 * r.x - l.x, y: r.y + 1.5, z: 2 * r.z - l.z } }); } catch {}
      try { r.e.setProperty("mrpg:mv", true); } catch {}
    }
  }
}
function evTick(fast) {
  for (const [pid, V0] of EV) {
    const p = world.getAllPlayers().find((x) => x.id === pid);
    if (!p || Date.now() > V0.end || hv(p.location, V0.A) > V0.A.r + 30) { evEnd(pid, !!(p && V0.good && Date.now() > V0.end), p); continue; }
    if (V0.ents.length && V0.ents.every((r) => !ok(r.e))) { evEnd(pid, false, p); continue; }
    evMove(V0, p);
    if (V0.caught) { evEnd(pid, true, p); continue; }
    if (V0.k === "lostpet" && V0.follow && V0.ents[0] && hv(V0.ents[0], V0.P) < 3.5) { evEnd(pid, true, p); continue; }
    if (fast) continue;
    const left = Math.ceil((V0.end - Date.now()) / 1000);
    if (V0.k === "fire") {
      if (hv(p.location, V0.P) < 30) { fxAt({ x: V0.P.x + Math.random() * 8 - 4, y: V0.P.y + 10 + Math.random() * 6, z: V0.P.z + Math.random() * 8 - 4 }, pick([T, N, "minecraft:critical_hit_emitter"])); try { p.playSound(pick(["firework.blast", "firework.twinkle", "firework.launch"]), { volume: 0.6 }); } catch {} }
      if (hv(p.location, V0.P) < 8 && !V0.seen) { V0.seen = 1; V0.end = Date.now() + 8000; V0.good = 1; msg(p, "§d夜空に 大きな 花火が 咲いた……！"); }
    }
    if (V0.k !== "caravan" && V0.k !== "fire") { const r = V0.ents[0]; if (r) bar(p, `§e${EVN[V0.k]} §f${Math.round(hv(p.location, V0.k === "lostpet" && V0.follow ? V0.P : r))}m §7（${left}秒）`); }
  }
}
/* たたいて しずめる・話しかけて 買う */
HIT_HOOKS.push((p, e) => {
  try { if (!e.hasTag("mrpg_tlev")) return false; } catch { return false; }
  for (const V0 of EV.values()) if (V0.ents.some((r) => r.id === e.id)) { if (V0.k === "runaway") V0.caught = 1; else if (V0.k === "lostpet" && !V0.follow) { V0.follow = 1; msg(p, "§eモンスターが ついて きた！"); } }
  return true;
});
const SALE = [["minecraft:cake", 1, 300, "ケーキ"], ["minecraft:golden_apple", 1, 600, "金の りんご"], ["minecraft:emerald", 2, 500, "エメラルド"], ["minecraft:honey_bottle", 2, 200, "はちみつ"], ["minecraft:glow_berries", 4, 150, "光る 木の実"]];
NPC_HOOKS.unshift((p, e) => {
  try { if (!e.hasTag("mrpg_tlev")) return false; } catch { return false; }
  let V0 = null; for (const v of EV.values()) if (v.ents.some((r) => r.id === e.id)) V0 = v;
  if (!V0) return true;
  if (V0.k === "thief") { V0.caught = 1; return true; }
  if (V0.k !== "caravan") return true;
  if (V0.bought.has(p.id) || busy.has(p.id)) { say(p, nmOf(e), "まいど！ また どこかの 町で 会おう"); return true; }
  busy.add(p.id);
  (async () => {
    try {
      const L = SALE.slice().sort(() => Math.random() - 0.5).slice(0, 3), d0 = load(p);
      const c = await choose(p, "行商キャラバン", `§fどれも 半額だよ！（1人 1つまで）\n§7お金: ${gold(d0?.gold || 0)}`, [...L.map(([, n, g, nm]) => [`${nm} ×${n}  ${g} タヨ`, ICON("i_bag")]), ["§7やめる", ICON("i_back")]]);
      if (c === undefined || c === null || c < 0 || !L[c] || V0.bought.has(p.id)) return;
      const d = load(p); if (!d || (d.gold || 0) < L[c][2]) { say(p, nmOf(e), "お金が 足りないみたいだね"); return; }
      d.gold -= L[c][2]; save(p, d); giveItem(p, L[c][0], L[c][1]); V0.bought.add(p.id); sound(p, "random.orb", 1);
      say(p, nmOf(e), "まいど あり！ いい 旅を");
    } catch {} finally { busy.delete(p.id); }
  })();
  return true;
});
/* 残った 事件の 人・モンスターを 片づける（読みこみ直し・ぬけた とき）*/
function sweep() {
  const live = LIVE();
  try { for (const e of OW().getEntities({ tags: ["mrpg_tlev"] })) if (!live.has(e.id)) try { e.remove(); } catch {} } catch {}
  for (const [id, h] of HOLD) if (Date.now() > h.until || !ok(h.e)) busyOff(h.e);
}

// ---------- 見はり ----------
let TT = 0, RAINP = new Map();
/* 第117版: 物語の 場面の 前後（1分半）と、第1章の 旅立ちが 終わる まで は 町の 事件を 起こさない */
const QB = new Map();
export function storyQuiet(p) { try { if (busy.has(p.id)) QB.set(p.id, Date.now()); if (Date.now() - (QB.get(p.id) || 0) < 90000) return true; const d = load(p); return !d || !d.story || !d.story.ch1b; } catch { return true; } }
system.runInterval(() => {
  TT++;
  if (TT % 30 === 1) sweep();
  for (const [id, h] of HOLD) if (Date.now() > h.until) busyOff(h.e);
  perfTick(); hideTick(); evTick(false);
  for (const p of players()) {
    let A = null; try { A = areaAt(p.location); } catch {}
    const was = PA.get(p.id); PA.set(p.id, A ? A.id : null);
    try { reqCheck(p); } catch {}
    if (!A) continue;
    if (was !== A.id) board(p, A);
    const ph = (TT + hashS(p.id)) % 6;
    try {
      lostTick(p, A);
      if (ph === 0) petReact(p);
      if (ph === 2) shopCall(p);
      if (ph === 4) plazaScene(A);
      if (festNow(A) && TT % 2 === 0) { const P = plazaOf(A); if (P && hv(p.location, P) < 24) { try { p.playSound(pick(["note.harp", "note.bell", "note.flute"]), { pitch: pick([0.8, 1, 1.2, 1.5]), volume: 0.4 }); } catch {} fxAt({ x: P.x + Math.random() * 6 - 3, y: P.y + 2.5, z: P.z + Math.random() * 6 - 3 }, V); } }
      const r = rainNow(); if (r && !RAINP.get(p.id)) { const s = [...__walk.W.values()].find((q) => q.a === A.id && hv(q, p.location) < 14); if (s) bar(p, `§e${nmOf(s.e)}§f「${pick(["わっ、降って きた！ 屋根の 下へ 急げ〜", "雨だ！ 洗濯物 しまわなきゃ", "傘、持って くれば よかった〜"])}」`); } RAINP.set(p.id, r);
      if (ph === 1 && TT % 20 < 6 && !EV.has(p.id) && !busy.has(p.id) && !HIDE.has(p.id) && !storyQuiet(p) && Math.random() < 0.06 && cap(p, "ev", 3)) evStart(p, A);
    } catch {}
  }
  if (PA.size > 50) PA.clear(); if (RAINP.size > 50) RAINP.clear();
}, 20);
system.runInterval(() => { if (EV.size) evTick(true); }, 4);
system.runTimeout(() => sweep(), 100);
export const __life = { INTER, EV, HIDE, HOLD, LOST, SC, SCN, evStart, evEnd, evTick, sweep, doInter, board, extraOpts, plazaScene, cap };
