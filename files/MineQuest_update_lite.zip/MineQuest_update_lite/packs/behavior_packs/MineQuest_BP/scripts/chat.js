// 第106版: NPCと 自由に 話す。話しかけると 入力欄が 出て、打った 言葉に 人物ごとの 性格で 返事する（まじめ と シュール が まざる）
import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { modal, show, ok, busy } from "./ui.js";

const pick = (L) => L[Math.floor(Math.random() * L.length)];
const clip = (s, n) => { const a = Array.from(s); return a.length > n ? a.slice(0, n).join("") + "…" : s; };

/* 第109版: 会話を 作りなおした。でたらめな 返事（シュール）は やめ、人ごとの 性格・覚えて いる こと・仲よしの 度合いで 筋の 通った 返事を する。
   返事の あとに 聞き返す ことが あり、次に 打った 言葉は その 答えとして 受けとる */
const TOPIC = [
  ["bye", /さよう?なら|またね|じゃあね|バイバイ|ばいばい|おやすみ|失礼します|帰る|かえる$|行くね|いくね/],
  ["greet", /^(こんにち[はわ]|こんばん[はわ]|おはよう|やあ|よう|ども|どうも|はじめまして|はろー|ハロー|ヤッホー|やっほー|おっす|オッス|おーい)/],
  ["date", /デート|遊ぼ|あそぼ|一緒に|いっしょに|出かけ|散歩しよ|お茶しよ|ご飯行/],
  ["love", /好き|すき|愛し|大好き|結婚|けっこん|付き合|つきあ|惚れ/],
  ["praise", /かわいい|可愛い|カワイイ|かっこいい|格好いい|美人|きれい|綺麗|すてき|素敵|優しい|やさしい|イケメン|似合/],
  ["insult", /バカ|ばか|馬鹿|アホ|あほ|うざ|ウザ|きも|キモ|しね|死ね|ブス|ぶす|くず|クズ|雑魚|ざこ|ザコ|嫌い|きらい/],
  ["thanks", /ありがと|サンキュ|感謝|助かっ/],
  ["sorry", /ごめん|すみません|すまん|申し訳|悪かった/],
  ["name", /名前|なまえ|誰|だれ|何者|なにもの/],
  ["job", /仕事|しごと|何して|なにして|職業|働/],
  ["age", /何歳|なんさい|年齢|ねんれい|いくつ/],
  ["family", /家族|かぞく|兄弟|姉妹|子ども|こども|親|彼氏|彼女|恋人/],
  ["town", /この町|この街|ここ|町の|街の|おすすめ|名物|観光|見どころ/],
  ["shop", /カフェ|食堂|レストラン|酒場|宿|店|みせ|買い物|ギルド|協会|闘技場|図書館/],
  ["weather", /天気|てんき|晴れ|はれ|雨|あめ|雪|ゆき|くもり|曇|暑い|あつい|寒い|さむい|風/],
  ["food", /腹|はら|お腹|おなか|食べ|たべ|ご飯|ごはん|飯|めし|うまい|美味|おいし|料理|肉|魚|パン|ケーキ|お茶|コーヒー/],
  ["monster", /モンスター|仲間|なかま|たまご|卵|進化|しんか|配合|はいごう|相棒|あいぼう/],
  ["strong", /強い|つよい|最強|さいきょう|レベル|勝負|しょうぶ|戦[いえお]|たたかう|バトル/],
  ["money", /金|かね|タヨ|安い|やすい|高い|たかい|値段|ねだん|売|買|貧乏|びんぼう/],
  ["quest", /依頼|いらい|クエスト|手伝|てつだ|助けて|たすけて|困っ|こまっ|頼み/],
  ["lore", /ノクス|魔将|エンマ|石板|せきばん|邪神|王冠|伝説|でんせつ|歴史|むかし|昔|遺跡/],
  ["tired", /疲れ|つかれ|眠|ねむ|だる|しんど|休み|やすみ/],
  ["sad", /悲し|かなし|つら|辛い|寂し|さびし|泣|落ち込|へこ/],
  ["happy", /嬉し|うれし|楽し|たのし|最高|さいこう|やった|わーい/],
  ["hobby", /趣味|しゅみ|好きな|すきな|休日|暇|ひま/],
  ["joke", /ギャグ|ネタ|面白い|おもしろい|笑わせ|ボケ/],
  ["laugh", /笑|わら|ww|ｗｗ|草$/i],
  ["yes", /^(はい|うん|そう|そうだね|そうです|ええ|おう|もちろん|いいよ|いいね|行く|いく)/],
  ["no", /^(いいえ|いや|ちがう|違う|ううん|ノー|やだ|だめ|無理)/],
  ["why", /なぜ|なんで|どうして|何で/],
  ["ask", /[?？]$|ですか$|かな$|の$/],
];
/* 返事。{p}=相手 {me}=自分の 名前 {w}=相手の 言葉 {time}=時間 {job}=仕事 {like}=好きな もの
   q: その 返事の あとに 聞く こと（[聞く 言葉, 答えの 種類]）*/
const LINES = {
  greet: ["{time}。{p}さん、こんにちは", "やあ、{p}さん。{time}", "いらっしゃい。町は もう 見て まわった？", "こんにちは。いい 顔つきの 相棒だね"],
  greet2: ["また 来てくれたんだね、{p}さん", "{p}さん！ ちょうど 話したいと 思ってたんだ", "おかえり、{p}さん。{time}"],
  name: ["私は {me}。この 町で {job}を してるんだ", "{me}だよ。{p}さんの ことは 噂で 聞いてる", "名前？ {me}。覚えて くれると うれしいな"],
  job: ["{job}を してる。毎日 同じ ようで、けっこう ちがうんだよ", "{job}だよ。大変だけど、町の 人の 顔が 見られるのが いい", "仕事？ {job}さ。{p}さんは 旅の 人だよね"],
  age: ["年は ないしょ。{p}さんより は 少し 上かな", "数えるのを やめちゃった", "ふふ、何歳に 見える？"],
  family: ["家族は この 町に いるよ。いつか 紹介するね", "家族の 話？ ……照れくさいな", "うちは にぎやかでね。夕飯は いつも 取りあいさ"],
  town: ["この 町の 名物は 広場の 噴水と、カフェの ケーキかな", "見どころなら、夕方の 広場が いちばん 好き。人が 集まって あったかいんだ", "おすすめ？ 食堂の 煮込みは 一度 食べて ほしいな"],
  shop: ["カフェは 午後が 混むよ。テラス席が おすすめ", "食堂の 料理人は 腕が いい。ちょっと 怒りっぽいけどね", "酒場は 夜が にぎやか。冒険者の 噂話も 聞けるよ", "宿屋の 2階は 景色が いいんだ"],
  weather: ["{time}。こういう 日は 遠くまで 歩けそうだ", "天気が いいと、モンスターも 機嫌が いいよね", "{time}。洗濯物が よく 乾きそう"],
  food: ["お腹が すいたなら 食堂へ どうぞ。この 町の 煮込みは 絶品だよ", "{like}が 好きなんだ。{p}さんは 何が 好き？", "カフェの ケーキ、もう 食べた？"],
  monster: ["いい 相棒だね。大事に されてるのが わかる", "モンスターは 一緒に 過ごした 時間で 強く なるって 聞くよ", "配合で 生まれた 子は、両方の 親に 少しずつ 似るんだって"],
  strong: ["強さは レベルだけじゃない。技の 組み合わせだよ", "勝負なら 協会の 依頼で 腕を 試すと いい", "相手の 系統を 見るんだ。それで 半分 決まる"],
  money: ["お金なら 協会の 依頼で かせげるよ", "装備に 使う お金は 惜しまない ほうが いい", "行商人の 値段は 日に よって ちがうんだ"],
  quest: ["困りごとなら 冒険者協会の 掲示板を 見てごらん", "町の 人の 頼みごとは 協会に 集まって いるよ", "手伝って くれるの？ やさしいね"],
  lore: ["……その 話は、あまり 大きな 声で しないほうが いい", "昔の ことは 遺跡の 碑文に 書いて あるらしい", "石板には それぞれ 主が いるって 聞いたことが ある"],
  tired: ["宿屋で 休んで いきなよ", "無理は 禁物だよ。キャンプを 張るのも いい", "カフェで ひと息 つくと いいよ"],
  sad: ["……何か あったの？ 話なら 聞くよ", "つらい ときは ひとりで 抱えないで。相棒も そばに いる", "泣いても いいんだよ。また 歩ければ それで いい"],
  happy: ["いいね、こっちまで うれしく なる", "{p}さんが 楽しそうだと、こっちも 楽しいよ", "いい 日に なったね"],
  hobby: ["{like}が 好きなんだ。休みの 日は いつも それ", "散歩かな。町を 歩くと 毎日 ちがう 発見が ある", "モンスターの 寝顔を 見る ことかな"],
  joke: ["冗談？ ……ふとんが ふっとんだ。ごめん、これしか 知らない", "笑いたいなら 酒場の 夜が いいよ。みんな 陽気だから"],
  laugh: ["ははっ、楽しそうだね", "{p}さんが 笑うと 安心するよ"],
  praise: ["え、ほんと？ ……ありがとう、照れるな", "そう 言って もらえると うれしいよ", "{p}さんも すてきだよ"],
  love: ["え、えっと…… もう 少し 仲よく なってから、ね？", "ありがとう。……でも まだ お互い よく 知らないでしょ？"],
  love2: ["……私も、{p}さんと 話す 時間が 好き", "そんな こと 言われたら、顔が 熱く なっちゃう"],
  date: ["一緒に？ うーん、もう 少し 仲よく なったらね", "今日は 仕事中なんだ。また 誘って"],
  date2: ["いいよ！ カフェに 行かない？ ……今度、ゆっくり ね", "{p}さんと なら よろこんで。……どこに 行こうか"],
  insult: ["……そういう 言い方は、相手も モンスターも 悲しむよ", "言葉は 返って くるよ。気を つけて", "疲れてるの？ 少し 休みなよ"],
  thanks: ["どういたしまして", "礼なんて いらないよ", "また 困ったら 声を かけてね"],
  sorry: ["気に しないで", "わかって くれたなら いいよ", "誰にでも ある ことさ"],
  yes: ["うん、そうだよね", "よかった", "なるほど"],
  no: ["そっか、ちがったか", "ごめん、早とちり した"],
  why: ["理由は……自分でも よく わからないんだ", "いい 質問だね。考えて おくよ"],
  ask: ["うーん、どうだろう。{p}さんは どう 思う？", "たぶん そうだと 思うよ", "それは 自分の 目で 確かめるのが いちばんだね"],
  bye: ["気を つけてね、{p}さん", "また 来てね", "いい 旅を"],
  other: ["へえ、そうなんだ", "なるほどね。もう 少し 聞かせて？", "ふむ……{p}さんらしいね", "そういう 考えも あるのか"],
  again: ["それ、さっきも 聞いたよ。大事な こと？", "ふふ、2回目だね"],
  empty: ["……？ 何か 言いかけた？", "だまって 見つめられると 照れるな"],
};
/* 聞き返す こと: [質問, 答えを 受けた ときの 返事（{w} = 答え）] */
const ASK = [
  ["{p}さんは どこから 来たの？", ["{w}から！ 遠かった でしょう", "{w}か。行った ことは ないけど、いい 所なんだろうね"]],
  ["好きな 食べ物は 何？", ["{w}！ いいね、今度 食堂で 頼んで みよう", "{w}か。{p}さんらしいな"]],
  ["相棒とは どこで 出会ったの？", ["{w}で？ 運命だったんだね", "へえ、{w}……。いい 出会いだ"]],
  ["旅は 楽しい？", ["そう 聞けて うれしいよ", "そっか。無理しないでね"]],
  ["次は どこへ 行くの？", ["{w}か。気を つけて 行ってね", "{w}……いいなあ。おみやげ話を 待ってる"]],
];
const JOBW = { 23: "町の 手伝い", 24: "店の 手伝い", 25: "冒険者", 26: "行商" };
const LIKES = ["ケーキ", "焼き魚", "花の 世話", "本を 読む こと", "昼寝", "星を 見る こと", "釣り", "歌う こと", "料理", "編み物"];
/* 第109版: 町の 人の 性格（名前で 決まる）*/
const TYPES = [
  { k: "やさしい", pre: ["", "ふふ、"], end: ["", ""], pol: 1 },
  { k: "元気", pre: ["あっ、", "ねえねえ、", ""], end: ["！", ""], pol: 0 },
  { k: "ぶっきらぼう", pre: ["……", "ああ、"], end: ["", "。……まあな"], pol: 0 },
  { k: "照れ屋", pre: ["え、えっと、", "あの……"], end: ["……", ""], pol: 1 },
  { k: "おしゃべり", pre: ["聞いて 聞いて、", "そうそう、"], end: ["。あ、それでね……ううん、また 今度！", ""], pol: 0 },
];
const hashS = (t) => { let h = 7; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
/* 人物の 性格: sur=シュールに なる 割合、pre=話し始め、end=口ぐせ（ときどき 足す） */
const PERSONA = {
  default: { sur: 0.4, pre: [""], end: [] },
  町の人: { sur: 0.45, pre: ["", "", "ええと、"], end: [] },
  冒険者: { sur: 0.3, pre: ["", "おう、"], end: ["……ま、がんばれよ"] },
  行商人: { sur: 0.4, pre: ["", "まいど！ "], end: ["……ところで 何か 買っていかない？"] },
  受付: { sur: 0.35, pre: ["", "はい、"], end: ["……協会からは 以上です"] },
  老人: { sur: 0.3, pre: ["ふぉっふぉ、", "うむ、"], end: ["……年寄りの 話は 長いぞ"] },
  子ども: { sur: 0.55, pre: ["ねえねえ、", "あのね、"], end: ["……おにいちゃん？ おねえちゃん？"] },
  海辺: { sur: 0.4, pre: ["ふふ、", "あはは、"], end: ["……海、入っていかない？"] },
  オルド: { sur: 0.25, pre: ["うむ、"], end: ["……それも 書いておこう"] },
  ヴァルカ: { sur: 0.45, pre: ["フン、", "アタシ？ "], end: ["……今のは 62点ね"] },
  マリン: { sur: 0.5, pre: [""], end: ["……潮は 待たない"] },
  ガロ: { sur: 0.6, pre: ["お、おう！ "], end: ["……給料 上がらねえかな"] },
  ミドリ: { sur: 0.35, pre: [""], end: ["……そうだよね、ポチ"] },
  ムサシ: { sur: 0.3, pre: ["ちくしょう、"], end: ["……いい刀 見たくなってきた"] },
  クロウ: { sur: 0.35, pre: [""], end: ["……その話、300タヨ"] },
  カゲツ: { sur: 0.5, pre: ["ふぁ……"], end: ["……眠い"] },
  レイ: { sur: 0.2, pre: ["おっ、", "へへ、", "おー！ "], end: ["……なあ、あとで 勝負しようぜ！", "……マジで 楽しいな！"] },
  セオ: { sur: 0.3, pre: ["あっ、す、すみません、", "ご、ごめんなさい、"], end: ["……あ、紅茶 冷めちゃった", "……すみません、今の メモしても いいですか"] },
  ゼファード: { sur: 0.15, pre: ["（背中を 向けたまま）"], end: ["……神の モンスターは、もっと 静かに 話す"] },
  セイル: { sur: 0.25, pre: [""], end: ["……あと 何人、石のまま……"] },
  セレネ: { sur: 0.2, pre: [""], end: ["……あの人も、そう 言ったかしら"] },
  カグラ: { sur: 0.35, pre: ["（くるりと 回って）"], end: ["……拍手は？"] },
  ナギサ: { sur: 0.4, pre: [""], end: ["……あ、干潮"] },
  ヨミ: { sur: 0.45, pre: ["……", ""], end: ["……今、後ろの 人も うなずいてる"] },
  ジン: { sur: 0.35, pre: [""], end: ["……今ので 十万二千本目"] },
  ゴウ: { sur: 0.3, pre: ["…………………………"], end: [] },
  シデン: { sur: 0.3, pre: ["結論:"], end: ["以上！ 次！"] },
  ソラ: { sur: 0.45, pre: ["（空を 見たまま）"], end: ["……君、誰だっけ"] },
  リリ: { sur: 0.35, pre: ["はい、"], end: ["……協会からは 以上です"] },
  ララ: { sur: 0.35, pre: ["はい、"], end: ["……リリとは 別人です"] },
  ルル: { sur: 0.35, pre: ["はい、"], end: ["……リリとは 別人です"] },
  レレ: { sur: 0.35, pre: ["はい、"], end: ["……リリとは 別人です"] },
  ロロ: { sur: 0.35, pre: ["はい、"], end: ["……リリとは 別人です"] },
  ドン: { sur: 0.5, pre: ["もぐもぐ……"], end: ["……石の パンって 知ってる？"] },
  フィオ: { sur: 0.3, pre: ["♪"], end: ["♪〜（歌で 返事を した）"] },
  ベリル: { sur: 0.45, pre: ["ふっふっふ、"], end: ["……幹部に なったら 覚えてなさいよ！"] },
  アルカ: { sur: 0.4, pre: ["（玉座から 動かずに）"], end: ["……食事も 玉座で とるのが 王の 務めじゃ"] },
  エルゼ: { sur: 0.35, pre: ["下界の 者よ、"], end: [] },
  セバス: { sur: 0.3, pre: [""], end: ["……王は ただいま 外出中です"] },
  ラシード: { sur: 0.2, pre: ["……"], end: ["……あの時は、本当に すまなかった"] },
  ルークス: { sur: 0.45, pre: ["（水晶を 見ながら）"], end: [] },
  マーレ: { sur: 0.5, pre: ["うっぷ……"], end: ["……船の 話は やめてくれ"] },
  モルテ: { sur: 0.5, pre: [""], end: ["……来年の 葬式にも 来てくれるか"] },
  バルド: { sur: 0.3, pre: ["（カン！ カン！）"], end: [] },
  ファーヴ: { sur: 0.3, pre: [""], end: ["……竜には 敬語を 使え"] },
  ピエリナ: { sur: 0.6, pre: ["さあさあ お立ち会い！ "], end: ["……拍手 拍手〜！"] },
  ドロス: { sur: 0.5, pre: ["（枯れた 花を 差し出して）"], end: [] },
  カメリオ: { sur: 0.5, pre: ["……", ""], end: ["……今の 私は、本物かしら？"] },
  グラトン: { sur: 0.5, pre: ["ガハハ！ "], end: ["……その 腕輪、うまそうだな"] },
  クロノ: { sur: 0.4, pre: ["（懐中時計を 見て）"], end: ["……残り 3秒です"] },
  ボルトス: { sur: 0.2, pre: ["ガッハッハ！ "], end: ["……正々堂々、それが 武人よ！"] },
  ヨル: { sur: 0.5, pre: ["みーつけた。"], end: ["……次は きみが 鬼ね"] },
  ユウシャ: { sur: 0.6, pre: ["勇者として 答えよう！ "], end: ["……（職業: 自称）"] },
};
/* しゃべり方が 特別な 人（決まった 返事だけ） */
const ONLY = {
  アルゴ: ["（札に 書いて 見せた）『……』", "（札に 書いて 見せた）『否』", "（札に 書いて 見せた）『静かに』", "（札に 書いて 見せた）『字が 汚くて すまない』"],
  フリージア: ["あたたかい / 言葉を かけても / 雪は 雪", "こんにちは / それだけ 言うのに / 五七五", "君の 声 / 氷の 下の / 魚まで", "わからない / わからないけど / 冬が 来る"],
  エンマ: ["……", "……そうか", "……斬った 数だけ、覚えている", "……負けてから、話す"],
};
const personaOf = (name, role) => {
  for (const k in PERSONA) if (k !== "default" && name.includes(k)) return PERSONA[k];
  return PERSONA[role] || PERSONA.default;
};

function timeWord() {
  let t = 6000; try { t = world.getTimeOfDay(); } catch {}
  return t < 1000 ? "朝だね" : t < 11000 ? "いい 昼だね" : t < 13000 ? "夕焼けが きれいだね" : "夜だね";
}

const MEM = new Map();   // 人id:NPC名 → { last, n, ask }（遊んでいる 間だけ）
/* 仲よし（好感度）: プレイヤーごとに 覚える（60人まで）*/
export function relOf(p, nm) { try { const v = JSON.parse(p.getDynamicProperty("mrpg:rel") || "{}"); return v[nm] || { a: 0, t: 0, n: 0 }; } catch { return { a: 0, t: 0, n: 0 }; } }
export function setRel(p, nm, r) {
  try { const v = JSON.parse(p.getDynamicProperty("mrpg:rel") || "{}"); r.t = Date.now(); v[nm] = r; const ks = Object.keys(v); if (ks.length > 60) { ks.sort((a, b) => (v[a].t || 0) - (v[b].t || 0)); delete v[ks[0]]; } p.setDynamicProperty("mrpg:rel", JSON.stringify(v)); } catch {}
}
const MOOD = { greet: 5, greet2: 5, praise: 9, love: 10, love2: 9, date2: 9, thanks: 10, sad: 12, insult: 12, happy: 9, laugh: 6, bye: 5, joke: 6 };
export function reply(p, npcName, role, text) {
  const t = String(text || "").replace(/§/g, "").trim();
  if (/石像/.test(npcName)) return { line: "……（石像は 何も 答えない）", bye: false, mood: 0 };
  for (const k in ONLY) if (npcName.includes(k)) return { line: pick(ONLY[k]), bye: /さよう?なら|またね|じゃあね|バイ/.test(t), mood: 4 };
  const P = personaOf(npcName, role), T = TYPES[hashS(npcName) % TYPES.length];
  const key = `${p.id}:${npcName}`;
  const m = MEM.get(key) || { last: "", n: 0, ask: null }; MEM.set(key, m);
  if (MEM.size > 200) MEM.delete(MEM.keys().next().value);
  const R = relOf(p, npcName), close = R.a >= 12;
  let topic = "other";
  if (!t) topic = "empty";
  else if (t === m.last) { m.n++; topic = "again"; }
  else { m.n = 1; for (const [k, re] of TOPIC) if (re.test(t)) { topic = k; break; } }
  m.last = t;
  const V = { p: p.name, me: npcName.split(" ").pop(), w: clip(t, 12), time: timeWord(), job: JOBW[role] || (role && role !== "町の人" ? role : JOBW[23]), like: LIKES[hashS(npcName + "l") % LIKES.length] };
  let line;
  /* 聞き返した ことへの 答え */
  if (m.ask && t && !["other", "ask", "yes", "no"].includes(topic)) m.ask = null;   /* 別の 話を 始めたら 聞いた ことは 忘れる */
  if (m.ask && t && ["other", "ask", "yes", "no"].includes(topic)) { const A = ASK[m.ask - 1]; line = pick(A[1]); m.ask = null; topic = topic === "no" ? "no" : "answer"; }
  else {
    const k2 = topic === "greet" && R.n > 0 ? "greet2" : topic === "love" && close ? "love2" : topic === "date" && close ? "date2" : topic;
    line = pick(LINES[k2] || LINES.other);
    if (k2 !== topic) topic = k2;
  }
  line = line.replace(/\{(p|me|w|time|job|like)\}/g, (_, k) => V[k]);   /* 打った 言葉の 中の 記号は そのまま 使わない */
  const pre = pick(P.pre && P !== PERSONA.default ? P.pre : T.pre); if (pre && !line.startsWith("…") && Math.random() < 0.4) line = pre + line;
  if (P.end && P.end.length && P !== PERSONA.default && Math.random() < 0.2) line += pick(P.end); else if (Math.random() < 0.3) { const e = pick(T.end); if (e && !/[！？。…]$/.test(line)) line += e; }
  /* ときどき 聞き返す（会話が 続く）*/
  if (!m.ask && !["bye", "insult", "again", "empty"].includes(topic) && Math.random() < 0.35) { const qi = hashS(npcName + R.n + m.n) % ASK.length; m.ask = qi + 1; line += `　${ASK[qi][0].replace("{p}", p.name)}`; }
  /* 好感度 */
  const dA = { thanks: 2, praise: 2, sorry: 1, insult: -4, love: 1, love2: 1, happy: 1, answer: 1 }[topic] ?? (topic === "again" ? 0 : 0.5);
  const now = Date.now(), dd = Math.floor(now / 86400000); if (R.cd !== dd) { R.cd = dd; R.cg = 0; } let dB = dA; if (dA > 0) { dB = Math.min(dA, Math.max(0, 3 - (R.cg || 0))); R.cg = (R.cg || 0) + dB; } R.a = Math.max(-20, Math.min(100, R.a + dB)); R.n = (R.n || 0) + (now - (R.t || 0) > 600000 ? 1 : 0); R.t = now; setRel(p, npcName, R);
  return { line, bye: topic === "bye", mood: MOOD[topic] || 4, aff: R.a };
}
/* 話す 画面。入力 → 返事 → 続ける／やめる */
export const CHATTING = new Set();
export async function chatWith(p, npc, npcName, role, opener) {
  if (CHATTING.has(p.id) || busy.has(p.id)) return;   /* 第106版: 二重に 開かない・ほかの 画面に 割りこまない */
  CHATTING.add(p.id); busy.add(p.id);
  try { await chatWith0(p, npc, npcName, role, opener); } catch {} finally { CHATTING.delete(p.id); busy.delete(p.id); }
}
async function chatWith0(p, npc, npcName, role, opener) {
  /* 第109版: 返事は チャットに 流れ、相手は 身ぶりで 答える。入力欄を 閉じると 会話おわり */
  const log = []; const first = opener || "何か 用かい？";
  const gest = (a) => { try { if (ok(npc)) { if (a === 0) { const b = npc.getDynamicProperty("mrpg:act0"); if (typeof b === "number") a = b; } npc.setProperty("mrpg:act", a); npc.teleport(npc.location, { facingLocation: p.getHeadLocation() }); } } catch {} };
  try { p.sendMessage(`§e${npcName}§f「${first}」`); } catch {} gest(5); log.push(`§e${npcName}§f「${first}」`);
  try {
    for (let turn = 0; turn < 20; turn++) {
      const R = relOf(p, npcName), heart = R.a >= 30 ? "§d♥♥♥" : R.a >= 12 ? "§d♥♥§7♥" : R.a >= 4 ? "§d♥§7♥♥" : "§7♥♥♥";
      const v = await modal(p, `${npcName}と 話す  ${heart}`, (f) => f.textField(log.slice(-5).join("\n"), "話しかける 言葉を 入力（閉じると おわり）", ""));
      if (!v || !ok(p)) return;
      const said = String(v[0] ?? "").replace(/§/g, "").slice(0, 60);
      const r = reply(p, npcName, role, said);
      if (said) { log.push(`§7あなた「${said}」`); try { p.sendMessage(`§7あなた「${said}」`); } catch {} }
      log.push(`§e${npcName}§f「${r.line}」`); try { p.sendMessage(`§e${npcName}§f「${r.line}」`); } catch {}
      gest(r.mood || 4);
      if (r.bye) return;
    }
  } finally { gest(0); }
}
/* しゃがんで 話しかけると、どの 人とも 自由に 話せる（物語の 人・店・マスター・王 など）*/
import { NPC_HOOKS } from "./npchook.js";
NPC_HOOKS.unshift((p, e) => {
  let sn = false; try { sn = !!p.isSneaking; } catch {}
  if (!sn) return false;
  try { const it = p.getComponent("minecraft:inventory")?.container?.getItem(p.selectedSlotIndex ?? 0); if (it) return false; } catch {}   /* 第106版: 手に 何も 持って いない ときだけ（店や マスターの メニューを じゃましない） */
  const nm = String(e.nameTag || "").replace(/§./g, "").replace(/（[^）]*）/g, "").trim() || "町の 人";
  if (/石像/.test(nm)) { try { p.sendMessage("§7……石像は 何も 答えない。"); } catch {} return true; }
  const role = /受付/.test(nm) ? "受付" : /老|長老|おばば/.test(nm) ? "老人" : /子ども/.test(nm) ? "子ども" : "町の人";
  chatWith(p, e, nm, role, pick(["ん？ 何か 用かい？", "はい、どうしました？", "おや、話し相手かい"]));
  return true;
});
export const __chat = { TOPIC, LINES, PERSONA, MEM };
