// ガイドブックのメニュー
import { RU_GATE, RU_HOOK } from "./ruinsarea.js";
import { sidOf } from "./idx.js";
import { repairFlow } from "./repair.js";
import { world, system } from "@minecraft/server";
import * as SUI from "@minecraft/server-ui";
import { MOVES, SKILLS, SPECIES, ORDER, STARTERS, EL_NAME, FAMILIES, ITEMS, EGGS, CURRENCY, CATS, NATURES, RECIPES, CHANGELOG, VERSION, TRAITS, RECIPES4, FAM_MIX, FAM_MIX3, ROMAN, DEITY, KSP,
  ST_COL, EL_COL, ELS, AILS, AIL_NAME, AIL_KANA, CAT_COL, KINDS, KIND_COL, WTYPES, ATYPES, ACCT, FAM_BONUS_TEXT, TIER_NAME, BOSS_SLAB, COMBO_INFO, SHADY , WKIND, CRAFT_DROP } from "./data.js";
import {
  skMax, MAXLV, migrate, STATS, ST_NAME, expNeed, calcStats, itemHp, itemMp, getMoves, makeMonster, setPoints, resOf, useItemOn, hatch, traitNames, moveDesc,
  TRAIT_MUL, isPal, palFix, fusionCandidates, fusion4Candidates, fusionSkillChoices, skillUpgrades, fuse, makeBook, FUSE_LV, natureText, masteryNeed, mixOf, mixOf2, BAND_NAME, romanOf, mixKey, bandOf,
  PARTY_MAX, PARTY_CAP, SIZE_SLOT, SIZE_NAME, sizeOf, partyUse, canJoin, addMon, SKILL_N, giveHidden, canEquip, equipText, moveLabel, stName, aresOf, tuneMonster,
  fixParty, slotOf, rankIdx, benchUse, canBench, BENCH_MAX, canFight, traitIds, realPower, canEvolveNow, evolve, evolveTo, awakenBlock, rankOfM, learnSkill, lineOf, CAT_TRAIT, GROW_SZ,
  TAL_MAX, talLabel, talTotal, talTotalLabel, comboSkills, skillTraits, fighter, costOf, healAmt, gainExp, fixSp, slotN, TACTICS, TAC_ALIAS } from "./core.js";
import { decodeLore as decodeLoreG, makeStack as makeStackG } from "./gear.js";
import { capRoll, capOf, RAR, RAR_COL, RAR_NAME, RW, rollGear, gearName, gearLines, giveGear, gearSlots, takeSlot, replaceSlot, gearPower, quality, maxStat, minStat, isGear, NPASS, FACT_LO, FACT_HI } from "./gear.js";
import { GOLD_MAX } from "./store.js";
import { load, save, mark, allMons, allMonsDeep, isBroken, clearBroken, forget, wipe, loadShared, saveShared, loadRank, BK_SLOTS, backupInfo, backupSave, backupLoad, backupDelete, isHost, isRealHost } from "./store.js";
import { TOWNS, getTown, townAt, townPos, JOBS, castleInfo } from "./structures.js";
import { WREGIONS } from "./worldmap.js";
import { spawnPet, recallPet, refreshPet, rideInfo, traitList, spawnWildNear, findPet } from "./field.js";
import { startPvp, startSpar, inBattle, coopList, coopJoin, expCapLv } from "./battle.js";
import { toSkyArena, backFromArena, skyArenaPos } from "./stage.js";
import { testInner } from "./test.js";
import { partnerEditor, findPartner } from "./partner.js";
import { applyLiteMark } from "./lite.js";
import { masterTalk, challengeMaster, spawnSlabBoss, SLAB_NAME, mrankText } from "./master.js";
import { naviMenu, storyGoalOf, goalLine } from "./navi.js";
import { tacticsAll, tacticOne, moveSetMenu, moveSetSummary } from "./tactics.js";
import { endgameMenu, inheritFlow, useLimit, useTmap, noteWalk, pickRule, HELP_TEXT as EG_HELP } from "./endgame.js";
import { enterDungeon, inDungeon, useXSlab, enterExtra } from "./dungeon.js";
import { rmTalk, kingTalk } from "./rmaster.js";
import { useKey, syncKeys } from "./saga.js";
import { betMenu } from "./bet.js";
import { qs, slabTierOk, endingDone, rankCap, capText, syncQuest, storyItemOk, storyLootOk, RANK_LBL, wtCap } from "./quest.js";
import { storyMenu, arenaMenu, prologue, chapterText, storyOf, WORLD_TEXT, maybeEnding, fight } from "./story.js";
import { musashiTalk, musashiSpar } from "./majin.js";
import {
  EXH, busy, choose, notice, confirm, modal, ICON, MON_ICON, ITEM_ICON, LINE, gold, countItem, takeItem, giveItem, rpgItems, bagLoad, bagSave, autoBag, stowAll, giveInv, invFree,
  particle, sound, monLabel, monLabel2, monName, monInfo, paged, GRID_ON, GRID_BODY, bodyLines, pagedGrid, meter, FAM_COLOR, famColor, isLite, liteAddon, refreshLite, rankOf, LOGO_ROWS, tps, heavy, clipT, ok, wait } from "./ui.js";

const BOX_MAX = Infinity;   // v3.0: 預かり所は いくらでも
const RESNAME = { "-1": "§c弱点", "0": "§7ふつう", "1": "§a軽減", "3": "§b激減", "2": "§d無効", "4": "§9吸収" };
const AILRES = { "-1": "§c弱点", "1": "§a軽減", "3": "§b激減", "2": "§d無効" };
export const elTag = (e) => `${EL_COL[e]}${EL_NAME[e]}§r`;
export const catTag = (c) => `${CAT_COL[c]}${CATS[c]}§r`;
export function affText(sid) {
  const a = SPECIES[sid].aff || {};
  return `§f得意: ${a.gc ? catTag(a.gc) : "-"} ${(a.ge || []).map(elTag).join("・")}  §f不得意: ${a.bc ? catTag(a.bc) : "-"} ${a.be ? elTag(a.be) : ""}`;
}
export function aresText(sid) {
  const r = SPECIES[sid].ares || {};
  const s = Object.entries(r).map(([k, v]) => `${AIL_NAME[k]}${AILRES[String(v)]}§r`);
  return s.length ? s.join(" ") : "§7とくになし";
}
const STAT_LINE = (st) => ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"].map((k) => `${ST_COL[k]}${ST_NAME[k]}§f${st[k]}`).join(" ");
const B = (t, icon) => [t, icon];

// ---------- 表示 ----------
function resText(m) {
  const r = resOf(m);
  const s = Object.entries(r).map(([k, v]) => `${elTag(k)}${RESNAME[String(v)]}§r`);
  return s.length ? s.join(" ") : "§7とくになし";
}
function eqText(m) {
  return ["w", "a", "x"].map((s) => `${{ w: "武器", a: "防具", x: "アクセ" }[s]}: ${m.eq[s] ? gearName(m.eq[s], m.eqr && m.eqr[s]) : "§7なし§r"}`).join("  ");
}
function monSummary(m) {
  const s = SPECIES[m.sp];
  const st = calcStats(m);
  const fam = FAMILIES.find((f) => f.id === s.fam).name;
  return [
    `§l${famColor(m.sp)}${m.nm}§r §7${s.name}  ${famColor(m.sp)}${fam}§7  ランク§e${s.rank}${m.plus ? ` §d+${m.plus}` : ""}`,
    `§fLv§e${m.lv}${m.lv < MAXLV ? ` §7(次まで ${expNeed(m.lv) - m.exp})` : " §6MAX"}   §fSP §e${m.spl}`,
    `§fHP ${meter(m.hp, st.hp, 12)} §a${m.hp}§7/${st.hp}`,
    `§fMP ${meter(m.mp, st.mp, 12, "§b")} §b${m.mp}§7/${st.mp}`,
    STAT_LINE(st),
    `§f性格 §d${NATURES[m.nat]?.name || "?"}${m.nat === s.rec ? " §6○" : ""}  §fサイズ §b${sizeOf(m)}  §7${FAM_BONUS_TEXT[s.fam] || ""}`,
    ...(m.ht && TRAITS[s.ht] ? [`§6§l${TRAITS[s.ht].name}§r §6（固有特性）`] : []),
    ...(m.kw || m.lim ? [`${m.kw ? "§6§l完全個体「極」§r " : ""}${m.lim ? `§d限界突破 ★${m.lim}（+${m.lim * 4}%）` : ""}`] : []),
    `§f装備 §7${["w", "a", "x"].map((k) => (m.eq[k] ? gearName(m.eq[k], m.eqr && m.eqr[k]) : "-")).join(" §7/ ")}`,
  ].join("\n");
}
function monText(m) {
  const s = SPECIES[m.sp];
  const L = [
    `§l§e詳しい 情報§r  ${m.nm}`, LINE,
    `§f性格: §d${natureText(m.nat)}`,
    `§fおすすめ: §b${natureText(s.rec)}`,
    affText(m.sp),
    `§f属性耐性: ${resText(m)}`,
    `§f状態異常耐性: ${aresText(m.sp)}`,
    `§f装備: ${equipText(m.sp)}`,
    `§7系統ボーナス: ${FAM_BONUS_TEXT[s.fam] || "-"}`,
    `§fライド: ${rideInfo(m.sp, m)}`,
  ];
  if (s.evo) L.push(`§dLv${s.evo[1]}で ${SPECIES[s.evo[0]].name}に 進化${m.noevo ? " §c（進化しない 設定）" : ""}`);
  if (s.ievo && SPECIES[s.ievo[0]]) L.push(`§6${ITEMS[s.ievo[1]]?.name}で ${SPECIES[s.ievo[0]].name}に 進化`);
  if (m.tm || m.awk) L.push(`§5§l闘魔覚醒§r§5: 能力 +25%・行動 +1・ダメージ上限なし・戦いの はじめに 全能力 +1段階・スキル枠 +1・その 子だけの 特性が 強く なる（数値 1.5倍・条件つきの 強化は +1段階）${m.awk ? `・${s.rank} → ${m.awk}ランクの 力` : ""}`);
  { const mul = TRAIT_MUL[SPECIES[m.sp]?.rank] || 1; L.push(LINE, `§l§e特性${mul > 1 ? ` §r§6（${SPECIES[m.sp].rank}ランク補正: 数値 ×${mul}）` : ""}`, ...traitIds(m).map((t) => `${(SPECIES[m.sp].traits || []).includes(t) || ["act2", "act23", "act34"].includes(t) ? "§d" : "§b◇"}${TRAITS[t]?.name}§7: ${TRAITS[t]?.desc}`), ...(m.xtr && TRAITS[m.xtr] ? [`§a★${TRAITS[m.xtr].name}§8（特性の秘薬）§7: ${TRAITS[m.xtr].desc}`] : []), ...((SPECIES[m.sp].tpool || []).length ? [`§8◇は この 個体だけの 特性（厳選）。相性の よい 候補: ${(SPECIES[m.sp].tpool || []).filter(([, w]) => w > 1).map(([t]) => TRAITS[t]?.name).slice(0, 6).join("・") || "-"}`] : []), ...skillTraits(m).map((t) => `§b${TRAITS[t]?.name}§8（スキル）§7: ${TRAITS[t]?.desc}`)); }
  { const b = TRAITS[SPECIES[m.sp].bd]; if (b) L.push(`§a◆体質「${b.name}」§7: ${b.desc}`); }   /* 第104版 */
  { const h = TRAITS[SPECIES[m.sp].ht]; if (h) L.push(m.ht ? `§6§l${h.name}§r§6: ${h.desc}` : `§8？？？（固有特性・この こは もっていない）`); }
  { const rl = recoLines(m.sp); if (rl.length) L.push(LINE, ...rl); }
  L.push(LINE, "§l§e覚えている 技");
  for (const id of getMoves(m)) {
    const mv = MOVES[id];
    const mu = (m.mu && m.mu[id]) || 0;
    const rp = realPower(m, id);
    const mk = (m.mk && m.mk[id]) || 0;
    L.push(`${moveLabel(id)}${mk >= 100 ? "§6★" : ""}§f${mv.name} §8${moveTag(id)}${rp ? ` §e実威力${rp}%` : ""}${mv.next ? ` §7進化まで ${Math.max(0, masteryNeed(id) - mu)}回` : ""} §8極め${Math.min(100, mk)}/100`);
  }
  return L.join("\n");
}
export function moveTag(id) {
  const mv = MOVES[id];
  const tgt = { enemy: "1体", enemies: "全体", ally: "味方1", allies: "味方全", self: "自分", all: "敵味方", rand2: "2体" }[mv.target] || "";
  return `${tgt}${mv.mult ? `・威力${Math.round(mv.mult * 100)}%` : ""} MP${mv.mp}`;
}

// ---------- メインメニュー ----------
const LOST_SAID = new Set();
let ITEM_IX = null; const itemIx = (id) => { if (!ITEM_IX) ITEM_IX = new Map(Object.keys(ITEMS).map((k, i) => [k, i])); return ITEM_IX.get(id) ?? 1e9; };   // 第69版: 道具の 並べかえを 軽く
const ownN = (d) => (d.own || []).filter((i) => i < ORDER.length).length;   // 第68版: 図鑑の 数に 神々は 入れない
export async function openMenu(p) {
  if (busy.has(p.id)) return;
  if (inBattle(p)) { try { p.onScreenDisplay.setActionBar("§7戦いの 最中は ガイドブックを 開けない"); } catch {} return; }
  busy.add(p.id);
  try {
    let d = load(p);
    if (!d && isBroken(p)) {   // v2.9.12: データが こわれて いる ときは 最初から に しない
      const c = await choose(p, "データが 読みこめません", "§c冒険の データが こわれて いて 読みこめませんでした。\n§fデータは 消さずに とって あります。\n§7バックアップから もどすか、どうしても 最初から 遊ぶ ときだけ「最初から」を えらんで ください。", [B("§aバックアップから もどす", ICON("i_back")), B("§c最初から はじめる（こわれた データは 消える）", ICON("i_close")), B("§7とじる", ICON("i_back"))]);
      if (c === 0) { await saveMenu(p); forget(p.id); if (load(p)) clearBroken(p); return; }
      if (c !== 1 || !(await confirm(p, "最初から", "§c本当に 最初から はじめますか？ こわれた データは もどせません。", "はじめる", "やめる"))) return;
      clearBroken(p);
    }
    if (!d) { d = await chooseStarter(p); if (!d) return; }
    if (d.lost && d.lost.length && !LOST_SAID.has(p.id)) { LOST_SAID.add(p.id); try { p.sendMessage(`§7いまの アドオンに いない 種族の 仲間 ${d.lost.length}体を 消さずに しまって います（前の アドオンに もどすと 帰ってきます）。`); } catch {} }   // v2.9.12
    await prologue(p, d);
    try { let n = 0; for (const x of allMons(d)) if (fixSp(x)) n++; if (n) { save(p, d); p.sendMessage(`§6${n}体に たりなかった スキルポイントを わたした`); } } catch {}
    // v2.9.12: 手元に ない 石板（封印した ものも）を もどす
    try { const got = syncQuest(p, d); if (got.length) { save(p, d); p.sendMessage(`§d${got.join("・")} を バッグに 入れた`); } } catch {}   /* 第69版 */
    try { const got = syncKeys(p, d); if (got.length) { save(p, d); p.sendMessage(`§6${[...new Set(got)].join("・")} が 手元に もどった`); } } catch {}   /* v2.9.12: だいじなものも 開いた ときに もどす */
    try { await maybeEnding(p, d); } catch {}   // v2.9.12: 星冠王に 勝った あと ぬけて エンディングを 見のがした とき
    try { const mode = p.getDynamicProperty("mrpg:autosp"); if (mode) { const r = autoSP(d, mode); if (r.length) { save(p, d); p.sendMessage(`§bSPを 自動で 振った（${r.length}体）`); } } } catch {}
    for (;;) {
      if (!ok(p)) return;   /* 第69版: 開いた まま 抜けた */
      const town = townAt(p.location);
      const party = d.party.map((m) => { const st = calcStats(m); return `§f${m.id === d.out ? "§b★" : " "}${m.nm} §7Lv${m.lv} ${meter(m.hp, st.hp, 8)}${m.spl ? " §6SP" + m.spl : ""}`; });
      const body = [
        `${LOGO_ROWS[0]}  ${LOGO_ROWS[1]}`,
        `§l§fモンスターマスター ${p.name}  §r§8v${VERSION}`, LINE,
        ...party, LINE,
        `§fお金 ${gold(d.gold)}   §f場所 ${town ? `§e${town.name}` : "§7フィールド"}`,
        `§f図鑑 §e${ownN(d)}§7/${ORDER.length}たい   §f預かり所 §e${d.box.length}§7たい`,
        `${chapterText(d)}  §bマスターポイント ${d.mpt || 0}`,
        ...(() => { try { const g = storyGoalOf(p); return g ? [LINE, goalLine(p, g, true)] : []; } catch { return []; } })(),
      ].join("\n");
      /* 第73版: マス目の ときは 説明を 6行に まとめる（スマホ・Switch の 画面に おさめる） */
      /* 第75版: マス目の ときは 説明を 4行に（写真で 測った 文字の 大きさ） */
      const body2 = !GRID_ON ? body : [
        `§l§f${p.name}§r  §fお金 ${gold(d.gold)}  §f${town ? `§e${town.name}` : "§7フィールド"}  §f図鑑 §e${ownN(d)}§7/${ORDER.length}`,
        clipT(d.party.map((m) => { const st = calcStats(m); return `${m.id === d.out ? "§b★" : "§f"}${m.nm}§7${m.lv} ${meter(m.hp, st.hp, 4)}${m.spl ? "§6SP" : ""}`; }).join(" "), 46),
        clipT(chapterText(d), 46),
        ...(() => { try { const g = storyGoalOf(p); return g ? [clipT(goalLine(p, g, false).split("\n")[0], 46)] : []; } catch { return []; } })(),
      ].join("\n");
      const bodyG = bodyLines(body2) <= GRID_BODY ? body2 : body;   /* 6行に おさまらない ときは もとの 説明（縦の 一覧） */
      const sel = await choose(p, "ガイドブック", bodyG, [
        B("§l仲間\n§8パーティ・預かり所・スキル・配合", ICON("i_party")),
        B("§l道具・装備\n§8道具・タマゴ・装備・素材", ICON("i_bag")),
        B("§lクラフト\n§8素材から 武器や 道具を 作る", ICON("i_equip")),
        B("§l冒険\n§8ワープ・ショップ・宿屋・図鑑", ICON("i_walk")),
        B("§6§lストーリー\n§8マスターリーグ・目標・伝説", ICON("i_fight")),
        B("§9§lマルチプレイ", ICON("i_scout")),
        B("§d§lやりこみ\n§8塔・ラッシュ・対戦・牧場・称号など", ICON("i_zukan")),
        B(`§a§l全回復 §8（回復技 → たりなければ 道具）\n§8${healStatus(d)}`, ICON("i_party")),
        B("§e§l用語説明\n§8能力・攻撃の種類・属性・状態異常など", ICON("i_zukan")),
        B("§7閉じる", ICON("i_close"))]);
      if (sel === 0) { if ((await friendsMenu(p, d)) === "close") return; }
      else if (sel === 1) await itemsMenu(p, d);
      else if (sel === 2) await craftMenu(p, d);
      else if (sel === 3) await adventureMenu(p, d);
      else if (sel === 4) { await storyMenu(p, d); d = load(p) || d; }   /* 第78版: 追加ストーリーの 中で 保存した 中身を 読み直す */
      else if (sel === 5) { if ((await multiMenu(p, d)) === "close") return; }
      else if (sel === 6) { const f = await endgameMenu(p, d); if (typeof f === "function") { AFTER.set(p.id, f); return; } }
      else if (sel === 7) await healAllFlow(p, d);
      else if (sel === 8) await glossaryMenu(p);
      else return;
    }
  } finally {
    busy.delete(p.id);
    const f = AFTER.get(p.id); AFTER.delete(p.id);
    if (f) system.run(() => { Promise.resolve().then(f).catch((e) => { if (!/PlayerQuit|InvalidEntity|invalid/i.test(String(e))) console.warn(`[MonsterRPG] after: ${e}`); }); });   /* 第69版 */
  }
}
// メニューを 閉じた あとに 実行する（バトルなど）
const AFTER = new Map();

// v1.7: 模擬戦（自分の モンスター どうし・空の 闘技場で）
async function pickTeam(p, d, title, used) {
  const team = [];
  for (;;) {
    const pool = allMons(d).filter((m) => !used.includes(m) && !team.includes(m));
    const body = `§f${title}: ${team.map((m) => m.nm).join("・") || "§7まだ いない"}  §8(${team.length}/4)\n§7追加する モンスターを 選んでください`;
    const extra = team.length ? [B("§a§l決定", ICON("i_party"))] : [];
    if (team.length >= 4) return team;
    const i = await paged(p, title, body, pool.map((m) => B(monLabel2(m, `§7${whereOf(d, m)[0]}`), MON_ICON(m.sp))), 8, extra);
    if (i === -2) return team;
    if (i < 0) return null;
    team.push(pool[i]);
  }
}
async function sparSetup(p, d) {
  if (allMons(d).length < 2) { await notice(p, "模擬戦", "§7モンスターが 2体 以上 必要です。"); return false; }
  const mode = await choose(p, "模擬戦", ["§f自分の モンスター どうしを 空の 闘技場で 戦わせます。", "§7報酬・経験値は なし。HP・MP・道具は 減りません。", "§7技や 作戦・AIの ためしに どうぞ。"].join("\n"),
    [B("§lチームAを 指示\n§8チームBは オート", ICON("i_fight")), B("両方 指示する", ICON("i_party")), B("観戦（両方 オート）\n§8しゃがむと 中断", ICON("i_scout")), B("§7戻る", ICON("i_back"))]);
  if (mode < 0 || mode > 2) return false;
  const A = await pickTeam(p, d, "チームA", []);
  if (!A || !A.length) return false;
  const Bt = await pickTeam(p, d, "チームB", A);
  if (!Bt || !Bt.length) return false;
  if (!(await confirm(p, "模擬戦", `§bA: ${A.map((m) => m.nm).join("・")}\n§cB: ${Bt.map((m) => m.nm).join("・")}\n\n§7空の 闘技場へ 移動して 戦います。終わると もとの 場所に 戻ります。`, "はじめる", "やめる"))) return false;
  AFTER.set(p.id, () => runSpar(p, A, Bt, ["manual", "both", "watch"][mode]));
  return true;
}
export async function runSpar(p, A, Bt, mode) {
  const r = await toSkyArena(p);
  try {
    const C = skyArenaPos();
    let pos;
    if (r && r.ok) {
      pos = { player: { x: C.x + 0.5, y: C.y, z: C.z - 11 }, a: { x: C.x + 0.5, y: C.y, z: C.z - 5 }, b: { x: C.x + 0.5, y: C.y, z: C.z + 6 } };
      try { p.teleport({ x: pos.player.x, y: C.y + 0.2, z: pos.player.z }, { facingLocation: { x: C.x + 0.5, y: C.y + 1, z: C.z } }); } catch {}
    }
    await startSpar(p, A, Bt, mode, pos);
  } finally { backFromArena(p); }
}

// ---------- v2.9.10: 回復技を 戦闘の 外でも ----------
function hpLine(m) { const st = calcStats(m); return `${m.hp <= 0 ? "§c" : m.hp < st.hp ? "§e" : "§a"}HP ${m.hp}/${st.hp} §bMP ${m.mp}/${st.mp}`; }
function healMovesOf(m) {
  if (m.hp <= 0) return [];
  let f; try { f = fighter(m, "a"); } catch { return []; }
  return f.moves.filter((id) => MOVES[id] && MOVES[id].heal && !MOVES[id].revive && (MOVES[id].target === "ally" || MOVES[id].target === "allies"))
    .map((id) => ({ m, id, mv: MOVES[id], cost: costOf(f, MOVES[id]) * 2, amt: Math.max(1, Math.floor(healAmt(f, MOVES[id]))) }));   /* 第103版: 戦いの 外の 回復技は MP 2倍（道具・宿の 意味を 出す） */
}
const frontOf = (d) => [...d.party, ...(d.bench || [])];   /* 第69版: 戦闘の 外の 回復は 表と 裏 */
function healStatus(d) {
  const hurt = frontOf(d).filter((m) => m.hp > 0 && m.hp < calcStats(m).hp).length, down = frontOf(d).filter((m) => m.hp <= 0).length;
  const can = frontOf(d).some((m) => healMovesOf(m).some((h) => m.mp >= h.cost));
  if (!hurt) return down ? `§cたおれて いる 仲間 ${down}体（宿屋・命の羽で）` : "§aみんな 元気";
  return can ? `§eけが ${hurt}体 → 回復できる` : `§7けが ${hurt}体（回復技か MPが ない）`;
}
function castHeal(d, h, target, log) {
  const ts = h.mv.target === "allies" ? frontOf(d).filter((x) => x.hp > 0) : [target];
  h.m.mp -= h.cost; let tot = 0;
  for (const t of ts) { const mx = calcStats(t).hp; const a = Math.max(0, Math.min(mx - t.hp, Math.floor(h.amt * (0.9 + Math.random() * 0.2)))); t.hp += a; tot += a; }
  log.push(`§b${h.m.nm}§fの ${h.mv.name} §7(MP-${h.cost})§f → ${ts.length > 1 ? "みんな" : ts[0].nm}の HPが ${tot} 回復`);
  return tot;
}
// おまかせで 全回復（MPが 足りる かぎり、むだの 少ない 技から）
function autoHeal(d) {
  const log = []; let guard = 0;
  for (;;) {
    if (guard++ > 200) break;
    const hurt = frontOf(d).filter((m) => m.hp > 0 && m.hp < calcStats(m).hp);
    if (!hurt.length) break;
    const opts = frontOf(d).flatMap(healMovesOf).filter((h) => h.m.mp >= h.cost);
    if (!opts.length) break;
    let best = null;
    for (const h of opts) {
      const targets = h.mv.target === "allies" ? hurt : [hurt.reduce((a, b) => (calcStats(a).hp - a.hp >= calcStats(b).hp - b.hp ? a : b))];
      const eff = targets.reduce((s2, t) => s2 + Math.min(calcStats(t).hp - t.hp, h.amt), 0);
      const sc = eff / Math.max(1, h.cost);
      if (!best || sc > best.sc || (sc === best.sc && eff > best.eff)) best = { h, t: targets[0], sc, eff };
    }
    if (!best || best.eff <= 0) break;
    castHeal(d, best.h, best.t, log);
  }
  return log;
}
/* 第103版: 全回復で 回復技の MPが 足りない ときは 道具も 使う（安い 道具から・むだの 少ない 順）。倒れた 仲間には 命の羽など */
function autoHealItems(p, d, log) {
  const have = (k) => Object.keys(ITEMS).filter((id) => ITEMS[id].kind === k && (ITEMS[id].price || 0) < 1000 && countItem(p, `mrpg:${id}`) > 0);   /* 第103版: 1000G 以上の 高い 道具は 使わない */
  for (let g = 0; g < 60; g++) {
    const down = frontOf(d).find((m) => m.hp <= 0);
    if (down) { const L = have("revive").sort((a, b) => (ITEMS[a].price || 0) - (ITEMS[b].price || 0)); if (L.length && takeItem(p, `mrpg:${L[0]}`)) { const l2 = []; if (useItemOn(down, L[0], l2)) log.push(`§b${ITEMS[L[0]].name}§f: ${l2.join(" ")}`); else giveItem(p, `mrpg:${L[0]}`, 1); continue; } }
    const hurt = frontOf(d).filter((m) => m.hp > 0 && m.hp < calcStats(m).hp).sort((a, b) => (calcStats(b).hp - b.hp) - (calcStats(a).hp - a.hp));
    if (!hurt.length) break;
    const m = hurt[0], mx = calcStats(m).hp, need = mx - m.hp, L = have("heal").sort((a, b) => itemHp(ITEMS[a], mx) - itemHp(ITEMS[b], mx));
    if (!L.length) break;
    const id = L.find((x) => itemHp(ITEMS[x], mx) >= need) || L.slice().sort((a, b) => itemHp(ITEMS[b], mx) / Math.max(1, ITEMS[b].price || 1) - itemHp(ITEMS[a], mx) / Math.max(1, ITEMS[a].price || 1))[0];   /* 足りなければ 安くて 効く ものを 何回か */
    if (!takeItem(p, `mrpg:${id}`)) break;
    const l2 = []; if (useItemOn(m, id, l2)) log.push(`§b${ITEMS[id].name}§f: ${l2.join(" ")}`); else { giveItem(p, `mrpg:${id}`, 1); break; }
  }
}
async function healAllFlow(p, d) {
  const before = frontOf(d).map((m) => m.hp);
  const log = autoHeal(d);
  autoHealItems(p, d, log);
  if (!log.length) {
    const hurt = frontOf(d).some((m) => m.hp > 0 && m.hp < calcStats(m).hp);
    await notice(p, "全回復", [hurt ? "§7回復技を 覚えた 仲間が いないか MPが 足りず、回復の 道具も ありません。" : "§aみんな 元気です。", "", ...frontOf(d).map((m) => `§f${m.nm} ${hpLine(m)}`), frontOf(d).some((m) => m.hp <= 0) ? "\n§7たおれた 仲間は 宿屋か 命の羽で 生きかえる" : ""].join("\n"));
    return;
  }
  save(p, d); sound(p, "random.levelup", 1.6); if (d.out) refreshPet(p, d);
  const left = frontOf(d).some((m) => m.hp > 0 && m.hp < calcStats(m).hp);
  await notice(p, "全回復", [...log.slice(0, 12), log.length > 12 ? `§7…ほか ${log.length - 12}回` : "", "", ...frontOf(d).map((m, i) => `§f${m.nm} ${hpLine(m)}${m.hp > before[i] ? ` §a(+${m.hp - before[i]})` : ""}`), left ? "\n§7MPと 道具が 足りず 全員は 回復できなかった" : ""].filter((x) => x !== "").join("\n"));
}
async function fieldHealMenu(p, d) {
  for (;;) {
    const opts = frontOf(d).flatMap(healMovesOf);
    const body = ["§f回復技を 覚えた 仲間が MPを 使って 回復します。", LINE, ...frontOf(d).map((m) => `§f${m.nm} ${hpLine(m)}`), !opts.length ? "\n§7表と 裏に 回復技を 覚えた 仲間が いません。" : ""].join("\n");
    const btn = [B("§a§lおまかせで 全回復", ICON("i_party")), ...opts.map((h) => B(`${h.m.mp >= h.cost ? "§f" : "§8"}${h.m.nm}: §l${h.mv.name}§r §9MP${h.cost}\n§8${h.mv.target === "allies" ? "みんなを" : "1体を"} 約${h.amt} 回復（MP ${h.m.mp}）`, ICON("i_skill"))), B("§7戻る", ICON("i_back"))];
    const s = await choose(p, "回復技で 回復", body, btn);
    if (s === 0) { await healAllFlow(p, d); continue; }
    if (s < 1 || s > opts.length) return;
    const h = opts[s - 1];
    if (h.m.mp < h.cost) { await notice(p, "回復", `§c${h.m.nm}の MPが 足りない。`); continue; }
    let t = null;
    if (h.mv.target === "ally") {
      const alive = frontOf(d).filter((m) => m.hp > 0);
      const k = await choose(p, `${h.mv.name}を 誰に？`, "", [...alive.map((m) => B(`${m.nm}\n${hpLine(m)}`, MON_ICON(m.sp))), B("§7やめる", ICON("i_back"))]);
      if (k < 0 || k >= alive.length) continue;
      t = alive[k];
      if (t.hp >= calcStats(t).hp) { await notice(p, "回復", `§7${t.nm}の HPは もう 満タンです。`); continue; }
    } else if (!frontOf(d).some((m) => m.hp > 0 && m.hp < calcStats(m).hp)) { await notice(p, "回復", "§7みんな HPは 満タンです。"); continue; }
    const log = []; castHeal(d, h, t, log); save(p, d); sound(p, "random.orb", 1.4); if (d.out) refreshPet(p, d);
    try { p.sendMessage(log[0]); } catch {}
  }
}
// v2.9.11: スキルポイントを まとめて 振る（何体でも いっぺんに）
const SPMODE = { even: "まんべんなく（どの スキルにも 同じだけ）", seq: "上の スキルから 順に 最大まで", near: "次の ごほうびが 近い スキルから" };
function planSP(m, mode) {
  const t = [...m.pts]; let left = m.spl;
  if (mode === "seq") { for (let i = 0; i < t.length && left > 0; i++) { const a = Math.min(left, skMax(m.sk[i]) - t[i]); t[i] += a; left -= a; } return t; }
  if (mode === "near") {
    let guard = 0;
    while (left > 0 && guard++ < 200) {
      let bi = -1, bd = 1e9;
      for (let i = 0; i < t.length; i++) { if (t[i] >= skMax(m.sk[i])) continue; const nx = SKILLS[m.sk[i]]?.list.find((e) => e.pt > t[i]); const dd = (nx ? nx.pt : skMax(m.sk[i])) - t[i]; if (dd < bd) { bd = dd; bi = i; } }
      if (bi < 0) break; const a = Math.min(left, bd); t[bi] += a; left -= a;
    }
    return t;
  }
  while (left > 0) { const open = t.map((_, i) => i).filter((i) => t[i] < skMax(m.sk[i])); if (!open.length) break; const i = open.reduce((a, b) => (t[a] <= t[b] ? a : b)); t[i]++; left--; }
  return t;
}
export function autoSP(d, mode, list) {
  const out = [];
  for (const m of list || allMons(d)) {
    if (!(m.spl > 0) || !m.sk || !m.sk.length) continue;
    const before = m.spl, msgs = setPoints(m, planSP(m, mode));
    if (m.spl < before) out.push({ m, used: before - m.spl, msgs });
  }
  return out;
}
async function skillPickMenu(p, d) {
  for (;;) {
    const withSp = allMons(d).filter((m) => m.spl > 0);
    const autoOn = p.getDynamicProperty("mrpg:autosp");
    const body = [`§fSPが のこって いる 仲間: §e${withSp.length}体§f（パーティ ${withSp.filter((m) => d.party.includes(m)).length}体・のこり 合計 §e${withSp.reduce((a, m) => a + m.spl, 0)}§f）`,
      `§fレベルアップで 自動で 振る: ${autoOn ? `§aオン（${SPMODE[autoOn]}）` : "§7オフ"}`, "§7いちいち 1体ずつ 振らなくても、ここで まとめて 振れます。"].join("\n");
    const k = await choose(p, "スキルポイント", body, [B("§d§lみんなの SPを まとめて 振る\n§8SPの のこって いる 全員を いっぺんに", ICON("i_fuse")), B("§dパーティだけ まとめて 振る", ICON("i_fuse")),
      B(`§bレベルアップで 自動で 振る: ${autoOn ? "§aオン" : "§7オフ"}\n§8オンに すると もう 振らなくて いい`, ICON("i_skill")), B("1体ずつ 振る（バー・ツリーを 見ながら）", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    if (k === 0 || k === 1) {
      const L = k === 0 ? withSp : withSp.filter((m) => d.party.includes(m));
      if (!L.length) { await notice(p, "スキルポイント", "§7SPの のこって いる 仲間は いません。"); continue; }
      const keys = Object.keys(SPMODE);
      const mm = await choose(p, "振り方", `§f${L.length}体の SP（合計 ${L.reduce((a, m) => a + m.spl, 0)}）を どう 振りますか？`, [...keys.map((x) => B(SPMODE[x], ICON("i_skill"))), B("§7やめる", ICON("i_back"))]);
      if (mm < 0 || mm >= keys.length) continue;
      const res = autoSP(d, keys[mm], L);
      save(p, d); sound(p, "random.levelup");
      const lines = []; for (const r of res) { lines.push(`§e${r.m.nm}§f SP-${r.used}: ${r.m.sk.map((x, i) => `${SKILLS[x].name.replace(/・入門編|・初級編|・中級編|・上級編/, "")} ${r.m.pts[i]}`).join("・")}`); for (const x of r.msgs.slice(0, 2)) lines.push("  " + x); }
      await notice(p, "まとめて 振った", [`§a${res.length}体の SPを 振りました。`, "", ...lines.slice(0, 40), lines.length > 40 ? "§7…" : ""].join("\n"));
      continue;
    }
    if (k === 2) {
      if (autoOn) { p.setDynamicProperty("mrpg:autosp", undefined); continue; }
      const keys = Object.keys(SPMODE);
      const mm = await choose(p, "自動で 振る", "§fレベルアップした ときに SPを 自動で 振ります。振り方を えらんでください。", [...keys.map((x) => B(SPMODE[x], ICON("i_skill"))), B("§7やめる", ICON("i_back"))]);
      if (mm >= 0 && mm < keys.length) { p.setDynamicProperty("mrpg:autosp", keys[mm]); const res = autoSP(d, keys[mm]); if (res.length) save(p, d); await notice(p, "自動で 振る", `§aオンに した。${res.length ? `いま のこって いた ${res.length}体の SPも 振った。` : ""}`); }
      continue;
    }
    if (k === 3) { const m = await pickMon(p, d, "スキル", "§7スキルを 振り分ける モンスターを 選んでください", false, true); if (m) await allocMenu(p, d, m); continue; }
    return;
  }
}
// v2.9.10: スキル（スキルの書）の 中身
// 第67版: 仲間に した ことが ある 子は 緑、まだの 子は 金色で「NEW!」
export const ownName = (d, sp, nm) => { const S = SPECIES[sp]; const own = d && Array.isArray(d.own) && S && d.own.includes(S.idx); return own ? `§a●§r§l§f${nm || S?.name || ""}§r` : `§6NEW!§r §l§e${nm || S?.name || ""}§r`; };
// 第67版: スキルの 技の くわしい 効果を 1つずつ 見る
export async function skillMovesView(p, sk, title = "") {
  const t = SKILLS[sk]; if (!t) return;
  for (;;) {
    const es = t.list.filter((e) => e.move && MOVES[e.move]);
    if (!es.length) { await notice(p, title || t.name, `§b${t.name}§r §7には 技が ありません（能力や 特性が 上がる スキル）。`); return; }
    const k = await paged(p, title || `${t.name}の 技`, `§b${t.name}§r §7の 技（押すと くわしい 効果）`, es.map((e) => B(`§l${MOVES[e.move].name}§r §8${e.pt}pt\n§7${moveTag(e.move)}`, ICON(MOVES[e.move].kind === "attack" ? "i_fight" : "i_spell"))), 8);
    if (k < 0 || k >= es.length) return;
    const id = es[k].move;
    await notice(p, MOVES[id].name, [`§l§e${MOVES[id].name}§r  §8${moveTag(id)}`, LINE, moveDesc(id)].join("\n"));
  }
}
export function skillPreview(sk) {
  const t = SKILLS[sk]; if (!t) return "";
  const L = [`§l§b${t.name}§r`, `§f${t.desc || ""}`, LINE];
  for (const [pt, es] of skGroups(t)) {
    const what = es.map((e) => e.move && MOVES[e.move] ? `§f${MOVES[e.move].name} §8${moveTag(e.move)}` : e.trait ? `§d特性【${TRAITS[e.trait]?.name}】 §8${TRAITS[e.trait]?.desc || ""}` : null).filter(Boolean);
    const st = es.filter((e) => e.stat); if (st.length) what.push(st.every((e) => e.val === st[0].val) ? st.map((e) => ST_NAME[e.stat]).join("＋") + ` +${st[0].val}` : st.map((e) => `${ST_NAME[e.stat]} +${e.val}`).join("・"));
    L.push(`§7${String(pt).padStart(3, " ")}pt  ${what.join(" §7/§r ")}`);
  }
  if (t.next && SKILLS[t.next]) L.push(`§8（100まで 振って 配合すると「${SKILLS[t.next].name}」に 進化）`);
  return L.join("\n");
}
async function friendsMenu(p, d) {
  for (;;) {
    const s0 = await choose(p, "仲間", "§7何を しますか？", [
      B(`§lパーティ（表） §8${partyUse(d)}/4枠`, ICON("i_party")), B(`§b裏（スタンバイ） §8${benchUse(d)}/4枠\n§8表が 倒れたら 出る 控え`, ICON("i_party")), B(`預かり所 §8${d.box.length}たい`, ICON("i_box")), B("スキルポイントを 振る\n§8まとめて 振れる・自動で 振る", ICON("i_skill")),
      B("連れ歩き・ライド", ICON("i_walk")), B("配合", ICON("i_fuse")), B("§e入れ替え\n§8表・裏・預かり所の 2体を 交換", ICON("i_fuse")), B("§d模擬戦\n§8自分の モンスター どうしで 戦う", ICON("i_fight")), B(`§b相棒（カスタム）\n§8${findPartner(d) ? findPartner(d).nm + "の 見た目・名前を かえる" : "自分だけの 相棒を つくる"}`, ICON("i_egg")), B("§6色がえ\n§8部位ごとに 色を かえる", ICON("i_skill")), B("§a回復技で 回復する\n§8MPを 使って HPを 回復", ICON("i_party")), B("§6作戦\n§8オートの 方針・技の 好み", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    if (s0 === 1) { await listMenu(p, d, d.bench, "裏（スタンバイ）"); continue; }   // 第68版
    const s = s0 > 1 ? s0 - 1 : s0;
    if (s === 0) await listMenu(p, d, d.party, "パーティ（表）");
    else if (s === 1) await listMenu(p, d, d.box, "預かり所");
    else if (s === 5) await swapMenu(p, d);
    else if (s === 6) { if (await sparSetup(p, d)) return "close"; }
    else if (s === 7) { const pm = findPartner(d); if (!pm && d.partnerId) { await notice(p, "相棒", "§7相棒は 1体だけ 作れます。\n§f手元に いない ときは、預かり所・牧場に いないか 見てみよう。§7（配合・交換・わかれた 相棒は もどりません）"); continue; } await partnerEditor(p, d, pm || null); if (pm && d.out === pm.id) refreshPet(p, d); }   // v2.9.12: 何体も 作れない ように
    else if (s === 2) await skillPickMenu(p, d);
    else if (s === 9) await fieldHealMenu(p, d);
    else if (s === 10) await tacticsAll(p, d.party, () => save(p, d), "作戦（パーティ）");
    else if (s === 3) await walkMenu(p, d);
    else if (s === 4) await fusionMenu(p, d);
    else if (s === 8) { const m = await pickMon(p, d, "色がえ", "§7色を かえる モンスターを 選んでください", false, true); if (m) await tintMenu(p, d, m); }
    else return;
  }
}
// v2.7: 部位ごとの 色がえ（1体ずつ）
const TINT_NAME = ["元の色", "赤", "朱", "橙", "金", "黄", "黄緑", "緑", "青緑", "水色", "青", "藍", "紫", "桃", "白", "灰", "黒"];
const TINT_COL = ["§f", "§4", "§c", "§6", "§6", "§e", "§a", "§2", "§3", "§b", "§9", "§1", "§5", "§d", "§f", "§7", "§8"];
const TINT_PART = [["h", "頭"], ["b", "体"], ["a", "手"], ["l", "足"], ["c", "爪"], ["w", "翼・飾り"]];
async function tintMenu(p, d, m) {
  for (;;) {
    const T = { ...(SPECIES[m.sp]?.dtint || {}), ...(m.tint || {}) };   /* 第69版: 神の 色を もとに */
    const body = [`§l${m.nm}§r の 色がえ`, LINE, ...TINT_PART.map(([k, n]) => `§f${n}: ${TINT_COL[T[k] || 0]}${TINT_NAME[T[k] || 0]}`), LINE,
      "§7色を かえたい 部位を えらんでください。§8（部位が ない モンスターは その 部位は 変わりません）"].join("\n");
    const s = await choose(p, "色がえ", body, [...TINT_PART.map(([k, n]) => B(`§l${n}§r §8${TINT_NAME[T[k] || 0]}`, ICON("i_skill"))),
      B("§dおまかせ\n§8ぜんぶの 部位を ランダムに", ICON("i_fuse")), B("§7もとの 色に もどす", ICON("i_close")), B("§7戻る", ICON("i_back"))]);
    if (s < 0 || s > TINT_PART.length + 1) return;
    if (s === TINT_PART.length) { const pal = [...Array(16).keys()].map((x) => x + 1).sort(() => Math.random() - 0.5); m.tint = Object.fromEntries(TINT_PART.map(([k], i) => [k, Math.random() < 0.25 ? 0 : pal[i % pal.length]]).filter(([, v]) => v));   /* 第69版: 0は 入れない（神の 色を のこす） */ }
    else if (s === TINT_PART.length + 1) m.tint = {};
    else {
      const [k, n] = TINT_PART[s];
      const c = await choose(p, `${n}の 色`, `§7${m.nm}の ${n}の 色を えらんでください`, [...TINT_NAME.map((x, i) => B(`${TINT_COL[i]}§l${x}`, ICON("i_skill"))), B("§7戻る", ICON("i_back"))]);
      if (c < 0 || c >= TINT_NAME.length) continue;
      if (c === 0) { const t = { ...(m.tint || {}) }; delete t[k]; m.tint = t; } else m.tint = { ...(m.tint || {}), [k]: c };   /* 第69版 */
    }
    save(p, d); sound(p, "random.orb");
    if (d.out === m.id) refreshPet(p, d);
  }
}
// v1.7: 2体を 選んで 入れかえる（表・預かり所）
const whereOf = (d, m) => d.party.includes(m) ? ["表", d.party] : (d.bench || []).includes(m) ? ["裏", d.bench] : ["預かり所", d.box];
/* 第71版: 表・裏へ 入れる。入らない ときは その場で 入れかえる 相手を えらぶか、自動で 空けて 入れる（いちいち 預けなくて よい） */
async function placeInto(p, d, m, dest) {
  d.bench = d.bench || [];
  const DL = dest === "party" ? d.party : d.bench, dn = dest === "party" ? "表" : "裏";
  const useOf = (L) => L.reduce((a, x) => a + slotOf(x), 0);
  const [srcN, SL0] = whereOf(d, m);
  if (SL0 === DL) return false;
  if (SL0 === d.party && d.party.length <= 1) { await notice(p, `${dn}へ`, "表の パーティが いなくなって しまいます。"); return false; }
  const done = () => { if (d.out && !d.party.some((x) => x.id === d.out)) recallPet(p, d); save(p, d); sound(p, "random.pop"); };
  if (useOf(DL) + slotOf(m) <= 4) { SL0.splice(SL0.indexOf(m), 1); DL.push(m); done(); return true; }
  const k = await choose(p, `${dn}へ 入れる`, [`§e${m.nm}§f（${SIZE_NAME?.[sizeOf(m)] || sizeOf(m)}・${slotOf(m)}枠）を ${dn}へ 入れます。`, `§c${dn}は いま ${useOf(DL)}/4枠で 入りません。`, "§f入れかえる 子を えらぶか、自動で 空けて 入れます。", `§7出た 子は ${SL0 === d.box && dest === "party" ? "裏" : srcN}へ（入らない ときは 預かり所へ）`].join("\n"),
    [...DL.map((c) => B(`§l${c.nm}§r と 入れかえ\n§8${slotOf(c)}枠 Lv${c.lv}`, MON_ICON(c.sp))), B("§e自動で 空けて 入れる\n§8うしろの 子から 出す", ICON("i_fuse")), B("§7やめる", ICON("i_back"))], false);
  if (k < 0 || k > DL.length) return false;
  const [, SL] = whereOf(d, m);   // 待って いる あいだの 変化に そなえて もう一度
  if (SL === DL || !SL.includes(m) || (k < DL.length && !DL[k])) return false;
  const snap = { party: [...d.party], bench: [...d.bench], box: [...d.box] };
  const out = [];
  SL.splice(SL.indexOf(m), 1);
  if (k < DL.length) { out.push(DL[k]); DL.splice(k, 1, m); } else DL.push(m);
  while (useOf(DL) > 4 && DL.length > 1) { let i = DL.length - 1; while (i >= 0 && DL[i] === m) i--; if (i < 0) break; out.push(DL.splice(i, 1)[0]); }   // まだ 入らなければ うしろから 出す
  for (const c of out) { if (SL !== d.box && useOf(SL) + slotOf(c) <= 4) SL.push(c); else if (SL === d.box && DL === d.party && useOf(d.bench) + slotOf(c) <= 4) d.bench.push(c); else d.box.push(c); }   // 預かり所から 表へ 入れた ときは 出た 子を まず 裏へ
  if (partyUse(d) > PARTY_CAP || benchUse(d) > BENCH_MAX || !d.party.length) {
    d.party.splice(0, d.party.length, ...snap.party); d.bench.splice(0, d.bench.length, ...snap.bench); d.box.splice(0, d.box.length, ...snap.box);
    await notice(p, `${dn}へ 入れる`, "§c枠に 入りきらないので 入れかえられませんでした。"); return false;
  }
  done();
  await notice(p, `${dn}へ 入れた`, [`§e${m.nm}§f を ${dn}へ 入れた！`, ...out.map((c) => `§7${c.nm} → ${whereOf(d, c)[0]}`)].join("\n"));
  return true;
}
async function swapMenu(p, d, first = null) {
  const all = () => [...d.party, ...(d.bench || []), ...d.box];
  const lab = (m) => B(monLabel2(m, `§7${whereOf(d, m)[0]}`), MON_ICON(m.sp));
  let a = first;
  if (!a) { const l = all(); const i = await paged(p, "入れ替え（1体目）", "§7入れかえる 1体目を 選んでください", l.map(lab)); if (i < 0) return; a = l[i]; }
  const l2 = all().filter((m) => m !== a && whereOf(d, m)[1] !== whereOf(d, a)[1]);
  if (!l2.length) { await notice(p, "入れ替え", "入れかえる 相手が いません。"); return; }
  const j = await paged(p, "入れ替え（2体目）", `§f${a.nm}§7（${whereOf(d, a)[0]}）と 入れかえる 相手を 選んでください`, l2.map(lab));
  if (j < 0) return;
  const b = l2[j];
  const [, la] = whereOf(d, a), [, lb] = whereOf(d, b);
  const ia = la.indexOf(a), ib = lb.indexOf(b);
  la[ia] = b; lb[ib] = a;
  if (partyUse(d) > PARTY_CAP || benchUse(d) > BENCH_MAX) { la[ia] = a; lb[ib] = b; await notice(p, "入れ替え", `§c${partyUse(d) > PARTY_CAP ? "表" : "裏"}の 枠（4）を こえてしまうので 入れかえられません。§r\n§7S=1枠 M=2枠 L=3枠 G=4枠`); return; }
  if (!d.party.some((m) => m.id === d.out)) recallPet(p, d);
  save(p, d); sound(p, "random.pop");
  await notice(p, "入れ替え", `§e${a.nm}§f と §e${b.nm}§f を 入れかえた！`);
}
async function itemsMenu(p, d) {
  for (;;) {
    const b = bagLoad(p), nb = Object.values(b.i).reduce((a, x) => a + x, 0) + b.g.length;
    const s = await choose(p, "道具・装備", `§7何を しますか？\n§fバッグの 中: §e${nb}§7こ（道具 ${Object.keys(b.i).length}しゅ・装備 ${b.g.length}こ）\n§7拾った 物を バッグへ: ${autoBag(p) ? "§aオン" : "§cオフ"}`,
      [B("§6§l持ち物を ぜんぶ バッグへ しまう\n§8インベントリを 空ける（ブック・コンパス・釣竿・だいじなものは のこす）", ICON("i_box")), B("§l道具・タマゴを 使う\n§8持ち物と バッグの 中から", ICON("i_bag")), B("装備を かえる", ICON("i_equip")), B("§6§lバッグを 開く\n§8取り出す・使う・自動で しまう 設定", ICON("i_bag")), B("§7戻る", ICON("i_back"))]);
    if (s === 0) { const n = stowAll(p, decodeLoreG); sound(p, "random.chestclosed"); await notice(p, "バッグ", n ? `§a${n}こ バッグに しまった！` : "§7しまう 物は ありませんでした。"); }
    else if (s === 1) await bagMenu(p, d);
    else if (s === 2) await equipPick(p, d);
    else if (s === 3) await bagStore(p, d);
    else return;
  }
}
async function settingsMenu(p) {
  const SPN = ["ゆっくり", "ふつう", "はやい"];
  for (;;) {
    const on = world.getDynamicProperty("mrpg:lite") === true;
    const conf = p.getDynamicProperty("mrpg:noconfirm") !== true;
    const sp = typeof p.getDynamicProperty("mrpg:bspeed") === "number" ? p.getDynamicProperty("mrpg:bspeed") : 1;
    const cam = p.getDynamicProperty("mrpg:nocam") !== true, stg = p.getDynamicProperty("mrpg:nostage") !== true;
    const body = [`§f確認画面（技・道具）: ${conf ? "§aオン" : "§7オフ"}`, `§fバトルの 速さ: §e${SPN[sp]}`, `§fカメラワーク: ${cam ? "§aオン" : "§7オフ"}`, `§f戦闘の 背景（ステージ）: ${stg ? "§aオン" : "§7オフ"}`,
      `§f軽量モード: ${isLite() ? "§aオン" : "§7オフ"}`, `§f預かり所の 仲間にも 経験値: ${p.getDynamicProperty("mrpg:noboxexp") === true ? "§7オフ" : "§aオン"}`, "§7軽量モード: 遠くの モンスターを かんたんな 形で えがき、遠くの 野生モンスターや 落ちた アイテムを 10秒ごとに かたづける",
      LINE, "§7戦闘の 背景は バトルの あいだ まわりを 一時的に ステージに 変えて、終わると もとに 戻します。建物の 近くで 戦う ときは オフに しても OK", "§7軽量モードは ワールドの みんなに かかります。とても 重いときは ダメージの 数字を 自動で 止めます（戦闘の 背景・カメラは そのまま）",
      `§7いまの 処理速度: §f${tps().toFixed(1)} §7/ 20 TPS ${heavy() >= 2 ? "§c（とても 重い）" : heavy() ? "§e（軽量化 中）" : "§a（ふつう）"}`].join("\n");
    const s = await choose(p, "設定", body, [B(conf ? "確認画面を §cオフ§r にする" : "確認画面を §aオン§r にする", ICON("i_help")),
      B(`バトルの 速さ: §e${SPN[sp]}§r → ${SPN[(sp + 1) % 3]}`, ICON("i_run")), B(cam ? "カメラワークを §cオフ§r にする" : "カメラワークを §aオン§r にする", ICON("i_scout")),
      B(stg ? "戦闘の 背景を §cオフ§r にする" : "戦闘の 背景を §aオン§r にする", ICON("i_walk")), B(on ? "軽量モードを §cオフ§r にする" : "軽量モードを §aオン§r にする", ICON("i_skill")),
      B("§7データを 前の 状態に もどす §8（もしもの とき）", ICON("i_box")), B("§cテスト メニュー §8（ためし用）", ICON("i_help")), B("§dチートブックを もらう", ICON("i_zukan")), ...(isRealHost(p) ? [B(`テスト・チートを みんなに 許可: ${world.getDynamicProperty("mrpg:cheatall") === true ? "§aオン" : "§cオフ"}`, ICON("i_party"))] : []),
      B(`預かり所にも 経験値: ${p.getDynamicProperty("mrpg:noboxexp") === true ? "§7オフ§r → §aオン" : "§aオン§r → §7オフ"}`, ICON("i_box")),
      B(`右上の 目的地 案内: ${p.getDynamicProperty("mrpg:nogoal") === true ? "§7オフ§r → §aオン" : "§aオン§r → §7オフ"}`, ICON("i_scout")),
      B(`戦いの ログを チャットにも: ${p.getDynamicProperty("mrpg:chatlog") === true ? "§aオン§r → §7オフ" : "§7オフ§r → §aオン"}\n§8ふだんは 画面の 左に 出ます`, ICON("i_help")),
      B(`戦いの 画面の 枠（上・左）: ${p.getDynamicProperty("mrpg:nohud") === true ? "§7オフ§r → §aオン" : "§aオン§r → §7オフ"}`, ICON("i_party")),
      B(`目的地の 光: ${p.getDynamicProperty("mrpg:nobeam") === true ? "§7オフ§r → §aオン" : "§aオン§r → §7オフ"}\n§8次の 目標に 光の 柱が 立つ`, ICON("i_scout")),
      ...(RU_GATE.on && RU_HOOK.levelMenu ? [B("滅びた世界の 強さ\n§8魔物の 数・追いかけ・ブレスと 魔法", ICON("i_fight"))] : []), B("§7戻る", ICON("i_back"))]);
    const BXI = isRealHost(p) ? 9 : 8;
    if (s === BXI) { p.setDynamicProperty("mrpg:noboxexp", p.getDynamicProperty("mrpg:noboxexp") !== true); sound(p, "random.click"); continue; }
    if (s === BXI + 1) { p.setDynamicProperty("mrpg:nogoal", p.getDynamicProperty("mrpg:nogoal") !== true); sound(p, "random.click"); continue; }
    if (s === BXI + 2) { p.setDynamicProperty("mrpg:chatlog", p.getDynamicProperty("mrpg:chatlog") !== true); sound(p, "random.click"); continue; }
    if (s === BXI + 3) { p.setDynamicProperty("mrpg:nohud", p.getDynamicProperty("mrpg:nohud") !== true); sound(p, "random.click"); continue; }
    if (s === BXI + 4) { p.setDynamicProperty("mrpg:nobeam", p.getDynamicProperty("mrpg:nobeam") !== true); sound(p, "random.click"); continue; }
    if (s === BXI + 5 && RU_GATE.on && RU_HOOK.levelMenu) { await RU_HOOK.levelMenu(p); continue; }
    if (s === 0) p.setDynamicProperty("mrpg:noconfirm", conf);
    else if (s === 1) p.setDynamicProperty("mrpg:bspeed", (sp + 1) % 3);
    else if (s === 2) p.setDynamicProperty("mrpg:nocam", cam);
    else if (s === 3) p.setDynamicProperty("mrpg:nostage", stg);
    else if (s === 4) { world.setDynamicProperty("mrpg:lite", !on); refreshLite(); applyLiteMark(); }
    else if (s === 5) { await saveMenu(p); continue; }
    else if ((s === 6 || s === 7) && !isHost(p)) { await notice(p, "設定", "§cテスト メニューと チートブックは ホスト（この ワールドを 作った ひと）だけ 使えます。\n§7ホストが 設定 →「テスト・チートを みんなに 許可」を オンに すると 使えます。"); continue; }
    else if (s === 8 && isRealHost(p)) { const v = world.getDynamicProperty("mrpg:cheatall") === true; world.setDynamicProperty("mrpg:cheatall", !v); await notice(p, "設定", !v ? "§aテスト・チートを みんなに 許可した。" : "§7テスト・チートは ホストだけに もどした。"); continue; }
    else if (s === 6) { const a = await testInner(p); if (a) { AFTER.set(p.id, a); await notice(p, "テスト", "§7メニューを 閉じると 移動します。"); } continue; }
    else if (s === 7) { if (await confirm(p, "チートブック", "§fチートブックを もらいますか？\n§7好きな モンスターを 仲間に したり 敵として 出したり できる 本です。ふつうに 遊ぶ ときは 使わない ほうが たのしめます。", "もらう", "やめる")) { giveItem(p, "mrpg:cheat_book", 1); sound(p, "random.pop"); } continue; }
    else return;
    sound(p, "random.click");
  }
}
// v1.7: セーブデータ（3スロット ＋ 自動バックアップ）
function bkText(m) {
  if (!m) return "§8（空き）";
  const dt = new Date(m.t), pad = (x) => String(x).padStart(2, "0");
  return `§f${dt.getMonth() + 1}/${dt.getDate()} ${pad(dt.getHours())}:${pad(dt.getMinutes())} §7v${m.ver}  モンスター${m.mons}体・最高Lv${m.lv}・${gold(m.gold)}`;
}
// v2.9.10: 手動の セーブは なくした（データは ワールドの 中に 自動で 保存される）。もしもの ときの 自動バックアップから もどす だけ
// v2.9.12: 人に わたした（おくった・交換・共有）あとは それより 前の バックアップに もどせない（ふえる ズルを ふせぐ）
function markXfer(p) { try { p.setDynamicProperty("mrpg:xferT", Date.now()); } catch {} }
export async function saveMenu(p) {
  const NM = { a: "自動バックアップ", 1: "スロット1（前の 版）", 2: "スロット2（前の 版）", 3: "スロット3（前の 版）" };
  const slots = BK_SLOTS.filter((k) => backupInfo(p, k));
  const body = ["§f冒険の データは ワールドの 中に 自動で 保存されて います（アドオンを 入れかえても 消えません）。", "§7ここは データが こわれた ときなどに、前の 状態へ もどす ための 場所です。", "§7自動バックアップは バージョンが 変わった とき・1日1回 ログイン時に 作られます。", LINE,
    ...(slots.length ? slots.map((k) => `§e${NM[k]}§r ${bkText(backupInfo(p, k))}`) : ["§8バックアップは まだ ありません。"])].join("\n");
  const k0 = await choose(p, "データを もどす", body, [...slots.map((k) => B(`§c${NM[k].replace("（前の 版）", "")}に もどす\n${bkText(backupInfo(p, k)).replace(/§./g, "").slice(0, 34)}`, ICON("i_back"))), B("§7戻る", ICON("i_back"))]);
  if (k0 < 0 || k0 >= slots.length) return;
  const k = slots[k0];
  { let gt = 0; try { gt = p.getDynamicProperty("mrpg:gotT") || 0; } catch {} const bi0 = backupInfo(p, k), cur0 = load(p);
    if (bi0 && gt > (bi0.t || 0) && cur0 && allMonsDeep(cur0).length) { await notice(p, "データを もどす", "§cこの バックアップの あとで 道具・装備を 受けとって いるので もどせません。\n§7（ほうびが ふえて しまう ため。データが こわれた ときは いつでも もどせます）"); return; } }   // v2.9.12
  { let xt = 0; try { xt = p.getDynamicProperty("mrpg:xferT") || 0; } catch {} const bi = backupInfo(p, k); if (bi && xt > (bi.t || 0)) { await notice(p, "データを もどす", "§cこの バックアップの あとで お金・モンスターを 人に わたしたり 売ったり しているので もどせません。§r\n§7（わたした ものが ふえて しまうのを ふせぐため）"); return; } }
  if (!(await confirm(p, "もどす", `§c§lいまの データは この 状態に 置きかわります。§r\n${bkText(backupInfo(p, k))}\n\n§7もどるのは モンスター・お金・図鑑・ストーリー。持ち物の アイテムは 変わりません（仲間の 装備は ぜんぶ 外れて バッグへ。お金は いまより ふえない）。`, "もどす", "やめる"))) return;
  { const bi = backupInfo(p, k); let used = []; try { used = JSON.parse(p.getDynamicProperty("mrpg:bkUsed") || "[]"); } catch {}
    if (bi && used.includes(bi.t)) { await notice(p, "データを もどす", "§cこの バックアップには もう 一度 もどしています。\n§7同じ バックアップに 何度も もどすと ほうびが ふえて しまうので、1回だけです。"); return; }
    if (bi) p.__bkMark = JSON.stringify([...used, bi.t].slice(-20)); }   // v2.9.12: 同じ バックアップは 1回だけ（読みこめたら 記録）
  try { recallPet(p, {}); } catch {}
  // v2.9.12: もどしても ふえない ように（お金は いまより 多く ならない・装備は いまの ものを バッグへ 外して、もどった 子は 装備なし）
  const cur = load(p), gold0 = cur && allMonsDeep(cur).length ? cur.gold : Infinity;   // v2.9.12: いまの データが こわれて いる ときは バックアップの お金の まま
  if (cur) { for (const mm of allMonsDeep(cur)) { for (const s of ["w", "a", "x"]) if (mm.eq && mm.eq[s]) giveGear(p, mm.eq[s], mm.eqr && mm.eqr[s]); mm.eq = { w: null, a: null, x: null }; mm.eqr = {}; } save(p, cur); }
  const d = backupLoad(p, k);
  if (!d) { await notice(p, "もどす", "§cデータが 壊れていて 読み込めませんでした。"); return; }
  for (const mm of allMonsDeep(d)) { mm.eq = { w: null, a: null, x: null }; mm.eqr = {}; const st = calcStats(mm); mm.hp = Math.min(mm.hp, st.hp); mm.mp = Math.min(mm.mp, st.mp); }
  d.gold = Math.min(d.gold || 0, gold0); save(p, d);
  try { if (p.__bkMark) p.setDynamicProperty("mrpg:bkUsed", p.__bkMark); } catch {}
  sound(p, "random.levelup", 1);
  await notice(p, "もどす", `§a${NM[k]} の データに もどしました。`);
}
/* 第103版: ゲームの 中で 見られる アップデート情報（新しい 順・短く） */
export const UPDATES = [
  ["第106版", "城下町・依頼・キャンプ・迷宮", ["町と 城を 大きく 作りなおした（城下町・坂と 丘・湖・港・大聖堂・広場の 噴水）。前の 町と 城は 近づくと 建てなおす", "城下町に 酒場・レストラン・冒険者協会。町の 人・冒険者・行商人が 道を 歩く（話しかけると ひとこと）", "冒険者協会の 依頼（F〜X級）: 討伐・納品・披露・調査・手配モンスター。ほうびは 種・進化石・石板・タマゴ。冒険者ランクが 上がると 上の 級が 受けられる", "キャンプ: ガイドブック → 冒険 →「キャンプ」。仲間 みんなが 出て 遊ぶ・なでる・いっしょに ごはん", "遊び場を 広く した。ボールは はねる ボールに。仲間 みんなが 島に 出る。相手の 速さを すこし ゆっくりに", "石板の 中を 広く した（64〜120マス）。高台・ワープ床・モンスターハウス・封印の 宝物庫", "ダメージの 計算を 見なおした（武系が 強すぎ・息系と 物理系が 弱かった）", "神系の ムラマサ・クワノトガル・ガルダバラの 見た目を 作りなおした（神話の 武器を 持つ 人外の 人型）", "物語を 全部 書きなおした（第1章〜終章と クリア後の お話）。物語の 戦いが ふえ、山場では モンスター同士が ぶつかる 演出が 入る", "物語の 人物・地方マスター・城の 王・町の 人に 顔（スキン）が ついた（約140人）", "NPCと 自由に 話せる: 町を 歩く 人は 話しかけると、ほかの 人は しゃがんで 話しかけると 入力欄が 出る", "町の トラブル（ナンパ・スリ・食い逃げ・酔っぱらい・迷子・カツアゲ・自称勇者）が ときどき 起きる", "海辺の 砂浜に 水着の 人たちが 出て 遊ぶ", "新しい モンスター: 虎の 武者 ビャッコマル（獣系・SS・二刀流。冒険者協会の 手配で 出会える）", "相棒を 配合すると 相棒だけが 生まれる（見た目・名前・きずなを 受けつぐ）"]],
  ["第105版", "不具合の 修正", ["遊び場へ 行こうと すると「石板・遺跡の 中や 戦いの 間は 行けない」と 出て 行けなかった のを 直した", "町や 城の 人が 2人に ふえる ことが あった のを 直した（町が 2回 建つ・城の 建てなおしで 古い 人が 残る・行商人などが 遠くで 消えずに 残る）。もう ふえて しまった 人も 1人に もどる"]],
  ["第104版", "総点検・迷宮・バランス", ["ゲームの 中で アップデート情報が 見られる ように した（この 画面）", "用語の 説明を 実際の 数値に 合わせて 直した・わかりにくい 文を 直した", "見つかった 不具合を 直した（1日の 上限が 入りなおすと もどる・きずなの 受けつぎ・名人の 呼びすぎ・残る 行商人 など）", "重さを へらした（戦いの 見はりを プレイヤーの 近くだけに）", "§d石板の 中を 迷宮に した§f: 部屋と 通路・見える モンスター（追う 子・逃げる 子）・鍵の 扉・近道の スイッチ・行き止まりの 宝箱・光る 採取（くわしくは 用語「石板と クリア後」）", "序盤の 強くなりすぎを おさえた（経験値の 上限・配合の 受けつぎ・野生戦の はじめの 強化）。§c息§f は 相手の 守りで へる ように", "道具を 使いやすく: 回復の 道具は 最大HPの 割合でも 回復・全回復で 道具も 使う・§e戦闘で 道具を 使っても 仲間の 行動は へらない§f。素材の 交換・作る 装備を ふやした", "技の 入れかえで 技を 選ぶと すぐ くわしく 見える。覚えた 固有技は 自動で 入る", "§aすべての モンスターに 体質§f（見た目に 合わせて 受ける ダメージを へらす。特性とは 別わく）", "ボスの HPを 1.5倍に", "§6戦いの 作戦を ふやした§f: 弱点と 会心で 守りを けずる §6ブレイク§f・だれでも 使える §6ためる§f・同じ 相手を 続けて 攻撃する §d連携と 連携技§f・戦う 場所の §f地形§f", "達人編・皆伝編の スキルを 150ptまで 振れる（150ptで 強い 特性）", "敵の かしこさ: ためる・ブレイクしそうな 相手や ブレイク中の 相手を ねらう", "§d相棒に ふれる§f: 連れ歩きの 子を たたくと なでる・抱っこ・高い高い・ぎゅっ・おしゃべり", "§d地方マスターと お見合い配合§f（勝った マスターに 話しかける・1日 3回）", "§b遊び場の 浮島§f（冒険 → 遊び場へ 行く）: ボールを 投げると 相棒が 取って くる・かけっこ・水泳・迷路・足場わたり・宝さがし・かくれんぼ・おにごっこ・相撲。行く ときは 持ち物の 道具を バッグへ しまう", "スキルの 見なおし（自分の 属性の スキルを 持つ 子は その 属性に 弱く ない など）"]],
  ["第102版", "町・きずな・探索の 追加", ["町に 旗・花壇・シンボル・季節の かざり。冒険 →「町の 広場」で 依頼・くじ・お祭り・発展度", "きずな（なつき度）: 連れ歩く・なでる・ごはん・いっしょに 戦う で 上がる。5段階。探索手帳 →「きずな」", "探索の 新しい 場所 24種・伝説の 秘宝・料理と 畑・レース・行商人・レーダー・ワープ石 など"]],
  ["第101版", "探索", ["冒険 →「探索手帳」: 地方ごとの 秘境・展望台・踏破率・素材の 交換", "採集ポイント・化石・環境の レア・異常気象・賞金首・迷子の モンスター・流れ星・なぞの 地図", "ライドの 熟練度（走った きょりで 速く なる）"]],
  ["第100版", "HPの 上限なし・軽量化", ["HPの 上限を なくした", "建物の 配置を つめて 軽く した"]],
];
async function updatesMenu(p) {
  const s = await choose(p, "アップデート情報", `§fいまの 版: §e${VERSION}\n§7見たい 版を えらぶ`, [...UPDATES.map((u) => B(`§l${u[0]}\n§8${u[1]}`, ICON("i_star"))), B("§7戻る", ICON("i_back"))]);
  if (s < 0 || s >= UPDATES.length) return;
  await notice(p, `${UPDATES[s][0]}（${UPDATES[s][1]}）`, UPDATES[s][2].map((x) => `§e・§f${x}`).join("\n"));
}
async function adventureMenu(p, d) {
  for (;;) {
    const town = townAt(p.location);
    const s = await choose(p, "冒険", town ? `§fいま §e${town.name}§f に います。` : "§7ショップと 宿屋は 街の なかで 使えます。", [
      B("§bワープ", ICON("i_run")), B(town ? "ショップ" : "§7ショップ", ICON("i_shop")), B(town ? "宿屋" : "§7宿屋", ICON("i_inn")),
      B("図鑑", ICON("i_zukan")), B("遊び方", ICON("i_help")), B(`設定 §8${isLite() ? "軽量モード" : ""}`, ICON("i_skill")), B("§e§l地図・コンパス\n§8町・遺跡・祭壇の 方向", ITEM_ICON("navi")), B("§c§lバグを 直す\n§8動けない・本が 開かない など", ICON("i_help")), B("§a§l探索手帳\n§8秘境・踏破率・賞金首・素材", ICON("i_zukan")), B(town ? "§6§l町の 広場\n§8依頼・くじ・お祭り・発展度" : "§7町の 広場\n§8町の 中で 使える", ICON("i_shop")), B("§b§l遊び場へ 行く\n§8ボール・かけっこ・迷路・かくれんぼ など", ICON("i_run")), B("§6§lキャンプ\n§8仲間みんなと ごはん・ボール遊び", ICON("i_inn")), B("§7戻る", ICON("i_back"))]);
    if (s === 7) { await repairFlow(p); continue; }   // v2.9.13
    if (s === 10) { if (EXH.isle) { await EXH.isle(p); return; } continue; }   /* 第104版: 遊び場 */
    if (s === 11) { if (EXH.camp) { await EXH.camp(p); return; } continue; }   /* 第106版: キャンプ */
    if (s === 8) { if (EXH.menu) await EXH.menu(p, load(p) || d); continue; }   /* 第101版: 探索手帳 */
    if (s === 9) { if (town && EXH.town) { const after = await EXH.town(p, load(p) || d, town); if (typeof after === "function") return after; } else await notice(p, "町の 広場", "§7町の 中で 使えます。"); continue; }   /* 第102版 */
    if (s === 6) { await naviMenu(p, d); if (!countItem(p, "mrpg:navi")) { giveItem(p, "mrpg:navi", 1); p.sendMessage("§e冒険のコンパスを わたした（持っていなかったので）"); } continue; }
    if (s === 0) await warpMenu(p, d);
    else if (s === 1) { if (town) await shopMenu(p, d); else await notice(p, "ショップ", "§7ショップは 街の なかで 使えます。\n街の 店の ひとに 話しかけても かえます。"); }
    else if (s === 2) { if (town) await innMenu(p, d); else await notice(p, "宿屋", "§7宿屋は 街の なかで 使えます。"); }
    else if (s === 3) await zukanMenu(p, d);
    else if (s === 4) { const h = await choose(p, "遊び方", "§f見たい ものを えらぶ", [B("§l遊び方", ICON("i_help")), B("§e§lアップデート情報\n§8新しく なった こと", ICON("i_star")), B("§7戻る", ICON("i_back"))]); if (h === 0) await notice(p, "遊び方", HELP); else if (h === 1) await updatesMenu(p); }
    else if (s === 5) await settingsMenu(p);
    else return;
  }
}
// v2.9.12: 物語の ネタバレ（人物・できごと・クリア後の 敵）は 物語を 見届けるまで かくす
export const SPOIL = /抜き身|悪夢|ヴァルグレイド|厄王|参謀|裏切|カゲツ|閻魔|エンマ|魔神の 柄|魔神の鍔|魔神編|冥府教団|邪刀|常世の刀|裏ボス|ラスボス|伝説の マスター|ムサシ|ラグナの 決戦|石板の ?王(?!冠)|濡れ衣|地下牢|牢屋|双子の 幹部|ロウ＆ルウ|ヴァルグレイド|覇剣王/;   // v2.9.12: 物語の しかけ・クリア後だけ（ふつうの 遊び方は かくさない）
// v3.0: 物語の ネタバレは 段階で 見せる（クリア前は 全部 かくす・魔神編の 中身は 魔神編が おわるまで かくす）
export const SPOIL_MAJIN = /魔神の 柄|魔神の鍔|魔神編|冥府教団|ムサシ|エンマ|取り憑|閻魔の 裁き|悪夢|抜き身|邪刀|常世の刀/;
const spLv = (p) => { try { const d = load(p); if (!d || !endingDone(d)) return 0; return d.story && d.story.enmaClear ? 2 : 1; } catch { return 0; } };
export const spTest = (x, lv) => { const t = String(x).replace(/§./g, ""); return lv >= 2 ? false : lv === 1 ? SPOIL_MAJIN.test(t) : SPOIL.test(t); };
export const spoilOK = (p) => spLv(p) >= 2;
export const spoilLv = spLv;
export const isSpoil = (x) => SPOIL.test(String(x).replace(/§./g, ""));
export const spoilCut = (p, lines) => { const lv = spLv(p); return lv >= 2 ? lines : lines.filter((x) => !spTest(x, lv)); };

async function chooseStarter(p) {
  // 王・神 以外の すべての 系統から、F・E・D ランクの 3たいずつ
  const fams = FAMILIES.filter((f) => f.id !== "king" && f.id !== "god");
  const cand = (fid) => ["F", "E", "D"].map((r) => ORDER.find((x) => SPECIES[x].fam === fid && SPECIES[x].rank === r && !SPECIES[x].giant)).filter(Boolean);
  let pickSid = null;
  while (!pickSid) {
    const f = await paged(p, "仲間を 選ぶ", "§f最初の 仲間を えらぼう！\n§7まず 系統を 選んでください（どの 系統も F・E・D の 3たいから 選べる）",
      fams.map((x) => B(`§l${FAM_COLOR[x.id] || ""}${x.name}\n§8${cand(x.id).map((y) => SPECIES[y].name).join("・")}`, MON_ICON(cand(x.id)[0]))), 7);
    if (f < 0) return null;
    const list = cand(fams[f].id);
    const body = list.map((id) => `${rankOf(id)} §l§e${SPECIES[id].name}§r §7（${SPECIES[id].sz}サイズ）\n§7スキル: ${SPECIES[id].skills.map((k) => SKILLS[k].name).join(" / ")}\n§7特性: ${traitNames(id).join("・")}\n${affText(id)}`).join("\n\n");
    const k = await choose(p, fams[f].name, body, [...list.map((id) => B(`${rankOf(id)} §l${SPECIES[id].name}`, MON_ICON(id))), B("§7系統を 選びなおす", ICON("i_back"))]);
    if (k >= 0 && k < list.length && await confirm(p, "仲間を 選ぶ", `${rankOf(list[k])} §l§e${SPECIES[list[k]].name}§r を 最初の 仲間に しますか？`, "この こに する", "やめる")) pickSid = list[k];
  }
  const m = makeMonster(pickSid, 1, false);
  m.pts = m.sk.map(() => 0); m.spl = 10;   // v2.9.12: 最初の 仲間は SP 10
  try { autoSP({ party: [m], box: [], bench: [] }, "near", [m]); const c0 = calcStats(m); m.hp = c0.hp; m.mp = c0.mp; } catch {}   // v3.0: 最初の 仲間は SPを 自動で 振って おく（はじめての 戦いで つまずかない）
  const d = { v: 3, party: [m], bench: [], box: [], seen: [], own: [], out: m.id, gold: 3000, stats: { wins: 0, pvp: 0, fused: 0 } };
  mark(d.own, m.sp); mark(d.seen, m.sp);
  save(p, d);
  spawnPet(p, m);
  giveItem(p, "mrpg:c_herb", 5); giveItem(p, "mrpg:t_bell", 2); giveItem(p, "mrpg:e_white", 1); giveItem(p, "mrpg:rod0", 1);
  await notice(p, "たびだち", `§e${m.nm}§rが 仲間に なった！\n\n§fお祝いに スキルポイント10、${gold(3000)}、いやし草5個、スカウトの鈴2個、しろのタマゴ、竹の釣竿を もらった。\n\n§7${m.nm}は あなたに ついてきます。そばで 使う（右クリック）と ライドできます。\n\n§bSPの 10は 自動で 振って おきました。§7あとで ふえた SPは「§f仲間 → スキルポイントを 振る§7」で 振ろう（設定で 自動にも できる）。`);
  if (await confirm(p, "相棒を つくろう", "§fさらに、自分だけの §b相棒モンスター§f を 作れます！\n§7体・頭・顔・ツノ・つばさ・しっぽ・マント・武器・色・性格・初期スキルを 自由に えらべます。\n§7（あとで 仲間 →「相棒」からでも 作れます）", "いま つくる", "あとで")) {
    await partnerEditor(p, d, null);
  }
  return d;
}

/* 第71版: 預かり所の 並べかえ・一覧の ページを おぼえる */
const BOX_MEM = new Map();
const boxMem = (p, k) => { const key = `${p.id}:${k}`; if (!BOX_MEM.has(key)) BOX_MEM.set(key, {}); return BOX_MEM.get(key); };
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { for (const k of [...BOX_MEM.keys()]) if (k.startsWith(playerId + ":")) BOX_MEM.delete(k); } catch {} }); } catch {}
globalThis.__mqClearMem = (pid) => { let n = 0; for (const M of [BOX_MEM, PAGE_MEM]) for (const k of [...M.keys()]) if (k.startsWith(pid + ":")) { M.delete(k); n++; } return n > 0; };   /* 第71版: バグを 直す から 消せる */
async function boxSort(p, d) {
  const keys = [["レベルが 高い 順", (a, b) => (b.lv || 0) - (a.lv || 0)], ["ランクが 高い 順", (a, b) => rankIdx(b.sp) - rankIdx(a.sp) || (b.lv || 0) - (a.lv || 0)],
    ["系統ごと", (a, b) => String(SPECIES[a.sp]?.fam).localeCompare(String(SPECIES[b.sp]?.fam)) || rankIdx(b.sp) - rankIdx(a.sp)], ["名前順", (a, b) => String(a.nm).localeCompare(String(b.nm), "ja")],
    ["＋値が 高い 順", (a, b) => (b.plus || 0) - (a.plus || 0) || (b.lv || 0) - (a.lv || 0)], ["新しく 来た 順", null]];
  const k = await choose(p, "並べかえ", `§7預かり所 ${d.box.length}たい を 並べかえます`, [...keys.map(([n]) => B(n, ICON("i_skill"))), B("§7やめる", ICON("i_back"))], false);
  if (k < 0 || k >= keys.length) return;
  if (keys[k][1]) d.box.sort(keys[k][1]); else d.box.reverse();   // その場で 並べかえる（一覧と 同じ 配列）
  save(p, d); boxMem(p, "box").page = 0; sound(p, "random.orb");
}
async function listMenu(p, d, list, t) {
  for (;;) {
    if (!list.length) { await notice(p, t, list === d.bench ? "§7裏（スタンバイ）には まだ だれも いません。\n§f仲間 → パーティ（表）や 預かり所の モンスターを えらんで「裏（スタンバイ）へ」で 入れられます。" : "モンスターは いません。"); return; }
    const head0 = `§7モンスターを 選んでください（${list.length}たい）${list === d.party ? `\n§f表の パーティ（戦う メンバー・${partyUse(d)}/4枠  S=1 M=2 L=3 G=4）` : list === d.bench ? `\n§b裏（スタンバイ・${benchUse(d)}/4枠）§7 表が 全員 倒れたら 出る。戦いの 中で「表と 裏を 入れかえ」も できる` : ""}`, g3 = pagedGrid(head0, list.length, 1);   /* 第73版: マス目なら メーターを 3行目に */
    const items = list.map((m) => { const st = calcStats(m); return B(`${m.id === d.out ? "§b★" : ""}${monName(m)}${m.spl ? " §6SP!" : ""}\n${monInfo(m)}${g3 ? "\n" : " "}${m.hp <= 0 ? "§c倒れ" : meter(m.hp, st.hp, 6)}`, MON_ICON(m.sp)); });
    const sel = await paged(p, t, head0, items, 8, list === d.box ? [B("§e並べかえ\n§8レベル・ランク・系統・名前", ICON("i_skill"))] : [B("§e表と 裏を まるごと 入れかえ", ICON("i_fuse"))], boxMem(p, list === d.box ? "box" : t));
    if (sel === -2 && list === d.box) { await boxSort(p, d); continue; }   /* 第70版 */
    if (sel === -2 && list !== d.box) {   /* 第71版: 表と 裏を まるごと 入れかえ */
      if (!(d.bench || []).length) { await notice(p, "入れかえ", "§7裏（スタンバイ）に だれも いません。"); continue; }
      if (!(await confirm(p, "入れかえ", `§f表（${d.party.map((x) => x.nm).join("・")}）と\n裏（${d.bench.map((x) => x.nm).join("・")}）を まるごと 入れかえますか？`, "入れかえる", "やめる"))) continue;
      if (!(d.bench || []).length) continue;
      const t0 = d.party; d.party = d.bench; d.bench = t0; try { fixParty(d); } catch {}
      if (d.out && !d.party.some((x) => x.id === d.out)) recallPet(p, d);
      save(p, d); sound(p, "random.pop"); await notice(p, "入れかえ", "§a表と 裏を 入れかえた！"); return;
    }
    if (sel < 0) return;
    await monMenu(p, d, list, sel);
  }
}

async function monMenu(p, d, list, idx) {
  for (;;) {
    const m = list[idx];
    if (!m) return;
    const inParty = list === d.party, inBench = list === d.bench;
    const sel = await choose(p, m.nm, monSummary(m), [B(`§lスキルを 振り分ける${m.spl ? " §6SP" + m.spl : ""}`, ICON("i_skill")), B("装備を かえる", ICON("i_equip")),
      B(`技・特性・詳しく\n§8戦いで 使う 技 ${moveSetSummary(m).replace(/§./g, "")}`, ICON("i_zukan")), B("名前を かえる", ICON("i_help")), B(inParty || inBench ? "あずける" : "パーティに 入れる", ICON("i_box")), B("§cわかれる", ICON("i_close")), B("§e入れ替え\n§8ほかの 1体と 交換", ICON("i_fuse")), B(`§d進化・覚醒${canEvolveNow(m) ? " §6!" : ""}\n§8${m.noevo ? "進化しない 設定" : "進化する 設定"}`, ICON("i_star")), B(`§b才能 §8${talTotal(m)}/${TAL_MAX * STATS.length}\n§8能力ごとの 才能を みる`, ICON("i_scout")), B(inBench ? "§a表（パーティ）へ 出す" : "§b裏（スタンバイ）へ\n§8表が 倒れたら 出る 控え", ICON("i_party")), B("§7戻る", ICON("i_back"))]);
    if (sel === 0) await allocMenu(p, d, m);
    else if (sel === 1) await equipMenu(p, d, m);
    else if (sel === 2) { const k = await choose(p, m.nm, "§7どちらを 見ますか？", [B("技・特性・詳しく 見る", ICON("i_zukan")), B(`§l戦いで 使う 技を えらぶ（6つまで）\n§8${moveSetSummary(m).replace(/§./g, "")}`, ICON("i_fight")), B("§7戻る", ICON("i_back"))]); if (k === 0) { for (;;) { const v = await choose(p, m.nm, monText(m), [B("§lOK", ICON("i_back")), ...m.sk.map((k2) => B(`§bスキル「${SKILLS[k2]?.name}」の 技`, ICON("i_spell")))]); if (v >= 1 && v <= m.sk.length) { await skillMovesView(p, m.sk[v - 1]); continue; } break; } } else if (k === 1) await moveSetMenu(p, m, () => save(p, d)); }   // v3.0
    else if (sel === 3) {
      const v = await modal(p, "名前を かえる", (f) => f.textField("新しい 名前（10もじまで）", m.nm, m.nm));
      const n = v && Array.from(String(v[0] || "").trim()).slice(0, 10).join("");   // v2.9.12: 絵文字を 半分で 切らない
      if (n) { m.nm = n.replace(/§/g, "") || m.nm; save(p, d); if (d.out === m.id) refreshPet(p, d); }
    } else if (sel === 4) {
      if (inBench) {   // 第68版
        if (d.box.length >= BOX_MAX) { await notice(p, "あずける", "預かり所が いっぱいです。"); continue; }
        d.box.push(d.bench.splice(idx, 1)[0]);
      } else if (inParty) {
        if (d.party.length <= 1) { await notice(p, "あずける", "パーティが いなくなってしまいます。"); continue; }
        if (d.box.length >= BOX_MAX) { await notice(p, "あずける", "預かり所が いっぱいです。"); continue; }
        if (d.out === m.id) recallPet(p, d);
        d.box.push(d.party.splice(idx, 1)[0]);
      } else {
        if (!canJoin(d, m)) { if (await placeInto(p, d, m, "party")) return; continue; }   /* 第71版 */
        d.party.push(list.splice(idx, 1)[0]);
      }
      save(p, d); return;
    } else if (sel === 6) { await swapMenu(p, d, m); return; }
    else if (sel === 7) await evoMenu(p, d, m);
    else if (sel === 8) await talentMenu(p, d, m);
    else if (sel === 9) {   // 第68版: 表・裏の 移動
      if (await placeInto(p, d, m, inBench ? "party" : "bench")) return;   /* 第71版: 入らない ときは その場で 入れかえ */
      continue;
    }
    else if (sel === 5) {
      if (inParty && d.party.length <= 1) { await notice(p, "わかれる", "最後の 仲間とは わかれられません。"); continue; }
      if (m.storyMusashi && !(d.story && d.story.enmaClear)) { await notice(p, "わかれる", "§cムサシ§f「おいおい、エンマに ケリ つけるまでは 離れねえぞ！」"); continue; }   // v2.9.14
      if (await confirm(p, "わかれる", `§c${m.nm}と 本当に わかれますか？\nもとに もどせません。§r${SPECIES[m.sp]?.deity !== undefined ? "\n§4§l神は 二度と 手に 入りません！" : ""}\n§7装備は 戻ってきます。`, "わかれる", "やめる")) {
        if (d.out === m.id) recallPet(p, d);
        for (const s of ["w", "a", "x"]) if (m.eq[s]) giveGear(p, m.eq[s], m.eqr && m.eqr[s]);
        list.splice(idx, 1); save(p, d);
        await notice(p, "わかれる", `${m.nm}は さっていった…`);
        return;
      }
    } else return;
  }
}

// v2.2: 才能（0〜31）の 判定と 才覚の珠
export function talentText(m) {
  const L = [`§l§e${m.nm} の 才能§r`, LINE];
  for (const k of STATS) { const v = (m.tal && m.tal[k]) ?? 16; L.push(`§f${ST_NAME[k]} ${meter(v, TAL_MAX, 10, "§b")} §e${String(v).padStart(2, " ")}§7/31  ${talLabel(v)}`); }
  L.push(LINE, `§f総合 §e${talTotal(m)}§7/${TAL_MAX * STATS.length}  ${talTotalLabel(m)}`);
  L.push("§7才能が 高いほど その 能力が のびる（最大 +8%・無才は -8%）。配合で 親の 才能を 3つ（4体配合は 5つ）受けつぐ");
  return L.join("\n");
}
async function talentMenu(p, d, m) {
  for (;;) {
    const n1 = countItem(p, "mrpg:i_tal1"), n9 = countItem(p, "mrpg:i_tal9");
    const s = await choose(p, "才能", talentText(m), [B(`§f才覚の銀珠を 使う §8×${n1}\n§8能力を 1つ 選んで 優秀／無才に`, ITEM_ICON("i_tal1")), B(`§6才覚の金珠を 使う §8×${n9}\n§8すべての 能力を 優秀／無才に`, ITEM_ICON("i_tal9")), B("§7戻る", ICON("i_back"))]);
    if (s === 0 || s === 1) { const id = s === 0 ? "i_tal1" : "i_tal9"; if (!countItem(p, `mrpg:${id}`)) { await notice(p, "才能", `§c${ITEMS[id].name}を もっていません。§r\n§7遠くの 町の 店や、強い ボスの 落とし物で 手に はいる`); continue; } await talentItem(p, d, id, m); }
    else return;
  }
}
async function talentItem(p, d, id, m0) {
  const it = ITEMS[id];
  const m = m0 || await pickMon(p, d, `${it.name}を 誰に 使う？`, itemDesc(id));
  if (!m) return;
  m.tal = m.tal || {};
  let keys = [...STATS];
  if (it.mode === "one") {
    const k = await choose(p, it.name, talentText(m) + "\n§f才能を かえる 能力を 選んでください", [...STATS.map((k) => B(`${ST_NAME[k]} §e${m.tal[k] ?? 16} ${talLabel(m.tal[k] ?? 16)}`, ICON("i_skill"))), B("§7やめる", ICON("i_back"))]);
    if (k < 0 || k >= STATS.length) return;
    keys = [STATS[k]];
  }
  const w = await choose(p, it.name, `§f${keys.map((k) => ST_NAME[k]).join("・")} の 才能を どうする？\n§6優秀§f: 31（天賦）に する\n§8無才§f: 0 に する（あえて 能力を おさえたい 時に）`, [B("§6優秀に する（31）", ICON("i_star")), B("§8無才に する（0）", ICON("i_close")), B("§7やめる", ICON("i_back"))]);
  if (w !== 0 && w !== 1) return;
if (countItem(p, `mrpg:${id}`) <= 0) return;   // v2.9.12: 手ばなした 道具では 使えない
  if (keys.every((k) => (m.tal[k] ?? 16) === (w === 0 ? TAL_MAX : 0))) { await notice(p, it.name, "§7もう その 才能です。（道具は へらない）"); return; }   // v3.0 第63版
  for (const k of keys) m.tal[k] = w === 0 ? TAL_MAX : 0;
  const st = calcStats(m); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp);
  takeItem(p, `mrpg:${id}`); save(p, d); sound(p, "random.levelup");
  await notice(p, it.name, `§a${m.nm}の ${keys.length > 1 ? "すべての 能力" : ST_NAME[keys[0]]}の 才能が ${w === 0 ? "§6優秀（31）" : "§8無才（0）"}§a に なった！\n\n` + talentText(m));
}
// v2.2: 能力ランキング（Lv100・才能ふつう・性格補正なし・装備なしで くらべる）
let RANK_CACHE = null;
function rankTable() {
  if (RANK_CACHE) return RANK_CACHE;
  const rows = ORDER.filter((x) => !SPECIES[x].metalmon).map((sp) => { const st = calcStats({ sp, lv: 100, sk: [], pts: [], plus: 0, eq: {}, nat: -1, bonus: {}, tal: Object.fromEntries(STATS.map((k) => [k, TAL_MAX / 2])) }); return { sp, st, tot: STATS.reduce((a, k) => a + st[k], 0) }; });
  RANK_CACHE = rows; return rows;
}
async function rankingMenu(p, d) {
  for (;;) {
    const keys = ["tot", ...STATS];
    const k = await choose(p, "能力ランキング", "§7全モンスターの Lv100の 能力（才能ふつう・性格補正なし・装備なし）で くらべた ランキング", [...keys.map((x) => B(x === "tot" ? "§6§l総合ランキング" : `§f${ST_NAME[x]} ランキング`, ICON("i_zukan"))), B("§7戻る", ICON("i_back"))]);
    if (k < 0 || k >= keys.length) return;
    const key = keys[k], val = (r) => key === "tot" ? r.tot : r.st[key];
    const slvR = spLv(p), rows = [...rankTable()].filter((r) => slvR >= 2 || (!SPECIES[r.sp].hidden && !spTest(SPECIES[r.sp].name, slvR))).sort((a, b) => val(b) - val(a)).slice(0, 50);
    const sel = await paged(p, key === "tot" ? "総合ランキング" : `${ST_NAME[key]} ランキング`, "§7上位 50たい（● 仲間に した ことが ある）", rows.map((r, i) => B(GRID_ON ? `${i < 3 ? ["§6", "§f", "§c"][i] : "§7"}${i + 1}位 §e${val(r)} §f${d.own.includes(SPECIES[r.sp].idx) ? "●" : "○"}\n${SPECIES[r.sp].name}\n§8${SPECIES[r.sp].rank}・${SPECIES[r.sp].sz}` : `${i < 3 ? ["§6", "§f", "§c"][i] : "§7"}${i + 1}位 §f${d.own.includes(SPECIES[r.sp].idx) ? "●" : "○"} ${SPECIES[r.sp].name} §8${SPECIES[r.sp].rank}・${SPECIES[r.sp].sz}\n§e${val(r)}`, MON_ICON(r.sp))), 10);
    if (sel >= 0 && rows[sel]) { const r = rows[sel]; await notice(p, SPECIES[r.sp].name, [`§l${SPECIES[r.sp].name}§r（${SPECIES[r.sp].rank}ランク・${SPECIES[r.sp].sz}サイズ）`, ...STATS.map((x) => `§f${ST_NAME[x]} §e${r.st[x]}`), `§6総合 ${r.tot}`].join("\n")); }
  }
}

// v2.1: 進化する／しない・今すぐ 進化・進化の石・闘魔覚醒の 状態
async function evoMenu(p, d, m) {
  for (;;) {
    const sp = SPECIES[m.sp];
    const L = [`§l§e${m.nm}§r  §7${sp.name}・ランク${rankOfM(m)}${m.tm || m.awk ? " §5（闘魔覚醒）" : ""}・Lv${m.lv}・プラス値 +${m.plus || 0}`, LINE];
    if (sp.evo && SPECIES[sp.evo[0]]) L.push(`§fレベル進化: §dLv${sp.evo[1]}で ${SPECIES[sp.evo[0]].name}（${SPECIES[sp.evo[0]].rank}）${canEvolveNow(m) ? " §6← いま 進化できる！" : ""}`);
    else L.push("§7レベルでは 進化しない");
    if (sp.ievo && SPECIES[sp.ievo[0]]) L.push(`§f石で 進化: §6${ITEMS[sp.ievo[1]]?.name}§f を 使うと ${SPECIES[sp.ievo[0]].name}（${SPECIES[sp.ievo[0]].rank}）に`);
    L.push(`§f設定: ${m.noevo ? "§c進化しない§7（レベルが 上がっても そのまま。いつでも 手動で 進化できる）" : "§a進化する§7（レベルが 上がると 自動で 進化）"}`);
    const ab = awakenBlock(m);
    L.push(LINE, `§5闘魔覚醒: §f${ab ? "§7" + ab : "§d「闘魔覚醒の秘玉」で 覚醒できる！§f（能力 +25%・固有特性・その 子だけの 特性が 1.5倍・行動 +1・ダメージ上限なし・はじめに 全能力 +1段階・スキル枠 +1" + (sp.rank !== "SS" ? "・SSランクの 力" : "") + "）"}`);
    const btn = [B(m.noevo ? "§a進化する 設定に する" : "§c進化しない 設定に する", ICON("i_help"))];
    if (canEvolveNow(m)) btn.push(B(`§l§d今すぐ 進化する\n§8${SPECIES[sp.evo[0]].name}に`, ICON("i_star")));
    btn.push(B("§7戻る", ICON("i_back")));
    const s = await choose(p, "進化・覚醒", L.join("\n"), btn);
    if (s === 0) { m.noevo = !m.noevo; save(p, d); continue; }
    if (s === 1 && canEvolveNow(m)) {
      if (!(await confirm(p, "進化", `${m.nm}を ${SPECIES[sp.evo[0]].name}に 進化させますか？`, "進化する", "やめる"))) continue;
      const log = []; evolve(m, log, true); mark(d.own, m.sp); mark(d.seen, m.sp);
      for (const x of fixParty(d)) log.push(`§e${x.nm}は 大きくなって パーティの 枠に 入らないので 預かり所へ 移った。`);
      save(p, d); if (d.out === m.id) refreshPet(p, d); particle(p, "minecraft:totem_particle", 1.5); sound(p, "random.levelup");
      await notice(p, "進化", log.join("\n")); continue;
    }
    return;
  }
}
// v2.1: スキル書を 使う（枠が いっぱいなら 忘れる スキルを 選ぶ）
async function skillBookFlow(p, d, id) {
  const it = ITEMS[id]; const sk = it.skill;
  // v2.9.10: どんな 技・特性が あるか 先に 見られる
  for (;;) {
    const v = await choose(p, it.name, skillPreview(sk), [B("§l誰に 使うか えらぶ", ICON("i_party")), B("§b技の くわしい 効果を 見る", ICON("i_spell")), B("§7やめる", ICON("i_back"))]);
    if (v === 1) { await skillMovesView(p, sk); continue; }
    if (v !== 0) return;
    break;
  }
  const m = await pickMon(p, d, `${it.name}を 誰に 使う？`, `§b${SKILLS[sk]?.name || ""}§7 を 覚えさせる`, false, true);
  if (!m) return;
  const log = [];
  const ui = m.sk.findIndex((x) => lineOf(x) && lineOf(x) === lineOf(sk));
  const upg = ui >= 0 && (SKILLS[sk].tier || 0) > (SKILLS[m.sk[ui]]?.tier || 0);   // 第67版: 上の 編の 書は その場で 入れかえ
  if (ui >= 0 && !upg) { await notice(p, it.name, `§7${m.nm}は もう 同じか 上の 編の スキル（${SKILLS[m.sk[ui]]?.name}）を 持っている。`); return; }
  let lostTxt = "";
  if (upg) { try { const cp = { ...m, sk: [...m.sk] }; cp.sk[ui] = sk; const a2 = getMoves(cp), ls = getMoves(m).filter((x) => !a2.includes(x)); if (ls.length) lostTxt = `\n§c使えなく なる 技: ${ls.map((x) => MOVES[x]?.name || x).join("・")}`; } catch {} }
  if (upg && !(await confirm(p, it.name, `§f${m.nm}の §b${SKILLS[m.sk[ui]].name}§f を §a${SKILLS[sk].name}§f に 入れかえます。\n§7振った ${m.pts[ui] || 0}pt は そのまま 引きつぎます。${lostTxt}`, "入れかえる", "やめる"))) return;
  const n = slotN(m);   // v2.9.12: 固有スキルの 子は 1つ 多い
  let rep = null;
  if (!upg && m.sk.length >= n) {
    for (;;) {
      const s = await choose(p, "忘れる スキル", `§f${m.nm}の スキルの 枠は ${n}つで いっぱいです。\n§7忘れる スキルを 選んでください（振った SPは 戻ってきます）\n§f覚える: §b${SKILLS[sk].name}`,
        [...m.sk.map((x, i) => B(`${SKILLS[x].name}\n§8${m.pts[i]}pt 振っている`, ICON("i_skill"))), B("§b覚える スキルの 技を 見る", ICON("i_spell")), B("§7やめる", ICON("i_back"))]);
      if (s === m.sk.length) { await skillMovesView(p, sk); continue; }
      if (s < 0 || s >= m.sk.length) return;
      // 第67版: 忘れる スキルと 覚える スキルを 見くらべてから 決める
      let c;
      for (;;) {   /* 第67版: 技を 見たら 見くらべ画面に もどる */
        c = await choose(p, "スキルの 入れかえ", [`§c忘れる: §f${SKILLS[m.sk[s]].name} §8（${m.pts[s]}pt → SP ${m.pts[s]} 戻る）`, `§a覚える: §f${SKILLS[sk].name}`, LINE, skillPreview(m.sk[s])].join("\n"),
          [B("§l入れかえる", ICON("i_skill")), B("§b忘れる スキルの 技を 見る", ICON("i_spell")), B("§b覚える スキルの 技を 見る", ICON("i_spell")), B("§7選びなおす", ICON("i_back"))]);
        if (c === 1) { await skillMovesView(p, m.sk[s]); continue; }
        if (c === 2) { await skillMovesView(p, sk); continue; }
        break;
      }
      if (c !== 0) continue;
      rep = s; break;
    }
  }
if (countItem(p, `mrpg:${id}`) <= 0) return;   // v2.9.12: 手ばなした 道具では 使えない
  if (!learnSkill(m, sk, rep, log)) { await notice(p, it.name, log.join("\n")); return; }
  takeItem(p, `mrpg:${id}`); save(p, d); sound(p, "random.levelup");
  await notice(p, it.name, log.join("\n"));
}

// v2.7: 同じ ポイントの ごほうびを まとめる（物力＋武力 など）
function skGroups(t) { const g = new Map(); for (const e of t.list) { if (!g.has(e.pt)) g.set(e.pt, []); g.get(e.pt).push(e); } return [...g.entries()]; }
export function skEntryText(t, pt) {
  const es = t.list.filter((e) => e.pt === pt);
  const L = es.filter((e) => e.move).map((e) => MOVES[e.move]?.name).concat(es.filter((e) => e.trait).map((e) => `特性【${TRAITS[e.trait]?.name}】`));
  const st = es.filter((e) => e.stat); if (st.length) L.push(st.every((e) => e.val === st[0].val) ? st.map((e) => ST_NAME[e.stat]).join("＋") + "+" + st[0].val : st.map((e) => ST_NAME[e.stat] + "+" + e.val).join("・"));
  return L.join("・");
}
// スキル振り分け: ツリーを 選ぶ → 何が もらえるか 見ながら 振る
function treeView(m, i) {
  const t = SKILLS[m.sk[i]];
  const pts = m.pts[i];
  const L = [`§l§b${t.name}§r  ${meter(pts, skMax(m.sk[i]), 20, "§b")} §e${pts}§7/${skMax(m.sk[i])}`];
  const nextPt = t.list.find((x) => x.pt > pts)?.pt;
  for (const [pt, es] of skGroups(t)) {
    const got = pts >= pt;
    const what = es.map((e) => e.move ? `${MOVES[e.move].name} §8${moveTag(e.move)}` : e.trait ? `§d特性【${TRAITS[e.trait]?.name}】 §8${TRAITS[e.trait]?.desc || ""}` : null).filter(Boolean);
    const st = es.filter((e) => e.stat); if (st.length) what.push(st.every((e) => e.val === st[0].val) ? st.map((e) => ST_NAME[e.stat]).join("＋") + ` +${st[0].val}` : st.map((e) => `${ST_NAME[e.stat]} +${e.val}`).join("・"));
    L.push(`${got ? "§a○" : pt === nextPt ? "§e→" : "§8・"} §7${String(pt).padStart(3, " ")}pt  ${got ? "§f" : "§7"}${what.join(" §7/§r ")}${!got && pt === nextPt ? ` §6(あと${pt - pts})` : ""}`);
  }
  if (t.next && SKILLS[t.next]) L.push(pts >= 100 ? `§d★ 100まで 振った！ 配合すると「${SKILLS[t.next].name}」に 進化して 引き継げる` : `§8（100まで 振って 配合すると「${SKILLS[t.next].name}」に 進化）`);
  return L.join("\n");
}
async function allocMenu(p, d, m) {
  let msgs = [];
  for (;;) {
    const body = [`§l${m.nm}§r の スキル    残りSP §e§l${m.spl}`, ...msgs, LINE,
      ...m.sk.map((k, i) => {
        const next = SKILLS[k].list.find((e) => e.pt > m.pts[i]);
        return `§b${SKILLS[k].name}§r ${meter(m.pts[i], skMax(k), 10, "§b")} §e${m.pts[i]}\n  ${next ? `§7次: §f${skEntryText(SKILLS[k], next.pt)} §7（あと${next.pt - m.pts[i]}）` : "§6コンプリート！"}`;
      }), LINE, "§7振り分けたい スキルを 選んでください"].join("\n");
    msgs = [];
    const sel = await choose(p, "スキル 振り分け", body, [...m.sk.map((k, i) => B(`§l${SKILLS[k].name}§r §8${m.pts[i]}/${skMax(k)}`, ICON("i_skill"))),
      B("§dおまかせで 全部 振る", ICON("i_fuse")), B("§bバーで まとめて 振る", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    const NK = m.sk.length;
    if (sel < 0 || sel === NK + 2) return;
    if (sel === NK + 1) {
      if (!m.spl) { msgs = ["§cSPが ありません"]; continue; }
      const v = await modal(p, `スキル（残りSP ${m.spl}）`, (f) => m.sk.forEach((k, i) => f.slider(`${SKILLS[k].name} §7(いま ${m.pts[i]})`, m.pts[i], Math.max(m.pts[i] + 1, Math.min(skMax(k), m.pts[i] + m.spl)), 1, m.pts[i])));
      if (!v) continue;
      const vv = v.map((x, i) => Math.min(skMax(m.sk[i]), Math.floor(x))); const add = vv.reduce((s2, x, i) => s2 + (x - m.pts[i]), 0);
      if (add > m.spl) { msgs = [`§cSPが たりません（${add} つかおうとしました／残り ${m.spl}）`]; continue; }
      msgs = setPoints(m, vv); save(p, d); if (msgs.length) sound(p, "random.levelup");
      continue;
    }
    if (sel === NK) {
      if (!m.spl) { msgs = ["§cSPが ありません"]; continue; }
      if (!(await confirm(p, "おまかせで 全部 振る", `§f残りSP §e${m.spl}§f を ${m.sk.map((k) => SKILLS[k].name).join("・")} に 同じくらいずつ 振ります。\n§c振った SPは もとに もどせません。`, "振る", "やめる"))) continue;   // UX案
      const t = [...m.pts];
      let left = m.spl;
      while (left > 0) {
        const open = t.map((_, i) => i).filter((i) => t[i] < skMax(m.sk[i])); if (!open.length) break;
        const i = open.reduce((a, b) => (t[a] <= t[b] ? a : b)); t[i]++; left--;
      }
      msgs = setPoints(m, t); save(p, d); if (msgs.length) sound(p, "random.levelup");
      continue;
    }
    // 1つの ツリー
    for (;;) {
      const pts = m.pts[sel];
      const next = SKILLS[m.sk[sel]].list.find((e) => e.pt > pts);
      const room = Math.min(m.spl, skMax(m.sk[sel]) - pts);
      const btns = [];
      const acts = [];
      if (next && room >= next.pt - pts) { btns.push(B(`§l§e次の 褒美まで 振る §8(+${next.pt - pts})`, ICON("i_skill"))); acts.push(next.pt - pts); }
      for (const n of [1, 5, 10]) if (room >= n) { btns.push(B(`+${n}`, ICON("i_skill"))); acts.push(n); }
      if (room > 10) { btns.push(B(`最大まで §8(+${room})`, ICON("i_skill"))); acts.push(room); }
      if (room > 1) { btns.push(B("§bバーで 選ぶ", ICON("i_skill"))); acts.push("bar"); }
      btns.push(B("§b技の くわしい 効果を 見る", ICON("i_spell"))); acts.push("view");   // 第67版
      btns.push(B("§7戻る", ICON("i_back")));
      const s2 = await choose(p, SKILLS[m.sk[sel]].name, `§f残りSP §e§l${m.spl}§r\n${msgs.join("\n")}\n${treeView(m, sel)}${room <= 0 ? `\n\n§7${m.spl ? "このスキルは コンプリートしています。" : "SPが ありません。レベルを あげよう。"}` : ""}`, btns);
      msgs = [];
      if (s2 < 0 || s2 >= acts.length) break;
      let addN = acts[s2];
      if (addN === "view") { await skillMovesView(p, m.sk[sel]); continue; }
      if (addN === "bar") { const v = await modal(p, SKILLS[m.sk[sel]].name, (f) => f.slider(`振る ポイント §7(残りSP ${m.spl})`, 1, room, 1, Math.min(room, next ? next.pt - pts : room))); if (!v) continue; addN = Math.floor(v[0]); }
      const t = [...m.pts]; t[sel] += addN;
      msgs = setPoints(m, t); save(p, d);
      if (msgs.length) sound(p, "random.levelup");
    }
  }
}

async function walkMenu(p, d) {
  const auto = p.hasTag("mrpg_autoride");
  const sel0 = await choose(p, "連れ歩き・ライド", `§fライド操作: ${auto ? "§e自動前進（見ている 方向へ 進む）" : "§aふつう（WASDで 操作）"}\n§7WASDで 動かない ときは「自動前進」に 切りかえてください。下を 見ると 止まります。`,
    [B("§lモンスターを 出す・しまう", ICON("i_walk")), B(`ライド操作を「${auto ? "ふつう" : "自動前進"}」に する`, ICON("i_run")), B("§7戻る", ICON("i_back"))]);
  if (sel0 === 1) { if (auto) p.removeTag("mrpg_autoride"); else p.addTag("mrpg_autoride"); await notice(p, "ライド操作", auto ? "ふつうの 操作に 戻しました。" : "自動前進に しました。\n乗っている 間は 見ている 方向へ 進みます。下を 見ると 止まります（ひこうタイプは 下降）。"); return; }
  if (sel0 !== 0) return;
  const sel = await choose(p, "連れ歩き・ライド", "§fフィールドに 出す モンスターを 選んでください。\n§7だした モンスターに ちかづいて 使う（右クリック）と ライドできます。\n§7ひこうタイプは ジャンプか 上を 見ると 上昇、下を 見ると 下降します。",
    [...d.party.map((m) => B(`${monName(m)}${m.hp <= 0 ? " §c倒れ" : ""}\n${m.id === d.out ? "§b★出ている（選ぶと しまう）" : "§8" + rideInfo(m.sp, m).replace(/§./g, "")}`, MON_ICON(m.sp))), B("§7戻る", ICON("i_back"))]);
  if (sel < 0 || sel >= d.party.length) return;
  const m = d.party[sel];
  if (m.id === d.out) { recallPet(p, d); save(p, d); return; }
  if (m.hp <= 0) { await notice(p, "連れ歩き", "倒れている モンスターは だせません。"); return; }
  recallPet(p, d); d.out = m.id; try { noteWalk(d, m); } catch {} save(p, d); spawnPet(p, m);
}

// ---------- 道具 ----------
const KIND_NAME = { weapon: "武器", armor: "防具", acc: "アクセサリー", egg: "タマゴ", heal: "回復", healall: "回復", fullall: "回復", mpheal: "回復",
  cure: "回復", revive: "回復", seed: "せいちょう", lvup: "せいちょう", exp: "せいちょう", sp: "せいちょう", respec: "せいちょう",
  scout: "バトル", bbuff: "バトル", escape: "バトル", bomb: "バトル", call: "冒険", warp: "冒険", money: "お金", rod: "釣り", treasure: "お宝",
  nature_rand: "厳選", nature_pick: "厳選", material: "素材",
  resize: "せいちょう", dream: "厳選", traitpick: "厳選", traitreroll: "厳選", tmap: "冒険", inherit: "厳選", limit: "せいちょう", plusup: "せいちょう", lvmax: "せいちょう", slab: "石板", bslab: "特別な石板", dslab: "特別な石板", xslab: "石板", key: "だいじなもの", mpall: "回復", reviveall: "回復", curall: "回復", bregen: "回復", bdebuff: "バトル", bstatus: "バトル", seedall: "せいちょう", matbox: "素材", reforge: "装備の 厳選" };
const ST_IM = AIL_NAME;
const CAT_N = CATS;
const WT_HELP = { weapon: (it) => `§6${WTYPES[it.wtype]}§7【${["一", "二", "三", "四"][it.wt]}段】${WKIND[it.wtype] ? ` §f${WKIND[it.wtype].depName}で 戦う・攻撃属性【${WKIND[it.wtype].attrName}】§7 ${WKIND[it.wtype].note}` : ""}`, armor: (it) => `§6${ATYPES[it.atype]}§7【${["一", "二", "三", "四"][it.wt]}段】`, acc: (it) => `§6${ACCT[it.atype] || ""}` };
function eqExtra(it) {
  const L = [];
  if (it.el) L.push(`ふつうの 攻撃が ${elTag(it.el)}§7属性に`);
  if (it.res) for (const [k, v] of Object.entries(it.res)) L.push(`${elTag(k)}${RESNAME[String(v)]}§7`);
  if (it.immune) L.push(`${ST_IM[it.immune] || it.immune}無効`);
  const fx = it.fx || {};
  if (fx.crit) L.push(`会心+${Math.round(fx.crit * 100)}%`);
  if (fx.evade) L.push(`回避+${Math.round(fx.evade * 100)}%`);
  if (fx.regen) L.push(`毎ターン HP${Math.round(fx.regen * 100)}%回復`);
  if (fx.lifesteal) L.push(`与えた ダメージの ${Math.round(fx.lifesteal * 100)}%を 吸収`);
  if (fx.pinch) L.push(`ピンチで 威力×${fx.pinch}`);
  for (const [k, v] of Object.entries(fx.dealt || {})) L.push(`${CAT_N[k] || (EL_NAME[k] ? EL_NAME[k] + "属性" : k)}の 威力+${Math.round(v * 100)}%`);
  for (const [k, v] of Object.entries(fx.onhit || {})) L.push(`攻撃で ${ST_IM[k]}${Math.round(v * 100)}%`);
  if (fx.metalkill) L.push(`ハガネ特効+${fx.metalkill}`);
  if (fx.antiflee) L.push("敵が 逃げにくい");
  if (fx.critdmg) L.push(`会心ダメージ+${Math.round(fx.critdmg * 100)}%`);
  if (fx.pierce) L.push(`硬力を ${Math.round(fx.pierce * 100)}% 無視`);
  if (fx.multi) L.push(`ときどき 2回 当たる ${Math.round(fx.multi * 100)}%`);
  if (fx.first_ch) L.push(`ときどき 先制 ${Math.round(fx.first_ch * 100)}%`);
  if (fx.halfmp_ch) L.push(`ときどき MP消費0 ${Math.round(fx.halfmp_ch * 100)}%`);
  if (fx.taken_all) L.push(`受ける ダメージ${Math.round(fx.taken_all * 100)}%`);
  if (fx.mpregen) L.push(`毎ターン MP${Math.round(fx.mpregen * 100)}%回復`);
  if (fx.first) L.push("いつも 先に 動ける");
  if (fx.first1) L.push(`1ターン目の 威力+${Math.round(fx.first1 * 100)}%`);
  if (fx.bigkill) L.push(`L・Gサイズに 威力+${Math.round(fx.bigkill * 100)}%`);
  if (fx.smallkill) L.push(`S・Mサイズに 威力+${Math.round(fx.smallkill * 100)}%`);
  if (fx.bloodlust) L.push(`HP半分 以下の 相手に 威力+${Math.round(fx.bloodlust * 100)}%`);
  if (fx.aoeup) L.push(`全体技の 威力+${Math.round(fx.aoeup * 100)}%`);
  if (fx.healboost) L.push(`回復の 力+${Math.round(fx.healboost * 100)}%`);
  if (fx.acc) L.push(`命中+${Math.round(fx.acc * 100)}%`);
  if (fx.slowfirst) L.push("遅いほど 先に 動ける");
  if (fx.nosealed) L.push("封印されない");
  if (fx.sturdy) L.push("HP満タンから 一撃では 倒れない");
  for (const [k, v] of Object.entries(fx.field || {})) L.push(`${{ exp: "経験値", gold: "お金", drop: "ドロップ" }[k] || k}+${Math.round(v * 100)}%`);
  return L.join(" ");
}
// v2.9.6: クラフトの 作り方・使いみち・手に 入る ところ
const VAN_NAME = { "minecraft:gold_ingot": "金インゴット", "minecraft:iron_ingot": "鉄インゴット", "minecraft:diamond": "ダイヤモンド", "minecraft:stick": "棒", "minecraft:string": "糸",
  "minecraft:gunpowder": "火薬", "minecraft:gold_nugget": "金塊", "minecraft:apple": "リンゴ", "minecraft:netherite_ingot": "ネザライト" };
const ingNm = (k) => k.startsWith("mrpg:") ? (ITEMS[k.slice(5)]?.name || k) : (VAN_NAME[k] || k.replace("minecraft:", ""));
let USES = null;
function usesOf(id) {
  if (!USES) { USES = {}; for (const [pid, need] of Object.entries(RECIPES)) for (const [k, n] of Object.entries(need)) if (k.startsWith("mrpg:")) (USES[k.slice(5)] ||= []).push([pid, n]); }
  return USES[id] || [];
}
export function craftInfo(id) {
  const it = ITEMS[id]; if (!it) return "";
  const L = [];
  if (RECIPES[id]) L.push(`§6作り方 §7（作業台 または ブック→クラフト）\n§f${Object.entries(RECIPES[id]).map(([k, n]) => `${ingNm(k)}×${n}`).join(" ＋ ")}`);
  const u = usesOf(id);
  if (u.length) {
    const KN = { weapon: "武器", armor: "防具", acc: "アクセ", material: "素材" };
    const kinds = {}; for (const [pid] of u) { const k = KN[ITEMS[pid]?.kind] || "道具"; kinds[k] = (kinds[k] || 0) + 1; }
    L.push(`§b使いみち §7（これを 使う レシピ ${u.length}こ: ${Object.entries(kinds).map(([k, n]) => `${k}${n}`).join("・")}）\n§f${u.slice(0, 6).map(([pid, n]) => `${ITEMS[pid]?.name || pid}(×${n})`).join("、")}${u.length > 6 ? ` §7ほか ${u.length - 6}こ` : ""}`);
  }
  if (it.kind === "material" || it.craft) {
    const fams = Object.entries(CRAFT_DROP || {}).filter(([, tiers]) => tiers.some((t) => t.includes(id))).map(([f]) => FAMILIES.find((x) => x.id === f)?.name || f);
    const f2 = it.fam && !fams.length ? [FAMILIES.find((x) => x.id === it.fam)?.name || it.fam] : [];
    if (fams.length || f2.length) L.push(`§a手に 入る ところ§f: ${[...fams, ...f2].join("・")}の モンスターが 落とす・宝箱`);
  }
  return L.join("\n");
}
export function itemDesc(id) {
  const it = ITEMS[id];
  switch (it.kind) {
    case "weapon": case "armor": case "acc": return [WT_HELP[it.kind](it), STATS.filter((k) => it[k]).map((k) => it[k] > 0 ? `${ST_COL[k]}${ST_NAME[k]}§f${minStat(id, k)}〜${maxStat(id, k)}` : `${ST_COL[k]}${ST_NAME[k]}§f${it[k]}`).join(" "), eqExtra(it)].filter(Boolean).join(" ") || "特別な 効果";
    case "key": return `§6だいじなもの§r。${it.desc || ""}（使っても なくならない）`;
    case "rod": return `釣竿（${["竹", "鉄", "金", "竜骨"][it.rod]}）。水に 向かって 使うと 釣りが できる。${["小魚や 道具", "お宝や 素材も", "めずらしい お宝や 強い モンスターも", "伝説の お宝や SSランクの モンスターも"][it.rod]}`;
    case "treasure": return `お宝。お店で ${it.val} ${CURRENCY}で 売れる`;
    case "material": return "クラフトの 素材（ブック→クラフト）";
    case "food": return `料理。食べると 次の 野生との 戦い 3回、能力が +1段階（${{ fd_stew: "物力・武力", fd_soup: "魔力・吹力", fd_curry: "全部", fd_cake: "走力", fd_tea: "硬力", fd_bento: "物力・走力", fd_egg: "魔硬力", fd_onigiri: "硬力・魔硬力" }[id] || ""}）`;
    case "snack": return "仲間 1体の なつき度 +60（なつき度が 高いと 戦いで 踏みとどまる）";
    case "homewing": return "いちばん 近い おとずれた 町へ もどる";
    case "chute": return "30秒 ゆっくり 落ちる";
    case "exmat": return "地方の 素材。光る 採集ポイントを こわすと 手に入る。探索手帳の「素材の 交換」で 道具に かえる";
    case "fossil": return "使うと 古代の 竜系か 物質系の モンスターが よみがえる（ランクは 物語の 進みまで・プラス値 +10）";
    case "rmap": return "使うと 宝の 場所が ことばで 書かれる（250〜450m 先）。40m まで 近づくと コンパスが 反応。着くと 宝箱";
    case "dream": return "モンスターの 固有特性（金色の 特性）を 目覚めさせる";
    case "traitpick": return "好きな 特性を 1つ えらんで 追加できる（1体に 1回だけ。行動回数・系統の王・固有特性・ロマン配合の 特性は えらべない）";
    case "traitreroll": return "モンスターの 特性を その 種族に 合う ものから 選びなおす（厳選）";
    case "plusup": return `プラス値を ${it.val} 上げる`;
    case "lvmax": return "レベルを 一気に 100に する";
    case "tmap": return "§e使い道§f: 使うと 300〜700m 先に しるしが うかぶ（画面の 下に 方角と きょり）。着くと 宝の 番人が 現れ、倒すと レアな 宝箱。行けない 場所なら もう一度 使うと しるしを 消せる\n§e入手§f: 強い 敵（ボス・マスター・Aランク以上）に 勝つと まれに（4%）・無限の塔 20階ごと（はじめて）・縛りの石板 クリア（35%）・今日の挑戦状 3日連続ごと・研究所（やりこみ → 研究所）";
    case "inherit": return "配合の とき、親の 特性を 1つ えらんで 子に 受けつがせる（子の 特性の どれかと 入れかわる）";
    case "limit": return "Lv100の 仲間の 能力を +4%（5段まで・合計 +20%）";
    case "slab": return `使うと ${["B", "A", "S", "SS"][it.slab]}ランクの ${it.sfam ? (FAMILIES.find((f) => f.id === it.sfam)?.name || "") + "の " : ""}石板ボスが 現れる（マルチOK・スカウトしやすい）`;
    case "dslab": { const G = DEITY[it.gi]; return G ? `${G.name}（${G.floors}階）が 眠る 神の 石板。触れると 中の 迷宮へ（${G.floors}階・中は SSランクの モンスター・最後の 階に 神）。神は とても 強い（Gサイズ・手持ちに 合わせた 強さ・HPが 半分に なると 1度だけ（ゲゼラは 2度）全回復して 全能力を 底上げ）。何も 落とさない かわりに 倒すと 低い 確率で 正気に もどり 仲間に なる（仲間に したら もう 戦えない）` : "神の石板"; }
    case "xslab": return it.x === "meet" ? "これまで 仲間に した モンスターと また 会える 石板。ランクを 選んで 使う（その ランクを たくさん 仲間に すると 開く・中の モンスターは Lv10・お金が かかる・なくならない）。クリア後" : it.x === "god" ? "神々（SS・X）が 待つ 神域へ 通じる 石板。勝つと なくなる。クリア後" : "王たち（SS）が 待つ 覇王の 闘技場へ 通じる 石板。勝つと なくなる。クリア後";
    case "bslab": { const b = BOSS_SLAB[it.bs]; return b ? `寂れた 謎の 石板。触れると 内側の 迷宮へ 引きこまれる（${b.floors}階・奥に 主「${b.title}」${b.rank}ランク）。主を たおすと 封印できる\n§7いつも バッグに 入って いる（ガイドブック → 道具・装備 → バッグ → 特別な石板 から 使う）` : "謎の 石板"; }
    case "egg": return "使うと モンスターが 生まれる";
    case "skillbook": { const sk = SKILLS[it.skill]; return sk ? `使うと スキル「${sk.name}」を 覚える。${sk.desc || ""}（スキルの 枠が いっぱいなら 1つ 忘れる）` : "スキルを 覚える"; }
    case "awaken": return "闘魔覚醒。プラス値 +99 以上の モンスター（神は のぞく）に 使うと、能力 +25%・固有特性が 目覚める・毎ターン 行動 +1（4回まで）・ダメージ上限（999）なし・戦いの はじめに 全能力 +1段階・スキル枠 +1。F〜Sランクは さらに SSランクの 力に";
    case "navi": return "使うと 町・遺跡・祭壇の 方向と きょりが わかる 地図が 開く。行き先を 選ぶと、着くまで 画面の 下に 矢印が 出る";
    case "talent": return it.mode === "one" ? "モンスターの 能力を 1つ 選び、その 才能を 天賦（31）か 無才（0）に する" : "モンスターの すべての 能力の 才能を 天賦（31）か 無才（0）に する";
    case "evostone": return `${FAMILIES.find((f) => f.id === it.fam)?.name || ""}の 決まった モンスターを 進化させる 石（ガイドブック→モンスター→進化・覚醒で 確認）`;
    case "resize": return it.to ? `サイズを ${it.to}に する（${{ S: "枠1・回避が 高い・大きい 子は 能力が 下がり 特性が 3つに", M: "枠2・2回行動・伸び 1.3倍", L: "枠3・2〜3回行動・物理が 全体・伸び 1.65倍", G: "枠4・3〜4回行動・物理が 全体で 2回攻撃・伸び 2.1倍" }[it.to]}）` : it.val > 0 ? "サイズが 1段 大きくなる（S→M→L）。強くなるが パーティの 枠を 使う" : "サイズが 1段 小さくなる（L→M→S）。パーティに たくさん 入れられる";
    case "mpall": return `みんなの MPを ${it.mp} 回復（バトルの 外でも 使える）`;
    case "reviveall": return `倒れた 仲間 全員を ${it.full ? "ぜんかいで " : ""}生き返らせる（バトルの 外でも 使える）`;
    case "curall": return "みんなの 状態異常を なおす（バトル中）";
    case "bregen": return `みんなが ${it.turns}ターン HPを 少しずつ 回復（バトル中）`;
    case "bdebuff": return `敵 全員の ${ST_NAME[it.stat]}を ${it.n || 1}だんかい 下げる（バトル中）`;
    case "bstatus": return `敵 全員を ${AIL_NAME[it.st]}に する（${Math.round(it.chance * 100)}%・バトル中）`;
    case "seedall": return it.rnd ? `すべての 能力が ずっと ${it.rnd[0]}〜${it.rnd[1]} 上がる（HP・MPは その 2倍）` : `すべての 能力が ずっと ${it.val} 上がる（HP・MPは ${it.val * 2}）`;
    case "matbox": return `${["ふつう", "レア", "ちょうレア"][it.mt]}の 素材が ${it.val}こ 出てくる`;
    case "heal": return it.hp >= 999 ? "1たいの HPを ぜんかいふく" : `1たいの HPを ${it.hp}${it.pct ? `か 最大の ${Math.round(it.pct * 100)}%（多い ほう）` : ""} 回復`;
    case "healall": return `みんなの HPを ${it.hp}${it.pct ? `か 最大の ${Math.round(it.pct * 100)}%（多い ほう）` : ""} 回復（バトルの 外でも 使える）`;
    case "fullall": return "みんなの HPと MPを ぜんかいふく（バトルの 外でも 使える）";
    case "mpheal": return it.mp >= 999 ? "1たいの MPを ぜんかいふく" : `1たいの MPを ${it.mp}${it.mpct ? `か 最大の ${Math.round(it.mpct * 100)}%（多い ほう）` : ""} 回復`;
    case "cure": return it.cures ? `${AIL_NAME[it.cures[0]]}を なおす（バトル中）` : "状態異常を すべて なおす（バトル中）";
    case "revive": return it.full ? "倒れた 仲間を ぜんかいで 生き返らせる" : "倒れた 仲間を 生き返らせる";
    case "seed": return it.rnd ? `${ST_NAME[it.stat]}が ずっと ${it.rnd[0]}〜${it.rnd[1]} 上がる` : `${ST_NAME[it.stat]}が ずっと ${it.val} 上がる`;
    case "lvup": return `レベルが ${it.val || 1} 上がる`;
    case "exp": return `経験値を ${it.val} もらえる`;
    case "sp": return `スキルポイントが ${it.val} 増える`;
    case "respec": return "振り分けた スキルポイントを 全部 戻す";
    case "scout": return `スカウト 成功りつ +${it.val}%（バトル中）`;
    case "bbuff": return `みんなの ${ST_NAME[it.stat]}を ${it.n || 1}段階 アップ（バトル中）`;
    case "escape": return "必ず 逃げられる（バトル中・ボス・マスター・対戦では 使えない）";
    case "bomb": return `敵 全員に ${it.el ? EL_NAME[it.el] + "属性の " : ""}ダメージ（仲間の レベルで 強くなる・バトル中）`;
    case "call": return "まわりに モンスターを よびよせる";
    case "warp": return "スポーン地点か ベッドに 戻る";
    case "money": return `${it.val} ${CURRENCY}に かえられる`;
    case "nature_rand": return "性格が ランダムに かわる";
    case "nature_pick": return "すきな 性格に かえられる";
    case "reforge": return { find: "装備の レア度と 能力を 振り直す", craft: "装備を 振り直す（良い 結果が 出やすい）", high: "装備を 振り直す（B〜SSのみ）", up: "装備の レア度を 1つ 上げて 振り直す" }[it.mode] || "装備を 打ち直す";
  }
  return "";
}

// v2.2: バッグ（インベントリが いっぱいに ならない ように 道具・素材・スキルの書・装備を しまう）
const BAG_CAT = [["道具", (it) => !["skillbook", "material", "weapon", "armor", "acc", "egg", "treasure", "evostone", "talent", "awaken", "slab", "bslab", "dslab", "xslab", "key"].includes(it.kind)], ["スキルの書", (it) => it.kind === "skillbook"],
  ["素材", (it) => it.kind === "material" || it.kind === "matbox"], ["タマゴ", (it) => it.kind === "egg"], ["お宝", (it) => it.kind === "treasure"], ["石板", (it) => it.kind === "slab" || it.kind === "xslab"], ["神の石板", (it) => it.kind === "dslab"], ["特別な石板", (it) => it.kind === "bslab"], ["だいじなもの", (it) => it.kind === "key"],
  ["進化・才能・覚醒", (it) => ["evostone", "talent", "awaken"].includes(it.kind)], ["武器", (it) => it.kind === "weapon"], ["防具", (it) => it.kind === "armor"], ["アクセサリー", (it) => it.kind === "acc"]];
const PAGE_MEM = new Map();   /* 第70版: 一覧の ページと しぼりこみを おぼえる（ワールドを 閉じると 消える） */
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { for (const k of [...PAGE_MEM.keys()]) if (k.startsWith(playerId + ":")) PAGE_MEM.delete(k); } catch {} }); } catch {}
/* 第70版: 種類の ボタンに その 種類の 道具の 絵を 出す（みな 同じ 草の 絵で 分かりにくかった） */
const CAT_ICON_CACHE = new Map();
function catIcon(key, test, fallback = "i_item") {
  if (!CAT_ICON_CACHE.has(key)) { const id = Object.keys(ITEMS).find((k) => { try { return test(ITEMS[k], k); } catch { return false; } }); CAT_ICON_CACHE.set(key, id || null); }
  const id = CAT_ICON_CACHE.get(key); return id ? ITEM_ICON(id) : ICON(fallback);
}
async function bagStore(p, d) {
  for (;;) {
    const b = bagLoad(p);
    const ri = rpgItems(p);
    const cnt = BAG_CAT.map(([n, f]) => [n, f, n === "だいじなもの" ? Object.keys(ri).filter((id) => ITEMS[id]?.kind === "key").length : Object.entries(b.i).filter(([id]) => ITEMS[id] && f(ITEMS[id])).reduce((a, [, x]) => a + x, 0) + b.g.filter(([id]) => ITEMS[id] && f(ITEMS[id])).length]);
    const s = await choose(p, "バッグ", ["§fバッグには いくらでも しまえます。§7（ガイドブック・コンパス・釣竿・だいじなものは 持ち物に のこる）", `§7インベントリの あき: §f${invFree(p)}`, `§7拾った 物を 自動で バッグへ: ${autoBag(p) ? "§aオン" : "§cオフ"}`].join("\n"),
      [B("§l持ち物を ぜんぶ バッグへ しまう", ICON("i_box")), ...cnt.map(([n, f0, c]) => B(`${n === "神の石板" && !c ? "？？？の石板" : n} §8${c}こ\n§8えらんで 取り出す`, n === "神の石板" && !c ? ICON("i_zukan") : catIcon("bag:" + n, (it) => f0(it)))),
        B(`拾った 物を 自動で バッグへ: ${autoBag(p) ? "§aオン" : "§cオフ"}`, ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    if (s === 0) { const n = stowAll(p, decodeLoreG); sound(p, "random.chestclosed"); await notice(p, "バッグ", `§a${n}こ しまった！`); continue; }
    if (s >= 1 && s <= BAG_CAT.length && BAG_CAT[s - 1][0] === "だいじなもの") { await keyList(p, d); continue; }   /* v2.9.12: だいじなものは 持ち物に ある ので いっしょに 見せる */
    if (s >= 1 && s <= BAG_CAT.length) { await bagTake(p, d, BAG_CAT[s - 1][0] === "神の石板" && !cnt[s - 1][2] ? ["？？？の石板", BAG_CAT[s - 1][1]] : BAG_CAT[s - 1]); continue; }   /* 第69版 */
    if (s === BAG_CAT.length + 1) { p.setDynamicProperty("mrpg:autobag", !autoBag(p)); continue; }
    return;
  }
}
async function keyList(p, d) {
  const ids = Object.keys(rpgItems(p)).filter((id) => ITEMS[id]?.kind === "key").sort((x, y) => itemIx(x) - itemIx(y));
  if (!ids.length) { await notice(p, "だいじなもの", "§7まだ 持っていません。\n§f物語の とちゅうで 手に入る 道具です。§7（なくしても しばらくすると 手元に もどる）"); return; }
  const sel = await paged(p, "【だいじなもの】", "§7持ち物と バッグの だいじなもの（使っても なくならない）", ids.map((id) => B(`§6${ITEMS[id].name}\n§7${clipT(itemDesc(id), 26)}`, ITEM_ICON(id))));
  if (sel < 0 || !ids[sel]) return;
  await useKey(p, d, ids[sel]);
}
async function bagTake(p, d, [name, f]) {
  for (;;) {
    const b = bagLoad(p);
    const items = Object.entries(b.i).filter(([id, n]) => ITEMS[id] && n > 0 && f(ITEMS[id])).sort((x, y) => itemIx(x[0]) - itemIx(y[0]));
    const gears = b.g.map((g, i) => [g, i]).filter(([[id]]) => ITEMS[id] && f(ITEMS[id])).sort((x, y) => gearPower(y[0][0], y[0][1]) - gearPower(x[0][0], x[0][1]));
    if (!items.length && !gears.length) { await notice(p, name, "§7バッグに ありません。"); return; }
    const btn = [...items.map(([id, n]) => B(`${ITEMS[id].name} §8×${n}\n${ITEMS[id].kind === "egg" ? eggLine(id, rankCap(d)) : `§7${clipT(itemDesc(id), 26)}`}`, ITEM_ICON(id))), ...gears.map(([[id, roll]]) => B(`${gearName(id, roll)}\n§7${gearLines(id, roll).slice(0, 1).join("").replace(/§./g, "").slice(0, 26)}`, ITEM_ICON(id)))];
    const pst = PAGE_MEM.get(`${p.id}:bag:${name}`) || {}; PAGE_MEM.set(`${p.id}:bag:${name}`, pst);   /* 第70版 */
    const sel = await paged(p, `バッグ：${name}`, "§7取り出す・使う 物を 選んでください", btn, 8, [], pst);
    if (sel < 0) return;
    if (sel < items.length) {
      const [id, n] = items[sel];
      const a = await choose(p, ITEMS[id].name, `§f${itemDesc(id)}\n§7バッグに ${n}こ${craftInfo(id) ? "\n\n" + craftInfo(id) : ""}`, ["bslab", "dslab"].includes(ITEMS[id].kind) ? [B("§l使う", ICON("i_bag")), B("§7戻る", ICON("i_back"))] : [B("§l使う", ICON("i_bag")), B("取り出す（持ち物へ）", ICON("i_box")), B("§7戻る", ICON("i_back"))]);
      if (["bslab", "dslab"].includes(ITEMS[id].kind) && a === 1) continue;   // v2.9.10: 物語の 石板は バッグから 使う（取り出さない）
      if (a === 0) await useItemFlow(p, d, id, true);
      else if (a === 1) {
        let k = 1;
        if (n > 1) { const v = await modal(p, "取り出す", (fm) => fm.slider(`いくつ 取り出す？`, 1, Math.min(n, 640), 1, Math.min(n, 64))); if (!v) continue; k = Math.round(v[0]); }
        const bb = bagLoad(p); bb.i[id] -= k; if (bb.i[id] <= 0) delete bb.i[id]; bagSave(p, bb); giveInv(p, `mrpg:${id}`, k); sound(p, "random.pop");
      }
    } else {
      const [[id, roll], gi] = gears[sel - items.length];
      const bb = bagLoad(p); if (!bb.g[gi] || bb.g[gi][0] !== id) continue;
      bb.g.splice(gi, 1); bagSave(p, bb); giveInv(p, `mrpg:${id}`, 1, () => makeStackG(id, roll)); sound(p, "random.pop");
    }
  }
}
async function bagMenu(p, d) {
  for (;;) {
    const have = Object.entries(rpgItems(p)).sort((a, b) => itemIx(a[0]) - itemIx(b[0]));
    // v2.8: 【石板】【特別な石板】【だいじなもの】は いつも 表示
    const cats = [...new Set([...have.map(([id]) => KIND_NAME[ITEMS[id].kind] || "そのた"), "石板", "特別な石板", "だいじなもの"])];
    const c = await choose(p, "道具・タマゴ", "§7種類を 選んでください（インベントリの もちもの）",
      [...cats.map((k) => B(`§l${k === "特別な石板" ? "§d" : k === "だいじなもの" ? "§6" : ""}${k === "石板" || k === "特別な石板" || k === "だいじなもの" ? `【${k}】` : k} §8${have.filter(([id]) => (KIND_NAME[ITEMS[id].kind] || "そのた") === k).length}しゅ`, (k === "石板" ? catIcon("use:slab", (it) => it.kind === "slab") : k === "特別な石板" ? catIcon("use:bslab", (it) => it.kind === "bslab") : k === "だいじなもの" ? catIcon("use:key", (it) => it.kind === "key") : catIcon("use:" + k, (it) => (KIND_NAME[it.kind] || "そのた") === k)))), B("§7戻る", ICON("i_back"))]);
    if (c < 0 || c >= cats.length) return;
    const list = have.filter(([id]) => (KIND_NAME[ITEMS[id].kind] || "そのた") === cats[c]);
    if (!list.length) { await notice(p, cats[c], cats[c] === "特別な石板" ? "§7まだ 持っていません。\n§f地方マスター・カップ・遺跡・星冠王から 受けとる、物語に 必要な 石板です。§7（使っても なくならない）" : cats[c] === "だいじなもの" ? "§7まだ 持っていません。\n§f物語の とちゅうで 手に入る 道具です（懐中電灯・潜水ゴーグル など）。§7使っても なくならない" : "§7まだ 持っていません。\n§f石板は マスターや ボスが 落とします。かかげると ボスが 現れます。"); continue; }
    // v2.9.12: タマゴは まとめて かえせる
    const egg = cats[c] === "タマゴ", tot = egg ? list.reduce((t, [, n]) => t + n, 0) : 0;
    const pst = PAGE_MEM.get(`${p.id}:use:${cats[c]}`) || {}; PAGE_MEM.set(`${p.id}:use:${cats[c]}`, pst);   /* 第70版: 前に 見て いた ページを おぼえる */
    const sel = await paged(p, cats[c], "§7使う 道具を 選んでください", [...(egg ? [B(`§6§lぜんぶ かえす §r§8（${tot}こ）\n§8生まれた 子は 預かり所へ`, ICON("i_egg"))] : []), ...list.map(([id, n]) => B(`${ITEMS[id].name} §8×${n}\n${egg ? eggLine(id, rankCap(d)) : `§7${clipT(itemDesc(id), 26)}`}`, ITEM_ICON(id)))], 8, [], pst);
    if (sel < 0) continue;
    if (egg && sel === 0) { await hatchAll(p, list); const nd = load(p); if (nd) Object.assign(d, nd); continue; }
    await useItemFlow(p, d, list[sel - (egg ? 1 : 0)][0], true);
  }
}

const eggHatchOk = (id, c) => { const rs = Object.keys(EGGS[id]?.ranks || {}).map((r) => RANK_LBL.indexOf(r)).filter((x) => x >= 0); return !rs.length || Math.max(...rs) <= c; };
/* 第70版: タマゴの ボタンに 生まれる ランクと 系統を 出す（どれも 同じ 形で 分かりにくかった） */
function eggLine(id, cap) {
  const E = EGGS[id]; if (!E) return "";
  const rs = Object.keys(E.ranks || {}).sort((a, b) => RANK_LBL.indexOf(a) - RANK_LBL.indexOf(b));
  const fam = (E.fams || []).map((f) => FAMILIES.find((q) => q.id === f)?.name).filter(Boolean).join("・");
  const rk = rs.length ? (rs.length > 1 ? `${rs[0]}〜${rs[rs.length - 1]}` : rs[0]) : "";
  return eggHatchOk(id, cap) ? `§2${rk}${fam ? ` §8${fam}` : ""}` : `§8${rk} §cまだ`;
}
async function hatchAll(p, list) {
  const d = load(p); if (!d) return;
  { const c0 = rankCap(d), held = list.filter(([id]) => !eggHatchOk(id, c0)); list = list.filter(([id]) => eggHatchOk(id, c0));   // v2.9.12: まだ かえせない タマゴは のこす（いちばん 高い ランクが 上限 いかに なったら かえせる）
    if (held.length) try { p.sendMessage(`§7まだ かえせない タマゴ（物語を 進めると かえせる）: ${held.slice(0, 3).map(([id]) => ITEMS[id]?.name).join("・")}${held.length > 3 ? ` ほか ${held.length - 3}種` : ""}`); } catch {}
    if (!list.length) { await notice(p, "タマゴ", "§7いま かえせる タマゴが ありません。\n§f物語を 進めると、強い タマゴも かえせるように なります。"); return; } }
  const room = BOX_MAX - d.box.length;
  const tot = list.reduce((t, [, n]) => t + n, 0);
  if (room <= 0) { await notice(p, "タマゴ", "預かり所が いっぱいです。"); return; }
  if (!(await confirm(p, "タマゴを ぜんぶ かえす", `§fタマゴ ${tot}こを かえしますか？${tot > room ? `\n§c預かり所の あきが ${room}体ぶん なので ${room}こだけ かえす。` : ""}\n§7生まれた 子は パーティに あきが あれば パーティ、なければ 預かり所へ。`, "かえす", "やめる"))) return;
  const got = [];
  for (const [id, n] of list) {
    for (let i = 0; i < n && got.length < room; i++) {
      if (!takeItem(p, `mrpg:${id}`)) break;
      const m = hatch(id, rankCap(d), endingDone(d)); m._nw = !d.own.includes(SPECIES[m.sp]?.idx); addMon(d, m); mark(d.own, m.sp); mark(d.seen, m.sp); got.push(m);
    }
  }
  save(p, d);
  if (!got.length) return;
  particle(p, "minecraft:totem_particle", 1.5); sound(p, "random.levelup");
  const ranks = {}; for (const m of got) { const r = SPECIES[m.sp].rank; ranks[r] = (ranks[r] || 0) + 1; }
  await notice(p, `タマゴが ${got.length}こ かえった！`, [`§7ランク: ${Object.entries(ranks).map(([r, k]) => `§e${r}§7×${k}`).join("  ")}`, "", ...got.map((m) => `${m._nw ? "§6NEW! " : "§a● "}§f${m.nm} §7ランク${SPECIES[m.sp].rank}${d.party.includes(m) ? " §a（パーティ）" : ""}`)].join("\n"));
}

export async function useItemFlow(p, d, id, inMenu = false) {
  const it = ITEMS[id];
  if (!d) { await notice(p, "道具", "まず ガイドブックで 最初の 仲間を えらぼう。"); return; }
  const k = it.kind;
  // v2.9.12: 物語より 先の 育成の 道具は まだ 使えない（どこから 手に 入れても）
  if (["lvup", "lvmax", "awaken", "talent", "seed", "seedall", "sp", "exp", "plusup", "inherit", "limit", "traitpick", "nature_pick", "dream", "resize"].includes(k) && !storyLootOk(it, null, rankCap(d))) {
    await notice(p, it.name, `§7まだ この 道具の 力を 引き出せない……\n§f物語を 進めると 使える §7（いまの 上限: ${RANK_LBL[rankCap(d)]}）`); return;
  }
  if (["food", "snack", "homewing", "chute"].includes(k)) { if (EXH.use) await EXH.use(p, d, id); return; }   /* 第102版 */
  if (k === "exmat") { await notice(p, it.name, `§7地方の 素材。§fガイドブック → 冒険 →「探索手帳」→「素材の 交換」で 道具に かえられる。`); return; }   /* 第101版 */
  if (k === "fossil") { if (EXH.fossil) await EXH.fossil(p, d); return; }
  if (k === "rmap") { if (EXH.rmap) await EXH.rmap(p, d); return; }
  if (k === "material") { await notice(p, it.name, `§7${FAMILIES.find((f) => f.id === it.fam)?.name || ""}の モンスターが おとす 素材。\n§fブック →「クラフト」で 武器・防具・アクセ・道具を 作れます。\n\n${craftInfo(id)}`); return; }
  if (k === "matbox") {
    const n = countItem(p, `mrpg:${id}`);
    if (!(await confirm(p, it.name, `${it.name}を あけますか？ §7（もっている ${n}こ）`, n > 1 ? "全部 あける" : "あける", "やめる"))) return;
    if (!takeItem(p, `mrpg:${id}`, n)) return;
    const fams = FAMILIES.map((f) => f.id), got = {};
    for (let i = 0; i < it.val * n; i++) { const mid = `mat_${fams[Math.floor(Math.random() * fams.length)]}${it.mt}`; if (ITEMS[mid]) got[mid] = (got[mid] || 0) + 1; }
    for (const [mid, c] of Object.entries(got)) giveItem(p, `mrpg:${mid}`, c);
    sound(p, "random.chestopen");
    await notice(p, it.name, Object.entries(got).map(([mid, c]) => `§b${ITEMS[mid].name} §f×${c}`).join("\n"));
    return;
  }
  if (k === "key") { await useKey(p, d, id); return; }
  if (k === "xslab") { if (inDungeon(p)) { await notice(p, it.name, "§7石板の 中では 使えない。"); return; } await useXSlab(p, d, it.x); return; }
  if (k === "bslab") {
    await enterDungeon(p, d, it.bs);
    return;
  }
  if (k === "dslab") {   // 第68版: 神の石板
    if (inDungeon(p)) { await notice(p, it.name, "§7石板の 中では 使えない。"); return; }
    const G = DEITY[it.gi]; if (!G) return;
    const s0 = qs(d);
    if (s0.dg && s0.dg[it.gi]) { await notice(p, it.name, `§7${G.name}は もう 仲間だ。石板は 静かに 光っている。`); return; }
    if (!(await confirm(p, it.name, [`§d§l${it.name}`, `§7${itemDesc(id)}`, "", `§f階層 §e${G.floors}§f・最後の 階に §c${G.name}§f（Xランク・Gサイズ）`, "§c神は とても 強い。§7手持ちを ととのえてから 挑もう", "§7負けても 石板は のこる", "", "§d触れますか？"].join("\n"), "触れる", "やめる"))) return;
    await enterExtra(p, d, "deity", it.gi);
    return;
  }
  if (k === "slab") {
    if (!canFight(d)) { await notice(p, it.name, "§c戦える 仲間が いない！"); return; }
    if (!slabTierOk(d, it.slab)) { await notice(p, it.name, "§7石板は 固く 沈黙している……\n§f物語を 見届けると（星冠王と 王冠の石板）、金・虹の 石板が 目を さます。"); return; }
    if (inDungeon(p)) { await notice(p, it.name, "§7石板の 中では 使えない。"); return; }
    if (p.dimension.getEntities({ type: "mrpg:monster", tags: ["mrpg_slab"], location: p.location, maxDistance: 48 }).length) { await notice(p, it.name, "§c近くに もう 石板ボスが いる！ さきに たおそう。"); return; }
    if (!(await confirm(p, it.name, `${itemDesc(id)}\n\n§fあたりに ボスが よびだされます。\n§7・ボスは 1体だけ・ボス専用の フィールドで 戦う\n§7・ボスは 10ぷんで 消える。負けると ボスは 去る（石板は もどらない）\n§7・ほかの ひとも 殴って さんせんできる\n§7・石板ボスの スカウトりつは ふつうの ボスの 2ばい 近く\n§7・まれに ランクが 1つ うえの ボスが 出る`, "かかげる！", "やめる"))) return;
    particle(p, "minecraft:totem_particle", 1.5); sound(p, "mob.evocation_illager.cast_spell", 1);
    try { p.runCommand?.("camerashake add @s 0.3 0.8 positional"); } catch {}
    await new Promise((r) => system.runTimeout(r, 30));
    if (!ok(p) || !takeItem(p, `mrpg:${id}`)) return;   // v2.9.12: ボスが 出る 直前に 石板を 使う（とちゅうで ぬけても なくならない）
    try { spawnSlabBoss(p, d, it.slab, it.sfam); } catch (e) { console.warn(`[MonsterRPG] slab: ${e}`); giveItem(p, `mrpg:${id}`, 1); }
    return;
  }
  if (["healall", "fullall", "mpall", "reviveall"].includes(k)) {   // v2.9.10: 戦闘の 外でも パーティ 全員に
    const body = [`§l§e${it.name}§r §8×${countItem(p, `mrpg:${id}`)}`, `§f${itemDesc(id)}`, LINE, ...frontOf(d).map((m) => `§f${m.nm} ${hpLine(m)}`), "", "§f表と 裏の 全員に 使いますか？"].join("\n");
    if (!(await confirm(p, it.name, body, "使う", "やめる"))) return;
    if (countItem(p, `mrpg:${id}`) <= 0) return;
    let n = 0;
    for (const m of frontOf(d)) {
      const st = calcStats(m), h0 = m.hp, m0 = m.mp;
      if (k === "healall" && m.hp > 0 && m.hp < st.hp) m.hp = Math.min(st.hp, m.hp + itemHp(it, st.hp));
      if (k === "fullall" && m.hp > 0 && (m.hp < st.hp || m.mp < st.mp)) { m.hp = Math.max(m.hp, st.hp); m.mp = Math.max(m.mp, st.mp); }
      if (k === "mpall" && m.hp > 0 && m.mp < st.mp) m.mp = Math.min(st.mp, m.mp + (it.mp || 0));
      if (k === "reviveall" && m.hp <= 0) m.hp = it.full ? st.hp : Math.floor(st.hp / 2);
      if (m.hp !== h0 || m.mp !== m0) n++;
    }
    if (!n) { await notice(p, it.name, "§7しかし 何も おこらなかった。（使わずに のこした）"); return; }
    takeItem(p, `mrpg:${id}`); save(p, d); sound(p, "random.levelup"); if (d.out) refreshPet(p, d);
    await notice(p, it.name, [`§a${it.name}を 使った！`, "", ...frontOf(d).map((m) => `§f${m.nm} ${hpLine(m)}`)].join("\n"));
    return;
  }
  if (["scout", "bbuff", "escape", "bomb", "cure", "curall", "bregen", "bdebuff", "bstatus"].includes(k)) {
    await notice(p, it.name, `${itemDesc(id)}\n\n§7この 道具は バトル中の「道具」から 使えます。`); return;
  }
  if (k === "rod") { await notice(p, it.name, `${itemDesc(id)}\n\n§7海・川・池の 水に 向かって 使う（右クリック）と 釣りが はじまる。\n§7釣竿は 街の §e釣り屋§7で 買える。`); return; }
  if (k === "treasure") { await notice(p, it.name, `${itemDesc(id)}\n\n§7お店の「売る」で お金に かえられる。`); return; }
  if (k === "money") {
    const n = countItem(p, `mrpg:${id}`);
    if (n <= 0 || !takeItem(p, `mrpg:${id}`, n)) return;
    d.gold += it.val * n; save(p, d); sound(p, "random.orb");
    await notice(p, "お金", `${it.name} ${n}こを ${gold(it.val * n)} に かえた！\nいま ${gold(d.gold)}`); return;
  }
  if (k === "egg") {
    if (d.box.length >= BOX_MAX) { await notice(p, "タマゴ", "預かり所が いっぱいです。"); return; }
    if (!eggHatchOk(id, rankCap(d))) { await notice(p, it.name, `§7タマゴは まだ 静かに 眠っている……\n§f物語を 進めると かえせる §7（いまの 上限: ${RANK_LBL[rankCap(d)]}・${Object.keys(EGGS[id].ranks).join("・")}ランクの タマゴ）`); return; }   // v2.9.12: 弱い 子に かわって しまわない ように 取って おく
    if (!(await confirm(p, it.name, `${it.name}を かえしますか？\n§7${(() => { const c = rankCap(d), rs = Object.keys(EGGS[id].ranks), ok2 = rs.filter((r) => RANK_LBL.indexOf(r) <= c); return ok2.length === rs.length ? `${rs.join("・")}ランクの モンスターが 生まれます。` : `${(ok2.length ? ok2 : [RANK_LBL[c]]).join("・")}ランクの モンスターが 生まれます。§e（いまの 物語の 上限は ${RANK_LBL[c]}。物語を 進めると もっと 高い ランクが 生まれる）`; })()}`))) return;
    if (!takeItem(p, `mrpg:${id}`)) return;
    const m = hatch(id, rankCap(d), endingDone(d)); const nw = !d.own.includes(SPECIES[m.sp]?.idx);   // UX案
    addMon(d, m);
    mark(d.own, m.sp); mark(d.seen, m.sp); save(p, d);
    particle(p, "minecraft:totem_particle", 1.5); sound(p, "random.levelup");
    await notice(p, "タマゴが かえった！", `${nw ? "§6NEW! " : "§a● "}§l§e${m.nm}§r（ランク${SPECIES[m.sp].rank}）が 生まれた！\n${d.party.includes(m) ? "パーティに くわわった。" : "預かり所に おくられた。"}`);
    return;
  }
  if (k === "call") {
    const n = spawnWildNear(p, it.val || 4, 5, 10);
    if (!n) { await notice(p, it.name, "§7ピーーッ……\n§fここでは モンスターが よってこなかった。§7（笛は へっていない。ひらけた 場所で ためそう）"); return; }   // v2.9.12: 何も 来なければ へらさない
    takeItem(p, `mrpg:${id}`);
    await notice(p, it.name, `ピーーッ！\n${n}たいの モンスターが よってきた！`); return;
  }
  if (k === "warp") {
    if (await warpMenu(p, d, true)) takeItem(p, `mrpg:${id}`);
    return;
  }
  if (["weapon", "armor", "acc"].includes(k)) {
    const m = await pickMon(p, d, `${it.name}を 誰に 装備する？`, itemDesc(id));
    if (!m) return;
    await equipMenu(p, d, m, k); return;
  }
  if (k === "skillbook") { await skillBookFlow(p, d, id); return; }
  if (k === "talent") { await talentItem(p, d, id); return; }
  if (k === "traitpick") { await traitPickFlow(p, d, id); return; }
  if (k === "tmap") { await useTmap(p, d); return; }
  if (k === "limit") { await useLimit(p, d, pickMon); return; }
  if (k === "inherit") { await notice(p, it.name, `${itemDesc(id)}\n\n§7持っていると 配合の ときに 使うか 聞かれる。`); return; }
  if (k === "navi") { await naviMenu(p, d); return; }
  if (k === "reforge") { await reforgeFlow(p, d, id); return;
  }
  if (k === "nature_pick") {
    const m = await pickMon(p, d, `${it.name}を 誰に 使う？`, itemDesc(id));
    if (!m) return;
    {
      const sel = await choose(p, "性格を 選ぶ", `§f${m.nm}の いまの 性格: §d${natureText(m.nat)}\n§fおすすめ: §b${natureText(SPECIES[m.sp].rec)}`,
        [...NATURES.map((n, i) => B(`${natureText(i)}${i === SPECIES[m.sp].rec ? " §6★" : ""}`, ICON("i_skill"))), B("§7やめる", ICON("i_back"))]);
      if (sel < 0 || sel >= NATURES.length) return;
      if (sel === m.nat) { await notice(p, "性格を 選ぶ", "§7いまと 同じ 性格です。（道具は へらない）"); return; }   // v3.0 第63版
      if (countItem(p, `mrpg:${id}`) <= 0) return;
      m.nat = sel;
    }
    const st = calcStats(m); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp);
    takeItem(p, `mrpg:${id}`); save(p, d); sound(p, "random.levelup");
    await notice(p, it.name, `§a${m.nm}の 性格が ${natureText(m.nat)}§a に かわった！`);
    return;
  }
  // モンスター1体に使う
  const hpv = ["heal", "mpheal", "revive"].includes(k);
  const m = await pickMon(p, d, `${it.name}を 誰に 使う？`, itemDesc(id), k === "revive", hpv, hpv);
  if (!m) return;
  // v1.7: いくつ 使うかを バーで えらぶ（まとめて 使える 道具）
  const MULTI = ["lvup", "exp", "seed", "seedall", "sp", "heal", "mpheal"];
  const have = countItem(p, `mrpg:${id}`);
  let n = 1;
  if (MULTI.includes(k) && have > 1) {
    const max = Math.min(have, k === "lvup" ? Math.max(1, Math.ceil((MAXLV - m.lv) / (it.val || 1))) : 99);
    if (max > 1) {
      const v = await modal(p, `${it.name}を 使う`, (f) => f.slider(`${m.nm}（Lv${m.lv}）に いくつ 使う？ §7（持っている ${have}個）`, 1, max, 1, 1));
      if (!v) return; n = Math.max(1, Math.min(max, v[0] | 0));
    }
  }
  if (p.getDynamicProperty("mrpg:noconfirm") !== true && !(await confirm(p, it.name, `§l§e${it.name}§r ×${n}\n§f${itemDesc(id)}\n\n§f${m.nm}§7（Lv${m.lv}）に 使いますか？`, "使う", "やめる"))) return;
  const log = [];
  let used = 0;
  n = Math.min(n, countItem(p, `mrpg:${id}`)); if (n <= 0) return;   // v2.9.12: 手もとに ある 数まで
  for (let i = 0; i < n; i++) { const l2 = []; if (!useItemOn(m, id, l2, rankCap(d), expCapLv(d))) { log.push(...l2); break; } used++; if (i < 3 || i === n - 1) log.push(...l2); else if (i === 3) log.push("§7…"); }
  if (!used) { await notice(p, it.name, log.length ? log.join("\n") : "§7しかし 何も おこらなかった。"); return; }
  if (used > 1) log.unshift(`§e${it.name}を ${used}個 使った！`);
  takeItem(p, `mrpg:${id}`, used);
  // サイズが 大きくなって パーティの 枠を こえたら 預かり所へ
  for (const x of fixParty(d)) { if (d.out === x.id) recallPet(p, d); log.push(`§e${x.nm}は 大きくなって パーティの 枠（${PARTY_CAP}）に 入らないので 預かり所へ 移った。`); }
  for (const mm of allMons(d)) mark(d.own, mm.sp);
  save(p, d); if (d.out === m.id) refreshPet(p, d);
  sound(p, "random.levelup");
  if (hpv) log.push("", `§f${m.nm} ${hpLine(m)}`);
  await notice(p, it.name, log.join("\n"));
}

async function pickMon(p, d, t, desc, deadOnly = false, partyFirst = false, hpView = false) {
  let list = allMons(d).filter((m) => !deadOnly || m.hp <= 0);
  if (partyFirst) list = [...list.filter((m) => d.party.includes(m)), ...list.filter((m) => !d.party.includes(m))];
  if (!list.length) { await notice(p, t, "使える モンスターが いません。"); return null; }
  // v2.9.10: 回復の 道具では のこりの HP・MPを 数字で
  const sel = await paged(p, t, `§7${desc}`, list.map((m) => { const st = calcStats(m); const g3 = pagedGrid(`§7${desc}`, list.length); return B(hpView ? (g3 ? `${d.party.includes(m) ? "§b表 " : ""}${m.nm}\n§7Lv${m.lv} ${hpLine(m).replace(" §bMP", "\n§bMP")}` : `${d.party.includes(m) ? "§b表 " : ""}${m.nm} §7Lv${m.lv}\n${hpLine(m)}`) : `${d.party.includes(m) ? "§b表 " : ""}${monName(m)}${m.spl ? " §6SP" + m.spl : ""}\n${monInfo(m)}${g3 ? "\n" : " "}${meter(m.hp, st.hp, 6)}`, MON_ICON(m.sp)); }));
  return sel < 0 ? null : list[sel];
}

// ---------- 装備 ----------
const SLOT = { weapon: "w", armor: "a", acc: "x" };
function equip(p, d, m, g) {
  const s = SLOT[ITEMS[g.id].kind];
  if (!canEquip(m, g.id)) { p.sendMessage(`§c${m.nm}は ${ITEMS[g.id].name}を 装備できない。`); return; }
  if (!takeSlot(p, g.slot, g.id)) return;
  m.eqr = m.eqr || {};
  if (m.eq[s]) giveGear(p, m.eq[s], m.eqr[s]);
  const before = calcStats(m);
  m.eq[s] = g.id; m.eqr[s] = g.roll || null;
  const after = calcStats(m);
  m.hp = Math.max(m.hp > 0 ? 1 : 0, Math.min(after.hp, m.hp + Math.max(0, after.hp - before.hp)));
  m.mp = Math.min(after.mp, m.mp);
  save(p, d); sound(p, "armor.equip_iron"); if (d.out === m.id) refreshPet(p, d);
  p.sendMessage(`§a${m.nm}は ${gearName(g.id, g.roll)}§aを 装備した！`);
}
async function equipPick(p, d) {
  const m = await pickMon(p, d, "装備", "装備を かえる モンスターを 選んでください");
  if (m) await equipMenu(p, d, m);
}
const gearBtn = (g) => B(`${gearName(g.id, g.roll)}${g.roll ? ` §8${quality(g.id, g.roll)}%` : ""}\n§7${gearLines(g.id, g.roll).slice(1).join(" ").replace(/§8\([^)]*\)/g, "").slice(0, 34)}`, ITEM_ICON(g.id));
async function equipMenu(p, d, m, kindOnly = null) {
  for (;;) {
    const slots = ["w", "a", "x"];
    let sel;
    if (kindOnly) sel = slots.indexOf(SLOT[kindOnly]);
    else sel = await choose(p, `${m.nm}の 装備`, `${eqText(m)}\n${LINE}\n${STATS.map((k) => `${ST_COL[k]}${ST_NAME[k]}§f ${calcStats(m)[k]}`).join("  ")}\n${LINE}\n§7装備できる もの: ${equipText(m.sp)}`,
      [...slots.map((s) => B(`${{ w: "武器", a: "防具", x: "アクセサリー" }[s]}: ${m.eq[s] ? gearName(m.eq[s], m.eqr && m.eqr[s]) : "§7なし"}`, m.eq[s] ? ITEM_ICON(m.eq[s]) : ICON("i_equip"))), B("§7戻る", ICON("i_back"))]);
    if (sel < 0 || sel >= 3) return;
    const s = slots[sel];
    const kind = { w: "weapon", a: "armor", x: "acc" }[s];
    const all = gearSlots(p, kind);
    const capE = rankCap(d), have = all.filter((g) => canEquip(m, g.id) && storyItemOk(ITEMS[g.id], null, capE)).sort((a, b) => gearPower(b.id, b.roll) - gearPower(a.id, a.roll));   // v2.9.12: 物語より 先の 段の 装備は まだ つけられない
    const ng = all.length - have.length;
    const cur = m.eq[s] ? gearLines(m.eq[s], m.eqr && m.eqr[s]) : [];
    const now = m.eq[s] ? `§fいま: ${gearName(m.eq[s], m.eqr && m.eqr[s])}\n${cur.join("\n")}\n` : "";
    const c = await paged(p, "装備を 選ぶ", now + (have.length ? "§7持っている 装備（強い順・%は 理論値に 対する 割合）" : "§7この 場所に 装備できる 物を 持っていません。\nクラフトや ショップ、宝箱で 手に入れよう。") + (ng ? `\n§8（${m.nm}が 装備できない 種類の 物が ${ng}個 あります）` : ""),
      have.map(gearBtn), 6, m.eq[s] ? [B("§cはずす", ICON("i_close"))] : [], null, false);   /* 第73版: 装備の 効果を 読めるように 縦 */
    if (c === -1) { if (kindOnly) return; continue; }
    if (c >= 0) {
      const g = have[c];
      if (!(await confirm(p, "装備", [`§l${gearName(g.id, g.roll)}`, ...gearLines(g.id, g.roll), "", "§7この 装備に かえますか？"].join("\n"), "装備する", "やめる"))) continue;
      equip(p, d, m, g);
    } else if (m.eq[s] && c === -2) { giveGear(p, m.eq[s], m.eqr && m.eqr[s]); m.eq[s] = null; if (m.eqr) m.eqr[s] = null; const st = calcStats(m); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp); save(p, d); if (d.out === m.id) refreshPet(p, d); }
    if (kindOnly) return;
  }
}
// 打ち直し（鍛冶の 槌など）
async function reforgeFlow(p, d, id) {
  const it = ITEMS[id];
  const have = gearSlots(p).filter((g) => g.roll && (it.mode !== "up" || g.roll.r < Math.min(8, capOf(p)))).sort((a, b) => gearPower(b.id, b.roll) - gearPower(a.id, a.roll));
  if (!have.length) { await notice(p, it.name, "§7打ち直せる 装備を 持っていません（インベントリの 装備が 対象）。"); return; }
  const c = await paged(p, it.name, `§f${itemDesc(id)}\n§7打ち直す 装備を 選んでください`, have.map(gearBtn), 6, [], null, false);   /* 第73版: 縦 */
  if (c < 0) return;
  const g = have[c];
  if (!(await confirm(p, it.name, [`§l${gearName(g.id, g.roll)}`, ...gearLines(g.id, g.roll), "", it.mode === "up" ? "§eレア度を 1つ 上げて 能力を 振り直します。" : "§eレア度・能力・パッシブを 全部 振り直します。§c（前より 悪くなる ことも）"].join("\n"), "打ち直す", "やめる"))) return;
  if (!gearSlots(p).some((x) => x.slot === g.slot && x.id === g.id)) return;   /* 第67版: 確認の 間に 装備が なくなったら 何もしない */
  if (!takeItem(p, `mrpg:${id}`)) return;
  const roll = capRoll(p, g.id, it.mode === "up" ? rollGear(g.id, "find", Math.min(8, g.roll.r + 1)) : rollGear(g.id, it.mode));
  replaceSlot(p, g.slot, g.id, roll);
  sound(p, "random.anvil_use"); particle(p, "minecraft:totem_particle", 1.0);
  await notice(p, "打ち直し", [`${gearName(g.id, g.roll)} §7→`, `§l${gearName(g.id, roll)}`, ...gearLines(g.id, roll)].join("\n"));
}

// ---------- 配合 ----------
async function fusionMenu(p, d) {
  const s = await choose(p, "配合", `§f2たいの モンスターから 新しい モンスターが 生まれます。\n§7生まれる 系統は 親の 系統と ランク帯（F〜C／B〜A／S〜SS）で 決まります（図鑑→系統 配合表）。\n§d決まった 2体で 思わぬ 強い 子が 生まれる「奇跡の配合」も！\n§7Sランクは 特別な 2体配合、SSランクは 特別な 4体配合でも 生まれます。\n§7生まれた 子は Lv1ですが プラス値の ぶん 強くなり、スキルを 引き継げます。`,
    [B("§l2たい 配合", ICON("i_fuse")), B("4たい 配合", ICON("i_fuse")), B("§6§l【おすすめ配合】\n§8いちばん 強い 子の 組み合わせ", ICON("i_star")), B("お見合い 配合（ほかの プレイヤーと）", ICON("i_scout")), B("§7戻る", ICON("i_back"))]);
  if (s === 0) await fuseFlow(p, d, 2);
  else if (s === 1) await fuseFlow(p, d, 4);
  else if (s === 2) await recoFuse(p, d);
  else if (s === 3) await omiaiRequest(p, d);
}
// v3.0: 【おすすめ配合】手持ちの 中から いちばん ランクが 高い（強い）子が 生まれる 2体の 組み合わせ
const RK_I = (id) => ["F", "E", "D", "C", "B", "A", "S", "SS", "X"].indexOf(SPECIES[id].rank);
const spPower = (id) => { const S = SPECIES[id]; let t = 0; for (const [k, v] of Object.entries(S.base || {})) t += v + ((S.grow || {})[k] || 0) * 49; return t; };
export function specialKids(parents, kids) {   // 特別な 配合（特別配合・奇跡の配合・4体配合）で 生まれる 子
  const out = new Set();
  if (parents.length === 2) { const ri = romanOf(parents[0], parents[1]); if (ri >= 0) out.add(ROMAN[ri][2]); }
  for (const id of kids) { const S = SPECIES[id]; if (parents.some((m) => m.sp === id)) continue; if (S.special || (parents.length === 4 && S.special4)) out.add(id); }
  if (parents.length === 4) { const have = parents.map((m) => m.sp).sort().join(","); for (const r of RECIPES4) if ([...r.need].sort().join(",") === have) out.add(r.sp); }
  return out;
}
function* recoGen(d, max = 5) {
  const ok0 = (m) => m.lv >= FUSE_LV && !(m.storyMusashi && !(d.story && d.story.enmaClear)) && !String(m.sp).startsWith("book_") && m.id !== d.partnerId;
  const all = allMons(d).filter(ok0);
  // 同じ 種族は 1体（プラス値・レベルの 高い 子）だけで 考える（重く ならない ように）
  const rep = {};
  for (const m of all) { const o = rep[m.sp]; if (!o || (m.plus || 0) > (o.plus || 0) || ((m.plus || 0) === (o.plus || 0) && m.lv > o.lv)) rep[m.sp] = m; }
  const need = new Set();   // 特別配合・奇跡の配合の 親に なる 種族は かならず 入れる
  for (const s of Object.values(SPECIES)) if (s.special) need.add(s.special[0]);
  for (const r of ROMAN) { need.add(r[0]); need.add(r[1]); }
  const reps = Object.values(rep).sort((a, b) => RK_I(b.sp) - RK_I(a.sp) || (b.plus || 0) - (a.plus || 0));
  const cand = [...reps.slice(0, 40), ...reps.slice(40).filter((m) => need.has(m.sp))].slice(0, 90);
  const score = (id, sp, a) => RK_I(id) * 1e6 + spPower(id) + (sp ? 5e5 : 0) + a;
  const res = [];
  let step = 0;
  for (let i = 0; i < cand.length; i++) for (let j = 0; j < cand.length; j++) {
    if (i === j) continue;
    if (++step % 30 === 0) yield null;   // スマホでも 止まらない ように 少しずつ
    const a = cand[i], b = cand[j];
    const kids = fusionCandidates(a, b).filter((id) => SPECIES[id] && id !== a.sp && id !== b.sp);   // 親と 同じ 子は おすすめに しない
    if (!kids.length) continue;
    const sp = specialKids([a, b], kids);
    const best = kids.reduce((x, y) => (score(y, sp.has(y), 0) > score(x, sp.has(x), 0) ? y : x));
    if (parentsAlreadyBetter(a, b, best)) continue;
    res.push({ a, b, sp: best, special: sp.has(best), score: score(best, sp.has(best), (a.plus || 0) + (b.plus || 0)) });
  }
  // 4体配合（決まった 4体が そろって いる とき）
  let r4 = 0;
  for (const r of RECIPES4) {
    if (++r4 % 10 === 0) yield null;
    const used = new Set(), parts = [];
    for (const n of r.need) { const m = all.filter((x) => x.sp === n && !used.has(x.id)).sort((x, y) => (y.plus || 0) - (x.plus || 0))[0]; if (!m) break; used.add(m.id); parts.push(m); }
    if (parts.length !== r.need.length || !SPECIES[r.sp]) continue;
    res.push({ four: parts, a: parts[0], b: parts[1], sp: r.sp, special: true, score: score(r.sp, true, 0) });
  }
  res.sort((x, y) => y.score - x.score);
  const seenK = new Set(), out = [];
  for (const r of res) { if (seenK.has(r.sp)) continue; seenK.add(r.sp); out.push(r); if (out.length >= max) break; }   // 同じ 子は 1回だけ
  return out;
}
export function recoPairs(d, max = 5) { const g = recoGen(d, max); for (;;) { const r = g.next(); if (r.done) return r.value; } }
// 1tick ごとに 少しずつ 計算する（重い 端末でも 固まらない）
function recoPairsAsync(p, d, max = 5) {
  return new Promise((res) => {
    const g = recoGen(d, max); let n = 0;
    const tick = () => { try { const t0 = Date.now(); for (;;) { const r = g.next(); if (r.done) return res(r.value); if (Date.now() - t0 > 25) break; } if (++n % 10 === 0) try { p.onScreenDisplay.setActionBar("§eおすすめ配合を さがして います…"); } catch {} system.runTimeout(tick, 1); } catch { res([]); } };
    tick();
  });
}
const parentsAlreadyBetter = (a, b, sp) => RK_I(sp) < Math.max(RK_I(a.sp), RK_I(b.sp));   // 親より 弱い 子しか 生まれない 組は のぞく
async function recoFuse(p, d) {
  const L = await recoPairsAsync(p, d, 6);
  if (!L.length) { await notice(p, "おすすめ配合", "§7いまの 手持ちでは、親より 強い 子が 生まれる 組み合わせが 見つかりませんでした。\n§f仲間を ふやすか、レベルを 上げてから ためそう。"); return; }
  const k = await choose(p, "【おすすめ配合】", ["§fいまの 手持ちで いちばん 強い 子が 生まれる 組み合わせです。§7（上から 強い 順・親の 順番も このまま）", ...L.map((r, i) => `§e${i + 1}. §f${SPECIES[r.sp].name}§7 ← ${(r.four || [r.a, r.b]).map((m) => `${m.nm} Lv${m.lv}${m.plus ? `+${m.plus}` : ""}`).join(r.four ? "・" : " × ")}`)].join("\n"),
    [...L.map((r, i) => B(`§l${i + 1}. ${ownName(d, r.sp)} §8${SPECIES[r.sp].rank}${r.four ? " §74体配合" : ""}${r.special ? "\n§d【何か特別な気配がする…！】" : ""}`, MON_ICON(r.sp))), B("§7戻る", ICON("i_back"))]);
  if (k < 0 || k >= L.length) return;
  if (L[k].four) await fuseFlow(p, d, 4, L[k].four); else await fuseFlow(p, d, 2, [L[k].a, L[k].b]);
}
const fLabel = (m) => B(monLabel2(m, `${famColor(m.sp)}${FAMILIES.find((f) => f.id === SPECIES[m.sp].fam).name}`), MON_ICON(m.sp));

async function pickParents(p, d, n, opt = null) {
  const cand = opt && opt.filter ? allMons(d).filter(opt.filter) : allMons(d).filter((m) => m.lv >= FUSE_LV || m.sp === "musashi");   /* 第71版: 交換でも 使う */   // v3.0: ムサシは いつでも 親に できる（生まれるのは ムサシだけ）
  if (cand.length < n) { await notice(p, opt && opt.title ? "交換" : "配合", opt && opt.title ? "§7わたせる モンスターが いません。" : `モンスターが ${n}たい 必要です。`); return null; }
  const chosen = [];
  for (let i = 0; i < n; i++) {
    const rest = cand.filter((m) => !chosen.includes(m));
    const sel = await paged(p, opt && opt.title ? opt.title : `配合 ${i + 1}/${n}`, opt && opt.body ? opt.body : `${chosen.length ? `§f選んだ: ${chosen.map((m) => m.nm).join("、")}\n` : ""}§7${i === 0 ? "1たいめ（けっとう）" : `${i + 1}たいめ`}を 選んでください`, rest.map(fLabel));
    if (sel < 0) { if (!chosen.length) return null; chosen.pop(); i -= 2; continue; }   // UX案: 1つ 前の 親を えらびなおす
    chosen.push(rest[sel]);
  }
  return chosen;
}
const FNAME = (id) => FAMILIES.find((f) => f.id === id)?.name || "";
const mxKnown = (d, k, band) => (d.mx || []).includes(`${k}#${band}`) || (band === 0 && (d.mx || []).includes(k));
async function chooseChild(p, d, parents, kids) {
  if (!kids || !kids.length) { await notice(p, "配合", "§7この 組み合わせでは 何も 生まれない。"); return null; }   // v3.0 第63版
  const [mf, sf, band] = mixOf2(parents), fn = FNAME;
  d.mx = d.mx || []; d.rm = d.rm || [];
  const mkey = parents.length === 2 ? mixKey(SPECIES[parents[0].sp].fam, SPECIES[parents[1].sp].fam) : null;
  if (mkey && FAM_MIX3[mkey] && !mxKnown(d, mkey, band)) d.mx.push(`${mkey}#${band}`);
  const ri_ = parents.length === 2 ? romanOf(parents[0], parents[1]) : -1;
  if (ri_ >= 0 && !d.rm.includes(ri_)) d.rm.push(ri_);
  const romanSp = ri_ >= 0 ? ROMAN[ri_][2] : null;
  const spSet = specialKids(parents, kids);
  const k = await paged(p, "生まれる モンスター", `${parents.map((m) => m.nm).join(" × ")}\n§7系統 配合（§f${BAND_NAME[band]}帯§7）: §f${parents.map((m) => fn(SPECIES[m.sp].fam)).join(" × ")} §7→ §e${fn(mf)}${sf !== mf ? ` §7／副 §b${fn(sf)}` : ""}${romanSp ? `\n§d★ 奇跡の配合 成立！ §f${SPECIES[romanSp].name}（${SPECIES[romanSp].rank}）が 生まれる` : ""}\n§7生まれる モンスターを 選んでください\n§b(親と 同じ)§7 を 選ぶと 同じ モンスターの まま プラス値を 上げられる（闘魔覚醒は +99 から）`,
    kids.map((id) => { const S = SPECIES[id], same = parents.some((x) => x.sp === id), nw = d.own.includes(S.idx) ? "" : "§6NEW! §r", fam = FAMILIES.find((f) => f.id === S.fam).name;
      return B(spSet.has(id) ? `§d【特別な気配！】\n${ownName(d, id)} §8${S.rank}` : `${id === romanSp ? "§d★ §r" : ""}${ownName(d, id)}\n§8${S.rank} ${famColor(id)}${fam}${same ? " §b(親と 同じ)" : ""}`, MON_ICON(id)); }));
  if (k < 0) return null;
  const sp = kids[k];
  const opts = fusionSkillChoices(parents, sp);
  const NS = SKILL_N[SPECIES[sp].sz] || 3;
  let skills = [...SPECIES[sp].skills, ...(SPECIES[sp].skx || [])].slice(0, NS);
  const ups0 = Object.values(skillUpgrades(parents)).filter((x) => opts.includes(x));
  const cb0 = comboSkills(parents).filter((x) => opts.includes(x));
  skills = [...new Set([...cb0.slice(0, 2), ...ups0, ...skills, ...cb0])].filter((x) => opts.includes(x)).slice(0, NS);
  for (const x of opts) if (skills.length < NS && !skills.includes(x)) skills.push(x);   // v3.0: 固有スキルは 数えない ので ちょうどに そろえる
  if (opts.length <= NS) skills = [...opts];
  if (cb0.length) await notice(p, "ロマン配合", ["§d§lロマン配合 成立！", ...cb0.map((x) => `§f「${SKILLS[x].name}」 §8${SKILLS[x].desc}`), "", "§7スキルを 選ぶ 画面で §d(ロマン配合)§7 と 書いてある ものです"].join("\n"));
  if (opts.length > NS) {
    for (;;) {
      // 第67版: えらぶ 前に スキルの 技を 見られる
      const pre = await choose(p, `スキルを ${NS}つ 選ぶ`, `§f受けつぐ スキルを ${NS}つ 選びます。\n§7選ぶ 前に、スキルの 中の 技の 効果を 見られます。`, [B("§lスキルを 選ぶ", ICON("i_skill")), B("§bスキルの 技を 見る", ICON("i_spell")), B("§7やめる", ICON("i_back"))]);
      if (pre === 1) { for (;;) { const q = await paged(p, "スキルの 技を 見る", "§7見たい スキルを えらぶ", opts.map((s) => B(`§l${SKILLS[s].name}\n§8${String(SKILLS[s].desc || "").replace(/§./g, "").slice(0, 36)}`, ICON("i_skill"))), 8); if (q < 0 || q >= opts.length) break; await skillMovesView(p, opts[q]); } continue; }
      if (pre !== 0) return null;
      const ups = Object.values(skillUpgrades(parents));
      const v = await modal(p, `スキルを ${NS}つ 選ぶ（${SPECIES[sp].sz}サイズ）`, (f) => opts.forEach((s) => f.toggle(`${SKILLS[s].name}${cb0.includes(s) ? " §d(ロマン配合！)" : ups.includes(s) ? " §d(進化！)" : SPECIES[sp].skills.includes(s) || (SPECIES[sp].skx || []).includes(s) ? " §7(もとから)" : " §e(引き継ぎ)"}`, skills.includes(s))));
      if (!v) return null;
      const picked = opts.filter((_, i) => v[i]);
      if (picked.filter((k) => (KSP || []).includes(k)).length > 1) { await notice(p, "スキル", "§c特別な 秘伝は 1体に 1つまで です。§f どれか 1つに してください。"); continue; }   // 第68版
      if (picked.length === NS) { skills = picked; break; }
      await notice(p, "スキル", `スキルは ちょうど ${NS}つ 選んでください。（いま ${picked.length}つ）`);
    }
  }
  const nats = [...new Set(parents.map((m) => m.nat))];
  const ns = await choose(p, "性格を 選ぶ", `§f生まれる子の 性格を 選んでください。\n§7おすすめ: §b${natureText(SPECIES[sp].rec)}`,
    [...nats.map((n) => B(`${natureText(n)}${n === SPECIES[sp].rec ? " §6★" : ""}`, ICON("i_skill"))), B("ランダム", ICON("i_fuse"))]);
  if (ns < 0) return null;
  return { sp, skills, nat: ns < nats.length ? nats[ns] : undefined };
}
// v2.2: 配合の 親の 装備は、子が 持てる ものは そのまま 子に・持てない ものは バッグへ
export function passGear(p, parents, child) {
  const kept = [], back = [];
  for (const m of parents) for (const s of ["w", "a", "x"]) {
    const id = m.eq && m.eq[s]; if (!id) continue;
    const roll = m.eqr && m.eqr[s];
    if (!child.eq[s] && canEquip(child, id)) { child.eq[s] = id; child.eqr = child.eqr || {}; if (roll) child.eqr[s] = roll; kept.push(gearName(id, roll)); }
    else { giveGear(p, id, roll); back.push(gearName(id, roll)); }
    m.eq[s] = null;
  }
  return { kept, back };
}
function removeMon(p, d, m, keepGear = false) {
  if (d.out === m.id) recallPet(p, d);
  if (!keepGear) { for (const s of ["w", "a", "x"]) if (m.eq && m.eq[s]) giveGear(p, m.eq[s], m.eqr && m.eqr[s]); if (m.eq) { m.eq = { w: null, a: null, x: null }; m.eqr = {}; } }   // v2.9.9: 返した 装備を もう一度 返さない
  for (const list of [d.party, d.bench || [], d.box]) { const i = list.indexOf(m); if (i >= 0) list.splice(i, 1); }
}
async function birth(p, d, child, extra = "", book = null) {
  if (child && child.recSame) { child.noRec = 1; delete child.recSame; }
  addMon(d, child);
  mark(d.own, child.sp); mark(d.seen, child.sp);
  if (book) { addMon(d, book); mark(d.own, book.sp); mark(d.seen, book.sp); }
  d.stats = d.stats || {}; d.stats.fused = (Number(d.stats.fused) || 0) + 1;
  save(p, d);
  particle(p, "minecraft:totem_particle", 1.5); sound(p, "random.levelup");
  await notice(p, "配合 成功！", `§l§e${child.nm}§r（ランク${SPECIES[child.sp].rank}）が 生まれた！\n§fプラス値 §d+${child.plus}§r（能力 ${child.plus}% アップ）\nスキルポイント §e${child.spl}§7（親の 合計の 半分を 受けついだ）${child.inh ? `\n§f受けついだ 能力: §bHP${child.inh.hp} 物力${child.inh.atk} 武力${child.inh.wpn} 魔力${child.inh.mat} 硬力${child.inh.def} 走力${child.inh.spd}` : ""}\n§fスキル: ${child.sk.map((s) => SKILLS[s].name).join(" / ")}\n§f性格: §d${natureText(child.nat)}\n\n${d.party.includes(child) ? "パーティに くわわった。" : (d.bench || []).includes(child) ? "控えに 入った。" : "預かり所に おくられた。"}${extra}`);
}
async function fuseFlow(p, d, n, pre = null) {
  const parents = pre || await pickParents(p, d, n);
  if (!parents) return;
  const kids = n === 4 ? fusion4Candidates(parents) : fusionCandidates(parents[0], parents[1]);
  const c = await chooseChild(p, d, parents, kids);
  if (!c) return;
  const warn = [];   // v3.0: 取り返しの つかない 配合は はっきり 知らせる
  if (parents.some((m) => m.sp === "musashi") && parents.length > 2) warn.push("§c§l注意: ムサシを 親に すると ムサシしか 生まれません。ほかの 親も いなくなります。");
  if (parents.some((m) => isPal(m))) warn.push("§d§l相棒を 親に すると、相棒だけが 生まれます。§r§d見た目・名前・きずなは そのまま、ほかの 親は いなくなります。");
  if (parents.some((m) => SPECIES[m.sp]?.deity !== undefined)) warn.push("§4§l注意: 神が ふくまれて います。神は 二度と 手に 入らず、戦った ときの 能力も 子には 引きつがれません。");   // 第68版
  if (!(await confirm(p, "配合 確認", `${warn.length ? warn.join("\n") + "\n\n" : ""}§c${parents.map((m) => m.nm).join("、")}は いなくなります。§r\n§7（装備は 戻ってきます）\n\n生まれる: ${ownName(d, c.sp)} §8${SPECIES[c.sp].rank}\n§fスキル: §b${c.skills.map((x) => SKILLS[x]?.name).join(" / ")}\n§f性格: §d${c.nat === undefined ? "ランダム" : natureText(c.nat)}`, "配合する", "やめる"))) return;
  if (d.party.length - parents.filter((m) => d.party.includes(m)).length + 1 < 1) return;
  const child = fuse(parents, c.sp, c.skills, c.nat);
  let inh = ""; try { inh = (await inheritFlow(p, d, parents, child)) || ""; } catch {}   // v2.9.12: 親を 消す 前に（とちゅうで 閉じても 親が いなく ならない）
  if (!ok(p)) return;   // disconnect: 抜けた 人の 古い データで 配合を つづけない（装備が バッグと 親の 両方に のこる）
  if (!parents.every((m) => d.party.includes(m) || d.box.includes(m) || (d.bench || []).includes(m))) return;
  const book = makeBook(parents, child);   // disconnect: 子と 魔書を 同じ セーブで（とちゅうで 閉じても 魔書が きえない）
  for (const m of parents) removeMon(p, d, m, true); { const _po = palFix(d, child); if (_po) import("./bond.js").then((B) => B.bondMove(p, _po, child.id)).catch(() => {}); }   /* 第106版: 親を 消した あとで 相棒の 番号と きずなを 子へ */
  const gp = passGear(p, parents, child);
  { const st = calcStats(child); child.hp = st.hp; child.mp = st.mp; }
  await birth(p, d, child, inh + (gp.kept.length ? `\n§a装備を 受けついだ: ${gp.kept.join("・")}` : "") + (gp.back.length ? `\n§7持てない 装備は バッグへ: ${gp.back.join("・")}` : ""), book);
  await bookBirth(p, d, book, true);
}
// v2.2: 魔書の 誕生
async function bookBirth(p, d, b, added = false) {
  if (!b) return;
  if (!added) { addMon(d, b); mark(d.own, b.sp); mark(d.seen, b.sp); save(p, d); }
  sound(p, "mob.evocation_illager.prepare_summon", 0.8); particle(p, "minecraft:knockback_roar_particle", 1);
  await notice(p, "魔書が 生まれた！", [`§5§l${SPECIES[b.sp].name}§r（${SPECIES[b.sp].sz}サイズ・ランク${SPECIES[b.sp].rank}）が 仲間に なった！`,
    `§7子が 受けつがなかった スキル ${b.sk.length}つを 封じこめた 書の モンスター（プラス値 +${b.plus}）`, "", "§f封じた スキル:", ...b.sk.map((k, i) => `§d・${SKILLS[k].name} §7${b.pts[i]}pt`),
    "", "§7配合の 親に すると、この スキルを 子に わたせる。", "§7親の プラス値 25以上→S・50以上→M・75以上→L・99以上→G の 書"].join("\n"));
}

// ---------- マルチプレイ ----------
function nearPlayers(p) {   // v3.0 第63版: 距離・ディメンションの 制限なし（ワールドの 全員）
  return world.getAllPlayers().filter((x) => x.id !== p.id && (() => { try { return x.isValid(); } catch { return false; } })());
}
async function pickPlayer(p, t) {
  const list = nearPlayers(p);
  if (!list.length) { await notice(p, t, "ほかの プレイヤーが いません。"); return null; }
  const s = await choose(p, t, "§7相手を 選んでください", [...list.map((x) => B(`§l${x.name}`, ICON("i_scout"))), B("§7戻る", ICON("i_back"))]);
  return s < 0 || s >= list.length ? null : list[s];
}
// v3.0: もうしこみ（相手が ほかの 画面や 戦いの 最中なら 30秒まで 待つ。返事の 中身を 分けて かえす）
const PENDING = new Map();   // v3.0: もうしこみ中（もうしこんだ 人 → 相手）
async function reqAsk(from, target, t, body, yes = "受ける", keep = false) {
  const alive = (x) => { try { return x.isValid(); } catch { return false; } };
  if (PENDING.get(target.id) === from.id) return { why: "cross" };   // おたがいに 同時に もうしこんだ
  PENDING.set(from.id, target.id);
  // 第63版: 待って いる あいだ「やめる」画面を 出す（返事の 画面は 60秒で 閉じる）
  const st = { cancel: false, done: false };
  if (typeof SUI.uiManager?.closeAllForms === "function") system.runTimeout(async () => { if (st.done || !alive(from)) return; st.shown = true; try { const s0 = await choose(from, t, `§7${target.name}の 返事を 待っています…\n§8（相手が いま ほかの 画面や 戦いの 最中なら 30秒まで 待ちます）`, [["§cもうしこみを やめる", ICON("i_close")]]); if (!st.done && s0 === 0) { st.cancel = true; if (st.asking) try { SUI.uiManager?.closeAllForms(target); } catch {} } } catch {} }, 10);
  try { const r = await reqAsk0(from, target, t, body, yes, keep, alive, st); return st.cancel && !r.ok ? { why: "cancel" } : r; }
  finally { st.done = true; if (st.shown) try { SUI.uiManager?.closeAllForms(from); } catch {} if (PENDING.get(from.id) === target.id) PENDING.delete(from.id); }
}
async function reqAsk0(from, target, t, body, yes, keep, alive, st = {}) {
  if (inBattle(target)) return { why: "battle" };   // v3.0 第63版: 戦闘中なら 待たせない
  if (busy.has(target.id)) {
    try { target.sendMessage(`§e${from.name}§r から §l${t}§r！ §7いまの 画面を 閉じると 返事が できます（30秒まで 待ちます）`); } catch {}
    try { from.sendMessage(`§7${target.name}は いま 別の ことを しています。画面を 閉じるまで 少し 待ちます（30秒まで・返事の 画面は 1分で 閉じます）…`); } catch {}
    for (let k = 0; k < 30 && busy.has(target.id); k++) { await wait(20); if (!alive(target) || !alive(from)) return { why: "gone" }; if (PENDING.get(target.id) === from.id) return { why: "cross" }; if (inBattle(target)) return { why: "battle" }; if (st.cancel) return { why: "cancel" }; }
    if (busy.has(target.id)) return { why: "busy" };
  }
  if (!alive(target)) return { why: "gone" };
  busy.add(target.id);
  let res = null;
  try {
    try { sound(target, "note.pling", 1.4); } catch {}
    if (st.cancel) return (res = { why: "cancel" });
    st.asking = true; let to = false; const tm = system.runTimeout(() => { to = true; try { SUI.uiManager?.closeAllForms(target); } catch {} }, 1200);
    const s = await choose(target, t, `§e§l${from.name}§r から ${body}`, [[`§2§l${yes}`, ICON("i_party")], ["§cことわる", ICON("i_close")]]);
    st.asking = false; try { system.clearRun(tm); } catch {}
    res = st.cancel ? { why: "cancel" } : s === 0 ? { ok: true } : { why: s === 1 ? "no" : to ? "timeout" : "closed" };
    if (res.why === "cancel") try { target.sendMessage(`§7${from.name}は もうしこみを やめた。`); } catch {}
    return res;
  } finally { if (!keep || !res || !res.ok) busy.delete(target.id); }   // 受けた ときだけ 続きの ために いそがしい まま
}
const reqWhy = (tn, why) => ({ busy: `§c${tn}は 30秒 たっても 手が はなせなかった。§7（相手が 画面を 閉じてから もう一度）`, no: `§c${tn}に ことわられた。`,
  closed: `§c${tn}は 返事を せずに 画面を 閉じた。§7（もう一度 もうしこめます）`, gone: `§7${tn}が いなく なった。`, cancel: "§7もうしこみを やめた。", timeout: `§7${tn}は 1分 たっても 返事を しなかった。`, cross: `§e${tn}も あなたに もうしこみ中です。§7この 画面を 閉じると ${tn}の もうしこみが 届きます。`, battle: `§e${tn}は いま 戦闘中です。§7戦いが 終わってから もう一度 もうしこんでください。`, nopick: `§7${tn}は かす モンスターを 選ばなかった。` })[why] || `§c${tn}に 届かなかった。`;
async function multiMenu(p, d, only = -1) {
  const s = only >= 0 ? only : await choose(p, "マルチプレイ", "§fワールドに いる ほかの プレイヤーと あそべます（距離の 制限なし）。\n§7・対戦: パーティどうしで バトル（HPは 減りません。遠くの 相手は 目の前に 来て、終われば もどる）\n§7・お見合い: 相手の モンスターを かりて 配合\n§7・交換 / タヨを おくる\n§7・共闘する: ほかの 人の 戦いに どこからでも さんせん（終われば もとの 場所へ）\n§7・レイドボス: 時々 現れる きょだいな ボスに みんなで 挑む（負けると 消える）",
    [B("§l対戦", ICON("i_fight")), B("お見合い 配合", ICON("i_fuse")), B("交換", ICON("i_box")), B("タヨを おくる", ICON("i_shop")), B("対戦 ランキング", ICON("i_zukan")), B("共有 預かり所", ICON("i_scout")), B("§b§l共闘する §8（ほかの 人の 戦いへ）", ICON("i_party")), B("§7戻る", ICON("i_back"))]);
  if (s === 4) { await notice(p, "対戦 ランキング", rankText()); return; }
  if (s === 5) { await sharedMenu(p, d); return; }
  if (s === 6) {   // v3.0 第63版: 共闘する
    const L = coopList(p);
    if (!L.length) { await notice(p, "共闘する", "§7いま 戦って いる 人は いません。"); return; }
    const k = await choose(p, "共闘する", "§7どの 戦いに さんせんする？（終わると もとの 場所に もどる）", [...L.map((bt) => B("§l" + bt.players.map((x) => x.p.name).join("・") + "\n§8vs " + bt.enemies.filter((e) => e.hp > 0).map((e) => e.name).join("・").slice(0, 30), ICON("i_fight"))), B("§7戻る", ICON("i_back"))]);
    if (k < 0 || k >= L.length) return;
    const msg = coopJoin(p, L[k]); if (msg) { await notice(p, "共闘する", msg); return; }
    return "close";
  }
  if (s === 0) {
    const t = await pickPlayer(p, "対戦");
    if (!t || !load(t)) return;
    const rule = await pickRule(p); if (!rule) return;   // v2.6: ルール別対戦
    p.sendMessage(`§7${t.name}に 対戦を もうしこんだ…（${rule.n}）`);
    const r = await reqAsk(p, t, "対戦の もうしこみ", `対戦を もうしこまれた！\n§7ルール: ${rule.n}\n§7（HPは 減りません。負けても 何も なくなりません）`, "対戦する", true);   // v2.9.6: 待って いる あいだも 「いそがしい」の まま（ほかの 戦いを はじめない）
    if (!r.ok) { await notice(p, "対戦", reqWhy(t.name, r.why)); return r.why === "cross" ? "close" : undefined; }   // v3.0 第63版: 同時の ときは ガイドブックを 閉じて 相手の もうしこみを 受ける
    let pv = false; try { pv = p.isValid(); } catch {} if (!pv) { try { t.sendMessage(`§7${p.name}が いなく なった。`); } catch {} busy.delete(t.id); return; }
    await startPvp(p, t, rule.r);
    busy.add(p.id);
  } else if (s === 1) return await omiaiRequest(p, d);
  else if (s === 2) return await tradeFlow(p, d);
  else if (s === 3) {
    const t = await pickPlayer(p, "タヨを おくる");
    if (!t) return;
    const v = await modal(p, "タヨを おくる", (f) => f.textField(`おくる がく（いま ${d.gold}）`, "100", ""));
    const n = Math.floor(Number(v && v[0]));
    d = load(p) || d;   // 第63版: 入力の あいだに もらった お金を 消さない
    if (!n || n <= 0 || n > d.gold) { await notice(p, "タヨを おくる", "§cその がくは おくれません。"); return; }
    let ok2 = false; try { ok2 = t.isValid(); } catch {}
    const dt = ok2 ? load(t) : null; if (!dt) { await notice(p, "タヨを おくる", "§7相手が いなく なった。"); return; }
    if (dt.gold + n > GOLD_MAX) { await notice(p, "タヨを おくる", `§c${t.name}の サイフが いっぱいです。§7（あと ${gold(Math.max(0, GOLD_MAX - dt.gold))} まで）`); return; }   // v3.0: 上限で 消えない ように
    dt.gold += n; save(t, dt); d.gold -= n; save(p, d); markXfer(p);   // 相手を 先に 保存
    t.sendMessage(`§e${p.name}から ${gold(n)} を もらった！`);
    await notice(p, "タヨを おくる", `${t.name}に ${gold(n)} を おくった。`);
  }
}

/* 第104版: 地方マスターと お見合い配合（勝った マスターの 仲間を 写しで かりる。1日 3回・お礼の お金）*/
EXH.omiaiM = async (p, d, title, team) => {
  const today = new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 10);
  if (!d.omm || d.omm.day !== today) d.omm = { day: today, n: 0 };
  if (d.omm.n >= 3) { await notice(p, "お見合い", "§7きょうの マスターとの お見合いは もう 3回 した。また 明日。"); return; }
  const list = team.filter((t) => SPECIES[t.sid] && SPECIES[t.sid].deity === undefined && !["king", "god"].includes(SPECIES[t.sid].fam));
  if (!list.length) { await notice(p, "お見合い", "§7いまは お見合いに 出せる 子が いない。"); return; }
  const k = await paged(p, `${title}と お見合い`, "§7マスターの 仲間を 写しで かりて 配合します（あなたの 子は 1体 へります）", list.map((t) => [`§l${SPECIES[t.sid].name} §7${SPECIES[t.sid].rank}ランク・${SPECIES[t.sid].famName || ""}`, MON_ICON(t.sid)]), 8);
  if (k < 0 || k >= list.length) return;
  const mine = await pickParents(p, d, 1); if (!mine) return; const A = mine[0];
  if (A.sp === "musashi" || A.sp === "enma" || A.storyMusashi || A.id === d.partnerId || SPECIES[A.sp]?.deity !== undefined) { await notice(p, "お見合い", "§7その 子（相棒・物語の 子・神）は お見合いに 出せない。"); return; }
  const copy = makeMonster(list[k].sid, Math.max(1, A.lv), false); copy.plus = Math.min(A.plus || 0, list[k].plus || 0); copy.nm = `${title}の ${SPECIES[list[k].sid].name}`;   /* 写しは あなたの 子と 同じ Lv・プラス値は 低い ほう（ふやせない）*/
  const fee = 300 + Math.floor(A.lv * 20);
  if (d.gold < fee) { await notice(p, "お見合い", `§cお礼の ${gold(fee)} が 足りない。`); return; }
  const c = await chooseChild(p, d, [A, copy], fusionCandidates(A, copy));
  if (!c) return;
  if (SPECIES[c.sp]?.deity !== undefined && c.sp !== A.sp) { await notice(p, "お見合い", "§7神は お見合いでは 生まれない。"); return; }
  if (!allMons(d).includes(A) || d.gold < fee) { await notice(p, "お見合い", "§c親か お金が 足りなく なった。"); return; }
  const child = fuse([A, copy], c.sp, c.skills, c.nat);
  child.paid = Math.max(2, monSell(A) * 2); delete child.bred;
  let inh = ""; try { inh = (await inheritFlow(p, d, [A, copy], child)) || ""; } catch {}
  if (!ok(p) || !allMons(d).includes(A) || d.gold < fee) return;
  d.gold -= fee; d.omm.n++;
  removeMon(p, d, A, true); { const _po = palFix(d, child); if (_po) import("./bond.js").then((B) => B.bondMove(p, _po, child.id)).catch(() => {}); }
  passGear(p, [A], child);
  await birth(p, d, child, `${inh}\n§7${title}の ${SPECIES[list[k].sid].name}との お見合いで 生まれた。（お礼 ${gold(fee)}）`, null);
};
EXH.stowAll = (p) => stowAll(p, decodeLoreG);   /* 第104版: 遊び場へ 行く ときに 使う */
async function omiaiRequest(p, d) {
  const t = await pickPlayer(p, "お見合い 配合");
  if (!t) return;
  const dt = load(t);
  if (!dt) { await notice(p, "お見合い", "§7相手が いなく なった。"); return; }
  const mine = await pickParents(p, d, 1);
  if (!mine) return;
  const A = mine[0];
  if (A.sp === "musashi") { await notice(p, "お見合い", "§7ムサシは 特別な 武士なので お見合いは できない。"); return; }   // v3.0
  if (SPECIES[A.sp]?.deity !== undefined && !(await confirm(p, "お見合い", "§4§l注意: 神を 親に えらんで います。§r\n§f神は 二度と 手に 入らず、戦った ときの 能力も 子には 引きつがれません。", "それでも 進む", "やめる"))) return;   /* 第69版: 申しこむ 前に */
  p.sendMessage(`§7${t.name}に お見合いを もうしこんだ…`);
  let offered = null, why = "no";   // v2.9.12: 相手の 返事を まつ あいだも 自分は いそがしい まま
  {
    const r = await reqAsk(p, t, "お見合いの もうしこみ", `${A.nm}（ランク${SPECIES[A.sp].rank}）と お見合いを したいそうです。\n§7あなたの モンスターは 減りません（相手が 写しで 配合します）。おれいに 500 ${CURRENCY} もらえます。`, "モンスターを 選ぶ", true);
    try {
      if (r.ok) {
        const list = allMons(dt).filter((m) => m.sp !== "musashi" && m.sp !== "enma" && SPECIES[m.sp]?.deity === undefined);   // 第69版: 神は 写しを かせない（増やせない）
        const sel = await paged(t, "お見合い", "§7相手に かす モンスターを 選んでください（写しを かすので 減りません）", list.map(fLabel), 10);   /* 第67版: 多くても ページで */
        if (sel >= 0 && sel < list.length) offered = list[sel]; else why = "nopick";
      } else why = r.why;
    } finally { if (r.ok) busy.delete(t.id); }
  }
  busy.add(p.id);
  { let pv = false; try { pv = p.isValid(); } catch {} if (!pv) { if (offered) try { t.sendMessage(`§7${p.name}が いなく なったので お見合いは 中止。`); } catch {} return; } }   // 第63版
  if (!offered) { await notice(p, "お見合い", reqWhy(t.name, why)); return why === "cross" ? "close" : undefined; }
  const copy = JSON.parse(JSON.stringify(offered)); delete copy.partner; delete copy.look; delete copy.bond;   /* 第106版: ほかの 人の 相棒は 相棒として うつさない */
  const c = await chooseChild(p, d, [A, copy], fusionCandidates(A, copy));
  if (c && SPECIES[c.sp]?.deity !== undefined && c.sp !== A.sp) { await notice(p, "お見合い", "§7神は お見合いでは 生まれない。"); return; }
  if (!c) { try { t.sendMessage(`§7${p.name}は お見合いを やめた。`); } catch {} return; }
  if (!allMons(d).includes(A)) { await notice(p, "お見合い", "§c親の モンスターが もう いない。"); return; }   // v2.9.9
  if (!ok(t)) { await notice(p, "お見合い", `§7${t.name}が いなく なったので お見合いは 取りやめ。`); return; }   // v2.9.12: 先に 相手を たしかめる（親を 失わない）
  const child2 = fuse([A, copy], c.sp, c.skills, c.nat);
  child2.paid = Math.max(2, monSell(A) * 2); delete child2.bred;   // v2.9.14: お見合いの 子は 自分の 親の 売値までしか 売れない（コピーの 親で もうけられない）
  let inh = ""; try { inh = (await inheritFlow(p, d, [A, copy], child2)) || ""; } catch {}
  if (!ok(p)) return;   // disconnect: 抜けたら 相手に おれいを わたさない・装備を ふやさない
  if (!allMons(d).includes(A)) return;
  removeMon(p, d, A, true); { const _po = palFix(d, child2); if (_po) import("./bond.js").then((B) => B.bondMove(p, _po, child2.id)).catch(() => {}); }
  let paid = false;
  try { const dt2 = load(t); if (dt2) { const today = new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 10); /* 日本の 日づけ */ if (!dt2.omd || dt2.omd.day !== today) dt2.omd = { day: today, n: 0 }; if (dt2.omd.n < 3) { dt2.omd.n++; dt2.gold += 500; paid = true; } save(t, dt2); } } catch {}   // v2.9.12: 相手の 最新の データに たす・おれいは 1日 3回まで
  try { t.sendMessage(paid ? `§e${p.name}との お見合いが せいりつ！ おれいに ${gold(500)} を もらった。` : `§e${p.name}との お見合いが せいりつ！ §7（きょうの おれいは もう もらった）`); } catch {}
  if (copy.eq) copy.eq = { w: null, a: null, x: null };
  passGear(p, [A], child2);
  const book2 = makeBook([A, { ...copy, plus: Math.min(copy.plus || 0, A.plus || 0) }], child2);
  await birth(p, d, child2, `${inh}\n§7${t.name}の ${offered.nm}との お見合いで 生まれた。`, book2);
  await bookBirth(p, d, book2, true);   // 第63版: 借りた 子の プラス値では 魔書を 作れない
}

async function tradeFlow(p, d) {
  const t = await pickPlayer(p, "交換");
  if (!t) return;
  const dt = load(t); if (!dt) return;
  const mine = await pickParents(p, d, 1, { title: "交換：わたす モンスター", body: "§7相手に わたす モンスターを 選んでください §8（神・ムサシ・エンマ・パーティ 最後の 1体は 出ません）", filter: (m) => !m.storyMusashi && m.sp !== "musashi" && m.sp !== "enma" && SPECIES[m.sp]?.deity === undefined && !(d.party.length === 1 && d.party[0] === m) });   /* 第71版 */
  if (!mine) return;
  const A = mine[0];
  if (d.party.length === 1 && d.party[0] === A) { await notice(p, "交換", "最後の パーティの 仲間は 交換できません。"); return; }
  if (SPECIES[A.sp]?.deity !== undefined) { await notice(p, "交換", "§c神は 交換できません。"); return; }   /* 第69版 */
  if (A.storyMusashi || A.sp === "musashi" || A.sp === "enma") { await notice(p, "交換", `§c${A.sp === "enma" ? "エンマ" : "ムサシ"}は 交換できません。`); return; }   // v2.9.14
  // v2.9.9: 交換が おわるまで 2人とも ほかの 操作が できない（とちゅうで 売る・あずける などで ふえる のを ふせぐ）
  busy.add(p.id);
  const r0 = await reqAsk(p, t, "交換の もうしこみ", `${monLabel(A)} と 交換したいそうです。`, "モンスターを 選ぶ", true);
  if (!r0.ok) { await notice(p, "交換", reqWhy(t.name, r0.why)); return r0.why === "cross" ? "close" : undefined; }
  busy.add(t.id);
  try {
    let offered = null;
    {
      const list = allMons(dt).filter((m) => !(dt.party.length === 1 && dt.party[0] === m) && !m.storyMusashi && m.sp !== "musashi" && m.sp !== "enma" && SPECIES[m.sp]?.deity === undefined);   // v2.9.14 第69版: 神は わたせない
      const sel = await paged(t, "交換", "§7わたす モンスターを 選んでください", list.map(fLabel), 10);   /* 第67版 */
      if (sel >= 0 && sel < list.length) offered = list[sel];
    }
    { let pv = false; try { pv = p.isValid(); } catch {} if (!pv) { try { t.sendMessage(`§7${p.name}が いなく なったので 交換は 中止。`); } catch {} return; } }   // 第63版
    if (!offered) { await notice(p, "交換", `${t.name}は モンスターを 選ばなかった。`); return; }
    if (!(await confirm(p, "交換 確認", `${A.nm} と ${t.name}の ${monLabel(offered)} を 交換しますか？\n${ownName(d, offered.sp, "")}${(d.own || []).includes(SPECIES[offered.sp]?.idx) ? "§a仲間に した ことが ある 種族" : "§6まだ 仲間に して いない 種族"}`, "交換する", "やめる"))) { try { t.sendMessage(`§7${p.name}は 交換を やめた。`); } catch {} return; }
    // 最新の データで もう一度 たしかめる
    let tv = false; try { tv = !!t.isValid?.(); } catch {}
    const d1 = load(p), d2 = tv ? load(t) : null;
    const A1 = d1 && allMons(d1).find((m) => m.id === A.id), O1 = d2 && allMons(d2).find((m) => m.id === offered.id);
    if (!A1 || !O1) { await notice(p, "交換", "§c交換できなかった（相手が いなく なったか、モンスターが もう いない）。"); return; }
    removeMon(p, d1, A1);
    removeMon(t, d2, O1);   // v2.9.6: あいての 装備も あいての バッグへ
    for (const [dd, m] of [[d1, O1], [d2, A1]]) { m.eq = { w: null, a: null, x: null }; m.eqr = {}; delete m.partner; delete m.look; delete m.bond;   /* 第106版: 相棒の 印は 相手に うつさない */ { const st = calcStats(m); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp); } addMon(dd, m); mark(dd.own, m.sp); mark(dd.seen, m.sp); }
    save(t, d2); save(p, d1); markXfer(p); markXfer(t);   // 相手を 先に（相手が ぬけて 失敗した ときは こちらも 書かない）
    d = d1; offered = O1;
    try { t.sendMessage(`§a${p.name}と 交換した！ ${A.nm}が 仲間に なった。`); } catch {}
    await notice(p, "交換 せいりつ", `${offered.nm}が 仲間に なった！`);
  } finally { busy.delete(t.id); }
}

// ---------- 街ごとの 品ぞろえ ----------
const TIER_GR = [[-1, 0, 1], [-1, 1, 2, 3], [2, 3, 4], [3, 4, 5, 6], [5, 6, 7], [6, 7, 8, 9], [7, 8, 9], [8, 9, 10]];
// v2.2: 遠くの 街（★7・★8）だけで 売る 品の 値段
const FAR_PRICE = { evostone: 30000, skillbook: 15000, awaken: 600000, egg: { e_rainbow: 90000, e_king: 400000, e_god: 2000000 } };
const shopPrice = (id) => { const it = ITEMS[id]; if (it.price > 0) return it.price; if ((it.kind === "weapon" || it.kind === "armor") && it.wt === 3) return it.noshop ? 0 : 240000; const f = FAR_PRICE[it.kind]; return typeof f === "number" ? f : (f && f[id]) || 0; };
const TOOL_KINDS = ["navi", "skillbook", "talent", "awaken", "evostone", "heal", "mpheal", "cure", "revive", "healall", "fullall", "mpall", "curall", "bregen", "reviveall", "scout", "bbuff", "bdebuff", "bstatus", "escape", "bomb", "call", "warp", "exp", "sp", "respec", "lvup", "nature_rand", "nature_pick", "matbox", "resize", "reforge"];
const EL_JP = EL_NAME;
function srng(seed) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seed.length; i++) { h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return () => { h ^= h << 13; h >>>= 0; h ^= h >>> 17; h ^= h << 5; h >>>= 0; return (h % 1000003) / 1000003; };
}
function shuffled(a, r) { const b = a.slice(); for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; }
const shopTown = (p) => townAt(p.location, 60) || (() => {   // v2.9.12: 城の 店は いちばん 近い 町の 品ぞろえ（前は いつも ルミナ）
  let best = TOWNS[0], bd = 1e18;
  for (const t of TOWNS) { const q = townPos(t), dd = (q.x - p.location.x) ** 2 + (q.z - p.location.z) ** 2; if (dd < bd) { bd = dd; best = t; } }
  return best;
})();
export function townStock(t, s) {
  const r = srng(`${t.id}:${s}`);
  const tier = Math.min(7, t.tier || 0);
  if (s === 4) { const gmax = Math.min(4, Math.floor(tier * 0.6) + 1), fe = [...new Set(t.fams || [])].flatMap((f) => [0, 1, 2, 3, 4].filter((g) => g <= gmax).map((g) => `e_${f}${g}`));   // v3.0: 町の 系統の タマゴ
    return [...new Set([...(t.eggs || ["e_white"]), ...fe])].filter((id) => ITEMS[id] && (ITEMS[id].price > 0 || (tier >= 6 && shopPrice(id) > 0))); }
  if (s === 0) {
    const pool = Object.keys(ITEMS).filter((id) => TOOL_KINDS.includes(ITEMS[id].kind) && ITEMS[id].price > 0 && (ITEMS[id].tier ?? 0) <= Math.min(3, tier));
    const must = pool.filter((id) => (["navi", "heal", "mpheal", "cure", "revive", "warp", "escape", "scout"].includes(ITEMS[id].kind) && (ITEMS[id].tier ?? 0) <= Math.max(0, tier - 1)) || id === "z_small" || id === "z_tos");   /* 第88版: 仲間を 小さく する 品は どの 道具屋にも（町の 段 2 から） */
    const rest = shuffled(pool.filter((id) => !must.includes(id)), r).slice(0, 12 + tier * 2);
    // v2.2: リスポーンから 遠い 街ほど めずらしい 品（才覚の珠・進化の石・スキルの書・闘魔覚醒）
    const far = tier >= 5 ? [...Object.keys(ITEMS).filter((id) => (ITEMS[id].kind === "talent" && (tier >= 6 || ITEMS[id].mode === "one")) || (tier >= 7 && ITEMS[id].kind === "awaken")),
      ...shuffled(Object.keys(ITEMS).filter((id) => ["evostone", "skillbook"].includes(ITEMS[id].kind) && !ITEMS[id].spec), r).slice(0, (tier - 4) * 4)] : [];
    return [...new Set([...must, ...rest, ...far])].sort((a, b) => SHOP_ORDER.indexOf(ITEMS[a].kind) - SHOP_ORDER.indexOf(ITEMS[b].kind) || ITEMS[a].price - ITEMS[b].price);
  }
  const kind = ["", "weapon", "armor", "acc"][s];
  const gr = TIER_GR[tier];
  const wt = [0, 0, 1, 1, 2, 2, 3, 3][tier];   // 街の ランクで 売る 段（★7からは 四段も 売る）
  const pool = Object.keys(ITEMS).filter((id) => ITEMS[id].kind === kind && !ITEMS[id].noshop && shopPrice(id) > 0 && (kind === "acc" ? (ITEMS[id].tier ?? 0) <= tier : (ITEMS[id].wt ?? 0) <= wt && (ITEMS[id].wt ?? 0) >= wt - 1) && (!ITEMS[id].el || ITEMS[id].el === t.el || r() < 0.3));
  const fav = pool.filter((id) => ITEMS[id].el === t.el || (ITEMS[id].res && ITEMS[id].res[t.el] > 0));
  return [...new Set([...shuffled(fav, r).slice(0, 4), ...shuffled(pool, r)])].slice(0, 14).sort((a, b) => ITEMS[a].price - ITEMS[b].price);
}
const priceAt = (t, id) => Math.max(1, Math.round(shopPrice(id) * (t.pm || 1)));
export const sellPrice = (id) => ITEMS[id].sell != null && !RECIPES[id] ? ITEMS[id].sell : Math.max(1, Math.floor((ITEMS[id].price || 200) * (RECIPES[id] ? 0.1 : 0.3)));   // v2.9.12: 作れる 品は 1割（作って 売る だけで もうからない ように）
const SHOP_NAMES = ["道具屋", "武器屋", "防具屋", "アクセサリー屋", "タマゴ屋"];

// ---------- ショップ・宿屋 ----------
const SHOP_ORDER = ["heal", "mpheal", "cure", "revive", "healall", "mpall", "curall", "bregen", "reviveall", "fullall", "scout", "bbuff", "bdebuff", "bstatus", "escape", "bomb", "matbox", "call", "warp", "egg", "weapon", "armor", "acc", "exp", "sp", "respec", "lvup", "seed", "reforge"];
export async function shopMenu(p, d, only = -1) {
  const t = shopTown(p);
  const tag = `§7${t.name}  §8特産: ${EL_JP[t.el] || ""}属性・値段 ×${(t.pm || 1).toFixed(2)}`;
  for (;;) {
    let s = only;
    if (only < 0) {
      s = await choose(p, "ショップ", `§fお金: ${gold(d.gold)}\n${tag}\n§7何を しますか？`, [B("§l道具屋", ICON("i_item")), B("武器屋", ICON("i_fight")), B("防具屋", ICON("i_guard")), B("アクセサリー屋", ICON("i_equip")), B("タマゴ屋", ICON("i_egg")), B("§2売る", ICON("i_shop")), ...(endingDone(d) ? [B("§5怪しい 薬屋 §8（店の 奥）", ICON("i_item"))] : []), B("§7戻る", ICON("i_back"))]);
      if (s === 6 && endingDone(d)) { await shadyShop(p, d); continue; }
      if (s < 0 || s > 5) return;
      if (s === 5) { await sellMenu(p, d); continue; }
    } else {
      const a = await choose(p, SHOP_NAMES[s], `§fいらっしゃい！ §fお金: ${gold(d.gold)}\n${tag}`, [B("§l買う", ICON("i_shop")), B("§2売る", ICON("i_bag")), B("§7戻る", ICON("i_back"))]);
      if (a === 1) { await sellMenu(p, d); continue; }
      if (a !== 0) return;
    }
    const capS = rankCap(d), shopWt = (id) => !(ITEMS[id].kind === "weapon" || ITEMS[id].kind === "armor") || (ITEMS[id].wt ?? 0) < Math.max(1, wtCap(capS));   /* 第103版: 店の 武器・防具は いまの 段の 1つ 下まで（いまの 段は クラフトと 拾う もの）*/
    let list = townStock(t, s).filter((id) => storyLootOk(ITEMS[id], EGGS[id]?.ranks, capS) && shopWt(id));   // v2.9.12: 物語の 進みで 解禁
    // 第66版: 物語の 序盤に 遠くの 街へ 行くと 武器・防具・アクセサリーが 空に なる 不具合 → 今 買える 段の 品で うめる
    if (s >= 1 && s <= 3 && list.length < 8) {
      const kind = ["", "weapon", "armor", "acc"][s], rr = srng(`${t.id}:fb${s}:${capS}`);
      const fb = Object.keys(ITEMS).filter((id) => ITEMS[id].kind === kind && !ITEMS[id].noshop && shopPrice(id) > 0 && !list.includes(id) && storyLootOk(ITEMS[id], undefined, capS) && shopWt(id) && (kind !== "acc" || (ITEMS[id].tier ?? 0) <= Math.max(1, Math.min(7, t.tier || 0))));
      const top = Math.max(-1, ...fb.map((id) => ITEMS[id].wt ?? ITEMS[id].tier ?? 0));
      const near = fb.filter((id) => (ITEMS[id].wt ?? ITEMS[id].tier ?? 0) >= top - 1), fav = near.filter((id) => ITEMS[id].el === t.el);
      list = [...new Set([...list, ...shuffled(fav, rr).slice(0, 3), ...shuffled(near, rr)])].slice(0, 12).sort((a, b) => ITEMS[a].price - ITEMS[b].price);
    }
    for (;;) {
      const sel = await paged(p, `${SHOP_NAMES[s]}（${t.name.split(" ").pop()}）`, `§fお金: ${gold(d.gold)}\n${tag}${s >= 1 && s <= 3 ? "\n§7街ごとに 品ぞろえが 違う。遠くの 街ほど 強い 装備" : ""}`,
        list.map((id) => B(`${ITEMS[id].name}  §e${priceAt(t, id)}${d.gold < priceAt(t, id) ? " §c×" : ""}${ITEMS[id].el === t.el ? " §6★" : ""}\n§7${clipT(itemDesc(id), 28)}`, ITEM_ICON(id))));
      if (sel < 0) break;
      const id = list[sel], it = ITEMS[id], pr = priceAt(t, id);
      if (it.kind === "skillbook" && SKILLS[it.skill]) {   // UX案: 買う 前に 中身を 見る
        let go = false;
        for (;;) { const v = await choose(p, it.name, `${skillPreview(it.skill)}\n${LINE}\n§f値段 ${gold(pr)}`, [B("§l買う", ICON("i_shop")), B("§b技の くわしい 効果を 見る", ICON("i_spell")), B("§7やめる", ICON("i_back"))]);
          if (v === 1) { await skillMovesView(p, it.skill); continue; } go = v === 0; break; }
        if (!go) continue;
      }
      const maxN = Math.min(64, Math.floor(d.gold / pr));
      if (maxN < 1) { await notice(p, "ショップ", "§cお金が たりません。"); continue; }
      let n = 1;
      if (maxN > 1 && !["weapon", "armor", "acc"].includes(it.kind)) {
        const v = await modal(p, `${it.name}を かう`, (f) => f.slider(`いくつ かう？ （1こ ${pr}）`, 1, maxN, 1, 1));
        if (!v) continue; n = Math.max(1, Math.min(maxN, Math.floor(Number(v[0]) || 1)));   /* 第67版: 変な 値を はじく */
        if (d.gold < pr * n) continue;
      } else if (!(await confirm(p, it.name, `§l§e${it.name}§r\n§f${itemDesc(id)}\n\n§f値段 ${gold(pr)}\n§7（もっている ${gold(d.gold)}）`, "かう", "やめる"))) continue;
      d.gold -= pr * n; save(p, d);
      if (isGear(id)) { const r = capRoll(p, id, rollGear(id, "shop")); giveGear(p, id, r); p.sendMessage(`§a${gearName(id, r)}§aを 買った！ 残り ${d.gold} ${CURRENCY}`); sound(p, "random.orb"); }
      else { giveItem(p, `mrpg:${id}`, n); sound(p, "random.orb");
      p.sendMessage(`§a${it.name}を ${n}個 買った！ 残り ${d.gold} ${CURRENCY}`); }
    }
    if (only >= 0) continue;
  }
}

// v2.5.4: 特性の秘薬（好きな 特性を 1つ。1体 1回）
const PICK_NG = /^(act|famking|metal_|nocap|revive|undying|h_|ut_|ct_|cet_|cxt_|cct_|cy_|tg_special|tg2_special)/;
async function traitPickFlow(p, d, id) {
  const m = await pickMon(p, d, "特性の秘薬を 誰に 使う？", "§7好きな 特性を 1つ 追加できる（1体に 1回だけ）");
  if (!m) return;
  if (m.xtr && m.xtr !== "metal") { await notice(p, "特性の秘薬", `§c${m.nm}は もう 特性の秘薬を 使っている。§7（${TRAITS[m.xtr]?.name}）`); return; }
  /* 第88版: あとから つけた ハガネボディ（戦いで HP 1割）は もう 一度 秘薬を 使えば ほかの 特性に かえられる */
  if (m.xtr === "metal" && !(await confirm(p, "特性の秘薬", `§f${m.nm}の §8ハガネボディ§f を ほかの 特性に かえますか？\n§7（戦いで HPが 1割に なる 状態が もとに もどる）`, "かえる", "やめる"))) return;
  for (;;) {
    const cats = TR_CATS.map(([n, re]) => [n, Object.keys(TRAITS).filter((t) => !TRAITS[t].rare && re.test(t) && !PICK_NG.test(t) && !traitIds(m).includes(t))]).filter(([, l]) => l.length);
    const c = await paged(p, "特性の秘薬", `§f${m.nm}に つける 特性の 分類を 選んでください`, cats.map(([n, l]) => B(`${n} §8${l.length}`, ICON("i_skill"))), 8);
    if (c < 0) return;
    const ids = cats[c][1];
    const k = await paged(p, cats[c][0], "§7つける 特性を 選んでください", ids.map((t) => B(`${TRAITS[t].name}\n§7${TRAITS[t].desc.slice(0, 28)}`, ICON("i_skill"))), 8);
    if (k < 0) continue;
    const t = ids[k];
    const mw = t === "metal" ? `\n\n§c§l注意: 戦いでは HPが 1割に なります§r§c（例: HP ${calcStats(m).hp} → 約 ${Math.max(1, Math.floor(calcStats(m).hp * 0.1))}）。物理系・武系・特質系は ふつうに 受けます。§7（もう 一度 特性の秘薬を 使えば ほかの 特性に かえられる）` : "\n\n§c1体に 1回だけ（あとから かえられない）";
    if (!(await confirm(p, "特性の秘薬", `§f${m.nm}に §a${TRAITS[t].name}§f を つけますか？\n§7${TRAITS[t].desc}${mw}`, "つける", "やめる"))) continue;
    if (!takeItem(p, `mrpg:${id}`)) return;
    { const d2 = load(p); const m2 = d2 && allMons(d2).find((x) => x.id === m.id); if (m2) { m2.xtr = t; save(p, d2); } else { m.xtr = t; save(p, d); } } sound(p, "random.levelup");
    await notice(p, "特性の秘薬", `§a${m.nm}は 特性【${TRAITS[t].name}】を 身につけた！`);
    return;
  }
}
// v2.5.4: 怪しい 薬屋（物語の あと）
export async function shadyShop(p, d) {
  for (;;) {
    const list = SHADY.filter(([i]) => ITEMS[i]);
    const sel = await paged(p, "§5怪しい 薬屋", `§5「ヒッヒッ……物語を 見届けた 者にだけ 売る 品さ。高いよォ」\n§fお金: ${gold(d.gold)}`,
      list.map(([i, pr]) => B(`${ITEMS[i].name}  §e${pr}${d.gold < pr ? " §c×" : ""}\n§7${clipT(itemDesc(i), 28)}`, ITEM_ICON(i))), 8);
    if (sel < 0) return;
    const [i, pr] = list[sel];
    const maxN = Math.min(20, Math.floor(d.gold / pr));
    if (maxN < 1) { await notice(p, "怪しい 薬屋", "§5「金が 足りないねェ……」"); continue; }
    let n = 1;
    if (maxN > 1) { const v = await modal(p, `${ITEMS[i].name}を かう`, (f) => f.slider(`いくつ かう？ （1こ ${pr}）`, 1, maxN, 1, 1)); if (!v) continue; n = Math.max(1, Math.min(maxN, Math.floor(Number(v[0]) || 1))); if (d.gold < pr * n) continue; }
    else if (!(await confirm(p, ITEMS[i].name, `§f${itemDesc(i)}\n\n§f値段 ${gold(pr)}`, "かう", "やめる"))) continue;
    d.gold -= pr * n; save(p, d); giveItem(p, `mrpg:${i}`, n); sound(p, "random.orb");
    p.sendMessage(`§5${ITEMS[i].name}を ${n}個 買った。§7残り ${d.gold} ${CURRENCY}`);
  }
}

// ---------- 図書館・物知り（特別配合の ヒント）----------
const SPECIALS = () => ORDER.filter((x) => SPECIES[x].special || SPECIES[x].special4);
const ingOf = (x) => SPECIES[x].special4 || [SPECIES[x].special[0]];
function hintCands(d) {
  const all = SPECIALS().filter((x) => !(d.hints || []).includes(x));
  const own = new Set(d.own);
  const near = all.filter((x) => ingOf(x).some((y) => own.has(SPECIES[y].idx)));
  return { all, near };
}
const BOOKS = ["古い 配合の きろく", "まものがくしゃの ノート", "王家の ひみつの ほん", "海の いいつたえ", "けんごうの まきもの", "神がみの しんわ", "石板の けんきゅう", "忘れられた にっき"];
async function libraryMenu(p, d) {
  const t = shopTown(p), day = dayKey(), key = `${t.id}:${day}`;
  d.lib = Object.fromEntries(Object.entries(d.lib || {}).filter(([k]) => k.endsWith(`:${day}`)));
  for (;;) {
    const left = 3 - (d.lib[key] || 0);
    const s = await choose(p, "図書館", `§fしずかに ほんを よもう。\n§7この 図書館で 今日 読める ほん: §e${left}§7さつ（毎日 戻る）\n§7知った 配合は 図鑑→「配合メモ」に 残る`,
      [B(left > 0 ? "§l§dほんを 読む\n§8特別配合の ヒント" : "§8ほんを 読む（今日は もう 読めない）", ICON("i_zukan")), B("アストラ大陸の 歴史", ICON("i_help")), B("§7戻る", ICON("i_back"))]);
    if (s === 1) { await notice(p, "歴史", WORLD_TEXT); continue; }
    if (s !== 0) return;
    if (left <= 0) { await notice(p, "図書館", "§7今日は もう つかれた…。また 明日 きてね。"); continue; }
    d.mx = d.mx || []; d.rm = d.rm || [];
    const roll = Math.random();
    const unk = []; for (const k of Object.keys(FAM_MIX3)) for (let b = 0; b < 3; b++) if (!mxKnown(d, k, b)) unk.push([k, b]);
    if (unk.length && roll < 0.35) {
      const [k, b] = unk[Math.floor(Math.random() * unk.length)], [a, c] = k.split("|"), fn = FNAME, [m1, m2] = FAM_MIX3[k][b];
      d.mx.push(`${k}#${b}`); d.lib[key] = (d.lib[key] || 0) + 1; save(p, d); sound(p, "item.book.page_turn");
      await notice(p, "系統 配合の 本", `§7…ページを めくると こう書いてあった。\n\n§f「§e${fn(a)}§f と §e${fn(c)}§f の 血が 交わる時、親が §b${BAND_NAME[b]}§f の 強さなら、§d${fn(m1)}§f${m2 !== m1 ? ` か §d${fn(m2)}§f` : ""} が 生まれる」\n\n§d※ 図鑑→系統 配合表 に 書き留めた`);
      continue;
    }
    const unr = ROMAN.map((_, i) => i).filter((i) => !d.rm.includes(i));
    if (unr.length && roll < 0.7) {
      const own = new Set(d.own);
      const near = unr.filter((i) => own.has(SPECIES[ROMAN[i][0]].idx) || own.has(SPECIES[ROMAN[i][1]].idx));
      const pool = near.length && Math.random() < 0.7 ? near : unr;
      const i = pool[Math.floor(Math.random() * pool.length)], [a, b, t] = ROMAN[i];
      d.rm.push(i); d.lib[key] = (d.lib[key] || 0) + 1; save(p, d); sound(p, "item.book.page_turn");
      await notice(p, "奇跡の配合の 書", `§7…古びた 本に こう書いてあった。\n\n§f「${famColor(a)}${SPECIES[a].name}§f（${SPECIES[a].rank}）と ${famColor(b)}${SPECIES[b].name}§f（${SPECIES[b].rank}）。\nこの 二体が 結ばれる時、§d${SPECIES[t].name}§f（§6${SPECIES[t].rank}§f）が 生まれる」\n\n§d※ 図鑑→奇跡の配合 に 書き留めた`);
      continue;
    }
    const { all, near } = hintCands(d);
    if (!all.length) { await notice(p, "図書館", "§6すべての 特別配合を 知っている！ あなたは 配合の たつじんだ。"); return; }
    const pool = near.length && Math.random() < 0.75 ? near : all;
    const x = pool[Math.floor(Math.random() * pool.length)];
    d.hints = d.hints || []; d.hints.push(x); d.lib[key] = (d.lib[key] || 0) + 1; save(p, d);
    sound(p, "item.book.page_turn");
    await notice(p, BOOKS[Math.floor(Math.random() * BOOKS.length)], [`§7…ページを めくると こう かいてあった。`, "", `§f「${famColor(x)}${SPECIES[x].name}§f（ランク${SPECIES[x].rank}）は、`, recipeText(x), "§fに よって 生まれると いう」", "", "§d※ 配合メモに かきとめた"].join("\n"));
  }
}
const SAGE_LINES = ["ここだけの はなし なんだがね…", "むかし きいた 噂 なんだけど…", "わしの じいさんが いっておった。", "たびの とちゅうで みた ことが あるの。"];
async function sageTalk(p, d) {
  if (Math.random() < 0.4) {
    const i = Math.floor(Math.random() * ROMAN.length), [a, b, t] = ROMAN[i];
    await notice(p, "物知り", `§7${SAGE_LINES[Math.floor(Math.random() * SAGE_LINES.length)]}\n\n§f「§e${SPECIES[a].name}§f と ${FNAME(SPECIES[b].fam)}の ランク${SPECIES[b].rank}の 誰かを 合わせると、§6ランク${SPECIES[t].rank}§f の ${FNAME(SPECIES[t].fam)}が 生まれる…という 噂じゃ。相手が 誰かは 忘れてしもうた」\n\n§8（図書館の 奇跡の配合の 書で 確かめよう）`);
    return;
  }
  const { all, near } = hintCands(d);
  if (!all.length) { await notice(p, "物知り", "§fもう わしが 教える ことは ないのう。"); return; }
  const pool = near.length ? near : all;
  const x = pool[Math.floor(Math.random() * pool.length)], sp = SPECIES[x], ing = ingOf(x);
  const known = SPECIES[ing[Math.floor(Math.random() * ing.length)]];
  const famN = FAMILIES.find((f) => f.id === sp.fam)?.name || "";
  const body = sp.special4
    ? `「${famN}の ランク${sp.rank}の モンスターは、§e${known.name}§f を ふくむ §e4たい§f を あわせると 生まれる らしい。残りの 3たいは… 忘れてしもうた」`
    : `「§e${known.name}§f に §e${(sp.special[1] === "*" ? "どの 系統でも" : FAMILIES.find((f) => f.id === sp.special[1])?.name || "")}§f の ${["F", "E", "D", "C", "B", "A", "S", "SS", "X"][sp.special[2] ?? 4]}ランク 以上の 仲間を あわせると、${famN}の めずらしい モンスターが 生まれる らしいぞ」`;
  await notice(p, "物知り", `§7${SAGE_LINES[Math.floor(Math.random() * SAGE_LINES.length)]}\n\n§f${body}\n\n§8（詳しくは 図書館の ほんで 調べよう）`);
}

// ---------- モンスター屋 ----------
const RANK_PRICE = { F: 300, E: 700, D: 1500, C: 3000, B: 6500, A: 16000, S: 45000, SS: 150000, X: 500000 };   // v2.9.12: SS・Xも（前は 値段が こわれて いた）
const MS_RANKS = [["F", "E"], ["E", "D"], ["D", "C"], ["C", "B"], ["B", "A"], ["A", "B", "S"], ["A", "S"], ["S", "SS"]];
const MS_LV = [3, 10, 20, 32, 45, 60, 70, 80];
function dayKey() { try { return world.getDay(); } catch { return Math.floor(Date.now() / 3600000); } }
function monStock(t, capM = 8) {
  const day = dayKey(), r = srng(`${t.id}:ms:${day}`), tier = Math.min(7, t.tier || 0);
  const out = [];
  for (let i = 0; i < 6; i++) {
    const rs0 = MS_RANKS[tier], rs = rs0.filter((r) => RANK_LBL.indexOf(r) <= capM).length ? rs0.filter((r) => RANK_LBL.indexOf(r) <= capM) : [RANK_LBL[Math.min(capM, 7)]];   // v2.9.12: 物語の 進みで 解禁
    const rank = rs[Math.min(rs.length - 1, r() < 0.65 ? 0 : r() < 0.9 || rs.length < 3 ? 1 : 2)];   // v2.9.12: 上限で 1つしか ない ときも こわれない
    const fam = r() < 0.65 ? (t.fams || [])[Math.floor(r() * (t.fams || []).length)] : null;
    let pool = ORDER.filter((x) => !SPECIES[x].hidden && !SPECIES[x].fuseonly && SPECIES[x].rank === rank && SPECIES[x].fam !== "king" && SPECIES[x].fam !== "god" && (!fam || SPECIES[x].fam === fam));
    if (!pool.length) pool = ORDER.filter((x) => !SPECIES[x].hidden && !SPECIES[x].fuseonly && SPECIES[x].rank === rank && SPECIES[x].fam !== "king" && SPECIES[x].fam !== "god");
    const sid = pool[Math.floor(r() * pool.length)];
    if (!sid) continue;
    const lv = Math.max(1, Math.min(MAXLV, MS_LV[tier] + Math.floor(r() * 5) - 2));
    out.push({ sid, lv, price: Math.round((RANK_PRICE[rank] || 150000) * (1 + lv / 50) * (t.pm || 1)), key: `${t.id}:${day}:${i}` });
  }
  return out;
}
const SELL_RANK = { ...RANK_PRICE, SS: 50000, X: 50000 };   // v2.9.12: 売値は 前と 同じ（店の 値段を 直した ぶんで 高く ならない）
const monSell = (m) => { const v = Math.floor(((SELL_RANK[SPECIES[m.sp].rank] || 50000) * 0.35 * (1 + m.lv / 40) + (m.plus || 0) * 40) * (m.bred ? 0.15 : m.paid > 0 ? 1 : 0.25));   /* v3.0 第63版: 野生で 仲間に した 子は 4分の1 */ return m.paid > 0 ? Math.min(v, Math.floor(m.paid * 0.5)) : v; };   /* v2.9.12: 買った 子・買った タマゴの 子は 買値の 半分まで（育てて 売る だけで もうからない） */   // 育て屋の 子は 安い
export async function monsterShop(p, d) {
  const t = shopTown(p);
  for (;;) {
    const s = await choose(p, "モンスター屋", `§fいらっしゃい！ ${t.name.split(" ").pop()}の モンスター屋だよ。\n§fお金: ${gold(d.gold)}\n§7品物（${(t.fams || []).map((f) => FAMILIES.find((x) => x.id === f)?.name || "").join("・")} が おおい）は 毎日 かわる`,
      [B("§lモンスターを 買う", ICON("i_party")), B("§2モンスターを 売る", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
    if (s === 0) await monBuy(p, d, t);
    else if (s === 1) await monSellMenu(p, d);
    else return;
  }
}
async function monBuy(p, d, t) {
  for (;;) {
    const day = dayKey();
    d.msb = Object.fromEntries(Object.entries(d.msb || {}).filter(([k]) => k.split(":")[1] === String(day)));
    const list = monStock(t, rankCap(d));
    const sel = await paged(p, "モンスターを 買う", `§fお金: ${gold(d.gold)}\n§7預かり所 ${d.box.length}たい`,
      list.map((x) => { const sp = SPECIES[x.sid]; const sold = d.msb[x.key]; return B(`${sold ? "§8【うりきれ】" + sp.name : ownName(d, x.sid)} §8Lv${x.lv} ${sp.rank} [${sp.sz}]\n${sold ? "§8" : d.gold < x.price ? "§c" : "§e"}${x.price} ${CURRENCY}  §7${sp.famName}`, MON_ICON(x.sid)); }));
    if (sel < 0) return;
    const x = list[sel], sp = SPECIES[x.sid];
    if (d.msb[x.key]) { await notice(p, "モンスター屋", "§7その こは もう うりきれ。明日 また きてね。"); continue; }
    const body = [`§l${famColor(x.sid)}${sp.name}§r  §7${sp.famName}・ランク${sp.rank}・${SIZE_NAME[sp.sz] || sp.sz}`, `§fLv${x.lv}  値段 ${gold(x.price)}`, LINE, ...traitList(x.sid), `§7${rideInfo(x.sid).replace(/§./g, "")}`].join("\n");
    if (!(await confirm(p, "モンスターを 買う", body + "\n\n§fこの こを 仲間に しますか？", "かう", "やめる"))) continue;
    if (d.gold < x.price) { await notice(p, "モンスター屋", "§cお金が たりません。"); continue; }
    if (d.box.length >= BOX_MAX && !canJoin(d, { sp: x.sid })) { await notice(p, "モンスター屋", "§c預かり所が いっぱいです。"); continue; }
    const m = makeMonster(x.sid, x.lv, true);
    tuneMonster(m, 0.25); giveHidden(m, 0.02); m.paid = x.price; const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
    d.gold -= x.price; d.msb[x.key] = 1;
    addMon(d, m); mark(d.own, m.sp); mark(d.seen, m.sp); save(p, d);
    particle(p, "minecraft:totem_particle", 1.2); sound(p, "random.levelup");
    await notice(p, "モンスター屋", `§a${m.nm}が 仲間に なった！\n${d.party.includes(m) ? "パーティに くわわった。" : "預かり所へ おくった。"}`);
  }
}
async function monSellMenu(p, d) {
  for (;;) {
    const list = [...d.party.map((m) => [m, "party"]), ...(d.bench || []).map((m) => [m, "bench"]), ...d.box.map((m) => [m, "box"])];
    const sel = await paged(p, "モンスターを 売る", `§fお金: ${gold(d.gold)}\n§7うった モンスターは 戻って こない。パーティの 最後の 1たいは うれない`,
      list.map(([m, w]) => B(`${monName(m)}\n§e${monSell(m)} ${CURRENCY}${w === "party" ? " §b表" : ""} ${monInfo(m)}`, MON_ICON(m.sp))));
    if (sel < 0) return;
    const [m, w] = list[sel];
    if (w === "party" && d.party.length <= 1) { await notice(p, "モンスターを 売る", "§cパーティの 最後の 1たいは うれません。"); continue; }
    if (m.storyMusashi && !(d.story && d.story.enmaClear)) { await notice(p, "モンスターを 売る", "§cムサシ§f「売るな売るな！ 俺は 商品じゃねえ！」"); continue; }
    const pr = monSell(m);
    if (!(await confirm(p, "モンスターを 売る", `${monLabel(m)}\n§fを ${gold(pr)} で うりますか？\n§c※ もとに もどせません${SPECIES[m.sp]?.deity !== undefined ? "\n§4§l神は 二度と 手に 入りません！" : ""}`, "うる", "やめる"))) continue;
    removeMon(p, d, m);   // v2.9.6: 装備は バッグへ もどす
    d.gold += pr; save(p, d); sound(p, "random.orb"); markXfer(p);   // v2.9.12: 売った あとは 前の バックアップに もどせない
    p.sendMessage(`§a${m.nm}を ${pr} ${CURRENCY}で うった。`);
  }
}
async function sellMenu(p, d) {
  const s0 = await choose(p, "売る", `§fお金: ${gold(d.gold)}`, [B("§l道具・素材", ICON("i_item")), B("§l装備 §8（レア度が 高いほど 高く 売れる）", ICON("i_fight")), B("§7戻る", ICON("i_back"))]);
  if (s0 === 1) {
    const gl = gearSlots(p).sort((a, b) => gearPower(a.id, a.roll) - gearPower(b.id, b.roll));
    if (!gl.length) { await notice(p, "売る", "売れる 装備が ありません。"); return; }
    const gp = (g) => Math.max(1, Math.min(Math.floor((ITEMS[g.id].price || 200) * 0.8), Math.floor((ITEMS[g.id].price || 200) * (RECIPES[g.id] ? 0.1 : 0.3) * (1 + 0.2 * (g.roll ? g.roll.r : 1)))));   // v2.9.12: 買った 値段より 高く 売れない（作れる 装備は 1割から）
    const k = await paged(p, "装備を 売る", `§fお金: ${gold(d.gold)}`, gl.map((g) => B(`${gearName(g.id, g.roll)}  §e${gp(g)}\n§7${gearLines(g.id, g.roll).slice(1).join(" ").replace(/§8\([^)]*\)/g, "").slice(0, 30)}`, ITEM_ICON(g.id))), 6);
    if (k < 0) return;
    const g = gl[k];
    if (g.roll && g.roll.r >= 5 && !(await confirm(p, "売る", `§l${gearName(g.id, g.roll)}§r を 本当に 売りますか？`, "売る", "やめる"))) return;
    if (takeSlot(p, g.slot, g.id)) { d.gold += gp(g); save(p, d); sound(p, "random.orb"); }
    return;
  }
  if (s0 !== 0) return;
  const have = Object.entries(rpgItems(p)).filter(([id]) => !["money", "bslab", "dslab", "key", "xslab", "navi"].includes(ITEMS[id].kind) && !isGear(id) && id !== "sx_meet");   // v2.9.12: 物語の 石板・だいじなもの は 売れない
  if (!have.length) { await notice(p, "うる", "うれる ものが ありません。"); return; }
  const price = (id) => ITEMS[id].kind === "treasure" ? ITEMS[id].val : sellPrice(id);
  have.sort((a, b) => (ITEMS[b[0]].kind === "treasure") - (ITEMS[a[0]].kind === "treasure"));
  const tre = have.filter(([id]) => ITEMS[id].kind === "treasure");   /* 第71版: お宝を まとめて 売る */
  const sel = await paged(p, "うる", `§fお金: ${gold(d.gold)}\n§7はんがくで かいとります（§6お宝§7は 満額）`, have.map(([id, n]) => B(`${ITEMS[id].name} §8×${n}  §e${price(id)}`, ITEM_ICON(id))), 8, tre.length ? [B(`§6§lお宝を ぜんぶ 売る\n§e${gold(tre.reduce((a, [id, n]) => a + ITEMS[id].val * n, 0))}`, ICON("i_shop"))] : []);
  if (sel === -2 && tre.length) {
    const sum = tre.reduce((a, [id, n]) => a + ITEMS[id].val * n, 0);
    if (!(await confirm(p, "お宝を 売る", [...tre.map(([id, n]) => `§f${ITEMS[id].name} ×${n}  §e${ITEMS[id].val * n}`), LINE, `§fぜんぶで ${gold(sum)}`].join("\n"), "ぜんぶ 売る", "やめる"))) return;
    let paid = 0; for (const [id, n] of tre) { const c = Math.min(n, countItem(p, `mrpg:${id}`)); if (c > 0 && takeItem(p, `mrpg:${id}`, c)) paid += ITEMS[id].val * c; }   // 本当に あった ぶんだけ
    const d2 = load(p); if (!d2) return; d2.gold += paid; save(p, d2); sound(p, "random.orb");
    await notice(p, "うる", `§a${gold(paid)} で 買いとった！`); return;
  }
  if (sel < 0) return;
  const [id, n] = have[sel];
  let k = 1;
  if (n > 1) { const v = await modal(p, `${ITEMS[id].name}を うる`, (f) => f.slider("いくつ うる？", 1, n, 1, 1)); if (!v) return; k = Math.max(1, Math.min(n, Math.floor(Number(v[0]) || 1))); }
  if (takeItem(p, `mrpg:${id}`, k)) { d.gold += price(id) * k; save(p, d); sound(p, "random.orb"); }
}
export async function innMenu(p, d) {
  const front = [...d.party, ...(d.bench || [])];   /* 第69版: 裏も */
  const cost = Math.max(10, Math.floor(front.reduce((s, m) => s + m.lv, 0) * 6));   /* 第103版: 宿代 Lv×4 → ×6 */
  const all = cost + Math.max(10, Math.floor(d.box.reduce((s, m) => s + m.lv, 0) * 3));   /* 第69版: みんなは かならず 表と 裏より 高い */
  const s = await choose(p, "宿屋", `§fお金: ${gold(d.gold)}\n§7一晩 泊まって 仲間の HPと MPを ぜんかいふく します。`,
    [B(`表と 裏だけ  §e${cost}`, ICON("i_inn")), B(`預かり所も みんな  §e${all}`, ICON("i_inn")), B("§7戻る", ICON("i_back"))]);
  if (s < 0 || s > 1) return;
  const c = s === 0 ? cost : all;
  if (d.gold < c) { await notice(p, "宿屋", "§cお金が たりません。"); return; }
  d.gold -= c;
  for (const m of s === 0 ? front : allMons(d)) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; }
  save(p, d); sound(p, "random.orb");
  await notice(p, "宿屋", "おはようございます。\n仲間は 元気に なりました！");
  try { if (EXH.inn) await EXH.inn(p); } catch {}   /* 第102版: 朝ごはん・夢・旅日記 */
}

export async function warpMenu(p, d, wing = false) {
  const towns = TOWNS.filter((t) => (d.towns || []).includes(t.id) && getTown(t.id)?.built);
  // v2.9.12: おとずれた 城も ワープ先に
  const cset = new Set(d.castles || []);
  WREGIONS.forEach((R, i) => { if (R.rm >= 0 && (d.story?.rm || []).includes(R.rm)) cset.add(i); });   // 前の 版で 行った 城（地方マスターに 勝った 城）も
  const castles = [...cset].sort((a, b) => a - b).filter((i) => castleInfo(i)?.built).map((i) => ({ i, c: castleInfo(i) }));
  const sp = p.getSpawnPoint?.();
  if (!castles.length && !towns.length && !(wing && sp)) { await notice(p, "ワープ", "§7まだ ワープできる 街が ありません。\n街を おとずれると ワープポイントに 登録されます。"); return false; }
  // v3.0: まず 街・城・ベッドを えらぶ（前は 城が 先に ならんで 街が 次の ページに かくれて いた）
  const kinds = [];
  if (towns.length) kinds.push(["town", B(`§l街へ\n§8おとずれた 街 ${towns.length}/${TOWNS.length}`, ICON("i_walk"))]);
  if (castles.length) kinds.push(["castle", B(`§6§l城へ\n§8おとずれた 城 ${castles.length}/${WREGIONS.length}`, ICON("i_fight"))]);
  if (wing && sp) kinds.push(["bed", B("ベッド（リスポーン地点）", ICON("i_inn"))]);
  const kk = await choose(p, wing ? "きかんのつばさ" : "ワープ", "§fどこへ ワープしますか？", [...kinds.map((k) => k[1]), B("§7やめる", ICON("i_back"))]);
  if (kk < 0 || kk >= kinds.length) return false;
  const kind = kinds[kk][0];
  let s0;
  if (kind === "bed") s0 = castles.length + towns.length;
  else if (kind === "castle") { const c = await paged(p, "城へ ワープ", "§fどの 城へ？", castles.map(({ i }) => B(`§6§l${WREGIONS[i].castle.name}\n§8${WREGIONS[i].name}の 城`, ICON("i_fight"))), 9); if (c < 0) return false; s0 = c; }
  else { const c = await paged(p, "街へ ワープ", "§fどの 街へ？", towns.map((t) => B(`§l${t.name}\n§8${"★".repeat((t.tier || 0) + 1)} ${EL_JP[t.el] || ""}`, ICON("i_walk"))), 9); if (c < 0) return false; s0 = castles.length + c; }
  const pet = findPet(p);
  if (s0 < castles.length) {
    const c = castles[s0].c;
    try { p.teleport({ x: c.x, y: c.y + 0.2, z: c.z + 23 }, { dimension: world.getDimension("overworld"), facingLocation: { x: c.x, y: c.y + 2, z: c.z } }); } catch { return false; }   // 城の 南の 外壁の 前
    if (pet) try { pet.teleport(p.location, { dimension: p.dimension }); } catch {}
    particle(p, "minecraft:totem_particle", 1); sound(p, "mob.endermen.portal");
    return true;
  }
  const s = s0 - castles.length;
  try {
    if (s < towns.length) { const i = getTown(towns[s].id); p.teleport({ x: i.x, y: i.y + 0.2, z: i.z + 5 }, { dimension: world.getDimension("overworld") }); }
    else p.teleport({ x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 }, { dimension: sp.dimension });
  } catch { return false; }
  if (pet) try { pet.teleport(p.location, { dimension: p.dimension }); } catch {}
  particle(p, "minecraft:totem_particle", 1); sound(p, "mob.endermen.portal");
  return true;
}

export async function npcMenu(p, job, ent) {
  if (busy.has(p.id)) return;
  try { if (ent && EXH.npc && ent.hasTag("mrpg_xnpc")) { let after = null; busy.add(p.id); try { after = await EXH.npc(p, ent); } finally { busy.delete(p.id); } if (typeof after === "function") await after(); return; } } catch (e) { console.warn(`[MonsterRPG] xnpc: ${e}`); }   /* 第102版: 行商人・旅人・盗賊 */
  try { if (ent && ent.getDynamicProperty("mrpg:saga")) return; } catch {}
  // v2.9.14: 魔神編の ムサシ
  try { if (ent && ent.hasTag("mrpg_musashi")) { busy.add(p.id); try { const r = await musashiTalk(p, ent); if (r === "spar") await musashiSpar(p, fight); } finally { busy.delete(p.id); } return; } } catch (e) { console.warn(`[MonsterRPG] musashi: ${e}`); }
  // v2.2.4: 地方マスター
  let rk; try { rk = ent ? ent.getDynamicProperty("mrpg:rm") : undefined; } catch {}
  let kg; try { kg = ent ? ent.getDynamicProperty("mrpg:king") : undefined; } catch {}
  if (typeof kg === "number") { let after = null; busy.add(p.id); try { after = await kingTalk(p, kg); } finally { busy.delete(p.id); } if (typeof after === "function") { try { await after(); } catch (e) { console.warn(`[MonsterRPG] king: ${e} ${e?.stack || ""}`); } } return; }
  if (typeof rk === "number") {
    let after = null; busy.add(p.id);
    try { after = await rmTalk(p, rk); } finally { busy.delete(p.id); }
    if (after) { try { await after(); } catch (e) { console.warn(`[MonsterRPG] rm: ${e} ${e?.stack || ""}`); } }
    return;
  }
  if (job >= 8 && job <= 10) {
    const d = load(p);
    if (!d) { p.sendMessage("§eガイドブックを 使って 最初の 仲間を えらぼう！"); return; }
    if (!canFight(d)) { p.sendMessage("§c戦える 仲間が いない！"); return; }
    let fight = false;
    busy.add(p.id);
    try { fight = await masterTalk(p, d, ent); } finally { busy.delete(p.id); }
    if (fight) await challengeMaster(p, ent);
    return;
  }
  busy.add(p.id);
  let after = null;
  try {
    let d = load(p);
    if (!d) { await notice(p, JOBS[job], "§fいらっしゃい！\n§7まずは ガイドブックで 最初の 仲間を 選んでね。"); return; }
    if (job === 11) await monsterShop(p, d);
    else if (job === 14) await fishShop(p, d);
    else if (job === 12) await libraryMenu(p, d);
    else if (job === 13) await sageTalk(p, d);
    else if (job <= 1) await shopMenu(p, d, job + 1);
    else if (job === 2) await innMenu(p, d);
    else if (job === 3) {
      const s = await choose(p, "道具屋", `§fお金: ${gold(d.gold)}`, [B("§l道具", ICON("i_shop")), B("§d石板工房", ICON("i_zukan")), B("§7戻る", ICON("i_back"))]);   // v3.0: 道具と 石板工房だけ
      if (s === 0) await shopMenu(p, d, 0); else if (s === 1) await slabShop(p, d);
    }
    else if (job === 4) await shopMenu(p, d, 4);
    else if (job === 5) {
      storyOf(d);
      const s = await choose(p, "闘技場", `§f強い モンスターマスターが 集まる 場所だ！\n${chapterText(d)}  §bマスターポイント ${d.mpt}`, [B("§l§6マスターリーグに 挑戦", ICON("i_fight")), B("マスターランキング", ICON("i_zukan")), B("対戦 ランキング", ICON("i_zukan")), B("対戦を もうしこむ", ICON("i_scout")), B("§d模擬戦 §8（自分の モンスター どうし）", ICON("i_party")), B("§6§lモンスター闘技場 §r§8（どっちが 勝つか かける）", ICON("i_item")), B("§7戻る", ICON("i_back"))]);
      if (s === 0) after = await arenaMenu(p, d);
      else if (s === 4) { if (await sparSetup(p, d)) { after = AFTER.get(p.id); AFTER.delete(p.id); } }
      else if (s === 5) after = await betMenu(p);
      else if (s === 1) await notice(p, "マスターランキング", mrankText());
      else if (s === 2) await notice(p, "闘技場 ランキング", rankText());
      else if (s === 3) await multiMenu(p, d, 0);
    } else if (job === 6) {
      const s = await choose(p, "預かり屋", "§fモンスターを おあずかりします。", [B("§l預かり所", ICON("i_box")), B("みんなの 共有 預かり所", ICON("i_scout")), B("§7戻る", ICON("i_back"))]);
      if (s === 0) await listMenu(p, d, d.box, "預かり所");
      else if (s === 1) await sharedMenu(p, d);
    } else if (job === 16) {
      await notice(p, "城の 衛兵", ["§f「ここは 王の 城だ。くれぐれも 失礼の ないように。」", "§f「王に 用なら 奥の 王の 間へ どうぞ。」", "§f「近ごろ ノクス団とかいう 連中が うろついて いる。気を つけるんだな。」"][Math.floor(Math.random() * 3)]);
    } else {
      const tw = townAt(p.location, 60);
      const info = tw ? [`§fようこそ！ ここは §e${tw.name}§f です。`, `§7特産: §f${EL_JP[tw.el] || ""}属性の 装備  §7値段 ×${(tw.pm || 1).toFixed(2)}`,
        `§7タマゴ屋: §f${(tw.eggs || []).map((e) => ITEMS[e]?.name).filter(Boolean).join("・")}`, `§7モンスター屋: §f${(tw.fams || []).map((f) => FAMILIES.find((x) => x.id === f)?.name || "").join("・")} が おおい`,
        `§7品ぞろえ ランク: §e${"★".repeat((tw.tier || 0) + 1)}`, `§7おとずれた 街: §f${(d.towns || []).length}/${TOWNS.length}`].join("\n") : "§fようこそ！";
      const s = await choose(p, "案内人", info, [B("§lワープ", ICON("i_run")), B("ストーリー", ICON("i_fight")), B("遊び方", ICON("i_help")), B("§7戻る", ICON("i_back"))]);
      if (s === 0) await warpMenu(p, d);
      else if (s === 1) await storyMenu(p, d);
      else if (s === 2) await notice(p, "遊び方", HELP);
    }
  } finally { busy.delete(p.id); }
  if (after) { try { await after(); } catch (e) { console.warn(`[MonsterRPG] arena: ${e} ${e?.stack || ""}`); } }
}

// ---------- 釣り屋 ----------
export async function fishShop(p, d) {
  const t = shopTown(p);
  for (;;) {
    const rods = Object.keys(ITEMS).filter((id) => ITEMS[id].kind === "rod");
    const s = await choose(p, "釣り屋", [`§fいらっしゃい！ 釣竿なら まかせて。  §fお金: ${gold(d.gold)}`, "§7海・川・池の 水に 向かって 釣竿を 使う（右クリック）と 釣りが できる。", "§7竿が 良いほど めずらしい お宝や 強い モンスターが 釣れる。", "§7釣った §6お宝§7は ここで 満額で 買いとるよ。"].join("\n"),
      [...rods.map((id) => B(`§l${ITEMS[id].name}  §e${priceAt(t, id)}\n§7${itemDesc(id).split("。").slice(-2).join("").slice(0, 30)}`, ITEM_ICON(id))), B("§6お宝を 売る", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
    if (s < 0 || s > rods.length) return;
    if (s === rods.length) {
      const have = Object.entries(rpgItems(p)).filter(([id]) => ITEMS[id].kind === "treasure");
      if (!have.length) { await notice(p, "釣り屋", "§7お宝を 持っていないね。"); continue; }
      const sum = have.reduce((a, [id, n]) => a + ITEMS[id].val * n, 0);
      if (!(await confirm(p, "お宝を 売る", [...have.map(([id, n]) => `§f${ITEMS[id].name} ×${n}  §e${ITEMS[id].val * n}`), LINE, `§fぜんぶで ${gold(sum)}`].join("\n"), "ぜんぶ 売る", "やめる"))) continue;
      let paid = 0; for (const [id, n] of have) { const c = Math.min(n, countItem(p, `mrpg:${id}`)); if (c > 0 && takeItem(p, `mrpg:${id}`, c)) paid += ITEMS[id].val * c; }   // v2.9.12: 本当に あった ぶんだけ
      d.gold += paid; save(p, d); sound(p, "random.orb");
      await notice(p, "釣り屋", `§a${gold(paid)} で 買いとった！`);
      continue;
    }
    const id = rods[s], pr = priceAt(t, id);
    { const need = [0, 2, 4, 6][ITEMS[id].tier || 0] ?? 0; if (rankCap(d) < need && !endingDone(d)) { await notice(p, "釣り屋", `§7その 竿は まだ 早いね。§f物語を 進めると 売って あげるよ。`); continue; } }   /* v2.9.14: 竿は 物語の 進みで 売る */
    if (!(await confirm(p, ITEMS[id].name, `§l§e${ITEMS[id].name}§r\n§f${itemDesc(id)}\n\n§f値段 ${gold(pr)}`, "買う", "やめる"))) continue;
    if (d.gold < pr) { await notice(p, "釣り屋", "§cお金が 足りないよ。"); continue; }
    d.gold -= pr; save(p, d); giveItem(p, `mrpg:${id}`, 1); sound(p, "random.orb");
  }
}

// ---------- 用語説明 ----------
export const GLOSSARY = [
  ["クリア後：滅びた世界（追加ストーリー）", ["§f追加ストーリーの パックを 入れた ワールドで、エンマを 倒して ムサシが 仲間の とき に 始まる（ガイドブック → ストーリー → ムサシと 話す → ルミナの 妙な 男）", "§f舞台は 灰の 街 ルインヘイム（遠く 100000,100000 付近）。§6キャンプ 11か所§f の たき火で 休む（全回復・もどり先）・ワープ・店・神官の 記録・配下の 居場所", "§f§c配下 15体§f: Lv100・HP 20000〜41000・2〜3回行動・急所隠し・不倒の誓い。倒すと 100000タヨ・神果（全能力）・まれに 万能の神果", "§f15体 倒すと 街の 真ん中の 電波塔に §5邪神§f（HP 60000・HP半分で 一度だけ 全回復）。倒すと 1000000タヨ・万能の神果×3・神果×5・称号「灰都の 救い手」・灰の 霧が 晴れる・セイルの 店", "§f邪神とは 1日 1回 再戦できる（HP 70000・少し 強い・200000タヨ など）", "§f野生は Lv80〜100。外（道・広場・屋上）に 巨大な 魔物（広い 所に 出ると 多めに 湧く）、建物の 中に 小さな 魔物、用水路や 池には 水の 魔物が 出る。建物の 中には 宝箱も ある（区画ごとに 12こまで）", "§f追い方は 系統ごとに ちがう: 獣は 猛ダッシュ・動物は ジグザグ・ドラゴンは ビルを 飛びこえる・ゴーレムは なぎ倒し・スライムは 跳ねる・剣士は 瞬間移動の 踏みこみ・水の 魔物は 水の 中で 速い・ネザーは 通った 跡が 焦げる・王は 地響き。§c飛べる 魔物は ライドで 空へ 逃げても 追って くる", "§f巨大な 魔物は 28m（しゃがむと 14m）に 近づくと 壁ごしでも 気づき（同時に 2体まで）、建物を 突き破って 追って くる。40m 離れると あきらめる。斬る・かむ・しっぽ・突進などの 物理が 中心。ブレスや 魔法の 型の 魔物は 離れると よく 撃って くる。街は どんどん 壊れる（ブロックは 落ちない）。§c受ける ダメージは 1秒で ハート3まで§f（防具では 減らない・耐性の 効果は 効く）。キャンプの そばは 安全", "§f配下・邪神は すみかに 近づく（56m）と 現れて しばらく 暴走する（その間は 戦えない）。§a疲れて 動きが 止まったら 攻撃すると 戦える§f（35秒 たつと また 暴れだす）", "§7配布マップには 街が 入って いる。ほかの ワールドでは 近づいた 区画から 少しずつ 建つ（PCは 更新ツールで 一度に 入れられる）"]],
  ["チートブック", ["§fホストだけ 使える（ホストが 設定で 許可すると みんな）", "§f味方 無敵・一撃 9999999: 大会・ランク・ゴースト・対戦では 効かない。一撃でも 神・邪神の 再臨（一度 全回復）は のこる。吸収・効かない 属性・よけられた 攻撃は 一撃に ならない", "§fスキルを 好きに 選ぶ: SPは 使わない・固有スキルの 枠は かえられない・はずした スキルの ptは もどらない・「ぜんぶ 最大pt」あり", "§fLv100・+99 は 表と 裏の 仲間が 対象", "§fクリア後の 世界を ためす: 追加ストーリーは ふくまれない。もとに 戻すと、ためして いる 間の 物語の 進みも 戻る", "§f滅びた世界へ すぐ 行く: 追加ストーリーの パックが ある ときだけ 出る。エンマを 倒して いなくても 追加ストーリーを 遊べる（本編の 進みは かわらない）"]],
  ["便利な 機能", ["§f選ぶ 画面は ボタンが 多い とき マス目（3列）に なり、下に ページ移動・さがす が 出る", "§f表と 裏の 入れかえ: 仲間 → 表・裏の 一覧で 1体を えらび「表へ 出す／裏へ」。入らない ときは その場で 入れかえる 子を えらぶか「自動で 空けて 入れる」。一覧の「表と 裏を まるごと 入れかえ」も ある", "§f預かり所の 一覧の「並べかえ」で レベル・ランク・系統・名前・＋値・新しい 順に できる", "§fお店の「売る」→ 道具・素材で、お宝を ぜんぶ まとめて 売れる", "§fバッグ・道具・預かり所の 一覧は 前に 見て いた ページを おぼえる（抜けると 消える）", "§fこまったら ガイドブック → 冒険 →「バグを 直す」。なくした 石板・だいじなもの・パーティの 枠こえ・表が 全滅の ままも 直す"]],
  ["裏（スタンバイ）", ["§f仲間 →「裏（スタンバイ）」に §b表と 同じ 4枠§f まで 入れられる（S=1 M=2 L=3 G=4）", "§f戦いの 中で「表と 裏を 入れかえ」で 表の 子と 入れかえられる。§c入れかえた 子は その ターン 動けない§f（ほかの 子は ふつうに 動く）", "§f表が 全員 倒れると、裏の 子が 自動で 出てくる（倒れた 子は その 戦いでは もう 出せない）", "§7場に 出なかった 裏の 子にも 経験値が 半分 入る。対戦・模擬戦・縛りの やりこみ戦・物語の 台本の 戦いでは 使えない"]],
  ["注意：裏（スタンバイ）", ["§f仲間 →「裏（スタンバイ）」に 控えを 入れて おくと、表が 全員 倒れても 戦いが 続く", "§c戦いの 中で 入れかえた 子は その ターン 動けない"]],
  ["クリア後：地方の 王", ["§f物語を 見届けると、11の 地方の §6城の 王§f が 直々に 戦って くれる（城の 中の 王に 話しかける）", "§f王の チームは §c全員 SSランク・王系が 1体 以上・4枠§f。全員 §cHP 1万5千 以上・能力 1200 以上§f。手持ちに 合わせて 強く、勝つほど さらに 強くなる。技は 固有技・打ち消し・回復・弱体などを 臨機応変に 使う", "§f何度でも 挑める。§e1回目の 勝利§f: §d神の石板§f（その 地方の 神）・万能の秘果・闘魔覚醒の秘玉", "§e2回目から§f: 万能の秘果か 神果・闘魔覚醒の秘玉 ＋ 豪華な ごほうび（王・にじいろ・神の タマゴ、能力の 神果、経験の天玉、才覚の金珠 など）"]],
  ["クリア後：神の石板と 神々", ["§f物語の 石板の 主 15体が 神の 名を 得た 姿（§dXランク・Gサイズ・色違い§f）。例: 厄王ヴァルグレイド → §4厄神ゲゼラ", "§f神の石板は 道具 →【特別な石板】から 使う。中は 迷宮（§e5階、厄神ゲゼラは 10階§f）。中の モンスターは §eすべて SSランク§f（王系・神系は 出ない）", "§f神は 手持ちに 合わせた 強さ（能力 1200 以上・HP 2万、ゲゼラは 3万）。2〜3回行動。§cHPが 半分 以下に なると 1度だけ 全回復し、全能力が 底上げ（3段階より 下がらない）§f（ゲゼラは 2度）", "§f§c何も 落とさない§f かわりに、倒すと §d低い 確率（8%、ゲゼラ 5%）§fで 正気に もどり 仲間に なる。§7戦った ときの 能力・特性の まま（HPは 9999まで）。仲間に したら もう 戦えない（負けても 石板は のこる）", "§f手に 入れ方: 地方の 王 11人に 初めて 勝つ（1〜11枚目）・伝説の マスター カゲツに 10・20・30勝（12〜14枚目）・40勝で 厄神ゲゼラ", "§7仲間に した 神は 交換・お見合い・共有 預かり所には 出せない（第69版）"]],
  ["クリア後：カゲツの ごほうび", ["§f伝説の マスター カゲツに §e10・20・30勝§f で 神の石板、§e40勝§f で 厄神ゲゼラの 石板。§f50勝からは 10勝ごとに SSランクの モンスター", "§71勝ごとの 豪華な ごほうびは これまで どおり", "§7魔神編で カゲツが 倒れた あとも、夢の 中で 同じように 挑める"]],
  ["クリア後：タマゴの 特別な 秘伝", ["§f物語を 見届けた あとに かえした タマゴの 子は、§d特別な 秘伝§f を 必ず 1つ 持って 生まれる", "§f極魔の秘伝（全属性の 強い 魔法）・極息・極拳・極武・極癒・極護 の どれか。100まで 振ると 専用の 特性"]],
  ["クリア後：+99を こえた 子の 継承", ["§f物語を 見届けた あと、配合で §d+99 を こえた 子§f は、親の 特性を §e1つ 受けつげる§f（継承の秘石 いらず）", "§7配合の あとに 出る 画面で 受けつぐ 特性と 入れかえる 特性を えらぶ"]],
  ["レイドボスと 王系", ["§f王系の モンスターは §6フィールドの レイドボス§f として だけ たまに 出る（終盤の 地方ほど 出やすい）", "§fレイドボスも 終盤の 地方ほど よく 現れる"]],
  ["闘技場の 結果スキップ", ["§fモンスター闘技場で かけた あと「§e結果だけ 見る§f」を えらぶと、戦いを 見ずに すぐ 結果が 出る（かけ金と 当たりは 観戦と 同じ）"]],
  ["バグを 直す", ["§fガイドブック → 冒険 →「§cバグを 直す§f」で、よく ある こまりごとを その場で 直せる（データは 消えない）",
    "§f直す もの: 本が 開かない・物語が 止まった・カメラや 操作が もどらない・無敵や 暗視が つきっぱなし・連れ歩きが 消えた・戦いの あとの モンスターが のこった・見えない まま・数値が おかしい・ブロックに うまった",
    "§f第94版から: 浮いた まま・ダメージを 受けない 効果の のこり・滅びた 世界の 落ちる 砂や 浮いた／うまった モンスター・石板の 中で 壁の 外に 見える 階段の 光・戻って いない お金（会う／かけ）も 直す",
    "§e本が 開かない ときは しゃがみながら 本を 使う§f と 開く。まだ だめなら「家へ もどる」で はじまりの 町へ"]],
  ["滅びた世界の 強さ", ["§f追加ストーリー「滅びた世界」で、§e魔物の 数・追いかけ・ブレスと 魔法§f を それぞれ 少なめ／ふつう／多め に できる（設定・キャンプ）", "§7魔物の 数: 少なめ 約4割（群れなし）・多め 約1.4倍。追いかけ: 気づかれる 距離 約0.65倍／1.3倍・同時に 追って くる 数 1／2／3体。ブレス・魔法: 少なめは ほぼ 物理", "§7自分の まわりと 自分への 攻撃 だけに かかる"]],
  ["赤い 月", ["§f滅びた 世界で 4日に 1回くらい 来る 夜。§c魔物が 約1.3倍に 増え、Lv90〜100・気づかれやすく・配下の 暴走が 長く§f なる", "§6そのかわり 宝箱に 能力の 実が 1つ 増え、灰晶も 出る"]],
  ["魔物の 巣", ["§f滅びた 世界の 10か所に できる 黒い 塚。近くでは 魔物が 多く、§4巣の 番人§f も 現れる", "§f真ん中の 核（スカルクの 触媒）を 掘って 壊すと、その 日は まわり（72m）の 湧きが 約4割に なる。§d灰晶 ×3§f・30,000 タヨ・ときどき 能力の 実", "§7日が 変わると また できる。近くの 巣には 赤い 光の 柱が 立つ"]],
  ["灰晶", ["§f滅びた 世界の 結晶。巣 ×3・配下 ×5・邪神 ×10（再戦 ×5）・赤い 月の 宝箱・調査隊の 日誌（全部で ×10）で 手に入る", "§fキャンプの §d灰の 工房§f で 装飾品（灰晶の首飾り・邪神殺しの指輪・結界の護符）や 能力の 実に、§b結界§f を 強める のにも 使う"]],
  ["結界", ["§fキャンプの 魔物が 近よらない 範囲。灰晶と お金で 2段階 強められる（1段階 8m）。ワールドの みんなで 共有", "§7段階1: 灰晶 ×5・50,000 タヨ／段階2: 灰晶 ×15・150,000 タヨ"]],
  ["配下の 弱点", ["§f配下（と 邪神）が 暴走の 後半で §4激昂§f すると、体が ときどき 光る。光って いる 3秒の 間に なぐると よろめき、暴走が 短く なる", "§f突いた 回数 ぶん、その 後の 戦いで 配下の HPが 1回 10%（2回まで）減る"]],
  ["群れと 待ちぶせ", ["§f滅びた 世界の 広い 所では 小さい 魔物が 2体の §c群れ§f で 囲んで くる（1体に 見つかると 群れ ぜんぶが 来る）", "§f建物の 中の 魔物は 物かげで §c待ちぶせ§f して いる ことが ある。しゃがむと 近づいても 気づかれにくい"]],
  ["調査隊の 日誌", ["§f滅びた 世界の 宝箱から 1枚ずつ 見つかる（全12枚）。キャンプの「神官の 記録」で 読める。全部 そろうと 灰晶 ×10・100,000 タヨ"]],
  ["画面の 右上", ["§f右上には 今の §6所持金§f と 物語の 目標（場所・方角・きょり）が 出る。目標は 設定で けせる"]],
  ["ハコダマシ", ["§f宝箱（木の宝箱 より 上）を 開けると、まれに 宝箱に 化けた モンスター §cハコダマシ§f が おそって くる",
    "§f勝つと 宝箱の 中身が 1段 よくなる。負けても 逃げても お金は へらず、宝箱は のこる（もう 一度 開ければ 中身を 取れる）",
    "§71つの 宝箱で 化けるか どうかは 最初に 開けた ときだけ 決まる。スカウトは できない"]],
  ["倒れた 仲間の 経験値", ["§f戦いに 勝つと、倒れた 仲間にも 経験値の 半分が 入る（倒れた ままで、回復は しない）"]],
  ["ワールドの 読みこみ", ["§fモンスターが 900種類 いるので、ワールドを 開くときに 少し 時間が かかる。同じ 形の モデルは まとめて あり、遠くの 土地を 先に 読みこむ 予約も 使わない",
    "§7実験的機能（ベータAPIなど）は 使って いないので、全部 オフの ままで 動く"]],
  ["物語の 章と あらすじ", ["§f物語は 第1章〜第11章と 終章。章が 始まると 画面に 章の 名前が 出る",
    "§fガイドブック → ストーリー →「これまでの あらすじ」で、たどりついた 章の お話を 読み返せる",
    "§f物語の 戦いで 負けても、その場で「もう一度 挑む」を えらべる（仲間は 全回復）。「あとで」なら ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶまで 物語は 止まる。勝てなくても 進む 決まった 戦いも ある",
    "§f物語は 順番どおりに 進む。物語の できごとを とばして 先の 地方へ 行く・先の 地方マスターに 挑む ことは できない（「まだ やるべき ことが ある」と 今の 目標が 出る）",
    "§bライバル レイ§f: オルドの 孫。ルミナ・荒野・天空郷で 物語の 勝負が ある。ほかの 地方でも ときどき 勝負を 挑んでくる（負けても また 会える）"]],
  ["魔神編（クリア後）", ["§f伝説の マスター §bカゲツ§f に はじめて 勝つと §4魔神の鍔§f を もらえる。ここから §d魔神編§f",
    "§fはがねの 村 §eクロガネ§f で 何かを 探している 武士に 鍔を 見せると、話が 進む。腕だめしに 勝つと §cムサシ§f が 仲間に", "§fムサシが 仲間に なったら、物語の 目標に そって §e魔4〜魔6§f（はぐれ鍛冶・千年前の 斬り跡・悪夢）を すませる。すませるまで 神殿の 鍔は 動かない",
    "§fムサシと §5閻魔の神殿§f で 鍔を 捧げると、魔神 §4エンマ§f が ムサシに 取り憑く。倒すと ムサシが もどる。そのあと 戦いの 中で ムサシに 魔神の鍔を 使うと エンマの 姿に 変わる（ムサシを 親に して 配合すると ムサシだけが 生まれる）",
    "§fムサシが 仲間に なったら、ガイドブック → ストーリー →「ムサシと 話す」で 家・鍔・エンマ・カゲツ などの 話が 聞ける",
    "§f魔神編の あと、戦いで ムサシの HPが 半分 以下の とき「魔神の鍔を 使う」を えらぶと §4魔神エンマ§f が 顕現する（全回復・全能力 2段階 上昇・3〜4回行動・魔神の闘気・最優先行動・上限なし・会心無効）",
    "§4閻魔の神殿§f では いつでも エンマと 再戦 できる（勝っても 負けても 鍔は 手元に もどる）。エンマは HP 20000・ほかの 能力 5000・MP 無限から はじまり、勝つたびに HP +1000・ほかの 能力 +500。技も ふえ、戦うたびに 戦い方が かわる。最大HPが 9000 以上の 相手には ダメージの 上限なしで 攻めてくる",
    "§fカゲツには 何度でも 挑める。§e10・20・30勝で 神の石板・40勝で 厄神ゲゼラの 石板§f、50勝からは 10勝ごとに SSランクの モンスター。地方マスター・石板の 主も クリア後に 再戦 できる"]],
  ["石板の 守り手（地方マスター）", ["§f8人の §6地方マスター§fは、それぞれの 地方の §d石板§fを 守る 守り手。石板を 託すに 相応しいか、戦って 見極める",
    "§f守り手には §e得意な 系統§fが ある（若葉＝動物系・鋼刃＝武者系・炎舞＝ネザー系・岩鉄＝無機物系・潮風＝海系・宵闇＝ネザー系・雷光＝動物系・天穹＝竜系）。戦う 前の 画面で 分かる",
    "§f認められると 石板を 託される → ガイドブック → 道具・装備 → 道具・タマゴを 使う →【特別な石板】から 使い、中の §6主§fを 封印すると 次の 地方へ 行ける",
    "§fガイドブック → ストーリー →「石板の 守り手の 記録」で、認められた 守り手と 封印の ようすが 見られる",
    "§f十四の 石板を すべて 封じ、星冠王から 託される §c王冠の 石板§fで §c石板の王§fを 封印すると 物語の 結末"]],
  ["遺跡と 星の かけら", ["§f各地の §6遺跡§fの ボスは §e星の かけら§fを 守っている。ノクス団も かけらを 狙っている",
    "§f遺跡の ボスを 倒すと かけらが 1つ。§e2つ目と 5つ目§fでは §d石板§fも 手に入る。§e8つ§f そろうと ネクロスに §6終の遺跡§fが 開く"]],
  ["物語の 場所と 洞くつ", ["§f画面の §e右上§fに 次の 目標と 方角・きょりが ずっと 出る（コンパスの 案内は 画面の 下。右上は 物語だけ）。設定 →「右上の 目的地 案内」で オフ", "§f行ける 地方と その 次の 地方の §e城・ステージ・町§fは、遠くに いる うちに 地表に 作られる（少し 時間が かかる）",
    "§fシルヴァ・クリスタリアには §e物語の 洞くつ§f（入口の 門 → 階段 → 地下の 広間）。右上の 案内で 入口へ 行き、§e階段を いちばん 下まで§f おりる。中に 入ると 案内が 奥の 広間を 指す",
    "§6懐中電灯§fは 使わなくても 持っているだけで 洞くつの 中が 明るく 見える",
    "§fもらった §6だいじなもの§f は ガイドブック →「道具・装備」→「道具・タマゴを 使う」→【だいじなもの】、または「バッグ」→ だいじなもの から 使える。§e特別な石板§f も 同じ 画面の【特別な石板】から",
    "§f物語の 戦いは 始まる 前に「戦う／あとで」を 聞く。あとで なら、ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶと もう一度 起きる（だいじなものの 戦いは、その だいじなものを もう一度 使う）。それまで 物語は 進まない"]],
  ["作戦と 技の 好み", ["§f仲間 →「作戦」か、戦闘の「作戦」で モンスターごとに 決める",
    "§e方針§f（6つ）: §a先手必勝§f（攻撃中心・毒や 守り下げの 攻撃・弱点を つく）・§a状況分析§f（攻撃・状態異常・補助を 的確に）・§a搦手上手§f（状態異常と 弱体）・§a反撃時間§f（反射技）・§a後援者§f（強化と 激減の 構え）・§aMP使うな§f（MP0の 技と ふつうの 攻撃）",
    "§e技の 好み§f: 技ごとに §a◎よく使う §f／ ○使う ／ §c×使わない§f。ふつうの 攻撃も ×に できる",
    "§f◎は 役に 立つ 場面で 優先。×は オートでは ぜったいに 使わない（自分で えらぶ ときは 使える）",
    "§2ずっと オート§f: 戦闘の 最初の 画面で えらぶと、毎ターン 自動で 戦う。§eしゃがむ（スニーク）§fと つぎの ターンで とまる"]],
  ["宝の地図", ["§e入手§f: 強い 敵（ボス・マスター・Aランク以上）に 勝つと まれに（4%）／無限の塔 20階ごと（はじめて 突破）／縛りの石板 クリア（35%）／今日の挑戦状 3日連続ごと／研究所で 作る（お金と 研究pt）",
    "§e使い道§f: 道具から 使うと 300〜700m 先に しるし。画面の 下に 方角と きょりが 出る。着くと 宝の 番人 → 倒すと レアな 宝箱",
    "§7まだ 行けない 地方に しるしが ついたら、地図を もう一度 開いて「しるしを 消す」"]],
  ["次の 目標の 表示", ["§f物語の 次の 目標が 画面の 右上に 出る（目的地の 名前・方角・きょり。戦いの あいだは かくれる）。目標が かわると チャットにも 出る",
    "§f向きは「まっすぐ・右・左ななめ後ろ」など ことばで 出る。設定で 表示を オフに できる",
    "§7コンパスで 行き先を えらぶと、そちらの 案内が 優先"]],
  ["回復・経験値・スキル", ["§a全回復§f: ガイドブックの「全回復」で、回復技を 覚えた 仲間が MPを 使って パーティの HPを 回復（MPの むだが 少ない 技から 自動で）",
    "§f仲間 →「回復技で 回復する」で 技と 相手を 自分で えらべる。§7たおれた 仲間は 宿屋か 命の羽で",
    "§b預かり所の 経験値§f: 戦闘で もらった 経験値の 半分が 預かり所の 仲間にも 入る（設定で オフに できる）",
    "§b相手との レベル差§f: 倒した 相手より 3以上 レベルが 高い 子は もらえる 経験値が へる（とても 高いと 1割）。低い 子は 少し ふえる",
    "§b経験値の 上限§f: §e次に 封印する 石板の 主の Lv−4§f を こえた 子は 経験値が 1割に なる（すべて 封印した あとは なし）",
    "§dスキルの書§f: 使う 前に どんな 技・特性が もらえるか 見られる", "§fSPは 仲間 →「スキルポイントを 振る」で §eみんなの ぶんを まとめて§f 振れる（まんべんなく・上から 順に・ごほうびが 近い 順）。§b「レベルアップで 自動で 振る」§fを オンに すれば もう 振らなくて いい",
    "§f回復の 道具は のこりの HP・MPを 見ながら 使える。全体回復の 道具も 戦闘の 外で 使える",
    "§7データは ワールドの 中に 自動で 保存される。もしもの ときは 設定 →「データを 前の 状態に もどす」"]],
  ["能力（ステータス）", ["§aHP§f: 体力。0に なると 倒れる", "§bMP§f: 技を 使う ための 力", "§c物力§f: 物理系（打撃）の 攻撃力", "§6硬力§f: 物理系・武系の 攻撃を 受ける 強さ（防御力）",
    "§d魔力§f: 魔法系の 攻撃力。回復の 量も 上がる", "§5魔硬力§f: 魔法系の 攻撃を 受ける 強さ（息系は 硬力と 魔硬力の 平均が 少し 効く）", "§e走力§f: 素早さ。高いほど 先に 動ける", "§4武力§f: 武系（武器）の 攻撃力。物力とは 別に 計算",
    "§3吹力§f: 息系の 攻撃力"]],
  ["能力の 上限", ["§f物力・硬力・魔力・魔硬力・走力・武力・吹力・MPは §e9999§f まで。§aHPだけは 上限なし§f（レベル・プラス値・能力の 実・装備・スキル・特性で どこまでも 伸びる）", "§71回の ダメージは 9999 まで。HPで 威力が きまる 技・毎ターンの 回復などの 割合の 回復・最後の報いは HP 9999 ぶんで 計算", "§7対戦の HP 2倍は 9999 まで（HPが 1万を こえる 子は そのまま）"]],
  ["能力の 段階（上昇・下降）", ["§f能力（物力・硬力・魔力・魔硬力・走力・武力・吹力）は §e−6〜+6段階§f まで 上げ下げ できる",
    "§a+1 1.5倍・+2 2倍・+3 2.5倍・+4 3倍・+5 3.5倍・+6 4倍", "§c−1 0.67倍・−2 0.5倍・−3 0.4倍・−4 0.33倍・−5 0.29倍・−6 0.25倍", "§7霧散の波動などで 上がった 段階は 0に もどる（下がった 段階は のこる）", "§e3つ以上の 能力を 一度に 上げる 技§fは その 技では §e+2段まで§f（1つずつ 上げる 技なら +6まで）", "§7もう 上がらない ときに 使うと 不発（下がる 能力も 下がらない）",
    "§f技は 自分だけ・味方1体・味方全体を 上げる もの、敵1体・ランダム2体・敵全体を 下げる もの、攻撃の ついでに 下げる（鎧崩しの拳 など）・上げる もの",
    "§fバトル中は 名前の 下に「物↑2 速↓1」の ように 出る。バトルが 終わると もとに もどる。特性「不屈」は 下げられない"]],
  ["対戦の かけひき", ["§d再誕の誓い§f: かけて おくと 倒れても すぐ よみがえる（1回）", "§4死線の執念§f（特性）: 倒れる ダメージを 受けても ラウンドの 終わりまで 動ける。再誕の誓いと 組みあわせると、暴れて 倒れて すぐ よみがえる",
    "§b霧散の波動§f: 敵の 強化（上がった 段階・纏い・反射・軽減・再誕・溜め・真価）だけを かき消す。特性「霧散の気」は ときどき 自動で 発動。「不動の加護」は 消されない",
    "§6真価解放§f: 自分の 良い 特性の 数値を 1.5倍に（2回まで）", "§6溜め§f: 重ねるほど 次の 攻撃が 2→2.6→3.3→4倍", "§6千刃の舞§f: ランダムな 敵に 4〜8回 武系の 攻撃・武力+1",
    "§d全魔解放§f: のこりの MPを すべて 使い 敵全体に 大ダメージ", "§5妖光の帳§f: 敵の 属性の 耐性を 1段 弱める", "§aときどき〜§f の 特性: ラウンドの 終わりに 確率で 発動",
    "§a特質系§f: 技ごとの 能力（走力・硬力 など）で 威力が きまる 攻撃の 種類",
    "§5○○ブレイク§f（特性）: その 属性の 攻撃は 相手の 耐性を 1段（超ブレイクは 2段）破る。無効・吸収も 破れる", "§e仁王の構え§f: その ラウンド、味方への 単体攻撃を 引き受ける（先制）",
    "§6賭けの返し§f（特性）: どんな 攻撃でも ときどき 1.5倍で 返す", "§d魔力の 暴走§f: 魔法系の 会心。守りは 効くが 1.75倍。息系は 会心に ならない"]],
  ["組み合わせの 例", ["§l§e不死身の 前衛§r§f: 死線の執念 ＋ 再誕の誓い（仲間に かけて もらう）。倒れても その ラウンドは 暴れて、終わりに 倒れて すぐ 復活",
    "§l§e盾と 回復§r§f: 仁王の構え（硬い 子）＋ 再誕術の 子。弱った 味方を 守りながら 立て直す",
    "§l§e溜めて 一撃§r§f: 闘気爆発（溜め2段）→ 静かなる溜め → 4倍の 一撃。霧散の波動で 消されないよう「不動の加護」の 子で",
    "§l§e耐性 破り§r§f: ○○ブレイクの 特性 ＋ 妖光の帳 で、無効・吸収の 相手にも 得意属性を 通す",
    "§l§e強化つぶし§r§f: 霧散の気（ときどき）・霧散の波動・消光の一閃 で 相手の 溜め・再誕・真価解放を 消す",
    "§l§e特性 特化§r§f: ○○の申し子・会心 特性の 子に 真価解放（1.5倍×2回）",
    "§l§e乱舞§r§f: 千刃の舞・百花の拳舞 は 撃つほど 武力・物力が 上がる。いきなり剛力・ときどき 力溜めと 相性が よい"]],
  ["ダメージの 計算", ["§f物理系: §e物力の 半分 − 硬力の 1/4§f。武系: §e武力の 半分 − 硬力の 1/5§f（武系は 硬力が 効きにくい）。守りが 高くても 攻撃の 1/12 は かならず 通る。会心は 守りを 完全に 無視",
    "§f魔法系: §e魔力の 半分 − 魔硬力の 1/4§f（魔力の 1/9 は 通る）", "§f息系: §e吹力 × 0.36 − （硬力＋魔硬力）÷2 × 0.075§f（吹力 × 0.144 は かならず 通る。属性の 耐性と 息の 軽減・激減でも 減る）",
    "§fそこに 技の 威力・レベルの 伸び（Lv100で 約2.2倍）・得意な 種類と 属性・サイズ・弱点などを かける。当たれば 最低 1 ダメージ",
    "§a特質系§f: §e技ごとの 能力（走力・硬力・魔硬力・HP・MP・全能力 など）の 半分 − （硬力＋魔硬力）/2 の 1/4§f",
    "§f会心: 守り（硬力・魔硬力・守りの 強化・ぼうぎょ・軽減の 構えと 特性）を §e完全に 無視§f し、ハガネにも 大ダメージ（ダメージ上限の 特性は 1.5倍まで 残る）。§d魔法系の 会心は「魔力の 暴走」§f（1.75倍）。§3息系は 会心に ならない",
    "§fハガネ族（特性 ハガネボディ）: §e会心・物理系・武系・物力か 武力で きまる 特質系§f は ふつうに 通る。魔法系・息系などは 0〜2。野生の ハガネ族は HPが 2〜8 しか ない",
    "§f特性の 秘薬で あとから ハガネボディを つけた 子は §c戦いで HPが 1割§fに なり、物理系・武系・特質系を 軽減も 反射も できない（もう 一度 特性の秘薬を 使えば ほかの 特性に かえられる）",
    "§f溜め（テンション）: 重ねるほど 次の 攻撃が §e2→2.6→3.3→4倍",
    "§f通常攻撃は 物理系。物力（または 武力の 8割の 高い ほう）で なぐる。武器の 属性は のる"]],
  ["攻撃の 種類", ["§c【物理系】§f 拳や 体当たり。物力 対 硬力", "§6【武系】§f 剣・槍・斧・弓などの 武器。武力 対 硬力（硬力の 影響が 少し 小さい）。§6武者系§fが 使うと 威力 1.2倍",
    "§3【息系】§f 炎や 氷の 息。吹力で 威力が 決まり、守り（硬力と 魔硬力の 平均）は 少しだけ 効く（属性の 耐性と 息の 軽減・激減でも 減る）。ほとんどが 敵全体。§c竜系§fが 使うと 威力 1.2倍", "§d【魔法系】§f 術や 魔導。魔力 対 魔硬力。§5ネザー系§fが 使うと 威力 1.2倍",
    "§fモンスターごとに 得意な 種類（威力 1.15倍〜1.3倍）と 不得意な 種類（0.8倍）が ある", "§a【特質系】§f 技ごとに 決まった 能力（走力・硬力 など）で なぐる。ほとんど 無属性", "§f得意な 種類は 見た目で きまる（刀を 持てば 武系、口から 吹けば 息系、杖や 本なら 魔法系、速さ・硬さ・巨体が 武器なら 特質系）",
    "§f武器を 持っても ふつうの 攻撃は §c物理系§fの まま（武器の 属性は のる）。武系かどうかは §e技で きまる§f。武器は 武力・魔本は 魔力を 上げる"]],
  ["戦いの 場・負けたとき", ["§f戦いは いまの 場所の §e真上の 高い 空§f に できる ステージで 行う（その 地方の 背景・地面は こわさない）。終わると もとの 場所へ もどる。足場から 落ちても ステージに もどされる。", "§f野生・ボス・レイドに 全滅すると §a近くの 町の 宿屋§f で 目を さます（仲間は 全回復・お金は 半分）。物語の 戦いは その場で 再挑戦。", "§5レイドボス§f は 負けると 消える。", "§fスカウトに 失敗する たびに 同じ 種族の 率が §b+3%§f（最大 +24%・仲間に すると もどる）。", "§f技の 横の §6★§f は おすすめの 技（状況分析）。"]],
  ["マルチプレイ", ["§fマルチプレイの やりとりは §e距離の 制限なし§f（ワールドの 全員）。遠くの 相手との 対戦は 相手が 目の前に 来て、終われば もどる。", "§f「§b共闘する§f」で ほかの 人の 戦いに どこからでも さんせん（終われば もとの 場所へ）。", "§fもうしこみを 待つ あいだは「やめる」が できる。返事の 画面は 60秒で 閉じる。"]],
  ["弱点・相性の 表示", ["§f戦いの 行動を えらぶ 画面の 下に §d相手の 弱点§f が いつも 出る。", "§f「§d弱点・相性を しらべる§f」で 敵と 味方の 弱点・半減・無効・吸収、受けやすい 攻撃の 種類、いまの 反射・構え・状態異常・能力の 段階、行動順の 目安が 見られる。", "§f技の 横の §8[ ]§f は 相手ごとの 効き目: §a◎ばつぐん §f○ふつう §7△いまひとつ §8×無効 §b吸 吸収 §5反 反射 §8鋼 ハガネ", "§f相手を えらぶ 画面には 効き目と §7ダメージの 目安（最大HPの 約何%）§f も 出る（乱数・会心は ふくまない）"]],
  ["技の 種類", ["§c攻撃系§f: ダメージを 与える", "§a補助系§f: 能力を 上げる・下げる、封印、行動順の 逆転", "§b反射系§f: 1つの 技で 1種類の 攻撃だけを 跳ね返す。§eアタハンシャ§f＝物理系（武系は のぞく）・§eマホハンシャ§f＝魔法系・§eブキハンシャ§f＝武系・§eイキハンシャ§f＝息系・§eワザハンシャ§f＝特質系。「〜の陣」は 味方全員。属性ごとの 反射技は ない（属性は 加護・守りで 軽減）", "§5状態異常系§f: 毒や 睡眠などに する",
    "§2回復系§f: HP回復・蘇生・状態異常を なおす", "§9吸収系§f: ダメージを 与えて HPや MPを 吸う", "§4捨て身系§f: 強力だが HPを 削る・反動が ある",
    "§fスキルは §e入門編→熟練編→達人編→皆伝編§f。100まで 振って 配合すると 次の 編に 進む"]],
  ["属性（10種）", ["§c炎（ホムラ）§f 火傷に しやすい", "§9水（ミナモ）", "§b氷（ツララ）§f 凍結に しやすい", "§e雷（イカヅチ）§f 麻痺に しやすい", "§a風（ハヤテ）", "§6地（イワオ）§f 鈍足に しやすい",
    "§2木（コノハ）§f 毒に しやすい", "§7鉄（クロガネ）§f 出血に しやすい", "§f光（アカツキ）", "§5闇（トコヤミ）§f 恐怖に しやすい",
    "§f得意な 属性は 威力 1.15倍〜1.3倍、不得意な 属性は 0.8倍"]],
  ["耐性", ["§c弱点§f: 受ける ダメージ 1.5倍", "§a軽減§f: 0.5倍", "§b激減§f: 0.25倍", "§d無効§f: 0（効かない）", "§9吸収§f: ダメージの かわりに HPが 回復",
    "§f状態異常にも 弱点・軽減・激減・無効が ある",
    "§5ブレイク§f（特性）: その 属性の 攻撃は 相手の 耐性を 1段（超ブレイクは 2段）破る。§5妖光の帳§fでも 1段 弱まる",
    "§9吸収の体・無効の体§f（特性）: その 属性を 吸収・無効に する"]],
  ["状態異常（10種）", ["§5毒（ドクケ）§f: ターンの 終わりに ダメージ", "§c火傷（ヤケド）§f: ダメージ＋物力・武力ダウン", "§4出血（チシオ）§f: 動くたびに 最大HPの 8%（上位の 技ほど 重く 最大20%・ボスは 半分）",
    "§e麻痺（シビレ）§f: ときどき 動けない", "§b凍結（コオリヅケ）§f: 完全に 止まる（炎で とける）", "§9睡眠（ネムリ）§f: 攻撃を 受けるまで 動けない", "§6鈍足（ニブリ）§f: 走力が 半分",
    "§d混乱（マドイ）§f: 敵味方 関係なく 攻撃する", "§d魅了（ミイリ）§f: しばらく 相手の 味方に なる。§e魅了中は スカウトしやすい", "§8恐怖（オビエ）§f: 逃げ回って 攻撃しない"]],
  ["行動順と 封印", ["§fまず §b先制度§f の 高い 行動から（用語「先制度」）。同じ 先制度なら 走力の 高い 順", "§d逆転の場§f: しばらく 走力の §e低い 順§fに 動く（先制度は そのまま）", "§d後の先§f: この 特性を もつ モンスターは 遅いほど 先に 動ける",
    "§7封印§f: 「封拳・封武・封息・封魔」の 技や 特性で、相手の 物理系・武系・息系・魔法系の 技を 数ターン 使えなく できる"]],
  ["系統（10）と ボーナス", ["粘液系: HP↑ 魔硬力↑", "獣系: 物力↑ 走力↑", "§a動物系§f: 走力↑ 物力↑（鳥・虫・植物の 姿の ものや、熊・虎・狼 など 強い 獣も）", "海系: HP↑ 魔硬力↑ 吹力↑",
    "無機物系: 硬力↑↑ 走力↓", "§4ネザー系§f: 魔力↑↑ HP↑（悪魔・死者・ネザーの 住民。ネザーや エンドにも すむ）", "武者系: 武力↑↑", "竜系: 吹力↑↑ HP↑", "§6王系§f: 全能力↑（全員 SSランク・2〜3回行動）", "§e神系§f: 全能力↑↑（全員 Xランク・3〜4回行動）"]],
  ["装備", ["§f§l武器 16種§r§f（用語「武器 16種」）。それぞれ 4段。種類ごとに 戦う 能力と 攻撃属性が ちがう", "§f属性つきの 武器は ふつうの 攻撃が その 属性に なり、その 属性の 威力も 上がる",
    "§f防具: 軽装・重装・法衣  装飾: 指輪・首飾り・護符", "§fモンスターごとに 装備できる 種類が 決まっている（相棒は なんでも OK）", "§f装備には レア度（F〜X）が あり、同じ 装備でも 能力に はばが ある",
    "§f武器を 装備すると その 武器を 手に 持ち、武器に あわせた 動きで 攻撃する", "§e属性の 武器§fには 技が 組みこまれている（例: 雷の 剣→§e稲妻斬§f）。段2以上は さらに 奥義"]],
  ["ランク・サイズ・枠", ["§fランク: F→E→D→C→B→A→S→SS→X", "§fパーティは §e4枠§f まで: §bS=1枠・M=2枠・L=3枠・G=4枠§f（例: S×4／M×2／L＋S／G×1）",
    "§f大きい ほど レベルアップの 伸びが 大きい: S 1倍・M 1.3倍・L 1.65倍・G 2.1倍", "§fL・Gは 物理系・武系・通常攻撃が §d敵全体§fに（ねらった 敵 以外は 0.75倍）", "§fGは さらに 1回の 行動で §d2回 攻撃§f（2撃目は 半分の 威力）",
    "§f野生の 敵の 群れも 合計 4枠まで（G なら 1体）"]],
  ["戦いの 作戦（ブレイク・ためる・連携・地形）", ["§6§lブレイク§r§f: 敵には §8[守3]§f のような 守りの ゲージ（S 2・M 3・L 4・G 5、ボスは +3）。§e弱点を つく か 会心§f で 1つ けずれ、0に なると §6ブレイク§f（1回 休み・受ける ダメージ 1.3倍。その あと しばらく けずれない）。対戦・レイド・エンマでは なし", "§6§lためる§r§f: だれでも 行動で「ためる」を えらべる。次の 攻撃が ×2（重ねると ×2.6・×3.3・×4）。敵も ときどき ためる", "§d§l連携§r§f: 同じ ターンに 同じ 相手を ちがう 仲間が 攻撃すると 威力 ×1.1・×1.2・×1.3。組み合わせの よい 系統（例: 竜＋剣＝竜騎の 一閃、スライム＋水＝しぶき アタック、同じ 系統どうし）だと 2人目で §d連携技§f（追加で ダメージの 半分）", "§f§l地形§r§f: 戦う 場所で きまる（森＝木・水辺＝水・灼熱＝炎・雪原＝氷・大地＝地・空＝風 など）。同じ 属性の 技は 1.2倍。天候とも 重なる", "§f§l150ptの スキル§r§f: 達人編・皆伝編の スキルは 150ptまで 振れる。150ptで 達人編は §a軽減§f（その 系統 -25%）、皆伝編は §6ブレイク§f（守りを 2つ けずる・その 系統 +10%）の 特性"]],
  ["相棒と ふれあう・遊び場", ["§f連れ歩きの 子を §dたたく§f と: なでる・抱っこ（6秒・しゃがむと おろす）・高い高い・ぎゅっと する・おしゃべり。どれも 1日 1回 なつき度が 上がる（L・Gサイズは 抱っこ できない）", "§b遊び場へ 行く§f（冒険）: 7つの 浮島。行く ときに 持ち物の 道具は バッグへ しまう（ガイドブック → バッグ から 出せる）。赤い 台で もとの 場所へ", "§fどの 島でも §eボール§f（雪玉）を 投げると 相棒が 走って 取って くる。空中で キャッチ する ことも", "§f運動場の 島: §6金の 線§f に 立つと 相棒と かけっこ。相棒は 追いつく ときに ダッシュ・前に いる ときは 力を ためる", "§f広場の 島: §6土俵§f の まん中で 相撲。たたいて おしだす。相手の 体当たりの かまえは よこへ よける・かまえ中に たたくと 大きく くずせる", "§fプール: §6金の 線§f で 水泳競争（向こうの かべで タッチ）／迷路: 入口で 迷路競争（相棒は 道を 考えるが ときどき まよう）／アスレチック: §6北の 金§f で 足場わたり（落ちたら やりなおし）", "§f砂浜: §6だいだいの 台§f で 宝さがし（砂を こわす・あつい つめたい。相棒も においで さがす）／原っぱ: §a緑の 台§f で かくれんぼ・§5紫の 台§f で おにごっこ（40秒 にげきる）。勝つと なつき度（1日 1回ずつ）", "§7どの 遊びも 台や 線の 上に §f1秒 立つと§7 はじまる（通りすぎる だけでは はじまらない）。足場わたりは 最後の 足場を ふまないと ゴールに ならない"]],
  ["地方マスターと お見合い配合", ["§f勝った 地方マスターに 話しかけると「お見合い配合」。マスターの 仲間の 写しを かりて 配合（あなたの 子は 1体 へる）", "§f写しは あなたの 子と 同じ Lv・プラス値は 低い ほう。お礼は 300G＋Lv×20G。1日 3回まで"]],
  ["体質（受ける ダメージを へらす）", ["§fすべての モンスターに、見た目に 合った §a体質§f が 1つ ある（特性とは 別わく。特性の 数は へらない）", "§f例: ぷるぷるボディ（スライム系）＝物理系と 武系 -25%／鋼鉄の装甲（物質系・機械）＝物理系と 武系 -25%／すりぬける体（悪魔系の 浮く 子）＝物理系 -35%／竜の うろこ＝息系 -35%／厚い 毛皮＝物理系 -25%・氷 -35%／魔を はじく 衣＝魔法系 -35%／王の 威厳・神の 衣＝4つの 系統 -20%・-25%", "§f会心の 一撃は 体質を 無視する。弱点の 属性は 体質では へらない。ほかの 軽減と 合わせて 90% まで", "§7モンスターの くわしい 画面の §a◆体質§7 で 見られる"]],
  ["特性と 行動回数", ["§f特性は モンスター 1体ずつの 才能。ランクで 数は かわらない", "§d複数回 行動は 交代制§f: 全員の 1回目 → 全員の 2回目 … の 順に 動く（ほかの 子の 行動が 間に はさまる）", "§fS: 2〜3個（C ランク 以上は ときどき 2回行動。§eF〜D の Sサイズは 1回行動§f）  M: 3〜4個（1つは かならず §d2回行動§f）",
    "§fL: 4個（1つは かならず §d2〜3回行動§f）  G: 5個（1つは かならず §d3〜4回行動§f）", "§f行動回数は 特性で きまる",
    "§bサイズの 秘薬§f: 1段階 §a大きく§f するごとに 行動回数 §a+1段階§f・特性の 数値 §a×1.15§f。1段階 §c小さく§f するごとに 行動回数 §c−1段階§f・特性の 数値 §c×0.8§f（段階: 1回→2回→2〜3回→3〜4回。M 以上は 2回、L は 2〜3回、G は 3〜4回を 下回らない）",
    "§fライドの 飛行・浮遊は 体の つくりで きまる もので、特性では ない",
    "§b小さく した とき§f: サイズの 秘薬で 小さく すると 能力が 下がり、特性も §eS 3個・M 4個・L 5個§f まで に へる（大きく もどすと もとどおり）",
    "§b手に 入れ方§f: §e縮小の秘薬（S）§fと §eちぢみの実§fは 町の 道具屋（2段目の 町から いつも 売って いる）。ちぢみの実は クラフトでも 作れる（光る鱗粉×2・命の木の芽×2）。戦いの 落とし物でも 出る",
    "§6王§fは かならず 2〜3回行動、§e神§fは かならず 3〜4回行動",
    "§b◇個体の 特性§f: 行動回数・系統の王・固有特性 以外は、その 種族に 合う ものから 個体ごとに 入れかわる（1つは 元の まま・1つめは 相性の よい もの）",
    "§6固有特性§f: 種族ごとに 1つの 金色の 特性。持っている 個体は まれ（固有の結晶で 目覚める）",
    "§a特性の秘薬§f: 好きな 特性を 1つ 追加（1体 1回）。§b特性の 選びなおし薬§f: 個体の 特性を 選びなおす",
    "§dSS・Xランク§f は 強い 特性だけを もつ。ロマン配合の スキルを 100まで 振っても 特性が つく"]],
  ["攻撃の 種類の 特質", [`§c物理系§f: ${CAT_TRAIT.phys}`, `§6武系§f: ${CAT_TRAIT.weapon}`, `§3息系§f: ${CAT_TRAIT.breath}`, `§d魔法系§f: ${CAT_TRAIT.magic}`, `§a特質系§f: ${CAT_TRAIT.special}`,
    "§f技の 威力は §eレベル§f（Lv100で 約2.2倍）と §e得意な 攻撃の 種類・得意な 属性§f（Lv1 1.15倍 → Lv100 1.3倍）で 上がる。「詳しく」で 実威力が 見られる", "§f無属性の 技は 属性の 耐性に 左右されない"]],
  ["スキルの 段階", ["§fどの スキルも §e3・5・6・8・10pt§f、そのあとは §e3〜5ptごと§fに 技か 能力が 上がる。技は 1つの スキルで 最大 10こ",
    "§e§l解放するほど 上がり幅が 大きく なる§r§f: §a入門 +3→+8§f・§b熟練 +5→+12§f・§d達人 +8→+16§f・§6皆伝 +11→+22§f（HPは 3倍・MPは 2倍）",
    "§6固有スキル§f: SS +13→+25・X +16→+31。その モンスターだけの スキル（スキルの 枠とは べつに 1つ）。100ptで その モンスターだけの 覚醒の 特性",
    "§d皆伝編（最上位）§fと 固有スキルは §e100pt§fで その スキルに あった §d特性§fを 覚える", "§f入門編→熟練編→達人編→皆伝編。100まで 振って 配合すると 次の 編に",
    "§fスキルの 区分: 属性の 技・属性の 書・§b天候§f・§bみかわし§f・無属性・武器の 型・状態異常・鼓舞と 崩し・特殊・能力アップ・系統の 秘伝と 奥義・§6神伝§f"]],
  ["石板と クリア後", ["§d石板§f（15枚）: 苔むしの石板（主 Lv17）→ 王冠の石板（主 Lv79）。中は 階ごとに §e迷宮・暗い 迷宮・宝物庫・広い 大地§f の どれか。最後の 階に 主",
    "§f§l石板の 迷宮§r§f: 部屋と 通路で できた 迷路。§c見える モンスター§f が うろつき、ぶつかると 戦い（§c赤い 名前§f は 追って くる・§b水色の 名前§f は 逃げる。逃げる 子に 勝つと 種・1日 5こ まで）。戦いの あと 3秒は ぶつかっても 戦いに ならない",
    "§f行き止まりに §6宝箱§f。§e金の 床§f で 鍵を 拾うと 階段の 部屋の §7鉄の 扉§f が ひらく。§a緑の 床の スイッチ§f を ふむと どこかの §7ひびの かべ§f が くずれて 近道に。§a光る 場所§f で 素材を 拾える（1日 30回 まで）。石板の 中では ブロックを こわせない。暗い 迷宮は 見通しが 悪い",
    "§f地方マスター（城）・カップ・遺跡で 石板が 手に 入る。§e遺跡を 8つ§f 越えると 終の遺跡",
    "§b再会の石板§f（エンディング後）: 仲間に した ことの ある モンスターが うろつく 世界（みんな Lv10）。各ランクは その ランクを 仲間に した かずで 開く（F 50・E 40・D 30・C 25・B 20・A 15・S 10・SS 8・X 5）",
    "§6覇王の石板・神域の石板§f: 王たち・神々と 戦う（主は スカウト できないが、倒すと 確率で 1体 仲間に）。§4閻魔の神殿§f: はじめて 入ると 悪夢（かならず 負ける 強制戦闘）。クリア後、裏ボス カゲツに 勝って 得た §4魔神の鍔§f を 捧げると エンマ（エンマの 技「国崩」は すべての 守りを 無視）",
    "§6§l厄王 ヴァルグレイド§r§f（王系・SSランク・G）: 覇王の石板の 主として 15%で 現れる。倒すと 8%で 仲間に。両腕を 大きく 広げた 臨戦の 構えの 鋼の 覇王。攻撃は §d瞬間移動して 2連続で 斬る§f。固有技「双覇断」（敵全体に 2回）",
    "§5怪しい 薬屋§f（エンディング後・町の ショップの 奥）: 特性の秘薬・転生の秘薬・極みの秘薬・叡智の秘薬・闘魔覚醒・能力の 実+100 など",
    "§c物語の 石板の 再戦§f（クリア後）: 封印した 石板に もう一度 触れると 再戦（何度でも）。主は 石板ごとに ちがう 王系の モンスター（Gサイズ・1体）で HP 15000・MP 5000・ほかの 能力 1200〜（手持ちが 強いほど 上がる）。石板の 王 ヴァルグレイドは HP 25000・MP 9999・ほか 2000",
    "§fチートブックの「クリア後の 世界を ためす」で 自分の 物語だけ クリア後に できる（もとに 戻せる）"]],
  ["地方の 景色", ["§f地方ごとに 地面・草花・木が ちがう。近くを 歩くと その 地方らしい 景色に なる",
    "§aアルカトラス§f=草原と 花畑の 大自然、§2シルヴァ§f=苔と 泥の 湿地帯（沼の 木・スイレン）、§7ルインズ§f=固い 土と 砂利の 荒れ地、§cヴォルカ§f=黒い 岩と 玄武岩の 火山",
    "§eサンドリア§f=砂と 砂岩の 砂漠、§dクリスタリア§f=方解石と 凝灰岩・アメジスト、§bマリノア§f=白い 砂浜と ヤシ、§8ネクロス§f=魂の 土と 骨の 冥府",
    "§fフロストヘイム§f=雪と トウヒの 雪山、§4ラグナ§f=真紅と 歪んだ 大地、§eセレスティア§f=花の 野と 桜",
    "§f町は 海や 川の そばでも 水が 入らない ように 堤防で かこまれて いる",
    "§7町・城・ステージ・遺跡の 中や 水は さわらない"]],
  ["起き上がる 仲間", ["§f野生の モンスターに 勝つと、倒した 子が ときどき §d起き上がって 仲間に なりたそうに§f する。「仲間に する」で 仲間に なる（1回の 戦いで 1体まで）",
    "§fランクごとの 確率: §fF 12%・E 10%・D 8%・C 6%・B 4.5%・A 3%・S 1.8%・SS 0.8%・X 0.3%",
    "§7ボス・マスター・レイド・石板・宝の 番人・地方の 主・対戦では 起き上がらない。物語の 上限より 上の ランクも 起き上がらない。預かり所が いっぱいだと 仲間に できない"]],
  ["スカウト", ["§aスカウト できる§f: 野生・石板の 中の モンスター・銅〜虹の 石板ボス・レイドボス・フィールドの（ほかの 地方の）マスターの モンスター・遺跡や 神殿の ボス",
    "§cスカウト できない§f: 物語の ボス（闘技場・城・星冠王・エンマ など）・地方マスター・石板の 主・石板の 番人（猛者）・覇王／神域の 主（倒すと 確率で 仲間に）",
    "§eスカウトの しかた§f: 「スカウト」を えらぶと 自分の 仲間が 1体ずつ 敵に 力を 見せつけ、§dスカウト率が たまって いく§f。最後に その 率で 判定。§d2回行動などの 子は その 回数ぶん 見せつける",
    "§e見せつける 力§f: その 子の §b物力・武力・魔力§f の うち いちばん 合う もの と、相手の §b硬力（物力・武力）か 魔硬力（魔力）§f を くらべる。相手より 強いほど たくさん たまる",
    "§f率が 上がる: 仲間の 攻撃力が 相手の 守りより 高い・敵の HPが 少ない・眠り／氷／魅了・スカウトの 道具（1回 +30%まで）・スカウト系の 特性",
    "§c率が 低い: ボス（12%まで・石板の 主は 15%まで）・レイドボス（物語の 序盤は 5%まで → 進むほど 上がり エンディング後は 100%まで。1回の 戦いで スカウトは 1人 1回だけ。負けたら その場で 消える）・マスターの モンスター（40%まで）・物語の 上限より 1つ 上の ランク（20%まで・2つ 以上 上は まだ 仲間に できない）。失敗すると 15%で おこって もう スカウトできない",
    "§f野生は スカウトに 成功した 時点で 勝ち。ボス戦・マスター戦は 仲間に した 子だけ ぬけて 戦いは つづく"]],
  ["こうさん・マルチ", ["§cこうさん§f: ボス・マスターなど 逃げられない 戦いでは「逃げる」の かわりに こうさん（お金は へらない）。40ラウンドで 時間切れ",
    "§f物語の 敵・野生の 敵は 再誕の誓いを 使わない", "§fマルチでも 物語の 進みは ひとりずつ。物語の 戦いと 石板の 中には ほかの 人は 加われない",
    "§f戦闘中は まわりの プレイヤーと NPCが 透明に なる"]],
  ["落とし物", ["§fモンスターを 倒すと 1体ごとに かならず §e2〜3個§f 落とす", "§f素材・道具・お金・スキル書・スキルポイントの 巻物など。ボスは 4個", "§f強い モンスターほど 良い ものを 落とす（熟練編の 書・神伝の 書・進化の石・闘魔覚醒の秘玉 など）"]],
  ["進化・覚醒", ["§fレベル進化: 決まった レベルで 進化。§c「進化しない」設定§fにも できる（モンスター→進化・覚醒）。あとから 手動で 進化できる", "§6進化の石§f: 系統ごとの 石で 決まった モンスターが 進化する",
    "§5闘魔覚醒§f: 「闘魔覚醒の秘玉」を プラス値 +99 以上の モンスターに 使う（§c神は できない§f）。§d能力 +25%§f・§6固有特性が 目覚める§f・§d毎ターン 行動 +1§f（4回まで）・§dダメージ上限（999）なし§f・§d戦いの はじめに 全能力 +1段階§f・§dスキル枠 +1§f。F〜Sランクは さらに §dSS§fランクの 力に。見た目は そのまま", "§f配合で §b親と 同じ モンスター§fを 選ぶと 姿を かえずに プラス値を 上げられる",
    "§e進化の 見た目§f: 進化先は 進化前の 体・顔・もようを 受けついで 成長する（足が のびて すらりと・系統ごとに 角・とさか・ひれ・花・よろい など）。§fSサイズの 子は 進化すると §eMサイズ以上§f に"]],
  ["やりこみ：挑戦", ["§f§lガイドブック →「やりこみ」→「挑戦する」§r§7（エンディング後）。パーティの コピーで 戦う（本物は 減らない・経験値なし）。空の 闘技場で",
    "§c無限の塔§f: 1階ずつ のぼる。回復なし（道具は 使える）。10階ごとに 番人（HPが 多い）。はじめて 越えた 番人の 階で お金・秘果・宝の地図・継承の秘石・限界突破の石・伝説の 装備・特性の秘薬。番人を 越えた 階から 再開できる。最高階は ランキングに",
    "§cボスラッシュの石板§f: 物語の 石板の 主15体 → 星冠王 の 16連戦。1戦ごとに 3割 回復。制覇で 50万タヨ・特性の秘薬・限界突破の石（はじめては 覇王の 伝説の 装備）。時間は ランキングに",
    "§c縛りの石板§f: 縛り2つ（Bランク以下だけ・1体だけ・魔法系の 攻撃技 禁止・Lv50・道具 禁止・S/Mサイズだけ）で 3連戦",
    "§c今日の挑戦状§f: 毎日 かわる 相手（全員 同じ）に 1日1回。勝つと 連続日数で ほうびが ふえる（3日ごとに 宝の地図・7日ごとに 限界突破の石）",
    "§c週替わりの強敵§f: 毎週 かわる 系統・属性の 強敵。何度でも。今週の 1・3・5・10回目に ほうび（5回目は その 系統の 伝説の 装備）"]],
  ["やりこみ：対戦", ["§9ランクマッチ§f: ゴースト（だれかの 登録パーティ）か AIと 1戦。レート（はじめは 1000）が 上下。ブロンズ→シルバー（1100）→ゴールド（1250）→プラチナ（1400）→マスター（1600）",
    "§f毎月 シーズンが かわる。最高レートで ほうびと 称号。新しい シーズンでは レートと 1000の 差が 半分に なる（例: 1400 → 1200）",
    "§9大会§f: 8人 トーナメント（ゴースト＋AI）。試合の 前に 回復。優勝は 全員に お知らせ",
    "§9ルール§f: 自由・Lv50 統一・同じ 種族なし・SS/X 禁止・スタンダード（3つ 全部）。大会と マルチの 対戦で えらべる", "§7Lv50 統一では 神の 上乗せ（戦いと 実の ぶん）も 外れる",
    "§9対戦の HP§f: マルチの 対戦では 全員の HPが §e2倍§f（1ターンで 決まらない ように。終わっても HPは 減らない）",
    "§9ゴースト§f: いまの パーティを 登録すると、ほかの 人が AIの あなたと 戦える（24人まで）"]],
  ["やりこみ：育成と 収集", ["§6技の 極め§f: 同じ 技を 100回 使うと「極めた」技（威力 +10%・消費MP -20%）。詳しい 情報の 技の 横に ★と 回数",
    "§6完全個体「極」§f: 才能 すべて 31・固有特性あり・個体の 特性（◇）が すべて 相性◎。名前に 極が つく",
    "§6継承の秘石§f: 配合の とき、親の 特性を 1つ 子に 受けつがせる（子の 特性と 入れかえ）",
    "§6限界突破の石§f: Lv100の 仲間の 能力 +4%（5段まで・+20%）",
    "§6伝説の 装備§f: 系統ごとの 刃・鎧・紋章（地方の 主・週替わりの強敵・図鑑の 系統 完成・塔・宝箱）。その 系統なら だれでも 装備。2つで 威力+10%・被ダメ-5%、3つで 威力+20%・被ダメ-12%・会心+5%",
    "§6期間限定の 色違い§f: 毎週 1つの 系統が かがやきやすい（1/250 → 1/50）",
    "§6図鑑の 達成報酬§f: 図鑑 100種ごと・系統の 完成（称号＋伝説の 装備）・ランクの 完成・かがやき図鑑・固有特性図鑑・散歩・ライド・極",
    "§d幻の モンスター§f: 満月の 夜・雷雨・雨・夜明けに だけ、Lv40以上の 土地に まれに 現れる SSランク",
    "§4地方の 主§f: クリア後、地方を 歩いていると まれに 現れる Gサイズの ボス（Lv100・スカウト不可）。倒すと 称号と 伝説の 装備",
    "§6宝の地図§f: 使うと 300〜700m 先に しるし。着くと 宝の 番人。倒すと 宝箱と お宝（強い 敵・ボスからも ときどき）"]],
  ["やりこみ：施設と 称号", ["§2牧場§f: 預かり所から 5体まで。時間で 経験値・お金・タマゴ（24時間ぶんまで）",
    "§2研究所§f: 素材を 寄付して 研究ポイント。宝の地図(30)・継承の秘石(120)・秘果(200)・限界突破の石(300)・転生の秘薬(400)・特性の秘薬(600)を お金で 作れる",
    "§5虚空の島§f: 星冠王・王冠の石板・終の遺跡を 越えると 行ける 天の 島。SSランクと、まれに 神（Xランク）が 出る（Lv90〜100・スカウトは 半分の 確率）",
    "§6称号§f: 名前の 上に 出る。やりこみ →「称号と 記録」。記録帳には 最大ダメージ・連勝・塔・ラッシュ・主 など"]],
  ["宝箱の レア度（10段階）", ["§fどの 宝箱も 中身は §e5〜10こ§f。ちがうのは レア度。§e開けると 中身を 一括で バッグへ（いっぱいなら 足もとに）。取りおわった 箱は 消える§f。自分で 置いた 箱は ふつうに 開く。開けると 名前が 出る。§b銀§f 以上は 光の 粒、§6王家§f 以上は 全員に お知らせ",
    "§f見た目: 1 小さな宝箱=たる・2 木の宝箱=チェスト・3 鉄=灰色の 箱・4 銀=白・5 金=黄・6 宝石=黄緑・7 魔法=赤紫・8 王家=赤・9 伝説=黒・10 神箱=紫",
    "§f1〜3: 回復・お金・ふつうの 道具が 中心（レアな 道具も 少し）。特性の秘薬 0.5〜2%",
    "§f4〜5: レアな 道具・2段目の 装備・アクセ が ふえる。特性の秘薬 3〜5%",
    "§f6: 大きな 実・タマゴ・スキルの 巻物・宝の地図 も。特性の秘薬 7%",
    "§f7〜8: 秘果・3段目の 装備・秘薬類（継承の秘石・限界突破の石・特性の秘薬・王のタマゴ など）。伝説の 装備 0.5〜3%",
    "§f9: 上級の 品が 中心・秘薬類が 出やすい。伝説の 装備 10%",
    "§f10 神箱: 上級と 秘薬類 だけ。伝説の 装備 40%",
    "§7出る 場所: 道ばた 1〜・洞くつ 2〜・家 3〜・海の 底 3〜・ネザー 3〜・エンド 4〜・遺跡/神殿/城 5〜（強い 土地は +1〜2、ネザー +2、エンド +3）。石板の 中 3〜8・遺跡の ボス 6〜・宝の地図 7〜（3%で 神箱）。どれも ときどき 1〜4段 上に"]],
  ["海・洞くつ・ネザー・エンド", ["§3海§f: 水面には 海の モンスター。§bもぐると 海の 中にも 出る§f。水面から 8ブロック 以上 深い §1深海§f は Lv+6・強い ランクが 2倍・海の ぬしが 3倍。海の 底に 宝箱（鉄の宝箱〜・深海は +1）",
    "§7洞くつ§f: Y40より 下は 5ブロックごとに Lv+1（最大 +15）。Y0より 下の 深い 洞くつは 専用の 顔ぶれ（岩・死者・魔が 多い）で 強い ランクが 2倍。宝箱は 木の宝箱〜（Y0より 下 +1）",
    "§cネザー§f: Lv+15。ソウルサンドの 谷（死者）・玄武岩の 三角州（無機物・竜）・真紅の 森（魔・獣）・歪んだ 森（魔・自然）で すむ モンスターが ちがう。強い ランクが 2倍。宝箱は 鉄の宝箱〜、とりでの 宝は +2",
    "§5エンド§f: Lv+30。中心から 900ブロック より 外の 島は さらに Lv+8（魔・竜・鳥）。宝箱は 銀の宝箱〜（外の 島 +1）、せいどうの 宝は +3"]],
  ["装備の 特殊効果（F〜X）", ["§f装備の レア度は §eF・E・D・C・B・A・S・SS・X§f の 9段階。高いほど 能力が 高く、特殊効果が 多く・強い",
    "§f物理反射・魔法反射・武系反射・息反射: その 種類の 技を ときどき 跳ね返す（F 3% → X 25%）",
    "§fHP吸収（F 3% → X 21%）・MP吸収・反撃・会心・会心ダメージ・先制・連撃・守り貫通・全ダメージ軽減・MP消費なし・回復量・毎ターン回復 など",
    "§e物語の 進みで 解放§f: はじめは 装備・タマゴ・モンスター屋が §eF〜Dランク§f まで。封印・遺跡・カップで C→B→A→S、エンディングで SS、さらに その先で X", "§7店と クラフトの 武器・防具の 段も: D まで 一段目（短剣など）・B まで 二段目・S まで 三段目・SS から 四段目。タマゴ屋は 生まれる ランクの 多くが 上限を こえる タマゴを まだ 売らない（もらった タマゴで 上限より 強い ものは、物語を 進めるまで 取って おける。かえせる ように なると 本来の ランクで 生まれる）", "§7モンスターの 落とし物・宝箱の 中身も 同じ。物語より 先の 装備・素材・育成の 道具は お金に かわる。素材の 段も 同じ（二段目の 素材は C から）。進化の 石は C から", "§fスキルポイント: 最初の 仲間は §e10§f、レベルが 1 上がるごとに §e3§f。スキルの 枠が ふえても SPは ふえない（レベル・道具・配合で ふえる）",
    "§fいまの 上限は ガイドブックの「ストーリー」で 見られる。上限より 上の レア度が 出る ときは 上限の レア度に なる（すでに もっている 装備は そのまま）"]],
  ["色がえ", ["§f仲間 →「§6色がえ§f」で 1体ずつ §e頭・体・手・足・爪・翼や飾り§f の 色を 16色から えらべる", "§f「おまかせ」で ランダム、「もとの 色に もどす」で もとどおり",
    "§f色は もとの 色に 重ねて ぬる（模様や 影は のこる）。目と 武器の 色は かわらない"]],
  ["物語の 冒険（メインクエスト）", ["§f冒険の 目標は ガイドブックの「ストーリー」→ 次の 目標、または §aセオの 研究メモ§f（だいじなもの）で わかる",
    "§f地方ごとに いろいろな できごとが 起きる（何が 起きるかは 進んでの お楽しみ）",
    "§f共闘: NPCの 仲間が いっしょに 戦う（動きは 自動）。自分の 仲間が 全員 倒れると 負け",
    "§f物語の 戦いは 負けても お金は へらない。その場で「もう一度 挑む」（仲間は 全回復）か「あとで」（ガイドブックの「物語の 戦いに 再挑戦」で もう一度）を えらべる"]],
  ["地方の 関所", ["§f地方は 物語の 順に 開く: アルカトラス → シルヴァ → ルインズ → ヴォルカ → サンドリア → クリスタリア → マリノア → ネクロス → フロストヘイム → ラグナ → セレスティア",
    "§fその 地方の §6主§f を 倒すと 次の 地方へ 行ける（地方マスターの 石板の 主を 封印・シルヴァは 森の 主・サンドリアは 王墓の 主）",
    "§fまだ 行けない 地方へ 入ろうと すると「§7まだ やるべき ことが あるようだ、引き返そう§f」と 押し戻される（乗っている 仲間ごと）",
    "§fクリア後は どこへでも 行ける。チートブックの ワープでは 関所を 外せる（あとで もどせる）"]],
  ["だいじなもの", ["§fストーリーアイテム。使っても なくならない。なくしても しばらくすると 手元に もどる",
    "§6懐中電灯§f: 持っていると 洞くつ（地下）が 明るく 見える。ないと 暗くて よく 見えない",
    "§6潜水ゴーグル§f: 持っていると 水の 中が 明るく・息が 続く。ないと 深い 海（水面から 10以上）は 真っ暗",
    "§6物語で もらう だいじなもの§f: 決まった 場所（ステージ・海の 深く など）で 使うと できごとが 起きる。どこで 使うかは 右上の 案内で わかる",
    "§4魔神の鍔§f: 裏ボス（伝説の マスター カゲツ）に はじめて 勝つと 手に入る。持ち主を さがそう"]],
  ["マスターと ライバル", ["§f§lNPCに からまれて 戦いに なる ことは ありません§r§f",
    "§bモンスターマスター§f: フィールドや 町を うろついている。§e話しかけると 勝負できる§f（断っても OK）。勝つと マスターポイント",
    "§bライバル レイ§f: 地方ごとに 1回 声を かけてくる。勝負するか えらべる（断っても また 会える）",
    "§bステージの 番人§f: ステージ（大地）に はじめて 入ると 現れる。挑むか えらべる（断っても 次に 来た ときに また）", "§f町に はじめて 着くと うわさや 小さな おくりもの"]],
  ["道具の 角の 印", ["§f同じ 形の 道具は 角の §e小さな 色の 印§fで 見分ける", "§7属性（炎=赤・水=青・氷=水色・雷=黄・風=黄緑・地=茶・木=緑・鉄=灰・光=白・闇=紫）・能力・系統・武器の 種類ごとに 色が ちがう"]],
  ["戦闘の 画面", ["§f技を 出すと 画面の まんなかに §l技の 名前§f が 大きく 出る。モンスターの 頭の 上に §aHPバー§f", "§f自分の 番に なると 画面の 下に「ガイドブックを 使って 行動を えらぶ」。§eガイドブックを 使うと§f 行動を えらぶ 画面が 開く（相手の HPの 残り・状態異常・バフも ここに）。演出の とちゅうで 使っても、自分の 番に なると すぐ 開く。画面を 閉じたら もう一度 本を 使う", "§f戦いの できごとは 色分け: §b→ 自分の モンスター§f・§a→ 味方（協力バトルの なかま）§f・§c← 相手§f。技の 名前の 色も 同じ", "§f画面の 上に 自分の モンスター（最大4体）の §lアイコン・名前・HP・MP§f と 状態異常・バフ（§a↑§f/§c↓§f）。画面の 左に 戦いの できごと（さいごの 6行・太字）", "§7設定で 上・左の 枠を けしたり、できごとを チャットにも 出せる。くわしい できごとは 行動の 画面の「戦況・ログを 見る」。対戦で 90秒 えらばないと おまかせ"]],
  ["ハンシャと マネマネ", ["§bハンシャ§f: 攻撃を 跳ね返す（2ターンまで）。使う ターンは §c行動が 1回 へる§f（2回行動なら 1回）",
    "§7ハンシャ封じの霧§f: みんなの 反射を 消して 3ターン 張れなく する。特性§e反射やぶり§fの 子の 攻撃は 跳ね返らない",
    "§dマネマネ§f: 最優先で 構え、その ターンに 受けた 攻撃（4つまで）を ターンの 最後に まとめて 返す。§7神技・自爆・ため技・反動技・1回休みの 技などは まねできない。使う ターンは 1回しか 動けない"]],
  ["デメリットの ある 技", ["§c反動技§f: 強いが 与えた ダメージの 一部を 自分も うける（決死の突進・魔力暴走・命削りの息吹 など）",
    "§c1回休みの 技§f: とても 強いが 次の ターンは 動けない（全力の鉄拳・大振りの剛剣・極大魔砲・全霊の咆哮）",
    "§c行動が へる 技§f: ハンシャ・全能力アップなど 強い 強化は 使う ターンの 行動が 1回 へる"]],
  ["タマゴを まとめて かえす", ["§fガイドブック →「道具・装備」→「道具・タマゴを 使う」→「タマゴ」→ いちばん 上の §6ぜんぶ かえす", "§7預かり所の あきの ぶんだけ かえる。生まれた 子と ランクを まとめて 表示"]],
  ["石板の 道具", ["§fガイドブック →「道具・装備」→「道具・タマゴを 使う」に §e【石板】§f と §d【特別な石板】§f と §6【だいじなもの】§f",
    "§e石板§f: かかげると ボスが 現れる（使うと なくなる）", "§d特別な石板§f: 物語に 必要な 十五の 石板。使っても なくならない（封印後は 再戦）。地方マスターから 受けとった 石板が 手元に ないときは 自動で もどる"]],
  ["町の 近くの 神殿", ["§f始まりの町の 近くに はじめから ある。§cはじめて 足を 踏み入れると「嫌な 予感が する……」§f → 抜き身の 刀を 持つ 何かとの 強制戦闘。こちらは 何も できず 先手を 取られ、かならず 負ける",
    "§f負けると 自分の 家で 目が さめる（悪夢）", "§fクリア後、裏ボス §bカゲツ§f に 勝つと §4魔神の鍔§f。§d魔神編§f が 始まる（はがねの 村 クロガネの 武士 → 閻魔の神殿）。エンマを 倒すと ムサシが もどり、魔神の鍔で エンマの 姿に 変われる ように なる",
    "§4エンマ§f の 姿は 2つ: 鍔を 捧げる 前は §7悪夢の 姿§f、捧げた あとは §c現世の 姿§f。どちらも 腰の 刀を 抜いて 斬り、斬り終えると 鞘に おさめる。エンマは 仲間に ならない。ムサシを 親に して 配合すると ムサシだけが 生まれる（お見合い 配合は できない）"]],
  ["持ち物", ["§f死んでも 持ち物を 落とさない（ワールドに 入ると 自動で 設定）"]],
  ["戦闘の 表示", ["§f戦闘が はじまっても 背景が 変わらない・モンスターが 見えない ときは、コマンドの 一番下「§7表示を なおす§f」を 押すと 背景を 作りなおし、モンスターを 置きなおす",
    "§f戦闘の 開始時にも 自動で 2回 確かめる。町の 中でも 背景を 作る（終われば もとに 戻る）"]],
  ["相棒の 配合", ["§f相棒（カスタムの 子）を 親に すると、§d相棒だけ§f が 生まれる（ムサシと 同じ）。§f見た目・名前・きずなは そのまま 受けつぎ、プラス値と スキルは ふつうの 配合と 同じく 上がる", "§7ほかの 親は いなくなる。ムサシと 相棒を いっしょに 親には できない"]],
  ["相棒の 見た目と 武器", ["§f仲間 →「相棒（カスタム）」で 体・頭の形・顔・ツノ・つばさ・しっぽ・§eマント§f・§e武器§f・色を いつでも 作りかえられる",
    "§f色 18・体 11・頭 10・顔 12・ツノ 10・つばさ 8・しっぽ 8・マント 6・武器 16（剣・槍・斧・銃・二刀流・弓・魔導書・こん棒 など）",
    "§f武器を 装備すると 見た目も その 武器に なる（二刀流は 両手に 剣）。攻撃の 動きも 武器ごと: 剣=斬りおろし・二刀流=左右の 連撃・槍=突き・斧/こん棒=たたきつけ・弓=引いて 射る・銃=かまえて 撃つ・魔導書=かかげて 放つ"]],
  ["天候（9種）", ["§f戦いの 場の 天候で 属性の 威力が かわる。§e闘技場は いつも 晴れ§f。野生の 戦いは 場所と ワールドの 天気で きまる",
    "§6晴れ§f: 炎 1.5倍・水 0.5倍", "§9雨§f: 水 1.5倍・炎 0.5倍", "§e砂嵐§f: 地 1.3倍・鉄 1.2倍。地・鉄が 得意な 子と 無機物系 いがいは 毎ターン 最大HPの 1/16 ダメージ",
    "§b雪§f: 氷 1.5倍・炎 0.8倍。氷が 得意な 子 いがいは 毎ターン 1/16 ダメージ", "§e雷雨§f: 雷 1.5倍・水 1.2倍・麻痺に なりやすい", "§a暴風§f: 風 1.5倍・息系 1.1倍",
    "§7霧§f: 物理系・武系の 命中 0.8倍・木 1.2倍", "§5闇夜§f: 闇 1.5倍・光 0.7倍", "§f天光: 光 1.5倍・闇 0.7倍・回復 1.2倍",
    "§f天候の 技（日照りの舞・雨乞いの歌 など）は 5ターン。§d天候の達人§fは 8ターン", "§f特性: §e〇〇呼び§f（はじめから その 天候）・§e〇〇の申し子§f（走力 2倍）・§e〇〇の力§f（ダメージ +30%）・§e〇〇の加護§f（毎ターン 回復・天候の ダメージなし）・§e凪の心§f（天候の 効果を うけない）",
    "§f天候で 強く なる 技（1.6〜2倍）: 陽光砲・豪雨弾・吹雪・雷鳴撃・竜巻・霧斬り・闇夜の爪・聖光の矢・砂塵刃"]],
  ["先制度", ["§fすべての 技に §b先制度（-2〜+4）§f が ある。高い ほうが 先に 動く。同じなら 走力の 高い 順", "§b+4§f: 反射の 技（どの 行動よりも 先）", "§b+3§f: 身を守る・身を固める など 守りの 技",
    "§a+1〜+2§f: 影走り・抜き打ち・天候の 技・みかわしの 構え など", "§70§f: ふつうの 技", "§c-1§f: 威力の 高い 大技（後攻）", "§c-2§f: 捨て身・全魔解放 など（最後）",
    "§f特性【先制】は 先制度 +1。弓の「先手を とる」も +1", "§f技の 説明に「先制度 +1」などと 出る"]],
  ["命中・回避・急所ランク", ["§e命中§f: 物理系・武系（と 武器の 通常攻撃）は はずれる ことが ある。ふつう 95%（通常攻撃は 97%）、大技 80〜85%、連続攻撃 90%。かならず 当たる 技も ある",
    "§b回避§f: §l走力の 勝負§r§f。相手より 走力が 高いほど よく かわす（先制度・反射には 左右されない）。特性【見切り】【疾風の身のこなし】・技【みかわしの構え】で もっと かわす",
    "§f霧の 中は 命中 0.8倍。【霊体】は 魔法系や 息系も ときどき かわす。【心眼】で 命中 +10%", "§e会心§f: ダメージ 1.5倍（物理系 1.7倍）で 守りを 完全に 無視。魔法の 会心は 魔力の 暴走（1.75倍）。息系は 会心なし",
    "§e急所ランク§f: 技・特性【急所の心得】で +1、急所を ねらう 技で +2（最大 +3）。+1: 会心率 +8%・+2: +20%・+3: +40%", "§7画面に「MISS」「かわした！」と 出る"]],
  ["武器 16種", ["§c物力§fで 戦う: §f棍棒（打・ときどき 麻痺）・斧（斬・一撃が 重い・大きい 相手に 強い・少し はずれやすい）・ムチ（鞭・敵 全体を 左から 打つ・Sサイズに 1.3倍）",
    "§6武力§fで 戦う: §f剣（斬・会心）・刀（斬・1ターン目 強い・会心ダメージ）・二刀流（斬・2回 攻撃）・槍（突・守りを つらぬく）・大鎌（斬・通常攻撃が 全体・弱った 相手に 強い）",
    "§6武力§fで 戦う: §f弓（射・先手）・銃（射・かならず 当たる）・戦輪（射・2回 跳ねる・全体技 強化）", "§d魔力§fで 戦う: §f魔本（魔・MP 半分の ことも）・杖（魔・回復 +・MPが 回復）",
    "§e走力§fで 戦う: §f爪（斬・2回 引っかく・出血）・鉄扇（打・かわしやすい）", "§a特質（硬力と 魔硬力）§fで 戦う: §f呪具（呪・混乱や 恐怖・神と 王に よく 効く）",
    "§f新しい 8種（ムチ・爪・刀・大鎌・鉄扇・杖・戦輪・呪具）は 持てる モンスターが 少ない。図鑑の「装備」で わかる"]],
  ["攻撃属性", ["§f武器の 攻撃には 攻撃属性が ある（属性とは べつ）。相手の 系統で 効き目が かわる",
    "§f【斬】獣 1.2・動物 1.15 ／ 無機物 0.7・粘液 0.85", "§f【打】無機物 1.3・ネザー 1.15 ／ 粘液 0.8・海 0.9", "§f【突】竜 1.25・獣 1.15 ／ ネザー 0.8・粘液 0.85",
    "§f【射】動物 1.2・竜 1.05 ／ 無機物 0.75", "§f【鞭】獣 1.1 ／ 無機物 0.7", "§f【魔】無機物 1.25・武者 1.2・王 1.1 ／ ネザー 0.8・神 0.85", "§f【呪】神 1.3・王 1.2・武者 1.1 ／ ネザー 0.7",
    "§7戦いで「【斬】が よく 効く！」と 出る"]],
  ["クラフト素材", ["§fモンスターが 落とす 武器づくりの 素材が §e30種§f（段0・段1・段2 が 10ずつ）", "§f例: 堅木の枝・獣の革・鉄くず・鋭い牙（段0）／ 鋼の延べ棒・竜のうろこ・黒曜の刃片・銀の糸（段1）／ ミスリル鋼・竜の腱・王家の宝玉・不死鳥の羽（段2）",
    "§f武器の 種類ごとに 使う 素材が ちがう（例: ムチ＝革・なめし革・竜の腱、大鎌＝骨片・霊布・冥界の布）", "§fモンスターが 落とすほか、§e宝箱§f（段が 高いほど 上の 素材）・民家・お宝部屋の 箱にも 入っている", "§fガイドブックの「クラフト」で 必要な 素材が わかる"]],
  ["負けイベント", ["§f物語には 勝てない 戦いも ある（お金は へらない・仲間は 回復・負けても 物語は 進む）", "§eサンドリア§f: 王墓荒らしの 濡れ衣で 衛兵に つかまり、城の 地下牢へ……",
    "§eマリノア§f: ノクス団の ヴァルカに 海神の 貝笛を 奪われる。マリンと 追いかけて 取りかえそう（負けても やりなおせる）"]],
  ["戦いの ドーム", ["§f野生・NPCとの 戦いでは その 場所に あわせた 大きな ドームが できる（戦いが 終わると もとに もどる）",
    "§f森=葉の 天井と 木々・洞くつ=岩の 天井と 水晶・雪=氷の ドームと 氷柱・ネザー=ネザーラックと 巨大キノコ・海底=プリズマリン・砂漠や 草原=空が 見える 骨組み など",
    "§fカメラは ドームの 中に おさまるので、大きな モンスターでも 見やすい", "§7重いときは 冒険 →「設定」の「戦闘の 背景」を オフに すると 作らない（軽量モードでは 小さめ）"]],
  ["ライドの 種類", ["§fつれ歩いている 仲間に 右クリックで ライド。種類は 図鑑と 仲間の 画面の「ライド」に 出る",
    "§a飛行§f: 動物系と 翼の ある モンスター（§eダチョウ・ニワトリ・キーウィ・コカトリス§fは 走る、§9ペンギンの なかま§fは 水の上）。ジャンプ／上を 見ると 上昇・下を 見ると 下降", "§9うみ§f: 海系（と ペンギンの なかま）。§e水の 上を すいすい 進む§f（潜らない）",
    "§6よじ登り§f: 動物系や クモ・ヤモリ・ネコ などの 子。壁に 向かって 進むと そのまま 登る", "§8掘り進み§f: モグラ・ドリル などの 子。ぶつかると 土や 石を 掘って 進む（ブロックは 落ちる）。下を 見ながら 進むと 下へ 掘る。§7町と 家の 近く・れんがや みがいた 石などの 建物は 掘らない",
    "§fあるく／ふゆう: ふつうの ライド。乗って 走ると 種類ごとの 動き（駆け足・はばたき・泳ぎ・よじ登り・掘る）"]],
  ["モンスター闘技場", ["§f闘技場の 受付 →「§6モンスター闘技場§f」。1対1の 戦いで どっちが 勝つか §eお金を かける§f",
    "§f能力は その モンスターの まま（同じ レベル）。§e技・特性・性格・スキルは 毎回 ランダム§f なので 強い ほうが 負ける ことも", "§fオッズは その 組み合わせで こっそり 何度か 戦わせて 決める。当たれば かけた お金 × オッズ",
    "§f出場する モンスターは 物語で ふえる: はじめは Eランクまで → C → A → S → SS → §dクリア後は 全ランク 全モンスター§f（神や かくれた 子も）。かけられる 上限も 物語で 上がる",
    "§f戦いは 空の 闘技場で 観戦（晴れから はじまる）。時間切れは かけ金が もどる"]],
  ["ダメージの 上限", ["§fS・M・Lサイズの 攻撃は §e1回 999§f まで（会心でも 弱点でも）。§6Gサイズは 上限なし§f", "§f連続攻撃は 1発ごとに 999まで（5連撃なら 最大 5回分）",
    "§b解放の霧§f: 味方全員の 上限を 3ターン なくす ／ §b覇気の霧§f: 5ターン なくして 物力・武力 +1", "§c封限の霧§f: 敵全員に 3ターン 上限 999を かける（Gや 解放中の 相手にも 効く）",
    "§e限界撃・天衝の一閃§f: その 技だけ 上限を 無視", "§f特性: §6上限知らず§f（いつも なし）・§6ときどき 上限破り§f（30%）・§6背水の 上限破り§f（HP 半分 以下）",
    "§fスキル「§a覇道の書§f」で 覚える（Bランク 以上・G 以外）。§7画面に「［上限］」と 出たら 上限で 止まった しるし"]],
  ["連続攻撃の 減衰", ["§f2回 以上 当たる 攻撃は 1発ごとに 威力が へる: §e1発目 100% → 88% → 77% → 68% → 60%§f …", "§f5連撃・ランダムな 敵に 当たる 技・連撃（ときどき 2回）も 同じ。加速する 技（加速するサンバ など）は べつ",
    "§7技の 説明の「威力」は 減衰を こみに した 合計"]],
  ["ダメージの 上限", ["§fS・M・Lサイズの 攻撃は §e1回 999§f まで（会心でも 弱点でも）。§6Gサイズは 上限なし§f", "§f連続攻撃は 1発ごとに 999まで（5連撃なら 最大 5回分）",
    "§b解放の霧§f: 味方全員の 上限を 3ターン なくす ／ §b覇気の霧§f: 5ターン なくして 物力・武力 +1", "§c封限の霧§f: 敵全員に 3ターン 上限 999を かける（Gや 解放中の 相手にも 効く）",
    "§e限界撃・天衝の一閃§f: その 技だけ 上限を 無視", "§f特性: §6上限知らず§f（いつも なし）・§6ときどき 上限破り§f（30%）・§6背水の 上限破り§f（HP 半分 以下）",
    "§fスキル「§a覇道の書§f」で 覚える（Bランク 以上・G 以外）。§7画面に「［上限］」と 出たら 上限で 止まった しるし"]],
  ["連続攻撃の 減衰", ["§f2回 以上 当たる 攻撃は 1発ごとに 威力が へる: §e1発目 100% → 88% → 77% → 68% → 60%§f …", "§f5連撃・ランダムな 敵に 当たる 技・連撃（ときどき 2回）も 同じ。加速する 技（加速するサンバ など）は べつ",
    "§7技の 説明の「威力」は 減衰を こみに した 合計"]],
  ["おすすめの 育て方", ["§f全900体に、1体ずつ 見た目と 能力から 決めた §aおすすめ§f が ある（図鑑・仲間の くわしい 画面）",
    "§fおすすめの 役割・スキル 3つ・技 4つ・特性 3つ・武器・防具・装飾・性格・作戦・得意な 天候・相方・ひとこと", "§fおすすめの スキルは 生まれつき 覚えて いる。おすすめの 特性は 個体の 特性として 出やすい",
    "§7あくまで めやす。自由に 育てて OK"]],
  ["SS・Xランクの すがた", ["§fSSランクは 系統ごとの 異形の かざりを 2つ まとう（4本腕・とげ・ツノの 冠・まわる 欠片・第三の目・扇の 羽・光る 紋章・金の ふち）",
    "§6王§fは 頭に 王冠（専用の 姿を もつ 王は その 姿の かざり）。§eXランクは 神だけ§f。神ごとに 色の ちがう 大きな 後光（光の すじと 宝玉）と かざり 4つ",
    "§f体も ひとまわり 大きい（SS 1.1倍・X 1.2倍）。4本腕の 追加の 腕も 攻撃・呪文で 動く"]],
  ["王と 神", ["§6王§f（全員 SSランク・名前は「〇王」）: 4つの ちがう 系統の SSランクを 4体配合して 生まれる。2〜3回行動",
    "§e神§f（全員 Xランク）: §6王 1体§f ＋ §fそれぞれ ちがう 系統の SSランク 3体§f の 4体配合で 生まれる（魔神エンマ だけは 仲間に ならない）。3〜4回行動",
    "§f神は 10柱: 天神アマテラス・刀神ガルダバラ・龍神テルグ・機神デュアル・武神クワノトガル・獣神バレサ・邪神ラグロア・妖神ムラマサ・覇神グラトンビラム・魔神エンマ",
    "§fクリア後は ほかに §d神の石板§fの 神 15柱（石板の主の 色ちがい・最後は 厄王の 姿の 厄神ゲゼラ）。2〜3回行動で、配合では 生まれない。石板の 奥で 倒すと まれに 仲間に なる",
    "§4鬼王ギレンドドロス§f: 黒曜石の 体に 4本の 腕、左下の 腕に 禍々しい 金槌、腹に 口を もつ 黒鬼の 王",
    "§b剱王カムトケ§f: 雷を まとう 剣の 王（Mサイズ）。§d厄王ヴァルグレイド§f: 瞬間移動して 2連続で 斬る",
    "§4魔神エンマ§f: 腰の 刀を 抜いて 斬り刻む（攻撃の あいだだけ 抜き身）。何も 語らない。ボスの ときは 3〜4回行動・先手・魔神の闘気・超再生・会心無効"]],
  ["ボスの 強さ", ["§f物語の ボス（石板の 主・地方マスター・星冠王・墓守・カゲツ）の 能力は、§c石板の王 厄王ヴァルグレイド§f（HP9999・MP無限・物力999・武力999・魔力700・吹力800・硬力750・魔硬力700・走力500・2〜3回行動）を いちばん 上に、ボスの レベルに あわせて 決まる。", "§7序盤の ボスは もとの 能力に 近く、物語が 進むほど ヴァルグレイドに 近づく。くわしい 能力・技・弱点は ガイドサイトの「ボス攻略」"]],
  ["よみがえり・かばいへの 対策", ["§f【冥府の鎖】【冥府の大鎖】: 相手を よみがえれなく する（再誕を 消す・死線の執念で 立って いる 子は その場で 倒れる）。", "§f【盾砕きの一撃】【魂断ちの斬撃】・特性【盾くだき】: かばう・挑発を 無視して ねらった 相手に 当たる。特性【鎮魂の気】: 戦いの はじめに 相手 全員を 3ターン よみがえれなく する。", "§7死線の執念で 立って いる 子は 仲間を かばえない。引導（倒した 相手は よみがえれない）も 有効"]],
  ["ボスの おすすめ 手持ち", ["§f手持ちの 上位3体の 平均レベルが ボスの すすめる レベルより 5 以上 高いと、物語の ボス（石板の 主・地方マスター・星冠王・墓守）も 1レベルごとに +2%（最大 +45%）強く なる。", "§7石板の王・カゲツ・エンマは 変わらない。くわしい めやすは ガイドサイトの「ボス攻略」"]],
  ["即死の 技", ["§f冥送の呪（1体 30%）・冥送の大呪（全体 16%）・冥府の大鎌（斬って 12%）で 相手を 一撃で 倒す。", "§7ボス・ハガネ・Gサイズ・特性【冥府の守り】には 効かない。", "§7ムサシ・エンマにも 効かない。Sランクは 0.75倍・SSは 半分・Xは 0.3倍しか 効かない。【冥送破り】で 1.5倍"]],
  ["幻惑", ["§f幻霧の術・幻影の大霧で 敵の 命中を 下げる。物理系・武系・通常攻撃が はずれやすく なる。", "§7特性【澄んだ眼】の 子は 命中が 下がらない"]],
  ["状態異常ブレイク", ["§f特性【ネムリ破り】【ドクケ破り】【シビレ破り】【マドイ破り】【異常ブレイク】は 相手の 耐性を 1段階 弱める（無効→激減→軽減→ふつう→弱点）。", "§7【封じ破り】は 封印を うけつけない 相手も 封じる。特性で 状態異常に ならない 子（〇〇知らず）には 効かない"]],
  // 第65版: 注意書き（はじめに 読もう）。初心者が かんちがい しやすい こと
  ["注意：戦いで 使う 技は 6つまで", ["§eスキルでは 何個も 技を 覚えさせられるが、戦闘で 使える 技は 1体 6つまで！", "§f戦いで 使う 技は §b作戦§f（ガイドブック → 仲間 → 作戦、または 戦闘中の 作戦）→ モンスター → §b戦いで 使う 技（6つ）§f で えらぶ", "§7えらばない ときは「おまかせ」で 強い 技・回復・補助を 自動で 6つ 入れる。戦闘中に 作戦から 入れかえる ことも できる"]],
  ["注意：パーティは 4枠", ["§fパーティは §e4体 ではなく 4枠§f。§bS=1枠・M=2枠・L=3枠・G=4枠", "§7Gサイズの 子は 1体で パーティが いっぱいに なる。大きい 子ほど HPは 高い"]],
  ["注意：配合すると 親は いなくなる", ["§f配合すると §c親の 2体は いなくなり§f、子が 1体 生まれる", "§7大事な 子は 配合の 前に よく 考えよう。子は 親の スキルや プラス値を 引きつぐ"]],
  ["注意：レベルが 上がりにくい とき", ["§f物語の とちゅうは、§e次に 封印する 石板の 主の レベル−4§f より 上は 経験値が 1割しか 入らない", "§7物語を 進めて 石板を 封印すると 上限が 上がる。経験の 道具も 上限を こえた 分は 1割。レベルアップの 道具は 上限で 止まる。エンディング後は 上限なし"]],
  ["注意：負けたとき", ["§f野生や ボスに 負けると §cお金が 半分§f に なり、§e近くの 町の 宿屋§f で 目を さます（仲間は 全回復）", "§7物語の 戦いや 石板の 中で 負けた ときは 宿屋へは 行かない。こうさん・時間切れ・闘技場では お金は へらない"]],
  ["注意：スカウトの コツ", ["§fスカウトは 失敗するたびに 次の 成功率が 上がる。弱らせる・道具を 使うと 成功しやすい", "§7失敗すると 15%で 相手が 怒って、その 戦いでは もう スカウトできない。物語の 石板の 主や 地方マスターは スカウトできない"]],
  ["注意：ハガネ族と 会心", ["§fハガネ族は 守りが とても 固い。§e会心・物理系・武系§f が 効く", "§7会心の 一撃は 守りを 完全に 無視する"]],
  ["注意：作戦は オートの 動き", ["§f作戦（先手必勝・状況分析 など）は §eオートで 戦う ときの 動き方§f。自分で 技を えらぶ ときは 関係ない", "§7技の 好み（◎○×）も オートの ときだけ 使われる"]],
  ["注意：専門の スキル", ["§f強化・弱体・反射・耐性・物理系・武系・特質系・魔法系 だけの §b専門の スキル§f（入門〜皆伝）が ある", "§7覚える モンスターの ほか、モンスターが 落とす スキル書でも 身につく。強い モンスターほど 上の 段の 書を 落とす"]],
  ["注意：技の 効果と NEW!", ["§fスキルの書・スキル振り分け・配合の スキル選びで §b技の くわしい 効果を 見る§f が えらべる", "§f配合の 子の 一覧・おすすめ配合・スカウトの 相手は §a●=仲間に した ことが ある§f／§6NEW!=まだ 仲間に して いない", "§7スキルの書で スキルを 入れかえる ときは、忘れる スキルと 覚える スキルを 見くらべてから 決められる（振った SPは 戻る）", "§f上の 編の スキルの書（熟練編 など）は、下の 編を 持つ 子に 使うと §eその場で 入れかわる§f（振った ポイントは そのまま）", "§7長い 一覧は「さがす・ページを とぶ」で 名前で しぼりこめる"]],
  ["注意：物語の 石板", ["§f物語に 必要な 十五の 石板は §eバッグの「特別な石板」§f に 入る（持ち物には 出ない）", "§7ガイドブック → 道具・装備 → バッグ → 特別な石板 から 使う"]],
  ["戦いで 使う 技（6つ）", ["§f戦いで 使えるのは 1体 6つまで。おぼえた 技の 中から 好きに えらべる。", "§f仲間 → モンスター →「技・特性・詳しく」→「戦いで 使う 技を えらぶ」、または 作戦 → 1体ずつ → 「戦いで 使う 技（6つ）」。戦いの とちゅうの 作戦からも かえられる。", "§f●= えらんだ 技、◆= おまかせで 入る 技。空いた わくは 強い 技で 自動で うまる（「空きは 空けたまま」に すると うめない）。"]],
  ["受け流し・さわると あぶない 体", ["§f【受け流し】: 単体攻撃を 20%で ほかの だれかへ 流す。", "§f【トゲの体】【大トゲの体】: 物理系・武系・通常攻撃の ダメージの 15%・30%を 返す。", "§f【毒の体】【しびれの体】【ねむりの体】【ほのおの体】: さわった 相手を 状態異常に。【瀕死の会心】: HP 25%以下で 会心率 アップ"]],
  ["探索手帳", ["§fガイドブック → 冒険 →「§a探索手帳§f」。地方ごとの 踏破率・秘境・賞金首・うわさ・素材の 交換・展望台へ ワープ", "§f踏破率: 地方を 32ブロックの マスに 分けて、歩いた マスの 割合"]],
  ["秘境と 展望台", ["§f地方ごとに §e展望台§f（高い 石の 塔）と §e古代の 石碑§f と 4つの §d秘境§f が ある", "§d崖の上の巣§f（よじ登り・飛行）・§d沖の 漂流島§f（海・浮遊）・§d地底の 空洞§f（地面の 20ブロック 下・掘り進み）・§d空の 浮島§f（飛行）。どれも 宝箱が ある",
    "§f展望台の てっぺんに 登ると その 地方の 秘境が 探索手帳に のり、コンパスで 案内できる。登った 展望台へは ワープできる", "§f踏破率 70%・展望台・石碑・秘境 4つ で その 地方を §a踏破§f。ごほうびと 称号（水が ない ため 島が ない 地方 などは その 分を のぞく）", "§f人の 建物が ある 場所には 秘境・展望台は 作られない"]],
  ["秘湯と 釣りの 名所", ["§f雪山・火山・結晶の 地方に §b秘湯§f。つかると 仲間の HPと MPが 全回復（10分ごと）", "§f§b釣りの 名所§f（ランタンの 柱）の 20m 以内で 釣ると 1段 上の 竿と 同じ"]],
  ["採集と 化石", ["§f歩いて いると 近くに §d光る 結晶§f（採集ポイント）が 出る。こわすと その 地方の 素材（11種）。4分で 消える", "§fルインズ荒野・サンドリア砂漠で 砂・砂岩・テラコッタ などを 掘ると、まれに §6化石の かけら§f（1日 12こまで）。地下の 深層岩でも",
    "§f化石の かけら ×8 で 古代の 化石。使うと 古代の 竜系・物質系の モンスターが よみがえる", "§f素材は 探索手帳の「素材の 交換」で なぞの 地図・槌・昇格の砥石 などに かえる"]],
  ["環境の レアと 異常気象", ["§f場所・時間・天気が そろうと 出る §b環境の レア§f が 10種（探索手帳で 条件が 見られる）。倒すか スカウトで 記録", "§f地方ごとに ときどき §e異常気象§f（吹雪・砂嵐・噴火の 熱波・濃霧 など 5分）。その 地方の 戦いの 天候に なり、環境の レアと 色違いが 出やすい"]],
  ["賞金首と 迷子", ["§c賞金首§f: 地方ごとに 毎日 かわる 強い 野生。その 地方を 歩くと 大きな 足あとの けむりで 方向が わかる。倒すと 賞金（1日 1回ずつ）。スカウトは できない", "§b迷子の モンスター§f: なぐると 戦わずに 話せる。仲間に できる。§7ときどき 出る「2人で ないと 心を ひらかない 迷子」は、もう 1人の プレイヤーが 16m 以内に いると 仲間に できる"]],
  ["流れ星・光の柱・なぞの 地図", ["§f夜は §e流れ星§f、雨上がりや 昼には §a光の柱§f が 立つ ことが ある。コンパスが 案内。着くと 宝箱（5分で 消える）", "§fなぞの 地図: 宝の 場所が「〇〇の 町から 北東へ 約300m」の ように ことばで 出る。40m まで 近づくと コンパスが 反応"]],
  ["探索ランクと ライドの 熟練度", ["§f探索で ポイントが たまると §a探索ランク§f（1〜8）が 上がり、特典が つく（探索手帳で 見られる）", "§fライドで 走った きょりで §bライドの 熟練度§f（5段・1段ごとに 速さ +4%）"]],
  ["冒険者協会の 依頼", ["§f城下町の §e冒険者協会の 受付§f・町の §e酒場の マスター§f に 話しかけると 依頼掲示板。掲示板は 毎日 かわる（協会ごと）", "§f級は F→E→D→C→B→A→S→SS→X。受けられるのは 自分の ランクの 1つ上まで（物語の 進み具合でも 上限が ある）", "§f種類: 討伐（その 系統を たおす）・納品（素材を わたす）・披露（条件の 仲間を 見せる）・調査（地図の 座標へ 行く）・手配（座標へ 行くと 手配モンスターが 出る。仲間に できない）", "§f受けられる 依頼は 1つ。報告は 全部の 協会で 1日 6つまで。あきらめた 依頼は その日 もう 受けられない", "§fほうび: お金・冒険者ポイント・級に 合った 種／進化石・石板・タマゴ など。ポイント 30・90・200・380・650・1000・1500・2200 で ランクが 上がる"]],
  ["キャンプ", ["§fガイドブック → 冒険 →「§6キャンプ§f」。その場に テントを はって、パーティと スタンバイの 子が 最大 8匹（軽量モードは 4匹）出る", "§fボールを 投げると みんなで 取りあう。仲間を たたくと なでる（10秒に 1回 きずな +1）", "§fテントを たたくと メニュー: §e料理を つくる§f（お金を はらう・みんなで 食べる・きずな +3（30分に 1回）・次の 戦い 3回 強く なる）", "§f32ブロック はなれる・戦いに なる・ちがう 世界へ 行く と 自動で 片づく。地上だけ・石板や 遊び場の 中では はれない"]],
  ["町の 広場", ["§fガイドブック → 冒険 →「§6町の 広場§f」（町の 中だけ）。依頼掲示板・屋台・くじ・宝くじ・花屋・パン屋・両替屋・占い・道場・吟遊詩人・郵便・運び屋・新聞・子どもの 頼み・お土産・名物・銭湯・レストラン・夜市・写真館・博物館・像・船旅 など", "§f町に 近づくと 旗・花壇・噴水の かざり・町の シンボルが 1回だけ 建つ（あいて いる 所だけ）。季節で かざりが かわる"]],
  ["町の 発展度と 人気度", ["§f発展度（1〜5）: 依頼・花を 植える・子どもの 頼み・買い物で 上がる。2で 銭湯、3で 夜市と レストラン、4で 写真館と 博物館、5で 限定タマゴと 名誉市民", "§f人気度: その 町で 依頼を こなすと 上がる。10ごとに 値引き 1%（最大 15%）。名誉市民は さらに 5%・お祭りの 町は 20%引き"]],
  ["お祭りと 町の できごと", ["§f週に 1回、どこかの 町が §6お祭り§f（さらに 20%引き・人気度や 名誉市民の 値引きと 合わせて 最大 40%・夜に 花火）", "§f朝・昼・夕に 時報の 鐘・広場に 入ると 音楽・晴れた 昼は 噴水に 虹・夜は 街灯が 灯る", "§f地方の 守り手に 勝つと その 地方の 町で お祝いと 記念碑"]],
  ["きずな（なつき度）", ["§fガイドブック → 冒険 → 探索手帳 →「§dきずな§f」。連れ歩き・なでる（1日 1回）・ごはん・いっしょに 戦う で なつき度が 上がる", "§f段階: 知り合い → なかよし（80）→ 相棒（250）→ 親友（600）→ 家族（900）", "§fなかよし 以上: 戦いで 倒れそうな とき 10〜30% 踏みとどまる（1回の 戦いで 1度だけ）。親友: 回避 +1。家族: 命中 +1。パーティ（2体 以上）の 全員が 相棒 以上で 硬力 +1。好きな 天気の 日は 走力 +1", "§7戦いの はじめの 強化（料理・朝ごはん・湯上がり・きずな など）は §e野生との 戦いだけ§7。合わせて 1つの 能力 +1 まで（マスター・ボス戦では 使わず、次の 野生戦まで のこる）",
    "§f1体ごとに 好物・苦手・好きな 場所・好きな 天気・誕生石が ある。仲間に なった 記念日には おやつの プレゼント", "§f配合などで いなく なった 子は「思い出の 仲間」に のこり、新しく 生まれた 子が きずなの 半分を 受けつぐ"]],
  ["料理と 畑", ["§f探索手帳 →「料理と 畑」: 地方の 素材と 町の パンで 料理（次の 野生との 戦い 3回、能力 +1段階）", "§f畑: 花の たね（町の 花屋）を まくと 30分後に 能力の 実", "§fおやつ: どんぐり ×4 で 作る。仲間の なつき度 +60"]],
  ["探索の 新しい 場所", ["§f新しい 場所: 地底湖・割れ目の 隠し部屋・崩れる 橋・霧の 迷路・沈没船・雲の 道・失われた 村・滝の うら・古い 井戸・溶岩洞・氷の 洞くつ・竜の 背骨・空への 階段・ことわざの 碑・蜃気楼・渦潮・夜光虫の 浜・キノコの 輪・木の 上の 巣・野生の 巣", "§f伝説の 秘宝 7つ（地方 1〜7）を 集めると 天空郷に 最後の 秘境。古い 地図の 切れ端 4つで 隠された 島",
    "§fできごと: 虹・雷の 結晶・隕石・風船・鬼火・灯籠流し・日食・週1の 流星群・雪崩・群れ・縄張り争い・眠って いる 子（スカウト +15%）・変わり種", "§f挑戦: レース・宝探し競争・地方の 名人・守り神（踏破した 地方）。フィールドで 行商人・旅の マスター・盗賊に 会う ことも"]],
  ["探索の 実績と 記録", ["§f探索手帳 →「探索の 実績」（30こ）・「旅の 記録」（歩いた きょり・最高地点・魚の 大きさ・最速踏破・踏破メダルと 歩いた マスの 地図・図鑑メモ・日記・スクラップ・名産図鑑・秘境の 旗）", "§f便利な 道具: レーダー（常時表示 あり）・キャンプ・ワープ石・応援旗・天気予報と 月・交換所"]],
  ["おすすめ配合", ["§f配合の 画面の §6§l【おすすめ配合】§r§fを 押すと、手持ちの 上位 36体から いちばん ランクが 高く 強い 子が 生まれる 組み合わせを 上から 6つ 出す", "§f親より 弱い 子しか 生まれない 組は 出ない。親の 順番（1体目・2体目）も 考えて ある", "§d【何か特別な気配がする…！】§fと 出たら、特別な 配合（ロマン配合・奇跡の配合など）で しか 生まれない 子"]],
  ["ロマン配合と 奇跡の配合", ["§dロマン配合§f: 親たちが 決まった スキルを 2つ 持っていると、配合で しか 生まれない スキル（100系統）が 子に つく。100まで 振ると 特性も",
    "§b奇跡の配合§f: 決まった 2体を 配合すると、ふつうは 生まれない モンスターが 生まれる（候補に「★ロマン」）",
    "§d特別配合§f: ある モンスターに 決まった 系統・ランク 以上の 仲間を あわせる。例: §5厄龍オロチ§f ＋ §fSSランクの どの 系統でも§f → §e光竜ギドラ",
    "§74体配合: 王・神は 4体を 1度に 配合して 生まれる"]],
];
// v2.9: 用語説明を 分類ごとに（見つけやすく）
{ const seen = new Set(); for (let i = GLOSSARY.length - 1; i >= 0; i--) { const k = GLOSSARY[i][0]; if (seen.has(k)) GLOSSARY.splice(i, 1); else seen.add(k); } }   // v2.9.12: 同じ 項目が 2回 出ない ように（あとの ほうを のこす）
const GLOSS_CAT = [
  ["§e§l注意書き（はじめに 読もう）", "i_help", ["注意：裏（スタンバイ）", "注意：戦いで 使う 技は 6つまで", "注意：パーティは 4枠", "注意：配合すると 親は いなくなる", "注意：レベルが 上がりにくい とき", "注意：負けたとき", "注意：スカウトの コツ", "注意：ハガネ族と 会心", "注意：作戦は オートの 動き", "注意：専門の スキル", "注意：技の 効果と NEW!", "注意：物語の 石板"]],
  ["§6§l町と きずな", "i_shop", ["町の 広場", "町の 発展度と 人気度", "お祭りと 町の できごと", "きずな（なつき度）", "料理と 畑", "探索の 新しい 場所", "探索の 実績と 記録"]],
  ["§a§l探索", "i_run", ["探索手帳", "秘境と 展望台", "秘湯と 釣りの 名所", "採集と 化石", "環境の レアと 異常気象", "賞金首と 迷子", "流れ星・光の柱・なぞの 地図", "探索ランクと ライドの 熟練度"]],
  ["§6§lクリア後に できること", "i_star", ["クリア後：滅びた世界（追加ストーリー）", "クリア後：地方の 王", "クリア後：神の石板と 神々", "クリア後：カゲツの ごほうび", "クリア後：タマゴの 特別な 秘伝", "クリア後：+99を こえた 子の 継承", "レイドボスと 王系"]],
  ["§c戦いの しくみ", "i_fight", ["裏（スタンバイ）", "戦闘の 画面", "ダメージの 計算", "ハンシャと マネマネ", "デメリットの ある 技", "ダメージの 上限", "連続攻撃の 減衰", "攻撃の 種類", "技の 種類", "先制度", "命中・回避・急所ランク", "天候（9種）", "属性（10種）", "耐性", "状態異常（10種）", "行動順と 封印", "能力の 段階（上昇・下降）", "攻撃の 種類の 特質", "戦闘の 表示", "戦いの ドーム", "スカウト", "起き上がる 仲間", "こうさん・マルチ"]],
  ["§bモンスター", "i_party", ["おすすめの 育て方", "能力（ステータス）", "系統（10）と ボーナス", "王と 神", "ロマン配合と 奇跡の配合", "ランク・サイズ・枠", "特性と 行動回数", "スキルの 段階", "進化・覚醒", "SS・Xランクの すがた", "色がえ", "相棒の 見た目と 武器"]],
  ["§6装備と 道具", "i_item", ["装備", "武器 16種", "攻撃属性", "装備の 特殊効果（F〜X）", "クラフト素材", "持ち物", "落とし物", "宝箱の レア度（10段階）", "石板の 道具"]],
  ["§a冒険と 物語", "i_run", ["物語の 冒険（メインクエスト）", "物語の 章と あらすじ", "地方の 景色", "石板の 守り手（地方マスター）", "魔神編（クリア後）", "遺跡と 星の かけら", "物語の 場所と 洞くつ", "ライドの 種類", "モンスター闘技場", "地方の 関所", "だいじなもの", "マスターと ライバル", "タマゴを まとめて かえす", "道具の 角の 印", "負けイベント", "海・洞くつ・ネザー・エンド", "石板と クリア後", "町の 近くの 神殿"]],
  ["§dやりこみ・対戦", "i_skill", ["闘技場の 結果スキップ", "やりこみ：挑戦", "やりこみ：対戦", "やりこみ：育成と 収集", "やりこみ：施設と 称号", "対戦の かけひき", "組み合わせの 例"]],
];
async function glossaryMenu(p) {
  const slv = spLv(p), sok = slv >= 2;
  const all = GLOSSARY.filter(([t, L]) => (slv >= 1 || !/^クリア後：/.test(t)) && (sok || (!spTest(t, slv) && L.some((x) => !spTest(x, slv))))).map(([t]) => t), used = new Set(GLOSS_CAT.flatMap((c) => c[2]));
  const cats = [...GLOSS_CAT.map(([n, ic, l]) => [n, ic, l.filter((t) => all.includes(t))]), ["§7その他", "i_help", all.filter((t) => !used.has(t))]].filter((c) => c[2].length);
  for (;;) {
    const c = await choose(p, "用語説明", "§7分類を 選んでください", [...cats.map(([n, ic, l]) => B(`§l${n}\n§r§8${l.length}こう`, ICON(ic))), B("§7戻る", ICON("i_back"))]);
    if (c < 0 || c >= cats.length) return;
    for (;;) {
      const L = cats[c][2];
      const s = await choose(p, `用語説明 ${cats[c][0].replace(/§./g, "")}`, "§7知りたい ことを 選んでください", [...L.map((t) => B(`§l${t}`, ICON("i_help"))), B("§7戻る", ICON("i_back"))]);
      if (s < 0 || s >= L.length) break;
      const g = GLOSSARY.find((x) => x[0] === L[s]);
      await notice(p, g[0], [`§l§e${g[0]}`, LINE, ...spoilCut(p, g[1], sok).map((x) => `§8・ §r${x}`), ...(sok || spoilCut(p, g[1], sok).length === g[1].length ? [] : ["§7（物語の ネタバレに なる 部分は 物語を 見届けると 表示）"])].join("\n\n"));
    }
  }
}

// ---------- 石板工房 ----------
const SLAB_COST = [3000, 12000, 40000, 150000];
const SLAB_MATN = [5, 4, 4, 6];
const SLAB_NEED = [0, 0, 3, 10];
export async function slabShop(p, d) {
  for (;;) {
    const wins = (d.stats && d.stats.masters) || 0;
    const t = await choose(p, "石板工房", [`§fお金: ${gold(d.gold)}  §7マスター 勝利 ${wins}かい`, "§7石板を かかげると レアな ボスが 現れる。マルチで 一緒に 戦えて、スカウトも しやすい。", "§7系統を 選ぶと 少し たかくなる。素材は その 系統の もの。"].join("\n"),
      [...SLAB_NAME.map((n, i) => { const lock = !slabTierOk(d, i); return B(`${lock || wins < SLAB_NEED[i] ? "§8× " : "§l"}${n}  §e${SLAB_COST[i]}\n§7${lock ? "物語を 見届けると 作れる" : `${["B", "A", "S", "SS"][i]}ランク${SLAB_NEED[i] ? `（マスター${SLAB_NEED[i]}しょう〜）` : ""}`}`, ITEM_ICON(`sl${i}`)); }), B(`${endingDone(d) ? "§6§l" : "§8× "}覇王の石板  §e500000\n§7王たちと 戦う（クリア後）`, ITEM_ICON("sx_king")), B(`${endingDone(d) ? "§d§l" : "§8× "}神域の石板  §e2000000\n§7神々と 戦う（クリア後）`, ITEM_ICON("sx_god")), B("§7戻る", ICON("i_back"))]);
    if (t === 4 || t === 5) {
      const id = t === 4 ? "sx_king" : "sx_god", cost = t === 4 ? 500000 : 2000000;
      if (!endingDone(d)) { await notice(p, "石板工房", "§7この 石板の 型は まだ 眠っている……（エンディング後）"); continue; }
      if (d.gold < cost) { await notice(p, "石板工房", `§cお金が たりない（${gold(cost)}）`); continue; }
      if (!(await confirm(p, ITEMS[id].name, `${itemDesc(id)}\n\n${gold(cost)} で 作りますか？`, "作る", "やめる"))) continue;
      d.gold -= cost; save(p, d); giveItem(p, `mrpg:${id}`); sound(p, "random.anvil_use");
      await notice(p, "石板工房", `§6${ITEMS[id].name}が できあがった！`); continue;
    }
    if (t < 0 || t > 3) return;
    if (!slabTierOk(d, t)) { await notice(p, "石板工房", `§7${SLAB_NAME[t]}の 型は まだ 眠っている……\n§fエンディング（星冠王 ゼファードと 王冠の石板）の あとで 作れるように なる。\n§7それまでは ぎんの石板まで 作れる。`); continue; }
    if (wins < SLAB_NEED[t]) { await notice(p, "石板工房", `§c${SLAB_NAME[t]}は モンスターマスターに ${SLAB_NEED[t]}かい かつと 作れるように なる。\n§7フィールドで マスターを さがそう！`); continue; }
    const fams = FAMILIES.filter((f) => f.id !== "king" && f.id !== "god");
    const f = await paged(p, SLAB_NAME[t], "§7どの 系統の ボスに する？", [B("§lおまかせ §7（素材は なんでも）", ICON("i_skill")), ...fams.map((x) => B(`${FAM_COLOR[x.id] || ""}${x.name}`, ITEM_ICON(`sl${t}_${x.id}`) || ICON("i_zukan")))]);
    if (f < 0) continue;
    const fam = f === 0 ? null : fams[f - 1].id;
    const cost = Math.floor(SLAB_COST[t] * (fam ? 1.2 : 1));
    const mt = Math.min(t, 2), need = SLAB_MATN[t];
    // 素材: 系統指定なら その系統、おまかせなら もっている いちばん おおい系統
    let matId = fam ? `mat_${fam}${mt}` : null;
    if (!matId) { const have = fams.map((x) => [`mat_${x.id}${mt}`, countItem(p, `mrpg:mat_${x.id}${mt}`)]).sort((a, b) => b[1] - a[1]); matId = have[0][0]; }
    const id = fam ? `sl${t}_${fam}` : `sl${t}`;
    if (!ITEMS[id] || !ITEMS[matId]) { await notice(p, "石板工房", "§cこの 石板は 作れません。"); continue; }
    const hasM = countItem(p, `mrpg:${matId}`);
    const okG = d.gold >= cost, okM = hasM >= need;
    if (!(await confirm(p, ITEMS[id].name, [`§l§d${ITEMS[id].name}`, `§f${itemDesc(id)}`, LINE, `${okG ? "§a" : "§c"}お金 ${cost}  §7（もっている ${d.gold}）`, `${okM ? "§a" : "§c"}${ITEMS[matId].name} ×${need}  §7（もっている ${hasM}）`].join("\n"), okG && okM ? "作る" : "§8たりない", "戻る")) || !okG || !okM) continue;
    if (d.gold < cost || !takeItem(p, `mrpg:${matId}`, need)) continue;
    d.gold -= cost; save(p, d);
    giveItem(p, `mrpg:${id}`);
    sound(p, "random.anvil_use"); particle(p, "minecraft:totem_particle", 1.2);
    await notice(p, "石板工房", `§d${ITEMS[id].name}が できあがった！\n§7道具から 使うと ボスが 現れる。`);
  }
}

function rankText() {
  const r = Object.entries(loadRank()).sort((a, b) => b[1].w - a[1].w || a[1].l - b[1].l).slice(0, 10);
  if (!r.length) return "§7まだ 対戦の きろくが ありません。";
  return ["§l§e対戦 ランキング", LINE, ...r.map(([n, v], i) => `${i < 3 ? ["§6", "§f", "§c"][i] : "§7"}${i + 1}い §f${n}  §a${v.w}しょう §c${v.l}はい`)].join("\n");
}

const SHARED_MAX = 100;
async function sharedMenu(p, d) {
  for (;;) {
    const list = loadShared();
    const s = await choose(p, "共有 預かり所", `§fワールドの みんなで 使える 預かり所です。（${list.length}/${SHARED_MAX}）\n§7誰でも ひきだせます。`, [B("§lあずける", ICON("i_box")), B("ひきだす", ICON("i_party")), B("§7戻る", ICON("i_back"))]);
    if (s === 0) {
      if (list.length >= SHARED_MAX) { await notice(p, "あずける", "いっぱいです。"); continue; }
      const m = await pickMon(p, d, "何を あずける？", "§7装備は はずれて 戻ってきます");
      if (!m) continue;
      if (d.party.length === 1 && d.party[0] === m) { await notice(p, "あずける", "最後の 仲間は あずけられません。"); continue; }
      if (SPECIES[m.sp]?.deity !== undefined) { await notice(p, "あずける", "§c神は 共有 預かり所に あずけられません。"); continue; }   /* 第69版 */
      if (m.sp === "musashi" || m.sp === "enma") { await notice(p, "あずける", `§c${m.sp === "enma" ? "エンマ" : "ムサシ"}は 共有 預かり所に あずけられません。`); continue; }   // v2.9.14
      const cur = loadShared();   // v2.9.9: 選んで いる あいだに ほかの 人が 出し入れ した ぶんを 消さない
      if (cur.length >= SHARED_MAX) { await notice(p, "あずける", "いっぱいです。"); continue; }
      if (!allMons(d).includes(m)) continue;
      removeMon(p, d, m); save(p, d);
      m.eq = { w: null, a: null, x: null }; m.eqr = {}; m.from = p.name; { const st = calcStats(m); m.hp = Math.min(m.hp, st.hp); m.mp = Math.min(m.mp, st.mp); }   // v2.9.12: 装備を 外したら HPも 上限まで
      cur.push(m); saveShared(cur); markXfer(p);
      await notice(p, "あずける", `${m.nm}を あずけた。`);
    } else if (s === 1) {
      if (!list.length) { await notice(p, "ひきだす", "誰も あずけていません。"); continue; }
      if (d.box.length >= BOX_MAX) { await notice(p, "ひきだす", "預かり所が いっぱいです。"); continue; }
      const sel = await paged(p, "ひきだす", "§7ひきだす モンスターを 選んでください", list.map((m) => B(monLabel2(m, `§7${m.from || "?"}`), MON_ICON(m.sp))));
      if (sel < 0) continue;
      const fresh = loadShared();
      const i = fresh.findIndex((x) => x.id === list[sel].id);
      if (i < 0) { await notice(p, "ひきだす", "ほかの ひとが さきに ひきだしました。"); continue; }
      if (SPECIES[fresh[i].sp]?.deity !== undefined && fresh[i].from !== p.name) { await notice(p, "ひきだす", "§c神は あずけた 本人しか ひきだせません。"); continue; }   /* 第69版 */
      const [m] = fresh.splice(i, 1); saveShared(fresh);
      delete m.from;
      try { migrate(m); } catch {}   // 第69版: 古い 形の 子も 直す
      addMon(d, m); mark(d.own, m.sp); mark(d.seen, m.sp); save(p, d);
      await notice(p, "ひきだす", `${m.nm}が 仲間に なった！`);
    } else return;
  }
}

// ---------- 図鑑（モンスター・特性・道具・装備・配合メモ）----------
function noteItems(p, d) {
  d.gi = d.gi || [];
  for (const id of Object.keys(rpgItems(p))) if (!d.gi.includes(id)) d.gi.push(id);
  for (const m of allMons(d)) for (const k of ["w", "a", "x"]) if (m.eq && m.eq[k] && !d.gi.includes(m.eq[k])) d.gi.push(m.eq[k]);
  d.hts = d.hts || [];
  for (const m of allMons(d)) if (m.ht && !d.hts.includes(m.sp)) d.hts.push(m.sp);
}
const ZK_ITEM = [["道具", (it) => !["weapon", "armor", "acc", "material", "egg"].includes(it.kind), "i_item"], ["武器", (it) => it.kind === "weapon", "i_fight"],
  ["防具", (it) => it.kind === "armor", "i_guard"], ["アクセサリー", (it) => it.kind === "acc", "i_equip"], ["タマゴ", (it) => it.kind === "egg", "i_egg"], ["素材", (it) => it.kind === "material", "i_equip"]];
function whereGet(id) {
  const it = ITEMS[id], w = [];
  if (it.price > 0) w.push("おみせ");
  if (RECIPES[id]) w.push("クラフト");
  if (it.kind === "material") w.push("モンスターが おとす");
  if (!w.length) w.push("宝箱・ボス・特別な 報酬");
  return w.join("・");
}
function recipeText(sid) {
  const sp = SPECIES[sid];
  if (sp.special4) return `§d4体配合§f: ${sp.special4.map((x) => SPECIES[x].name).join(" ＋ ")}`;
  if (sp.special) return `§d特別配合§f: ${SPECIES[sp.special[0]].name} ＋ ${(sp.special[1] === "*" ? "どの 系統でも" : FAMILIES.find((f) => f.id === sp.special[1])?.name || "")}（${["F", "E", "D", "C", "B", "A", "S", "SS", "X"][sp.special[2] ?? 4]}ランク 以上）`;
  return "";
}
async function zukanMenu(p, d) {
  noteItems(p, d); save(p, d);
  for (;;) {
    const nItem = Object.keys(ITEMS).length, gotN = (d.gi || []).filter((x) => ITEMS[x]).length;
    const nTr = Object.keys(TRAITS).filter((t) => !TRAITS[t].rare).length;
    const s0 = await choose(p, "図鑑", [`§fモンスター §e${ownN(d)}§7/${ORDER.length}  ${meter(ownN(d), ORDER.length, 10)}`, `§f道具・装備 §e${gotN}§7/${nItem}  ${meter(gotN, nItem, 10)}`, `§6固有特性 §e${(d.hts || []).length}§7/${ORDER.length}`, `§f配合メモ §e${(d.hints || []).length}`].join("\n"),
      [B("§e§lキーワード検索\n§8技・特性・スキル・道具から", ICON("i_scout")), B("§lモンスター", ICON("i_zukan")), B("特性\n§8ふつうの 特性・§6固有特性", ICON("i_skill")), B(`技 §8${Object.keys(MOVES).length}種\n§8攻撃・補助・反射・回復 など`, ICON("i_spell")), B(`スキル §8${Object.keys(SKILLS).length}しゅ\n§8覚える 技と 能力`, ICON("i_skill")), ...ZK_ITEM.map(([n, , ic]) => B(n, ICON(ic))), B("§d配合メモ\n§8図書館・物知りで 知った配合", ICON("i_fuse")), B(`§b系統 配合表 §8${mixCount(d)}/${MIX_TOTAL}\n§8系統 × ランク帯で 生まれる 系統`, ICON("i_fuse")), B(`§d奇跡の配合 §8${(d.rm || []).length}/${ROMAN.length}\n§8低ランクから 高ランクが 生まれる`, ICON("i_fuse")), B("§6能力ランキング\n§8能力ごと・総合", ICON("i_star")), B("§7戻る", ICON("i_back"))]);
    if (s0 === 0) { await wordSearch(p, d); continue; }
    const s = s0 - 1;
    if (s === 0) await zukanMon(p, d);
    else if (s === 1) await zukanTraits(p, d);
    else if (s === 2) await zukanMoves(p, d);
    else if (s === 3) await zukanSkills(p, d);
    else if (s >= 4 && s < 4 + ZK_ITEM.length) await zukanItems(p, d, ZK_ITEM[s - 4]);
    else if (s === 4 + ZK_ITEM.length) await zukanHints(p, d);
    else if (s === 5 + ZK_ITEM.length) await zukanMix(p, d);
    else if (s === 6 + ZK_ITEM.length) await zukanRoman(p, d);
    else if (s === 7 + ZK_ITEM.length) await rankingMenu(p, d);
    else return;
  }
}
const GEAR_HELP = ["§e装備の 厳選", "§7手に入れた 時に レア度が 決まる（F〜X）。同じ 装備でも 能力に はばが あり、高い レア度ほど 理論値に 近く パッシブも 多く・強い。",
  ...RAR.map((r, i) => `${RAR_COL[i]}${r}（${RAR_NAME[i]}）§7 能力×${FACT_LO(i).toFixed(2)}〜${FACT_HI(i).toFixed(2)} パッシブ${NPASS[i]}${i < 3 ? " デメリット あり" : ""}`),
  "§7出やすさ: 店 F〜B ／ 拾う・宝箱 F〜X ／ クラフト E〜X（良い）／ ボス D〜X", "§e物語の 進みで 出る レア度に 上限§7（はじめは D まで → 進むほど 解放・エンディングで SS・伝説の 先で X）",
  "§b特殊効果§7: 物理反射・魔法反射・武系反射・息反射・HP吸収・MP吸収・会心ダメージ・先制・連撃・守り貫通・全ダメージ軽減・MP消費なし・回復量 など。レア度が 高いほど 効果が 大きい（例: 物理反射 F 3% → X 25%）", "§7鍛冶の 槌・砥石で 打ち直せる"].join("\n");
async function zukanItems(p, d, [name, fn]) {
  let ids = Object.keys(ITEMS).filter((id) => fn(ITEMS[id])).sort((a, b) => (ITEMS[a].grade ?? -1) - (ITEMS[b].grade ?? -1) || (ITEMS[a].price || 0) - (ITEMS[b].price || 0));
  const got = new Set(d.gi || []);
  const all = ids;
  if (ids.length && isGear(ids[ids.length - 1])) {
    const key = (id) => ITEMS[id].kind === "weapon" ? ITEMS[id].wtype : ITEMS[id].atype;
    const nm = (k) => WTYPES[k] || ATYPES[k] || ACCT[k] || k;
    const grs = [...new Set(all.map(key))];
    const gsel = await choose(p, `図鑑：${name}`, `§7全部で ${all.length}種。種類を 選んでください\n${GEAR_HELP}`, [...grs.map((g) => B(`§l${nm(g)} §8${all.filter((id) => key(id) === g).length}種`, ICON("i_equip"))), B("§7戻る", ICON("i_back"))]);
    if (gsel < 0 || gsel >= grs.length) return;
    ids = all.filter((id) => key(id) === grs[gsel]).sort((a, b) => (ITEMS[a].wt ?? ITEMS[a].tier ?? 0) - (ITEMS[b].wt ?? ITEMS[b].tier ?? 0) || ELS.indexOf(ITEMS[a].el) - ELS.indexOf(ITEMS[b].el));
  }
  const slvI = spLv(p), hidI = (id) => !got.has(id) && ((ITEMS[id].kind === "dslab" && slvI < 1) || spTest(ITEMS[id].name + itemDesc(id), slvI) || (ITEMS[id].kind === "key" && slvI < 2));   // v3.0: まだの だいじなものは ？？？   // v2.9.12: まだの ひみつの 品は ？？？
  for (;;) {
    const k = await paged(p, `図鑑：${name}`, `§7○ 手に入れた  ・ まだ  §f${ids.filter((x) => got.has(x)).length}/${ids.length}`,
      ids.map((id) => hidI(id) ? B("§8・ ？？？\n§7まだ ひみつ", ICON("i_help")) : B(`${got.has(id) ? "§2○ §f" : "§8・ "}${ITEMS[id].name}\n§7${itemDesc(id).replace(/§./g, "").slice(0, 30)}`, ITEM_ICON(id))), 8);
    if (k < 0) return;
    const id = ids[k];
    if (hidI(id)) { await notice(p, "？？？", "§7物語を 進めると わかる 品。"); continue; }
    await notice(p, ITEMS[id].name, [`§l§e${ITEMS[id].name}§r ${got.has(id) ? "§2○ 手に入れた" : "§8まだ 手に入れていない"}`, LINE, `§f${itemDesc(id)}`, `§7値段: ${ITEMS[id].price ? ITEMS[id].price + " " + CURRENCY : "うっていない"}`, `§7手に入る 場所: ${whereGet(id)}`, ...(craftInfo(id) ? [LINE, craftInfo(id)] : []), ...(isGear(id) ? [LINE, "§7能力は 手に入れた 時の レア度で 変わる（理論値は SS の 最大）"] : [])].join("\n"));
  }
}
async function zukanTraits(p, d) {
  for (;;) {
    const cats = TR_CATS.map(([n, re]) => [n, Object.keys(TRAITS).filter((t) => !TRAITS[t].rare && re.test(t))]);
    const s0 = await paged(p, "図鑑：特性", "§7分類を 選んでください", [B("§6固有特性（金色）", ICON("i_skill")), ...cats.map(([n, l]) => B(`${n} §8${l.length}`, ICON("i_skill")))], 8);
    if (s0 < 0) return;
    const s = s0 === 0 ? 1 : 0;
    if (s === 0) {
      const ids = cats[s0 - 1][1];
      const k = await paged(p, "ふつうの 特性", `§7全部で ${ids.length}しゅ`, ids.map((t) => B(`${TRAITS[t].name}\n§7${TRAITS[t].desc.slice(0, 28)}`, ICON("i_skill"))), 8);
      if (k >= 0) { const t = ids[k]; const who = ORDER.filter((x) => (SPECIES[x].traits || []).includes(t) && d.own.includes(SPECIES[x].idx)).map((x) => SPECIES[x].name); await notice(p, TRAITS[t].name, `§l§e${TRAITS[t].name}§r\n§f${TRAITS[t].desc}\n${LINE}\n§7もっている 仲間: ${who.slice(0, 12).join("・") || "まだ いない"}`); }
    } else if (s === 1) {
      const seen = d.hts || [];
      const list = ORDER.filter((x) => d.own.includes(SPECIES[x].idx));
      const k = await paged(p, "固有特性", `§6固有特性は しゅごとに 1つ。もっている 個体は まれ。\n§7◆ 育てた ことが ある  ？ まだ  §f${seen.length}/${ORDER.length}`,
        list.map((x) => { const h = TRAITS[SPECIES[x].ht]; return B(seen.includes(x) ? `§6◆ ${h.name}\n§7${SPECIES[x].name}` : `§8？？？\n§7${SPECIES[x].name}`, MON_ICON(x)); }), 8);
      if (k >= 0) { const x = list[k], h = TRAITS[SPECIES[x].ht]; await notice(p, "固有特性", seen.includes(x) ? `§6§l${h.name}§r\n§6${h.desc}\n\n§7${SPECIES[x].name}の 固有特性` : `§8？？？\n\n§7${SPECIES[x].name}の 固有特性は まだ 分からない。\n固有特性を もつ こを 手に入れよう（野生・ボス・石板・配合・夢のしずく）`); }
    } else return;
  }
}
const isA = (m) => m.kind === "attack" && !m.sig && !m.boss;
// v2.5.3: 特性の 分類（図鑑）
const TR_CATS = [["すべての 特性", /./], ["§d対戦の かけひき§r（執念・再誕・霧散・引導 など）", /^(undying|autodispel|startraise|lastrev|nodispel|critguard|gcounter|mindbar|mindbar2|finisher|finisher2|healcut|counter|revive|sturdy|taunt|guardian|grudge|rage)$/],
  ["§aときどき 発動", /^(toki|tdn_|tsl_|trf_|tench_)/], ["§eいきなり（戦いの はじめ）", /^(ik_|ik2_|revstart|sealstart_|startraise|startall|startregen|startcharge|srf_|sgd_)/],
  ["§cキラー（系統 特攻）", /^kil2?_/], ["§bガード（系統 軽減）", /^fg/], ["§5ブレイク（耐性を 破る）", /^brk/], ["§9吸収・無効の 体", /^(abs_|nul_)/], ["§d残響（もう一度 当たる）", /^echo_/],
  ["§6条件で 威力アップ", /^(bt_|bt2_|reckstance|careful|gambler|lucky|pinch|bloodlust|heavyhit)/], ["§a受けると・倒すと", /^(hb_|kb_|killheal|allyheal|critdebuff|critheal|mphit|chargeplus)/],
  ["§b守りの 体", /^(fullguard|dmgcap|guts|laststand|ndb_|cnt_)/], ["§6行動回数", /^(act|famking)/],
  ["§c能力アップ", /^st_/], ["§c攻撃の 種類・属性の 威力", /^(cd_|ed_|ed2_)/], ["§b軽減・激減・反射・障壁", /^(tg_|tg2_|te_|te2_|bar_|barrier_|mreflect|ct_phys|ct_weapon|ct_breath|ct_magic)/],
  ["§5状態異常（与える・防ぐ）", /^(oh_|im_|mindbar|aillong)/], ["§dロマン配合で 身につく", /^(ct_|cet_|cxt_|cct_|cy_)/], ["§7その他", /^(first|slowfirst|regen|mpregen|evade|crit|critdmg|lifesteal|pierce|halfmp|healboost|echo|multi|scout|expup|goldup|nosealed|nodebuff|metal|rapid)$/]];
const NEW_MV = new Set(["再誕の誓い", "再誕の大誓", "再誕の祈り", "霧散の波動", "静寂の指", "消光の魔弾", "消光の一閃", "真価解放", "妖光の帳", "仁王の構え", "不落の盾", "千刃の舞", "双刃の舞", "百花の拳舞", "千々の吹息", "全魔解放", "魔力の湧水", "闘気爆発", "静かなる溜め"]);
const MV_GROUPS = [["§c物理系§r（攻撃）", (m) => isA(m) && m.cat === "phys"], ["§6武系§r（攻撃）", (m) => isA(m) && m.cat === "weapon"], ["§3息系§r（攻撃）", (m) => isA(m) && m.cat === "breath"],
  ["§d魔法系§r（攻撃）", (m) => isA(m) && m.cat === "magic"], ["§a特質系§r（攻撃）", (m) => isA(m) && m.cat === "special"],
  ["§d§lかけひきの 技", (m) => !!m.combo || NEW_MV.has(m.name)], ["§6対戦向け§r（再誕・霧散・盾・溜め・耐性下げ）", (m) => !m.boss && !!(m.reraise || m.dispel || m.dispelhit || m.cover || m.charge || m.resdown || m.trboost || m.allmp || m.hitsR)], ["§a補助系", (m) => m.kind === "support" && !m.sig && !m.boss], ["§b反射系", (m) => m.kind === "reflect"],
  ["§5状態異常系", (m) => m.kind === "status" && !m.sig], ["§2回復系", (m) => m.kind === "heal" && !m.sig], ["§9吸収系", (m) => m.kind === "drain" && !m.sig],
  ["§4捨て身系", (m) => m.kind === "reckless" && !m.sig], ["§6固有技§r（系統べつ）", (m) => !!m.sig], ["§8ボス専用技", (m) => !!m.boss]];
async function zukanMoves(p, d) {
  for (;;) {
    const g = await choose(p, "図鑑：技", `§7全部で ${Object.keys(MOVES).length}しゅ`, [...MV_GROUPS.map(([n, f]) => B(`${n} §8${Object.values(MOVES).filter(f).length}`, ICON("i_spell"))), B("§7戻る", ICON("i_back"))]);
    if (g < 0 || g >= MV_GROUPS.length) return;
    const slvM = spLv(p);   /* 第67版: 物語を 見届ける 前は ネタバレの 技を 出さない */
    let ids = Object.keys(MOVES).filter((id) => MV_GROUPS[g][1](MOVES[id]) && (slvM >= 2 || (!(MOVES[id].sig && SPECIES[MOVES[id].sig]?.hidden) && !spTest(`${MOVES[id].name} ${SPECIES[MOVES[id].sig]?.name || ""} ${moveDesc(id)}`, slvM))));
    if (MV_GROUPS[g][1]({ sig: 1 })) {
      const fams = FAMILIES.filter((f) => ids.some((id) => SPECIES[MOVES[id].sig]?.fam === f.id));
      const f = await paged(p, "固有技", "§7系統を 選んでください", fams.map((x) => B(`${FAM_COLOR[x.id] || ""}${x.name}`, ICON("i_zukan"))), 8);
      if (f < 0) continue;
      ids = ids.filter((id) => SPECIES[MOVES[id].sig]?.fam === fams[f].id);
    } else ids.sort((a, b) => (MOVES[a].tier ?? 0) - (MOVES[b].tier ?? 0) || (MOVES[a].mp || 0) - (MOVES[b].mp || 0));
    for (;;) {
      const k = await paged(p, MV_GROUPS[g][0].replace(/§./g, ""), `§7${ids.length}種`, ids.map((id) => B(`§l${MOVES[id].name}§r §9MP${MOVES[id].mp || 0}\n${moveLabel(id)}§8${moveDesc(id, true).replace(/§./g, "").replace(/^(【[^】]*】)+/, "")}`, ICON("i_spell"))), 8);
      if (k < 0) break;
      const id = ids[k];
      const who = ORDER.filter((x) => SPECIES[x].sig === id || [...SPECIES[x].skills, ...(SPECIES[x].skx || [])].some((sk) => SKILLS[sk]?.list.some((e) => e.move === id))).filter((x) => slvM >= 2 || (!SPECIES[x].hidden && !spTest(SPECIES[x].name, slvM))).slice(0, 8).map((x) => SPECIES[x].name);
      const from = Object.entries(SKILLS).filter(([, sk]) => sk.list.some((e) => e.move === id) && (slvM >= 2 || !spTest(`${sk.name} ${sk.desc || ""}`, slvM)))   /* 第69版 */.map(([, sk]) => sk.name).slice(0, 6);
      await notice(p, MOVES[id].name, [moveDesc(id), LINE, from.length ? `§7覚える スキル: ${from.join("・")}` : "", `§7使う モンスター: ${who.join("・") || "-"}`].filter(Boolean).join("\n"));
    }
  }
}
async function zukanSkills(p, d) {
  const NEWL = new Set(["rz", "hd", "kb", "kbp", "mz", "ch", "cvl", "gd_special"]);
  const c = await choose(p, "図鑑：スキル", "§7どれを 見る？", [B(`すべて §8${Object.keys(SKILLS).length}`, ICON("i_skill")), B(`§dロマン配合（配合でしか 生まれない） §8${Object.values(SKILLS).filter((x) => x.combo).length}`, ICON("i_fuse")), B("§6かけひきの スキル\n§8再誕術・波動術・剣舞術 など", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
  if (c < 0 || c > 2) return;
  const slvK = spLv(p);   /* 第69版: ネタバレの スキルは かくす */
  const ids = Object.keys(SKILLS).filter((id) => (c === 0 || (c === 1 ? SKILLS[id].combo : NEWL.has(SKILLS[id].line))) && (slvK >= 2 || !spTest(`${SKILLS[id].name} ${SKILLS[id].desc || ""}`, slvK)));
  const pst = {}, mine = new Set(allMons(d).flatMap((m) => m.sk));
  for (;;) {
    const k = await paged(p, "図鑑：スキル", `§7全部で ${ids.length}しゅ（ポイントを 振ると 技や 能力を 覚える）§a● 仲間が 持っている`, ids.map((id) => B(`${mine.has(id) ? "§a● §r" : ""}${SKILLS[id].name}\n§8${SKILLS[id].list.filter((e) => e.move).map((e) => MOVES[e.move]?.name).filter(Boolean).slice(0, 3).join("・")}…`, ICON("i_skill"))), 8, [], pst);
    if (k < 0) return;
    const sk = SKILLS[ids[k]];
    const vv = await choose(p, sk.name, [`§l§e${sk.name}`, LINE, ...(COMBO_INFO[sk.line] ? [`§dロマン配合: §f${COMBO_INFO[sk.line].a} §7× §f${COMBO_INFO[sk.line].b}§7（親たちが 持っていると 配合で 生まれる）`] : []), ...sk.list.map((e) => `§7${String(e.pt).padStart(3, " ")}pt §f${e.move ? `技「${MOVES[e.move]?.name}」 §8${moveDesc(e.move, true)}` : e.trait ? `§d特性【${TRAITS[e.trait]?.name}】§8 ${TRAITS[e.trait]?.desc || ""}` : `${ST_NAME[e.stat]} +${e.val}`}`)].join("\n"), [B("§lOK", ICON("i_back")), B("§b技の くわしい 効果を 見る", ICON("i_spell"))]);
    if (vv === 1) await skillMovesView(p, ids[k]);   // UX案
  }
}
const MIX_TOTAL = Object.keys(FAM_MIX3).length * 3;
const mixCount = (d) => { let n = 0; for (const k of Object.keys(FAM_MIX3)) for (let b = 0; b < 3; b++) if (mxKnown(d, k, b)) n++; return n; };
async function zukanMix(p, d) {
  const fn = FNAME, fams = [...new Set(Object.keys(FAM_MIX3).flatMap((k) => k.split("|")))];
  for (;;) {
    const f = await paged(p, "系統 配合表", `§f親の 系統と ランク帯（いちばん 高い 親の ランク）で 生まれる 系統が 決まる。\n§7主の 系統から 2体・副から 1体・血統（1体目）から 1体が 候補になる\n§7知った 組み合わせ §e${mixCount(d)}§7/${MIX_TOTAL}`,
      fams.map((x) => B(`${FAM_COLOR[x] || ""}${fn(x)}§r と 配合すると…`, ICON("i_fuse"))), 8);
    if (f < 0) return;
    const a = fams[f];
    const lines = fams.map((b) => {
      const k = mixKey(a, b), e = FAM_MIX3[k];
      return `§f${fn(a)} × ${fn(b)}\n` + [0, 1, 2].map((band) => mxKnown(d, k, band) ? `  §7${BAND_NAME[band]}: §e${fn(e[band][0])}${e[band][1] !== e[band][0] ? `§7／§b${fn(e[band][1])}` : ""}` : `  §8${BAND_NAME[band]}: ？？？`).join("\n");
    });
    await notice(p, `${fn(a)}の 配合表`, ["§7（主／副）  4体配合は（1×2）と（3×4）の 主を さらに 合わせる。王・神が 入ると その 系統の まま", LINE, ...lines].join("\n"));
  }
}
async function zukanRoman(p, d) {
  const list = (d.rm || []).filter((i) => ROMAN[i]);
  if (!list.length) { await notice(p, "奇跡の配合", `§7まだ 1つも 知らない。（全 ${ROMAN.length}通り）\n§f決まった 2体を 配合すると、思わぬ 強い 子が 生まれる ことが ある。\n§e図書館§f の 本や §e物知り§f の 噂、実際に 配合して 見つけよう。`); return; }
  const k = await paged(p, "奇跡の配合", `§7見つけた 奇跡の配合 §e${list.length}§7/${ROMAN.length}`, list.map((i) => { const [a, b, t] = ROMAN[i]; return B(`${famColor(t)}${SPECIES[t].name} §6${SPECIES[t].rank}\n§8${SPECIES[a].name}(${SPECIES[a].rank}) × ${SPECIES[b].name}(${SPECIES[b].rank})`, MON_ICON(t)); }), 8);
  if (k >= 0) { const [a, b, t] = ROMAN[list[k]]; await notice(p, SPECIES[t].name, `§l${SPECIES[t].name}§r（ランク${SPECIES[t].rank}）\n\n§f${SPECIES[a].name}（${SPECIES[a].rank}・${FNAME(SPECIES[a].fam)}）\n× ${SPECIES[b].name}（${SPECIES[b].rank}・${FNAME(SPECIES[b].fam)}）\n\n§7この 2体を 2体配合すると 候補の 先頭に 出る`); }
}
async function zukanHints(p, d) {
  const list = (d.hints || []).filter((x) => SPECIES[x]);
  if (!list.length) { await notice(p, "配合メモ", "§7まだ メモが ない。\n§f街の §e図書館§f で ほんを 読んだり、§e物知り§f に はなしを 聞こう。"); return; }
  const k = await paged(p, "配合メモ", `§7知った 特別配合 ${list.length}こ`, list.map((x) => B(`${famColor(x)}${SPECIES[x].name} §8${SPECIES[x].rank}\n§7${recipeText(x).replace(/§./g, "").slice(0, 30)}`, MON_ICON(x))), 8);
  if (k >= 0) await notice(p, SPECIES[list[k]].name, `§l${SPECIES[list[k]].name}§r（ランク${SPECIES[list[k]].rank}）\n${recipeText(list[k])}`);
}
async function zukanMon(p, d) {
  for (;;) {
    const fams = FAMILIES.map((f) => { const l = ORDER.filter((x) => SPECIES[x].fam === f.id); return [f, l, l.filter((x) => d.own.includes(SPECIES[x].idx)).length]; });
    const s0 = await choose(p, "図鑑：モンスター", `§f見つけた §e${(() => { const sl = spLv(p); return (d.seen || []).filter((i) => { const x = sidOf(i); return x && (d.own.includes(i) || !(SPECIES[x].hidden && spTest(SPECIES[x].name, sl))); }).length; })()}§r / 仲間にした §e${ownN(d)}§r / ${ORDER.length}\n${meter(ownN(d), ORDER.length, 20)}\n§7系統を 選ぶか、§e検索§7で しぼりこめます`,
      [B("§e§l検索・しぼりこみ\n§8名前・ランク・系統・特性 など", ICON("i_scout")), ...fams.map(([f, l, n]) => B(`§l${FAM_COLOR[f.id] || ""}${f.name}§r §8${n}/${l.length}\n${meter(n, l.length, 10)}`, MON_ICON(l[0]))), B("§7戻る", ICON("i_back"))]);
    if (s0 === 0) { await monSearch(p, d); continue; }
    const s = s0 - 1;
    if (s < 0 || s >= fams.length) return;
    const [f, l] = fams[s];
    const ranks = [...new Set(l.map((x) => SPECIES[x].rank))];
    for (;;) {
      const r = await choose(p, f.name, "§7ランクを 選んでください", [...ranks.map((rk) => { const ll = l.filter((x) => SPECIES[x].rank === rk); return B(`§lランク ${rk}§r §8${ll.filter((x) => d.own.includes(SPECIES[x].idx)).length}/${ll.length}`, ICON("i_zukan")); }), B("§7戻る", ICON("i_back"))]);
      if (r < 0 || r >= ranks.length) break;
      const ll = l.filter((x) => SPECIES[x].rank === ranks[r]), pst = {};
      for (;;) {   // UX案: 1体 見たら 同じ 一覧・同じ ページに もどる
      const k = await paged(p, `${f.name} ${ranks[r]}`, "§7● 仲間  ○ 見つけた  ？ みたことがない  §6◆ 固有特性を 知っている", ll.map((x) => {
        const i = SPECIES[x].idx, h = (d.hts || []).includes(x) ? " §6◆" : "";
        return d.own.includes(i) ? B(`§f● ${SPECIES[x].name}${h}`, MON_ICON(x)) : d.seen.includes(i) && !(SPECIES[x].hidden && spTest(SPECIES[x].name, spLv(p))) ? B(`§7○ ${SPECIES[x].name}`, MON_ICON(x)) : B("§8？？？", ICON("i_zukan"));
      }), 10, [], pst);
      if (k < 0) break;
      await monDetail(p, d, ll[k]);
      }
    }
  }
}
// v2.9.1: おすすめ（1体ずつ 手作業で 決めた 育て方）
const TAC_N = Object.fromEntries(Object.keys(TAC_ALIAS).map((k) => [k, TACTICS[TAC_ALIAS[k]]]).concat(Object.entries(TACTICS)));   // 第63版: 6つの 作戦名で 表示
const WX_N = { sun: "§6晴れ", rain: "§9雨", sand: "§e砂嵐", snow: "§b雪", storm: "§e雷雨", wind: "§a暴風", fog: "§7霧", dark: "§5闇夜", holy: "§f天光" };
export function recoLines(sid) {
  const R = SPECIES[sid]?.reco; if (!R) return [];
  const sk = (R.skills || []).map((k) => (SKILLS[k]?.name || k).split("・")[0]).join(" / ");
  return [`§l§aおすすめの 育て方§r §7（${R.look || ""}）`, `§f役割: §e${R.role}§f  作戦: §b${TAC_N[R.tactic] || "-"}§f  天候: ${WX_N[R.weather] || "§7とくになし"}`,
    `§fスキル: §a${sk}`, `§f技: §d${(R.moves || []).map((m) => MOVES[m]?.name).filter(Boolean).join("・")}`,
    SPECIES[sid]?.deity !== undefined ? `§f特性: §7神は 決まった 特性（${(SPECIES[sid].traits || []).map((t) => TRAITS[t]?.name).filter(Boolean).slice(0, 3).join("・")}）` : `§f特性: §e${(R.traits || []).map((t) => TRAITS[t]?.name).filter(Boolean).join("・")}`,   /* 第71版 */
    `§f装備: §6${[R.weapon && WTYPES[R.weapon], R.armor && ATYPES[R.armor], R.acc && ACCT[R.acc]].filter(Boolean).join("・") || "-"}§f  性格: §b${R.nature || "-"}`,
    R.partner ? `§f相方: §f${R.partner}` : "", R.comment ? `§7「${R.comment}」` : ""].filter(Boolean);
}
async function monDetail(p, d, x) {
  {
    {
      const sp = SPECIES[x], f = FAMILIES.find((q) => q.id === sp.fam) || { name: sp.famName || "" };
      if (!d.own.includes(sp.idx) && (!d.seen.includes(sp.idx) || (sp.hidden && spTest(sp.name, spLv(p))))) { await notice(p, "？？？", "§7まだ みたことが ない モンスター。"); return; }   /* 第69版 */
      const res = Object.entries(sp.res || {}).map(([e, v]) => `${elTag(e)}${RESNAME[String(v)]}§r`).join(" ") || "§7とくになし";
      const h = TRAITS[sp.ht];
      const rec = (d.hints || []).includes(x) ? recipeText(x) : sp.special || sp.special4 ? "§8特別配合（図書館で 調べよう）" : sp.evo ? "" : "";
      const sks = [...sp.skills, ...(sp.skx || [])].slice(0, SKILL_N[sp.sz] || 3).filter((k2) => SKILLS[k2]);
      for (;;) { const v = await choose(p, sp.name, [`§l§e${sp.name}§r §7ランク${sp.rank} ${f.name}  §bサイズ${sp.sz}`, LINE, `§f${sp.desc || ""}`,
        `§fスキル: ${[...sp.skills, ...(sp.skx || [])].slice(0, SKILL_N[sp.sz] || 3).map((k2) => SKILLS[k2]?.name).join(" / ")}`, affText(x), `§f属性耐性: ${res}`, `§f状態異常耐性: ${aresText(x)}`, `§f${equipText(x)}`, `§7系統ボーナス: ${FAM_BONUS_TEXT[sp.fam] || "-"}`, `§fライド: ${rideInfo(x)}`, `§fおすすめ 性格: §b${natureText(sp.rec)}`,
        sp.sig && MOVES[sp.sig] ? `§6固有技: ${MOVES[sp.sig].name}（Lv${sp.siglv}）§7 ${moveDesc(sp.sig, true)}` : "",
        sp.evo ? `§dLv${sp.evo[1]}で ${SPECIES[sp.evo[0]].name}に 進化` : "", rec,
        LINE, ...recoLines(x),
        LINE, "§l§e特性", ...traitList(x), h ? ((d.hts || []).includes(x) ? `§6§l${h.name}§r§6: ${h.desc}` : "§8固有特性: ？？？") : ""].filter(Boolean).join("\n"),
        [B("§lOK", ICON("i_back")), ...sks.map((k2) => B(`§bスキル「${SKILLS[k2].name}」の 技`, ICON("i_spell")))]);   // UX案
        if (v >= 1 && v <= sks.length) { await skillMovesView(p, sks[v - 1]); continue; } break; }
    }
  }
}

// v1.7: 図鑑の 検索
const kata = (t) => (t || "").replace(/[\u3041-\u3096]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 0x60)).replace(/\s/g, "");
const ZS = { q: "", t: "", r: 0, f: 0, z: 0, rd: 0, st: 0, sort: 0 };
const ZRANKS = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
async function monSearch(p, d) {
  const prev = ZS[p.id] || { ...ZS };
  const v = await modal(p, "図鑑：検索", (f) => {
    f.textField("名前（ひらがな OK・一部で OK）", "例: ぷる", prev.q);
    f.textField("特性・技・スキルの 名前（一部で OK）", "例: ハガネ", prev.t);
    f.dropdown("ランク", ["すべて", ...ZRANKS], prev.r);
    f.dropdown("系統", ["すべて", ...FAMILIES.map((x) => x.name)], prev.f);
    f.dropdown("サイズ", ["すべて", "S", "M", "L", "G"], prev.z);
    f.dropdown("ライド", ["すべて", "あるく", "ふゆう", "ひこう"], prev.rd);
    f.dropdown("得意な 攻撃の 種類", ["すべて", ...Object.values(CATS)], prev.gc || 0);
    f.dropdown("得意な 属性", ["すべて", ...ELS.map((e) => EL_NAME[e])], prev.ge || 0);
    f.dropdown("じょうたい", ["すべて", "仲間に した", "見つけた（まだ 仲間で ない）", "見つけていない", "ハガネ族", "固有特性を 知っている"], prev.st);
    f.dropdown("ならびかえ", ["図鑑の じゅん", "ランクの 高い じゅん", "名前じゅん"], prev.sort);
  });
  if (!v) return;
  const c = { q: String(v[0] || ""), t: String(v[1] || ""), r: v[2], f: v[3], z: v[4], rd: v[5], gc: v[6], ge: v[7], st: v[8], sort: v[9] };
  ZS[p.id] = c;
  const q = kata(c.q), tq = kata(c.t), known = (x) => (d.seen.includes(SPECIES[x].idx) && !(SPECIES[x].hidden && spTest(SPECIES[x].name, spLv(p)))) || d.own.includes(SPECIES[x].idx);   /* 第69版 */
  const hit = (name) => kata(name).includes(tq);
  let l = ORDER.filter((x) => {
    const sp = SPECIES[x];
    if (c.r && sp.rank !== ZRANKS[c.r - 1]) return false;
    if (c.f && sp.fam !== FAMILIES[c.f - 1].id) return false;
    if (c.z && (sp.sz || "M") !== "SMLG"[c.z - 1]) return false;
    if (c.rd && sp.ride !== ["walk", "float", "fly"][c.rd - 1]) return false;
    if (c.gc && (sp.aff || {}).gc !== Object.keys(CATS)[c.gc - 1]) return false;
    if (c.ge && !((sp.aff || {}).ge || []).includes(ELS[c.ge - 1])) return false;
    const own = d.own.includes(sp.idx), seen = d.seen.includes(sp.idx) && !(sp.hidden && spTest(sp.name, spLv(p)));   /* 第69版 */
    if (c.st === 1 && !own) return false;
    if (c.st === 2 && (own || !seen)) return false;
    if (c.st === 3 && (own || seen)) return false;
    if (c.st === 4 && !sp.metalmon) return false;
    if (c.st === 5 && !(d.hts || []).includes(x)) return false;
    if (q && !(known(x) && kata(sp.name).includes(q))) return false;
    if (tq) {
      if (!known(x)) return false;
      const ok2 = (sp.traits || []).some((t) => TRAITS[t] && hit(TRAITS[t].name)) || (sp.sig && MOVES[sp.sig] && hit(MOVES[sp.sig].name))
        || [...sp.skills, ...(sp.skx || [])].some((k) => SKILLS[k] && (hit(SKILLS[k].name) || (SKILLS[k].list || []).some((e) => e.move && MOVES[e.move] && hit(MOVES[e.move].name))));
      if (!ok2) return false;
    }
    return true;
  });
  if (c.sort === 1) l = l.slice().sort((a, b) => ZRANKS.indexOf(SPECIES[b].rank) - ZRANKS.indexOf(SPECIES[a].rank));
  else if (c.sort === 2) l = l.slice().sort((a, b) => SPECIES[a].name.localeCompare(SPECIES[b].name, "ja"));
  if (!l.length) { await notice(p, "検索", "§7みつかりませんでした。\n§8名前・特性での 検索は 見つけた ことの ある モンスターだけが 対象です。"); return; }
  for (;;) {
    const k = await paged(p, `検索 §8${l.length}たい`, "§7● 仲間  ○ 見つけた  ？ みたことがない", l.map((x) => {
      const sp = SPECIES[x], own = d.own.includes(sp.idx), seen = d.seen.includes(sp.idx) && !(sp.hidden && spTest(sp.name, spLv(p)));   /* 第69版 */
      return own ? B(`§f● ${sp.name} §8${sp.rank} ${sp.sz || "M"}\n§7${sp.famName || ""}`, MON_ICON(x)) : seen ? B(`§7○ ${sp.name} §8${sp.rank}\n§8${sp.famName || ""}`, MON_ICON(x)) : B(`§8？？？ ${sp.rank}\n§8${sp.famName || ""}`, ICON("i_zukan"));
    }), 10);
    if (k < 0) return;
    await monDetail(p, d, l[k]);
  }
}
// 図鑑の キーワード検索（技・特性・スキル・道具）
async function wordSearch(p, d) {
  const v = await modal(p, "図鑑：キーワード検索", (f) => { f.textField("技・特性・スキル・道具の 名前や 説明（ひらがな OK）", "例: 会心", ZS[p.id + ":w"] || ""); f.dropdown("さがす ところ", ["ぜんぶ", "技", "特性", "スキル", "道具・装備"], 0); });
  if (!v) return;
  const w = String(v[0] || "").trim(); ZS[p.id + ":w"] = w;
  if (!w) return;
  const q = kata(w), m = (t) => t && (kata(t).includes(q) || t.includes(w));
  const R = [];
  const cat = v[1];
  const slvK = spLv(p), hideK = (t) => slvK < 2 && spTest(t, slvK);   // v3.0: 検索でも ネタバレを 出さない
  if (!cat || cat === 1) for (const [id, mv] of Object.entries(MOVES)) if ((m(mv.name) || m(moveDesc(id, true))) && !hideK(mv.name + moveDesc(id, true)) && !(mv.sig && hideK(SPECIES[mv.sig]?.name || "")) && !(mv.sig && SPECIES[mv.sig]?.hidden && slvK < 2)) R.push(["技", mv.name, () => `§l§e${mv.name}§r §9MP${mv.mp || 0}\n§f${moveDesc(id)}`, ICON("i_spell")]);
  if (!cat || cat === 2) for (const [id, t] of Object.entries(TRAITS)) if (!t.rare && (m(t.name) || m(t.desc))) R.push(["特性", t.name, () => `§l§e${t.name}§r\n§f${t.desc}\n§7もっている 仲間: ${ORDER.filter((x) => (SPECIES[x].traits || []).includes(id) && d.own.includes(SPECIES[x].idx)).slice(0, 12).map((x) => SPECIES[x].name).join("・") || "まだ いない"}`, ICON("i_skill")]);
  if (!cat || cat === 3) for (const [id, sk] of Object.entries(SKILLS)) if ((m(sk.name) || m(sk.desc) || (sk.list || []).some((e) => e.move && MOVES[e.move] && m(MOVES[e.move].name))) && !hideK(sk.name + (sk.desc || ""))) R.push(["スキル", sk.name, () => `§l§e${sk.name}§r\n§f${sk.desc || ""}\n§7覚える 技: ${(sk.list || []).filter((e) => e.move && MOVES[e.move]).map((e) => `${MOVES[e.move].name}(${e.pt})`).join("・") || "なし"}`, ICON("i_skill")]);
  const slvS = spLv(p), gotS = new Set((load(p)?.gi) || []);
  if (!cat || cat === 4) for (const [id, it] of Object.entries(ITEMS)) if ((m(it.name) || m(itemDesc(id))) && (gotS.has(id) || !((it.kind === "dslab" && slvS < 1) || (it.kind === "key" && slvS < 2) || spTest(it.name + itemDesc(id), slvS)))) R.push(["道具", it.name, () => `§l§e${it.name}§r\n§f${itemDesc(id)}\n§7手に入る 場所: ${whereGet(id)}${craftInfo(id) ? "\n" + craftInfo(id) : ""}`, ITEM_ICON(id)]);
  if (!R.length) { await notice(p, "キーワード検索", `§7「${w}」は みつかりませんでした。`); return; }
  const L = R.slice(0, 300);
  for (;;) {
    const k = await paged(p, `「${w.slice(0, 8)}」 §8${R.length}けん${R.length > 300 ? "（300まで 表示）" : ""}`, "", L.map(([c, n, , ic]) => B(`§8[${c}]§r ${n}`, ic)), 10);
    if (k < 0) return;
    await notice(p, L[k][1], L[k][2]());
  }
}

// ---------- クラフト ----------
const CRAFT_CATS = [["武器", "weapon", "i_fight"], ["防具", "armor", "i_guard"], ["アクセサリー", "acc", "i_equip"], ["道具", null, "i_item"]];
const ingName = (k) => k.startsWith("mrpg:") ? (ITEMS[k.slice(5)]?.name || k) : ({ "minecraft:stick": "ぼう", "minecraft:iron_ingot": "てつインゴット", "minecraft:gold_ingot": "きんインゴット", "minecraft:diamond": "ダイヤモンド", "minecraft:emerald": "エメラルド", "minecraft:string": "いと", "minecraft:leather": "かわ", "minecraft:copper_ingot": "どうインゴット", "minecraft:netherite_ingot": "ネザライト", "minecraft:amethyst_shard": "アメジスト", "minecraft:redstone": "レッドストーン", "minecraft:glowstone_dust": "グロウストーン", "minecraft:paper": "神", "minecraft:feather": "はね", "minecraft:wheat_seeds": "たね", "minecraft:wheat": "こむぎ", "minecraft:glass_bottle": "びん", "minecraft:ender_pearl": "エンダーパール", "minecraft:blaze_powder": "ブレイズパウダー", "minecraft:egg": "タマゴ", "minecraft:sugar": "さとう", "minecraft:apple": "りんご", "minecraft:gold_nugget": "きんのつぶ", "minecraft:iron_nugget": "てつのつぶ", "minecraft:lapis_lazuli": "ラピスラズリ", "minecraft:quartz": "クォーツ", "minecraft:nether_star": "ネザースター", "minecraft:prismarine_shard": "プリズマリン", "minecraft:honey_bottle": "はちみつ", "minecraft:book": "ほん", "minecraft:netherite_scrap": "ネザライトのかけら", "minecraft:gunpowder": "かやく" }[k] || k.replace("minecraft:", ""));
function craftable(p, rec) { return Object.entries(rec).every(([k, n]) => countItem(p, k) >= n); }
const craftVisible = (id, c) => storyItemOk(ITEMS[id], EGGS[id]?.ranks, c) && Object.keys(RECIPES[id]).every((k) => !k.startsWith("mrpg:") || !ITEMS[k.slice(5)] || storyItemOk(ITEMS[k.slice(5)], null, c));   // v2.9.12: 物語で 作れる もの
async function craftMenu(p, d) {
  for (;;) {
    const c = await choose(p, "クラフト", "§fモンスターを 倒して 手に入れた 素材で 作ります。\n§7素材は 系統ごとに 3種類（ふつう・レア・ちょうレア）。\n§7マイクラの さぎょうだいでも 同じ レシピで 作れます。",
      [...CRAFT_CATS.map(([n, k, ic]) => { const capK = rankCap(d), l = Object.keys(RECIPES).filter((id) => ITEMS[id] && (k ? ITEMS[id].kind === k : !["weapon", "armor", "acc"].includes(ITEMS[id].kind)) && craftVisible(id, capK)); const ok = l.filter((id) => craftable(p, RECIPES[id])).length; return B(`§l${n}§r §8${l.length}しゅ${ok ? ` §2作れる ${ok}` : ""}`, ICON(ic)); }), B("§7戻る", ICON("i_back"))]);
    if (c < 0 || c >= CRAFT_CATS.length) return;
    const k = CRAFT_CATS[c][1];
    for (;;) {
      const only = await choose(p, CRAFT_CATS[c][0], "§7ひょうじする ものを 選んでください", [B("§l§2いま 作れる もの", ICON("i_party")), B("全部 見る", ICON("i_zukan")), B("§7戻る", ICON("i_back"))]);
      if (only < 0 || only > 1) break;
      let l = Object.keys(RECIPES).filter((id) => ITEMS[id] && (k ? ITEMS[id].kind === k : !["weapon", "armor", "acc"].includes(ITEMS[id].kind)));
      l.sort((a, b) => (ITEMS[a].price || 0) - (ITEMS[b].price || 0));
      { const capC = rankCap(d); l = l.filter((id) => craftVisible(id, capC)); }   // 素材が まだ 手に 入らない ものも 出さない   // v2.9.12: 物語の 進みで 作れる 段が ふえる
      if (only === 0) l = l.filter((id) => craftable(p, RECIPES[id]));
      if (!l.length) { await notice(p, "クラフト", "§7いま 作れる ものは ありません。\nモンスターを 倒して 素材を 集めよう。"); continue; }
      for (;;) {
        const sel = await paged(p, CRAFT_CATS[c][0], "§2○§7 = 作れる", l.map((id) => B(`${craftable(p, RECIPES[id]) ? "§2○ " : "§8"}${ITEMS[id].name}\n§7${clipT(itemDesc(id), 28)}`, ITEM_ICON(id))));
        if (sel < 0) break;
        const id = l[sel], rec = RECIPES[id];
        const lines = Object.entries(rec).map(([kk, n]) => { const h = countItem(p, kk); return `${h >= n ? "§a○" : "§c×"} §f${ingName(kk)} §7${h}/${n}`; });
        const can = craftable(p, rec);
        const body = [`§l§e${ITEMS[id].name}`, `§f${itemDesc(id)}`, LINE, "§f必要なもの:", ...lines].join("\n");
        if (!can) { await notice(p, "クラフト", body + "\n\n§c素材が たりません。"); continue; }
        if (!(await confirm(p, "クラフト", body, "作る", "やめる"))) continue;
        if (!craftable(p, rec)) continue;
        { const taken = []; let okT = true; for (const [kk, n] of Object.entries(rec)) { if (takeItem(p, kk, n)) taken.push([kk, n]); else { okT = false; break; } } if (!okT) { for (const [kk, n] of taken) giveItem(p, kk, n); continue; } }
        if (isGear(id)) { const r = capRoll(p, id, rollGear(id, "craft")); giveGear(p, id, r); await notice(p, "クラフト 成功！", [`§l${gearName(id, r)}`, ...gearLines(id, r)].join("\n")); }
        else { giveItem(p, `mrpg:${id}`, 1); p.sendMessage(`§a${ITEMS[id].name}を 作った！`); }
        sound(p, "random.anvil_use"); particle(p, "minecraft:totem_particle", 1.2);
      }
    }
  }
}

export const HELP = [
  "§l§eマインクエストの 遊び方", LINE,
  "§6§l■ はじめに", "§f・ ガイドブックを 使うと メニュー。困ったら §e用語説明§f（分類ごと）を 見よう",
  "§f・ 物語は「ストーリー → 次の 目標」か §eセオの 研究メモ§f で 確認。地方の 主を 倒すと 次の 地方へ",
  "§f・ モンスターを 殴ると バトル。§bモンスターマスター§fには 話しかけると 勝負（からまれる ことは ない）", "",
  "§c§l■ 戦い", "§f・ 攻撃は §c物理系§f・§6武系§f・§3息系§f・§d魔法系§f・§a特質系§f。属性 10種・状態異常 10種",
  "§f・ §b先制度§f（-2〜+4）が 高い 技から 動く。同じなら 走力の 高い 順",
  "§f・ S・M・Lの 攻撃は 1回 §e999§f まで（Gは 上限なし）。§b解放の霧§f などで はずせる。連続攻撃は 1発ごとに 弱まる",
  "§f・ 物理系・武系は §eはずれる§f ことも。§b回避§fは 走力の 勝負。会心は 1.5倍・急所ランクで 出やすく",
  "§f・ §6天候§f 9種（晴れで 炎 1.5倍・水 0.5倍 など）。闘技場は いつも 晴れ",
  "§f・ 戦いの 場は ステージごとの §bドーム§f。終われば もとに もどる。逃げられない 戦いは こうさん OK", "",
  "§b§l■ そだてる", "§f・ レベルで SP → スキルに 振る。§e解放するほど 上がり幅が 大きく§f（皆伝編は 最後 +22）",
  "§f・ 配合で プラス値が のびる。性格（±10%）。技は 100回 使うと「極めた」技に", "§f・ パーティは 4枠（S1・M2・L3・G4）。L・Gは 物理が 全体",
  "§f・ 図鑑と 仲間の 画面に §aおすすめの 育て方§f（全900体・1体ずつ）。迷ったら これを 見よう",
  "§f・ 仲間 →「色がえ」で 部位ごとの 色。相棒は 見た目（マント・武器）を 作りかえ", "",
  "§6§l■ 装備と 道具", "§f・ §e武器 16種§f: 種類ごとに 戦う 能力（物力・武力・魔力・走力・特質）と 攻撃属性（斬・打・突・射・鞭・魔・呪）が ちがう",
  "§f・ 装備は レア度 F〜X（物語で 解放）。§aクラフト素材 30種§fで 武器を 作る", "§f・ だいじなもの（懐中電灯・ゴーグル など）・特別な石板は 使っても なくならない",
  "§f・ 死んでも 持ち物は 落とさない。倒した モンスターは 2〜3個 落とす", "",
  "§a§l■ 冒険", "§f・ 街・城（地方ごとに 個性）・遺跡・神殿・ステージ。遠いほど 敵が 強い（ネザー+15・エンド+30）",
  "§f・ ライドは 種類ごと: 飛行・泳ぎ（海の 上を 進む）・よじ登り・掘り進み。闘技場の 受付で §6モンスター闘技場§f（かけ）",
  "§f・ 連れ歩く 仲間に 右クリックで ライド。§b釣り§f・石板の ボス・マルチ（対戦・協力・レイド）", "§f・ クリア後: 再会の石板・覇王／神域・やりこみ など", "",
  "§7§l■ こまったら", "§7・ 重いときは 冒険 →「設定」で 軽量モード", "§7・ 戦闘中に 見えない ときは コマンドの「表示を なおす」",
].join("\n");

export async function resetData(p) {
  try { if (EXH.reset) EXH.reset(p); } catch {}   /* 第101版: 探索の 記録も 消す */
  const d = load(p);
  if (d) recallPet(p, d);
  wipe(p);
}

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { AFTER.delete(playerId); } catch {} }); } catch {}
