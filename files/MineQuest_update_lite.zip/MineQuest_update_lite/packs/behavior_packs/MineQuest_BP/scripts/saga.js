// v2.8: 物語の 冒険（地方の 関所・メインクエスト・だいじなもの・NPCの からみ・ライバル・共闘・裏切り）
// ・メインクエストは 1本道（s.mq）。手順が まだ 来ていない できごとは 起きないので、ワープしても 矛盾しない
// ・地方は「その 地方の 主」を 倒すと 次が 開く。それまでは「まだ やるべき ことが あるようだ、引き返そう」
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, ITEMS, BOSS_SLAB } from "./data.js";
import { load, save } from "./store.js";
import { busy, ok, wait, notice, confirm, sound, particle, giveItem, countItem, gold, seedId, takeItem, barNote, showTitle, setJob, bagAdd } from "./ui.js";
import { WREGIONS, regionIdx, regionLv, landSites, LAYOUT } from "./worldmap.js";
import { townAt, homeInfo, landInfo, unstuckNpc, groundY, castleInfo, castleSpot, TOWNS, townPos, caveInfo, CAVE_R, caveSite } from "./structures.js";
import { qs, syncQuest, postOpen, BS_N } from "./quest.js";
import { fight } from "./story.js";
import { calcStats, canFight } from "./core.js";
import { underwater, waterDepth, hooks } from "./field.js";
import { nearAltar, dreamFlow, altarInfo, rfInfo } from "./postgame.js";
import { musashiTownInfo } from "./majin.js";

const SP = () => { try { const w = world.getDefaultSpawnLocation(); return { x: w.x, y: w.y, z: w.z }; } catch { return { x: 0, y: 64, z: 0 }; } };
export const regAt = (loc) => { const s = SP(); return regionIdx(loc.x - s.x, loc.z - s.z); };
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const ri = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const RN = (r) => WREGIONS[r]?.name || "";

// ---------- 地方の 関所 ----------
// 地方 r を こえるための 目標（その 地方の 主）
const RGOAL = [
  { t: (s) => s.bs.includes(0), h: () => `アルカトラス城の 地方マスターに 勝ち、「${BOSS_SLAB[0]?.name}」の 主を 封印する` },
  { t: (s) => !!(s.gate && s.gate[1]), h: () => "シルヴァ大森林の「森の 主」を しずめる（セオと 共闘）" },
  { t: (s) => s.bs.includes(2), h: () => `ルインズ荒野の 地方マスターに 勝ち、「${BOSS_SLAB[2]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(4), h: () => `ヴォルカ火山帯の 地方マスターに 勝ち、「${BOSS_SLAB[4]?.name}」の 主を 封印する` },
  { t: (s) => !!(s.gate && s.gate[4]), h: () => "サンドリア砂漠の「王墓の 主」を 倒す（レイと 共闘）" },
  { t: (s) => s.bs.includes(6), h: () => `クリスタリアの 地方マスターに 勝ち、「${BOSS_SLAB[6]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(8), h: () => `マリノア諸島の 地方マスターに 勝ち、「${BOSS_SLAB[8]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(10), h: () => `ネクロス冥府領の 地方マスターに 勝ち、「${BOSS_SLAB[10]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(12), h: () => `フロストヘイムの 地方マスターに 勝ち、「${BOSS_SLAB[12]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(13), h: () => `ラグナの 地方マスターに 勝ち、「${BOSS_SLAB[13]?.name}」の 主を 封印する` },
];
// どこまで 行けるか（後の 目標を 果たしていれば、前の 地方も すべて 開く）
function sealOpen(s) { for (let j = RGOAL.length - 1; j >= 0; j--) if (RGOAL[j].t(s)) return j + 1; return 0; }
// v2.9.13: 物語の 順番（いまの 段の 地方より 先へは 行けない。フラグを 飛ばせない ように）
function storyOpen(s) { const st = MQ[s.mq ?? 0]; return !st || st.r === 99 ? 99 : st.r; }
export function openUpTo(d) {
  const s = qs(d);
  if (s.ending || s.gateFree) return 99;
  const u = sealOpen(s);
  return s.ord ? Math.min(u, storyOpen(s)) : u;
}
// その 地方マスターに 挑める 段まで 物語が 進んで いるか
export function sealReady(d, si) { const s = qs(d); if (!s.ord || s.ending) return true; const k = MQ.findIndex((x) => x.seal === si); return k < 0 || (s.mq ?? 0) >= k; }
export function storyNowHint(d) { const s = qs(d); const st = MQ[s.mq ?? 0]; return st ? hintOf(st, d) : ""; }
hooks.openUpTo = (d) => openUpTo(d);   // v2.9.12: 物語の 場所を 先に 作る 範囲
export const regionOpen = (d, r) => r <= openUpTo(d);
export const gateHint = (d) => { const u = openUpTo(d), s = qs(d); if (u >= RGOAL.length || u >= 99) return null; if (s.ord && storyOpen(s) < sealOpen(s)) return `§7（${RN(u + 1)}へ 行くには、まず 物語を 進めよう: ${String(storyNowHint(d)).replace(/§./g, "")}）`; return `§7（${RN(u + 1)}へ 行くには: ${RGOAL[u].h()}）`; };

// ---------- だいじなもの ----------
export const hasKey = (p, id) => countItem(p, `mrpg:${id}`) > 0;
function giveKey(p, d, id) {
  const s = qs(d); s.keys = [...new Set([...(s.keys || []), id])];
  if (!hasKey(p, id)) giveItem(p, `mrpg:${id}`, 1);
  try { showTitle(p, " ", { subtitle: `§6だいじなもの「${ITEMS[id]?.name}」を 手に入れた！`, fadeInDuration: 5, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
  sound(p, "random.levelup", 1.2);
}
// なくした だいじなもの・特別な 石板を もどす
// 持ち物が いっぱいの ときは 足もとに 落とさず バッグへ（何度も 落ちて ふえない ように）
function giveItemSafe(p, id) {
  try { const c = p.getComponent("minecraft:inventory")?.container; if (c && c.emptySlotsCount === 0) { bagAdd(p, id, 1); return true; } } catch {}
  giveItem(p, `mrpg:${id}`, 1); return true;
}
export function syncKeys(p, d) {
  const s = qs(d), back = [];
  // v2.9.12: いまの 段で 使う だいじなものが 記録に なければ わたす（とちゅうで ぬけて もらいそびれた とき）
  try { const cur = MQ[s.mq ?? 0]; if (cur && cur.key && ITEMS[cur.key] && !(s.keys || []).includes(cur.key)) s.keys = [...(s.keys || []), cur.key]; } catch {}
  for (const id of s.keys || []) if (ITEMS[id] && !hasKey(p, id)) { if (!giveItemSafe(p, id)) continue; back.push(ITEMS[id].name); }
  try { back.push(...syncQuest(p, d)); } catch {}
  return back;
}

// ---------- チーム ----------
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
const rankForLv = (lv) => (lv < 8 ? 0 : lv < 14 ? 1 : lv < 22 ? 2 : lv < 32 ? 3 : lv < 44 ? 4 : lv < 56 ? 5 : lv < 70 ? 6 : 7);
function cands(fams, rk, sizes) {
  return ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !["king", "god"].includes(S.fam) && (!fams || fams.includes(S.fam)) && S.rank === RK[rk] && (!sizes || sizes.includes(S.sz)); });
}
export function team(fams, lv, n = 3, plus = 0, lead = null) {
  const out = []; let used = 0;
  const rk0 = rankForLv(lv);
  if (lead) { out.push({ sid: lead, lv: Math.min(100, lv + 2), q: 0.8, plus: plus + 5 }); used += SLOT[SPECIES[lead]?.sz] || 2; }
  for (let k = 0; out.length < n && k < 12; k++) {
    const rk = Math.max(0, rk0 - (out.length >= 2 ? 1 : 0));
    let c = cands(fams, rk).filter((x) => used + (SLOT[SPECIES[x].sz] || 2) <= 4 && !out.some((t) => t.sid === x));
    if (!c.length) c = cands(null, rk).filter((x) => used + (SLOT[SPECIES[x].sz] || 2) <= 4 && !out.some((t) => t.sid === x));
    if (!c.length) break;
    const x = pick(c); used += SLOT[SPECIES[x].sz] || 2;
    out.push({ sid: x, lv: Math.min(100, lv + (out.length ? 0 : 1)), q: 0.7, plus });
  }
  return out;
}
function bossOne(fams, lv, plus, rkUp = 1) {
  const rk = Math.min(7, rankForLv(lv) + rkUp);
  let c = cands(fams, rk, ["L", "G"]); if (!c.length) c = cands(fams, rk); if (!c.length) c = cands(null, rk, ["L", "G"]);
  return [{ sid: pick(c) || ORDER[0], lv: Math.min(100, lv), q: 1, plus }];
}
const leadOf = (fam, lv) => { const c = cands([fam], Math.min(7, rankForLv(lv) + 1)); return c.length ? pick(c) : null; };

// ---------- 会話・演出 ----------
const COL = { オルド: "§e", セオ: "§a", レイ: "§b", "？？？": "§4", ヴァルカ: "§c", マリン: "§3", ロウ: "§9", ルウ: "§d" };
async function say(p, who, lines) { const c = COL[who] || "§6"; for (const l of [].concat(lines)) await notice(p, who, /^§7→/.test(l) ? l : `${c}§l${who}§r\n\n§f「${l}」`); }   // v3.0 第63版: 操作の 案内は セリフに しない
async function narr(p, t, lines) { await notice(p, t, [].concat(lines).join("\n")); }
function big(p, a, b, snd = "random.levelup") { try { showTitle(p, a, { subtitle: b || "", fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {} if (snd) sound(p, snd, 1); }
function npcNear(p, name, job = 8) {
  try {
    const yaw = (p.getRotation().y * Math.PI) / 180, l = p.location;
    const pos = { x: l.x - Math.sin(yaw) * 3.5, y: l.y, z: l.z + Math.cos(yaw) * 3.5 };
    const e = p.dimension.spawnEntity("mrpg:npc", pos);
    if (MQASK.has(p.id)) { const L = SPAWNED.get(p.id) || []; L.push(e); SPAWNED.set(p.id, L); }
    { const A = TALKERS.get(p.id) || []; A.push(e); TALKERS.set(p.id, A.filter((x) => ok(x))); }   // v3.0: 戦いの 前に 消す ため
    try { setJob(e, job); } catch {}
    e.addTag("mrpg_npc"); e.addTag("mrpg_saga"); e.setDynamicProperty("mrpg:saga", true); e.nameTag = name;
    try { e.teleport(pos, { facingLocation: { x: l.x, y: l.y + 1.5, z: l.z } }); } catch {}
    particle(e, "minecraft:knockback_roar_particle", 1);
    system.runTimeout(() => unstuckNpc(e), 4);
    return e;
  } catch { return null; }
}
const rm = (e) => { if (ok(e)) try { e.remove(); } catch {} };
// v2.9.12: 物語の 戦いは 始まる 前に 聞く（着いた とたんに 戦いに ならない）。「あとで」なら 少し たってから もう一度
const MQRUN_KEY = new Set();   // v2.9.13: だいじなもので 始まった 段
const MQASK = new Set(), MQRUN = new Set(), SPAWNED = new Map(), LATER = { later: true };
function laterClean(p) { for (const e of SPAWNED.get(p.id) || []) rm(e); SPAWNED.delete(p.id); }
// 物語の 戦い（勝っても 負けても 仲間は 回復。お金は へらない）
const TALKERS = new Map();   // v3.0: 会話の ために 出した 人（戦いが 始まる ときに 消す。ライバルが 戦いの 場に 残らない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { for (const e of TALKERS.get(playerId) || []) rm(e); TALKERS.delete(playerId); }); } catch {}
async function battle(p, foe, info) {
  const d0 = load(p); if (!canFight(d0)) return "_noparty";
  for (const e of TALKERS.get(p.id) || []) rm(e); TALKERS.delete(p.id);
  if (MQASK.has(p.id)) {
    MQASK.delete(p.id);
    if (!info.asked && !(await confirm(p, "物語の 戦い", `§c§l戦いが 始まる！§r\n\n§f相手: §e${info.name || "？？？"}\n${info.heal === false ? "§c仲間の 回復は なし。" : "§7仲間は 戦いの 前に 全回復する。"}${info.scripted ? "\n§e（この 戦いは 勝てなくても 物語は 進む）" : "\n§7（負けても その場で もう一度 挑める）"}\n§7「あとで」を えらんだ ときは、ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度 起きる（だいじなものの 戦いは その だいじなものを もう一度 使う）。それまで 物語は 先へ 進まない。`, "戦う", "あとで"))) throw LATER;
  }
  if (info.heal !== false) { for (const m of d0.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d0); }
  let res = null;
  busy.delete(p.id);   // 戦いは 自分で busy を つける
  try { res = await fight(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", ...info }); } catch (e) { console.warn(`[MonsterRPG] saga fight: ${e}`); }
  // v2.9.13: 負けたら その場で「もう一度 挑む」（決まった 負けの できごとは のぞく）
  for (let k = 0; k < 5 && res === "lose" && !info.scripted && info.heal !== false; k++) {   // 回復なしの 連戦は その場で やりなおさない
    busy.add(p.id);   // 再戦の 画面の あいだは ほかの 人の 申しこみを 止める
    let again = false; try { if (ok(p)) again = await confirm(p, "負けて しまった……", `§f相手: §e${info.name || "？？？"}\n\n§fもう一度 挑みますか？\n§7（仲間は 全回復する。${!MQRUN.has(p.id) ? "「あとで」なら また 今度 挑める" : `「あとで」なら ${MQRUN_KEY.has(p.id) ? "もう一度 だいじなものを 使えば" : "ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶと"} もう一度 起きる`}）`, "もう一度 挑む", "あとで"); } catch {}
    if (!again || !ok(p)) break;
    const dr = load(p); if (!dr) break;
    for (const m of dr.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, dr);
    busy.delete(p.id);
    try { res = await fight(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", ...info, asked: true }); } catch (e) { console.warn(`[MonsterRPG] saga fight: ${e}`); res = null; }
  }
  if (EVT.has(p.id)) busy.add(p.id);   // 戦いの あとも 物語の 会話が 終わるまで ほかの できごとを 止める
  const d = load(p); if (d && res !== "win") { for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = Math.max(m.hp, Math.floor(c.hp / 2)); m.mp = Math.max(m.mp, Math.floor(c.mp / 2)); } save(p, d); }
  return res;
}
function reward(p, d, g, items = []) {
  const got = [];
  if (MQRUN.has(p.id)) { const s0 = qs(d); s0.mqPaid = s0.mq ?? 0; }   // v2.9.12: ごほうびを わたした 段は とちゅうで 落ちても 先へ 進める（2回 もらえない）
  if (g) { d.gold += g; got.push(gold(g)); }
  for (let [id, n] of items) { if (id === "SEED2") id = seedId(2); if (id === "SEED3") id = seedId(3); if (!ITEMS[id]) continue; giveItem(p, `mrpg:${id}`, n || 1); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); }
  return got;
}
export function homeTp(p) {
  const h = homeInfo(); const s = SP();
  const at = h && h.built ? { x: h.x, y: h.y + 0.1, z: h.z } : { x: s.x + 0.5, y: s.y + 0.2, z: s.z + 0.5 };
  try { p.teleport(at, { dimension: world.getDimension("overworld") }); } catch {}
  try { p.addEffect("slow_falling", 100, { showParticles: false }); } catch {}
}

// ---------- 状況（地下・海・町・ステージ）----------
function underground(p) {
  try {
    const l = p.location; if (p.dimension.id !== "minecraft:overworld" || l.y > 58) return false;
    const x = Math.floor(l.x), z = Math.floor(l.z), y = Math.floor(l.y);
    for (let dy = 2; dy < 22; dy++) { const t = p.dimension.getBlock({ x, y: y + dy, z })?.typeId || ""; if (!t) return false; if (t !== "minecraft:air" && !t.includes("leaves") && !t.includes("water") && !t.includes("glass")) return true; }
  } catch {}
  return false;
}
// v2.9.12: 物語で 作った 洞くつの 中（階段の 下の ほう〜広間）に いるか
export function inCave(p, R) {
  try {
    if (p.dimension.id !== "minecraft:overworld") return false;
    const v = caveInfo(R); if (!v || !v.built) return false;
    const l = p.location, zEnd = v.hall ? v.hall.z + 10 : v.z + 70;
    return Math.abs(l.x - v.x) < 8 && l.z >= v.z - 4 && l.z <= zEnd && l.y < v.y - 6;
  } catch { return false; }
}
function depthOf(p) { try { const l = p.location; return underwater(p) ? waterDepth(p.dimension, Math.floor(l.x), Math.floor(l.y) + 1, Math.floor(l.z)) : 0; } catch { return 0; } }
function stageNear(p, r = 40) {   /* v2.9.12: 右上の「この あたり」と おなじ 40 */
  const R = regAt(p.location);
  for (const L of landSites(R)) { const I = landInfo(L.key); if (I && I.built && Math.hypot(p.location.x - L.x, p.location.z - L.z) < r) return { ...L, name: I.name, r: R }; }
  return null;
}
const exempt = (p) => { try { const l = p.location; if (p.dimension.id !== "minecraft:overworld" || l.y > 180 || busy.has(p.id)) return true; if (typeof p.getDynamicProperty("mrpg:dg") === "string" || typeof p.getDynamicProperty("mrpg:ret") === "string") return true; const s = SP(); return Math.hypot(l.x - s.x, l.z - s.z) > 4200; } catch { return true; } };

// ---------- v2.9: 冤罪 → 城の 牢屋（負けイベント）----------
const _jh = (id) => { let h = 7; for (const c of String(id || "")) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
// v2.9.12: 牢屋の 番号は 入る ときに 空いて いる ものを えらんで 記録（ほかの 人と 同じ 牢屋に ならない）
function jailPeek(p) { try { const v = p.getDynamicProperty("mrpg:jailk"); if (typeof v === "number") return v; } catch {} return null; }   // v3.0: 読むだけ（入って いない 人には 番号を わりあてない）
function jailSlot(p) {
  try { const v = p.getDynamicProperty("mrpg:jailk"); if (typeof v === "number") return v; } catch {}
  let R = {}; try { R = JSON.parse(world.getDynamicProperty("mrpg:jailslots") || "{}"); } catch {}
  if (typeof R[p.id] === "number") { try { p.setDynamicProperty("mrpg:jailk", R[p.id]); } catch {} return R[p.id]; }
  const used = new Set(Object.values(R));   // v2.9.12: ワールドに 記録（ぬけて いる 人の 牢屋も ほかの 人に わたさない）
  let k = _jh(p.id) % 64; for (let n = 0; n < 64 && used.has(k); n++) k = (k + 1) % 64;
  try { p.setDynamicProperty("mrpg:jailk", k); } catch {}
  R[p.id] = k; try { world.setDynamicProperty("mrpg:jailslots", JSON.stringify(R)); } catch {}
  return k;
}
const JOFF = () => Math.round(720 * LAYOUT.k);   /* 第99版: 寄せた 配置では 地形の 中に */
const JAIL = (p) => { const s = SP(), k = p ? jailSlot(p) : 0; return { x: Math.floor(s.x) - JOFF() - (k % 8) * 24, y: 232, z: Math.floor(s.z) - JOFF() - Math.floor(k / 8) * 24 }; };   // v2.9.2: 人ごとに べつの 牢屋
function jcmd(dim, c) { try { if (typeof dim.runCommand === "function") dim.runCommand(c); else dim.runCommandAsync(c); } catch {} }
export const inJail = (p) => { try { const k = jailPeek(p); if (k === null) return false; const s = SP(), J = { x: Math.floor(s.x) - JOFF() - (k % 8) * 24, y: 232, z: Math.floor(s.z) - JOFF() - Math.floor(k / 8) * 24 }, l = p.location; return p.dimension.id === "minecraft:overworld" && Math.abs(l.x - J.x) < 12 && Math.abs(l.z - J.z) < 12 && Math.abs(l.y - J.y) < 12; } catch { return false; } };
async function buildJail(ow, J) {
  jcmd(ow, `tickingarea add ${J.x - 8} 0 ${J.z - 8} ${J.x + 8} 0 ${J.z + 8} mrpg_jail_${J.x}_${J.z}`);
  for (let t = 0; t < 40; t++) { let okb = false; try { okb = !!ow.getBlock({ x: J.x, y: J.y, z: J.z }); } catch {} if (okb) break; await wait(5); }
  const C = [`fill ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} stone_bricks`, `fill ${J.x - 4} ${J.y} ${J.z - 4} ${J.x + 4} ${J.y + 4} ${J.z + 4} air`,
    `fill ${J.x - 4} ${J.y - 1} ${J.z - 4} ${J.x + 4} ${J.y - 1} ${J.z + 4} cobblestone`, `fill ${J.x - 1} ${J.y} ${J.z - 4} ${J.x - 1} ${J.y + 3} ${J.z + 4} iron_bars`,
    `fill ${J.x - 3} ${J.y} ${J.z - 4} ${J.x - 2} ${J.y} ${J.z - 3} hay_block`, `setblock ${J.x - 4} ${J.y + 3} ${J.z} soul_lantern`, `setblock ${J.x + 3} ${J.y + 3} ${J.z + 3} lantern`,
    `fill ${J.x - 5} ${J.y + 2} ${J.z - 1} ${J.x - 5} ${J.y + 2} ${J.z + 1} iron_bars`, `setblock ${J.x - 3} ${J.y} ${J.z + 3} iron_bars`, `fill ${J.x + 1} ${J.y} ${J.z + 4} ${J.x + 4} ${J.y} ${J.z + 4} barrel`,
    `setblock ${J.x + 3} ${J.y} ${J.z - 3} smithing_table`, `fill ${J.x - 4} ${J.y + 4} ${J.z - 4} ${J.x - 2} ${J.y + 4} ${J.z - 4} web`];
  for (const c of C) jcmd(ow, c);
}
function clearJail(ow, J) { jcmd(ow, `fill ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} air`); jcmd(ow, `tickingarea remove mrpg_jail_${J.x}_${J.z}`); }
// v2.9.12: 牢屋に いる まま ぬけた 人の 読みこみ範囲は 外す（もどって きたら 外へ 出す 処理は 別に ある）
try { world.beforeEvents.playerLeave.subscribe((e) => { try { const p = e.player; if (!inJail(p)) return; const J = JAIL(p); system.run(() => { try { world.getDimension("overworld").runCommand(`tickingarea remove mrpg_jail_${J.x}_${J.z}`); } catch {} }); } catch {} }); } catch {}
export function releaseJail(p) {
  const d = load(p); const s = d ? qs(d) : null;
  const r = s && s.jailRet;
  try { if (r) p.teleport({ x: r.x, y: r.y + 0.2, z: r.z }, { dimension: world.getDimension("overworld") }); else homeTp(p); } catch {}
  try { p.addEffect("slow_falling", 200, { showParticles: false }); p.addEffect("resistance", 200, { amplifier: 4, showParticles: false }); } catch {}
}
async function jailEvent(p) {
  const d = load(p); if (!d) return false;
  const s = qs(d);
  const ret = { x: p.location.x, y: p.location.y, z: p.location.z };
  try { const gy = groundY(p.dimension, ret.x, ret.z, Math.floor(ret.y)); if (typeof gy === "number" && gy <= ret.y) ret.y = gy; } catch {}   // 空中なら 地面へ
  const e = npcNear(p, "§6サンドリア城の 衛兵長 ガルム", 16);
  big(p, "§c§l止まれ！", "§f衛兵たちに 囲まれた……！", "mob.villager.no");
  await say(p, "ガルム", ["そこの 旅人、止まれ！ 王墓を 荒らした 一味だな！", "石板を 持った あやしい やつが いると 聞いた。言い訳は 牢で 聞こう！"]);
  await say(p, "レイ", ["はあ！？ オレ様たちは 今 着いた ばっかりだぞ！"]);
  await battle(p, team(["golem", "sword"], 75, 3, 45), { name: "衛兵長 ガルム", arena: "冤罪！", theme: "desert", speaker: "ガルム", hpk: 40, extra: 0.6, tag: "衛兵長", heal: false,
    scripted: { turns: 2, lines: ["§6§l城の 衛兵たちが 次々と なだれこんできた！", "§7多勢に 無勢…… 仲間たちが 取りおさえられていく！"] }, lines: { half: "抵抗するか！ ますます 怪しい！" } });
  rm(e);
  const d2 = load(p); if (!d2) return false; const s2 = qs(d2); s2.jailRet = ret; save(p, d2);
  // 牢屋へ
  const ow = world.getDimension("overworld"), J = JAIL(p);
  try { showTitle(p, "§8……", { subtitle: "§7目の 前が 真っ暗に なった", fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  await buildJail(ow, J);
  // v2.9.9: とちゅうで ぬけた ときは 牢屋を のこす（もどった とき 空中に 落ちない。もどると 自動で 外へ 出して 片づける）
  try { return await jailInside(p, ow, J); } finally { let valid = false; try { valid = !!p.isValid?.(); } catch {} if (valid && inJail(p)) { try { clearJail(ow, J); } catch {} } }
}
async function jailInside(p, ow, J) {
  try { p.addEffect("slow_falling", 600, { showParticles: false }); p.addEffect("resistance", 600, { amplifier: 4, showParticles: false }); } catch {}
  let floorOk = false; try { floorOk = (ow.getBlock({ x: J.x + 2, y: J.y - 1, z: J.z })?.typeId || "").includes("cobblestone"); } catch {}
  if (!floorOk) {   // 牢屋を 作れなかった ときは その場で 話だけ
    await narr(p, "地下牢", ["§7（あなたは 城の 地下牢に 連れて いかれた……）"]);
    clearJail(ow, J);
  } else try { p.teleport({ x: J.x + 2.5, y: J.y + 0.1, z: J.z + 0.5 }, { dimension: ow, facingLocation: { x: J.x - 3, y: J.y + 1.5, z: J.z + 0.5 } }); } catch {}
  try { p.addEffect("slowness", 400, { amplifier: 2, showParticles: false }); } catch {}
  await wait(30);
  big(p, "§8§lサンドリア城 地下牢", "§7ひんやりした 石の 床……", "random.door_close");
  await narr(p, "地下牢", ["§7石の 壁に 鉄格子。外から 砂の 音が する。", "§f……王墓荒らしに されて しまった。"]);
  await say(p, "牢番", ["おとなしく しておれ。明日の 朝には 裁きが くだる。"]);
  await wait(40);
  sound(p, "random.anvil_land", 0.7);
  await say(p, "レイ", ["（鉄格子の 向こうから）おい、生きてるか？ オレ様は 逃げきったぜ。", "へへ……いい もん 手に 入れてな。体が 軽くて しょうがねえ。", "それと、セオが 真犯人を 見つけたってよ。衛兵に 化けた ノクス団だ。"]);
  await say(p, "ガルム", ["……すまなかった。真犯人は 捕らえた。", "詫びの しるしだ。城の 倉庫から 持って いってくれ。"]);
  const d3 = load(p); if (!d3) return false; const s3 = qs(d3); s3.jailDone = 1;
  s3.keys = [...new Set([...(s3.keys || []), "k_tomb"])];   // v2.9.12: 先に 記録（このあと ぬけても 地図は もどる）
  const got = reward(p, d3, 5000, [["c_herbs", 3], ["g_sp2", 1]]); save(p, d3);
  try { p.removeEffect("slowness"); } catch {}
  releaseJail(p);
  clearJail(ow, J);
  big(p, "§a§l釈放された！", "§f濡れ衣は 晴れた");
  await narr(p, "釈放", ["§a濡れ衣が 晴れて 牢屋から 出られた。", ...got.map((x) => "§e" + x)]);
  return true;
}
// ---------- メインクエスト ----------
// trig: いつ 起きるか（c = 状況）／ key: その だいじなものを 使うと 起きる ／ run: 進めば true
const has = (c, id) => hasKey(c.p, id);
const RIVAL_JOB = 17, TRAITOR_JOB = 18;   // v2.9.13: 作者の スキン（ライバル・学者セオ）
export const MQ = [
  { r: 0, ch: "第1章 旅立ち", hint: "§fライバル §bレイ§f と 最初の 勝負！ §7（負けても もう一度 挑める）", trig: (c) => true,
    run: async (p, d) => {
      if (!qs(d).introDone) {
        await say(p, "オルド", ["よう 来たのう。わしは ルミナの 長老、オルドじゃ。", "その子が おまえさんを 選んだか……。不思議な ものじゃのう。", "8人の §6地方マスター§f に 会い、目覚めた §6主§f を 封じて くれんか。", "……おお、孫の §bレイ§f が 来おった。"]);
        const d1 = load(p); if (d1) { qs(d1).introDone = 1; save(p, d1); }
      }
      const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
      await say(p, "レイ", ["フン、お前が あのチビに 選ばれた やつか。", "オレ様は レイ。いずれ 星冠王に なる 男だ。", "……石板は オレ様が 任される はずだったんだ。勝負しな！"]);
      const res = await battle(p, team(["dragon"], 1, 1, 0).map((t) => ({ ...t, lv: 1, q: 0 })), { name: "ライバル レイ", arena: "はじめての 勝負", easy: true, speaker: "レイ", lines: { half: "チッ……生意気な！", low: "う、ウソだろ……！？" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "レイ", ["ハッ、話に ならねえな！ 出直してきな。", "§7（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）"]); return false; }
      await say(p, "レイ", ["ちっ……まぐれだ、まぐれ！", "次は ぜったい オレ様が 勝つ。覚えてろよ！"]);
      await say(p, "オルド", ["ほっほ、いい 勝負じゃった。あの子は 負けずぎらいでのう。", "まずは §6アルカトラス城§f の マスター §6ミドリ§f の ところへ 行くんじゃ。", "§7→ 右上の 案内へ"]);
      reward(p, d2, 500, [["c_herbs", 2]]); save(p, d2);
      return true;
    } },
  { r: 0, hint: "§fルミナの 町の 外を 歩いて アルカトラス城へ 向かおう", trig: (c) => c.r === 0 && !c.town && c.dist > 110,
    run: async (p, d) => {
      const e = npcNear(p, "§cノクス団の 下っぱ ガロ", 9);
      big(p, "§c！", "§fだれかが 道を ふさいだ！", "mob.villager.no");
      await say(p, "ガロ", ["おっと 待ちな。お前から 石板の 匂いが プンプン するぜ。", "へっ、オレたち §5ノクス団§f が いただくぜ。置いていきな！"]);
      const res = await battle(p, team(["beast", "animal", "animal"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "ノクス団の 下っぱ ガロ", arena: "ノクス団", easy: true, speaker: "ガロ", lines: { half: "ちっ、ガキの くせに やるじゃねえか……！" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "ガロ", ["へっ、ガキが！ 出直してきな！", "§7（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）"]); return false; }
      await say(p, "ガロ", ["お、覚えてやがれ！ ボスに 言いつけて やるからな！"]);
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB);
      await say(p, "セオ", ["大丈夫ですか！？ ……よかった、けがは ないですね。", "僕は セオ。石板を 研究している 学者です。", "あなた、石板に 好かれる 体質ですね。……めずらしい。", "これ、僕の 研究メモです。困ったら 開いて ください。"]);
      rm(eS);
      giveKey(p, d2, "k_note"); reward(p, d2, 300);
      save(p, d2); return true;
    } },
  { r: 0, seal: 0, hint: "§fアルカトラス城の §6地方マスター ミドリ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(0),
    run: async (p, d) => { await gateOpen(p, 1, "セオ", "主の 封印、おめでとうございます！ 森の 匂いが 変わった……シルヴァ大森林への 道が 開いたようですね。僕も 先に 行っています。"); return true; } },
  { r: 1, ch: "第2章 森の 精霊石", hint: "§fシルヴァ大森林へ 行こう", trig: (c) => c.r === 1,
    run: async (p, d) => {
      big(p, "§2§lシルヴァ大森林", "§f木漏れ日の 奥で セオが 手を ふっている");
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB);
      await say(p, "セオ", ["来ましたね！ この 森の 地下の §e洞くつ§f で §d光る 石§f を 見たんです。", "中は 真っ暗なので、これを どうぞ。§6懐中電灯§f です。持っているだけで 明るく なりますよ。", "§7→ 洞くつの 階段を いちばん 下まで（右上の 案内へ）"]);
      rm(eS); giveKey(p, d, "k_light"); save(p, d); return true;
    } },
  { r: 1, hint: "§fシルヴァの §e洞くつ§f に 入って、§e階段を いちばん 下まで§f おりよう §7（右上の 案内で 入口へ。懐中電灯は 持っているだけで よい）", trig: (c) => c.r === 1 && has(c, "k_light") && (c.cave(1) || c.under()),
    run: async (p, d) => {
      big(p, "§d§l光る 石を 見つけた！", "§f懐中電灯の 光に 応えて、石が 脈を 打つ", "random.orb");
      giveKey(p, d, "k_spirit"); save(p, d);   // v2.9.12: 先に わたして から 説明する
      await narr(p, "森の 精霊石", ["§7洞くつの 奥、苔の 下で 緑色の 石が 光っている。", "§f手に 取ると、森の どこかで 何かが 目を さました……", "§7→ §6だいじなもの§7 に 入った。§bシルヴァの ステージ（大地）§7で 使おう"]);
      return true;
    } },
  { r: 1, hint: "§f森の 精霊石を §bシルヴァの ステージ（大地）§f で 使おう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【だいじなもの】）", key: "k_spirit", where: (c) => c.r === 1 && !!c.stage, whereMsg: "§7ここでは 何も 起きない。§fシルヴァの ステージ（大地）§7で 使おう。",
    run: async (p, d) => {
      big(p, "§2§l森の 主が 目を さました！", "§fセオが 駆けつけた", "mob.ravager.roar");
      await say(p, "セオ", ["森の 主が 目を さました……！ 僕も 戦います、一緒に しずめましょう！"]);
      const lv = 22;
      const res = await battle(p, bossOne(["animal", "animal"], lv, 10), { name: "森の 主", arena: "森の 主", theme: "forest", hpk: 2.6, extra: 0.3, tag: "森の主", guests: team(["animal", "animal"], lv - 3, 2).map((t) => ({ ...t, owner: "セオ" })), speaker: "森の 主", lines: { half: "……ゴゴゴ……モリヲ……ケガス……ナ……", low: "……オマエタチ……ナラ……" } });
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "セオ", ["くっ……いったん 引きましょう。仲間を 休ませて、また 精霊石を！"]); return false; }
      const s = qs(d2); s.gate = { ...(s.gate || {}), 1: true };
      const got = reward(p, d2, 3000, [["e_bronze", 1], ["SEED2", 1]]);
      save(p, d2);
      await narr(p, "森の 主を しずめた！", ["§2森の 主は 静かに 森の 奥へ 帰っていった。", ...got.map((x) => "§e" + x)]);
      await gateOpen(p, 2, "セオ", "やりましたね！ 主が 道を 開けて くれました。この 先は ルインズ荒野……。僕は ちょっと 調べものが あるので、後で 合流します。");
      return true;
    } },
  { r: 2, ch: "第3章 荒野の ライバル", hint: "§fルインズ荒野へ 行こう", trig: (c) => c.r === 2,
    run: async (p, d) => {
      const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
      big(p, "§b§lライバル レイ", "§f「見つけたぜ！ 勝負だ！」", "raid.horn");
      await say(p, "レイ", ["よう、遅かったじゃねえか。待ちくたびれたぜ。", "ルミナの 借りを 返しに 来た。今度は 本気だ！"]);
      const lv = 22;
      const res = await battle(p, team(["dragon", "animal", "beast"], lv, 3, 5, leadOf("dragon", lv)), { name: "ライバル レイ", arena: "ライバル", speaker: "レイ", lines: { half: "まだだ！ オレ様の ドラゴンは ここからだぜ！", low: "バ、バカな……押されてるだと……！？" }, heal: true });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "レイ", ["ハッ、まだまだだな！ 鍛えて 出直してこい！", "§7（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）"]); return false; }
      const s = qs(d2); s.reiW = (s.reiW || 0) + 1;
      await say(p, "レイ", ["くそっ……！ また 負けかよ……。", "……なんで あいつは お前を 選んだんだろうな。", "フン、なんでもねえ！ ノクス団なんかに 負けたら 承知しねえぞ！"]);
      await say(p, "オルド", ["（手紙）荒野の 遺跡に §e星の かけら§f が 眠っておる。ノクス団より 先にのう。", "……レイは 元気に しておったか。"]);
      await narr(p, "オルドの 手紙", ["§7遺跡の ボスを 倒すと 星の かけら。2つ目と 5つ目には 石板も。8つで ネクロスの §6終の遺跡§7 が 開く。", "§7→ 遺跡は コンパスで 探せる"]);
      reward(p, d2, 4000, [["e_silver", 1]]); save(p, d2);
      return true;
    } },
  { r: 2, seal: 2, hint: "§fルインズ荒野の §6地方マスター ジン§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(2),
    run: async (p, d) => { await gateOpen(p, 3, "オルド", "（手紙）石板を 二枚も 封じたか。ヴォルカ火山帯への 道が 開いたようじゃ。あそこには ノクス団の 幹部が いると 聞く……気を つけるんじゃぞ。"); return true; } },
  { r: 3, ch: "第4章 炎の 幹部", hint: "§fヴォルカ火山帯の §e町§f を たずねよう", trig: (c) => c.r === 3 && !!c.town,
    run: async (p, d) => {
      const e = npcNear(p, "§cノクス団 幹部 ヴァルカ", 10);
      big(p, "§c§lノクス団 幹部 ヴァルカ", "§f町が 炎に 包まれている……！", "mob.blaze.shoot");
      await say(p, "ヴァルカ", ["アンタが ガロを 泣かせた ガキだね？ アタシは ノクス団 幹部、§c炎の ヴァルカ§f。", "石板を よこしな。燃えカスに なりたく ないならね！"]);
      const lv = 32;
      const res = await battle(p, team(["dragon", "nether"], lv, 3, 12), { name: "ノクス団 幹部 ヴァルカ", arena: "炎の 幹部", theme: "volcano", speaker: "ヴァルカ", lines: { half: "熱いじゃないか……アタシを 本気に させたね！", low: "この アタシが……燃え尽きる……！？" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "ヴァルカ", ["アハハ！ 出直して きな、ガキ！"]); return false; }
      await say(p, "ヴァルカ", ["ちっ……覚えて おきな。", "アタシは §5参謀§f の 言うとおりに 動いてる だけさ。ノクス団は 終わらないよ！"]);
      await say(p, "セオ", ["（遅れて 駆けつけて）すごい……幹部を 退けるなんて。", "……参謀、ですか。（セオの 視線が 一瞬、あなたの 石板に 向いた 気が した）"]);
      reward(p, d2, 6000, [["e_red", 1], ["SEED2", 2]]); save(p, d2);
      return true;
    } },
  { r: 3, seal: 4, hint: "§fヴォルカ火山帯の §6地方マスター カグラ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(4),
    run: async (p, d) => { await gateOpen(p, 4, "セオ", "サンドリア砂漠への 道が 開きました！ 砂の 下に 古い 王墓が あるんです。現地で 地図を 渡しますね。"); return true; } },
  { r: 4, ch: "第5章 砂の 王墓", hint: "§fサンドリア砂漠へ 行こう", trig: (c) => c.r === 4,
    run: async (p, d) => {
      big(p, "§e§lサンドリア砂漠", "§f熱い 風の 中に セオと レイが 待っている");
      // v2.9: 負けイベント（冤罪 → 城の 牢屋）
      if (!qs(d).jailDone) { const ok2 = await jailEvent(p); if (!ok2) return false; d = load(p); if (!d) return false; }
      await say(p, "セオ", ["これが §6王墓の 地図§f です。砂の 下の 入口が 開くはずですよ。", "レイくんには お守りを 渡して おきました。きっと 役に 立ちます。", "§7→ §bサンドリアの ステージ（大地）§7で 地図を 広げよう"]);
      await say(p, "レイ", ["見ろよ、これ。§e星の かけら§f だ。力が あふれて くるぜ……！", "学者が くれたんだ。これで オレ様も 選ばれる側だ。", "王墓の 主？ 上等だ、足を 引っぱるなよ！"]);
      giveKey(p, d, "k_tomb"); save(p, d); return true;
    } },
  { r: 4, hint: "§f王墓の 地図を §bサンドリアの ステージ（大地）§f で 使おう §7（レイと 共闘）", key: "k_tomb", where: (c) => c.r === 4 && !!c.stage, whereMsg: "§7地図の 印は ここでは ない。§fサンドリアの ステージ（大地）§7で 広げよう。",
    run: async (p, d) => {
      big(p, "§6§l王墓が 開いた！", "§f砂の 下から 番人が 起きあがる", "mob.wither.spawn");
      await say(p, "レイ", ["来やがったな！ かけらの 力、見せてやるぜ！"]);
      const lv = 42;
      const res = await battle(p, bossOne(["nether", "golem"], lv, 22), { name: "王墓の 主", arena: "王墓の 主", theme: "ruins", hpk: 3, extra: 0.35, tag: "王墓の主", guests: team(["dragon"], lv - 2, 2).map((t) => ({ ...t, owner: "レイ" })), speaker: "王墓の 主", lines: { half: "……王の 眠りを 妨げる 者よ……", low: "……王よ……お許しを……" } });
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "レイ", ["チッ……一回 引くぞ！ 地図は まだ 使える、もう一度だ！"]); return false; }
      const s = qs(d2); s.gate = { ...(s.gate || {}), 4: true };
      const got = reward(p, d2, 12000, [["e_silver", 1], ["SEED3", 1]]);
      save(p, d2);
      await narr(p, "王墓の 主を 倒した！", ["§6王墓の 奥で、古い 王の 冠が 砂に 還った。", ...got.map((x) => "§e" + x)]);
      await say(p, "レイ", ["へっ、オレ様たちに かかれば こんな もんよ！", "……っ！（レイの 手の 中で かけらが 赤黒く 光った）", "な、なんでもねえよ！ ……もっとだ。もっと 強く なれる……。"]);
      await gateOpen(p, 5, "セオ", "（手紙）クリスタリアへの 道が 開いたようです。水晶の 洞くつに ノクス団が 出入りしていると 聞きました。お気を つけて。");
      return true;
    } },
  { r: 5, ch: "第6章 水晶の 洞くつ", hint: "§fクリスタリアの §e洞くつ§f に 入って、§e階段を いちばん 下まで§f おりよう §7（右上の 案内で 入口へ）", trig: (c) => c.r === 5 && (c.cave(5) || c.under()),
    run: async (p, d) => {
      big(p, "§d§l水晶の 洞くつ", "§fノクス団が だれかを 捕まえている！", "mob.villager.no");
      await say(p, "マリン", ["た、助けて！ わたし、潜水士の マリン！","この 人たちに 捕まっちゃって……！"]);
      await say(p, "ガロ", ["へっ、また お前かよ！","今日は 三人だぜ。逃がさねえぞ！"]);
      for (let k = 0; k < 3; k++) {
        const lv = 40 + k * 3;
        const res = await battle(p, team(["golem", "nether", "animal"], lv, 2 + (k === 2 ? 1 : 0), 8 + k * 4), { name: `ノクス団の 下っぱ（${k + 1}/3）`, arena: "連戦", theme: "cave", speaker: ["ガロ", "ゴロ", "グロ"][k], heal: k === 0 });
        if (res !== "win") { await say(p, "マリン", ["だ、大丈夫！？ あいつら まだ 洞くつに いるよ。","もう一度 来て！"]); return false; }
        if (k < 2) await narr(p, "連戦", [`§a${k + 1}人目を 倒した！ §f次が 来る……！`, "§7（仲間の HP・MPは そのまま）"]);
      }
      const d2 = load(p); if (!d2) return false;
      await say(p, "マリン", ["ありがとう！ お礼に わたしの 予備の §6潜水ゴーグル§f、あげる！","これが あれば 海の 中でも 明るいし、息も 長く 続くよ。","マリノアの 深い 海には §d沈んだ 神殿§f が あるんだ……"]);
      giveKey(p, d2, "k_goggle"); reward(p, d2, 9000, [["e_blue", 1]]); save(p, d2);
      return true;
    } },
  { r: 5, seal: 6, hint: "§fクリスタリアの §6地方マスター ゴウ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(6),
    run: async (p, d) => { await gateOpen(p, 6, "マリン", "マリノア諸島への 道が 開いたって！ 港で 待ってるね！"); return true; } },
  { r: 6, ch: "第7章 海神の 貝笛", hint: "§fマリノア諸島へ 行こう", trig: (c) => c.r === 6,
    run: async (p, d) => {
      const s0 = qs(d);
      if (s0.shellBack) return true;   // 取りかえした あとに 落ちても やりなおさない
      if (!s0.shellLost) {
        big(p, "§b§lマリノア諸島", "§f潮風の 港で マリンが 待っている");
        await say(p, "マリン", ["来た来た！ 港の 長老から 預かった §6海神の 貝笛§f だよ。","ゴーグルを つけて 深い 海で 吹くと、神殿の 番人が 答えるんだって！","§7→ 水面から 6ブロック 以上 もぐって 吹く"]);
        giveKey(p, d, "k_shell"); save(p, d);
        // v2.9: 負けイベント（だいじなものを 奪われる）
        const e = npcNear(p, "§cノクス団 幹部 ヴァルカ", 10);
        big(p, "§c§l！", "§fうしろから 熱風が……！", "mob.blaze.shoot");
        await say(p, "ヴァルカ", ["その 貝笛、いただくよ。参謀さまの 言いつけでね。","この前の 借りも 返すよ。今日の アタシは 本気だよ！"]);
        await battle(p, team(["dragon", "nether"], 70, 3, 40), { name: "ノクス団 幹部 ヴァルカ", arena: "奪われた 貝笛", theme: "beach", speaker: "ヴァルカ", hpk: 30, extra: 0.6, tag: "本気の 幹部", heal: false,
          scripted: { turns: 2, lines: ["§c§lヴァルカの 仲間が 炎の 渦を 起こした！", "§7熱で 視界が ゆがむ…… 仲間たちが 次々と 倒れていく！"] }, lines: { half: "やるねえ……でも ムダだよ！" } });
        rm(e);
        const d2 = load(p); if (!d2) return false; const s2 = qs(d2);
        { const n = countItem(p, "mrpg:k_shell"); if (n > 0) takeItem(p, "mrpg:k_shell", n); } s2.keys = (s2.keys || []).filter((k) => k !== "k_shell"); s2.shellLost = 1; save(p, d2);
        big(p, "§c§l海神の 貝笛を 奪われた！", "§fヴァルカは まだ 近くに いる", "mob.villager.no");
        await narr(p, "奪われた 貝笛", ["§c目を 覚ますと、貝笛が 消えていた。","§fマリン「ごめん……何も できなかった。でも ヴァルカは まだ 近くに いるはず。追いかけよう！」"]);
      }
      // 取りかえす（負けても ここから やりなおせる）
      if (!(await confirm(p, "奪われた 貝笛", "§fヴァルカを 追いかける？\n§7（マリンも いっしょに 戦う）", "追いかける", "あとで"))) return false;
      const e2 = npcNear(p, "§cノクス団 幹部 ヴァルカ", 10);
      await say(p, "ヴァルカ", ["しつこいねえ……！ いいよ、今度こそ 灰に してやるよ！"]);
      const r2 = await battle(p, team(["dragon", "nether"], 50, 3, 18), { name: "ノクス団 幹部 ヴァルカ", arena: "貝笛を 取りかえせ", asked: true, theme: "beach", speaker: "ヴァルカ",
        guests: team(["aqua"], 48, 2).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "なんで…… さっきは 手も 足も 出なかった くせに！", low: "参謀さまに なんて 言えば……！" } });
      rm(e2);
      const d3 = load(p); if (!d3) return false;
      if (r2 !== "win") { await say(p, "マリン", ["くっ……一度 港で 立てなおそう！","貝笛は ぜったい 取りかえすよ！"]); return false; }
      const s3 = qs(d3); s3.shellLost = 0; s3.shellBack = 1; giveKey(p, d3, "k_shell"); save(p, d3);
      big(p, "§b§l海神の 貝笛を 取りかえした！", "§fもう 二度と はなさない");
      await say(p, "マリン", ["やった、取りかえした！","……ねえ、ヴァルカの 言ってた『参謀』って 誰なんだろう。","§7→ ゴーグルを つけて 深い 海で 貝笛を 吹く"]);
      return true;
    } },
  { r: 6, hint: "§fゴーグルを 持って §b海の 深く（水面から 6以上）§f で 海神の 貝笛を 吹こう §7（深い 海が 見つからない ときは マリノアの ステージ（大地）でも 吹ける）", key: "k_shell", where: (c) => c.r === 6 && (c.depth() >= 6 || !!c.stage), whereMsg: "§7ここでは 音が 響かない。§fマリノアの 海の 深く（水面から 6ブロック 以上）§7で 吹こう。",
    pre: (c) => (has(c, "k_goggle") ? null : "§7暗くて 何も 見えない……潜水ゴーグルが 必要だ。"),
    run: async (p, d) => {
      big(p, "§3§l沈んだ 神殿の 番人", "§f貝笛の 音が 海の 底へ 響いた", "mob.elderguardian.curse");
      const lv = 52;
      const res = await battle(p, bossOne(["aqua"], lv, 30), { name: "神殿の 番人", arena: "沈んだ 神殿", theme: "beach", hpk: 3, extra: 0.4, tag: "神殿の番人", speaker: "神殿の 番人", lines: { half: "……海ノ 誓イヲ……知ル者カ……", low: "……認メヨウ……陸ノ 子ヨ……" } });
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await narr(p, "沈んだ 神殿", ["§7番人は 海の 底へ 消えた。§f貝笛は まだ 使える。"]); return false; }
      giveKey(p, d2, "k_crest");
      const got = reward(p, d2, 18000, [["e_rainbow", 1], ["SEED3", 1]]); save(p, d2);
      await narr(p, "潮の 紋章", ["§3番人は あなたを 認め、§6潮の 紋章§3 を 託した。", ...got.map((x) => "§e" + x)]);
      return true;
    } },
  { r: 6, seal: 8, hint: "§fマリノア諸島の §6地方マスター ナギサ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(8),
    run: async (p, d) => { await gateOpen(p, 7, "セオ", "ネクロス冥府領への 道が 開きましたね。……そこで 待っています。大事な 話が あるんです。"); return true; } },
  { r: 7, ch: "第8章 学者の 正体", hint: "§fネクロス冥府領へ 行こう", trig: (c) => c.r === 7,
    run: async (p, d) => {
      const e = npcNear(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB), eR = npcNear(p, "§5ノクス団 レイ", RIVAL_JOB);
      big(p, "§5§l裏 切 り", "§fセオが 黒い 外套を まとっている……", "mob.wither.spawn");
      await say(p, "セオ", ["来て くれましたね。石板を ここまで 集めて くれて、ありがとう。","僕の 正体は §5ノクス団の 参謀§f です。ガロも ヴァルカも、僕の 指示です。","封印は いつか 必ず 切れる。なら、こちらで 目覚めさせて 終わらせる。","……レイくん。かけらの 力、見せて ください。"]);
      await say(p, "レイ", ["……悪いな。かけらが もっと 力を くれるってよ。", "今の オレ様は §5ノクス団§f だ。来いよ！"]);
      const lv = 58;
      // v3.0: 星の かけらに 呑まれた レイと 戦う（セオは 見ている だけ。セオとの 戦いは 竜骨の 祭壇で）
      const res = await battle(p, team(["dragon", "nether", "dragon"], lv, 4, 26, leadOf("dragon", lv)), { name: "ノクス団 レイ", arena: "裏切り", theme: "soulvalley", speaker: "レイ", lines: { half: "まだだ……かけらが もっと よこせって 言ってんだよ！", low: "なんで……なんで お前ばっかり……！" } });
      rm(e); rm(eR);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "セオ", ["ふふ……かけらの 力は こんな ものでは ありませんよ。","§7＞ ガイドブック ＞ ストーリー ＞「物語の 戦いに 再挑戦」"]); return false; }
      const s = qs(d2); s.theoBetray = true;
      await say(p, "セオ", ["……かけらが 割れましたか。器には 足りませんでしたね。","僕は §6ラグナ§f の 竜骨の 祭壇へ 行きます。……では。"]);
      await say(p, "レイ", ["器……？ オレ様は ただの 試し だったってのか。","選ばれる側に なれるって……全部 うそ かよ。","……くそっ。セオの やつは、オレ様が 止める。"]);
      reward(p, d2, 20000, [["e_rainbow", 1]]); save(p, d2);
      return true;
    } },
  { r: 7, seal: 10, hint: "§fネクロス冥府領の §6地方マスター ヨミ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(10),
    run: async (p, d) => { await gateOpen(p, 8, "レイ", "フロストヘイムへの 道が 開いたぜ！ ノクス団の 双子が 待ち伏せしてるらしい。……今回だけ 組んでやる、ありがたく 思え！"); return true; } },
  { r: 8, ch: "第9章 双子の 幹部", hint: "§fフロストヘイム雪山へ 行こう §7（レイと 共闘）", trig: (c) => c.r === 8,
    run: async (p, d) => {
      const e = npcNear(p, "§9ノクス団 双子の 幹部 ロウ＆ルウ", 10);
      big(p, "§9§l双子の 幹部", "§f吹雪の 中から 二つの 影", "mob.polarbear.warning");
      await say(p, "ロウ", ["ここは 通さない。","セオさまの 儀式の じゃまは させない。"]);
      await say(p, "ルウ", ["あれ、レイだ！ そっちに ついたんだね。","二人 なら ちょうど いいや。ボクたちも 二人！"]);
      await say(p, "レイ", ["うるせえ！ オレ様は もう ノクス団じゃねえ！","行くぞ、足 引っぱるなよ！"]);
      const lv = 66;
      const res = await battle(p, team(["beast", "aqua", "dragon"], lv, 4, 34), { name: "双子の 幹部 ロウ＆ルウ", arena: "双子の 幹部", theme: "snow", speaker: "ロウ＆ルウ", guests: team(["dragon", "animal"], lv, 2, 20).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "ルウ、合わせるよ！ ――うん、ロウ！", low: "そんな……ボクたちの 連携が……！" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "レイ", ["くそっ……今のは オレ様の ミスだ。もう一回 行くぞ！"]); return false; }
      await say(p, "ルウ", ["……セオさまは、ほんとは やさしい 人なんだ。","石板の 声を 聞いてから、おかしく なっちゃった……"]);
      reward(p, d2, 26000, [["e_king", 1], ["SEED3", 2]]); save(p, d2);
      return true;
    } },
  { r: 8, seal: 12, hint: "§fフロストヘイムの §6地方マスター シデン§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(12),
    run: async (p, d) => { await gateOpen(p, 9, "オルド", "（手紙）ラグナへの 道が 開いた。セオという 若者……石板の 声に 呑まれておる。救えるのは、呑まれなかった おまえさんだけじゃ。わしも 行こう。"); return true; } },
  { r: 9, ch: "第10章 竜骨の 決戦", hint: "§f終焉の地 ラグナへ 行こう §7（レイ・オルドと 共闘）", trig: (c) => c.r === 9,
    run: async (p, d) => {
      const e = npcNear(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB);
      big(p, "§4§l決 戦", "§f竜の 骨の 祭壇で、セオが 石板を 掲げている", "mob.enderdragon.growl");
      await say(p, "セオ", ["来ましたね。見て ください、王の 眷属が もう 目覚めている。","あとは 器だけ。……あなたです。","さあ、石板の 声を 聞いて。じゃまを するなら、眷属ごと お相手します！"]);
      await say(p, "オルド", ["レイ、よう 来てくれたのう。","セオよ。石板の 声は やさしい ふりを する。……今なら まだ 戻れるぞ。"]);
      await say(p, "レイ", ["……じいちゃん。オレ様、間違ってた。", "話は あとだ。今は セオを 止める！"]);
      await say(p, "レイ", ["聞くな！ その 声に 耳を かすんじゃねえ！","オレ様は 一度 呑まれた。……こいつまで 渡すかよ。","目を 覚ましやがれ、セオ！"]);
      const lv = 74;
      const foe = [...bossOne(["nether", "dragon"], lv, 40, 1), ...team(["nether", "nether"], lv, 2, 30)];
      const res = await battle(p, foe, { name: "参謀 セオと 王の 眷属", arena: "竜骨の 祭壇", theme: "endcity", hpk: 2.2, extra: 0.35, tag: "王の眷属", speaker: "セオ", guests: [...team(["dragon"], lv, 1, 30).map((t) => ({ ...t, owner: "レイ" })), ...team(["beast", "animal"], lv, 1, 30).map((t) => ({ ...t, owner: "オルド" }))], lines: { half: "どうして……どうして 届かないんだ……！", low: "あたたかい……これが、仲間の 力……？" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "オルド", ["……退くぞ！ 立てなおして、もう一度じゃ！"]); return false; }
      await say(p, "セオ", ["……ああ。頭の 中の 声が、消えた。","僕は……なんて ことを。ごめん なさい。","王冠の 石板は、星冠王 ゼファードが 持っています。……あなたなら、きっと。"]);
      const s = qs(d2); s.theoSaved = true;
      const got = reward(p, d2, 40000, [["e_king", 1], ["i_awaken", 1], ["SEED3", 2]]); save(p, d2);
      await narr(p, "ノクス団 解散", ["§dノクス団は 解散した。セオは オルドの もとで 一から 学び直す ことに なった。", ...got.map((x) => "§e" + x)]);
      return true;
    } },
  { r: 9, seal: 13, hint: "§fラグナの §6地方マスター ソラ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(13),
    run: async (p, d) => { await gateOpen(p, 10, "レイ", "セレスティア天空郷への 道が 開いたな。……先に 行って 待ってるぜ。星冠王の 前に、オレ様と 最後の 勝負だ！"); return true; } },
  { r: 10, ch: "第11章 最後の ライバル", hint: "§fセレスティア天空郷へ 行き、ライバル §bレイ§f と 最後の 勝負", trig: (c) => c.r === 10 || c.s.ending,
    run: async (p, d) => {
      if (qs(d).ending) return true;
      big(p, "§6§lセレスティア天空郷", "§f雲の 上で レイが 待っている");
      const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
      await say(p, "レイ", ["来たな。ここなら じゃまは 入らねえ。","かけらも 何も なしの オレ様で、お前と ケリを つける。","手加減は なしだぜ！"]);
      const lv = 80;
      const res = await battle(p, team(["dragon", "animal", "beast"], lv, 4, 36, leadOf("dragon", lv)), { name: "ライバル レイ（最後の 勝負）", arena: "最後の ライバル戦", theme: "sky", speaker: "レイ", lines: { half: "まだだ……オレ様の 全部を 出しきる！", low: "……ハハ、やっぱ お前は すげえよ。" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "レイ", ["どうした、そんなもんか？ 星冠王は オレ様より 強えぞ。出直してこい！"]); return false; }
      const s = qs(d2); s.reiW = (s.reiW || 0) + 1; s.reiFinal = 1;
      await say(p, "レイ", ["……完敗だ。お前が 選ばれた わけ、やっと わかったぜ。","オレ様は ルミナに 帰る。じいちゃんと 町を 守るのは、オレ様が 決めた 役目だ。","行けよ。§c星冠王§f に 勝つ ところ、見せろよな。","§7→ §cルミナの 闘技場§7 で カップを 勝ちぬく"]);
      reward(p, d2, 30000, [["e_king", 1], ["SEED3", 1]]); save(p, d2);
      return true;
    } },
  { r: 99, ch: "終章 星冠王", hint: "§f闘技場の カップを ぜんぶ 勝って §c星冠王§f に 挑もう。石板を ぜんぶ 封印したら 王冠の 石板へ §7（進み具合は ガイドブック ＞ ストーリー）", trig: (c) => !!c.s.ending,
    run: async (p, d) => {
      await say(p, "オルド", ["ようやったのう。ゼファードどのも、封印を おまえさんに 託すと 言うて おった。","……ところで、§5古い 神殿§f の あたりで 悪い 夢を 見る 者が おるそうじゃ。","闘技場の 奥に いる §e伝説の マスター§f なら、何か 知って おるかも しれんのう。"]);
      return true;
    } },
  { r: 99, ch: "魔神編", hint: "§f伝説の マスター カゲツ（裏ボス）に 勝とう §7（ルミナの 闘技場）", trig: (c) => has(c, "k_hilt") && !!c.s.hiltGot,
    run: async (p, d) => {
      big(p, "§4§l魔神編", "§f赤黒く 光る 鍔が、持ち主を 呼んでいる", "mob.wither.spawn");
      await narr(p, "魔神の鍔", ["§4カゲツに 託された 鍔が、赤黒く 脈を 打つ……", "§f「クロガネに いる 弟子の ムサシを たずねろ」", "", "§e→ §fはがねの 村 §eクロガネ§f で §cムサシ§f を さがそう §7（右上の 案内）"]);
      return true;
    } },
  { r: 99, hint: "§fカゲツの 弟子 §cムサシ§f を さがそう §7（はがねの 村 クロガネに いる 武士に 話しかける）", trig: (c) => !!c.s.musashiJoin,
    run: async (p, d) => true },
  { r: 99, hint: "§fムサシと §5閻魔の神殿§f へ 行き、魔神の鍔を 捧げよう §7（神殿の 前で ガイドブックを 使う）", trig: () => false, run: async () => false },
];
const POST = MQ.findIndex((x) => x.r === 99);
async function gateOpen(p, r, who, line) {
  big(p, "§a§l道が 開けた！", `§f${RN(r)}へ 行けるように なった`, "ui.toast.challenge_complete");
  particle(p, "minecraft:totem_particle", 1.5);
  if (who) await say(p, who, [line]);
}

// 前の バージョンの セーブ・チート: いまの 進みに あわせて 手順を 決める（だいじなもの も そろえる）
function fixMq(p, d) {
  const s = qs(d);
  // v2.9.13: 物語と 地方の 進みが そろって いる セーブは 順番を 守る（古い セーブで 物語が 遅れて いる ときは そのまま）
  if ((s.kg || 0) >= 1 && !s.hiltGot) { s.hiltGot = true; s.keys = [...new Set([...(s.keys || []), "k_hilt"])]; return true; }
  if (s.hiltGot && !(s.keys || []).includes("k_hilt")) { s.keys = [...(s.keys || []), "k_hilt"]; return true; }   /* v2.9.13: 前の 版で カゲツに 勝った 人 */
  /* v2.9.14: 前の 版で ムサシ（カゲツ）・エンマを 仲間に した 人は 魔神編を すませた ことに */
  if (!s.musashiJoin && (s.kg || 0) >= 1 && (d.own || []).includes(SPECIES.musashi?.idx)) { s.musashiJoin = 1; return true; }
  if (!s.enmaClear && s.enmaJoin) { s.enmaClear = 1; s.musashiJoin = 1; return true; }
  if (!s.ord && s.mq !== undefined && !s.ending && storyOpen(s) >= sealOpen(s)) { s.ord = 1; return true; }
  if (s.ending && (s.mq === undefined || s.mq < POST)) { s.mq = POST; for (const k of ["k_note", "k_light", "k_goggle"]) if (!(s.keys || []).includes(k)) giveKey(p, d, k); return true; }
  if (s.mq !== undefined) return false;
  const u = openUpTo(d);
  let i = 0;
  if (u > 0) { i = MQ.findIndex((x) => x.r >= u); if (i < 0) i = POST; if (i > 0 && MQ[i].r === u && MQ[i - 1].r === u) i--; }
  s.mq = Math.max(0, i);
  if (u >= 1) { for (const k of ["k_note"]) if (!(s.keys || []).includes(k)) giveKey(p, d, k); }
  if (u >= 2) giveKey(p, d, "k_light");
  if (u >= 6) giveKey(p, d, "k_goggle");
  return true;
}
// v2.9.10: いまの 目標と その 場所（画面の 下と チャットに 出す）
// v2.9.12: カゲツは 終の遺跡を こえるまで 出ない ので、それまでは 遺跡を 案内する
const KAGETU_PRE = "§fネクロスの §6終の遺跡§f を こえよう（遺跡を 8つ こえると 開く）。そのあと ルミナの 闘技場で 伝説の マスターに 挑もう";
function hintOf(st, d) { const h = hintOf0(st, d); const s = qs(d); return s.mqHold && s.mqHold.i === (s.mq ?? 0) && st && st.trig ? `${h} §e（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）` : h; }
function hintOf0(st, d) {
  if (st && st.r === 99 && /カゲツ/.test(st.hint) && !postOpen(d)) return KAGETU_PRE;
  if (st && st.r === 99 && /カップ/.test(st.hint)) {   // v2.9.13: 終章は 進み具合で 書きかえる（カップ → 星冠王 → 石板の 封印 → 石板の王）
    const s = qs(d), n = (s.bs || []).length;
    if (!s.final) return `§fルミナの 闘技場で カップを 勝ちぬき §c星冠王§f に 挑もう §7（カップ ${Math.min(8, s.cup || 0)}/8。ポイントは フィールドの モンスターマスターに 勝って 集める）`;
    if (n < BS_N - 1) return `§fのこりの 石板で 主を 封印しよう §7（封印 ${n}/${BS_N - 1}。ぜんぶ 封じると 王冠の 石板が 目を さます。石板は カップ・遺跡でも 手に入る）`;
    if (!s.bsFinal) return "§c王冠の 石板§f で §c石板の王§f に 挑もう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【特別な石板】）";
  }
  // v2.9.13: マスターに 勝って 石板を もらったら、次は その 石板で 主を 封印（どこでも 使える）
  if (st && typeof st.seal === "number") { const s = qs(d); if ((s.bsg || []).includes(st.seal) && !(s.bs || []).includes(st.seal)) return `§fもらった §d石板§f で ${WREGIONS[st.r].short}の §6主§f を 封印しよう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【特別な石板】）`; }
  return st ? st.hint : "";
}
// v2.9.13: 章ごとの あらすじ（たどりついた 章だけ 見せる）
const SYNOPSIS = {
  "第1章 旅立ち": "ルミナの 長老 オルドの もとで 最初の 仲間に 選ばれた。千年前に 石板へ 封じられた 古い 王の 力が ゆるみ、各地で「主」が 目覚めはじめて いる。8人の 地方マスターに 認められ、主を 封じ直しながら 闘技場の 頂点 星冠王を 目指す 旅が 始まった。石板を 託される はずだった オルドの 孫 レイは、くやしさを かくして 勝負を しかけて きた。",
  "第2章 森の 精霊石": "シルヴァ大森林で 学者 セオと 出会い、洞くつの 奥で 森の 精霊石を 見つけた。目覚めかけて いた 森の 主を、セオと 力を あわせて しずめた。",
  "第3章 荒野の ライバル": "ルインズ荒野で レイと ふたたび 戦った。ノクス団が 遺跡に 眠る 星の かけらを ねらって いる ことを 知った。",
  "第4章 炎の 幹部": "ヴォルカの 町を ノクス団 幹部 ヴァルカが 襲った。退けた とき、ヴァルカは「参謀」の 名を もらした。",
  "第5章 砂の 王墓": "王墓荒らしの 濡れ衣を 晴らした あと、王墓に 現れた レイと 組んで 主を 倒した。レイの 手には、学者に もらったと いう 星の かけらが 光って いた。",
  "第6章 水晶の 洞くつ": "クリスタリアの 洞くつで ノクス団に 捕まった 潜水士 マリンを 助け、潜水ゴーグルを もらった。",
  "第7章 海神の 貝笛": "マリノアで ヴァルカに 奪われた 海神の 貝笛を マリンと 取りかえし、沈んだ 神殿の 番人に 認められた。",
  "第8章 学者の 正体": "ネクロスで、セオが ノクス団の 参謀だと 明かした。かけらに 呑まれた レイと 戦い、勝つと かけらは 割れた。セオは ラグナへ 去り、レイは 利用されて いたと 知った。",
  "第9章 双子の 幹部": "立ち直った レイと 組んで、雪山で 待ちぶせて いた 双子の 幹部を 退けた。セオは 石板の 声に 呑まれかけて いると いう。",
  "第10章 竜骨の 決戦": "ラグナの 竜骨の 祭壇で、レイ・オルドと ともに セオを 止めた。石板の 声から レイが かばって くれた。セオは 正気に もどり、ノクス団は 解散した。",
  "第11章 最後の ライバル": "天空郷で、レイと 対等な 相手として 最後の 勝負を した。レイは ふるさと ルミナを 守ると 決めた。",
  "終章 星冠王": "最後の 封印者 星冠王 ゼファードの 試験に 挑み、王冠の 石板に 眠る 古い 王と 向きあう。",
};
export function synopsisText(d) {
  const s = qs(d), i = s.mq ?? 0, cur = chapterOf(d), L = ["§l§eこれまでの あらすじ", "§7（たどりついた 章だけ）", ""];
  for (let k = 0; k <= Math.min(i, MQ.length - 1); k++) {
    const ch = MQ[k].ch; if (!ch || !SYNOPSIS[ch] || !(k < i || s.chSeen === k)) continue;
    if (ch === cur && k >= i) { L.push(`§6§l${ch} §a（いま ここ）`, "§7（この 章の お話は これから……）", ""); continue; }   // v2.9.13: まだ 起きて いない ことは 書かない
    L.push(`§6§l${ch}${ch === cur ? " §a（いま ここ）" : ""}`, `§f${SYNOPSIS[ch]}`, "");
  }
  return L.join("\n");
}
export function chapterOf(d) { const s = qs(d), i = s.mq ?? 0; for (let k = Math.min(i, MQ.length - 1); k >= 0; k--) if (MQ[k].ch && (k < i || s.chSeen === k || (k === POST && i === POST))) return MQ[k].ch; return ""; }   // v2.9.13: 始まった 章だけ
// uxprog68: クリア後の 目標（まだ 勝って いない 城の 王 → 近い 順）
function postGoal(p, d) {
  const s = qs(d); if (!s.ending) return null;
  const kw = s.kgw || {}, left = WREGIONS.map((R, i) => i).filter((i) => !kw[i]);
  if (!left.length) {   // 王を みな 倒した あと: 使って いない 神の石板 → カゲツ（40勝まで）
    const dg = s.dg || {}, own = (Array.isArray(s.dgs) ? s.dgs : []).filter((gi) => !dg[gi]);
    if (own.length) return { text: `神の石板で 神を 鎮めよう（まだ 仲間に して いない 神 ${own.length}柱・仲間にした 神 ${Object.keys(dg).length}/15）`, name: "", near: "", x: null, z: null, key: `dg${own.length}` };
    if ((s.kg || 0) < 40) { const t = TOWNS.find((t) => t.id === "t0"), tp = t ? townPos(t) : null; return { text: `カゲツに 勝って 神の石板を（あと ${10 - ((s.kg || 0) % 10)}勝）`, name: "ルミナの 闘技場", near: "§a闘技場の カゲツに 話しかけよう", x: tp ? tp.x : null, z: tp ? tp.z : null, key: `kgx${s.kg || 0}` }; }
    return null;
  }
  let best = null; for (const i of left) { const c = castleInfo(i) || castleSpot(i); if (!c) continue; const dd = Math.hypot(p.location.x - c.x, p.location.z - c.z); if (!best || dd < best.dd) best = { i, c, dd }; }
  if (!best) return null;
  return { text: `城の 王に 勝って 神の石板を（${WREGIONS.length - left.length}/${WREGIONS.length}）`, name: WREGIONS[best.i].castle.name, near: "§a城の 奥の 王に 話しかけよう", x: best.c.x, z: best.c.z, key: `kg${left.length}` };
}
export const GOAL_HOOKS = [];   /* 第76版: 追加ストーリーの 目標（null で ふつうの 目標） */
export function storyTarget(p, d) {
  for (const h of GOAL_HOOKS) { try { const g = h(p, d); if (g) return g; } catch {} }
  const s = qs(d), st = MQ[s.mq ?? 0];
  if (!st || (st.r === 99 && s.enmaClear && /閻魔/.test(st.hint))) return postGoal(p, d);   // uxprog68: 物語の あとは 城の 王・神の石板へ
  const text = String(hintOf(st, d) || "").replace(/§./g, "").replace(/\s+/g, " ").trim();
  const R = Math.max(0, Math.min(WREGIONS.length - 1, st.r ?? 0));
  const me = p.location; let here = -1; try { here = regAt(me); } catch {}
  let pos = null, name = "", near = "";
  try {
    const cv = /洞くつ/.test(text) && CAVE_R.includes(R) ? caveInfo(R) : null;
    if (st.r === 99) {   // v2.9.12: クリア後は 天空郷では なく 本当の 場所へ
      if (/閻魔/.test(text)) { if (s.enmaClear) return null; const a = altarInfo(); if (a) { pos = a; name = "閻魔の神殿"; } }
      else if (/クロガネ/.test(text)) { const M = musashiTownInfo(); if (M) { pos = M.pos; name = M.t.name; } }
      else if (/終の遺跡/.test(text)) { const a = rfInfo(); if (a) { pos = a; name = "終の遺跡"; } else { const c = castleInfo(7) || castleSpot(7); if (c) { pos = c; name = WREGIONS[7].name; } } }
      else if (/星冠王/.test(text)) { const t = TOWNS.find((t) => t.id === "t0"); if (t) { pos = townPos(t); name = "ルミナの 闘技場"; } }
      else if (/カゲツ/.test(text) && postOpen(d)) { const t = TOWNS.find((t) => t.id === "t0"); if (t) { pos = townPos(t); name = "ルミナの 闘技場"; } }
    }
    else if (cv && cv.built) {   // v2.9.12: 洞くつの 中では 奥の 広間を 指す・入口の 近くでは「階段を 下まで」
      const me2 = p.location, inside = me2.y < cv.y - 3 && Math.abs(me2.x - cv.x) < 10 && me2.z > cv.z - 6 && (!cv.hall || me2.z < cv.hall.z + 14);
      if (inside && cv.hall) { pos = cv.hall; name = "洞くつの 奥"; near = "§a奥の 広間へ すすもう"; }
      else { pos = cv; name = `${WREGIONS[R].short}の 洞くつ`; near = "§a入口の 階段を 下まで おりよう"; }
    }
    else if (/洞くつ/.test(text) && CAVE_R.includes(R)) { const c = caveSite(R); pos = { x: c.x, y: 64, z: c.z + 20 }; name = `${WREGIONS[R].short}の 洞くつ`; }   // v2.9.12: まだ できて いない ときも 場所を 指す
    else if (/ステージ|大地/.test(text)) {
      // v2.9.12: 目的地が ぶれない ように いつも 同じ ステージ（できて いる ものを 優先・地方の 中で 決まった 順）
      let best = null; for (const L of landSites(R)) { const I = landInfo(L.key); if (I && I.skip) continue; const sc = I && I.built ? 0 : 1; if (!best || sc < best.sc) best = { ...L, sc, nm: (I && I.name) || "ステージ" }; }
      if (best) { pos = best; name = best.nm; }
    } else if (/もらった/.test(text)) {
      pos = null;   /* 第67版: もらった あとは 城を 指さない（石板は どこでも 使える） */
    } else if (/城|地方マスター|王さま|王様/.test(text)) {
      const c = castleInfo(R) || castleSpot(R); if (c) { pos = c; name = WREGIONS[R].castle.name; }
    } else if (/洞くつ|地下|海|水|歩いて|外を/.test(text) && here === R) {
      pos = null;   // その 地方の 中で する こと（場所は 自由）
    } else if (here !== R && !/町/.test(text)) {
      const c = castleInfo(R) || castleSpot(R); if (c) { pos = c; name = WREGIONS[R].name; }
    } else if (/町/.test(text)) {   // v2.9.12: 町が 目的地なら 地方の 外からでも その 町を 指す（ぶれない）
      let t = TOWNS.find((t) => text.includes(t.name.replace(/の 町|の 村/, "")));
      if (!t) { const c0 = castleInfo(R) || castleSpot(R); let bd = 1e18; for (const u of TOWNS) { const q = townPos(u); if (regAt(q) !== R) continue; const dd = (q.x - c0.x) ** 2 + (q.z - c0.z) ** 2; if (dd < bd) { bd = dd; t = u; } } }   // 城に いちばん 近い 町（いつも 同じ）   // v2.9.12: 名前の ない「町」は いちばん 近い その 地方の 町
      if (t) { pos = townPos(t); name = t.name; }
    }
  } catch {}
  return { text, name, near, x: pos ? pos.x : null, z: pos ? pos.z : null, key: `${s.mq ?? 0}` };
}
export function sagaHint(d) {
  const s = qs(d);
  const st = MQ[s.mq ?? 0];
  const L = [];
  { const ch = chapterOf(d); if (ch) L.push(`§d§l${ch}`); }
  if (st && !(st.r === 99 && /閻魔/.test(st.hint) && s.enmaClear)) L.push(`§6【メイン】§r${hintOf(st, d)}`);
  const g = gateHint(d); if (g) L.push(g);
  return L.join("\n");
}

// ---------- だいじなもの を 使う ----------
export async function useKey(p, d, id) {
  if (!d) return;
  const it = ITEMS[id], s = qs(d);
  if ((s.mqPaid ?? -1) === (s.mq ?? 0) && (s.mq ?? 0) < MQ.length - 1) { s.mq = (s.mq ?? 0) + 1; save(p, d); }   // v2.9.12
  const st = MQ[s.mq ?? 0];
  const c = ctx(p, d);
  if (st && st.key === id) {
    if (st.pre) { const m = st.pre(c); if (m) { await notice(p, it.name, m); return; } }
    if (!st.where(c)) { await notice(p, it.name, `${it.desc || ""}\n\n${st.whereMsg}`); return; }
    let done = false;
    EVT.add(p.id);   // v2.9.2: だいじなもの から 始まった できごとの あいだも ほかの できごとを 止める
    MQASK.add(p.id); MQRUN.add(p.id); MQRUN_KEY.add(p.id);
    try { done = await st.run(p, d); } catch (e) { if (e === LATER) { laterClean(p); } else console.warn(`[MonsterRPG] saga key: ${e} ${e?.stack || ""}`); } finally { EVT.delete(p.id); MQASK.delete(p.id); MQRUN.delete(p.id); MQRUN_KEY.delete(p.id); SPAWNED.delete(p.id); }
    { const dx = load(p); if (!done && dx && qs(dx).mqPaid === MQ.indexOf(st)) done = true; }
    if (!done) try { p.sendMessage("§7準備が できたら、もう一度 だいじなものを 使おう。§8（右上の 案内が 場所を 教えて くれる）"); } catch {}
    const d2 = load(p); if (d2 && done) { const s2 = qs(d2); if ((s2.mq ?? 0) === MQ.indexOf(st)) { s2.mq = MQ.indexOf(st) + 1; save(p, d2); } }
    return;
  }
  if (id === "k_note") { await notice(p, it.name, ["§a§lセオの 研究メモ", "", sagaHint(d), "", `§7行ける 地方: ${WREGIONS.slice(0, Math.min(WREGIONS.length, openUpTo(d) + 1)).map((R) => R.short).join("・")}`].join("\n")); return; }
  if (id === "k_light" && st && (st.r === 1 || st.r === 5) && /洞くつ/.test(st.hint)) { await notice(p, it.name, "§f懐中電灯は 持っているだけで 光る。\n§e右上の 案内の 洞くつの 入口から、階段を 下まで おりよう。"); return; }   /* v2.9.12 */
  if (id === "k_hilt") {   // v3.0: すすみぐあいで 言うことを かえる（先の 物語を 明かさない）
    const s = qs(d);
    const t = s.enmaClear ? "§f戦いの 中で ムサシに 使うと、鍔の 力を 借りられる。§7（ガイドブック →「魔神の鍔を 使う」）"
      : s.musashiJoin ? "§fムサシと いっしょに §5閻魔の神殿§f へ 行こう。§7（神殿の 前で ガイドブックを 使う）"
      : s.hiltGot ? "§fカゲツの 弟子 §cムサシ§f を たずねよう。§7（はがねの 村 §eクロガネ§7）" : "§f鍔は 何かを 呼んで いる……";
    await notice(p, it.name, `§c赤黒く 光る 鍔。カゲツの 家が 千年 守ってきた ものだ。\n\n${t}`); return;
  }
  await notice(p, it.name, `§6だいじなもの§r\n${it.desc || ""}`);
}

// ---------- 状況 ----------
function ctx(p, d) {
  const s = qs(d), l = p.location, sp = SP();
  let u, dp, tw, sg;
  return {
    p, d, s, r: p.dimension.id === "minecraft:overworld" ? regAt(l) : -1, dist: Math.hypot(l.x - sp.x, l.z - sp.z),
    get town() { return tw === undefined ? (tw = townAt(l, 38) || null) : tw; },
    get stage() { return sg === undefined ? (sg = stageNear(p) || null) : sg; },
    under: () => (u === undefined ? (u = underground(p)) : u),
    cave: (R) => inCave(p, R),
    depth: () => (dp === undefined ? (dp = depthOf(p)) : dp),
  };
}

// ---------- NPCの からみ（ランダム）・ライバル・ステージの 番人 ----------
async function rival(p, d, r) {
  const s = qs(d);
  const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
  big(p, "§b§lライバル レイ", "§f「よう、また 会ったな！」", "raid.horn");
  // v2.9: 勝負は 自分で えらぶ（断っても あとで また 会える）
  if (!(await confirm(p, "ライバル レイ", "§b§lレイ§r\n\n§f「勝負しろ！ ……なんだ、今は 忙しいのか？」", "勝負する", "また 今度"))) { await say(p, "レイ", ["フン、逃げるのか？ まあいい、次は 逃がさねえからな！"]); rm(e); const d2 = load(p); if (d2) { const s2 = qs(d2); s2.reiT = Date.now(); save(p, d2); } return; }
  await say(p, "レイ", [pick(["ここで 会ったが 百年目だ！ 勝負しろ！", "オレ様は この 地方で 特訓してたんだ。見せてやるよ！", "お前に 勝つ ために ドラゴンと 毎日 鍛えてんだ。行くぜ！"])]);
  const lv = Math.min(100, WREGIONS[r].lv[1] + 2);
  const res = await battle(p, team(["dragon", "animal", "beast"], lv, 3, 8 + (s.reiW || 0) * 4, leadOf("dragon", lv)), { name: "ライバル レイ", arena: "ライバル", speaker: "レイ", lines: { half: "まだまだ！ 本番は ここからだ！" } });
  rm(e);
  const d2 = load(p); if (!d2) return;
  const s2 = qs(d2);
  if (res === "win") { s2.reiR = [...new Set([...(s2.reiR || []), r])]; s2.reiW = (s2.reiW || 0) + 1; } else s2.reiT = Date.now();   // v2.9.13: 負けたら また 会える
  await say(p, "レイ", [res === "win" ? pick(["くっそー！ また 負けた！ 次こそ ぶっ倒す！", "……チッ、強く なりやがって。"]) : pick(["ハッ、オレ様の 勝ちだ！ 悔しけりゃ また 来い！", "どうだ、特訓の 成果だぜ！"])]);
  reward(p, d2, res === "win" ? 3000 + lv * 120 : 500, res === "win" ? [[pick(["e_silver", "e_red", "e_blue", "SEED2"]), 1]] : []); save(p, d2);
}
async function stageGuard(p, d, st) {
  const s = qs(d);
  const lv = Math.max(5, Math.min(100, regionLv(p.location) + 3));
  const fam = Object.keys(WREGIONS[st.r].fams || { beast: 1 });
  big(p, `§b§l${st.name || "ステージ"}`, "§fステージの 番人が 立ちはだかる！", "mob.ravager.roar");
  if (!(await confirm(p, "ステージの 番人", `§b${st.name || "ステージ"}§r\n\n§f番人が こちらを 見ている。§7（勝つと ごほうび。断っても 次に 来た ときに また 挑める）`, "挑む", "今は やめておく"))) { const d2 = load(p); if (d2) { const s2 = qs(d2); s2.svT = { ...(s2.svT || {}), [st.key]: Date.now() }; save(p, d2); } return; }
  const TH = { underworld: "soulvalley", void: "endcity", crystal: "dripstone", sea: "beach", ruins: "ruins" };
  const res = await battle(p, bossOne(fam, lv, Math.floor(lv / 4), 0), { name: "ステージの 番人", arena: st.name || "ステージ", theme: TH[st.theme] || st.theme, hpk: 1.8, extra: 0.2, tag: "番人", speaker: "番人" });
  const d2 = load(p); if (!d2) return;
  const s2 = qs(d2);
  if (res === "win") s2.sv = [...new Set([...(s2.sv || []), st.key])]; else s2.svT = { ...(s2.svT || {}), [st.key]: Date.now() };   // v2.9.13: 負けたら また 挑める
  if (res === "win") { const got = reward(p, d2, 800 + lv * 100, [[pick(["e_silver", "SEED2", "g_sp2", "e_bronze"]), 1]]); save(p, d2); await notice(p, "ステージの 番人", ["§bステージの 番人を 倒した！", ...got.map((x) => "§e" + x)].join("\n")); }
  else save(p, d2);
}
// 町の うわさ（はじめて 着いた ときだけ・ちょっとした できごと）
const RUMOR = [
  ["§e町の 子ども", "ねえねえ、知ってる？ 夜に なると 強い モンスターが 出るんだって！", [["c_herb2", 2]]],
  ["§e宿屋の おかみ", "旅の 人、顔色が 悪いよ。これ 持って いきな。", [["c_herbs", 1]]],
  ["§e行商人", "石板？ さあねえ。でも 石板の 近くでは モンスターが 騒ぐって 話は 聞くよ。", [["g_sp", 1]]],
  ["§e老人", "わしの 若い ころはのう、地方の 主に 挑む 若者で 町が にぎわった ものじゃ。", [["e_bronze", 1]]],
  ["§e漁師", "海の 深い ところは 真っ暗だ。潜るなら ゴーグルが 要るぞ。", [["c_herb2", 1]]],
  ["§e鉱夫", "洞くつの 奥は 何も 見えねえ。灯りなしで 入るのは 無茶だぜ。", [["c_herb2", 1]]],
];
async function townRumor(p, d, t) {
  const s = qs(d);
  s.tv = [...new Set([...(s.tv || []), t.id])]; save(p, d);
  const [who, line, items] = pick(RUMOR);
  await notice(p, t.name, `${who}§r\n\n§f「${line}」`);
  const got = reward(p, d, 0, items); save(p, d);
  if (got.length) try { p.sendMessage(`§a${got.join("・")} を もらった！`); } catch {}
}

// ---------- だいじなもの の 効果（懐中電灯・ゴーグル）----------
const HINT_T = new Map();
function keyFx(p, d) {
  const under = underground(p), uw = underwater(p);
  if (under && !uw) {
    if (hasKey(p, "k_light")) try { p.addEffect("night_vision", 320, { showParticles: false }); } catch {}
    else if (p.location.y < 40 && Date.now() - (HINT_T.get(p.id) || 0) > 40000) { HINT_T.set(p.id, Date.now()); try { barNote(p).setActionBar("§7暗くて よく 見えない……§8（懐中電灯が あれば……）"); } catch {} }
  }
  if (uw) {
    if (hasKey(p, "k_goggle")) { try { p.addEffect("night_vision", 320, { showParticles: false }); p.addEffect("water_breathing", 320, { showParticles: false }); } catch {} }
    else { const dp = depthOf(p); if (dp >= 10) { try { p.addEffect("blindness", 50, { showParticles: false }); } catch {} if (Date.now() - (HINT_T.get(p.id) || 0) > 20000) { HINT_T.set(p.id, Date.now()); try { barNote(p).setActionBar("§3深すぎて 何も 見えない……§8（潜水ゴーグルが あれば……）"); } catch {} } } }
  }
}

// ---------- ループ ----------
const SAFE = new Map(), LAST = new Map(), INREG = new Map(), EVT = new Set();
// v2.9.12: ぬけた 人の 物語の 印は 消す（ほかの 人の 物語や あとかたづけを 止めない）
try { world.afterEvents.playerLeave.subscribe((e) => { const id = e.playerId; for (const x of SPAWNED.get(id) || []) rm(x); EVT.delete(id); MQRUN_KEY.delete(id); MQASK.delete(id); MQRUN.delete(id); SPAWNED.delete(id); SAFE.delete(id); LAST.delete(id); INREG.delete(id); }); } catch {}
let tick = 0;
const DREAM_CD = new Map();
function runEvt(p, fn) {
  if (EVT.has(p.id)) return;
  EVT.add(p.id); busy.add(p.id);
  system.run(async () => { try { await fn(); } catch (e) { console.warn(`[MonsterRPG] saga: ${e} ${e?.stack || ""}`); } finally { EVT.delete(p.id); busy.delete(p.id); } });
}
function gateCheck(p, d) {
  const l = p.location, r = regAt(l), up = openUpTo(d);
  if (r <= up) {
    let og = true; try { og = p.isOnGround !== false; } catch {}
    if (og) SAFE.set(p.id, { x: l.x, y: l.y, z: l.z });
    else {   // v2.9.6: 乗って いる・飛んで いる ときは 真下の 地面を 記録（遠くへ もどされない ように）
      try { for (let k = 1; k < 48; k++) { const b = p.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y) - k, z: Math.floor(l.z) }); if (b && !b.isAir && !b.isLiquid) { SAFE.set(p.id, { x: l.x, y: Math.floor(l.y) - k + 1.05, z: l.z }); break; } if (b && b.isLiquid) break; } } catch {}
    }
    return true;
  }
  const back = SAFE.get(p.id);
  let mount = null; try { mount = p.getComponent("minecraft:riding")?.entityRidingOn; } catch {}
  const to = back || (() => { const h = homeInfo(), s = SP(); return h && h.built ? { x: h.x, y: h.y + 0.1, z: h.z } : { x: s.x, y: s.y + 0.2, z: s.z }; })();
  try { if (mount) { mount.getComponent("minecraft:rideable")?.ejectRider(p); mount.teleport(to); } } catch {}
  try { p.teleport(to); } catch {}
  try { p.addEffect("slow_falling", 60, { showParticles: false }); } catch {}
  big(p, "§7まだ やるべき ことが あるようだ……", "§f引き返そう", "random.door_close");
  const g = gateHint(d); if (g) try { p.sendMessage(`§7まだ やるべき ことが あるようだ、引き返そう。 ${g}`); } catch {}
  return false;
}
function step(p) {
  const d = load(p);
  if (!d || !d.party || !d.party.length) return;
  const s = qs(d);
  if (fixMq(p, d)) save(p, d);
  if (!EVT.has(p.id) && inJail(p)) { releaseJail(p); try { clearJail(world.getDimension("overworld"), JAIL(p)); } catch {} try { p.sendMessage("§7牢屋から 出られた。"); } catch {} return; }
  if (exempt(p) || EVT.has(p.id)) return;
  // 関所
  if (!gateCheck(p, d)) return;
  const c = ctx(p, d);
  // 閻魔の神殿（はじめて 近づいたとき 悪夢）
  try { if (!s.enmaDream && !s.enmaJoin && !s.musashiJoin && !s.enmaClear && nearAltar(p, 6) && canFight(d) && !(Date.now() - (DREAM_CD.get(p.id) || 0) < 60000)) { DREAM_CD.set(p.id, Date.now()); runEvt(p, () => dreamFlow(p, fight, homeTp)); return; } } catch {}   // v3.0: すぐ busy・始められない ときは 1分 あける
  // メインクエスト
  const i = s.mq ?? 0, st = MQ[i];
  if (st && s.mqPaid === i && i < MQ.length - 1) { s.mq = i + 1; save(p, d); return; }   // v2.9.12: ごほうびを もらった 段は とちゅうで ぬけても 先へ（2回 もらえない）
  // v2.9.13: 「あとで」・負けた あとは、ガイドブック →「物語の 戦いに 再挑戦」で もう一度
  if (s.mqHold && s.mqHold.i !== i) { delete s.mqHold; save(p, d); }   // v2.9.13: 再挑戦は ガイドブックで えらぶ（えらぶまで 物語は 進まない）
  if (st && st.trig && !s.mqHold && canFight(d)) {
    let go = false; try { go = st.trig(c); } catch {}
    if (go) {
      runEvt(p, async () => {
        const dd = load(p); if (!dd) return;
        if (st.ch && qs(dd).chSeen !== i) { qs(dd).chSeen = i; save(p, dd); big(p, `§6§l${st.ch}`, "§f物語が 動きだす", "ui.toast.challenge_complete"); await wait(50); }   // v2.9.13: 章の はじまり
        let done = false, later = false; MQASK.add(p.id); MQRUN.add(p.id);
        try { done = await st.run(p, dd); } catch (e) { if (e === LATER) later = true; else console.warn(`[MonsterRPG] saga mq: ${e} ${e?.stack || ""}`); } finally { MQASK.delete(p.id); MQRUN.delete(p.id); }
        { const dx = load(p); if (!done && !later && dx && qs(dx).mqPaid === i) done = true; }
        if (later) laterClean(p);
        if (!done) try { p.sendMessage(`§7準備が できたら ${st.key ? "もう一度 だいじなものを 使おう" : "ガイドブック ＞ ストーリー ＞「物語の 戦いに 再挑戦」を えらぼう"}。§8（右上の 案内が 場所を 教えて くれる）`); } catch {}
        SPAWNED.delete(p.id);
        const d2 = load(p); if (!d2) return; const s2 = qs(d2);
        if ((s2.mq ?? 0) === i) { if (done) { s2.mq = i + 1; delete s2.mqHold; } else { const l = p.location; s2.mqHold = { i, x: Math.floor(l.x), z: Math.floor(l.z) }; } save(p, d2); }   // v2.9.13: 時間では なく 場所で もう一度
      });
      return;
    }
  }
  // 歩いた かず
  const l = p.location, pv = LAST.get(p.id); LAST.set(p.id, { x: l.x, z: l.z });
  const moved = pv ? Math.hypot(l.x - pv.x, l.z - pv.z) : 0;
  if (!canFight(d)) return;
  // ステージの 番人（はじめて 来たとき）
  const sg = c.stage;
  if (sg && !(s.sv || []).includes(sg.key) && (s.mq ?? 0) >= 2 && Date.now() - ((s.svT || {})[sg.key] || 0) > 300000) { runEvt(p, () => stageGuard(p, d, sg)); return; }
  // 町の うわさ（はじめて 来たとき）
  const tw = c.town;
  if (tw && !(s.tv || []).includes(tw.id) && tw.id !== "t0") { runEvt(p, () => townRumor(p, d, tw)); return; }
  // ライバル（地方ごとに 1回・入って しばらく たってから）
  const ir = INREG.get(p.id); if (!ir || ir.r !== c.r) INREG.set(p.id, { r: c.r, t: Date.now() });
  if (c.r >= 2 && (s.mq ?? 0) > MQ.findIndex((x) => x.hint.includes("ルインズ荒野へ")) && !(s.reiR || []).includes(c.r) && Date.now() - (s.reiT || 0) > 600000 && Date.now() - (INREG.get(p.id)?.t || Date.now()) > 120000 && moved > 2 && Math.random() < 0.15) { runEvt(p, () => rival(p, d, c.r)); return; }
  // v2.9: NPCに からまれる 戦いは なし（うろついている モンスターマスターに 話しかけると 勝負できる）
}
export function initSaga() {
  system.runInterval(() => {
    tick++;
    for (const p of world.getAllPlayers()) {
      try {
        if (tick % 2 === 0) step(p);
        const d = load(p);
        if (d && tick % 2 === 1 && !busy.has(p.id)) keyFx(p, d);
        if (d && tick % 30 === 5 && !busy.has(p.id) && !EVT.has(p.id)) { const back = syncKeys(p, d); if (back.length) { save(p, d); try { p.sendMessage(`§d手元に なかった ものが もどってきた: §f${back.join("・")}`); } catch {} } }
      } catch (e) { console.warn(`[MonsterRPG] saga loop: ${e}`); }
    }
  }, 20);
}
// チート: 関所を なくす／もどす
export function setGateFree(d, v) { const s = qs(d); s.gateFree = !!v; }

// v2.9.8: 物語の とちゅうで ワールドを 閉じた ときに のこった 会話用の 人を 片づける（読みこみ 直後と、ときどき）
system.runInterval(() => {
  for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
    try { for (const e of world.getDimension(id).getEntities({ type: "mrpg:npc", tags: ["mrpg_saga"] })) { if (EVT.size === 0) try { e.remove(); } catch {} } } catch {}
  }
}, 1200);

// v2.9.13: 「あとで」・負けて 止まって いる 物語の 戦い（ガイドブックから 再挑戦を えらぶ）
export function mqHeld(d) { try { const s = qs(d), i = s.mq ?? 0; return !!(s.mqHold && s.mqHold.i === i && MQ[i] && MQ[i].trig); } catch { return false; } }
export function mqRetry(p, d) {
  const s = qs(d); delete s.mqHold; save(p, d);
  const st = MQ[s.mq ?? 0];
  let here = false; try { here = !!(st && st.trig && st.trig(ctx(p, d))); } catch {}
  return here ? "§aもう一度 挑む！ §7（ガイドブックを 閉じると 始まる）" : `§aもう一度 挑む 準備が できた。§f${(() => { try { return hintOf0(st, d); } catch { return ""; } })()} §7（その 場所へ 行くと 始まる）`;
}

// v2.9.13: 「バグを 直す」用: 止まった 物語の できごとの しるしを 外す（呼んだ 人だけ）
export function sagaUnlock(p) {
  let n = 0;
  for (const S of [EVT, MQASK, MQRUN, MQRUN_KEY]) if (S.has(p.id)) { S.delete(p.id); n++; }
  if (SPAWNED.has(p.id)) { laterClean(p); n++; }
  return n;
}

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { HINT_T.delete(playerId); DREAM_CD.delete(playerId); } catch {} }); } catch {}
