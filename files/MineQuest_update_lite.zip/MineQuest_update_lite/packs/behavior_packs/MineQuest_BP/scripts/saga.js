// v2.8: 物語の 冒険（地方の 関所・メインクエスト・だいじなもの・NPCの からみ・ライバル・共闘・裏切り）
// ・メインクエストは 1本道（s.mq）。手順が まだ 来ていない できごとは 起きないので、ワープしても 矛盾しない
// ・地方は「その 地方の 主」を 倒すと 次が 開く。それまでは「まだ やるべき ことが あるようだ、引き返そう」
/* 第122版: 物語の 印（qs(d)）のうち ほかの ファイルも 読む もの
   hakuStone  第10章で オルドの 相棒 ハクが 石に なった（オルドは 生きて いる。前の 版の ordoDead は 読みこみ時に これへ 置きかえる）
   ordoMask   せいかんカップで 仮面の 王者が オルドだと 分かった（cupScene）
   nagiDead   ナギサが 港の マスターを 退いた ／ yomiStone ヨミが 石に なった ／ rouDead 双子が 連れ去られた
   theoBetray・theoSaved・reiFinal・ch10b など 段の 印は MQ の 中を 見る */
import { world, system } from "@minecraft/server";
import { talk, tell, setSpeakerFinder, clearSkip, establish, camFade, lookAt, camAt, scenePause, sceneResume, inScene, cineCard, cineSting, cineFx, mood, boxLine } from "./talk.js";
import { stageBegin, stageEnd, stageMove, stageNow, stageOf, stageFor, slotOf, addActor, freeNear, walkFrom, clampPath, stagePt, standY } from "./stagecore.js";   /* 第123版: 場面の 舞台 */   /* 第108版: 会話は フォームで 止めない */
import { SPECIES, ORDER, ITEMS, BOSS_SLAB } from "./data.js";
import { load, save } from "./store.js";
import { busy, ok, wait, notice, confirm, sound, particle, giveItem, countItem, gold, seedId, takeItem, barNote, showTitle, setJob, bagAdd } from "./ui.js";
import { WREGIONS, regionIdx, regionLv, landSites, LAYOUT } from "./worldmap.js";
import { townAt, homeInfo, landInfo, unstuckNpc, groundY, castleInfo, castleSpot, TOWNS, townPos, caveInfo, CAVE_R, caveSite, getTown } from "./structures.js";
import { qs, syncQuest, postOpen, BS_N } from "./quest.js";
import { fight } from "./story.js";
import { calcStats, canFight } from "./core.js";
import { underwater, waterDepth, hooks, setLook, TYPE as MON_TYPE } from "./field.js";
import { nearAltar, dreamFlow, altarInfo, rfInfo } from "./postgame.js";
import { musashiTownInfo } from "./majin.js";
import { duel } from "./cine.js";   /* 第106版: 山場の モンスター同士の 演出 */
import { PSKIN } from "./skinjobs.js";
import { face as dFace, emote as dEmote } from "./direct.js";   /* 第121版: だまった ままの 表情・マーク */
import { partnerEditor, findPartner, baseOf, simpleLook } from "./partner.js";
import { choose, ICON, hudSend } from "./ui.js";
const PJ = (k, d) => (PSKIN[k] ? PSKIN[k][0] : d);   /* 第106版: 人物の スキンの 番号 */
/* 第106版: 相棒の 名前（相棒が いなければ 先頭の 子） */
function palNm(p) { try { const d = load(p); const m = [...(d.party || []), ...(d.bench || []), ...(d.box || [])].find((x) => x && (x.id === d.partnerId || x.partner || x.look)) || d.party[0]; return m ? (m.nm || SPECIES[m.sp]?.name || "相棒") : "相棒"; } catch { return "相棒"; } }

const SP = () => { try { const w = world.getDefaultSpawnLocation(); return { x: w.x, y: w.y, z: w.z }; } catch { return { x: 0, y: 64, z: 0 }; } };
export const regAt = (loc) => { const s = SP(); return regionIdx(loc.x - s.x, loc.z - s.z); };
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const ri = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const RN = (r) => WREGIONS[r]?.name || "";

// ---------- 地方の 関所 ----------
// 地方 r を こえるための 目標（その 地方の 主）
const RGOAL = [
  { t: (s) => s.bs.includes(0), h: () => `アルカトラス城の 地方マスターに 勝ち、「${BOSS_SLAB[0]?.name}」の 主を 封印する` },
  { t: (s) => !!(s.gate && s.gate[1]), h: () => "シルヴァ大森林の「森の 主」を しずめる（セオと 共闘）" },
  { t: (s) => s.bs.includes(2), h: () => `ルインズ荒野の 地方マスターに 勝ち、「${BOSS_SLAB[2]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(4), h: () => `ヴォルカ火山帯の 地方マスターに 勝ち、「${BOSS_SLAB[4]?.name}」の 主を 封印する` },
  { t: (s) => !!(s.gate && s.gate[4]), h: () => "サンドリア砂漠の「王墓の 主」を 倒す（レイと 共闘）" },
  { t: (s) => s.bs.includes(6), h: () => `クリスタリアの 地方マスターに 勝ち、「${BOSS_SLAB[6]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(8), h: () => `マリノア諸島の 地方マスターに 勝ち、「${BOSS_SLAB[8]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(10), h: () => `ネクロス冥府領の 地方マスターに 勝ち、「${BOSS_SLAB[10]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(12), h: () => `フロストヘイムの 地方マスターに 勝ち、「${BOSS_SLAB[12]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(13), h: () => `ラグナの 地方マスターに 勝ち、「${BOSS_SLAB[13]?.name}」の 主を 封印する` },
];
// どこまで 行けるか（後の 目標を 果たしていれば、前の 地方も すべて 開く）
function sealOpen(s) { for (let j = RGOAL.length - 1; j >= 0; j--) if (RGOAL[j].t(s)) return j + 1; return 0; }
// v2.9.13: 物語の 順番（いまの 段の 地方より 先へは 行けない。フラグを 飛ばせない ように）
function storyOpen(s) { const st = MQ[s.mq ?? 0]; return !st || st.r === 99 ? 99 : st.r; }
export function openUpTo(d) {
  const s = qs(d);
  if (s.ending || s.gateFree) return 99;
  const u = sealOpen(s);
  return s.ord ? Math.min(u, storyOpen(s)) : u;
}
// その 地方マスターに 挑める 段まで 物語が 進んで いるか
const wonOf = (p, k) => { const x = load(p); return !!(x && qs(x)["w_" + k]); };   /* 第106版: 勝った 戦いは やり直しで くり返さない */
const setWon = (p, k) => { const x = load(p); if (x) { qs(x)["w_" + k] = 1; save(p, x); } };
export function sealReady(d, si) { const s = qs(d); if (!s.ord || s.ending) return true; const k = MQ.findIndex((x) => x.seal === si); return k < 0 || (s.mq ?? 0) >= k; }
export function palLocked(d) { try { const s = qs(d); if (s.palMet || s.ending) return false; const k = MQ.findIndex((x) => x.spot === garoSpot || /北の 門§f を 出て/.test(x.hint || "")); return k >= 0 && (s.mq ?? 0) <= k; } catch { return false; } }   /* 第115版: 相棒は ガロの 場面で 出会う */
export function storyNowHint(d) { const s = qs(d); const st = MQ[s.mq ?? 0]; return st ? hintOf(st, d) : ""; }
hooks.openUpTo = (d) => openUpTo(d);   // v2.9.12: 物語の 場所を 先に 作る 範囲
export const regionOpen = (d, r) => r <= openUpTo(d);
export const gateHint = (d) => { const u = openUpTo(d), s = qs(d); if (u >= RGOAL.length || u >= 99) return null; if (s.ord && storyOpen(s) < sealOpen(s)) return `§7（${RN(u + 1)}へ 行くには、まず 物語を 進めよう: ${String(storyNowHint(d)).replace(/§./g, "")}）`; return `§7（${RN(u + 1)}へ 行くには: ${RGOAL[u].h()}）`; };

// ---------- だいじなもの ----------
export const hasKey = (p, id) => countItem(p, `mrpg:${id}`) > 0;
function giveKey(p, d, id) {
  const s = qs(d); s.keys = [...new Set([...(s.keys || []), id])];
  if (!hasKey(p, id)) giveItem(p, `mrpg:${id}`, 1);
  try { showTitle(p, " ", { subtitle: `§6だいじなもの「${ITEMS[id]?.name}」を 手に入れた！`, fadeInDuration: 5, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
  sound(p, "random.levelup", 1.2);
}
// なくした だいじなもの・特別な 石板を もどす
// 持ち物が いっぱいの ときは 足もとに 落とさず バッグへ（何度も 落ちて ふえない ように）
function giveItemSafe(p, id) {
  try { const c = p.getComponent("minecraft:inventory")?.container; if (c && c.emptySlotsCount === 0) { bagAdd(p, id, 1); return true; } } catch {}
  giveItem(p, `mrpg:${id}`, 1); return true;
}
export function syncKeys(p, d) {
  const s = qs(d), back = [];
  // v2.9.12: いまの 段で 使う だいじなものが 記録に なければ わたす（とちゅうで ぬけて もらいそびれた とき）
  try { const cur = MQ[s.mq ?? 0]; if (cur && cur.key && ITEMS[cur.key] && !(s.keys || []).includes(cur.key)) s.keys = [...(s.keys || []), cur.key]; } catch {}
  for (const id of s.keys || []) if (ITEMS[id] && !hasKey(p, id)) { if (!giveItemSafe(p, id)) continue; back.push(ITEMS[id].name); }
  try { back.push(...syncQuest(p, d)); } catch {}
  return back;
}

// ---------- チーム ----------
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
const rankForLv = (lv) => (lv < 8 ? 0 : lv < 14 ? 1 : lv < 22 ? 2 : lv < 32 ? 3 : lv < 44 ? 4 : lv < 56 ? 5 : lv < 70 ? 6 : 7);
function cands(fams, rk, sizes) {
  return ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !["king", "god"].includes(S.fam) && (!fams || fams.includes(S.fam)) && S.rank === RK[rk] && (!sizes || sizes.includes(S.sz)); });
}
export function team(fams, lv, n = 3, plus = 0, lead = null) {
  const out = []; let used = 0;
  const rk0 = rankForLv(lv);
  if (lead) { out.push({ sid: lead, lv: Math.min(100, lv + 2), q: 0.8, plus: plus + 5 }); used += SLOT[SPECIES[lead]?.sz] || 2; }
  for (let k = 0; out.length < n && k < 12; k++) {
    const rk = Math.max(0, rk0 - (out.length >= 2 ? 1 : 0));
    let c = cands(fams, rk).filter((x) => used + (SLOT[SPECIES[x].sz] || 2) <= 4 && !out.some((t) => t.sid === x));
    if (!c.length) c = cands(null, rk).filter((x) => used + (SLOT[SPECIES[x].sz] || 2) <= 4 && !out.some((t) => t.sid === x));
    if (!c.length) break;
    const x = pick(c); used += SLOT[SPECIES[x].sz] || 2;
    out.push({ sid: x, lv: Math.min(100, lv + (out.length ? 0 : 1)), q: 0.7, plus });
  }
  return out;
}
function bossOne(fams, lv, plus, rkUp = 1) {
  const rk = Math.min(7, rankForLv(lv) + rkUp);
  let c = cands(fams, rk, ["L", "G"]); if (!c.length) c = cands(fams, rk); if (!c.length) c = cands(null, rk, ["L", "G"]);
  return [{ sid: pick(c) || ORDER[0], lv: Math.min(100, lv), q: 1, plus }];
}
const leadOf = (fam, lv) => { const c = cands([fam], Math.min(7, rankForLv(lv) + 1)); return c.length ? pick(c) : null; };

// ---------- 会話・演出 ----------
const COL = { オルド: "§e", セオ: "§a", レイ: "§b", "？？？": "§4", ヴァルカ: "§c", マリン: "§3", ロウ: "§9", ルウ: "§d" };
async function say(p, who, lines) { await talk(p, who, lines, COL[who] || "§6"); }   // v3.0 第63版: 操作の 案内は セリフに しない
async function narr(p, t, lines) { await tell(p, t, lines); }
/* 第113版: 再挑戦の 案内は はじめの 1回だけ くわしく（2回目からは 短く） */
function RT(p) { try { const d = load(p); if (d && !qs(d).rtHint) { qs(d).rtHint = 1; save(p, d); return "§7（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）"; } } catch {} return "§7（準備が できたら、もう一度）"; }
/* 第113版: 相棒の 声（守り手の 印を もらった あとは、あなたにだけ 少し 聞こえる）。{n} は 相棒の 名前 */
async function pal(p, lines) { const nm = palNm(p); await talk(p, `${nm}（相棒）`, lines.map((l) => String(l).replace(/\{n\}/g, nm)), "§e"); }
function big(p, a, b, snd = "random.levelup") {
  const t = String(a || "").replace(/§./g, "").trim();
  if (/^第.+章/.test(t)) { cineCard(p, `§f§l${t}${b ? `\n§r§7${String(b).replace(/§./g, "")}` : ""}`, 80); if (snd) sound(p, snd, 1); return; }   /* 第125版: 章の 札 */
  if (inScene(p) && t && t.length <= 8) {   /* 第125版: ムービーの あいだは 大きな 一文字（影・！）と 会話の 枠の 地の文 */
    cineSting(p, String(a).replace(/§l/g, ""), 36); cineFx(p, "s", 12); if (b) hudSend(p, "MQD", boxLine(`§7${String(b).replace(/§./g, "")}`));
    if (/影/.test(t)) mood(p, "shadow");
    if (snd) sound(p, snd, 1); return;
  }
  try { showTitle(p, a, { subtitle: b || "", fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {} if (snd) sound(p, snd, 1);
}
/* 第123版: 役者は 舞台の 立ち位置に 立つ（話す 人は 正面の 弧・旅の 仲間は となり・敵は 向こう側）。重ならない・葉の 上に 立たない */
function roleOf(p, name) { const n = String(name || ""), h = heroOf(p); if (h && n.replace(/§./g, "") === h.name) return "hero"; if (/^§[c45]/.test(n) || /ノクス|手下|影/.test(n)) return "foe"; return "ally"; }
function npcNear(p, name, job = 8, noWalk = false) {
  try {
    const S = stageNow(p), role = roleOf(p, name), pos = slotOf(S, role, name, null);
    const e = p.dimension.spawnEntity("mrpg:npc", pos);
    if (MQASK.has(p.id)) { const L = SPAWNED.get(p.id) || []; L.push(e); SPAWNED.set(p.id, L); }
    { const A = TALKERS.get(p.id) || []; A.push(e); TALKERS.set(p.id, A.filter((x) => ok(x))); }   // v3.0: 戦いの 前に 消す ため
    try { setJob(e, job); } catch {}
    e.addTag("mrpg_npc"); e.addTag("mrpg_saga"); e.setDynamicProperty("mrpg:saga", true); e.nameTag = name;
    if (role === "hero") e.addTag("mrpg_hero");
    addActor(S, e, name, pos);
    const look = role === "hero" ? S.at(3.5, 0, 1.5) : { x: S.P.x, y: S.P.y + 1.5, z: S.P.z };
    try { e.teleport(pos, { facingLocation: look }); } catch {}
    if (!noWalk) walkIn(S, e, pos, look);   /* 第115版: いきなり 現れず、少し はなれた 所から 歩いて くる */
    return e;
  } catch { return null; }
}
/* 第123版: 立ち位置の 外側（道が ある 所）から 歩いて 来る */
function walkIn(S, e, to, look) {
  try {
    const from = walkFrom(S, to, e); if (!from) return;
    e.teleport(from, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } }); try { e.setProperty("mrpg:mv", true); } catch {}
    let k = 0; const id = system.runInterval(() => { k++; if (!ok(e) || k > 12) { system.clearRun(id); try { if (ok(e)) { e.teleport(to, { facingLocation: look }); e.setProperty("mrpg:mv", false); } } catch {} return; }
      const t = k / 12, x = from.x + (to.x - from.x) * t, z = from.z + (to.z - from.z) * t; let y = from.y + (to.y - from.y) * t; { const g = standY(S.dim, x, z, y, S.C); if (g !== null && g > y && g - y < 1.2) y = g; }   /* 第127版: 坂で 足が うまらない */
      try { e.teleport({ x, y, z }, { facingLocation: to }); } catch {} }, 2);
  } catch {}
}
/* ---------- 第115版: 演出の 道具（文字で 説明せず、画面で 起きる ことを 見せる）---------- */
const ACT = { kneel: 15, point: 16, guard: 17, raise: 18, run: 19, knocked: 20, down: 8, recoil: 22, hold: 23, up: 24, sad: 12 };
function act(e, k, keep = true) { try { const n = typeof k === "number" ? k : ACT[k] ?? 0; e.setProperty("mrpg:act", n); if (keep) e.setDynamicProperty("mrpg:act0", n); } catch {} }
async function go(e, to, ticks = 14, run = false) {   /* 歩く・走って 移動 */
  if (!ok(e) || !to) return; const f = e.location;
  { const S = stageFor(e); if (S && Math.abs(to.y - f.y) < 1.6) { to = clampPath(S, f, to); to = freeNear(S, to, e, 1.25, 2.1) || to; S.dest.set(e.id, to); } else if (S) { const y = standY(S.dim, to.x, to.z, to.y, S.C); if (y !== null && Math.abs(y - to.y) <= 1.2) { to = { ...to, y }; to = freeNear(S, to, e, 1.25, 2.1) || to; S.dest.set(e.id, to); } } }   /* 第123版: 壁を ぬけない・人に 重ならない。第127版: 坂・飛び降りでも うまらない・重ならない */ try { e.setProperty("mrpg:mv", true); if (run) e.setProperty("mrpg:act", ACT.run); } catch {}
  for (let k = 1; k <= ticks; k++) { if (!ok(e)) return; const t = k / ticks; try { e.teleport({ x: f.x + (to.x - f.x) * t, y: f.y + (to.y - f.y) * t, z: f.z + (to.z - f.z) * t }, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } }); } catch {} await wait(1); }
  try { e.setProperty("mrpg:mv", false); if (run) e.setProperty("mrpg:act", 0); } catch {}
}
async function knock(e, from, dist = 3.5) {   /* 吹っ飛んで 倒れる */
  if (!ok(e)) return; const l = e.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L; act(e, "knocked", false);
  let to = { x: l.x + ux * dist, y: l.y, z: l.z + uz * dist }; { const S = stageFor(e); if (S) { to = clampPath(S, l, to); to = freeNear(S, to, e, 1.25, 1.4) || to; S.dest.set(e.id, to); } }   /* 第123版: 壁の 手前で 止まる */
  for (let k = 1; k <= 8; k++) { if (!ok(e)) return; const t = k / 8; try { e.teleport({ x: l.x + (to.x - l.x) * t, y: l.y + (to.y - l.y) * t + Math.sin(t * Math.PI) * 1.4, z: l.z + (to.z - l.z) * t }, { facingLocation: from }); } catch {} await wait(1); }
  act(e, "down");
}
function knockP(p, from, h = 1.1, v = 0.45) { try { const l = p.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1; cmd(p, "inputpermission set @s lateral_movement enabled"); p.applyKnockback(dx / L, dz / L, h, v); system.runTimeout(() => { try { if (inScene(p)) p.runCommand("inputpermission set @s lateral_movement disabled"); } catch {} }, 12); } catch {} }
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
function shake(p, pw = 0.5, t = 0.6) { cmd(p, `camerashake add @s ${pw} ${t} positional`); }
function flash(p, white = true) { cmd(p, `camera @s fade time 0.05 0.15 0.4 color ${white ? "255 255 255" : "0 0 0"}`); }
function boom(dim, at) { try { dim.spawnParticle("mrpg:shock_ring", { x: at.x, y: at.y + 0.1, z: at.z }); dim.spawnParticle("mrpg:dust_puff", { x: at.x, y: at.y + 0.1, z: at.z }); } catch {} try { dim.spawnParticle("minecraft:explosion_particle", { x: at.x, y: at.y + 0.5, z: at.z }); for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; dim.spawnParticle("minecraft:white_smoke_particle", { x: at.x + Math.cos(a) * 2, y: at.y + 0.3, z: at.z + Math.sin(a) * 2 }); } } catch {} }
async function shadowFlow(p, from, to, ticks = 20) {   /* 黒い 影が 地面を すべる */
  mood(p, "shadow");   /* 第125版: 紫の 霧と 暗がり */
  for (let k = 0; k <= ticks; k++) { if (!ok(p)) return; const t = k / ticks, x = from.x + (to.x - from.x) * t, z = from.z + (to.z - from.z) * t, y = from.y + (to.y - from.y) * t;
    if (k % 2 === 0) try { p.dimension.spawnParticle("mrpg:shadow_smoke", { x, y: y + 0.6, z }); if (k % 4 === 0) p.dimension.spawnParticle("mrpg:glow_mote", { x, y: y + 0.8, z }); } catch {}   /* 第125版: やわらかい 紫の 煙 */
    for (let i = 0; i < 2; i++) try { p.dimension.spawnParticle(i % 2 ? "minecraft:soul_particle" : "minecraft:basic_smoke_particle", { x: x + (Math.random() - 0.5) * 2.2, y: y + 0.2 + Math.random() * 0.8, z: z + (Math.random() - 0.5) * 2.2 }); } catch {}
    if (k % 6 === 0) sound(p, "mob.wither.ambient", 0.3); await wait(1); }
}
/* 第115版: 影が 人を 包む（粒が うずまき、その 人は 倒れて 眠る）*/
async function engulf(p, e) {
  if (!ok(e)) return; lookAt(p, e); mood(p, "shadow");
  for (let k = 0; k < 16; k++) { if (!ok(e)) break; const l = e.location; if (k % 6 === 0) try { e.dimension.spawnParticle("mrpg:vortex", { x: l.x, y: l.y + 0.1, z: l.z }); e.dimension.spawnParticle("mrpg:shadow_smoke", { x: l.x, y: l.y + 0.9, z: l.z }); } catch {} for (let i = 0; i < 4; i++) { const a = k * 0.8 + i * 1.57, r = 1.6 - k * 0.08; try { e.dimension.spawnParticle(i % 2 ? "minecraft:soul_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(a) * r, y: l.y + 0.2 + (k % 4) * 0.4, z: l.z + Math.sin(a) * r }); } catch {} } await wait(3); }
  try { e.setProperty("mrpg:act", 8); e.setDynamicProperty("mrpg:act0", 8); } catch {}   /* 倒れて 眠る */
  sound(p, "mob.wither.ambient", 0.6);
}
const rm = (e) => { if (ok(e)) try { e.remove(); } catch {} };
/* ---------- 第115版: 旅の 仲間（ヒロイン）。プレイヤーが 12人から えらぶ ---------- */
export const HEROES = [["hero_rio", "リオ", "栗色の 髪の 冒険者。明るくて 涙もろい"], ["hero_yuna", "ユナ", "銀髪の 白い コート。おっとりした お姉さん"], ["hero_chloe", "クロエ", "ゴーグルの 発明家。怒ると 顔が 真っ赤"], ["hero_mia", "ミア", "金髪の 魔法使い。ちょっと 生意気"],
  ["hero_hana", "ハナ", "ピンクの 髪の 格闘家。元気 いっぱい"], ["hero_shion", "シオン", "紫の 髪の 巫女。静かで やさしい"], ["hero_leaf", "リーフ", "緑の 髪の 弓使い。クールな しっかり者"], ["hero_mel", "メル", "メイド服の お姉さん。丁寧で 心配性"],
  ["hero_nami", "ナミ", "水色の 髪の 船乗り。さっぱりした 性格"], ["hero_kaede", "カエデ", "着物の 剣士。まじめで 照れ屋"], ["hero_cecil", "セシル", "金髪の 女騎士。正義感が 強い"], ["hero_lulu", "ルル", "身軽な 盗賊。いたずら好き"]];
async function heroJoin(p) {
  const pick = await choose(p, "旅の 仲間", "§f§l旅の 仲間が 追いかけて きた！\n\n§7あなたの 幼なじみは だれ？（あとから かえる ことは できません）", HEROES.map((h) => [`§l${h[1]}§r\n§8${h[2]}`, `textures/ui/mrpg/h_${h[0]}`]));
  if (!(pick >= 0)) return false; const d = load(p); if (!d) return false; qs(d).hero = HEROES[pick][0]; save(p, d);
  const e = heroNear(p);
  await hsay(p, ["{rage,怒,jump}はあ、はあ……やっと 追いついた！ 置いて いくなんて ひどい！", "{smile,♪}コンパス、ちゃんと 使ってくれてる？ ……わたしも 一緒に 行く。地図を ぜんぶ 描くのが 夢なの。"]);
  rm(e); return true;
}
function heroOf(p) { try { const d = load(p), k = d && qs(d).hero; const h = HEROES.find((x) => x[0] === k); return h ? { key: h[0], name: h[1] } : null; } catch { return null; } }
const HN = (p) => (heroOf(p) || { name: "ユナ" }).name;
async function hsay(p, lines) { const h = heroOf(p); if (h) await say(p, h.name, lines); }
/* 第115版: ガロたちに 囲まれて いる 小さな モンスター（あとで 相棒に なる 子） */
function palVictim(p, near) { try { let b = near && ok(near) ? near.location : p.location, yaw = (p.getRotation().y * Math.PI) / 180;
  let pos = near && ok(near) ? { x: b.x + 1.5, y: b.y, z: b.z + 1.5 } : { x: b.x - Math.sin(yaw) * 3, y: b.y, z: b.z + Math.cos(yaw) * 3 };
  const S = stageOf(p); if (S) { const P = S.P; if (near && ok(near) && S.dest.get(near.id)) b = S.dest.get(near.id); pos = near && ok(near) ? { x: P.x + (b.x - P.x) * 0.6, y: b.y, z: P.z + (b.z - P.z) * 0.6 } : stagePt(S, 2.6, 0.8); pos = freeNear(S, pos, null, 1.4) || pos; }   /* 第123版: ガロと あなたの あいだ（重ならない）*/
  const fams = ["beast", "animal", "slime", "dragon", "bird"].filter((f) => baseOf(f)); const sid = baseOf(fams[Math.floor(Math.random() * fams.length)] || "animal");
  const e = p.dimension.spawnEntity(MON_TYPE, pos); e.addTag("mrpg_temp"); e.addTag("mrpg_preview"); try { e.triggerEvent("mrpg:make_battle"); } catch {}
  setLook(e, sid, { sp: sid, nm: "小さな モンスター", look: simpleLook() }); e.nameTag = "§7小さな モンスター"; if (S) addActor(S, e, null, null); return e; } catch { return null; } }
function heroNear(p, noWalk = false) { const h = heroOf(p); return h ? npcNear(p, `§d${h.name}`, PJ(h.key, 9), noWalk) : null; }
/* ---------- 第121版: 第2〜6章の 演出の 小道具（軽い。毎tickの ループは なし）---------- */
const EMK = { "!": "bang", "?": "q", "…": "dots", "汗": "sweat", "怒": "anger", "♥": "heart", "息": "sigh", "♪": "note", "☆": "spark" };
function re(e, f, m, t = 40) { if (!ok(e)) return; if (f) dFace(e, f, t); if (m) dEmote(e, EMK[m] || m); }   /* だまって 反応（表情・マーク）*/
/* 旅の 仲間を 場面の あいだ そばに 置く（戦いで 消えたら その場に 出しなおす。歩いて こない）*/
function heroBox(p, walk = false) { let e = walk ? heroNear(p) : null; return { get e() { if (!ok(e)) e = heroNear(p, true); return e; }, rm() { rm(e); } }; }
function fwd(p, k = 5, sd = 0, dy = 0) { try { const S = stageOf(p); if (S) return stagePt(S, k, sd, dy); const l = p.location, a = (p.getRotation().y * Math.PI) / 180, X = -Math.sin(a), Z = Math.cos(a); return { x: l.x + X * k - Z * sd, y: l.y + dy, z: l.z + Z * k + X * sd }; } catch { return null; } }
function away(e, p, k = 8) { try { const a = e.location, b = p.location, dx = a.x - b.x, dz = a.z - b.z, L = Math.hypot(dx, dz) || 1, q = { x: a.x + (dx / L) * k, y: a.y, z: a.z + (dz / L) * k }, S = stageFor(e); return S ? clampPath(S, a, q) : q; } catch { return null; } }
async function leave(e, p, k = 8, run = true) { const q = ok(e) ? away(e, p, k) : null; if (q) await go(e, q, run ? 12 : 22, run); rm(e); }   /* 背を 向けて 去る */
function place(e, p, q) { if (ok(e) && q) try { const S = stageFor(e); if (S) { const y = standY(S.dim, q.x, q.z, q.y, S.C); q = freeNear(S, q, e, 1.4) || (y !== null && freeNear(S, { ...q, y }, e, 1.4)) || q; S.mem.set(e.nameTag, { ...q }); S.dest.set(e.id, { ...q }); } e.teleport(q, { facingLocation: p.getHeadLocation() }); } catch {} return e; }
const npcAt = (p, nm, job, q) => place(npcNear(p, nm, job, true), p, q);
async function sayAt(p, nm, job, who, lines) { const e = npcNear(p, nm, job, true); await say(p, who, lines); rm(e); }   /* 負けた あとの 一言（その場に 立って 話す）*/
function burst(dim, at, nm, n = 8, r = 1.2, dy = 0.5) { if (!at) return; for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; try { dim.spawnParticle(nm, { x: at.x + Math.cos(a) * r, y: at.y + dy + (i % 3) * 0.4, z: at.z + Math.sin(a) * r }); } catch {} } }
async function blaze(p, at, k = 4) { if (!at) return; for (let j = 0; j < k && ok(p); j++) { burst(p.dimension, at, j % 2 ? "minecraft:basic_flame_particle" : "minecraft:lava_particle", 8, 0.8 + j * 0.4); burst(p.dimension, at, "minecraft:basic_smoke_particle", 6, 1.4, 2); await wait(3); } }
function redGlow(e) { if (!ok(e)) return; burst(e.dimension, e.location, "minecraft:redstone_wire_dust_particle", 6, 0.35, 1.2); }   /* かけらの 赤黒い 光 */
async function drop(p, e, h = 5) { if (!ok(e)) return; const l = e.location; try { e.teleport({ x: l.x, y: l.y + h, z: l.z }); } catch {} await go(e, l, 7); burst(p.dimension, l, "minecraft:white_smoke_particle", 8, 1, 0.1); sound(p, "random.anvil_land", 1.4); shake(p, 0.25, 0.3); }   /* 上から 飛び降りて くる */
function camPt(p, at, k = 3, dy = 1) { try { if (!at) return false; const P = p.location, dx = P.x - at.x, dz = P.z - at.z, L = Math.hypot(dx, dz) || 1; return camAt(p, { x: at.x + (dx / L) * k, y: at.y + dy + 0.4, z: at.z + (dz / L) * k }, { x: at.x, y: at.y + dy, z: at.z }, 0.5); } catch { return false; } }
const camNear = (p, e, k = 2.2, dy = 1.3) => ok(e) && camPt(p, e.location, k, dy);
function camLowUp(p, q) { const c = fwd(p, -1.5, 0, 0.4); if (c && q) camAt(p, c, { x: q.x, y: q.y + 4, z: q.z }, 0.5); }   /* 足もとから 見上げる（大きな 主）*/
function palEnt(p) {   /* 相棒の 姿を 横に 出す（演出だけ。rmCine で 消す）*/
  try { const d = load(p); const m = [...(d.party || [])].find((x) => x && (x.id === d.partnerId || x.partner || x.look)) || d.party[0]; const S = stageOf(p); let q = fwd(p, 2, 1.6); if (S && q) q = freeNear(S, q, null, 1.3) || q; if (!m || !q || !SPECIES[m.sp]) return null;
    const g = p.dimension.spawnEntity(MON_TYPE, q); g.addTag("mrpg_temp"); g.addTag("mrpg_cine"); setLook(g, m.sp); (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(g.id); if (S) addActor(S, g, null, null); try { g.teleport(q, { facingLocation: p.getHeadLocation() }); } catch {} return g; } catch { return null; }
}
function rmCine(g) { try { if (g) { globalThis.__mqCine?.delete(g.id); if (g.isValid()) g.remove(); } } catch {} }
/* 第122版: 演出だけの モンスター（オルドの 相棒 ハク・レイの 竜など）。rmCine で 消す */
const HAKU_SP = SPECIES.hbea14 ? "hbea14" : SPECIES.hbea01 ? "hbea01" : ORDER[0];
function monEnt(p, q, sid, nm) {
  try { if (!q || !SPECIES[sid]) return null; const S = stageOf(p); if (S) q = freeNear(S, q, null, 1.6, 3) || q; const g = p.dimension.spawnEntity(MON_TYPE, q); if (S) addActor(S, g, null, null); g.addTag("mrpg_temp"); g.addTag("mrpg_cine"); setLook(g, sid); g.nameTag = nm || "";
    (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(g.id); try { g.teleport(q, { facingLocation: p.getHeadLocation() }); } catch {} return g; } catch { return null; }
}
const hakuEnt = (p, q) => monEnt(p, q, HAKU_SP, "§fハク");
const DRAGON_SP = () => (SPECIES.hdra12 ? "hdra12" : ORDER.find((x) => SPECIES[x].fam === "dragon" && SPECIES[x].sz === "L" && !SPECIES[x].hidden) || HAKU_SP);   /* レイの 竜 */
function ride(m, r) { try { const c = m && r && m.getComponent("minecraft:rideable"); return !!(c && c.addRider(r)); } catch { return false; } }   /* 乗れない ときは 横を 歩く */
async function stoneFx(p, e, nm) {   /* 足もとから 灰色に なって 石に なる */
  if (!ok(e)) return; sound(p, "block.stone.break", 0.6);
  for (let k = 0; k < 6; k++) { if (!ok(e)) return; burst(p.dimension, e.location, k % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.6, k * 0.35); await wait(4); }
  sound(p, "block.stone.place", 0.8); try { e.setProperty("mrpg:mv", false); } catch {} if (nm) try { e.nameTag = nm; } catch {}
}
function spkClean(p) { try { for (const e of p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_autospk"] })) if (e.getDynamicProperty("mrpg:spkOwner") === p.id) e.remove(); } catch {} }
function gotShow(p, t, got) { big(p, t, got.length ? `§e${got.join("・")}` : ""); for (const x of got) try { p.sendMessage(`§e${x}`); } catch {} }
/* 第109版: 話す 人が その場に いなければ 出す（オルドなどが 声だけで 姿が なかった）。いれば その人が 身ぶりで 話す */
const SPK = { "オルド": () => PJ("ordo", 8), "レイ": () => 17, "セオ": () => 18, "ガロ": () => PJ("garo", 9), "ヴァルカ": () => PJ("valka", 10), "ベリル": () => PJ("beryl", 9), "マリン": () => PJ("marin", 9), "ルウ": () => PJ("ruu", 9), "ロウ": () => PJ("rou", 9), "ピコ": () => PJ("pico", 9), "ヨミ": () => PJ("yomi", 9), "老人 イザク": () => PJ("isak", 8), "砂王 ラシード": () => PJ("rashid", 8), "女王 エルゼ": () => PJ("elze", 8), "冥王 モルテ": () => PJ("morte", 8), "アルカ十三世": () => PJ("arca13", 8), "ムサシ": () => 19 };
setSpeakerFinder((p, who) => {
  const key = String(who).replace(/§./g, "").trim(), short = key.split(" ").pop();
  try { for (const e of p.dimension.getEntities({ type: "mrpg:npc", location: p.location, maxDistance: 14 })) { const n = String(e.nameTag || "").replace(/§./g, ""); if (n && (n.includes(key) || n.split(" ").pop() === short)) { const S1 = stageFor(e); if (S1 && S1.pid !== p.id) continue; return e; } } } catch {}   /* マルチ: ほかの 人の 場面の 役者は 使わない */
  let f = SPK[key]; { const h = heroOf(p); if (h && key === h.name) f = () => PJ(h.key, 9); } if (!f) return null;
  const e = npcNear(p, `§e${key}`, f()); if (e) try { e.addTag("mrpg_autospk"); e.setDynamicProperty("mrpg:spkOwner", p.id); } catch {}
  return e;
});
// v2.9.12: 物語の 戦いは 始まる 前に 聞く（着いた とたんに 戦いに ならない）。「あとで」なら 少し たってから もう一度
const MQRUN_KEY = new Set();   // v2.9.13: だいじなもので 始まった 段
const MQASK = new Set(), MQRUN = new Set(), SPAWNED = new Map(), LATER = { later: true };
function laterClean(p) { for (const e of SPAWNED.get(p.id) || []) rm(e); SPAWNED.delete(p.id); }
// 物語の 戦い（勝っても 負けても 仲間は 回復。お金は へらない）
const TALKERS = new Map();   // v3.0: 会話の ために 出した 人（戦いが 始まる ときに 消す。ライバルが 戦いの 場に 残らない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { for (const e of TALKERS.get(playerId) || []) rm(e); TALKERS.delete(playerId); }); } catch {}
async function battle(p, foe, info) {
  const d0 = load(p); if (!canFight(d0)) return "_noparty";
  for (const e of TALKERS.get(p.id) || []) rm(e); TALKERS.delete(p.id);
  if (MQASK.has(p.id)) {
    MQASK.delete(p.id);
    if (!info.asked && !(await confirm(p, "物語の 戦い", `§c§l戦いが 始まる！§r\n\n§f相手: §e${info.name || "？？？"}\n${info.heal === false ? "§c仲間の 回復は なし。" : "§7仲間は 戦いの 前に 全回復する。"}${info.scripted ? "\n§e（この 戦いは 勝てなくても 物語は 進む）" : "\n§7（負けても その場で もう一度 挑める）"}\n§7「あとで」を えらんだ ときは、ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度 起きる（だいじなものの 戦いは その だいじなものを もう一度 使う）。それまで 物語は 先へ 進まない。`, "戦う", "あとで"))) throw LATER;
  }
  if (info.heal !== false) { for (const m of d0.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d0); }
  let res = null;
  busy.delete(p.id);   // 戦いは 自分で busy を つける
  if (inScene(p)) { cineSting(p, "§e§lBATTLE", 26); cineFx(p, "s", 22); await wait(22); }   /* 第125版: 戦いの 前の 大きな 文字 */
  scenePause(p);   /* 第123版: 戦いは 自分の カメラと HUD */
  try { res = await fight(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", friends: true, ...info }); } catch (e) { console.warn(`[MonsterRPG] saga fight: ${e}`); }
  // v2.9.13: 負けたら その場で「もう一度 挑む」（決まった 負けの できごとは のぞく）
  for (let k = 0; k < 5 && res === "lose" && !info.scripted && info.heal !== false; k++) {   // 回復なしの 連戦は その場で やりなおさない
    busy.add(p.id);   // 再戦の 画面の あいだは ほかの 人の 申しこみを 止める
    let again = false; try { if (ok(p)) again = await confirm(p, "負けて しまった……", `§f相手: §e${info.name || "？？？"}\n\n§fもう一度 挑みますか？\n§7（仲間は 全回復する。${!MQRUN.has(p.id) ? "「あとで」なら また 今度 挑める" : `「あとで」なら ${MQRUN_KEY.has(p.id) ? "もう一度 だいじなものを 使えば" : "ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶと"} もう一度 起きる`}）`, "もう一度 挑む", "あとで"); } catch {}
    if (!again || !ok(p)) break;
    const dr = load(p); if (!dr) break;
    for (const m of dr.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, dr);
    busy.delete(p.id);
    try { res = await fight(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", friends: true, ...info, asked: true }); } catch (e) { console.warn(`[MonsterRPG] saga fight: ${e}`); res = null; }
  }
  if (EVT.has(p.id)) busy.add(p.id);   // 戦いの あとも 物語の 会話が 終わるまで ほかの できごとを 止める
  if (ok(p)) sceneResume(p);
  const d = load(p); if (d && res !== "win") { for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = Math.max(m.hp, Math.floor(c.hp / 2)); m.mp = Math.max(m.mp, Math.floor(c.mp / 2)); } save(p, d); }
  return res;
}
function reward(p, d, g, items = [], mark = true) {   /* 第106版: 段の とちゅうの ごほうびは mark=false（段を 終えた 印を つけない） */
  const got = [];
  if (mark && MQRUN.has(p.id)) { const s0 = qs(d); s0.mqPaid = s0.mq ?? 0; }   // v2.9.12: ごほうびを わたした 段は とちゅうで 落ちても 先へ 進める（2回 もらえない）
  if (g) { d.gold += g; got.push(gold(g)); }
  for (let [id, n] of items) { if (id === "SEED2") id = seedId(2); if (id === "SEED3") id = seedId(3); if (!ITEMS[id]) continue; giveItem(p, `mrpg:${id}`, n || 1); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); }
  return got;
}
export function homeTp(p) {
  const h = homeInfo(); const s = SP();
  const at = h && h.built ? { x: h.x, y: h.y + 0.1, z: h.z } : { x: s.x + 0.5, y: s.y + 0.2, z: s.z + 0.5 };
  try { p.teleport(at, { dimension: world.getDimension("overworld") }); } catch {}
  try { p.addEffect("slow_falling", 100, { showParticles: false }); } catch {}
}

// ---------- 状況（地下・海・町・ステージ）----------
function underground(p) {
  try {
    const l = p.location; if (p.dimension.id !== "minecraft:overworld" || l.y > 58) return false;
    const x = Math.floor(l.x), z = Math.floor(l.z), y = Math.floor(l.y);
    for (let dy = 2; dy < 22; dy++) { const t = p.dimension.getBlock({ x, y: y + dy, z })?.typeId || ""; if (!t) return false; if (t !== "minecraft:air" && !t.includes("leaves") && !t.includes("water") && !t.includes("glass")) return true; }
  } catch {}
  return false;
}
// v2.9.12: 物語で 作った 洞くつの 中（階段の 下の ほう〜広間）に いるか
export function inCave(p, R) {
  try {
    if (p.dimension.id !== "minecraft:overworld") return false;
    const v = caveInfo(R); if (!v || !v.built) return false;
    const l = p.location, zEnd = v.hall ? v.hall.z + 10 : v.z + 70;
    return Math.abs(l.x - v.x) < 8 && l.z >= v.z - 4 && l.z <= zEnd && l.y < v.y - 6;
  } catch { return false; }
}
function depthOf(p) { try { const l = p.location; return underwater(p) ? waterDepth(p.dimension, Math.floor(l.x), Math.floor(l.y) + 1, Math.floor(l.z)) : 0; } catch { return 0; } }
function stageNear(p, r = 40) {   /* v2.9.12: 右上の「この あたり」と おなじ 40 */
  const R = regAt(p.location);
  for (const L of landSites(R)) { const I = landInfo(L.key); if (I && I.built && Math.hypot(p.location.x - L.x, p.location.z - L.z) < r) return { ...L, name: I.name, r: R }; }
  return null;
}
const exempt = (p) => { try { const l = p.location; if (p.dimension.id !== "minecraft:overworld" || l.y > 180 || busy.has(p.id)) return true; if (typeof p.getDynamicProperty("mrpg:dg") === "string" || typeof p.getDynamicProperty("mrpg:ret") === "string") return true; const s = SP(); return Math.hypot(l.x - s.x, l.z - s.z) > 4200; } catch { return true; } };

// ---------- v2.9: 冤罪 → 城の 牢屋（負けイベント）----------
const _jh = (id) => { let h = 7; for (const c of String(id || "")) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
// v2.9.12: 牢屋の 番号は 入る ときに 空いて いる ものを えらんで 記録（ほかの 人と 同じ 牢屋に ならない）
function jailPeek(p) { try { const v = p.getDynamicProperty("mrpg:jailk"); if (typeof v === "number") return v; } catch {} return null; }   // v3.0: 読むだけ（入って いない 人には 番号を わりあてない）
function jailSlot(p) {
  try { const v = p.getDynamicProperty("mrpg:jailk"); if (typeof v === "number") return v; } catch {}
  let R = {}; try { R = JSON.parse(world.getDynamicProperty("mrpg:jailslots") || "{}"); } catch {}
  if (typeof R[p.id] === "number") { try { p.setDynamicProperty("mrpg:jailk", R[p.id]); } catch {} return R[p.id]; }
  const used = new Set(Object.values(R));   // v2.9.12: ワールドに 記録（ぬけて いる 人の 牢屋も ほかの 人に わたさない）
  let k = _jh(p.id) % 64; for (let n = 0; n < 64 && used.has(k); n++) k = (k + 1) % 64;
  try { p.setDynamicProperty("mrpg:jailk", k); } catch {}
  R[p.id] = k; try { world.setDynamicProperty("mrpg:jailslots", JSON.stringify(R)); } catch {}
  return k;
}
const JOFF = () => Math.round(720 * LAYOUT.k);   /* 第99版: 寄せた 配置では 地形の 中に */
const JAIL = (p) => { const s = SP(), k = p ? jailSlot(p) : 0; return { x: Math.floor(s.x) - JOFF() - (k % 8) * 24, y: 232, z: Math.floor(s.z) - JOFF() - Math.floor(k / 8) * 24 }; };   // v2.9.2: 人ごとに べつの 牢屋
function jcmd(dim, c) { try { if (typeof dim.runCommand === "function") dim.runCommand(c); else dim.runCommandAsync(c); } catch {} }
export const inJail = (p) => { try { const k = jailPeek(p); if (k === null) return false; const s = SP(), J = { x: Math.floor(s.x) - JOFF() - (k % 8) * 24, y: 232, z: Math.floor(s.z) - JOFF() - Math.floor(k / 8) * 24 }, l = p.location; return p.dimension.id === "minecraft:overworld" && Math.abs(l.x - J.x) < 12 && Math.abs(l.z - J.z) < 12 && Math.abs(l.y - J.y) < 12; } catch { return false; } };
async function buildJail(ow, J) {
  jcmd(ow, `tickingarea add ${J.x - 8} 0 ${J.z - 8} ${J.x + 8} 0 ${J.z + 8} mrpg_jail_${J.x}_${J.z}`);
  for (let t = 0; t < 40; t++) { let okb = false; try { okb = !!ow.getBlock({ x: J.x, y: J.y, z: J.z }); } catch {} if (okb) break; await wait(5); }
  const C = [`fill ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} stone_bricks`, `fill ${J.x - 4} ${J.y} ${J.z - 4} ${J.x + 4} ${J.y + 4} ${J.z + 4} air`,
    `fill ${J.x - 4} ${J.y - 1} ${J.z - 4} ${J.x + 4} ${J.y - 1} ${J.z + 4} cobblestone`, `fill ${J.x - 1} ${J.y} ${J.z - 4} ${J.x - 1} ${J.y + 3} ${J.z + 4} iron_bars`,
    `fill ${J.x - 3} ${J.y} ${J.z - 4} ${J.x - 2} ${J.y} ${J.z - 3} hay_block`, `setblock ${J.x - 4} ${J.y + 3} ${J.z} soul_lantern`, `setblock ${J.x + 3} ${J.y + 3} ${J.z + 3} lantern`,
    `fill ${J.x - 5} ${J.y + 2} ${J.z - 1} ${J.x - 5} ${J.y + 2} ${J.z + 1} iron_bars`, `setblock ${J.x - 3} ${J.y} ${J.z + 3} iron_bars`, `fill ${J.x + 1} ${J.y} ${J.z + 4} ${J.x + 4} ${J.y} ${J.z + 4} barrel`,
    `setblock ${J.x + 3} ${J.y} ${J.z - 3} smithing_table`, `fill ${J.x - 4} ${J.y + 4} ${J.z - 4} ${J.x - 2} ${J.y + 4} ${J.z - 4} web`];
  for (const c of C) jcmd(ow, c);
}
function clearJail(ow, J) { jcmd(ow, `fill ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} air`); jcmd(ow, `tickingarea remove mrpg_jail_${J.x}_${J.z}`); }
// v2.9.12: 牢屋に いる まま ぬけた 人の 読みこみ範囲は 外す（もどって きたら 外へ 出す 処理は 別に ある）
try { world.beforeEvents.playerLeave.subscribe((e) => { try { const p = e.player; if (!inJail(p)) return; const J = JAIL(p); system.run(() => { try { world.getDimension("overworld").runCommand(`tickingarea remove mrpg_jail_${J.x}_${J.z}`); } catch {} }); } catch {} }); } catch {}
export function releaseJail(p) {
  const d = load(p); const s = d ? qs(d) : null;
  const r = s && s.jailRet;
  try { if (r) p.teleport({ x: r.x, y: r.y + 0.2, z: r.z }, { dimension: world.getDimension("overworld") }); else homeTp(p); } catch {}
  try { p.addEffect("slow_falling", 200, { showParticles: false }); p.addEffect("resistance", 200, { amplifier: 4, showParticles: false }); } catch {}
}
async function jailEvent(p) {
  const d = load(p); if (!d) return false;
  const s = qs(d);
  const ret = { x: p.location.x, y: p.location.y, z: p.location.z };
  try { const gy = groundY(p.dimension, ret.x, ret.z, Math.floor(ret.y)); if (typeof gy === "number" && gy <= ret.y) ret.y = gy; } catch {}   // 空中なら 地面へ
  /* 第121版: 衛兵に 囲まれる（左右から 槍を かまえて 走って くる）*/
  const H = heroBox(p, true);
  const e = npcNear(p, "§6サンドリア城の 衛兵長 ガルム", PJ("glen", 16));
  const g1 = npcNear(p, "§6サンドリア城の 衛兵", PJ("glen", 16)), g2 = npcNear(p, "§6サンドリア城の 衛兵", PJ("glen", 16));
  act(g1, "guard"); act(g2, "guard");
  big(p, "§c§l止まれ！", "§f衛兵たちに 囲まれた……！", "mob.villager.no");
  re(H.e, "shock", "!"); act(H.e, "guard");
  await say(p, "ガルム", ["{angry,!,low}そこの 旅人、止まれ！ 王墓を 荒らした 一味だな！", "石板を 持った よそ者が 王墓に 入ったと 報せが あった。言い訳は 牢で 聞く！"]);
  await hsay(p, ["{rage,怒,jump}はあ！？ 王墓なんて まだ 見ても いないよ！"]);
  const eR = npcNear(p, "§bライバル レイ", RIVAL_JOB); act(eR, "run", false); await wait(12); act(eR, 0);
  await say(p, "レイ", ["{angry,!}待てよ！ オレたち、今 着いた ばかりだ！"]);
  try {
    await battle(p, team(["golem", "sword"], 75, 3, 45), { name: "衛兵長 ガルム", arena: "冤罪！", theme: "desert", speaker: "ガルム", hpk: 40, extra: 0.6, tag: "衛兵長", heal: false,
      scripted: { turns: 2, lines: ["§6§l城の 衛兵たちが 次々と なだれこんできた！", "§7多勢に 無勢…… 仲間たちが 取りおさえられていく！"] }, lines: { half: "抵抗するか！ ますます 怪しい！" } });
  } finally { rm(e); rm(g1); rm(g2); rm(eR); H.rm(); }
  const d2 = load(p); if (!d2) return false; const s2 = qs(d2); s2.jailRet = ret; save(p, d2);
  // 牢屋へ
  const ow = world.getDimension("overworld"), J = JAIL(p);
  cmd(p, "camera @s fade time 0.2 1.6 0.6 color 0 0 0");
  try { showTitle(p, "§8……", { subtitle: "§7目の 前が 真っ暗に なった", fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  await buildJail(ow, J);
  // v2.9.9: とちゅうで ぬけた ときは 牢屋を のこす（もどった とき 空中に 落ちない。もどると 自動で 外へ 出して 片づける）
  try { return await jailInside(p, ow, J); } finally { let valid = false; try { valid = !!p.isValid?.(); } catch {} if (valid && inJail(p)) { try { clearJail(ow, J); } catch {} } }
}
async function jailInside(p, ow, J) {
  try { p.addEffect("slow_falling", 600, { showParticles: false }); p.addEffect("resistance", 600, { amplifier: 4, showParticles: false }); } catch {}
  let floorOk = false; try { floorOk = (ow.getBlock({ x: J.x + 2, y: J.y - 1, z: J.z })?.typeId || "").includes("cobblestone"); } catch {}
  if (!floorOk) {   // 牢屋を 作れなかった ときは その場で 話だけ
    await narr(p, "地下牢", ["§7（あなたは 城の 地下牢に 連れて いかれた……）"]);
    clearJail(ow, J);
  } else try { p.teleport({ x: J.x + 2.5, y: J.y + 0.1, z: J.z + 0.5 }, { dimension: ow, facingLocation: { x: J.x - 3, y: J.y + 1.5, z: J.z + 0.5 } }); } catch {}
  try { p.addEffect("slowness", 400, { amplifier: 2, showParticles: false }); } catch {}
  await wait(30);
  /* 第121版: 牢の 中の 位置（鉄格子は x-1。こちら側が 牢・向こう側が 通路）。作れなかった ときは ふつうに 並ぶ */
  const at = (dx, dz) => (floorOk ? { x: J.x + dx, y: J.y, z: J.z + dz } : null);
  big(p, "§8§lサンドリア城 地下牢", "§7ひんやりした 石の 床……", "random.door_close");
  if (floorOk) { camAt(p, { x: J.x + 3.8, y: J.y + 3, z: J.z - 3.6 }, { x: J.x + 0.5, y: J.y + 0.8, z: J.z + 1 }, 0.6); await wait(30); }   /* 牢の すみから 見下ろす 引きの 絵 */
  const eH = place(heroNear(p, true), p, at(1.5, -2.5)); act(eH, "sad");
  await hsay(p, ["{sad,…}……王墓荒らし、だって。何も して ないのに。", "{rage,怒,up}あの 衛兵長、次 会ったら 文句 百個 言って やるんだから！"]);
  act(eH, 0);
  const eJ = npcAt(p, "§7牢番", PJ("glen", 16), at(-2.5, 0.5));
  await say(p, "牢番", ["{angry,low}おとなしく しておれ。明日の 朝には 裁きが くだる。"]);
  if (floorOk) await go(eJ, at(-2.5, -3.5), 14); rm(eJ);
  /* 第106版: 同じ 牢の 老人イザク・牢破り・看守ブルーノ */
  if (!qs(load(p) || {}).jailIsak) {
    const eI = npcAt(p, "§7老人 イザク", PJ("isak", 8), at(3.5, 3.2)); act(eI, "down");   /* 牢の すみで 横に なって いた */
    re(eH, "shock", "!");
    await hsay(p, ["{shock,!,jump}わっ！ す、すみに だれか 寝てる！"]);
    act(eI, "kneel");
    await say(p, "老人 イザク", ["{closed}……新入りかね。わしは イザク。この 牢で 七年に なる。", "{sad}罪状？ 王墓に 入った。……七年前、娘が 石に なってな。石に なった 者は、王墓の 石の 間に 葬られる 決まりなんじゃ。", "{smile}花を 一輪、届けたかった だけじゃよ。", "{up}おまえさんの 目は まだ 死んでおらん。……ここを 出たいか？"]);
    await hsay(p, ["{shock,!}……七年も！？ 花を 届けたかった だけで？"]);
    act(eI, "hold");
    await say(p, "老人 イザク", ["{smile,up}この 骨で 鍵を 開けられる。七年 かけて 削ったんじゃ。", "{closed}わしは もう 足が 動かん。おまえさんが 行け。", "{sad}……いつか、娘の 墓に 花を 頼む。"]);
    act(eI, "kneel");
    sound(p, "random.door_open", 0.8); burst(p.dimension, at(-1, 0.5) || fwd(p, 3), "minecraft:critical_hit_emitter", 4, 0.3, 1);
    await hsay(p, ["{smile,☆,jump}開いた！ ……おじいさん、ありがとう！ 花の こと、ちゃんと 覚えとく！"]);
    const eG = npcAt(p, "§8看守 ブルーノ", PJ("bruno", 16), at(-2.5, -3.5)); if (floorOk) await go(eG, at(-2.5, 0.5), 10, true);
    await say(p, "看守 ブルーノ", ["{shock,!,jump}おい、何の 音だ！ ……鍵が 開いてる！？ 逃がすか！"]);
    await hsay(p, ["{angry,怒}どいて！ 通して もらうよ！"]);
    const r = await battle(p, team(["golem", "beast"], 34, 2, 6), { name: "看守 ブルーノ", arena: "牢破り", theme: "desert", speaker: "看守 ブルーノ", lines: { half: "くそっ、応援を 呼べ！", low: "……行け。どうせ 外も 地獄だ" } });
    rm(eG); rm(eI);
    if (r !== "win") { await say(p, "看守 ブルーノ", ["牢に もどれ！ ……次は 見張りを 倍に するぞ"]); }
    const dI = load(p); if (dI) { qs(dI).jailIsak = 1; save(p, dI); }
  }
  await wait(40);
  sound(p, "random.anvil_land", 0.7);
  const eH2 = place(heroNear(p, true), p, at(1.5, -2.5));
  const eR = npcAt(p, "§bライバル レイ", RIVAL_JOB, at(-2.5, 0.5));   /* 鉄格子の 向こうに レイ */
  await hsay(p, ["{shock,!,jump}レイ！？"]);
  await say(p, "レイ", ["{sweat,汗}おい、大丈夫か！？ オレは なんとか 逃げきれた。", "{smile}……ちょっと、いい ものを 手に 入れてさ。体が 軽いんだ。今なら 衛兵が 十人 来ても 負ける 気が しない。"]);
  camNear(p, eR, 1.3, 1.6); redGlow(eR); sound(p, "mob.wither.ambient", 1.6); await wait(16);   /* 目が 一瞬 赤く 光る */
  await hsay(p, ["{?,up}……今、レイの 目……赤く 光らなかった？"]);
  await say(p, "レイ", ["{?}ん？ 何の 話だ？ ……それより、セオが 真犯人を 見つけた。衛兵に 化けた ノクス団だ。"]);
  const eGa = npcAt(p, "§6衛兵長 ガルム", PJ("glen", 16), at(-2.5, -1.5)); act(eGa, "kneel");   /* 頭を 下げる */
  await say(p, "ガルム", ["{sad,汗}……すまなかった。真犯人は 捕らえた。", "詫びの しるしだ。城の 倉庫から 持って いってくれ。"]);
  await hsay(p, ["{rage,怒,jump}すまなかった、で 済むと 思ってるの！？ ……もらえる ものは もらうけど！"]);
  rm(eR); rm(eGa); rm(eH2); rm(eH);
  const d3 = load(p); if (!d3) return false; const s3 = qs(d3); s3.jailDone = 1;
  s3.keys = [...new Set([...(s3.keys || []), "k_tomb"])];   // v2.9.12: 先に 記録（このあと ぬけても 地図は もどる）
  const got = reward(p, d3, 5000, [["c_herbs", 3], ["g_sp2", 1]]); save(p, d3);
  try { p.removeEffect("slowness"); } catch {}
  releaseJail(p);
  clearJail(ow, J);
  gotShow(p, "§a§l釈放された！", got);
  await wait(40);
  /* 第106版: イザクの 公開処刑（主人公は 見ている しか できない）。第121版: 文で 語らず、目の 前で 起きる */
  big(p, "§4§l城の 前の 広場", "§7人だかりが できている", "mob.wither.ambient");
  const eI2 = npcNear(p, "§7老人 イザク", PJ("isak", 8), true), eRa = npcNear(p, "§6砂王 ラシード", PJ("rashid", 8), true);
  const eH3 = heroNear(p, true), eR3 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true);
  act(eI2, "sad");   /* 縄で しばられ、うなだれて いる */
  { const c = fwd(p, -3, 0, 2.2), q = fwd(p, 3.5, 0, 1.2); if (c && q) camAt(p, c, q, 0.6); await wait(24); }
  await hsay(p, ["{shock,!,jump}……え？ イザクさん！？ なんで しばられてるの！？"]);
  await say(p, "砂王 ラシード", ["{closed,low}罪状は、囚人の 脱獄を 手助けした こと。", "{angry,low}王の 法は、砂より 重い。"]);
  await say(p, "老人 イザク", ["{smile,up}……"]);   /* 一度だけ こちらを 見て、小さく うなずく */
  await hsay(p, ["{rage,怒,jump}待って！ その人は 何も――"]);
  cmd(p, "camera @s fade time 0.1 1.4 0.8 color 0 0 0"); sound(p, "random.anvil_land", 0.5); shake(p, 0.3, 0.3); await wait(6);
  await narr(p, "広場", ["§8刃が 落ちる 音が した。"]);
  { const q = ok(eI2) ? eI2.location : null; rm(eI2); burst(p.dimension, q, "minecraft:white_smoke_particle", 10, 0.8, 0.2); }   /* 砂が 台の 上を 覆う */
  await leave(eRa, p, 10, false);
  await hsay(p, ["{shock,…,up}…………。", "{angry,up}……こんなの、ぜったい おかしいよ。"]);
  await say(p, "レイ", ["{shock,up}……なんだよ、これ。", "{rage,怒,up}あの じいさん、おまえを 逃がした だけだろ……！ なんで……！"]);
  act(eR3, "hold"); camNear(p, eR3, 1.8, 1.0); redGlow(eR3); sound(p, "mob.wither.ambient", 0.8); await wait(16);   /* 握った 拳の 中で、何かが 赤黒く 光る */
  re(eH3, "shock", "!");
  const g = palEnt(p); if (g) { camNear(p, g, 2.4, 0.8); await wait(8); }   /* 相棒が 足もとから はなれない */
  await pal(p, ["……こわい。", "でも、はなれない。"]);
  rmCine(g); rm(eR3); rm(eH3);
  return true;
}
// ---------- メインクエスト ----------
// trig: いつ 起きるか（c = 状況）／ key: その だいじなものを 使うと 起きる ／ run: 進めば true
const has = (c, id) => hasKey(c.p, id);
const RIVAL_JOB = 17, TRAITOR_JOB = 18;   // v2.9.13: 作者の スキン（ライバル・学者セオ）
export const MQ = [
  { r: 0, ch: "第1章 旅立ち", at: "town", hint: "§fライバル §bレイ§f と 最初の 勝負！ §7（負けても もう一度 挑める）", trig: (c) => true,
    run: async (p, d) => {
      if (!qs(d).introDone) {
        /* 第115版: 旅立ちの 朝。コンパスを 作った 幼なじみ（ヒロイン）を えらぶ */
        if (!qs(load(p) || d).hero) {
          const pick = await choose(p, "幼なじみ", "§f§lあなたの 幼なじみは だれ？\n\n§7小さい ころから いっしょに 育った 仲良しで、好奇心で 旅に ついて くる 仲間です。あとから かえる ことは できません。", HEROES.map((h) => [`§l${h[1]}§r\n§8${h[2]}`, `textures/ui/mrpg/h_${h[0]}`]));
          if (!(pick >= 0)) return false; const dh = load(p); if (!dh) return false; qs(dh).hero = HEROES[pick][0]; save(p, dh);
        }
        const eH = heroNear(p);
        await hsay(p, ["{!,jump}あっ、いた いた！ おーい！", "{rage,怒}もう、遅い！ 今日が 旅立ちの 日だって、あれだけ 言ったのに！"]);
        await hsay(p, ["{blush,up}……ま、いいけど。はい、これ。", "{smile,☆}じゃーん！ わたしが 作った §e冒険の コンパス§f！ 行きたい 場所の 方を、ちゃんと 指して くれるの。"]);
        giveItem(p, "mrpg:navi", 1); sound(p, "random.levelup", 1);
        await hsay(p, ["{sweat,汗}……三日 寝ないで 作ったんだから、なくしたら 怒るからね。"]);
        /* 第122版: 最初の 仲間は オルドの 牧場の 子。牧場の 奥で ハクが 眠って いる */
        const g0 = palEnt(p); if (g0) { camNear(p, g0, 2.2, 0.7); await wait(10); }
        await hsay(p, ["{?}……その子、村長の 牧場の 子でしょ？ 朝から ずっと しっぽ 振ってる。"]);
        rmCine(g0);
        const eO = npcNear(p, "§eオルド", PJ("ordo", 8));
        await say(p, "オルド", ["ほっほ。朝から にぎやかじゃのう。"]);
        await hsay(p, ["{?,up}ねえ 村長。村長って、モンスター なんて 持ってたっけ？ あの 牧場の 子たち、どこから 来たの？"]);
        re(eO, "smile", "♪");
        await say(p, "オルド", ["{smile}ほっほ。昔、ちょっとな。"]);
        await hsay(p, ["{rage,怒,jump}ちょっとって 何よ！ ……もう、すぐ 笑って ごまかすんだから。"]);
        { const hq = fwd(p, 8, 3); const hk = hakuEnt(p, hq); if (hk) { camPt(p, hk.location, 4, 1); await wait(16); }
          await say(p, "オルド", ["{closed}旅に 出る 前に、牧場の 奥で 寝とる §fハク§f にも あいさつ して いけ。"]);
          await hsay(p, ["{smile,♪}ハク！ 小さい ころ、あの 背中で よく お昼寝 したよね。", "{sweat,汗}……たてがみに 絵を 描いて、二人で 叱られたっけ。"]);
          rmCine(hk); }
        await say(p, "オルド", ["{up}……さて。旅に 出る 前に、ひとつ 大事な 話を させて おくれ。"]);
        await say(p, "オルド", ["{low}大昔、§6「王」§f と 呼ばれる ものが おった。人と モンスターの §e心§f を 呑みこむ 怪物じゃ。", "人々は 王と、王に 従う 十四の §6主§f を、§d十五枚の 石板§f に 封じた。……その 封印が、今 ゆるみ始めて おる。"]);
        await hsay(p, ["{shock,!,jump}ええっ！？ じゃあ、ときどき 町の 外に 出る あの 黒い 影って……"]);
        await say(p, "オルド", ["{closed}……うむ。そして 石板は、ごく まれに §b反応する 者§f を 選ぶ。", "{up}おまえさんじゃよ。"]);
        await hsay(p, ["{shock,!,up}…………へ？", "{rage,怒,jump}な、なんで この 寝ぼすけが！？ ……あっ、ちがう、すごい！ すごいけど！"]);
        await say(p, "オルド", ["8つの 地方の §6地方マスター§f が、石板を 一枚ずつ 預かって おる。勝って 石板を 受け取り、目覚めた 主を 封じ直して くれんか。"]);
        await hsay(p, ["{smile,☆,up}……ねえ。それって、すっごく おもしろそう！", "{smile,♪}決めた、わたしも ついて いく！ 小さい ころから、あなたが 行く 所には いつも いっしょ だったでしょ？", "{blush}……それに、コンパスの 作り主が いないと 困るでしょ。"]);
        await say(p, "オルド", ["ほっほ、頼もしい。……おお、孫の §bレイ§f が 来おった。"]);
        rm(eO); rm(eH);
        const d1 = load(p); if (d1) { qs(d1).introDone = 1; save(p, d1); }
      }
      /* 第122版: レイは オルドの 孫で、小さい ころからの 顔なじみ（一つ 年上）*/
      const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
      await say(p, "レイ", ["{closed}じいちゃんから 聞いた。……石板に 選ばれたのは、おまえ なんだってな。", "{angry}オレは ずっと、石板を 任される 日の ために 竜と 鍛えて きた。", "{sad,up}……なのに、選ばれたのは おまえか。小さい ころ、オレの 後ろを ついて 回ってた おまえが。", "{angry,!}文句を 言っても 始まらない。だから、確かめさせろ。"]);
      { const eH0 = heroNear(p, true); await hsay(p, ["{rage,怒}レイ！ 一つ 年上なんだから、大人げない こと 言わないでよ！"]); rm(eH0); }
      await duel(p, "§b§lレイ", "§fレイの 竜が 広場に 飛びこんで きた！", { fams: ["dragon"] });
      const res = await battle(p, team(["dragon"], 1, 1, 0).map((t) => ({ ...t, lv: 1, q: 0 })), { name: "ライバル レイ", arena: "はじめての 勝負", easy: true, speaker: "レイ", lines: { half: "……やるな。手を 抜いてる わけじゃ ないのに", low: "くそっ……ここで 負けたら、オレは……！" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await say(p, "レイ", ["……オレの 勝ちだ。でも、石板が 選んだのは おまえの ままだ。", "そんな 腕で 主に 挑む 気か。……もう一度 来い。", RT(p)]); return false; }
      const eR1 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true); act(eR1, "kneel");
      await say(p, "レイ", ["{sad,…}……負けた。", "{closed}わかったよ。石板が おまえを 選んだ わけ、少しだけな。", "{angry,up}でも、オレは あきらめない。いつか 必ず 追いつく。……覚えて おけよ。"]);
      act(eR1, 0); await leave(eR1, p, 10, false);
      const eO2 = npcNear(p, "§eオルド", PJ("ordo", 8)); act(eO2, "hold"); re(eO2, "closed");   /* つえを 握る 手に、一瞬 力が こもる */
      await say(p, "オルド", ["……あの子は 負けずぎらいでのう。悪く 思わんで やって くれ。", "まずは §6アルカトラス城§f へ。地方マスター §6ミドリ§f が 一枚目の 石板を 預かって おる。", "町の 外は 物騒に なった。石板を 狙う §5ノクス団§f という 連中が うろついて おる。気を つけるんじゃぞ。", "それと、近ごろ §7学者の セオ§f と いう 若者が 町に 来て おる。石板と、町の まわりに 出る §8黒い 影§f を 調べて おるそうじゃ。会ったら 力に なって くれるじゃろう。", "§7→ 右上の 案内へ"]);
      rm(eO2);
      reward(p, d2, 500, [["c_herbs", 2]]); save(p, d2);
      return true;
    } },
  { r: 0, hint: "§fルミナの §e北の 門§f を 出て、アルカトラス城への 道を 進もう", spot: () => garoSpot(), trig: (c) => c.r === 0 && !c.town,
    run: async (p, d) => {
      const e = npcNear(p, "§cノクス団の 下っぱ ガロ", PJ("garo", 9));
      const eHg = heroNear(p);
      /* 第115版: 相棒との 出会い（ガロと ピコに いじめられて いる 子を 助ける） */
      const palOld = !!findPartner(load(p) || d) || !!(load(p) || d).partnerId, firstMeet = !wonOf(p, "garo1");
      let eV = null, ePk = null;
      if (firstMeet) {
        ePk = npcNear(p, "§d手下 ピコ", PJ("pico", 9));
        eV = palVictim(p, e);
        big(p, "§c！", "§f道の 先で、だれかが 小さな モンスターを 囲んで いる……", "mob.villager.no");
        if (ok(eV)) { lookAt(p, eV); act(e, "point"); }
        await say(p, "ガロ", ["{angry,low}おい、逃がすな ピコ。そいつは 石板の 匂いが する。団に 持って 帰りゃ 金に なる。"]);
        await say(p, "ピコ", ["{sweat,汗}う、うん……！ ……ごめんね、ごめんね……"]);
        if (ok(eV) && ok(e)) { await knock(eV, e.location, 2); sound(p, "mob.wolf.hurt", 1.2); }
        await hsay(p, ["{rage,怒,up}ちょっと！！ なに やってるの！！"]);
        if (ok(eHg) && ok(eV)) { const q = eV.location; await go(eHg, { x: q.x + 0.8, y: q.y, z: q.z + 0.8 }, 12, true); act(eHg, "guard"); }
        await hsay(p, ["{angry,怒}よってたかって 小さい子 いじめて、はずかしく ないの！？ どきなさいよ！"]);
        lookAt(p, e);
        await say(p, "ガロ", ["{angry}……なんだ、お前ら。……いや、待て。", "{!}お前だな、石板が 反応したって いう ガキは。ルミナの 噂は 早いんだよ。", "オレは §5ノクス団§f の ガロ。石板も、そいつも 渡せ。そうすりゃ 手荒な ことは しない。"]);
        await hsay(p, ["{angry}だれが 渡すもんですか。……ほら、やっちゃって！"]);
      } else {
        big(p, "§c！", "§fだれかが 道を ふさいだ！", "mob.villager.no");
        await say(p, "ガロ", ["{angry,low}……止まれ。", "石板を 渡せ。そうすりゃ 手荒な ことは しない。"]);
      }
      const res = wonOf(p, "garo1") ? "win" : await battle(p, team(["beast", "animal", "animal"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "ノクス団の 下っぱ ガロ", arena: "ノクス団", easy: true, speaker: "ガロ", lines: { half: "ちっ……こっちも 引けねえんだよ……！" } });
      if (res === "win") setWon(p, "garo1");
      rm(e); rm(ePk);
      if (res !== "win") { rm(eV); rm(eHg); await say(p, "ガロ", ["……今日は 見逃して やる。次は ねえぞ。", RT(p)]); return false; }
      if (!qs(load(p) || d).palMet) {   /* 助けた 子が 相棒に なる（すでに 相棒が いる 古い セーブは 見送るだけ） */
        if (!ok(eV)) eV = palVictim(p, null);
        if (ok(eV)) { lookAt(p, eV); await go(eV, { x: p.location.x + 0.8, y: p.location.y, z: p.location.z + 0.8 }, 16); }
        await hsay(p, ["{sad}……だいじょうぶ？ いたかったね。", "{!,shock}……あれ？ この子、あなたの 足もとから はなれない。", "{smile,♥,up}ふふっ、なつかれちゃったね。……ねえ、連れて 行って あげようよ。"]);
        rm(eV);
        const dP = load(p); if (!dP) { rm(eHg); return false; }
        let pm = palOld ? findPartner(dP) : null;
        if (!palOld) {
          await notice(p, "相棒との 出会い", "§f助けた 小さな モンスターが、あなたの そばを はなれない。\n\n§eこの 子が あなたの §b相棒§e に なります。§7タイプ（系統）・見た目・名前・性格・初期スキルを 決めよう。");
          pm = await partnerEditor(p, dP, null);
          if (!pm) { rm(eHg); await notice(p, "相棒", "§7ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶと、もう 一度 相棒を 決められます。"); return false; }
        } else await hsay(p, ["{smile}……行っちゃった。元気でね！ §7（小さな モンスターは 森へ 帰って いった）"]);
        const dQ = load(p); if (dQ) { qs(dQ).palMet = 1; save(p, dQ); }
        if (pm && !palOld) await hsay(p, [`{smile,♪}よろしくね、${pm.nm}！ ……わたしの ことも 忘れないでよ？`]);
      }
      rm(eHg);
      const d2 = load(p); if (!d2) return false;
      /* 第106版: 第1章を 濃く（ガロの 連戦・手下の 少年ピコ・町を 襲う 影・セオの 問い） */
      if (!qs(d2).ch1b) {
        if (!qs(load(p) || d2).ch1x) {
        const e2 = npcNear(p, "§cノクス団の 下っぱ ガロ", PJ("garo", 9)), eP = npcNear(p, "§d手下 ピコ", PJ("pico", 9));
        await say(p, "ガロ", ["……待て。まだ 終わって ねえ。"]);
        await say(p, "ピコ", ["兄ちゃん！ ……だいじょうぶ？", "§7（さっき モンスターを 追い回して いた、ぶかぶかの 帽子の 少年が ガロの 前に 飛び出した）", "この人が 石板の……？ ぼくも 戦う。手ぶらで 帰ったら、また 二人とも 外で 寝る ことに なっちゃう。"]);
        await say(p, "ガロ", ["……下がってろって 言ったろ、ピコ。", "§7（ガロは 少年の 帽子を 深く かぶせ直した）", "悪いな、旅人。オレたちは 親も 家も ねえ。ノクス団に 拾われて、やっと 屋根の 下で 飯が 食えるように なったんだ。", "石板を 持って 帰れなきゃ、また 外だ。……だから、二人で 行く。"]);
        const r2 = await battle(p, team(["beast", "animal"], 3, 3).map((t) => ({ ...t, lv: 3, q: 0 })), { name: "ガロと 手下たち", arena: "ノクス団 連戦", easy: true, heal: false, speaker: "ガロ", lines: { half: "ピコ、前に 出るな！ 後ろに いろ！", low: "……くそ、ここまで か……" } });
        rm(e2); rm(eP);
        if (r2 !== "win") { await say(p, "ガロ", ["……悪く 思うな。こっちも 生きるのに 必死なんだ。", RT(p)]); return false; }
        { const dx = load(p); if (dx) { qs(dx).ch1x = 1; save(p, dx); } }
        }
        let e3 = null;
        if (!qs(load(p) || d2).ch1y) {
        e3 = npcNear(p, "§cノクス団の 下っぱ ガロ", PJ("garo", 9)); const eP2 = npcNear(p, "§d手下 ピコ", PJ("pico", 9));
        const eH1 = heroNear(p);
        await say(p, "ピコ", ["{sad}……兄ちゃん、ごめん。ぼく、役に 立たなかった。"]);
        await hsay(p, ["{q}……ねえ、あの子 ふるえてる。ほんとは 戦いたく ないんじゃ ない？"]);
        /* 第115版: 影の 場面は 文字で 説明せず、画面で 見せる */
        act(eP2, "point"); act(e3, "up");
        await say(p, "ピコ", ["……兄ちゃん、あれ。空が……黒い……"]);
        { const L0 = ok(eP2) ? eP2.location : p.location, S0 = stageOf(p), far = S0 ? stagePt(S0, 20, -4) : { x: L0.x, y: L0.y, z: L0.z - 16 };
          if (S0) camAt(p, S0.at(-2.5, 5 * S0.side, 5.5), S0.at(9, -1, 1.5), 0.5); else camAt(p, { x: L0.x + 7, y: L0.y + 6, z: L0.z + 7 }, { x: far.x, y: far.y + 1, z: far.z + 6 }, 0.5);   /* 引きの 絵: 向こうから 影が 来る */
          big(p, "§4§l影", "", "mob.wither.spawn");
          await shadowFlow(p, far, L0, 26);
          boom(p.dimension, L0); sound(p, "random.explode", 1); shake(p, 0.8, 0.8); flash(p, true);
          await Promise.all([knock(e3, L0, 4), (async () => knockP(p, L0))()]);   /* ガロと あなたが 吹っ飛ぶ */
          await wait(6);
          lookAt(p, eP2); await engulf(p, eP2);   /* ピコが 影の うずに 呑まれて 倒れる */
          await wait(10);
          const town = (() => { try { const t = getTown("t0"); return t && t.built ? { x: t.x, y: L0.y, z: t.z } : { x: L0.x, y: L0.y, z: L0.z + 30 }; } catch { return { x: L0.x, y: L0.y, z: L0.z + 30 }; } })();
          camAt(p, S0 ? S0.at(4.5, -3.5 * S0.side, 3) : { x: L0.x - 4, y: L0.y + 3, z: L0.z - 4 }, { x: town.x, y: town.y + 4, z: town.z }, 0.8);   /* 影は 町の 方へ */
          await shadowFlow(p, L0, { x: L0.x + (town.x - L0.x) * 0.6, y: L0.y, z: L0.z + (town.z - L0.z) * 0.6 }, 30);
          if (ok(e3) && ok(eP2)) { const q = eP2.location; await go(e3, { x: q.x + 1.2, y: q.y, z: q.z }, 12, true); } act(e3, "kneel"); lookAt(p, e3); }
        await say(p, "ガロ", ["{shock,!,up}……ピコ！！"]);
        await hsay(p, ["{shock,!,up}……え！？ あの子……呑みこまれた……！？", "{sweat,汗}な、なによ あれ……。さっきまで そこに 立ってたのに……！"]);
        await say(p, "ガロ", ["おい、ピコ。……返事を しろ。", "屋根の ある 所で 寝かせて やるって、約束 したろ。……なあ。"]);
          rm(eP2); rm(eH1); const dy = load(p); if (dy) { qs(dy).ch1y = 1; save(p, dy); }
        } else e3 = npcNear(p, "§cノクス団の 下っぱ ガロ", PJ("garo", 9));
        await duel(p, "§4影の モンスター", "§c影の モンスターが 町を 襲う！");
        const r3 = await battle(p, bossOne(["nether"], 5, 4), { name: "影の モンスター", arena: "町を 襲う 影", theme: "underworld", hpk: 1.6, speaker: "影の モンスター", guests: team(["beast"], 4, 1).map((t) => ({ ...t, owner: "ガロ" })), lines: { half: "………………", low: "……ササヤキ……ガ……トドカ……ナイ……？" } });
        rm(e3);
        if (r3 !== "win") { await say(p, "ガロ", ["くそっ……くそっ！ 立て、まだ 終わってねえ！", RT(p)]); return false; }
        const eP3 = npcNear(p, "§d手下 ピコ", PJ("pico", 9), true), e4 = npcNear(p, "§cノクス団の 下っぱ ガロ", PJ("garo", 9), true);
        act(eP3, "down"); try { const q = eP3.location, S = stageFor(e4), w = (S && freeNear(S, { x: q.x + 1.3, y: q.y, z: q.z }, e4, 1.25, 1.4)) || { x: q.x + 1.3, y: q.y, z: q.z }; if (S) S.dest.set(e4.id, w); e4.teleport(w, { facingLocation: q }); } catch {} act(e4, "hold");   /* 眠った ピコを ガロが だきかかえる */
        lookAt(p, eP3);
        lookAt(p, eP3); await shadowFlow(p, eP3.location, { x: eP3.location.x, y: eP3.location.y + 4, z: eP3.location.z }, 16);   /* 残った 影が ほどけて 消える */
        await say(p, "ガロ", ["{sad,up}……ピコ。……息は、してる。", "{cry,tears}なのに……なんで 起きねえんだよ……"]);
        await say(p, "ガロ", ["……礼は 言わねえ。", "影に 呑まれた やつは、心を 持って いかれる。体は 生きてても、もう 起きねえって 話だ。", "団の 上の 連中は 言ってた。石板を 集めて 王を 起こせば、§e呑まれた 心も 戻る§f って。", "……ピコは、起きるのか。なあ。", "§7（答えを 待たずに、ガロは 眠った ピコを 背負って 去って いった。帽子は ガロの 腰に 下がって いた）"]);
        rm(e4); rm(eP3);
        const d3 = load(p); if (d3) { qs(d3).ch1b = 1; save(p, d3); }
      }
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB);
      lookAt(p, eS); act(eS, "run", false); await wait(14); act(eS, 0);   /* 町の 方から 走って くる セオ */
      await say(p, "セオ", ["大丈夫ですか！？ ……よかった、けがは ないようですね。", "僕は セオ。石板を 研究している 学者です。今の 影を 追って ここまで 来ました。……間に合わなくて、すみません。", "あれは §5影の モンスター§f。封印の ゆるんだ 石板から にじみ出て、人や モンスターの 心を 呑みこむんです。", "§7（セオは あなたの 石板を じっと 見つめ、声を ひそめた）", "……一つ、聞かせて ください。石板から、§5やさしい ささやき§f が 聞こえませんでしたか？"]);
      const qa = await choose(p, "セオ", "§a§lセオ§r\n\n§f「……石板から、やさしい ささやき、聞こえませんでしたか？」", [["何も 聞こえなかった", ICON("i_close")], ["……少し 聞こえた 気が する", ICON("i_book")]]);
      await say(p, "セオ", qa === 1 ? ["……そう、ですか。", "いえ。それは きっと 影の 声です。石板の 声は、もっと…… やさしい ものですから。", "§7（セオの 手が、ほんの 少し ふるえて いた）"] : ["……そうですか。石板は あなたに 反応して いるのに、声は 届かない。", "めずらしい 体質です。……少し、うらやましい。"]);
      await say(p, "セオ", ["これは 僕の 研究メモです。石板と 各地方の ことを 書きとめて あります。迷ったら 開いて ください。", "§7（研究メモは【だいじなもの】に 入る。→ 次は アルカトラス城へ。右上の 案内）"]);
      rm(eS);
      giveKey(p, d2, "k_note"); reward(p, d2, 300);
      save(p, d2); return true;
    } },
  { r: 0, seal: 0, hint: "§fアルカトラス城の §6地方マスター ミドリ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(0),
    run: async (p, d) => { await gateOpen(p, 1, "セオ", "一枚目の 封印、見届けました。……森の 方から 嫌な 風が 吹いて います。シルヴァ大森林への 道が 開きました。僕は 先に 行って 調べて おきます。"); return true; } },
  { r: 1, ch: "第2章 森の 精霊石", at: "cave", hint: "§fシルヴァ大森林へ 行こう", trig: (c) => c.r === 1,
    run: async (p, d) => {
      /* 第121版: 洞くつの 入口。セオが 待って いる */
      big(p, "§2§lシルヴァ大森林", "§f森の 洞くつの 入口で セオが 待っている");
      const H = heroBox(p, true);
      await hsay(p, ["{shock,!,jump}うわあ……木が 空まで 届いてる！", "{?}……でも 静かすぎない？ 鳥の 声が ぜんぜん しない。"]);
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB);
      await say(p, "セオ", ["{!}来て くれましたか。……この 森は 今、おかしい。森の §6主§f が 目を さまし かけて いるんです。", "{up}この §e洞くつ§f の 奥、森の 地下深くに §d光る 石§f が あります。主を 鎮める 鍵は、きっと それです。"]);
      act(eS, "hold");
      await say(p, "セオ", ["中は 真っ暗です。この §6懐中電灯§f を。持って いるだけで 明るく なります。"]);
      act(eS, 0); giveKey(p, d, "k_light"); save(p, d);
      await hsay(p, ["{smile,☆,jump}洞くつ探検！ わくわく してきた！"]);
      await say(p, "セオ", ["{sweat,汗}……遊びじゃ ありませんよ。", "§7→ 洞くつの 階段を いちばん 下まで（右上の 案内へ）"]);
      /* 第106版: 病んだ 森の 群れ・ベリル 初登場 */
      if (!qs(d).ch2a) {
        const q = fwd(p, 6);
        sound(p, "mob.wolf.growl", 0.7); shake(p, 0.25, 0.4); burst(p.dimension, q, "minecraft:spore_blossom_ambient_particle", 10, 1.6, 0.4);
        big(p, "§2§l森が 病んで いる", "§7葉の 色が 灰色に くすんで いる", "mob.wolf.growl");
        if (camPt(p, q, 4, 1)) await wait(16);   /* 草むらが ゆれる */
        act(H.e, "guard");
        await hsay(p, ["{shock,!,up}草むらから 何か 来る！ ……目が 赤い！"]);
        await say(p, "セオ", ["{sweat,汗}おびえて 暴れて いるんです……！ しずめて あげて ください！"]);
        const r1 = await battle(p, team(["animal", "blob", "animal"], 12, 3), { name: "病んだ 森の モンスター", arena: "病んだ 森", theme: "forest", speaker: "森の モンスター", lines: { half: "……グルル……コエ……", low: "……キュウ……" } });
        if (r1 !== "win") { await sayAt(p, "§7学者 セオ", TRAITOR_JOB, "セオ", ["{sweat,汗}だ、大丈夫ですか！？ いったん 下がって！", RT(p)]); H.rm(); return false; }
        H.e;
        const eB = npcNear(p, "§5ノクス団 ベリル", PJ("beryl", 9));
        re(H.e, "shock", "!");
        await say(p, "ベリル", ["{closed,low}……見つけた。あなたが、石板の 子ね。", "わたしは ベリル。ノクス団の §e幹部候補§f。……まだ、候補。", "石板を 一枚 持って 帰れば、正式に 仲間に して もらえる。そう 約束 されてるの。", "{sad,up}わたしの 村は 石に なった。家族も、友だちも。……帰る 場所は、もう ノクス団しか ないの。"]);
        act(H.e, "guard");
        await hsay(p, ["{angry,怒,wide}事情は わかった。でも 石板は 渡さない！ この子に 手は 出させないよ！"]);
        const r2 = await battle(p, team(["beast", "blob"], 13, 2, 2), { name: "幹部候補 ベリル", arena: "ノクス団", speaker: "ベリル", lines: { half: "負けられない……負けたら、また 一人に なる……", low: "……いや。まだ、終わりたく ない……" } });
        rm(eB);
        if (r2 !== "win") { await sayAt(p, "§5ノクス団 ベリル", PJ("beryl", 9), "ベリル", ["……勝った。でも、石板を 奪う 力までは 残って ない。……また 来るわ。", RT(p)]); H.rm(); return false; }
        H.e; const eB2 = npcNear(p, "§5ノクス団 ベリル", PJ("beryl", 9), true); act(eB2, "kneel");
        await say(p, "ベリル", ["{sad,…}……また、だめだった。", "{sad,up}ねえ。あなたには、帰る 場所が ある？ ……ううん、答えなくて いい。"]);
        act(eB2, 0); await leave(eB2, p, 12, true);   /* 森の 奥へ 走り去る */
        await hsay(p, ["{?}……行っちゃった。", "{sweat,汗}なんだか、迷子みたいな 顔 してたね。"]);
        const d2 = load(p); if (d2) { qs(d2).ch2a = 1; save(p, d2); }
      }
      rm(eS); H.rm();
      return true;
    } },
  { r: 1, hint: "§fシルヴァの §e洞くつ§f に 入って、§e階段を いちばん 下まで§f おりよう §7（右上の 案内で 入口へ。懐中電灯は 持っているだけで よい）", nospot: 1, trig: (c) => c.r === 1 && has(c, "k_light") && (c.cave(1) || c.under()),
    run: async (p, d) => {
      const H = heroBox(p);
      if (!qs(d).ch2b) {   /* 第106版: 洞くつの 番人。第121版: 壁が 立ち上がる */
        H.e; await hsay(p, ["{sweat,汗}……ひんやり。懐中電灯が なかったら、何も 見えなかったね。"]);
        const q = fwd(p, 6);
        sound(p, "mob.irongolem.hit", 0.6); shake(p, 0.7, 0.9); boom(p.dimension, q || p.location);
        big(p, "§6§l洞くつの 番人", "§f石の 体の 番人が 立ちはだかる", "mob.irongolem.hit");
        camLowUp(p, q); await wait(14);
        act(H.e, "guard");
        await hsay(p, ["{shock,!,jump}か、壁が 立ち上がった！？", "{angry,怒}……上等！ 下がらないよ、わたしたち！"]);
        const r = await battle(p, bossOne(["golem", "animal"], 16, 6), { name: "洞くつの 番人", arena: "洞くつの 番人", theme: "cave", hpk: 1.5, speaker: "番人", lines: { half: "……ヌシ……マモル……", low: "……トオレ……" } });
        if (r !== "win") { await say(p, "？？？", ["……マダ……ハヤイ……", RT(p)]); H.rm(); return false; }
        const d1 = load(p); if (d1) { qs(d1).ch2b = 1; save(p, d1); } d = d1 || d;
      }
      /* 苔の 下で 緑の 光が 脈を 打つ */
      const st0 = fwd(p, 4); H.e;
      if (camPt(p, st0, 3, 0.6)) for (let k = 0; k < 6; k++) { burst(p.dimension, st0, "minecraft:villager_happy", 6, 0.5 + k * 0.1, 0.2); await wait(3); }
      big(p, "§d§l光る 石を 見つけた！", "§f懐中電灯の 光に 応えて、石が 脈を 打つ", "random.orb");
      giveKey(p, d, "k_spirit"); save(p, d);   // v2.9.12: 先に わたして から 説明する
      await hsay(p, ["{shock,!,up}石が……光って、息を してる！？"]);
      /* 光の 中に 小さな 精霊。精霊は あなたではなく 相棒を 見る */
      const g = palEnt(p);
      if (g && ok(H.e)) { const hl = H.e.location; place(g, p, { x: hl.x + 0.8, y: hl.y, z: hl.z + 0.8 }); camNear(p, g, 2.4, 0.8); await wait(8); }   /* 相棒は 光に びっくりして 仲間の 後ろへ */
      H.e; await hsay(p, [`{smile,♪}だいじょうぶ、${palNm(p)}。……って、わたしの 後ろに かくれないでよ！`]);
      if (camPt(p, st0, 2.4, 1.2)) { burst(p.dimension, st0, "minecraft:totem_particle", 10, 0.4, 1); sound(p, "random.orb", 1.6); await wait(12); }
      await say(p, "森の 精霊", ["……ああ、来て くれた。"]);
      if (g) { camNear(p, g, 2.4, 0.8); await wait(10); }
      await say(p, "森の 精霊", ["この 子にも…… §d石板の ささやきが 届かない§f のね。あなたと 同じ。よかった。", "ささやきは 心の 傷に 入りこむ。届かない 者だけが、目覚めた 主の 前に 立てるの。"]);
      camPt(p, st0, 2.4, 1.2);
      await say(p, "森の 精霊", ["……それは §6守り手の 印§f。この 子と あなた、二人で 一つの 印。片方が 呑まれても、もう 片方が 呼べば 戻れる。どうか、なくさないで。", "わたしは この 石の 中で 眠る。……主の もとへ、連れて いって。"]);
      /* 精霊は 光の 粒に なって 石の 中へ */
      for (let k = 0; k < 5; k++) { burst(p.dimension, st0, "minecraft:totem_particle", 6, 1.6 - k * 0.3, 1.4 - k * 0.25); await wait(3); }
      sound(p, "random.orb", 0.7);
      await hsay(p, ["{sad,…,up}……石の 中で、精霊が 小さく 息を してる。千年 守った 森を 離れて、眠りに ついたんだね。"]);
      /* 守り手の 印: 手の甲と 相棒の 額に 同じ 光 */
      flash(p, true); sound(p, "random.levelup", 0.7); particle(p, "minecraft:totem_particle", 1);
      if (g) { burst(p.dimension, g.location, "minecraft:totem_particle", 6, 0.3, 1.2); camNear(p, g, 2.2, 0.9); await wait(12); }
      await hsay(p, ["{shock,!,jump}ちょっと！ 手の甲が 光ってる！ " + palNm(p) + " の おでこにも 同じ 光が……！"]);
      if (g) { camNear(p, g, 1.8, 0.9); await wait(6); }
      await pal(p, ["……きこえる？"]);
      await hsay(p, [`{blush,♥}……今、${palNm(p)} が しゃべった？ ……ずるい、わたしにも 聞かせてよ！`]);
      rmCine(g); H.rm();
      await narr(p, "精霊石", ["§7→ §6だいじなもの§7 に 入った。§bシルヴァの ステージ（大地）§7で 使おう"]);
      return true;
    } },
  { r: 1, hint: "§f森の 精霊石を §bシルヴァの ステージ（大地）§f で 使おう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【だいじなもの】）", key: "k_spirit", where: (c) => c.r === 1 && !!c.stage, whereMsg: "§7ここでは 何も 起きない。§fシルヴァの ステージ（大地）§7で 使おう。",
    run: async (p, d) => {
      const H = heroBox(p);
      if (!(qs(d).gate || {})[1]) {   /* 第106版: 主に 勝った あとで 試し合いに 負けても、主とは もう 戦わない */
        /* 第121版: 主の 咆哮で 吹き飛ばされる → セオが 駆けつける */
        const q = fwd(p, 8); H.e;
        sound(p, "mob.ravager.roar", 0.7); shake(p, 0.9, 1.2); flash(p, true);
        if (q) { boom(p.dimension, q); burst(p.dimension, q, "minecraft:spore_blossom_ambient_particle", 12, 2.5, 0.5); camLowUp(p, q); }
        big(p, "§2§l森の 主が 目を さました！", "§fセオが 駆けつけた", "mob.ravager.roar");
        await wait(16);
        if (q) await knock(H.e, q, 2.5);
        act(H.e, "guard");
        await hsay(p, ["{rage,怒,jump}いったぁ……！ もう、いきなり 吠えないでよ！"]);
        const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB); act(eS, "run", false); await wait(14); act(eS, 0);
        await say(p, "セオ", ["{!,wide}森の 主が 目を さましました……！ 精霊石の 光で 弱って いる 今しか ありません。", "{angry}僕も 戦います。一緒に 鎮めましょう！"]);
        await duel(p, "§2§l森の 主", "§aセオの 子が 主の 弱点を 突く！", { fams: ["animal"] });
        const lv = 22;
        const res = await battle(p, bossOne(["animal", "animal"], lv, 10), { name: "森の 主", arena: "森の 主", theme: "forest", hpk: 2.6, extra: 0.3, tag: "森の主", guests: team(["animal", "animal"], lv - 3, 2).map((t) => ({ ...t, owner: "セオ" })), speaker: "森の 主", lines: { half: "……ゴゴゴ……モリヲ……ケガス……ナ……", low: "……オマエタチ……ナラ……" } });
        rm(eS);
        const d2x = load(p); if (!d2x) return false; const d2 = d2x;
        if (res !== "win") { await sayAt(p, "§7学者 セオ", TRAITOR_JOB, "セオ", ["{sweat,汗}くっ……いったん 引きましょう。仲間を 休ませて、もう一度 精霊石を！"]); H.rm(); return false; }
        const s = qs(d2); s.gate = { ...(s.gate || {}), 1: true };
        const got = reward(p, d2, 3000, [["e_bronze", 1], ["SEED2", 1]], false);
        save(p, d2);
        gotShow(p, "§2§l森の 主を しずめた！", got);
        particle(p, "minecraft:totem_particle", 1.5); burst(p.dimension, p.location, "minecraft:villager_happy", 10, 2.5, 0.6);   /* 森に 色が 戻る */
        H.e; await hsay(p, ["{smile,♪,jump}見て！ 葉っぱの 色が 戻って いく！", "{blush,♥}……さっきの、ちょっとだけ かっこよかった。……ちょっとだけ ね！"]);
      }
      const d2 = load(p); if (!d2) return false;
      if (!qs(load(p) || d2).ch2c) {   /* 第106版: 女王エルゼの 試し合い。第121版: 木の 上から 飛び降りて くる */
        H.e;
        const eE = npcNear(p, "§a女王 エルゼ", PJ("elze", 8), true); await drop(p, eE, 6);
        re(H.e, "shock", "!");
        await hsay(p, ["{shock,!,jump}わっ！ 木の 上から 人が 降って きた！？"]);
        await say(p, "女王 エルゼ", ["{closed,low}わたしは 樹上の 民の 女王、エルゼ。主を 鎮めた こと、木の 上から 見て いたわ。", "{sad}……でも、精霊は 石の 中で 眠って しまった。千年 この 森を 守って きた あの子が、もう 森の 声を 聞けない。", "{angry,up}あなたが 精霊の 命を 背負うに ふさわしいか、試させて もらうわ。"]);
        await hsay(p, ["{rage,怒}見てたなら 手伝ってよ！ ……もう、受けて 立つ！"]);
        const r = await battle(p, team(["animal", "animal", "blob"], 24, 3, 6), { name: "女王 エルゼ", arena: "樹上の 試し合い", theme: "forest", speaker: "女王 エルゼ", lines: { half: "下界にも、骨の ある 者が いるのね。", low: "……いいわ。認めましょう。" } });
        rm(eE);
        if (r !== "win") { await sayAt(p, "§a女王 エルゼ", PJ("elze", 8), "女王 エルゼ", ["まだ 背負う 覚悟が 足りないわ。出直しなさい。", RT(p)]); H.rm(); return false; }
        const d3 = load(p); if (d3) { qs(d3).ch2c = 1; reward(p, d3, 1500, [["SEED2", 1]]); save(p, d3); }
        const eE2 = npcNear(p, "§a女王 エルゼ", PJ("elze", 8), true);
        await say(p, "女王 エルゼ", ["{smile,up}精霊が 目を さます 日まで、その 石を 守りなさい。……それが 森の 掟よ。"]);
        if (ok(eE2)) { const l = eE2.location; await go(eE2, { x: l.x, y: l.y + 7, z: l.z }, 8); }   /* ひと跳びで 木の 上へ */
        rm(eE2);
      }
      await gateOpen(p, 2, "セオ", "主は 眠りに つきました。ルインズ荒野への 道が 開いた ようです。……僕は 少し 調べものが あります。あとで 合流しましょう。");
      H.e; await hsay(p, ["{smile,♪}新しい 道！ 地図、また 描き足さなきゃ。"]);
      H.rm();
      return true;
    } },
  { r: 2, ch: "第3章 荒野の ライバル", at: "castle", hint: "§fルインズ荒野へ 行こう", trig: (c) => c.r === 2,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch3a) {   /* 第106版: 廃都の 盗賊団。第121版: 柱の 上から 頭が 飛び降り、手下に 囲まれる */
        big(p, "§6§l廃都の 盗賊団", "§f崩れた 柱の かげから 人影が！", "mob.pillager.idle");
        const eT = npcNear(p, "§6砂ぼこり団 盗賊の 頭", PJ("bandit", 9), true); await drop(p, eT, 4);
        const eA = npcNear(p, "§6砂ぼこり団の 手下", 9), eB = npcNear(p, "§6砂ぼこり団の 手下", 9); act(eA, "guard"); act(eB, "guard");
        act(H.e, "guard"); re(H.e, "shock", "!");
        await hsay(p, ["{shock,!,jump}か、囲まれてる！？"]);
        await say(p, "盗賊の 頭", ["{angry,low}止まれ。この 廃都は 俺たち §6砂ぼこり団§f の 縄張りだ。", "石に なった 町から 逃げて きた 者の 寄せ集めさ。生きる ためなら 何でも する。", "{angry,up}通りたければ、モンスターを 置いて いけ。"]);
        await hsay(p, ["{rage,怒,jump}はあ！？ 置いて いく わけ ないでしょ！ この子たちは 家族なんだから！"]);
        const r = await battle(p, team(["beast", "sword", "golem"], 18, 3, 3), { name: "砂ぼこり団", arena: "廃都の 盗賊団", theme: "ruins", speaker: "盗賊の 頭", lines: { half: "本気で やれ！ 今夜の 水が かかってるんだ！", low: "……引くぞ！ 命あっての ものだ！" } });
        rm(eT); rm(eA); rm(eB);
        if (r !== "win") { await sayAt(p, "§6砂ぼこり団 盗賊の 頭", PJ("bandit", 9), "盗賊の 頭", ["……今日は 見逃す。次は 本当に 置いて いって もらうぞ。", RT(p)]); H.rm(); return false; }
        const eT2 = npcNear(p, "§6砂ぼこり団 盗賊の 頭", PJ("bandit", 9), true); act(eT2, "recoil");
        await say(p, "盗賊の 頭", ["{sweat,汗}ちっ……覚えてろ！"]);
        act(eT2, 0); await leave(eT2, p, 12, true);
        /* 壁画: 仲間が 見つけて 指さす */
        act(H.e, "point");
        await hsay(p, ["{?}ねえ、見て。あいつらが 逃げた あとの 壁に、古い 絵が……", "{shock,!,up}王様が 一人。その まわりに 影が §e十四§f。……オルドさんの 話と 同じ！", "{sweat,汗}……待って。王様の すぐ 隣に、もう 一つ……§c削り取られた 影§f の 跡が ある。", "{?,up}主は 十四の はず。……じゃあ、削られた 一つは 誰？"]);
        act(H.e, 0);
        const d1 = load(p); if (d1) { qs(d1).ch3a = 1; save(p, d1); } d = d1 || d;
      }
      if (!qs(d).ch3b) {   /* 第106版: 弟子に 負けて やりなおしても、レイとは もう 戦わない */
        const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
        big(p, "§b§lライバル レイ", "§f「……待ってたよ。勝負だ」", "raid.horn"); await wait(14);
        await say(p, "レイ", ["{smile,!}……来たか。待ってたよ。", "{angry}ルミナで 負けてから、ずっと 竜と 鍛えて きた。今度は 負けない。", "{closed,up}正直に 言う。石板を 任されたのが おまえなのか、オレは まだ 納得 できて ない。"]);
        H.e; await hsay(p, ["{rage,怒,jump}ちょっと！ まだ そんな こと 言ってるの！？ しつこい！"]);
        await say(p, "レイ", ["{sweat,汗}な、なんで そっちが 怒るんだよ……。", "{angry,low}……とにかく、勝負だ！"]);
        await duel(p, "§b§l空中戦", "§f崩れた 柱の 上で 竜と ぶつかる！", { fams: ["dragon"] });
        const lv = 22;
        const res = await battle(p, team(["dragon", "animal", "beast"], lv, 3, 5, leadOf("dragon", lv)), { name: "ライバル レイ", arena: "ライバル", speaker: "レイ", lines: { half: "まだだ……ここからが オレの 本気だ！", low: "なんで……なんで 届かないんだ……！" }, heal: true });
        rm(e);
        const d2r = load(p); if (!d2r) return false;
        if (res !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["{smile}オレの 勝ちだ。……少しは、追いつけたかな。", "そんな ものなら、石板は オレが 預かる。……もう一度 来い。", RT(p)]); H.rm(); return false; }
        const s = qs(d2r); s.reiW = (s.reiW || 0) + 1; s.ch3b = 1; save(p, d2r);
        const e2 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true); act(e2, "kneel");   /* ひざを ついて 自分の 手を 見る */
        await say(p, "レイ", ["{sad,…}……また、負けた。", "{sad,up}おまえは 強い。それは 認める。……でも、オレには 何が 足りないんだ。"]);
        act(e2, "sad"); H.e;
        await hsay(p, ["{smile,♪}足りない もの 探しなら、付き合って あげても いいよ？"]);
        await say(p, "レイ", ["{blush,汗}う、うるさいな。……ノクス団には 気を つけろよ。じゃあな。"]);
        act(e2, 0); await leave(e2, p, 12, false);
      }
      const d2 = load(p); if (!d2) return false;
      /* 第106版: ジンの 弟子たち（3連戦）*/
      const eK = npcNear(p, "§c弟子 ケン", PJ("ken", 8));
      await say(p, "弟子 ケン", ["{angry,!,low}師匠 ジンに 挑む なら、まず 俺たち 三人を 越えて みろ。", "師匠は この 都が 滅びた 日から、一日も 休まず 剣を 振って いる。"]);
      H.e; await hsay(p, ["{smile,☆}三人 まとめて？ いいね、燃えて きた！"]);
      let kk = 0;
      for (const [k, nm, fams, ln] of [["ken", "弟子 ケン", ["sword", "beast"], "一番手、ケン。参る！"], ["ryu", "弟子 リュウ", ["sword", "dragon"], "二番手、リュウ。……師匠の 剣は、守れなかった 者の 剣だ"], ["haku", "弟子 ハルカ", ["sword", "animal"], "三番手、ハルカ。……師匠は この 廃都を 一度も 出た ことが ないの"]]) {
        if (wonOf(p, "d3_" + k)) continue;
        const ex = k === "ken" && ok(eK) ? eK : npcNear(p, "§c" + nm, PJ(k, 8)); act(ex, "guard");   /* 一人ずつ 前へ 出て かまえる */
        await say(p, nm, ["{angry,!}" + ln]);
        act(ex, 0);
        const r = await battle(p, team(fams, 20, 2, 2), { name: nm, arena: "ジンの 弟子", theme: "ruins", heal: kk++ === 0, speaker: nm, lines: { half: "まだまだ！", low: "……参りました" } });
        rm(ex);
        if (r !== "win") { await sayAt(p, "§c" + nm, PJ(k, 8), nm, ["修行が 足りない！ 出直して こい！", RT(p)]); rm(eK); H.rm(); return false; }
        setWon(p, "d3_" + k);
      }
      rm(eK);
      const eHk = npcNear(p, "§c弟子 ハルカ", PJ("haku", 8), true); act(eHk, "kneel");
      await say(p, "弟子 ハルカ", ["{closed}三人とも 負けた……。師匠 ジンは この 城の 奥で、あなたを 待って いるわ。", "{sad,up}……師匠は、壁画の 削られた 影の 話を すると、黙って 剣を 振るの。", "{?}……それと、あなた ルミナから 来たのよね。師匠が 言ってた。§eオルド殿§f には、若い ころ 一度も 勝てなかったって。"]);
      H.e; await hsay(p, ["{shock,!,jump}え、村長って そんなに すごい人なの！？ ……いつも 縁側で お茶 飲んでる だけなのに！", "{closed,…}……手帳に 書いとこ。『村長・若い ころ・負けなし？』。……まさかね。"]);
      rm(eHk);
      /* オルドの 手紙（鳥が 運んで くる）*/
      sound(p, "mob.parrot.fly", 1); particle(p, "minecraft:white_smoke_particle", 2.4);
      H.e; await hsay(p, ["{!,jump}あ、オルドさんから 手紙！ ……読むね。"]);
      await say(p, "オルド", ["（手紙）荒野の 遺跡には §e星の かけら§f が 眠っておる。石板から 欠け落ちた 力の 粒じゃ。", "ノクス団も あれを 探して おる。かけらは 持つ 者に 力を 与えるが、心を 削る。……気を つけるんじゃぞ。", "……レイは 元気に しておったか。あの子は 意地を 張ると、何も 言わんでな。"]);
      await hsay(p, ["{smile,♪}……『元気に 落ちこんでました』って 返事 しとこうか。"]);
      await narr(p, "オルドの 手紙", ["§7→ 遺跡の ボスを 倒すと 星の かけら（2つ目と 5つ目には 石板も）。8つで ネクロスの §6終の遺跡§7。コンパスで 探せる"]);
      reward(p, d2, 4000, [["e_silver", 1]]); save(p, d2);
      H.rm();
      return true;
    } },
  { r: 2, seal: 2, hint: "§fルインズ荒野の §6地方マスター ジン§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(2),
    run: async (p, d) => { await gateOpen(p, 3, "オルド", "（手紙）石板を 二枚 封じたか。ヴォルカ火山帯への 道が 開いたようじゃ。火山の 町に ノクス団の 幹部が おると 聞く。……気を つけるんじゃぞ。"); const H = heroBox(p, true); await hsay(p, ["{smile,☆,jump}石板、二枚目！ 次は 火山だって！", "{sweat,汗}……あつそう。水筒、多めに 持って いこうね。"]); H.rm(); return true; } },
  { r: 3, ch: "第4章 炎の 幹部", at: "town", hint: "§fヴォルカ火山帯の §e町§f を たずねよう", trig: (c) => c.r === 3 && !!c.town,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch4a) {   /* 第106版: 燃える 鍛冶場の 救助・爆弾班。第121版: 炎と 爆発を 見せる */
        const f = fwd(p, 7);
        big(p, "§c§l鍛冶場が 燃えている！", "§f中に 人と モンスターが 取り残されている", "mob.blaze.shoot");
        sound(p, "random.explode", 0.8); shake(p, 0.5, 0.6); if (f) { boom(p.dimension, f); camPt(p, f, 6, 2); await blaze(p, f, 6); }
        await hsay(p, ["{shock,!,jump}火事！？ 鍛冶場が 燃えてる！"]);
        const eW = npcAt(p, "§e若い 鍛冶屋", PJ("smith", 8), fwd(p, 5, 1.5)); act(eW, "hold");   /* 暴れる モンスターを 抱えて 動けない */
        await say(p, "若い 鍛冶屋", ["{cry,汗,up}だ、だれか！ この子たちが 火に おびえて 暴れて……動けないんだ！"]);
        await hsay(p, ["{angry,怒}休んでる ひまは ない……行こう！ あの子たちを しずめなきゃ！"]);
        const r1 = await battle(p, team(["nether", "golem"], 28, 3, 4), { name: "火に おびえた モンスター", arena: "燃える 鍛冶場", theme: "volcano", speaker: "モンスター", lines: { half: "……アツイ……アツイ……！", low: "……キュウ……" } });
        rm(eW);
        if (r1 !== "win") { await sayAt(p, "§e若い 鍛冶屋", PJ("smith", 8), "鍛冶屋", ["だ、だめだ、火が……！ 一度 外へ！", RT(p)]); H.rm(); return false; }
        const eW2 = npcNear(p, "§e若い 鍛冶屋", PJ("smith", 8), true);
        await say(p, "若い 鍛冶屋", ["{sweat,汗}た、助かった……！ 火を つけたのは §5ノクス団の 爆弾班§f だ！", "{angry,怒}石板の ありかを 言えって、炉に 火薬を 投げこんで いった……！"]);
        /* 爆弾が 投げこまれる → 吹き飛ぶ */
        const bq = fwd(p, 3, 2); H.e;
        sound(p, "random.fuse", 1); await wait(12);
        boom(p.dimension, bq || p.location); sound(p, "random.explode", 1); flash(p, true); shake(p, 0.8, 0.6);
        if (bq) { knockP(p, bq); await knock(H.e, bq, 2.5); }
        await wait(6); act(H.e, 0);
        const eBm = npcNear(p, "§5爆弾班 ボム", PJ("bomb", 9));
        await hsay(p, ["{rage,怒,jump}けほっ、けほっ……ちょっと！ 人に 向かって 投げる！？ " + palNm(p) + " に 当たったら どうするの！"]);
        await say(p, "爆弾班 ボム", ["{smile,low}……まだ 生きてたか。", "{angry}石板の ありかを 言え。言わねえなら、次は 町ごと 燃やす。", "ヴァルカ様の 命令だ。燃やせば 何か 出て くる ってな。"]);
        const r2 = await battle(p, team(["nether", "dragon"], 29, 3, 5), { name: "ノクス団 爆弾班", arena: "爆弾班", theme: "volcano", speaker: "爆弾班 ボム", lines: { half: "……熱い……まだだ……！", low: "ヴァルカ様……すみません……" } });
        rm(eBm); rm(eW2);
        if (r2 !== "win") { await sayAt(p, "§5爆弾班 ボム", PJ("bomb", 9), "爆弾班 ボム", ["……わかったろ。次は 町ごとだ。", RT(p)]); H.rm(); return false; }
        const d1 = load(p); if (d1) { qs(d1).ch4a = 1; save(p, d1); } d = d1 || d;
      }
      /* ヴァルカは 炎の 中から 現れる */
      const e = npcNear(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10), true);
      if (ok(e)) { camNear(p, e, 4, 1.4); await blaze(p, e.location, 5); flash(p, true); }
      big(p, "§c§lノクス団 幹部 ヴァルカ", "§f町が 炎に 包まれている……！", "mob.blaze.shoot");
      act(H.e, "guard"); re(H.e, "shock", "!");
      await say(p, "ヴァルカ", ["{smile,low}アンタが ガロの 相手を した 子だね。アタシは ノクス団 幹部、§c炎の ヴァルカ§f。", "石板を 渡しな。この 町が これ 以上 燃える 前に。"]);
      await hsay(p, ["{rage,怒,up}燃やしたのは そっちの 仲間でしょ！ 何 えらそうに！"]);
      await say(p, "ヴァルカ", ["{closed}……品の ない 火だ。ボムの やつ、火の 扱いも 知らないで。", "{smile,up}鍛冶の 火は、物を 生む ための ものさ。……本物を 見せて あげる。"]);
      await duel(p, "§c§l溶岩の 上の 決闘", "§fヴァルカの 炎の 竜が 飛びかかる！", { fams: ["dragon", "nether"] });
      const lv = 32;
      const res = await battle(p, team(["dragon", "nether"], lv, 3, 12), { name: "ノクス団 幹部 ヴァルカ", arena: "炎の 幹部", theme: "volcano", speaker: "ヴァルカ", lines: { half: "熱いじゃないか……アタシを 本気に させたね！", low: "この アタシの 火が……消える……？" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await sayAt(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10), "ヴァルカ", ["{smile,low}出直して きな。……次は 灰も 残らないよ。"]); H.rm(); return false; }
      const e2 = npcNear(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10), true); act(e2, "recoil");
      await say(p, "ヴァルカ", ["{angry,汗}ちっ……今日は 退くよ。", "{closed}§5参謀§f とは 取り引きさ。石板が そろったら、§6クロガネ§f の 工房の §c開かずの 部屋§f の 鍵を もらう 約束でね。", "アタシは 昔、そこで 槌を 振ってた。千年 だれも 開けない 部屋さ。……開けようと して、破門に なった。", "{smile,up}失くした ものを 取り戻したい？ ……ちがうね。アタシは ただ §e見たい§f だけ。千年 隠された 物を。"]);
      act(e2, 0); if (ok(e2)) { await blaze(p, e2.location, 4); flash(p, true); } rm(e2);   /* 炎の 中に 消える */
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB); act(eS, "run", false); await wait(14); act(eS, 0);   /* 遅れて 駆けつける */
      await say(p, "セオ", ["{sweat,汗}はあ、はあ……けが人は？ ……そうですか、よかった。", "{closed,…,up}参謀……。ノクス団を 動かして いる 人物、ですか。"]);
      H.e; await hsay(p, ["{?}……セオ？ 今、石板の 方 じっと 見てなかった？"]);
      await say(p, "セオ", ["{smile,汗}え？ ……いえ、なんでも ありません。"]);
      rm(eS);
      reward(p, d2, 6000, [["e_red", 1], ["SEED2", 2]]); save(p, d2);
      H.rm();
      return true;
    } },
  { r: 3, seal: 4, hint: "§fヴォルカ火山帯の §6地方マスター カグラ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(4),
    run: async (p, d) => { await gateOpen(p, 4, "セオ", "サンドリア砂漠への 道が 開きました。砂の 下に 古い 王墓が あります。……現地で 地図を 渡しますね。"); const H = heroBox(p, true); await hsay(p, ["{shock,!,jump}王墓！？ ……お宝とか、あるかな？", "{sweat,汗}……呪いとかも、あるかな。"]); H.rm(); return true; } },
  { r: 4, ch: "第5章 砂の 王墓", at: "castle", hint: "§fサンドリア砂漠へ 行こう", trig: (c) => c.r === 4,
    run: async (p, d) => {
      big(p, "§e§lサンドリア砂漠", "§f砂の 王宮の 前で セオと レイが 待っている");
      // v2.9: 負けイベント（冤罪 → 城の 牢屋）
      if (!qs(d).jailDone) {
        { const H0 = heroBox(p, true); await hsay(p, ["{sweat,汗}あ、暑い……砂が 口に 入る……。", "{smile,♪}でも 見て！ 砂の 王宮！ 地図に 描くの、楽しみ！"]); H0.rm(); }
        const ok2 = await jailEvent(p); if (!ok2) return false; d = load(p); if (!d) return false;
      }
      const H = heroBox(p, true);
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB), eR = npcNear(p, "§bライバル レイ", RIVAL_JOB);
      await say(p, "セオ", ["{sad}……イザクさんの こと、聞きました。僕が もっと 早く 真犯人を 見つけて いれば。"]);
      act(eS, "hold");
      await say(p, "セオ", ["これが §6王墓の 地図§f です。砂の 下の 入口に 印を つけて あります。王墓の 奥で、§6主§f が 目を さまし かけて いる。", "{smile}レイくんには お守りを 渡して おきました。きっと 力に なります。", "§7→ §bサンドリアの ステージ（大地）§7で 地図を 広げよう（地図は【だいじなもの】に 入る）"]);
      act(eS, 0);
      act(eR, "raise"); redGlow(eR); sound(p, "random.orb", 0.5);   /* かけらを かかげる */
      await say(p, "レイ", ["{smile,☆,up}見ろよ、これ。§e星の かけら§f だ。セオが くれた。", "{closed}持ってると、力が 湧いて くる。……じいさんを 助けられなかった 自分を、見なくて 済む 気が する。", "{angry}これで オレも、選ばれる 側に なれる。……王墓の 主、一緒に 行こう。"]);
      act(eR, 0); H.e;
      await hsay(p, ["{sweat,?}……ねえ、その 石、なんだか 嫌な 感じ しない？"]);
      await say(p, "レイ", ["{angry,怒}……気の せいだろ。"]);
      rm(eS); rm(eR); H.rm();
      giveKey(p, d, "k_tomb"); save(p, d); return true;
    } },
  { r: 4, hint: "§f王墓の 地図を §bサンドリアの ステージ（大地）§f で 使おう §7（レイと 共闘）", key: "k_tomb", where: (c) => c.r === 4 && !!c.stage, whereMsg: "§7地図の 印は ここでは ない。§fサンドリアの ステージ（大地）§7で 広げよう。",
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch5a) {   /* 第106版: 王墓の 罠。第121版: 床が 沈み、砂から 兵が わく */
        const eR0 = npcNear(p, "§bライバル レイ", RIVAL_JOB);
        sound(p, "random.explode", 0.5); shake(p, 0.6, 1.0); await wait(6);
        big(p, "§6§l王墓の 罠", "§f床が 沈み、壁から 砂の 兵が わき出る！", "mob.husk.ambient");
        { const q = fwd(p, 5); for (let k = 0; k < 3; k++) { burst(p.dimension, q, "minecraft:white_smoke_particle", 10, 1 + k, 0.1); await wait(4); } }
        act(H.e, "guard"); re(H.e, "shock", "!");
        await hsay(p, ["{shock,!,jump}床が 沈んでる！？ 壁から 何か 出て くる！"]);
        act(eR0, "guard");
        await say(p, "レイ", ["{angry,!,low}砂の 兵だ！ 背中は 任せろ！"]);
        const r = await battle(p, team(["golem", "nether", "golem"], 40, 3, 10), { name: "王墓の 罠", arena: "王墓の 罠", theme: "ruins", speaker: "砂の 兵", guests: team(["dragon"], 38, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……ネムリヲ……", low: "……サラサラ……" } });
        rm(eR0);
        if (r !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["くっ、罠か！ いったん 出よう！", "§7→ 地図は まだ 使える。もう一度 ステージで 広げよう"]); H.rm(); return false; }
        act(H.e, "point");   /* 碑文を 見つけて 読む */
        await hsay(p, ["{?}……ねえ、壁に 文字が 刻まれてる。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……", "{sweat,汗}誰かが 爪で 引っかいて、消そうと した 跡が ある……。"]);
        act(H.e, 0);
        const d1 = load(p); if (d1) { qs(d1).ch5a = 1; save(p, d1); } d = d1 || d;
      }
      if (!(qs(d).gate || {})[4]) {   /* 第106版: 主に 勝った あとは 主と もう 戦わない */
        const eR = npcNear(p, "§bライバル レイ", RIVAL_JOB, true), q = fwd(p, 8);
        sound(p, "mob.wither.spawn", 0.8); shake(p, 1, 1.4); flash(p, false);
        if (q) { boom(p.dimension, q); camLowUp(p, q); }
        big(p, "§6§l王墓が 開いた！", "§f砂の 下から 番人が 起きあがる", "mob.wither.spawn"); await wait(16);
        act(eR, "raise"); redGlow(eR);
        await say(p, "レイ", ["{rage,up}……かけらが 熱い。力が、あふれて 止まらない……！", "{smile,low}行こう。今の オレなら、主にも 負けない！"]);
        H.e; await hsay(p, ["{rage,怒,jump}ちょ、ちょっと レイ！ 一人で 突っこまないでよ！"]);
        act(eR, 0);
        await duel(p, "§6§l王墓の 主", "§fレイの 竜と 背中を 合わせる！", { fams: ["nether", "golem"] });
        const lv = 42;
        const res = await battle(p, bossOne(["nether", "golem"], lv, 22), { name: "王墓の 主", arena: "王墓の 主", theme: "ruins", hpk: 3, extra: 0.35, tag: "王墓の主", guests: team(["dragon"], lv - 2, 2).map((t) => ({ ...t, owner: "レイ" })), speaker: "王墓の 主", lines: { half: "……王の 眠りを 妨げる 者よ……", low: "……王よ……お許しを……" } });
        rm(eR);
        const d2 = load(p); if (!d2) return false;
        if (res !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["{angry}いったん 引こう！ 地図は まだ 使える。……次は、もっと 力を 引き出す。"]); H.rm(); return false; }
        const s = qs(d2); s.gate = { ...(s.gate || {}), 4: true };
        const got = reward(p, d2, 12000, [["e_silver", 1], ["SEED3", 1]], false);
        save(p, d2);
        gotShow(p, "§6§l王墓の 主を 倒した！", got);
        const eR2 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true);
        await say(p, "レイ", ["{smile,☆}……やった。二人なら、主にも 勝てる。"]);
        act(eR2, "hold"); camNear(p, eR2, 1.8, 1.0); redGlow(eR2); sound(p, "mob.wither.ambient", 1.4); await wait(12);   /* 手の 中で かけらが 赤黒く 光る */
        await say(p, "レイ", ["{shock,!,up}……っ！", "{angry,closed}なんでもない。……もっとだ。もっと、強く なれる……。"]);
        H.e; await hsay(p, ["{sad,?}……レイ。今の 光、ほんとに なんでもないの？"]);
        act(eR2, 0); await leave(eR2, p, 10, false);
      }
      const d2 = load(p); if (!d2) return false;
      if (!qs(load(p) || d2).ch5b) {   /* 第106版: 砂王ラシードの 詫びの 決闘 */
        const eR = npcNear(p, "§6砂王 ラシード", PJ("rashid", 8));
        await say(p, "砂王 ラシード", ["{closed,low}……王墓の 主を 倒したのは、おまえか。", "{sad}わしは おまえを 牢に 入れ、おまえを 逃がした 老人を 斬らせた。"]);
        H.e; await hsay(p, ["{rage,怒,up}……イザクさんは、娘さんに 花を 届けたかった だけなのに！"]);
        await say(p, "砂王 ラシード", ["{closed}謝って 済む ことでは ない。……だから、剣で 詫びる。", "{angry,low}わしを 打ちのめせ。それが 砂の 国の 詫び方だ。"]);
        const r = await battle(p, team(["golem", "nether", "dragon"], 44, 3, 14), { name: "砂王 ラシード", arena: "詫びの 決闘", theme: "desert", speaker: "砂王 ラシード", lines: { half: "……まだだ。まだ 足りぬ", low: "……イザク。わしは、法を 守った だけの 愚か者だ" } });
        rm(eR);
        if (r !== "win") { await sayAt(p, "§6砂王 ラシード", PJ("rashid", 8), "砂王 ラシード", ["……これでは 詫びに ならぬ。また 来い。", RT(p)]); H.rm(); return false; }
        const d5 = load(p); if (d5) { qs(d5).ch5b = 1; reward(p, d5, 5000, [["SEED3", 1]]); save(p, d5); }
        const eR2 = npcNear(p, "§6砂王 ラシード", PJ("rashid", 8), true); act(eR2, "kneel");   /* 王が ひざを つく */
        await say(p, "砂王 ラシード", ["{sad}……イザクの 墓を、王墓の 隣に 建てる。", "{closed,up}それで 許されるとは 思わん。……あの 碑文の 意味が、今なら わかる 気が する"]);
        act(eR2, 0); await leave(eR2, p, 10, false);
      }
      await gateOpen(p, 5, "セオ", "（手紙）クリスタリアへの 道が 開きました。水晶の 洞くつに ノクス団が 出入りして いる そうです。……レイくんの 様子は、どうですか。");
      H.e; await hsay(p, ["{sad,…}……レイの 様子、か。", "{angry,怒}次に 会ったら、あの かけら、ぜったい 手放させて やるんだから。"]);
      H.rm();
      return true;
    } },
  { r: 5, ch: "第6章 水晶の 洞くつ", hint: "§fクリスタリアの §e洞くつ§f に 入って、§e階段を いちばん 下まで§f おりよう §7（右上の 案内で 入口へ）", nospot: 1, trig: (c) => c.r === 5 && (c.cave(5) || c.under()),
    run: async (p, d) => {
      const H = heroBox(p);
      big(p, "§d§l水晶の 洞くつ", "§fノクス団が だれかを 捕まえている！", "mob.villager.no");
      const eM = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true); act(eM, "kneel");   /* 捕まって ひざを つかされて いる */
      const eG = npcNear(p, "§cノクス団 班長 ガロ", PJ("garo", 9));
      re(H.e, "shock", "!");
      await say(p, "マリン", ["{cry,!,up}……助けて！ わたしは マリノアの 潜水士、マリン。", "{sad}沈んだ 神殿の ことを 聞かれて、知らないって 言ったら、ここまで 連れて こられたの。"]);
      act(H.e, "guard");
      await hsay(p, ["{rage,怒,jump}ちょっと！ 一人を 寄って たかって、何 してるの！"]);
      await say(p, "ガロ", ["{closed,low}……また お前か。", "{smile}昇進したよ。§e班長§f だとさ。部下を 三人 預けられた。……ピコの 代わりに、だと。"]);
      act(H.e, "point");
      await hsay(p, ["{shock,!}……その 腰の 帽子、ピコの……！"]);
      act(H.e, "guard");
      await say(p, "ガロ", ["{sad,up}ピコは まだ 眠ってる。団の 医者に 預けてある。……参謀は 言った。王が 起きれば、呑まれた 心も 戻ると。", "{angry,low}だから、ここは 通さねえ。"]);
      for (let k = qs(d).ch6x ? 3 : 0; k < 3; k++) {   /* 第106版: 連戦に 勝った あとは くり返さない。第121版: 次の 下っぱが 走って くる */
        if (k > 0) {
          const nm = ["ガロ", "ゴロ", "グロ"][k], ex = npcNear(p, `§cノクス団の 下っぱ ${nm}`, 9); act(ex, "run", false); await wait(10); act(ex, "guard");
          await say(p, nm, [k === 1 ? "{angry,!}班長の 仇だ！ 次は オレ、ゴロ様だ！" : "{angry,!,low}グロ様の 番だ！ 逃がさねえぞ！"]);
          try { p.sendMessage("§7（仲間の HP・MPは そのまま）"); } catch {}
        }
        const lv = 40 + k * 3;
        const res = await battle(p, team(["golem", "nether", "animal"], lv, 2 + (k === 2 ? 1 : 0), 8 + k * 4), { name: `ノクス団の 下っぱ（${k + 1}/3）`, arena: "連戦", theme: "cave", speaker: ["ガロ", "ゴロ", "グロ"][k], heal: k === 0 });
        if (res !== "win") { await sayAt(p, "§3潜水士 マリン", PJ("marin", 9), "マリン", ["{sweat,汗}……一度 引いて。お願い、また 来て。"]); rm(eM); rm(eG); H.rm(); return false; }
      }
      rm(eM); rm(eG);
      { const dx = load(p); if (dx && !qs(dx).ch6x) { qs(dx).ch6x = 1; save(p, dx); } }
      /* 第106版: 曇った 水晶の 幻・ベリル 二度目。第121版: 水晶が 光り、影が にじみ出す */
      if (!qs(load(p) || d).ch6a) {
        const q = fwd(p, 5, 0, 1); H.e;
        const eM2 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
        if (camPt(p, q, 3, 0.5)) for (let k = 0; k < 5; k++) { burst(p.dimension, q, "minecraft:portal_reverse_particle", 8, 0.7, 0); await wait(3); }
        big(p, "§d§l水晶の 幻", "§f曇った 水晶に 何かが 映る", "block.amethyst_block.chime");
        await hsay(p, ["{shock,!,up}……水晶の 中に、街が 映ってる。", "{sweat,汗}人も、犬も、噴水の しぶきまで……灰色の 石に なって 止まってる。", "{shock,!,jump}い、今！ 石の 子どもと 目が 合った！"]);
        await say(p, "マリン", ["{sad,…}……これが、各地で 広がってる §8石化§f……。"]);
        if (q) { camPt(p, q, 4, 0.5); await shadowFlow(p, q, p.location, 16); }
        shake(p, 0.6, 0.6); flash(p, false);
        act(H.e, "guard");
        await hsay(p, ["{angry,!}水晶から 影が あふれて くる！ 来るよ！"]);
        const r1 = await battle(p, bossOne(["golem", "nether"], 44, 12), { name: "水晶の 幻", arena: "曇った 水晶", theme: "crystal", hpk: 1.4, speaker: "幻", lines: { half: "……ワスレ……ナイデ……", low: "……オボエテ……" } });
        rm(eM2);
        if (r1 !== "win") { await sayAt(p, "§3潜水士 マリン", PJ("marin", 9), "マリン", ["……一度 戻ろう。水晶の 影は、洞くつの 外までは 追って こない。"]); H.rm(); return false; }
        const eB = npcNear(p, "§5ノクス団 ベリル", PJ("beryl", 9)), eM3 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
        await say(p, "ベリル", ["{closed}……また 会ったわね。", "{sad}わたし、まだ 仲間に して もらえないの。『石板を 持って こい』の 一点張り。", "{sad,up}……あの 街、わたしの 村に 似てる。だから、早く 終わらせたいの。"]);
        act(eM3, "guard");
        await say(p, "マリン", ["{angry,!}……わたしも 戦う。助けて もらった 借りは、ここで 返す！"]);
        await duel(p, "§d§l背中あわせ", "§fマリンの 子と 背中を 合わせて 三方向の 敵を 迎え撃つ！", { fams: ["beast", "blob"] });
        const r2 = await battle(p, team(["beast", "blob", "golem"], 45, 3, 10), { name: "幹部候補 ベリル", arena: "ノクス団", theme: "crystal", speaker: "ベリル", guests: team(["aqua"], 43, 1).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "二対一……それでも、引けない！", low: "……どうして、いつも こうなの……" } });
        rm(eB); rm(eM3);
        if (r2 !== "win") { await sayAt(p, "§5ノクス団 ベリル", PJ("beryl", 9), "ベリル", ["……勝った。でも、石板を 奪う 力までは 残って ない。……また 来る。", RT(p)]); H.rm(); return false; }
        const eB2 = npcNear(p, "§5ノクス団 ベリル", PJ("beryl", 9), true); act(eB2, "kneel");
        await say(p, "ベリル", ["{sad,…}……また、だめ。", "参謀さまは 約束したの。石板を 持って きたら、わたしの 名前を 団の 名簿に 書くって。", "{cry,tears,up}わたしの 村は 石に なって、地図からも 消された。……名簿に 名前が 残れば、村が あった ことも、だれかが 覚えて いて くれる。"]);
        H.e; await hsay(p, ["{shock,…}……地図から、消された……？"]);
        act(eB2, 0); await leave(eB2, p, 12, true);
        const d6 = load(p); if (d6) { qs(d6).ch6a = 1; save(p, d6); }
      }
      const d2 = load(p); if (!d2) return false;
      const eM4 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
      await say(p, "マリン", ["{smile}……ありがとう。あなたが 来なければ、わたしも 水晶の 奥に 置いて いかれてた。"]);
      act(eM4, "hold");
      await say(p, "マリン", ["{smile,☆}お礼に、わたしの 予備の §6潜水ゴーグル§f を。深い 海でも 目が 利くように なる。", "{sad}マリノアの 深い 海には §d沈んだ 神殿§f が あるの。……わたしの 村も、そこに 沈んでる。", "§7→ ゴーグルは【だいじなもの】に 入る。クリスタリアの 城で 地方マスターに 挑もう"]);
      act(eM4, 0);
      giveKey(p, d2, "k_goggle"); reward(p, d2, 9000, [["e_blue", 1]]); save(p, d2);
      H.e; await hsay(p, ["{smile,♪}ゴーグル、似合いそう！ ……あとで ちょっと 貸してね？"]);
      rm(eM4); H.rm();
      return true;
    } },
  { r: 5, seal: 6, hint: "§fクリスタリアの §6地方マスター ゴウ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(6),
    run: async (p, d) => { await gateOpen(p, 6, "マリン", "マリノア諸島への 道が 開いた。……港で 待ってる。姉さんにも、会って ほしいの。"); const H = heroBox(p, true); await hsay(p, ["{smile,☆,jump}海！ 港！ 潜水！ ……楽しみに なって きた！"]); H.rm(); return true; } },
  { r: 6, ch: "第7章 海神の 貝笛", at: "town", hint: "§fマリノア諸島へ 行こう", trig: (c) => c.r === 6,
    run: async (p, d) => {
      const s0 = qs(d);
      if (s0.shellBack) return true;   // 取りかえした あとに 落ちても やりなおさない
      const H = heroBox(p, true);
      if (!s0.shellLost) {
        /* 第122版: 波を 数える ナギサ → 夜の 浜が 燃える → 焼けた 腕 */
        big(p, "§b§lマリノア諸島", "§f潮風の 港で、だれかが 波に 向かって 指を 折っている");
        const eN = npcAt(p, "§6潮風の 地方マスター ナギサ", PJ("nagisa", 8), fwd(p, 4, 1.5)); act(eN, "point");
        await say(p, "ナギサ", ["{closed}……七、八。今日は 満ちるのが 遅いな。"]);
        act(eN, 0);
        await say(p, "ナギサ", ["{shock,!,jump}……うわっ！？ いつから いたの？"]);
        const eM = npcNear(p, "§3潜水士 マリン", PJ("marin", 9));
        await say(p, "マリン", ["{smile}姉さん、この 人たちが 水晶の 洞くつで 助けて くれたの。"]);
        act(eN, "hold");   /* 両手で 手を 握って ぶんぶん 振る */
        await say(p, "ナギサ", ["{smile,♪,up}マリンを！？ ありがとう、ありがとう！ わたしは 姉の ナギサ。この 港の 地方マスターよ。", "{blush}あの子、潜る ことしか 考えて ないから。……あ、でも、わたしの いちばんの 自慢なんだ。"]);
        act(eN, 0);
        await hsay(p, ["{smile,♪}ナギサさん、ね。……手帳の 名簿に 書いとこ。"]);
        act(eM, "hold");
        await say(p, "マリン", ["これは 姉さんから 預かった §6海神の 貝笛§f。沈んだ 神殿の 番人を 呼び起こす 笛よ。", "深い 海で 吹くと、番人が 答える。番人が 認めれば、神殿に 眠る 紋章を 託して くれるはず。", "§7→ 水面から 6ブロック 以上 もぐって 吹く"]);
        act(eM, 0);
        giveKey(p, d, "k_shell"); save(p, d);
        await say(p, "ナギサ", ["{smile}潮が 満ちる 前に、戻って きてね。"]);
        // v2.9: 負けイベント（だいじなものを 奪われる）。第122版: 夜の 浜に 炎が 走る
        cmd(p, "camera @s fade time 0.3 0.8 0.6 color 0 0 0"); await wait(16);
        const f = fwd(p, 7);
        sound(p, "random.explode", 0.8); shake(p, 0.6, 0.8);
        if (f) { camPt(p, f, 6, 2); await blaze(p, f, 6); }
        big(p, "§c§l浜が 燃えている！", "§f炎の 中から、だれかが 歩いて くる", "mob.blaze.shoot");
        const e = npcAt(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10), f); if (ok(e)) flash(p, true);
        if (ok(eN)) { const q = fwd(p, 3); if (q) await go(eN, q, 10, true); act(eN, "guard"); }   /* ナギサが 貝笛を 抱いて 前に 出る */
        re(H.e, "shock", "!");
        await say(p, "ヴァルカ", ["{smile,low}その 貝笛、いただくよ。参謀の 言いつけでね。", "{angry}この前の 借りも 返す。……今日の アタシは、手加減 しない。"]);
        await hsay(p, ["{rage,怒,jump}ナギサさん、下がって！"]);
        await battle(p, team(["dragon", "nether"], 70, 3, 40), { name: "ノクス団 幹部 ヴァルカ", arena: "奪われた 貝笛", theme: "beach", speaker: "ヴァルカ", hpk: 30, extra: 0.6, tag: "本気の 幹部", heal: false,
          scripted: { turns: 2, lines: ["§c§lヴァルカの 仲間が 炎の 渦を 起こした！", "§7熱で 視界が ゆがむ…… 仲間たちが 次々と 倒れていく！"] }, lines: { half: "やるねえ……でも ムダだよ！" } });
        rm(e); rm(eN); rm(eM);
        const d2 = load(p); if (!d2) { H.rm(); return false; } const s2 = qs(d2);
        { const n = countItem(p, "mrpg:k_shell"); if (n > 0) takeItem(p, "mrpg:k_shell", n); } s2.keys = (s2.keys || []).filter((k) => k !== "k_shell"); s2.shellLost = 1; save(p, d2);
        { const tid = townOfReg(6); await sceneAt(p, tid ? (spotOf(tid, "harbor") || plazaOf(tid)) : null, "港の 桟橋"); }
        big(p, "§c§l海神の 貝笛を 奪われた！", "§f桟橋が 半分 焼け落ちている……", "random.explode");
        /* 第113版: ナギサは 生きて いる（両腕を 焼かれて もう 潜れない）。印 nagiDead は「マスターを 退いた」の 意味の まま 使う */
        const eN2 = npcAt(p, "§6ナギサ", PJ("nagisa", 8), fwd(p, 3.5)); act(eN2, "down");
        if (ok(eN2)) { camNear(p, eN2, 2.4, 0.4); burst(p.dimension, eN2.location, "minecraft:basic_smoke_particle", 8, 0.6, 0.3); await wait(14); }   /* 焼けた 腕から 煙が 上がる */
        { const dn = load(p); if (dn) { qs(dn).nagiDead = 1; save(p, dn); } }
        const eM2 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true); act(eM2, "run", false);
        if (ok(eM2) && ok(eN2)) { const q = eN2.location; await go(eM2, { x: q.x + 0.9, y: q.y, z: q.z }, 10, true); } act(eM2, "kneel");
        await say(p, "マリン", ["{cry,!,up}姉さん！！", "{sad,tears}……息、してる。してる……！"]);
        act(eN2, "kneel");
        await say(p, "ナギサ", ["{sad}……ごめんね、マリン。笛、取られちゃった。", "{closed,…}……でも、石板だけは 手放さなかった。", "{sad,up}この 腕じゃ、もう 潜れないね。港の マスターも、ここまで。……マリン、この 石板を あなたに。"]);
        await hsay(p, ["{shock,…,up}……ナギサさんの 腕……"]);
        const eV = npcAt(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10), fwd(p, 8, -3)); act(eV, "raise");   /* 岩の 上で 貝笛を ゆらす */
        if (ok(eV)) { lookAt(p, eV); await wait(10); }
        if (ok(H.e)) { const q = fwd(p, 5, -2); if (q) await go(H.e, q, 12, true); act(H.e, "guard"); }   /* 手当てより 先に、まっすぐ ヴァルカへ */
        await hsay(p, ["{rage,怒,up}……それ、返しなさいよ。", "{rage,怒,jump}返しなさいって！！"]);
        await say(p, "ヴァルカ", ["{smile,low}取り引きの 品だよ。これで『開かずの 部屋』の 鍵に 一歩 近づく。", "{closed,息}……港まで 焼く つもりは、なかった。"]);
        act(eV, 0); if (ok(eV)) await blaze(p, eV.location, 3); await leave(eV, p, 10, true);
        act(eM2, "hold");   /* 姉の ゴーグルを 額に かける */
        await say(p, "マリン", ["{closed}……潮は 引いても、必ず 満ちる。", "{angry,up}姉さんの 代わりに、わたしが 潜る。……ヴァルカは まだ 近くに いる。追いかけよう。"]);
        rm(eN2); rm(eM2);
      }
      // 取りかえす（負けても ここから やりなおせる）
      if (!(await confirm(p, "奪われた 貝笛", "§fヴァルカを 追いかける？\n§7（マリンも いっしょに 戦う）", "追いかける", "あとで"))) { H.rm(); return false; }
      const e2 = npcNear(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10));
      await say(p, "ヴァルカ", ["{angry,low}……しつこいね。いいよ、今度こそ 灰に して あげる。"]);
      const r2 = await battle(p, team(["dragon", "nether"], 50, 3, 18), { name: "ノクス団 幹部 ヴァルカ", arena: "貝笛を 取りかえせ", asked: true, theme: "beach", speaker: "ヴァルカ",
        guests: team(["aqua"], 48, 2).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "なんで…… さっきは 手も 足も 出なかった くせに！", low: "……参謀に、なんて 言えば……" } });
      rm(e2);
      const d3 = load(p); if (!d3) { H.rm(); return false; }
      if (r2 !== "win") { await sayAt(p, "§3潜水士 マリン", PJ("marin", 9), "マリン", ["……一度 港で 立てなおそう。", "貝笛は、必ず 取りかえす。姉さんの ためにも。"]); H.rm(); return false; }
      const s3 = qs(d3); s3.shellLost = 0; s3.shellBack = 1; giveKey(p, d3, "k_shell"); save(p, d3);
      big(p, "§b§l海神の 貝笛を 取りかえした！", "§fもう 二度と はなさない");
      const eV3 = npcNear(p, "§cノクス団 幹部 ヴァルカ", PJ("valka", 10), true); act(eV3, "kneel");
      await say(p, "ヴァルカ", ["{sweat,息}……ふん。疲れたよ。……参謀に、なんて 言えば いいんだか。"]);
      if (ok(eV3)) await blaze(p, eV3.location, 3); rm(eV3);   /* 炎の 中に 消える */
      const eM3 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
      await say(p, "マリン", ["{smile}……取りかえした。", "{?}ヴァルカの 言ってた『参謀』……ノクス団を 動かしてる 人。いったい 誰なの。", "§7→ ゴーグルを 持って 深い 海で 貝笛を 吹く"]);
      await hsay(p, ["{angry,up}……誰でも いい。ナギサさんの 腕の 分、ぜったい 許さない。"]);
      rm(eM3); H.rm();
      return true;
    } },
  { r: 6, hint: "§fゴーグルを 持って §b海の 深く（水面から 6以上）§f で 海神の 貝笛を 吹こう §7（深い 海が 見つからない ときは マリノアの ステージ（大地）でも 吹ける）", key: "k_shell", where: (c) => c.r === 6 && (c.depth() >= 6 || !!c.stage), whereMsg: "§7ここでは 音が 響かない。§fマリノアの 海の 深く（水面から 6ブロック 以上）§7で 吹こう。",
    pre: (c) => (has(c, "k_goggle") ? null : "§7暗くて 何も 見えない……潜水ゴーグルが 必要だ。"),
    run: async (p, d) => {
      const H = heroBox(p);
      /* 第122版: 泡が 立ちのぼり、番人が 下から 現れる */
      const q = fwd(p, 6, 0, -2);
      for (let k = 0; k < 4; k++) { burst(p.dimension, q, "minecraft:bubble_column_up_particle", 8, 0.6 + k * 0.4, 0); await wait(3); }
      sound(p, "mob.elderguardian.curse", 0.8); shake(p, 0.5, 0.8); if (q) camLowUp(p, q);
      big(p, "§3§l沈んだ 神殿の 番人", "§f貝笛の 音が 海の 底へ 響いた", "mob.elderguardian.curse");
      H.e; await hsay(p, ["{shock,!,up}……下から 何か 上がって くる！ おっきい……！"]);
      const lv = 52;
      const res = await battle(p, bossOne(["aqua"], lv, 30), { name: "神殿の 番人", arena: "沈んだ 神殿", theme: "beach", hpk: 3, extra: 0.4, tag: "神殿の番人", speaker: "神殿の 番人", lines: { half: "……海ノ 誓イヲ……知ル者カ……", low: "……認メヨウ……陸ノ 子ヨ……" } });
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { H.e; await hsay(p, ["{sweat,汗}番人、海の 底へ 戻っちゃった……。貝笛は まだ 使えるよ。"]); H.rm(); return false; }
      giveKey(p, d2, "k_crest");
      const got = reward(p, d2, 18000, [["e_rainbow", 1], ["SEED3", 1]]); save(p, d2);
      gotShow(p, "§3§l潮の 紋章を 託された！", got);
      /* 港へ 戻って、ナギサに 知らせる */
      { const tid = townOfReg(6); await sceneAt(p, tid ? (spotOf(tid, "harbor") || plazaOf(tid)) : null, "港の 桟橋"); }
      const eN = npcAt(p, "§6ナギサ", PJ("nagisa", 8), fwd(p, 3.5)); act(eN, "sad");
      const eM = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
      if (ok(H.e) && ok(eN)) { const l = eN.location; await go(H.e, { x: l.x + 0.9, y: l.y, z: l.z + 0.4 }, 10); act(H.e, "kneel"); }
      await hsay(p, ["{sad,…}……ナギサさん。番人、ちゃんと 答えて くれたよ。", "{sad,up}……ごめんなさい。間に 合わなかった。"]);
      act(eN, "hold");   /* 包帯の 手で、不器用に 頭を なでる */
      await say(p, "ナギサ", ["{smile,up}間に 合ったよ。マリンが、潜ったんだから。"]);
      await hsay(p, ["{cry,tears,up}……っ。"]);   /* こらえきれずに、一粒だけ */
      act(eN, 0); act(H.e, 0); act(eM, "guard");
      await say(p, "マリン", ["{angry,!}今度は わたしが 港の マスター。……城で 待ってる。手加減 しないから！", "§7→ マリノアの 城で 地方マスター マリンに 挑もう"]);
      rm(eN); rm(eM); H.rm();
      return true;
    } },
  { r: 6, seal: 8, hint: "§fマリノア諸島の §6地方マスター マリン（ナギサの 跡つぎ）§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(8),
    run: async (p, d) => { await gateOpen(p, 7, "セオ", "ネクロス冥府領への 道が 開きましたね。……そこで 待っています。あなたに、話して おかなければ ならない ことが あります。"); const H = heroBox(p, true); await hsay(p, ["{?}……セオの 声、なんだか 暗かった。"]); H.rm(); return true; } },
  { r: 7, ch: "第8章 学者の 正体", at: "castle", hint: "§fネクロス冥府領へ 行こう", trig: (c) => c.r === 7,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch8a) {   /* 第106版: 冥王の 葬列・セオの 回し者。第122版: 葬列が 進み、影が 棺を 狙う */
        big(p, "§5§l冥王の 葬列", "§7黒い 行列が 霊廟へ 向かう", "mob.wither.ambient");
        const eM = npcAt(p, "§5冥王 モルテ", PJ("morte", 15), fwd(p, 4, 1.5));
        const c1 = npcAt(p, "§8葬列の 民", 9, fwd(p, 6, -1)), c2 = npcAt(p, "§8葬列の 民", 9, fwd(p, 7, 1)); act(c1, "sad"); act(c2, "sad");
        if (ok(c1)) { camPt(p, c1.location, 6, 1.5); const a = fwd(p, 9, -3), b = fwd(p, 10, -1); if (a) go(c1, a, 30); if (b) go(c2, b, 30); await wait(20); }
        await say(p, "冥王 モルテ", ["{closed,low}……ようこそ、死者の 国へ。わしは この 地を 治める 冥王 モルテ。", "{sad}今日は 葬列の 日だ。石に なって 死んだ 者たちを、年に 一度 霊廟へ 送る。", "{angry,up}近ごろ 影の モンスターが 棺を 狙って くる。……護衛を 頼めるか。"]);
        { const a = fwd(p, 8, 3), b = fwd(p, 3); if (a && b) { await shadowFlow(p, a, b, 16); shake(p, 0.4, 0.5); } }
        act(H.e, "guard"); re(H.e, "shock", "!");
        await hsay(p, ["{angry,!}来た！ 棺には さわらせないよ！"]);
        const r1 = await battle(p, team(["nether", "nether", "animal"], 54, 3, 14), { name: "墓場の モンスター", arena: "冥王の 葬列", theme: "soulvalley", speaker: "墓場の モンスター", lines: { half: "……ヒツギ……ヨコセ……", low: "……ネムラセテ……" } });
        rm(eM); rm(c1); rm(c2);
        if (r1 !== "win") { await sayAt(p, "§5冥王 モルテ", PJ("morte", 15), "冥王 モルテ", ["……棺が 倒れた。死者に 申し訳が 立たぬ。", RT(p)]); H.rm(); return false; }
        const eM2 = npcNear(p, "§5冥王 モルテ", PJ("morte", 15), true); act(eM2, "kneel");
        await say(p, "冥王 モルテ", ["{closed}……無事に 葬れた。礼を 言う。", "{sad,up}棺の 中は、石に なった 子どもだった。……石化は 年々 広がって おる。この 国の 墓は、もう 足りぬ。"]);
        rm(eM2);
        H.e; await hsay(p, ["{sad,…}……石に なった、子ども……。"]);
        const eA = npcNear(p, "§5ノクス団の 回し者", PJ("noxa", 9)); act(eA, "point");
        await say(p, "回し者", ["{angry,low}……参謀さまの ご命令だ。石板の 子を、祭壇まで 連れて いく。", "抵抗するなら、力ずくで。"]);
        const r2 = await battle(p, team(["nether", "beast", "golem"], 56, 3, 18), { name: "参謀の 回し者", arena: "回し者", theme: "soulvalley", speaker: "回し者", lines: { half: "……聞いて いた より 強い", low: "参謀さま…… 申し訳……" } });
        rm(eA);
        if (r2 !== "win") { await sayAt(p, "§5ノクス団の 回し者", PJ("noxa", 9), "回し者", ["……眠って いろ", RT(p)]); H.rm(); return false; }
        const eA2 = npcNear(p, "§5ノクス団の 回し者", PJ("noxa", 9), true); act(eA2, "recoil");
        const bq = ok(eA2) ? eA2.location : fwd(p, 3);
        await say(p, "回し者", ["{sweat,汗}……くそっ！"]);
        act(eA2, 0); await leave(eA2, p, 12, true);
        burst(p.dimension, bq, "minecraft:white_smoke_particle", 5, 0.4, 0.1); sound(p, "item.book.page_turn", 1);   /* 紙の 束が 落ちる */
        if (ok(H.e) && bq) { await go(H.e, bq, 10); act(H.e, "kneel"); await wait(6); act(H.e, "hold"); }
        await hsay(p, ["{?}……紙の 束。……これ、セオの 研究メモと 同じ 字だ。", "{shock,!,up}『器の 条件: 石板の ささやきが 届く こと。……あの 旅人には 届かない。不適。レイを 試す』……！？"]);
        act(H.e, "raise"); if (ok(H.e)) { camNear(p, H.e, 1.8, 1.9); flash(p, true); await wait(10); }   /* 最後の 頁を 光に かざす */
        await hsay(p, ["{?,up}……最後の 頁、インクで 塗りつぶして ある。光に かざすと……", "{shock,!,up}『記録の 神』……？"]);
        act(H.e, "hold");
        await hsay(p, ["{closed}……わたしの 手帳。荒野の 壁画で 写した、王の 隣の 削られた 影。", "{shock,!,jump}……形が、そっくり。ねえ、王の 隣に いたの、この 人じゃ ない？"]);
        act(H.e, 0);
        const d1 = load(p); if (d1) { qs(d1).ch8a = 1; save(p, d1); } d = d1 || d;
      }
      /* 第122版: 暗い 霊廟の 奥。セオは もう 眼鏡を かけて いない */
      cmd(p, "camera @s fade time 0.3 0.6 0.6 color 0 0 0"); await wait(14);
      big(p, "§5§l裏 切 り", "§f霊廟の 奥で、セオが 待っていた", "mob.wither.spawn");
      const e = npcNear(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB);
      H.e; re(H.e, "shock", "!");
      await say(p, "セオ", ["{closed,low}来て くれましたね。……もう、隠す 必要は ありません。", "{angry,up}僕は §5ノクス団の 参謀§f です。ガロも、ヴァルカも、僕の 指示で 動いて いました。"]);
      await hsay(p, ["{shock,…,up}……うそ。だって、森で 一緒に……"]);
      await say(p, "セオ", ["{closed}封じられた 石板には、主の 力が たまって いく。あなたが 封じる たびに、王を 目覚めさせる 力が そろって いったんです。", "{sad,up}僕の 家族は、一夜で 石に なりました。……その 夜から、石板が ささやくんです。『王が 起きれば、全部 戻る』と。", "{smile,low}とても、やさしい 声で。"]);
      act(H.e, "hold");
      await hsay(p, ["{shock,!}……水晶の 洞くつで 見た、石の 町。わたし、手帳に『学者の 家』って 書いた。", "{sad,up}……あの 町。セオさんの……"]);
      act(H.e, 0);
      await say(p, "セオ", ["{closed}そうです。……だから、引けないんです。", "王が 目覚めるには、王の 心を 宿す §e器§f が 要る。ささやきの 届く 体が。……あなたには、届かなかった。", "{up}……レイくん。かけらの 力、見せて ください。"]);
      const eR = npcNear(p, "§5ノクス団 レイ", RIVAL_JOB); act(eR, "raise"); sound(p, "mob.wither.ambient", 1.2);
      if (ok(eR)) { camNear(p, eR, 1.4, 1.6); redGlow(eR); await wait(14); }   /* 竜の 目が 赤黒く にごる */
      await say(p, "レイ", ["{angry,low}……ごめんな。かけらが 言うんだ。もっと 力を やる、選ばれる 側に して やるって。", "{rage}今の オレは §5ノクス団§f だ。……来いよ。", "{sad,up}……止めて、くれ。"]);
      act(eR, 0);
      await hsay(p, ["{rage,怒,jump}レイの ばか！！ そんなので 勝って、村長が 喜ぶとでも 思うの！？"]);
      await duel(p, "§5§l暴走", "§fかけらに 呑まれた レイの 竜が 黒く 反転する！", { fams: ["dragon"] });
      const lv = 58;
      // v3.0: 星の かけらに 呑まれた レイと 戦う（セオは 見ている だけ。セオとの 戦いは 竜骨の 祭壇で）
      const res = await battle(p, team(["dragon", "nether", "dragon"], lv, 4, 26, leadOf("dragon", lv)), { name: "ノクス団 レイ", arena: "裏切り", theme: "soulvalley", speaker: "レイ", lines: { half: "まだだ……かけらが もっと よこせって 言ってんだよ！", low: "なんで……なんで おまえばっかり……！" } });
      rm(e); rm(eR);
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { await sayAt(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB, "セオ", ["……かけらの 力は、まだ こんな ものでは ありませんよ。", RT(p)]); H.rm(); return false; }
      const s = qs(d2); s.theoBetray = true;
      const e3 = npcNear(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB, true), eR2 = npcNear(p, "§bレイ", RIVAL_JOB, true); act(eR2, "kneel");
      await say(p, "セオ", ["{closed}……かけらが 割れましたか。器には、足りませんでしたね。", "僕は §6ラグナ§f の 竜骨の 祭壇へ 行きます。そこで 儀式を 終わらせる。", "{sad,up}……止めに 来るなら、急いで ください。"]);
      act(e3, 0); await leave(e3, p, 12, false);
      await say(p, "レイ", ["{sad,…}……器……？ オレは、ただの 試し だったのか。", "{cry,tears,up}選ばれる 側に なれるって……あれは 全部、オレが 聞きたかった 言葉 だった だけだ。", "{closed}……おまえが 止めて くれた。今度は オレが セオを 止める。……じいちゃんにも、謝らないと。"]);
      const g = palEnt(p); if (g && ok(eR2)) { const l = eR2.location; place(g, p, { x: l.x + 0.8, y: l.y, z: l.z + 0.6 }); camNear(p, g, 2.2, 0.8); await wait(10); }   /* 相棒が レイの 手に 鼻を 押しあてる */
      await pal(p, ["……レイ、ないてた。"]);
      await say(p, "レイ", [`{smile,…}……へへ。ありがとな、${palNm(p)}。`]);
      rmCine(g); rm(eR2);
      await hsay(p, ["{sad}……レイ。", "{angry,up}行こう。セオさんを 止めなきゃ。", "§7→ ネクロスの 城で 地方マスター ヨミに 挑もう"]);
      reward(p, d2, 20000, [["e_rainbow", 1]]); save(p, d2);
      H.rm();
      return true;
    } },
  { r: 7, seal: 10, hint: "§fネクロス冥府領の §6地方マスター ヨミ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(10),
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).yomiStone) {   /* 第106版: ヨミが 石に なる。第122版: 影が あなたへ 伸び、ヨミが 割って 入る */
        big(p, "§5§l宵闇", "§7霊廟の 影が、こちらへ 伸びて くる", "mob.wither.ambient");
        { const far = fwd(p, 12, 4), nr = fwd(p, 3); if (far && nr) { camPt(p, far, 6, 1); await shadowFlow(p, far, nr, 22); } }
        const eY = npcAt(p, "§6宵闇の 地方マスター ヨミ", PJ("yomi", 8), fwd(p, 6, -2));
        if (ok(eY)) { const q = fwd(p, 2.2); if (q) await go(eY, q, 8, true); act(eY, "guard"); }
        boom(p.dimension, fwd(p, 3) || p.location); flash(p, false); shake(p, 0.6, 0.6);
        await say(p, "ヨミ", ["{angry,!,low}……下がって。", "{closed}守り手から、あなたたちに 伝言が ある。", "{up}『印を 分けあう 二人、離れるな』"]);
        act(eY, "kneel"); await stoneFx(p, eY);   /* つま先から 灰色に */
        H.e; await hsay(p, ["{shock,!,jump}ヨミさん、足が……！"]);
        const g = palEnt(p); if (g && ok(eY)) { const l = eY.location; place(g, p, { x: l.x + 0.7, y: l.y, z: l.z + 0.7 }); camNear(p, g, 2, 0.8); await wait(8); }
        act(eY, "hold");   /* 相棒の 額に 手を 当てる */
        await say(p, "ヨミ", ["{smile}……いい子。この 子を、手放しちゃ だめ。", "{closed,…}……ささやきの 主は、王じゃ ない。……記ろ……"]);
        await stoneFx(p, eY); try { setJob(eY, PJ("yomi_stone", 8)); eY.nameTag = "§7ヨミの 石像"; } catch {} act(eY, 0);
        if (ok(eY)) { camNear(p, eY, 2.2, 1.3); await wait(20); }
        rmCine(g);
        act(H.e, "hold");   /* 相棒を 強く 抱く。泣かない */
        await hsay(p, ["{sad,…,up}…………。", "{closed,up}……離れない。約束する。"]);
        act(H.e, 0); rm(eY);
        const dy = load(p); if (dy) { qs(dy).yomiStone = 1; save(p, dy); }
      }
      await gateOpen(p, 8, "レイ", "……ヨミの こと、オレは 忘れない。フロストヘイムへの 道が 開いた。セオの 儀式を 守る 双子の 幹部が、雪山で 待ち伏せ してる らしい。……今度は、一緒に 行かせて くれ。");
      H.rm(); return true;
    } },
  { r: 8, ch: "第9章 双子の 幹部", at: "land0", hint: "§fフロストヘイム雪山へ 行こう §7（レイと 共闘）", trig: (c) => c.r === 8,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch9a) {   /* 第106版: 雪崩の 中の ノクス団。第122版: かけらを 捨てた レイ */
        const eR0 = npcNear(p, "§bレイ", RIVAL_JOB);
        await say(p, "レイ", ["{closed}……捨てた。かけらは もう ない。", "{blush,汗}じいちゃんには 言うなよ。……今度は 一緒に 行く。"]);
        if (ok(H.e) && ok(eR0)) { const l = eR0.location; await go(H.e, { x: l.x + 0.8, y: l.y, z: l.z + 0.8 }, 8); act(H.e, "raise"); sound(p, "random.pop", 1.2); act(eR0, "recoil"); }   /* 背中を ばしんと たたく */
        await hsay(p, ["{smile,♪,jump}ぜったい 言う。帰ったら 一番に 言う！"]);
        await say(p, "レイ", ["{sweat,汗}……いてて。"]);
        act(H.e, 0); act(eR0, 0);
        sound(p, "random.explode", 0.6); shake(p, 0.9, 1.4);
        big(p, "§f§l雪崩", "§7山が 鳴った――", "random.explode");
        { const q = fwd(p, 14, 0, 6); if (q) { camPt(p, q, 8, 1); for (let k = 0; k < 6; k++) { burst(p.dimension, fwd(p, 14 - k * 2, 0, 6 - k), "minecraft:white_smoke_particle", 12, 2.5, 0); await wait(3); } } }
        act(H.e, "guard"); act(eR0, "guard");
        await hsay(p, ["{shock,!,jump}雪の 中から ノクス団が 突っこんで くる！"]);
        const r = await battle(p, team(["beast", "aqua", "golem"], 62, 3, 22), { name: "雪崩の 中の ノクス団", arena: "雪崩", theme: "snow", speaker: "ノクス団", guests: team(["dragon"], 60, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "前が 見えない……！", low: "……退け！ 雪に 呑まれるぞ！" } });
        rm(eR0);
        if (r !== "win") { await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["雪が ひどすぎる！ いったん 戻ろう！"]); H.rm(); return false; }
        const d1 = load(p); if (d1) { qs(d1).ch9a = 1; save(p, d1); } d = d1 || d;
      }
      const fin9 = !!(qs(d).ch9c || qs(d).rouDead);   /* 第106版: 双子に 勝った あとの やり直しでは 双子を 出さない */
      const e = fin9 ? null : npcNear(p, "§9双子の 幹部 ロウ", PJ("rou", 10)), eU = fin9 ? null : npcNear(p, "§d双子の 幹部 ルウ", PJ("ruu", 10));
      if (!fin9) {
        big(p, "§9§l双子の 幹部", "§f吹雪の 中から、手を つないだ 二つの 影", "mob.polarbear.warning");
        act(e, "hold"); act(eU, "hold");   /* 二人は 手を つないだまま 離さない */
        await say(p, "ロウ", ["{closed}ボクは ロウ。本当の ことしか 言わない。", "{sad}施設の 大人たちは、ボクたちを 別々の 家に やろうと した。セオさまだけが、二人 一緒に 引き取って くれた。", "{angry,up}だから ここは 通さない。セオさまの 儀式の じゃまは させない。"]);
        await say(p, "ルウ", ["{smile}ボクは ルウ。うそしか 言わないよ。", "ボクたち、離ればなれに なっても ぜんぜん 平気だよ。"]);
        await say(p, "ロウ", ["{sad,…}……ボクたち、離ればなれに なるのが いちばん こわいんだ。"]);
        await say(p, "ルウ", ["{closed,up}……これは、本当。"]);
        await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["{angry}オレは もう ノクス団じゃ ない。セオを 止めるって 決めたんだ。……行こう。"]);
      }
      if (!qs(d).ch9b && !fin9) {
        /* なぞかけ: どちらが うそつきか */
        const q = await choose(p, "なぞかけ", "§9§lロウ§r「ルウは うそつき。」\n§d§lルウ§r「ロウは うそつき。」\n\n§f二人とも 同じ 服。どちらかが うそしか 言わない。\n§7……最初に 名乗った 方は 本当の ことしか 言わない と 言った。", [["§9左の 子が 正直（ロウ）", ICON("i_book")], ["§d右の 子が 正直（ルウ）", ICON("i_book")]]);
        await say(p, "ロウ", [q === 0 ? "{smile}……当たり。ボクが ロウ。" : "{sweat,汗}……はずれ。でも、ボクも ときどき わからなく なるんだ。どっちが どっちか"]);
        for (const [nm, k, fams] of [["ロウ", "rou", ["beast", "aqua"]], ["ルウ", "ruu", ["dragon", "aqua"]]]) {
          if (wonOf(p, "t9_" + k)) continue;
          const r = await battle(p, team(fams, 64, 3, 26), { name: `双子の 幹部 ${nm}`, arena: "双子の 連戦", theme: "snow", heal: nm === "ロウ", speaker: nm, lines: { half: nm === "ロウ" ? "ボクの 方が 強い。本当だよ" : "ボクの 方が 弱いよ。うそだけど", low: nm === "ロウ" ? "……負けた。本当に" : "勝った！ ……うそ" } });
          if (r !== "win") { await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["すまない、今のは オレの せいだ。……もう一度 行こう。"]); rm(e); rm(eU); H.rm(); return false; }
          setWon(p, "t9_" + k);
        }
        const d1 = load(p); if (d1) { qs(d1).ch9b = 1; save(p, d1); } d = d1 || d;
      }
      const done9 = !!(qs(load(p) || d).ch9c || qs(load(p) || d).rouDead);   /* 第106版: 勝った あとに 抜けても もう 戦わない */
      if (!done9) await duel(p, "§9§l双子", "§f雪崩の 中で 二体が 同時に 動く！", { fams: ["beast", "aqua"] });
      const lv = 66;
      const res = done9 ? "win" : await battle(p, team(["beast", "aqua", "dragon"], lv, 4, 34), { name: "双子の 幹部 ロウ＆ルウ", arena: "双子の 幹部", theme: "snow", speaker: "ロウ＆ルウ", guests: team(["dragon", "animal"], lv, 2, 20).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "ルウ、そこは 氷が 厚いよ！ ――うん、ロウ！", low: "そんな……ボクたちの 連携が……！" } });
      const d2 = load(p); if (!d2) { rm(e); rm(eU); H.rm(); return false; }
      if (res !== "win") { rm(e); rm(eU); await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["すまない、今のは オレの せいだ。……もう一度 行こう。"]); H.rm(); return false; }
      if (!qs(d2).ch9c) { qs(d2).ch9c = 1; save(p, d2); }
      rm(e); rm(eU);
      /* 第113版: ロウは 氷の 下に 落ち、仮面の 戦士に 引き上げられて 双子ごと 連れ去られる（印 rouDead は「この 場面を 見た」の 意味の まま）。第122版: 目の 前で 起きる */
      if (!qs(d2).rouDead) {
        const eR = npcNear(p, "§bレイ", RIVAL_JOB, true);
        const eO = npcAt(p, "§9双子の 幹部 ロウ", PJ("rou", 10), fwd(p, 5, -1)), eL = npcAt(p, "§d双子の 幹部 ルウ", PJ("ruu", 10), fwd(p, 5, 1));
        act(eO, "kneel"); act(eL, "kneel");
        await say(p, "ルウ", ["{sweat,汗}……ロウ、逃げよう。こっちの 氷は 厚いよ。大丈夫。"]);
        await say(p, "ロウ", ["{smile}ルウが 言うなら、本当だ。"]);
        const ice = fwd(p, 8, -2);
        act(eO, 0); if (ok(eO) && ice) await go(eO, ice, 14);
        sound(p, "random.glass", 1.2); shake(p, 0.4, 0.4); burst(p.dimension, ice, "minecraft:white_smoke_particle", 10, 1, 0.1);
        big(p, "§b§l氷が 割れる", "", "random.glass");
        if (ok(eO)) { const l = eO.location; try { eO.teleport({ x: l.x, y: l.y - 1.6, z: l.z }); } catch {} await wait(6); } rm(eO);   /* 白い 水が、ロウを 飲みこんで 閉じた */
        qs(d2).rouDead = 1; save(p, d2);
        if (ok(H.e)) { const q = fwd(p, 6, -1.5); if (q) await go(H.e, q, 8, true); }   /* 割れた 氷に 飛びつこうと する */
        if (ok(eR) && ok(H.e)) { const l = H.e.location; await go(eR, { x: l.x - 0.6, y: l.y, z: l.z - 0.6 }, 6, true); act(eR, "hold"); act(H.e, "recoil"); }
        await say(p, "レイ", ["{angry,!,up}ばか、おまえまで 落ちるぞ！"]);
        act(H.e, 0); act(eR, 0);
        await say(p, "ルウ", ["{shock,…}……ロウ？", "{cry,tears,up}ロウ、うそだよね。……うそって、言って。", "{cry,tears}……ボク、うそを ついた。ずっと、うそを ついて きた。もう、うそ、言いたく ない。", "{sad,up}……セオさまは、ほんとは やさしい 人なんだ。石板の ささやきを 聞いてから、おかしく なっちゃった。……これは 本当。"]);
        /* 仮面の 戦士（必ず 負ける・十魔将の 予告） */
        const eX = npcAt(p, "§4仮面の 戦士", PJ("argo", 10), ice ? { x: ice.x + 1.2, y: ice.y, z: ice.z } : fwd(p, 8)); await drop(p, eX, 6);
        big(p, "§4§l？？？", "§7吹雪の 向こうから、白い 仮面の 戦士", "mob.warden.emerge");
        act(eX, "kneel"); if (ok(eX)) { camNear(p, eX, 2.6, 0.6); burst(p.dimension, ice, "minecraft:white_smoke_particle", 8, 0.6, 0.1); await wait(14); }   /* 割れた 氷に 腕を 差し入れる */
        const eO2 = npcAt(p, "§9ロウ", PJ("rou", 10), ice); act(eO2, "down"); act(eX, "hold");
        await hsay(p, ["{shock,!,up}あの 仮面の 人、ロウを 引き上げた……！", "{sad,?}……息は してる。でも、目を 開けない……。"]);
        if (ok(eL) && ok(eX)) { const l = eX.location; await go(eL, { x: l.x - 0.7, y: l.y, z: l.z }, 8, true); act(eL, "hold"); }   /* 外套に しがみつく */
        await say(p, "ルウ", ["{cry,tears,up}……返して。ロウを、返して。", "{cry}……これは、本当。"]);
        act(H.e, "guard");
        await battle(p, team(["sword", "nether", "dragon"], 90, 3, 60), { name: "仮面の 戦士", arena: "？？？", theme: "snow", hpk: 30, extra: 0.6, tag: "仮面の 戦士", heal: false, asked: true,
          scripted: { turns: 2, lines: ["§4§l仮面の 戦士の 一閃！", "§7……何が 起きたのか 見えなかった"] }, lines: { half: "『否』" } });
        rm(eX); rm(eO2); rm(eL); rm(eR);
        flash(p, true); shake(p, 0.5, 0.4);
        big(p, "§8……", "§7気が つくと、戦士も 双子も いなかった", "random.orb");
        const cq = fwd(p, 4); burst(p.dimension, cq, "minecraft:white_smoke_particle", 4, 0.3, 0.1);   /* 雪の 上に 札が 一枚 */
        const eR3 = npcNear(p, "§bレイ", RIVAL_JOB, true);
        if (ok(H.e) && cq) { await go(H.e, cq, 10); act(H.e, "kneel"); await wait(6); act(H.e, "hold"); }
        await hsay(p, ["{?}……札が 一枚。『双子は 預かる。器で ないと 分かれば 返す』", "{shock,!,up}……裏にも、もう 一行。『十の 席の 一つ。名は まだ 名乗らぬ』", "{sad,…}……器って なに。十の 席って なに。……わかんない ことばっか。"]);
        act(H.e, "sad");
        await say(p, "レイ", ["{closed}……手、ふるえてるぞ。"]);
        await hsay(p, ["{angry,汗}……寒い だけ。"]);
        act(H.e, 0); rm(eR3);
      }
      { const d9 = load(p) || d2; reward(p, d9, 26000, [["e_king", 1], ["SEED3", 2]]); save(p, d9); }
      H.rm();
      return true;
    } },
  { r: 8, seal: 12, hint: "§fフロストヘイムの §6地方マスター シデン§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(12),
    run: async (p, d) => {
      await gateOpen(p, 9, null, null);
      /* 第122版: その 夜、オルドの 手紙が 届く */
      const H = heroBox(p, true), eR = npcNear(p, "§bレイ", RIVAL_JOB);
      sound(p, "mob.parrot.fly", 1); burst(p.dimension, fwd(p, 2, 0, 1.5), "minecraft:white_smoke_particle", 5, 0.4, 0.5);
      act(H.e, "hold");
      await hsay(p, ["{!,jump}あ、手紙！ ……村長の 字だ。読むね。"]);
      await say(p, "オルド", ["（手紙）ラグナへの 道が 開いた。セオという 若者は、石板の ささやきに 呑まれておる。救えるのは、呑まれなかった おまえさんだけじゃ。", "……わしも 行く。二十年前の しくじりを、今度こそ 終わらせる。"]);
      re(H.e, "closed", "…"); await wait(16); re(H.e, "shock", "?");   /* 三回 読みなおす */
      await hsay(p, ["{?,up}……『わしも 行く』って、どういう こと？", "{sweat,汗}あの人、闘技場の 階段で 息切れ してたよね？"]);
      re(eR, "closed", "…"); if (ok(eR)) { camNear(p, eR, 1.6, 1.6); await wait(16); }   /* レイは、笑わなかった */
      act(H.e, 0); rm(eR); H.rm();
      return true;
    } },
  { r: 9, ch: "第10章 竜骨の 決戦", at: "land0", hint: "§f終焉の地 ラグナへ 行こう §7（レイと 共闘）", trig: (c) => c.r === 9,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch10a) {   /* 第106版: 本拠地の 門番・ベリル 最後 */
        big(p, "§5§lノクス団 本拠地", "§7竜の 骨で できた 門", "mob.enderdragon.growl");
        const eG = npcNear(p, "§cノクス団 中隊長 ガロ", PJ("garo", 9)); act(eG, "guard");
        if (ok(eG)) { camNear(p, eG, 3, 1.4); await wait(10); }
        await say(p, "ガロ", ["{closed,low}……よう。また 昇進した。§e中隊長§f だ。部下は もう 一人も いねえ。", "{sad}門番を やれと 言われた。……でもな、参謀の 言う『戻る』は、いつまで 待っても 来なかった。"]);
        act(eG, "hold");   /* 腰の 帽子を 握りしめる */
        await say(p, "ガロ", ["{closed}行けよ。奥の 番兵どもは 本気で 来る。……オレは、何も 見なかった ことに する。"]);
        await hsay(p, ["{sad}……ピコくん、迎えに 行って あげて。団の 医者じゃ なくて、あなたが。"]);
        re(eG, "shock", "…"); act(eG, 0); await leave(eG, p, 12, false);
        if (!wonOf(p, "gate10")) { const g1 = npcAt(p, "§5本拠地の 門番", PJ("noxa", 9), fwd(p, 5, -1.5)), g2 = npcAt(p, "§5本拠地の 門番", PJ("noxa", 9), fwd(p, 5, 1.5)); act(g1, "guard"); act(g2, "guard"); await say(p, "門番", ["{angry,!,low}通すな！ 儀式を 守れ！"]); }
        const r1 = wonOf(p, "gate10") ? "win" : await battle(p, team(["golem", "nether", "beast"], 70, 3, 30), { name: "本拠地の 門番", arena: "門番", theme: "endcity", speaker: "門番", lines: { half: "通すな！ 儀式を 守れ！", low: "……参謀に、知らせ……" } });
        if (r1 !== "win") { await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["一回 引こう！ 立てなおすぞ！"]); H.rm(); return false; }
        setWon(p, "gate10");
        const eB = npcNear(p, "§5ノクス団 ベリル", PJ("beryl", 9));
        await say(p, "ベリル", ["{closed}……待って。", "{sad}ねえ、知ってた？ 参謀さまの 儀式が 終わったら、ノクス団は なくなるんだって。", "わたし、結局 一度も 仲間に して もらえなかった。名簿に、わたしの 名前は 一度も 書かれなかった。", "{angry,up}だから 最後に 一度だけ。わたしが ここに いた 意味を、ちょうだい。"]);
        const r2 = await battle(p, team(["beast", "blob", "golem"], 72, 3, 32), { name: "幹部候補 ベリル（最後）", arena: "最後の 願い", theme: "endcity", speaker: "ベリル", lines: { half: "今日の わたしは、本気なの！", low: "……やっぱり、だめ、か" } });
        rm(eB);
        if (r2 !== "win") { await sayAt(p, "§5ノクス団 ベリル", PJ("beryl", 9), "ベリル", ["……勝った。初めて、勝った。……なのに、どうして 嬉しく ないの。", RT(p)]); H.rm(); return false; }
        const eB2 = npcNear(p, "§5ノクス団 ベリル", PJ("beryl", 9), true); act(eB2, "kneel");
        await say(p, "ベリル", ["{sad,…}……負けた。", "{sad,up}ねえ。ノクス団が なくなったら、わたし、どこへ 行けば いいの。"]);
        act(eB2, 0);
        if (ok(H.e) && ok(eB2)) { const l = eB2.location; await go(H.e, { x: l.x + 0.8, y: l.y, z: l.z + 0.6 }, 10); act(H.e, "hold"); }   /* 手帳を 差し出す */
        await hsay(p, ["{smile}……行く 所なら、ここに 一つ あるよ。わたしの 手帳の 名簿。"]);
        act(eB2, "hold");   /* 今度は 自分から 受け取る */
        await say(p, "ベリル", ["{closed}……そこに、わたしの 名前、書いて いい？", "{smile,…}……ベ、リ、ル。"]);
        await hsay(p, ["{smile,♪,up}……うん。ちゃんと 書いてある。"]);
        await say(p, "ベリル", ["{smile,up}……ありがとう。行って。あの 人を、止めて あげて。"]);
        act(eB2, 0); act(H.e, 0); await leave(eB2, p, 12, false);
        const d1 = load(p); if (d1) { qs(d1).ch10a = 1; save(p, d1); } d = d1 || d;
      }
      const first = !qs(d).ch10b;   /* 第122版: ハクが 石に なった あとの やり直しでは 守り手の 場面を くり返さない */
      const e = npcNear(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB), eR = npcNear(p, "§bレイ", RIVAL_JOB);
      big(p, "§4§l決 戦", "§f竜の 骨の 祭壇で、セオが 石板を 円に 並べている", "mob.enderdragon.growl");
      if (ok(e)) { camNear(p, e, 3, 1.2); await wait(8); }
      await say(p, "セオ", ["{closed,low}……やっと、そろいました。", "{sad,up}来ましたね。……すみません。本当に、すみません。"]);
      if (first) {
        /* 十四の 影が 円に 立ち上がる */
        const c0 = ok(e) ? e.location : fwd(p, 6);
        if (c0) { for (let k = 0; k < 7; k++) { const a = (k / 7) * Math.PI * 2; burst(p.dimension, { x: c0.x + Math.cos(a) * 4, y: c0.y, z: c0.z + Math.sin(a) * 4 }, "minecraft:soul_particle", 6, 0.5, 0.2); await wait(2); } camLowUp(p, c0); }
        sound(p, "mob.wither.spawn", 0.8); shake(p, 0.7, 1); flash(p, false);
        big(p, "§6§l十四の 守り手", "§f封じた 主たちが、セオの 呼びかけに 応えて 並ぶ", "mob.wither.spawn");
        await say(p, "セオ", ["{angry,up}あとは 器だけ。……レイくん、あなたの 体を 借ります。"]);
        act(eR, "guard"); act(H.e, "guard");
        await say(p, "レイ", ["{angry,!,low}……背中は 任せた。行くぞ！"]);
        /* 七体目の 黒い 息が、レイへ → 白い 獅子が 跳びこむ */
        { const from = fwd(p, 9, 3); if (from && ok(eR)) { camPt(p, eR.location, 4, 1.2); await shadowFlow(p, from, eR.location, 14); } }
        const hk = hakuEnt(p, fwd(p, 3.5, -1.5)), eO = npcNear(p, "§eオルド", PJ("ordo", 8), true);
        if (ok(eO) && ok(hk)) { const l = hk.location; place(eO, p, { x: l.x + 0.6, y: l.y, z: l.z - 0.6 }); ride(hk, eO); }   /* 背に オルドを 乗せて */
        await drop(p, hk, 5); boom(p.dimension, ok(hk) ? hk.location : p.location); sound(p, "mob.ravager.roar", 1); flash(p, true);
        if (ok(hk)) { camNear(p, hk, 3.2, 1.2); await wait(10); }
        await say(p, "オルド", ["{smile,up}……ほっほ。間に 合ったのう。"]);
        re(H.e, "shock", "!");
        await hsay(p, ["{shock,!,jump}……うそ。村長！？ ハク！？", "{rage,怒,up}……腰、痛いんじゃ なかったの！？"]);
        await say(p, "オルド", ["{closed}痛いとも。じゃが、孫を やられる ほうが もっと 痛い。"]);
        act(eO, "raise"); sound(p, "mob.ravager.roar", 1.4); shake(p, 1, 1);   /* つえの 一振りで、ハクが 咆哮 */
        { const c1 = fwd(p, 8); if (c1) { boom(p.dimension, c1); burst(p.dimension, c1, "minecraft:soul_particle", 12, 3, 0.4); } }
        big(p, "§e§lハクの 咆哮", "§f守り手が 三体、後ろへ 吹き飛んだ", "mob.ravager.roar");
        act(eO, 0);
        await hsay(p, ["{shock,…,up}……村長、何も 言って ないのに、ハクが 村長の 見た ところへ 動いてる……。", "{closed}……手帳の『まさかね』、消さなきゃ。……まさか だった。"]);
        await say(p, "レイ", ["{shock,!}じいちゃん……。……ごめん。オレ、間違ってた。"]);
        await say(p, "オルド", ["{smile}話は あとじゃ。……セオよ、ささやきは やさしい ふりを する。今なら まだ 戻れるぞ。"]);
        rmCine(hk);
        await duel(p, "§6§l守り手", "§f三人の 子が 左右と 空から 同時に 撃つ！", { fams: ["dragon", "golem"] });
        const lv0 = 72;
        const r3 = await battle(p, [...bossOne(["dragon", "golem"], lv0, 34, 1), ...team(["dragon", "golem"], lv0, 2, 26)], { name: "呼び出された 守り手", arena: "守り手", theme: "endcity", hpk: 1.8, extra: 0.3, tag: "守り手", speaker: "守り手", guests: [...team(["dragon"], lv0, 1, 30).map((t) => ({ ...t, owner: "レイ" })), ...team(["beast", "animal"], lv0, 1, 30).map((t) => ({ ...t, owner: "オルド" }))], lines: { half: "……ネムリヲ……ジャマ……スルナ……", low: "……カギハ……ドコダ……" } });
        rm(e); rm(eR); rm(eO);
        if (r3 !== "win") { await sayAt(p, "§eオルド", PJ("ordo", 8), "オルド", ["……退くぞ！ 立てなおして、もう一度じゃ！"]); H.rm(); return false; }
        /* 第122版: 王の 影の 黒い 槍。ハクが レイの 身代わりに なって 石に なる（オルドは 生きる） */
        const eR2 = npcAt(p, "§bレイ", RIVAL_JOB, fwd(p, 4, 1.8)), eO2 = npcAt(p, "§eオルド", PJ("ordo", 8), fwd(p, 3, -2.2)), hk2 = hakuEnt(p, fwd(p, 3.5, -0.5));
        act(eR2, "kneel");   /* 竜を 失いかけて ひざを つく */
        big(p, "§c§l！", "§f祭壇の まん中から、黒い 槍が 一筋", "mob.wither.shoot");
        { const sp = fwd(p, 9); if (sp && ok(eR2)) { camPt(p, eR2.location, 4, 1); await shadowFlow(p, sp, eR2.location, 10); } }
        if (ok(hk2) && ok(eR2)) { const l = eR2.location; await go(hk2, { x: l.x + 0.9, y: l.y, z: l.z + 0.9 }, 5, true); }   /* ハクが 跳ぶ */
        flash(p, false); shake(p, 0.8, 0.6); sound(p, "mob.wither.break_block", 0.8);
        if (ok(hk2)) camNear(p, hk2, 3, 1);
        await stoneFx(p, hk2);
        if (ok(hk2) && ok(eO2)) { const l = eO2.location; await go(hk2, { x: l.x + 1, y: l.y, z: l.z }, 10); }   /* 一度だけ 振り返り、オルドの 手に 額を こすりつける */
        act(eO2, "hold");
        await stoneFx(p, hk2, "§7ハクの 石像");
        { const dh = load(p); if (dh) { const sh = qs(dh); sh.ch10b = 1; sh.hakuStone = 1; save(p, dh); } d = load(p) || d; }
        await say(p, "オルド", ["{closed,…}……ハク。"]);
        if (ok(H.e) && ok(hk2)) { const l = hk2.location; await go(H.e, { x: l.x - 0.8, y: l.y, z: l.z + 0.4 }, 8, true); act(H.e, "hold"); }   /* 石の 背中に しがみつく */
        await hsay(p, ["{cry,tears,up}……ハク。ハク！！", "{cry,tears}小さい ころ、この 背中で 何回も お昼寝 したのに……！ たてがみに 絵 描いて、一緒に 叱られたのに……！"]);
        await pal(p, ["……はなれない。ぜったい。"]);
        act(H.e, 0); act(eO2, 0); act(eR2, 0);
        rmCine(hk2); rm(eR2); rm(eO2);
        await sayAt(p, "§5ノクス団 参謀 セオ", TRAITOR_JOB, "セオ", ["{shock,…}……どうして。どうして、そこまで……。", "{rage,up}……もう、止まれないんです！"]);
      } else await sayAt(p, "§eオルド", PJ("ordo", 8), "オルド", ["{closed}……行け。わしは ここで 見て おる。"]);
      const lv = 74;
      const res = await battle(p, team(["nether", "nether", "dragon"], lv, 3, 34), { name: "参謀 セオ", arena: "竜骨の 祭壇", theme: "endcity", hpk: 1.6, speaker: "セオ", guests: team(["dragon"], lv, 1, 30).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "どうして……どうして 届かないんだ……！", low: "……あたたかい。ささやきが、遠く なる……" } });
      rm(e); rm(eR);
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["……まだだ。じいちゃんと ハクの 分まで、止める！ もう一回！"]); H.rm(); return false; }
      const s = qs(d2); s.theoSaved = true;
      const got = reward(p, d2, 40000, [["e_king", 1], ["i_awaken", 1], ["SEED3", 2]]); save(p, d2);
      /* 祭壇の まん中で、セオが ひざを つく */
      const eS3 = npcAt(p, "§7セオ", TRAITOR_JOB, fwd(p, 5)); act(eS3, "kneel");
      const eO3 = npcAt(p, "§eオルド", PJ("ordo", 8), fwd(p, 3, -2.5)), eR3 = npcAt(p, "§bレイ", RIVAL_JOB, fwd(p, 3, 2)), hk3 = hakuEnt(p, fwd(p, 4, -3.6)); if (ok(hk3)) hk3.nameTag = "§7ハクの 石像";
      await say(p, "セオ", ["{shock,…,up}……ささやきが、聞こえない。", "{cry,tears}……僕は、何を。……何を して いたんですか。", "{sad}……家族は、戻らない。本当は、わかって いたのに。", "最後の 一枚、§6王冠の 石板§f は、§c星冠王 ゼファード§f が 持って います。ルミナの 闘技場の 頂点に 立つ 人です。……あなたなら、きっと。"]);
      act(eO3, "hold"); if (ok(hk3)) { camNear(p, hk3, 2.6, 1); await wait(10); }   /* 石の 頭を なでてから、古い 帳面を 取り出す */
      await say(p, "オルド", ["{closed}レイ。これを おまえに やる。§eしくじり帳§f じゃ。わしが 一生で した、しくじりの 全部じゃ。"]);
      act(eR3, "hold");
      await say(p, "レイ", ["{shock,?,up}……じいちゃんは？"]);
      await say(p, "オルド", ["{closed,up}わしの 戦いは、ここまで じゃ。", "{smile,…}……ハクが いない 戦いは、わしの 戦いでは ない。"]);
      act(eO3, 0); act(eR3, 0);
      gotShow(p, "§d§lノクス団 解散", got);
      act(eS3, 0); await leave(eS3, p, 14, false);   /* 誰にも 許されず、誰にも 罰せられず、一人で 歩いて いく */
      const eG = npcAt(p, "§cガロ", PJ("garo", 9), fwd(p, 7, 3)), eP = npcAt(p, "§dピコ", PJ("pico", 9), fwd(p, 7, 4.2)); act(eP, "down"); act(eG, "raise");
      await say(p, "ガロ", ["{closed}……最後の 辞令だとさ。『総帥代理』。……団は もう ねえのにな。"]);
      if (ok(eG)) burst(p.dimension, eG.location, "minecraft:white_smoke_particle", 5, 0.4, 1.4); sound(p, "item.book.page_turn", 1);   /* 辞令を 破り捨てる */
      act(eG, "hold"); rm(eP);   /* 眠った ピコを 背負う */
      await say(p, "ガロ", ["{sad}……ピコ、帰るぞ。屋根の ある 所に。"]);
      await leave(eG, p, 14, false);
      H.e; re(H.e, "sad", "…"); if (ok(H.e)) { camNear(p, H.e, 1.6, 1.6); await wait(24); }   /* 一言も しゃべらない */
      await hsay(p, ["{sad,up}……村長。いつか、全部 話して もらうからね。闘技場の ことも、二十年前の ことも。"]);
      await say(p, "オルド", ["{smile}ほっほ。"]);
      rm(eO3); rm(eR3); rmCine(hk3); H.rm();
      return true;
    } },
  { r: 9, seal: 13, hint: "§fラグナの §6地方マスター ソラ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(13),
    run: async (p, d) => {
      const H = heroBox(p, true), eSo = npcNear(p, "§6ラグナの 地方マスター ソラ", PJ("sora", 8));
      await say(p, "ソラ", ["{closed}これで、地方の 石板は 全部だ。あとは 王冠の 石板。", "{up}……そこへの 扉は、闘技場の いちばん 奥に ある。その 前に 立つ 王者を 越えなければ ならない。"]);
      await hsay(p, ["{?}王者って、だれ？"]);
      act(eSo, "point"); re(eSo, "closed");   /* 答えず、ルミナの 方角を 見る */
      if (ok(eSo)) { camNear(p, eSo, 2, 1.5); await wait(16); }
      await hsay(p, ["{closed,…,up}……。……まさかね。"]);
      act(eSo, 0); rm(eSo);
      await gateOpen(p, 10, "レイ", "セレスティア天空郷への 道が 開いた。……先に 行って 待ってる。星冠王に 挑む 前に、オレと 最後の 勝負を して くれ。");
      H.rm(); return true;
    } },
  { r: 10, ch: "第11章 最後の ライバル", at: "castle", hint: "§fセレスティア天空郷へ 行き、ライバル §bレイ§f と 最後の 勝負", trig: (c) => c.r === 10 || c.s.ending,
    run: async (p, d) => {
      if (qs(d).ending) return true;
      big(p, "§6§lセレスティア天空郷", "§f雲の 上で レイが 待っている");
      const H = heroBox(p, true);
      if (!qs(d).ch11a) {   /* 第106版: 天空郷の 番人たち（3連戦）。第122版: 雲を 割って 現れる */
        const gq = fwd(p, 7);
        sound(p, "mob.enderdragon.flap", 1); shake(p, 0.4, 0.6);
        if (gq) { camLowUp(p, gq); for (let k = 0; k < 4; k++) { burst(p.dimension, gq, "minecraft:white_smoke_particle", 10, 1.5 + k * 0.6, 0.3); await wait(3); } }
        big(p, "§6§l天空郷の 門", "§f雲の 門の 前に、番人が 三体", "mob.enderdragon.growl");
        act(H.e, "guard");
        await hsay(p, ["{shock,!,up}雲の 中から、番人が 三体……！ 言葉じゃ なくて、爪で 聞いて くる 気だ！"]);
        for (let k = 0; k < 3; k++) {
          if (wonOf(p, "g11_" + k)) continue;
          const r = await battle(p, team([["dragon", "animal"], ["golem", "dragon"], ["animal", "nether"]][k], 76 + k * 2, 3, 30 + k * 4), { name: `天空郷の 番人（${k + 1}/3）`, arena: "天空郷の 門", theme: "sky", heal: k === 0, speaker: "番人", lines: { half: "……問イハ マダ 続ク", low: "……通ルガ ヨイ" } });
          if (r !== "win") { await say(p, "レイ", ["（遠くから 声）無理するな！ 待ってるから！"]); H.rm(); return false; }
          setWon(p, "g11_" + k);
        }
        const d1 = load(p); if (d1) { qs(d1).ch11a = 1; save(p, d1); } d = d1 || d;
      }
      /* 第106版: かけらを 捨てた 反動で、レイの 竜が 石に なった。第122版: 島の 端に 石の 竜 */
      const sq = fwd(p, 5, 2.6), dr = monEnt(p, sq, DRAGON_SP(), "§7竜の 石像");
      const e = npcAt(p, "§bライバル レイ", RIVAL_JOB, fwd(p, 4, 1)); act(e, "hold");   /* 石の 竜の 首を、いつもの ように なでる */
      big(p, "§8§l竜の 石像", "§fレイの 隣に、大きな 竜の 石像", "block.stone.break");
      if (ok(dr)) { camNear(p, dr, 4, 1.5); burst(p.dimension, dr.location, "minecraft:white_smoke_particle", 6, 1, 1); await wait(16); }
      await say(p, "レイ", ["{smile}来て くれたか。……こいつ？ オレの 相棒だ。……今は、石像 みたいだけどな。", "{sad}かけらを 捨てた 夜から、少しずつ 固まって いった。かけらの 代わりに、こいつが 持って いかれたんだと 思う。", "{closed,…}……オレの せいだ。"]);
      const g = palEnt(p); if (g && ok(dr)) { const l = dr.location; place(g, p, { x: l.x - 1, y: l.y, z: l.z }); camNear(p, g, 2.2, 0.8); await wait(8); }   /* 相棒が 石の 竜に 鼻を 押しあてる */
      await pal(p, ["……まだ、なかに いる。"]);
      rmCine(g);
      await hsay(p, ["{sad,…}……ラグナで 石に なった、ハクの 背中みたい。", "{smile,up}……レイ。村長と おんなじ 顔 してる。"]);
      await say(p, "レイ", ["{blush,汗}……うるせえ。", "{smile}……へへ。"]);
      act(e, "raise");   /* しくじり帳を 取り出す */
      await say(p, "レイ", ["{closed}じいちゃんの しくじり帳。全部 読んだ。……二十年前の ことだけ、書いて なかった。"]);
      await hsay(p, ["{rage,怒,jump}書いて ないの！？ ずるい！ 一番 大事な ところじゃない！"]);
      await say(p, "レイ", ["{smile,!}だろ？ ……だから、最後の 頁は オレが 書く。", "{angry,up}かけらも 竜も なしの、ほんとの オレで 勝負したい。……手加減は なしだ。"]);
      act(e, "guard");
      await hsay(p, ["{smile,☆,jump}がんばれー！ ……レイも！ ちょっとだけ、がんばれ！"]);
      rmCine(dr);
      await duel(p, "§b§l雲の 上の 一騎打ち", "§f竜の いない レイの 子が 真っ向から 飛びこむ！", { fams: ["animal", "beast"] });
      const lv = 80;
      const res = await battle(p, team(["animal", "beast", "golem"], lv, 4, 36), { name: "ライバル レイ（最後の 勝負）", arena: "最後の ライバル戦", theme: "sky", speaker: "レイ", lines: { half: "まだだ……オレも 全部 出しきる！", low: "……ハハ、やっぱ おまえは すげえよ。" } });
      rm(e);
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["{smile}オレの 勝ちだ。……でも 星冠王は、オレより ずっと 強い。もう一度、鍛えて 来い。"]); H.rm(); return false; }
      const s = qs(d2); s.reiW = (s.reiW || 0) + 1; s.reiFinal = 1;
      const e2 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true), dr2 = monEnt(p, sq, DRAGON_SP(), "§7竜の 石像");
      act(e2, "up"); if (ok(e2)) { camNear(p, e2, 2, 1.6); await wait(20); }   /* しばらく 空を 見上げる */
      await say(p, "レイ", ["{smile,…}……完敗だ。"]);
      act(e2, "hold"); sound(p, "item.book.page_turn", 1); await wait(10);   /* しくじり帳の 最後の 頁に、一行だけ 書く */
      await say(p, "レイ", ["{closed,up}『オレは、ルミナを 守る。』……これで いいよな、じいちゃん。", "{smile,up}……石板の 続きは、おまえに 任せた。じいちゃんと ハクの 分まで、終わらせて こい。", "{?}……なあ。さっき、おまえの 後ろに 誰か 立って なかったか？ ……気のせいか", "§7→ §cルミナの 闘技場§7 で カップを 勝ちぬく"]);
      act(e2, 0); rm(e2); rmCine(dr2); H.rm();
      reward(p, d2, 30000, [["e_king", 1], ["SEED3", 1]]); save(p, d2);
      return true;
    } },
  { r: 99, nospot: 1, ch: "終章 星冠王", hint: "§f闘技場の カップを ぜんぶ 勝って §c星冠王§f に 挑もう。石板を ぜんぶ 封印したら 王冠の 石板へ §7（進み具合は ガイドブック ＞ ストーリー）", trig: (c) => !!c.s.ending,
    run: async (p, d) => {
      if (!wonOf(p, "e0")) {   /* 第122版: ルミナの 夕方。牧場の すみに 石の ハクと 竜。ゼファードの 伝言を オルドへ */
        await sceneAt(p, plazaOf("t0"), "ルミナの 牧場");
        const H = heroBox(p, true);
        const hk = hakuEnt(p, fwd(p, 5, -2)), dr = monEnt(p, fwd(p, 5, 2.6), DRAGON_SP(), "§7竜の 石像"); if (ok(hk)) hk.nameTag = "§7ハクの 石像";
        if (ok(hk)) { camPt(p, hk.location, 6, 1.5); await wait(16); }
        const eG = npcAt(p, "§cガロ", PJ("garo", 9), fwd(p, 4, -3.4)), eP = npcAt(p, "§dピコ", PJ("pico", 9), fwd(p, 5, -1)); act(eP, "down"); act(eG, "kneel");   /* 眠った ピコを ハクの 背に もたれさせる */
        await say(p, "ガロ", ["{closed}……ここが いちばん、あったかい 気が するんだ。"]);
        const eR = npcNear(p, "§bレイ", RIVAL_JOB); act(eR, "hold");
        await say(p, "レイ", ["{smile}……終わったな。", "{closed}ゼファードさん、石の 眠りに つく 前に、おまえの 名前を 呼んでたよ。"]);
        const eO = npcNear(p, "§eオルド", PJ("ordo", 8));
        await hsay(p, ["{smile}村長。ゼファードさんから 伝言。", "{closed,up}『おまえの 弟子は、よい 子だ』って。"]);
        re(eO, "closed", "…"); if (ok(eO)) { camNear(p, eO, 1.6, 1.6); await wait(16); }
        await say(p, "オルド", ["{smile,…}……ほっほ。……あいつめ。"]);
        if (ok(H.e) && ok(hk)) { const l = hk.location; await go(H.e, { x: l.x + 0.9, y: l.y, z: l.z + 0.9 }, 10); act(H.e, "kneel"); }   /* ハクの 前に しゃがんで 手帳を 開く */
        await hsay(p, ["{sad}……まだ 終わって ないよ。ハクも、竜も、ピコくんも。石に なった 人たちも。", "{smile,up}いつか 全部、この 手帳に『おかえり』って 書くんだから。"]);
        act(H.e, 0); sound(p, "random.orb", 0.6); particle(p, "minecraft:totem_particle", 0.6);   /* コンパスの 針が 揺れる */
        await hsay(p, ["{shock,!,jump}……あれ？ コンパスの 針が 揺れてる。……闘技場の、もっと 奥を 指してる！"]);
        rm(eG); rm(eP); rm(eR); rm(eO); rmCine(hk); rmCine(dr); H.rm();
        setWon(p, "e0"); d = load(p) || d;
      }
      if (!qs(d).m1) {   /* 第106版: 魔1「鍵の 外れた 夜」 */
        big(p, "§4§l鍵の 外れた 夜", "§7アルカトラス城の 地下から 地鳴り", "ambient.weather.thunder");
        await narr(p, "地鳴り", ["§7その 夜、アルカトラス城の 地下から 地鳴りが した。", "§f城の 使いが 走って きた。§6「王が お呼びです。……王が、§c玉座から 立ちました§6」"]);
        await goScene(p, 0, "アルカトラス城");   /* 第112版: 城の 使いに 連れられて 城へ（前は その場で 話が 進んで いた）*/
        const eK = npcNear(p, "§6アルカ十三世", PJ("arca13", 15));
        await say(p, "アルカ十三世", ["§7（王の 手が、玉座の ひじかけから 離れた）", "……すまぬ。余は 生まれて 初めて 玉座を 立った。", "見よ。玉座の 下には、§e千年分の 王の 名§f が 刻まれて おる。全員、ここから 一歩も 動かなかった", "この 城は 城では ない。§6アルカの 砦§f――丘の 下に 眠る 者を 見張る ための 砦なのだ"]);
        camFade(p); await wait(12); await establish(p, p.location, "城の 地下 封印庫", 6, 40); await narr(p, "地下の 封印庫", ["§7王に 連れられて 地下へ 降りると、古い 壁画が あった。", "§f白い 髪の 剣士と、もう 一人の 剣士が 向かい合って いる。", "§7片方は §6アルカ§7。初代の 王で、当時の 封じ手。", "§7もう 片方の 剣士の 刀には、§c鍔が なかった§7。", "§8……壁画の 下で、封印の 石が 割れて いた。"]);
        big(p, "§4§l影が あふれた！", "§f封印庫から 影の モンスターが 城下町へ！", "mob.wither.spawn"); await drama(p);
        await say(p, "衛兵の 子 トト", ["ぼくも 戦う！ 父さんは 衛兵なんだ。……影に やられて、まだ 目を さまさない けど。"]);
        const r = await battle(p, team(["nether", "nether", "dragon"], 92, 3, 50), { name: "封印庫から あふれた 影", arena: "城下町の 夜", theme: "underworld", speaker: "影", guests: team(["beast"], 85, 1).map((t) => ({ ...t, owner: "衛兵の 子 トト" })), lines: { half: "……カギ……ハズレタ……", low: "……オカ……ノ……シタ……" } });
        rm(eK);
        if (r !== "win") { await say(p, "アルカ十三世", ["……引け！ 体勢を 立てなおすのだ", RT(p)]); return false; }
        await say(p, "アルカ十三世", ["……礼を 言う。千年、見張って きた 甲斐が あった。", "丘の 下の 者を 救える とすれば、§e伝説の マスター§f カゲツの 家だけだ。§7ルミナの 闘技場で 寝て おる"]);
        const d1 = load(p); if (d1) { qs(d1).m1 = 1; save(p, d1); }
      }
      return true;
    } },
  { r: 99, nospot: 1, ch: "魔神編", hint: "§f伝説の マスター カゲツ（裏ボス）に 勝とう §7（ルミナの 闘技場）", trig: (c) => has(c, "k_hilt") && !!c.s.hiltGot,
    run: async (p, d) => {
      await sceneAt(p, plazaOf("t0"), "ルミナの 闘技場"); big(p, "§4§l魔神編", "§f赤黒く 光る 鍔が、持ち主を 呼んでいる", "mob.wither.spawn");
      await say(p, "カゲツ", ["ふぁ……起きちまった。……よく 寝てる 間に 勝ったな", "この 鍔は、§6剣の 家§f が 千年 守って きた。", "……打ったのは、うちじゃねえ。§6クロガネ§f の 鍛冶だ。", "眠い。……クロガネの §cムサシ§f を たずねろ。あいつの 家の 話だ"]);
      await narr(p, "魔神の鍔", ["§4カゲツに 託された 鍔が、赤黒く 脈を 打つ……", "§e→ §fはがねの 村 §eクロガネ§f で §cムサシ§f を さがそう §7（右上の 案内）"]);
      return true;
    } },
  { r: 99, hint: "§fカゲツの 弟子 §cムサシ§f を さがそう §7（はがねの 村 クロガネに いる 武士に 話しかける）", trig: (c) => !!c.s.musashiJoin,
    spot: (p, d) => majinSpot(d), run: async (p, d) => majinMid(p, d) },
  { r: 99, hint: "§fムサシと §5閻魔の神殿§f へ 行き、魔神の鍔を 捧げよう §7（神殿の 前で ガイドブックを 使う）", trig: () => false, run: async () => false },
];
const POST = MQ.findIndex((x) => x.r === 99);
/* 第106版: 神殿へ 行く 前に 魔4〜魔6を すませる（前の 版で この 段を こえた セーブは そのまま） */
export function majinReady(d) { const s = qs(d), k = MQ.findIndex((x) => x.r === 99 && /ムサシ§f を さがそう/.test(x.hint || "")); return !!s.m6 || k < 0 || (s.mq ?? 0) > k; }
/* 第108版: 魔4（クロガネの 工房）→ 魔5（アルカトラス地方の 5つの 斬り跡を 1か所ずつ 歩いて 回る）→ 魔6（宿で 見る 悪夢）
   1回の 呼び出しで 1場面だけ。次の 場所は 右上と 足もとの「！」で 案内する */
const CRACK = [["丘の 割れ目", 30], ["川辺の 割れ目", 100], ["森の 割れ目", 170], ["谷の 割れ目", 240], ["王冠の 割れ目", 310]];
function crackPos(n) { const s0 = SP(), R = WREGIONS[0], a = CRACK[n][1] * Math.PI / 180, rr = Math.min(170, R.r * 0.55); return { x: Math.floor(s0.x + R.c[0] + Math.cos(a) * rr), z: Math.floor(s0.z + R.c[1] + Math.sin(a) * rr) }; }
function majinSpot(d) {
  const s = qs(d);
  if (!s.m4) { const t = musashiTownInfo(); if (!t || !t.pos) return null; return { key: "m4", x: Math.floor(t.pos.x) + 3, y: t.built ? Math.floor(t.pos.y) : null, z: Math.floor(t.pos.z) - 6, nm: "クロガネ（工房）" }; }
  const n = s.m5 || 0;
  if (n < CRACK.length) { const q = crackPos(n); return { key: "m5_" + n, x: q.x, y: null, z: q.z, nm: `アルカトラス地方の ${CRACK[n][0]}`, r: 6 }; }
  if (!s.m6) { let best = null; try { for (const t of TOWNS) { const q = getTown(t.id); if (!q || !q.built || !q.y) continue; const sp2 = innOf(t.id) || plazaOf(t.id) || { x: Math.floor(q.x) + 3, y: Math.floor(q.y), z: Math.floor(q.z) - 6 }; if (!best) best = { key: "m6", ...sp2, nm: t.name + "（宿屋）", np: 1 }; if (t.id === "t0") { best = { key: "m6", ...sp2, nm: t.name + "（宿屋）", np: 1 }; break; } } } catch {} return best; }
  return null;
}
async function majinMid(p, d) {
  if (!qs(d).m4) {   /* 魔4 はぐれ鍛冶（クロガネの 工房） */
    big(p, "§c§lはぐれ鍛冶", "§fクロガネの 工房に 火の 手が", "mob.blaze.shoot");
    const eV = npcNear(p, "§cはぐれ鍛冶 ヴァルカ", PJ("valka", 10));
    await say(p, "ヴァルカ", ["よう、ムサシ。……久しぶりだね、§e弟弟子§f。", "ノクス団が 消えて、帰る 場所が ここしか なかった。", "工房の 奥の 開かずの 部屋。鍵は アタシが もらったよ。……中、見たかったんだ。ずっと"]);
    await say(p, "ムサシ", ["ヴァルカ……！ ちくしょう、なんで お前が……！", "§7（ムサシの 拳が ふるえて いた）"]);
    if (!wonOf(p, "m4v")) {
      await duel(p, "§c§l屋根の 上の 二対一", "§fムサシと 並んで ヴァルカを 迎え撃つ！", { a: "musashi", fams: ["dragon", "nether"] });
      const r = await battle(p, team(["dragon", "nether", "nether"], 92, 3, 50), { name: "はぐれ鍛冶 ヴァルカ", arena: "鍛冶場の 屋根", theme: "volcano", speaker: "ヴァルカ", guests: [{ sid: "musashi", lv: 90, q: 1, plus: 15, owner: "ムサシ" }], lines: { half: "……いい 太刀筋だ", low: "……悪くない。本当に" } });
      if (r !== "win") { rm(eV); await say(p, "ヴァルカ", ["……まだ 早いよ、弟弟子。", RT(p)]); return false; }
      setWon(p, "m4v");
    }
    big(p, "§c§l工房が 崩れる！", "", "random.explode");
    await narr(p, "崩れる 工房", ["§c燃えた 梁が、ムサシの 頭上に 落ちて くる。", "§fヴァルカが、ムサシを 突き飛ばした。", "§8……梁の 下から、ヴァルカの 声が した。"]);
    await say(p, "ヴァルカ", ["……アンタの 炉の 火、きれいだったよ。昔から。", "アタシが 焼いた 港の 人…… ナギサって 言ったっけ。もう 潜れない 腕に したのは、アタシだ。", "許さなくて いいよ。……許さないで"]);
    rm(eV);
    await narr(p, "開かずの 部屋", ["§7焼け残った 奥の 部屋に、§f少女の 石像§7 が あった。", "§f台座の 文字: §6「エンマの 妹 ――」§7（名前は 削られて いる）", "§7ムサシ「……先祖が 閉じこめて きたのは、エンマじゃ なかった。この子だった」", "§e→ §fアルカトラス地方に 残る §65つの 斬り跡§f を たどろう §7（右上の 案内と「！」）"]);
    const d1 = load(p); if (d1) { qs(d1).m4 = 1; save(p, d1); }
    return "next";   /* 次の 場所へ（物語は この 段の まま） */
  }
  const n = qs(d).m5 || 0;
  if (n < CRACK.length) {   /* 魔5 千年前の 斬り跡（1か所ずつ） */
    const where = CRACK[n][0];
    big(p, `§6§l斬り跡 ${n + 1}/5`, `§f${where}に 残像が 立ち上がる`, "block.amethyst_block.chime");
    let r = "win";
    if (n === 0) {   /* 村を 守る 剣士 エンマ：村を 襲う 群れを 残像と 一緒に 払う */
      await narr(p, where, ["§7割れ目に 触れると、千年前の 景色が 重なった。", "§7村を 魔物の 群れが 襲って いる。§f白い 髪の 剣士が、村の 子を 背に かばって 立って いる。", "§f剣士の 名は §4エンマ§f。……こちらに 気づいて、短く うなずいた。"]);
      r = await battle(p, team(["beast", "nether", "beast"], 90, 3, 46), { name: "村を 襲う 群れ（千年前）", arena: where, theme: "ruins", speaker: "群れ", guests: [{ sid: "enma", lv: 80, q: 1, plus: 0, owner: "残像の エンマ" }], lines: { half: "グルル……", low: "……ニゲロ……" } });
    } else if (n === 1) {   /* 妹と 鍔：戦いは ない */
      await narr(p, where, ["§7川べりで、少女が 笑って いる。", "§f「兄さま、刀に 鍔を つけて もらったの？ ……かっこいい」", "§7エンマは 照れて、鍔を 指で なぞった。§8その 鍔は、クロガネの 鍛冶が 打った ものだった。"]);
      await say(p, "ムサシ", ["……うちの 鍔だ。こんなに 大事に されてたのか"]);
    } else if (n === 2) {   /* 石に なった 村：石の 番兵と 戦う */
      await narr(p, where, ["§8ある 朝、妹が 石に なって いた。", "§7村じゅうが 灰色に 止まって、エンマだけが 動いて いた。", "§7石に なった 番兵たちが、ゆっくりと こちらを 向く――"]);
      await duel(p, "§7§l石の 番兵", "§f石に なりかけた 番兵が 動き出す！", { fams: ["golem"] });
      r = await battle(p, team(["golem", "golem", "dragon"], 92, 3, 50), { name: "石に なった 村の 番兵", arena: where, theme: "ruins", speaker: "番兵", lines: { half: "……イシニ……ナル……", low: "……アリガトウ……" } });
    } else if (n === 3) {   /* ささやき：影と 戦う */
      await narr(p, where, ["§5「王を 斬れば、妹は 戻る」", "§7……頭の 中に、やさしい ささやきが した。§fエンマは、王の 城へ 向かった。", "§7割れ目から、ささやきの 影が あふれ出す。§8……あなたには、何も 聞こえない。"]);
      r = await battle(p, team(["nether", "nether", "dragon"], 94, 3, 54), { name: "ささやきの 影", arena: where, theme: "underworld", speaker: "影", lines: { half: "……キコエナイノ……？", low: "……ナゼ……キカナイ……" } });
    } else {   /* 王冠：残像の エンマ（1体の 強敵） */
      await narr(p, where, ["§fエンマは 王を 斬った。§7王の 隣の 守り手も 斬った。", "§8……王の すぐ 後ろに、もう 一つ 影が 立って いた。§5ささやきの 主§8 だ。", "§8エンマの 刀が 届く 前に、影は 壁画から §c自分を 削り取って§8 消えた。", "§7（荒野の 壁画の 削られた 影は、これだった）", "§4残像の エンマ§7 が、こちらに 刀を 向けた。"]);
      await duel(p, "§4§l残像の エンマ", "§fムサシの 子と 残像の 刀が 交わる！", { a: "musashi", b: "enma" });
      r = await battle(p, [{ sid: "enma", lv: 95, q: 1, plus: 60 }], { name: "残像の エンマ", arena: where, theme: "palace", speaker: "エンマ", hpk: 0.6, extra: 0.3, lines: { half: "……", low: "……イモウト……" } });
      if (r === "win") await narr(p, "最後の 残像", ["§8エンマが、石の 妹を 抱いて 叫んで いる。", "§8残像に 音は ない。口だけが、何度も 同じ 形に 動いて いた。"]);
    }
    if (r !== "win") return false;
    const dn = load(p); if (dn) { qs(dn).m5 = n + 1; if (n + 1 >= CRACK.length) qs(dn).m5b = 1; save(p, dn); }
    if (n + 1 < CRACK.length) { try { p.sendMessage(`§e→ §f次は §6${CRACK[n + 1][0]}§f §7（右上の 案内と「！」）`); } catch {} return "next"; }
    try { p.sendMessage("§e→ §fどこかの 町の 宿屋で 休もう §7（広場の「！」）"); } catch {}
    return "next";
  }
  if (!qs(d).m6) {   /* 魔6: 悪夢（宿で 眠ると エンマの 側から 見た 夢） */
    big(p, "§4§l悪夢", "§7宿屋の 布団で 目を 閉じると――", "mob.wither.ambient");
    await narr(p, "悪夢", ["§8……夢の 中で、自分は §4エンマ§8 だった。", "§8神殿に 来た 小さな 旅人を、一太刀で 斬った。§7あれは、ずっと 前に 神殿で 負けた 自分だ。", "§8斬りながら、エンマは 思って いた。§7『§f私は、正しかったのか§7』"]);
    await battle(p, [{ sid: "enma", lv: 100, q: 1, plus: 99 }], { name: "夢の 中の エンマ", arena: "悪夢", theme: "hell", heal: false, asked: true, speaker: "エンマ",
      scripted: { turns: 1, lines: ["§4§l国崩", "§7……一瞬で、すべてが 斬られた"] }, lines: { half: "……" } });
    await narr(p, "目覚め", ["§7目が 覚めると、仲間は 隣で 寝息を 立てて いた。", "§f……§5閻魔の神殿§f へ 行こう。鍔を 捧げる 時だ。"]);
    const d1 = load(p); if (d1) { qs(d1).m6 = 1; save(p, d1); }
  }
  return true;
}
/* 第122版: 闘技場の 最後の カップ（仮面の 王者 → オルド）と 星冠王の 場面。story.js から 呼ぶ。
   k: "mask"（決勝の 前）・"ordoWin"（オルドに 勝った あと）・"zeph0"（星冠王の 前）・"zeph1"（星冠王に 勝った あと）
   返り値: "ordo"（仮面を 取った）・"mask"（仮面の まま）・true */
export async function cupScene(p, k) {
  const d = load(p); if (!d) return true; const s = qs(d);
  const H = heroBox(p, true), L = [];
  const N = (nm, job, q) => { const e = q ? npcAt(p, nm, job, q) : npcNear(p, nm, job, true); L.push(e); return e; };
  let out = true;
  try {
    if (k === "mask") {
      const eO = N("§7仮面の 王者", PJ("ordo", 8), fwd(p, 6));
      big(p, "§6§lけっしょう", "§f反対側の 門から、仮面の 人影が 歩いて くる", "raid.horn");
      if (ok(eO)) { const q = fwd(p, 4); camNear(p, eO, 3, 1.2); if (q) await go(eO, q, 18); }   /* つえを ついて、腰が 少し 曲がって いる */
      if (!(s.hakuStone || s.ending)) {   /* 第10章より 前は 仮面の まま 何も 言わない */
        re(eO, "closed", "…");
        await hsay(p, ["{?,up}……あの 歩き方、どこかで……？"]);
        return (out = "mask");
      }
      if (s.ordoMask) { await say(p, "オルド", ["{smile}ほっほ。また 来たか。……手加減は せんぞ。"]); return (out = "ordo"); }
      act(H.e, "up"); re(H.e, "shock", "!");
      if (ok(eO)) { camNear(p, eO, 1.6, 1.6); await wait(16); }
      act(eO, "raise"); flash(p, true); sound(p, "random.orb", 1);   /* 仮面に 手を かけて、はずす */
      try { if (ok(eO)) eO.nameTag = "§eオルド"; } catch {}
      act(eO, 0);
      await say(p, "オルド", ["{smile,up}……ほっほ。待たせたのう。"]);
      await hsay(p, ["{rage,怒,jump}やっぱり 隠してたー！！", "{rage,怒,up}『昔、ちょっとな』じゃ ないでしょ！！ 『ちょっと』って 何よ！ この 二十年、村の 屋根を だれが 直してたと 思ってんの！"]);
      await say(p, "オルド", ["{smile,汗}ほっほ。それは、わしじゃな。腰は 痛いがのう。"]);
      sound(p, "random.levelup", 0.4); burst(p.dimension, p.location, "minecraft:villager_happy", 10, 6, 1.5);   /* 観客席が どっと わく */
      /* オルドの 後ろに 並んだ 子たち。ハクは いない */
      const g1 = monEnt(p, fwd(p, 5, -1.5), "nbea003", ""), g2 = monEnt(p, fwd(p, 5.5, 1.5), "nbea036", "");
      if (ok(g1)) { camNear(p, g1, 3, 0.8); await wait(14); }
      await hsay(p, ["{sad,…}……村長。ハク なしで、まだ 戦うの？"]);
      rmCine(g1); rmCine(g2);
      await say(p, "オルド", ["{closed}わしの 戦いは、ラグナで 終わった。じゃから、これは わしの 戦いでは ない。ハクの あとに 育てた、この 子たちの 戦いじゃ。", "{up}大事な ものを 失っても、前には 進める。……それを、王冠の 石板へ 行く 前の おまえさんに 見せて おきたかった。", "{smile,!}それが、わしの 最後の 仕事じゃ。"]);
      const d1 = load(p); if (d1) { qs(d1).ordoMask = 1; save(p, d1); }
      return (out = "ordo");
    }
    if (k === "ordoWin") {
      const eO = N("§eオルド", PJ("ordo", 8), fwd(p, 3.5)); act(eO, "kneel");
      await say(p, "オルド", ["{smile,…}……ほっほ。二十年ぶりに、負けたわい。"]);
      act(eO, 0);
      cmd(p, "camera @s fade time 0.3 0.6 0.6 color 0 0 0"); await wait(14);
      big(p, "§6§l闘技場の いちばん 奥", "§f重い 扉の 前で", "random.door_close");
      const dq = fwd(p, 7, 0, 1.5); if (dq) { camPt(p, dq, 5, 1); burst(p.dimension, dq, "minecraft:totem_particle", 8, 1.2, 0.5); await wait(14); }
      await say(p, "オルド", ["{closed}わしと、友の ゼファードは、王を 終わらせる ために 王冠の 石板に 入った。", "{sad}……わしは、途中で 引き返した。ハクが 呑まれかけてな。ハクを 連れて 戻るか、ハクを 置いて 先へ 行くか。わしは 戻る 方を 選んだ。"]);
      await hsay(p, ["{sad,?}……ゼファードさんは？"]);
      await say(p, "オルド", ["{closed,up}一人で 残った。そして、最後の 封印者に なった。……二十年、あいつは あそこで、一人で 王を 押さえて おる。", "{smile,…}それが、わしの しくじりじゃ。じゃが、後悔は して おらん。ハクと 二十年、この 村で、おまえさんたちが 背中に 乗るのを 見て こられた。"]);
      if (ok(H.e) && ok(eO)) { const l = eO.location; await go(H.e, { x: l.x + 0.7, y: l.y, z: l.z + 0.7 }, 8); act(H.e, "raise"); sound(p, "random.pop", 1); }   /* 腰を ちょっとだけ 強く たたく */
      await say(p, "オルド", ["{sweat,汗}いたたた。……ほっほ。", "§7→ 闘技場の 奥の 扉（星冠の 王座）へ"]);
      act(H.e, 0);
      return true;
    }
    if (k === "zeph0") {
      const eZ = N("§c星冠王 ゼファード", PJ("zephard", 8), fwd(p, 5)); act(eZ, "kneel");   /* 玉座に 座った まま。足もとは もう 半分 石 */
      if (ok(eZ)) { burst(p.dimension, eZ.location, "minecraft:white_smoke_particle", 6, 0.6, 0.1); camNear(p, eZ, 2.6, 1.2); await wait(14); }
      await say(p, "ゼファード", ["{closed,low}……待って いたぞ。石板が 選んだ マスターよ。", "{smile,up}……オルドは 元気か。"]);
      await hsay(p, ["{rage,怒,jump}元気すぎます！"]);
      sound(p, "random.orb", 0.5);
      await say(p, "ゼファード", ["{smile}……ふ、ははは。二十年ぶりに、声を 立てて 笑った。", "{angry,up}王座で 見せて もらう。おまえに、あれを 託せるか。"]);
      return true;
    }
    if (k === "zeph1") {
      const eZ = N("§c星冠王 ゼファード", PJ("zephard", 8), fwd(p, 4)); act(eZ, "kneel");
      await say(p, "ゼファード", ["{closed}……負けた、のか。この わたしが。", "{up}これを 持って いけ。§6王冠の 石板§f――古い 王が 眠る 最後の 一枚だ。", "{sad}王は ささやく。『失った ものを、全部 返して やろう』と。……ハクも、竜も、眠った 子の 心も。"]);
      await hsay(p, ["{angry,up}……いらない。返して もらうんじゃ なくて、自分たちで 取り戻すの。", "{closed}……王墓の 壁に 書いて あったでしょ。『永遠を 願うな。願いは 石に なる』って。"]);
      await say(p, "ゼファード", ["{smile,…}……そうか。その 子と おまえの 間に、§6印§f が 見える。……二人で 一つなら、呑まれない。", "{closed,up}……オルドに 伝えて くれ。『おまえの 弟子は、よい 子だ』と。"]);
      await stoneFx(p, eZ, "§7ゼファードの 石像");   /* 二十年分の 息を 吐いて、石の 眠りに つく */
      if (ok(eZ)) { camNear(p, eZ, 2.2, 1.3); await wait(20); }
      await hsay(p, ["{sad,…}……おやすみなさい。……ちゃんと、伝えるね。"]);
      return true;
    }
  } finally { for (const e of L) rm(e); H.rm(); spkClean(p); }
  return out;
}
async function gateOpen(p, r, who, line) {
  big(p, "§a§l道が 開けた！", `§f${RN(r)}へ 行けるように なった`, "ui.toast.challenge_complete");
  particle(p, "minecraft:totem_particle", 1.5);
  if (who) await say(p, who, [line]);
}

// 前の バージョンの セーブ・チート: いまの 進みに あわせて 手順を 決める（だいじなもの も そろえる）
function fixMq(p, d) {
  const s = qs(d);
  // v2.9.13: 物語と 地方の 進みが そろって いる セーブは 順番を 守る（古い セーブで 物語が 遅れて いる ときは そのまま）
  if ((s.kg || 0) >= 1 && !s.hiltGot) { s.hiltGot = true; s.keys = [...new Set([...(s.keys || []), "k_hilt"])]; return true; }
  if (s.hiltGot && !(s.keys || []).includes("k_hilt")) { s.keys = [...(s.keys || []), "k_hilt"]; return true; }   /* v2.9.13: 前の 版で カゲツに 勝った 人 */
  /* v2.9.14: 前の 版で ムサシ（カゲツ）・エンマを 仲間に した 人は 魔神編を すませた ことに */
  if (!s.musashiJoin && (s.kg || 0) >= 1 && (d.own || []).includes(SPECIES.musashi?.idx)) { s.musashiJoin = 1; return true; }
  if (!s.enmaClear && s.enmaJoin) { s.enmaClear = 1; s.musashiJoin = 1; return true; }
  if (!s.ord && s.mq !== undefined && !s.ending && storyOpen(s) >= sealOpen(s)) { s.ord = 1; return true; }
  if (s.ending && (s.mq === undefined || s.mq < POST)) { s.mq = POST; for (const k of ["k_note", "k_light", "k_goggle"]) if (!(s.keys || []).includes(k)) giveKey(p, d, k); return true; }
  /* 第106版: 前の 版で 物語を 先まで 進めた セーブは、亡くなった 人の 印を そろえる（1回だけ） */
  /* 第122版: オルドは 亡くならない（代わりに ハクが 石に なる）。前の 版の 印を 置きかえる */
  if (s.ordoDead) { delete s.ordoDead; s.hakuStone = 1; return true; }
  if (!s.v106 && s.mq !== undefined) {
    s.v106 = 1;
    const past = (re) => { const k = MQ.findIndex((x) => re.test(x.ch || x.hint || "")); return k >= 0 && (s.mq ?? 0) > k; };
    if (!s.nagiDead && past(/第7章/)) s.nagiDead = 1;
    { const k10 = MQ.findIndex((x) => x.seal === 10); if (!s.yomiStone && (s.bs || []).includes(10) && k10 >= 0 && (s.mq ?? 0) > k10) s.yomiStone = 1; }   /* 石に なる 場面を 見た あとだけ */
    if (!s.rouDead && past(/第9章/)) s.rouDead = 1;
    if (past(/第10章/)) { s.hakuStone = 1; s.ch10b = 1; }
    if (!s.kagetsuDead && s.enmaClear) s.kagetsuDead = 1;
    if (s.enmaClear) { s.m4 = s.m4 || 1; s.m5 = Math.max(s.m5 || 0, 5); s.m5b = 1; s.m6 = 1; }
    return true;
  }
  if (s.mq !== undefined) return false;
  const u = openUpTo(d);
  let i = 0;
  if (u > 0) { i = MQ.findIndex((x) => x.r >= u); if (i < 0) i = POST; if (i > 0 && MQ[i].r === u && MQ[i - 1].r === u) i--; }
  s.mq = Math.max(0, i);
  if (u >= 1) { for (const k of ["k_note"]) if (!(s.keys || []).includes(k)) giveKey(p, d, k); }
  if (u >= 2) giveKey(p, d, "k_light");
  if (u >= 6) giveKey(p, d, "k_goggle");
  return true;
}
// v2.9.10: いまの 目標と その 場所（画面の 下と チャットに 出す）
// v2.9.12: カゲツは 終の遺跡を こえるまで 出ない ので、それまでは 遺跡を 案内する
const KAGETU_PRE = "§fネクロスの §6終の遺跡§f を こえよう（遺跡を 8つ こえると 開く）。そのあと ルミナの 闘技場で 伝説の マスターに 挑もう";
function hintOf(st, d) { const h = hintOf0(st, d); const s = qs(d); return s.mqHold && s.mqHold.i === (s.mq ?? 0) && st && st.trig ? `${h} §e（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）` : h; }
function hintOf0(st, d) {
  if (st && st.r === 99 && /カゲツ/.test(st.hint) && !postOpen(d)) return KAGETU_PRE;
  if (st && st.r === 99 && /カップ/.test(st.hint)) {   // v2.9.13: 終章は 進み具合で 書きかえる（カップ → 星冠王 → 石板の 封印 → 石板の王）
    const s = qs(d), n = (s.bs || []).length;
    if (!s.final) return `§fルミナの 闘技場で カップを 勝ちぬき §c星冠王§f に 挑もう §7（カップ ${Math.min(8, s.cup || 0)}/8。ポイントは フィールドの モンスターマスターに 勝って 集める）`;
    if (n < BS_N - 1) return `§fのこりの 石板で 主を 封印しよう §7（封印 ${n}/${BS_N - 1}。ぜんぶ 封じると 王冠の 石板が 目を さます。石板は カップ・遺跡でも 手に入る）`;
    if (!s.bsFinal) return "§c王冠の 石板§f で §c石板の王§f に 挑もう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【特別な石板】）";
  }
  // v2.9.13: マスターに 勝って 石板を もらったら、次は その 石板で 主を 封印（どこでも 使える）
  if (st && typeof st.seal === "number") { const s = qs(d); if ((s.bsg || []).includes(st.seal) && !(s.bs || []).includes(st.seal)) return `§fもらった §d石板§f で ${WREGIONS[st.r].short}の §6主§f を 封印しよう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【特別な石板】）`; }
  return st ? st.hint : "";
}
// v2.9.13: 章ごとの あらすじ（たどりついた 章だけ 見せる）
const SYNOPSIS = {
  "第1章 旅立ち": "ルミナの 長老 オルドの 牧場から、最初の 仲間を もらった（村長が なぜ モンスターを 育てて いるのかは、「昔、ちょっとな」と はぐらかされた）。オルドから、心を 呑む「王」と、王と 十四の 主を 封じた 十五の 石板の 話を 聞いた。石板が 反応する 者として 旅に 出た。ノクス団の ガロが 守って いた 少年 ピコは、町を 襲った 影に 心を 呑まれ、目を 覚まさなく なった。学者 セオは「石板から やさしい ささやきは 聞こえなかったか」と たずねた。",
  "第2章 森の 精霊石": "病んだ シルヴァの 森で、村を 石に されて 行き場を なくした ノクス団の ベリルと 戦った。森の 精霊は 相棒を 見て「二人で 一つの 守り手の 印」と 言い、精霊石の 中で 眠りに ついた。その 日から、相棒の 声が 少しだけ 聞こえる。セオと 森の 主を しずめ、女王エルゼの 試しを 越えた。",
  "第3章 荒野の ライバル": "廃都の 壁画で、王の 隣の 影が 一つ 削られて いるのを 見た。レイと 竜の 空中戦を し、ジンの 弟子たちを 越えた。弟子は「ジン師匠は オルド殿に 一度も 勝てなかった」と 言った。",
  "第4章 炎の 幹部": "燃える 鍛冶場で 人を 助け、爆弾班と 幹部 ヴァルカを 退けた。ヴァルカは 参謀との 取り引き――クロガネの「開かずの 部屋」の 鍵が 目当てだと もらした。",
  "第5章 砂の 王墓": "濡れ衣で 入った 牢で 老人 イザクに 助けられ、イザクは 処刑された。王墓の 碑文「永遠を 願うな。願いは 石に なる」。王墓の 主を レイと 倒し、砂王ラシードは 剣で 詫びた。",
  "第6章 水晶の 洞くつ": "班長に なった ガロたちから 潜水士 マリンを 助けた。ガロは 眠った ままの ピコの ために 戦い、ベリルは 団の 名簿に 名前を 残す ために 戦って いた。曇った 水晶には 石に なった 街が 映って いた。",
  "第7章 海神の 貝笛": "貝笛を 奪った ヴァルカの 炎で、マリンの 姉 ナギサは 両腕を 焼かれ、もう 潜れない 体に なった。マリンは 姉の 跡を 継いで 潜り、貝笛を 取りかえした。「間に 合ったよ」と 言われて、旅の 仲間は 初めて 涙を こぼした。",
  "第8章 学者の 正体": "冥王の 葬列を 守り、セオの メモに 塗りつぶされた「記録の 神」の 文字を 見つけた。荒野の 壁画の 削られた 影と 同じ 形だった。セオは ノクス団の 参謀だった。家族を 石に され、ささやきに 従って 王を 目覚めさせようと して いた。かけらに 呑まれた レイと 戦った。ヨミは「印を 分けあう 二人、離れるな」と 伝えて 石に なった。",
  "第9章 双子の 幹部": "かけらを 捨てた レイと 雪山へ。離ればなれを 恐れる 双子の 幹部と 戦った。ルウの うそを 信じた ロウは 氷の 下に 落ち、仮面の 戦士が ロウを 引き上げて、双子ごと 連れ去った。残された 札には「十の 席の 一つ」。その 夜、オルドから「わしも 行く」と 手紙が 届いた。",
  "第10章 竜骨の 決戦": "ラグナの 祭壇で、セオが 呼び出した 十四の 守り手と 戦った。白い 獅子 ハクに 乗った オルドが 駆けつけ、初めて 戦う 姿を 見せた。王の 影の 槍から レイを かばって、ハクは 石に なった。オルドは「わしの 戦いは ここまで」と、しくじり帳を レイに 渡した。セオは 正気に もどり、ノクス団は 解散した。ガロは 眠った ままの ピコを 連れて ルミナへ 向かった。",
  "第11章 最後の ライバル": "ソラは「闘技場の 奥の 扉の 前に、王者が 立つ」と 言った。天空郷で、竜が 石に なった レイと、竜なしの 最後の 勝負を した。レイは しくじり帳の 最後の 頁に「オレは、ルミナを 守る。」と 書いた。",
  "終章 星冠王": "闘技場の 最後の カップで、仮面の 王者と 戦う。最後の 封印者 星冠王 ゼファードの 試験に 挑み、王冠の 石板に 眠る 古い 王と 向きあう。ゼファードは「オルドに 伝えて くれ」と 言い残して、石の 眠りに ついた。",
};
export function synopsisText(d) {
  const s = qs(d), i = s.mq ?? 0, cur = chapterOf(d), L = ["§l§eこれまでの あらすじ", "§7（たどりついた 章だけ）", ""];
  for (let k = 0; k <= Math.min(i, MQ.length - 1); k++) {
    const ch = MQ[k].ch; if (!ch || !SYNOPSIS[ch] || !(k < i || s.chSeen === k)) continue;
    if (ch === cur && k >= i) { L.push(`§6§l${ch} §a（いま ここ）`, "§7（この 章の お話は これから……）", ""); continue; }   // v2.9.13: まだ 起きて いない ことは 書かない
    L.push(`§6§l${ch}${ch === cur ? " §a（いま ここ）" : ""}`, `§f${SYNOPSIS[ch]}`, "");
  }
  return L.join("\n");
}
export function chapterOf(d) { const s = qs(d), i = s.mq ?? 0; for (let k = Math.min(i, MQ.length - 1); k >= 0; k--) if (MQ[k].ch && (k < i || s.chSeen === k || (k === POST && i === POST))) return MQ[k].ch; return ""; }   // v2.9.13: 始まった 章だけ
// uxprog68: クリア後の 目標（まだ 勝って いない 城の 王 → 近い 順）
function postGoal(p, d) {
  const s = qs(d); if (!s.ending) return null;
  const kw = s.kgw || {}, left = WREGIONS.map((R, i) => i).filter((i) => !kw[i]);
  if (!left.length) {   // 王を みな 倒した あと: 使って いない 神の石板 → カゲツ（40勝まで）
    const dg = s.dg || {}, own = (Array.isArray(s.dgs) ? s.dgs : []).filter((gi) => !dg[gi]);
    if (own.length) return { text: `神の石板で 神を 鎮めよう（まだ 仲間に して いない 神 ${own.length}柱・仲間にした 神 ${Object.keys(dg).length}/15）`, name: "", near: "", x: null, z: null, key: `dg${own.length}` };
    if ((s.kg || 0) < 40) { const t = TOWNS.find((t) => t.id === "t0"), tp = t ? townPos(t) : null; return { text: `カゲツに 勝って 神の石板を（あと ${10 - ((s.kg || 0) % 10)}勝）`, name: "ルミナの 闘技場", near: "§a闘技場の カゲツに 話しかけよう", x: tp ? tp.x : null, z: tp ? tp.z : null, key: `kgx${s.kg || 0}` }; }
    return null;
  }
  let best = null; for (const i of left) { const c = castleInfo(i) || castleSpot(i); if (!c) continue; const dd = Math.hypot(p.location.x - c.x, p.location.z - c.z); if (!best || dd < best.dd) best = { i, c, dd }; }
  if (!best) return null;
  return { text: `城の 王に 勝って 神の石板を（${WREGIONS.length - left.length}/${WREGIONS.length}）`, name: WREGIONS[best.i].castle.name, near: "§a城の 奥の 王に 話しかけよう", x: best.c.x, z: best.c.z, key: `kg${left.length}` };
}
export const GOAL_HOOKS = [];   /* 第76版: 追加ストーリーの 目標（null で ふつうの 目標） */
export function storyTarget(p, d) {
  for (const h of GOAL_HOOKS) { try { const g = h(p, d); if (g) return g; } catch {} }
  const s = qs(d), st = MQ[s.mq ?? 0];
  if (!st || (st.r === 99 && s.enmaClear && /閻魔/.test(st.hint))) return postGoal(p, d);   // uxprog68: 物語の あとは 城の 王・神の石板へ
  const text = String(hintOf(st, d) || "").replace(/§./g, "").replace(/\s+/g, " ").trim();
  const R = Math.max(0, Math.min(WREGIONS.length - 1, st.r ?? 0));
  const me = p.location; let here = -1; try { here = regAt(me); } catch {}
  let pos = null, name = "", near = "";
  try {
    const cv = /洞くつ/.test(text) && CAVE_R.includes(R) ? caveInfo(R) : null;
    if (st.r === 99) {   // v2.9.12: クリア後は 天空郷では なく 本当の 場所へ
      if (/閻魔/.test(text)) { if (s.enmaClear) return null; const a = altarInfo(); if (a) { pos = a; name = "閻魔の神殿"; } }
      else if (/クロガネ/.test(text)) { const M = musashiTownInfo(); if (M) { pos = M.pos; name = M.t.name; } }
      else if (/終の遺跡/.test(text)) { const a = rfInfo(); if (a) { pos = a; name = "終の遺跡"; } else { const c = castleInfo(7) || castleSpot(7); if (c) { pos = c; name = WREGIONS[7].name; } } }
      else if (/星冠王/.test(text)) { const t = TOWNS.find((t) => t.id === "t0"); if (t) { pos = townPos(t); name = "ルミナの 闘技場"; } }
      else if (/カゲツ/.test(text) && postOpen(d)) { const t = TOWNS.find((t) => t.id === "t0"); if (t) { pos = townPos(t); name = "ルミナの 闘技場"; } }
    }
    else if (cv && cv.built) {   // v2.9.12: 洞くつの 中では 奥の 広間を 指す・入口の 近くでは「階段を 下まで」
      const me2 = p.location, inside = me2.y < cv.y - 3 && Math.abs(me2.x - cv.x) < 10 && me2.z > cv.z - 6 && (!cv.hall || me2.z < cv.hall.z + 14);
      if (inside && cv.hall) { pos = cv.hall; name = "洞くつの 奥"; near = "§a奥の 広間へ すすもう"; }
      else { pos = cv; name = `${WREGIONS[R].short}の 洞くつ`; near = "§a入口の 階段を 下まで おりよう"; }
    }
    else if (/洞くつ/.test(text) && CAVE_R.includes(R)) { const c = caveSite(R); pos = { x: c.x, y: 64, z: c.z + 20 }; name = `${WREGIONS[R].short}の 洞くつ`; }   // v2.9.12: まだ できて いない ときも 場所を 指す
    else if (/ステージ|大地/.test(text)) {
      // v2.9.12: 目的地が ぶれない ように いつも 同じ ステージ（できて いる ものを 優先・地方の 中で 決まった 順）
      let best = null; for (const L of landSites(R)) { const I = landInfo(L.key); if (I && I.skip) continue; const sc = I && I.built ? 0 : 1; if (!best || sc < best.sc) best = { ...L, sc, nm: (I && I.name) || "ステージ" }; }
      if (best) { pos = best; name = best.nm; }
    } else if (/もらった/.test(text)) {
      pos = null;   /* 第67版: もらった あとは 城を 指さない（石板は どこでも 使える） */
    } else if (/城|地方マスター|王さま|王様/.test(text)) {
      const c = castleInfo(R) || castleSpot(R); if (c) { pos = c; name = WREGIONS[R].castle.name; }
    } else if (/洞くつ|地下|海|水|歩いて|外を/.test(text) && here === R) {
      pos = null;   // その 地方の 中で する こと（場所は 自由）
    } else if (here !== R && !/町/.test(text)) {
      const c = castleInfo(R) || castleSpot(R); if (c) { pos = c; name = WREGIONS[R].name; }
    } else if (/町/.test(text)) {   // v2.9.12: 町が 目的地なら 地方の 外からでも その 町を 指す（ぶれない）
      let t = TOWNS.find((t) => text.includes(t.name.replace(/の 町|の 村/, "")));
      if (!t) { const c0 = castleInfo(R) || castleSpot(R); let bd = 1e18; for (const u of TOWNS) { const q = townPos(u); if (regAt(q) !== R) continue; const dd = (q.x - c0.x) ** 2 + (q.z - c0.z) ** 2; if (dd < bd) { bd = dd; t = u; } } }   // 城に いちばん 近い 町（いつも 同じ）   // v2.9.12: 名前の ない「町」は いちばん 近い その 地方の 町
      if (t) { pos = townPos(t); name = t.name; }
    }
  } catch {}
  if (s.mqSpot && s.mqSpot.i === (s.mq ?? 0) && !st.key && !st.nospot) { pos = { x: s.mqSpot.x + 0.5, z: s.mqSpot.z + 0.5 }; name = s.mqSpot.np ? s.mqSpot.nm : `${s.mqSpot.nm}の 広場`; }   /* 第108版: 物語の 待ち合わせ 場所へ 案内 */
  return { text, name, near, x: pos ? pos.x : null, z: pos ? pos.z : null, key: `${s.mq ?? 0}` };
}
export function sagaHint(d) {
  const s = qs(d);
  const st = MQ[s.mq ?? 0];
  const L = [];
  { const ch = chapterOf(d); if (ch) L.push(`§d§l${ch}`); }
  if (st && !(st.r === 99 && /閻魔/.test(st.hint) && s.enmaClear)) L.push(`§6【メイン】§r${hintOf(st, d)}`);
  const g = gateHint(d); if (g) L.push(g);
  return L.join("\n");
}

// ---------- だいじなもの を 使う ----------
export async function useKey(p, d, id) {
  if (!d) return;
  const it = ITEMS[id], s = qs(d);
  if ((s.mqPaid ?? -1) === (s.mq ?? 0) && (s.mq ?? 0) < MQ.length - 1) { s.mq = (s.mq ?? 0) + 1; save(p, d); }   // v2.9.12
  const st = MQ[s.mq ?? 0];
  const c = ctx(p, d);
  if (st && st.key === id) {
    if (st.pre) { const m = st.pre(c); if (m) { await notice(p, it.name, m); return; } }
    if (!st.where(c)) { await notice(p, it.name, `${it.desc || ""}\n\n${st.whereMsg}`); return; }
    let done = false;
    EVT.add(p.id);   // v2.9.2: だいじなもの から 始まった できごとの あいだも ほかの できごとを 止める
    MQASK.add(p.id); MQRUN.add(p.id); MQRUN_KEY.add(p.id);
    try { await stageBegin(p, { move: !underwater(p), R: 10 }); done = await st.run(p, d); } catch (e) { if (e === LATER) { laterClean(p); } else console.warn(`[MonsterRPG] saga key: ${e} ${e?.stack || ""}`); } finally { try { stageEnd(p, true); } catch {} spkClean(p); EVT.delete(p.id); MQASK.delete(p.id); MQRUN.delete(p.id); MQRUN_KEY.delete(p.id); SPAWNED.delete(p.id); }
    { const dx = load(p); if (!done && dx && qs(dx).mqPaid === MQ.indexOf(st)) done = true; }
    if (!done) try { p.sendMessage("§7準備が できたら、もう一度 だいじなものを 使おう。§8（右上の 案内が 場所を 教えて くれる）"); } catch {}
    const d2 = load(p); if (d2 && done) { const s2 = qs(d2); if ((s2.mq ?? 0) === MQ.indexOf(st)) { s2.mq = MQ.indexOf(st) + 1; save(p, d2); } }
    return;
  }
  if (id === "k_note") { await notice(p, it.name, ["§a§lセオの 研究メモ", "", sagaHint(d), "", `§7行ける 地方: ${WREGIONS.slice(0, Math.min(WREGIONS.length, openUpTo(d) + 1)).map((R) => R.short).join("・")}`].join("\n")); return; }
  if (id === "k_light" && st && (st.r === 1 || st.r === 5) && /洞くつ/.test(st.hint)) { await notice(p, it.name, "§f懐中電灯は 持っているだけで 光る。\n§e右上の 案内の 洞くつの 入口から、階段を 下まで おりよう。"); return; }   /* v2.9.12 */
  if (id === "k_hilt") {   // v3.0: すすみぐあいで 言うことを かえる（先の 物語を 明かさない）
    const s = qs(d);
    const t = s.enmaClear ? "§f戦いの 中で ムサシに 使うと、鍔の 力を 借りられる。§7（ガイドブック →「魔神の鍔を 使う」）"
      : s.musashiJoin ? "§fムサシと いっしょに §5閻魔の神殿§f へ 行こう。§7（神殿の 前で ガイドブックを 使う）"
      : s.hiltGot ? "§fカゲツの 弟子 §cムサシ§f を たずねよう。§7（はがねの 村 §eクロガネ§7）" : "§f鍔は 何かを 呼んで いる……";
    await notice(p, it.name, `§c赤黒く 光る 鍔。カゲツの 家が 千年 守ってきた ものだ。\n\n${t}`); return;
  }
  await notice(p, it.name, `§6だいじなもの§r\n${it.desc || ""}`);
}

// ---------- 状況 ----------
function ctx(p, d) {
  const s = qs(d), l = p.location, sp = SP();
  let u, dp, tw, sg;
  return {
    p, d, s, r: p.dimension.id === "minecraft:overworld" ? regAt(l) : -1, dist: Math.hypot(l.x - sp.x, l.z - sp.z),
    get town() { return tw === undefined ? (tw = townAt(l, 38) || null) : tw; },
    get stage() { return sg === undefined ? (sg = stageNear(p) || null) : sg; },
    under: () => (u === undefined ? (u = underground(p)) : u),
    cave: (R) => inCave(p, R),
    depth: () => (dp === undefined ? (dp = depthOf(p)) : dp),
  };
}

// ---------- NPCの からみ（ランダム）・ライバル・ステージの 番人 ----------
/* 第113版: レイの ようすは 物語の 進みで かわる（0: ライバル／1: かけらに 呑まれかけ／2: 裏切りの あと／3: 竜が 石に なった あと） */
export const reiPhase = (s) => (s.reiFinal ? 3 : s.theoBetray ? 2 : s.jailDone ? 1 : 0);
const REI_T = [
  { sub: "「……待ってたよ」", ask: "「……来たか。勝負だ。今度こそ、オレが 勝つ」", no: "……そうか。逃げるなよ。次は 受けて もらう",
    hi: ["この 地方で ずっと 竜と 鍛えてた。……見てろ", "選ばれたのが おまえで、オレじゃ ない。その わけを、勝って 確かめる"],
    win: ["……また 負けた。なんで 届かないんだ", "強いな。……でも、次は 負けない"], lose: ["オレの 勝ちだ。……少しは、追いつけたかな", "勝った。……なのに、石板は おまえを 選んだ ままだ"] },
  { sub: "「……見つけた」", ask: "「……よう。かけらの 力、試させて くれよ」§7（レイの 目が、かすかに 赤い）", no: "……ちっ。まあ いい。次は 逃がさない",
    hi: ["見ろよ、力が あふれて 止まらない。……今の オレは、選ばれる 側だ", "じいさんの ことを 考えると、かけらが 熱く なる。……来い"],
    win: ["……くそっ。まだ 足りない。もっとだ、もっと……", "なんでだよ……かけらが あっても 届かない……"], lose: ["ハハ……勝った。かけらが あれば、オレだって……", "見たか。……これが オレの 力だ。……オレの、だよな"] },
  { sub: "「……少し、いいか」", ask: "「……付き合って くれないか。かけらなしの 腕を、取り戻したいんだ」", no: "そうだよな。……今の オレが 頼める 立場じゃ ない",
    hi: ["かけらの ない 竜は、前より 遅い。……それで いい。これが 本当の オレの 力だ", "裏切った オレと、まだ 戦って くれるんだな。……ありがとう"],
    win: ["……やっぱり おまえは 強い。オレも、もう 迷わない", "負けた。でも、かけらの ときより ずっと 気分が いい"], lose: ["勝った……のか。自分の 力で。……そうか", "ごめん、手加減 できなかった。今の オレには、これしか ないから"] },
  { sub: "「よう、また 会ったな！」", ask: "「よう！ 竜は いないけど、こいつらと 鍛えてるんだ。勝負、どうだ？」", no: "そっか、また 今度な。ルミナに 帰る 前に、もう一回 やろうぜ",
    hi: ["竜が 石に なってから、こいつらに 助けられて ばっかりだ。……見てくれよ", "じいちゃんの しくじり帳、新しい 頁が 増えたんだ。今日の 勝負も 書いて おく"],
    win: ["完敗！ ……悔しいけど、楽しかった", "やっぱり おまえは すげえよ。また 頼む"], lose: ["勝った！ ……竜にも 見せたかったな", "へへ、今日は オレの 勝ち。しくじり帳に 書いとく"] },
];
async function rival(p, d, r) {
  const s = qs(d), ph = reiPhase(s), T = REI_T[ph];
  const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
  big(p, "§b§lライバル レイ", `§f${T.sub}`, "raid.horn");
  // v2.9: 勝負は 自分で えらぶ（断っても あとで また 会える）
  if (!(await confirm(p, "ライバル レイ", `§b§lレイ§r\n\n§f${T.ask}`, "勝負する", "また 今度"))) { await say(p, "レイ", [T.no]); rm(e); const d2 = load(p); if (d2) { const s2 = qs(d2); s2.reiT = Date.now(); save(p, d2); } return; }
  await say(p, "レイ", [pick(T.hi)]);
  const lv = Math.min(100, WREGIONS[r].lv[1] + 2);
  const foe = ph === 3 ? team(["animal", "beast", "golem"], lv, 3, 8 + (s.reiW || 0) * 4) : team(["dragon", "animal", "beast"], lv, 3, 8 + (s.reiW || 0) * 4, leadOf("dragon", lv));   /* 竜が 石に なった あとは 竜を 出さない */
  const res = await battle(p, foe, { name: "ライバル レイ", arena: "ライバル", speaker: "レイ", lines: { half: ph === 1 ? "まだだ……かけらが もっと よこせって 言ってる！" : "まだだ！ ここからだ！" } });
  rm(e);
  const d2 = load(p); if (!d2) return;
  const s2 = qs(d2);
  if (res === "win") { s2.reiR = [...new Set([...(s2.reiR || []), r])]; s2.reiW = (s2.reiW || 0) + 1; } else s2.reiT = Date.now();   /* v2.9.13: 負けたら また 会える */
  await say(p, "レイ", [pick(res === "win" ? T.win : T.lose)]);
  reward(p, d2, res === "win" ? 3000 + lv * 120 : 500, res === "win" ? [[pick(["e_silver", "e_red", "e_blue", "SEED2"]), 1]] : []); save(p, d2);
}
/* 第106版: ステージの 番人は 大地の まん中の 柱の 前で「大地の 宝」を 守って いる。近づくと 姿を 見せる。
   勝つと 宝（タマゴ・能力の 種・お金）と 制覇の 印★。全部の ステージを 制覇すると 称号と 特別な ごほうび */
const STAGE_HINT = new Map();
function stageHint(p, st) { const now = Date.now(); if (now - (STAGE_HINT.get(p.id) || 0) < 60000) return; STAGE_HINT.set(p.id, now); try { barNote(p).setActionBar(`§b${st.name || "ステージ"}§f: まん中の 柱の 前で §6番人§f が 大地の 宝を 守って いる`); } catch {} }
async function stageGuard(p, d, st) {
  const lv = Math.max(5, Math.min(100, regionLv(p.location) + 3));
  const fam = Object.keys(WREGIONS[st.r].fams || { beast: 1 });
  const foe = bossOne(fam, lv, Math.floor(lv / 4), 0);
  /* 番人の 姿を 柱の 前に 出す */
  let g = null; try { const I = landInfo(st.key); g = p.dimension.spawnEntity(MON_TYPE, { x: st.x + 0.5, y: (I && I.y ? I.y + 1 : p.location.y), z: st.z + 2.5 }); g.addTag("mrpg_temp"); g.addTag("mrpg_cine"); setLook(g, foe[0].sid); (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(g.id); g.nameTag = "§6ステージの 番人"; try { g.teleport(g.location, { facingLocation: p.location }); } catch {} } catch {}
  try {
    big(p, `§6§l${st.name || "ステージ"}の 番人`, "§f大地の 宝を 守って いる", "mob.ravager.roar");
    const all = (qs(d).sv || []).length, total = WREGIONS.reduce((a, _, i) => a + landSites(i).length, 0);
    if (!(await confirm(p, "ステージの 番人", `§b${st.name || "ステージ"}§r\n\n§f柱の 前で 番人が 大地の 宝を 守って いる。\n\n§e勝つと: §fタマゴ・能力の 種・お金と 制覇の 印\n§7（いま ${all}/${total} の ステージを 制覇。全部 制覇すると 称号と 特別な ごほうび）\n§7断っても、また 柱に 近づけば 挑める`, "挑む", "今は やめておく"))) { const d0 = load(p); if (d0) { const s0 = qs(d0); s0.svT = { ...(s0.svT || {}), [st.key]: Date.now() }; save(p, d0); } return; }
    const TH = { underworld: "soulvalley", void: "endcity", crystal: "dripstone", sea: "beach", ruins: "ruins" };
    const res = await battle(p, foe, { name: "ステージの 番人", arena: st.name || "ステージ", theme: TH[st.theme] || st.theme, hpk: 1.8, extra: 0.2, tag: "番人", speaker: "番人" });
    const d2 = load(p); if (!d2) return;
    const s2 = qs(d2);
    if (res !== "win") { s2.svT = { ...(s2.svT || {}), [st.key]: Date.now() }; save(p, d2); return; }
    s2.sv = [...new Set([...(s2.sv || []), st.key])];
    const n = s2.sv.length, egg = lv >= 60 ? "e_red" : lv >= 30 ? "e_silver" : "e_bronze";
    const items = [[egg, 1], [lv >= 50 ? "SEED3" : "SEED2", 2]];
    const allDone = n >= total && !s2.svAll; if (allDone) { s2.svAll = 1; items.push(["e_rainbow", 1], ["SEED3", 5]); }
    const got = reward(p, d2, 800 + lv * 150, items); save(p, d2);
    await notice(p, "大地の 宝", [`§6${st.name || "ステージ"}§f を 制覇した！ §e（制覇 ${n}/${total}）`, "", ...got.map((x) => "§e" + x), ...(allDone ? ["", "§d§lすべての ステージを 制覇した！ §r§f特別な ごほうびを 受けとった"] : [])].join("\n"));
  } finally { try { if (g) { globalThis.__mqCine?.delete(g.id); if (g.isValid()) g.remove(); } } catch {} }
}
// 町の うわさ（はじめて 着いた ときだけ・ちょっとした できごと）
const RUMOR = [
  ["§e町の 子ども", "ねえねえ、知ってる？ 夜に なると 強い モンスターが 出るんだって！", [["c_herb2", 2]]],
  ["§e宿屋の おかみ", "旅の 人、顔色が 悪いよ。これ 持って いきな。", [["c_herbs", 1]]],
  ["§e行商人", "石板？ さあねえ。でも 石板の 近くでは モンスターが 騒ぐって 話は 聞くよ。", [["g_sp", 1]]],
  ["§e老人", "わしの 若い ころはのう、地方の 主に 挑む 若者で 町が にぎわった ものじゃ。", [["e_bronze", 1]]],
  ["§e漁師", "海の 深い ところは 真っ暗だ。潜るなら ゴーグルが 要るぞ。", [["c_herb2", 1]]],
  ["§e鉱夫", "洞くつの 奥は 何も 見えねえ。灯りなしで 入るのは 無茶だぜ。", [["c_herb2", 1]]],
];
async function townRumor(p, d, t) {
  const s = qs(d);
  s.tv = [...new Set([...(s.tv || []), t.id])]; save(p, d);
  const [who, line, items] = pick(RUMOR);
  await tell(p, t.name, `${who}§r\n\n§f「${line}」`);
  const got = reward(p, d, 0, items); save(p, d);
  if (got.length) try { p.sendMessage(`§a${got.join("・")} を もらった！`); } catch {}
}

// ---------- だいじなもの の 効果（懐中電灯・ゴーグル）----------
const HINT_T = new Map();
function keyFx(p, d) {
  const under = underground(p), uw = underwater(p);
  if (under && !uw) {
    if (hasKey(p, "k_light")) try { p.addEffect("night_vision", 320, { showParticles: false }); } catch {}
    else if (p.location.y < 40 && Date.now() - (HINT_T.get(p.id) || 0) > 40000) { HINT_T.set(p.id, Date.now()); try { barNote(p).setActionBar("§7暗くて よく 見えない……§8（懐中電灯が あれば……）"); } catch {} }
  }
  if (uw) {
    if (hasKey(p, "k_goggle")) { try { p.addEffect("night_vision", 320, { showParticles: false }); p.addEffect("water_breathing", 320, { showParticles: false }); } catch {} }
    else { const dp = depthOf(p); if (dp >= 10) { try { p.addEffect("blindness", 50, { showParticles: false }); } catch {} if (Date.now() - (HINT_T.get(p.id) || 0) > 20000) { HINT_T.set(p.id, Date.now()); try { barNote(p).setActionBar("§3深すぎて 何も 見えない……§8（潜水ゴーグルが あれば……）"); } catch {} } } }
  }
}

// ---------- ループ ----------
const SAFE = new Map(), LAST = new Map(), INREG = new Map(), EVT = new Set();
// v2.9.12: ぬけた 人の 物語の 印は 消す（ほかの 人の 物語や あとかたづけを 止めない）
try { world.afterEvents.playerLeave.subscribe((e) => { const id = e.playerId; for (const x of SPAWNED.get(id) || []) rm(x); EVT.delete(id); MQRUN_KEY.delete(id); MQASK.delete(id); MQRUN.delete(id); SPAWNED.delete(id); SAFE.delete(id); LAST.delete(id); INREG.delete(id); }); } catch {}
let tick = 0;
const DREAM_CD = new Map();
function runEvt(p, fn) {
  if (EVT.has(p.id)) return;
  EVT.add(p.id); busy.add(p.id);
  system.run(async () => { try { await stageBegin(p, { lazy: true, move: false }); await fn(); } catch (e) { console.warn(`[MonsterRPG] saga: ${e} ${e?.stack || ""}`); } finally { try { stageEnd(p, true); } catch {} EVT.delete(p.id); busy.delete(p.id); clearSkip(p); try { for (const e of world.getDimension("overworld").getEntities({ type: "mrpg:npc", tags: ["mrpg_autospk"] })) if (e.getDynamicProperty("mrpg:spkOwner") === p.id) e.remove(); } catch {} } });
}
/* 第106版: 地方の さかいに またがる 城・町・ステージは、持ち主の 地方として あつかう（城の 半分が となりの 地方で 押しもどされて いた） */
function siteReg(l, up) {
  try {
    for (let i = 0; i <= Math.min(up, WREGIONS.length - 1); i++) { const c = castleSpot(i); if (c && Math.abs(l.x - c.x) <= 72 && Math.abs(l.z - c.z) <= 72) return i; }
    for (const t of TOWNS) { if (t.reg === undefined || t.reg > up) continue; const q = townPos(t); if (q && Math.abs(l.x - q.x) <= 70 && Math.abs(l.z - q.z) <= 70) return t.reg; }
    for (let i = 0; i <= Math.min(up, WREGIONS.length - 1); i++) for (const S of landSites(i)) if (Math.abs(l.x - S.x) <= 48 && Math.abs(l.z - S.z) <= 48) return i;
  } catch {}
  return -1;
}
function gateCheck(p, d) {
  const l = p.location, up = openUpTo(d); let r = regAt(l);
  if (r > up) { const o = siteReg(l, up); if (o >= 0) r = o; }
  if (r <= up) {
    let og = true; try { og = p.isOnGround !== false; } catch {}
    if (og) SAFE.set(p.id, { x: l.x, y: l.y, z: l.z });
    else {   // v2.9.6: 乗って いる・飛んで いる ときは 真下の 地面を 記録（遠くへ もどされない ように）
      try { for (let k = 1; k < 48; k++) { const b = p.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y) - k, z: Math.floor(l.z) }); if (b && !b.isAir && !b.isLiquid) { SAFE.set(p.id, { x: l.x, y: Math.floor(l.y) - k + 1.05, z: l.z }); break; } if (b && b.isLiquid) break; } } catch {}
    }
    return true;
  }
  const back = SAFE.get(p.id);
  let mount = null; try { mount = p.getComponent("minecraft:riding")?.entityRidingOn; } catch {}
  const to = back || (() => { const h = homeInfo(), s = SP(); return h && h.built ? { x: h.x, y: h.y + 0.1, z: h.z } : { x: s.x, y: s.y + 0.2, z: s.z }; })();
  try { if (mount) { mount.getComponent("minecraft:rideable")?.ejectRider(p); mount.teleport(to); } } catch {}
  try { p.teleport(to); } catch {}
  try { p.addEffect("slow_falling", 60, { showParticles: false }); } catch {}
  big(p, "§7まだ やるべき ことが あるようだ……", "§f引き返そう", "random.door_close");
  const g = gateHint(d); if (g) try { p.sendMessage(`§7まだ やるべき ことが あるようだ、引き返そう。 ${g}`); } catch {}
  return false;
}
/* ---------- 第108版: 物語は 決まった 場所で 待つ（町の 広場・城の 広場）。着いた とたんに 戦いが 始まらない ---------- */
const DIR8 = ["東", "南東", "南", "南西", "西", "北西", "北", "北東"];
const dirOf = (a, b) => DIR8[Math.round(((Math.atan2(b.z - a.z, b.x - a.x) * 180 / Math.PI) + 360) % 360 / 45) % 8];
/* 第112版: 場面の 場所へ 移る（暗転 → その 場所へ → 引きの 絵で 場所の 名前）。場所が まだ ない ときは その場で 引きの 絵だけ */
function spotOf(id, k) { try { const w = JSON.parse(world.getDynamicProperty(`mrpg:walk:${id}`) || "null"); const q = w && Array.isArray(w.p) && w.p.find((x) => x[0] === k); return q ? { x: w.x + q[1], y: w.y + q[2], z: w.z + q[3] } : null; } catch { return null; } }
function townOfReg(r) { try { for (const t of TOWNS) if (t.reg === r) { const q = getTown(t.id); if (q && q.built) return t.id; } } catch {} return null; }
function castleQ(r) { try { const ci = castleInfo(r); if (ci && ci.built) return { x: Math.floor(ci.x) + 3, y: Math.floor(ci.y) + 5, z: Math.floor(ci.z) - 6 }; } catch {} return null; }
async function sceneAt(p, q, nm) {
  if (!ok(p)) return false;
  if (q && Math.hypot(q.x - p.location.x, q.z - p.location.z) > 20) {
    camFade(p); await wait(10); if (!ok(p)) return false;
    try { p.teleport({ x: q.x + 0.5, y: q.y + 1, z: q.z + 0.5 }, { dimension: world.getDimension("overworld") }); } catch { q = null; }
    if (q) { await wait(14); if (!ok(p)) return false; if (stageOf(p)) await stageMove(p, { x: q.x + 0.5, y: q.y + 1, z: q.z + 0.5 }); else { const g = goodSpot(q.x, q.z, q.y + 6); if (g) try { p.teleport({ x: g.x + 0.5, y: g.y, z: g.z + 0.5 }); } catch {} } }   /* 第123版: 着いた 先でも 開けた 所を 舞台に */
  }
  await establish(p, p.location, nm); return true;
}
const drama = async () => {};   /* 第115版: 山場の カメラ回しは やめた（酔う）*/   /* 山場: 主人公の まわりを ぐるりと */
function garoSpot() { try { const t = TOWNS.find((u) => u.id === "t0"), q = t ? getTown(t.id) : null; if (!q || !q.built) return null; return { key: "garo", x: Math.floor(q.x), y: null, z: Math.floor(q.z) - 52, nm: "ルミナの 北の 門の 外", np: 1 }; } catch { return null; } }   /* 第115版: ガロの 場面は 城へ 向かう 道の 上 */
async function goScene(p, r, nm) { return sceneAt(p, castleQ(r), nm); }
function plazaOf(id) { return spotOf(id, "plaza"); }
function innOf(id) { return spotOf(id, "inn"); }
function mqSpot(p, d, i, st) {
  const s = qs(d);
  if (st.spot) { const q = st.spot(p, d); if (!q) return null; if (s.mqSpot && s.mqSpot.i === i && s.mqSpot.key === q.key) return s.mqSpot; const sp = { i, ...q }; s.mqSpot = sp; save(p, d); return sp; }
  if (s.mqSpot && s.mqSpot.i === i) return s.mqSpot;
  const r = st.r >= 0 && st.r < WREGIONS.length ? st.r : regAt(p.location), L = [];
  /* 第112版: 場面の 場所（at）で 物語を 起こす（城・大地・洞くつの 入口）。町の 広場では ない ときは np（「広場」と 書かない） */
  if (st.at && st.at !== "town") {
    let q = null;
    try {
      if (st.at === "castle") { const ci = castleInfo(r), b = !!(ci && ci.built), c = b ? ci : castleSpot(r); if (c) q = { x: Math.floor(c.x) + 3, y: b ? Math.floor(ci.y) + 5 : null, z: Math.floor(c.z) - 6, nm: WREGIONS[r].castle.name }; }
      else if (/^land\d$/.test(st.at)) { const S0 = landSites(r)[+st.at.slice(4)] || landSites(r)[0]; if (S0) q = { x: S0.x + 24, y: null, z: S0.z, nm: `${WREGIONS[r].short}の 大地` }; }   // 柱（まん中）の 番人と 重ならない ように 少し 外す
      else if (st.at === "cave") { const v = caveInfo(r), b = !!(v && v.built), c = b ? v : caveSite(r); if (c) q = { x: Math.floor(c.x), y: b ? Math.floor(v.y) : null, z: Math.floor(c.z) - 7, nm: `${WREGIONS[r].short}の 洞くつの 入口` }; }
    } catch {}
    if (q) { const sp = { i, ...q, np: 1 }; s.mqSpot = sp; save(p, d); return sp; }
  }
  const wantCastle = /城/.test(String(st.hint || ""));
  try { const ci = castleInfo(r); if (ci && ci.built && st.at !== "town") L.push({ x: Math.floor(ci.x) + 3, y: Math.floor(ci.y) + 5, z: Math.floor(ci.z) - 6, nm: WREGIONS[r].castle.name, c: 1 }); } catch {}
  try { for (const t of TOWNS) { if (t.reg !== r) continue; const q = getTown(t.id); if (q && q.built && q.y) { const pz2 = plazaOf(t.id); L.push(pz2 ? { ...pz2, nm: t.name, c: 0 } : { x: Math.floor(q.x) + 3, y: Math.floor(q.y), z: Math.floor(q.z) - 6, nm: t.name, c: 0 }); } } } catch {}
  if (!L.length) return null;
  const l = p.location, dist = (q) => Math.hypot(q.x - l.x, q.z - l.z) - (wantCastle && q.c ? 400 : 0);
  L.sort((a, b) => dist(a) - dist(b));
  const sp = { i, ...L[0] }; s.mqSpot = sp; save(p, d); return sp;
}
const MARK = new Map();
function mqMarker(p, sp) {
  const l = p.location, far = Math.hypot(sp.x - l.x, sp.z - l.z);
  const now = Date.now(); if (now - (MARK.get(p.id) || 0) > 20000) { MARK.set(p.id, now); try { barNote(p).setActionBar(`§e！ §f${sp.nm}${sp.np ? "" : "の 広場"}で 物語が 待って いる §7（${dirOf(l, sp)}へ ${Math.round(far)}m）`); } catch {} }
  if (far > 64) return;
  if (sp.y === null || sp.y === undefined) { const q = goodSpot(sp.x, sp.z, Math.floor(p.location.y) + 20); if (q) { const d0 = load(p); if (d0) { const s0 = qs(d0); if (s0.mqSpot) { Object.assign(s0.mqSpot, q); save(p, d0); } } Object.assign(sp, q); } if (sp.y === null || sp.y === undefined) return; }
  try {
    const dim = world.getDimension("overworld");
    if (dim.getEntities({ type: "mrpg:npc", tags: ["mrpg_mqspot"], location: { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 }, maxDistance: 6 }).length) return;
    const e = dim.spawnEntity("mrpg:npc", { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 });
    setJob(e, 7); e.addTag("mrpg_npc"); e.addTag("mrpg_mqspot"); e.nameTag = "§e§l！§r §f物語が 待って いる";
  } catch {}
}
/* 第111版: 物語の 場所は 平らで かわいた 地面に（崖・水・木の 上に なって いた）。まわり ±12 から いちばん よい 所を えらぶ */
function goodSpot(x0, z0, y0) {
  const D = world.getDimension("overworld"); let best = null, bv = 1e9;
  const bad = (x, y, z) => { try { const b = D.getBlock({ x, y: y - 1, z }); return !b || b.isLiquid || /water|lava|leaves|log|ice|cactus|fence|magma/.test(b.typeId); } catch { return true; } };
  for (const [dx, dz] of [[0, 0], [4, 0], [-4, 0], [0, 4], [0, -4], [8, 0], [-8, 0], [0, 8], [0, -8], [6, 6], [-6, -6], [6, -6], [-6, 6], [12, 0], [-12, 0], [0, 12], [0, -12]]) {
    const x = Math.floor(x0 + dx), z = Math.floor(z0 + dz), y = groundY(D, x, z, y0); if (typeof y !== "number" || bad(x, y, z)) continue;
    let rough = 0, ok2 = true; for (const [a, c] of [[2, 0], [-2, 0], [0, 2], [0, -2]]) { const yy = groundY(D, x + a, z + c, y + 4); if (typeof yy !== "number" || bad(x + a, yy, z + c)) { ok2 = false; break; } rough += Math.abs(yy - y); }
    if (!ok2) continue; const v = rough * 3 + Math.hypot(dx, dz) * 0.2; if (v < bv) { bv = v; best = { x, y, z }; } if (rough === 0 && dx === 0 && dz === 0) break;
  }
  return best;
}
function mqMarkerClear(sp) { try { for (const e of world.getDimension("overworld").getEntities({ type: "mrpg:npc", tags: ["mrpg_mqspot"], location: { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 }, maxDistance: 8 })) e.remove(); } catch {} }
function step(p) {
  const d = load(p);
  if (!d || !d.party || !d.party.length) return;
  const s = qs(d);
  if (fixMq(p, d)) save(p, d);
  if (!EVT.has(p.id) && inJail(p)) { releaseJail(p); try { clearJail(world.getDimension("overworld"), JAIL(p)); } catch {} try { p.sendMessage("§7牢屋から 出られた。"); } catch {} return; }
  if (exempt(p) || EVT.has(p.id)) return;
  // 関所
  if (!gateCheck(p, d)) return;
  const c = ctx(p, d);
  // 閻魔の神殿（はじめて 近づいたとき 悪夢）
  try { if (!s.enmaDream && !s.enmaJoin && !s.musashiJoin && !s.enmaClear && nearAltar(p, 6) && canFight(d) && !(Date.now() - (DREAM_CD.get(p.id) || 0) < 60000)) { DREAM_CD.set(p.id, Date.now()); runEvt(p, () => dreamFlow(p, fight, homeTp)); return; } } catch {}   // v3.0: すぐ busy・始められない ときは 1分 あける
  // メインクエスト
  const i = s.mq ?? 0, st = MQ[i];
  if (st && s.mqPaid === i && i < MQ.length - 1) { s.mq = i + 1; save(p, d); return; }   // v2.9.12: ごほうびを もらった 段は とちゅうで ぬけても 先へ（2回 もらえない）
  // v2.9.13: 「あとで」・負けた あとは、ガイドブック →「物語の 戦いに 再挑戦」で もう一度
  if (s.mqHold && s.mqHold.i !== i) { delete s.mqHold; save(p, d); }   // v2.9.13: 再挑戦は ガイドブックで えらぶ（えらぶまで 物語は 進まない）
  if (st && st.trig && !s.mqHold && canFight(d)) {
    let go = false; try { go = st.trig(c); } catch {}
    if (!go && !st.key && !st.nospot && s.mqSpot && s.mqSpot.i === i) go = true;   /* 場所が 決まった あとは そこへ 行けば 始まる */
    if (go && !st.key && !st.nospot) {   /* 第108版: 決まった 場所（広場）に 着いて から 始める */
      const sp = mqSpot(p, d, i, st);
      if (sp) { const l = p.location; if (Math.hypot(sp.x + 0.5 - l.x, sp.z + 0.5 - l.z) > (sp.r || 4) || (typeof sp.y === "number" && Math.abs(sp.y - l.y) > 6)) { mqMarker(p, sp); go = false; } else if (typeof sp.y === "number") mqMarkerClear(sp); }
    }
    if (go) {
      runEvt(p, async () => {
        const dd = load(p); if (!dd) return;
        if (st.ch && qs(dd).chSeen !== i) { qs(dd).chSeen = i; save(p, dd); big(p, `§6§l${st.ch}`, "§f物語が 動きだす", "ui.toast.challenge_complete"); await wait(50); }   // v2.9.13: 章の はじまり
        { const sp4 = qs(dd).mqSpot, at = !st.key && !st.nospot && sp4 && sp4.i === i ? { x: sp4.x + 0.5, y: typeof sp4.y === "number" ? sp4.y : p.location.y, z: sp4.z + 0.5 } : null; await stageBegin(p, at ? { anchor: at, move: true } : { move: false }); }   /* 第123版: 場面は 決まった 場所の 開けた 平らな 所で（プレイヤーを 立ち位置へ）*/
        if (!st.key && !st.nospot && qs(dd).estSeen !== i) { qs(dd).estSeen = i; save(p, dd); const sp3 = qs(dd).mqSpot; await establish(p, p.location, st.ch ? null : (sp3 && sp3.i === i ? sp3.nm : null)); }   /* 第112版: 場面の 始めに 引きの 絵 */
        if (qs(dd).introDone && !qs(dd).hero && !(await heroJoin(p))) return;   /* 第115版: 前の 版から 遊んで いる 人にも 旅の 仲間を */
        let done = false, later = false, next = false; MQASK.add(p.id); MQRUN.add(p.id);
        try { done = await st.run(p, dd); if (done === "next") { next = true; done = false; } } catch (e) { if (e === LATER) later = true; else console.warn(`[MonsterRPG] saga mq: ${e} ${e?.stack || ""}`); } finally { MQASK.delete(p.id); MQRUN.delete(p.id); }
        { const dx = load(p); if (!done && !later && dx && qs(dx).mqPaid === i) done = true; }
        if (later) laterClean(p);
        if (next) { SPAWNED.delete(p.id); return; }   /* 第108版: 同じ 段の 次の 場所へ（止めない） */
        if (!done) try { p.sendMessage(`§7準備が できたら ${st.key ? "もう一度 だいじなものを 使おう" : "ガイドブック ＞ ストーリー ＞「物語の 戦いに 再挑戦」を えらぼう"}。§8（右上の 案内が 場所を 教えて くれる）`); } catch {}
        SPAWNED.delete(p.id);
        const d2 = load(p); if (!d2) return; const s2 = qs(d2);
        if ((s2.mq ?? 0) === i) { if (done) { s2.mq = i + 1; delete s2.mqHold; } else { const l = p.location; s2.mqHold = { i, x: Math.floor(l.x), z: Math.floor(l.z) }; } save(p, d2); }   // v2.9.13: 時間では なく 場所で もう一度
      });
      return;
    }
  }
  // 歩いた かず
  const l = p.location, pv = LAST.get(p.id); LAST.set(p.id, { x: l.x, z: l.z });
  const moved = pv ? Math.hypot(l.x - pv.x, l.z - pv.z) : 0;
  if (!canFight(d)) return;
  // ステージの 番人（はじめて 来たとき）
  const sg = c.stage;
  if (sg && !(s.sv || []).includes(sg.key) && (s.mq ?? 0) >= 2) {   /* 第106版: 柱（まん中）の そばに 来たら 番人が 出る。まわりでは 案内だけ */
    if (Math.hypot(p.location.x - sg.x, p.location.z - sg.z) < 7 && Date.now() - ((s.svT || {})[sg.key] || 0) > 30000) { runEvt(p, () => stageGuard(p, d, sg)); return; }
    stageHint(p, sg);
  }
  // 町の うわさ（はじめて 来たとき）
  const tw = c.town;
  if (tw && !(s.tv || []).includes(tw.id) && tw.id !== "t0") { runEvt(p, () => townRumor(p, d, tw)); return; }
  // ライバル（地方ごとに 1回・入って しばらく たってから）
  const ir = INREG.get(p.id); if (!ir || ir.r !== c.r) INREG.set(p.id, { r: c.r, t: Date.now() });
  if (c.r >= 2 && (s.mq ?? 0) > MQ.findIndex((x) => x.hint.includes("ルインズ荒野へ")) && !(s.reiR || []).includes(c.r) && Date.now() - (s.reiT || 0) > 600000 && Date.now() - (INREG.get(p.id)?.t || Date.now()) > 120000 && moved > 2 && Math.random() < 0.15) { runEvt(p, () => rival(p, d, c.r)); return; }
  // v2.9: NPCに からまれる 戦いは なし（うろついている モンスターマスターに 話しかけると 勝負できる）
}
export function initSaga() {
  system.runInterval(() => {
    tick++;
    for (const p of world.getAllPlayers()) {
      try {
        if (tick % 2 === 0) step(p);
        const d = load(p);
        if (d && tick % 2 === 1 && !busy.has(p.id)) keyFx(p, d);
        if (d && tick % 30 === 5 && !busy.has(p.id) && !EVT.has(p.id)) { const back = syncKeys(p, d); if (back.length) { save(p, d); try { p.sendMessage(`§d手元に なかった ものが もどってきた: §f${back.join("・")}`); } catch {} } }
      } catch (e) { console.warn(`[MonsterRPG] saga loop: ${e}`); }
    }
  }, 20);
}
// チート: 関所を なくす／もどす
export function setGateFree(d, v) { const s = qs(d); s.gateFree = !!v; }

// v2.9.8: 物語の とちゅうで ワールドを 閉じた ときに のこった 会話用の 人を 片づける（読みこみ 直後と、ときどき）
system.runInterval(() => {
  for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
    try { for (const e of world.getDimension(id).getEntities({ type: "mrpg:npc", tags: ["mrpg_saga"] })) { if (EVT.size === 0) try { e.remove(); } catch {} } } catch {}
  }
}, 1200);

// v2.9.13: 「あとで」・負けて 止まって いる 物語の 戦い（ガイドブックから 再挑戦を えらぶ）
export function mqHeld(d) { try { const s = qs(d), i = s.mq ?? 0; return !!(s.mqHold && s.mqHold.i === i && MQ[i] && MQ[i].trig); } catch { return false; } }
export function mqRetry(p, d) {
  const s = qs(d); delete s.mqHold; save(p, d);
  const st = MQ[s.mq ?? 0];
  let here = false; try { here = !!(st && st.trig && st.trig(ctx(p, d))); } catch {}
  return here ? "§aもう一度 挑む！ §7（ガイドブックを 閉じると 始まる）" : `§aもう一度 挑む 準備が できた。§f${(() => { try { return hintOf0(st, d); } catch { return ""; } })()} §7（その 場所へ 行くと 始まる）`;
}

// v2.9.13: 「バグを 直す」用: 止まった 物語の できごとの しるしを 外す（呼んだ 人だけ）
export function sagaUnlock(p) {
  let n = 0;
  for (const S of [EVT, MQASK, MQRUN, MQRUN_KEY]) if (S.has(p.id)) { S.delete(p.id); n++; }
  if (SPAWNED.has(p.id)) { laterClean(p); n++; }
  return n;
}

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { HINT_T.delete(playerId); DREAM_CD.delete(playerId); } catch {} }); } catch {}
