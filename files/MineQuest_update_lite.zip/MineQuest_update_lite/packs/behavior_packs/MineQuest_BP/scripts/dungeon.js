// v2.2.3: 石板の 中の 世界（テーマ別の だだっ広い エリア・エンカウント・泉・猛者の 印・階層を 下りて 主を 封印）
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, ITEMS, BOSS_SLAB, DEITY } from "./data.js";
import { load, save, mark } from "./store.js";
import { busy, ok, wait, notice, confirm, choose, sound, giveItem, takeItem, gold, ICON, seedId, barNote, showTitle } from "./ui.js";
import { TYPE, setLook, hooks } from "./field.js";
import { bk } from "./stage.js";
import { fight, maybeEnding } from "./story.js";
import { startBattle } from "./battle.js";
import { calcStats, makeMonster, addMon, canFight } from "./core.js";
import { qs, bossLv, slabBossLv, mobLv, bossPlus, rIdx, RI, CROWN, BS_N, partyPower, endingDone } from "./quest.js";
// v2.5.10: クリア後の 再戦（やりこみ）。手持ちに あわせて 主も 中の 敵も 強い
export const reLv = (d) => Math.min(100, Math.max(90, partyPower(d).lv + 3));
export const rePlus = (d) => Math.min(99, Math.max(60, Math.max(0, ...[...(d.party || []), ...(d.bench || [])].map((m) => m.plus || 0)) + 10));
import { DG_THEMES, themeFor, areaSize, genFloor, ALL_THEMES } from "./dgthemes.js";

// ---- v2.4: クリア後の 石板（覇王・神域・再会）----
export const MEET_RANK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
export const MEET_COST = [1000, 3000, 8000, 20000, 50000, 120000, 300000, 800000, 2000000];
export const MEET_FLOORS = [5, 6, 8, 10, 12, 14, 16, 18, 20];
export const MEET_LV = [10, 10, 10, 10, 10, 10, 10, 10, 10];   // v2.5.5: 再会の石板の モンスターは みんな Lv10
// v2.5.5: その ランクの モンスターを 何体 仲間に したかで 解放（F 50体 … X 5体）
export const MEET_NEED = [50, 40, 30, 25, 20, 15, 10, 8, 5];
export const meetCount = (d, k) => { const R = MEET_RANK[k]; const own = [...new Set(d.own || [])].filter((ix) => SPECIES[ORDER[ix]]?.rank === R).length; return Math.max(own, (d.recR && d.recR[R]) || 0); };
const XS = {
  king: { id: "sx_king", name: "覇王の石板", title: "覇王", enter: "いくつもの 王の 気配が ぶつかりあっている……", floors: 5, rank: "SS",
    pre: ["……また 一人、王座を のぞく 者が 来たか。", "ここは 王たちの 闘技場。冠を かぶる 資格が あるか、その 仲間で 示してみよ。"], win: "見事。……今日の 王座は お前の ものだ。" },
  god: { id: "sx_god", name: "神域の石板", title: "神", enter: "まばゆい 光の 奥から、声なき 声が 響く……", floors: 6, rank: "X",
    pre: ["人の 子よ。石板の 王を 封じた 者よ。", "その 絆が、神の 前でも 折れぬか。……試させて もらう。"], win: "……良い。人と モンスターの 絆、たしかに 見届けた。" },
};
export function SPC(st) {
  if (st.kind === "meet") return { id: "sx_meet", name: `再会の石板（${MEET_RANK[st.mr]}）`, title: "", enter: "なつかしい 気配が あたりに 満ちている……", floors: st.F, pre: [], win: "", rank: MEET_RANK[st.mr] };
  if (st.kind === "king" || st.kind === "god") return XS[st.kind];
  if (st.kind === "deity") { const G = DEITY[st.mr] || DEITY[0]; return { id: G.slab, name: ITEMS[G.slab]?.name || "神の石板", title: G.name, enter: "神の 咆哮が 石板の 奥から 響いてくる……", floors: G.floors, rank: "X",
    pre: ["グ……ルォォォォォ……ッ！！", `（${SPECIES[G.base]?.name || ""}の 面影を 残した 神が、正気を 失って 襲いかかってくる！）`], win: "……ア……ァ……（神の 目に、かすかな 光が もどった）" }; }
  return BOSS_SLAB[st.i];
}

const DKEY = "mrpg:dg", OUT = "mrpg:dgout";
const OW = () => world.getDimension("minecraft:overworld");
const Y0 = 230;
const NOFAM = new Set(["king", "god"]);
const pick = (a, r = Math.random) => a[Math.floor(r() * a.length)];
const run = (dim, c) => { try { dim.runCommand(c); } catch {} };
const SLOT = { S: 1, M: 2, L: 3, G: 4 };

export function getDg(p) { try { const v = p.getDynamicProperty(DKEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
function setDg(p, v) { try { p.setDynamicProperty(DKEY, v ? JSON.stringify(v) : undefined); } catch {} }
export const inDungeon = (p) => { try { return typeof p.getDynamicProperty(DKEY) === "string"; } catch { return false; } };   // 第63版: 中身を 読まずに 判定（軽く）
hooks.noSpawn = inDungeon;

function slotOf(p) { let slots = {}; try { slots = JSON.parse(world.getDynamicProperty("mrpg:dgslots") || "{}"); } catch {} return slots[p.id]; }
function tickName(p) { zoneOf(p); const k = slotOf(p); return `mrpg_dgk${typeof k === "number" ? k : 0}`; }
// v2.9.9: ワールドを 開いた とき、石板の 中に いない 人の 読みこみ範囲を 片づける（前の 版の 名前も）
system.runTimeout(() => {
  try {
    const ow = world.getDimension("minecraft:overworld");
    let slots = {}; try { slots = JSON.parse(world.getDynamicProperty("mrpg:dgslots") || "{}"); } catch {}
    const inside = new Set(); for (const q of world.getAllPlayers()) { try { if (getDg(q)) inside.add(slots[q.id]); } catch {} }
    for (const k of Object.values(slots)) if (!inside.has(k)) try { ow.runCommand(`tickingarea remove mrpg_dgk${k}`); } catch {}
    // 前の 版の 名前（mrpg_dg0〜999）は 1回だけ 少しずつ 消す（石板の 中に いる 人が いない とき）
    if (!world.getDynamicProperty("mrpg:dgtk2") && !inside.size) {
      let i = 0;
      const step = () => { for (let n = 0; n < 50 && i < 1000; n++, i++) try { ow.runCommand(`tickingarea remove mrpg_dg${i}`); } catch {} if (i < 1000) system.runTimeout(step, 2); else try { world.setDynamicProperty("mrpg:dgtk2", true); } catch {} };
      step();
    }
  } catch {}
}, 60);
// プレイヤーごとの 場所（ワールドの はるか 遠く・空の 上）。階ごとに 南北を 入れかえる
function zoneOf(p) {
  let s = { x: 0, z: 0 }; try { const w = world.getDefaultSpawnLocation(); s = { x: w.x, z: w.z }; } catch {}
  // v2.9.8: 人ごとに 空いて いる 場所を わりあてる（マルチで 2人が 同じ 場所に ならない）
  let slots = {}; try { slots = JSON.parse(world.getDynamicProperty("mrpg:dgslots") || "{}"); } catch {}
  let k = slots[p.id];
  if (typeof k !== "number") {
    const used = new Set(Object.values(slots));
    let h = 0; for (const c of String(p.id)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    k = h % 256; for (let n = 0; n < 256 && used.has(k); n++) k = (k + 1) % 256;   // v2.9.9: 全部 うまっても 止まらない
    slots[p.id] = k; try { world.setDynamicProperty("mrpg:dgslots", JSON.stringify(slots)); } catch {}
  }
  return { x: Math.floor(s.x) + 7000 + (k % 16) * 400, z: Math.floor(s.z) - 7000 - Math.floor(k / 16) * 400 };
}
export function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const FX = { forest: "minecraft:spore_blossom_ambient_particle", cherry: "minecraft:cherry_leaves_particle", snow: "minecraft:snowflake_particle", sea: "minecraft:water_wake_particle", desert: "minecraft:basic_smoke_particle",
  volcano: "minecraft:lava_particle", cave: "minecraft:spore_blossom_ambient_particle", crystal: "minecraft:enchanting_table_particle", ruins: "minecraft:basic_smoke_particle", sky: "minecraft:villager_happy",
  swamp: "minecraft:spore_blossom_ambient_particle", mushroom: "minecraft:spore_blossom_ambient_particle", underworld: "minecraft:soul_particle", void: "minecraft:portal_reverse_particle", palace: "minecraft:totem_particle" };

// ---- 主の 間（テーマの ブロックで）----
export function hallCmds(st) {
  const T = DG_THEMES[st.theme] || DG_THEMES.ruins, { x0, y0, z0 } = st;
  const wall = bk(T.wall === "barrier" ? "smooth_quartz" : T.wall), fl = bk(T.fl), ac = bk(T.fl2[0] || T.fl), li = bk(T.light === "lantern_post" || T.light === "end_rod_post" ? "glowstone" : T.light);
  const C = [];
  /* 第89版: 前の 階（最大 80マス）の 階段や 壁が 外に 残らない ように 広く 空ける（2列ずつ: 1回の fill は 32768 以下） */
  for (let z = z0 - 3; z <= z0 + 83; z += 2) C.push(`fill ${x0 - 36} ${y0 - 10} ${z} ${x0 + 83} ${y0 + 22} ${Math.min(z0 + 83, z + 1)} air`);
  C.push(`fill ${x0} ${y0 - 1} ${z0} ${x0 + 40} ${y0 + 8} ${z0 + 40} ${wall}`, `fill ${x0} ${y0 + 9} ${z0} ${x0 + 40} ${y0 + 18} ${z0 + 40} ${wall}`, `fill ${x0 + 1} ${y0 + 1} ${z0 + 1} ${x0 + 39} ${y0 + 17} ${z0 + 39} air`, `fill ${x0 + 1} ${y0} ${z0 + 1} ${x0 + 39} ${y0} ${z0 + 39} ${fl}`);
  C.push(`fill ${x0 + 12} ${y0} ${z0 + 12} ${x0 + 28} ${y0} ${z0 + 28} ${ac}`, `fill ${x0 + 14} ${y0} ${z0 + 14} ${x0 + 26} ${y0} ${z0 + 26} ${fl}`);
  for (const [a, b] of [[5, 5], [35, 5], [5, 35], [35, 35], [5, 20], [35, 20]]) { C.push(`fill ${x0 + a} ${y0 + 1} ${z0 + b} ${x0 + a} ${y0 + 15} ${z0 + b} ${ac}`); C.push(`setblock ${x0 + a} ${y0 + 16} ${z0 + b} ${li}`); }
  for (let a = 4; a <= 36; a += 8) for (let b = 4; b <= 36; b += 8) C.push(`setblock ${x0 + a} ${y0} ${z0 + b} ${li}`);
  return { cmds: C, info: { start: { x: x0 + 20.5, y: y0 + 1, z: z0 + 4.5 }, bx: x0 + 20, bz: z0 + 20, by: y0 + 1, bd: 6, sx: null, sz: null, chests: [], spring: null, elite: null, theme: st.theme } };
}

// ---- エンカウントの 相手 ----
export function encounterFoe(st, r = Math.random, elite = false) {
  if (st.kind === "deity") {   // 第68版: 神の石板の 中は SSランクだけ（王系・神系は 出ない）
    const okD = (s) => { const S = SPECIES[s]; return S && !S.hidden && !S.metalmon && S.sz !== "G" && S.fam !== "king" && S.fam !== "god" && S.rank === "SS"; };
    const pool = ORDER.filter(okD);
    const lv = Math.min(100, (st.reLv || 90) - 2 + st.f + Math.floor(r() * 3) + (elite ? 4 : 0));
    return { sid: pick(pool, r), lv, q: 1, pool: elite ? [] : pool.slice().sort(() => r() - 0.5).slice(0, 12) };
  }
  if (st.kind === "king" || st.kind === "god") {
    const god = st.kind === "god", rk = god ? (r() < 0.5 ? "SS" : "S") : (r() < 0.6 ? "S" : "A");
    const okX = (s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.sz !== "G" && S.fam !== "god" && S.rank === RI[Math.min(7, RI.indexOf(rk) + (elite ? 1 : 0))]; };
    let pool = ORDER.filter((s) => okX(s) && (god || SPECIES[s].fam === "king" || r() < 0.5));
    if (!pool.length) pool = ORDER.filter(okX);
    const lv = Math.min(100, (god ? 88 : 80) + st.f + Math.floor(r() * 5) - 2 + (elite ? 5 : 0));
    return { sid: pick(pool, r), lv, q: elite ? 1 : 0.8, pool: elite ? [] : pool.sort(() => r() - 0.5).slice(0, 12) };
  }
  const b = BOSS_SLAB[st.i], T = DG_THEMES[st.theme] || DG_THEMES.forest;
  const r0 = Math.max(0, Math.min(6, rIdx(b.sid) - 1));
  const rr = Math.max(0, Math.min(7, r0 - (r() < 0.4 ? 1 : 0) + (elite ? 2 : 0)));
  const okS = (s, rank) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.sz !== "G" && !NOFAM.has(S.fam) && S.rank === RI[rank]; };
  let pool = ORDER.filter((s) => okS(s, rr) && T.fams.includes(SPECIES[s].fam));
  if (pool.length < 3) pool = ORDER.filter((s) => okS(s, rr));
  if (!pool.length) pool = ORDER.filter((s) => okS(s, 0));
  const half = Math.floor((st.F - 1) / 2);
  const lv = st.re ? Math.min(100, (st.reLv || 90) - 4 + st.f + Math.floor(r() * 3) + (elite ? 4 : 0)) : Math.max(1, Math.min(100, mobLv(st.i) + (st.f - half) + Math.floor(r() * 5) - 2 + (elite ? 6 : 0)));
  const comp = ORDER.filter((s) => okS(s, Math.max(0, rr - (elite ? 2 : 0))) && T.fams.includes(SPECIES[s].fam)).slice(0, 400);
  return { sid: pick(pool, r), lv, q: st.re ? 1 : Math.min(0.95, 0.25 + st.i * 0.02 + st.f * 0.03 + (elite ? 0.4 : 0)), pool: elite ? [] : (comp.length ? comp : pool).sort(() => r() - 0.5).slice(0, 12) };
}

// ---- 主の チーム ----
// 第65版: クリア後の 再戦では 石板の 主が 王系（Gサイズ）に 変わる。石板ごとに ちがう 王（属性が 近い 子を 先に）
const RE_NO = new Set(["haken", "giren", "kamutoke", "enma", "musashi"]);
export const RE_KING = (() => {
  const pool = ORDER.filter((s) => { const S = SPECIES[s]; return S.fam === "king" && !S.hidden && !RE_NO.has(s) && !S.metalmon; });
  const used = new Set(), out = [];
  for (let i = 0; i < BOSS_SLAB.length; i++) {
    if (BOSS_SLAB[i].sid === "haken") { out.push("haken"); continue; }
    const ge = (SPECIES[BOSS_SLAB[i].sid]?.aff?.ge) || [];
    const free = pool.filter((s) => !used.has(s));
    const best = free.find((s) => (SPECIES[s].aff?.ge || []).some((e) => ge.includes(e))) || free[0] || pool[i % pool.length];
    used.add(best); out.push(best);
  }
  return out;
})();
export function bossTeam(d, i, re = false, king = false) {
  const b = BOSS_SLAB[i], lv = re ? reLv(d) : slabBossLv(i), plus = re ? rePlus(d) : bossPlus(d, b.sid, i);   // v3.0: 地方マスター（主力）より +5 くらい 高く
  if (re && king) return [{ sid: RE_KING[i] || b.sid, lv, q: 1, plus, sz: "G" }];   // 第65版: 迷宮の 再戦は 王系の 主が 1体（Gサイズ）。連戦（ボスラッシュ）は 今まで どおり
  const team = [{ sid: b.sid, lv, q: 1, plus }];
  if (b.sid === "haken") return team;   // v3.0: 石板の 王 ヴァルグレイドは 1体で
  const ne = re ? 3 : i < 1 ? 0 : i < 5 ? 1 : i < 10 ? 2 : 3;
  const r0 = rIdx(b.sid), fam = SPECIES[b.sid].fam;
  let used = SLOT[SPECIES[b.sid].sz] || 2;
  for (let k = 0; k < ne && used < 4; k++) {
    const rr = re ? Math.max(RI.indexOf("S"), Math.min(RI.indexOf("SS"), r0 - (k % 2))) : Math.max(0, r0 - 1 - (k % 2));   // 第63版: 再戦の 配下は S・SS から
    let pool = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && (S.fam === fam || (!NOFAM.has(S.fam) && Math.random() < 0.35)) && used + (SLOT[S.sz] || 2) <= 4; });
    if (fam === "king") pool = pool.concat(ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].fam === "king" && SPECIES[s].rank === "SS" && used + (SLOT[SPECIES[s].sz] || 2) <= 4));
    if (!pool.length) break;
    const s = pick(pool); used += SLOT[SPECIES[s].sz] || 2;
    team.push(re ? { sid: s, lv: Math.max(1, lv - 1), q: 1, plus: Math.floor(plus * 0.9) } : { sid: s, lv: Math.max(1, lv - 3), q: 0.8, plus: Math.floor(plus / 2) });
  }
  return team;
}

export function xTeam(d, kind) {
  const P = partyPower(d), god = kind === "god";
  const plus = Math.min(99, (god ? 40 : 25) + Math.max(0, Math.round((P.rank - 6) * 15)));
  const lead = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && S.fam === (god ? "god" : "king") && (god ? (Math.random() < 0.2 ? S.rank === "X" : S.rank === "SS") : S.rank === "SS"); });
  let a = pick(lead.length ? lead : ORDER.filter((s) => SPECIES[s].fam === (god ? "god" : "king") && !SPECIES[s].hidden));
  // v2.6.3: 覇王の石板では 15%で 覇剣王 ヴァルグレイド（Xランク）が 主に
  if (!god && SPECIES.haken && Math.random() < 0.15) a = "haken";
  const team = [{ sid: a, lv: a === "haken" ? 100 : god ? 100 : 95, q: 1, plus: a === "haken" ? plus + 15 : plus }];
  let used = SLOT[SPECIES[a].sz] || 2;
  for (let k = 0; k < 3 && used < 4; k++) {
    const c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && S.fam === (god ? "god" : "king") && (S.rank === "SS" || S.rank === "S") && used + (SLOT[S.sz] || 2) <= 4 && !team.some((t) => t.sid === s); });
    if (!c.length) break;
    const x = pick(c); used += SLOT[SPECIES[x].sz] || 2;
    team.push({ sid: x, lv: god ? 96 : 90, q: 1, plus: Math.floor(plus * 0.8) });
  }
  return team;
}

// ---- 建てる ----
const loaded = (dim, x, y, z) => { try { return !!dim.getBlock({ x, y, z }); } catch { return false; } };
export function planFloor(st) {
  const r = rng(st.seed + st.f * 7919);
  if (st.kind) {
    st.theme = st.boss ? (st.kind === "god" || st.kind === "deity" ? "palace" : ALL_THEMES[Math.floor(r() * ALL_THEMES.length)]) : ALL_THEMES[Math.floor(r() * ALL_THEMES.length)];
    st.S = st.boss ? 41 : st.kind === "meet" ? 60 : 80;
  } else {
    st.theme = st.boss ? (themeFor(st.i, 0, rng(st.seed)) ) : themeFor(st.i, st.f, r);
    if (st.boss && st.i === CROWN) st.theme = "palace";
    st.S = st.boss ? 41 : areaSize(st.i);
  }
  return st.boss ? hallCmds(st) : genFloor(st, r);
}
async function buildFloor(p, st) {
  const ow = OW();
  const { cmds, info } = planFloor(st);
  const tn = tickName(p);   // v2.9.9: 人ごとに 決まった 名前（ワールドを 閉じても のこりつづけない）
  run(ow, `tickingarea remove ${tn}`);
  const S = Math.max(st.S, 80);   /* 第89版: 前の 階の あとも 片づける ので 広く 読みこむ */
  run(ow, `tickingarea add ${st.x0 - 36} ${st.y0} ${st.z0 - 3} ${st.x0 + S + 3} ${st.y0} ${st.z0 + S + 3} ${tn}`);
  const corners = [[-36, -3], [S + 3, S + 3], [-36, S + 3], [S + 3, -3], [0, 0]];
  for (let t = 0; t < 100 && !corners.every(([dx, dz]) => loaded(ow, st.x0 + dx, st.y0, st.z0 + dz)); t++) await wait(5);
  if (!loaded(ow, st.x0, st.y0, st.z0)) { run(ow, `tickingarea remove ${tn}`); return null; }
  cleanMobs(p, ow, st);
  try { barNote(p).setActionBar(`§d${DG_THEMES[st.theme]?.name || ""} を 形づくっている……`); } catch {}
  for (let k = 0; k < cmds.length; k++) { run(ow, cmds[k]); if (k % 40 === 39) await wait(1); }
  await wait(2);
  st.tn = tn;
  return info;
}
function cleanMobs(p, ow, st) {
  try { for (const e of ow.getEntities({ type: TYPE, tags: ["mrpg_dg"], location: { x: st.x0 + 40, y: st.y0, z: st.z0 + 60 }, maxDistance: 260 })) { if (e.getDynamicProperty("mrpg:dgo") === p.id && !e.hasTag("mrpg_battle")) try { e.remove(); } catch {} } } catch {}
}
function fade(p, slow) { try { p.runCommand(`camera @s fade time ${slow ? "0.6 1.2 0.8" : "0.3 0.6 0.4"} color 0 0 0`); } catch {} }
function originFor(p, f) { const z = zoneOf(p); return { x0: z.x, y0: Y0, z0: z.z + (f % 2) * 170 }; }
function applyInfo(st, info) { Object.assign(st, { sx: info.sx, sz: info.sz, bx: info.bx, bz: info.bz, by: info.by, bd: info.bd, spring: info.spring, elite: info.elite, start: info.start }); }
const ENC = new Map();
function resetEnc(p, grace = 14) { ENC.set(p.id, { last: { x: p.location.x, z: p.location.z }, walked: -grace, need: 22 + Math.floor(Math.random() * 24) }); }

// ---- 入る ----
export async function enterDungeon(p, d, i) {
  const b = BOSS_SLAB[i], s = qs(d);
  if (getDg(p)) { await notice(p, b.name, "§7いまは ほかの 石板の 中に いる。"); return false; }
  const re = s.bs.includes(i) && endingDone(d);
  if (s.bs.includes(i) && !re) { await notice(p, b.name, "§7この 石板は もう 封印した。ひびの 奥は 静かだ。\n§8（物語を 見届けると 再戦できる）"); return false; }
  if (i === CROWN && s.bs.length < CROWN) { await notice(p, b.name, `§6王冠の石板§fは 冷たく 沈黙している……\n§7ほかの 石板を すべて 封印すると 目覚める（${s.bs.length}/${CROWN}）`); return false; }
  if (!canFight(d)) { await notice(p, b.name, "§c戦える 仲間が いない！"); return false; }
  // v2.9.6: 自分で 手に 入れた 石板だけ（ほかの 人から もらった 石板では 先へ 進めない）
  if (!(s.bsg || []).includes(i) && !s.bs.includes(i)) { await notice(p, b.name, "§7この 石板は まだ あなたに 応えない……\n§8（自分で 地方の マスターに 勝って 手に 入れた 石板だけ 使える）"); return false; }
  const P = partyPower(d);
  if (re && !(await confirm(p, b.name, [`§5§l${b.name} §c§l【再戦】`, "§7封印した 主が、ふたたび 力を とりもどしている……", "",
    i === CROWN ? `§f主 §c${b.title}§f（Gサイズ）  §cHP 25000・MP 9999・ほかの 能力 すべて 2000` : `§f主は 王系の §c${SPECIES[RE_KING[i]]?.name || b.title}§f（Gサイズ・1体）  §cHP 15000・MP 5000・ほかの 能力 1200〜（あなたの 手持ちが 強いほど 上がる）`,
    `§f主の Lv §c${reLv(d)}§f・中の モンスター Lv §e${reLv(d) - 4}〜`,
    "§7・主は スカウトできない。勝つと 能力の 実・タマゴ など", "§7・何度でも 挑める（石板は なくならない）", "", "§d挑みますか？"].join("\n"), "挑む", "やめる"))) return false;
  if (!re && !(await confirm(p, b.name, [`§5§l${b.name}`, `§7${b.enter}`, "", `§f階層 §e${b.floors}§f（最後の 階に 主 §c${b.title}§f）  広さ §e${areaSize(i)}×${areaSize(i)}`, `§f主の ランク §c${b.rank}§f  Lv §c${slabBossLv(i)}§f  ／ 中の モンスター Lv §e${mobLv(i)}§7 前後（あなたの 主力 Lv${P.lv}）`,
    "§7・歩いていると モンスターに 出会う（エンカウント）。中の モンスターは スカウトできる", "§7・§b青い 泉§7で 回復、§6金の 印§7には 強敵と ごほうび", "§7・主は スカウトできない。全滅すると 外へ（石板は のこる）", "§7・ガイドブックで いつでも 脱出", "", "§d触れますか？"].join("\n"), "触れる", "やめる"))) return false;
  try { showTitle(p, "§5……", { subtitle: `§d${b.enter}`, fadeInDuration: 5, stayDuration: 30, fadeOutDuration: 10 }); } catch {}
  sound(p, "mob.endermen.portal", 0.6); sound(p, "ambient.cave", 1);
  fade(p, true);
  await wait(14);
  const st = { i, f: 0, F: b.floors, ...originFor(p, 0), seed: (Date.now() ^ (i * 2654435761)) >>> 0, t0: Date.now(), ret: { x: p.location.x, y: p.location.y, z: p.location.z, dim: p.dimension.id }, ...(re ? { re: true, reLv: reLv(d) } : {}) };
  st.boss = st.F === 1;
  try { barNote(p).setActionBar("§d石板の 内側へ 引きこまれていく……"); } catch {}
  const info = await buildFloor(p, st);
  if (!info) { await notice(p, b.name, "§c石板の 中へ 入れなかった（遠くの 土地を 読みこめなかった）。もう いちど ためしてね。"); return false; }
  applyInfo(st, info);
  setDg(p, st);
  try { p.teleport(info.start, { dimension: OW(), facingLocation: { x: info.start.x + 5, y: info.start.y + 1, z: info.start.z + 5 } }); } catch {}
  run(OW(), `tickingarea remove ${st.tn}`);
  fade(p, false);
  resetEnc(p);
  try { showTitle(p, `§5§l${b.name}`, { subtitle: `§f1F / ${st.F}F  §7${DG_THEMES[st.theme]?.name || ""}`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  p.sendMessage(`§5[${b.name}]§d ${b.enter}\n§7紫に 光る 床（階段）を さがそう。ガイドブックで 脱出できる。`);
  return true;
}

// 覇王・神域・再会（mr = 再会の ランク）
export async function enterExtra(p, d, kind, mr = 0) {
  const st0 = { kind, mr }, b = SPC({ ...st0, F: MEET_FLOORS[mr] });
  if (getDg(p)) { await notice(p, b.name, "§7いまは ほかの 石板の 中に いる。"); return false; }
  if (!canFight(d)) { await notice(p, b.name, "§c戦える 仲間が いない！"); return false; }
  try { showTitle(p, "§5……", { subtitle: `§d${b.enter}`, fadeInDuration: 5, stayDuration: 30, fadeOutDuration: 10 }); } catch {}
  sound(p, "mob.endermen.portal", 0.6); fade(p, true);
  await wait(14);
  const st = { kind, mr, i: kind === "meet" ? 0 : 14, f: 0, F: kind === "meet" ? MEET_FLOORS[mr] : b.floors, reLv: kind === "deity" ? reLv(d) : undefined, ...originFor(p, 0), seed: (Date.now() ^ (mr * 7919 + 13)) >>> 0, t0: Date.now(), ret: { x: p.location.x, y: p.location.y, z: p.location.z, dim: p.dimension.id } };
  st.boss = false;
  const info = await buildFloor(p, st);
  if (!info) { await notice(p, b.name, "§c石板の 中へ 入れなかった。もう いちど ためしてね。"); return false; }
  applyInfo(st, info);
  setDg(p, st);
  try { p.teleport(info.start, { dimension: OW(), facingLocation: { x: info.start.x + 5, y: info.start.y + 1, z: info.start.z + 5 } }); } catch {}
  run(OW(), `tickingarea remove ${st.tn}`);
  fade(p, false); resetEnc(p);
  if (kind === "meet") spawnMeet(p, st, info, d);
  try { showTitle(p, `§5§l${b.name}`, { subtitle: `§f1F / ${st.F}F  §7${DG_THEMES[st.theme]?.name || ""}`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  p.sendMessage(`§5[${b.name}]§d ${b.enter}\n§7紫に 光る 床（階段）を さがそう。ガイドブックで 脱出できる。`);
  return true;
}
// 再会: これまで 仲間に した その ランクの モンスターが あたりを うろつく
export function meetPool(d, mr) { const R = MEET_RANK[mr]; return [...new Set(d.own || [])].map((ix) => ORDER[ix]).filter((s) => s && SPECIES[s] && !SPECIES[s].hidden && s !== "musashi" && s !== "enma" && SPECIES[s].rank === R); }
function spawnMeet(p, st, info, d) {
  const pool = meetPool(d, st.mr); if (!pool.length) return;
  const r = rng(st.seed + st.f * 31), n = 7 + Math.floor(st.f / 2), ow = OW();
  for (let k = 0; k < n; k++) {
    const sid = pick(pool, r), lv = MEET_LV[st.mr];
    const x = st.x0 + 6 + Math.floor(r() * (st.S - 12)), z = st.z0 + 6 + Math.floor(r() * (st.S - 12));
    if (Math.hypot(x - info.start.x, z - info.start.z) < 10) continue;
    try {
      const e = ow.spawnEntity(TYPE, { x: x + 0.5, y: st.y0 + 1, z: z + 0.5 });
      e.addTag("mrpg_dg"); e.setDynamicProperty("mrpg:sid", sid); e.setDynamicProperty("mrpg:lv", lv); e.setDynamicProperty("mrpg:q", Math.min(0.95, 0.4 + st.mr * 0.06)); e.setDynamicProperty("mrpg:dgo", p.id);
      e.setDynamicProperty("mrpg:pool", JSON.stringify(pool.slice(0, 12)));
      setLook(e, sid); e.nameTag = `§b${SPECIES[sid].name} §7Lv${lv} ${SPECIES[sid].rank}`;
    } catch {}
  }
}

async function nextFloor(p, st) {
  busy.add(p.id);
  try {
    const b = SPC(st);
    // 再会: 最後の 階の 階段で 帰る
    if (st.kind === "meet" && st.f >= st.F - 1) {
      if (st.paid) { await exitDungeon(p, false); busy.delete(p.id); return; } st.paid = true; setDg(p, st);   // v2.9.12: ごほうびは 1回だけ
      const d0 = load(p); if (d0) { const g = Math.floor(MEET_COST[st.mr] * 0.3); d0.gold += g; save(p, d0); const sd = seedId(st.mr >= 7 ? 3 : 2); giveItem(p, `mrpg:${sd}`, 1); p.sendMessage(`§b再会の 旅を 終えた！ §e${gold(g)}§b が もどってきた・§a${ITEMS[sd].name}§b を 見つけた`); }
      sound(p, "ui.toast.challenge_complete", 1);
      await exitDungeon(p, false); busy.delete(p.id); return;
    }
    fade(p, false); sound(p, "mob.endermen.portal", 0.8);
    await wait(8);
    const prev = { ...st };
    st.f++; Object.assign(st, originFor(p, st.f)); st.boss = st.kind !== "meet" && st.f >= st.F - 1; st.springUsed = false; st.eliteDone = false;
    const info = await buildFloor(p, st);
    if (!info) { setDg(p, prev); p.sendMessage("§c先へ 進めなかった。もういちど 階段に 乗ってみて。"); return; }
    applyInfo(st, info);
    setDg(p, st);
    try { p.teleport(info.start, { dimension: OW(), facingLocation: { x: info.start.x + (st.boss ? 0 : 5), y: info.start.y + 1, z: info.start.z + 10 } }); } catch {}
    run(OW(), `tickingarea remove ${st.tn}`);
    resetEnc(p);
    if (st.kind === "meet") { const dm = load(p); if (dm) spawnMeet(p, st, info, dm); }
    try { showTitle(p, st.boss ? `§c§l${b.title}` : `§5${st.f + 1}F §f${DG_THEMES[st.theme]?.name || ""}`, { subtitle: st.boss ? "§7最深部" : `§f${b.name}  ${st.f + 1}F / ${st.F}F`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  } finally { busy.delete(p.id); }
  if (st.boss) system.runTimeout(() => { bossSequence(p).catch((e) => console.warn(`[MonsterRPG] dg boss: ${e} ${e?.stack || ""}`)); }, 40);
}

// ---- エンカウント（歩いた きょりで）----
const ELITE_GIFT = [["i_dream", 1], ["e_rainbow", 1], ["f_exp10k", 1], ["SEED2", 1], ["i_tal1", 1], ["i_awaken", 1], ["SEED3", 1], ["z_tog", 1], ["f_exp30k", 1]];
export async function encounter(p, st, elite = false) {
  // v2.5.8: 「！」から 間を あけずに その場で 戦闘を はじめる（待つと 判定が ずれる）
  if (busy.has(p.id) || !getDg(p)) { resetEnc(p, 6); return null; }
  const f = encounterFoe(st, Math.random, elite);
  const make = () => {
    let e = null;
    try { e = OW().spawnEntity(TYPE, { x: p.location.x, y: p.location.y, z: p.location.z }); } catch { return null; }
    try {
      e.addTag("mrpg_dg"); if (elite) e.addTag("mrpg_rare");
      e.setDynamicProperty("mrpg:sid", f.sid); e.setDynamicProperty("mrpg:lv", f.lv); e.setDynamicProperty("mrpg:q", f.q); e.setDynamicProperty("mrpg:dgo", p.id);
      e.setDynamicProperty("mrpg:pool", JSON.stringify(f.pool));
      setLook(e, f.sid);
      e.nameTag = `${elite ? "§6【猛者】" : "§c"}${SPECIES[f.sid].name} §7Lv${f.lv} ${SPECIES[f.sid].rank}`;
    } catch {}
    return e;
  };
  let e = make();
  if (!e) { resetEnc(p, 10); return null; }
  // 同じ ティックの うちに 戦闘を 登録（busy が すぐ つく）→ その あとで 「！」を 出す
  let pr = startBattle(p, e);
  try { showTitle(p, elite ? "§6§l猛者が 現れた！" : "§c！", { subtitle: elite ? `§f${SPECIES[f.sid].name}` : "", fadeInDuration: 0, stayDuration: 12, fadeOutDuration: 4 }); } catch {}
  sound(p, elite ? "mob.wither.spawn" : "random.anvil_land", elite ? 1.3 : 1.8);
  let res = null;
  try {
    res = await pr;
    if (res === "_invalid") { if (ok(e)) try { e.remove(); } catch {} e = make(); if (e) res = await startBattle(p, e); }
    if (typeof res === "string" && res.startsWith("_")) { console.warn(`[MonsterRPG] encounter: battle not started (${res})`); if (res !== "_noparty" && res !== "_nodata") try { p.sendMessage("§7…モンスターは 逃げていった。"); } catch {} }
  } finally { if (ok(e)) try { e.remove(); } catch {} }
  resetEnc(p, 10);
  if (elite && res === "win") {
    const s2 = getDg(p); if (s2) { s2.eliteDone = true; setDg(p, s2); }
    let [id, n] = ELITE_GIFT[Math.min(ELITE_GIFT.length - 1, Math.floor(Math.random() * (3 + Math.floor((st.kind ? 14 : st.i) / 3))))];
    if (id === "SEED2") id = seedId(2); if (id === "SEED3") id = seedId(3);
    if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); p.sendMessage(`§6§l猛者の 印が 消え、${ITEMS[id].name}が のこされていた！`); sound(p, "random.levelup", 1.2); }
  }
  return res;
}
async function useSpring(p, st) {
  const d = load(p); if (!d) return;
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  save(p, d);
  st.springUsed = true; setDg(p, st);
  sound(p, "random.splash", 1.2); sound(p, "random.levelup", 1.6);
  try { showTitle(p, " ", { subtitle: "§b青い 泉で 仲間が 元気に なった！", fadeInDuration: 0, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
}

async function talk(p, title, lines) { for (const l of lines) await notice(p, title, `§c§l${title}§r\n\n§f「${l}」`); }

export async function bossSequence(p) {
  const st = getDg(p);
  if (!st || !st.boss || busy.has(p.id) || st.fought || FIGHTING.has(p.id)) return;
  if (st.won) {   // v2.9.9: 勝った あと ごほうびの 画面で ぬけた ときは もう 戦わず 外へ（ごほうびは 受けとり済み）
    FIGHTING.add(p.id);
    try { await exitDungeon(p, false); if (!st.kind && !st.re) { const d = load(p); if (d) await maybeEnding(p, d); } } finally { FIGHTING.delete(p.id); }
    return;
  }
  FIGHTING.add(p.id);   // v2.9.8: 戦って いる ことは セーブに 書かない（とちゅうで ぬけても また 主が 出る）
  try { await bossRun(p, st); } finally { FIGHTING.delete(p.id); }
}
const FIGHTING = new Set();
async function bossRun(p, st) {
  const b = SPC(st);
  let d = load(p); if (!d) return;
  const team = st.kind === "deity" ? [{ sid: (DEITY[st.mr] || DEITY[0]).id, lv: 100, q: 1, plus: 99, sz: "G" }] : st.kind ? xTeam(d, st.kind) : bossTeam(d, st.i, !!st.re, !!st.re);
  const reK = !st.kind && st.re && team[0].sid !== b.sid;   // 第65版: 再戦で 王が 出る ときは 王の 名前と 台詞
  const btitle = st.kind === "deity" ? `【神】${b.title}` : st.kind ? `${b.title} ${SPECIES[team[0].sid].name}` : reK ? `石板を 喰らった 王 ${SPECIES[team[0].sid].name}` : b.title;
  const RE_PRE = [`……封印の 奥で、${b.title}の 気配が 王に 喰われた。`, `「石板の 力は いただいた。次は 貴様らの 番だ。」`];
  const bb = reK ? { ...b, pre: RE_PRE, win: "……見事だ。王の 座は、まだ 遠いと 知れ。", half: undefined, low: undefined } : b;
  busy.add(p.id);
  try { sound(p, "mob.enderdragon.growl", 0.7); if (st.kind === "deity") { sound(p, "mob.ravager.roar", 0.6); sound(p, "mob.wither.spawn", 0.8); try { p.runCommand?.("camerashake add @s 0.6 1.5 positional"); } catch {} try { showTitle(p, "§4§lグルォォォォ……ッ！！", { subtitle: `§d${b.title}`, fadeInDuration: 2, stayDuration: 40, fadeOutDuration: 10 }); } catch {} } await talk(p, btitle, bb.pre); } finally { busy.delete(p.id); }
  try { p.teleport({ x: st.bx + 0.5, y: st.by, z: st.bz - st.bd + 0.5 }, { facingLocation: { x: st.bx + 0.5, y: st.by + 1, z: st.bz + st.bd + 0.5 } }); } catch {}
  if (!ok(p)) { busy.delete(p.id); return; }   /* 第69版: 前口上の 途中で 抜けた */
  const res = await fight(p, { team }, { tier: 2, name: btitle, fam: "", npc: null, arena: b.name, deity: st.kind === "deity" ? st.mr : undefined, bslab: st.kind === "deity" ? undefined : st.kind === "god" ? 20 : st.kind === "king" ? 14 : st.re ? 20 : st.i, re: !st.kind && !!st.re, reIdx: st.i, reKings: RE_KING, crownRe: !st.kind && !!st.re && st.i === CROWN, speaker: btitle, lines: bb.half ? { half: bb.half, low: bb.low } : undefined });
  d = load(p); if (!d) return;
  if (res === null || res === undefined) return;
  if (res !== "win") {
    await notice(p, b.name, `§c§l${btitle}§r§f「……まだ 足りない。」\n\n§7石板の 外へ はじき出された。石板は 手元に のこっている。`);
    await exitDungeon(p, true);
    return;
  }
  const mins = Math.max(1, Math.round((Date.now() - (st.t0 || Date.now())) / 60000));
  st.won = true; setDg(p, st);   // ごほうびを わたす 前に 勝ちを 記録（とちゅうで ぬけても 二重に もらえない）
  if (st.kind === "deity") { await deityAfter(p, d, st.mr, btitle, b); await exitDungeon(p, false); return; }
  if (st.kind) { await xReward(p, d, st.kind, btitle, b, team); await exitDungeon(p, false); return; }
  if (st.re) { await reReward(p, d, st.i, btitle, bb, mins); await exitDungeon(p, false); return; }
  await sealSlab(p, d, st.i, mins);
  await exitDungeon(p, false);
  d = load(p); if (d) await maybeEnding(p, d);
}

// 覇王・神域の ごほうび（石板は 使うと なくなる）
// v2.5.9: 覇王・神域の 主は スカウトできない かわりに、倒すと 確率で 仲間に（1回に 1体まで）
export const X_JOIN = { king: [0.15, 0.12], kingX: 0.08, god: [0.1, 0.08], godX: 0.06 };
export function xJoinRoll(kind, team, r = Math.random) {
  for (let i = 0; i < (team || []).length; i++) {
    const t = team[i], S = SPECIES[t.sid]; if (!S) continue;
    const ch = kind === "god" ? (i === 0 ? (S.rank === "X" ? X_JOIN.godX : X_JOIN.god[0]) : X_JOIN.god[1]) : (i === 0 ? (S.rank === "X" ? X_JOIN.kingX : X_JOIN.king[0]) : X_JOIN.king[1]);
    if (r() < ch) return { t, ch };
  }
  return null;
}
async function xReward(p, d, kind, btitle, b, team = []) {
  const god = kind === "god", got = [];
  const give = (id, n = 1) => { if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); } };
  if (!takeItem(p, `mrpg:${b.id}`, 1)) { await notice(p, b.name, "§7石板が 手元に ない……ごほうびは 受けとれなかった。§8（石板を 持ったまま 勝とう）"); return; }   // v2.9.12: 石板を 手ばなして 何度も もらえないように
  const g = god ? 400000 : 200000; d.gold += g; got.push(gold(g));
  give(seedId(4)); if (god) { give(seedId(4)); if (Math.random() < 0.25) give("s_all4"); }
  const J = xJoinRoll(kind, team);
  if (J) {
    const m = makeMonster(J.t.sid, Math.min(100, J.t.lv || 90), true);
    const c = calcStats(m); m.hp = c.hp; m.mp = c.mp;
    addMon(d, m); mark(d.own, J.t.sid); mark(d.seen, J.t.sid);
    got.unshift(`§d§l${SPECIES[J.t.sid].name}が 起きあがり、仲間に なりたそうに こちらを 見ている……仲間に なった！ §r§7（${Math.round(J.ch * 100)}%）`);
    p.sendMessage(`§d§l◆ ${SPECIES[J.t.sid].name}が 仲間に 加わった！`);   // v3.0: ほかの 人には 明かさない
  } else got.unshift(`§7${god ? "神々" : "王たち"}は 光と なって 消えていった……§8（仲間に なる 確率: 主 ${god ? "10%（Xは 6%）" : "15%"}・ほかの 子 ${god ? "8%" : "12%"}）`);
  if (god) { give("i_tal9"); give("i_awaken"); if (Math.random() < 0.12) give("e_god"); if (Math.random() < 0.35) give("e_king"); }
  else { give("f_exp100k"); give("i_awaken"); if (Math.random() < 0.25) give("e_king"); if (Math.random() < 0.03) give("e_god"); }
  const s = qs(d); s[god ? "xgod" : "xking"] = (s[god ? "xgod" : "xking"] || 0) + 1;
  save(p, d);
  sound(p, "ui.toast.challenge_complete", 1);
  for (const q of world.getAllPlayers()) { try { const dq = q.id === p.id ? d : load(q); if (q.id === p.id || (dq && dq.story && dq.story.ending)) q.sendMessage(`§6§l◆ ${p.name}が ${b.name}で ${btitle}に 勝った！`); } catch {} }   /* 第69版: クリア前の 人には 出さない */
  await notice(p, b.name, [`§c§l${btitle}§r§f「${b.win}」`, "", ...got.map((x) => "§e" + x)].join("\n"));
}
// 第68版: 神を 鎮めた あと。何も 落とさない かわりに 低い 確率で 正気に もどって 仲間に（戦った 能力・特性の まま）。仲間に なったら もう 戦えない
export const DEITY_JOIN = (gi) => (gi === 14 ? 0.05 : 0.08);
export const DEITY_LAST = (globalThis.__MQ_DEITY_LAST = globalThis.__MQ_DEITY_LAST || new Map());   // 戦いの 能力（battle.js が 入れる）
async function deityAfter(p, d, gi, btitle, b) {
  const G = DEITY[gi]; if (!G) return;
  const s = qs(d); s.dg = s.dg || {}; s.dgw = s.dgw || {};
  s.dgw[gi] = (s.dgw[gi] || 0) + 1;
  const ch = DEITY_JOIN(gi);
  if (!s.dg[gi] && Math.random() < ch) {
    if (!takeItem(p, `mrpg:${G.slab}`, 1)) { save(p, d); await notice(p, b.name, "§7石板が 手元に ない……§8（石板を 持ったまま 勝とう）"); return; }
    const m = makeMonster(G.id, 100, true);
    m.plus = 99; m.noevo = true;
    try {
      const last = DEITY_LAST.get(p.id); DEITY_LAST.delete(p.id);
      const c = calcStats(m); m.bonus = m.bonus || {};
      if (last && last.gi === gi) for (const k of ["hp", "mp", "atk", "def", "mat", "mdf", "spd", "wpn", "brt"]) { const want = Math.max(0, Math.floor(last.mx[k] || 0)); if (want > (c[k] || 0)) m.bonus[k] = (m.bonus[k] || 0) + (want - c[k]); }
      const c2 = calcStats(m); m.hp = c2.hp; m.mp = c2.mp;
    } catch (e) { console.warn(`[MonsterRPG] deity join: ${e}`); }
    s.dg[gi] = 1;
    const where = addMon(d, m); mark(d.own, G.id); mark(d.seen, G.id);
    save(p, d);
    sound(p, "ui.toast.challenge_complete", 1); sound(p, "beacon.activate", 1);
    for (const q of world.getAllPlayers()) { try { const dq = q.id === p.id ? d : load(q); if (dq && dq.story && dq.story.ending) q.sendMessage(`§6§l◆ ${p.name}が 神の 怒りを 鎮めた！`); } catch {} }   /* 第69版: クリア前の 人には 出さない */
    await notice(p, b.name, [`§d§l${G.name}§r§f「……ここは……。荒ぶる 心に、声が 届いた。」`, "", `§d§l${G.name}が 正気を 取り戻し、仲間に なった！ §r§7（${Math.round(ch * 100)}%）`, `§7${where === "party" ? "パーティ" : "預かり所"}へ 入った（Gサイズは 表の 4枠を ひとりで 使う）。戦った ときの 能力と 特性の まま（HPは 9999まで）。この 神とは もう 戦えない（石板は 光に 溶けた）`].join("\n"));
    return;
  }
  save(p, d);
  sound(p, "beacon.deactivate", 1);
  await notice(p, b.name, [`§c§l${btitle}§r§f「${b.win}」`, "", "§7神は 静まり、光と なって 石板へ 還っていった……", `§8（神の石板の 主は 何も 落とさない。倒すと ${Math.round(ch * 100)}%で 仲間に なる・石板は のこる）`, `§7鎮めた 回数: ${s.dgw[gi]}`].join("\n"));
}
// v2.5.10: 再戦の ごほうび（石板は なくならない）
async function reReward(p, d, i, btitle, b, mins) {
  const got = [];
  const give = (id, n = 1) => { if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); } };
  const g = 50000 + i * 15000; d.gold += g; got.push(gold(g));
  give(seedId(i >= 10 ? 4 : 3)); if (Math.random() < 0.3) give(seedId(4));
  if (Math.random() < 0.15) give("i_trpick"); if (Math.random() < 0.2) give("e_king"); if (Math.random() < 0.04) give("e_god"); if (Math.random() < 0.25) give("i_awaken");
  const s = qs(d); s.reW = s.reW || {}; s.reW[i] = (s.reW[i] || 0) + 1; save(p, d);
  sound(p, "ui.toast.challenge_complete", 1);
  await notice(p, b.name, [`§c§l${btitle}§r§f「${b.win}」`, `§d§l再戦に 勝利！ §r§7（${s.reW[i]}回目・${mins}分）`, "", ...got.map((x) => "§e" + x)].join("\n"));
}
export function sealRewards(i) {
  if (i === CROWN) return { gold: 300000, items: [["e_king", 1], ["e_rainbow", 2], ["f_exp100k", 1], ["i_tal9", 1], ["i_awaken", 1]] };
  const t = Math.floor(i / 3);
  const items = [[["e_silver", 1], ["f_exp1k", 2]], [["e_silver", 2], ["f_exp3k", 2], ["i_tal1", 1]], [["e_rainbow", 1], ["f_exp5k", 2], ["i_tal1", 1]], [["e_rainbow", 1], ["f_exp10k", 2], ["i_awaken", 1]], [["e_rainbow", 2], ["f_exp30k", 1], ["i_awaken", 1], ["i_dream", 1]]][Math.min(4, t)];
  return { gold: 3000 + i * i * 600, items };
}
export async function sealSlab(p, d, i, mins = 0) {
  if (i >= 4) { const sid = seedId(i >= 10 ? 3 : 2); if (ITEMS[sid]) giveItem(p, `mrpg:${sid}`, 1); }
  if (i === CROWN) giveItem(p, "mrpg:s_all3", 1);
  const s = qs(d), b = BOSS_SLAB[i];
  if (!s.bs.includes(i)) s.bs.push(i);
  if (i === CROWN) s.bsFinal = true;
  if (mins) { if (!s.bsT) s.bsT = {}; s.bsT[i] = Math.min(s.bsT[i] || 1e9, mins); }
  // v2.9.12: 封印した 石板は なくさない（バッグの「特別な石板」に のこる。物語を 見届けると 再戦できる）
  const R = sealRewards(i), got = [];
  d.gold += R.gold; got.push(gold(R.gold));
  for (const [id, n] of R.items) if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); }
  save(p, d);
  sound(p, "ui.toast.challenge_complete", 1); sound(p, "beacon.activate", 0.8);
  for (const q of world.getAllPlayers()) q.sendMessage(q.id === p.id ? `§5§l◆ ${b.name}の 主「${b.title}」を 封印した！（${s.bs.length}/${BS_N}）` : `§5§l◆ ${p.name}が 石板を 1枚 封印した！`);   // v3.0: 主の 名前は 本人にだけ
  await notice(p, "封印", [`§c§l${b.title}§r§f「${b.win}」`, "", `§d§l${b.name}を 封印した！ §r§7（${s.bs.length}/${BS_N}${mins ? `・踏破 ${mins}分` : ""}）`, "§7石板は バッグの「特別な石板」に のこる（物語を 見届けると 再戦できる）", "", ...got.map((x) => "§e" + x), ...(s.bs.length === CROWN && !s.bsFinal ? ["", "§6王冠の石板が どこかで 脈を 打ちはじめた……"] : [])].join("\n"));
}

export async function exitDungeon(p, lost) {
  const st = getDg(p);
  if (!st) return;
  fade(p, true);
  await wait(10);
  cleanMobs(p, OW(), st);
  setDg(p, null); ENC.delete(p.id);
  try { OW().runCommand(`tickingarea remove ${tickName(p)}`); } catch {}   // v2.9.12: 読みこみ範囲を のこさない
  try { p.setDynamicProperty(OUT, undefined); } catch {}
  try { p.removeEffect("night_vision"); } catch {}
  try { const o = st.ret; p.teleport({ x: o.x, y: o.y, z: o.z }, { dimension: world.getDimension(o.dim || "minecraft:overworld") }); } catch {}
  if (lost) try { showTitle(p, "§7……", { subtitle: "§7気がつくと 石板の 前に いた", fadeInDuration: 10, stayDuration: 30, fadeOutDuration: 10 }); } catch {}
}

export async function dungeonMenu(p) {
  const st = getDg(p); if (!st) return "open";
  const b = SPC(st);
  const s = await choose(p, b.name, [`§5§l${b.name}§r  §f${st.f + 1}F / ${st.F}F  §7${DG_THEMES[st.theme]?.name || ""}`, `§7${st.boss ? "主の 間" : "紫に 光る 床（階段）を さがそう"}`, `§7泉: ${st.spring ? (st.springUsed ? "使った" : "§bこの 階に ある") : "なし"}§7  猛者の 印: ${st.elite ? (st.eliteDone ? "たおした" : "§6この 階に ある") : "なし"}`].join("\n"), [["§lガイドブックを 開く", ICON("i_zukan")], ["§c石板の 外へ 脱出する\n§7石板は 手元に のこる", ICON("i_run")], ["§7閉じる", ICON("i_back")]]);
  if (s === 0) return "open";
  if (s === 1 && (await confirm(p, "脱出", "§f石板の 外へ 出ますか？\n§7また 触れれば 1Fから やりなおし。", "脱出する", "やめる"))) { await exitDungeon(p, false); }
  return null;
}

const near = (l, q, y0, r) => q && Math.hypot(l.x - q.x - 0.5, l.z - q.z - 0.5) < r && Math.abs(l.y - y0 - 1) < 2;
const hint = (n) => (n > 80 ? "§8とても 遠い" : n > 45 ? "§7遠い" : n > 20 ? "§fすこし 近い" : "§e§lすぐ そこ");
// ---- 見張り（階段・泉・猛者・エンカウント・落下・全滅・ワープで 出た とき）----
let tick = 0;
system.runInterval(() => {
  tick++;
  for (const p of world.getAllPlayers()) {
    if (!inDungeon(p)) continue;   // 第63版: 石板に いない 人は 中身を 読まない
    const st = getDg(p);
    if (!st) continue;
    try {
      if (p.getDynamicProperty(OUT) === true) { if (!busy.has(p.id)) { busy.add(p.id); exitDungeon(p, true).finally(() => busy.delete(p.id)); } continue; }
      if (busy.has(p.id)) { const e = ENC.get(p.id); if (e) e.last = { x: p.location.x, z: p.location.z }; continue; }
      const l = p.location;
      if (p.dimension.id !== "minecraft:overworld" || Math.hypot(l.x - st.x0 - 40, l.z - st.z0 - 40) > 320) { cleanMobs(p, OW(), st); setDg(p, null); ENC.delete(p.id); continue; }
      if (l.y < st.y0 - 4) { try { p.teleport(st.start || { x: st.x0 + 4.5, y: st.y0 + 1, z: st.z0 + 4.5 }); p.sendMessage("§7落ちて しまった……入口に もどされた。"); } catch {} resetEnc(p, 6); continue; }
      if (!st.boss && st.sx !== null && near(l, { x: st.sx, z: st.sz }, st.y0, 1.7)) { nextFloor(p, st).catch((e) => console.warn(`[MonsterRPG] dg: ${e}`)); continue; }
      if (st.spring && !st.springUsed && near(l, st.spring, st.y0, 1.8)) { useSpring(p, st); continue; }
      if (st.elite && !st.eliteDone && !(st.eliteCd > Date.now()) && near(l, st.elite, st.y0, 1.6)) { const s2 = { ...st, eliteDone: true }; setDg(p, s2); encounter(p, st, true).then((res) => { if (res !== "win") { const s3 = getDg(p); if (s3) { s3.eliteDone = false; s3.eliteCd = Date.now() + 15000; setDg(p, s3); } } }).catch((e) => console.warn(`[MonsterRPG] elite: ${e}`)); continue; }
      // エンカウント
      if (!st.boss && st.kind !== "meet") {
        let e = ENC.get(p.id); if (!e) { resetEnc(p); e = ENC.get(p.id); }
        const dd = Math.hypot(l.x - e.last.x, l.z - e.last.z); e.last = { x: l.x, z: l.z };
        if (dd < 8) e.walked += dd;
        const nearSpot = (st.sx !== null && Math.hypot(l.x - st.sx, l.z - st.sz) < 5) || (st.spring && !st.springUsed && Math.hypot(l.x - st.spring.x, l.z - st.spring.z) < 5) || (st.elite && !st.eliteDone && Math.hypot(l.x - st.elite.x, l.z - st.elite.z) < 5);
        if (e.walked >= e.need && d_alive(p) && !nearSpot) { e.walked = -999; encounter(p, st).catch((err) => console.warn(`[MonsterRPG] enc: ${err}`)); continue; }
      }
      if (tick % 3 === 0) {
        const b = SPC(st);
        const sd = st.sx !== null ? Math.hypot(l.x - st.sx, l.z - st.sz) : 0;
        try { barNote(p).setActionBar(`§5${b.name} §f${st.f + 1}F/${st.F}F §7${DG_THEMES[st.theme]?.name || ""}  ${st.boss ? "§c主の 間" : `§7階段の 気配… ${hint(sd)}`}`); } catch {}
        if (!st.boss && sd < 64) for (let y = 1; y <= 9; y += 2) try { p.dimension.spawnParticle("minecraft:portal_reverse_particle", { x: st.sx + 0.5, y: st.y0 + y, z: st.sz + 0.5 }); } catch {}
        if (st.spring && !st.springUsed && Math.hypot(l.x - st.spring.x, l.z - st.spring.z) < 40) try { p.dimension.spawnParticle("minecraft:villager_happy", { x: st.spring.x + 0.5, y: st.y0 + 1.6, z: st.spring.z + 0.5 }); } catch {}
        if (st.elite && !st.eliteDone && Math.hypot(l.x - st.elite.x, l.z - st.elite.z) < 40) try { p.dimension.spawnParticle("minecraft:totem_particle", { x: st.elite.x + 0.5, y: st.y0 + 1.6, z: st.elite.z + 0.5 }); } catch {}
        const fx = FX[st.theme]; if (fx && Math.random() < 0.6) try { p.dimension.spawnParticle(fx, { x: l.x + (Math.random() - 0.5) * 8, y: l.y + 2, z: l.z + (Math.random() - 0.5) * 8 }); } catch {}
      }
      if (tick % 25 === 0) {
        try { p.addEffect("night_vision", 400, { showParticles: false }); } catch {}
        // ふつうの 敵（ゾンビ など）は 石板の 中に 入れない
        try { for (const e of p.dimension.getEntities({ location: l, maxDistance: 64, families: ["monster"] })) { const t = e.typeId || ""; if (!t.startsWith("mrpg:") && t !== "minecraft:player" && Math.abs(e.location.y - st.y0) < 24) try { e.remove(); } catch {} } } catch {}
      }
    } catch {}
  }
}, 8);
function d_alive(p) { return canFight(load(p)); }   /* 第69版: 裏も */
world.afterEvents.playerSpawn.subscribe(({ player }) => {
  system.runTimeout(() => {
    try { const st = getDg(player); if (!st) return; if (st.boss && st.fought && !st.sealed) { st.fought = false; setDg(player, st); } const l = player.location; if (Math.hypot(l.x - st.x0 - 40, l.z - st.z0 - 40) > 320) { setDg(player, null); ENC.delete(player.id); player.setDynamicProperty(OUT, undefined); player.sendMessage("§7石板の 外に はじき出された……（石板は 手元に のこっている）"); } } catch {}
  }, 40);
});
system.runInterval(() => {
  for (const p of world.getAllPlayers()) { const st = getDg(p); if (st && st.boss && !busy.has(p.id) && !st.fought) bossSequence(p).catch(() => {}); }
}, 200);

// ---- 再会の石板の メニュー（ランクを 選ぶ・その ランクの 仲間が 必要・ランクごとの お金）----
export async function meetMenu(p, d) {
  for (;;) {
    const btn = MEET_RANK.map((R, k) => {
      const n = meetPool(d, k).length, c = meetCount(d, k), open = c >= MEET_NEED[k], okG = d.gold >= MEET_COST[k];
      return [`${n && open && okG ? "§l" : "§8"}${R}ランク §e${MEET_COST[k].toLocaleString ? MEET_COST[k].toLocaleString() : MEET_COST[k]}G §7${MEET_FLOORS[k]}階\n§8会える ${n}種 ${open ? "§a解放ずみ" : `§c仲間に した ${R}ランク ${c}/${MEET_NEED[k]}`}`, ICON("i_scout")];
    });
    btn.push(["§7戻る", ICON("i_back")]);
    const k = await choose(p, "再会の石板", ["§b§l再会の石板", "§fこれまで 仲間に した ことの ある モンスターが、石板の 中の 世界を うろついている。", "§7・ランクを 選ぶと、その ランクの モンスターだけに 会える（系統は 問わない）", "§7・その ランクの モンスターを たくさん 仲間に すると 開く（F 50体・E 40・D 30・C 25・B 20・A 15・S 10・SS 8・X 5）", "§7・使う たびに お金が かかる（石板は なくならない）。最後の 階まで 行くと 3割 もどる", "§7・モンスターに さわると バトル。スカウトできる", `§fお金: ${gold(d.gold)}`].join("\n"), btn);
    if (k < 0 || k >= MEET_RANK.length) return;
    const R = MEET_RANK[k], pool = meetPool(d, k);
    if (!pool.length) { await notice(p, "再会の石板", `§7${R}ランクの モンスターを まだ 仲間に した ことが ない。`); continue; }
    if (meetCount(d, k) < MEET_NEED[k]) { await notice(p, "再会の石板", `§c${R}ランクの 世界は まだ 開いていない。\n§f${R}ランクの モンスターを ${MEET_NEED[k]}体 仲間に すると 開く §7（いま ${meetCount(d, k)}体）`); continue; }
    if (d.gold < MEET_COST[k]) { await notice(p, "再会の石板", `§cお金が たりない（${gold(MEET_COST[k])} 必要）`); continue; }
    if (!(await confirm(p, `${R}ランクの 再会`, [`§b${R}ランクの 世界 §f${MEET_FLOORS[k]}階`, `§f会える: §e${pool.slice(0, 12).map((s) => SPECIES[s].name).join("・")}${pool.length > 12 ? ` ほか${pool.length - 12}種` : ""}`, `§f出てくる モンスターは みんな Lv${MEET_LV[k]} ／ お金 ${gold(MEET_COST[k])}`].join("\n"), "触れる", "やめる"))) continue;
    d.gold -= MEET_COST[k]; d.meetPend = MEET_COST[k]; save(p, d);   /* 第89版: 入る 途中で ぬけたら 次に 入った とき 返す */
    let okE = false; try { okE = await enterExtra(p, d, "meet", k); } catch (e) { console.warn(`[MonsterRPG] meet enter: ${e}`); }   // v2.9.12: 失敗したら かならず 返金
    { const d2 = load(p); if (d2) { if (!okE && d2.meetPend) d2.gold += d2.meetPend; delete d2.meetPend; save(p, d2); } }
    return;
  }
}
// 覇王・神域の 石板を 使う
export async function useXSlab(p, d, x) {
  const s = qs(d);
  if (!s.ending) { await notice(p, "石板", "§7石板は 何も こたえない……\n§f物語を 見届けた あとで 目を さますようだ。"); return; }
  if (x === "meet") return meetMenu(p, d);
  const b = XS[x];
  if (!(await confirm(p, b.name, [`§6§l${b.name}`, `§7${b.enter}`, "", `§f${b.floors}階・最後の 階に ${x === "god" ? "§d神々§f（SS・X）" : "§6王たち§f（SS）"}`, `§f中の モンスター: ${x === "god" ? "S〜SS Lv88〜" : "A〜S（王系も） Lv80〜"}`, "§7・勝つと 石板は なくなる（負けたら のこる）", `§7・ごほうび: ${x === "god" ? "神のタマゴ（12%）・王のタマゴ・才覚の金珠・闘魔覚醒" : "王のタマゴ（25%）・経験の玉・闘魔覚醒"}`, "", "§d触れますか？"].join("\n"), "触れる", "やめる"))) return;
  await enterExtra(p, d, x);
}

/* 第89版: 再会の石板に 入る 途中で ぬけた 人に お金を 返す（石板の 中に いない とき） */
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => { if (!initialSpawn) return; system.runTimeout(() => { try { const d = load(p); if (!d || !(d.meetPend > 0)) return; if (getDg(p)) { delete d.meetPend; save(p, d); return; } d.gold += d.meetPend; const n = d.meetPend; delete d.meetPend; save(p, d); p.sendMessage(`§7再会の石板に 入る 前に ぬけたので ${n.toLocaleString()} タヨを 返しました`); } catch {} }, 40); }); } catch {}
