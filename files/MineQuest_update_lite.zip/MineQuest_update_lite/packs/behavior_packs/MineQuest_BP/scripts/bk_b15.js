/* 第126版 本15「ラグナロクの城」（ラグナ・ラグナロク／エンド）— 作業 MD
   1 エンドの朝（しくじり帳に 何も 書けない レイ）→ 2 シズクが 竜の 言葉を 訳す（「まだ 中に おる」・石を 聞き比べる）→ 3 竜の 骨の 橋
   → 4 城（石の 翼の 竜を 磨く ソラ）→ 5 塔（「飛びたい」と 一度 返事を した・翼の 付け根に 紫の 文字）→ 6 ソラとの 戦い（MQ22）
   → 7 城の 上（北の 高みから 声「影は、知る 者に 宿る」）→ 8 見晴らし台（レイ「待ってろ」）→ 9 エンドの 港（石と 墓標を シズクに 託す）
   MQ22: 前の 版は「石板で 主を 封じたら」始まる 段だった。ソラとの 戦い（b15e6）を 段の 話に するため、段の 始まりを 城の 中庭へ 移す（下の MQ[22]）*/
import { bkAdd, mqOver } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facMark } from "./epfac.js";
import { placeOf, bldOf, townOut } from "./storyplace.js";
import { ok } from "./ui.js";
import { MQ } from "./saga.js";
import { qs, giveSlab } from "./quest.js";
import { load, save } from "./store.js";
import { rmTeam } from "./rmaster.js";
import { LOOK, Y, REI, DRAG, HNm, graveSpot, graveQuick, heroStone } from "./bk_b13.js";

const { F, S1 } = FAC_OPS;
/* ---------- セット ---------- */
/* 竜の 骨の 橋: 谷を わたる 骨の 床と 肋骨の 欄干 */
facAdd("bonebridge", { D: [7, 9, 6], box: [-1, -4, 10, 4], H: 4, look: [5, 0, 1], marks: { start: [0, 0, 0], mid: [5, 0, 0], end: [9, 0, 0] }, build: () => [
  F(1, -4, -5, 8, 4, -2, "air"), F(0, -1, -1, 9, 1, -1, "bone_block"),
  F(2, -2, -1, 2, -2, 1, "bone_block"), F(2, 2, -1, 2, 2, 1, "bone_block"), F(5, -2, -1, 5, -2, 2, "bone_block"), F(5, 2, -1, 5, 2, 2, "bone_block"), F(8, -2, -1, 8, -2, 1, "bone_block"), F(8, 2, -1, 8, 2, 1, "bone_block"),
  S1(0, -2, 0, "soul_lantern"), S1(9, 2, 0, "soul_lantern"),
] });
/* 港の 桟橋（村に 港の ない 世界だけ）: 水・板の 桟橋・灯り・舟 */
facAdd("pier", { D: [8, 10, 7], box: [-1, -3, 7, 3], H: 3, look: [4, 0, 0.5], marks: { end: [5, 0, 0], boat: [4, 2, 0] }, build: () => [
  F(1, -3, -2, 7, 3, -1, "water"), F(0, -1, -1, 6, 1, -1, "spruce_planks"), S1(6, -1, 0, "spruce_fence"), S1(6, 1, 0, "spruce_fence"), S1(6, 1, 1, "lantern"), ["e", 4, 2, 0, "boat"],
] });
/* 竜骨の 城の 塔の 根もと: 戸口の あいた 塔・紫の 窓・石の 翼の 竜の 台座 */
facAdd("wingtower", { D: [10, 12, 9], box: [-1, -7, 7, 3], H: 9, look: [3, -2, 2], marks: { door: [1, 0, 0], in: [4, 0, 0], wing: [1, -5, 0], front: [-1, -2, 0], top: [4, 0, 7] }, build: () => [
  F(2, -2, 0, 6, 2, 6, "end_stone_bricks"), F(3, -1, 0, 5, 1, 5, "air"), F(2, 0, 0, 2, 0, 1, "air"), F(2, -2, 6, 6, 2, 6, "purpur_block"),
  S1(2, -2, 7, "purpur_pillar"), S1(2, 2, 7, "purpur_pillar"), S1(6, -2, 7, "purpur_pillar"), S1(6, 2, 7, "purpur_pillar"), S1(4, -2, 3, "purple_stained_glass"), S1(4, 2, 3, "purple_stained_glass"), S1(4, 0, 5, "end_rod"),
  F(0, -6, -1, 2, -4, -1, "purpur_block"), S1(3, -5, 0, "soul_lantern"),
] });

/* ---------- 場所 ---------- */
const COURT = (nm = "竜骨の 城 ラグナロク（塔の 根もと）") => { const q = placeOf("court", 9); return q ? { x: q.x, z: q.z, y: q.y, nm } : null; };
const BRIDGE = () => { const q = placeOf("road", 9); return q ? { x: q.x, z: q.z, nm: "竜の 骨の 橋（ラグナロクへの 道）" } : null; };
const HARBOR = () => bldOf("t27", ["harbor"], "エンドの 港") || (() => { const o = townOut("t27", 0.6, "港"); return o ? { x: o.x, z: o.z, nm: "エンドの 港（桟橋）" } : null; })();
const SORA = (K, p, w = false) => K.cast(p, "sora", w);
const tower = (K, p) => K.fac(p, "r9wing", "wingtower", 9, Y(K, p));
const TM = (K, p, n, a, b) => facMark("r9wing", n) || K.fwd(p, a, b);
const wingDragon = (K, p) => K.monEnt(p, TM(K, p, "wing", 4, -4), DRAG(), "§7石の 翼の 竜");

castAdd("sora", { nm: "ソラ", role: "地方マスター", col: "§6", gobi: "", skin: "sora", town: "t27", from: "r9e5",
  at: () => { const q = placeOf("court", 9); return q ? { x: q.x + 3, y: q.y, z: q.z - 3 } : null; },
  pre: ["{closed}……竜は、まだ 飛ばない。"],
  after: [
    [(s) => !!s.ending, ["{smile}……今朝、竜の 羽が 一枚 だけ 動いた 気が した。", "{closed}名前で 呼んだ。毎朝、三度。……自分の 名前で 返事を する ように。"]],
    [(s) => (s.rm || []).includes(7), ["{closed}……羽の 数は、今日も 同じだった。", "{smile,up}数えるのは、やめない。……あんたも、自分の 足で 立って いろ。"]],
    [() => true, ["{closed}……羽の 数を 数えて いる。じゃまを するな。"]],
  ] });

/* ---------- 1話 エンドの 朝 ---------- */
const E1 = { id: "b15e1", t: "エンドの 朝", place: () => LOOK("エンドの 竜の 見晴らし台（朝）"), fac: "r9look",
  hint: "§fエンドの §e竜の 見晴らし台§f へ §7（夜が 明けた。右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "朝。レイは 石の 竜の 前から 動かなかった。腰の しくじり帳を 開いた まま、何も 書けずに いた。",
  battles: 0,
  async run(p, d, K) {
    const FQ = K.fac(p, "r9look", "lookout", 9, Y(K, p));
    await K.open(p, "エンドの 竜の 見晴らし台（朝）", "day");
    const gq = graveSpot(K, p); graveQuick(K, p, gq);
    const eHs = await heroStone(K, p, { x: gq.x + 1.4, y: gq.y, z: gq.z + 0.8 });
    const dq = { x: gq.x - 3.5, y: gq.y, z: gq.z + 2 }, dr = K.monEnt(p, dq, DRAG(), "§7石の 竜");
    await K.at(p, gq, 16, 6, 1.6);
    await K.narr(p, ["§7朝の 光が、鱗の 墓標と 二つの 石を 照らした。"], gq);
    const eR = await K.put(p, "§bレイ", { x: dq.x + 1.6, y: dq.y, z: dq.z - 1 }, dq, 17); K.act(eR, "kneel"); K.hold(eR, "notebook");
    await K.at(p, ok(eR) ? { x: eR.location.x, y: eR.location.y + 1, z: eR.location.z } : dq, 14, 1.8, 0.2);
    await K.narr(p, ["§7レイは 石の 竜の 前に 座りこんで いた。……ゆうべから、ずっと。", "§7ひざの しくじり帳は 開いた まま。ペンは、一度も 動いて いない。"], eR);
    const g = K.palEnt(p); if (g && ok(eR)) { await K.go(g, { x: eR.location.x + 1, y: eR.location.y, z: eR.location.z + 0.6 }, 12); await K.up(p, g, 8); }
    await K.say(p, "レイ", ["{closed,low}……じいちゃんの しくじりは、全部 書けた。", "{sad}……自分のは、書けねえ。何を 書いたら いいのか、わからねえ。"], g);
    K.rmCine(g);
    await K.ots(p, eR, eHs, 10);
    await K.say(p, "レイ", ["{sad,low}……あいつ なら、なんて 書くんだろうな。"]);
    K.pay(p, E1, 500, []);
    await K.end(p, { bye: [eR, eHs], card: "§7→ シズクが 見晴らし台へ 来る", kind: "day", t: 30 });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 2話 竜の 言葉 ---------- */
const E2 = { id: "b15e2", t: "まだ 中に", place: () => LOOK("エンドの 竜の 見晴らし台"), fac: "r9look",
  hint: "§fエンドの §e竜の 見晴らし台§f §7（右上の 案内）",
  syn: "シズクが 竜の 言葉を 訳した。「この 子は、まだ 中に おると」。相棒が 仲間の 石と レイの 竜の 石を 聞き比べた。仲間の 石は からっぽ、竜の 石は 中に いる 音。",
  battles: 0,
  async run(p, d, K) {
    K.fac(p, "r9look", "lookout", 9, Y(K, p));
    await K.open(p, "エンドの 竜の 見晴らし台", "day");
    const gq = graveSpot(K, p); graveQuick(K, p, gq);
    const eHs = await heroStone(K, p, { x: gq.x + 1.4, y: gq.y, z: gq.z + 0.8 });
    const dq = { x: gq.x - 3.5, y: gq.y, z: gq.z + 2 }, dr = K.monEnt(p, dq, DRAG(), "§7石の 竜");
    const eR = REI(K, p); K.act(eR, "kneel");
    const eS = K.cast(p, "shizuku"); K.act(eS, "hold");
    if (ok(eS)) { await K.walkCam(p, eS, { x: dq.x + 1, y: dq.y, z: dq.z + 1.2 }, 18); K.act(eS, "kneel"); }
    await K.narr(p, ["§7シズクが 石の 竜の 首に 額を 当て、しばらく 目を 閉じて いた。"], eS);
    await K.csay(p, "shizuku", ["{closed,up}……竜骨の 竜が、この 子に 話しかけて おります。", "{smile,tears}……『この 子は、まだ 中に おる』と。"], eR);
    K.act(eR, "up"); await K.up(p, eR, 10);
    await K.say(p, "レイ", ["{shock,…,up}……中に、いる……。"], eS);
    /* 相棒が 聞き比べる */
    const g = K.palEnt(p);
    if (g && dr) { await K.go(g, { x: dq.x + 0.8, y: dq.y, z: dq.z - 0.6 }, 12); K.sound(p, "dig.stone", 0.4); await K.up(p, g, 8); }
    await K.pal(p, ["……こつ、こつ。……ねてる おと。"]);
    if (g && ok(eHs)) { await K.go(g, { x: eHs.location.x + 0.6, y: eHs.location.y, z: eHs.location.z + 0.4 }, 14); K.sound(p, "block.amethyst_block.hit", 0.5); await K.up(p, g, 8); }
    await K.pal(p, ["……こっちは、すんだ おと。……だれも、いない おと。"]);
    K.rmCine(g);
    await K.csay(p, "shizuku", ["{sad,closed}……竜も、同じ ことを 申します。あの方の 石は、からっぽで ございます。", "{closed,up}体は ここに。……でも、あの方は どこかで、まだ 名前を 待って おられる かも しれませぬ。"], eR);
    await K.say(p, "レイ", ["{closed}……ラグナの 地方マスターが、城の 塔で 待ってる。……行くか。", "{sad,up}立って いられるか、見せに。"], eS);
    K.pay(p, E2, 1000, [["c_herbs2", 1]]);
    await K.end(p, { leave: [eR], bye: [eS, eHs], card: "§7→ 竜骨の 城 ラグナロクへ。§e竜の 骨の 橋§7 を わたる（右上の 案内）", kind: "day" });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 3話 竜の 骨の 橋 ---------- */
const E3 = { id: "b15e3", t: "竜の 骨の 橋", place: BRIDGE, fac: "r9bridge",
  hint: "§fラグナの 街道、§e竜の 骨の 橋§f へ §7（竜骨の 城 ラグナロクへの 道。右上の 案内）",
  syn: "ラグナロクへの 道に、竜の 骨で できた 橋が かかって いた。下は 底の 見えない 谷。レイは 橋の まんなかで 一度 だけ 立ち止まり、それから 渡りきった。",
  battles: 0,
  async run(p, d, K) {
    const FB = K.fac(p, "r9bridge", "bonebridge", 9, Y(K, p));
    await K.open(p, "竜の 骨の 橋", "ash");
    const st = facMark("r9bridge", "start") || K.fwd(p, 3), mid = facMark("r9bridge", "mid") || K.fwd(p, 8), en = facMark("r9bridge", "end") || K.fwd(p, 12);
    if (FB) await K.at(p, FB, 16, 8, 1);
    await K.narr(p, ["§7谷を またいで、白い 骨の 橋が かかって いる。肋骨の 欄干の 下は、底の 見えない 闇。"], mid);
    const eR = REI(K, p);
    if (ok(eR)) await K.walkCam(p, eR, st, 14);
    await K.say(p, "レイ", ["{closed}……竜の 骨の 橋。ラグナの 竜は、死んでも 道に なるんだと。"], mid);
    if (ok(eR)) await K.walkCam(p, eR, mid, 18);
    K.act(eR, "hold"); if (ok(eR)) K.turn(eR, { x: mid.x, y: mid.y - 6, z: mid.z + 3 });
    await K.up(p, eR, 10);
    await K.say(p, "レイ", ["{sad,low}……あいつの 竜も、いつか こう なるのか。……いや。", "{angry,up}ならねえ。中に いるって、言ったんだ。"]);
    K.turn(eR);
    if (ok(eR)) await K.walkCam(p, eR, en, 16);
    const g = K.palEnt(p); if (g) { await K.go(g, mid, 14); await K.go(g, en, 14); }
    K.rmCine(g);
    K.pay(p, E3, 1500, [["x_ragna", 1]]);
    await K.end(p, { leave: [eR], card: "§7→ §e竜骨の 城 ラグナロク§7（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 4話 ラグナロクの 城（石の 翼の 竜を 磨く ソラ）---------- */
const E4 = { id: "b15e4", t: "石の 翼", place: () => COURT(), fac: "r9wing",
  hint: "§f§e竜骨の 城 ラグナロク§f の 塔の 根もとへ §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "竜骨の 城 ラグナロク。塔の 根もとで、ソラが 石の 翼の 竜を 磨きながら、羽の 数を 数えて いた。",
  battles: 0,
  async run(p, d, K) {
    const FT = tower(K, p);
    await K.open(p, "竜骨の 城 ラグナロク", "ash");
    if (FT) await K.at(p, FT, 16, 9, 3);
    const dr = wingDragon(K, p), wq = TM(K, p, "wing", 4, -4);
    await K.at(p, wq, 14, 4.5, 1.6);
    await K.narr(p, ["§7塔の 根もとの 台座に、翼を 広げた まま 石に なった 竜。"], wq);
    const eSo = await K.put(p, "sora", { x: wq.x - 1.8, y: wq.y, z: wq.z + 0.6 }, wq); K.act(eSo, "hold"); K.hold(eSo, "brush");
    await K.up(p, eSo, 10);
    await K.csay(p, "sora", ["{closed,low}……三百十二、三百十三……。", "{closed}……三百十四。……今日も、同じだ。"]);
    const eR = REI(K, p); K.act(eR, "hold");
    await K.say(p, "レイ", ["{?,up}……何、数えてんだ。"], eSo);
    await K.csay(p, "sora", ["{closed}羽だ。毎朝 磨いて、数える。……一枚でも 動いたら、わかる ように。"], eR);
    await K.say(p, "レイ", ["{sad,low}……オレの 竜も、祭壇で 石に なった。"], eSo);
    K.act(eSo, 0); K.hold(eSo); K.turn(eSo, eR ? eR.location : null);
    await K.csay(p, "sora", ["{closed}……知って いる。見張り台から 見て いた。", "{closed,up}塔へ 来い。話す ことが ある。"], eR);
    K.pay(p, E4, 1000, []);
    await K.end(p, { leave: [eSo], card: "§7→ 塔の 中へ", kind: "ash", t: 30 });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 5話 城の 塔（「飛びたい」）---------- */
const E5 = { id: "b15e5", t: "一度の 返事", place: () => COURT("竜骨の 城 ラグナロク（塔の 戸口）"), fac: "r9wing",
  hint: "§f§e竜骨の 城 ラグナロク§f の 塔へ §7（右上の 案内）",
  syn: "塔の 戸口で、ソラが 話した。「一度だけ、ささやきに 返事を した。『飛びたい』と」。その 夜、竜の 翼が 石に なった。翼の 付け根にだけ、紫の 文字の 跡が 残って いた。影は、知って 欲しがった 者に 宿る。",
  F: ["F15"], battles: 0,
  async run(p, d, K) {
    tower(K, p);
    await K.open(p, "竜骨の 城 ラグナロク（塔）", "ash");
    const door = TM(K, p, "door", 5, 0), wq = TM(K, p, "wing", 4, -4), dr = wingDragon(K, p);
    const eSo = SORA(K, p); K.act(eSo, "hold");
    if (ok(eSo)) { await K.walkCam(p, eSo, door, 16); K.turn(eSo, wq); }
    await K.csay(p, "sora", ["{closed,low}……あの 竜と、子どもの ころから 空を 飛んで いた。", "{sad}三年前の 夜。竜骨の 方から、ささやきが 聞こえた。『どこまで 飛びたい？』……と。"], dr);
    K.turn(eSo); await K.push(p, eSo, 22, 4, 1.6);
    await K.csay(p, "sora", ["{closed,up}一度だけ、返事を した。『飛びたい』と。", "{sad,low}……次の 朝、翼が 石に なって いた。"]);
    await K.at(p, wq, 14, 2, 1.8);
    K.burst(p.dimension, { x: wq.x, y: wq.y + 1.8, z: wq.z }, "minecraft:portal_reverse_particle", 6, 0.3, 0);
    await K.narr(p, ["§7翼の 付け根。そこだけに、紫の 細い 文字の 跡が 焼きついて いる。"], wq);   /*（決まり二 植）*/
    await K.say(p, "レイ", ["{shock,…,up}……祭壇で セオの 目に 流れこんでた 字と、同じ 色だ。"], eSo);
    await K.csay(p, "sora", ["{closed}……影は、知って 欲しがった 者に 宿る。", "{sad}わたしは、知って ほしかった。この 竜と、どこまで 飛べるかを。……返事を した 分だけ、持って いかれた。"], REI(K, p, true));   /*F15 強: 知って 欲しがった 者 */
    await K.say(p, "レイ", ["{closed,low}……セオは、全部 知りたがってた。……だから、全部 持って いかれたのか。"], eSo);
    K.pay(p, E5, 1000, []);
    await K.end(p, { bye: [eSo], card: "§7― 塔の 戸口 ―", kind: "ash", t: 24 });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 6話 ソラとの 戦い（MQ22）---------- */
const E6 = { id: "b15e6", t: "自分の 名前で",
  hint: "§f§e竜骨の 城 ラグナロク§f の 塔の 前 §7（ラグナの 地方マスター ソラと 戦う）",
  syn: "ソラは 見晴らし台で 言った 試しを 塔の 前で 果たした。「立って いられるか、見せて くれ。泣きながらで いい」。戦いの あと、ソラは 言った。「ささやきには 答えるな。……自分の 名前で、返事を して」。ラグナの 石板を 受け取った。",
  battles: 1,
  async run(p, d, K) {
    tower(K, p);
    await K.open(p, "竜骨の 城 ラグナロク（塔の 前）", "ash");
    const door = TM(K, p, "door", 5, 0), dr = wingDragon(K, p);
    const eSo = SORA(K, p); K.act(eSo, "guard");
    if (ok(eSo)) { await K.walkCam(p, eSo, door, 14); K.turn(eSo); }
    const eRr = REI(K, p);
    await K.push(p, eSo, 22, 4.2, 1.7);
    await K.csay(p, "sora", ["{closed,up}……竜は 教える。墓標に 名を 刻む 者は、自分の 足で 立って いられる 者で なければ ならない、と。", "{angry,up}ラグナの 石板は 渡す。……その 前に、立って いられるか、ここで 見せて くれ。"], eRr);
    await K.say(p, "レイ", ["{angry,tears,up}……まだ、泣いてるかも しれねえぞ。"], eSo);
    await K.csay(p, "sora", ["{closed}泣くのを やめろ とは 言わない。泣きながらで いい。"], eRr);
    const s0 = qs(load(p) || d);
    if (!(s0.rm || []).includes(7) && !K.flag(p, "b15e6a")) {
      K.rmCine(dr);
      await K.duel(p, "§6§l竜骨の 城の 試し", "§f石の 翼を 背に、地方マスター ソラが 立ちはだかる！", { fams: ["dragon"] });
      const r = await K.battle(p, rmTeam(load(p) || d, 7), { name: "ラグナの 地方マスター ソラ", arena: "竜骨の 城", theme: "endcity", speaker: "ソラ", lines: { half: "……まだ 立つか。", low: "……立って いるな。" } });
      if (r !== "win") { await K.csay(p, "sora", ["{closed}……ひざを ついても いい。また 来い。ここで 待つ。", K.RT(p)]); return false; }
      if (!K.replay(p)) { const d3 = load(p); if (d3) { const s3 = qs(d3); s3.rm = s3.rm || []; if (!s3.rm.includes(7)) s3.rm.push(7); s3.rmw = s3.rmw || {}; s3.rmw[7] = (s3.rmw[7] || 0) + 1; d3.gold = (d3.gold || 0) + 61000; save(p, d3); } }
      K.setFlag(p, "b15e6a");
    }
    if (!K.replay(p)) { const d4 = load(p); if (d4) { const b = giveSlab(p, d4, 13); save(p, d4); try { if (b) p.sendMessage(`§d§l${b.name}§r §7を 受け取った（道具から 使うと、ラグナの 主を 封じられる）`); } catch {} } }
    const eSo2 = SORA(K, p, true); K.act(eSo2, "show"); K.hold(eSo2, "tablet");
    await K.up(p, eSo2, 10);
    await K.csay(p, "sora", ["{smile}……立って いた。受け取れ。", "{closed,up}ささやきには 答えるな。……答える なら、自分の 名前で、返事を して。"], eRr);
    await K.say(p, "レイ", ["{closed}……自分の 名前で。", "{smile,tears,up}……覚えとく。"], eSo2);
    K.hold(eSo2); K.act(eSo2, 0);
    K.pay(p, E6, 3000, [["c_revive2", 2]]);
    await K.end(p, { bye: [eSo2], card: "§7→ 石板で §6ラグナの 主§7 を 封じよう（道具から）。北の 道が 開く", kind: "ash", t: 40 });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 7話 城の 上（北の 高みからの 声）---------- */
const E7 = { id: "b15e7", t: "北の 声", place: () => COURT("竜骨の 城 ラグナロク（城壁の 上）"), fac: "r9wing",
  hint: "§f§e竜骨の 城 ラグナロク§f の 塔の 下へ §7（石板で ラグナの 主を 封じたら。右上の 案内）",
  syn: "城の 上から 見上げた 空に、紫の 尾。遠い 北の 高みから、セオの 声が 風に 乗って 届いた。「影は、知る 者に 宿る」。声は、世界じゅうに 流れて いた。",
  battles: 0,
  async run(p, d, K) {
    tower(K, p);
    await K.open(p, "竜骨の 城 ラグナロク（城壁の 上）", "ash");
    const eRr = REI(K, p), S = K.S(p), north = S ? S.at(30, -10, 22) : K.fwd(p, 26, -8, 22);
    K.act(eRr, "up"); if (ok(eRr)) K.turn(eRr, north);
    await K.at(p, north, 18, 14, 0);
    K.burst(p.dimension, north, "minecraft:portal_reverse_particle", 12, 2, 0);
    await K.narr(p, ["§7北の 空。雲の 上に、紫の 尾が 細く 一本 かかって いる。"], north);
    K.sound(p, "mob.wither.ambient", 0.4);
    await K.say(p, "セオの 声", ["{closed,low}……『影は、知る 者に 宿る』……"]);
    await K.ots(p, eRr, north, 10);
    await K.say(p, "レイ", ["{shock,!,up}……セオの 声だ。……風に 乗って、北から……！"]);
    const eSo = SORA(K, p); K.act(eSo, "hold");
    if (ok(eSo) && ok(eRr)) await K.approach(p, eSo, eRr, 2);
    await K.csay(p, "sora", ["{closed}……北の 高みは、セレスティア。風の 塔の 町が ある。", "{sad}……今の 声、たぶん 世界じゅうで 聞こえて いる。"], eRr);
    K.act(eRr, 0);
    K.pay(p, E7, 1000, []);
    await K.end(p, { leave: [eRr], bye: [eSo], card: "§7→ エンドの §e竜の 見晴らし台§7 へ（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 8話 待ってろ ---------- */
const E8 = { id: "b15e8", t: "待ってろ", place: () => LOOK("エンドの 竜の 見晴らし台"), fac: "r9look",
  hint: "§fエンドの §e竜の 見晴らし台§f §7（右上の 案内）",
  syn: "レイは 石の 竜の 首に 手を 置いた。「待ってろ」。それから 立ち上がり、北の 空を 見た。セレスティアへ 行く。",
  battles: 0,
  async run(p, d, K) {
    K.fac(p, "r9look", "lookout", 9, Y(K, p));
    await K.open(p, "エンドの 竜の 見晴らし台", "dusk", "dusk");
    const gq = graveSpot(K, p); graveQuick(K, p, gq);
    const eHs = await heroStone(K, p, { x: gq.x + 1.4, y: gq.y, z: gq.z + 0.8 });
    const dq = { x: gq.x - 3.5, y: gq.y, z: gq.z + 2 }, dr = K.monEnt(p, dq, DRAG(), "§7石の 竜");
    const eRr = REI(K, p);
    if (ok(eRr)) { await K.walkCam(p, eRr, { x: dq.x + 1.3, y: dq.y, z: dq.z - 0.6 }, 16); K.act(eRr, "hold"); }
    await K.at(p, dq, 12, 2.4, 1.4);
    await K.say(p, "レイ", ["{closed,low}……待ってろ。", "{closed}中に いるなら、待ってろ。……オレが 迎えに 来るまで。"], dr);
    K.act(eRr, 0); if (ok(eRr)) K.turn(eRr, K.fwd(p, 30, 0, 18));
    await K.ots(p, eRr, K.fwd(p, 30, 0, 18), 10);
    await K.say(p, "レイ", ["{angry,up}……北だ。セレスティア。セオの 声の 出どころへ 行く。", "{closed}……おまえも 来るだろ。"]);
    const g = K.palEnt(p); if (g) { await K.up(p, g, 10); }
    await K.pal(p, ["……いく。あの子の 手帳も、いっしょに。"]);
    K.rmCine(g);
    K.pay(p, E8, 1000, []);
    await K.end(p, { leave: [eRr], bye: [eHs], card: "§7→ エンドの §e港§7 へ（右上の 案内）", kind: "dusk" });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 9話 エンドの 港 ---------- */
const E9 = { id: "b15e9", t: "千年", place: HARBOR,
  hint: "§fエンドの §e港§f へ §7（右上の 案内）",
  syn: "港で、シズクが 見送りに 来た。仲間の 石と 鱗の 墓標を、シズクに 託した。「竜は その 名を 千年 守ります」。舟は 北へ 出た。",
  F: ["F29"], battles: 0,
  async run(p, d, K) {
    if (!bldOf("t27", ["harbor"])) K.fac(p, "r9pier", "pier", 9, Y(K, p));   /* 村に 港が ない 世界は 桟橋を 建てる */
    await K.open(p, "エンドの 港", "dusk", "dusk");
    const eRr = REI(K, p), eS = K.cast(p, "shizuku"); K.act(eS, "hold"); K.hold(eS, "chochin");
    if (ok(eS) && ok(eRr)) await K.approach(p, eS, eRr, 2);
    await K.up(p, eS, 8);
    await K.csay(p, "shizuku", ["{smile}……見送りに 参りました。", "{closed}あの方の 石と 墓標は、わたくしが お預かり いたします。"], eRr);
    await K.say(p, "レイ", ["{closed}……たのむ。竜の 石も。", "{sad,up}……迎えに 来る。いつか、必ず。"], eS);
    K.act(eS, "raise");
    await K.push(p, eS, 22, 4.2, 1.7);
    await K.csay(p, "shizuku", ["{smile,tears,up}……竜は、その 名を 千年 守ります。", "{closed,up}名を 呼ぶ 方が おられる かぎり、灯りは 消えませぬ。"]);   /*F29 回 */
    K.sound(p, "note.chime", 0.6);
    const S = K.S(p), sea = S ? S.at(16, 4, 2) : K.fwd(p, 14, 4, 2);
    await K.at(p, sea, 16, 10, 1);
    await K.narr(p, ["§7舟が 港を 出た。見晴らし台の 方に、灯りが 一つ ともって いた。"], sea);
    K.act(eS, 0);
    K.pay(p, E9, 2000, [["x_ragna", 2]]);
    await K.end(p, { leave: [eRr], bye: [eS], card: "§f― 第15章 ラグナロクの城 おわり ―\n§7→ 北の §eセレスティア天空郷§7 へ（右上の 案内）", kind: "dusk", t: 60 });
    return true;
  } };

bkAdd("b15", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);

/* MQ22: ソラとの 戦い（b15e6）。段の 始まりを「石板で 封じた とき」から「城の 塔の 根もとに 来た とき」へ（封じるのは この 段の あと。北の 関所が 待つ）*/
{ const st = MQ[22];
  if (st && st.seal === 13) {
    st.trig = (c) => c.r === 9 || (c.s && (c.s.bs || []).includes(13));
    delete st.nospot;
    st.hint = "§fラグナの §e竜骨の 城 ラグナロク§f の 塔の 根もとへ §7（地方マスター ソラが 待って いる。右上の 案内）";
  }
}
mqOver(22, async (p, d, K, c) => c.play("b15e6"), {
  cond: async () => true,
  spot: (p) => { const q = placeOf("court", 9); return q ? { x: q.x, z: q.z, nm: "竜骨の 城 ラグナロク（塔の 根もと）", np: 1, key: "b15e6" } : null; },
});
