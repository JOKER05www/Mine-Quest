// 第106版: 常世編（ルインヘイム）。十の 区を 十魔将が 一人ずつ 治める。石の 人の 記録・魔将の 会話・区が とける 場面・
// エンマの 妹・リリの 姉妹・カメリオの 正体・セイルの 告白・王妃セレネ・邪神が 相棒に 取りつく 最終戦
import { world, system } from "@minecraft/server";
import { load, save } from "./store.js";
import { notice, choose, ICON, sound, showTitle, ok } from "./ui.js";
import { qs } from "./quest.js";
import { exOf } from "./explore.js";
import { SPECIES } from "./data.js";
import { PSKIN } from "./skinjobs.js";
import { setJob } from "./ui.js";
/* 第106版: 場面の 間だけ 人物を 立たせる（抜けても 海辺の 片づけ（mrpg_cine）で 消える） */
const TK_SK = ["argo", "pierina", "doros", "camelio", "glutton", "chrono", "freesia", "boltos", "yoru", "selene"];
const LIVE = (globalThis.__mqCine = globalThis.__mqCine || new Set());
function stand(p, name, key) {
  const S = PSKIN[key]; if (!S) return null;
  try {
    const yaw = (p.getRotation().y * Math.PI) / 180, l = p.location;
    const e = p.dimension.spawnEntity("mrpg:npc", { x: l.x - Math.sin(yaw) * 3.5, y: l.y, z: l.z + Math.cos(yaw) * 3.5 });
    setJob(e, S[0]); e.addTag("mrpg_npc"); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); e.nameTag = name; LIVE.add(e.id);
    try { e.teleport(e.location, { facingLocation: { x: l.x, y: l.y + 1.6, z: l.z } }); } catch {}
    return e;
  } catch { return null; }
}
function gone(...E) { for (const e of E) { if (!e) continue; try { LIVE.delete(e.id); } catch {} try { if (e.isValid()) e.remove(); } catch {} } }

/* 第106版: 物語の 場面の あいだは 魔物が 襲って こない（ruins.js が 見る） */
export const TK_CALM = new Set();
const CALMN = new Map();   /* 第106版: 場面が 続いても 前の 予約で 消さない（人ごとの 数） */
const calm = async (p, fn) => { const id = p.id; CALMN.set(id, (CALMN.get(id) || 0) + 1); TK_CALM.add(id); try { return await fn(); } finally { system.runTimeout(() => { const n = (CALMN.get(id) || 1) - 1; if (n > 0) CALMN.set(id, n); else { CALMN.delete(id); TK_CALM.delete(id); } }, 100); } };
const say = async (p, who, lines, col = "§f") => { for (const l of [].concat(lines)) await notice(p, who, `${col}§l${who}§r\n\n§f「${l}」`); };
const narr = (p, t, L) => notice(p, t, [].concat(L).join("\n"));
const big = (p, a, b, snd) => { try { showTitle(p, a, { subtitle: b || "", fadeInDuration: 6, stayDuration: 50, fadeOutDuration: 12 }); } catch {} if (snd) sound(p, snd, 1); };
const ruOf = (d) => { const s = qs(d); s.ru = s.ru || {}; return s.ru; };

/* 区の 名前（0〜9 魔将・10〜14 番兵） */
export const TK_EPI = ["静寂の区", "歓喜の区", "花壇の区", "千面の区", "暴食の区", "時計の区", "氷葬の区", "雷鳴の区", "遊び場の区", "王宮の区", "東の 石門", "西の 石門", "南の 石門", "北の 石門", "記録塔の 門"];
export const TK_NAME = ["第一魔将 静寂の アルゴ", "第二魔将 歓喜の ピエリナ", "第三魔将 腐花の ドロス", "第四魔将 千面の カメリオ", "第五魔将 暴食の グラトン", "第六魔将 時計仕掛けの クロノ", "第七魔将 氷葬の フリージア", "第八魔将 雷鳴の ボルトス", "第九魔将 影縫いの ヨル", "第十魔将 虚ろの 王妃 セレネ"];
export const tkBossName = (i, monName) => (i < 10 ? `${TK_NAME[i]}（${monName}）` : `区の 番兵「${TK_EPI[i]}」${monName ? "（" + monName + "）" : ""}`);

/* 石の 人の 記録（区の 入口で 拾う 本）*/
const RECORD = [
  "§7『書記 マルタ。最後に 書いた 字は「静かに」。……子どもが 泣き止まなかった』",
  "§7『道化 ポポ。三千年前の 今日、最後の 公演。客は 全員、拍手の 形の まま 止まった』",
  "§7『花売り エラ。妹たちに 花冠を 編んで いた。三つ 目を 編み終える 前に』",
  "§7『案内人 トマ。旅人を 町へ 案内して いた。……この 名前を、どこかで 聞いた 気が する』",
  "§7『パン屋 グスタフ。食卓の 上の パンまで 石に なった。家族の 一人だけ、扉へ 手を 伸ばして いる。記録「逃げろと 叫んだ。誰も 動かなかった」』\n§7『隣の 家の 少女 §fサヤ§7。千年 前から、兄の 帰りを 待って いる』",
  "§7『時計番 オットー。塔の 時計は 23時59分で 止まって いる。あと 一分で 明日 だった』",
  "§7『詩人 ユキノ。辞世の 句「とけたなら / 春と 呼んでね / 名を 呼んで」』",
  "§7『兵士 ガイ。最後まで 門を 守った。剣を 抜いた 形の まま』",
  "§7『子ども ミナ、リク、ソラ、ハル。ボールを 追いかけて いた。四人とも 笑って いる』",
  "§7『王妃の 侍女 ミラ。王妃さまは 祈って いた。「この 一日が、永遠に 続きますように」と』",
];
/* 魔将の 会話（戦う 前）*/
const PRE = [
  ["（札に 書いて 見せた）『静かに』", "（札）『ここの 者は 皆、静かに なった』", "（札）『おまえも』"],
  ["さあさあ お立ち会い！ 本日の 演目は『石の 街の 最後の 一日』！", "拍手の 形の まま 三千年！ ねえ、すてきでしょう？ 拍手 拍手〜！"],
  ["ようこそ、ぼくの 花壇へ。", "ほら、見て。みんな、きれいに 咲いたよ。", "§7（花は 人の 形の 土から 生えて いた）"],
  ["……やあ。久しぶり。", "覚えて ない？ ルミナで 最初に 会ったじゃ ないか。§e案内人§f だよ。", "ワープ、ストーリー、遊び方。全部 教えて あげたよね。……ずっと、きみの 後ろに いたんだ"],
  ["ガハハ！ 腹が 減った！ 三千年 ぶんの 腹ぺこだ！", "その 腕輪、うまそうだな。その 鍔も。その 相棒も！"],
  ["（懐中時計を 見て）……予定より 4秒 遅い。", "わたしは 時刻ちょうどにしか 現れない。今が その時刻だ。", "残り 3秒。……2。……1。"],
  ["とけたなら / 春と 呼んでと / 言われても", "わたしは 冬 / 名前は 呼ばない / 凍らせる"],
  ["ガッハッハ！ 来たか、声の…… いや、ささやきの 届かぬ 者よ！", "ムサシは おるか！ あの 若造の 太刀筋、気に入って おる！", "正々堂々、一騎打ちだ！"],
  ["みーつけた。", "ねえ、かくれんぼ しよう。三千年 ずっと、鬼が 来なかったの。", "……次は、きみが 鬼ね"],
  ["……あの人は、まだ 来ないの。", "わたしは 祈ったの。この 一日が 永遠に 続きますようにって。", "あの人と 過ごした、なんでも ない 一日。……それが、こんな ことに なるなんて"],
];
const POST = [
  ["（札）『……やっと 声を 出しても いいか』", "§7アルゴは 初めて 口を 開いた。かすれた 声で「ありがとう」と 言って、消えた"],
  ["……拍手、もう 止めて いいのね。", "§7観客席の 石が とけ、人々が 一度だけ 手を 叩いて、消えた"],
  null, null,
  ["ガハ…… 腹が…… いっぱいだ……", "§7グラトンの 腹から、三千年分の 食卓の パンが 転がり出て、灰に なった"],
  ["……時刻ちょうど。おわりの 時刻だ", "§7塔の 時計の 針が 動いた。0時00分。§f三千年ぶりに、明日が 来た"],
  ["春と 呼ぶ / 名前は ユキノ / わたしの 名", "§7フリージアは 自分の 名を 呼んで、とけた"],
  ["見事！ ……ムサシに 伝えろ。いい 太刀筋 だったと", "§7ボルトスは 胸を 張った まま、雷の 粒に なった"],
  null,
  null,
];

/* 戦う 前 */
export function tkPre(p, i) { return calm(p, async () => { const e = i < 10 ? stand(p, "§4" + TK_NAME[i], TK_SK[i]) : null; try { return await _tkPre(p, i); } finally { gone(e); } }); }
async function _tkPre(p, i) {
  const d = load(p); if (!d) return;
  const r = ruOf(d); r.rec = r.rec || [];
  if (i < 10) {
    if (!r.rec.includes(i)) { await narr(p, `石の 人の 記録（${TK_EPI[i]}）`, ["§7区の 入口に、石に なった 人が 一冊の 本を 抱いて いた。", "", RECORD[i]]); r.rec.push(i); save(p, d); }
    await say(p, TK_NAME[i], PRE[i], "§4");
  } else {
    await narr(p, TK_EPI[i], ["§7石の 門の 前に、門を 守る 魔物が 立って いる。", "§8門の 柱には、三千年前の 落書きが 残って いた。§7「明日 また 遊ぼうね」"]);
  }
}

/* 勝った あと（その 区の 石が とける） */
export function tkPost(p, i, n) { return calm(p, async () => { const e = i === 9 ? stand(p, "§d王妃 セレネ", "selene") : null; try { return await _tkPost(p, i, n); } finally { gone(e); } }); }
async function _tkPost(p, i, n) {
  const d = load(p); if (!d) return;
  const r = ruOf(d), s = qs(d);
  big(p, "§b§l石が とける", `§f${TK_EPI[i]}の 人々が 一瞬だけ 動いて、消えて いく`, "block.amethyst_block.chime");
  if (i === 2) {   /* ドロスの 花壇・リリの 姉妹 */
    await narr(p, "花壇", ["§7花壇の 土が 崩れた。", "§f中から、制服の 切れはしが 三つ 出て きた。§9紺色の、協会の 制服。", "§7……受付の §eリリ§7 と 同じ 顔の 少女たちが、三人。"]);
    await say(p, "第三魔将 ドロス", ["みんな、きれいに 咲いたのに。……どうして 枯らすの"], "§4");
    await narr(p, "リリの 姉妹", ["§7（五つ子の うち 三人は、ここで 花の 養分に されて いた）", "§7受付で 何度も 聞いた『姉が 帰って こないの』の 答えが、これだった。", "§8……残った 二人に、何と 伝えれば いいのだろう。"]);
    s.liliSis = 1;
  } else if (i === 3) {   /* カメリオの 正体 */
    await say(p, "第四魔将 カメリオ", ["負けちゃった。……ねえ、レイくんが 言ってたでしょ。『後ろに 誰か 立ってなかったか』って。", "ぼくだよ。ずっと 見てた。きみには ささやきが 届かない。だから 器には ならない。……でも、きみの §e相棒§f は ちがうかもね", "ヴォルナグさまは、もう 決めてる。§c相棒を もらう§f って"], "§4");
    await narr(p, "案内人", ["§7カメリオの 顔が、ルミナの §e案内人§7 の 顔に なり、§8最後に 誰でも ない 顔に なって 崩れた。"]);
    s.camelio = 1;
  } else if (i === 8) {   /* 遊び場 */
    await narr(p, "遊び場", ["§7ヨルが 消えた あと、遊び場の 子どもたちは §8ボールを 追いかける 姿の まま§7 だった。", "§7石が とけて、子どもたちは 一度だけ 笑って、消えた。", "", "§fあなたの 相棒が、転がって きた ボールを くわえて 戻って きた。", "§8……渡す 相手は、もう いなかった。"]);
  } else if (i === 9) {   /* 王妃セレネ */
    await say(p, "王妃 セレネ", ["……あの人。あなた、まだ そこに いるの？"], "§d");
    await narr(p, "厄王の ささやき", ["§6石板の 奥から、一度だけ 返事が あった。", "", "§6「§fもういい。一日は 終わるから、楽しかった§6」"]);
    await say(p, "王妃 セレネ", ["……そう。楽しかった、のね。", "わたしも。"], "§d");
    await narr(p, "王宮の区", ["§7王妃は 笑って、灰に なった。", "§7侍女 ミラの 石像が とけて、王妃の 灰に 頭を 下げて、消えた。"]);
  } else if (POST[i]) {
    const [a, b] = POST[i]; await say(p, i < 10 ? TK_NAME[i] : TK_EPI[i], [a], "§4"); await narr(p, TK_EPI[i], [b]);
  } else await narr(p, TK_EPI[i], ["§7門の 石が とけ、門番の 魔物は 静かに 崩れた。"]);
  /* 5区め: エンマの 妹 */
  if (n >= 5 && !s.sisterDone) {
    big(p, "§4§lエンマの 妹", "§f石の 少女が 立って いる", "mob.wither.ambient");
    await narr(p, "妹の 区", ["§7街の はずれ、小さな 家の 前に、§f少女の 石像§7 が あった。", "§fエンマ（鍔の 中）が、初めて 自分から 姿を 見せた。"]);
    await say(p, "エンマ", ["……§eサヤ§f。", "§7（エンマが 名前を 呼ぶと、石が とけはじめた）"], "§4");
    await say(p, "エンマの 妹", ["……兄さま。", "鍔、つけて もらえたのね。"], "§d");
    await narr(p, "灰", ["§8少女は 一言だけ 言って、§7灰に なった。", "§8……千年前に、もう 死んで いた。", "§c「あの ささやきは、妹が 生きて いると 嘘を ついた」", "§7エンマは 消えなかった。妹の 灰を 鍔に 封じて、刀を 腰に もどした。", "§4エンマ「……償う。生きて。」"]);
    s.enmaAlly = 1; s.sisterDone = 1; save(p, d);
  }
  /* 全部 とけた: セイルの 告白・セオ */
  if (n >= 15 && !s.seilDone) {
    big(p, "§5§lセイルの 告白", "", "ambient.cave");
    const eS = stand(p, "§5神官 セイル", "seil");
    await say(p, "神官 セイル", ["……全部、とけたのか。数えて いたよ。あと 何人、石の まま か。……ゼロだ。", "あなたに 言わなければ いけない ことが ある。", "王妃に『§d永遠を 願う 祈り§f』を 教えたのは、§c私§f だ。", "あの 祈りが、ヴォルナグを 呼んだ。……私が、最初に 祈った"], "§5");
    await say(p, "セオ", ["§7（息を 切らして 駆けこんで きた）", "セイル……さん。僕は、あなたの 子孫です。", "あなたの メモを 読んで、僕も 同じ ことを した。……ごめんなさい。僕たちは 二人とも"], "§a");
    await say(p, "神官 セイル", ["……そうか。ならば 最後の 祈りを 教えよう。", "記録塔の 扉は、記録でしか 開かない。§e私を 一頁に する§f。", "セオ。嘘を 書かない 歴史を 書きなさい。それが、私たちの 罰だ"], "§5");
    s.seilDone = 1; save(p, d); gone(eS);
    await narr(p, "最後の 頁", ["§7セイルの 体が、一枚の 紙に なって、記録塔の 扉に 吸いこまれた。", "§f扉が 開いた。", "§7セオは 扉の 前で、紙の 切れはしを 拾って、長い あいだ 動かなかった。"]);
  }
  save(p, d);
}

/* 最終戦の 前: 邪神が 相棒に 取りつく。きずなで 有利・不利 */
const TIERS = [0, 80, 250, 600, 900];
export function palOf(d) { return [...(d.party || []), ...(d.bench || []), ...(d.box || [])].find((m) => m && (m.id === d.partnerId || m.partner || m.look)) || null; }
export function tkFinalPre(p) { return calm(p, () => _tkFinalPre(p)); }
async function _tkFinalPre(p) {
  const d = load(p); if (!d) return { wk: 0, add: [] };
  const m = palOf(d);
  await say(p, "邪神 ヴォルナグ", ["……よく 来ました。覚えて おいて あげましょう。", "あなたには、わたしの ささやきが 届かない。……さびしい ことです", m ? `だから、その 子を いただきます。§e${m.nm || SPECIES[m.sp]?.name}§f。……ほら、あなたを 呼んで いますよ` : "……おや、ひとりですか。"], "§5");
  if (!m) return { wk: 0, add: [] };
  let nk = 0; try { nk = Number((exOf(p).nk || {})[m.id]) || 0; } catch {}
  const t = TIERS.filter((v) => nk >= v).length - 1;
  const nm = m.nm || SPECIES[m.sp]?.name;
  await narr(p, "取りつかれた 相棒", [`§5黒い 霧が §e${nm}§5 を 包んだ。`, `§e${nm}§f が こちらを 向いて、§c${p.name}§f の 名前を 呼びながら 牙を むく――`]);
  let wk = 0, line;
  if (t >= 3) { wk = 3; line = `§a${nm}は 霧の 中で もがいて いる。§f中から 何度も、あなたを 呼び返して いる！ §7（きずなが 強い: 邪神の HP −30%）`; }
  else if (t >= 2) { wk = 1; line = `§e${nm}は 霧に 抵抗して いる。§7（きずな「相棒」: 邪神の HP −10%）`; }
  else { wk = -2; line = `§c${nm}は 霧に 呑まれかけて いる……！ §7（きずなが 弱い: 邪神の HP +20%。ガイドブックの きずなを 深めて 来ると 有利に なる）`; }
  await narr(p, "きずな", [line]);
  return { wk, add: [{ sid: m.sp, lv: m.lv, q: 1, plus: Math.min(99, (m.plus || 0) + 10) }], pal: nm, t };
}
export function tkFinalPost(p, info) { return calm(p, () => _tkFinalPost(p,info)); }
async function _tkFinalPost(p, info) {
  if (!info || !info.pal) return;
  await narr(p, "霧が 晴れる", [`§f黒い 霧が ほどけ、§e${info.pal}§f が 足もとに 転がって きた。`, info.t >= 2 ? "§a……しっぽを 振って、あなたの 手を なめた。" : "§7……しばらく ぼんやりして いたが、やがて あなたの 匂いを かいで、そばに 座った。"]);
  await say(p, "邪神 ヴォルナグ", ["……ああ。消える。忘れられて しまう。", "わたしは、ただ…… 誰の ことも、忘れたく なかった"], "§5");
  await narr(p, "白紙", ["§f世界じゅうの 石板の 文字が、すうっと 消えて いった。", "§7すべての 石板が §f白紙§7 に なった。", "§e記録は 封じる ものでは なく、終わらせる ものだった。"]);
  await narr(p, "エピローグ", ["§cムサシ§f は クロガネで、§e封じる ためでは ない 鍔§f を 打った。エンマの 墓に 供える ために。", "§4エンマ§f は 妹の 灰を 鍔に 抱いて、ムサシの 隣を 歩いて いる。", "§aセオ§f は 嘘を 書かない 歴史書を 書きはじめた。最初の 頁には、セイルと オルドの 名前。", "§bレイ§f は しくじり帳の 最後の 頁に、竜の 石像の 絵を 描いた。", "§7そして カゲツは、ようやく ぐっすり 眠って いる。"]);
}
