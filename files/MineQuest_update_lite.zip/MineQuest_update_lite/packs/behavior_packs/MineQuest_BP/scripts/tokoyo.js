// 第106版: 常世編。十の 区を 十魔将が 一人ずつ 治める。石の 人の 記録・魔将の 会話・区が とける 場面
// 第126版: 邪闘十魔将（十冠 ヒフミ＆シゴロ〜一冠 ベルガ）。Gサイズの 禍々しい 魔物で 登場・前ぶれ・魂が 歩いて 戻る
// 第125版: 魔将は とらわれた 魂を 一つずつ 抱えて いる（サヤ・ヒロイン・セオ）。ヴァルグレイドの 魂の わび・邪神の あとで みんなが 戻る
import { world, system } from "@minecraft/server";
import { talk, tell, establish, camShot, camN } from "./talk.js";   /* 第108版: 会話は フォームで 止めない */
import { load, save } from "./store.js";
import { notice, choose, ICON, sound, showTitle, ok, anim, pillar } from "./ui.js";
import { qs } from "./quest.js";
import { exOf } from "./explore.js";
import { SPECIES } from "./data.js";
import { PSKIN } from "./skinjobs.js";
import { setJob } from "./ui.js";
import { busy } from "./ui.js";
import { inBattle } from "./battle.js";
import { townAt } from "./structures.js";
import { RU_GATE } from "./ruinsarea.js";
import { heroOf } from "./stage2.js";
import { scene, act, go, knock, knockP, shake, flash, fx, wave, shadowFlow, fade, pause, spot, lookUp, lookAt, camAt, emote, PJ, HAKU_SP, REI_DRAGON_SP, stoneFx, rmE, exit, face, tears } from "./stage2.js";
import { arrive } from "./stagecore.js";
/* 第121版: 場面の 人物は stage2 の cast で 立たせて、場面の 終わりに 消す（抜けても 海辺の 片づけ mrpg_cine で 消える） */
/* 第126版: 邪闘十魔将。十冠 ヒフミ＆シゴロから 戦い、一冠 ベルガが いちばん 上（0 が 十冠）。魔将は 禍々しい 色の Gサイズの 魔物で 立つ */
import { lookOf, setLook } from "./field.js";
import { TK_SP, TK_LOOK, TK_LOOK2, TK_PT, TK_CROWN, TK_NM, TK_LESSON } from "./tkgimmick.js";
const SOUL_SK = ["m6_pip", "toma", "m6_father", "m6_paolo", "rosa", "otto", "guy", "shiori", "yuki", "mira"];   /* 区の 石の 人（記録の 人）の 魂 */
const SAIL = "常世の 渡し守", GBIG = 1.15;
const PCOL = [[0.9, 0.9, 0.9], [0.6, 0.2, 0.8], [0.8, 0.9, 1], [1, 0.8, 0.2], [1, 0.5, 0.7], [0.3, 0.8, 0.9], [1, 0.95, 0.3], [0.6, 0.85, 1], [1, 0.45, 0.1], [0.8, 0.2, 0.8]];   /* 第125版: 魔将ごとの 柱の 色（TK_PT と 同じ 色あい）*/

/* 第106版: 物語の 場面の あいだは 魔物が 襲って こない（ruins.js が 見る） */
export const TK_CALM = new Set();
const CALMN = new Map();   /* 第106版: 場面が 続いても 前の 予約で 消さない（人ごとの 数） */
const calm = async (p, fn) => { const id = p.id; CALMN.set(id, (CALMN.get(id) || 0) + 1); TK_CALM.add(id); try { return await fn(); } finally { system.runTimeout(() => { const n = (CALMN.get(id) || 1) - 1; if (n > 0) CALMN.set(id, n); else { CALMN.delete(id); TK_CALM.delete(id); } }, 100); } };
const say = (p, who, lines, col = "§f") => talk(p, who, lines, col);
const narr = (p, t, L) => tell(p, t, L);
const big = (p, a, b, snd) => { try { showTitle(p, a, { subtitle: b || "", fadeInDuration: 6, stayDuration: 50, fadeOutDuration: 12 }); } catch {} if (snd) sound(p, snd, 1); };
const ruOf = (d) => { const s = qs(d); s.ru = s.ru || {}; return s.ru; };
/* 第125版: ヒロインが 戻る までは 場面に 立たせない（印は 表の 物語と 共通）*/
const heroOn = (p) => { try { const s = qs(load(p) || {}); return !(s.heroDead && !s.heroBack); } catch { return true; } };
const HERO = (p, C, ...a) => (heroOn(p) ? C.hero(...a) : null);
const mkOf = (r) => (r.b || []).filter((x) => x >= 0 && x < 10).length;
const clearScr = (p) => { try { p.runCommand("title @s clear"); } catch {} try { p.onScreenDisplay.setActionBar(" "); } catch {} };   /* 場面の あとは セリフと 画面を 消す */

/* 区の 名前（0〜9 魔将・10〜14 番兵） */
export const TK_EPI = ["遊び場の区", "人形の区", "鏡の区", "馬場の区", "花壇の区", "時計の区", "雷鳴の区", "静寂の区", "城壁の区", "王宮の区", "東の 石門", "西の 石門", "南の 石門", "北の 石門", "記録塔の 門"];
export const TK_NAME = TK_NM.map((n, i) => `邪闘十魔将 ${TK_CROWN[i]} ${n}`);
export const tkBossName = (i, monName) => (i < 10 ? TK_NAME[i] : `区の 番兵「${TK_EPI[i]}」${monName ? "（" + monName + "）" : ""}`);
/* 十冠から 順に（前の 魔将を すべて 倒すと 次が ひらく）。番兵は いつでも */
export const tkOpen = (b, i) => { if (!(i >= 0 && i < 10)) return true; const B = Array.isArray(b) ? b : []; for (let j = 0; j < i; j++) if (!B.includes(j)) return false; return true; };

/* 石の 人の 記録（区の 入口で 拾う 本）。魔将の 過去と つながる */
const RECORD = [
  "§7『子ども ミナ、リク、ソラ、ハル。ボールを 追いかけて いた。四人とも 笑って いる』\n§8そばの 石段に、白と 黒の サイコロが 一つずつ。だれかの 字で「次は ぼくらの 番」。",
  "§7『案内人 トマ。旅人を 町へ 案内して いた。……この 名前を、どこかで 聞いた 気が する』\n§8その 手首には、切れた 糸が 一本、からまって いた。",
  "§7『パン屋 グスタフ。食卓の 上の パンまで 石に なった。家族の 一人だけ、扉へ 手を 伸ばして いる。記録「逃げろと 叫んだ。誰も 動かなかった」』\n§7『隣の 家の 少女 §fサヤ§7。千年 前から、兄の 帰りを 待って いる』\n§8壁の 大きな 鏡には、まだ 動いて いる 家族が 映って いた。",
  "§7『道化 ポポ。三千年前の 今日、最後の 公演。くじ引きで 大当たりを 引いた 子が、跳び上がった 形の まま 止まった』",
  "§7『花売り エラ。妹たちに 花冠を 編んで いた。三つ 目を 編み終える 前に』",
  "§7『時計番 オットー。塔の 時計は 23時59分で 止まって いる。あと 一分で 明日 だった』\n§8それから この 区には、朝が 来て いない。",
  "§7『兵士 ガイ。最後まで 門を 守った。剣を 抜いた 形の まま』\n§8……空の どこかから、ずっと 見られて いる 気が する。",
  "§7『書記 マルタ。最後に 書いた 字は「静かに」。……子どもが 泣き止まなかった』\n§8その 横に、一本の 刀傷。石を 音も なく 斬った 跡だった。",
  "§7『詩人 ユキノ。辞世の 句「とけたなら / 春と 呼んでね / 名を 呼んで」』\n§8城壁は 三重。どれも 内側から 閉ざされて いる。",
  "§7『王妃の 侍女 ミラ。王妃さまは 祈って いた。「この 一日が、永遠に 続きますように」と』\n§8玉座の 前には、ひざまずいた 形の 石が 百も 並んで いた。",
];
/* 魔将の 会話（戦う 前）。[話す 人, 文]。"H" は ヒロイン。1行ごとに カメラを かえる */
const PRE = [
  [["ヒフミ", "{smile,♪,jump}あはは！ 来た 来た。シゴロ、お客さんだよ"], ["シゴロ", "{smile,…}うん。……ずっと、だれも 来なかったもんね"], ["ヒフミ", "{smile,☆,up}ここの 子たちは、ボールを 追いかける とちゅうで 止まっちゃった"], ["シゴロ", "{angry,low}だから ぼくらが かわりに 遊んで あげてる。……サイコロで"], ["H", { g: "{angry,怒}遊び？ ……この 子たちを 返してから 言って！", o: "{angry}遊び……？ この 子たちを 返してから 言って。", c: "{angry,怒}遊び？ ……この 子たちを 返せ。話は それからだ。", t: "{angry,怒}遊び、ですか？ ……この 子たちを 返してから おっしゃって ください！" }], ["ヒフミ", "{smile,♪,up}じゃあ 賭けよう。さあ、振るよ"]],
  [["イトマ", "{smile}……やあ。久しぶり。"], ["イトマ", "{smile,?,up}覚えて ない？ ルミナで 最初に 会ったじゃ ないか。§e案内人§f だよ"], ["H", { g: "{shock,!,jump}な、なに あの 声……！ 糸の 先から 聞こえる！", o: "{shock,!}……なに、あの 声。糸の 先から 聞こえるわ……！", c: "{shock,!}……声。糸の 先から。", t: "{shock,!,up}な、何でしょう あの 声……！ 糸の 先から 聞こえます！" }], ["イトマ", "{smile,…,low}あの 案内人は、わたしの 人形。ワープも、遊び方も、ぜんぶ 糸で しゃべらせたの"], ["イトマ", "{smile,♪,up}……ずっと、あなたの 後ろに いたのよ"]],
  [["テルグ", "{closed,…}……映せ、映せ。"], ["テルグ", "{smile,up}この 区の 鏡には、石に なる 前の 家族が 映って いる。わたしが 映し続けて いる"], ["H", { g: "{sad,…}……パン屋さんの 家族、鏡の 中では まだ ご飯を 食べてる", o: "{sad,…}……パン屋さんの 家族、鏡の 中では まだ ご飯を 食べてるのね", c: "{sad,…}……パン屋の 家族。鏡の 中では まだ 食事中", t: "{sad,…}……パン屋さんの ご家族、鏡の 中では まだ お食事を されて います" }], ["テルグ", "{angry,!,low,roar}おまえの 技も、そのまま 返して やろう"]],
  [["サイオウバ", "{smile}禍福は あざなえる 縄の ごとし。……知って いるかね"], ["サイオウバ", "{smile,?,up}道化が 大当たりを 引いた 日、この 区は 石に なった。福の あとには、禍が 来る"], ["H", { g: "{angry,怒}……それを 決めたのは、あんたでしょ", o: "{angry}……それを 決めたのは、あなたでしょう", c: "{angry,怒}……決めたのは、おまえだ", t: "{angry,怒}……それを 決めたのは、あなたでは ありませんか" }], ["サイオウバ", "{angry,low}さあ、おまえの 運を 裏返して やろう"]],
  [["ハドラ", "{smile,♪}ようこそ、ぼくの 花壇へ。"], ["ハドラ", "{smile,♥,up}ほら、見て。首が、みんな きれいに 咲いたよ"]],
  [["ザキュラス", "{closed}……23時59分。この 区の 時は、ここで 止めた"], ["ザキュラス", "{smile,up}明日は 来ない。夜は 終わらない。……夜こそ、わたしの 食卓だ"], ["H", { g: "{shock,汗}……空、まっくら。昼の はず なのに", o: "{shock,汗}……空が まっくら。昼の はず なのにね", c: "{shock,汗}……空が 暗い。昼の はず", t: "{shock,汗}……空が まっくらです。昼の はず なのに" }], ["ザキュラス", "{angry,!,low,roar}血を 置いて いけ"]],
  [["ガムラ", "{angry,…}……見て いた。"], ["ガムラ", "{closed,up}門を 守った 兵士を。三千年、ずっと。剣を 抜いた まま、一度も 倒れなかった"], ["H", { g: "{shock,!}あの 目……どこへ 行っても、こっちを 見てた 目だ", o: "{shock,!}あの 目……どこへ 行っても、こっちを 見てた 目だわ", c: "{shock,!}……あの 目。どこでも こっちを 見てた", t: "{shock,!}あの 目……どこへ 行っても、こちらを 見て いた 目です" }], ["ガムラ", "{rage,!,low,roar}おまえも 見て やる。最後まで 立って いられるか"]],
  [["リョウマ", "{closed,…}…………"], ["H", { g: "{shock,汗}……音が、ぜんぜん しない。自分の 足音まで", o: "{shock,汗}……音が、ぜんぜん しないわ。自分の 足音まで", c: "{shock,汗}……音が しない。足音も", t: "{shock,汗}……音が、まったく しません。自分の 足音まで" }], ["リョウマ", "{closed,low}静かに。刃は、音より 先に 届く"], ["リョウマ", "{angry,!,up,roar}一騎打ちだ。一人ずつ 来い"]],
  [["ギレンドドロス", "{closed}三重の 壁。三重の 鎧。……何ものも、ここへは 入れぬ"], ["ギレンドドロス", "{sad,up}わたしは 永遠を 願った。王妃と 同じく。……永遠とは、こわれぬ ことだ"], ["H", { g: "{angry,怒}こわれない ものなんて、ない！", o: "{angry}こわれない ものなんて、ないのよ", c: "{angry,怒}……こわれない ものは、ない", t: "{angry,怒}こわれない ものなど、ありません！" }], ["ギレンドドロス", "{angry,!,low,roar}ならば、こわして みよ"]],
  [["ベルガ", "{angry,low}ひざまずけ。"], ["ベルガ", "{closed,up}わたしは 王の 声。……王が 黙った 千年、わたしが 命じて きた"], ["H", { g: "{angry,!}王さまの 声？ ……王さまを どこへ やったの", o: "{angry}王さまの 声……？ 王さまを、どこへ やったの", c: "{angry,!}王の 声？ ……王を どこへ やった", t: "{angry,!}王さまの 声？ ……王さまを どこへ やったのですか" }], ["ベルガ", "{rage,!,roar}答える 義理は ない。命令だ。§cひざまずけ"]],
];
/* 勝った あと: [魔将の ひとこと（話す 人と 文）, 区が とける 絵の 文] */
const POST = [
  [["シゴロ", "{sad,…}……負けちゃった。ヒフミ、つぎの 目は？"], ["ヒフミ", "{smile,closed}もう 振らなくて いいよ。……みんなと 遊ぼう"]],
  [["イトマ", "{smile}負けちゃった。……ねえ、気づかなかった？ ルミナから ずっと、あなたの 後ろに 立って いたのに"]],
  [["テルグ", "{closed,…}……鏡が、割れる。映して いた 家族も、もう"], "§7鏡の 中の 家族が、こちらに 一度だけ 手を 振った。そして 鏡は 空っぽに なった"],
  [["サイオウバ", "{closed,up}……禍の あとには、福が 来る。……そう だろう？"], "§7くじの 大当たりを 引いた 子の 石が、三千年ぶりに 着地した。そして、笑って 消えた"],
  [["ハドラ", "{sad,?}みんな、きれいに 咲いたのに。……どうして 枯らすの"]],
  [["ザキュラス", "{closed,…}……朝、か。……まぶしいな"], "§7塔の 時計の 針が 動いた。0時00分。§f三千年ぶりに、明日が 来た"],
  [["ガムラ", "{closed,…}……見事だ。あの 兵士と、同じ 目を して いる"], "§7門の 前の 兵士 ガイの 石が、剣を 鞘に 納めて、消えた"],
  [["リョウマ", "{smile,☆,low}見事。……ムサシに 伝えろ。いい 太刀筋 だったと"], "§7リョウマが 刀を 鞘に 納めた。§f音が、もどって きた"],
  [["ギレンドドロス", "{closed,up}……とけて しまえば、春が 来るのだな"], "§7三重の 城壁が、内側から ひらいた。詩人 ユキノの 石が 空を 見上げて、とけた"],
  [["ベルガ", "{shock,…,up}……命令が、とどかない。……王よ、わたしは"], "§7王宮の 百の 石が、一度だけ 顔を 上げた。そして、ひざまずくのを やめて 消えた"],
];
const STONE = ["stoneknight", "ruinguard", "guy", "otto", "toma", "mira"];
/* 区の 石が とける: 石の 人々が 一度だけ 動いて、光に なって 消える */
async function melt(p, C, n = 3, pose = "hold", move = "cheer") {
  const E = []; for (let k = 0; k < n; k++) { const e = C.npc("", PJ(STONE[(k * 2 + n) % STONE.length], 8), 5 + (k % 2), (k - (n - 1) / 2) * 1.8); if (e) { act(e, pose); E.push(e); } }
  if (!E.length) return; camAt(p, spot(p, -1, 0, 2.2) || p.location, E[0].location);
  await pause(26); flash(p); sound(p, "block.amethyst_block.chime", 1);   /* 第124版(fix2): 出す ときの 暗転が 明けて から 光る（2回 ちらつかない）*/
  for (const e of E) { act(e, move); emote(e, "spark"); } await pause(24);
  for (const e of E) await fade(e, "minecraft:endrod");
}
/* 魔将（Gサイズ・禍々しい 色）を 場面に 立たせる */
/* 第124版(cam): 顔の 高さは 天井より 下（洞くつ・広間で 岩の 中を 映さない）*/
const roomY = (e, h) => { try { const l = e.location; for (let y = 2; y <= h + 1; y++) { const b = e.dimension.getBlock({ x: l.x, y: l.y + y, z: l.z }); if (b && !b.isAir) return Math.max(1.6, Math.min(h, y - 1.2)); } } catch {} return h; };
const hyOf = (e, i) => { try { const v = e.getDynamicProperty("mrpg:hy"); if (typeof v === "number") return v; } catch {} return faceY(i); };
const faceY = (i) => { try { return Math.max(2, Math.min(10, lookOf(TK_SP[i], { sz: "G" }).mh * GBIG * 0.85)); } catch { return 4; } };
function genMon(p, C, i, dist, side = 0, black = false, how = "smoke") {
  const sid = TK_SP[i], e = C.mon(sid, dist, side, 0, how); if (!e) return null;
  try { setLook(e, sid, { tint: black ? TK_LOOK2 : TK_LOOK[i], sz: "G" }); e.setProperty("mrpg:size", Math.min(2500, Math.round(lookOf(sid, { sz: "G" }).size * GBIG))); } catch {}
  try { e.nameTag = ""; e.addTag("mrpg_spkm"); e.setDynamicProperty("mrpg:spk", TK_NM[i]); e.setDynamicProperty("mrpg:hy", roomY(e, faceY(i))); } catch {}   /* 第124版(cam): 名札が なくても 話す 人として 見つかる・顔の 高さ */
  return e;
}
const spkAs = (E) => { for (const k in E) if (k !== "_" && E[k]) try { E[k].setDynamicProperty("mrpg:spk", k); } catch {} };
/* 魔将の 顔を 映す（k で 角度を かえる: 下から・顔の 寄り・肩ごし）*/
function faceShot(p, e, i, k) {
  if (!e || !e.isValid || !e.isValid()) return;
  try {
    const l = e.location, h = hyOf(e, i), P = p.location, dx = P.x - l.x, dz = P.z - l.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n, rx = -uz, rz = ux, look = { x: l.x, y: l.y + h, z: l.z };
    const S = [{ x: l.x + ux * (h * 0.9 + 2) + rx * 2, y: l.y + h * 0.3, z: l.z + uz * (h * 0.9 + 2) + rz * 2 }, { x: l.x + ux * (h * 0.5 + 1.6) - rx * 1.4, y: l.y + h * 0.95, z: l.z + uz * (h * 0.5 + 1.6) - rz * 1.4 }, { x: P.x - ux * 1.8 + rx * 0.9, y: P.y + 1.9, z: P.z - uz * 1.8 + rz * 0.9 }];
    camShot(p, e, S[k % 3], look) || camShot(p, e, S[(k + 1) % 3], look) || camShot(p, e, { x: l.x + ux * (h + 6), y: l.y + h + 3, z: l.z + uz * (h + 6) }, look);   /* 第124版(cam): ふさがれば 別の 角度 → 引きの 高い 絵 */
  } catch {}
}
async function lines(p, C, i, E, L) {
  let k = 0;
  for (const [who, l] of L) {
    if (who === "H") { await hsay(p, C, typeof l === "string" ? [l] : { g: [l.g], o: [l.o], c: [l.c], t: [l.t] }); continue; }
    if (!/^\{[^}]*\b(up|low|wide|high|shock|rage)\b/.test(l)) faceShot(p, E[who] || E._, i, k++);   /* 第124版(fix2): 札で 撮る 行は 2回 撮らない */
    await say(p, who, [l], "§4");
  }
}
/* 魔将の 登場: 画面が 暗く なり、色の 粒。足もとから 見上げて 顔へ。名乗りの 札は 一行ずつ */
async function bossIn(p, C, i) {
  const E = {}, twin = i === 0;
  try { p.runCommand("camera @s fade time 0.4 0.9 0.6 color 0 0 0"); } catch {}
  sound(p, "mob.wither.ambient", 0.6); await pause(10);
  const e = genMon(p, C, i, 13, twin ? -2.4 : 0), e2 = twin ? genMon(p, C, i, 13, 2.4, true) : null;
  E._ = e; if (twin) { E["ヒフミ"] = e; E["シゴロ"] = e2; } else E[TK_NM[i]] = e; spkAs(E);
  if (!e) return E;
  for (const x of [e, e2]) if (x) { fx(p.dimension, TK_PT[i], x.location, 10, 2.5); fx(p.dimension, "minecraft:basic_smoke_particle", x.location, 6, 2); }
  camAt(p, spot(p, 1.2, -2.6, 0.5) || p.location, e.location);
  await Promise.all([go(e, spot(p, 7.5, twin ? -2.4 : 0), 26), e2 ? go(e2, spot(p, 7.5, 2.4), 26) : null]);
  try {
    const l = e.location, h = hyOf(e, i), P = p.location, dx = P.x - l.x, dz = P.z - l.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n, low = { x: l.x + ux * 4.5, y: l.y + 0.4, z: l.z + uz * 4.5 };
    shake(p, 0.4, 0.5); sound(p, "mob.ravager.stun", 0.6);
    camAt(p, low, { x: l.x, y: l.y + 0.6, z: l.z }, 0); fx(p.dimension, "minecraft:basic_smoke_particle", l, 8, 1.5); for (const x of [e, e2]) pillar(x, PCOL[i], 2.5); await pause(16);
    camAt(p, low, { x: l.x, y: l.y + h, z: l.z }, 1.4); for (const x of [e, e2]) anim(x, "g_roar"); sound(p, "mob.ravager.roar", 0.7, 0.8); await pause(26);   /* 第125版: 見上げた ところで 吠える */
    camAt(p, { x: l.x + ux * (h * 0.45 + 1.8), y: l.y + h * 0.95, z: l.z + uz * (h * 0.45 + 1.8) }, { x: l.x, y: l.y + h, z: l.z }, 1.2);
    fx(p.dimension, "minecraft:redstone_ore_dust_particle", { x: l.x, y: l.y + h, z: l.z }, 8, 0.6);
  } catch {}
  showTitle(p, `§7邪闘十魔将 ${TK_CROWN[i]}`, { subtitle: " ", fadeInDuration: 8, stayDuration: 30, fadeOutDuration: 4 }); sound(p, "block.bell.hit", 0.5); await pause(28);
  showTitle(p, `§4§l${TK_NM[i]}`, { subtitle: `§7邪闘十魔将 ${TK_CROWN[i]}`, fadeInDuration: 4, stayDuration: 50, fadeOutDuration: 14 }); sound(p, "mob.wither.spawn", 0.5); shake(p, 0.5, 0.6); await pause(40);
  return E;
}
const HTY = { hero_rio: "g", hero_chloe: "g", hero_hana: "g", hero_lulu: "g", hero_yuna: "o", hero_shion: "o", hero_mia: "c", hero_leaf: "c", hero_nami: "c", hero_mel: "t", hero_kaede: "t", hero_cecil: "t" };   /* 第124版: ヒロインの 話し方（saga.js の HT と 同じ）*/
const hv = (p, L) => { if (Array.isArray(L)) return L; const h = heroOf(p); return L[(h && HTY[h.key]) || "g"] || L.g; };
const hsay = async (p, C, L) => { if (C.hn) await talk(p, C.hn, hv(p, L), "§d"); };

/* 戦う 前 */
export function tkPre(p, i) { return calm(p, () => scene(p, (C) => _tkPre(p, i, C))); }
async function _tkPre(p, i, C) {
  const d = load(p); if (!d) return;
  const r = ruOf(d); r.rec = r.rec || []; r.gk = Array.isArray(r.gk) ? r.gk : [];
  if (i < 10) {
    { const a = spot(p, -7, 5, 8), b = spot(p, 7, 0, 1); if (a && b) { camAt(p, a, b, 0); await pause(26); } }   /* 第124版(fix2): 区の 始めは 場所を 見せる 引きの 絵 */
    if (!r.rec.includes(i)) {   /* 石の 人が 本を 抱いて いる → カメラが 寄る → 本を 読む */
      const st = C.npc("", PJ(STONE[i % STONE.length], 8), 3, -2); act(st, i === 6 ? "guard" : i === 0 ? "run" : "hold");
      if (st) { camAt(p, spot(p, 1.4, -1.2, 1.6) || p.location, { x: st.location.x, y: st.location.y + 1.2, z: st.location.z }); await pause(20); }
      await narr(p, `石の 人の 記録（${TK_EPI[i]}）`, ["§7区の 入口に、石に なった 人が 一冊の 本を 抱いて いた。", "", RECORD[i]]); r.rec.push(i); save(p, d);
    }
    const H = HERO(p, C);
    if (!r.gk.includes(i)) {   /* はじめての ギミック: 渡し守が 歩いて 来て 短く 教える */
      const S = C.npc(`§5${SAIL}`, 13, 3.2, -1.8); act(S, 0);   /* 第124版(cam): 映らない 所から 歩いて 来て、着いてから 寄る */
      if (S) { await arrive(S); lookAt(p, S); }
      const L = TK_LESSON[i];
      await say(p, SAIL, [`{closed}待て。${TK_NM[i]}の 仕掛けを 教えて おく`, L[0]], "§5");
      if (H) { act(H, "hold"); await hsay(p, C, { g: ["{shock,?}……しかけ？"], o: ["{shock,?}……しかけ、かしら？"], c: ["{shock,?}……しかけ。"], t: ["{shock,?}……しかけ、ですか？"] }); }
      if (L.length > 1) await say(p, SAIL, L.slice(1, 3), "§5");
      r.gk.push(i); save(p, d);
      if (S) { act(S, "wave"); await pause(10); act(S, 0); await exit(p, S, 10); }   /* 手を ふって から 背を 向ける */
    }
    const E = await bossIn(p, C, i);
    if (i === 1) {   /* イトマ: 糸の 先に 案内人の 人形 */
      flash(p, "0 0 0"); await pause(2); const pu = C.npc("§e案内人", PJ("toma", 8), 4.2, 1.8, 0, "none"); act(pu, "hold"); if (pu) { lookAt(p, pu); fx(p.dimension, "minecraft:endrod", pu.location, 6, 0.6); await pause(14); }
      E["イトマ"] = E._;
    }
    await lines(p, C, i, E, PRE[i]);
    if (i === 4) {   /* 花は 人の 形の 土から 生えて いた */
      const q = spot(p, 4.5, 2); if (q) { camAt(p, { x: q.x - 1, y: q.y + 1.2, z: q.z - 1 }, q); fx(p.dimension, "minecraft:spore_blossom_ambient_particle", q, 10, 0.8); await pause(16); }
      await narr(p, TK_EPI[i], ["§7（首の 根もとは、人の 形の 土だった）"]);
      act(H, "guard"); await hsay(p, C, { g: ["{rage,怒,jump}……ちょっと。これの どこが『きれい』なの！"], o: ["{angry}……これの どこが『きれい』なの……？"], c: ["{angry,怒}……これを『きれい』とは 呼ばない。"], t: ["{angry,怒}……これの どこが『きれい』なのですか！"] });
    }
    if (i === 6) { sound(p, "ambient.weather.thunder", 1); flash(p); }
    if (i === 7) { try { p.runCommand("stopsound @s"); } catch {} }
    shake(p, 0.4, 0.4); fx(p.dimension, TK_PT[i], spot(p, 7, 0) || p.location, 12, 3);
    clearScr(p);
  } else {   /* 石門: 地面が ゆれて 番兵が 立ち上がる */
    sound(p, "mob.ravager.roar", 0.7); shake(p, 0.7, 0.8); await wave(p, spot(p, 6, 0) || p.location);
    lookUp(p, spot(p, 7, 0, 5) || p.location);
    await narr(p, TK_EPI[i], ["§7石の 門の 前に、門を 守る 魔物が 立って いる。", "§8門の 柱には、三千年前の 落書きが 残って いた。§7「明日 また 遊ぼうね」"]);
  }
}
/* 魂が 光に なって 歩いて くる */
async function glowWalk(p, e, to, ticks) { if (!e) return; const w = go(e, to, ticks); for (let k = 0; k < ticks; k += 3) { try { if (!e.isValid()) break; fx(p.dimension, "minecraft:endrod", e.location, 2, 0.4); } catch { break; } await pause(3); } await w; }

/* 勝った あと（魔将が 崩れ、魂が 歩いて 来て、区の 石が 一瞬 動く。引きの 絵で 閉じる） */
export function tkPost(p, i, n) { return calm(p, () => scene(p, (C) => _tkPost(p, i, n, C))); }
async function _tkPost(p, i, n, C) {
  const d = load(p); if (!d) return;
  const r = ruOf(d), s = qs(d);
  const H = HERO(p, C);
  if (i < 10) {
    const twin = i === 0, e = genMon(p, C, i, 7, twin ? -2.4 : 0, false, "veil"), e2 = twin ? genMon(p, C, i, 7, 2.4, true, "veil") : null;   /* 第124版(cam): 戦いの あとも そこに いる（暗転の 中で）*/
    const E = { _: e }; if (twin) { E["ヒフミ"] = e; E["シゴロ"] = e2; } else E[TK_NM[i]] = e; spkAs(E);
    const [L, b] = [POST[i].filter((x) => Array.isArray(x)), POST[i].find((x) => typeof x === "string")];
    await lines(p, C, i, E, L);
    if (i === 1) {   /* 第125版の カメリオ → イトマ: 案内人は イトマの 人形だった */
      await say(p, "イトマ", ["{smile,…,up}わたしよ。ずっと 見てた。あなたには ささやきが 届かない。だから 器には ならない。……でも、あなたの §e相棒§f は ちがうかもね"], "§4");
      faceShot(p, e, i, 1); await say(p, "イトマ", ["{smile,♪,low}ヴォルナグさまは、もう 決めてる。§c相棒を もらう§f って"], "§4");
      act(H, "guard"); await hsay(p, C, { g: ["{rage,怒,jump}ふざけないで！ あの 子は 誰にも あげない！"], o: ["{angry,up}……だめ。あの 子は、誰にも あげない。"], c: ["{rage,怒}……あの 子は 渡さない。"], t: ["{angry,怒,up}おやめ ください！ あの 子は 誰にも 渡しません！"] });
      flash(p, "0 0 0"); await pause(2); const pu = C.npc("§e案内人", PJ("toma", 8), 4, 2, 0, "none"); act(pu, "hold");
      if (pu) { lookAt(p, pu); flash(p); await pause(16); try { setJob(pu, 0); pu.nameTag = ""; } catch {} await pause(10); await knock(pu, p.location, 0.5); await fade(pu, "minecraft:basic_smoke_particle"); }
      await narr(p, "案内人", ["§7糸が 切れた。案内人の 人形は、§8最後に 誰でも ない 顔に なって 崩れた。"]);
      s.camelio = 1;
    }
    if (i === 4) {   /* ハドラの 花壇・リリの 姉妹 */
      shake(p, 0.6, 0.6); sound(p, "random.explode", 0.4); await wave(p, spot(p, 5, 2) || p.location, "minecraft:basic_smoke_particle");
      const L3 = [C.npc("", PJ("lili2", 9), 5, 1), C.npc("", PJ("lili3", 9), 5.5, 2.2), C.npc("", PJ("lili4", 9), 5, 3.4)]; for (const x of L3) act(x, "down");
      if (L3[0]) { camAt(p, spot(p, 3, 2.2, 1.5) || p.location, L3[1] ? L3[1].location : L3[0].location); await pause(24); }
      await narr(p, "花壇", ["§7花壇の 土が 崩れた。中から、§9紺色の、協会の 制服§7 の 切れはしが 三つ。"]);
      await hsay(p, C, { g: ["{shock,!,jump}……この 顔、受付の リリさんと 同じ……！？"], o: ["{shock,!}……この 顔、受付の リリさんと 同じだわ……！"], c: ["{shock,!}……この 顔。受付の リリと 同じ。"], t: ["{shock,!,up}……この お顔、受付の リリさんと 同じ……！？"] });
      act(H, "guard"); await hsay(p, C, { g: ["{rage,怒,low}……あんたが『きれい』なんて 言うな！"], o: ["{angry,low}……あなたが『きれい』なんて、言わないで。"], c: ["{rage,怒,low}……おまえが『きれい』を 語るな。"], t: ["{rage,怒,low}……あなたに『きれい』などと 言う 資格は ありません！"] });
      for (const x of L3) await fade(x, "minecraft:cherry_leaves_particle");
      await narr(p, "リリの 姉妹", ["§7（五つ子の うち 三人は、ここで 首の 花の 養分に されて いた）", "§7受付で 何度も 聞いた『姉が 帰って こないの』の 答えが、これだった。", "§8……残った 二人に、何と 伝えれば いいのだろう。"]);
      s.liliSis = 1;
    }
    /* 魔将が 崩れる */
    for (const x of [e, e2]) if (x) { anim(x, "hurt_big"); fx(p.dimension, TK_PT[i], x.location, 14, 2.5); fx(p.dimension, "minecraft:basic_smoke_particle", x.location, 10, 2.5); }
    shake(p, 0.7, 0.8); sound(p, "mob.wither.death", 1, 0.4); if (e) camAt(p, spot(p, -1.5, 3, 3) || p.location, e.location);
    await pause(12); for (const x of [e, e2]) anim(x, "faint", true);   /* やられて 崩れる */
    for (const x of [e, e2]) if (x) await fade(x, TK_PT[i]);
    if (i === 9) await valgreid(p, C, s, d);
    else {   /* 抱えて いた 魂が 光に なって 歩いて くる */
      const so = C.npc("§b魂の 光", PJ(SOUL_SK[i], 8), 10, 1.4, 0, "smoke"); act(so, "hold");
      if (so) { lookAt(p, so); await glowWalk(p, so, spot(p, 3, 0.8), 30); act(so, "bow"); emote(so, "spark"); }
      await narr(p, "魂", [`§b${TK_NM[i]}が 抱えて いた 魂が、光に なって 歩いて きた。`, "§7ぺこりと 頭を 下げると、空へ のぼって いった。"]);
      if (so) await fade(so, "minecraft:endrod");
    }
    if (i === 0) {   /* 遊び場: 子どもたちが 一度 笑って 消える・相棒が ボールを くわえて 戻る */
      await melt(p, C, 4, "run", "cheer");
      const m = palOf(d); const pm = m ? C.mon(m.sp, 7, 2) : null;
      if (pm) { lookAt(p, pm); await go(pm, spot(p, 1.5, 0.6), 24); emote(pm, "q"); }
      await narr(p, "遊び場", ["§fあなたの 相棒が、転がって きた ボールを くわえて 戻って きた。", "§8……渡す 相手は、もう いなかった。"]);
      await hsay(p, C, { g: ["{sad,…}……うん。いい子。……持って 帰ろっか、それ。"], o: ["{sad,…}……ええ。いい子ね。……持って 帰りましょうか、それ。"], c: ["{sad,…}……いい子。それ、持って 帰ろう。"], t: ["{sad,…}……はい。いい子です。……持って 帰りましょうか、それ。"] });
    } else await melt(p, C, 3, i === 6 ? "guard" : i === 9 ? "kneel" : "hold", i === 3 ? 6 : "cheer");
    big(p, "§b§l石が とける", `§f${TK_EPI[i]}の 人々が 一瞬だけ 動いて、終われた`, "block.amethyst_block.chime");
    try { camAt(p, spot(p, -7, 5, 8) || p.location, spot(p, 7, 0, 1) || p.location, 1.5); } catch {}   /* 引きの 絵で 区を 見せる */
    await narr(p, TK_EPI[i], [b || "§7区の 石が とけ、静かに 風が 吹いた。"]);
    await pause(30);
  } else { big(p, "§b§l石が とける", `§f${TK_EPI[i]}の 門が ひらいた`, "block.amethyst_block.chime"); shake(p, 0.4, 0.4); await melt(p, C, 2, "guard", "bow"); await narr(p, TK_EPI[i], ["§7門の 石が とけ、門番の 魔物は 静かに 崩れた。"]); }
  /* 第125版: 魔将が 抱えて いた 魂が 戻る（倒した 魔将の 数で 決まる・1回ずつ）*/
  const mk = mkOf(r);
  if (mk >= 3 && !s.sisterDone) {   /* エンマの 妹 サヤ */
    big(p, "§d§lサヤ", "§f石の 少女の 魂", "mob.wither.ambient");
    const g = C.npc("§dサヤ", PJ("sayo", 9), 4.5, 0, 0, "smoke"); act(g, "hold");
    if (g) { lookAt(p, g); await pause(20); }
    flash(p, "120 0 0"); shake(p, 0.5, 0.5); sound(p, "mob.wither.spawn", 0.4);
    const en = C.mon("enma", 2.5, -1.8); if (en) { fx(p.dimension, "minecraft:basic_flame_particle", en.location, 14, 0.7); lookAt(p, en); }
    await say(p, "ムサシ", ["{shock,!,jump}エンマ！ 鍔から 出て きた……！"], "§c");
    await say(p, "エンマ", ["……§dサヤ§f。"], "§4");
    if (g) { fx(p.dimension, "minecraft:endrod", g.location, 10, 0.5); act(g, 0); }
    await say(p, "サヤ", ["{closed}……兄さま。", "{smile,tears,up}兄さまの 帳に、わたしの 名前、載らなかったね。", "{smile}だから わたし、まだ ここに いられたの。"], "§d");
    if (en) { emote(en, "dots"); fx(p.dimension, "minecraft:white_smoke_particle", en.location, 8, 0.5); await pause(16); }
    await say(p, "エンマ", ["……千年、待たせた。", "クロガネの 工房に、おまえの 体が ある。……先に 帰って いろ"], "§4");
    await say(p, "サヤ", ["{smile,☆,up}うん。……兄さまも、ちゃんと 帰って きてね"], "§d");
    await fade(g, "minecraft:endrod");
    await narr(p, "サヤ", ["§7少女の 魂は、ほそい 光に なって 空へ のぼった。", "§fムサシ「……工房の 石の 子が、目を 開ける 日が 来るのか」"]);
    await fade(en, "minecraft:basic_flame_particle");
    s.enmaAlly = 1; s.sisterDone = 1; save(p, d);
  }
  if (mk >= 6 && !s.heroSoul && s.heroDead && !s.heroBack) {   /* ヒロインの 魂 */
    const h0 = heroOf(p), hk = h0 && h0.key, hn = h0 ? h0.name : "あの 子";
    big(p, "§d§l小さな 光", "§f手帳が あたたかい", "block.amethyst_block.chime");
    const g = hk ? C.npc("§d？？？", PJ(hk, 9), 4.5, 0, 0, "smoke") : null; act(g, "sad");
    if (g) { lookAt(p, g); fx(p.dimension, "minecraft:endrod", g.location, 12, 0.6); await pause(20); }
    await narr(p, "魂", [`§7光の 中に、見なれた 背中が あった。§f……${hn}だ。`, "§7体は すけて いて、手を のばしても さわれない。"]);
    await say(p, `${hn}の 魂`, ["{shock,…,up}……あれ。……なんで、こんな ところに いるの。", "{sad}ここ、寒いね。……名前、ちょっとずつ 忘れて いくんだ。", "{smile,tears,up}でも、あなたの 足音だけは、ずっと 聞こえてた。"], "§d");
    await say(p, "ムサシ", ["{rage,怒,up}待ってろ！ 邪神を ぶっ倒して、絶対 連れて 帰る！"], "§c");
    await say(p, `${hn}の 魂`, ["{smile,closed}……うん。手帳、持ってて ね。……最後の 頁、まだ 白紙 でしょ"], "§d");
    await fade(g, "minecraft:endrod");
    s.heroSoul = 1; save(p, d);
  }
  if (mk >= 10 && !s.theoSoul && !s.theoBack) {   /* セオの 魂（影に つながれた まま）*/
    big(p, "§a§l影の 鎖", "§f最後の 魔将が 抱えて いた 魂", "mob.wither.ambient");
    const t = C.npc("§aセオ", 18, 5, 0, 0, "veil"); act(t, "kneel");
    if (t) { lookAt(p, t); await shadowFlow(p, spot(p, 9, 0) || p.location, t.location, 10); }
    await narr(p, "セオの 魂", ["§7黒い 鎖に つながれた 魂が、ひざを ついて いた。§f……セオだ。", "§8鎖は 街の 真ん中、記録塔の 上へ 続いて いる。"]);
    await say(p, "セオ", ["{closed,…}……来て、しまったのか。", "{cry,tears,up}僕は、あの 子を…… この 手で。……ここに いる 資格なんて、ない。", "{sad,low}影が 離れない。僕が 覚えて いる 全部に、からみついて いる"], "§a");
    await say(p, "エンマ", ["……影の 根は、邪神に ある。根を 断てば、鎖は 切れる。", "あとは、王の 魂が 言った とおりだ。§e名を 呼べ§f"], "§4");
    await tell(p, "あなた", [`§f……セオの 名前を、呼んだ。`]);
    if (t) { act(t, 0); emote(t, "q"); }
    await say(p, "セオ", ["{shock,…,up}……そうか。まだ、呼んで くれるのか。", "{closed,tears}……待つよ。記録塔の 上で"], "§a");
    await fade(t, "minecraft:basic_smoke_particle");
    s.theoSoul = 1; save(p, d);
  }
  save(p, d);
  clearScr(p);
}

/* 最終戦の 前: 邪神の 霧が 相棒を さらおうと する（モンスターには 宿れない）。きずなで 有利・不利 */
const TIERS = [0, 80, 250, 600, 900];
export function palOf(d) { return [...(d.party || []), ...(d.bench || []), ...(d.box || [])].find((m) => m && (m.id === d.partnerId || m.partner || m.look)) || null; }
/* 第125版: 邪神の 体（Gサイズ）を 場面に 立たせる。話す 人として 見つかる（mrpg:spk）・顔の 高さ（mrpg:hy）*/
function godBody(p, C) {
  const sid = SPECIES.god43 ? "god43" : null; if (!sid) return null;
  const G = C.mon(sid, 9, 0, 0, "veil"); if (!G) return null;
  let h = 4; try { const L = lookOf(sid, { sz: "G" }); setLook(G, sid, { sz: "G" }); G.setProperty("mrpg:size", Math.min(2500, Math.round(L.size * GBIG))); h = roomY(G, Math.max(2, Math.min(10, L.mh * GBIG * 0.85))); } catch {}
  try { G.nameTag = ""; G.addTag("mrpg_spkm"); G.setDynamicProperty("mrpg:spk", "邪神 ヴォルナグ"); G.setDynamicProperty("mrpg:hy", h); } catch {}
  return G;
}
const godTop = (G) => { try { const l = G.location, h = G.getDynamicProperty("mrpg:hy"); return { x: l.x, y: l.y + (typeof h === "number" ? h : 4), z: l.z }; } catch { return null; } };
export function tkFinalPre(p) { return calm(p, () => scene(p, (C) => _tkFinalPre(p, C))); }
async function _tkFinalPre(p, C) {
  const d = load(p); if (!d) return { wk: 0, add: [] };
  const m = palOf(d);
  const H = HERO(p, C);
  const pm = m ? C.mon(m.sp, 2, 1.5) : null;
  /* 玉座の 上の 影を 見上げる */
  sound(p, "mob.wither.ambient", 0.8); fx(p.dimension, "minecraft:soul_particle", spot(p, 7, 0, 3) || p.location, 20, 2);
  const G = godBody(p, C); if (G) { pillar(G, [0.55, 0.1, 0.75], 3); anim(G, "g_roar"); sound(p, "mob.enderdragon.growl", 0.6, 0.7); }   /* 玉座の 上に 邪神の 体。紫の 柱と 吠える 動き */
  lookUp(p, (G && godTop(G)) || spot(p, 8, 0, 6) || p.location);
  await say(p, "邪神 ヴォルナグ", ["……よく 来ました。覚えて おいて あげましょう。", "わたしは §5記録の 神§f。すべてを 書き留め、何ひとつ 手放さない 神。", "千年前、帳の 王に 命じました。石の 者は 死者だと 書けと。……書けば、その 魂は わたしの 頁に なった。あの 王は 筆を 折りましたが", "王に ささやいたのも、セオに ささやいたのも わたし。知りすぎた 者の 心は、よく 響く", "あなたには、わたしの ささやきが 届かない。……さびしい ことです", m ? `だから、その 子を いただきます。§e${m.nm || SPECIES[m.sp]?.name}§f。……ほら、あなたを 呼んで いますよ` : "……おや、ひとりですか。"], "§5");
  if (!m) return { wk: 0, add: [] };
  let nk = 0; try { nk = Number((exOf(p).nk || {})[m.id]) || 0; } catch {}
  const t = TIERS.filter((v) => nk >= v).length - 1;
  const nm = m.nm || SPECIES[m.sp]?.name;
  /* 黒い 霧が 相棒を 包む → 相棒が 牙を むき、衝撃で はじかれる */
  if (pm) { await shadowFlow(p, spot(p, 8, 0) || p.location, pm.location, 12); lookAt(p, pm); for (let k = 0; k < 10; k++) { const l = pm.location; fx(p.dimension, k % 2 ? "minecraft:soul_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(k) * 1.2, y: l.y + 0.3 + k * 0.1, z: l.z + Math.sin(k) * 1.2 }, 3, 0.2); await pause(2); } }
  sound(p, "mob.wolf.growl", 1); flash(p, "40 0 60"); shake(p, 0.7, 0.6); if (pm) { knockP(p, pm.location); await knock(H, pm.location, 2); await pause(10); act(H, "kneel"); }   /* 吹き飛んで ひざを つき、それから 身構えて 叫ぶ */
  await narr(p, "さらわれかける 相棒", [`§5黒い 霧が §e${nm}§5 を 包み、玉座の 奥へ 引きずって いく。`, "§7……モンスターには、影は 宿れない。だから 霧は、相棒ごと 常世の 底へ 連れ去ろうと して いる。", `§e${nm}§f は 足を ふんばり、§c${p.name}§f の 名前を 呼ぶ――`]);
  if (H) { act(H, "guard"); await hsay(p, C, { g: [`{rage,怒,jump}${nm}！ 離れちゃ だめ！ ……その 子を 返しなさいよ！`], o: [`{shock,!,up}${nm}！ 離れちゃ だめ！ ……その 子を 返して！`], c: [`{angry,!}${nm}、離れるな。……その 子を 返せ。`], t: [`{shock,!,up}${nm}！ 離れては いけません！ ……その 子を お返し ください！`] }); }
  let wk = 0, line;
  if (t >= 3) { wk = 3; line = `§a${nm}は 霧の 中で もがいて いる。§f中から 何度も、あなたを 呼び返して いる！ §7（きずなが 強い: 邪神の HP −30%）`; }
  else if (t >= 2) { wk = 1; line = `§e${nm}は 霧に 抵抗して いる。§7（きずな「相棒」: 邪神の HP −10%）`; }
  else { wk = -2; line = `§c${nm}は 霧に 引きずられかけて いる……！ §7（きずなが 弱い: 邪神の HP +20%。ガイドブックの きずなを 深めて 来ると 有利に なる）`; }
  /* 第113版: 森の 精霊の「守り手の 印」――二人で 一つ。ささやきは 片方（相棒）にしか 届かない。届かない あなたが 呼び戻す */
  const s0 = qs(d), mark = !!((s0.gate || {})[1] || (s0.keys || []).includes("k_spirit"));
  if (mark) {
    flash(p, "255 220 120"); sound(p, "beacon.activate", 1); fx(p.dimension, "minecraft:totem_particle", p.location, 12, 0.5); if (pm) fx(p.dimension, "minecraft:totem_particle", pm.location, 12, 0.5);
    await narr(p, "守り手の 印", [`§6あなたの 手の甲と、§e${nm}§6 の 額に、同じ 形の 光が 浮かんだ。`, "§7森の 精霊の 声が よみがえる。§a『この 子と あなた、二人で 一つの 印。片方が 連れ去られても、もう 片方が 呼べば 戻れる』", `§f……${nm} の 名前を、呼んだ。`]);
    if (pm) emote(pm, "heart");
    await say(p, `${nm}（相棒）`, [`……${p.name}。`, "……きこえる。ここ、だよ。"], "§e");
    if (wk < 0) { wk = 0; line = `§6守り手の 印が 霧を おさえた。§7（きずなが 弱くても、邪神の HP は ふえない）`; }
  }
  await narr(p, "きずな", [line]);
  return { wk, add: [{ sid: m.sp, lv: m.lv, q: 1, plus: Math.min(99, (m.plus || 0) + 10) }], pal: nm, t, sp: m.sp };
}
export function tkFinalPost(p, info) { return calm(p, () => scene(p, (C) => _tkFinalPost(p, info, C))); }
/* エピローグの 一場面ずつ（人を 1人 立たせて カメラを 寄せる）*/
const EPI = [
  ["§cムサシ", 19, "raise", "§cムサシ§f は クロガネの 工房で、§e封じる ためでは ない 鍔§f を 打った。帳の 王の 座に 供える ために。", "random.anvil_use"],
  ["§4エンマ", null, null, "§4エンマ§f は 閻魔の神殿の 玉座に 戻り、千年分の 帳を 書きなおして いる。§d石の 者は、一人も 載って いない。"],
  ["§dサヤ", "sayo", "cheer", "§dサヤ§f は クロガネで 目を 覚ました。最初に 言った ことばは「兄さま、おなか すいた」。"],
  ["§bレイ", 17, "hold", "§bレイ§f は しくじり帳の あの 一行の 下に、竜の 絵を 描いた。"],
  ["", null, null, "§a森の 精霊§f は 精霊石の 中で 目を さまし、シルヴァの 森へ 帰った。"],
  ["§7カゲツ", "kagetsu", "down", "§7そして カゲツは、ようやく ぐっすり 眠って いる。"],
];
async function _tkFinalPost(p, info, C) {
  if (!info || !info.pal) return;
  const H = HERO(p, C);
  const pm = info.sp ? C.mon(info.sp, 5, 0) : null;
  flash(p); if (pm) { lookAt(p, pm); await go(pm, spot(p, 1.4, 0), 14); emote(pm, info.t >= 2 ? "heart" : "q"); }
  await narr(p, "霧が 晴れる", [`§f黒い 霧が ほどけ、§e${info.pal}§f が 足もとに 転がって きた。`, info.t >= 2 ? "§a……しっぽを 振って、あなたの 手を なめた。" : "§7……しばらく ぼんやりして いたが、やがて あなたの 匂いを かいで、そばに 座った。"]);
  await say(p, `${info.pal}（相棒）`, ["……ただいま。"], "§e");
  if (H) await hsay(p, C, { g: ["{cry,tears,jump}……もう！ 心配 させないでよ、ばか！ ……おかえり！"], o: ["{cry,tears,up}……もう。心配 したんだから……おかえり。"], c: ["{cry,tears}……心配 させるな。……ばか。おかえり。"], t: ["{cry,tears,up}……もう！ ご心配 おかけして……おかえりなさい！"] });
  const G = godBody(p, C); if (G) anim(G, "hurt_big");   /* 崩れて いく 邪神の 体 */
  shake(p, 0.4, 1.2); fx(p.dimension, "minecraft:soul_particle", spot(p, 7, 0, 3) || p.location, 20, 2); lookUp(p, (G && godTop(G)) || spot(p, 8, 0, 6) || p.location);
  await say(p, "邪神 ヴォルナグ", ["……ああ。消える。忘れられて しまう。", "わたしは、ただ…… 誰の ことも、忘れたく なかった"], "§5");
  if (G) { anim(G, "hurt_big"); await pause(10); await fade(G, "minecraft:soul_particle"); }
  flash(p); sound(p, "item.book.page_turn", 1); fx(p.dimension, "minecraft:endrod", p.location, 24, 4);
  await narr(p, "白紙", ["§f世界じゅうの 石板の 文字が、すうっと 消えて いった。", "§7すべての 石板が §f白紙§7 に なった。", "§e記録は 封じる ものでは なく、終わらせる ものだった。"]);
  let prev = null;
  for (const [nm, job, pose, line, snd, after] of EPI) {   /* 場面を 切りかえて 一人ずつ。第124版(cam): 暗く なってから 前の 人を 下げ、次の 人を 立たせる */
    flash(p, "0 0 0"); await pause(2); if (prev) rmE(prev);
    let e = null;
    if (nm === "§4エンマ") e = C.mon("enma", 3.5, 0, 0, "none"); else if (job !== null) e = C.npc(nm, typeof job === "string" ? PJ(job, 8) : job, 3.5, 0, 0, "none");
    prev = e; if (e) { act(e, pose); camAt(p, spot(p, 1.5, 1.2, 1.5) || p.location, { x: e.location.x, y: e.location.y + 1.3, z: e.location.z }); } else fx(p.dimension, "minecraft:villager_happy", spot(p, 4, 0) || p.location, 10, 2);
    if (snd) sound(p, snd, 1);
    await narr(p, "エピローグ", [line]);
    if (e && after !== undefined) { act(e, after); emote(e, "bang"); await pause(14); }
  }
}
/* 第125版: 常世編の 結末。邪神を 倒した 朝、ルミナの 牧場で 石に なった 者たちが 戻り、ヒロインが 生き返り、セオが 帰る（1回だけ）*/
export async function tkStoneBack(p) {
  const d = load(p); if (!d) return false; const s = qs(d); if (s.stoneBack) return false;
  if (!s.ending) return false;
  const back = !!(s.heroDead && !s.heroBack), theo = !s.theoBack;
  s.stoneBack = 1; s.heroBack = 1; s.theoBack = 1;
  { const h = heroOf(p); s.techo = [...new Set([...(s.techo || []), ...(h ? [h.name] : []), "セオ"])]; }
  save(p, d);
  await calm(p, () => scene(p, (C) => _tkStoneBack(p, C, back, theo)));
  return true;
}
async function _tkStoneBack(p, C, back, theo) {
  try { p.runCommand("camera @s fade time 0.5 1.0 0.8 color 255 255 255"); } catch {}
  big(p, " ", "§7― 常世から 戻った 朝 ルミナの 牧場 ―"); await pause(10);   /* 第124版(cam): 白く なってから 立たせる */
  const Hk = C.mon(HAKU_SP, 5, 0.6, 0, "none"), Dr = C.mon(REI_DRAGON_SP, 6.5, 3.2, 0, "none"), Pc = C.npc("§dピコ", PJ("pico", 8), 4.2, -0.6, 0, "none"), G = C.npc("§7ガロ", PJ("garo", 9), 3.2, -2.2, 0, "none"), O = C.npc("§eオルド", PJ("ordo", 8), 3.4, 2, 0, "none"), R = C.npc("§bレイ", 17, 4.6, 3.6, 0, "none");
  for (const [e, n] of [[Hk, "§7ハク（石）"], [Dr, "§7竜の 石像"]]) if (e) try { e.nameTag = n; } catch {}
  act(Pc, "down"); act(G, "sad"); act(O, "hold"); act(R, "hold"); stoneFx(p, Hk, 8); stoneFx(p, Dr, 8);
  if (Hk) camAt(p, spot(p, 1.4, -1.6, 1.8) || p.location, { x: Hk.location.x, y: Hk.location.y + 1, z: Hk.location.z });
  await pause(20);
  await narr(p, "ルミナの 牧場", ["§7牧場の すみに、石の §fハク§7 と、§fレイの 竜§7 の 石像。", "§7ハクの 背中に もたれて、§dピコ§7 が 眠って いる。"]);
  sound(p, "random.break", 1); shake(p, 0.25, 0.4); if (Hk) emote(Hk, "bang"); await pause(14);
  sound(p, "dig.stone", 1); stoneFx(p, Hk, 14); shake(p, 0.35, 0.6); await pause(10);
  flash(p); sound(p, "random.levelup", 0.8); if (Hk) { fx(p.dimension, "minecraft:totem_particle", Hk.location, 16, 1); try { Hk.nameTag = "§fハク"; } catch {} }
  await narr(p, "白い 毛", ["§fハクの 背中の 灰色が、ひびの ように 割れて 落ちて いく。", "§fその 下から、§l白い 毛§r§f が のぞいて いた。"]);
  if (O) { await go(O, spot(p, 4.4, 1.2), 10, true); act(O, "kneel"); }
  if (Hk) emote(Hk, "heart");
  await talk(p, "オルド", ["{shock,…,up}……ハク。", "{smile,tears,up}ほっほ……ほっほっほ！ ……遅いわい、この 寝ぼすけ が！"], "§e");
  if (Dr) { lookAt(p, Dr); stoneFx(p, Dr, 14); sound(p, "mob.enderdragon.flap", 0.8); system.runTimeout(() => sound(p, "mob.horse.breathe", 0.6), 6); try { Dr.nameTag = "§bレイの 竜"; } catch {} emote(Dr, "q"); }
  await narr(p, "竜", ["§f隣では、レイの 竜が 大きな §eあくび§f を した。"]);
  if (R) { act(R, "up"); await talk(p, "レイ", ["{shock,!,jump}……おまえ……！", "{cry,tears,up}……寝坊 しすぎだ、ばか。"], "§b"); }
  if (Pc) { lookAt(p, Pc); act(Pc, 0); emote(Pc, "q"); }
  await talk(p, "ピコ", ["{closed,…}……兄ちゃん？", "{shock,?}……ここ、どこ？ 屋根、ある ね"], "§d");
  if (G && Pc) { await go(G, spot(p, 3.6, -1.4), 10, true); act(G, "hold"); }
  await narr(p, "帽子", ["§7ガロは 何も 言わずに、腰から 帽子を 外して、ピコの 頭に 深く かぶせた。"]);
  /* 丘の 上の 墓で */
  const h = heroOf(p), hn = h ? h.name : "";
  let H = null;
  if (back && h) {
    flash(p, "0 0 0"); const gq = spot(p, 7, -1);
    if (gq) { camAt(p, spot(p, 2, -2.5, 1.6) || p.location, gq); for (let k = 0; k < 6; k++) { fx(p.dimension, "minecraft:endrod", { x: gq.x, y: gq.y + 0.4 + k * 0.4, z: gq.z }, 6, 0.6); await pause(4); } }
    await narr(p, "丘の 上の 墓", ["§7丘の 上の 小さな 墓に、空から 光の 糸が 一本、降りて きた。", "§f……墓の 前に、だれかが 立って いる。"]);
    H = C.npc(`§d${hn}`, PJ(h.key, 9), 9, -1); if (H) { lookAt(p, H); await go(H, spot(p, 2.4, -0.4), 26); act(H, "up"); }
    if (H) { camAt(p, spot(p, 1.2, -0.9, 1.6) || p.location, { x: H.location.x, y: H.location.y + 1.5, z: H.location.z }); } await pause(30);   /* 第124版(dir#42): 寄って、音の ない 間 */
    await talk(p, hn, hv(p, { g: ["{closed,…}……ただいま。"], o: ["{closed,…}……ただいま。"], c: ["{closed,…}……ただいま。"], t: ["{closed,…}……ただいま、戻りました。"] }), "§d");
    { const m = palOf(load(p) || {}); const pe = m ? C.mon(m.sp, 6, 1.6) : null; if (pe) { lookAt(p, pe); await go(pe, spot(p, 2, -0.2), 10, true); emote(pe, "heart"); sound(p, "random.pop", 0.6); } }   /* 相棒が 駆け寄る（死ぬ ときの「……おきて」を 受ける）*/
    await talk(p, hn, hv(p, { g: ["{smile,tears}……ちゃんと、起きたよ。"], o: ["{smile,tears}……ちゃんと、起きたわ。"], c: ["{smile,tears}……起きた。ちゃんと。"], t: ["{smile,tears}……ちゃんと、起きましたよ。"] }), "§d");
    if (H) { await go(H, spot(p, 1.3, -0.2), 10); act(H, 23); emote(H, "heart"); }   /* 近づいて 手を とる */
    await talk(p, hn, hv(p, { g: ["{smile,tears,up}……ねえ。手帳、ちゃんと 持ってて くれた？"], o: ["{smile,tears,up}……ねえ。手帳、ちゃんと 持ってて くれたの？"], c: ["{smile,tears,up}……手帳。持ってて くれた？"], t: ["{smile,tears,up}……あの。手帳、ちゃんと 持って いて くださいましたか？"] }), "§d");
    if (H) { act(H, "hold"); sound(p, "item.book.page_turn", 1); await pause(12); act(H, 0); }   /* 手帳を 返す */
    if (O) { act(O, 0); await talk(p, "オルド", ["{cry,tears,up}……ほっ、ほ……。……おかえり。"], "§e"); }
  }
  if (theo) {
    if (back && H) { camAt(p, spot(p, -3, 2.5, 3.5) || p.location, spot(p, 4, 0, 1) || p.location); await pause(40); }   /* 第124版(dir#43): セオが 来る 前に 引きの 絵で 余韻 */
    const T = C.npc("§aセオ", 18, 11, 2.5);
    if (T) { lookAt(p, T); await go(T, spot(p, 4.6, 0.8), 30); act(T, "sad"); }
    await narr(p, "牧場の 入口", ["§7道の 向こうから、一人の 学者が 歩いて きた。§f……セオだ。", "§8影は もう ない。でも、影の 中で 見た ことは、ひとつも 忘れて いなかった。"]);
    act(T, "kneel");   /* 頭を 下げる */
    await talk(p, "セオ", ["{closed,…}……全部、覚えて いる。槍を 向けた ことも。君たちの 顔も。", hn ? `{cry,tears,up}${hn}。……ごめん。僕は、君を――` : "{cry,tears,up}……ごめん。僕は――"], "§a");
    if (H) {
      act(H, "hold"); sound(p, "item.book.page_turn", 1);
      await talk(p, hn, hv(p, { g: ["{angry,!,up}……知ってる。わたし、死んでたんだから。", "{sad}許すとか、許さないとか、まだ わかんない。……でも"], o: ["{sad,up}……知ってるわ。わたし、死んでたんだもの。", "{sad}許すとか、許さないとか、まだ わからないの。……でも"], c: ["{closed}……知ってる。わたし、死んでた。", "{sad}許すか どうかは、まだ 決めて ない。……でも"], t: ["{sad,up}……存じて います。わたし、死んで いたのですから。", "{sad}許すとか、許さないとか、まだ わかりません。……でも"] }), "§d");
      await narr(p, "手帳の 名簿", [`§d${hn}§f は 手帳の 名簿を 最初の 頁から 一人ずつ たどった。`, "§fそして、一人ずつの 名前の 横に、小さく 書きこんで いった。§e『おかえり』", "§f最後に、名簿の いちばん 下の 行に、§aセオ§f の 名前を 書き足した。"]);
      await talk(p, hn, hv(p, { g: ["{smile,tears,up}はい。……セオさんも、おかえり。"], o: ["{smile,tears,up}はい。……セオさんも、おかえりなさい。"], c: ["{smile,tears,up}……ほら。セオも、おかえり。"], t: ["{smile,tears,up}はい。……セオさんも、おかえりなさい。"] }), "§d");
    } else await narr(p, "手帳の 名簿", ["§f旅の 手帳の 一人ずつの 名前の 横に、小さく 書きこんだ。§e『おかえり』", "§f最後に、名簿の いちばん 下の 行に、§aセオ§f の 名前を 書き足した。"]);
    act(T, "up"); await talk(p, "セオ", ["{shock,…,up}……僕の 名前も、書くのか。", "{closed,tears}……ありがとう。"], "§a");
    if (T) { camAt(p, spot(p, 1.4, 1.2, 1.6) || p.location, { x: T.location.x, y: T.location.y + 1.5, z: T.location.z }); await pause(6); }
    await talk(p, "セオ", ["{smile,up}僕は 旅に 戻るよ。§e嘘を 書かない 記録§f を 書く。……それが、僕に できる ことだから"], "§a");
    if (T) { act(T, 0); await exit(p, T, 14); }   /* 第124版(cam): 映らない 所まで 歩いて 去る */
  } else if (H) await narr(p, "手帳の 名簿", [`§d${hn}§f は 手帳の 名簿の 一人ずつの 名前の 横に、小さく 書きこんだ。§e『おかえり』`]);
  flash(p, "0 0 0"); lookUp(p, spot(p, 8, 0, 8) || p.location); sound(p, "beacon.activate", 0.8);
  for (let k = 0; k < 5; k++) { fx(p.dimension, "minecraft:endrod", spot(p, 4, 0, 3 + k) || p.location, 6, 5); await pause(4); }
  await narr(p, "各地で", ["§f石に なって いた 人たちも、各地で 目を さました。", "§aベリルの 一座の 人たち§f も、宵闇の §aヨミ§f も。§fクロガネでは §dサヤ§f が。", "§f闘技場の 奥の 王座でも、石の §6ゼファード§f が 二十年分の 息を 吐いて、立ち上がった。"]);
  await epiLinks(p, C, H, hn, theo);
  if (H) { act(H, "cheer"); await talk(p, hn, hv(p, { g: ["{smile,☆}……最後の 頁、やっと 書けた。", "{smile,♪,jump}次は どこ 行く？ 地図、まだ 半分も 描けて ないんだから！"], o: ["{smile}……最後の 頁、やっと 書けたわ。", "{smile,up}次は どこへ 行く？ 地図、まだ 半分も 描けて ないのよ。"], c: ["{smile}……最後の 頁、書けた。", "{smile,up}次は どこ。地図は まだ 半分も 描けて ない。"], t: ["{smile,☆}……最後の 頁、やっと 書けました。", "{smile,up}次は どこへ 行きましょう？ 地図は まだ 半分も 描けて いませんから！"] }), "§d"); }
  big(p, "§b§lおかえり", "§f石に なった 者たちと、大事な 二人が 帰って きた", "random.levelup");
  await pause(30);
}


/* 第125版: すべてが つながる（常世から 戻った 朝の 各地）。場面は 暗転で つなぎ、人は 歩いて 来る・寄る カメラ */
const DREAM_T = ["牧場で のんびり したい", "また 新しい 旅に 出たい", "旅で 会った みんなに 会いに 行きたい"];
async function shotIn(p, C, nm, job, dist, sd, to) { const e = C.npc(nm, job, to, sd); if (e) await arrive(e); return e; }   /* 第124版(fix2): 映すのは 次の pushCam（2回 撮らない）*/   /* 第124版(cam): 映らない 所から 歩いて 来て、着いてから 映す */
function pushCam(p, e, k0 = 5, k1 = 2.2) { if (!e) return; const l = e.location, L = { x: l.x, y: l.y + 1.3, z: l.z }; camShot(p, e, spot(p, Math.max(0.5, 4 - k0), 1.2, 2.6) || p.location, L, 0.7); const n = camN(p); system.runTimeout(() => { if (camN(p) === n && e.isValid()) camAt(p, spot(p, Math.max(0.5, 4 - k1), 0.6, 1.6) || p.location, L, 1.4); }, 12); }   /* 第124版(cam): なめらかに 寄ってから ゆっくり 押す（急に 切りかえない）*/
async function epiLinks(p, C, H, hn, theo) {
  const d = load(p), s = d ? qs(d) : {}, x = s.epx || {};
  const R = []; const card = (t) => big(p, " ", `§7― ${t} ―`);
  try {
    /* 手帳の 最後の 頁（竜祭りの 答え）*/
    if (H) {
      act(H, "hold"); sound(p, "item.book.page_turn", 1); camAt(p, spot(p, 1, -1.2, 1.4) || p.location, { x: H.location.x, y: H.location.y + 1.1, z: H.location.z }, 0.8); await pause(10);
      const a = typeof x.dream === "number" && DREAM_T[x.dream] ? `『この 旅が 終わったら、${DREAM_T[x.dream]}』` : "『この 旅が 終わったら』";
      await narr(p, "手帳の 最後の 頁", [`§d${hn}§f は 手帳の 最後の 頁を ひらいて、竜祭りの 夜の 答えを 書いた。`, `§f${a}§7 ……その 下に、二人の 名前を ならべて。`]);
    }
    /* ルミエ: セオと 弟 */
    if (theo) {
      flash(p, "0 0 0"); card("ほたるの 里 ルミエ"); await pause(8);
      const B = C.npc("§fセオの 弟", PJ("m6_sota", 9), 4, 1.2, 0, "veil"); R.push(B); act(B, "up");
      const T = await shotIn(p, C, "§aセオ", 18, 4, -1.2, 3.4); R.push(T);
      if (B) { pushCam(p, B); stoneFx(p, B, 10); await pause(12); }
      await narr(p, "ほたるの 里", ["§7ピピが 毎日 話しかけて いた 石の 少年に、ひびが 走った。", "§f……灰色の 下から、小さな 指が 動いた。"]);
      if (T) { act(T, "kneel"); pushCam(p, T, 4, 1.8); await pause(8); }
      await talk(p, "セオ", ["{cry,tears,up}……ただいま。……いや、おかえり、か。", "{closed,tears}十二年、一日も 忘れられなかった。……忘れなくて、よかった。"], "§a");
      await talk(p, "セオの 弟", ["{smile,?,up}……にいちゃん？ ……本、よんで。"], "§f");
    }
    /* コラリア: 姉妹が 紐を 編み上げる */
    flash(p, "0 0 0"); card("さんごの 町 コラリア"); await pause(8);
    { const M = await shotIn(p, C, "§3マリン", PJ("marin", 9), 4, -0.9, 3.4), N = await shotIn(p, C, "§6ナギサ", PJ("nagisa", 9), 4, 0.9, 3.4); R.push(M, N); act(M, "hold"); act(N, "hold");
      if (M) { pushCam(p, M); await pause(8); }
      if ((qs(load(p) || {}).epx || {}).cord6) {   /* 第124版: 紐の 場面（おっとうの 編み目）を 見た 人だけ */
      await narr(p, "二人の 紐", ["§7ほどきかけだった 紐の 最後の 一目を、姉と 妹が いっしょに 結んだ。"]);
      await talk(p, "マリン", ["{smile,tears,up}……できた。おっとうの 編み目と、わたしたちの 編み目。"], "§3");
      if (N) { pushCam(p, N, 4, 1.8); await pause(6); }
      await talk(p, "ナギサ", ["{smile,tears,up}……渡しに 行こう。闘技場の 奥で、おっとうが 起きたって。"], "§6");
      } else {
      await narr(p, "さんごの 浜", ["§7石に なって いた 港の 人たちが、浜に 出て 朝の 海を 見て いた。"]);
      await talk(p, "マリン", ["{smile,up}……海、また 青く なったね。"], "§3");
      if (N) { pushCam(p, N, 4, 1.8); await pause(6); }
      await talk(p, "ナギサ", ["{smile}……うん。今日は、潮が 素直。"], "§6");
      } }
    /* ソウラ: 妃が 戻り、アルゴが 泣く */
    flash(p, "0 0 0"); card("たましいの 町 ソウラ"); await pause(8);
    { const Mo = C.npc("§5冥王 モルテ", PJ("morte", 15), 4.4, -1.4), A = C.npc("§4アルゴ", PJ("argo", 10), 4.4, 1.4); R.push(Mo, A);
      const Q = C.npc("§d冥王の 妃", PJ("rosa", 8), 9, 0, 0, "smoke"); R.push(Q); if (Q) { lookAt(p, Q); await glowWalk(p, Q, spot(p, 5, 0), 22); }
      await narr(p, "川べり", ["§7石に なって 十年。川べりに、冥王の 妃が 立って いた。"]);
      if (Mo) { pushCam(p, Mo, 4, 1.8); await pause(6); }
      await talk(p, "モルテ", ["{smile,tears,up}……おかえり。……赤い 灯籠を、流して おいたぞ。"], "§5");
      if (A) { act(A, "kneel"); face(A, "cry", 80); tears(A, 60); pushCam(p, A, 4, 1.6); sound(p, "mob.villager.no", 1, 0.4); await pause(10); }
      await narr(p, "アルゴ", ["§7仮面の ない 顔で、アルゴが ひざを ついた。", "§f……う、あ……ああああ……！ §7はじめて、声を 上げて 泣いた。"]);
      if (Mo) { pushCam(p, Mo, 3.5, 1.6); await pause(6); }
      await talk(p, "モルテ", ["{closed,up}……泣いて よい。十年、だれよりも 泣かずに 来た 兵で あろう。"], "§5"); }
    /* ルミナの 門: ゴンザ */
    flash(p, "0 0 0"); card("始まりの町 ルミナ 北の 門"); await pause(8);
    { const G = C.npc("§e門番 ゴンザ", PJ("m6_takeru", 8), 4.4, 0, 0, "veil"); R.push(G); act(G, "raise");
      const Mi = await shotIn(p, C, "§eミミ", PJ("mimi", 8), 4, -1.8, 4.2), Be = await shotIn(p, C, "§7ベリル", PJ("beryl", 9), 4, 1.8, 4.2); R.push(Mi, Be);
      if (G) { pushCam(p, G, 5, 2); await pause(8); }
      await talk(p, "ゴンザ", ["{smile,tears,up}……門を あけて 待って おったでござる。", "{smile,☆,up}みなさま、§eおかえりなさいでござる§f！！"], "§e");
      fx(p.dimension, "minecraft:totem_particle", G ? G.location : p.location, 14, 2); sound(p, "firework.blast", 0.7); }
  } finally { if (R.some((e) => e && e.isValid())) { flash(p, "0 0 0"); await pause(3); } for (const e of R) rmE(e); }   /* 第124版(cam): 暗転の 中で 下げる */
}

/* 第126版: 一冠 ベルガが 握って いた 王の 鎖。王妃 セレネと 千年前の 王 ヴァルグレイドの 魂（第125版の 場面を 受けつぐ）*/
async function valgreid(p, C, s, d) {
  const se = C.npc("§d王妃 セレネの 魂", PJ("selene", 8), 10, -1.4, 0, "smoke"); act(se, 0);
  if (se) { lookAt(p, se); await glowWalk(p, se, spot(p, 3.6, -1), 26); }
  await say(p, "王妃 セレネ", ["{sad,?,up}……あの人。あなた、まだ そこに いるの？"], "§d");
  flash(p, "255 200 80"); sound(p, "beacon.power", 0.8); fx(p.dimension, "minecraft:totem_particle", p.location, 12, 0.6); await pause(10);
  const V = C.npc("§6王 ヴァルグレイドの 魂", PJ("arca13", 15), 9, 1.6, 0, "smoke"); if (V) { lookAt(p, V); await go(V, spot(p, 4.2, 1.6), 24); emote(V, "dots"); }
  await say(p, "ヴァルグレイドの 魂", ["……ああ。ここに いる。ベルガが 握って いた 影の 鎖が、今 ほどけた。", "{smile,closed}セレネ。……あの 一日は、楽しかった"], "§6");
  if (ok(se) && ok(V)) { const a = se.location, b = V.location, n = Math.hypot(a.x - b.x, a.z - b.z) || 1; await go(se, { x: b.x + ((a.x - b.x) / n) * 1.2, y: b.y, z: b.z + ((a.z - b.z) / n) * 1.2 }, 14); act(se, "hold"); }   /* 王の そばへ */
  await say(p, "王妃 セレネ", ["{smile,tears,up}……そう。楽しかった、のね。", "{smile,closed}わたしも。"], "§d");
  await fade(se, "minecraft:white_smoke_particle");
  const mi = C.npc("", PJ("mira", 8), 4, -1.5); act(mi, "bow"); if (mi) { lookAt(p, mi); await pause(20); await fade(mi, "minecraft:endrod"); }
  if (V) { lookAt(p, V); act(V, "kneel"); }
  await say(p, "ヴァルグレイドの 魂", ["……石板の 王と 呼ばれた 者だ。千年前、わたしは 知りすぎて、影に 飲まれた。", "わたしを 斬ったのは、友の §6アルディス§f。……人々は 彼の 名を 壁画から 削った。王殺しの 裏切り者と して。"], "§6");
  await say(p, "ヴァルグレイドの 魂", ["{sad,up}アルディス。……すまなかった。おまえに、千年分の 汚名を 着せた"], "§6");
  await narr(p, "王の 隣の 影", ["§7あなたが 見た、廃都の 壁画の 削られた 影。§fそれが アルディスだった。"]);
  act(V, 0);
  /* 第125版: すべてが つながる。王の 後ろで、セオの 魂が 同じ ことばを あなたに */
  { const T = C.npc("§aセオの 魂", 18, 9, -2.6, 0, "smoke");
    if (T) { await glowWalk(p, T, spot(p, 5.2, -2.2), 22); act(T, "kneel"); camAt(p, spot(p, 2.2, -0.6, 1.6) || p.location, { x: T.location.x, y: T.location.y + 1.2, z: T.location.z }, 0.8); await pause(10); }
    await say(p, "セオの 魂", ["{sad,up}……すまなかった。", "{closed}君に、汚名じゃ なくて……もっと 重い ものを 着せた。"], "§a");
    if (T) { act(T, 0); await fade(T, "minecraft:endrod"); } }
  { flash(p, "60 0 80"); sound(p, "beacon.power", 0.5); fx(p.dimension, "minecraft:portal_reverse_particle", spot(p, 6, 2.5, 1) || p.location, 14, 0.8); s.gezGlow = 1; save(p, d);
    await narr(p, "虚神の 石板", ["§5……どこかで、§d虚神ゲゼラ§5 の 石板が、一度だけ 静かに 光った。", "§8王の 捨てた 怒りが、中身の ない 器の 中で、何かを 待って いる。"]); }
  await say(p, "ヴァルグレイドの 魂", ["……おまえの 友も、わたしと 同じ 道を 歩かされた。記録の 力を 持つ 学者だ。", "{closed}影と 魂を 切りはなす 方法を、わたしは 千年 かけて 知った。"], "§6");
  await say(p, "ヴァルグレイドの 魂", ["{up}影は、知った ことに 宿る。……廃都の 台座の 残りは、こうだ。『§e名を 呼ぶ 声には 宿れぬ§f』。", "§e大切な 者が その 名を 呼び、書き記せば、影は 魂を つかめなく なる§f。……覚えて おけ。最後に 要る"], "§6");
  s.valgreid = 1; save(p, d);
  if (V) { act(V, "up"); await glowWalk(p, V, spot(p, 8, 2.5), 20); }
  await fade(V, "minecraft:endrod");
  await narr(p, "王宮の区", ["§7王の 魂は、光に なって 空へ のぼった。§8……千年ぶりに、空の 色を 見に 行った ようだった。"]);
}

/* 第126版: 区に 入ると 起きる 前ぶれ（ruins.js が 2秒に 1回 よぶ。粒は 少なめ）*/
const OMT = new Map();
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => OMT.delete(playerId)); } catch {}
const OMEN = [
  "§7どこかで、サイコロを 振る 音が する……", "§5見えない 糸が、肩に ふれた……", "§b足もとの 水たまりに、知らない 家族が 映った……", "§6蹄の 音が、近づいては 遠ざかる……", "§2地面の 下で、なにかが 首を もたげた……",
  "§9こうもりの 羽音。……昼 なのに、空が 暗い", "§e空に、大きな 目が ひらいた。……こちらを 見て いる", "§8……音が、消えた", "§7重い 鎧の 足音が、地面を ゆらす……", "§5「ひざまずけ」 §7……声が、頭の 中に ひびいた",
];
export function tkOmen(p, i, dd, q) {
  try {
    const o = OMT.get(p.id) || { i: -1, n: 0 }; if (o.i !== i) { o.i = i; o.n = 0; } o.n++; OMT.set(p.id, o);
    const dim = p.dimension, l = p.location, dx = q.x - l.x, dz = q.z - l.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L;
    if (o.n === 1 || o.n % 12 === 0) try { p.onScreenDisplay.setActionBar(OMEN[i]); } catch {}
    const P = (id, x, y, z) => { try { dim.spawnParticle(id, { x, y, z }); } catch {} };
    if (i === 6) {   /* 空の 大きな 目: ゆっくり ひらき、どこに いても こちらを 向く */
      const op = Math.min(1, o.n / 6), c = { x: l.x + ux * 22, y: l.y + 24, z: l.z + uz * 22 }, rx = -uz, rz = ux;
      for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2; P("minecraft:endrod", c.x + rx * Math.cos(a) * 6, c.y + Math.sin(a) * 2.6 * op, c.z + rz * Math.cos(a) * 6); }
      if (op > 0.3) for (let k = 0; k < 4; k++) P("minecraft:redstone_ore_dust_particle", c.x + rx * (k - 1.5) * 0.6, c.y, c.z + rz * (k - 1.5) * 0.6);
      if (o.n % 5 === 0) sound(p, "ambient.weather.thunder", 0.8, 0.3);
    } else if (i === 7) { try { p.runCommand("stopsound @s"); } catch {} }   /* 静寂: 足音も 音も 消える */
    else if (i === 8) { if (o.n % 3 === 0) try { p.runCommand("camerashake add @s 0.15 0.4 positional"); } catch {} sound(p, "mob.irongolem.walk", 0.6); }
    else {
      const S = ["random.click", "mob.spider.say", "block.amethyst_block.chime", "mob.horse.gallop", "mob.enderdragon.growl", "mob.bat.idle", null, null, null, "mob.wither.ambient"][i];
      if (S && o.n % 2 === 1) sound(p, S, 1, i === 4 || i === 9 ? 0.25 : 0.6);
      const a = { x: l.x + ux * 6, y: l.y + 1, z: l.z + uz * 6 };
      if (i === 1) for (let k = 0; k < 6; k++) P("minecraft:endrod", l.x + ux * 0.6, l.y + 2 + k * 1.5, l.z + uz * 0.6);
      else for (let k = 0; k < 3; k++) P(TK_PT[i], a.x + (Math.random() - 0.5) * 4, a.y + Math.random() * 2, a.z + (Math.random() - 0.5) * 4);
    }
  } catch {}
}
