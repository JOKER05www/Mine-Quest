// v2.2.3: 石板の 中の 世界（だだっ広い テーマ別エリア）。コマンドの 列を 作るだけ（マイクラに 依存しない）
import { rollTier, lvBonus, chestCmds, BASE_OF } from "./chests.js";
import { bk } from "./stage.js";
import { BOSS_SLAB } from "./data.js";

// fl=床 fl2=まだら base=床下 wall=外周 ceil=天井(閉じた 場所) light=床の 明かり feats=[[種類, 100ブロック²あたり の 数]]
export const DG_THEMES = {
  forest: { name: "深き森", fl: "grass_block", fl2: ["moss_block", "podzol", "coarse_dirt"], base: "dirt", wall: "oak_log", light: "ochre_froglight",
    feats: [["tree_oak", 0.55], ["tree_dark", 0.2], ["grass", 1.6], ["flower", 0.7], ["pond", 0.05], ["rock", 0.12], ["hill", 0.05]], fams: ["animal", "animal", "beast", "animal"] },
  cherry: { name: "桜の園", fl: "grass_block", fl2: ["moss_block", "pink_wool"], base: "dirt", wall: "cherry_log", light: "pearlescent_froglight",
    feats: [["tree_cherry", 0.45], ["grass", 1.2], ["flower", 1.0], ["pond", 0.06], ["lantern", 0.1]], fams: ["animal", "animal", "beast", "blob"] },
  snow: { name: "白銀の 雪原", fl: "snow", fl2: ["packed_ice", "powder_snow_safe", "blue_ice"], base: "packed_ice", wall: "packed_ice", light: "sea_lantern",
    feats: [["tree_spruce", 0.3], ["spike", 0.12], ["hill", 0.08], ["rock_ice", 0.15]], fams: ["aqua", "beast", "dragon", "golem"] },
  sea: { name: "浅き 海", fl: "sand", fl2: ["gravel", "prismarine", "clay"], base: "stone", wall: "prismarine_bricks", light: "sea_lantern", water: true,
    feats: [["island", 0.07], ["reef", 0.25], ["pillar_sea", 0.06]], fams: ["aqua", "aqua", "blob", "animal"] },
  desert: { name: "灼熱の 砂漠", fl: "sand", fl2: ["sandstone", "red_sand", "smooth_sandstone"], base: "sandstone", wall: "smooth_sandstone", light: "glowstone",
    feats: [["dune", 0.12], ["cactus", 0.35], ["deadbush", 0.5], ["ruin_pillar", 0.08], ["bones", 0.05]], fams: ["golem", "nether", "animal", "dragon"] },
  volcano: { name: "火の 山", fl: "blackstone", fl2: ["basalt", "smooth_basalt", "magma"], base: "blackstone", wall: "basalt", light: "shroomlight",
    feats: [["lavapool", 0.06], ["hill_basalt", 0.08], ["pillar_basalt", 0.14], ["rock_obs", 0.1]], fams: ["dragon", "nether", "golem"] },
  cave: { name: "地底の 洞窟", fl: "stone", fl2: ["deepslate", "tuff", "gravel", "andesite"], base: "stone", wall: "deepslate", ceil: "stone", light: "glowstone",
    feats: [["stalag", 0.3], ["pond", 0.04], ["rock", 0.2], ["ore", 0.15]], fams: ["golem", "nether", "animal", "nether"] },
  crystal: { name: "水晶の 洞", fl: "calcite", fl2: ["amethyst_block", "tuff", "smooth_basalt"], base: "calcite", wall: "amethyst_block", ceil: "calcite", light: "sea_lantern",
    feats: [["crystal", 0.25], ["stalag_am", 0.15], ["pond", 0.04]], fams: ["golem", "blob", "nether", "dragon"] },
  ruins: { name: "古の 都", fl: "stone_bricks", fl2: ["mossy_stone_bricks", "cracked_stone_bricks", "cobblestone", "mossy_cobblestone"], base: "stone", wall: "stone_bricks", light: "lantern_post",
    feats: [["ruin_room", 0.06], ["ruin_pillar", 0.12], ["grass", 0.5], ["rock", 0.08]], fams: ["nether", "sword", "golem", "beast"] },
  sky: { name: "空の 浮島", fl: "grass_block", fl2: ["moss_block", "quartz_block"], base: "dirt", wall: "barrier", light: "glowstone", sky: true,
    feats: [["tree_oak", 0.25], ["flower", 0.8], ["grass", 1.0]], fams: ["animal", "dragon", "blob", "animal"] },
  swamp: { name: "霧の 沼地", fl: "mud", fl2: ["moss_block", "grass_block", "packed_mud"], base: "dirt", wall: "mangrove_log", light: "verdant_froglight",
    feats: [["pond", 0.18], ["tree_mangrove", 0.3], ["grass", 1.0], ["stump", 0.1]], fams: ["animal", "aqua", "nether", "blob"] },
  mushroom: { name: "きのこの 森", fl: "mycelium", fl2: ["podzol", "moss_block"], base: "dirt", wall: "mushroom_stem", light: "shroomlight",
    feats: [["mushroom_big", 0.28], ["mushroom_small", 0.6], ["hill", 0.04]], fams: ["animal", "blob", "animal"] },
  underworld: { name: "冥府の 谷", fl: "soul_soil", fl2: ["soul_sand", "bone_block", "blackstone"], base: "blackstone", wall: "polished_blackstone_bricks", ceil: "blackstone", light: "shroomlight",
    feats: [["bones", 0.15], ["pillar_bone", 0.12], ["lavapool", 0.03], ["soul_lantern", 0.12]], fams: ["nether", "nether", "dragon"] },
  void: { name: "虚空の 島々", fl: "end_stone", fl2: ["end_stone_bricks", "purpur_block", "obsidian"], base: "end_stone", wall: "barrier", light: "end_rod_post", sky: true,
    feats: [["pillar_purpur", 0.12], ["rock_obs", 0.1], ["crystal", 0.05]], fams: ["nether", "dragon", "nether", "golem"] },
  palace: { name: "王冠の 宮殿", fl: "polished_blackstone_bricks", fl2: ["gold_block", "gilded_blackstone", "chiseled_polished_blackstone"], base: "blackstone", wall: "polished_blackstone_bricks", ceil: "polished_blackstone_bricks", light: "glowstone",
    feats: [["palace_pillar", 0.12], ["carpet", 0.1], ["ruin_room", 0.03]], fams: ["dragon", "sword", "nether", "golem"] },
};
// 石板ごとの テーマ（主・副）
export const SLAB_THEMES = [["forest", "swamp"], ["sea", "cave"], ["forest", "mushroom"], ["forest", "sky"], ["volcano", "ruins"], ["sky", "cherry"], ["ruins", "cave"], ["cave", "sea"], ["void", "cherry"], ["volcano", "cave"],
  ["desert", "underworld"], ["crystal", "snow"], ["sky", "sea"], ["volcano", "underworld"], ["sea", "void"], ["swamp", "mushroom"], ["forest", "cherry"], ["underworld", "ruins"], ["crystal", "mushroom"], ["void", "crystal"],
  ["ruins", "desert"], ["sky", "cave"], ["void", "underworld"], ["snow", "crystal"], ["desert", "ruins"], ["underworld", "cave"], ["ruins", "sky"], ["mushroom", "void"], ["volcano", "void"], ["palace", "palace"]];
const ALL = Object.keys(DG_THEMES).filter((k) => k !== "palace");
export const ALL_THEMES = ALL;
export function themeFor(i, f, r) {
  const o = BOSS_SLAB[i] ? BOSS_SLAB[i].old : i;
  const [a, b] = SLAB_THEMES[o] || ["forest", "cave"];
  if (o === SLAB_THEMES.length - 1) return f === 0 ? "palace" : ALL[Math.floor(r() * ALL.length)];   // 王冠: いろいろな 世界を 越えて いく
  const x = r();
  return x < 0.45 ? a : x < 0.8 ? b : ALL[Math.floor(r() * ALL.length)];
}
// 進むほど 広く
export const areaSize = (i) => Math.round(64 + (56 * i) / Math.max(1, BOSS_SLAB.length - 1));

const B = (id) => (id === "powder_snow_safe" ? bk("snow") : bk(id));
const ri = (r, a, b) => a + Math.floor(r() * (b - a + 1));
const pk = (r, a) => a[Math.floor(r() * a.length)];

// ---- 第103版: 迷宮の 階（部屋と 通路・行き止まりの 宝・鍵の 扉・スイッチの 近道・光る 採取・見える モンスター）----
/* 階の 種類: maze=迷宮 / dark=暗い 迷宮（明かりが 少ない）/ vault=宝物庫（宝が 多い）/ open=いままでの 大部屋 */
export function floorType(st, r) {
  const T = DG_THEMES[st.theme] || {};
  if (st.boss || st.kind === "meet" || T.sky) return "open";
  const x = r();
  if (st.f >= 1 && st.f < (st.F || 3) - 2 && x < 0.1) return "vault";
  return x < 0.62 ? "maze" : x < 0.8 ? "dark" : "open";
}
export function genMaze(st, r, ft) {
  const T = DG_THEMES[st.theme] || DG_THEMES.forest;
  const { x0, y0, z0 } = st, S = st.S, C = [];
  const F = (a, b, c, d, e, f, blk, mode) => C.push(`fill ${a} ${b} ${c} ${d} ${e} ${f} ${blk}${mode ? " " + mode : ""}`);
  const SB = (x, y, z, blk) => C.push(`setblock ${x} ${y} ${z} ${blk}`);
  const X1 = x0 + S - 1, Z1 = z0 + S - 1, H = 6;   /* 第106版: 天井を 高く（高台の 部屋） */
  const wallB = B(T.wall === "barrier" || !T.wall ? (T.fl2[0] || "stone_bricks") : T.wall), flB = B(T.fl), baseB = B(T.base);
  const rowsOf = (h) => Math.max(1, Math.floor(32000 / ((S + 80) * h)));
  /* 1) 片づけ（前の 階ぶん 80マス）→ 床・かべで うめる・見えない 天井 */
  const SM = Math.max(S, 120), cx0 = x0 - 36, cx1 = x0 + SM + 2, ZC = z0 + SM - 1;
  for (let z = z0 - 3, rw = Math.max(1, Math.floor(32000 / ((cx1 - cx0 + 1) * 33))); z <= ZC + 3; z += rw) F(cx0, y0 - 10, z, cx1, y0 + 22, Math.min(ZC + 3, z + rw - 1), "air");
  for (let z = z0 - 1, rw = rowsOf(1); z <= Z1 + 1; z += rw) { F(x0 - 1, y0 - 1, z, X1 + 1, y0 - 1, Math.min(Z1 + 1, z + rw - 1), baseB); F(x0 - 1, y0, z, X1 + 1, y0, Math.min(Z1 + 1, z + rw - 1), flB); }
  for (let z = z0 - 1, rw = Math.max(1, Math.floor(32000 / ((S + 2) * H))); z <= Z1 + 1; z += rw) F(x0 - 1, y0 + 1, z, X1 + 1, y0 + H, Math.min(Z1 + 1, z + rw - 1), wallB);
  for (let z = z0 - 1, rw = rowsOf(1); z <= Z1 + 1; z += rw) F(x0 - 1, y0 + H + 1, z, X1 + 1, y0 + H + 1, Math.min(Z1 + 1, z + rw - 1), "barrier");
  /* 2) マス目（1マス 13）に 部屋 */
  const G = Math.max(3, Math.floor(S / 16)), cs = Math.floor(S / G), cell = (i, j) => ({ cx: x0 + i * cs + Math.floor(cs / 2), cz: z0 + j * cs + Math.floor(cs / 2) });
  const rooms = []; for (let j = 0; j < G; j++) for (let i = 0; i < G; i++) { const c = cell(i, j), hw = ri(r, 3, Math.max(3, Math.floor(cs / 2) - 2)), hd = ri(r, 3, Math.max(3, Math.floor(cs / 2) - 2)); rooms.push({ i, j, ...c, hw, hd, adj: [] }); }
  const R = (i, j) => rooms[j * G + i];
  const carve = (a, b, c, d) => F(Math.min(a, c), y0 + 1, Math.min(b, d), Math.max(a, c), y0 + H, Math.max(b, d), "air");
  for (const q of rooms) carve(q.cx - q.hw, q.cz - q.hd, q.cx + q.hw, q.cz + q.hd);
  /* 3) 通路: ばらばらに 掘って 全部の 部屋を つなぐ（木）＋ 輪っかの 道を 少し */
  const seen = new Set([0]), stk = [0], edges = [];
  while (stk.length) { const k = stk[stk.length - 1], q = rooms[k]; const nb = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([a, b]) => [q.i + a, q.j + b]).filter(([a, b]) => a >= 0 && b >= 0 && a < G && b < G && !seen.has(b * G + a)); if (!nb.length) { stk.pop(); continue; } const [a, b] = nb[ri(r, 0, nb.length - 1)], n = b * G + a; seen.add(n); stk.push(n); edges.push([k, n]); }
  const loops = []; for (const q of rooms) for (const [a, b] of [[1, 0], [0, 1]]) { const n = (q.j + b) * G + (q.i + a); if (q.i + a < G && q.j + b < G && !edges.some(([u, v]) => (u === rooms.indexOf(q) && v === n) || (v === rooms.indexOf(q) && u === n)) && r() < 0.18) loops.push([rooms.indexOf(q), n]); }
  const corridor = ([u, v]) => { const a = rooms[u], b = rooms[v], w = r() < 0.35 ? 2 : 1; if (a.i !== b.i) carve(a.cx, a.cz - w, b.cx, a.cz + w); else carve(a.cx - w, a.cz, a.cx + w, b.cz); };
  for (const e of [...edges, ...loops]) { corridor(e); rooms[e[0]].adj.push(e[1]); rooms[e[1]].adj.push(e[0]); }
  /* 4) 入口と 階段（いちばん 遠い 部屋）*/
  const dist = new Array(rooms.length).fill(-1); dist[0] = 0; const qq = [0]; while (qq.length) { const k = qq.shift(); for (const n of rooms[k].adj) if (dist[n] < 0) { dist[n] = dist[k] + 1; qq.push(n); } }
  const eu = (k) => Math.hypot(rooms[k].cx - rooms[0].cx, rooms[k].cz - rooms[0].cz) / Math.max(1, cs), far = rooms.map((_, k) => k).sort((a, b) => (dist[b] + 3 * eu(b)) - (dist[a] + 3 * eu(a)));   /* 道のりも まっすぐの 距離も 遠い 部屋 */
  const startR = rooms[0], stairsR = st.boss ? null : rooms[far[0]];
  const start = { x: startR.cx, z: startR.cz }, stairs = stairsR ? { x: stairsR.cx, z: stairsR.cz } : null;
  const dead = rooms.map((q, k) => k).filter((k) => k !== 0 && rooms[k] !== stairsR && rooms[k].adj.length === 1);
  const used = new Set([0, far[0]]);
  const take = (L) => { const k = L.find((x) => !used.has(x)); if (k === undefined) return null; used.add(k); return rooms[k]; };
  const others = shuffle(rooms.map((_, k) => k).filter((k) => !used.has(k)), r);
  /* 5) 宝箱（行き止まりの 部屋）・泉・猛者 */
  const chests = []; const nch = ft === "vault" ? 6 + Math.floor(S / 30) : 2 + Math.floor(S / 40);
  for (let k = 0; k < nch; k++) { const q = take([...dead, ...others]); if (!q) break; chests.push({ x: q.cx + ri(r, -1, 1), z: q.cz + ri(r, -1, 1) }); }
  const spring = !st.boss && r() < 0.6 ? (() => { const q = take(others); return q ? { x: q.cx, z: q.cz } : null; })() : null;
  const elite = !st.boss && st.f >= 1 && st.kind !== "meet" && r() < 0.5 ? (() => { const q = take(others); return q ? { x: q.cx, z: q.cz } : null; })() : null;
  /* 6) 鍵の 扉（階段の 部屋に 入る 通路を ふさぐ。鍵は ほかの 遠い 部屋に）*/
  let door = null, key = null;
  if (stairsR && st.f >= 1 && ft !== "vault" && r() < 0.55) {
    const sk = far[0], k2 = rooms[sk].adj.length === 1 ? rooms[sk].adj[0] : null;
    if (k2 !== null) { const a = rooms[k2], b = rooms[sk]; const mx = Math.round((a.cx + b.cx) / 2), mz = Math.round((a.cz + b.cz) / 2), vert = a.i === b.i;
      const kq = take(dead.filter((k) => k !== sk).sort((u, v) => dist[v] - dist[u])) || take(others);
      if (kq) { key = { x: kq.cx, z: kq.cz }; door = { x: mx, z: mz, vert }; const bars = B("iron_bars"); if (vert) F(mx - 2, y0 + 1, mz, mx + 2, y0 + H, mz, bars); else F(mx, y0 + 1, mz - 2, mx, y0 + H, mz + 2, bars); } }   /* 鍵の 部屋が 決まってから 扉を 置く・天井まで */
  }
  /* 7) スイッチの 近道（輪っかの 道を 1本 ひびわれた かべで ふさぎ、遠い 側の 部屋に スイッチ）*/
  let sw = null, swWall = null;
  if (loops.length && ft !== "vault") { const [u, v] = loops[ri(r, 0, loops.length - 1)], a = rooms[u], b = rooms[v], mx = Math.round((a.cx + b.cx) / 2), mz = Math.round((a.cz + b.cz) / 2), vert = a.i === b.i;
    swWall = { x: mx, z: mz, vert }; const cr = B("cracked_stone_bricks"); if (vert) F(mx - 2, y0 + 1, mz, mx + 2, y0 + H, mz, cr); else F(mx, y0 + 1, mz - 2, mx, y0 + H, mz + 2, cr);
    const fr = dist[u] > dist[v] ? a : b; sw = { x: fr.cx + 2, z: fr.cz + 2 }; SB(sw.x, y0, sw.z, B("lime_concrete")); SB(sw.x, y0 + 1, sw.z, B("stone_pressure_plate")); }
  /* 8) 光る 採取ポイント */
  const sparks = []; for (let k = 0; k < 2 + Math.floor(S / 40) && others.length; k++) { const q = rooms[others[(k * 3 + 1) % others.length]]; sparks.push({ x: q.cx + ri(r, -q.hw + 1, q.hw - 1), z: q.cz + ri(r, -q.hd + 1, q.hd - 1) }); }
  for (const s of sparks) SB(s.x, y0, s.z, B(T.light === "lantern_post" || T.light === "end_rod_post" ? "glowstone" : T.light || "glowstone"));
  /* 第106版: 部屋の 役わり（高台・ワープ床・モンスターハウス・封印の 宝物庫）*/
  const special = new Set();
  const ledges = [];
  for (const k of others) { if (ledges.length >= 2) break; const q = rooms[k]; if (used.has(k) || q.hw < 6 || q.hd < 6 || r() < 0.4) continue; used.add(k); special.add(q); ledges.push(q); }
  const warps = []; { const L = others.filter((k) => !used.has(k)); if (L.length >= 4 && r() < 0.75) { const a = rooms[L[0]], b = rooms[L[L.length - 1]]; used.add(L[0]); used.add(L[L.length - 1]); warps.push([{ x: a.cx - 2, z: a.cz - 2 }, { x: b.cx - 2, z: b.cz - 2 }]); } }
  let house = null; { const L = others.filter((k) => !used.has(k) && rooms[k].hw >= 4 && rooms[k].hd >= 4); if (L.length && st.f >= 1 && !st.kind && r() < 0.45) { const q = rooms[L[0]]; used.add(L[0]); special.add(q); house = { x: q.cx, z: q.cz, hw: q.hw, hd: q.hd }; } }
  let seal = null; { const busyQ = [key, spring, elite].filter(Boolean), vk = dead.find((k) => rooms[k].adj.length === 1 && k !== far[0] && !special.has(rooms[k]) && !busyQ.some((q) => Math.abs(q.x - rooms[k].cx) <= rooms[k].hw && Math.abs(q.z - rooms[k].cz) <= rooms[k].hd) && !warps.some((w) => w.some((q) => Math.abs(q.x - rooms[k].cx) <= rooms[k].hw + 2 && Math.abs(q.z - rooms[k].cz) <= rooms[k].hd + 2))), L = others.filter((k) => !used.has(k) && k !== vk); if (vk !== undefined && L.length >= 3 && ft !== "vault" && r() < 0.5) { used.add(vk); const v = rooms[vk], a = rooms[v.adj[0]], mx = Math.round((a.cx + v.cx) / 2), mz = Math.round((a.cz + v.cz) / 2), vert = a.i === v.i; seal = { x: mx, z: mz, vert, v: { x: v.cx, z: v.cz }, sw: L.slice(0, 3).map((k) => { used.add(k); return { x: rooms[k].cx + 2, z: rooms[k].cz - 2 }; }) }; special.add(v); } }
  /* 9) 部屋の 飾り・明かり（暗い 階は 少し）*/
  const feats = (T.feats || []).filter(([k]) => !/tree|hill|dune|pond|island|lavapool|ruin_room|spike|stalag/.test(k));
  for (const q of rooms) {
    if (q === startR || q === stairsR) continue;
    if (special.has(q)) { if (ft !== "dark" || r() < 0.5) SB(q.cx, y0 + H, q.cz, B("glowstone")); continue; }
    for (const [kind, dens] of feats) { const n = Math.min(4, Math.round((q.hw * q.hd * 4 / 100) * dens)); for (let k = 0; k < n; k++) feature(kind, q.cx + ri(r, -q.hw + 1, q.hw - 1), q.cz + ri(r, -q.hd + 1, q.hd - 1), y0, r, F, SB, T, y0 + H, { x0: q.cx - q.hw, z0: q.cz - q.hd, X1: q.cx + q.hw, Z1: q.cz + q.hd }); }
    if (ft !== "dark" || r() < 0.25) SB(q.cx, y0 + H, q.cz, B("glowstone"));
  }
  /* 10) 入口・階段・宝箱・泉・猛者（いままでと 同じ 見た目）*/
  const pad = (q, rad, blk) => { F(q.x - rad, y0 + 1, q.z - rad, q.x + rad, y0 + H, q.z + rad, "air"); F(q.x - rad, y0, q.z - rad, q.x + rad, y0, q.z + rad, blk || flB); };
  pad(start, 1, B(T.fl2[0] || T.fl));
  if (stairs) { pad(stairs, 2); F(stairs.x - 1, y0, stairs.z - 1, stairs.x + 1, y0, stairs.z + 1, B("crying_obsidian")); SB(stairs.x, y0, stairs.z, B("amethyst_block")); for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) F(stairs.x + a, y0 + 1, stairs.z + b, stairs.x + a, y0 + 3, stairs.z + b, B("end_rod")); }
  const tb = st.kind === "god" ? 8 : st.kind === "king" ? 7 : st.re ? 7 : 3 + Math.floor((st.i || 0) / 5) + (ft === "vault" ? 1 : 0), tg = st.kind === "god" || st.kind === "king" || !!st.re;
  for (const q of chests) { pad(q, 1); const [c1] = chestCmds(q.x, y0 + 1, q.z, rollTier(Math.min(9, tb), st.f >= (st.F || 1) - 1 ? 1 : 0, tg)); C.push(c1); }
  if (spring) { pad(spring, 2, B("prismarine_bricks")); F(spring.x - 1, y0, spring.z - 1, spring.x + 1, y0, spring.z + 1, "water"); SB(spring.x, y0 - 1, spring.z, B("sea_lantern")); }
  if (elite) { pad(elite, 2, B("gold_block")); F(elite.x - 1, y0, elite.z - 1, elite.x + 1, y0, elite.z + 1, B("red_nether_brick")); SB(elite.x, y0, elite.z, B("crying_obsidian")); }
  if (key) SB(key.x, y0, key.z, B("gold_block"));
  /* 第106版: 高台（2段・階段で 上る・上に 宝箱）*/
  const stairB = /brick|stone|deepslate|blackstone|sandstone|quartz|prismarine|purpur|nether/.test(T.wall || "") ? B("stone_brick_stairs") : B("oak_stairs");
  for (const q of ledges) {
    const a = q.cx + 3, b = q.cz + 3, a1 = q.cx + q.hw, b1 = q.cz + q.hd;
    F(a, y0 + 1, b, a1, y0 + 2, b1, wallB); F(a, y0 + 3, b, a1, y0 + 3, b1, "air");
    for (let z = b; z <= Math.min(b + 1, b1); z++) { SB(a - 2, y0 + 1, z, `${stairB} ["weirdo_direction"=0]`); SB(a - 1, y0 + 1, z, wallB); SB(a - 1, y0 + 2, z, `${stairB} ["weirdo_direction"=0]`); }
    for (let x = a; x <= a1; x += 2) SB(x, y0 + 3, b1, B("oak_fence"));
    const [c1] = chestCmds(a1 - 1, y0 + 3, b1 - 1, rollTier(Math.min(9, tb + 1), 0, tg)); C.push(c1); chests.push({ x: a1 - 1, z: b1 - 1, y: y0 + 3 });
    SB(a, y0 + 3, b1 - 1, B(T.light === "lantern_post" || T.light === "end_rod_post" ? "lantern" : "lantern"));
  }
  /* ワープ床（ふむと つながった 部屋へ）*/
  for (const [a, b] of warps) for (const q of [a, b]) { pad(q, 1, B("purpur_block")); SB(q.x, y0, q.z, B("crying_obsidian")); }
  /* モンスターハウス（入ると まわりから あらわれる・宝箱 2つ）*/
  if (house) for (const [dx, dz] of [[-house.hw + 1, -house.hd + 1], [house.hw - 1, house.hd - 1]]) { const [c1] = chestCmds(house.x + dx, y0 + 1, house.z + dz, rollTier(Math.min(9, tb + 1), 0, tg)); C.push(c1); chests.push({ x: house.x + dx, z: house.z + dz }); }
  /* 封印の 宝物庫（3つの 青い スイッチを ふむと ひらく）*/
  if (seal) {
    const bars = B("iron_bars"); if (seal.vert) F(seal.x - 2, y0 + 1, seal.z, seal.x + 2, y0 + H, seal.z, bars); else F(seal.x, y0 + 1, seal.z - 2, seal.x, y0 + H, seal.z + 2, bars);
    for (const q of seal.sw) { SB(q.x, y0, q.z, B("light_blue_concrete")); SB(q.x, y0 + 1, q.z, B("stone_pressure_plate")); }
    for (const dx of [-1, 1]) { const [c1] = chestCmds(seal.v.x + dx, y0 + 1, seal.v.z, rollTier(Math.min(9, tb + 2), 1, tg)); C.push(c1); chests.push({ x: seal.v.x + dx, z: seal.v.z }); }
    SB(seal.v.x, y0, seal.v.z, B("gold_block"));
  }
  /* 11) 戦いの 間（西どなり）*/
  const rx = x0 - 34;
  F(rx, y0 - 1, z0, rx + 22, y0 + 12, z0 + 22, wallB); F(rx + 1, y0 + 1, z0 + 1, rx + 21, y0 + 11, z0 + 21, "air"); F(rx + 1, y0, z0 + 1, rx + 21, y0, z0 + 21, B(T.fl === "mud" || T.fl === "sand" ? T.fl2[0] : T.fl));
  for (let a = 3; a <= 19; a += 8) for (let b = 3; b <= 19; b += 8) SB(rx + a, y0 + 12, z0 + b, B("glowstone"));
  /* 見える モンスターの 出る 場所（入口と 階段の 部屋 以外）*/
  const symSpots = rooms.filter((q) => q !== startR && q !== stairsR).map((q) => ({ x: q.cx + 0.5, z: q.cz + 0.5, hw: q.hw, hd: q.hd }));
  return { cmds: C, info: { start: { x: start.x + 0.5, y: y0 + 1, z: start.z + 0.5 }, bx: rx + 11, bz: z0 + 11, by: y0 + 1, bd: 4.5, sx: stairs ? stairs.x : null, sz: stairs ? stairs.z : null, chests, spring, elite, theme: st.theme, ft, door, key, sw, swWall, sparks, symSpots, H, warps, house, seal } };
}
function shuffle(a, r) { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; }

export function genFloor(st, r) {
  { const ft = floorType(st, r); st.ft = ft; if (ft !== "open") return genMaze(st, r, ft); }   /* 第103版 */
  const T = DG_THEMES[st.theme] || DG_THEMES.forest;
  const { x0, y0, z0 } = st, S = st.S;
  const C = [];
  const F = (a, b, c, d, e, f, blk, mode) => C.push(`fill ${a} ${b} ${c} ${d} ${e} ${f} ${blk}${mode ? " " + mode : ""}`);
  const SB = (x, y, z, blk) => C.push(`setblock ${x} ${y} ${z} ${blk}`);
  const X1 = x0 + S - 1, Z1 = z0 + S - 1;
  // 1) まっさらに（戦いの 間・雲の 下まで）
  /* 第89版: 前の 階が 大きかった ときの 階段や 壁が 外に 残らない ように、いつも 80マスぶん 空ける */
  const SM = Math.max(S, 120), cx0 = x0 - 36, cx1 = x0 + SM + 2, cy0 = y0 - 10, cy1 = y0 + 22, rows = Math.max(1, Math.floor(32000 / ((cx1 - cx0 + 1) * (cy1 - cy0 + 1)))), ZC = z0 + SM - 1;
  for (let z = z0 - 3; z <= ZC + 3; z += rows) F(cx0, cy0, z, cx1, cy1, Math.min(ZC + 3, z + rows - 1), "air");
  const sky = !!T.sky;
  // 2) 地面
  if (!sky) { F(x0, y0 - 1, z0, X1, y0 - 1, Z1, B(T.base)); F(x0, y0, z0, X1, y0, Z1, B(T.fl)); }
  else { const rows2 = Math.max(1, Math.floor(32000 / S)); for (let z = z0 - 2; z <= Z1 + 2; z += rows2) F(x0 - 2, y0 - 8, z, X1 + 2, y0 - 8, Math.min(Z1 + 2, z + rows2 - 1), B(st.theme === "void" ? "obsidian" : "white_wool")); }
  // 3) 外周の 壁・見えない 壁・天井
  const wallH = T.ceil ? 9 : sky ? 0 : 4;
  for (const [a, c, d, f] of [[x0 - 1, z0 - 1, X1 + 1, z0 - 1], [x0 - 1, Z1 + 1, X1 + 1, Z1 + 1], [x0 - 1, z0, x0 - 1, Z1], [X1 + 1, z0, X1 + 1, Z1]]) {
    if (wallH) F(a, y0 - 1, c, d, y0 + wallH, f, B(T.wall === "barrier" ? T.fl : T.wall));
    F(a, y0 + wallH + 1, c, d, y0 + 18, f, "barrier");
    if (sky) F(a, y0 - 7, c, d, y0, f, "barrier");
  }
  if (T.ceil) { const rows3 = Math.max(1, Math.floor(32000 / S)); for (let z = z0; z <= Z1; z += rows3) F(x0, y0 + 10, z, X1, y0 + 10, Math.min(Z1, z + rows3 - 1), B(T.ceil)); }
  // 4) 特別な 場所（入口・階段・宝箱・泉・猛者の 印）を 先に 決める
  const start = { x: x0 + 4, z: z0 + 4 };
  const far = () => { for (let k = 0; k < 40; k++) { const x = ri(r, x0 + Math.floor(S * 0.45), X1 - 5), z = ri(r, z0 + Math.floor(S * 0.45), Z1 - 5); if (Math.hypot(x - start.x, z - start.z) > S * 0.7) return { x, z }; } return { x: X1 - 5, z: Z1 - 5 }; };
  const stairs = st.boss ? null : far();
  const spots = [];
  const randSpot = (minD = 8) => { for (let k = 0; k < 40; k++) { const x = ri(r, x0 + 5, X1 - 5), z = ri(r, z0 + 5, Z1 - 5); if ([start, stairs, ...spots].every((q) => !q || Math.hypot(q.x - x, q.z - z) > minD)) return { x, z }; } return { x: ri(r, x0 + 5, X1 - 5), z: ri(r, z0 + 5, Z1 - 5) }; };
  const chests = []; const nch = 2 + Math.floor(S / 40) + (r() < 0.4 ? 1 : 0);
  for (let k = 0; k < nch; k++) { const q = randSpot(); spots.push(q); chests.push(q); }
  const spring = !st.boss && r() < 0.55 ? (() => { const q = randSpot(12); spots.push(q); return q; })() : null;
  const elite = !st.boss && st.f >= 1 && st.kind !== "meet" && r() < 0.45 ? (() => { const q = randSpot(12); spots.push(q); return q; })() : null;
  // 浮島: 入口→階段の 道に そって 島を つなぐ
  if (sky) {
    const isl = [start];
    const goal = stairs || { x: x0 + Math.floor(S / 2), z: z0 + Math.floor(S / 2) };
    const n = 3 + Math.floor(S / 16);
    for (let k = 1; k < n; k++) { const t = k / n; isl.push({ x: Math.round(start.x + (goal.x - start.x) * t + ri(r, -S / 6, S / 6)), z: Math.round(start.z + (goal.z - start.z) * t + ri(r, -S / 6, S / 6)) }); }
    isl.push(goal); for (const q of spots) isl.push(q);
    for (let k = 0; k < Math.floor(S / 20); k++) isl.push({ x: ri(r, x0 + 6, X1 - 6), z: ri(r, z0 + 6, Z1 - 6) });
    const clampX = (v) => Math.max(x0 + 1, Math.min(X1 - 1, v)), clampZ = (v) => Math.max(z0 + 1, Math.min(Z1 - 1, v));
    isl.forEach((q, k) => {
      q.x = clampX(q.x); q.z = clampZ(q.z);
      const rad = k === 0 || q === goal ? 6 : ri(r, 4, 8);
      for (let dz = -rad; dz <= rad; dz++) { const w = Math.floor(Math.sqrt(rad * rad - dz * dz)); F(clampX(q.x - w), y0, clampZ(q.z + dz), clampX(q.x + w), y0, clampZ(q.z + dz), B(T.fl)); if (Math.abs(dz) < rad - 1) F(clampX(q.x - w + 1), y0 - 1, clampZ(q.z + dz), clampX(q.x + w - 1), y0 - 1, clampZ(q.z + dz), B(T.base)); }
      F(clampX(q.x - 2), y0 - 3, clampZ(q.z - 2), clampX(q.x + 2), y0 - 2, clampZ(q.z + 2), B(T.base));
    });
    // 橋（つぎの 島へ・のこりは 近い 島へ）
    const bridge = (a, b) => { const bb = st.theme === "void" ? B("purpur_block") : B("oak_planks"); const steps = Math.max(Math.abs(b.x - a.x), Math.abs(b.z - a.z)); for (let s = 0; s <= steps; s += 3) { const x = Math.round(a.x + (b.x - a.x) * s / steps), z = Math.round(a.z + (b.z - a.z) * s / steps); F(clampX(x - 1), y0, clampZ(z - 1), clampX(x + 1), y0, clampZ(z + 1), bb); } };
    for (let k = 0; k + 1 < n + 1; k++) bridge(isl[k], isl[k + 1]);
    for (let k = n + 1; k < isl.length; k++) { let best = isl[0], bd = 1e9; for (let j = 0; j <= n; j++) { const dd = Math.hypot(isl[j].x - isl[k].x, isl[j].z - isl[k].z); if (dd < bd) { bd = dd; best = isl[j]; } } bridge(isl[k], best); }
  }
  // 5) まだら模様
  const area = S * S;
  if (!sky) for (let k = 0; k < Math.floor(area / 90); k++) { const x = ri(r, x0, X1), z = ri(r, z0, Z1), w = ri(r, 1, 4), h = ri(r, 1, 4); F(Math.max(x0, x - w), y0, Math.max(z0, z - h), Math.min(X1, x + w), y0, Math.min(Z1, z + h), B(pk(r, T.fl2))); }
  // 海: ひざ下の 水を はる
  if (T.water) { const rows4 = Math.max(1, Math.floor(32000 / S)); for (let z = z0; z <= Z1; z += rows4) F(x0, y0 + 1, z, X1, y0 + 1, Math.min(Z1, z + rows4 - 1), "water"); }
  // 6) 飾り
  const top = T.ceil ? y0 + 9 : y0 + 16;
  for (const [kind, dens] of T.feats) {
    const n = Math.round((area / 100) * dens * (sky ? 0.45 : 1));
    for (let k = 0; k < n; k++) {
      const x = ri(r, x0 + 2, X1 - 2), z = ri(r, z0 + 2, Z1 - 2);
      feature(kind, x, z, y0, r, F, SB, T, top, { x0, z0, X1, Z1 });
    }
  }
  // 7) 明かり（床に うめる・柱の 上）
  const step = T.ceil ? 7 : 9;
  for (let x = x0 + 3; x <= X1 - 2; x += step) for (let z = z0 + 3 + ((x / step) % 2 ? 4 : 0); z <= Z1 - 2; z += step) {
    if (T.light === "lantern_post") { F(x, y0 + 1, z, x, y0 + 2, z, B("oak_fence")); SB(x, y0 + 3, z, B("lantern")); }
    else if (T.light === "end_rod_post") { if (!sky) SB(x, y0 + 1, z, B("end_rod")); }
    else if (!sky) SB(x, y0, z, B(T.light));
    if (T.ceil && (x + z) % 2 === 0) SB(x, y0 + 10, z, B(T.light === "lantern_post" || /^(soul_)?lantern$/.test(T.light) ? "glowstone" : T.light));   /* v3.0: 天井に ランタンを 置かない（落ちて アイテムに なる） */
  }
  // 8) 特別な 場所を ととのえる（上を あけて 床を しく）
  const pad = (q, rad, blk) => { F(q.x - rad, y0 + 1, q.z - rad, q.x + rad, top, q.z + rad, "air"); F(q.x - rad, y0, q.z - rad, q.x + rad, y0, q.z + rad, blk || B(T.fl)); F(q.x - rad, y0 - 1, q.z - rad, q.x + rad, y0 - 1, q.z + rad, B(T.base)); };
  pad(start, 2, B(T.fl2[0] || T.fl));
  if (stairs) {
    pad(stairs, 2);
    F(stairs.x - 1, y0, stairs.z - 1, stairs.x + 1, y0, stairs.z + 1, B("crying_obsidian")); SB(stairs.x, y0, stairs.z, B("amethyst_block"));   /* 第92版: ビーコンの 光が となりの 階から 見えて「外に ポータルが ある」ように 見えた */
    for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) F(stairs.x + a, y0 + 1, stairs.z + b, stairs.x + a, y0 + 3, stairs.z + b, B("end_rod"));
  }
  // v2.6.1: 石板の 中の 宝箱（物語 3〜5・最後の 階 +1・再戦 7・覇王 7・神域 8・再会 4。再戦・覇王・神域は 神箱も）
  const tb = st.kind === "god" ? 8 : st.kind === "king" ? 7 : st.kind === "meet" ? 4 : st.re ? 7 : 3 + Math.floor((st.i || 0) / 5), tg = st.kind === "god" || st.kind === "king" || !!st.re;
  for (const q of chests) { pad(q, 1); const [c1, c2] = chestCmds(q.x, y0 + 1, q.z, rollTier(tb, st.f >= (st.F || 1) - 1 ? 1 : 0, tg)); C.push(c1); }
  if (spring) { pad(spring, 2, B("prismarine_bricks")); F(spring.x - 1, y0, spring.z - 1, spring.x + 1, y0, spring.z + 1, "water"); SB(spring.x, y0 - 1, spring.z, B("sea_lantern")); for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) SB(spring.x + a, y0 + 1, spring.z + b, B("sea_lantern")); }
  if (elite) { pad(elite, 2, B("gold_block")); F(elite.x - 1, y0, elite.z - 1, elite.x + 1, y0, elite.z + 1, B("red_nether_brick")); SB(elite.x, y0, elite.z, B("crying_obsidian")); for (const [a, b] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) { SB(elite.x + a, y0 + 1, elite.z + b, B("blackstone_wall") === "stone" ? B("blackstone") : B("blackstone_wall")); SB(elite.x + a, y0 + 2, elite.z + b, B("soul_lantern")); } }
  // 9) 戦いの 間（西どなり・閉じた 部屋・テーマの 床）
  const rx = x0 - 34;
  F(rx, y0 - 1, z0, rx + 22, y0 + 12, z0 + 22, B(T.wall === "barrier" ? "smooth_quartz" : T.wall));
  F(rx + 1, y0 + 1, z0 + 1, rx + 21, y0 + 11, z0 + 21, "air");
  F(rx + 1, y0, z0 + 1, rx + 21, y0, z0 + 21, B(T.fl === "mud" || T.fl === "sand" ? T.fl2[0] : T.fl));
  for (let a = 3; a <= 19; a += 8) for (let b = 3; b <= 19; b += 8) SB(rx + a, y0 + 12, z0 + b, B("glowstone"));
  return {
    cmds: C,
    info: { start: { x: start.x + 0.5, y: y0 + 1, z: start.z + 0.5 }, bx: rx + 11, bz: z0 + 11, by: y0 + 1, bd: 4.5, sx: stairs ? stairs.x : null, sz: stairs ? stairs.z : null, chests, spring, elite, theme: st.theme },
  };
}

function feature(kind, x, z, y0, r, F, SB, T, top, R) {
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const X = (v) => cl(v, R.x0, R.X1), Zc = (v) => cl(v, R.z0, R.Z1);
  const tree = (log, leaves, h0) => { const h = h0 + (T.tall | 0); F(x, y0 + 1, z, x, y0 + h, z, B(log)); F(X(x - 2), y0 + h - 1, Zc(z - 2), X(x + 2), y0 + h, Zc(z + 2), B(leaves), "keep"); F(X(x - 1), y0 + h + 1, Zc(z - 1), X(x + 1), y0 + h + 1, Zc(z + 1), B(leaves), "keep"); SB(x, Math.min(top, y0 + h + 2), z, B(leaves)); };
  switch (kind) {
    case "tree_oak": return tree("oak_log", "oak_leaves", ri(r, 4, 6));
    case "tree_dark": return tree("dark_oak_log", "dark_oak_leaves", ri(r, 5, 7));
    case "tree_cherry": return tree("cherry_log", "cherry_leaves", ri(r, 4, 6));
    case "tree_spruce": { const h = ri(r, 6, 9); F(x, y0 + 1, z, x, y0 + h, z, B("spruce_log")); for (let k = 0; k < 3; k++) { const w = 2 - k, y = y0 + 3 + k * 2; F(X(x - w), y, Zc(z - w), X(x + w), y + 1, Zc(z + w), B("spruce_leaves"), "keep"); } SB(x, y0 + h + 1, z, B("spruce_leaves")); return; }
    case "tree_mangrove": { const h = ri(r, 4, 6); for (const [a, b] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) SB(X(x + a), y0 + 1, Zc(z + b), B("mangrove_roots")); return tree("mangrove_log", "mangrove_leaves", h); }
    case "grass": return SB(x, y0 + 1, z, B(r() < 0.7 ? "short_grass" : "fern"));
    case "flower": return SB(x, y0 + 1, z, B(pk(r, ["poppy", "dandelion", "cornflower", "oxeye_daisy"])));
    case "deadbush": return SB(x, y0 + 1, z, B("deadbush"));
    case "cactus": { const h = ri(r, 1, 3); return F(x, y0 + 1, z, x, y0 + h, z, B("cactus")); }
    case "rock": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + ri(r, 1, 2), Zc(z + ri(r, 0, 1)), B(pk(r, ["cobblestone", "mossy_cobblestone", "andesite"])));
    case "rock_ice": return F(x, y0 + 1, z, X(x + 1), y0 + ri(r, 1, 2), Zc(z + 1), B(pk(r, ["packed_ice", "blue_ice"])));
    case "rock_obs": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + ri(r, 1, 3), Zc(z + ri(r, 0, 1)), B(pk(r, ["obsidian", "crying_obsidian", "blackstone"])));
    case "ore": return F(x, y0 + 1, z, X(x + 1), y0 + 2, Zc(z + 1), B(pk(r, ["iron_ore", "gold_ore", "diamond_ore", "emerald_ore", "lapis_ore", "redstone_ore", "copper_ore"])));
    case "hill": case "dune": case "hill_basalt": {
      const blk = kind === "dune" ? "sand" : kind === "hill_basalt" ? "basalt" : T.fl;
      const rad = ri(r, 3, 6), h = ri(r, 1, 3);
      for (let k = 0; k < h; k++) { const w = rad - k * 2; if (w < 1) break; F(X(x - w), y0 + 1 + k, Zc(z - w), X(x + w), y0 + 1 + k, Zc(z + w), B(blk)); }
      return;
    }
    case "pond": { const w = ri(r, 2, 4), h = ri(r, 2, 4); F(X(x - w - 1), y0, Zc(z - h - 1), X(x + w + 1), y0, Zc(z + h + 1), B(T.fl2[0] || "sand")); return F(X(x - w), y0, Zc(z - h), X(x + w), y0, Zc(z + h), "water"); }
    case "lavapool": { const w = ri(r, 1, 3); F(X(x - w - 1), y0 + 1, Zc(z - w - 1), X(x + w + 1), y0 + 1, Zc(z + w + 1), B("blackstone")); F(X(x - w), y0 + 1, Zc(z - w), X(x + w), y0 + 1, Zc(z + w), "air"); return F(X(x - w), y0, Zc(z - w), X(x + w), y0, Zc(z + w), "lava"); }
    case "island": { const rad = ri(r, 3, 6); for (let k = 0; k < 2; k++) { const w = rad - k * 2; F(X(x - w), y0 + 1 + k, Zc(z - w), X(x + w), y0 + 1 + k, Zc(z + w), B("sand")); } if (r() < 0.7) { F(x, y0 + 3, z, x, y0 + 7, z, B("jungle_log")); F(X(x - 2), y0 + 8, z, X(x + 2), y0 + 8, z, B("jungle_leaves"), "keep"); F(x, y0 + 8, Zc(z - 2), x, y0 + 8, Zc(z + 2), B("jungle_leaves"), "keep"); } return; }
    case "reef": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + 1, Zc(z + ri(r, 0, 1)), B(pk(r, ["prismarine", "dark_prismarine", "sea_lantern", "prismarine_bricks"])));
    case "pillar_sea": { const h = ri(r, 3, 7); return F(x, y0 + 1, z, X(x + 1), y0 + h, Zc(z + 1), B("prismarine_bricks")); }
    case "spike": { const h = ri(r, 5, 11); F(x, y0 + 1, z, X(x + 1), y0 + Math.floor(h / 2), Zc(z + 1), B("packed_ice")); return F(x, y0 + 1, z, x, y0 + h, z, B("packed_ice")); }
    case "stalag": { const h = ri(r, 2, 9); F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + h, Zc(z + ri(r, 0, 1)), B(pk(r, ["stone", "dripstone_block", "tuff"]))); if (h > 6) F(x, y0 + h, z, x, top, z, B("stone")); return; }
    case "stalag_am": { const h = ri(r, 2, 8); return F(x, y0 + 1, z, x, y0 + h, z, B(pk(r, ["amethyst_block", "calcite"]))); }
    case "crystal": { F(x, y0 + 1, z, x, y0 + ri(r, 2, 5), z, B("amethyst_block")); for (const [a, b] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) if (r() < 0.7) SB(X(x + a), y0 + 1, Zc(z + b), B("amethyst_cluster")); return; }
    case "ruin_pillar": { const h = ri(r, 2, 7); F(x, y0 + 1, z, x, y0 + h, z, B(pk(r, ["stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks", "chiseled_sandstone"]))); return; }
    case "ruin_room": {
      const w = ri(r, 4, 7), h = ri(r, 2, 4), blk = B(pk(r, ["stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks"]));
      const gx = ri(r, -w + 1, w - 1), gz = ri(r, -w + 1, w - 1);
      F(X(x - w), y0 + 1, Zc(z - w), X(x + w), y0 + h, Zc(z - w), blk); F(X(x - w), y0 + 1, Zc(z + w), X(x + w), y0 + h, Zc(z + w), blk);
      F(X(x - w), y0 + 1, Zc(z - w), X(x - w), y0 + h, Zc(z + w), blk); F(X(x + w), y0 + 1, Zc(z - w), X(x + w), y0 + h, Zc(z + w), blk);
      F(X(x + gx - 1), y0 + 1, Zc(z - w), X(x + gx + 1), y0 + h, Zc(z - w), "air"); F(X(x - w), y0 + 1, Zc(z + gz - 1), X(x - w), y0 + h, Zc(z + gz + 1), "air");
      if (r() < 0.5) F(X(x + w), y0 + 1, Zc(z - 1), X(x + w), y0 + h, Zc(z + 1), "air");
      return;
    }
    case "bones": { F(x, y0 + 1, z, x, y0 + 3, z, B("bone_block")); F(X(x + 3), y0 + 1, z, X(x + 3), y0 + 3, z, B("bone_block")); return F(x, y0 + 4, z, X(x + 3), y0 + 4, z, B("bone_block")); }
    case "pillar_bone": return F(x, y0 + 1, z, x, y0 + ri(r, 3, 8), z, B("bone_block"));
    case "pillar_basalt": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + ri(r, 2, 7), Zc(z + ri(r, 0, 1)), B("basalt"));
    case "pillar_purpur": { const h = ri(r, 3, 9); F(x, y0 + 1, z, x, y0 + h, z, B("purpur_pillar")); return SB(x, y0 + h + 1, z, B("end_rod")); }
    case "palace_pillar": { F(x, y0 + 1, z, x, y0 + 9, z, B("quartz_pillar")); SB(x, y0 + 1, z, B("gold_block")); return SB(x, y0 + 9, z, B("gold_block")); }
    case "carpet": return F(x, y0 + 1, z, X(x + ri(r, 1, 3)), y0 + 1, Zc(z + ri(r, 1, 3)), B("red_carpet"));
    case "soul_lantern": { F(x, y0 + 1, z, x, y0 + 2, z, B("polished_blackstone_wall") === "stone" ? B("blackstone") : B("polished_blackstone_wall")); return SB(x, y0 + 3, z, B("soul_lantern")); }
    case "lantern": { F(x, y0 + 1, z, x, y0 + 2, z, B("cherry_fence") === "stone" ? B("oak_fence") : B("cherry_fence")); return SB(x, y0 + 3, z, B("lantern")); }
    case "mushroom_big": { const h = ri(r, 4, 7), red = r() < 0.5; F(x, y0 + 1, z, x, y0 + h, z, B("mushroom_stem")); return F(X(x - 2), y0 + h + 1, Zc(z - 2), X(x + 2), y0 + h + 1, Zc(z + 2), B(red ? "red_mushroom_block" : "brown_mushroom_block")); }
    case "mushroom_small": return SB(x, y0 + 1, z, B(r() < 0.5 ? "red_mushroom" : "brown_mushroom"));
    case "stump": return F(x, y0 + 1, z, x, y0 + ri(r, 1, 2), z, B("mangrove_log"));
  }
}

// ---- v2.3: 地上の ステージ（地方の テーマの 大地。半径 r の 円）----
// 第124版(tr): 高低差の ある 地形（山道・肩の 台地・頂上の 見晴らし台・谷の 小川・裂け目の 橋）。高さの 表を 先に 作り、
// 入口（東）→ まん中 → 肩の 台地 → らせんの 山道 → 頂上 を 1段ずつの 道で つなぐ。平らな 場所: 入口・場面・まん中・出来事の 入口（高さ y）と 肩の 台地
const LAND_NAME = { forest: "こもれびの 森", cherry: "さくらの 丘", snow: "しろがねの 雪原", sea: "あさせの 入り江", desert: "すなかぜの 砂丘", volcano: "ようがんの 原", cave: "いわやの 谷", crystal: "すいしょうの 野",
  ruins: "くずれた 都", sky: "うかぶ 浮島", swamp: "きりの 沼", mushroom: "おおきのこの 森", underworld: "めいふの 谷", void: "こくうの 野", palace: "おうきゅうの 庭" };
export const LAND_V = 1;
const NONE = -99, PAD = 1, TRAIL = 2, WIDE = 4, LIQ = 8, FEAT = 16, BRIDGE = 32, SLAB = 64, SKIP = 128;
export const LAND_F = { NONE, PAD, TRAIL, WIDE, LIQ, FEAT, BRIDGE, SLAB, SKIP };
/* hp=頂上の 高さ st=平らな 場所の わきの 急さ q=段々 ns=でこぼこ dn=ふもとの 起伏 liq=広場の まわりの 小川（2 は 溶岩）chasm=裂け目（cd=深さ）path=道 bridge=橋 cliff=がけ tall=木を 高く fx=飾りの 多さ */
const LAND_T = {
  forest: { hp: 30, ns: 2, liq: 1, path: "coarse_dirt", bridge: "oak_planks", cliff: "stone", tall: 4, fx: 1.8 },
  cherry: { hp: 18, st: 2.5, ns: 1, liq: 1, path: "coarse_dirt", bridge: "oak_planks", cliff: "stone" },
  mushroom: { hp: 20, ns: 2, dn: 2, path: "podzol", bridge: "mushroom_stem", cliff: "coarse_dirt" },
  swamp: { hp: 16, st: 2.5, ns: 1, liq: 1, pools: 30, path: "packed_mud", bridge: "oak_planks", cliff: "dirt" },
  snow: { hp: 33, st: 4, ns: 2, dn: 2, chasm: 1, cd: 10, path: "cobblestone", bridge: "packed_ice", cliff: "stone" },
  desert: { hp: 20, q: 5, ns: 1, dn: 3, path: "smooth_sandstone", bridge: "sandstone", cliff: "sandstone" },
  volcano: { hp: 24, ns: 1, dn: 1, liq: 2, lava: 8, path: "smooth_basalt", bridge: "basalt", cliff: "basalt" },
  crystal: { hp: 20, q: 4, path: "smooth_basalt", bridge: "amethyst_block", cliff: "calcite" },
  cave: { hp: 22, q: 2, ns: 2, dn: 2, path: "cobblestone", bridge: "andesite", cliff: "deepslate" },
  ruins: { hp: 18, q: 3, ns: 1, path: "mossy_cobblestone", bridge: "stone_bricks", cliff: "cracked_stone_bricks" },
  sea: { hp: 16, q: 2, sea: 1, path: "sandstone", bridge: "prismarine_bricks", cliff: "stone" },
  underworld: { hp: 20, ns: 2, dn: 1, chasm: 1, lava: 4, path: "polished_blackstone_bricks", bridge: "bone_block", cliff: "blackstone" },
  void: { hp: 20, ns: 2, dn: 1, chasm: 1, path: "end_stone_bricks", bridge: "bone_block", cliff: "obsidian" },
  sky: { sky: 1, path: "quartz_block", bridge: "oak_planks", cliff: "dirt" },
};
const LAND_D = { hp: 18, ns: 1, path: "cobblestone", bridge: "oak_planks", cliff: "stone" };
/* 安い ノイズ（格子の 乱数を なめらかに つなぐ・0〜1）*/
function vn(i, j, s, sd) {
  const fi = Math.floor(i / s), fj = Math.floor(j / s), u = i / s - fi, v = j / s - fj;
  const g = (a, b) => { let t = Math.imul((Math.imul(a, 374761393) + Math.imul(b, 668265263)) ^ sd, 1274126177); t ^= t >>> 13; t = Math.imul(t, 1103515245); return ((t >>> 8) & 1023) / 1023; };
  const a = g(fi, fj), b = g(fi + 1, fj), c = g(fi, fj + 1), d = g(fi + 1, fj + 1), su = u * u * (3 - 2 * u), sv = v * v * (3 - 2 * v);
  return a + (b - a) * su + (c - a + (a - b + d - c) * su) * sv;
}
/* 同じ 値の マスを 四角に まとめる（コマンドを へらす）*/
function mesh(N, key, emit) {
  const used = new Uint8Array(N * N);
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
    const c = j * N + i, k = key[c]; if (used[c] || k === NONE) continue;
    let w = 1; while (i + w < N && !used[c + w] && key[c + w] === k) w++;
    let h = 1; o: while (j + h < N) { for (let a = 0; a < w; a++) { const d = c + h * N + a; if (used[d] || key[d] !== k) break o; } h++; }
    for (let b = 0; b < h; b++) used.fill(1, c + b * N, c + b * N + w);
    emit(i, j, i + w - 1, j + h - 1, k);
  }
}
/* 歩いて 行ける マス（1段までの 上り下り・水と 溶岩と 飾りは 通らない）。from = [i, j]（中心からの ずれ）*/
export function landWalk(g, from) {
  const { N, r, H, K } = g, seen = new Uint8Array(N * N), q = [(from[1] + r) * N + from[0] + r]; seen[q[0]] = 1;
  for (let n = 0; n < q.length; n++) { const c = q[n], i = c % N; for (const d of [1, -1, N, -N]) { const e = c + d; if (e < 0 || e >= N * N || seen[e] || (d === 1 && i === N - 1) || (d === -1 && i === 0)) continue; if (H[e] === NONE || (K[e] & (LIQ | FEAT)) || Math.abs(H[e] - H[c]) > 1) continue; seen[e] = 1; q.push(e); } }
  return seen;
}
/* 落ちても 出られる マス（下りは 何段でも・上りは 1段で、道・平らな 場所・橋の 上・円の 外へ 行ける）。浅い 水は 水面の 高さ。橋は 上と 下を 別に 見る */
export function landEscape(g) {
  const { N, r, H, K, G } = g, M = N * N, es = new Uint8Array(M * 2), q = [];
  const gh = (c) => (K[c] & LIQ ? H[c] + 1 : K[c] & BRIDGE ? G[c] : H[c]), ins = (i, j) => i * i + j * j <= r * r;
  for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
    if (!ins(i, j)) continue; const c = (j + r) * N + i + r; if (H[c] === NONE) continue;
    if (K[c] & BRIDGE) { es[M + c] = 1; q.push(M + c); }
    else if ((K[c] & (TRAIL | PAD)) || !ins(i + 1, j) || !ins(i - 1, j) || !ins(i, j + 1) || !ins(i, j - 1)) { es[c] = 1; q.push(c); }
  }
  for (let n = 0; n < q.length; n++) { const a = q[n], c = a % M, ha = a >= M ? H[c] : gh(c), i = c % N; for (const d of [1, -1, N, -N]) { const e = c + d; if (e < 0 || e >= M || es[e] || H[e] === NONE || (d === 1 && i === N - 1) || (d === -1 && i === 0) || ha - gh(e) > 1) continue; es[e] = 1; q.push(e); } }
  return es;
}
export function genLand(cx, y, cz, theme, r, seed, opts = {}) {
  let G = null;
  for (let t = 0; t < 4; t++) { G = landBuild(cx, y, cz, theme, r, (seed + t * 7919) >>> 0, t === 3 ? { ...opts, gentle: true } : opts); if (G.ok) break; }
  return G;
}
function landBuild(cx, y, cz, theme, r, seed, opts) {
  const T = DG_THEMES[theme] || DG_THEMES.forest, L0 = LAND_T[theme] || LAND_D;
  const L = opts.gentle && !L0.sky ? { ...L0, hp: 8, st: 1.2, q: 0, chasm: 0, dn: 3, ns: 1, tall: 0 } : L0;
  let a = seed >>> 0; const rnd = () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const C = [];
  const F = (a1, b1, c1, d1, e1, f1, blk, mode) => {
    if ((d1 - a1 + 1) * (e1 - b1 + 1) * (f1 - c1 + 1) > 30000) { const m = (a1 + d1) >> 1; F(a1, b1, c1, m, e1, f1, blk, mode); F(m + 1, b1, c1, d1, e1, f1, blk, mode); return; }
    C.push(`fill ${a1} ${b1} ${c1} ${d1} ${e1} ${f1} ${blk}${mode ? " " + mode : ""}`);
  };
  const SB = (x, yy, z, blk) => C.push(`setblock ${x} ${yy} ${z} ${blk}`);
  const sky = !!L.sky, N = 2 * r + 1, H = new Int16Array(N * N).fill(NONE), K = new Uint8Array(N * N), GR = new Int16Array(N * N);
  const at = (i, j) => (j + r) * N + i + r, ins = (i, j, rr = r) => i * i + j * j <= rr * rr, cl = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const ed = typeof opts.ed === "number" && opts.ed >= 0 && opts.ed <= 3 ? opts.ed : -1;
  /* 出来事の 入口の 側（-F）。0 北 1 東 2 南 3 西 */
  const EV = [[0, -1], [1, 0], [0, 1], [-1, 0]][ed] || null;
  const pads = [{ n: "ent", a: [15, -4, 23, 4], h: 0 }, { n: "scene", a: [10, 2, 18, 10], h: 0 }, { n: "center", a: [-4, -4, 4, 4], h: sky ? 12 : 0 }];
  if (EV && !sky) pads.push({ n: "event", a: EV[0] ? (EV[0] > 0 ? [13, -8, 24, 8] : [-24, -8, -13, 8]) : EV[1] > 0 ? [-8, 13, 8, 24] : [-8, -24, 8, -13], h: 0 });
  /* 出来事の 階段の 上（入口から まん中まで）は 掘らない・水を 置かない */
  const strip = (i, j) => { if (!EV || sky) return false; const b = -(i * EV[0] + j * EV[1]), s = Math.abs(i * EV[1] - j * EV[0]); return s <= 9 && b >= -26 && b <= -5; };
  const line = (i0, j0, i1, j1) => { const o = [[i0, j0]]; let i = i0, j = j0; const n = Math.max(Math.abs(i1 - i0), Math.abs(j1 - j0)); for (let s = 1; s <= n; s++) { const ti = Math.round(i0 + ((i1 - i0) * s) / n), tj = Math.round(j0 + ((j1 - j0) * s) / n); if (ti !== i && tj !== j) o.push([ti, j]); if (ti !== i || tj !== j) o.push([ti, tj]); i = ti; j = tj; } return o; };
  const path = [];   /* [i, j, 高さ] の 列（道の まん中）*/
  let top = [0, 0, 0], sh = null, hpk = 0;
  if (sky) {
    /* 地面の 帯（入口・場面・まん中の 真下）は じかに 置く。島・階段・橋は 表に 入れる */
    for (let j = -5; j <= 10; j++) for (let i = -5; i <= 23; i++) if (ins(i, j)) { H[at(i, j)] = 0; K[at(i, j)] = SKIP; }
    const disc = (ci, cj, rad, h) => { for (let j = Math.ceil(cj - rad); j <= cj + rad; j++) for (let i = Math.ceil(ci - rad); i <= ci + rad; i++) if (ins(i, j, r - 1) && Math.hypot(i - ci, j - cj) <= rad) { H[at(i, j)] = h; K[at(i, j)] = SLAB; } };
    disc(0, 0, 9, 12);
    const st = [...line(19, -5, 19, -11), ...line(19, -11, 7, -11).slice(1), ...line(7, -11, 5, -7).slice(1)];
    st.forEach(([i, j], k) => path.push([i, j, Math.min(12, Math.round((k * 12) / (st.length - 4))), 0]));
    let pv = { i: 0, j: 0, rad: 9, h: 12 };
    const jt = () => Math.floor(rnd() * 3) - 1;
    for (const [ni, nj, nr] of [[2 + jt(), -18, 4], [-13, -13 + jt(), 5], [-12, 12, 6]]) {
      let cur = pv.h; const seg = [];
      for (const [i, j] of line(pv.i, pv.j, ni, nj)) { if (Math.hypot(i - pv.i, j - pv.j) > pv.rad && Math.hypot(i - ni, j - nj) > nr && cur < pv.h + 5) cur++; seg.push([i, j, Math.hypot(i - pv.i, j - pv.j) <= pv.rad ? pv.h : cur, 1]); }
      disc(ni, nj, nr, cur); path.push(...seg); if (!sh) sh = [ni, nj, cur]; pv = { i: ni, j: nj, rad: nr, h: cur };
    }
    top = [pv.i, pv.j, pv.h]; hpk = pv.h; pads.push({ n: "top", a: [pv.i - 4, pv.j - 4, pv.i + 4, pv.j + 4], h: pv.h });
  } else {
    /* まん中の 広場を 山が ぐるりと 囲む 谷。東（入口）と 出来事の 入口の 側だけ 切れて いる。
       山道は 広場の ふちから 山はだを 回りながら 上り（行き止まりで 折り返す）、尾根の 見晴らし台で 終わる */
    const D2R = Math.PI / 180, hp = L.hp, slope = hp / 9.5, rate = Math.min(0.8, 0.95 / slope), RM = 17.2;
    const A0 = (ed === 2 ? 135 : ed === 3 ? 225 : 55) * D2R, A1 = (ed === 0 ? 225 : 325) * D2R;
    const r0 = (al) => 7 + (vn(al / D2R, 0, 50, seed ^ 0x33) - 0.5) * 1.5;
    let dir = rnd() < 0.5 ? 1 : -1, al = dir > 0 ? A0 : A1, ro = r0(al), hf = 0, hold = 0, held = !!(EV && ed !== 1), turn = 0, tail = 0, li = null, lj = 0, hc = 0, shc = null, amin = al, amax = al;
    const hqT = Math.max(3, Math.round(hp * 0.4)), sp = [];
    for (let n = 0; n < 6000; n++) {
      const ds = 0.25;
      if (hold > 0) { hold -= ds; if (!shc && hold <= 6.5) shc = [al, ro]; } else if (hf < hp) hf = Math.min(hp, hf + 0.95 * ds); else if ((tail += ds) > 3) break;
      if (turn > 0) { ro += ds; turn -= ds; if (turn <= 0) dir = -dir; }
      else {
        al += (dir * ds) / ro;
        if (al > A1 || al < A0) { al = cl(al, A0, A1); if (ro + 3 > RM) break; turn = 3; continue; }
        ro = Math.max(ro, Math.min(r0(al) + hf / slope, ro + rate * ds, RM));
      }
      if (!held && hf >= hqT) { held = true; hold = 13; }
      amin = Math.min(amin, al); amax = Math.max(amax, al);
      const i = Math.round(Math.cos(al) * ro), j = Math.round(Math.sin(al) * ro);
      if (li !== null && i === li && j === lj) continue;
      if (li !== null && i !== li && j !== lj) { hc = Math.min(hc + 1, Math.round(hf)); sp.push([i, lj, hc]); }
      hc = Math.min(hc + 1, Math.round(hf)); sp.push([i, j, hc]); li = i; lj = j;
    }
    for (const [i, j] of line(23, 0, 5, 0)) path.push([i, j, 0]);
    const cor = [[5, -3, 14, 3], [23, -4, 24, 4]];
    if (EV && ed !== 1) { for (const [i, j] of line(EV[0] * 5, EV[1] * 5, EV[0] * 13, EV[1] * 13)) path.push([i, j, 0]); cor.push([Math.min(EV[0] * 5, EV[0] * 12) - 3 * Math.abs(EV[1]), Math.min(EV[1] * 5, EV[1] * 12) - 3 * Math.abs(EV[0]), Math.max(EV[0] * 5, EV[0] * 12) + 3 * Math.abs(EV[1]), Math.max(EV[1] * 5, EV[1] * 12) + 3 * Math.abs(EV[0])]); }
    for (const [i, j] of line(cl(sp[0][0], -4, 4), cl(sp[0][1], -4, 4), sp[0][0], sp[0][1])) path.push([i, j, 0]);
    path.push(...sp);
    /* 頂上の 見晴らし台と 肩の 台地（ほかの 平らな 場所と 重なる ときは 作らない）*/
    const addPad = (n, a1, h) => { if (pads.some((p) => !(p.a[2] < a1[0] || a1[2] < p.a[0] || p.a[3] < a1[1] || a1[3] < p.a[1]))) return false; pads.push({ n, a: a1, h }); return true; };
    hpk = hc; top = [li, lj, hpk]; addPad("top", [li - 2, lj - 2, li + 2, lj + 2], hpk);
    if (shc) { const qi = Math.round(Math.cos(shc[0]) * (shc[1] + 3.5)), qj = Math.round(Math.sin(shc[0]) * (shc[1] + 3.5)); if (addPad("shoulder", [qi - 4, qj - 4, qi + 4, qj + 4], hqT)) sh = [qi, qj, hqT]; }
    /* 高さの もと（すりばち形の 山・尾根の 高い 低い・起伏・裂け目・段々）→ 平らな 場所と 円の ふちに 向かって 下げる */
    const base = [...pads.filter((p) => p.h === 0).map((p) => p.a), ...cor], stp = L.st || 3, ch = [];
    if (L.chasm) for (const t of [0.3, 0.7]) ch.push(amin + (amax - amin) * t);
    for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
      if (!ins(i, j)) continue;
      const rr = Math.hypot(i, j); let an = Math.atan2(j, i); if (an < 0) an += Math.PI * 2;
      let v = Math.min((rr - r0(an)) * slope, hpk + 1);
      if (an < amin - 0.2 || an > amax + 0.2) v = Math.min(v, (hpk + 1) * (0.7 + 0.3 * vn(an / D2R, 9, 35, seed)));
      if (L.dn) v = Math.max(v, L.dn * vn(i, j, 7, seed ^ 0x51));
      if (v > 1.5 && L.ns) v += (vn(i, j, 5, seed) - 0.5) * 2 * L.ns;
      for (const ca of ch) if (rr > 7.5 && rr < 19.5 && Math.abs(an - ca) * rr < 1.4) v = L.cd ? Math.max(0, v - L.cd) : Math.min(v, vn(i, j, 3, seed) > 0.5 ? 1 : 0);
      if (L.q) v = Math.round(v / L.q) * L.q;
      v = Math.min(v, hpk + 1);
      let D = 99; for (const p of base) D = Math.min(D, Math.max(p[0] - i, i - p[2], p[1] - j, j - p[3], 0));
      v = Math.min(v, D * stp, 2 + (r - rr) * 4);
      H[at(i, j)] = Math.max(0, Math.round(v));
    }
  }
  /* 道を きざむ（はば 3。先に わき、あとで まん中）。下の 地面より 3つ 以上 高い 所は 橋 */
  const RAW = H.slice();
  const lay = (i, j, h, f, br) => {
    if (!ins(i, j, r - 1)) return; const c = at(i, j);
    if (K[c] & (PAD | LIQ)) return;
    if (sky) {
      if (K[c] & SLAB) { if (f === TRAIL) { K[c] |= TRAIL; H[c] = h; } return; }
      if ((K[c] & SKIP) && h === 0) return;
      H[c] = h; K[c] = f | (br && RAW[c] === NONE ? BRIDGE : 0); return;
    }
    H[c] = h; K[c] = f; if (br && h - RAW[c] >= 3) { K[c] |= BRIDGE; GR[c] = RAW[c]; }
  };
  for (const f of [WIDE, TRAIL]) for (const [i, j, h, b0] of path) { const br = sky ? b0 : ins(i, j, r - 1) && h - RAW[at(i, j)] >= 3; if (f === TRAIL) lay(i, j, h, f, br); else for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) if (di || dj) lay(i + di, j + dj, h, f, br); }
  for (const p of pads) for (let j = p.a[1]; j <= p.a[3]; j++) for (let i = p.a[0]; i <= p.a[2]; i++) {
    if (!ins(i, j)) continue; const c = at(i, j);
    if (sky) { if (H[c] === p.h) K[c] |= PAD; continue; }
    if (p.h > 0 && (K[c] & (TRAIL | WIDE)) && H[c] !== p.h) continue;
    H[c] = p.h; K[c] = PAD | (K[c] & TRAIL);
  }
  /* 水・溶岩: 水面は まわりの 地面と 同じ 高さ（あふれない）。道・平らな 場所・出来事の 階段の 上には 置かない */
  const wet = (i, j, lava) => {
    if (sky || !ins(i, j, r - 3) || strip(i, j)) return false; const c = at(i, j);
    if (K[c] !== 0 || H[c] > (lava ? 0 : 1)) return false;
    if (lava) for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) if (K[at(i + di, j + dj)] & (PAD | TRAIL | WIDE)) return false;
    H[c] = -1; K[c] = LIQ; GR[c] = lava ? 1 : 0; return true;
  };
  if (L.sea) { for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (ins(i, j, r - 3) && H[at(i, j)] === 0) wet(i, j, false); }
  if (L.liq) for (let d = 0; d < 360; d += 3) { const rad = 5.9 + vn(d, 0, 40, seed) * 1.2, an = (d * Math.PI) / 180; wet(Math.round(Math.cos(an) * rad), Math.round(Math.sin(an) * rad), L.liq === 2); }
  for (let k = 0; k < (L.pools || 0); k++) wet(Math.floor((rnd() * 2 - 1) * (r - 4)), Math.floor((rnd() * 2 - 1) * (r - 4)), false);
  for (let k = 0, n = 0; k < 60 && n < (L.lava || 0); k++) { const i = Math.floor((rnd() * 2 - 1) * (r - 5)), j = Math.floor((rnd() * 2 - 1) * (r - 5)); if (wet(i, j, true)) { n++; wet(i + 1, j, true); wet(i, j + 1, true); } }
  /* 落ちたら 出られない くぼみを うめる（どの マスからも 道か 円の 外へ 出られる ように）*/
  if (!sky) for (let t = 0; t < 14; t++) {
    const es = landEscape({ N, r, H, K, G: GR }); let n = 0;
    for (let j = -r + 1; j < r; j++) for (let i = -r + 1; i < r; i++) {
      const c = at(i, j); if (es[c] || K[c] !== 0 || H[c] === NONE) continue;
      let m = 99; for (const d of [1, -1, N, -N]) { const e = c + d; if (K[e] & BRIDGE) m = Math.min(m, H[e]); else if (es[e]) m = Math.min(m, K[e] & LIQ ? H[e] + 1 : H[e]); }
      if (m < 99 && m - 1 > H[c]) { H[c] = m - 1; n++; }
    }
    if (!n) break;
  }
  /* 地表の ブロック（道・橋・がけ・まだら）と 中身 */
  const pal = [], pix = (id) => { const b = B(id); let k = pal.indexOf(b); if (k < 0) { k = pal.length; pal.push(b); } return k; };
  const lightB = !T.light || /post|lantern/.test(T.light) ? "glowstone" : T.light;
  const TB = new Int32Array(N * N).fill(NONE), BD = new Int32Array(N * N).fill(NONE), HA = new Int32Array(N * N).fill(NONE), LQ = new Int32Array(N * N).fill(NONE);
  const lit = new Uint8Array(N * N); path.forEach(([i, j], k) => { if (k % 6 === 3 && ins(i, j, r - 1)) lit[at(i, j)] = 1; }); if (ins(top[0], top[1], r - 1)) lit[at(top[0], top[1])] = 1;
  for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
    const c = at(i, j), h = H[c], k = K[c]; if (h === NONE || !ins(i, j)) continue;
    if (k & SKIP) continue;
    let id;
    if (k & BRIDGE) id = L.bridge;
    else if (lit[c] && (k & (TRAIL | PAD))) id = lightB;
    else if (k & TRAIL) id = L.path;
    else if (k & LIQ) id = GR[c] ? T.base : T.fl2[0] || T.base;
    else if (k & PAD) id = h > 0 && !sky ? L.path : T.fl;
    else if (k & WIDE) id = sky ? L.path : T.fl;
    else if (k & SLAB) id = T.fl;
    else { let st = 0; for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) if (ins(i + di, j + dj) && H[at(i + di, j + dj)] !== NONE) st = Math.max(st, Math.abs(H[at(i + di, j + dj)] - h)); id = st >= 3 ? L.cliff : vn(i, j, 3, seed ^ 0x77) > 0.78 ? T.fl2[(((i * 7 + j * 13) % 64) + 64) % T.fl2.length] : T.fl; }
    TB[c] = (h + 2) * 64 + pix(id);
    if (sky) { if (k & SLAB) BD[c] = (h + 2) * 4 + 1; else if (!(k & BRIDGE) && h >= 1) BD[c] = (h + 2) * 4 + 2; HA[c] = h; }
    else { const tl = k & BRIDGE ? GR[c] : h - 1; if (tl >= 0) BD[c] = (tl + 2) * 4; if (h >= 11) HA[c] = h; if (k & LIQ) LQ[c] = (h + 2) * 2 + (GR[c] ? 1 : 0); }
  }
  const W = (i) => cx + i, Z = (j) => cz + j, baseB = B(T.base);
  if (!sky) {
    for (let dz = -r; dz <= r; dz++) { const w = Math.floor(Math.sqrt(r * r - dz * dz)); F(cx - w, y + 1, cz + dz, cx + w, y + 14, cz + dz, "air"); F(cx - w, y - 10, cz + dz, cx + w, y - 4, cz + dz, baseB, "keep"); F(cx - w, y - 3, cz + dz, cx + w, y - 1, cz + dz, baseB); }
    mesh(N, HA, (i0, j0, i1, j1, h) => F(W(i0 - r), Math.max(y + h + 1, y + 15), Z(j0 - r), W(i1 - r), y + h + 4, Z(j1 - r), "air"));
  } else {
    for (let j = -5; j <= 10; j++) { let i0 = -5, i1 = 23; while (!ins(i1, j)) i1--; F(W(i0), y + 1, Z(j), W(i1), y + 9, Z(j), "air"); F(W(i0), y - 10, Z(j), W(i1), y - 4, Z(j), baseB, "keep"); F(W(i0), y - 3, Z(j), W(i1), y - 1, Z(j), baseB); F(W(i0), y, Z(j), W(i1), y, Z(j), B(T.fl)); }
    for (const [i, j] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) SB(W(i), y, Z(j), B(lightB));
    mesh(N, HA, (i0, j0, i1, j1, h) => F(W(i0 - r), y + h + 1, Z(j0 - r), W(i1 - r), y + h + 5, Z(j1 - r), "air"));
  }
  mesh(N, BD, (i0, j0, i1, j1, k) => { const h = (k >> 2) - 2, m = k & 3; F(W(i0 - r), m === 1 ? y + h - 2 : m === 2 ? y - 2 : y, Z(j0 - r), W(i1 - r), m ? y + h - 1 : y + h, Z(j1 - r), m === 2 ? B(L.path) : baseB); });
  mesh(N, TB, (i0, j0, i1, j1, k) => F(W(i0 - r), y + (k >> 6) - 2, Z(j0 - r), W(i1 - r), y + (k >> 6) - 2, Z(j1 - r), pal[k & 63]));
  mesh(N, LQ, (i0, j0, i1, j1, k) => F(W(i0 - r), y + (k >> 1) - 1, Z(j0 - r), W(i1 - r), y + (k >> 1) - 1, Z(j1 - r), k & 1 ? "lava" : "water"));
  /* 飾り（道と 平らな 場所には 置かない。木は 道から 2マス はなす）*/
  const soft = /^(grass|flower|deadbush|mushroom_small|carpet)$/, big = /^(tree_|mushroom_big)/, one = /^(tree_|mushroom_big|cactus|ruin_pillar|pillar_bone|pillar_purpur|stalag_am|crystal|lantern|soul_lantern|stump|palace_pillar)/;
  const T2 = L.tall ? { ...T, tall: L.tall } : T, R0 = { x0: cx - r + 2, z0: cz - r + 2, X1: cx + r - 2, Z1: cz + r - 2 };
  for (const [kind, dens] of T.feats) {
    if (/^(pond|lavapool|hill|dune|hill_basalt|island|ruin_room)$/.test(kind)) continue;
    const n = Math.round(((Math.PI * r * r) / 100) * dens * (L.fx || 1.3) * (sky ? 0.5 : 1));
    for (let k = 0; k < n; k++) {
      const i = Math.floor((rnd() * 2 - 1) * (r - 3)), j = Math.floor((rnd() * 2 - 1) * (r - 3)); if (!ins(i, j, r - 3)) continue;
      const c = at(i, j); if (H[c] === NONE) continue;
      if (!(sky ? K[c] === SLAB : K[c] === 0 || (L.sea && K[c] === LIQ && /^(reef|pillar_sea)$/.test(kind)))) continue;
      if (!soft.test(kind)) {
        const m = big.test(kind) ? 2 : 0; let bad = false;
        for (let dj = -m; dj <= Math.max(m, 1); dj++) for (let di = -m; di <= Math.max(m, kind === "bones" ? 3 : 1); di++) if (!ins(i + di, j + dj) || (K[at(i + di, j + dj)] & (PAD | TRAIL | WIDE))) bad = true;
        if (bad) continue;
        K[c] |= FEAT; if (kind === "bones") K[at(i + 3, j)] |= FEAT; else if (!one.test(kind)) { K[at(i + 1, j)] |= FEAT; K[at(i, j + 1)] |= FEAT; K[at(i + 1, j + 1)] |= FEAT; }
      }
      feature(kind, W(i), Z(j), y + H[c], rnd, F, SB, T2, y + H[c] + 16, R0);
    }
  }
  /* 目印の 柱（まん中）・ふちの 明かり */
  F(cx, y + 1, cz, cx, y + (sky ? 17 : 5), cz, B(T.wall === "barrier" ? "quartz_pillar" : T.wall)); SB(cx, y + (sky ? 18 : 6), cz, B(lightB)); K[at(0, 0)] |= FEAT;
  if (!sky) for (let k = 0; k < 8; k++) { const ang = (k / 8) * Math.PI * 2, i = Math.round(Math.cos(ang) * (r - 4)), j = Math.round(Math.sin(ang) * (r - 4)), c = at(i, j); if (K[c] & (TRAIL | LIQ | PAD | FEAT)) continue; F(W(i), y + H[c] + 1, Z(j), W(i), y + H[c] + 2, Z(j), B("oak_fence")); SB(W(i), y + H[c] + 3, Z(j), B(T.light === "lantern_post" || T.light === "end_rod_post" ? "lantern" : T.light)); K[c] |= FEAT; }
  /* 歩いて 行けるか たしかめる（入口 → それぞれの 平らな 場所・頂上）*/
  const geo = { N, r, H, K, G: GR, pads, ent: [19, 0], top, sh };
  const seen = landWalk(geo, geo.ent);
  let ok = !!seen[at(top[0], top[1])];
  for (const p of pads) { const i = (p.a[0] + p.a[2]) >> 1, j = (p.a[1] + p.a[3]) >> 1; if (!seen[at(i + 1, j)]) ok = false; }
  /* 宝箱: 頂上（いちばん 良い）・肩の 台地・歩いて 行ける 所 */
  const chest = (i, j, tier) => { const c = at(i, j); F(W(i), y + H[c] + 1, Z(j), W(i), y + H[c] + 3, Z(j), "air"); C.push(chestCmds(W(i), y + H[c] + 1, Z(j), rollTier(tier, lvBonus({ x: cx, z: cz })))[0]); K[c] |= FEAT; };
  const corner = (q, hw, tier) => { for (const [a1, b1] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) { const i = q[0] + a1 * hw, j = q[1] + b1 * hw; if (!ins(i, j, r - 1)) continue; const c = at(i, j); if (seen[c] && H[c] === q[2] && !(K[c] & (TRAIL | FEAT | LIQ))) { chest(i, j, tier); return true; } } return false; };
  let nch = 3 + Math.floor(rnd() * 2);
  if (corner(top, sky ? 3 : 2, 4)) nch--;
  if (sh && corner(sh, 3, 2)) nch--;
  for (let k = 0; k < 60 && nch > 0; k++) { const i = Math.floor((rnd() * 2 - 1) * (r - 4)), j = Math.floor((rnd() * 2 - 1) * (r - 4)); if (!ins(i, j, r - 4)) continue; const c = at(i, j); if (!seen[c] || (K[c] !== 0 && K[c] !== SLAB)) continue; chest(i, j, 2); nch--; }
  return { cmds: C, name: LAND_NAME[theme] || T.name, tv: LAND_V, ok, hi: hpk, geo };
}
