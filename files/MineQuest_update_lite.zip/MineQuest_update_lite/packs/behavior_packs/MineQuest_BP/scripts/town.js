// 第102版: 町を 華やかに（飾り・シンボル・町の モンスター・広場の お店と 遊び・依頼・発展度・お祭り）
// 軽く: 飾りは 町に 近づいた ときに 1回だけ 置く（あいて いる 所だけ）。演出は その場かぎりの 粒と 音
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES, ORDER, EGGS } from "./data.js";
import { WREGIONS } from "./worldmap.js";
import { TOWNS, getTown, townAt, building } from "./structures.js";
import { load, save, loadW } from "./store.js";
import { busy, choose, notice, confirm, paged, ICON, MON_ICON, giveItem, takeItem, countItem, sound, barNote, showTitle, gold, EXH } from "./ui.js";
import { hooks, TYPE, setLook } from "./field.js";
import { battleHooks, START_HOOKS, HIT_HOOKS } from "./battle.js";
import { calcStats, BUF_KEYS, BUF_MAX } from "./core.js";
import { rankCap, storyLootOk, endingDone, rIdx } from "./quest.js";
import { award, TITLES } from "./endgame.js";
import { exOf, exSave, addPt, prize, giveGold, XT, regAtLoc, hash, dayNo, dirTo, hd, run, fx, nowT, pickA, MATS, KINDS, spotsOf, bountyOf, ENVR, envSid, groundNear } from "./explore.js";
import { scrap } from "./explore2.js";
import { boon } from "./boon.js";
import { mailTo } from "./life.js";
import { storyFest } from "./citylife.js";   /* 第125版: 物語の 祭り */

const OW = "minecraft:overworld";
const B = (t, icon) => [t, icon];
const rnd = () => Math.random();
const say = (p, m) => { try { p.sendMessage(m); } catch {} };
const bar = (p, m) => { try { barNote(p).setActionBar(m); } catch {} };
const timeOf = () => { try { return world.getTimeOfDay(); } catch { return 6000; } };
const night = () => { const t = timeOf(); return t > 13000 && t < 23000; };
const week = () => Math.floor(dayNo() / 7);
const regOfTown = (t) => { const g = getTown(t.id); return g ? regAtLoc(g) : 0; };

// ---------- 町の 記録（ワールド）----------
const TW = new Map();
function tw(id) { if (TW.has(id)) return TW.get(id); let v = null; try { const s = world.getDynamicProperty(`mrpg:tw:${id}`); if (typeof s === "string") v = JSON.parse(s); } catch {} v = v && typeof v === "object" ? v : {}; v.xp = +v.xp || 0; TW.set(id, v); return v; }
function twSave(id) { try { world.setDynamicProperty(`mrpg:tw:${id}`, JSON.stringify(tw(id))); } catch {} }
// 85) 発展度
const TLV = [0, 100, 300, 700, 1500];
export const townLv = (id) => TLV.filter((n) => tw(id).xp >= n).length;
function townXp(p, t, n) {
  const v = tw(t.id), l0 = townLv(t.id); v.xp += n; twSave(t.id); const l1 = townLv(t.id);
  if (l1 > l0) { for (const q of world.getAllPlayers()) if (hd(q.location, getTown(t.id) || q.location) < 80) { say(q, `§6§l${t.name}が 発展度 ${l1} に なった！ §r§6${OPEN[l1] || ""}`); fanfare(q); } }   // 111) ファンファーレ
}
export function townXpBy(id, n) { const t = TOWNS.find((u) => u.id === id); if (t && n > 0) townXp(null, t, n); }   /* 第125版: 物語で 町が 変わる（sagaep.js）*/
const OPEN = { 2: "銭湯が ひらいた", 3: "夜市と レストランが ひらいた", 4: "写真館と 博物館が ひらいた", 5: "限定タマゴと 名誉市民" };
function fanfare(p) { sound(p, "random.levelup", 0.8); for (const [k, pi] of [[0, 1], [4, 1.26], [8, 1.5], [12, 2]]) system.runTimeout(() => { try { p.playSound("note.pling", { pitch: pi, volume: 0.7 }); } catch {} }, k); fireworks(p.dimension, p.location); }
function fireworks(dim, L) { for (let k = 0; k < 3; k++) system.runTimeout(() => { const x = L.x + (rnd() - 0.5) * 16, z = L.z + (rnd() - 0.5) * 16, y = L.y + 12 + rnd() * 6; for (let a = 0; a < 10; a++) fx(dim, a % 2 ? "minecraft:totem_particle" : "minecraft:villager_happy", { x: x + Math.cos(a) * 2, y: y + Math.sin(a) * 2, z }); try { dim.runCommand(`playsound firework.blast @a ${Math.floor(x)} ${Math.floor(y)} ${Math.floor(z)} 1 1`); } catch {} }, k * 15); }
// プレイヤーの 町の 記録
const pt = (p) => { const e = exOf(p); e.tw = e.tw && typeof e.tw === "object" ? e.tw : {}; for (const k of ["rep", "stamp", "sv", "nm", "cel", "bd"]) e.tw[k] = e.tw[k] && typeof e.tw[k] === "object" ? e.tw[k] : {}; return [e, e.tw]; };
const disc = (p, t) => { const [, T] = pt(p); return Math.min(15, Math.floor((T.rep[t.id] || 0) / 10)) + (T.cit?.[t.id] ? 5 : 0) + (FEST() === t.id || storyFest(t.id) ? 20 : 0); };   // 92) 人気度・109) 名誉市民・80) お祭りの 値引き（%）
const price = (p, t, n) => Math.max(1, Math.floor((n * (100 - disc(p, t))) / 100));
const rep = (p, t, n) => { const [e, T] = pt(p); T.rep[t.id] = Math.min(999, (T.rep[t.id] || 0) + n); exSave(p); };
const FEST = () => TOWNS[week() % TOWNS.length]?.id;   // 80) 週に 1回 お祭り

// ---------- 71〜75・83・88・115) 飾り（町ごとに 1回・あいて いる 所だけ）----------
const DECO_V = 1;
const STY = {
  village: { wool: "red_wool", soil: "grass_block", fl: ["poppy", "dandelion", "oxeye_daisy"], rim: "flowering_azalea" }, port: { wool: "light_blue_wool", soil: "grass_block", fl: ["cornflower", "blue_orchid"], rim: "sea_lantern" },
  forest: { wool: "green_wool", soil: "grass_block", fl: ["lily_of_the_valley", "allium"], rim: "moss_block" }, desert: { wool: "orange_wool", soil: "sand", fl: ["deadbush"], rim: "cut_sandstone" },
  snow: { wool: "white_wool", soil: "grass_block", fl: ["white_tulip"], rim: "packed_ice" }, castle: { wool: "purple_wool", soil: "grass_block", fl: ["red_tulip", "allium"], rim: "polished_andesite" },
  garden: { wool: "pink_wool", soil: "grass_block", fl: ["pink_tulip", "orange_tulip"], rim: "flowering_azalea" }, sky: { wool: "yellow_wool", soil: "grass_block", fl: ["azure_bluet"], rim: "quartz_pillar" },
  dark: { wool: "black_wool", soil: "soul_soil", fl: ["wither_rose"], rim: "crying_obsidian" }, volcano: { wool: "red_wool", soil: "crimson_nylium", fl: ["crimson_roots"], rim: "magma" },
  crystal: { wool: "purple_wool", soil: "grass_block", fl: ["allium"], rim: "amethyst_block" }, farm: { wool: "yellow_wool", soil: "grass_block", fl: ["dandelion", "poppy"], rim: "hay_block" },
};
const SYMBOL = {   // 75) 町の シンボル（相対 x,z = 9,-30 の 3×3）
  village: ["時計台", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y + 8} ${Z + 1} stone_bricks`, `fill ${X - 1} ${Y + 9} ${Z - 1} ${X + 1} ${Y + 9} ${Z + 1} dark_oak_planks`, `setblock ${X} ${Y + 7} ${Z + 2} bell ["attachment"="side","direction"=0]`, `setblock ${X} ${Y + 10} ${Z} lantern`]],
  port: ["灯台", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y + 10} ${Z + 1} white_concrete`, `fill ${X - 1} ${Y + 4} ${Z - 1} ${X + 1} ${Y + 5} ${Z + 1} red_concrete`, `setblock ${X} ${Y + 11} ${Z} sea_lantern`]],
  forest: ["大樹", (X, Y, Z) => [`fill ${X} ${Y} ${Z} ${X} ${Y + 10} ${Z} oak_log`, `fill ${X - 2} ${Y + 7} ${Z - 2} ${X + 2} ${Y + 10} ${Z + 2} oak_leaves ["persistent_bit"=true]`, `fill ${X} ${Y} ${Z} ${X} ${Y + 10} ${Z} oak_log`]],
  desert: ["オベリスク", (X, Y, Z) => [`fill ${X} ${Y} ${Z} ${X} ${Y + 10} ${Z} chiseled_sandstone`, `fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y} ${Z + 1} cut_sandstone`, `setblock ${X} ${Y + 11} ${Z} gold_block`]],
  snow: ["氷の 彫刻", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y + 1} ${Z + 1} packed_ice`, `fill ${X} ${Y + 2} ${Z} ${X} ${Y + 6} ${Z} blue_ice`, `setblock ${X} ${Y + 7} ${Z} sea_lantern`]],
  castle: ["剣の 碑", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y} ${Z + 1} polished_andesite`, `fill ${X} ${Y + 1} ${Z} ${X} ${Y + 6} ${Z} iron_block`, `fill ${X - 1} ${Y + 4} ${Z} ${X + 1} ${Y + 4} ${Z} iron_block`]],
  garden: ["花の アーチ", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z} ${X - 1} ${Y + 4} ${Z} birch_fence`, `fill ${X + 1} ${Y} ${Z} ${X + 1} ${Y + 4} ${Z} birch_fence`, `fill ${X - 1} ${Y + 5} ${Z} ${X + 1} ${Y + 5} ${Z} flowering_azalea`]],
  sky: ["天使の 像", (X, Y, Z) => [`fill ${X} ${Y} ${Z} ${X} ${Y + 3} ${Z} quartz_pillar`, `fill ${X - 1} ${Y + 3} ${Z} ${X + 1} ${Y + 3} ${Z} quartz_block`, `setblock ${X} ${Y + 4} ${Z} end_rod`]],
  dark: ["鐘楼", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y + 6} ${Z + 1} polished_blackstone_bricks`, `setblock ${X} ${Y + 7} ${Z} soul_lantern`, `setblock ${X} ${Y + 5} ${Z + 2} bell ["attachment"="side","direction"=0]`]],
  volcano: ["竜の 像", (X, Y, Z) => [`fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y + 3} ${Z + 1} blackstone`, `fill ${X} ${Y + 4} ${Z - 1} ${X} ${Y + 5} ${Z + 1} blackstone`, `setblock ${X} ${Y + 5} ${Z - 2} magma`]],
  crystal: ["大結晶", (X, Y, Z) => [`fill ${X} ${Y} ${Z} ${X} ${Y + 8} ${Z} amethyst_block`, `fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y + 3} ${Z + 1} amethyst_block`, `setblock ${X} ${Y + 9} ${Z} amethyst_cluster`]],
  farm: ["風車", (X, Y, Z) => [`fill ${X} ${Y} ${Z} ${X} ${Y + 7} ${Z} oak_log`, `fill ${X - 3} ${Y + 7} ${Z + 1} ${X + 3} ${Y + 7} ${Z + 1} white_wool`, `fill ${X} ${Y + 4} ${Z + 1} ${X} ${Y + 10} ${Z + 1} white_wool`]],
};
const free = (dim, x, y, z) => { try { const b = dim.getBlock({ x, y, z }), u = dim.getBlock({ x, y: y - 1, z }); return b && b.isAir && u && !u.isAir && !u.isLiquid; } catch { return false; } };
const loaded = (dim, x, y, z) => { try { return !!dim.getBlock({ x, y, z }); } catch { return false; } };
function decorate(dim, t, g) {
  const v = tw(t.id), S = STY[t.style] || STY.village, X = Math.floor(g.x), Y = g.y, Z = Math.floor(g.z), C = [];
  if (!loaded(dim, X - 34, Y, Z - 34) || !loaded(dim, X + 34, Y, Z + 34)) return false;
  if ((v.dv || 0) < DECO_V) {
    // 71) 花壇（大通りの わき）
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let k = 9; k <= 13; k++) { const x = X + sx * 4, z = Z + sz * k; if (free(dim, x, Y, z)) C.push(`setblock ${x} ${Y - 1} ${z} ${S.soil}`, `setblock ${x} ${Y} ${z} ${pickA(S.fl)}`); }
    // 73) 門の 旗（地方の 色）
    for (const [dx, dz] of [[0, -34], [0, 34]]) for (const sx of [-3, 3]) C.push(`fill ${X + sx} ${Y + 3} ${Z + dz} ${X + sx} ${Y + 4} ${Z + dz} ${v.fc || S.wool}`);
    for (const [dx, dz] of [[-34, 0], [34, 0]]) for (const sz of [-3, 3]) C.push(`fill ${X + dx} ${Y + 3} ${Z + sz} ${X + dx} ${Y + 4} ${Z + sz} ${v.fc || S.wool}`);
    // 74) 噴水の 四すみ
    for (const [dx, dz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) if (free(dim, X + dx, Y + 1, Z + dz)) C.push(`setblock ${X + dx} ${Y + 1} ${Z + dz} ${S.rim}`);
    // 75) シンボル
    const sym = SYMBOL[t.style] || SYMBOL.village; if ([[8, -31], [10, -29], [9, -30]].every(([dx, dz]) => free(dim, X + dx, Y, Z + dz))) C.push(...sym[1](X + 9, Y, Z - 30));
    v.dv = DECO_V;
  }
  // 83) 季節の 飾り（季節が かわると おきかえ）
  const sea = SEASON_NOW();
  if (v.sea !== sea) {
    const spots = [[-6, 11], [6, -11], [-6, -11]];   /* 大通りの わき（家の 中に 入らない） */
    for (const [dx, dz] of spots) { const x = X + dx, z = Z + dz; const prevOk = v.sea !== undefined && v.ss && v.ss.includes(`${dx},${dz}`); if (!prevOk && !free(dim, x, Y, z)) continue; (v.ss = v.ss || []).includes(`${dx},${dz}`) || v.ss.push(`${dx},${dz}`); C.push(`fill ${x} ${Y} ${z} ${x} ${Y + 2} ${z} air`); C.push(...SEA_DECO[sea](x, Y, z)); }
    v.sea = sea;
  }
  // 115) 勝利の 記念碑（地方マスターに 勝った 地方の 町）
  if (v.mon !== 1 && WON_REG.has(regOfTown(t)) && !free(dim, X + 9, Y, Z + 30)) v.mon = 2;   /* ふさがって いたら あきらめる */
  if (v.mon !== 1 && v.mon !== 2 && WON_REG.has(regOfTown(t)) && free(dim, X + 9, Y, Z + 30)) { C.push(`fill ${X + 8} ${Y} ${Z + 29} ${X + 10} ${Y} ${Z + 31} chiseled_stone_bricks`, `setblock ${X + 9} ${Y + 1} ${Z + 30} gold_block`, `setblock ${X + 9} ${Y + 2} ${Z + 30} ${S.wool}`, `setblock ${X + 9} ${Y + 3} ${Z + 30} lantern`); v.mon = 1; }
  for (const c of C) run(dim, c);
  twSave(t.id); return true;
}
const SEASON_NOW = () => { const m = new Date(Date.now() + 9 * 3600000).getUTCMonth() + 1; return m <= 2 || m === 12 ? "winter" : m <= 5 ? "spring" : m <= 8 ? "summer" : "autumn"; };
const SEA_DECO = {
  winter: (x, y, z) => [`setblock ${x} ${y} ${z} spruce_log`, `setblock ${x} ${y + 1} ${z} spruce_leaves ["persistent_bit"=true]`, `setblock ${x} ${y + 2} ${z} lantern`],
  spring: (x, y, z) => [`setblock ${x} ${y} ${z} cherry_log`, `setblock ${x} ${y + 1} ${z} cherry_leaves ["persistent_bit"=true]`],
  summer: (x, y, z) => [`setblock ${x} ${y} ${z} melon_block`, `setblock ${x} ${y + 1} ${z} sea_lantern`],
  autumn: (x, y, z) => [`setblock ${x} ${y} ${z} hay_block`, `setblock ${x} ${y + 1} ${z} carved_pumpkin`],
};
let WON_REG = new Set();
// 88) 自分の 像
function statue(dim, t, g, name, pet) { const X = Math.floor(g.x) - 9, Y = g.y, Z = Math.floor(g.z) - 30; run(dim, `fill ${X - 1} ${Y} ${Z - 1} ${X + 1} ${Y} ${Z + 1} smooth_stone`); run(dim, `fill ${X} ${Y + 1} ${Z} ${X} ${Y + 2} ${Z} gold_block`); run(dim, `setblock ${X} ${Y + 3} ${Z} carved_pumpkin`); const v = tw(t.id); v.st = { n: name, pet, d: dayNo() }; twSave(t.id); }

// ---------- 76・79) 町の モンスター（町に 人が いる ときだけ・3体まで）----------
const TDECO = new Map();   // townId -> [ids]
function decoTick(p, t, g) {
  const L = TDECO.get(t.id) || [];
  const alive = L.filter((id) => { try { const e = world.getEntity(id); return e && e.isValid(); } catch { return false; } });
  if (alive.length >= 3) { TDECO.set(t.id, alive); return; }
  const fams = Object.keys(WREGIONS[regOfTown(t)]?.fams || { animal: 1 });
  const sl = ORDER.filter((s) => { const S = SPECIES[s]; return S.wild && !S.hidden && fams.includes(S.fam) && ["F", "E", "D", "C"].includes(S.rank); });
  if (!sl.length) return;
  const k = alive.length, x = Math.floor(g.x) + [6, -6, 0][k], z = Math.floor(g.z) + [0, 0, 8][k];
  let e; try { e = p.dimension.spawnEntity(TYPE, { x: x + 0.5, y: g.y, z: z + 0.5 }); } catch { return; }
  const sid = sl[(hash(t.id) + k * 7 + dayNo()) % sl.length]; setLook(e, sid); e.addTag("mrpg_tdeco");
  try { e.setDynamicProperty("mrpg:town", t.id); } catch {}
  e.nameTag = k === 2 ? `§7旅の マスターの 相棒 §f${SPECIES[sid].name}` : `§7町の §f${SPECIES[sid].name}`;
  alive.push(e.id); TDECO.set(t.id, alive);
}
function decoClean() {
  for (const e of world.getDimension("overworld").getEntities({ type: TYPE, tags: ["mrpg_tdeco"] })) { const near = world.getAllPlayers().some((q) => q.dimension.id === OW && hd(q.location, e.location) < 80); if (!near) try { e.remove(); } catch {} }
  for (const [k, L] of TDECO) TDECO.set(k, L.filter((id) => { try { return !!world.getEntity(id); } catch { return false; } }));
}
system.runInterval(decoClean, 600);
system.runTimeout(() => { try { for (const e of world.getDimension("overworld").getEntities({ type: TYPE, tags: ["mrpg_tdeco"] })) e.remove(); } catch {} }, 100);   /* 入りなおした ときに 前の 子を 消す（ふえない ように） */
const DECO_LINE = ["きょうも いい 天気", "町が にぎやかに なって きたね", "広場の 噴水、きれいでしょ", "屋台の パン、おいしいよ", "旅の 人？ ゆっくり して いってね"];
HIT_HOOKS.push((p, e) => {
  if (e.hasTag("mrpg_tdeco")) { const t = TOWNS.find((x) => x.id === e.getDynamicProperty("mrpg:town")); bar(p, `§f${e.nameTag.replace(/§./g, "")}「${pickA(DECO_LINE)}」`); fx(p.dimension, "minecraft:heart_particle", { x: e.location.x, y: e.location.y + 1.5, z: e.location.z }); if (t) { const [ex, T] = pt(p); if ((T.pet || 0) !== dayNo()) { T.pet = dayNo(); rep(p, t, 1); } } return true; }
  if (e.hasTag("mrpg_thide") || e.hasTag("mrpg_tchild")) { const kid = e.hasTag("mrpg_tchild"); let tid; try { tid = e.getDynamicProperty("mrpg:town"); } catch {} const owner = e.getDynamicProperty("mrpg:xowner"); if (owner && owner !== p.id) { bar(p, "§7（ほかの 人の 頼みごと）"); return true; } try { e.remove(); } catch {} const t = TOWNS.find((x) => x.id === tid); const d = load(p); if (!d) return true; const [ex] = pt(p); say(p, kid ? "§a迷子の 子どもを 見つけた！ 町へ 帰って いった" : "§aみーつけた！"); prize(p, d, t ? regOfTown(t) : 0, 0, 1); if (t) { rep(p, t, kid ? 8 : 4); townXp(p, t, kid ? 10 : 5); } addPt(p, ex, 4); save(p, d); return true; }
  return false;
});

// ---------- 見はり（町の 中・2秒ごと）----------
const SEEN = new Map(), QUEST = new Map();   // QUEST: pid -> { k, x, z, t }
XT.tick.push((p, d, e, i, L, tk) => {
  const t = townAt(L, 45); const sn = SEEN.get(p.id) || {}; SEEN.set(p.id, sn);
  // 39) 運び屋（町に 着いたら）
  const [, T] = pt(p);
  if (T.pk && t && T.pk.to === t.id) { if (nowT() - T.pk.t < 20 * 60000) { const tt = TOWNS.find((x) => x.id === T.pk.from); say(p, `§a${tt?.name || ""}からの 荷物を とどけた！ ${boon(p, d, 1)}§f・${giveGold(d, 1000)}`); save(p, d); rep(p, t, 6); townXp(p, t, 8); addPt(p, e, 6); } else say(p, "§7荷物の 期限が すぎて いた……"); delete T.pk; exSave(p, true); }
  if (!t) { sn.t = null; return; }
  const g = getTown(t.id); if (!g || !g.built) return;
  // 97) はじめて 来た 町の 歓迎・121) スタンプ
  if (sn.t !== t.id) { sn.t = t.id; if (!T.stamp[t.id]) { T.stamp[t.id] = dayNo(); exSave(p, true); showTitle(p, `§e§lようこそ ${t.name}へ！`, { subtitle: `§fスタンプ ${Object.keys(T.stamp).length}/${TOWNS.length}`, fadeInDuration: 8, stayDuration: 50, fadeOutDuration: 10 }); fireworks(p.dimension, L); if (Object.keys(T.stamp).length >= TOWNS.length) { award(p, d, "tw_stamp", null); save(p, d); } } else bar(p, `§e${t.name} §7発展度 ${townLv(t.id)}${FEST() === t.id ? "  §6§lお祭り中！" : ""}`);
    // 82) 勝利の お祝い
    const ri = regOfTown(t), R = WREGIONS[ri]; if (R && R.rm >= 0 && (d.story?.rm || []).includes(R.rm) && !T.cel[t.id] && !(d.story?.heroDead && !d.story?.ending)) {   /* 第124版(合議): 世界が 滅びかけて いる 間は お祝いの 声を 出さない（終わった あとに 出る）*/ T.cel[t.id] = 1; exSave(p, true); fireworks(p.dimension, L); say(p, `§6§l${t.name}の 人たち「${R.short}の 守り手に 勝ったんだって！ おめでとう！」 §r${giveGold(d, 1000 * (ri + 1))}`); save(p, d); for (let k = 0; k < 20; k++) fx(p.dimension, "minecraft:totem_particle", { x: L.x + (rnd() - 0.5) * 6, y: L.y + 3, z: L.z + (rnd() - 0.5) * 6 }); } }
  // 飾り（1回）・町の モンスター
  if (tk % 30 === 0) WON_REG = new Set(WREGIONS.map((R, k) => ((d.story?.rm || []).includes(R.rm) ? k : -1)).filter((k) => k >= 0));
  const v = tw(t.id); if (((v.dv || 0) < DECO_V || v.sea !== SEASON_NOW() || (!v.mon && WON_REG.has(regOfTown(t)))) && !building() && tk % 5 === 0) { WON_REG = new Set(WREGIONS.map((R, k) => ((d.story?.rm || []).includes(R.rm) ? k : -1)).filter((k) => k >= 0)); decorate(p.dimension, t, g); }
  if (tk % 5 === 1) decoTick(p, t, g);
  const ph = (tk + (hash(p.id) % 30)) % 30, dc = hd(L, g);
  // 72) 夜の 明かり・117) 灯台の 光・80/81) お祭りの 花火・98) 噴水の 虹
  if (night() && ph % 3 === 0) for (const [dx, dz] of [[-6, -6], [6, -6], [-6, 6], [6, 6], [-3, -16], [3, 16]]) fx(p.dimension, "minecraft:basic_flame_particle", { x: g.x + dx, y: g.y + 3.6, z: g.z + dz });
  if (night() && t.style === "port" && ph % 2 === 0) { const a = tk * 0.6; for (let k = 1; k <= 6; k++) fx(p.dimension, "minecraft:electric_spark_particle", { x: g.x + 9 + Math.cos(a) * k * 2, y: g.y + 11, z: g.z - 30 + Math.sin(a) * k * 2 }); }
  if (night() && FEST() === t.id && ph === 4) fireworks(p.dimension, g);
  if (!night() && dc < 10 && ph % 4 === 0 && !/rain|thunder/i.test(WW)) for (let k = 0; k < 7; k++) fx(p.dimension, ["minecraft:redstone_ore_dust_particle", "minecraft:villager_happy", "minecraft:electric_spark_particle"][k % 3], { x: g.x - 3 + k, y: g.y + 3 + Math.sin(k / 2) * 1.5, z: g.z });
  // 91) 音楽隊（広場に 入ったら・3分に 1回）
  if (dc < 8 && nowT() - (sn.mu || 0) > 180000) { sn.mu = nowT(); const M = [1, 1.26, 1.5, 1.26, 1, 1.5, 2]; M.forEach((pi, k) => system.runTimeout(() => { try { p.playSound("note.harp", { pitch: pi, volume: 0.5 }); } catch {} }, k * 5)); }
  // 96) 時報の 鐘（朝・昼・夕）
  const tt = timeOf(), slot = tt < 300 ? 0 : tt >= 6000 && tt < 6300 ? 1 : tt >= 12000 && tt < 12300 ? 2 : -1; if (slot >= 0 && sn.bell !== `${dayNo()}:${slot}`) { sn.bell = `${dayNo()}:${slot}`; for (let k = 0; k < 3; k++) system.runTimeout(() => { try { p.playSound("block.bell.hit", { pitch: 0.9, volume: 0.6 }); } catch {} }, k * 20); }
  // 78) 町の 人の 会話（6秒ごと）
  if (ph % 3 === 2) { let n = []; try { n = p.dimension.getEntities({ type: "mrpg:npc", location: L, maxDistance: 4 }); } catch {} if (n.length) bar(p, `§f${(n[0].nameTag || "町の 人").replace(/§./g, "")}「${talkLine(i)}」`); }
  // 36) なくし物さがし
  const q = QUEST.get(p.id); if (q && q.k === "lost") { if (nowT() - q.t > 180000) { QUEST.delete(p.id); say(p, "§7なくし物は 見つからなかった……"); } else { fx(p.dimension, "minecraft:villager_happy", { x: q.x + 0.5, y: q.y + 0.5, z: q.z + 0.5 }); if (hd(L, q) < 2) { QUEST.delete(p.id); say(p, "§aなくし物を 見つけた！"); prize(p, d, i, 0, 1); rep(p, t, 5); townXp(p, t, 5); addPt(p, e, 3); } } }
  // 125) 像の 前の 記念撮影 は 広場の 画面から
});
let WW = ""; try { world.afterEvents.weatherChange.subscribe((ev) => { try { WW = String(ev.newWeather || ""); } catch {} }); } catch {}
function talkLine(i) { const w = XT.evt ? null : null; const R = WREGIONS[i]; const L = [`${R?.short || ""}の 外には めずらしい 子が いる らしい`, "展望台に 登ると 遠くまで 見えるよ", "賞金首の 足あとを 見た 人が いる", "夜は 流れ星が 落ちる ことが ある", "広場の 屋台、今日は 何が あるかな"]; return pickA(L); }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { SEEN.delete(playerId); QUEST.delete(playerId); }); } catch {}

// ---------- 戦いの はじめ（101 朝ごはん・94 吟遊詩人の 歌・105 占い・100 湯上がり）----------
START_HOOKS.push((B0, p) => {
  if (!p || B0.pvp) return;
  const [e, T] = pt(p); const mine = (B0.allies || []).filter((f) => !f.guest && (!f.owner || f.owner === p.id)); if (!mine.length) return;
  const up = (f, ks) => { for (const k of ks) f.buf[k] = Math.min(BUF_MAX, (f.buf[k] || 0) + 1); };
  if (T.bf) { for (const f of mine) up(f, ["atk", "mat"]); say(p, "§e朝ごはんの 力！ 物力・魔力 +1"); delete T.bf; }
  if (T.song) { for (const f of mine) f.mp = f.mx.mp; say(p, "§b吟遊詩人の 歌が 頭に のこって いる… MP 満タン"); delete T.song; }
  if (T.bath) { for (const f of mine) up(f, BUF_KEYS); say(p, "§b湯上がりで 体が 軽い！ 全能力 +1"); delete T.bath; }
  if (T.fort && T.fort[0] === dayNo()) { const fm = mine.filter((f) => SPECIES[f.m?.sp]?.fam === T.fort[1]); for (const f of fm) up(f, ["atk", "def"]); if (fm.length) say(p, `§d占いの とおり！ ${fm.map((f) => f.name).join("・")}の 物力・硬力 +1`); }
  exSave(p);
});
// 38) 宿屋の 夢・101) 朝ごはん・123) 旅日記
EXH.inn = async (p) => {
  const [e, T] = pt(p); T.bf = 1;
  const i = regAtLoc(p.location), miss = spotsOf(i).filter((q) => q.info?.ok && !q.info.skip && !e.f[`${i}.${q.k}`] && KINDS[q.k]);
  const dream = miss.length ? `${KINDS[miss[0].k].n}が ${dirTo(p.location, miss[0].info)}の ほうに ある 夢を 見た` : "何も 思い出せない 夢だった";
  e.dd = e.dd && e.dd.d === dayNo() ? e.dd : { d: dayNo(), pt: e.pt, w: e.walk || 0 };
  exSave(p, true);
  await notice(p, "朝", [`§d夢: §f${dream}`, "§e朝ごはんを 食べた！ §7（次の 戦いで 物力・魔力 +1）", "", `§6旅日記（今日）: §f探索 +${e.pt - e.dd.pt}pt・歩いた ${Math.max(0, (e.walk || 0) - e.dd.w)}m`, ...(e.sc || []).slice(0, 3).map((x) => `§7・${x}`)].join("\n"));
};
// 町の 依頼の 勝ち数・新聞
battleHooks.push((B0, x) => { const { p } = x; if (B0.result !== "win") return; try { if (!p.isValid()) return; } catch { return; } const [e, T] = pt(p); const i = regAtLoc(B0.center || p.location); T.win = T.win && T.win.d === dayNo() ? T.win : { d: dayNo() }; T.win[i] = (T.win[i] || 0) + 1; if (B0.bounty) news((B0.wtags || []).includes("mrpg_xboss") ? `${p.name}が 強敵に 勝った` : `${p.name}が 賞金首を 倒した`); exSave(p); });
function news(s) { let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:news") || "[]"); } catch {} L.unshift(`${new Date(Date.now() + 9 * 3600000).toISOString().slice(5, 10)} ${s}`); try { world.setDynamicProperty("mrpg:news", JSON.stringify(L.slice(0, 15))); } catch {} }

// ---------- 町の 広場（ガイドブック → 冒険）----------
TITLES.tw_stamp = ["町めぐり", "すべての 町を おとずれる"]; TITLES.tw_sv = ["お土産 名人", "すべての 町の お土産"]; TITLES.tw_face = ["町の 顔", "自分の 像の 前で 記念撮影"]; TITLES.tw_lotto = ["強運", "宝くじの 1等"];
TOWNS.forEach((t) => { TITLES[`tw_cit_${t.id}`] = [`${t.name.split(" ").pop()}の 名誉市民`, `${t.name}の 名誉市民に なる`]; });
const STALL = ["c_herb2", "c_fruit", "c_drop", "c_water2", "c_fairy", "c_revive", "x_bread", "x_flower", "f_exp1k", "g_sp", "x_snack", "x_chute", "x_wing2"];
const NIGHT = [["x_rmap", 15000], ["rf_2", 6000], ["i_tal1", 12000], ["c_revive2", 4000], ["x_fossil", 3000], ["f_exp10k", 9000]];
const MEIBUTSU = { port: ["x_mari", 3, 1500], snow: ["x_frost", 3, 1500], volcano: ["x_volka", 3, 1500], desert: ["x_sand", 3, 1500], crystal: ["x_crys", 3, 2000], forest: ["x_silva", 3, 1200], dark: ["x_necro", 3, 2000], sky: ["x_celes", 3, 2500], castle: ["x_ruins", 3, 1500], village: ["x_arca", 3, 1000], garden: ["x_snack", 1, 1200], farm: ["x_bread", 3, 600] };
const MENU = [
  ["§l町の 案内\n§8発展度・人気度・お祭り・時計", info], ["§6§l依頼掲示板\n§8町の 人の 頼み（毎日 3つ）", requests], ["§l屋台通り\n§8日がわりの 品（値引きあり）", stalls], ["§lくじ引き・宝くじ\n§81日 1回・週 1回", lottery],
  ["§l花屋・パン屋・両替屋", shops], ["§l占い師・道場・吟遊詩人", mystic], ["§l郵便屋・運び屋・新聞", post], ["§l子どもの 頼み・かくれんぼ・なくし物", kids],
  ["§lお土産・名物・誕生日", gifts], ["§l銭湯・レストラン\n§8発展度 2・3", bathFood], ["§l夜市\n§8発展度 3・夜だけ", nightMarket], ["§l写真館・博物館\n§8発展度 4", museum],
  ["§l像・記念碑・飾りつけ", monuments], ["§lおばあさんの うわさ・ギルドの 依頼", gossip], ["§l船旅（港町）・今週の 強い マスター", travel], ["§6§l限定タマゴ・名誉市民\n§8発展度 5", premium],
];
EXH.town = async (p, d, t) => {
  if (!t || !getTown(t.id)) return;
  for (;;) {
    const lv = townLv(t.id), [e, T] = pt(p);
    const s = await paged(p, t.name, `§f発展度 §e${lv}§f・人気度 §e${T.rep[t.id] || 0}§f・値引き §e${disc(p, t)}%${FEST() === t.id ? "  §6§lお祭り中！" : ""}\n§7いま ${jst()}`, MENU.map(([n]) => B(n, ICON("i_shop"))), 8);
    if (s < 0 || !MENU[s]) return;
    const d2 = load(p); if (!d2) return;
    await MENU[s][1](p, d2, t);
  }
};
const jst = () => { const n = new Date(Date.now() + 9 * 3600000); return `${n.getUTCHours()}時${String(n.getUTCMinutes()).padStart(2, "0")}分`; };   // 118) 時計台
async function info(p, d, t) {
  const [e, T] = pt(p), lv = townLv(t.id), v = tw(t.id);
  await notice(p, t.name, [`§f発展度 §e${lv}§f（${v.xp}${TLV[lv] ? ` / 次 ${TLV[lv]}` : ""}）`, `§f人気度 §e${T.rep[t.id] || 0}§7（10ごとに 値引き 1%・最大 15%）`, `§fシンボル: §e${(SYMBOL[t.style] || SYMBOL.village)[0]}`, `§fお祭り: §e${TOWNS.find((x) => x.id === FEST())?.name || ""}§7（週がわり・20%引き・夜に 花火）`, `§f時計台: §e${jst()}`, "", "§7発展度は 依頼・花を 植える・子どもの 頼み などで 上がる", ...Object.entries(OPEN).map(([k, s]) => `${lv >= +k ? "§a○" : "§7・"} 発展度 ${k}: ${s}`)].join("\n"));
}
// 84) 依頼掲示板（毎日 3つ）
function reqsOf(t) {
  const h = hash(`${t.id}:${dayNo()}`), i = regOfTown(t), R = WREGIONS[i] || WREGIONS[0], fams = Object.keys(R.fams || { animal: 1 });
  return [
    { k: "fam", fam: fams[h % fams.length], lv: Math.max(5, R.lv[0]), n: `${famName(fams[h % fams.length])}の 仲間を 見せて（Lv${Math.max(5, R.lv[0])} 以上）` },
    { k: "mat", id: MATS[(h >>> 3) % MATS.length], c: 3 + ((h >>> 5) % 4), n: "" },
    { k: "win", i, c: 3 + ((h >>> 7) % 3), n: `今日 ${R.short}で ${3 + ((h >>> 7) % 3)}回 勝つ` },
  ].map((q) => (q.k === "mat" ? { ...q, n: `${ITEMS[q.id]?.name}を ${q.c}こ ほしい` } : q));
}
const famName = (f) => ({ blob: "粘液系", animal: "動物系", beast: "獣系", aqua: "水系", dragon: "竜系", golem: "物質系", sword: "剣系", nether: "魔系", king: "王系", god: "神系" })[f] || f;
async function requests(p, d, t) {
  for (;;) {
    const [e, T] = pt(p); T.rq = T.rq && T.rq.d === dayNo() ? T.rq : { d: dayNo(), done: {} };
    const Q = reqsOf(t);
    const c = await choose(p, "依頼掲示板", "§7毎日 かわる。お礼: 道具・人気度・町の 発展", [...Q.map((q, k) => B(`${T.rq.done[`${t.id}${k}`] ? "§a○ " : ""}${q.n}`, ICON("i_help"))), B("§7戻る", ICON("i_back"))]);
    const q = Q[c]; if (!q) return;
    if (T.rq.done[`${t.id}${c}`]) { await notice(p, "依頼", "§7もう 終わった"); continue; }
    if (Object.keys(T.rq.done).length >= 3) { await notice(p, "依頼", "§7今日は もう 3つ こなした（全部の 町で 1日 3つまで）"); continue; }
    let okk = false;
    if (q.k === "fam") okk = [...d.party, ...(d.bench || [])].some((m) => SPECIES[m.sp]?.fam === q.fam && m.lv >= q.lv);
    else if (q.k === "mat") okk = countItem(p, `mrpg:${q.id}`) >= q.c && (await confirm(p, "依頼", `§f${ITEMS[q.id]?.name}を ${q.c}こ わたす？`, "わたす", "やめる")) && takeItem(p, `mrpg:${q.id}`, q.c);
    else okk = ((T.win && T.win.d === dayNo() && T.win[q.i]) || 0) >= q.c;
    if (!okk) { await notice(p, "依頼", "§7まだ たりない"); continue; }
    T.rq.done[`${t.id}${c}`] = 1; const d2 = load(p); const g = `${boon(p, d2, 2)}§f・${giveGold(d2, 500 + 150 * regOfTown(t))}`; save(p, d2);   /* 第124版: お礼は 道具が 主 */ rep(p, t, 10); townXp(p, t, 25); addPt(p, e, 5); exSave(p, true);
    sound(p, "random.levelup"); await notice(p, "依頼", `§aありがとう！ §f${g}・人気度 +10`);
  }
}
// 77) 屋台通り
async function stalls(p, d, t) {
  const h = hash(`${t.id}:${dayNo()}`), cap = rankCap(d), L = [0, 1, 2, 3].map((k) => STALL[(h + k * 5) % STALL.length]).filter((id, k, a) => ITEMS[id] && a.indexOf(id) === k && storyLootOk(ITEMS[id], null, cap));
  for (;;) { const d2 = load(p); const c = await choose(p, "屋台通り", `§7お金 ${gold(d2.gold)}・値引き ${disc(p, t)}%`, [...L.map((id) => B(`${ITEMS[id].name}\n§8${price(p, t, base(id)).toLocaleString()} タヨ`, ICON("i_shop"))), B("§7戻る", ICON("i_back"))]); const id = L[c]; if (!id) return; if (!pay(p, price(p, t, base(id)))) { await notice(p, "屋台", "§7お金が たりない"); continue; } giveItem(p, `mrpg:${id}`, 1); sound(p, "random.orb"); townXp(p, t, 1); }
}
const base = (id) => Math.max(100, ITEMS[id]?.price || 800);
function pay(p, n) { const d = load(p); if (!d || (d.gold || 0) < n) return false; d.gold -= n; save(p, d); return true; }
// 99) くじ引き・120) 宝くじ
async function lottery(p, d, t) {
  const [e, T] = pt(p);
  const c = await choose(p, "くじ引き", `§7くじ引きは 1日 1回 むりょう。宝くじは 週に 1枚（1000 タヨ）。先週の 当たり番号: §e${String(hash(`L${week() - 1}`) % 100).padStart(2, "0")}`, [B(T.lot === dayNo() ? "§7くじ引き（今日は 引いた）" : "§e§lくじ引き", ICON("i_shop")), B(T.lt && T.lt[0] === week() ? `§7宝くじ（${String(T.lt[1]).padStart(2, "0")}番を 買った）` : "§l宝くじを 買う", ICON("i_shop")), B(T.lt && T.lt[0] < week() ? "§a§l宝くじの 結果を 見る" : "§7宝くじの 結果（来週）", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && T.lot !== dayNo()) { T.lot = dayNo(); exSave(p, true); const r = rnd(); const d2 = load(p); if (r < 0.01) { prize(p, d2, 9, 2, 1); await notice(p, "くじ引き", "§6§l大当たり！"); } else if (r < 0.2) { prize(p, d2, regOfTown(t), 0, 1); await notice(p, "くじ引き", "§a当たり！"); } else { const g = giveGold(d2, 100 + Math.floor(rnd() * 400)); await notice(p, "くじ引き", `§fはずれ… §7（参加賞 ${g}）`); } save(p, d2); }
  if (c === 1 && T.lt && T.lt[0] < week()) { await notice(p, "宝くじ", "§7先に 前の 宝くじの 結果を 見よう"); return; }
  if (c === 1 && !(T.lt && T.lt[0] === week())) { if (!pay(p, 1000)) { await notice(p, "宝くじ", "§7お金が たりない"); return; } T.lt = [week(), Math.floor(rnd() * 100)]; exSave(p, true); await notice(p, "宝くじ", `§f${String(T.lt[1]).padStart(2, "0")}番を 買った！ §7来週 結果が わかる`); }
  if (c === 2 && T.lt && T.lt[0] < week()) { const win = hash(`L${T.lt[0]}`) % 100, n = T.lt[1]; delete T.lt; exSave(p, true); const d2 = load(p); const prz = n === win ? 100000 : Math.abs(n - win) === 1 ? 10000 : n % 10 === win % 10 ? 2000 : 0; if (prz) { giveGold(d2, prz); if (prz === 100000) award(p, d2, "tw_lotto", null); } save(p, d2); await notice(p, "宝くじ", `§f当たり番号 §e${String(win).padStart(2, "0")}§f・あなたの 番号 §e${String(n).padStart(2, "0")}\n${prz ? `§6§l当たり！ ${prz.toLocaleString()} タヨ` : "§7はずれ"}`); }
}
// 102) 花屋・103) パン屋・104) 両替屋
async function shops(p, d, t) {
  for (;;) {
    const [e, T] = pt(p); T.ex = T.ex && T.ex[0] === dayNo() ? T.ex : [dayNo(), 0];
    const c = await choose(p, "花屋・パン屋・両替屋", `§7お金 ${gold(load(p).gold)}`, [B(`§l花の たね §8${price(p, t, 1000)} タヨ（畑に まく）`, ICON("i_shop")), B(`§l町に 花を 植える §8${price(p, t, 1000)} タヨ（発展度 +10）`, ICON("i_skill")), B(`§l町の パン §8${price(p, t, 300)} タヨ（料理の 材料）`, ICON("i_shop")), B(`§l素材を 売る §81こ 50 タヨ（今日 あと ${50 - T.ex[1]}こ）`, ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) { if (!pay(p, price(p, t, 1000))) { await notice(p, "花屋", "§7お金が たりない"); continue; } giveItem(p, "mrpg:x_flower", 1); }
    else if (c === 1) { if (!pay(p, price(p, t, 1000))) { await notice(p, "花屋", "§7お金が たりない"); continue; } townXp(p, t, 10); rep(p, t, 2); const g = getTown(t.id); for (let k = 0; k < 6; k++) { const x = Math.floor(g.x + (rnd() - 0.5) * 50), z = Math.floor(g.z + (rnd() - 0.5) * 50); if (free(p.dimension, x, g.y, z)) { run(p.dimension, `setblock ${x} ${g.y} ${z} ${pickA((STY[t.style] || STY.village).fl)}`); break; } } await notice(p, "花屋", "§a花を 植えた！ 町が すこし はなやかに なった"); }
    else if (c === 2) { if (!pay(p, price(p, t, 300))) { await notice(p, "パン屋", "§7お金が たりない"); continue; } giveItem(p, "mrpg:x_bread", 1); }
    else if (c === 3) { const have = MATS.filter((id) => countItem(p, `mrpg:${id}`) > 0); if (!have.length || T.ex[1] >= 50) { await notice(p, "両替屋", "§7売れる 素材が ない"); continue; } const k = await paged(p, "両替屋", "", have.map((id) => B(`${ITEMS[id].name} §8×${countItem(p, `mrpg:${id}`)}`, ICON("i_shop"))), 8); if (k < 0) continue; const n = Math.min(countItem(p, `mrpg:${have[k]}`), 50 - T.ex[1]); if (!takeItem(p, `mrpg:${have[k]}`, n)) continue; T.ex[1] += n; exSave(p, true); const d2 = load(p); giveGold(d2, n * 50); save(p, d2); }
    else return;
  }
}
// 105) 占い師・106) 道場・94/37) 吟遊詩人
async function mystic(p, d, t) {
  const [e, T] = pt(p), fams = ["blob", "animal", "beast", "aqua", "dragon", "golem", "sword", "nether"];
  const c = await choose(p, "占い師・道場・吟遊詩人", "", [B(T.fort && T.fort[0] === dayNo() ? `§7今日の ラッキー系統: ${famName(T.fort[1])}` : "§l占い §8（1日 1回）", ICON("i_help")), B(T.dj === dayNo() ? "§7道場（今日は 修行した）" : "§l道場 §8仲間 1体に SP +3（1日 1回）", ICON("i_fight")), B(T.bd2 === dayNo() ? "§7吟遊詩人（今日は 聞いた）" : "§l吟遊詩人の 歌 §8次の 戦いで MP 満タン・秘境の ヒント", ICON("i_help")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && !(T.fort && T.fort[0] === dayNo())) { T.fort = [dayNo(), fams[hash(`${p.id}${dayNo()}`) % fams.length]]; exSave(p, true); await notice(p, "占い", `§d今日の ラッキー系統は §e${famName(T.fort[1])}§d！ §7（戦いの はじめに 物力・硬力 +1）`); }
  if (c === 1 && T.dj !== dayNo()) { const L = [...d.party, ...(d.bench || [])]; const k = await paged(p, "道場", "§fだれを きたえる？", L.map((m) => B(`${m.nm} §7Lv${m.lv}`, MON_ICON(m.sp))), 8); if (k < 0 || !L[k]) return; const d2 = load(p); const m = [...d2.party, ...(d2.bench || [])].find((x) => x.id === L[k].id); if (!m) return; m.spl = (m.spl || 0) + 3; save(p, d2); T.dj = dayNo(); exSave(p, true); await notice(p, "道場", `§a${m.nm}の SPが 3 ふえた！`); }
  if (c === 2 && T.bd2 !== dayNo()) { T.bd2 = dayNo(); T.song = 1; exSave(p, true); const i = regOfTown(t), q = spotsOf(i).find((s) => s.info?.ok && !s.info.skip && !e.f[`${i}.${s.k}`] && KINDS[s.k]); const g = getTown(t.id); for (let k = 0; k < 5; k++) system.runTimeout(() => { try { p.playSound("note.flute", { pitch: [1, 1.2, 1.5, 1.2, 1][k], volume: 0.6 }); } catch {} }, k * 6); await notice(p, "吟遊詩人", `§f♪ ${q && g ? `${KINDS[q.k].n}は 町から ${dirTo(g, q.info)}の 方…` : "この 地方の 秘境は もう 歌に ならない"} ♪\n§7（次の 戦いで MP 満タン）`); }
}
// 107) 郵便屋・39) 運び屋・108) 新聞
async function post(p, d, t) {
  const [e, T] = pt(p);
  const c = await choose(p, "郵便屋・運び屋・新聞", "", [B("§l郵便を 出す §8素材・料理を ほかの 人へ", ICON("i_shop")), B(T.pk ? `§7運び屋（${TOWNS.find((x) => x.id === T.pk.to)?.name}へ 運び中）` : "§l運び屋 §8荷物を 別の 町へ（20分）", ICON("i_run")), B("§l町の 新聞", ICON("i_help")), B("§7戻る", ICON("i_back"))]);
  if (c === 0) {
    const names = [...new Set(world.getAllPlayers().filter((q) => q.id !== p.id).map((q) => q.name))]; if (!names.length) { await notice(p, "郵便屋", "§7いま ほかの 人が いない"); return; }
    const a = await paged(p, "だれに？", "", names.map((n) => B(n, ICON("i_party"))), 8); if (a < 0) return;
    const items = [...MATS, "x_fossil", "x_bread", "x_snack", "fd_stew", "fd_soup", "fd_curry", "fd_cake", "fd_tea", "fd_bento", "fd_egg", "fd_onigiri"].filter((id) => ITEMS[id] && countItem(p, `mrpg:${id}`) > 0);
    if (!items.length) { await notice(p, "郵便屋", "§7おくれる 品が ない"); return; }
    const b = await paged(p, "何を？（1こ）", "", items.map((id) => B(`${ITEMS[id].name} §8×${countItem(p, `mrpg:${id}`)}`, ICON("i_shop"))), 8); if (b < 0) return;
    if (!takeItem(p, `mrpg:${items[b]}`)) return; mailTo(names[a], items[b], 1); await notice(p, "郵便屋", `§a${names[a]}へ ${ITEMS[items[b]].name} を おくった`); return;
  }
  if (c === 1 && T.pk && nowT() - T.pk.t > 20 * 60000) delete T.pk;   /* 期限が すぎたら 次を うけられる */
  if (c === 1 && !T.pk) { T.pkd = T.pkd && T.pkd[0] === dayNo() ? T.pkd : [dayNo(), 0]; if (T.pkd[1] >= 3) { await notice(p, "運び屋", "§7今日は もう 3回 運んだ"); return; } const L = TOWNS.filter((x) => x.id !== t.id && getTown(x.id)?.built && (d.towns || []).includes(x.id)); if (!L.length) { await notice(p, "運び屋", "§7とどけ先の 町を まだ 知らない"); return; } const to = pickA(L); T.pkd[1]++; T.pk = { from: t.id, to: to.id, t: nowT() }; exSave(p, true); await notice(p, "運び屋", `§f${to.name}へ 荷物を とどけて！ §7（20分 以内・着いたら 自動で わたす）`); }
  if (c === 2) { let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:news") || "[]"); } catch {} if (!Array.isArray(L)) L = []; const b = bountyOf(regOfTown(t)); await notice(p, `${t.name} 新聞`, [`§6■ 今日の 賞金首: §f${b.epi}${SPECIES[b.sid]?.name || ""}（${WREGIONS[b.i]?.short}）`, "§6■ ワールドの できごと", ...L.map((x) => `§f・${x}`), "§6■ あなたの 最近", ...(e.sc || []).slice(0, 5).map((x) => `§7・${x}`)].join("\n")); }   // 116) 掲示板の 賞金首
}
// 93) 子どもの 頼み・42) かくれんぼ・36) なくし物
async function kids(p, d, t) {
  const g = getTown(t.id); if (!g) return; const [, T] = pt(p);
  const c = await choose(p, "子どもたち", "", [B("§l迷子の 子どもを さがして §8町の 外", ICON("i_run")), B("§lかくれんぼ §8町の 中に かくれた 子を さがす（2分）", ICON("i_run")), B("§lなくし物さがし §8町の 中の 光る 物（3分）", ICON("i_run")), B("§7戻る", ICON("i_back"))]);
  T.kd = T.kd && T.kd.d === dayNo() ? T.kd : { d: dayNo() };   /* それぞれ 1日 1回 */
  if (c >= 0 && c <= 2 && T.kd[c]) { await notice(p, "子どもたち", "§7今日は もう やった。また 明日"); return; }
  if (c === 0 || c === 1) {
    const kid = c === 0; let pos = null;
    for (let k = 0; k < 8 && !pos; k++) { const a = rnd() * Math.PI * 2, r = kid ? 50 + rnd() * 20 : 8 + rnd() * 22, x = Math.floor(g.x + Math.cos(a) * r), z = Math.floor(g.z + Math.sin(a) * r); let tb; try { tb = p.dimension.getTopmostBlock({ x, z }); } catch {} if (tb && !tb.isLiquid) pos = { x, y: tb.location.y + 1, z }; }
    if (!pos) { await notice(p, "子どもたち", "§7（いまは できない）"); return; }
    T.kd[c] = 1; exSave(p, true);
    const sl = ORDER.filter((s) => SPECIES[s].wild && !SPECIES[s].hidden && ["F", "E"].includes(SPECIES[s].rank)); let e; try { e = p.dimension.spawnEntity(TYPE, { x: pos.x + 0.5, y: pos.y, z: pos.z + 0.5 }); } catch { return; }
    setLook(e, pickA(sl)); e.addTag(kid ? "mrpg_tchild" : "mrpg_thide"); e.addTag("mrpg_keep"); try { e.setDynamicProperty("mrpg:town", t.id); e.setDynamicProperty("mrpg:xowner", p.id); e.setDynamicProperty("mrpg:rt", Date.now() - 300000 + 180000); e.triggerEvent("mrpg:keep"); } catch {}
    e.nameTag = kid ? "§b迷子の 子ども" : ""; await notice(p, "子どもたち", kid ? `§f町の ${dirTo(g, pos)}の 外で 迷子に なったらしい……（なぐると 見つけた ことに なる）` : "§fもう いいかい？ §7（町の 中の どこかに いる子を なぐる）"); return;
  }
  if (c === 2) { const L = []; for (let k = 0; k < 10 && !L.length; k++) { const x = Math.floor(g.x + (rnd() - 0.5) * 56), z = Math.floor(g.z + (rnd() - 0.5) * 56); if (free(p.dimension, x, g.y, z)) L.push({ x, y: g.y, z }); } if (!L.length) return; T.kd[2] = 1; exSave(p, true); QUEST.set(p.id, { k: "lost", ...L[0], t: nowT() }); await notice(p, "なくし物", "§f町の どこかで 光って いる 物を さがして！（3分）"); }
}
// 122) お土産・90) 名物・124) 誕生日
async function gifts(p, d, t) {
  const [e, T] = pt(p), M = MEIBUTSU[t.style] || MEIBUTSU.village, bday = TOWNS[hash(`b${dayNo()}`) % TOWNS.length];
  const c = await choose(p, "お土産・名物・誕生日", `§7今日は ${bday.name}の 住人の 誕生日`, [B(T.sv[t.id] ? "§7お土産（もらった）" : "§lお土産を もらう §8町ごとに 1回", ICON("i_shop")), B(T.nm[t.id] === dayNo() ? "§7名物（今日は 買った）" : `§l名物: ${ITEMS[M[0]]?.name}×${M[1]} §8${price(p, t, M[2])} タヨ`, ICON("i_shop")), B(bday.id === t.id ? (T.bd[t.id] === dayNo() ? "§7プレゼントを わたした" : "§d§l誕生日プレゼントを わたす §8500 タヨ") : "§7（この 町の 誕生日では ない）", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && !T.sv[t.id]) { T.sv[t.id] = 1; exSave(p, true); const n = Object.keys(T.sv).length; giveItem(p, "mrpg:x_snack", 1); await notice(p, "お土産", `§a${t.name}の お土産（おやつ）を もらった！ §7（${n}/${TOWNS.length}・ぜんぶの 町で 称号）`); if (n >= TOWNS.length) { const d2 = load(p); award(p, d2, "tw_sv", null); save(p, d2); } }
  if (c === 1 && T.nm[t.id] !== dayNo()) { if (!pay(p, price(p, t, M[2]))) { await notice(p, "名物", "§7お金が たりない"); return; } T.nm[t.id] = dayNo(); exSave(p, true); giveItem(p, `mrpg:${M[0]}`, M[1]); }
  if (c === 2 && bday.id === t.id && T.bd[t.id] !== dayNo()) { if (!pay(p, 500)) return; T.bd[t.id] = dayNo(); rep(p, t, 20); exSave(p, true); const d2 = load(p); prize(p, d2, regOfTown(t), 0, 1); save(p, d2); fireworks(p.dimension, p.location); await notice(p, "誕生日", "§d「ありがとう！ これ、お礼に」 §7（人気度 +20）"); }
}
// 100) 銭湯・86) レストラン
async function bathFood(p, d, t) {
  const lv = townLv(t.id), [e, T] = pt(p);
  const c = await choose(p, "銭湯・レストラン", "", [B(lv >= 2 ? `§l銭湯 §8${price(p, t, 300)} タヨ（全回復＋湯上がり）` : "§7銭湯（発展度 2）", ICON("i_inn")), B(lv >= 3 ? `§lレストラン §8${price(p, t, 1200)} タヨ（料理を 食べる）` : "§7レストラン（発展度 3）", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && lv >= 2) { if (!pay(p, price(p, t, 300))) { await notice(p, "銭湯", "§7お金が たりない"); return; } const d2 = load(p); for (const m of d2.party) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } save(p, d2); T.bath = 1; exSave(p, true); sound(p, "random.splash"); await notice(p, "銭湯", "§bいい お湯だった！ §7（仲間が 全回復・次の 戦いで 全能力 +1）"); }
  if (c === 1 && lv >= 3) { const L = ["fd_stew", "fd_soup", "fd_curry", "fd_cake", "fd_tea", "fd_bento"].filter((id) => ITEMS[id]); const k = await paged(p, "レストラン", "§7食べると 次の 戦い 3回 強く なる", L.map((id) => B(ITEMS[id].name, ICON("i_shop"))), 8); if (k < 0) return; if (!pay(p, price(p, t, 1200))) { await notice(p, "レストラン", "§7お金が たりない"); return; } e.food = { k: L[k], n: 3 }; e.ck2 = (e.ck2 || 0) + 1; exSave(p, true); townXp(p, t, 2); sound(p, "random.burp"); await notice(p, "レストラン", `§a${ITEMS[L[k]].name}を 食べた！`); }
}
// 112) 夜市
async function nightMarket(p, d, t) {
  if (townLv(t.id) < 3) { await notice(p, "夜市", "§7発展度 3 で ひらく"); return; } if (!(timeOf() > 13000 && timeOf() < 23000)) { await notice(p, "夜市", "§7夜だけ ひらく"); return; }
  const cap = rankCap(d), L = NIGHT.filter(([id]) => ITEMS[id] && storyLootOk(ITEMS[id], null, cap));
  for (;;) { const c = await choose(p, "夜市", `§7お金 ${gold(load(p).gold)}`, [...L.map(([id, n]) => B(`${ITEMS[id].name}\n§8${price(p, t, n).toLocaleString()} タヨ`, ICON("i_shop"))), B("§7戻る", ICON("i_back"))]); const x = L[c]; if (!x) return; if (!pay(p, price(p, t, x[1]))) { await notice(p, "夜市", "§7お金が たりない"); continue; } giveItem(p, `mrpg:${x[0]}`, 1); townXp(p, t, 2); }
}
// 89) 写真館・87) 博物館
async function museum(p, d, t) {
  if (townLv(t.id) < 4) { await notice(p, "写真館・博物館", "§7発展度 4 で ひらく"); return; } const [e] = pt(p), v = tw(t.id);
  const c = await choose(p, "写真館・博物館", "", [B("§l写真を かざる §8アルバムの 1枚を 町に", ICON("i_zukan")), B("§l町の 写真を 見る", ICON("i_zukan")), B("§l博物館 §8あなたの 集めた もの", ICON("i_zukan")), B("§7戻る", ICON("i_back"))]);
  if (c === 0) { if (!(e.ph || []).length) { await notice(p, "写真館", "§7アルバムに 写真が ない（探索手帳 → 相棒 → 記念撮影）"); return; } v.ph = [`${p.name}: ${e.ph[0]}`, ...(v.ph || [])].slice(0, 10); twSave(t.id); townXp(p, t, 3); await notice(p, "写真館", "§a写真を かざった！"); }
  if (c === 1) await notice(p, "町の 写真", (v.ph || []).map((x) => `§f・${x}`).join("\n") || "§7まだ ない");
  if (c === 2) await notice(p, "博物館", [`§f化石 §e${e.fo || 0}§f・古代の 化石の 復元 など`, `§f環境の レア §e${Object.keys(e.r).length}/${ENVR.length}`, `§f伝説の 秘宝 §e${Object.keys(e.rl || {}).length}/7§f・地図の 切れ端 §e${Object.keys(e.mp || {}).length}/4`, `§f称号 §e${(d.eg?.titles || []).length}`, `§f変わり種 §e${e.odd || 0}§f・魚の 自己ベスト §e${e.fb || 0}cm`, `§f町の スタンプ §e${Object.keys(pt(p)[1].stamp).length}/${TOWNS.length}`].join("\n"));
}
// 88) 像・115) 記念碑・114) 飾りつけ係・125) 記念撮影
async function monuments(p, d, t) {
  const v = tw(t.id), g = getTown(t.id), [e] = pt(p);
  const can = endingDone(d) || Object.keys(e.cl).length > 0;
  const c = await choose(p, "像・記念碑・飾りつけ", `§f像: §e${v.st ? `${v.st.n}と ${v.st.pet}` : "まだ ない"}\n§f記念碑: §e${v.mon === 1 ? "あり" : v.mon === 2 ? "場所が ふさがって いて 建てられなかった" : "地方の 守り手に 勝つと 建つ"}`, [B(can ? "§6§l自分の 像を 建てる §850000 タヨ" : "§7自分の 像（物語を 見届けるか 地方を 踏破）", ICON("i_skill")), B("§l像の 前で 記念撮影", ICON("i_zukan")), B("§l飾りつけ係 §8門の 旗の 色を かえる（5000 タヨ）", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && can && v.st && v.st.n !== p.name && dayNo() - (v.st.d || 0) < 7) { await notice(p, "像", `§7${v.st.n}の 像が 建った ばかり（7日 たつと 建てかえられる）`); return; }
  if (c === 0 && can) { if (!pay(p, 50000)) { await notice(p, "像", "§7お金が たりない"); return; } const pet = [...d.party][0]?.nm || ""; statue(p.dimension, t, g, p.name, pet); townXp(p, t, 30); fireworks(p.dimension, p.location); await notice(p, "像", `§6${p.name}と ${pet}の 像が 建った！`); }
  if (c === 1) { if (!v.st) { await notice(p, "記念撮影", "§7まだ 像が ない"); return; } if (hd(p.location, { x: g.x - 9, z: g.z - 30 }) > 6) { await notice(p, "記念撮影", `§7像（町の ${dirTo(g, { x: g.x - 9, z: g.z - 30 })}）の 前に 立とう`); return; } e.ph = Array.isArray(e.ph) ? e.ph : []; e.ph.unshift(`★ ${t.name}の 像の 前で`); e.ph.length = Math.min(20, e.ph.length); exSave(p, true); const d2 = load(p); if (v.st.n === p.name) award(p, d2, "tw_face", null); save(p, d2); for (let k = 0; k < 12; k++) fx(p.dimension, "minecraft:totem_particle", p.location); await notice(p, "記念撮影", "§aパシャ！ 特別な 1枚"); }
  if (c === 2) { const C = ["red_wool", "blue_wool", "yellow_wool", "green_wool", "purple_wool", "white_wool", "black_wool", "orange_wool"]; const k = await paged(p, "旗の 色", "", ["赤", "青", "黄", "緑", "紫", "白", "黒", "だいだい"].map((n) => B(n, ICON("i_skill"))), 8); if (k < 0) return; if (!pay(p, 5000)) { await notice(p, "飾りつけ", "§7お金が たりない"); return; } v.fc = C[k]; v.dv = 0; twSave(t.id); townXp(p, t, 5); await notice(p, "飾りつけ", "§a旗の 色を かえた（少し して から かわる）"); }
}
// 119) おばあさんの うわさ・33) ギルドの 依頼（探索の 依頼）
async function gossip(p, d, t) {
  const [e, T] = pt(p), i = regOfTown(t);
  const r = ENVR[hash(`${t.id}${dayNo()}`) % ENVR.length];
  T.gd = T.gd && T.gd.d === dayNo() ? T.gd : { d: dayNo(), done: {} };
  const G = [{ n: `${WREGIONS[i].short}の 展望台に 登る`, ok: () => !!e.t[i] }, { n: "地方の 素材を 10こ もって くる", ok: () => MATS.reduce((a, id) => a + countItem(p, `mrpg:${id}`), 0) >= 10 }];
  const c = await choose(p, "おばあさん・ギルド", `§fおばあさん「${r.c}には ${r.n}が 出る と 聞いたよ。${SPECIES[envSid(r)]?.name || ""} と いう 子だ」`, [...G.map((g, k) => B(`${T.gd.done[k] ? "§a○ " : ""}§lギルド: ${g.n}`, ICON("i_help"))), B("§7戻る", ICON("i_back"))]);
  const g = G[c]; if (!g || T.gd.done[c]) return; if (!g.ok()) { await notice(p, "ギルド", "§7まだ できて いない"); return; }
  T.gd.done[c] = 1; exSave(p, true); const d2 = load(p); prize(p, d2, i, 1, 1); save(p, d2); addPt(p, e, 8); await notice(p, "ギルド", "§aギルドの 依頼を 達成！");
}
// 149) 船旅・95) 今週の 強い マスター
async function travel(p, d, t) {
  const c = await choose(p, "船旅・強い マスター", "", [B(t.style === "port" ? "§l船旅 §8ほかの 港・水べの 町へ（500 タヨ）" : "§7船旅（港町だけ）", ICON("i_run")), B("§l今週の 強い マスター", ICON("i_fight")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && t.style === "port") { const L = TOWNS.filter((x) => x.id !== t.id && ["port", "village", "garden"].includes(x.style) && getTown(x.id)?.built && (d.towns || []).includes(x.id)); if (!L.length) { await notice(p, "船旅", "§7行ける 町を まだ 知らない"); return; } const k = await paged(p, "船旅", "§fどこへ？", L.map((x) => B(x.name, ICON("i_run"))), 8); if (k < 0) return; if (!pay(p, 500)) { await notice(p, "船旅", "§7お金が たりない"); return; } const g = getTown(L[k].id); for (let s = 0; s < 3; s++) system.runTimeout(() => { try { p.playSound("random.splash", { pitch: 0.8 }); } catch {} }, s * 10); try { p.teleport({ x: g.x, y: g.y + 0.2, z: g.z + 5 }, { dimension: world.getDimension("overworld") }); } catch {} return; }
  if (c === 1) { let G = []; try { G = loadW("mrpg_eg_ghost", []); } catch {} G = [...G].sort((a, b) => (b.r || 1000) - (a.r || 1000)).slice(0, 5); await notice(p, "今週の 強い マスター", G.map((x, k) => `§e${k + 1}. §f${x.name} §7レート${x.r || 1000}・${(x.team || []).map((m) => m.nm).slice(0, 3).join("・")}`).join("\n") || "§7まだ だれも いない（ゴースト対戦に 登録すると のる）"); }
}
// 110) 限定タマゴ・109) 名誉市民
async function premium(p, d, t) {
  if (townLv(t.id) < 5) { await notice(p, "限定タマゴ・名誉市民", "§7発展度 5 で ひらく"); return; }
  const [e, T] = pt(p); T.cit = T.cit || {}; T.egw = T.egw || {};
  const c = await choose(p, "限定タマゴ・名誉市民", "", [B(T.egw[t.id] === week() ? "§7限定タマゴ（今週は 買った）" : "§6§l限定タマゴ §830000 タヨ（週に 1こ）", ICON("i_shop")), B(T.cit[t.id] ? "§a名誉市民（値引き +5%）" : `§l名誉市民に なる §8人気度 100（いま ${T.rep[t.id] || 0}）`, ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
  if (c === 0 && T.egw[t.id] !== week()) { const L = Object.keys(EGGS).filter((id) => ITEMS[id] && storyLootOk(ITEMS[id], EGGS[id]?.ranks, rankCap(d)) && !/king|god/.test(id)); const id = L.length ? L[hash(`${t.id}${week()}`) % L.length] : null; if (!id) return; if (!pay(p, 30000)) { await notice(p, "限定タマゴ", "§7お金が たりない"); return; } T.egw[t.id] = week(); exSave(p, true); giveItem(p, `mrpg:${id}`, 1); await notice(p, "限定タマゴ", `§a${ITEMS[id].name}を 手に入れた！`); }
  if (c === 1 && !T.cit[t.id]) { if ((T.rep[t.id] || 0) < 100) { await notice(p, "名誉市民", "§7人気度が たりない"); return; } T.cit[t.id] = 1; exSave(p, true); const d2 = load(p); award(p, d2, `tw_cit_${t.id}`, null); save(p, d2); fanfare(p); }
}
export const __town = { tw, townLv, decorate, reqsOf, FEST, disc, price, SYMBOL, STY, statue, decoTick, TDECO, QUEST, MENU };
