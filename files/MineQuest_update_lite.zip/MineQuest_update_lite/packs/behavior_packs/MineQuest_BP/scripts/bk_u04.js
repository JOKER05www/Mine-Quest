/* 第126版 裏4「赤い髪の弟子」（クロガネ／ラヴィ／スス）— 作業 UA
   選択 U04（機神の 型を ヴァルカに 渡すか／ムサシが 持つか）。C04（台座か 父の 刀か）が 4-2・4-4 に 返る。
   MQ26 = 裏3＋裏4 の 16話（1話ずつ。次の 話の 場所へ 案内）*/
import { bkAdd, bkHas, mqOver, BKE } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { fac, facMark, facState } from "./epfac.js";
import { MQ } from "./saga.js";
import { placeOf, bldOf } from "./storyplace.js";
import { ok } from "./ui.js";
import { UA } from "./bk_u01.js";
import { KP, koubou } from "./bk_u03.js";
import { qs as _qs } from "./quest.js";
const K0 = { qs: _qs };

castAdd("u_valka", { nm: "ヴァルカ", role: "", col: "§c", gobi: "", skin: "valka", town: "t30", at: () => { const q = bldOf("t30", ["forge", "shop"]); return q ? { x: q.x - 2, z: q.z + 2 } : null; },
  hide: (s) => !bkHas(s, "u04e8"),
  after: [
    [(s) => (s.ch || {}).u04 === "v", ["{closed}結びは 打った。……熱いのは 好きかい？ アタシは、今日の 火が いちばん 好きだ。"]],
    [() => true, ["{closed}結びは、まだだ。型なしで 打つ。……何年 かかっても いい。", "{smile}末っ子の 腕輪、いい 音 してたよ。"]],
  ] });
castAdd("u_tombo", { nm: "トンボ", role: "見習い鍛冶", gobi: "ッス", skin: "tetsu", town: "t30", at: () => { const q = bldOf("t30", ["forge", "shop"]); return q ? { x: q.x + 2, z: q.z + 2 } : null; },
  hide: (s) => !bkHas(s, "u04e5"),
  after: [[() => true, ["{smile,☆}三人で 打った 日の 拍子、まだ 手が 覚えてるッス！", "{closed}……あの 木槌も、毎晩 磨いてるッス。"]]] });
castAdd("u_yone", { nm: "ヨネ", role: "ススの", gobi: "", skin: "baba", town: "t57", at: () => { const q = bldOf("t57", ["home", "home2", "home3"]); return q ? { x: q.x + 2, z: q.z + 1 } : null; },
  hide: (s) => !bkHas(s, "u04e6"),
  after: [[() => true, ["{smile}あの 侍さん、木槌を 叩いて『子どもの 手の 音だ』って。……あたしゃ、泣きそうに なったよ。"]]] });

const RAVI = UA.place("forge", 3, "ようがんの 里 ラヴィの 鍛冶場");
const SUSU = UA.bld("t57", ["home", "home2", "home3", "plaza"], "すすけた 里 スス");
const smithy = (K, p) => fac(K, p, "r3smithy", "smithy", 3, UA.Y(K, p));
const valka = (K, p) => { const e = K.cast(p, "u_valka"); return e; };
const sword = (K, p) => K.ch(p, "c04") !== "p";   /* s: 父の 刀が 残って いる */
const hammer3 = async (K, p, es, n = 3) => { for (let i = 0; i < n; i++) { for (const e of es) if (ok(e)) { K.hold(e, "hammer"); K.act(e, "raise"); } K.sound(p, "random.anvil_use", 0.5); await K.wait(5); for (const e of es) K.act(e, "hold"); await K.wait(4); } for (const e of es) K.act(e, 0); };

bkAdd("u04", [
  { id: "u04e1", t: "親父の 末っ子", place: KP.entry, F: ["F23"], battles: 0,
    hint: "§fクロガネの §e朝の 門§f へ 行こう §7（赤い 外套の 女が 来て いる）",
    syn: "朝の 門に ヴァルカが 来た。「……アンタが、親父の 末っ子かい」。二人は 互いの 名を 本人の 口から 聞いた。「アタシは 嘘を つかない。型を 見せて ほしい」。",
    async run(p, d, K) {
      fac(K, p, "u_kpost", "waypost", 3, UA.Y(K, p));
      await K.open(p, "クロガネの 朝の 門", "day");
      const eM = UA.mu(K, p, true), eV = valka(K, p);
      await K.walkCam(p, eV, UA.near(eV, eM || p, 2.2), 20);
      await K.up(p, eV, 10);
      await K.csay(p, "u_valka", ["{closed}……アンタが、親父の 末っ子かい。", "{?}名を 聞かせな。アンタの 口で。"], eM);
      await K.say(p, "ムサシ", ["{closed}ムサシ。……そっちは。顔は うっすら 覚えてる。赤い 髪の。"], eV);
      await K.csay(p, "u_valka", ["{closed}ヴァルカ。十九で ここに 弟子入りして、二十で 追い出された。"], eM);
      /*F23*/ await K.csay(p, "u_valka", ["{angry,up}アタシは、嘘を つかない。……だから 先に 言う。", "{closed}奥の 部屋の 型が 見たい。十年、それだけを 考えて きた。"], eM);
      await K.say(p, "ムサシ", ["{closed}……嘘の 音は しねえ。", "{smile}入れよ。親父は もう いねえ。"], eV);
      await K.end(p, { leave: [eV, eM], card: "§7→ 工房へ" });
      return true;
    } },
  { id: "u04e2", t: "背の 刀", place: KP.koubou, fac: "u_koubou", battles: 0,
    hint: "§fムサシの 家の §e工房§f で、型の 前の ヴァルカと 話そう",
    syn: "型の 前の ヴァルカ。父の 刀の「結び」は、この 型が なければ 打てない。（C04 で 刀を 引き出して いれば 背に 父の 刀。台座を 割って いれば、刀は もう 鉄塊で トンボの 手に ある）",
    async run(p, d, K) {
      koubou(K, p); facState("u_koubou", 1); const hq = facMark("u_koubou", "shelf", p.location);
      await K.open(p, "ムサシの 家の 工房", "day");
      const eV = valka(K, p), eM = UA.mu(K, p, true);
      if (hq) await K.approach(p, eV, hq, 1.4, 14);
      if (hq) await K.push(p, hq, 18, 3.5, 0.6);
      await K.csay(p, "u_valka", ["{closed,…}……これだ。"], eM);
      if (sword(K, p)) {
        K.hold(eV, "sword"); await K.up(p, eV, 10);
        await K.narr(p, ["§7ヴァルカの 背に、布で 巻いた §f父の 刀§7。§8……柄の 先だけ、まだ 結ばれて いない。"], eV);
        await K.csay(p, "u_valka", ["{sad}親父の 最後の 刀だ。鋳造所で 引き出した。", "{closed}結びが 打てなかった。型が ないと、刃と 柄の 鳴りが 合わない。"], eM);
      } else {
        await K.up(p, eV, 10);
        await K.narr(p, ["§7ヴァルカの 背には、何も ない。§8鋳造所で 溶けた 刀は、鉄の 塊に なって トンボの 手に 渡った。"], eV);
        await K.csay(p, "u_valka", ["{sad}親父の 刀は、もう ない。鉄塊は トンボに 渡した。……あいつの 村を 焼いた 鉄だからね。", "{closed}それでも 結びは 打ちたい。新しい 刃に。"], eM);
      }
      await UA.tap(K, p, eM, hq);
      await K.say(p, "ムサシ", ["{closed}……型は 一組だ。鍔と 腕輪で 一組。", "{sad}どっちかに 使えば、もう 片方には 使えねえ 音だ。"], eV);
      await K.end(p, { leave: [eV, eM], card: "§7→ 型を どうするか（工房で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u04e3", t: "型の 行き先", place: KP.koubou, fac: "u_koubou", battles: 0,
    hint: "§fムサシの 家の §e工房§f で、機神の 型の 行き先を 決めよう",
    syn: "型は 一組。ヴァルカの 十年の 願い（父の 刀の 結び）と、ムサシの 闘魔の 腕輪。主人公が 選んだ。",
    async run(p, d, K) {
      koubou(K, p); facState("u_koubou", 1); const hq = facMark("u_koubou", "shelf", p.location);
      await K.open(p, "ムサシの 家の 工房", "day");
      const eV = valka(K, p), eM = UA.mu(K, p, true);
      if (hq) await K.push(p, hq, 16, 3, 0.6);
      await K.csay(p, "u_valka", ["{closed}アンタの 家の 型だ。末っ子が 決めな。"], eM);
      await K.say(p, "ムサシ", ["{closed}……俺は 決めねえ。鍔を 持ってるのは こいつだ。", "{smile}おまえが 決めろ。……どっちの 音が 聞きてえ。"], null);
      const v = await K.pick(p, "u04");
      if (v === "v") {
        K.give(eM, eV, "book"); await K.up(p, eV, 12);
        await K.csay(p, "u_valka", ["{shock,…}……いいのかい。", "{closed}……十年だ。熱いのは 好きかい？ アタシは、今 いちばん 熱い。"], eM);
        await K.say(p, "ムサシ", ["{smile}持ってけ。腕輪は 打てねえが、俺には 耳が ある。"], eV);
      } else {
        K.hold(eM, "book"); await K.up(p, eM, 12);
        await K.say(p, "ムサシ", ["{closed}……俺が 打つ。闘魔の 腕輪だ。", "{sad}悪い。おまえの 十年を、もう 少し 待たせる。"], eV);
        await K.csay(p, "u_valka", ["{closed}……いいさ。型なしで 結びを 打つ。何年 かかっても いい。", "{smile}アタシは 嘘を つかない。……本当に、それで いい。"], eM);
      }
      await K.end(p, { leave: [eV, eM], card: "§7→ ラヴィの 鍛冶場へ（トンボに 会う）" });
      return true;
    } },
  { id: "u04e4", t: "トンボの 刃", place: RAVI, fac: "r3smithy", battles: 0,
    hint: "§fヴォルカの §eようがんの 里 ラヴィの 鍛冶場§f へ 行こう",
    syn: "ラヴィの 鍛冶場で トンボが 待って いた。（C04 で 刀を 引き出して いれば、ひびの 入った ホムラを 継いだ 跡。台座を 割って いれば、村を 焼いた 鉄で 打った 新しい 刃）",
    async run(p, d, K) {
      const Q = smithy(K, p);
      await K.open(p, "ようがんの 里 ラヴィの 鍛冶場", "day");
      if (Q) await K.at(p, Q, 14, 6, 1.6);
      const eT = K.cast(p, "u_tombo"), eV = valka(K, p), eM = UA.mu(K, p, true);
      await K.up(p, eT, 10);
      await K.csay(p, "u_tombo", ["{smile,!}ヴァルカさん！ ……あっ、お客さんも ッスか！"], eV);
      K.hold(eT, "sword"); await K.push(p, eT, 18, 3, 1.3);
      if (sword(K, p)) await K.csay(p, "u_tombo", ["{closed}ホムラの ひび、ヴァルカさんと 二人で 継いだッス。", "{smile}継ぎ目、見えるッスか？ ……ここだけ、色が 違うッス。"], eM);
      else await K.csay(p, "u_tombo", ["{closed}……おれの 村を 焼いた 鉄で、新しい 刃を 打ったッス。", "{smile,…}重いッス。けど、もう 焼く 鉄じゃ ないッス。"], eM);
      await UA.tap(K, p, eM, eT ? eT.location : null);
      await K.say(p, "ムサシ", ["{smile}……いい 音だ。迷ってねえ。", "{closed}前に 寄った とき、看板じゃ なくて この 音で 店を 選んだんだ。"], eT);
      await K.csay(p, "u_tombo", ["{shock,!}あっ！ 字の 読めない お侍さん ッス！"], eM);
      await K.end(p, { leave: [eT, eV, eM], card: "§7→ 三人で 打つ（鍛冶場で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u04e5", t: "三つの 拍子", place: RAVI, fac: "r3smithy", battles: 0,
    hint: "§fラヴィの §e鍛冶場§f で、三人の 槌を 聞こう",
    syn: "ヴァルカと ムサシと トンボが 並んで 打った。三人とも 違う 拍子で、途中で そろった。",
    async run(p, d, K) {
      smithy(K, p);
      await K.open(p, "ラヴィの 鍛冶場", "day");
      const eT = K.cast(p, "u_tombo"), eV = valka(K, p), eM = UA.mu(K, p, true);
      await K.csay(p, "u_valka", ["{smile}並びな。三人で 一本 打つ。"], eT);
      K.sound(p, "random.anvil_use", 0.6); await K.wait(3); K.sound(p, "random.anvil_use", 0.4); await K.wait(7); K.sound(p, "random.anvil_use", 0.5); await K.wait(4);
      await K.say(p, "ムサシ", ["{sweat}……ばらばらだ。", "{smile}トンボ、速え。ヴァルカ、重てえ。俺は……逆か？ 俺が 遅えのか。"], eV);
      await hammer3(K, p, [eT, eV, eM], 3);
      await K.narr(p, ["§7カン、カン、カン。§f……三つの 槌が、いつの まにか 一つの 音に なった。"], eT);
      await K.csay(p, "u_tombo", ["{smile,☆,jump}そろったッス！ 今、そろったッス！"], eV);
      await K.csay(p, "u_valka", ["{smile,…}……ふん。悪くない。"], eM);
      K.pay(p, this, 1000, [["c_fruit", 2]]);
      await K.end(p, { leave: [eT, eV, eM], card: "§7→ すすけた 里 スス へ（トンボの 木槌の 話）" });
      return true;
    } },
  { id: "u04e6", t: "子どもの 手の 音", place: SUSU, F: ["F60"], battles: 0,
    hint: "§fヴォルカの §eすすけた 里 スス§f へ 行こう",
    syn: "スス。ヨネ婆が トンボの 木槌の 話を した。焼けた 村から 拾った、小さな 木槌。ムサシが 叩いて「子どもの 手の 音だ」。",
    async run(p, d, K) {
      await K.open(p, "すすけた 里 スス", "ash");
      const eY = K.cast(p, "u_yone"), eT = K.cast(p, "u_tombo"), eM = UA.mu(K, p, true);
      K.hold(eT, "hammer"); await K.up(p, eY, 10);
      /*F60*/ await K.csay(p, "u_yone", ["{closed}その 木槌はね、灰の 冬に 焼けた 村で 拾ったんだよ。", "{sad}持ち主を 待って、十二年 あたしが 預かってた。……今は、トンボの 手に ある。"], eT);
      await K.push(p, eT, 16, 3, 1.1);
      await K.csay(p, "u_tombo", ["{sad,…}……おれの、ッス。三つの とき、親父に 作って もらったッス。"], eY);
      await UA.tap(K, p, eM, eT ? eT.location : null);
      await K.say(p, "ムサシ", ["{closed,…}……軽い。", "{sad}子どもの 手の 音だ。……ずっと、握られるのを 待ってた 音だ。"], eT);
      await K.csay(p, "u_yone", ["{smile,tears}……そうかい。そうかい。"], eM);
      await K.end(p, { leave: [eT, eM], bye: [eY], kind: "ash", card: "§7→ 夜の ラヴィの 鍛冶場へ" });
      return true;
    } },
  { id: "u04e7", t: "斬り跡を 辿れ", place: RAVI, fac: "r3smithy", battles: 0,
    hint: "§fラヴィの §e夜の 鍛冶場§f",
    syn: "夜の 鍛冶場。エンマが ムサシの 口で 言った。「われの 斬り跡を 辿れ。帳の 在りかへ 通じる」。",
    async run(p, d, K) {
      smithy(K, p);
      await K.open(p, "ラヴィの 鍛冶場（夜）", "night", "night");
      const eM = UA.mu(K, p, true), eV = valka(K, p);
      await K.narr(p, ["§7炉の 火が 小さく なった。§8ムサシは 鍔を 布ごと 膝に 置いて、うつらうつら して いる。"], eM);
      K.burst(p.dimension, eM ? eM.location : p.location, "minecraft:basic_flame_particle", 8, 0.6, 1); K.act(eM, "raise");
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{rage,low}§4……われの 斬り跡を 辿れ。", "§4帳の 在りかへ、通じる。"], null);
      await K.csay(p, "u_valka", ["{shock,!}……末っ子？ 今の 声、アンタの じゃ ないね。"], eM);
      K.act(eM, 0);
      await K.say(p, "ムサシ", ["{sweat,息}……また 借りやがった。", "{angry}斬り跡だと？ 何を 斬ったか 先に 言え、エンマ。"], eV);
      await K.say(p, "ムサシ", ["{rage,low}§4……見れば わかる。字より 確かだ。"], eV);
      await K.say(p, "ムサシ", ["{closed}……字より 確か、だと。……王さまが 言う ことか。"], eV);
      await K.end(p, { leave: [eV, eM], kind: "night", card: "§7→ 朝、鍛冶場で 地図を 広げる" });
      return true;
    } },
  { id: "u04e8", t: "五つの 印", place: RAVI, fac: "r3smithy", battles: 0,
    hint: "§fラヴィの §e鍛冶場§f で 地図を 見よう",
    syn: "地図に 五つの 印（ポカラの 丘、リールの 川辺、こもれびの 森、谷の 割れ目、王冠の 割れ目）。ムサシ「……読んで くれ」。ヴァルカが 読んだ。",
    async run(p, d, K) {
      smithy(K, p);
      await K.open(p, "ラヴィの 鍛冶場", "day");
      const eM = UA.mu(K, p, true), eV = valka(K, p);
      K.sound(p, "item.book.page_turn", 0.8); K.hold(eM, "map");
      await K.narr(p, ["§7朝、鍔を 地図の 上に 置くと、§c五か所§7 に 焦げたような 印が 浮かんだ。"], eM);
      await K.say(p, "ムサシ", ["{sweat}……字だ。読めねえ。", "{closed}読んで くれ。……声で。"], eV);
      await K.up(p, eV, 10);
      await K.csay(p, "u_valka", ["{closed}ひだまりの 村 ポカラの 丘。おがわの 里 リールの 川辺。こもれびの 森。", "{closed}谷の 割れ目。……それと、§c王冠の 割れ目§f。ルミナの 外れだね。"], eM);
      await K.say(p, "ムサシ", ["{closed}……五つ。順に 回る。", "{smile}ヴァルカ、ありがとな。……おまえの 声は、嘘の 音が しねえ。"], eV);
      await K.csay(p, "u_valka", ["{smile}知ってるよ。"], eM);
      K.pay(p, this, 2000, [["c_fruit", 3]]);
      await UA.zeph(K, p);
      await K.end(p, { leave: [eV, eM], card: "§7→ アルカトラス地方 §eひだまりの 村 ポカラの 丘§7 の 割れ目へ（右上の 案内）" });
      return true;
    } },
]);

/* MQ26: 裏3＋裏4（1話ずつ。次の 話の 場所へ「！」で 案内する）*/
const MQ26 = ["u03e1", "u03e2", "u03e3", "u03e4", "u03e5", "u03e6", "u03e7", "u03e8", "u04e1", "u04e2", "u04e3", "u04e4", "u04e5", "u04e6", "u04e7", "u04e8"];
const SAME = (a, b) => { const A = BKE.get(a), B = BKE.get(b); return A && B && A.place === B.place; };
if (MQ[26]) { MQ[26].trig = (c) => !!c.s.ending; MQ[26].run = async () => true; MQ[26].hint = "§fヴォルカの §eはがねの 村 クロガネ§f へ 行こう §7（鍔を 打った 家）"; }
mqOver(26, async (p, d, K, c) => {
  const L = c.undone; if (!L.length) return true;
  /* 同じ 場所の 話は 続けて 流す。場所が かわる 所で 止めて 次へ 案内 */
  for (let i = 0; i < L.length; i++) { if (!(await c.play(L[i]))) return false; if (i + 1 < L.length && !SAME(L[i], L[i + 1])) return "next"; }
  return true;
}, { cond: async () => true, spot: (p, d) => { const s = K0.qs(d); const id = MQ26.find((x) => !bkHas(s, x)); const e = id && BKE.get(id); let q = null; try { q = e && e.place ? e.place(p) : null; } catch {} return q ? { x: Math.floor(q.x), y: null, z: Math.floor(q.z), nm: q.nm, key: id, np: 1 } : null; } });
