// 第106版: 町・城下町を 歩く 人たち（近くに プレイヤーが いる ときだけ 出る・軽い 動き）
// 道すじは 町を 作った ときに world の mrpg:walk:<町の id> に 保存してある（中心からの 相対座標）
import { world, system } from "@minecraft/server";
import { personName, nearNpcs } from "./names.js";   /* 第106版: 同じ 見た目でも 名前は ちがう */
import { ok, isLite, sound, setJob, busy } from "./ui.js";
import { NPC_HOOKS } from "./npchook.js";
import { chatWith } from "./chat.js";
import { PSKIN } from "./skinjobs.js";
/* 第106版: 町を 歩く 人にも 顔（スキン）を。キー → 役割（話す 内容） */
const TOWNS_SK = { rosa: 24, shiori: 24, tetsu: 23, toma: 23, milk: 24, hanna: 24, kanon: 26, mimi: 24, taro: 23, baba: 23, allen: 25, milfy: 25, leaf: 25, gantz: 25, sera: 25, ed: 23, emma: 24, nico: 26, zenia: 26, jack: 26, wolf: 25, otto: 23, hans: 23, noel: 24, shiori2: 24, mimosa: 24, kaede: 25, luna2: 25, moka: 24, aoi: 25, sakuya: 24, lily: 26, maria2: 24, rosa2: 24, kaori: 24, hanna2: 24, clarice: 24, erika: 25, viola: 26, ayame: 24, beatrice: 24, milka: 24, gracia: 25, jasmine: 26, sayo: 24, tsubaki: 24, yuki: 24, fio: 26, tia: 24, guy: 25, don: 24, crow: 26, leon: 25, zaza: 26, miko: 24 };   /* 第106版: 美少女・お姉さん 30人（水着の 人は 海辺） */

const OW = () => world.getDimension("overworld");
const WJOBS = [23, 24, 25, 26];
const NAMES = ["ミーナ", "トマス", "リオ", "エマ", "グスタフ", "ノエル", "ハンナ", "ペトロ", "サラ", "ユリウス", "アンナ", "カイ", "ロッテ", "マルコ", "ニナ", "オスカー", "ララ", "ベン", "ソフィ", "ヨハン"];
const ROLE = { 23: "町の人", 24: "町の人", 25: "冒険者", 26: "行商人" };
const LINES = {
  23: ["今日も いい 天気だな", "広場の 噴水は 町の 自慢なんだ", "城の 坂を 上ると 町が 一望できるよ", "夜は 酒場が にぎやかでね", "最近 畑を 荒らす モンスターが 出て 困ってるんだ"],
  24: ["市場の 野菜は 朝が いちばん 新鮮よ", "レストランの ケーキ、食べた？", "子どもたちが 遊び場の 話ばかり するの", "教会の 鐘が 鳴ると お昼なの", "モンスターと 暮らすって すてきね"],
  25: ["協会の 掲示板、今日は いい 依頼が あるかな", "C級に 上がるまで 3年 かかったよ……", "手配モンスターは 手ごわいぜ。回復は 多めにな", "遠くの 調査依頼は 座標を 見ると いい", "X級の 冒険者なんて 伝説の 中の 話さ"],
  26: ["遠い 町から 来たんだ。港町の 魚は 絶品だぞ", "砂漠の 町では 水が 金より 高い", "雪の 町の 薬草茶は 体が あたたまる", "商売の コツ？ 笑顔と 足の 速ささ", "ノクス団の せいで 街道が 物騒でね"],
};
const pick = (L) => L[Math.floor(Math.random() * L.length)];

// ---------- 道すじの 記録 ----------
let AREAS = [], AREA_T = 0;
function areas() {
  if (Date.now() - AREA_T < 30000) return AREAS;
  AREA_T = Date.now(); const out = [];
  try {
    for (const id of JSON.parse(world.getDynamicProperty("mrpg:walkids") || "[]")) {
      if (typeof id !== "string") continue;
      try { const v = JSON.parse(world.getDynamicProperty(`mrpg:walk:${id}`) || "null"); if (v && Array.isArray(v.w) && v.w.length) { out.push({ id, x: v.x, y: v.y, z: v.z, w: v.w.filter((r) => Array.isArray(r) && r.length >= 2), r: id.startsWith("c") ? 76 : 48 }); } } catch {}
    }
  } catch {}
  return (AREAS = out);
}
export const resetWalkCache = () => { AREA_T = 0; };

// ---------- 歩く 人 ----------
const W = new Map();   // entity id → { e, a: area id, r: 道の 番号, i: 次の 点, wait, x, y, z }
const tagOf = (id) => `mrpg_wk_${id}`.replace(/[^A-Za-z0-9_]/g, "_");
function spawnOne(A) {
  const r = Math.floor(Math.random() * A.w.length), R = A.w[r], i = Math.floor(Math.random() * R.length), P = R[i];
  const pos = { x: A.x + P[0] + 0.5, y: A.y + P[1], z: A.z + P[2] + 0.5 };
  let e; try { e = OW().spawnEntity("mrpg:npc", pos); } catch { return; }
  const keys = Object.keys(TOWNS_SK).filter((k) => PSKIN[k]), key = keys.length && Math.random() < 0.85 ? pick(keys) : null;
  const j = key ? TOWNS_SK[key] : pick(WJOBS);
  try { if (key) { setJob(e, PSKIN[key][0]); e.setDynamicProperty("mrpg:wr", j); e.nameTag = `§f${personName(PSKIN[key][1], PSKIN[key][2], nearNpcs(pos))}`; } else { setJob(e, j); e.nameTag = `§f${ROLE[j]} ${pick(NAMES)}`; } e.addTag("mrpg_npc"); e.addTag("mrpg_walker"); e.addTag(tagOf(A.id)); e.setDynamicProperty("mrpg:wa", A.id); } catch {}
  W.set(e.id, { e, a: A.id, r, i: (i + 1) % R.length, wait: 0, ...pos });
}
function adopt(e, A) {
  /* 読みこみ直した あとの 人: いちばん 近い 点から 歩きはじめる */
  const L = e.location; let best = null;
  A.w.forEach((R, r) => R.forEach((P, i) => { const d = Math.hypot(A.x + P[0] + 0.5 - L.x, A.z + P[2] + 0.5 - L.z); if (!best || d < best.d) best = { d, r, i }; }));
  if (!best || best.d > 12) { try { e.remove(); } catch {} return; }
  W.set(e.id, { e, a: A.id, r: best.r, i: best.i, wait: 0, x: L.x, y: L.y, z: L.z });
}
const WANT = (A) => (isLite() ? (A.id.startsWith("c") ? 4 : 2) : (A.id.startsWith("c") ? 9 : 5));
/* 1秒ごと: 人が 近い 町に 人を ふやす・遠い 町の 人を 消す */
system.runInterval(() => {
  const A0 = areas(); if (!A0.length) return;
  const ps = world.getAllPlayers().filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
  for (const A of A0) {
    const near = ps.some((p) => Math.hypot(p.location.x - A.x, p.location.z - A.z) < A.r + 24);
    let L = []; try { L = OW().getEntities({ type: "mrpg:npc", tags: [tagOf(A.id)], location: { x: A.x, y: A.y, z: A.z }, maxDistance: A.r + 30 }); } catch {}
    if (!near) { for (const e of L) { W.delete(e.id); try { e.remove(); } catch {} } continue; }
    for (const e of L) if (!W.has(e.id)) adopt(e, A);
    const mine = L.filter((e) => W.has(e.id));
    if (mine.length > WANT(A)) for (const e of mine.slice(WANT(A))) { W.delete(e.id); try { e.remove(); } catch {} }
    else if (mine.length < WANT(A) && A.w.length) spawnOne(A);
  }
  for (const [id, s] of W) if (!ok(s.e)) W.delete(id);
}, 20);
/* 4tick ごと: すこしずつ 前へ（1秒で 約1.5ブロック） */
const STEP = 0.3;
system.runInterval(() => {
  if (!W.size) return;
  const AM = new Map(areas().map((A) => [A.id, A]));
  for (const [id, s] of W) {
    const A = AM.get(s.a); if (!A || !ok(s.e)) { W.delete(id); continue; }
    if (s.wait > 0) { s.wait--; if (s.wait === 0) try { s.e.setProperty("mrpg:mv", true); } catch {} continue; }
    const R = A.w[s.r]; if (!R) { W.delete(id); continue; }
    const P = R[s.i % R.length], tx = A.x + P[0] + 0.5, ty = A.y + P[1], tz = A.z + P[2] + 0.5;
    const dx = tx - s.x, dz = tz - s.z, d = Math.hypot(dx, dz);
    if (d < STEP) {
      s.x = tx; s.z = tz; s.y = ty; s.i = (s.i + 1) % R.length;
      if (Math.random() < 0.4) { s.wait = 10 + Math.floor(Math.random() * 25); try { s.e.setProperty("mrpg:mv", false); } catch {} }
    } else { const k = STEP / d; s.x += dx * k; s.z += dz * k; s.y += (ty - s.y) * Math.min(1, k * 1.2); }
    try { s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: tx, y: ty + 1.5, z: tz } }); if (s.wait === 0 && s.e.getProperty("mrpg:mv") !== true) s.e.setProperty("mrpg:mv", true); } catch {}
  }
}, 4);
/* 話しかけ: 立ちどまって ひとこと（画面は 出さない） */
NPC_HOOKS.push((p, e) => {
  if (!e.hasTag("mrpg_walker")) return false;
  if (e.hasTag("mrpg_beach") || e.hasTag("mrpg_trouble")) return false;
  if (busy.has(p.id)) return true;
  const s = W.get(e.id); if (s) { s.wait = 40; try { e.setProperty("mrpg:mv", false); e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
  let j = 23; try { j = e.getProperty("mrpg:job"); const wr = e.getDynamicProperty("mrpg:wr"); if (typeof wr === "number") j = wr; } catch {}
  const nm = String(e.nameTag || "").replace(/§./g, "");
  sound(p, "random.pop", 0.6);
  chatWith(p, e, nm, ROLE[j] || "町の人", pick(LINES[j] || LINES[23]));   /* 第106版: 自由に 話せる */
  return true;
});
export const __walk = { W, areas, spawnOne, adopt, tagOf, WANT };
