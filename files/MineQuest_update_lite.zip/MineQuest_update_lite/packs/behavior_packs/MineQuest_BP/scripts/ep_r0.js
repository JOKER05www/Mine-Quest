/* 第125版: 第1地方 アルカトラス の 5話（手本）
   ■ この ファイルの 書き方（ほかの 地方も 同じ 形。ep_r1.js 〜 ep_r10.js）
   1) 登場人物を castAdd で 登録する（cast.js）。見た目は skinjobs.js の PSKIN の キー（"mimi" など）。語尾 gobi は 必ず 書く
      town と at を 書くと、from の 話を 終えた 人には 町に 立って、話しかけると after の「その後」を 話す
   2) epAdd(地方の 番号, [話, ...], { steps: { 地方の 中の 段の 番号: [話の 番号, 題] } }) で 話を 足す
      ・at: その 地方の 何番目の 段の 前に 入るか（0 から。段の 数と 同じ なら 最後の 段の あと）。同じ at の 話は ord の 順
      ・id は ほかと かぶらない 名前（"r地方e話" の 形）。一度 出したら かえない（セーブに 残る）
      ・place(p) は 始まる 場所 { x, z, nm }。噴水の 横・町の 中の 通り道・階段や 坂の 途中は だめ。町の 外れ・城の 中庭・ステージなど
      ・hint は 右上と ガイドブックの 文（どこで・何を・どうやって。2行まで）。syn は あらすじ（話が 済んだ あと だけ 出る）
      ・run(p, d, K) は 場面。true を 返すと 済み。負けた・あとで は false（ガイドブックの「物語の 戦いに 再挑戦」で もう一度）
      ・とちゅうの 印は K.flag(p, "名前")／K.setFlag(p, "名前")（とちゅうで 抜けても 戦いを くり返さない）
      ・ほうびは K.pay(p, ep, お金, [[道具, 数]])（1回だけ）。町の 変化は fx: { xp: ["t0", 数], fest: "t0" }（ワールドで 1回）
      ・skip(s) は チートや「とばす」で 飛ばした ときに そろえる 印。set は 話を 終えた ときに s.epx へ 入れる 印
   3) 演出は K の 部品で 書く（決まりを 守る ため）
      K.open（始まりの 引きの 絵）→ K.cast／K.hero（人は 歩いて 来る）→ K.csay／K.say／K.hsay（2行ごとに 聞き手の 顔へ 切りかえ）
      気持ちが 動く 行は {顔,up}（寄り と 表情）。しぐさは K.act・{nod}{arms} などで 3行に 1回 以上。K.up／K.low／K.two／K.wide／K.at で 絵を かえる
      戦いは K.battle（1つの 場面で 3回まで）。終わりは K.end({ leave: [去る 人], card: "次の 案内" })（引きの 絵 → セリフと 画面を 消す）
      集中線・上下の 黒い 帯は 使わない。ひらがな 多め・わかち書き。クリア前に 見える 文に ネタバレを 書かない */
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, ranchSpot, spotOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, castleSpot } from "./structures.js";
import { regionIdx } from "./worldmap.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok, anim } from "./ui.js";
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* b の そば k マス（a の 側）*/
import { baseOf } from "./partner.js";

/* ---------- 場所 ---------- */
const lumina = () => { const t = TOWNS.find((u) => u.id === "t0"); if (!t) return null; const q = getTown("t0"); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
/* 祭りの 原っぱ: ルミナの 外れ（城と 反対・牧場とも 北の 門とも ちがう 向き）。町の 中の 道・噴水から はなれた 平らな 所 */
let FESTQ = null;
const FEST = () => {   /* ルミナから 58マス。ほかの 町・城・牧場・北の 門から いちばん はなれた 向き（地方の 中）*/
  if (FESTQ) return FESTQ;
  const c = lumina(); if (!c) return null;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  const avoid = []; for (const t of TOWNS) if (t.id !== "t0") { const q = townPos(t); avoid.push([q.x, q.z, 44]); }
  for (let i = 0; i < 11; i++) { const k = castleSpot(i); if (k) avoid.push([k.x, k.z, 72]); }
  { const r = ranchSpot(); if (r) avoid.push([r.x, r.z, 16]); } avoid.push([c.x, c.z - 52, 16]);
  let best = null;
  for (let a = 0; a < 16; a++) { const t = (a / 16) * Math.PI * 2, x = Math.floor(c.x + Math.cos(t) * 58), z = Math.floor(c.z + Math.sin(t) * 58); if (regionIdx(x - s0.x, z - s0.z) !== 0) continue; let m = 1e9; for (const [X, Z, R] of avoid) m = Math.min(m, Math.hypot(X - x, Z - z) - R); if (!best || m > best.m) best = { x, z, m }; }
  if (!best) { const o = townOut("t0", -0.9, "祭りの 原っぱ"); best = o ? { x: o.x, z: o.z } : null; }
  FESTQ = best ? { x: best.x, z: best.z, nm: "ルミナの 外れの 祭りの 原っぱ" } : null; return FESTQ;
};
const COURT = () => { const q = placeOf("court", 0); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm || "アルカトラス城の 中庭" } : null; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("gonza", { nm: "ゴンザ", role: "門番", gobi: "ござる", skin: "m6_takeru", town: "t0", from: "r0e3",
  at: () => { const c = lumina(); return c ? { x: c.x + 3, y: c.y, z: c.z - 29 } : null; },
  pre: ["{closed}北の 門は 拙者が 守って おるでござる。"],
  after: [
    [(s) => !!s.ending, ["{smile}空が 晴れたでござる。……門を くぐる 者の 顔が、みな 明るいでござる。"]],
    [(s) => !!s.heroDead, ["{sad}……門を くぐる 者が、一人 減ったでござる。", "{closed}それでも 拙者は、門を 開けて 待つでござる。いつでも 帰って くるでござるよ。"]],
    [(s) => !!st(s).fest0, ["{smile}傷は 町を 守った 印でござる。", "{smile,♪}いって らっしゃいでござる！ 門は いつでも 開けて 待って おるでござる。"]],
    [(s) => !!st(s).gonzaHurt, ["{sweat,汗}かすり傷でござる。……少し、しみるでござるが。", "{angry}拙者が 立たねば、門が さびしがるでござる。"]],
    [() => true, ["{smile}祭りの 夜は 助かったでござる。ミミ殿の 屋台も 無事でござる。"]],
  ] });
castAdd("mimi", { nm: "ミミ", role: "パン屋の", gobi: "だよっ", skin: "mimi", town: "t0", from: "r0e2",
  at: () => { const q = spotOf("t0", "diner") || spotOf("t0", "cafe"); if (q) return { x: q.x + 1.5, y: q.y, z: q.z - 2 }; const c = lumina(); return c ? { x: c.x + 8, y: c.y, z: c.z + 19 } : null; },
  pre: ["{smile}いらっしゃいませだよっ！"],
  after: [
    [(s) => !!s.ending, ["{smile,☆}町に 人が もどって きたよっ！ 今年の 収穫祭は、いちばん 大きく するんだよっ！"]],
    [(s) => !!(s.heroDead && s.epx && s.epx.lchase && s.epx.mimiDad), ["{smile}お父さんと いっしょに、毎朝 パンを 配ってるよっ。", "{smile,up}……帰って きたら、いちばん 焼きたてを とって おくんだよっ。"]],
    [(s) => !!(s.heroDead && s.epx && s.epx.lchase), ["{sad}お父さん、まだ 石の まま なんだよっ……。", "{angry,up}インク、見つけたら お父さんの 名前、書いて ほしいんだよっ！"]],
    [(s) => !!s.heroDead, ["{sad}……麦パン、毎朝 焼いてるよっ。", "{cry}いつ 帰って きても いい ように。……あたし、待ってるんだよっ。"]],
    [(s) => !!st(s).fest0, ["{smile,♪}やり直しの お祭り、ほんとに うれしかったよっ！", "{smile}町の みんなが お店を 増やしたんだよっ。また パンを 食べに 来てねっ！"]],
    [(s) => !!st(s).gonzaHurt, ["{sad}ゴンザさん、まだ 足を 引きずってるんだよっ……。", "{angry}でも、お祭りは あきらめないよっ！ 約束、だよっ！"]],
    [() => true, ["{smile,☆}収穫祭、ぜったい 来てねっ！ 焼きたての 麦パン、とって おくんだよっ！"]],
  ] });
castAdd("nol", { nm: "ノルじい", role: "牧場の", gobi: "じゃよ", skin: "m6_gramps", town: "t0", from: "r0e2",
  at: () => { const q = ranchSpot(); return q ? { x: q.x + 5, y: q.y ?? undefined, z: q.z + 4 } : null; },
  pre: ["{smile}ほっほ、牧場の 干し草は よう 乾いて おるんじゃよ。"],
  after: [
    [(s) => !!s.final, ["{closed}……そうか。あの 男は、そういう 道を 選んだんじゃな。", "{sad}紐の お守りは、できあがったんじゃろうか。……できて いると、ええんじゃよ。"]],
    [(s) => !!st(s).fest0, ["{smile}あの 二人も 昔、ここで 送り出されたんじゃよ。", "{closed}……今度は、みんな 帰って くるんじゃよ。約束じゃよ。"]],
    [() => true, ["{closed}オルドの 昔話は、ないしょじゃよ。……あやつ、照れると 怒るんじゃよ。"]],
  ] });
castAdd("arca", { nm: "アルカ十三世", role: "王", col: "§6", gobi: "", skin: "arca13" });
castAdd("midori", { nm: "ミドリ", role: "地方マスター", col: "§6", gobi: "", skin: "midori" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d), S = null; return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : S; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const ORDO = (K, p, w = false) => K.npcNear(p, "§eオルド", K.PJ("ordo", 8), w);
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };

/* ---------- 2話 収穫祭の 前 ---------- */
const E2 = { id: "r0e2", n: 2, t: "収穫祭の 前", at: 1, ord: 0, place: FEST,
  hint: "§fルミナの 外れの §e祭りの 原っぱ§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まると、パン屋の §eミミ§7 が 待って いる）",
  syn: "収穫祭の 二日前。パン屋の ミミと 祭りの 飾りを 集め、畑を 荒らす 野生の 群れを 追いはらった。牧場の ノルじいは「オルドは 昔、いつも もう 一人と 一緒だった」と 話した。その 男は 娘の ために 紐の お守りを 編みつづけ、ある 冬、二人で 旅に 出て……帰って きたのは オルド 一人だった。",
  set: { met0: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "t0fest", 0, c, y0);
    await K.open(p, "ルミナの 外れの 祭りの 原っぱ", "day");
    const eM = K.cast(p, "mimi"), eH = K.hero(p);
    K.act(eM, "raise");
    await K.csay(p, "mimi", ["{!,jump}あーっ、いた いた！ 石板に えらばれた 人だよねっ？", "{smile,☆}町じゅう その うわさで もちきりだよっ！"]);
    await K.hsay(p, K.V(["{smile,♪,up}ミミちゃん！ ……って、うわさ 早すぎない！？"], ["{smile}あら、ミミちゃん。……もう 町じゅうに 広まってるの？"], ["{sweat,汗}……ミミ。うわさ、早すぎ。"], ["{smile}ミミさん、こんにちは。……もう 広まって いるんですね。"]));
    K.act(eM, 0);
    await K.csay(p, "mimi", ["{smile}あさっては 収穫祭なんだよっ。あたし、今年は 実行係なんだよっ！", "{sad,…,up}でもね……飾りが ぜんぜん 足りないの。それに、畑の 麦が 毎晩 食べられちゃうんだよっ。"], eH);
    const eN = K.cast(p, "nol");
    K.act(eN, "hold");
    await K.csay(p, "nol", ["{smile}ほっほ。ミミ、そう 大声を 出すと 麦が おびえるんじゃよ。", "{closed}わしは ノル。……と、名乗るまでも ないか。干し草の じじいじゃよ。"]);
    await K.hsay(p, K.V(["{smile,♪}ノルじい！ 腰は もう いいの？"], ["{smile}ノルじい。腰は もう いいの？"], ["{closed}ノルじい。腰は。"], ["{smile}ノルじいさま！ お腰は もう よろしいのですか？"]));
    await K.csay(p, "nol", ["{smile,nod}この とおりじゃよ。……ほれ、言うて おる そばから、来おったわい。"]);
    K.act(eN, 0);
    /* 畑を 荒らす 野生（畑の 方を 映す）*/
    const fld = { x: c.x + 14, y: y0, z: c.z };
    const w1 = K.monEnt(p, { x: fld.x - 1, y: y0, z: fld.z - 1 }, K.wildSp("animal"), ""), w2 = K.monEnt(p, { x: fld.x + 1, y: y0, z: fld.z + 1 }, K.wildSp("beast"), "");
    K.sound(p, "mob.wolf.growl", 0.8); K.burst(p.dimension, fld, "minecraft:white_smoke_particle", 8, 1.4, 0.3);
    await K.at(p, fld, 18, 5, 1);
    await K.csay(p, "mimi", ["{shock,!,up}あーっ！ また 来たんだよっ！ 麦がーっ！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,怒,up}もう！ お祭りの 麦なんだから！ 追いはらうよ！"], ["{angry,up}……ごめんね。でも その 麦は、みんなの お祭りの ぶんなの。"], ["{angry,up}……追いはらう。手加減は する。"], ["{angry,up}お祭りの 麦です！ 追いはらいましょう！"]));
    if (!K.flag(p, "r0e2w")) {
      K.rmCine(w1); K.rmCine(w2);
      const r = await K.battle(p, K.team(["animal", "beast"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "畑を 荒らす 野生の 群れ", arena: "収穫祭の 前", easy: true, speaker: "野生の モンスター", lines: { half: "……ガウ……", low: "……キュウ……" } });
      if (r !== "win") return lose(K, p, "§eパン屋の ミミ", K.PJ("mimi", 9), "ミミ", "{sad}だ、だいじょうぶ？ ……麦より、あなたの ほうが 大事なんだよっ。");
      K.setFlag(p, "r0e2w");
    } else { K.rmCine(w1); K.rmCine(w2); }
    K.burst(p.dimension, fld, "minecraft:villager_happy", 8, 1.2, 0.6);
    await K.csay(p, "mimi", ["{smile,☆,jump}やったー！ 逃げてったよっ！", "{smile,up}ありがとうだよっ！ ……ねえ、ついでに 飾りあつめも 手伝って くれる？"]);
    await K.hsay(p, K.V(["{smile,♪,nod}もちろん！"], ["{smile,nod}ええ、もちろん。"], ["{closed,nod}……いいよ。"], ["{smile,nod}はい、喜んで！"]));
    /* 時が 流れる: 飾りが そろう */
    K.cmd(p, "camera @s fade time 0.4 0.6 0.5 color 30 20 10"); await K.wait(12);
    K.deco(p, "t0fest", 1, c, y0);
    await K.narr(p, ["§7あなたたちは 半日 かけて、麦わらと 花と 灯りを 集めて 回った。", "§7やがて 日が かたむき、原っぱに 屋台の 骨組みが 並んだ。"], { x: c.x - 11, y: y0, z: c.z });
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z });
    /* ノルじいの 昔話（オルドと、もう 一人の 若者）*/
    K.act(eN, "hold");
    await K.hsay(p, K.V(["{?}ねえ ノルじい。村長って、昔から ああなの？", "{sweat,汗}なんでも『昔、ちょっとな』で ごまかすんだもん。"], ["{?}ノルじい。村長さんって、昔から 口数が 少ないの？"], ["{?}ノルじい。村長の『昔、ちょっと』って、何？"], ["{?}ノルじいさま。村長さまの『昔、ちょっと』とは……？"]));
    await K.csay(p, "nol", ["{closed,息}ほっほ……オルドか。あれは 昔は、よう しゃべる 男じゃったよ。", "{smile}いつも もう 一人と 一緒でな。背の 高い、星を 見るのが 好きな 若者じゃったよ。"], eH);
    await K.memory(p, eN, "§7― 四十年 ほど 前 ―", ["§7若い オルドと、もう 一人の 若者が、この 原っぱで 星を 数えて いた。", "§7二人は どこへ 行くにも、いつも 一緒だった。"]);
    await K.at(p, { x: c.x, y: y0 + 6, z: c.z }, 10, 6, 4);
    await K.memory(p, eN, "§7― 二十年 ほど 前の 冬 ―", ["§7男の 手には、編みかけの 紐が あった。", "§7「うまく 編めたら、生まれた ばかりの 娘に やるんだ」と、男は 笑って いた。"]);
    await K.narr(p, ["§7ほどいては 編み、ほどいては 編み……紐は いつまでも、できあがらなかった。"], eN);
    await K.csay(p, "nol", ["{sad,…,up}その 冬、二人は もう 一度 旅に 出た。……帰って きたのは、オルド 一人じゃったよ。"]);
    await K.hsay(p, K.V(["{shock,!,up}え……！ じゃあ、その 人は……？"], ["{sad,up}……その 方は、どう なったの？"], ["{shock,…,up}……もう 一人は？"], ["{shock,!,up}そ、その 方は……？"]));
    await K.csay(p, "nol", ["{closed,no}わからん。オルドは あれから、あの 男の 名を 一度も 口に せんのじゃよ。", "{sad}わしが 聞いても、遠くの 空を 見るだけじゃよ。"], eH);
    await K.up(p, eN, 10);
    await K.csay(p, "nol", ["{smile,up}……おまえさんが 旅に 出ると 聞いて、あの 二人を 思い出して しもうたんじゃよ。", "{closed}年寄りの 昔話じゃ。……忘れんで、おいて くれるかの。"]);
    K.act(eN, 0);
    /* 第125版: 八年前の 収穫祭（道化の 一座と、袖の 女の子）*/
    K.act(eM, "hold");
    await K.up(p, eM, 12);
    await K.csay(p, "mimi", ["{smile,…,up}……屋台の 骨組みを 見ると、思い出すんだよっ。八年前の 収穫祭に、道化の 一座が 来たんだよっ。", "{smile}舞台の 袖に、あたしと 同じ くらいの 女の子が いてね。台本を 抱えて、ずっと 舞台を 見てたんだよっ。"]);
    await K.csay(p, "mimi", ["{smile,♪}パンを 半分こ して、友だちに なろうねって 約束したの。", "{sad,up}……でも 一座は 次の 年から 来なく なっちゃった。"], eH);
    await K.csay(p, "mimi", ["{sad,up}名前、教えて もらったのに……思い出せないんだよっ。"]);
    K.act(eM, 0);
    await K.csay(p, "mimi", ["{smile,♪,jump}飾り、ぜーんぶ そろったよっ！ あさっての 夜、ぜったい 来てねっ！"]);
    await K.hsay(p, K.V(["{smile,☆,up}うん、約束！"], ["{smile,up}ええ、約束ね。"], ["{smile,up}……約束。"], ["{smile,up}はい、約束です。"]));
    await K.csay(p, "nol", ["{closed,low}……祭りの 夜は、昔から 影が 騒ぐ。気を つけるんじゃよ。"]);
    K.pay(p, E2, 200, [["gift_bread", 2]]);
    await K.end(p, { leave: [eM, eN], card: "§7― 収穫祭まで、あと 二日 ―", kind: "fest" });
    return true;
  } };

/* ---------- 3話 祭りの 夜（屋台 → ガロは 北の 門の 外へ。決着は 今の 段「北の 門」）---------- */
const E3 = { id: "r0e3", n: 3, t: "祭りの 夜", at: 1, ord: 1, place: FEST,
  hint: "§fルミナの 外れの §e祭りの 原っぱ§f で §6収穫祭§f が 始まる §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "収穫祭の 夜、六影を 名乗る 下っぱの ガロが ミミの 屋台を おどした。門番の ゴンザが 立ちはだかり、オルドは「その 名の 重さを 知って 名乗って おるのか」と ガロを にらんだ。手下を 退けると、ガロは 毎年 パンを もらいに 来る 小さな モンスターを さらって、北の 門の 外へ 逃げた。",
  set: { garoFest: 1, met0: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), garoFest: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "t0fest", 1, c, y0);
    await K.open(p, "ルミナの 収穫祭（夜）", "night");
    K.sound(p, "note.harp", 0.7); K.sound(p, "note.bell", 0.5);
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{smile,☆,jump}わあ……！ 屋台が いっぱい！ 灯りが きれい！"], ["{smile,♪}……きれい。毎年 見てるのに、今年は なんだか ちがって 見える。"], ["{smile}……悪くない。灯りの 数、去年より 多い。"], ["{smile,☆}わあ……なんて きれいな 灯りでしょう。"]));
    const eM = K.cast(p, "mimi"); K.act(eM, "raise");
    await K.csay(p, "mimi", ["{smile,☆,jump}来てくれたーっ！ 収穫祭の 麦パン、焼きたてだよっ！", "{smile}これは あたしからだよっ。飾りあつめの お礼なんだよっ！"]);
    const q0 = K.fwd(p, 3.5, -2.2);
    const kid = K.monEnt(p, q0, baseOf("animal") || K.wildSp("animal"), "§7小さな モンスター");
    if (ok(kid)) { K.burst(p.dimension, kid.location, "minecraft:heart_particle", 4, 0.5, 0.8); await K.up(p, kid, 12); }
    await K.narr(p, ["§7屋台の かげから、小さな 野生の モンスターが 顔を 出した。"], kid);
    await K.csay(p, "mimi", ["{smile,♥}あ、この子！ 毎年 パンを もらいに 来るんだよっ。", "{smile,♪}はい、今年の ぶんだよっ。……ふふ、しっぽ ふってるよっ。"]);
    const eG = K.cast(p, "gonza"); K.act(eG, "hold");
    await K.csay(p, "gonza", ["{closed}祭りの 夜は、拙者が 見回るでござる。", "{smile}ミミ殿の パンは、今年も うまそうでござるな。", "{smile}その 子は、オルド殿の 石板の 蔵の 軒下で 寝て おる 野良でござるよ。"], eH);
    await K.hsay(p, K.V(["{?}ゴンザさん、門は いいの？"], ["{?}ゴンザさん、門は いいの？"], ["{?}ゴンザ、門は。"], ["{?}ゴンザさん、門は よろしいのですか？"]));
    await K.csay(p, "gonza", ["{smile,nod}門には 弟分を 立たせて おるでござる。……祭りの 夜くらい、町の 外も 守るでござるよ。"]);
    K.act(eG, 0);
    /* ガロと 手下が 来る */
    K.sound(p, "mob.villager.no", 1);
    const eGa = K.npcNear(p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9)), eD = K.npcNear(p, "§c六影の 下っぱ ドンゴ", K.PJ("noxa", 9)), eC = K.npcNear(p, "§c六影の 下っぱ チョロ", K.PJ("noxb", 9)), ePi = K.npcNear(p, "§d手下 ピコ", K.PJ("pico", 9));   /* 第124版(合議): ピコは 袋持ち。祭りの 夜に 先に 顔を 出す */
    await K.low(p, eGa, 12);
    await K.say(p, "ガロ", ["{angry,low}おい、パン屋。今夜の 売り上げ、半分 よこしな。"]);
    await K.csay(p, "mimi", ["{shock,!,up}え……！？ やだよっ！ これは 町の みんなで 作った お祭りなんだよっ！"]);
    K.act(eD, "point");
    await K.say(p, "ドンゴ", ["{angry}へっへっ。§5六影§f の 名前を 聞いても、まだ 逆らうか？"]);
    await K.say(p, "ガロ", ["{angry}オレたちは §5六影§f だ。逆らえば、屋台ごと ひっくり返す。"]);
    if (ok(eG) && ok(eM)) { const q = eM.location; await K.go(eG, { x: q.x + 1.3, y: q.y, z: q.z + 0.6 }, 10, true); } K.act(eG, "guard");
    await K.csay(p, "gonza", ["{angry,怒,up}待たれよ！ 祭りを 汚す 者は、この ゴンザが 通さぬでござる！"]);
    /* オルドが 歩いて 来る */
    const eO = ORDO(K, p); K.act(eO, "hold");
    await K.low(p, eO, 14);
    await K.say(p, "オルド", ["{angry,low}……小僧。", "{angry,up}おまえさん、その 名の 重さを 知って 名乗って おるのか。"]);
    await K.say(p, "ガロ", ["{sweat,汗}……な、なんだ じじい。名前に 重いも 軽いも あるかよ。"]);
    await K.say(p, "オルド", ["{closed,low}石板を 集める 者が、なぜ 祭りの 売り上げを ほしがる。……おまえさん、上から 何も 聞かされて おらんな。"]);
    await K.say(p, "ガロ", ["{sweat,汗}……上は『石板を 持って こい。石板に なつく モンスターを 見つけろ』しか 言わねえ。飯代は てめえで かせぐしか ねえんだよ！"]);
    await K.hsay(p, K.V(["{shock,…,up}（……村長、牧場でも 同じ 顔 してた。あの 名前を 聞いた ときだけ……）"], ["{sad,…,up}（……村長さん、また あの 顔。あの 名前の ときだけ）"], ["{closed,…,up}（……また だ。あの 名前で、村長の 顔が かわる）"], ["{shock,…,up}（村長さま……あの 名前の ときだけ、あんな お顔を……）"]));
    await K.say(p, "チョロ", ["{sweat,汗}あ、兄貴……あの じいさん、目が こわいっす……。"]);
    await K.say(p, "ガロ", ["{angry,!}う、うるせえ！ ドンゴ、チョロ、やっちまえ！"]);
    if (!K.flag(p, "r0e3w")) {
      const r = await K.battle(p, K.team(["beast", "animal"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "ガロの 手下 ドンゴと チョロ", arena: "祭りの 夜", easy: true, speaker: "ドンゴ", lines: { half: "ひいっ、この ガキ つええ……！", low: "あ、兄貴ぃーっ！" } });
      if (r !== "win") return lose(K, p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9), "ガロ", "……へっ。祭りの 売り上げは もらって いくぜ。");
      K.setFlag(p, "r0e3w");
    }
    const eD2 = K.npcNear(p, "§c六影の 下っぱ ドンゴ", K.PJ("noxa", 9), true), eC2 = K.npcNear(p, "§c六影の 下っぱ チョロ", K.PJ("noxb", 9), true); K.act(eD2, "down"); K.act(eC2, "kneel");
    const eGa2 = K.npcNear(p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9), true);
    await K.say(p, "ガロ", ["{angry}……ちっ。覚えて おけ。"]);
    const kid2 = ok(kid) ? kid : K.monEnt(p, K.fwd(p, 3.5, -2.2), baseOf("animal") || K.wildSp("animal"), "§7小さな モンスター");
    if (ok(eGa2) && ok(kid2)) { const q = kid2.location; await K.go(eGa2, { x: q.x + 0.9, y: q.y, z: q.z }, 8, true); K.act(eGa2, "hold"); }
    await K.up(p, eGa2, 10);
    await K.say(p, "チョロ", ["{sweat,汗}あ、兄貴、あの チビ……石板の 蔵の 軒下の やつっす。石板の 匂いが するっす。"]);
    await K.say(p, "ガロ", ["{!,low}……石板に なつく やつか。手ぶらじゃ 帰れねえ。もらって いくぜ！"]);
    const ePi2 = K.npcNear(p, "§d手下 ピコ", K.PJ("pico", 9), true);
    await K.say(p, "ピコ", ["{sweat,汗}に、兄ちゃん……その 子、ないてるよ……。"]);
    await K.say(p, "ガロ", ["{angry}うるせえ、ピコ！ 袋を 開けろ！"]);
    K.sound(p, "mob.wolf.whine", 1.1);
    if (ok(eM) && ok(kid2)) { const q = nearPt(eM, kid2, 1.5); if (q) await K.go(eM, q, 8, true); K.act(eM, "point"); }
    if (ok(kid2) && kid2.typeId !== "mrpg:npc") anim(kid2, "guard");
    await K.csay(p, "mimi", ["{cry,tears,up}あの子が……！ 毎年 パンを 食べに 来る 子なんだよっ！ 返してよっ！"]);
    const run = [K.leave(eGa2, p, 12, true), K.leave(eD2, p, 12, true), K.leave(eC2, p, 12, true), K.leave(ePi2, p, 12, true)];
    if (ok(kid2)) run.push((async () => { const q = K.away(kid2, p, 10); if (q) await K.go(kid2, q, 12, true); K.rmCine(kid2); })());
    await K.wide(p, 10); await Promise.all(run);
    await K.csay(p, "gonza", ["{angry,!,up}手下の 二人は 南へ 逃げたでござる。ガロと、袋を 持った 小さいのは 北の 門の 方でござる！"]);
    await K.say(p, "オルド", ["{closed}……追うんじゃ。じゃが 深追いは するな。", "{sad,low}門の 外は 今夜、嫌な 風が 吹いて おる。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}行こう！ あの子を 取り返す！"], ["{angry,up}……行きましょう。あの子、こわがってた。"], ["{angry,up}……行く。返して もらう。"], ["{angry,up}追いかけましょう！ あの子を 取り返します！"]));
    K.pay(p, E3, 200, [["mei_arca", 1]]);
    await K.end(p, { leave: [eM, eG, eO], card: "§7→ 北の 門を 出て、ガロを 追おう（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 4話 影が 来る（北の 門の 外の 影が 祭りへ）---------- */
const E4 = { id: "r0e4", n: 4, t: "影が 来る", snd: "item.book.page_turn", at: 2, ord: 0, place: FEST,
  hint: "§f影が ルミナの 方へ 流れた！ §e祭りの 原っぱ§f へ もどろう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "北の 門の 外から 流れた 影の 残りが、収穫祭を おそった。灯りが 倒れ、門番の ゴンザは ミミを かばって けがを した。オルドは「……二十年前と 同じ 影じゃ」と つぶやいた。祭りは 中止に なり、あなたは ミミと「帰って きたら、もう一度 祭りを しよう」と 約束して、旅に 出る 覚悟を 決めた。",
  set: { gonzaHurt: 1, met0: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), gonzaHurt: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), met = !!(qs(load(p) || d).epx || {}).met0;
    K.deco(p, "t0fest", 9, c, y0);
    await K.open(p, "祭りの 原っぱ", "ash");
    K.sound(p, "mob.villager.no", 1); K.shake(p, 0.25, 0.5);
    const eH = K.hero(p), eS = THEO(K, p);
    await K.hsay(p, K.V(["{shock,!,up}お祭りが……！ 灯りが 倒れてる！"], ["{shock,…,up}……そんな。お祭りが……"], ["{shock,!,up}……祭りが、やられてる。"], ["{shock,!,up}お、お祭りが……！"]));
    await K.say(p, "セオ", ["{sweat,汗}影の 残りが、人の 多い 方へ 流れたんだ……！ まだ 近くに いる！"]);
    const eM = K.cast(p, "mimi"), eG = K.cast(p, "gonza");
    K.act(eM, "kneel"); K.act(eG, "guard");
    if (!met) await K.csay(p, "mimi", ["{cry,tears,up}た、助けて……！ 影が、屋台を……！"]);
    await K.csay(p, "gonza", ["{angry,!,up}ミミ殿、拙者の 後ろへ！ ……門番 ゴンザ、ここは 通さぬでござる！"]);
    /* 影が ミミへ。ゴンザが かばう */
    const far = K.fwd(p, 12, 3), mq = ok(eM) ? eM.location : K.fwd(p, 3);
    await K.at(p, far, 8, 5, 1);
    await K.shadowFlow(p, far, mq, 22);
    K.boom(p.dimension, mq); K.sound(p, "random.explode", 0.8); K.shake(p, 0.7, 0.6); K.flash(p, false);
    if (ok(eG)) await K.knock(eG, far, 2.5);
    await K.up(p, eG, 10);
    await K.csay(p, "mimi", ["{cry,tears,up}ゴンザさん！！"]);
    await K.csay(p, "gonza", ["{sad,up}……かすり傷でござる……。ミミ殿、さがって おれ……"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{rage,怒,up}……ゆるさない！ みんなの お祭りを！！"], ["{angry,tears,up}……もう、だれも 傷つけさせない！"], ["{rage,怒,up}……許さない。"], ["{rage,怒,up}ゆるしません……！ みんなの お祭りを！"]));
    if (!K.flag(p, "r0e4w")) {
      await K.duel(p, "§4影の かけら", "§c影の かけらが 灯りを 呑みこむ！");
      const r = await K.battle(p, K.bossOne(["nether"], 4, 12), { name: "影の かけら", arena: "影が 来る", theme: "underworld", hpk: 2.5, speaker: "影の かけら", lines: { half: "………………", low: "……マツリ……キエ……ル……" } });
      if (r !== "win") return lose(K, p, "§7学者 セオ", 18, "セオ", "{sweat,汗}い、いったん 下がって！ 影は まだ 消えて いない……！");
      K.setFlag(p, "r0e4w");
    }
    const eG2 = K.cast(p, "gonza", true); K.act(eG2, "kneel");
    const eM2 = K.cast(p, "mimi", true);
    K.burst(p.dimension, ok(eG2) ? eG2.location : c, "minecraft:white_smoke_particle", 10, 1.6, 0.4);
    await K.narr(p, ["§7影は ほどけて 夜空へ 消えた。", "§7倒れた 灯りの 煙だけが、原っぱに 残った。"], eG2);
    const eO = ORDO(K, p); K.act(eO, "kneel");
    if (ok(eO) && ok(eG2)) { const q = eG2.location; await K.go(eO, { x: q.x - 1.2, y: q.y, z: q.z + 0.4 }, 10); }
    await K.say(p, "オルド", ["{closed}……骨は 折れて おらん。じゃが、しばらくは 門に 立てんぞ。"]);
    K.act(eG2, "up");
    await K.csay(p, "gonza", ["{angry,stagger,up}拙者が 立たねば、だれが 門を 守るでござるか……！"]);
    K.act(eO, 0);
    await K.up(p, eO, 12);
    await K.say(p, "オルド", ["{sad,low}…………二十年前と、同じ 影じゃ。"]);
    await K.hsay(p, K.V(["{?,up}村長……？ 二十年前って……"], ["{?,up}村長さん……？ 二十年前って……"], ["{?,up}……村長。二十年前？"], ["{?,up}村長さま……？ 二十年前とは……"]));
    await K.say(p, "オルド", ["{closed,no}……いや。なんでも ない。"]);
    K.act(eM2, "kneel");
    await K.csay(p, "mimi", ["{cry,tears,up}お祭り……なくなっちゃったよっ……。", "{cry,up}みんなで 飾り、集めたのに……。"]);
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:heart_particle", 4, 0.4, 0.9); await K.up(p, g, 12); }
    await K.hsay(p, K.V(["{angry,!,up}……決めた。わたしたち、石板を 集める。", "{smile,tears,up}ミミちゃん、約束する。帰って きたら、もう一度 お祭りを しよう！"], ["{closed,up}……決めたわ。石板を 集めて、影を 止める。", "{smile,tears,up}ミミちゃん。帰って きたら、もう一度 お祭りを しましょう。約束よ。"], ["{angry,up}……決めた。影を 止める。石板を 集める。", "{smile,up}ミミ。帰ったら、祭りの やり直し。……約束。"], ["{angry,up}……決めました。石板を 集めて、影を 止めます。", "{smile,tears,up}ミミさん。帰って きたら、もう一度 お祭りを しましょう。約束です。"]));
    K.act(eM2, 0);
    await K.csay(p, "mimi", ["{cry,smile,up}……うん。約束、だよっ。"]);
    K.rmCine(g);
    await K.up(p, eS, 10);
    await K.say(p, "セオ", ["{closed}……今夜の ことは、全部 書き留めて おきます。"]);
    await K.hsay(p, K.V(["{?}セオさん？"], ["{?}セオさん？"], ["{?}……セオ？"], ["{?}セオさん……？"]));
    await K.say(p, "セオ", ["{smile,汗}あ、いえ。学者の くせです。", "{closed}……城へ 急ぎましょう。王に 伝えなければ。"], eH);
    await K.csay(p, "gonza", ["{smile,up}拙者は ここで 町を 守るでござる。……必ず、帰って くるでござるよ。"]);
    K.pay(p, E4, 300, [["c_herbs", 2]]);
    await K.end(p, { leave: [eO, eM2], bye: [eG2, eS], card: "§7→ アルカトラス城の 中庭へ（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 5話 城へ（王と 地方マスター ミドリ。勝負は 中庭の ミドリに 話しかける）---------- */
const E5 = { id: "r0e5", n: 5, t: "城へ", at: 2, ord: 1, place: COURT,
  hint: "§f§6アルカトラス城の 中庭§f へ 行こう §7（右上の 案内。王に 祭りの ことを 知らせる。「！」の 目印の そばで 立ち止まろう）",
  syn: "アルカトラス城の 中庭で、王 アルカ十三世に 祭りの ことを 知らせた。王は「父の 代に、地下の 封印庫を 開けて 調べさせて くれと 言うた 男が いた。父は 追い返した」と 話した。地方マスター ミドリは「悔しいなら、その 気持ちを 仲間に 預けて」と 勝負を 受けた。",
  set: { met0: 1 },
  async run(p, d, K) {
    await K.open(p, "アルカトラス城の 中庭", "castle");
    K.sound(p, "note.bell", 0.6);
    const eH = K.hero(p), eS = THEO(K, p);
    const eK = K.cast(p, "arca"); K.act(eK, "hold");
    await K.low(p, eK, 14);
    await K.csay(p, "arca", ["{closed}……セオから 聞いた。ルミナの 祭りが、影に おそわれたと。", "{sad,up}民の 祭りを 守れなかった。王として、恥ずかしい かぎりだ。"]);
    await K.hsay(p, K.V(["{angry,!,up}王さまの せいじゃ ないよ！ 悪いのは あの 影だよ！"], ["{sad,up}……王さまの せいじゃ ないわ。"], ["{closed,up}……王の せいじゃ ない。"], ["{shock,!,up}へ、陛下の せいでは ありません！"]));
    K.act(eK, 0);
    await K.up(p, eK, 10);
    await K.csay(p, "arca", ["{closed,low}……わが 父の 代にも、似た ことが あった。", "{sad}ある 男が 城に 来て、『封印が ゆるむ。地下の 封印庫を 調べさせて くれ』と 言うたのだ。"], eH);
    K.act(eK, "point");
    await K.csay(p, "arca", ["{closed}父は 王冠を 狙う 者と 決めつけ、追い返した。", "{sad,up}……今にして 思えば、あの 者は、何を 知って いたのか。"], eH);
    K.act(eK, 0);
    await K.up(p, eS, 12);
    await K.say(p, "セオ", ["{closed,…}…………そう、ですか。"]);
    await K.csay(p, "arca", ["{up}石板は、守り手に 勝った 者にしか 渡らぬ 決まり。……ミドリ。"]);
    const eMi = K.cast(p, "midori"); K.act(eMi, "hold");
    await K.two(p, eK, eMi, 10);
    await K.csay(p, "midori", ["{smile}はい、陛下。", "{smile}……あなたが ルミナの 子ね。祭りの こと、聞いたわ。"]);
    K.act(eMi, "guard");
    await K.csay(p, "midori", ["{angry,up}悔しいなら、その 気持ちを 仲間に 預けて。", "{smile,up}わたしに 勝てたら、一枚目の 石板を 託すわ。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}……うん。勝って、ミミちゃんとの 約束を 守る！"], ["{closed,up}……ええ。ミミちゃんとの 約束、守りたいもの。"], ["{angry,up}……勝つ。約束が ある。"], ["{angry,up}はい。ミミさんとの 約束を 守ります！"]));
    K.act(eMi, 0);
    await K.csay(p, "midori", ["{smile,nod}準備が できたら、中庭の わたしに 話しかけて。……待ってるわ。"]);
    K.pay(p, E5, 200, []);
    await K.end(p, { leave: [eMi, eK], bye: [eS], card: "§7→ 中庭の §6地方マスター ミドリ§7 に 話しかけて 勝負（勝つと 石板）", kind: "castle" });
    return true;
  } };

/* ---------- 5話 城へ（つづき）: やり直しの 収穫祭。町の 発展度が 上がり、祭りが 開かれる ---------- */
const E6 = { id: "r0e6", n: 6, t: "やり直しの 収穫祭", at: 3, ord: 0, place: FEST,
  hint: "§fルミナの §e祭りの 原っぱ§f で §6やり直しの 収穫祭§f が 開かれる §7（右上の 案内。ミミとの 約束。そのあと シルヴァの 洞くつへ）",
  syn: "一枚目の 石板を 封じて ルミナへ もどると、ミミとの 約束どおり、やり直しの 収穫祭が 開かれた。けがの 治った ゴンザ、ノルじい、オルドが あなたを 送り出した。町の 人たちは「帰る 場所を 守ろう」と 店を 増やし、ルミナは 少し にぎやかに なった。",
  set: { fest0: 1, met0: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest0: 1 }; },
  fx: { xp: ["t0", 160], fest: "t0" },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "t0fest", 2, c, y0);
    await K.open(p, "ルミナの やり直しの 収穫祭", "fest");
    K.sound(p, "firework.blast", 0.7); K.sound(p, "note.harp", 0.8);
    const eH = K.hero(p), eM = K.cast(p, "mimi");
    K.act(eM, "raise");
    await K.csay(p, "mimi", ["{smile,☆,jump,up}来て くれたーっ！ 約束、ちゃんと 守って くれたんだよっ！"]);
    await K.hsay(p, K.V(["{smile,tears,up}ただいま、ミミちゃん！ ……灯り、前より 多いね！"], ["{smile,tears,up}……ただいま。灯りが、前より 増えてる。"], ["{smile,up}……ただいま。約束、守った。"], ["{smile,tears,up}ただいま 帰りました！ 灯りが、前より 増えて いますね。"]));
    await K.csay(p, "mimi", ["{smile,♪}町の みんなが ね、『あの 子たちの 帰る 場所を 守ろう』って……", "{smile,☆,up}前より たくさん お店を 出したんだよっ！"], eH);
    const eG = K.cast(p, "gonza"); K.act(eG, "hold");
    await K.csay(p, "gonza", ["{smile}拙者も この とおり、門に もどれたでござる。", "{closed,up}……傷は 残ったが、これは 町を 守った 印でござる。"]);
    const eN = K.cast(p, "nol");
    await K.csay(p, "nol", ["{smile,♪}ほっほ、にぎやかじゃのう。祭りは こうで なくちゃ いかんのじゃよ。"]);
    const eO = ORDO(K, p);
    await K.say(p, "オルド", ["{smile,up}……一枚目の 石板、見事じゃった。"]);
    K.act(eO, "hold");
    await K.up(p, eO, 10);
    await K.say(p, "オルド", ["{closed}わしも 若い ころ、ここで こうして 送り出された ことが ある。", "{sad,…,up}……そして、帰って きたのは……いや。"], eN);
    K.act(eO, 0);
    if (ok(eN)) { K.re(eN, "closed", "…"); await K.up(p, eN, 12); }
    await K.csay(p, "nol", ["{smile,up}……今度は、みんな 帰って くるんじゃよ。のう、オルド。"]);
    await K.say(p, "オルド", ["{smile,息}……ああ。そうじゃな。"]);
    /* 踊りの 輪 */
    for (const e of [eM, eG, eN, eH]) K.act(e, 9);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z }); K.sound(p, "note.pling", 0.8);
    const g = K.palEnt(p); if (g) K.burst(p.dimension, g.location, "minecraft:note_particle", 5, 0.5, 1);
    await K.wide(p, 26);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z });
    for (const e of [eM, eG, eN, eH]) K.act(e, 0);
    K.rmCine(g);
    K.act(eM, "hold");
    await K.csay(p, "mimi", ["{smile,♥}はい、これ！ 収穫祭の はちみつパンだよっ。旅の おともに するんだよっ！"]);
    const got = K.pay(p, E6, 500, [["mei_arca", 2], ["gift_bread", 3]]);
    if (got.length) K.big(p, "§e§lミミの パン", `§e${got.join("・")}`);
    K.act(eM, 0);
    await K.csay(p, "gonza", ["{smile,up}いって らっしゃいでござる！ 門は いつでも、開けて 待って おるでござる！"]);
    await K.hsay(p, K.V(["{smile,tears,up}……いって きます！！"], ["{smile,tears,up}……いって きます。"], ["{smile,up}……いって きます。"], ["{smile,tears,up}……いって まいります！"]));
    await K.end(p, { leave: [eO], bye: [eM, eG, eN], card: "§f― 第1章 旅立ち おわり ―\n§7→ 次は シルヴァ大森林の ほたるの 里 ルミエへ（セオの 待つ 洞くつは その 先。右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(0, [E2, E3, E4, E5, E6], { steps: { 0: [1, "旅立ち"], 1: [3, "祭りの 夜（北の 門の 外）"], 2: [5, "城へ（ミドリとの 勝負）"] } });
