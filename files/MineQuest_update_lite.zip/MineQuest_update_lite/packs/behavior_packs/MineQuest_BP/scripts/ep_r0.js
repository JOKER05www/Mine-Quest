/* 第125版: 第1地方 アルカトラス の 5話（手本）
   ■ この ファイルの 書き方（ほかの 地方も 同じ 形。ep_r1.js 〜 ep_r10.js）
   1) 登場人物を castAdd で 登録する（cast.js）。見た目は skinjobs.js の PSKIN の キー（"mimi" など）。語尾 gobi は 必ず 書く
      town と at を 書くと、from の 話を 終えた 人には 町に 立って、話しかけると after の「その後」を 話す
   2) epAdd(地方の 番号, [話, ...], { steps: { 地方の 中の 段の 番号: [話の 番号, 題] } }) で 話を 足す
      ・at: その 地方の 何番目の 段の 前に 入るか（0 から。段の 数と 同じ なら 最後の 段の あと）。同じ at の 話は ord の 順
      ・id は ほかと かぶらない 名前（"r地方e話" の 形）。一度 出したら かえない（セーブに 残る）
      ・place(p) は 始まる 場所 { x, z, nm }。噴水の 横・町の 中の 通り道・階段や 坂の 途中は だめ。町の 外れ・城の 中庭・ステージなど
      ・hint は 右上と ガイドブックの 文（どこで・何を・どうやって。2行まで）。syn は あらすじ（話が 済んだ あと だけ 出る）
      ・run(p, d, K) は 場面。true を 返すと 済み。負けた・あとで は false（ガイドブックの「物語の 戦いに 再挑戦」で もう一度）
      ・とちゅうの 印は K.flag(p, "名前")／K.setFlag(p, "名前")（とちゅうで 抜けても 戦いを くり返さない）
      ・ほうびは K.pay(p, ep, お金, [[道具, 数]])（1回だけ）。町の 変化は fx: { xp: ["t0", 数], fest: "t0" }（ワールドで 1回）
      ・skip(s) は チートや「とばす」で 飛ばした ときに そろえる 印。set は 話を 終えた ときに s.epx へ 入れる 印
   3) 演出は K の 部品で 書く（決まりを 守る ため）
      K.open（始まりの 引きの 絵）→ K.cast／K.hero（人は 歩いて 来る）→ K.csay／K.say／K.hsay（2行ごとに 聞き手の 顔へ 切りかえ）
      気持ちが 動く 行は {顔,up}（寄り と 表情）。しぐさは K.act・{nod}{arms} などで 3行に 1回 以上。K.up／K.low／K.two／K.wide／K.at で 絵を かえる
      戦いは K.battle（1つの 場面で 3回まで）。終わりは K.end({ leave: [去る 人], card: "次の 案内" })（引きの 絵 → セリフと 画面を 消す）
      集中線・上下の 黒い 帯は 使わない。ひらがな 多め・わかち書き。クリア前に 見える 文に ネタバレを 書かない */
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, ranchSpot, spotOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, castleSpot } from "./structures.js";
import { regionIdx } from "./worldmap.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok, anim } from "./ui.js";
import { stageFor, standY, clampPath, freeAt } from "./stagecore.js";
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* b の そば k マス（a の 側）*/
import { baseOf } from "./partner.js";
import { wl } from "./wqlore.js";
import { plazaOf, gateOut, festSet, crowd, gateSet, moveG } from "./pvplace.js";   /* 第126版(PV): 祭りは 町の 広場・戦いは 門の 外 */   /* 第125版: 世界の 依頼を 済ませた 人だけの 一言 */
/* 第126版(PV): 吹っ飛ぶ（攻撃した 側から 離れる 向き。あなたと ほかの 人から 2マス 以上・立てる 地面・壁の 手前。まっすぐ 後ろが あなたなら 斜め 横へ）*/
async function knockSafe(K, p, e, from, dist = 3) {
  if (!ok(e) || !from) return null; const l = e.location, S = stageFor(e) || K.S(p), dim = p.dimension;
  const a0 = Math.atan2(l.z - from.z, l.x - from.x), P0 = p.location; let best = null;
  for (const dd of [dist, dist + 1, dist + 2]) { for (const da of [0, 0.6, -0.6, 1.1, -1.1, 1.6, -1.6]) {
    const a = a0 + da; let to = { x: l.x + Math.cos(a) * dd, y: l.y, z: l.z + Math.sin(a) * dd };
    if (S) to = clampPath(S, l, to); if (Math.hypot(to.x - l.x, to.z - l.z) < 1.5) continue;
    const y = standY(dim, to.x, to.z, l.y, S && S.C); if (y === null) continue; to.y = y;
    if (Math.hypot(to.x - P0.x, to.z - P0.z) < 2.2) continue; if (S && !freeAt(S, to, e, 2)) continue;
    { const ux = to.x - from.x, uz = to.z - from.z, n = Math.hypot(ux, uz) || 1, hx = to.x + (ux / n) * 1.8, hz = to.z + (uz / n) * 1.8;   /* 倒れた 体（頭は 攻撃と 反対の 背中の 側へ 1.8）が だれの 足もとにも かからない */
      const who = [P0]; try { if (S) for (const o of S.ents) if (o !== e && ok(o)) who.push(o.location); } catch {}
      if (who.some((w) => { for (let t = 0; t <= 1.001; t += 0.25) if (Math.hypot(to.x + (hx - to.x) * t - w.x, to.z + (hz - to.z) * t - w.z) < 1.3) return true; return false; })) continue; }
    best = to; break; } if (best) break; }
  if (!best) { K.act(e, "down"); return null; }
  K.act(e, "knocked", false); if (S && S.dest) S.dest.set(e.id, best);
  for (let k = 1; k <= 8; k++) { if (!ok(e)) return best; const t = k / 8; try { e.teleport({ x: l.x + (best.x - l.x) * t, y: l.y + (best.y - l.y) * t + Math.sin(t * Math.PI) * 1.2, z: l.z + (best.z - l.z) * t }, { facingLocation: { x: from.x, y: best.y + 1, z: from.z } }); } catch {} await K.wait(1); }
  K.act(e, "down"); return best;
}

/* ---------- 場所 ---------- */
const lumina = () => { const t = TOWNS.find((u) => u.id === "t0"); if (!t) return null; const q = getTown("t0"); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
/* 祭りの 原っぱ: ルミナの 外れ（城と 反対・牧場とも 北の 門とも ちがう 向き）。町の 中の 道・噴水から はなれた 平らな 所 */
let FESTQ = null;
export const r0Field = () => FIELD();
const FIELD = () => {   /* ルミナから 58マス。ほかの 町・城・牧場・北の 門から いちばん はなれた 向き（地方の 中）*/
  if (FESTQ) return FESTQ;
  const c = lumina(); if (!c) return null;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  const avoid = []; for (const t of TOWNS) if (t.id !== "t0") { const q = townPos(t); avoid.push([q.x, q.z, 44]); }
  for (let i = 0; i < 11; i++) { const k = castleSpot(i); if (k) avoid.push([k.x, k.z, 72]); }
  { const r = ranchSpot(); if (r) avoid.push([r.x, r.z, 16]); } avoid.push([c.x, c.z - 52, 16]);
  let best = null;
  for (let a = 0; a < 16; a++) { const t = (a / 16) * Math.PI * 2, x = Math.floor(c.x + Math.cos(t) * 58), z = Math.floor(c.z + Math.sin(t) * 58); if (regionIdx(x - s0.x, z - s0.z) !== 0) continue; let m = 1e9; for (const [X, Z, R] of avoid) m = Math.min(m, Math.hypot(X - x, Z - z) - R); if (!best || m > best.m) best = { x, z, m }; }
  if (!best) { const o = townOut("t0", -0.9, "祭りの 原っぱ"); best = o ? { x: o.x, z: o.z } : null; }
  FESTQ = best ? { x: best.x, z: best.z, nm: "ルミナの 外れの 麦畑" } : null; return FESTQ;
};
/* 第126版(PV): 収穫祭は ルミナの 広場（屋台・灯り・旗・町の 人）。麦畑は 町の 外れ（畑を 荒らす 群れとの 戦い）。祭りに 来た 敵とは 北の 門の 外で 戦う */
const FEST = () => { const q = plazaOf("t0", "ルミナの 広場（収穫祭）"); return q ? { x: q.x, z: q.z, nm: q.nm } : FIELD(); };
const NGATE = () => gateOut("t0", -Math.PI / 2, "ルミナの 北の 門の 外", 54);
const FCTR = () => { const q = FEST(); return q ? { x: q.x + 0.5, z: q.z + 0.5 } : null; };
/* 門の 外へ 出て 戦う（暗転 → 門の 外 → 戦い）。戻る ときは backFest */
async function outGate(K, p, drop = [], nm = "ルミナの 北の 門の 外") { const q = NGATE(); if (!q) return false; gateSet(p, "t0n", q, { x: q.fx, z: q.fz }, Y(K, p)); return moveG(K, p, q, nm, drop.filter(ok), { x: q.fx, y: Y(K, p) + 2, z: q.fz }); }
async function backFest(K, p, drop = [], nm = "ルミナの 広場（収穫祭）") { const q = FEST(); if (!q) return false; return moveG(K, p, q, nm, drop.filter(ok)); }
const COURT = () => { const q = placeOf("court", 0); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm || "アルカトラス城の 中庭" } : null; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("gonza", { nm: "ゴンザ", role: "門番", gobi: "ござる", skin: "m6_takeru", town: "t0", from: "r0e3",
  at: () => { const c = lumina(); return c ? { x: c.x + 3, y: c.y, z: c.z - 29 } : null; },
  pre: ["{closed}北の 門は 拙者が 守って おるでござる。"],
  after: [
    [(s) => !!s.ending, ["{smile}空が 晴れたでござる。……門を くぐる 者の 顔が、みな 明るいでござる。"]],
    [(s) => !!s.heroDead, ["{sad}……門を くぐる 者が、一人 減ったでござる。", "{closed}それでも 拙者は、門を 開けて 待つでござる。いつでも 帰って くるでござるよ。"]],
    [(s) => !!st(s).fest0, ["{smile}傷は 町を 守った 印でござる。", "{smile,♪}いって らっしゃいでござる！ 門は いつでも 開けて 待って おるでござる。"]],
    [(s) => !!st(s).gonzaHurt, ["{sweat,汗}かすり傷でござる。……少し、しみるでござるが。", "{angry}拙者が 立たねば、門が さびしがるでござる。"]],
    [() => true, ["{smile}祭りの 夜は 助かったでござる。ミミ殿の 屋台も 無事でござる。"]],
  ] });
castAdd("mimi", { nm: "ミミ", role: "パン屋の", gobi: "だよっ", skin: "mimi", town: "t0", from: "r0e2",
  at: () => { const q = spotOf("t0", "diner") || spotOf("t0", "cafe"); if (q) return { x: q.x + 1.5, y: q.y, z: q.z - 2 }; const c = lumina(); return c ? { x: c.x + 8, y: c.y, z: c.z + 19 } : null; },
  pre: ["{smile}いらっしゃいませだよっ！"],
  after: [
    [(s) => !!s.ending, ["{smile,☆}町に 人が もどって きたよっ！ 今年の 収穫祭は、いちばん 大きく するんだよっ！"]],
    [(s) => !!(s.heroDead && s.epx && s.epx.lchase && s.epx.mimiDad), ["{smile}お父さんと いっしょに、毎朝 パンを 配ってるよっ。", "{smile,up}……帰って きたら、いちばん 焼きたてを とって おくんだよっ。"]],
    [(s) => !!(s.heroDead && s.epx && s.epx.lchase), ["{sad}お父さん、まだ 石の まま なんだよっ……。", "{angry,up}インク、見つけたら お父さんの 名前、書いて ほしいんだよっ！"]],
    [(s) => !!s.heroDead, ["{sad}……麦パン、毎朝 焼いてるよっ。", "{cry}いつ 帰って きても いい ように。……あたし、待ってるんだよっ。"]],
    [(s) => !!st(s).fest0, ["{smile,♪}やり直しの お祭り、ほんとに うれしかったよっ！", "{smile}町の みんなが お店を 増やしたんだよっ。また パンを 食べに 来てねっ！"]],
    [(s) => !!st(s).gonzaHurt, ["{sad}ゴンザさん、まだ 足を 引きずってるんだよっ……。", "{angry}でも、お祭りは あきらめないよっ！ 約束、だよっ！"]],
    [() => true, ["{smile,☆}収穫祭、ぜったい 来てねっ！ 焼きたての 麦パン、とって おくんだよっ！"]],
  ] });
castAdd("nol", { nm: "ノルじい", role: "牧場の", gobi: "じゃよ", skin: "m6_gramps", town: "t0", from: "r0e2",
  at: () => { const q = ranchSpot(); return q ? { x: q.x + 5, y: q.y ?? undefined, z: q.z + 4 } : null; },
  pre: ["{smile}ほっほ、牧場の 干し草は よう 乾いて おるんじゃよ。"],
  after: [
    [(s) => !!s.final, ["{closed}……そうか。あの 男は、そういう 道を 選んだんじゃな。", "{sad}紐の お守りは、できあがったんじゃろうか。……できて いると、ええんじゃよ。"]],
    [(s) => !!st(s).fest0, ["{smile}あの 二人も 昔、ここで 送り出されたんじゃよ。", "{closed}……今度は、みんな 帰って くるんじゃよ。約束じゃよ。"]],
    [() => true, ["{closed}オルドの 昔話は、ないしょじゃよ。……あやつ、照れると 怒るんじゃよ。"]],
  ] });
castAdd("arca", { nm: "アルカ十三世", role: "王", col: "§6", gobi: "", skin: "arca13" });
castAdd("midori", { nm: "ミドリ", role: "地方マスター", col: "§6", gobi: "", skin: "midori" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d), S = null; return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : S; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const ORDO = (K, p, w = false) => K.npcNear(p, "§eオルド", K.PJ("ordo", 8), w);
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };

/* ---------- 2話 収穫祭の 前 ---------- */
const E2 = { id: "r0e2", n: 2, t: "収穫祭の 前", at: 1, ord: 0, place: FEST,
  hint: "§fルミナの §e広場§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まると、パン屋の §eミミ§7 が 待って いる）",
  syn: "収穫祭の 二日前。パン屋の ミミと 祭りの 飾りを 集め、畑を 荒らす 野生の 群れを 追いはらった。牧場の ノルじいは「オルドは 昔、いつも もう 一人と 一緒だった」と 話した。その 男は 娘の ために 紐の お守りを 編みつづけ、ある 冬、二人で 旅に 出て……帰って きたのは オルド 一人だった。",
  set: { met0: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    await K.open(p, "ルミナの 広場（収穫祭の 支度）", "day");
    let eM = K.cast(p, "mimi"), eH = K.hero(p);
    K.act(eM, "raise"); K.hold(eM, "basket");
    if (ok(eM)) await K.walkCam(p, eM, K.fwd(p, 3, 1.4), 16);   /* 第125版(rs): かごを 振って かけて くる */
    await K.csay(p, "mimi", ["{!,jump}あーっ、いた いた！ 石板に えらばれた 人だよねっ？", "{smile,☆}町じゅう その うわさで もちきりだよっ！"]);
    await K.hsay(p, K.V(["{smile,♪,up}ミミちゃん！ ……って、うわさ 早すぎない！？"], ["{smile}あら、ミミちゃん。……もう 町じゅうに 広まってるの？"], ["{sweat,汗}……ミミ。うわさ、早すぎ。"], ["{smile}ミミさん、こんにちは。……もう 広まって いるんですね。"]));
    K.act(eM, 0);
    await K.csay(p, "mimi", ["{smile}あさっては 収穫祭なんだよっ。あたし、今年は 実行係なんだよっ！"], eH);
    await K.csay(p, "mimi", ["{sad,…,up}でもね……飾りが ぜんぜん 足りないの。それに、畑の 麦が 毎晩 食べられちゃうんだよっ。"], eH);
    K.turn(eM);
    let eN = K.cast(p, "nol");
    K.act(eN, "hold");
    await K.ots(p, eH, eN, 10);   /* 干し草の じじいが 歩いて 来る */
    await K.csay(p, "nol", ["{smile}ほっほ。ミミ、そう 大声を 出すと 麦が おびえるんじゃよ。", "{closed}わしは ノル。……と、名乗るまでも ないか。干し草の じじいじゃよ。"], eH);
    await K.hsay(p, K.V(["{smile,♪}ノルじい！ 腰は もう いいの？"], ["{smile}ノルじい。腰は もう いいの？"], ["{closed}ノルじい。腰は。"], ["{smile}ノルじいさま！ お腰は もう よろしいのですか？"]));
    await K.csay(p, "nol", ["{smile,nod}この とおりじゃよ。……ほれ、外れの 畑の ほうが 騒がしい。来おったわい。"]);
    K.act(eN, 0);
    /* 第126版(PV): 畑を 荒らす 野生 → 町の 外れの 麦畑へ（戦いは 町の 外）*/
    const FQ = FIELD(); if (FQ) { await moveG(K, p, FQ, "ルミナの 外れの 麦畑", [eN].filter(ok)); K.deco(p, "t0field", 0, { x: FQ.x + 0.5 - 14, z: FQ.z + 0.5 }, Y(K, p)); }
    if (FQ) { const e1 = K.cast(p, "mimi"); if (ok(e1)) eM = e1; const e3 = K.hero(p); if (ok(e3)) eH = e3; }
    const fc = FQ ? { x: FQ.x + 0.5 - 14, z: FQ.z + 0.5 } : c, fy = Y(K, p);
    const fld = { x: fc.x + 14, y: fy, z: fc.z };
    const w1 = K.monEnt(p, { x: fld.x - 1, y: fy, z: fld.z - 1 }, K.wildSp("animal"), ""), w2 = K.monEnt(p, { x: fld.x + 1, y: fy, z: fld.z + 1 }, K.wildSp("beast"), "");
    K.sound(p, "mob.wolf.growl", 0.8); K.burst(p.dimension, fld, "minecraft:white_smoke_particle", 8, 1.4, 0.3);
    await K.at(p, fld, 18, 5, 1);
    await K.csay(p, "mimi", ["{shock,!,up}あーっ！ また 来たんだよっ！ 麦がーっ！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,怒,up}もう！ お祭りの 麦なんだから！ 追いはらうよ！"], ["{angry,up}……ごめんね。でも その 麦は、みんなの お祭りの ぶんなの。"], ["{angry,up}……追いはらう。手加減は する。"], ["{angry,up}お祭りの 麦です！ 追いはらいましょう！"]));
    if (!K.flag(p, "r0e2w")) {
      K.rmCine(w1); K.rmCine(w2);
      const r = await K.battle(p, K.team(["animal", "beast"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "畑を 荒らす 野生の 群れ", arena: "収穫祭の 前", easy: true, speaker: "野生の モンスター", lines: { half: "……ガウ……", low: "……キュウ……" } });
      if (r !== "win") return lose(K, p, "§eパン屋の ミミ", K.PJ("mimi", 9), "ミミ", "{sad}だ、だいじょうぶ？ ……麦より、あなたの ほうが 大事なんだよっ。");
      K.setFlag(p, "r0e2w");
    } else { K.rmCine(w1); K.rmCine(w2); }
    K.burst(p.dimension, fld, "minecraft:villager_happy", 8, 1.2, 0.6);
    await K.csay(p, "mimi", ["{smile,☆,jump}やったー！ 逃げてったよっ！", "{smile,up}ありがとうだよっ！ ……ねえ、ついでに 飾りあつめも 手伝って くれる？"]);
    await K.hsay(p, K.V(["{smile,♪,nod}もちろん！"], ["{smile,nod}ええ、もちろん。"], ["{closed,nod}……いいよ。"], ["{smile,nod}はい、喜んで！"]));
    /* 時が 流れる: 広場へ もどって 飾りが そろう */
    if (FQ) await backFest(K, p, [eM]);
    festSet(p, "t0", c, y0); const cw = crowd(K, p, 3);
    { const e1 = K.cast(p, "mimi"); if (ok(e1)) eM = e1; const e2 = K.cast(p, "nol"); if (ok(e2)) eN = e2; const e3 = K.hero(p); if (ok(e3)) eH = e3; }
    K.hold(eM, "chochin"); K.hold(eH, "bouquet");
    if (ok(eM)) K.go(eM, { x: c.x - 9, y: y0, z: c.z - 1.5 }, 30); if (ok(eH)) K.go(eH, { x: c.x - 9, y: y0, z: c.z + 1.5 }, 30);   /* 灯りを 運んで 屋台へ */
    await K.narr(p, ["§7あなたたちは 半日 かけて、麦わらと 花と 灯りを 集めて 回った。", "§7やがて 日が かたむき、広場に 屋台の 骨組みが 並んだ。"], { x: c.x - 11, y: y0, z: c.z });
    K.act(eM, "work"); await K.at(p, { x: c.x - 12, y: y0 + 2, z: c.z }, 14, 4, 1); K.act(eM, 0);   /* 屋台の 柱に 灯りを つるす */
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z });
    /* ノルじいの 昔話（オルドと、もう 一人の 若者）*/
    K.act(eN, "hold");
    await K.hsay(p, K.V(["{?}ねえ ノルじい。村長って、昔から ああなの？", "{sweat,汗}なんでも『昔、ちょっとな』で ごまかすんだもん。"], ["{?}ノルじい。村長さんって、昔から 口数が 少ないの？"], ["{?}ノルじい。村長の『昔、ちょっと』って、何？"], ["{?}ノルじいさま。村長さまの『昔、ちょっと』とは……？"]));
    if (ok(eN)) { await K.go(eN, { x: c.x - 7, y: y0, z: c.z + 3.2 }, 18); K.act(eN, "kneel"); }   /* 第125版(rs2): ノルじいも 屋台へ 来て、干し草に 腰を おろす */
    await K.csay(p, "nol", ["{closed,息}ほっほ……オルドか。あれは 昔は、よう しゃべる 男じゃったよ。", "{smile}いつも もう 一人と 一緒でな。背の 高い、星を 見るのが 好きな 若者じゃったよ。"], eH);
    await K.memory(p, eN, "§7― 四十年 ほど 前 ―", ["§7若い オルドと、もう 一人の 若者が、この 原っぱで 星を 数えて いた。", "§7二人は どこへ 行くにも、いつも 一緒だった。"]);
    await K.at(p, { x: c.x, y: y0 + 6, z: c.z }, 10, 6, 4);
    await K.memory(p, eN, "§7― 二十年 ほど 前の 冬 ―", ["§7男の 手には、編みかけの 紐が あった。", "§7「うまく 編めたら、生まれた ばかりの 娘に やるんだ」と、男は 笑って いた。"]);
    await K.narr(p, ["§7ほどいては 編み、ほどいては 編み……紐は いつまでも、できあがらなかった。"], eN);
    K.act(eN, 0); if (ok(eN)) K.turn(eN, { x: c.x, y: y0 + 6, z: c.z - 30 });   /* 立ちあがり、遠くの 空を 見る */
    await K.csay(p, "nol", ["{sad,…,up}その 冬、二人は もう 一度 旅に 出た。……帰って きたのは、オルド 一人じゃったよ。"]);
    K.turn(eN);
    await K.hsay(p, K.V(["{shock,!,up}え……！ じゃあ、その 人は……？"], ["{sad,up}……その 方は、どう なったの？"], ["{shock,…,up}……もう 一人は？"], ["{shock,!,up}そ、その 方は……？"]));
    await K.csay(p, "nol", ["{closed,no}わからん。オルドは あれから、あの 男の 名を 一度も 口に せんのじゃよ。", "{sad}わしが 聞いても、遠くの 空を 見るだけじゃよ。"], eH);
    await K.approach(p, eN, eH, 1.9); await K.push(p, eN, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "nol", ["{smile,up}……おまえさんが 旅に 出ると 聞いて、あの 二人を 思い出して しもうたんじゃよ。", "{closed}年寄りの 昔話じゃ。……忘れんで、おいて くれるかの。"]);
    K.act(eN, 0);
    /* 第125版: 八年前の 収穫祭（道化の 一座と、袖の 女の子）*/
    K.act(eM, "hold");
    await K.push(p, eM, 22, 4.2, 1.7);
    await K.csay(p, "mimi", ["{smile,…,up}……屋台の 骨組みを 見ると、思い出すんだよっ。八年前の 収穫祭に、道化の 一座が 来たんだよっ。", "{smile}舞台の 袖に、あたしと 同じ くらいの 女の子が いてね。台本を 抱えて、ずっと 舞台を 見てたんだよっ。"]);
    await K.past(p, "§7―― 八年前　収穫祭の 舞台の 袖"); await K.at(p, { x: c.x - 12, y: y0 + 1, z: c.z }, 16, 5, 1.2);   /* 第125版(rs2): 昔の 話は 回想の 札 → 屋台の 骨組み */
    await K.csay(p, "mimi", ["{smile,♪}パンを 半分こ して、友だちに なろうねって 約束したの。", "{sad,up}……でも 一座は 次の 年から 来なく なっちゃった。"], eH);
    await K.csay(p, "mimi", ["{sad,up}名前、教えて もらったのに……思い出せないんだよっ。"]);
    await K.hsay(p, K.V(["{sad}……思い出したら、いちばんに 教えてね。"], ["{sad}……思い出せたら、わたしにも 教えてね。"], ["{closed}……思い出したら 言って。"], ["{sad}……思い出されたら、教えて くださいね。"]));
    await K.csay(p, "mimi", ["{smile,…}うん。……名前は 出て こないのに、半分この パンの 味は 覚えてるんだよっ。", "{smile,up}あの子、耳の 先まで 真っ赤に して『おいしい』って 言ったの。"], eH);
    K.act(eM, 0);
    await K.csay(p, "mimi", ["{smile,♪,jump}飾り、ぜーんぶ そろったよっ！ あさっての 夜、ぜったい 来てねっ！"]);
    await K.hsay(p, K.V(["{smile,☆,up}うん、約束！"], ["{smile,up}ええ、約束ね。"], ["{smile,up}……約束。"], ["{smile,up}はい、約束です。"]));
    await K.csay(p, "nol", ["{closed,low}……祭りの 夜は、昔から 影が 騒ぐ。気を つけるんじゃよ。"]);
    K.pay(p, E2, 200, [["gift_bread", 2]]);
    await K.end(p, { leave: [eM, eN, ...cw], card: "§7― 収穫祭まで、あと 二日 ―", kind: "fest" });
    return true;
  } };

/* ---------- 3話 祭りの 夜（屋台 → ガロは 北の 門の 外へ。決着は 今の 段「北の 門」）---------- */
const E3 = { id: "r0e3", n: 3, t: "祭りの 夜", at: 1, ord: 1, place: FEST,
  hint: "§fルミナの §e広場§f で §6収穫祭§f が 始まる §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "収穫祭の 夜、六影を 名乗る 下っぱの ガロが ミミの 屋台を おどした。門番の ゴンザが 立ちはだかり、オルドは「その 名の 重さを 知って 名乗って おるのか」と ガロを にらんだ。手下を 退けると、ガロは 毎年 パンを もらいに 来る 小さな モンスターを さらって、北の 門の 外へ 逃げた。",
  set: { garoFest: 1, met0: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), garoFest: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    festSet(p, "t0", c, y0); const cw = crowd(K, p, 3);
    await K.open(p, "ルミナの 広場（収穫祭の 夜）", "night");
    K.sound(p, "note.harp", 0.7); K.sound(p, "note.bell", 0.5);
    let eH = K.hero(p);
    if (ok(eH)) await K.walkCam(p, eH, { x: c.x - 6, y: y0, z: c.z + 2 }, 22);   /* 第125版(rs): 屋台の あいだを 歩く */
    await K.hsay(p, K.V(["{smile,☆,jump}わあ……！ 屋台が いっぱい！ 灯りが きれい！"], ["{smile,♪}……きれい。毎年 見てるのに、今年は なんだか ちがって 見える。"], ["{smile}……悪くない。灯りの 数、去年より 多い。"], ["{smile,☆}わあ……なんて きれいな 灯りでしょう。"]));
    let eM = K.cast(p, "mimi"); K.act(eM, "raise"); K.hold(eM, "basket");
    await K.csay(p, "mimi", ["{smile,☆,jump}来てくれたーっ！ 収穫祭の 麦パン、焼きたてだよっ！", "{smile}これは あたしからだよっ。飾りあつめの お礼なんだよっ！"]);
    await K.give(eM, eH, "basket"); K.hold(eM, "basket");
    const q0 = K.fwd(p, 3.5, -2.2);
    const kid = K.monEnt(p, q0, baseOf("animal") || K.wildSp("animal"), "§7小さな モンスター");
    if (ok(kid)) { K.burst(p.dimension, kid.location, "minecraft:heart_particle", 4, 0.5, 0.8); await K.push(p, kid, 22, 4.2, 1.7); }
    await K.narr(p, ["§7屋台の かげから、小さな 野生の モンスターが 顔を 出した。"], kid);
    await K.csay(p, "mimi", ["{smile,♥}あ、この子！ 毎年 パンを もらいに 来るんだよっ。", "{smile,♪}はい、今年の ぶんだよっ。……ふふ、しっぽ ふってるよっ。"]);
    K.act(eM, "give", false); await K.wait(8); K.act(eM, 0, false);
    let eG = K.cast(p, "gonza"); K.act(eG, "hold"); K.hold(eG, "spear");
    await K.csay(p, "gonza", ["{closed}祭りの 夜は、拙者が 見回るでござる。", "{smile}ミミ殿の パンは、今年も うまそうでござるな。", "{smile}その 子は、オルド殿の 石板の 蔵の 軒下で 寝て おる 野良でござるよ。", "{closed}毎晩、蔵の 石板の 唸りを 子守唄に して 寝て おるのでござる。"], eH);
    await K.hsay(p, K.V(["{?}ゴンザさん、門は いいの？"], ["{?}ゴンザさん、門は いいの？"], ["{?}ゴンザ、門は。"], ["{?}ゴンザさん、門は よろしいのですか？"]));
    await K.csay(p, "gonza", ["{smile,nod}門には 弟分を 立たせて おるでござる。……祭りの 夜くらい、町の 外も 守るでござるよ。"]);
    K.act(eG, 0);
    /* ガロと 手下が 来る */
    K.sound(p, "mob.villager.no", 1);
    const eGa = K.npcNear(p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9)), eD = K.npcNear(p, "§c六影の 下っぱ ドンゴ", K.PJ("noxa", 9)), eC = K.npcNear(p, "§c六影の 下っぱ チョロ", K.PJ("noxb", 9)), ePi = K.npcNear(p, "§d手下 ピコ", K.PJ("pico", 9));   /* 第124版(合議): ピコは 袋持ち。祭りの 夜に 先に 顔を 出す */
    await K.low(p, eGa, 12);
    if (ok(eGa) && ok(eM)) await K.approach(p, eGa, eM, 1.7);   /* 第125版(rs2): ガロが 屋台の ミミに つめよる */
    await K.say(p, "ガロ", ["{angry,low}おい、パン屋。今夜の 売り上げ、半分 よこしな。"], eM);
    K.act(eM, "recoil"); await K.ots(p, eGa, eM, 8);   /* ガロの 肩ごしに、あとずさる ミミ */
    await K.csay(p, "mimi",["{shock,!,up}え……！？ やだよっ！ これは 町の みんなで 作った お祭りなんだよっ！"]);
    K.act(eD, "point");
    await K.say(p, "ドンゴ", ["{angry}へっへっ。§5六影§f の 名前を 聞いても、まだ 逆らうか？"]);
    await K.say(p, "ガロ", ["{angry}オレたちは §5六影§f だ。逆らえば、屋台ごと ひっくり返す。"]);
    if (ok(eG) && ok(eM)) { const q = eM.location; await K.go(eG, { x: q.x + 1.3, y: q.y, z: q.z + 0.6 }, 10, true); } K.act(eG, "guard");
    await K.csay(p, "gonza", ["{angry,怒,up}待たれよ！ 祭りを 汚す 者は、この ゴンザが 通さぬでござる！"]);
    /* オルドが 歩いて 来る */
    let eO = ORDO(K, p); K.act(eO, "hold");
    if (ok(eO) && ok(eGa)) await K.walkCam(p, eO, nearPt(eO, eGa, 2.4), 18);   /* ガロの 前まで 歩いて 来る */
    await K.low(p, eO, 12);
    await K.say(p, "オルド", ["{angry,low}……小僧。", "{angry,up}おまえさん、その 名の 重さを 知って 名乗って おるのか。"]);
    await K.ots(p, eO, eGa, 10);   /* 村長の 肩ごしに ガロ */
    await K.say(p, "ガロ", ["{sweat,汗}……な、なんだ じじい。名前に 重いも 軽いも あるかよ。"]);
    await K.say(p, "オルド", ["{closed,low}石板を 集める 者が、なぜ 祭りの 売り上げを ほしがる。……おまえさん、上から 何も 聞かされて おらんな。"]);
    await K.say(p, "ガロ", ["{sweat,汗}……上は『石板を 持って こい。石板に なつく モンスターを 見つけろ』しか 言わねえ。飯代は てめえで かせぐしか ねえんだよ！"]);
    await K.hsay(p, K.V(["{shock,…,up}（……村長、牧場でも 同じ 顔 してた。あの 名前を 聞いた ときだけ……）"], ["{sad,…,up}（……村長さん、また あの 顔。あの 名前の ときだけ）"], ["{closed,…,up}（……また だ。あの 名前で、村長の 顔が かわる）"], ["{shock,…,up}（村長さま……あの 名前の ときだけ、あんな お顔を……）"]));
    await K.say(p, "チョロ", ["{sweat,汗}あ、兄貴……あの じいさん、目が こわいっす……。"], eGa);
    await K.say(p, "ガロ", ["{angry,!}う、うるせえ！ ドンゴ、チョロ、やっちまえ！"]);
    /* 第126版(PV): 町の 中では 戦わない。ゴンザが 門の 外へ 追い出す → 北の 門の 外で 戦う */
    await K.csay(p, "gonza", ["{angry,!,up}祭りの 広場で 暴れさせは せぬ！ 表へ 出るでござる！"]);
    await outGate(K, p, [eGa, eD, eC, ePi, eM, eO, eG, kid, ...cw], "ルミナの 北の 門の 外（夜）");
    { const e1 = K.hero(p); if (ok(e1)) eH = e1; const e2 = K.cast(p, "gonza"); if (ok(e2)) { eG = e2; K.act(eG, "guard"); } const e3 = K.cast(p, "mimi"); if (ok(e3)) eM = e3; const e4 = ORDO(K, p); if (ok(e4)) eO = e4; }
    for (const [nm, j] of [["§c六影の 下っぱ ガロ", "garo"], ["§c六影の 下っぱ ドンゴ", "noxa"], ["§c六影の 下っぱ チョロ", "noxb"], ["§d手下 ピコ", "pico"]]) K.npcNear(p, nm, K.PJ(j, 9));   /* 門の 外へ 歩いて 出て くる */
    await K.wide(p, 16);
    if (!K.flag(p, "r0e3w")) {
      const r = await K.battle(p, K.team(["beast", "animal"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "ガロの 手下 ドンゴと チョロ", arena: "祭りの 夜", easy: true, speaker: "ドンゴ", lines: { half: "ひいっ、この ガキ つええ……！", low: "あ、兄貴ぃーっ！" } });
      if (r !== "win") return lose(K, p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9), "ガロ", "……へっ。祭りの 売り上げは もらって いくぜ。");
      K.setFlag(p, "r0e3w");
    }
    const eD2 = K.npcNear(p, "§c六影の 下っぱ ドンゴ", K.PJ("noxa", 9), true), eC2 = K.npcNear(p, "§c六影の 下っぱ チョロ", K.PJ("noxb", 9), true); K.act(eD2, "down"); K.act(eC2, "kneel");
    const eGa2 = K.npcNear(p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9), true);
    await K.say(p, "ガロ", ["{angry}……ちっ。覚えて おけ。"]);
    if (ok(kid)) K.rmCine(kid); const kid2 = K.monEnt(p, K.fwd(p, 3.5, -2.2), baseOf("animal") || K.wildSp("animal"), "§7小さな モンスター");
    if (ok(eGa2) && ok(kid2)) { const q = kid2.location; await K.go(eGa2, { x: q.x + 0.9, y: q.y, z: q.z }, 8, true); K.act(eGa2, "hold"); }
    await K.push(p, eGa2, 22, 4.2, 1.7);
    await K.say(p, "ガロ", ["{!,low}……この チビ、石板の 蔵の 軒下に いた やつだな。石板の 匂いが する。", "{!,low}……石板に なつく やつか。手ぶらじゃ 帰れねえ。もらって いくぜ！"]);   /* 第124版(合議 B-1): 倒れた チョロは 話さない（その場に わいた ように 見えない）*/
    const ePi2 = K.npcNear(p, "§d手下 ピコ", K.PJ("pico", 9), true);
    await K.say(p, "ピコ", ["{sweat,汗}に、兄ちゃん……その 子、ないてるよ……。"]);
    await K.say(p, "ガロ", ["{angry}うるせえ、ピコ！ 袋を 開けろ！"]);
    K.sound(p, "mob.wolf.whine", 1.1);
    if (ok(eM) && ok(kid2)) { const q = nearPt(eM, kid2, 1.5); if (q) await K.go(eM, q, 8, true); K.act(eM, "point"); }
    if (ok(kid2) && kid2.typeId !== "mrpg:npc") anim(kid2, "guard");
    await K.csay(p, "mimi", ["{cry,tears,up}あの子が……！ 毎年 パンを 食べに 来る 子なんだよっ！ 返してよっ！"]);
    const run = [K.leave(eGa2, p, 12, true), K.leave(eD2, p, 12, true), K.leave(eC2, p, 12, true), K.leave(ePi2, p, 12, true)];
    if (ok(kid2)) run.push((async () => { const q = K.away(kid2, p, 10); if (q) await K.go(kid2, q, 12, true); K.rmCine(kid2); })());
    await K.pull(p, K.S(p) && K.S(p).Cn, 34); await Promise.all(run);
    await K.csay(p, "gonza", ["{angry,!,up}手下の 二人は 南へ 逃げたでござる。ガロと、袋を 持った 小さいのは 北の 道の 先でござる！"]);
    await K.say(p, "オルド", ["{closed}……追うんじゃ。じゃが 深追いは するな。", "{sad,low}門の 外は 今夜、嫌な 風が 吹いて おる。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}行こう！ あの子を 取り返す！"], ["{angry,up}……行きましょう。あの子、こわがってた。"], ["{angry,up}……行く。返して もらう。"], ["{angry,up}追いかけましょう！ あの子を 取り返します！"]));
    K.pay(p, E3, 200, [["mei_arca", 1]]);
    await K.end(p, { leave: [eM, eG, eO], card: "§7→ 北の 門の 外の 道へ、ガロを 追おう（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 4話 影が 来る（北の 門の 外の 影が 祭りへ）---------- */
const E4 = { id: "r0e4", n: 4, t: "影が 来る", snd: "item.book.page_turn", at: 2, ord: 0, place: FEST,
  hint: "§f影が ルミナの 方へ 流れた！ §eルミナの 広場§f へ もどろう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "北の 門の 外から 流れた 影の 残りが、収穫祭を おそった。灯りが 倒れ、門番の ゴンザは ミミを かばって けがを した。オルドは「……二十年前と 同じ 影じゃ」と つぶやいた。祭りは 中止に なり、あなたは ミミと「帰って きたら、もう一度 祭りを しよう」と 約束して、旅に 出る 覚悟を 決めた。",
  set: { gonzaHurt: 1, met0: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), gonzaHurt: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), met = !!(qs(load(p) || d).epx || {}).met0;
    festSet(p, "t0", c, y0);
    await K.open(p, "ルミナの 広場（収穫祭）", "ash");
    K.sound(p, "mob.villager.no", 1); K.shake(p, 0.25, 0.5);
    const eH = K.hero(p), eS = THEO(K, p);
    await K.at(p, { x: c.x - 10, y: y0 + 1, z: c.z - 7 }, 14, 3.5, 0.6);   /* 第125版(rs2): 倒れた 灯りの 柱の 寄り */
    await K.hsay(p, K.V(["{shock,!,up}お祭りが……！ 灯りが 倒れてる！"], ["{shock,…,up}……そんな。お祭りが……"], ["{shock,!,up}……祭りが、やられてる。"], ["{shock,!,up}お、お祭りが……！"]));
    await K.say(p, "セオ", ["{sweat,汗}影の 残りが、人の 多い 方へ 流れたんだ……！ まだ 近くに いる！"]);
    const eM = K.cast(p, "mimi"), eG = K.cast(p, "gonza");
    K.act(eM, "kneel"); K.act(eG, "guard");
    if (ok(eG) && ok(eM)) await K.go(eG, nearPt(eG, eM, 1.3) || eM.location, 10, true);   /* 第125版(rs): ミミの 前へ 走って かばう */
    if (!met) await K.csay(p, "mimi", ["{cry,tears,up}た、助けて……！ 影が、屋台を……！"]);
    await K.ots(p, eM, eG, 8);   /* 第125版(rs2): ミミの 肩ごしに、立ちはだかる ゴンザ */
    await K.csay(p, "gonza", ["{angry,!,up}ミミ殿、拙者の 後ろへ！ ……門番 ゴンザ、ここは 通さぬでござる！"]);
    /* 影が ミミへ。ゴンザが かばう */
    const far = K.fwd(p, 12, 3), mq = ok(eM) ? eM.location : K.fwd(p, 3);
    await K.at(p, far, 8, 5, 1);
    await K.shadowFlow(p, far, mq, 22);
    K.boom(p.dimension, mq); K.sound(p, "random.explode", 0.8); K.shake(p, 0.7, 0.6); K.flash(p, false);
    if (ok(eG)) await knockSafe(K, p, eG, far, 2.5);   /* 第126版(PV): あなたや ミミの 上に 落ちない */
    if (ok(eM) && ok(eG)) await K.approach(p, eM, eG, 1.6); await K.push(p, eG, 24, 4.5, 1.7);   /* ミミが 駆けよる */   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "mimi", ["{cry,tears,up}ゴンザさん！！"]);
    await K.csay(p, "gonza", ["{sad,up}……かすり傷でござる……。ミミ殿、さがって おれ……"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{rage,怒,up}……ゆるさない！ みんなの お祭りを！！"], ["{angry,tears,up}……もう、だれも 傷つけさせない！"], ["{rage,怒,up}……許さない。"], ["{rage,怒,up}ゆるしません……！ みんなの お祭りを！"]));
    /* 第126版(PV): 影の かけらは 北の 門の 外へ 流れる → 門の 外で 戦う（広場では 戦わない）→ 広場へ もどる */
    await K.narr(p, ["§7影の かけらは 灯りを 一つ 呑みこむと、北の 門の ほうへ すべって いった。"], far);
    const wentOut = !K.flag(p, "r0e4w") && (await outGate(K, p, [], "ルミナの 北の 門の 外（影を 追う）"));
    if (wentOut) { const e1 = K.hero(p); if (ok(e1)) K.act(e1, "guard"); await K.wide(p, 14); }
    if (!K.flag(p, "r0e4w")) {
      await K.duel(p, "§4影の かけら", "§c影の かけらが 灯りを 呑みこむ！");
      const r = await K.battle(p, K.bossOne(["nether"], 4, 12), { name: "影の かけら", arena: "影が 来る", theme: "underworld", hpk: 2.5, speaker: "影の かけら", lines: { half: "………………", low: "……マツリ……キエ……ル……" } });
      if (r !== "win") return lose(K, p, "§7学者 セオ", 18, "セオ", "{sweat,汗}い、いったん 下がって！ 影は まだ 消えて いない……！");
      K.setFlag(p, "r0e4w");
    }
    if (wentOut) await backFest(K, p, [], "ルミナの 広場（収穫祭の あと）");
    const eG2 = K.cast(p, "gonza", true); K.act(eG2, "kneel");
    const eM2 = K.cast(p, "mimi", true);
    K.burst(p.dimension, ok(eG2) ? eG2.location : c, "minecraft:white_smoke_particle", 10, 1.6, 0.4);
    await K.narr(p, ["§7影は ほどけて 夜空へ 消えた。", "§7倒れた 灯りの 煙だけが、広場に 残った。"], eG2);
    const eO = ORDO(K, p); K.act(eO, "kneel");
    if (ok(eO) && ok(eG2)) { const q = eG2.location; await K.go(eO, { x: q.x - 1.2, y: q.y, z: q.z + 0.4 }, 10); }
    await K.say(p, "オルド", ["{closed}……骨は 折れて おらん。じゃが、しばらくは 門に 立てんぞ。"]);
    K.act(eG2, "up");
    await K.csay(p, "gonza", ["{angry,stagger,up}拙者が 立たねば、だれが 門を 守るでござるか……！"]);
    K.act(eO, 0); if (ok(eO)) K.turn(eO, K.fwd(p, 20, 0, 4));   /* 第125版(rs2): 北の 門の 空へ 背を 向ける */
    await K.push(p, eO, 22, 4.2, 1.7);
    await K.say(p, "オルド", ["{sad,low}…………二十年前と、同じ 影じゃ。"]);
    await K.hsay(p, K.V(["{?,up}村長……？ 二十年前って……"], ["{?,up}村長さん……？ 二十年前って……"], ["{?,up}……村長。二十年前？"], ["{?,up}村長さま……？ 二十年前とは……"]));
    await K.say(p, "オルド", ["{closed,no}……いや。なんでも ない。"]); K.turn(eO);
    await K.hsay(p, K.V(["{angry,up}なんでも なく ないでしょ！ 村長、さっきから 顔が まっ青だよ。"], ["{sad,up}……村長さん。なんでも ない 顔じゃ ないわ。"], ["{closed,up}……なんでも ない 顔じゃ ない。"], ["{sad,up}村長さま……なんでも ない お顔では ありません。"]), eO);
    K.re(eO, "closed", "…");
    await K.say(p, "オルド", ["{closed}……昔、ちょっとな。", "{sad,low}……今は、ゴンザの 手当てが 先じゃ。話は、また いつか。"], eH);
    K.act(eM2, "kneel"); K.hold(eM2, "chochin"); await K.push(p, eM2, 20, 4, 1.2);   /* 第125版(rs2): 折れた 提灯を 拾って ひざを つく */
    await K.csay(p, "mimi", ["{cry,tears,up}お祭り……なくなっちゃったよっ……。", "{cry,up}みんなで 飾り、集めたのに……。"]);
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:heart_particle", 4, 0.4, 0.9); await K.up(p, g, 12); }
    await K.hsay(p, K.V(["{angry,!,up}……決めた。わたしたち、石板を 集める。", "{smile,tears,up}ミミちゃん、約束する。帰って きたら、もう一度 お祭りを しよう！"], ["{closed,up}……決めたわ。石板を 集めて、影を 止める。", "{smile,tears,up}ミミちゃん。帰って きたら、もう一度 お祭りを しましょう。約束よ。"], ["{angry,up}……決めた。影を 止める。石板を 集める。", "{smile,up}ミミ。帰ったら、祭りの やり直し。……約束。"], ["{angry,up}……決めました。石板を 集めて、影を 止めます。", "{smile,tears,up}ミミさん。帰って きたら、もう一度 お祭りを しましょう。約束です。"]));
    K.act(eM2, 0);
    await K.csay(p, "mimi", ["{cry,smile,up}……うん。約束、だよっ。"]);
    K.rmCine(g);
    K.hold(eM2); if (ok(eS)) { await K.go(eS, { x: c.x - 9, y: y0, z: c.z - 6 }, 14); K.turn(eS, { x: c.x - 10, y: y0, z: c.z - 7 }); }   /* 第125版(rs2): 倒れた 灯りの 柱へ 歩いて */
    K.hold(eS, "notebook"); K.act(eS, "work"); await K.push(p, eS, 22, 4, 1.6);   /* 倒れた 灯りの 前で 手帳に 書く */
    await K.say(p, "セオ", ["{closed}……今夜の ことは、全部 書き留めて おきます。"]);
    K.act(eS, 0); K.turn(eS);
    await K.hsay(p, K.V(["{?}セオさん？"], ["{?}セオさん？"], ["{?}……セオ？"], ["{?}セオさん……？"]));
    await K.say(p, "セオ", ["{smile,汗}あ、いえ。学者の くせです。", "{closed}……城へ 急ぎましょう。王に 伝えなければ。"], eH);
    await K.csay(p, "gonza", ["{smile,up}拙者は ここで 町を 守るでござる。……必ず、帰って くるでござるよ。"]);
    K.pay(p, E4, 300, [["c_herbs", 2]]);
    await K.end(p, { leave: [eO, eM2], bye: [eG2, eS], card: "§7→ アルカトラス城の 中庭へ（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 5話 城へ（王と 地方マスター ミドリ。勝負は 中庭の ミドリに 話しかける）---------- */
const E5 = { id: "r0e5", n: 5, t: "城へ", at: 2, ord: 1, place: COURT,
  hint: "§f§6アルカトラス城の 中庭§f へ 行こう §7（右上の 案内。王に 祭りの ことを 知らせる。「！」の 目印の そばで 立ち止まろう）",
  syn: "アルカトラス城の 中庭で、王 アルカ十三世に 祭りの ことを 知らせた。王は「父の 代に、地下の 封印庫を 開けて 調べさせて くれと 言うた 男が いた。父は 追い返した」と 話した。地方マスター ミドリは「悔しいなら、その 気持ちを 仲間に 預けて」と 勝負を 受けた。",
  set: { met0: 1 },
  async run(p, d, K) {
    await K.open(p, "アルカトラス城の 中庭", "castle");
    K.sound(p, "note.bell", 0.6);
    const eH = K.hero(p), eS = THEO(K, p);
    const eK = K.cast(p, "arca"); K.act(eK, "hold"); K.hold(eK, "staff"); K.hold(eS, "notebook");
    await K.low(p, eK, 14);
    await K.csay(p, "arca", ["{closed}……セオから 聞いた。ルミナの 祭りが、影に おそわれたと。", "{sad,up}民の 祭りを 守れなかった。王として、恥ずかしい かぎりだ。"]);
    await K.hsay(p, K.V(["{angry,!,up}王さまの せいじゃ ないよ！ 悪いのは あの 影だよ！"], ["{sad,up}……王さまの せいじゃ ないわ。"], ["{closed,up}……王の せいじゃ ない。"], ["{shock,!,up}へ、陛下の せいでは ありません！"]));
    K.act(eK, 0);
    await K.approach(p, eK, eH, 1.9); await K.push(p, eK, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "arca", ["{closed,low}……わが 父の 代にも、似た ことが あった。", "{sad}ある 男が 城に 来て、『封印が ゆるむ。地下の 封印庫を 調べさせて くれ』と 言うたのだ。"], eH);
    await K.past(p, "§7―― 先代の 王の ころ　アルカトラス城"); await K.wide(p, 16);   /* 第125版(rs2): 父の 代の 話は 回想の 札 → 城の 引き */
    K.act(eK, "point"); if (ok(eK)) K.turn(eK, K.fwd(p, 20, 0, 6));   /* 第125版(rs): 城の 塔を 見上げ、背を 向けて 父の 話 */
    await K.csay(p, "arca", ["{closed}父は 王冠を 狙う 者と 決めつけ、追い返した。", "{sad,up}……今にして 思えば、あの 者は、何を 知って いたのか。"], eH);
    K.act(eK, 0); K.turn(eK);
    if (ok(eS)) K.turn(eS, K.fwd(p, 20, -6, 2));   /* 第125版(rs2): セオは 顔を そむけて 聞く（背中へ ゆっくり 寄る）*/
    await K.push(p, eS, 22, 4.2, 1.7);
    await K.say(p, "セオ", ["{closed,…}…………そう、ですか。"]); K.turn(eS);
    await K.hsay(p, K.V(["{?}セオさん？ 何か 知ってるの？"], ["{?}セオさん、何か ご存じなの？"], ["{?}セオ。心当たりが？"], ["{?}セオさん、何か ご存じなのですか？"]), eS);
    await K.say(p, "セオ", ["{closed}……いえ。書庫には、その ころの 記録が ほとんど 残って いないんです。", "{sad}まるで だれかが、頁ごと 抜いた みたいに。……それが、気に なって。"], eH);
    await K.csay(p, "arca", ["{up}石板は、守り手に 勝った 者にしか 渡らぬ 決まり。……ミドリ。"]);
    const eMi = K.cast(p, "midori"); K.act(eMi, "hold");
    if (ok(eMi) && ok(eK)) await K.walkCam(p, eMi, nearPt(eMi, eK, 1.6), 16);   /* 王の 横へ 歩いて 来て ひざを つく */
    K.act(eMi, "bow"); await K.two(p, eK, eMi, 10); K.act(eMi, "hold");
    await K.csay(p, "midori", ["{smile}はい、陛下。", "{smile}……あなたが ルミナの 子ね。祭りの こと、聞いたわ。"]);
    K.act(eMi, "guard");
    if (ok(eMi) && ok(eH)) await K.go(eMi, nearPt(eMi, eH, 2.2), 12);
    await K.ots(p, eH, eMi, 8);
    await K.csay(p, "midori", ["{angry,up}悔しいなら、その 気持ちを 仲間に 預けて。", "{smile,up}わたしに 勝てたら、一枚目の 石板を 託すわ。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}……うん。勝って、ミミちゃんとの 約束を 守る！"], ["{closed,up}……ええ。ミミちゃんとの 約束、守りたいもの。"], ["{angry,up}……勝つ。約束が ある。"], ["{angry,up}はい。ミミさんとの 約束を 守ります！"]));
    K.act(eMi, 0);
    await K.csay(p, "midori", ["{smile,nod}準備が できたら、中庭の わたしに 話しかけて。……待ってるわ。"]);
    K.pay(p, E5, 200, []);
    await K.end(p, { leave: [eMi, eK], bye: [eS], card: "§7→ 中庭の §6地方マスター ミドリ§7 に 話しかけて 勝負（勝つと 石板）", kind: "castle" });
    return true;
  } };

/* ---------- 5話 城へ（つづき）: やり直しの 収穫祭。町の 発展度が 上がり、祭りが 開かれる ---------- */
const E6 = { id: "r0e6", n: 6, t: "やり直しの 収穫祭", at: 3, ord: 0, place: FEST,
  hint: "§fルミナの §e広場§f で §6やり直しの 収穫祭§f が 開かれる §7（右上の 案内。ミミとの 約束。そのあと シルヴァの 洞くつへ）",
  syn: "一枚目の 石板を 封じて ルミナへ もどると、ミミとの 約束どおり、やり直しの 収穫祭が 開かれた。けがの 治った ゴンザ、ノルじい、オルドが あなたを 送り出した。町の 人たちは「帰る 場所を 守ろう」と 店を 増やし、ルミナは 少し にぎやかに なった。",
  set: { fest0: 1, met0: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest0: 1 }; },
  fx: { xp: ["t0", 160], fest: "t0" },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    festSet(p, "t0", c, y0); const cw = crowd(K, p, 4);
    await K.open(p, "ルミナの 広場（やり直しの 収穫祭）", "fest");
    K.sound(p, "firework.blast", 0.7); K.sound(p, "note.harp", 0.8);
    const eH = K.hero(p), eM = K.cast(p, "mimi");
    K.act(eM, "raise");
    if (ok(eM) && ok(eH)) await K.walkCam(p, eM, nearPt(eM, eH, 1.3), 14);   /* 第125版(rs): かけよって くる */
    await K.csay(p, "mimi", ["{smile,☆,jump,up}来て くれたーっ！ 約束、ちゃんと 守って くれたんだよっ！"]);
    await K.hsay(p, K.V(["{smile,tears,up}ただいま、ミミちゃん！ ……灯り、前より 多いね！"], ["{smile,tears,up}……ただいま。灯りが、前より 増えてる。"], ["{smile,up}……ただいま。約束、守った。"], ["{smile,tears,up}ただいま 帰りました！ 灯りが、前より 増えて いますね。"]));
    await K.csay(p, "mimi", ["{smile,♪}町の みんなが ね、『あの 子たちの 帰る 場所を 守ろう』って……", "{smile,☆,up}前より たくさん お店を 出したんだよっ！"], eH);
    if (ok(eM)) K.go(eM, { x: c.x - 10.5, y: y0, z: c.z + 1.2 }, 18); if (ok(eH)) await K.walkCam(p, eH, { x: c.x - 9.5, y: y0, z: c.z + 2.6 }, 18);   /* 第125版(rs2): ミミに 手を 引かれて 新しい 屋台へ */
    await K.at(p, { x: c.x - 12, y: y0 + 2, z: c.z + 1 }, 14, 4, 0.6);   /* 屋台の 灯りの 寄り */
    const eG = K.cast(p, "gonza"); K.act(eG, "hold"); K.hold(eG, "spear");
    await K.csay(p, "gonza", ["{smile}拙者も この とおり、門に もどれたでござる。", "{closed,up}……傷は 残ったが、これは 町を 守った 印でござる。"]);
    const eN = K.cast(p, "nol");
    await K.csay(p, "nol", ["{smile,♪}ほっほ、にぎやかじゃのう。祭りは こうで なくちゃ いかんのじゃよ。"]);
    if (wl(qs(load(p) || d), "wq0c")) await K.csay(p, "mimi", ["{smile,☆,up}灯籠は ね、リールの ロクさんが 作り直して くれたんだよっ！", "{smile}川ほたる石、あんたたちが 届けて くれたんでしょ？"], eH);   /* 第125版: 世界の 依頼「倒れた 灯籠」を 済ませた 人だけ */
    const eO = ORDO(K, p);
    await K.say(p, "オルド", ["{smile,up}……一枚目の 石板、見事じゃった。"]);
    K.act(eO, "hold");
    await K.approach(p, eO, eH, 1.9); await K.push(p, eO, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    if (ok(eO)) K.turn(eO, { x: c.x, y: y0 + 6, z: c.z - 30 });   /* 遠くの 空へ 背を 向ける */
    await K.say(p, "オルド", ["{closed}わしも 若い ころ、ここで こうして 送り出された ことが ある。"], eN);
    await K.past(p, "§7―― 四十年 ほど 前　祭りの 原っぱ"); await K.at(p, { x: c.x, y: y0 + 4, z: c.z }, 14, 9, 2);   /* 第125版(rs2): 若い ころの 話は 回想の 札 → 原っぱの 引き */
    await K.push(p, eO, 20, 4, 1.6);
    await K.say(p, "オルド", ["{sad,…,up}……そして、帰って きたのは……いや。"], eN);
    K.turn(eO); K.act(eO, 0);
    if (ok(eN)) { K.re(eN, "closed", "…"); await K.ots(p, eO, eN, 10); }   /* 第125版(rs2): オルドの 肩ごしに ノルじい（オルドに 言う）*/
    await K.csay(p, "nol", ["{smile,up}……今度は、みんな 帰って くるんじゃよ。のう、オルド。"]);
    await K.say(p, "オルド", ["{smile,息}……ああ。そうじゃな。"]);
    /* 踊りの 輪 */
    for (const e of [eM, eG, eN, eH]) K.act(e, 9);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z }); K.sound(p, "note.pling", 0.8);
    const g = K.palEnt(p); if (g) K.burst(p.dimension, g.location, "minecraft:note_particle", 5, 0.5, 1);
    await K.pull(p, K.S(p) && K.S(p).Cn, 34);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z });
    for (const e of [eM, eG, eN, eH]) K.act(e, 0);
    K.rmCine(g);
    K.act(eM, "hold"); K.hold(eM, "basket");
    await K.csay(p, "mimi", ["{smile,♥}はい、これ！ 収穫祭の はちみつパンだよっ。旅の おともに するんだよっ！"]);
    const got = K.pay(p, E6, 500, [["mei_arca", 2], ["gift_bread", 3]]);
    await K.give(eM, eH, "basket");
    if (got.length) K.big(p, "§e§lミミの パン", `§e${got.join("・")}`);
    K.act(eM, 0);
    await K.csay(p, "gonza", ["{smile,up}いって らっしゃいでござる！ 門は いつでも、開けて 待って おるでござる！"]);
    await K.hsay(p, K.V(["{smile,tears,up}……いって きます！！"], ["{smile,tears,up}……いって きます。"], ["{smile,up}……いって きます。"], ["{smile,tears,up}……いって まいります！"]));
    await K.end(p, { leave: [eO], bye: [eM, eG, eN, ...cw], card: "§f― 第1章 旅立ち おわり ―\n§7→ 次は シルヴァ大森林の ほたるの 里 ルミエへ（セオの 待つ 洞くつは その 先。右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(0, [E2, E3, E4, E5, E6], { steps: { 0: [1, "旅立ち"], 1: [3, "祭りの 夜（北の 門の 外）"], 2: [5, "城へ（ミドリとの 勝負）"] } });
