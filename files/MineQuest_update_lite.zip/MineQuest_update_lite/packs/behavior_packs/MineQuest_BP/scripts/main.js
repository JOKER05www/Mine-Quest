import { world, system, ItemStack } from "@minecraft/server";
import { ITEMS, VERSION, CHANGELOG, EGGS } from "./data.js";
import { load, save, autoBackup, noteHost, isHost } from "./store.js";
import { promoteBench } from "./core.js";
import { GEAR_CAP } from "./gear.js";
import { rankCap, storyLootOk } from "./quest.js";
GEAR_CAP.f = (p) => { const d = load(p); return d ? rankCap(d) : 8; };
import { TYPE, initWild, spawnWildNear, hooks as FHOOKS } from "./field.js";
import { onHitMonster, inBattle } from "./battle.js";
import { repairFlow } from "./repair.js";
import { openMenu, useItemFlow, resetData, npcMenu, isSpoil } from "./menu.js";
import { busy, giveItem, showLogo } from "./ui.js";
import { npcJob } from "./structures.js";
import { BOOKWAIT, bookEarly } from "./battle.js";
import "./master.js";
import "./navi.js";
import "./nametag.js";   /* 第117版: 名札は 大事な 人だけ */
import "./fieldnpc.js";   /* 第117版: 町の 外を 旅する 人・戦う 冒険者 */
import "./regionskin.js";
import "./lite.js";
import "./islands.js";   /* 第104版: 遊び場の 浮島 */   // v3.0: 軽量モード（本体に 入れた）   // v3.0: 地方ごとの 景色
import "./guild.js";   /* 第106版: 冒険者協会の 依頼・酒場・レストラン */
import "./citylife.js";
import "./social.js";   /* 第110版: 町の 人と 交流 */   /* 第106版: 町を 歩く 人 */
import "./camp.js";   /* 第106版: キャンプ */
import "./beach.js";   /* 第106版: 海辺の 人たち */
import "./troubles.js";   /* 第106版: 町の トラブル */
import { testMenu } from "./test.js";
import { cheatMenu } from "./cheat.js";
import { fish } from "./fishing.js";
import { nearAltar, hasTokoyo, altarAsk, altarFlow, dreamFlow, nearRf, rfAsk, rfFlow } from "./postgame.js";
import { homeTp, initSaga, team as sagaTeam } from "./saga.js";
import { regionLv } from "./worldmap.js";
import { inDungeon, dungeonMenu } from "./dungeon.js";
import { fight, holdBusy } from "./story.js";
import { initEndgame } from "./endgame.js";
import { initChests, CHEST_GATE } from "./chests.js";
import { NPC_HOOKS } from "./npchook.js";
import "./ruins.js";   /* 第76版: 追加ストーリー「滅びた世界」（追加パックが あるときだけ 動く） */
import "./guide.js";   /* 第90版: 目的地の 光 */
import "./explore.js";   /* 第101版: 探索 */
import "./explore2.js";   /* 第102版: 探索の 追加 */
import "./life.js";   /* 第102版: 旅の くらし */
import "./town.js";   /* 第102版: 町 */
import "./bond.js";   /* 第102版: きずな */
import { talkUse } from "./talkbook.js";   /* 第115版: トークブック（仲間が チャットで 話す） */
import "./toys.js"; import "./contest.js";   /* 第113版: 相棒の おもちゃ・贈り物・おもちゃ屋・コンテスト */
// v2.9.13: ハコダマシ（宝箱に 化けた モンスター）。土地と 宝箱の 段で 強さが きまる（手持ちより 強く なりすぎない）
CHEST_GATE.mimicOk = (p) => { try { if (!p || !p.isValid() || busy.has(p.id) || typeof p.getDynamicProperty("mrpg:dg") === "string") return false; const d = load(p); if (d && d.party && promoteBench(d)) save(p, d); return !!(d && d.party && d.party.some((m) => m.hp > 0)); } catch { return false; } };
CHEST_GATE.mimic = async (p, t, loc) => {
  const d = load(p); if (!d) return null;
  const top = Math.max(1, ...[...d.party, ...(d.bench || [])].map((m) => m.lv || 1));
  let lv = 3; try { lv = regionLv(loc) + t; } catch {}
  lv = Math.max(1, Math.min(100, top + 2, lv));
  const foe = sagaTeam(["nether", "golem", "nether"], lv, t >= 6 ? 2 : 1, Math.min(20, t * 2)).map((m, i) => ({ ...m, q: i ? 0.4 : 0.7 }));
  if (!foe.length) return null;
  return await fight(p, { team: foe }, { tier: 0, fam: "", npc: null, theme: "cave", name: "ハコダマシ", arena: "宝箱の わな", mimic: true, easy: t <= 3, speaker: "ハコダマシ", lines: { half: "§7（宝箱の ふたが ガタガタ 鳴って いる）", low: "§7（ふたが 半分 開いて きた……）" } });
};
CHEST_GATE.fn = (p, id) => { let c = 8; try { c = rankCap(load(p)); } catch {} return storyLootOk(ITEMS[id], EGGS[id]?.ranks, c); };   // v2.9.12
try { initChests(); } catch (e) { console.warn(`[MonsterRPG] chests: ${e}`); }
try { initEndgame(); } catch (e) { console.warn(`[MonsterRPG] endgame: ${e}`); }

const BOOK = "mrpg:monster_book";
const giveBook = (p) => { try { giveItem(p, BOOK, 1); } catch {} };

world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => {
  if (initialSpawn) noteHost(player);
  // v1.7: ワールドに 入ったら ロゴ
  if (initialSpawn) system.runTimeout(() => { try { showLogo(player, "§eマインクエスト §7― スカウト・配合して 最強の マスターへ"); player.playSound("random.levelup", { pitch: 0.8, volume: 0.6 }); } catch {} }, 60);
  // v2.0: アイテム パックが 入っているか
  if (initialSpawn) system.runTimeout(() => { try { new ItemStack("mrpg:c_herb", 1); } catch { try { player.sendMessage("§c§l[マインクエスト]§r§c アイテム パック（マインクエスト アイテム）が 入っていません。§f道具・装備・タマゴ・釣竿が 使えないので、ワールドの 設定で ビヘイビアパック・リソースパックの 両方を 有効に してください。"); } catch {} } }, 80);
  // v1.7: 自動バックアップ（バージョンが かわった とき・1日1回）
  if (initialSpawn) system.runTimeout(() => { try { autoBackup(player, VERSION); } catch {} }, 10);
  /* 第103版: 新しい 版に なった ことを 1回だけ 知らせる */
  if (initialSpawn) { const veteran = player.hasTag("mrpg_given3"); system.runTimeout(() => { try { if (player.getDynamicProperty("mrpg:verSeen") !== VERSION) { const old = player.getDynamicProperty("mrpg:verSeen"); player.setDynamicProperty("mrpg:verSeen", VERSION); if (old !== undefined || veteran) player.sendMessage(`§e§l[マインクエスト] ${VERSION.replace(/^\S+ /, "")}に なりました。§r§f新しい こと: ガイドブック → 冒険 → 遊び方 →「§eアップデート情報§f」`); } } catch {} }, 120); }
  // v2.2: 冒険のコンパス（いままでの プレイヤーにも 1回だけ）
  if (initialSpawn && !player.hasTag("mrpg_navi")) system.runTimeout(() => { try { const d0 = load(player); if (!d0 || !(d0.story && d0.story.introDone)) return;   /* 第115版: はじめての 人は 幼なじみが 作った コンパスを 物語で もらう */ player.addTag("mrpg_navi"); giveItem(player, "mrpg:navi", 1); player.sendMessage("§e§l冒険のコンパス§r§e を もらった！ §f使うと 町や 遺跡の 方向が わかる 地図が 開きます。"); } catch {} }, 100);
  if (!initialSpawn || player.hasTag("mrpg_given3")) return;
  player.addTag("mrpg_given3");
  player.addTag("mrpg_newhome");   // v2.3: 始まりの町 ルミナの 自分の 家から
  if (!player.hasTag("mrpg_given2")) giveBook(player);
  player.addTag("mrpg_given2");
  player.sendMessage("§b§lマインクエスト§r §fへ ようこそ！ ガイドブックを 使って 冒険を 初めよう。");
});

world.afterEvents.itemUse.subscribe(({ source: p, itemStack }) => {
  if (p.typeId !== "minecraft:player" || !itemStack) return;
  const id = itemStack.typeId;
  if (id === BOOK && BOOKWAIT.has(p.id)) { const r = BOOKWAIT.get(p.id); BOOKWAIT.delete(p.id); r("open"); return; }   // v2.9.12: 戦闘中は 行動の 画面
  if (id === BOOK && bookEarly(p)) return;   // 演出中に 使ったら 自分の 番で すぐ 開く
  // v2.4: 閻魔の神殿の 前で ブックか 邪刀・閻魔を 使う
  if ((id === BOOK || id === "mrpg:wp_tokoyo" || id === "mrpg:k_hilt") && nearAltar(p) && !busy.has(p.id)) {
    system.run(async () => {
      let r = false;
      try { const d = load(p); if (d && promoteBench(d)) save(p, d); if (d && d.party.some((m) => m.hp > 0)) { busy.add(p.id); try { r = await altarAsk(p, d); } finally { busy.delete(p.id); } if (r === "go") r = await holdBusy(p, () => altarFlow(p, load(p), fight, true)); else if (r === "dream") r = await holdBusy(p, () => dreamFlow(p, fight, homeTp)); } } catch (e) { console.warn(`[MonsterRPG] altar: ${e}`); }
      if (r === false || r === "cancel") { if (id === BOOK) openMenu(p); else if (!busy.has(p.id)) { busy.add(p.id); try { await useItemFlow(p, load(p), id.slice(5)); } finally { busy.delete(p.id); } } }
    });
    return;
  }
  // v2.2.2: 石板の 中では 脱出メニュー
  if (id === BOOK && inDungeon(p) && !busy.has(p.id)) {
    system.run(async () => { busy.add(p.id); let r = null; try { r = await dungeonMenu(p); } finally { busy.delete(p.id); } if (r === "open") openMenu(p); });
    return;
  }
  // v2.2.2: 終の遺跡の 棺の 前
  if (id === BOOK && nearRf(p) && !busy.has(p.id)) {
    system.run(async () => {
      let r = false;
      try { const d = load(p); if (d) { busy.add(p.id); try { r = await rfAsk(p, d); } finally { busy.delete(p.id); } if (r === "go") r = await holdBusy(p, () => rfFlow(p, load(p), fight)); } } catch (e) { console.warn(`[MonsterRPG] rfin: ${e}`); }
      if (r === false || r === "cancel") openMenu(p);
    });
    return;
  }
  if (id === BOOK) {
    // v2.9.13: 本が 開かない（止まった）ときは しゃがみながら 使うと「バグを 直す」
    if (busy.has(p.id) && !inBattle(p)) {
      if (p.isSneaking) { system.run(() => repairFlow(p, true)); return; }
      try { p.sendMessage("§7ガイドブックが 開かない ときは、§fしゃがみながら 使うと「バグを 直す」§7が 開きます。"); } catch {}
      return;
    }
    system.run(() => openMenu(p)); return;
  }
  if (id === "mrpg:talkbook") { system.run(() => talkUse(p)); return; }   /* 第115版 */
  if (id === "mrpg:cheat_book") { system.run(() => { if (isHost(p)) cheatMenu(p); else p.sendMessage("§cチートブックは ホストだけ 使えます（ホストが 設定で 許可すると 使えます）。"); }); return; }
  if (id.startsWith("mrpg:") && ITEMS[id.slice(5)]?.kind === "rod") { system.run(() => fish(p, id.slice(5))); return; }
  if (id.startsWith("mrpg:") && ITEMS[id.slice(5)]) {
    system.run(async () => {
      if (busy.has(p.id)) return;
      busy.add(p.id);
      try { await useItemFlow(p, load(p), id.slice(5)); } finally { busy.delete(p.id); }
    });
  }
});

world.afterEvents.entitySpawn.subscribe(({ entity }) => {
  if (entity?.typeId !== TYPE) return;
  system.run(() => { try { initWild(entity); } catch {} });
});

function onNpc(p, e) {
  try { e.getComponent("minecraft:health")?.resetToMaxValue(); } catch {}
  for (const h of NPC_HOOKS) { try { if (h(p, e)) return; } catch {} }
  const job = npcJob(e);   // v2.9.12: プロパティが 初期値に もどって いても 正しい 仕事で 開く
  system.run(() => npcMenu(p, job, e));
}
world.afterEvents.entityHitEntity.subscribe(({ damagingEntity: p, hitEntity: e }) => {
  if (p?.typeId !== "minecraft:player" || !e) return;
  if (e.typeId === "mrpg:npc") return onNpc(p, e);
  if (e.typeId === TYPE && e.hasTag("mrpg_pet")) { system.run(() => { try { if (FHOOKS.petTouch) FHOOKS.petTouch(p, e); } catch {} }); return; }   /* 第104版: 相棒に ふれる */
  if (e.typeId === TYPE) system.run(() => onHitMonster(p, e));
});
world.afterEvents.entityHurt.subscribe(({ hurtEntity: e, damageSource }) => {
  const p = damageSource?.damagingEntity;
  if (p?.typeId !== "minecraft:player" || e?.typeId !== TYPE || damageSource.cause !== "projectile") return;
  system.run(() => onHitMonster(p, e));
});
try {
  world.afterEvents.playerInteractWithEntity?.subscribe(({ player: p, target: e }) => {
    if (e?.typeId === "mrpg:npc") onNpc(p, e);
  });
} catch {}

system.afterEvents.scriptEventReceive.subscribe(({ id, sourceEntity: p }) => {
  if (!p || p.typeId !== "minecraft:player") return;
  if (id === "mrpg:menu") openMenu(p);
  else if (id === "mrpg:give") giveBook(p);
  else if (id === "mrpg:spawn") spawnWildNear(p, 1, 3, 5);
  else if (id === "mrpg:items") { for (const k of Object.keys(ITEMS)) giveItem(p, `mrpg:${k}`, 1); }
  else if (id === "mrpg:test") system.run(() => testMenu(p));
  else if (id === "mrpg:cheat") { giveItem(p, "mrpg:cheat_book", 1); p.sendMessage("§dチートブックを 手に入れた。"); }
  else if (id === "mrpg:reset") { resetData(p); p.sendMessage("§cマインクエストの データを 消しました。"); }
});

// v2.8: 死んでも 持ち物を 落とさない（はじめから。毎回 たしかめる）
function keepInv() { try { world.getDimension("overworld").runCommand("gamerule keepinventory true"); } catch {} }
system.runTimeout(keepInv, 40);
world.afterEvents.playerSpawn.subscribe(({ initialSpawn }) => { if (initialSpawn) system.runTimeout(keepInv, 20); });
initSaga();

