/* 第126版 裏15「記録塔と おかえり」（記録塔／各地）【裏の 最終章】— 作業 UB
   記録塔（区15）: 1〜3話 前 → 4話 向かい合う（最終戦は ruins.js。前の 返り値 info = { wk, add, pal, t, sp }）→ 後: 勝った 一拍（相棒が 戻る）
     → 5話（崩れる 玉座・本当の 名「ヴォルナグ」を 一度だけ 読む・選択 U15）→ 6話（白く なる 頁・stoneBack）
   7〜10話: 常世を 終えた あとの 各地（エンドの 鱗の 墓標 → ルミエの 小川 → ルミナの 牧場 → クロガネの 工房）。bk_u08.js の AFTER が 案内して 流す
   ・「日記帳」「ヴォルナグ」は この 章だけ。神は 名を 名乗らない（「名など、とうに 無くしました」）。名は 5話で 一度だけ 読み上げる */
import { K } from "./bkeng.js";
import { U, AFTER } from "./bk_u08.js";
import { SGK } from "./saga.js";
import { act, hold, fx, fade, PJ, heroOf, shadowFlow } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
import { townOut, ranchSpot, bldOf } from "./storyplace.js";
import { SPECIES } from "./data.js";
import { setLook, lookOf } from "./field.js";
import { exOf } from "./explore.js";
import { qs } from "./quest.js";
import { load, save } from "./store.js";
const { F, S1, ok } = U;
const V = (g, o, c, t) => ({ g, o, c, t });
const GOD = "名の ない 神";

facAdd("u15stair", { D: [10, 12, 14], box: [0, -4, 7, 4], H: 6, look: [5, 0, 2], marks: { stair: [2, 0, 1.5], throne: [6, 0, 3], pages: [5, -3, 2] },
  build: () => [F(1, -1, 0, 1, 1, 0, "polished_deepslate_stairs"), F(2, -1, 0, 2, 1, 1, "polished_deepslate"), F(3, -1, 0, 3, 1, 2, "polished_deepslate"), F(4, -2, 0, 7, 2, 2, "polished_deepslate"), S1(6, 0, 3, "purpur_stairs"), F(7, -1, 3, 7, 1, 5, "purpur_pillar"),
    F(5, -4, 0, 5, -3, 4, "bookshelf"), F(5, 3, 0, 5, 4, 4, "bookshelf")] });
facAdd("u15grave", { D: [9, 11, 13], box: [0, -3, 3, 3], H: 3, look: [1.5, 0, 0.8], marks: { grave: [2, 0, 1.2], bed: [1, -2, 0.6] },
  build: () => [F(0, -3, -1, 3, 3, -1, "end_stone_bricks"), S1(2, 0, 0, "mossy_stone_brick_wall"), S1(2, 0, 1, "stone_brick_slab"), F(3, -3, 0, 3, 3, 0, "prismarine_bricks"), S1(3, 0, 1, "dark_prismarine"), F(1, -3, 0, 1, -1, 0, "smooth_stone_slab"), S1(1, 2, 0, "cornflower"), S1(1, 3, 0, "poppy")] });
facAdd("u15brook", { D: [9, 11, 13], box: [0, -5, 3, 5], H: 3, look: [1.5, 0, 0.5], marks: { brook: [1.5, 0, 0.3], bank: [0, 2, 0.5] },
  build: () => [F(1, -5, -1, 2, 5, -1, "water"), F(0, -5, 0, 0, -3, 0, "short_grass"), F(3, 2, 0, 3, 5, 0, "short_grass"), S1(0, 4, 0, "oak_fence"), S1(0, 4, 1, "lantern")] });
facAdd("u15ranch", { D: [10, 12, 14], box: [0, -5, 5, 5], H: 3, look: [2.5, 0, 0.8], marks: { pen: [2.5, 0, 0.6], roof: [4, -4, 2] },
  build: () => [F(0, -5, 0, 5, -5, 0, "oak_fence"), F(0, 5, 0, 5, 5, 0, "oak_fence"), F(5, -5, 0, 5, 5, 0, "oak_fence"), F(4, -4, 0, 4, -3, 1, "hay_block"), F(3, -4, 2, 5, -2, 2, "spruce_slab"), S1(3, -2, 0, "spruce_fence"), S1(3, -2, 1, "spruce_fence")] });
facAdd("u15forge", { D: [9, 11, 13], box: [0, -4, 4, 4], H: 4, look: [2, 0, 1], marks: { anvil: [1, -1, 1], post: [3, 3, 1.5], bed: [2, 3, 0.6], fire: [3, -2, 1] },
  build: () => [S1(1, -1, 0, "anvil"), S1(3, -2, 0, "blast_furnace"), S1(3, -3, 0, "campfire"), F(3, 3, 0, 3, 3, 3, "stripped_oak_log"), F(1, 3, 0, 2, 3, 0, "smooth_stone_slab"), F(4, -4, 0, 4, 4, 3, "bricks")] });

/* ---- 神の 体（G サイズの 抜け殻。顔は 破り取られた 頁）---- */
const godBody = (p, C, dist = 9) => {
  const sid = SPECIES.god43 ? "god43" : null; if (!sid) return null;
  const G = C.mon(sid, dist, 0, 0, "smoke"); if (!G) return null;
  let h = 4; try { setLook(G, sid, { sz: "G" }); const L = lookOf(sid, { sz: "G" }); G.setProperty("mrpg:size", Math.min(2500, Math.round(L.size * 1.15))); h = Math.max(2, Math.min(9, L.mh * 1.15 * 0.85)); } catch {}
  try { G.nameTag = ""; G.addTag("mrpg_spkm"); G.setDynamicProperty("mrpg:spk", GOD); G.setDynamicProperty("mrpg:hy", h); } catch {}
  return G;
};
/* ---- 最終戦の 前の 返り値（きずな・守り手の 印・選択 U11）。tokoyo.js の 第125版の 決まりを 受けつぐ ---- */
const TIERS = [0, 80, 250, 600, 900];
const INFO = new Map();
function finInfo(p) {
  const d = load(p); if (!d) return { wk: 0, add: [] };
  const m = [...(d.party || []), ...(d.bench || []), ...(d.box || [])].find((x) => x && (x.id === d.partnerId || x.partner || x.look)); if (!m) return { wk: 0, add: [] };
  let nk = 0; try { nk = Number((exOf(p).nk || {})[m.id]) || 0; } catch {}
  const t = TIERS.filter((v) => nk >= v).length - 1, s = qs(d), mark = !!((s.gate || {})[1] || (s.keys || []).includes("k_spirit"));
  let wk = t >= 3 ? 3 : t >= 2 ? 1 : mark ? 0 : -2;
  const u11 = (s.ch || {}).u11; if (u11 === "a") wk += 1; else if (u11 === "s") wk -= 1;   /* U11: 針を 進めた → 一段 少ない／止めた → 土台の 頁の 盾で 一段 多い */
  return { wk, add: [{ sid: m.sp, lv: m.lv, q: 1, plus: Math.min(99, (m.plus || 0) + 10) }], pal: m.nm || SPECIES[m.sp]?.name, t, sp: m.sp, mark };
}

const fight15 = U.fight(15, async (p, C) => {
  await K.open(p, "常世 ― 記録塔の 頂の 玉座", "ash");
  K.fac(p, "u15stair", "u15stair", 99, U.y0(p));
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  const G = godBody(p, C); if (ok(G)) await K.low(p, G, 14);
  const u11 = K.ch(p, "u11");
  if (u11 === "s") {
    K.sound(p, "item.book.page_turn", 1); if (ok(G)) await K.at(p, U.top(G), 14, 7, 0);
    await U.narr(p, ["§7神の 前に、§f石の 都の 頁§7 が 何枚も 重なって 盾に なった。§8……止めた ままの 二十三時 五十九分。"], G);
    await U.say(p, GOD, ["{closed}……止めた 一日は、わたしを 守って くれます。あなたが 止めたのですよ"]);
  } else if (u11 === "a") await U.narr(p, ["§8神の 足もとの 頁は、もう 薄い。……朝を 迎えた 都は、盾に ならない。"], G);
  await K.up(p, mu, 8);
  await U.M(p, mu, ["{angry,!,up}書いて 閉じこめるのが お前の 記録なら、俺は 打ち直す。", "{closed}名前は 刀と 同じだ。鈍ったら、打ち直せる。"], "raise");
  await U.E(p, mu, ["……書き留めるだけでは、記録では ない。終わらせて こそだ"]);
  await U.M(p, mu, ["{closed}エンマ。俺が 前、お前が 後ろ……いや 逆か？"], "guard");
  await U.E(p, mu, ["……逆では ない。今日は、並べ"]);
}, async (p, C) => {
  K.fac(p, "u15stair", "u15stair", 99, U.y0(p));
  const pm = U.pal(p, C, 6, 0);
  K.flash(p); if (pm && ok(pm.e)) { const l = p.location; await K.walkCam(p, pm.e, { x: l.x + 1.4, y: l.y, z: l.z }, 16); K.re(pm.e, null, "heart"); }
  await U.narr(p, [`§f黒い 霧が ほどけ、§e${pm ? pm.nm : "相棒"}§f が 足もとに 転がって きた。`], pm && pm.e);
  await U.say(p, `${pm ? pm.nm : "相棒"}（相棒）`, ["……ただいま。"]);
  const so = U.soul(p, C, 2.6, -1.8, "none");
  await U.H(p, V(["{cry,tears,jump}……もう！ 心配 させないでよ！ ……おかえり！"], ["{cry,tears,up}……もう。心配 したんだから……おかえり"], ["{cry,tears}……心配 させるな。……おかえり"], ["{cry,tears,up}……もう！ ご心配 おかけして……おかえりなさい！"]), pm && pm.e);
});

U.reg("u15", [
  { id: "u15e1", t: "うるせえ 塔", free: false, F: ["F39"],
    syn: "記録塔の 階段は、名前が ぎゅうぎゅうに 詰まって 鳴って いた。ムサシは 記録塔を「うるせえ 塔」と 呼んだ。「今日の 言葉は、逆じゃ ねえ」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 記録塔の 階段", "ash");
        const s0 = K.fac(p, "u15stair", "u15stair", 99, U.y0(p)), st = facMark("u15stair", "stair", p.location) || s0, pg = facMark("u15stair", "pages", p.location) || s0;
        if (st) await K.at(p, st, 16, 6, 1.5);
        for (let k = 0; k < 6; k++) { K.sound(p, "item.book.page_turn", 0.4, 0.6 + k * 0.1); await K.wait(3); }
        await U.narr(p, ["§7壁と いう 壁に、紙が 詰まって いた。§8……ざわざわ、ざわざわ。紙の 中で、名前が 鳴って いる。"], pg);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        await U.tap(p, mu);
        await U.M(p, mu, ["{angry,汗}……うるせえ。名前が ぎゅうぎゅうに 詰まって、塔ごと 鳴ってやがる。", "{closed}……こいつは『うるせえ 塔』だ。"], "point");
        await U.E(p, mu, ["……記録塔、と 書いて ある"]);
        await U.M(p, mu, ["{smile}知ってる。……けど、今日は 俺の 名前の ほうが 合ってる。"], "arms");
        await U.H(p, V(["{smile}……うん。今日は、ムサシの 名前の ほうが 合ってる"], ["{smile}……ええ。今日は、ムサシの 名前の ほうが 合ってるわ"], ["{smile}……今日は ムサシの 名前が 合ってる"], ["{smile}……はい。今日は、ムサシさんの 名前の ほうが 合って います"]), mu);
        /*F39 回: 最後の「逆」は 逆じゃない */
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……いや、逆か？", "{smile,low}……ちゃんと 鳴った。今日の 言葉は、逆じゃ ねえ。"], "raise");
        await U.end(p, C, { card: "§7→ 頂の 玉座へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e2", t: "覚えて おいて あげましょう", free: false,
    syn: "頂の 玉座に、顔の ない 神が いた。「覚えて おいて あげましょう」。玉座の まわりの 頁には、四歳の 冬の 夜の ことも 書かれて いた。「この 常世は、わたしの 日記帳」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 記録塔の 頂の 玉座", "ash");
        const s0 = K.fac(p, "u15stair", "u15stair", 99, U.y0(p)), th = facMark("u15stair", "throne", p.location) || s0, pg = facMark("u15stair", "pages", p.location) || s0;
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none");
        const G = godBody(p, C); if (ok(G)) { await K.low(p, G, 16); await K.at(p, U.top(G), 18, 6, 0); }
        await U.narr(p, ["§7玉座の 上に、大きな 抜け殻の 体。§f顔の 所だけ、頁を 破り取った ように、四角く 白い。"], G);
        await U.say(p, GOD, ["……よく 来ました。覚えて おいて あげましょう。", "あなたの ことも、その 子の ことも。……もう、書いて ありますから"], mu);
        if (pg) await K.push(p, pg, 22, 4, 1.6, 0.6);
        await U.narr(p, ["§7玉座の まわりの 頁に、§f見覚えの ある 字§7。§8……灰の 冬の 夜。四歳の 子が、目を 覚まさない 子の 名を、一晩じゅう 呼んで いる。"]);
        await K.up(p, so, 8);
        await U.H(p, V(["{shock,…,up}……これ、わたしたちだ。四歳の 冬。……わたし、あなたの 名前を ずっと 呼んでた"], ["{shock,…,up}……これ、わたしたちよ。四歳の 冬。……わたし、あなたの 名前を ずっと 呼んで いたの"], ["{shock,…,up}……わたしたち。四歳の 冬。……ずっと 呼んでた"], ["{shock,…,up}……これ、わたしたちです。四歳の 冬。……わたし、あなたの お名前を ずっと 呼んで いました"]));
        await U.say(p, GOD, ["……この 常世は、わたしの 日記帳。『永遠に』と 願われた 一日を、一頁ずつ 綴じて きました", "誰も 失わない ように。……誰の ことも、忘れない ように"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{angry}……お前、名前は。"], "guard");
        if (ok(G)) await K.at(p, U.top(G), 12, 6, 0);
        await U.say(p, GOD, ["{closed}……名など、とうに 無くしました。", "{smile}人は わたしを 邪神と 呼び、昔の 民は 記録の 神と 呼びました。……どちらでも かまいませんよ"]);
        await U.end(p, C, { card: "§7→ 黒い 霧が、こちらへ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e3", t: "守り手の 印", free: false, F: ["F31"],
    syn: "黒い 霧が 相棒を さらおうと した。手の 甲と 相棒の 額に、守り手の 印。相棒の 名を 呼んだ。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 玉座", "ash");
        K.fac(p, "u15stair", "u15stair", 99, U.y0(p));
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"), pm = U.pal(p, C, 2.6, 1.2);
        const G = godBody(p, C, 10);
        const info = finInfo(p); INFO.set(p.id, info);
        await U.say(p, GOD, ["……あなたには、わたしの ささやきが 届かない。さびしい ことです。", `だから、その 子を いただきます。§e${info.pal || "相棒"}§f。……ほら、あなたを 呼んで いますよ`], pm && pm.e);
        if (pm && ok(pm.e)) { await shadowFlow(p, ok(G) ? G.location : p.location, pm.e.location, 12); await K.up(p, pm.e, 10); }
        K.sound(p, "mob.wolf.growl", 1); K.shake(p, 0.6, 0.6);
        await U.narr(p, [`§5黒い 霧が §e${info.pal || "相棒"}§5 を 包み、玉座の 奥へ 引きずって いく。`, "§7……言葉を 持たない ものには、影は 宿れない。だから 霧は、体ごと 連れ去ろうと して いる。"], pm && pm.e);
        await U.M(p, mu, [`{rage,怒,jump}${info.pal || "相棒"}！ 踏んばれ！ ……そいつを 返しやがれ！`], "guard");
        /*F31 回: 守り手の 印（片方が 呑まれても、もう 片方が 呼べば 戻れる）*/
        if (info.mark) {
          K.flash(p); K.sound(p, "beacon.activate", 1); if (pm && ok(pm.e)) fx(p.dimension, "minecraft:totem_particle", pm.e.location, 12, 0.5);
          await U.narr(p, [`§6あなたの 手の 甲と、§e${info.pal}§6 の 額に、同じ 形の 光が 浮かんだ。`, "§a『片方が 連れ去られても、もう 片方が 呼べば 戻れる』", `§f……${info.pal} の 名前を、呼んだ。`]);
        } else await U.narr(p, [`§f……${info.pal || "相棒"} の 名前を、呼んだ。`]);
        await U.say(p, `${info.pal || "相棒"}（相棒）`, [`……${U.nm(p)}。`, "……きこえる。ここ、だよ。"]);
        const line = info.wk >= 3 ? "§a霧の 中から、何度も あなたを 呼び返して いる！ §7（きずなが 強い: 神の HP −30%）" : info.wk >= 1 ? "§e霧に 抵抗して いる。§7（神の HP が 少し 下がる）" : info.wk >= 0 ? "§6呼ぶ 声が 霧を おさえた。§7（神の HP は ふえない）" : "§c霧に 引きずられかけて いる……！ §7（きずなが 弱い: 神の HP が ふえる。きずなを 深めて 来ると 有利に なる）";
        await U.narr(p, [line]);
        await U.end(p, C, { card: "§7→ 最後の 戦い" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e4", t: "打ち直す", free: false, run: fight15, syn: "最後の 戦い。ムサシ「名前は 刀と 同じだ。鈍ったら 打ち直せる」。" },
  { id: "u15e5", t: "破れた 頁", free: false, F: ["F13"], ans: ["qb031", "qu111", "qu141"],
    syn: "崩れる 玉座で、神の 顔の 破り取られた 頁の 形が、廃都の 壁画の 古い 削り跡と 同じだと わかった。三千年前、都の 祈りを 書き留めて 都を 止めて しまった 神は、自分の 名の 頁を 破り、壁画から 自分を 削った。消えて ゆく 神の 前で、破れた 頁に 残った 本当の 名を、一度だけ 声に 出して 読んだ。セオは 自分の 字で その 名を 書き、ムサシは 返事の 声を 耳で 聞いた。「わたしは、ただ……誰の ことも、忘れたく なかった」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 崩れる 玉座", "ash");
        const s0 = K.fac(p, "u15stair", "u15stair", 99, U.y0(p)), th0 = facMark("u15stair", "throne", p.location) || s0, pg = facMark("u15stair", "pages", p.location) || s0;
        const at = (a, b) => { const S = K.S(p); return S ? S.at(a, b) : null; };
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"), pm = U.pal(p, C, 3.4, 0.2), pal = pm ? pm.nm : "相棒";
        const G = godBody(p, C, 8);
        const nm = U.nm(p), hn = U.hn(p);
        /* 1 崩れる 玉座: 抜け殻が 膝を つく（引き → 見上げ）*/
        K.shake(p, 0.4, 1.2); K.sound(p, "random.break", 0.6, 0.6);
        if (ok(G)) await K.pull(p, G, 24);
        await U.narr(p, ["§7玉座が、音を 立てて 割れた。§f抜け殻の 大きな 体が、ゆっくりと 膝を ついた。", "§8……顔の 四角い 白い 頁だけが、風も ないのに めくれかけて いる。"], th0);
        /* 2 神の おそれ: 何も 忘れなかった 神が、自分だけ 残らない ことを おそれる */
        if (ok(G)) await K.low(p, G, 12);
        await U.say(p, GOD, ["{closed}……ふしぎですね。痛くは ないのです", "{sad}ただ、塔の 字が 上の 段から 順に 薄く なって いくのが、分かります"]);
        if (ok(G)) await K.at(p, U.top(G), 14, 5, 0);
        await U.say(p, GOD, ["{sad,…}三千年、わたしは 誰の 名も 書き落としませんでした。……けれど、わたしの 名を 書いた 者は、どこにも いない", "{closed,tears}わたしが 消えたら、わたしの いた 頁は……どの 本にも、残らないのですね"]);
        if (ok(mu)) await K.ots(p, mu, p, 10);
        await U.say(p, nm, ["{closed}……書いた 人が いなくても、呼ぶ 人は ここに いる"]);   /* 主人公の 声（オーナーの 指定）*/
        /* 3 セオが 破れた 頁を 拾って 歩いて 来て、ひざを つく */
        const th = C.npc("§aセオ", 18, 3.6, 3.6, 0, "walk"); hold(th, "scroll");
        if (ok(th)) { await K.walkCam(p, th, at(6, 1.9), 18); act(th, "kneel"); }
        await U.narr(p, ["§7鎖の 切れた セオが、塔の 紙の 山から 一枚を 拾って 歩いて きた。§8……四角く 破られた 頁。"], pg);
        if (ok(th)) await K.push(p, th, 20, 3.6, 1.4, 1);
        /*F13 回（二層目）: 削り跡の 下の 古い 四角 ＝ 神の 破れた 顔の 形 */
        await U.say(p, "セオ", ["{closed}……この 破れ目の 形。廃都の 壁画の、いちばん 古い 削り跡と 同じです", "{sad,up}都を 止めて しまった 夜、あなたは 自分の 名の 頁を 破って、壁から 自分を 削った。……ちがいますか"]);
        if (ok(G)) await K.ots(p, th, G, 10);
        await U.say(p, GOD, ["{closed}……ちがいません。愛した 都を 止めた 者の 名など、どこにも 残しては いけないと 思いました"]);
        /* 4 セオ: 同じ 病。……名は 君が 読んで くれ */
        if (ok(th)) await K.up(p, th, 10);
        await U.say(p, "セオ", ["{closed}……僕も、忘れられない 頭を 持って います。あなたの 病は、僕の 病です", "{sad}破れた 頁の 裏に、一行だけ 名が 残って いる。……僕の 声は、長く 影の 声だった。君が 読んで くれ"]);
        if (ok(th)) { act(th, "give"); K.sound(p, "item.book.page_turn", 0.8); await K.wait(10); act(th, "kneel"); hold(th, 0); }
        /* 5 本当の 名を 読む（00 §16: 口に するのは ここ 一度だけ。名を 呼ぶ 声が 影を 退ける）*/
        if (ok(G)) await K.ots(p, p, G, 12);
        await U.narr(p, ["§f破れた 頁を 両手で 持ち、あなたは 声に 出して 読んだ。"]);
        K.flash(p); K.sound(p, "beacon.power", 0.8);
        if (ok(G)) await K.push(p, U.top(G), 18, 7, 3, 0);
        await U.narr(p, ["§e§l『ヴォルナグ』"]);
        /* 6 名を 呼ばれた 神 */
        if (ok(G)) { try { G.setDynamicProperty("mrpg:spk", "ヴォルナグ"); } catch {} K.turn(G, p.location); await K.at(p, U.top(G), 12, 4, 0); }   /* 呼んだ 人を 見る */
        await U.narr(p, ["§7四角く 白かった 頁に、うすく 顔が 浮かんだ。§8……目を 細めた、やさしい 顔。"], G);
        await U.say(p, "ヴォルナグ", ["{shock,…}……ああ。", "{smile,tears}誰の 名も 書く ばかりで……呼ばれたのは、三千年ぶりです。……そう。それが、わたしの 名でした"]);
        if (ok(th)) await K.ots(p, th, p, 10);
        await U.say(p, nm, ["{closed}一晩 目を 覚まさなかった 冬、名前を 呼ばれて 帰って きた", "{up}呼ばれた 名前は、帰る 場所を 覚えてる。……今日から、あなたの 名前も そうだ"]);
        if (ok(G)) await K.at(p, U.top(G), 8, 5, 0);
        K.turn(G, null);
        /* 7 セオが 自分の 字で 書く（嘘を 書かない 記録）*/
        if (ok(th)) { hold(th, "notebook"); await K.up(p, th, 10); }
        await U.say(p, "セオ", ["{closed}……誰の 字でも 写して きた 手です。今日は、自分の 字で 書きます"]);
        if (ok(th)) { K.sound(p, "item.book.page_turn", 0.6); await K.push(p, th, 18, 2.8, 1.2, 0.7); }
        await U.narr(p, ["§7セオは 塔の 白い 紙を 膝に のせ、紫の インクで 一行 書いた。", "§f『記録の 神 §eヴォルナグ§f。民を 愛し、誰も 手放せなかった。名を 呼ばれて、終わった』"]);
        if (ok(G)) await K.ots(p, th, G, 8);
        await U.say(p, "ヴォルナグ", ["{closed,tears}……嘘が、一行も ありませんね"]);
        if (ok(th)) await K.up(p, th, 8);
        await U.say(p, "セオ", ["{sad,closed}嘘は、もう 書きません。……あなたの 頁にも、僕の 頁にも"]);
        /* 8 ムサシ: 声を 聞いた（人は 叩かず、耳を 寄せる）*/
        if (ok(mu)) { await K.walkCam(p, mu, at(6.2, 0.1), 16); act(mu, "kneel"); }
        await U.narr(p, ["§7ムサシは 聞き槌を 腰に 戻し、神の 胸に 耳を 寄せた。§8……人と 生き物は、叩かない。"], mu);
        await U.M(p, mu, ["{closed}……書いた 名前は 信じねえ。それが 俺の 掟だ", "{smile,low}けど 今、呼ばれて 返事を したのは、お前の 声だった。……俺の 耳が、ちゃんと 聞いた"]);
        if (ok(G)) await K.two(p, mu, G, 10);
        await U.M(p, mu, ["{closed}字が ぜんぶ 白く なっても、耳の ほうは 白く ならねえ"]);
        await U.E(p, mu, ["……終わる ことと、忘れられる ことは、同じでは ない。千年 帳を 抱いて いた われが 言うのだ"]);
        /* 9 相棒: 蔵の 石板の 子守唄 */
        if (pm && ok(pm.e)) { await K.walkCam(p, pm.e, at(6.8, -1.3), 16); K.re(pm.e, null, "heart"); await K.up(p, pm.e, 8); }
        await U.say(p, `${pal}（相棒）`, ["……この おと、しってる。", "……蔵の 石板の うた。まいばん、これを きいて ねてた。"]);
        if (ok(G)) await K.low(p, G, 10);
        await U.say(p, "ヴォルナグ", ["{shock,…}……蔵の 軒下の、小さな 子。", "{smile,tears}わたしの 字が 鳴る 音を、子守唄に して くれたのですね"]);
        /* 10 幼なじみ: 名前を 落として いった 怖さを 知って いる 者の 言葉 */
        if (ok(so)) { await K.walkCam(p, so, at(5.2, -2.2), 16); await K.up(p, so, 8); }
        await U.H(p, V(
          ["{sad}……わたしね、馬場の 区で、自分の 名前を 一つずつ 落としてたの。", "{closed}すごく こわかった。……だから、今の あなたの 声、分かるよ", `{smile,tears}でも ${nm}が、何回も 何回も 呼んで くれた。呼ばれた 名前はね、帰り道に なるの`, "{smile,tears,up}あなたの 名前も、いま 呼ばれたよ。……もう、名の ない 神さまじゃ ない"],
          ["{sad}……わたしね、馬場の 区で、自分の 名前を 一つずつ 落として いたの。", "{closed}とても こわかったわ。……だから、今の あなたの 声、分かるの", `{smile,tears}でも ${nm}が、何度も 何度も 呼んで くれたの。呼ばれた 名前はね、帰り道に なるのよ`, "{smile,tears,up}あなたの 名前も、いま 呼ばれたわ。……もう、名の ない 神さまじゃ ないのよ"],
          ["{sad}……馬場の 区で、自分の 名前を 一つずつ 落とした。", "{closed}こわかった。……だから、今の 声は 分かる", `{smile,tears}でも ${nm}が 何度も 呼んだ。呼ばれた 名前は、帰り道に なる`, "{smile,tears,up}あなたの 名前も、いま 呼ばれた。……もう、名の ない 神じゃ ない"],
          ["{sad}……わたし、馬場の 区で、自分の 名前を 一つずつ 落として いきました。", "{closed}とても こわかったです。……ですから、今の あなたの お声、分かります", `{smile,tears}でも ${nm}さんが、何度も 何度も 呼んで くださいました。呼ばれた 名前は、帰り道に なるんです`, "{smile,tears,up}あなたの お名前も、いま 呼ばれました。……もう、名の ない 神さまでは ありません"]));
        if (ok(G)) await K.at(p, U.top(G), 10, 4, 0);
        await U.say(p, "ヴォルナグ", ["{smile,tears}……帰り道。……わたしにも、あったのですね"]);
        if (ok(so)) await K.up(p, so, 8);
        await U.H(p, V(["{sad}……わたしの 手帳、持ってて くれてるよね。名前の 頁の 最後の 行、空いてる"], ["{sad}……わたしの 手帳、持って いて くれて いるわね。名前の 頁の 最後の 行が 空いて いるわ"], ["{sad}……わたしの 手帳。名前の 頁の 最後の 行が 空いてる"], ["{sad}……わたしの 手帳を、お持ちですよね。名前の 頁の 最後の 行が 空いて います"]));
        const v = await K.pick(p, "u15");
        if (ok(G)) await K.push(p, U.top(G), 16, 6, 3.2, 0);
        if (v === "w") {
          await U.narr(p, ["§fあなたは 手帳を ひらき、名前の 頁の 最後の 行に、§eヴォルナグ§f と 書いた。"]);
          await U.say(p, "ヴォルナグ", ["{shock,…}……わたしが、誰かの 手帳に。", "{smile,tears}書く ばかりで、書かれたのは はじめてです。……あたたかい ものですね"]);
        } else {
          await U.narr(p, ["§7あなたは 手帳を ひらき、最後の 行を 一行 あけた。§8……何も 書かずに、そっと 閉じた。"]);
          await U.say(p, "ヴォルナグ", ["{smile,closed}……ええ。それで いいのです。その 行は、帰って くる 人の ために", "{closed}セオの 紙に 一行。その 子の 耳に 一つ。……わたしには、もう 十分すぎるほどです"]);
        }
        /* 11 最期の 言葉 → 頁が 光に ほどけ、石の 人の 名前が はなれて いく */
        if (ok(so)) await K.ots(p, so, p, 10);
        await U.say(p, nm, ["{closed,tears}三千年、誰かを 覚えて いて くれた。……今度は、こっちが 覚えて いる 番だ"]);
        if (ok(G)) await K.low(p, G, 10);
        await U.say(p, "ヴォルナグ", ["{closed}……お預かり して いた 日々を、お返し します", "{closed,tears}……ああ。消える。わたしは、ただ……誰の ことも、忘れたく なかった"]);
        const gl = ok(G) ? { ...G.location } : (pg ? { ...pg } : { ...p.location });
        for (let k = 0; k < 6; k++) { K.sound(p, "item.book.page_turn", 0.5, 0.7 + k * 0.08); for (let j = 0; j < 4; j++) try { p.dimension.spawnParticle("minecraft:endrod", { x: gl.x + Math.cos(k + j * 1.6) * 1.6, y: gl.y + 1 + k * 0.6 + j * 0.3, z: gl.z + Math.sin(k + j * 1.6) * 1.6 }); } catch {} await K.wait(4); }
        if (ok(G)) await fade(G, "minecraft:soul_particle");
        await K.pull(p, gl, 26);
        await U.narr(p, ["§f抜け殻の 体が、頁に ほどけた。§7一枚、また 一枚。紙は 光に なって、玉座の まわりを 舞い上がる。", "§7光の 中から、名前が 一つずつ はなれて いく。§f……ノエ。ミナモ。イリア。ヨミ。ハク。§8……数えきれない、名前。"]);
        if (ok(th)) await K.up(p, th, 8);
        await U.narr(p, ["§7セオの 膝の 紙に、§f紫の 一行§7 だけが 残った。§8……インクは まだ、乾いて いない。"], th);
        /* 12 しずかな 終わりの 絵: 空いた 玉座の 段で、相棒が 耳を すませる */
        if (pm && ok(pm.e)) { await K.walkCam(p, pm.e, at(7.6, -0.4), 14); await K.push(p, pm.e, 22, 4.5, 2.2, 0.5); }
        await U.narr(p, [`§7${pal} が 空いた 玉座の 段に 丸く なって、耳を すませた。`, "§8……もう、何も 鳴って いない。"], pm && ok(pm.e) ? pm.e : th0);
        await U.end(p, C, { leave: [th], card: "§7→ 頁が、白く なって いく" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e6", t: "白く なる 頁", free: false, F: ["F28"],
    syn: "日記帳の 頁が 一枚ずつ 白く なって いった。石に なって いた 者たちが、帰りはじめた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 記録塔の 頂", "ash");
        K.fac(p, "u15stair", "u15stair", 99, U.y0(p));
        K.flash(p); K.sound(p, "item.book.page_turn", 1);
        for (let k = 0; k < 10; k++) try { p.dimension.spawnParticle("minecraft:endrod", { x: p.location.x + (k - 5), y: p.location.y + 3 + (k % 3), z: p.location.z + 4 }); } catch {}
        await K.wide(p, 18);
        /*F28 回: 送らなかった 名前が 帰る */
        await U.narr(p, ["§f塔の 頁が、一枚ずつ 白く なって いった。§7……名前が 紙から 浮かび上がり、光の 糸に なって 空へ のびて いく。", "§8死者と 書かれなかった 名前たちが、帰り道を 思い出して いく。"]);
        const u11 = K.ch(p, "u11"), u09 = K.ch(p, "u09");
        await U.narr(p, [u11 === "a" ? "§7三千年前の 都は、朝の 光の 中で 砂に なり、白い 頁の 中へ 消えた。" : "§7三千年前の 都は、白い 頁の 中に、石の 都の まま 残った。§8……いつか、訪ねて 行ける かもしれない。"]);
        if (u09 === "k" && u11 !== "a") await U.narr(p, ["§8糸の 人形が、あなたの 後ろで 小さく 手を 振った。……ルミナへ 帰るらしい。"]);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        const l = so && ok(so) ? so.location : null; if (l) for (let k = 0; k < 6; k++) try { p.dimension.spawnParticle("minecraft:endrod", { x: l.x, y: l.y + 1 + k * 0.4, z: l.z }); } catch {}
        await U.H(p, V(["{smile,tears}……足もとの 字、消えた。", "{smile}先に 行って、起きて 待ってる。……エンドの 墓標の ところで"], ["{smile,tears}……足もとの 字が、消えたわ。", "{smile}先に 行って、起きて 待ってるわね。……エンドの 墓標の ところで"], ["{smile,tears}……字が 消えた。", "{smile}先に 行って 待ってる。エンドの 墓標で"], ["{smile,tears}……足もとの 字が、消えました。", "{smile}先に 参って、起きて お待ちして います。……エンドの 墓標の ところで"]));
        if (ok(so)) await fade(so, "minecraft:endrod");
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{smile}……へっ。帰ろうぜ。……みんな、待ってる。"], "raise");
        U.flag(p, "stoneBack");
        await U.end(p, C, { card: "§7→ 常世から 戻り、§eさいはての 村 エンド§7 の 墓標へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e7", t: "ちゃんと、起きたよ", free: false, F: ["F30", "F58"], ans: ["qb201"], keys: [],
    syn: "エンドの 鱗の 墓標の 横で、幼なじみの 胸の 穴が 閉じ、目を 開けた。「……ちゃんと、起きたよ」。雲の 島の インクで、手帳の 最後の 頁に 二人の 一行。名前の 頁には、セオの 名も。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "さいはての 村 エンド ― 鱗の 墓標");
        const g = K.fac(p, "u15grave", "u15grave", 9, U.y0(p)), gv = facMark("u15grave", "grave", p.location) || g, bd = facMark("u15grave", "bed", p.location) || g;
        if (gv) await K.at(p, gv, 16, 5, 0.8);
        const h = heroOf(p), hn = U.hn(p);
        const H = h ? C.npc(`§d${hn}`, PJ(h.key, 9), 4, -1.4, 0, "veil") : null; act(H, "prone");
        if (ok(H)) { await K.push(p, H, 22, 4, 1.8, 0.6); try { p.dimension.spawnParticle("minecraft:basic_smoke_particle", H.location); } catch {} }
        await U.narr(p, ["§7墓標の 横に、石の 幼なじみが 眠って いた。§8胸に、小さな 穴。"], H);
        K.sound(p, "block.amethyst_block.chime", 1); for (let k = 0; k < 8; k++) { if (ok(H)) try { p.dimension.spawnParticle("minecraft:endrod", { x: H.location.x, y: H.location.y + 0.5 + k * 0.3, z: H.location.z }); } catch {} await K.wait(3); }
        await U.narr(p, ["§f空から 光の 糸が 一本、降りて きた。§7……胸の 穴が、ゆっくり 閉じた。"]);
        if (ok(H)) { act(H, "kneel"); await K.wait(10); act(H, "up"); await K.up(p, H, 16); }
        await K.say(p, hn, [U.hv(p, V("{closed,…}……ん。", "{closed,…}……ん。", "{closed,…}……ん。", "{closed,…}……ん。"))]);
        await K.say(p, hn, [U.hv(p, V("{smile,tears}……ちゃんと、起きたよ。", "{smile,tears}……ちゃんと、起きたわ。", "{smile,tears}……起きた。ちゃんと。", "{smile,tears}……ちゃんと、起きましたよ。"))]);
        const pm = U.pal(p, C, 6, 1.6); if (pm && ok(pm.e) && ok(H)) { await K.approach(p, pm.e, H, 1.2, 12); K.re(pm.e, null, "heart"); }
        /*F30・F58 回: 最後の 頁に 雲の 島の インクで 二人の 一行 */
        if (ok(H)) { hold(H, "notebook"); act(H, "show"); K.sound(p, "item.book.page_turn", 1); await K.up(p, H, 10); await K.wait(4); SGK.camNear(p, H, 1.8, 1.5); await K.wait(6); }
        await K.say(p, hn, [U.hv(p, V("{smile}……手帳、持っててくれたんだ。インクも。……雲の 島の おばあさんの インクだ", "{smile}……手帳、持って いて くれたのね。インクも。……雲の 島の おばあさんの インクね", "{smile}……手帳と インク。雲の 島の おばあさんの", "{smile}……手帳を、持って いて くださったのですね。インクも。……雲の 島の おばあさまの インクです"))]);
        await U.narr(p, ["§7最後の 頁に、二人で 一行ずつ 書いた。§f『次は、どこ 行く？』", "§7名前の 頁の いちばん 下の 行には、§aセオ§7 の 名前。"]);
        const u15 = K.ch(p, "u15");
        if (ok(H)) await K.up(p, H, 8);
        await K.say(p, hn, [U.hv(p, u15 === "w" ? V("{smile,closed}……最後の 行、あの 神さまの 名前だ。覚えて いて あげるのも、迎える ことだよね", "{smile,closed}……最後の 行は、あの 神さまの 名前ね。覚えて いて あげるのも、迎える ことよね", "{smile,closed}……最後の 行は、あの 神の 名前。覚えて おくのも、迎える こと", "{smile,closed}……最後の 行は、あの 神さまの お名前ですね。覚えて いて さしあげるのも、お迎えする ことですね") : V("{closed}……一行、あいてる。……おやすみ", "{closed}……一行、あいてるのね。……おやすみ", "{closed}……一行 あいてる。おやすみ", "{closed}……一行、あいて います。……おやすみなさい"))]);
        if (ok(H)) { hold(H, "compass"); act(H, "hold"); }
        await U.narr(p, ["§7首の コンパスを、持ち主の 首へ 返した。§8……針は、まっすぐ 北を 指して いる。"], H);
        U.drop(p, "k_compass"); U.drop(p, "k_ink");
        const mu = U.mu(C, 3, 2); await K.up(p, mu, 8);
        await U.M(p, mu, [`{closed}……${hn}。体の ほうとは、はじめましてだな。`, "{smile}ムサシだ。……三度 言っとくか？"], "hold");
        await K.say(p, hn, [U.hv(p, V("{smile,♪}一回で いいよ。声、覚えてるもん", "{smile}一回で いいわ。声、覚えて いるもの", "{smile}一回で いい。声は 覚えてる", "{smile}一回で 結構です。お声、覚えて いますから"))]);
        if (!K.replay(p)) { const dd = load(p); if (dd) { const s = qs(dd); s.techo = [...new Set([...(s.techo || []), hn, "セオ"])]; save(p, dd); } }
        await U.end(p, C, { card: "§7→ §eほたるの 里 ルミエ§7 の 小川へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e8", t: "おかえり（各地）", free: false, F: ["F20", "F06", "F10", "F52", "F68", "F37", "F56"],
    syn: "ルミエの 小川で、セオが 弟の 名を はじめて 声に 出した。「……ノエ」。コラリアでは 姉妹が 紐の 最後の 一目を 結び、ナギサの 笛で 母を 呼んだ。沈んだ 神殿から ミナモが 浮かんだ。ソウラでは イリアが 戻り、アルゴが 仮面を 外した まま 泣いた。ヨミも 戻った。セプルクでは 幕の 上がった 舞台で 一座が 動きだし、袖に ベリルが いた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "ほたるの 里 ルミエ ― 小川", "night");
        const b = K.fac(p, "u15brook", "u15brook", 17, U.y0(p)), bq = facMark("u15brook", "brook", p.location) || b;
        if (bq) await K.at(p, bq, 16, 5, 0.4);
        const T = C.npc("§aセオ", 18, 3, -1.8, 0, "walk"); act(T, "hold");
        const B = C.npc("§fノエ", PJ("m6_sota", 9), 5, 1.2, 0, "veil"); act(B, "up");
        if (ok(B)) { await K.push(p, B, 18, 4, 1.6, 1); fx(p.dimension, "minecraft:basic_smoke_particle", B.location, 8, 0.6); }
        await U.narr(p, ["§7小川の 前の 石の 少年に、ひびが 走った。§f……灰色の 下から、小さな 指が 動いた。"], B);
        if (ok(T)) { act(T, "kneel"); await K.up(p, T, 12); }
        /*F20・F06 回: 書けるのに 呼べなかった 名を、声に */
        await U.say(p, "セオ", ["{closed,…}……ノ、", "{cry,tears,up}……ノエ。"]);
        await U.say(p, "ノエ", ["{smile,?,up}……にいちゃん？ ……本、よんで。"], T);
        if (ok(T)) await K.up(p, T, 8);
        await U.say(p, "セオ", ["{closed,tears}……十二年、一日も 忘れられなかった。……忘れなくて、よかった"]);
        if (ok(T)) { hold(T, "lantern"); await K.up(p, T, 8); }
        await U.narr(p, ["§7セオは 腰の 白い 灯籠を はずし、火を 入れない まま 小川の そばに 置いた。§8……送らなくて、よかった。"], T);
        const ch = (id) => K.ch(p, id), card = async (t) => { K.flash(p, false); await K.wait(8); K.card(p, `§7― ${t} ―`, 60); await K.wait(10); };
        const pop = (nm, skin, side) => { const e = C.npc(nm, PJ(skin, 8), 4, side, 0, "walk"); return e; };
        /* コラリア */
        await card("さんごの 町 コラリア");
        { const M = pop("§3マリン", "marin", -1), N = pop("§6ナギサ", "nagisa", 1); hold(M, "rope"); hold(N, "rope"); act(M, "hold"); act(N, "hold");
          if (ok(M)) await K.up(p, M, 10);
          /*F10 回: 姉妹が 紐の 最後の 一目 */
          await U.narr(p, ["§7ほどきかけだった 紐の 最後の 一目を、姉と 妹が いっしょに 結んだ。"], M);
          if (ok(M) && ok(N)) K.turn(M, N.location);   /* 妹と 結んだ 紐を 見せあう */
          await U.say(p, "マリン", ["{smile,tears,up}……できた。おっとうの 編み目と、わたしたちの 編み目。"], N); K.turn(M, null);
          if (ok(N)) { hold(N, "flute"); await K.up(p, N, 8); }
          /*F52・F68 回: 笛で 母を 呼ぶ／ミナモが 浮かぶ */
          await U.narr(p, [ch("c07") === "n" ? "§7ナギサが 傷あとの 残る 手で、海神の 貝笛を 吹いた。" : "§7ナギサが、海神の 貝笛を 吹いた。", "§f……沈んだ 神殿の 上に、白い 泡が のぼり、§bミナモ§f が 水面へ 浮かんだ。"], N);
          await U.say(p, "ナギサ", ["{cry,tears,up}……おっかあ。……おかえり。"]);
          await SGK.bye(p, M, N); }
        /* ソウラ */
        await card("たましいの 町 ソウラ");
        { const Mo = pop("§5冥王 モルテ", "morte", -1.2), A = pop("§4アルゴ", "argo", 1.2), Y = pop("§bヨミ", "yomi", 0);
          if (ok(Mo)) await K.up(p, Mo, 8);
          await U.say(p, "モルテ", ["{smile,tears,up}……イリア。おかえり。……赤い 灯籠を、流して おいたぞ。"], A);
          /*F37 回: 仮面を 外した アルゴが 泣く */
          if (ok(A)) { act(A, "kneel"); await K.up(p, A, 10); }
          await U.narr(p, ["§7仮面の ない 顔で、アルゴが ひざを ついた。§f……はじめて、声を 上げて 泣いた。"], A);
          if (ok(Y)) await K.up(p, Y, 8);
          await U.say(p, "ヨミ", ch("c08") === "y" ? ["{smile,up}……一番に 起こして くれたのね。ソウラの みんなを 連れて、エンドへ 行くわ"] : ["{smile,?,up}……セオは？ ……あの 人、ちゃんと 帰って きた？"]);
          await SGK.bye(p, Mo, A, Y); }
        /* セプルク */
        await card("ぼひょうの 町 セプルク");
        { const Be = pop("§7ベリル", "beryl", 1.2), Tr = pop("", "m6_paolo", -1.2); act(Tr, "cheer");
          /*F56 回: 幕の 上がった 舞台の 一座が 動きだす */
          await K.wide(p, 12);
          await U.narr(p, ["§7幕の 上がった 舞台で、石の 一座が 動きだした。§8台本を 抱いた 子の 空いて いた 場所に、袖から ベリルが 歩いて 出た。"], Be);
          await U.say(p, "ベリル", ["{smile,tears}……覚えてて くれた 人が いた。……それで、十分。"]);
          await SGK.bye(p, Be, Tr); }
        /* ヘイムダル（C10 d）・ラヴィ（U04）*/
        if (ch("c10") === "d") { await card("フロストヘイム ヘイムダル城"); const Hm = pop("§bヘイム王", "heim", 0); if (ok(Hm)) await K.up(p, Hm, 8); await U.say(p, "ヘイム", ["{closed,up}……『この 国が、このまま』と 願った 王は、もう 石では ない。……春を 待つ 王に なろう"]); await SGK.bye(p, Hm); }
        await card("ようがんの 里 ラヴィ");
        { const Va = pop("§cヴァルカ", "valka", 0); if (ok(Va)) await K.up(p, Va, 8);
          await U.say(p, "ヴァルカ", ch("u04") === "v" ? ["{smile}……火祭りの 守り刀に した。結びは、打てた。……アンタの おかげだよ"] : ["{closed}……結びは、まだだ。何年 かかっても いい。アタシの 手で 打つ"]);
          await SGK.bye(p, Va); }
        U.drop(p, "k_shell");
        await U.end(p, C, { leave: [T], card: "§7→ §e始まりの町 ルミナ§7 の 牧場へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e9", t: "屋根の ある 所", free: false, F: ["F12", "F11", "F18"],
    syn: "闘技場の 下で、錠の 座の 人が 息を 吐いて 立ち上がった。客席の 上で、その 名を 三度 呼ぶ 声。牧場では ハクが 割れて 白い 毛。ピコ「ここ、屋根、あるね」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        const ch = (id) => K.ch(p, id), z = ch("c20") !== "o";
        K.flash(p, false); await K.wait(6); K.card(p, "§7― ルミナの 闘技場の 下 ―", 60);
        await K.open(p, "始まりの町 ルミナ ― 牧場");
        K.fac(p, "u15ranch", "u15ranch", 0, U.y0(p));
        /*F11・F12 回: 錠の 座の 人が 立ち、客席が 名を 三度 呼ぶ */
        { const S = z ? C.npc("§6ゼファード", PJ("zephard", 9), 4, 0, 0, "veil") : C.npc("§eオルド", PJ("ordo", 8), 4, 0, 0, "veil"); act(S, "up");
          if (ok(S)) await K.up(p, S, 14);
          await U.narr(p, [z ? "§7錠の 座で、石の ゼファードが §f二十年分の 息§7 を 吐いて、立ち上がった。" : "§7錠の 座で、石の オルドが §fひと月分の 息§7 を 吐いて、立ち上がった。"], S);
          for (let k = 0; k < 3; k++) { K.sound(p, "random.levelup", 0.3, 0.6 + k * 0.1); await K.wait(12); }
          await U.narr(p, [`§f客席の 上で、だれかが §e${z ? "ゼファード" : "オルド"}§f の 名を 三度 呼んだ。`]);
          if (z) { const M = C.npc("§3マリン", PJ("marin", 9), 4.6, -1.6, 0, "walk"), N = C.npc("§6ナギサ", PJ("nagisa", 9), 4.6, 1.6, 0, "walk"); hold(M, "rope"); if (ok(M)) await K.up(p, M, 8); if (ok(M) && ok(S)) K.turn(M, S.location); await U.say(p, "マリン", ["{smile,tears,up}……おっとう。紐、わたしたちで 結んだ。……最後の 一目、見て"], S); K.turn(M, null); await U.say(p, "ゼファード", ["{closed,tears}……ああ。……星の 名じゃ なくて、海の 名だ。いい 名を もらったな"]); await SGK.bye(p, M, N); }
          else await U.say(p, "オルド", ["{smile,汗}……ほっほ。ひと月 座っとったら、腰が 石みたいじゃ"]);
          await SGK.bye(p, S); }
        K.flash(p, false); await K.wait(6); K.card(p, "§7― オルドの 牧場 ―", 50);
        const pen = facMark("u15ranch", "pen", p.location);
        const Hk = C.mon(SPECIES.hbea14 ? "hbea14" : "hbea01", 5, 0.6, 0, "smoke"), Pc = C.npc("§dピコ", PJ("pico", 8), 4, -1.4, 0, "veil"), G = C.npc("§7ガロ", PJ("garo", 9), 3.4, -2.6, 0, "walk");
        act(Pc, "down"); if (ok(Hk)) try { Hk.nameTag = "§7ハク（石）"; } catch {}
        if (ok(Hk)) await K.up(p, Hk, 12);
        K.sound(p, "random.break", 1); K.shake(p, 0.25, 0.4); await K.wait(10); if (ok(Hk)) { fx(p.dimension, "minecraft:totem_particle", Hk.location, 16, 1); try { Hk.nameTag = "§fハク"; } catch {} }
        await U.narr(p, ["§fハクの 背中の 灰色が、ひびの ように 割れて 落ちた。§7その 下から、§f白い 毛§7。"], Hk);
        if (!z) await U.narr(p, ["§7ハクが、オルドより 先に 起きて、帰って きた オルドの 胸に 鼻を 押しつけた。§8……『遅いわい』と 言われる 番が、まわって きた。"]);
        /*F18 回: ピコが 起きる */
        if (ok(Pc)) { act(Pc, 0); await K.up(p, Pc, 10); }
        if (ok(Pc) && ok(G)) K.turn(Pc, G.location);   /* 目を 開けて、まず ガロを 探す */
        await U.say(p, "ピコ", ["{closed,…}……兄ちゃん？", "{shock,?}……ここ、どこ？ 屋根、ある ね"], G); K.turn(Pc, null);
        if (ch("c01") === "k") { await U.narr(p, ["§7あなたは 小さな 帽子を、ピコの 頭に かぶせた。§8ガロは 黙って、深く 頭を 下げた。"], Pc); U.drop(p, "k_cap"); }
        else { if (ok(G)) await K.approach(p, G, Pc, 1.2, 12); await U.narr(p, ["§7ガロは 何も 言わずに、腰から 帽子を 外して、ピコの 頭に 深く かぶせた。"], G); }
        if (ch("c06") === "t") { const Ga = C.npc("§6ガンテツ", PJ("m6_gramps", 8), 6, 2.6, 0, "walk"); if (ok(Ga)) await K.up(p, Ga, 8); await U.say(p, "ガンテツ", ["{closed}……帰る 場所は、明るく しといた。……来い"], G); await SGK.bye(p, Ga); }
        else await U.narr(p, ["§8……しばらくして、ガロは 一人で、グロウの 方へ 歩いて いった。遠い 背中。"], G);
        if (ch("u09") === "k" && ch("u11") !== "a") await U.narr(p, ["§7ルミナの 門の 案内人の 腕に、§fあの 人形§7 が 戻って いた。§8……今度は、ちゃんと 足音を 立てて 来たらしい。"]);
        K.flash(p, false); await K.wait(6); K.card(p, "§7― さいはての 村 エンド ―", 40);
        await U.narr(p, ["§fレイの 竜が、大きな §eあくび§f を した。"]);
        await U.end(p, C, { card: "§7→ §eはがねの 村 クロガネ§7 の 工房へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u15e10", t: "封じない 鍔", free: false, F: ["F42", "F41"], keys: ["k_trec"],
    syn: "クロガネの 工房で、サヤが 目を 覚ました。「兄さま、おなか すいた」。ムサシは 封じる ためでは ない 鍔を 打ち、柱の 刻みの 最後に 一本 足した。セオは「嘘を 書かない 記録」を 書きあげて、主人公に 渡した。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "はがねの 村 クロガネ ― 工房");
        const f = K.fac(p, "u15forge", "u15forge", 3, U.y0(p)), an = facMark("u15forge", "anvil", p.location) || f, po = facMark("u15forge", "post", p.location) || f, bd = facMark("u15forge", "bed", p.location) || f;
        if (bd) await K.at(p, bd, 14, 4, 0.6);
        const sy = C.npc("§dサヤ", PJ("sayo", 9), 4.2, 1.6, 0, "veil"); act(sy, "prone");
        if (ok(sy)) { await K.push(p, sy, 18, 3.5, 1.6, 0.6); fx(p.dimension, "minecraft:endrod", sy.location, 10, 0.6); }
        await U.narr(p, ["§7工房の 奥の 石の 寝台で、千年 眠って いた 少女の 指が、動いた。"], sy);
        if (ok(sy)) { act(sy, "up"); await K.up(p, sy, 12); }
        await U.say(p, "サヤ", ["{closed,…}……ん。", "{smile,?,up}……兄さま、おなか すいた。"]);
        const mu = U.mu(C), hn = U.hn(p), h = heroOf(p), H = h ? C.npc(`§d${hn}`, PJ(h.key, 9), 2.4, -1.8, 0, "walk") : null;
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{shock,汗}……千年ぶりの 第一声が それか。", "{smile,tears}……飯、炊く。待ってろ。"], "hold");
        /*F42・F41 回: 柱の 最後の 一本・封じない 鍔 */
        if (ok(mu) && an) await K.walkCam(p, mu, an, 16);
        act(mu, "work"); hold(mu, "hammer"); for (let k = 0; k < 3; k++) { K.sound(p, "random.anvil_use", 0.6, 1 + k * 0.05); await K.wait(10); }
        await U.narr(p, ["§7ムサシは 炉に 火を 入れ、§e封じる ためでは ない 鍔§7 を 打った。§8帳の 王の 座に 供える ための 鍔。"], mu);
        await U.M(p, mu, K.ch(p, "u04") === "v" ? ["{closed}……型なんか いらねえ。音で いい。"] : ["{closed}……型どおりに 打つ。けど 最後の 一打は、音で 決める。"], "work");
        hold(mu, 0); if (ok(mu) && po) await K.walkCam(p, mu, po, 14);
        if (po) await K.push(p, po, 18, 3, 1.3, 0.4);
        await U.narr(p, ["§7工房の 柱。千年分の 朝の 刻み。§fムサシは その 最後に、一本 足した。"], po);
        await U.M(p, mu, ["{closed}……親父。今日の ぶんだ。……もう、叩きに 来なくて いい 朝だ。"], "kneel");
        /* ムサシ と 幼なじみ */
        if (ok(H)) await K.two(p, mu, H, 10);
        await U.M(p, mu, ["{?}……おい、手帳の 持ち主。あの 柱の 横の 札、声に 出して 読んで くれ。"], "point");
        if (ok(H)) await K.say(p, hn, [U.hv(p, V("{smile}……『サヤ。毎朝 一度』。……お父さんの 字だね", "{smile}……『サヤ。毎朝 一度』。……お父さまの 字ね", "{smile}……『サヤ。毎朝 一度』。父親の 字", "{smile}……『サヤ。毎朝 一度』。……お父さまの 字ですね"))], mu);
        await U.M(p, mu, ["{smile,tears}……ああ。それなら 本物だ。"], "nod");
        if (ok(H)) await K.say(p, hn, [U.hv(p, V("{smile,♪}ムサシ、字 教えて あげようか？", "{smile}ムサシ、字を 教えて あげましょうか？", "{smile}ムサシ。字、教える？", "{smile}ムサシさん、字を お教え しましょうか？"))], mu);
        await U.M(p, mu, ["{closed}……いらねえ。お前が 読めば 足りる。", "{smile}……けど、サヤの 名前だけは、そのうち 頼む。"], "arms");
        /* セオの「嘘を 書かない 記録」（裏の 後の 試練で 要る）*/
        const T = C.npc("§aセオ", 18, 5, -2.4, 0, "walk"); hold(T, "notebook");
        if (ok(T)) await K.up(p, T, 12);
        await U.say(p, "セオ", ["{closed}……書きあげたよ。千年前の 王が、自ら 錠に なった こと。友が それを 斬って 閉じた こと。……嘘は 一行も 書いて いない"], mu);
        if (ok(T)) await K.ots(p, mu, T, 8);
        await U.say(p, "セオ", ["{sad,up}『嘘を 書かない 記録』だ。……王を 怪物と 書いた 記録に 怒って いる ものが、まだ どこかに いる。そのとき、これが 要る。君が 持って いて くれ"], mu);
        if (ok(T)) { act(T, "give"); await K.wait(10); act(T, 0); hold(T, 0); }
        if (!K.key(p, "k_trec") && !K.replay(p)) { const dd = load(p); if (dd) { const s = qs(dd); s.truebook = 1; save(p, dd); } }
        await U.narr(p, ["§e『嘘を 書かない 記録』§f を 受けとった。"]);
        await U.E(p, mu, ["……字は、書いた 者が 死んでも 残る。……だから 書く 者は、嘘を 書いては ならぬ。……よく 書いた"]);
        await U.c20(p);
        await U.end(p, C, { card: "§b§l裏の 物語 おわり §r§7― 神の 石板が、静かに ひらいた" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(15, ["u15e1", "u15e2", "u15e3", "u15e4"], ["u15e5", "u15e6"], { ret: (p) => { const i = INFO.get(p.id) || finInfo(p); INFO.delete(p.id); return i; } });

/* 7〜10話: 常世を 終えた あとの 各地（自由な 話の 列には 入れない。bk_u08.js の AFTER）*/
const OUT = "§7（常世に いる ときは、キャンプの「元の 世界へ もどる」）";
AFTER.push(
  { id: "u15e7", hint: `§fさいはての 村 エンドの §e鱗の 墓標§f へ 行こう ${OUT}`, place: () => { const o = townOut("t27", 0.6, "鱗の 墓標"); return o ? { ...o, nm: "さいはての 村 エンドの 鱗の 墓標" } : null; } },
  { id: "u15e8", hint: `§fほたるの 里 ルミエの §e小川§f へ 行こう ${OUT}`, place: () => { const o = townOut("t17", 0.4, "小川"); return o ? { ...o, nm: "ほたるの 里 ルミエの 小川" } : null; } },
  { id: "u15e9", hint: `§f始まりの町 ルミナの §eオルドの 牧場§f へ 行こう ${OUT}`, place: () => ranchSpot() },
  { id: "u15e10", hint: `§fはがねの 村 クロガネの §e工房§f へ 行こう ${OUT}`, place: () => bldOf("t42", ["forge"], "クロガネの 工房") || townOut("t42", 0.5, "工房") },
);
