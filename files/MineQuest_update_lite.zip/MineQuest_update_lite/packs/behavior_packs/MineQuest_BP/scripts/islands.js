// 第104版: 遊び場の 浮島。ガイドブック →「遊び場へ 行く」で 島を えらぶと 転送。島の 赤い 台で もとの 場所へ 帰る
// 島は 7つ。1つずつ 空に 間を あけて 浮かぶ（壁は なし。落ちたら 入口へ もどす）。はじめて 行く ときに その 島だけ 建てる
// 遊び: どの 島でも ボールを 投げると 相棒が 取って くる・運動場の 島で かけっこ（相棒と 競争）・広場の 島で 相撲
import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";
import { load } from "./store.js";
import { SPECIES } from "./data.js";
import { notice, choose, ICON, barNote, showTitle, EXH, sound, anim, busy } from "./ui.js";
import { inDungeon } from "./dungeon.js";
import { inRuins } from "./ruinsarea.js";
import { findPet, spawnPet, hooks, setLook, TYPE } from "./field.js";
import { HIT_HOOKS, inBattle } from "./battle.js";

const OWID = "minecraft:overworld", OW = () => world.getDimension(OWID);
const run = (c) => { try { OW().runCommand(c); return true; } catch { return false; } };
const bk = (...ids) => { for (const id of ids) { try { BlockPermutation.resolve(`minecraft:${id}`); return id; } catch {} } return "stone"; };
const wait = (t) => new Promise((r) => system.runTimeout(r, Math.max(1, t)));
const title = (p, t, s = "") => showTitle(p, t, { subtitle: s, fadeInDuration: 0, stayDuration: 50, fadeOutDuration: 10 });
const R = 22;   /* 島の 半径 */

export const ISLES = [
  ["track", "運動場の 島", "トラックと 観客席"], ["pool", "プールの 島", "プールと ヤシの 木"], ["maze", "迷路の 島", "生け垣の 迷路"],
  ["park", "アスレチックの 島", "水の 上の 足場"], ["field", "原っぱの 島", "木と 草むらと 花"], ["sand", "砂浜の 島", "砂浜と 流木"], ["stage", "広場の 島", "タイルの 広場と ステージ"],
];
export function isleCenter(k) {   /* 第104版: はじめに 決めた 場所を おぼえる（スポーンを 変えても 島が ずれない）*/
  let o = null; try { const v = world.getDynamicProperty("mrpg:isleO"); if (typeof v === "string") o = JSON.parse(v); } catch {}
  if (!o) { let s = { x: 0, z: 0 }; try { const w = world.getDefaultSpawnLocation(); s = { x: w.x, z: w.z }; } catch {} o = { x: Math.floor(s.x) - 3000, z: Math.floor(s.z) + 3000 }; try { world.setDynamicProperty("mrpg:isleO", JSON.stringify(o)); } catch {} }
  return { x: o.x + k * 100, y: globalThis.__PG_Y ?? 230, z: o.z };
}
const entry = (k) => { const c = isleCenter(k); return { x: c.x + 0.5, y: c.y, z: c.z - R + 4.5 }; };
const exitPad = (k) => { const c = isleCenter(k); return { x0: c.x + 6, z0: c.z - R + 3, x1: c.x + 8, z1: c.z - R + 5, y: c.y }; };
const inBox = (l, b) => l.x >= b.x0 && l.x < b.x1 + 1 && l.z >= b.z0 && l.z < b.z1 + 1 && Math.abs(l.y - b.y) < 2.5;
const isleAt = (l) => { for (let k = 0; k < ISLES.length; k++) { const c = isleCenter(k); if (Math.abs(l.x - c.x) <= 40 && Math.abs(l.z - c.z) <= 40 && Math.abs(l.y - c.y) < 40) return k; } return -1; };

/* 島の 形: 上は 平ら（半径 R）、下へ いくほど 細く なる 土と 石（横から 見て 浮島らしく）*/
async function shape(c, top) {
  const dirt = bk("dirt"), stone = bk("stone"), y = c.y;
  for (let dy = 1; dy <= 12; dy++) {
    const r = Math.max(2, Math.round(R * Math.cos(Math.min(1.45, dy * 0.12)) - dy * 0.6)), blk = dy <= 2 ? (dy === 1 ? top : dirt) : stone;
    for (let z = -r; z <= r; z++) { const xo = Math.floor(Math.sqrt(Math.max(0, r * r - z * z))); run(`fill ${c.x - xo} ${y - dy} ${c.z + z} ${c.x + xo} ${y - dy} ${c.z + z} ${blk}`); }
    if (dy % 2 === 0) await wait(1);
  }
  for (let z = -R; z <= R; z += 11) { run(`fill ${c.x - R} ${y} ${c.z + z} ${c.x + R} ${y + 10} ${Math.min(c.z + R, c.z + z + 10)} air`); }
}
/* ふちの かざり（円の まわりに 柵・生け垣 など。入口は あける）*/
function rim(c, blk, h = 1, gap = 3) {
  for (let a = 0; a < 360; a += 3) { const r = R - 0.5, x = Math.round(c.x + Math.sin((a * Math.PI) / 180) * r), z = Math.round(c.z + Math.cos((a * Math.PI) / 180) * r); if (z < c.z - R + 6 && Math.abs(x - c.x) <= gap) continue; run(`fill ${x} ${c.y} ${z} ${x} ${c.y + h - 1} ${z} ${blk}`); }
}
function palm(x, y, z) { const log = bk("jungle_log", "log"), leaf = bk("jungle_leaves", "leaves"); run(`fill ${x} ${y} ${z} ${x} ${y + 4} ${z} ${log}`); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) run(`setblock ${x + dx} ${y + 4 - (Math.abs(dx) + Math.abs(dz) > 1 ? 1 : 0)} ${z + dz} ${leaf}`); run(`setblock ${x} ${y + 5} ${z} ${leaf}`); }
function tree(x, y, z) { const log = bk("oak_log", "log"), leaf = bk("oak_leaves", "leaves"); run(`fill ${x} ${y} ${z} ${x} ${y + 3} ${z} ${log}`); run(`fill ${x - 2} ${y + 3} ${z - 2} ${x + 2} ${y + 4} ${z + 2} ${leaf} replace air`); run(`fill ${x - 1} ${y + 5} ${z - 1} ${x + 1} ${y + 5} ${z + 1} ${leaf}`); }
async function build(k) {
  const c = isleCenter(k), y = c.y, key = ISLES[k][0];
  run(`tickingarea add ${c.x - R - 2} 0 ${c.z - R - 2} ${c.x + R + 2} 0 ${c.z + R + 2} mrpg_isle${k}`);
  const loaded = () => [[-R, -R], [R, R], [0, 0]].every(([dx, dz]) => { try { return !!OW().getBlock({ x: c.x + dx, y, z: c.z + dz }); } catch { return false; } });
  for (let t = 0; t < 80 && !loaded(); t++) await wait(5);
  const top = { track: bk("grass_block"), pool: bk("smooth_stone", "stone"), maze: bk("grass_block"), park: bk("grass_block"), field: bk("grass_block"), sand: bk("sand"), stage: bk("smooth_quartz", "quartz_block") }[key] || bk("grass_block");
  await shape(c, top);
  const fence = bk("oak_fence", "fence"), gold = bk("gold_block");
  if (key === "track") {   /* 4レーンの トラック・東に 観客席 */
    run(`fill ${c.x - 6} ${y - 1} ${c.z - 15} ${c.x + 5} ${y - 1} ${c.z + 15} ${bk("red_terracotta", "hardened_clay")}`);
    for (let i = 0; i <= 4; i++) run(`fill ${c.x - 6 + i * 3} ${y - 1} ${c.z - 15} ${c.x - 6 + i * 3} ${y - 1} ${c.z + 15} ${bk("white_concrete", "concrete")}`);
    for (let s = 0; s < 3; s++) run(`fill ${c.x + 9 + s} ${y + s} ${c.z - 10} ${c.x + 9 + s} ${y + s} ${c.z + 10} ${bk("spruce_stairs", "oak_stairs")} ["weirdo_direction"=1]`);
    for (let s = 0; s < 3; s++) run(`fill ${c.x + 9 + s} ${y} ${c.z - 10} ${c.x + 9 + s} ${y + s - 1} ${c.z + 10} ${bk("spruce_planks", "planks")}`);
    run(`fill ${c.x - 6} ${y - 1} ${c.z + 14} ${c.x + 5} ${y - 1} ${c.z + 14} ${gold}`); run(`fill ${c.x - 6} ${y - 1} ${c.z - 14} ${c.x + 5} ${y - 1} ${c.z - 14} ${bk("black_concrete", "concrete")}`);   /* 第104版: 金の スタート・黒の 折り返し */
    rim(c, fence);
  }
  if (key === "pool") {
    run(`fill ${c.x - 7} ${y - 3} ${c.z - 12} ${c.x + 7} ${y - 1} ${c.z + 12} ${bk("light_blue_concrete", "concrete")}`); run(`fill ${c.x - 6} ${y - 2} ${c.z - 11} ${c.x + 6} ${y - 1} ${c.z + 11} water`);
    for (const [dx, dz] of [[-12, -8], [12, -6], [-11, 9], [13, 8]]) palm(c.x + dx, y, c.z + dz);
    run(`fill ${c.x - 6} ${y - 1} ${c.z + 13} ${c.x + 6} ${y - 1} ${c.z + 13} ${gold}`);   /* 第104版: 水泳の スタート */
    rim(c, bk("stone_brick_wall", "cobblestone_wall"));
  }
  if (key === "maze") { buildMaze(c); rim(c, bk("moss_block", "leaves"), 2); }
  if (key === "park") { run(`fill ${c.x - 4} ${y - 3} ${c.z - 14} ${c.x + 4} ${y - 1} ${c.z + 16} water`); for (const [i, q] of PARK_ST.entries()) run(`setblock ${c.x + q[0]} ${y - 1 + q[2]} ${c.z + q[1]} ${bk(q[2] ? "oak_log" : "mossy_stone_bricks", "stone")}`); run(`fill ${c.x - 5} ${y} ${c.z - 14} ${c.x - 5} ${y} ${c.z + 16} ${fence}`); run(`fill ${c.x + 5} ${y} ${c.z - 14} ${c.x + 5} ${y} ${c.z + 16} ${fence}`); run(`fill ${c.x - 1} ${y - 1} ${c.z - 15} ${c.x + 1} ${y - 1} ${c.z - 15} ${gold}`); run(`fill ${c.x - 2} ${y - 1} ${c.z + 18} ${c.x + 2} ${y - 1} ${c.z + 18} ${gold}`); rim(c, fence); for (const [dx, dz] of [[-14, 0], [14, 0]]) { run(`fill ${c.x + dx} ${y} ${c.z + dz} ${c.x + dx} ${y + 3} ${c.z + dz} ${fence}`); run(`setblock ${c.x + dx} ${y + 3} ${c.z + dz + 1} ${bk("red_wool", "wool")}`); } }
  if (key === "field") { for (const [dx, dz] of [[-10, -5], [9, -7], [-6, 10], [11, 9], [0, 15], [-14, 4]]) tree(c.x + dx, y, c.z + dz); for (let n = 0; n < 40; n++) { const a = n * 2.4, r = 3 + (n * 7) % 17, x = Math.round(c.x + Math.cos(a) * r), z = Math.round(c.z + Math.sin(a) * r); run(`setblock ${x} ${y} ${z} ${["poppy", "dandelion", "oxeye_daisy", "cornflower"].map((f) => bk(f, "red_flower"))[n % 4]} replace air`); } run(`fill ${c.x - 5} ${y - 1} ${c.z - 15} ${c.x - 4} ${y - 1} ${c.z - 14} ${bk("lime_concrete", "concrete")}`); run(`fill ${c.x + 4} ${y - 1} ${c.z - 15} ${c.x + 5} ${y - 1} ${c.z - 14} ${bk("purple_concrete", "concrete")}`); rim(c, fence); }
  if (key === "sand") { for (const [dx, dz, l] of [[-9, 6, 4], [8, -9, 3], [12, 7, 5]]) run(`fill ${c.x + dx} ${y} ${c.z + dz} ${c.x + dx + l} ${y} ${c.z + dz} ${bk("stripped_oak_log", "log")}`); for (const [dx, dz] of [[-15, -6], [14, -2], [-4, 15]]) run(`fill ${c.x + dx} ${y} ${c.z + dz} ${c.x + dx + 1} ${y + 1} ${c.z + dz + 1} ${bk("mossy_cobblestone", "cobblestone")}`); for (const [dx, dz] of [[-12, 12], [12, -13]]) palm(c.x + dx, y, c.z + dz); run(`fill ${c.x - 1} ${y - 1} ${c.z - 15} ${c.x + 1} ${y - 1} ${c.z - 14} ${bk("orange_concrete", "concrete")}`); }
  if (key === "stage") {   /* 第104版: まん中に 土俵 */
    run(`fill ${c.x - 6} ${y - 1} ${c.z - 6} ${c.x + 6} ${y - 1} ${c.z + 6} ${bk("smooth_quartz", "quartz_block")}`);
    for (let z = -5; z <= 5; z++) { const xo = Math.floor(Math.sqrt(Math.max(0, 25 - z * z))); run(`fill ${c.x - xo} ${y - 1} ${c.z + z} ${c.x + xo} ${y - 1} ${c.z + z} ${bk("sandstone", "sand")}`); }
    for (let a = 0; a < 360; a += 6) { const x = Math.round(c.x + Math.sin((a * Math.PI) / 180) * 5), z = Math.round(c.z + Math.cos((a * Math.PI) / 180) * 5); run(`setblock ${x} ${y - 1} ${z} ${bk("hay_block", "sandstone")}`); }
    rim(c, bk("white_concrete", "concrete")); }
  if (key === "stage_old") { for (let i = 0; i < 9; i++) { const col = i % 3, row = Math.floor(i / 3), x = c.x - 7 + col * 5, z = c.z - 6 + row * 5; run(`fill ${x} ${y - 1} ${z} ${x + 3} ${y - 1} ${z + 3} ${bk(["white", "light_gray", "white", "light_gray", "white", "light_gray", "white", "light_gray", "white"][i] + "_concrete", "concrete")}`); } run(`fill ${c.x - 4} ${y} ${c.z + 12} ${c.x + 4} ${y} ${c.z + 15} ${bk("quartz_block", "stone")}`); for (const dx of [-4, 4]) run(`fill ${c.x + dx} ${y + 1} ${c.z + 15} ${c.x + dx} ${y + 4} ${c.z + 15} ${bk("quartz_pillar", "quartz_block")}`); rim(c, bk("white_concrete", "concrete")); }
  /* 入口の 石畳と 帰りの 赤い 台 */
  run(`fill ${c.x - 2} ${y - 1} ${c.z - R + 2} ${c.x + 2} ${y - 1} ${c.z - R + 6} ${bk("stone_bricks", "stone")}`); run(`fill ${c.x - 2} ${y} ${c.z - R + 2} ${c.x + 2} ${y + 1} ${c.z - R + 6} air`);
  const E = exitPad(k); run(`fill ${E.x0} ${y - 1} ${E.z0} ${E.x1} ${y - 1} ${E.z1} ${bk("red_concrete", "concrete")}`);
  await wait(4);
  run(`tickingarea remove mrpg_isle${k}`);
  const ok = (() => { try { const b = OW().getBlock({ x: c.x, y: y - 1, z: c.z }); return b && !b.isAir; } catch { return false; } })();
  if (ok) try { world.setDynamicProperty(`mrpg:isle${k}`, 2); } catch {}   /* 第104版: 遊びの しかけを 足したので 2 */
  return ok;
}
let LOCK = null;
async function ready(k) {
  while (LOCK) { try { await LOCK; } catch {} }
  if (world.getDynamicProperty(`mrpg:isle${k}`) === 2) return true;
  let done; LOCK = new Promise((r) => (done = r));
  try { return (await build(k)) || (await build(k)); } finally { LOCK = null; done(); }
}

// ---------- 行く・帰る ----------
const inIsleMode = (p) => { try { return typeof p.getDynamicProperty("mrpg:pret") === "string"; } catch { return false; } };
export async function goIsle(p, k) {
  try { barNote(p).setActionBar("§e島を 準備中…（はじめての 島は 少し 待つ）"); } catch {}
  if (!(await ready(k))) { await notice(p, "遊び場", "§c島を 準備できなかった。少し たってから もう一度。"); return false; }
  try { if (!inIsleMode(p)) p.setDynamicProperty("mrpg:pret", JSON.stringify({ x: p.location.x, y: p.location.y, z: p.location.z, dim: p.dimension.id })); } catch {}
  try { const pet = findPet(p); if (pet) pet.remove(); } catch {}
  try { const n = EXH.stowAll ? EXH.stowAll(p) : 0; if (n) p.sendMessage(`§7持ち物の 道具 ${n}こを バッグに しまった（ガイドブック → バッグ から 出せる）`); } catch {}   /* 第104版: 遊び場では 道具は バッグへ */
  giveBall(p);
  try { p.addEffect("resistance", 100, { amplifier: 4, showParticles: false }); p.teleport(entry(k), { dimension: OW(), facingLocation: isleCenter(k) }); } catch {}
  title(p, `§e${ISLES[k][1]}`, "§f赤い 台で もとの 場所へ 帰る");
  return true;
}
export function leaveIsle(p) {
  let r; try { r = p.getDynamicProperty("mrpg:pret"); } catch { return; }
  if (typeof r === "string") try { const o = JSON.parse(r); p.teleport({ x: o.x, y: o.y, z: o.z }, { dimension: world.getDimension(o.dim) }); } catch {}
  try { p.setDynamicProperty("mrpg:pret", undefined); } catch {}
  endPlay(p);
  system.runTimeout(() => { try { const d = load(p); const m = d && d.out && [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out); if (m && !findPet(p)) spawnPet(p, m); } catch {} }, 10);
}
hooks.petHold = ((prev) => (p) => (prev && prev(p)) || inIsleMode(p))(hooks.petHold);
/* 島に いる 人だけ 見る（1秒に 2回）: 赤い 台・落ちた とき・島を はなれた とき */
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (!inIsleMode(p)) continue;
    try {
      const l = p.location, kk = p.dimension.id === OWID ? isleAt({ ...l, y: isleCenter(0).y }) : -1;
      if (kk < 0) { p.setDynamicProperty("mrpg:pret", undefined); endPlay(p); continue; }   /* ワープ・死んで 島を はなれた ときは 記録を 消すだけ */
      const c = isleCenter(kk);
      if (l.y < c.y - 8) { p.addEffect("slow_falling", 60, { showParticles: false }); p.teleport(entry(kk), { facingLocation: c }); continue; }
      if (inBox(l, exitPad(kk))) { leaveIsle(p); continue; }
      const E = exitPad(kk); if (Math.random() < 0.3) OW().spawnParticle("minecraft:basic_flame_particle", { x: E.x0 + 1.5, y: c.y + 0.4, z: E.z0 + 1.5 });
    } catch {}
  }
}, 10);
world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => { if (!initialSpawn) return; system.runTimeout(() => { try { if (inIsleMode(player)) leaveIsle(player); } catch {} }, 80); });

// ---------- 入口（ガイドブック → 冒険 →「遊び場へ 行く」）----------
export async function isleMenu(p) {
  if (inIsleMode(p)) { leaveIsle(p); return; }
  if (inDungeon(p) || inBattle(p) || (() => { try { return inRuins(p.location); } catch { return false; } })()) { await notice(p, "遊び場", "§7石板・遺跡の 中や 戦いの 間は 行けない。外に 出てから 行こう。"); return; }   /* 第104版 */
  try { if (p.getComponent("minecraft:riding")?.entityRidingOn) { await notice(p, "遊び場", "§7ライドから おりて から 行こう。"); return; } } catch {}
  const c = await choose(p, "遊び場へ 行く", "§f行きたい 島を えらぶと そこへ 転送。§7島の 赤い 台で もとの 場所へ 帰る", [...ISLES.map((x) => [`§l${x[1]}\n§8${x[2]}`, ICON("i_run")]), ["§7戻る", ICON("i_back")]]);
  if (c < 0 || c >= ISLES.length) return;
  await goIsle(p, c);
}
EXH.isle = isleMenu;
export const __isle = { ISLES, isleCenter, entry, exitPad, ready, build, goIsle, leaveIsle, isleAt };

// ================= 第104版: 遊び（ボール・かけっこ・相撲）=================
/* 遊び相手は 相棒の 写し（連れ歩きとは 別。島の 中だけ）。動きは スクリプトで（軽く: 2tickに 1回、島に いる 人だけ）*/
const BUD = new Map();   /* pid -> { e, sid, mode, ball, carry, t } */
const PLAY = new Map();  /* pid -> { kind: "race"|"sumo", ... } */
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const outMon = (p) => { const d = load(p); if (!d || !d.out) return null; return [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out) || null; };
const spdK = (sid) => { const b = SPECIES[sid]?.base || {}; return Math.max(0.85, Math.min(1.15, 0.85 + (b.spd || 4) / 20)); };
function giveBall(p) {
  try { const c = p.getComponent("minecraft:inventory")?.container; if (!c) return; for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (it?.typeId === "minecraft:snowball" && String(it.nameTag || "").startsWith("§eボール")) return; } const b = new ItemStack("minecraft:snowball", 1); b.nameTag = "§eボール §7（投げると 相棒が 取って くる）"; c.addItem(b); } catch {}
}
function spawnBud(p) {
  const m = outMon(p); if (!m) return null;
  let e = null; try { e = OW().spawnEntity(TYPE, { x: p.location.x + 1.5, y: p.location.y, z: p.location.z + 1 }); } catch { return null; }
  try { e.addTag("mrpg_play"); e.setDynamicProperty("mrpg:pown", p.id); setLook(e, m.sp, m); e.triggerEvent("mrpg:make_battle"); e.nameTag = `§d${m.nm}`; } catch {}
  const b = { e, sid: m.sp, nm: m.nm, mode: "follow", ball: null, carry: false, t: 0, k: spdK(m.sp) }; BUD.set(p.id, b); return b;
}
function endPlay(p) {
  const b = BUD.get(p.id); if (b) { try { if (okE(b.e)) b.e.remove(); } catch {} BUD.delete(p.id); }
  const g = PLAY.get(p.id); if (g) { try { if (g.fin) g.fin(); } catch {} try { if (g.rv && okE(g.rv)) g.rv.remove(); } catch {} PLAY.delete(p.id); }
  try { const c = p.getComponent("minecraft:inventory")?.container; if (c) for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (it?.typeId === "minecraft:snowball" && String(it.nameTag || "").startsWith("§eボール")) c.setItem(i, undefined); } } catch {}   /* ボールだけ 消す（持ちこんだ 雪玉は のこす）*/
}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { const b = BUD.get(playerId); if (b) try { b.e.remove(); } catch {} BUD.delete(playerId); const g = PLAY.get(playerId); if (g) { try { if (g.fin) g.fin(); } catch {} if (g.rv) try { g.rv.remove(); } catch {} } PLAY.delete(playerId); }); } catch {}
/* 起動した ときに 残った 遊び相手を 片づける */
system.runTimeout(() => { try { for (const e of OW().getEntities({ type: TYPE, tags: ["mrpg_play"] })) try { e.remove(); } catch {} } catch {} }, 100);
const stepTo = (e, to, sp, y) => { const l = e.location, dx = to.x - l.x, dz = to.z - l.z, d = Math.hypot(dx, dz); if (d < 0.05) return 0; const k = Math.min(sp, d) / d; try { e.teleport({ x: l.x + dx * k, y, z: l.z + dz * k }, { facingLocation: { x: to.x, y: y, z: to.z } }); } catch {} return d; };

/* ---- ボール（取って こい）: 投げた ボールを 空中でも 追いかける ---- */
try {
  world.afterEvents.entitySpawn.subscribe(({ entity: e }) => {
    if (e?.typeId !== "minecraft:snowball") return;
    system.run(() => {
      try { if (!okE(e)) return; let own = null; try { own = e.getComponent("minecraft:projectile")?.owner; } catch {}
        if (!own) { const L = e.dimension.getPlayers({ location: e.location, maxDistance: 3 }); own = L[0]; }
        if (!own || !inIsleMode(own)) return; const b = BUD.get(own.id); if (!b || PLAY.has(own.id)) return;
        b.ball = e; b.mode = "chase"; b.land = null; b.t = 0; anim(b.e, "happy"); } catch {}
    });
  });
} catch {}
try {
  world.afterEvents.projectileHitBlock.subscribe((ev) => {
    try { const pr = ev.projectile; if (pr?.typeId !== "minecraft:snowball") return; const own = ev.source; if (!own || own.typeId !== "minecraft:player") return; const b = BUD.get(own.id); if (!b || b.mode !== "chase") return; b.land = { x: ev.location.x, z: ev.location.z }; b.ball = null; } catch {}
  });
} catch {}
function budTick(p, c, l) {
  let b = BUD.get(p.id); if (!b || !okE(b.e)) { if (PLAY.has(p.id)) return; b = spawnBud(p); if (!b) return; }
  if (PLAY.has(p.id)) return;
  const e = b.e, y = c.y, el = e.location; b.t++;
  if (el.y < y - 6) { try { e.teleport({ x: l.x + 1, y, z: l.z + 1 }); } catch {} return; }
  if (b.mode === "chase") {
    let tgt = null; const bl = okE(b.ball) ? b.ball.location : null;
    if (bl) { tgt = bl; if (b.t > 6 && hv(bl, el) < 1.6 && bl.y - y < 3.2) { try { b.ball.remove(); } catch {} b.mode = "back"; b.carry = true; anim(e, "atk_jump"); try { barNote(p).setActionBar(`§e§lナイスキャッチ！ §f${b.nm}が 空中で くわえた`); } catch {} sound(p, "random.pop", 1.6); return; } }
    else if (b.land) { tgt = b.land; if (hv(tgt, el) < 1.2) { b.mode = "back"; b.carry = true; b.land = null; anim(e, "happy"); return; } }
    else if (b.t > 40) { b.mode = "follow"; giveBall(p); return; }   /* 見うしなった（ボールは 手元に もどす）*/
    if (tgt) stepTo(e, tgt, 0.42 * b.k, y);
    if (b.t > 200) { b.mode = "back"; b.carry = true; b.ball = null; }
    return;
  }
  if (b.mode === "back") {
    const d = stepTo(e, l, 0.36 * b.k, y);
    if ((b.t & 3) === 0) try { OW().spawnParticle("minecraft:villager_happy", { x: e.location.x, y: y + 1.6, z: e.location.z }); } catch {}
    if (d < 1.8) { b.mode = "follow"; b.carry = false; b.t = 0; giveBall(p); anim(e, "happy"); try { for (let k = 0; k < 4; k++) OW().spawnParticle("minecraft:heart_particle", { x: e.location.x + (Math.random() - 0.5), y: y + 1.2, z: e.location.z + (Math.random() - 0.5) }); } catch {} b.n = (b.n || 0) + 1; try { barNote(p).setActionBar(`§d${b.nm}が ボールを もって きた！ §7（${b.n}回目）`); } catch {} sound(p, "random.orb", 1.4); if (hooks.addNkOut && b.n % 5 === 0) hooks.addNkOut(p, 2, "ボール あそび"); }
    return;
  }
  /* ついて くる */
  const d = hv(el, l); if (d > 3) stepTo(e, l, Math.min(0.4, 0.12 + d * 0.02), y);
}

/* ---- かけっこ（運動場の 島）: 金の 線に 立つと スタート。黒い 線を ふんで 金の 線に もどる。相手は 相棒（かしこく 走る）---- */
function rival(p, at, face) {   /* 遊びの 相手（相棒の 写し）を 出す */
  const m = outMon(p); if (!m) { try { barNote(p).setActionBar("§7連れ歩きの 子が いないと 遊べない"); } catch {} return null; }
  let rv = null; try { rv = OW().spawnEntity(TYPE, at); rv.addTag("mrpg_play"); rv.setDynamicProperty("mrpg:pown", p.id); setLook(rv, m.sp, m); rv.triggerEvent("mrpg:make_battle"); rv.nameTag = `§c${m.nm}`; if (face) rv.teleport(at, { facingLocation: face }); } catch {}
  const bud = BUD.get(p.id); if (bud) { try { bud.e.remove(); } catch {} BUD.delete(p.id); }
  return { rv, m, k: spdK(m.sp) };
}
function raceStart(p, c, l, swim) {
  const zs = swim ? c.z + 11 : c.z + 14, zt = swim ? c.z - 10 : c.z - 14, ry = swim ? c.y - 1.6 : c.y, lim = swim ? 5 : 5.5;
  const lane = l.x > c.x ? -1 : 1, x0 = Math.max(c.x - lim, Math.min(c.x + lim - 1, l.x + lane * 2.5));
  const R0 = rival(p, { x: x0, y: ry, z: zs - 0.5 }, { x: x0, y: ry, z: zt }); if (!R0) return;
  PLAY.set(p.id, { kind: "race", rv: R0.rv, x0, t: -60, st: 100, pTurn: false, rTurn: false, k: R0.k, nm: R0.m.nm, zs, zt, ry, swim, v0: swim ? 0.3 : 0.5, py: swim ? c.y - 1 : c.y });
  title(p, swim ? "§b水泳競争" : "§eかけっこ", swim ? "§f向こうの かべに タッチして もどれ！" : "§f黒い 線を ふんで 金の 線に もどれ！");
}
function raceTick(p, g, c, l) {
  g.t++; const y = c.y;
  if (g.t < 0) { if (g.t === -40 || g.t === -20 || g.t === -1) { title(p, g.t === -40 ? "§c3" : g.t === -20 ? "§62" : "§e1"); sound(p, "note.hat", 1); } if (g.t < -1 && Math.abs(l.z - g.zs) > 1.5) { try { p.teleport({ x: l.x, y: g.py, z: g.zs + 0.5 }, { facingLocation: { x: l.x, y: g.py, z: g.zt } }); } catch {} } return; }
  if (g.t === 0) { title(p, "§a§lスタート！"); sound(p, "note.pling", 1.4); }
  /* プレイヤー */
  const L = g.zs - g.zt;
  if (!g.pTurn && l.z <= g.zt + 0.5) { g.pTurn = true; sound(p, "random.orb", 1.2); }
  /* 相手の かしこい 走り: 巡航 0.24・追う ときは ダッシュ（スタミナを 使う）・前に いる ときは 温存・最後の 8マスは 全力 */
  if (!okE(g.rv)) { PLAY.delete(p.id); return; }
  const rl = g.rv.location, prog = (z, turned) => (turned ? L + (z - g.zt) : g.zs - z);
  const pp = prog(l.z, g.pTurn), rp = prog(rl.z, g.rTurn), gap = pp - rp, left = 2 * L - rp;
  let v = g.v0 * g.k; const dash = (left < 8 && g.st > 0) || (gap > 1.5 && g.st > 25);
  if (dash) { v *= 1.3; g.st -= 1.6; } else { g.st = Math.min(100, g.st + (gap < -4 ? 1.2 : 0.6)); if (gap < -5) v *= 0.92; }
  if (Math.random() < 0.01) v *= 0.5;   /* たまに つまずく */
  const tz = g.rTurn ? g.zs + 0.5 : g.zt - 0.5; stepTo(g.rv, { x: g.x0, z: tz }, v, g.ry);
  if (!g.rTurn && g.rv.location.z <= g.zt + 0.5) g.rTurn = true;
  if ((g.t % 10) === 0) try { barNote(p).setActionBar(`§fあなた ${Math.round(Math.max(0, pp) / (2 * L) * 100)}%  §c${g.nm} ${Math.round(Math.max(0, rp) / (2 * L) * 100)}%  §7${g.st < 30 ? "（相手は 息切れ）" : ""}`); } catch {}
  const pWin = g.pTurn && l.z >= g.zs - 0.5, rWin = g.rTurn && g.rv.location.z >= g.zs - 0.5;
  if (pWin || rWin || g.t > 20 * 60) {
    title(p, pWin ? "§a§l勝ち！" : rWin ? "§c負け…" : "§7時間切れ", pWin ? `§f${g.nm}より 先に ゴール` : `§f${g.nm}が 先に ゴール`); sound(p, pWin ? "random.levelup" : "note.bass", 1);
    if (pWin && hooks.addNkOut) hooks.addNkOut(p, 3, g.swim ? "水泳" : "かけっこ"); SUMO_CD.set(p.id, system.currentTick + 120);
    try { g.rv.remove(); } catch {} PLAY.delete(p.id);
  }
}

/* ---- 相撲（広場の 島）: 土俵に 入ると はじまる。たたくと 相手を おす。相手は 体当たり・よける・まん中に もどる ---- */
const SUMO_R = 5;
function sumoStart(p, c, l) {
  const m = outMon(p); if (!m) { try { barNote(p).setActionBar("§7連れ歩きの 子が いないと 相撲 できない"); } catch {} return; }
  const at = { x: c.x + 0.5, y: c.y, z: c.z + 2.5 };
  let rv = null; try { rv = OW().spawnEntity(TYPE, at); rv.addTag("mrpg_play"); rv.setDynamicProperty("mrpg:pown", p.id); setLook(rv, m.sp, m); rv.triggerEvent("mrpg:make_battle"); rv.nameTag = `§c${m.nm}`; } catch {}
  const bud = BUD.get(p.id); if (bud) { try { bud.e.remove(); } catch {} BUD.delete(p.id); }
  try { p.teleport({ x: c.x + 0.5, y: c.y, z: c.z - 2 }, { facingLocation: at }); } catch {}
  const sz = SPECIES[m.sp]?.sz || "M";
  PLAY.set(p.id, { kind: "sumo", rv, t: -50, st: "idle", cd: 30, wt: { S: 1.25, M: 1, L: 0.7, G: 0.5 }[sz] || 1, nm: m.nm, k: spdK(m.sp), hits: 0 });
  title(p, "§e相撲", "§f相手を たたいて 土俵の 外へ おしだせ！");
}
function sumoTick(p, g, c, l) {
  g.t++; const y = c.y, C = { x: c.x + 0.5, z: c.z + 0.5 };
  if (!okE(g.rv)) { PLAY.delete(p.id); return; }
  if (g.t < 0) { if (g.t === -30 || g.t === -15 || g.t === -1) title(p, g.t === -30 ? "§cはっけよい…" : g.t === -15 ? "§6…" : "§e§lのこった！"); return; }
  const e = g.rv, el = e.location, toP = { x: l.x - el.x, z: l.z - el.z }, dP = Math.hypot(toP.x, toP.z) || 1, rE = hv(el, C), rP = hv(l, C);
  /* 勝ち負け */
  if (rE > SUMO_R + 0.3 || rP > SUMO_R + 0.3 || g.t > 20 * 60) {
    const win = rE > SUMO_R + 0.3 && !(rP > SUMO_R + 0.3);
    title(p, win ? "§a§l勝ち！" : rP > SUMO_R + 0.3 ? "§c負け…" : "§7引き分け", win ? `§f${g.nm}を おしだした` : rP > SUMO_R + 0.3 ? "§f土俵の 外に 出て しまった" : "");
    sound(p, win ? "random.levelup" : "note.bass", 1); if (win && hooks.addNkOut) hooks.addNkOut(p, 3, "相撲");
    try { e.remove(); } catch {} PLAY.delete(p.id); return;
  }
  g.cd--;
  if (g.st === "tele") { g.tt--; if (g.tt <= 0) { g.st = "lunge"; g.tt = 7; g.dir = { x: toP.x / dP, z: toP.z / dP }; } return; }   /* ため（体を ひく）*/
  if (g.st === "lunge") {   /* 体当たり */
    g.tt--; const n = { x: el.x + g.dir.x * 0.55 * g.k, z: el.z + g.dir.z * 0.55 * g.k }; try { e.teleport({ x: n.x, y, z: n.z }, { facingLocation: { x: l.x, y, z: l.z } }); } catch {}
    if (hv(n, l) < 1.4) { try { p.applyKnockback(g.dir.x, g.dir.z, 1.1 / Math.max(0.6, g.wt) * 0.9 + 0.3, 0.25); } catch {} sound(p, "random.anvil_land", 1.6); g.st = "idle"; g.cd = 28; }
    if (g.tt <= 0) { g.st = "idle"; g.cd = 20; }
    return;
  }
  if (g.st === "side") { g.tt--; const n = { x: el.x + g.dir.x * 0.3, z: el.z + g.dir.z * 0.3 }; if (hv(n, C) < SUMO_R - 0.8) try { e.teleport({ x: n.x, y, z: n.z }, { facingLocation: { x: l.x, y, z: l.z } }); } catch {} if (g.tt <= 0) g.st = "idle"; return; }
  /* ふだん: はしに 近いと まん中へ・相手と まん中の 間に 入る・近いと 体当たりの ため */
  if (rE > SUMO_R - 1.4) { stepTo(e, C, 0.22 * g.k, y); return; }
  const guard = { x: C.x + (l.x - C.x) * 0.35, z: C.z + (l.z - C.z) * 0.35 };   /* 相手と 自分の 間を まん中より に とる */
  if (dP > 2.6) stepTo(e, hv(el, guard) > 1.2 ? guard : l, 0.14 * g.k, y);
  else if (g.cd <= 0) { g.st = "tele"; g.tt = 8; anim(e, "atk_charge"); try { barNote(p).setActionBar(`§c${g.nm}が 体当たりの かまえ！ §7よこへ よけろ`); } catch {} }
}
/* たたいたら おす（重い 子ほど 動かない）・ため中に たたくと くずせる・よける ことも ある */
system.run(() => HIT_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_play")) return false;
  try { e.getComponent("minecraft:health")?.resetToMaxValue(); } catch {}
  let own = null; try { own = e.getDynamicProperty("mrpg:pown"); } catch {} if (own !== p.id) return true;
  const g = PLAY.get(p.id); if (!g || g.kind !== "sumo" || g.t < 0 || g.rv?.id !== e.id) return true;
  const c = isleCenter(isleAt(e.location)), el = e.location, l = p.location, dx = el.x - l.x, dz = el.z - l.z, d = Math.hypot(dx, dz) || 1;
  if (g.st === "idle" && Math.random() < 0.28) { g.st = "side"; g.tt = 5; const s = Math.random() < 0.5 ? 1 : -1; g.dir = { x: (-dz / d) * s, z: (dx / d) * s }; try { barNote(p).setActionBar(`§7${g.nm}が ひらりと よけた！`); } catch {} return true; }
  const push = (g.st === "tele" ? 1.6 : 0.9) * g.wt; if (g.st === "tele") { g.st = "idle"; g.cd = 24; try { barNote(p).setActionBar("§e§lため中を くずした！"); } catch {} }
  try { e.teleport({ x: el.x + (dx / d) * push, y: c.y, z: el.z + (dz / d) * push }, { facingLocation: l }); } catch {}
  sound(p, "random.anvil_land", 1.8); g.hits++; return true;
}));
try {   /* ボールが 生き物に 当たった: 自分の 遊び相手なら キャッチ・ほかなら そこへ 取りに いく */
  world.afterEvents.projectileHitEntity.subscribe((ev) => {
    try { const pr = ev.projectile; if (pr?.typeId !== "minecraft:snowball") return; const own = ev.source; if (!own || own.typeId !== "minecraft:player") return; const b = BUD.get(own.id); if (!b || b.mode !== "chase") return;
      const hit = ev.getEntityHit?.()?.entity; if (hit && b.e && hit.id === b.e.id) { b.mode = "back"; b.carry = true; b.ball = null; anim(b.e, "atk_jump"); try { barNote(own).setActionBar(`§e§lナイスキャッチ！ §f${b.nm}が くわえた`); } catch {} return; }
      b.land = { x: ev.location.x, z: ev.location.z }; b.ball = null; } catch {}
  });
} catch {}
/* 島では 野生が 出ない・ブロックを こわせない／置けない */
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => inIsleMode(p) || (prev ? prev(p) : false); });
try { world.beforeEvents.playerBreakBlock.subscribe((ev) => { if (inIsleMode(ev.player)) ev.cancel = true; }); } catch {}
try { world.beforeEvents.playerPlaceBlock?.subscribe((ev) => { if (inIsleMode(ev.player)) ev.cancel = true; }); } catch {}
const RACE_OFF = new Set(), PADN = new Map(), RACE_T = new Map();   /* ゴールした あと 金の 線から いちど はなれるまで 始めない */
/* 島ごとの 見はり（leaveIsle などと 同じ 10tickでは 遅いので、遊びは 2tickの 見はりで）*/
system.runInterval(() => {
  if (!BUD.size && !PLAY.size && !world.getAllPlayers().some((p) => inIsleMode(p))) return;
  for (const p of world.getAllPlayers()) {
    if (!inIsleMode(p)) continue;
    try {
      const l = p.location, k = p.dimension.id === OWID ? isleAt({ ...l, y: isleCenter(0).y }) : -1; if (k < 0) continue;
      const c = isleCenter(k), key = ISLES[k][0], g = PLAY.get(p.id);
      if (inBattle(p)) { if (g) { try { if (g.fin) g.fin(); } catch {} try { if (g.rv) g.rv.remove(); } catch {} PLAY.delete(p.id); } continue; }   /* 戦いに なったら 遊びは やめる */
      if (busy.has(p.id)) continue;   /* 画面を 開いて いる 間は 止める（やめない）*/
      if ((system.currentTick % 100) < 2) try { for (const e of OW().getEntities({ type: TYPE, tags: ["mrpg_play"], location: { x: c.x, y: c.y, z: c.z }, maxDistance: 45 })) { const own = e.getDynamicProperty("mrpg:pown"); const mine = [...BUD.values()].some((x) => x.e && x.e.id === e.id) || [...PLAY.values()].some((x) => x.rv && x.rv.id === e.id); if (!mine) e.remove(); } } catch {}   /* 残った 遊び相手を 片づける */
      const pad = padAt(key, c, l); if (!pad) { RACE_OFF.delete(p.id); PADN.delete(p.id); }
      if (g) { const T = TICKS[g.kind]; if (T) T(p, g, c, l); continue; }
      if (pad && !RACE_OFF.has(p.id) && !((RACE_T.get(p.id) || 0) > Date.now())) { const n = (PADN.get(p.id) || 0) + 1; PADN.set(p.id, n); if (n === 2) try { barNote(p).setActionBar("§eそのまま 立って いると はじまる…"); } catch {} if (n >= 10) { PADN.delete(p.id); RACE_OFF.add(p.id); STARTS[pad](p, c, l); } continue; }   /* 1秒 立つと はじまる（通りすぎる だけでは はじまらない）*/
      budTick(p, c, l);
    } catch {}
  }
}, 2);
const SUMO_CD = new Map();
export const __play = { BUD, PLAY, RACE_T };

// ================= 第104版: 遊びを ふやす（水泳・迷路・足場わたり・宝さがし・かくれんぼ・おにごっこ）=================
const finish = (p, g, win, msg, why) => {
  title(p, win ? "§a§l勝ち！" : win === false ? "§c負け…" : "§7おしまい", msg || ""); sound(p, win ? "random.levelup" : "note.bass", 1);
  if (win && hooks.addNkOut) hooks.addNkOut(p, 3, why);
  try { if (g.fin) { if (g.kind === "sand") system.runTimeout(() => { try { g.fin(); } catch {} }, 60); else g.fin(); } } catch {} try { if (g.rv && okE(g.rv)) g.rv.remove(); } catch {} PLAY.delete(p.id); RACE_T.set(p.id, Date.now() + 5000);
};
const count3 = (p, g) => { if (g.t === -40 || g.t === -20 || g.t === -1) { title(p, g.t === -40 ? "§c3" : g.t === -20 ? "§62" : "§e1"); sound(p, "note.hat", 1); } if (g.t === 0) { title(p, "§a§lスタート！"); sound(p, "note.pling", 1.4); } };
const hold = (p, at) => { try { if (hv(p.location, at) > 1.2) p.teleport(at); } catch {} };

/* ---- 迷路（7×7 の 部屋・コケの 生け垣）: 北の 入口から 南の 金の ゴールへ。相棒は 道を 考えて 進むが ときどき 迷う ---- */
const MZ_N = 7, MZ_S = 4;
function mazeGraph() {
  let s = 104; const r = () => { s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const adj = Array.from({ length: MZ_N * MZ_N }, () => []), seen = new Set([3]), st = [3];
  while (st.length) { const u = st[st.length - 1], i = u % MZ_N, j = Math.floor(u / MZ_N); const nb = [[i + 1, j], [i - 1, j], [i, j + 1], [i, j - 1]].filter(([a, b]) => a >= 0 && b >= 0 && a < MZ_N && b < MZ_N && !seen.has(b * MZ_N + a)); if (!nb.length) { st.pop(); continue; } const [a, b] = nb[Math.floor(r() * nb.length)], v = b * MZ_N + a; adj[u].push(v); adj[v].push(u); seen.add(v); st.push(v); }
  for (let n = 0; n < 5; n++) { const u = Math.floor(r() * MZ_N * MZ_N), i = u % MZ_N; if (i < MZ_N - 1 && !adj[u].includes(u + 1)) { adj[u].push(u + 1); adj[u + 1].push(u); } }   /* 輪っかを 少し */
  return adj;
}
const MZ = mazeGraph();
const mzCell = (c, u) => ({ x: c.x - 14 + (u % MZ_N) * MZ_S + 2.5, z: c.z - 14 + Math.floor(u / MZ_N) * MZ_S + 2.5 });
const MZ_START = 3, MZ_GOAL = 6 * MZ_N + 3;
function buildMaze(c) {
  const y = c.y, x0 = c.x - 14, z0 = c.z - 14, w = bk("moss_block", "leaves");
  run(`fill ${x0} ${y} ${z0} ${x0 + 28} ${y + 2} ${z0 + 28} ${w}`);
  for (let u = 0; u < MZ_N * MZ_N; u++) { const i = u % MZ_N, j = Math.floor(u / MZ_N), ax = x0 + 1 + i * MZ_S, az = z0 + 1 + j * MZ_S; run(`fill ${ax} ${y} ${az} ${ax + 2} ${y + 2} ${az + 2} air`);
    for (const v of MZ[u]) { if (v === u + 1) run(`fill ${ax + 3} ${y} ${az} ${ax + 3} ${y + 2} ${az + 2} air`); if (v === u + MZ_N) run(`fill ${ax} ${y} ${az + 3} ${ax + 2} ${y + 2} ${az + 3} air`); } }
  run(`fill ${x0 + 13} ${y} ${z0} ${x0 + 15} ${y + 2} ${z0} air`);   /* 入口 */
  const gq = mzCell(c, MZ_GOAL); run(`setblock ${Math.floor(gq.x)} ${y - 1} ${Math.floor(gq.z)} ${bk("gold_block")}`);
}
function mazeRoute() {   /* 正しい 道（BFS）＋ ときどき わき道に 入って もどる */
  const prev = new Map([[MZ_START, -1]]), q = [MZ_START]; while (q.length) { const u = q.shift(); if (u === MZ_GOAL) break; for (const v of MZ[u]) if (!prev.has(v)) { prev.set(v, u); q.push(v); } }
  const path = []; for (let u = MZ_GOAL; u !== -1 && u !== undefined; u = prev.get(u)) path.unshift(u);
  const out = []; for (let k = 0; k < path.length; k++) { const u = path[k]; out.push(u); const wrong = MZ[u].filter((v) => v !== path[k + 1] && v !== path[k - 1]); if (wrong.length && Math.random() < 0.3) out.push(wrong[0], u); }
  return out;
}
function mazeStart(p, c, l) {
  const s = mzCell(c, MZ_START), R0 = rival(p, { x: s.x + 1, y: c.y, z: s.z }, mzCell(c, MZ_START + MZ_N)); if (!R0) return;
  PLAY.set(p.id, { kind: "maze", rv: R0.rv, k: R0.k, nm: R0.m.nm, t: -60, route: mazeRoute(), ri: 0, wait: 0, at: { x: s.x - 1, y: c.y, z: s.z } });
  title(p, "§e迷路", "§f南の 金の ブロックが ゴール");
}
function mazeTick(p, g, c, l) {
  g.t++; count3(p, g); if (g.t < 0) { hold(p, g.at); return; }
  if (!okE(g.rv)) { PLAY.delete(p.id); return; }
  const goal = mzCell(c, MZ_GOAL);
  if (g.wait > 0) g.wait--; else if (g.ri < g.route.length) { const w = mzCell(c, g.route[g.ri]); if (stepTo(g.rv, w, 0.32 * g.k, c.y) < 0.35) { g.ri++; if (Math.random() < 0.12) { g.wait = 12; anim(g.rv, "happy"); } } }   /* 角で ちょっと 考える */
  if (hv(l, goal) < 1.4) return finish(p, g, true, `§f${g.nm}より 先に ゴール（${Math.round(g.t / 10)}秒）`, "迷路");
  if (g.ri >= g.route.length) return finish(p, g, false, `§f${g.nm}が 先に ゴール`);
  if (g.t > 20 * 120) return finish(p, g, null, "§f時間切れ");
  if (g.t % 10 === 0) try { barNote(p).setActionBar(`§f迷路 §7${Math.round(g.t / 10)}秒  §c${g.nm}: ${Math.round((g.ri / g.route.length) * 100)}%`); } catch {}
}

/* ---- 足場わたり（アスレチックの 島）: 北の 金から 水の 上の 足場を とんで 南の 金へ。落ちたら スタート ---- */
const PARK_ST = [[-1, -12, 0], [1, -9, 0], [2, -6, 1], [0, -3, 0], [-2, 0, 0], [-1, 3, 1], [1, 6, 0], [2, 9, 0], [0, 12, 1], [-1, 15, 0]];
function parkStart(p, c, l) {
  const R0 = rival(p, { x: c.x + 1.5, y: c.y, z: c.z - 14.5 }, { x: c.x, y: c.y, z: c.z + 18 }); if (!R0) return;
  PLAY.set(p.id, { kind: "park", rv: R0.rv, k: R0.k, nm: R0.m.nm, t: -60, si: -1, hop: 0, wait: 0, falls: 0, at: { x: c.x - 0.5, y: c.y, z: c.z - 14.5 } });
  title(p, "§e足場わたり", "§f足場を とんで 南の 金へ。落ちたら やりなおし");
}
function parkTick(p, g, c, l) {
  g.t++; count3(p, g); if (g.t < 0) { hold(p, g.at); return; }
  if (!okE(g.rv)) { PLAY.delete(p.id); return; }
  /* プレイヤー: 水に 落ちたら スタートへ */
  if (Math.abs(l.x - c.x) <= 4.5 && l.z > c.z - 14.5 && l.z < c.z + 16.5 && l.y < c.y - 0.4) { g.falls++; try { p.teleport(g.at, { facingLocation: { x: c.x, y: c.y, z: c.z + 18 } }); } catch {} sound(p, "random.splash", 1); try { barNote(p).setActionBar("§b落ちた！ スタートから"); } catch {} }
  /* 相手: 1つずつ とぶ（とぶ 間は 弧を えがく）。たまに 足を すべらせて 少し 止まる */
  if (g.wait > 0) g.wait--;
  else if (g.hop > 0) { g.hop--; const n = g.si + 1 < PARK_ST.length ? PARK_ST[g.si + 1] : null, to = n ? { x: c.x + n[0] + 0.5, z: c.z + n[1] + 0.5, y: c.y + n[2] } : { x: c.x + 0.5, z: c.z + 18.5, y: c.y }, f = 1 - g.hop / 8, from = g.from;
    try { g.rv.teleport({ x: from.x + (to.x - from.x) * f, y: from.y + (to.y - from.y) * f + Math.sin(f * Math.PI) * 1.3, z: from.z + (to.z - from.z) * f }, { facingLocation: { x: to.x, y: to.y, z: to.z } }); } catch {}
    if (g.hop === 0) { g.si++; g.wait = Math.round((4 + Math.random() * 6) / g.k); if (Math.random() < 0.08) { g.wait += 30; try { barNote(p).setActionBar(`§7${g.nm}が 足を すべらせた！`); } catch {} } } }
  else { g.from = { ...g.rv.location }; g.hop = 8; }
  PARK_ST.forEach((q, i) => { if (i > (g.ps ?? -1) && Math.abs(l.x - (c.x + q[0] + 0.5)) < 0.9 && Math.abs(l.z - (c.z + q[1] + 0.5)) < 0.9 && l.y >= c.y + q[2] - 0.2) g.ps = i; });
  if (l.z >= c.z + 17.5 && Math.abs(l.x - c.x) < 3 && l.y >= c.y - 0.5 && (g.ps ?? -1) >= PARK_ST.length - 1) return finish(p, g, true, `§f${g.nm}より 先に ゴール（落ちた ${g.falls}回）`, "足場わたり");
  if (g.si >= PARK_ST.length) return finish(p, g, false, `§f${g.nm}が 先に ゴール`);
  if (g.t > 20 * 120) return finish(p, g, null, "§f時間切れ");
}

/* ---- 宝さがし（砂浜の 島）: 砂の 下の 宝を ほりあてる（あつい・つめたい）。相棒も においで さがす ---- */
function sandStart(p, c, l) {
  let tq = null; for (let n = 0; n < 30 && !tq; n++) { const a = Math.random() * Math.PI * 2, r = 4 + Math.random() * 9, x = Math.floor(c.x + Math.cos(a) * r), z = Math.floor(c.z + Math.sin(a) * r); try { const b = OW().getBlock({ x, y: c.y - 1, z }); if (b && /sand/.test(b.typeId) && OW().getBlock({ x, y: c.y, z })?.isAir) tq = { x, z }; } catch {} }
  if (!tq) tq = { x: c.x + 3, z: c.z + 3 };
  const R0 = rival(p, { x: c.x + 2.5, y: c.y, z: c.z - 13.5 }, c); if (!R0) return;
  const g = { kind: "sand", rv: R0.rv, k: R0.k, nm: R0.m.nm, t: -60, tq, dug: [], wp: null, dig: 0, at: { x: c.x + 0.5, y: c.y, z: c.z - 13.5 } };
  g.fin = () => { for (const q of g.dug) run(`setblock ${q.x} ${c.y - 1} ${q.z} ${bk("sand")}`); };
  PLAY.set(p.id, g); title(p, "§e宝さがし", "§f砂を こわして 宝を さがせ（あつい・つめたい）");
}
function sandDig(p, g, pos, c) {   /* 砂を ほる（こわした 砂は 落とさない・あとで もどす）*/
  if (PLAY.get(p.id) !== g) return;
  try { if (!/sand/.test(OW().getBlock(pos)?.typeId || "")) return; } catch { return; }
  if (Math.abs(pos.y - (c.y - 1)) > 0 || hv({ x: pos.x + 0.5, z: pos.z + 0.5 }, c) > 15) return;
  run(`setblock ${pos.x} ${pos.y} ${pos.z} air`); g.dug.push({ x: pos.x, z: pos.z }); sound(p, "dig.sand", 1);
  if (pos.x === g.tq.x && pos.z === g.tq.z) { run(`setblock ${pos.x} ${pos.y} ${pos.z} ${bk("gold_block")}`); try { for (let k = 0; k < 8; k++) OW().spawnParticle("minecraft:totem_particle", { x: pos.x + 0.5, y: c.y + 0.5, z: pos.z + 0.5 }); } catch {} g.dug.push({ x: pos.x, z: pos.z }); finish(p, g, true, `§f宝を ほりあてた！（${g.dug.length - 1}回 ほった）`, "宝さがし"); }
}
function sandTick(p, g, c, l) {
  g.t++; count3(p, g); if (g.t < 0) return;
  if (!okE(g.rv)) return finish(p, g, null, "");
  const T = { x: g.tq.x + 0.5, z: g.tq.z + 0.5 }, d = hv(l, T);
  if (g.t % 8 === 0) try { barNote(p).setActionBar(`§f砂を こわして さがせ  ${d < 2 ? "§c§lあつい！" : d < 4 ? "§6あたたかい" : d < 7 ? "§eぬるい" : "§bつめたい"}  §7${Math.max(0, 90 - Math.round(g.t / 10))}秒`); } catch {}
  /* 相手: においを かぎながら 少しずつ 近づく（はじめは 大きく まよう）*/
  if (g.dig > 0) { g.dig--; if (g.dig % 6 === 0) anim(g.rv, "atk_claw"); if (g.dig === 0) { run(`setblock ${g.tq.x} ${c.y - 1} ${g.tq.z} ${bk("gold_block")}`); g.dug.push({ x: g.tq.x, z: g.tq.z }); return finish(p, g, false, `§f${g.nm}が 先に 宝を 見つけた`); } return; }
  const rad = Math.max(0, 9 - g.t / 70);
  if (!g.wp || hv(g.rv.location, g.wp) < 0.6) { const a = Math.random() * Math.PI * 2; g.wp = { x: T.x + Math.cos(a) * rad, z: T.z + Math.sin(a) * rad }; if (Math.random() < 0.4) anim(g.rv, "happy"); }
  stepTo(g.rv, g.wp, 0.1 * g.k, c.y);
  if (rad < 0.8 && hv(g.rv.location, T) < 1.1) { g.dig = 36; try { barNote(p).setActionBar(`§c${g.nm}が ほりはじめた！ いそげ！`); } catch {} }
  if (g.t > 10 * 90) return finish(p, g, null, "§f時間切れ");
}

/* ---- かくれんぼ（原っぱの 島・緑の 台）: 相棒が 木の かげに かくれる。近づくと こっそり 逃げる ことも ---- */
const HIDE = [[-10, -5], [9, -7], [-6, 10], [11, 9], [0, 15], [-14, 4], [6, 2], [-12, 12]];
const hideSpot = (c, k, from) => { const [dx, dz] = HIDE[k], d = Math.hypot(dx, dz) || 1, o = from ? 1.6 : 0; return { x: c.x + dx + (dx / d) * o + 0.5, z: c.z + dz + (dz / d) * o + 0.5 }; };
function hideStart(p, c, l) {
  const R0 = rival(p, { x: c.x, y: c.y, z: c.z }, null); if (!R0) return;
  const k = Math.floor(Math.random() * HIDE.length); const s = hideSpot(c, k, true);
  try { R0.rv.nameTag = ""; R0.rv.teleport({ x: s.x, y: c.y, z: s.z }); } catch {}
  try { p.addEffect("blindness", 70, { amplifier: 0, showParticles: false }); } catch {}
  PLAY.set(p.id, { kind: "hide", rv: R0.rv, k: R0.k, nm: R0.m.nm, t: -60, spot: k, moves: 0, run: null, still: 0 });
  title(p, "§aかくれんぼ", `§f${R0.m.nm}が かくれる… 10 かぞえて！`);
}
function hideTick(p, g, c, l) {
  g.t++; if (g.t < 0) { if (g.t === -1) { title(p, "§a§lもういいよ！", "§f60秒で 見つけよう"); sound(p, "note.pling", 1.4); } return; }
  if (!okE(g.rv)) { PLAY.delete(p.id); return; }
  const e = g.rv, d = hv(l, e.location);
  if (g.run) { if (stepTo(e, g.run, 0.32 * g.k, c.y) < 0.3) g.run = null; }
  else if (d < 6 && d > 2.2 && g.moves < 2 && ++g.still > 40 && Math.random() < 0.05) {   /* こっそり 遠い かげへ */
    let best = g.spot, bd = -1; HIDE.forEach((_, k) => { const s = hideSpot(c, k, true), dd = hv(s, l); if (k !== g.spot && dd > bd) { bd = dd; best = k; } });
    g.spot = best; g.run = hideSpot(c, best, true); g.moves++; g.still = 0; try { barNote(p).setActionBar("§7がさがさっ… なにかが 走った！"); } catch {}
  }
  if (g.t % 200 === 100) try { OW().spawnParticle("minecraft:villager_happy", { x: e.location.x, y: c.y + 1.5, z: e.location.z }); } catch {}
  if (d < 1.8) { try { e.nameTag = `§d${g.nm}`; } catch {} anim(e, "happy"); return finish(p, g, true, `§f${g.nm}を 見つけた！（${Math.round(g.t / 10)}秒）`, "かくれんぼ"); }
  if (g.t > 10 * 60) { try { e.nameTag = `§d${g.nm}`; } catch {} return finish(p, g, false, `§f${g.nm}「ここだよ〜！」`); }
}

/* ---- おにごっこ（原っぱの 島・紫の 台）: 相棒が 鬼。先回りして 追って くる。40秒 にげきれば 勝ち ---- */
function tagStart(p, c, l) {
  const R0 = rival(p, { x: c.x + 0.5, y: c.y, z: c.z + 8 }, l); if (!R0) return;
  PLAY.set(p.id, { kind: "tag", rv: R0.rv, k: R0.k, nm: R0.m.nm, t: -60, st: 100, last: { ...l } });
  title(p, "§5おにごっこ", `§f${R0.m.nm}が 鬼！ 40秒 にげきれ`);
}
function tagTick(p, g, c, l) {
  g.t++; count3(p, g); if (g.t < 0) { g.last = { ...l }; return; }
  if (!okE(g.rv)) { PLAY.delete(p.id); return; }
  const e = g.rv, vx = l.x - g.last.x, vz = l.z - g.last.z; g.last = { ...l };
  const d = hv(l, e.location), lead = Math.min(8, d / 0.25) * 0.5;   /* 先回り: 走って くる 先を ねらう */
  const tgt = { x: l.x + vx * lead, z: l.z + vz * lead }; { const dc = hv(tgt, c); if (dc > 18) { tgt.x = c.x + (tgt.x - c.x) * 18 / dc; tgt.z = c.z + (tgt.z - c.z) * 18 / dc; } }   /* 島の 外へは 出ない */
  let v = 0.4 * g.k; if (d < 7 && g.st > 0) { v = 0.55 * g.k; g.st -= 2.5; } else g.st = Math.min(100, g.st + 0.8);
  stepTo(e, tgt, v, c.y);
  if (d < 1.15) return finish(p, g, false, `§f${g.nm}に つかまった（${Math.round(g.t / 10)}秒）`);
  if (g.t >= 10 * 40) return finish(p, g, true, `§f${g.nm}から にげきった！`, "おにごっこ");
  if (g.t % 10 === 0) try { barNote(p).setActionBar(`§5おにごっこ §fのこり ${40 - Math.round(g.t / 10)}秒  §7${g.st < 20 ? `（${g.nm}は 息切れ）` : ""}`); } catch {}
}

/* ---- 台・線と 遊びの つながり ---- */
function padAt(key, c, l) {
  if (Math.abs(l.y - c.y) > 1.6) return null; const x = l.x, z = l.z;
  if (key === "track" && Math.abs(z - (c.z + 14.5)) < 0.8 && x > c.x - 6.5 && x < c.x + 6) return "race";
  if (key === "pool" && Math.abs(z - (c.z + 13.5)) < 0.8 && x > c.x - 6.5 && x < c.x + 7) return "swim";
  if (key === "maze" && Math.abs(z - (c.z - 13.5)) < 0.8 && x > c.x - 1.5 && x < c.x + 2.5) return "maze";
  if (key === "park" && Math.abs(z - (c.z - 14.5)) < 0.8 && x > c.x - 1.5 && x < c.x + 2.5) return "park";
  if (key === "sand" && z > c.z - 15.2 && z < c.z - 12.8 && x > c.x - 1.2 && x < c.x + 2.2) return "sand";
  if (key === "field" && z > c.z - 15.2 && z < c.z - 12.8 && x > c.x - 5.2 && x < c.x - 2.8) return "hide";
  if (key === "field" && z > c.z - 15.2 && z < c.z - 12.8 && x > c.x + 3.8 && x < c.x + 6.2) return "tag";
  if (key === "stage" && hv(l, { x: c.x + 0.5, z: c.z + 0.5 }) < 3) return "sumo";
  return null;
}
const STARTS = { race: (p, c, l) => raceStart(p, c, l, false), swim: (p, c, l) => raceStart(p, c, l, true), maze: mazeStart, park: parkStart, sand: sandStart, hide: hideStart, tag: tagStart, sumo: (p, c, l) => sumoStart(p, c, l) };
const TICKS = { race: raceTick, sumo: sumoTick, maze: mazeTick, park: parkTick, sand: sandTick, hide: hideTick, tag: tagTick };
/* 宝さがしの 間だけ 砂を ほれる（ふつうに こわすと 砂が 落ちるので、こちらで 消す）*/
try { world.beforeEvents.playerBreakBlock.subscribe((ev) => { const p = ev.player, g = PLAY.get(p?.id); if (!g || g.kind !== "sand" || g.t < 0) return; const pos = { ...ev.block.location }; system.run(() => { try { const k = isleAt({ ...p.location, y: isleCenter(0).y }); if (k >= 0) sandDig(p, g, pos, isleCenter(k)); } catch {} }); }); } catch {}
EXH.isleInfo = () => ["§fどの 島でも §eボール§f を 投げると 相棒が 取って くる", "§f運動場: 金の 線で かけっこ／プール: 金の 線で 水泳競争／迷路: 入口で 迷路競争／アスレチック: 北の 金で 足場わたり", "§f砂浜: だいだいの 台で 宝さがし／原っぱ: 緑の 台で かくれんぼ・紫の 台で おにごっこ／広場: 土俵で 相撲"];
