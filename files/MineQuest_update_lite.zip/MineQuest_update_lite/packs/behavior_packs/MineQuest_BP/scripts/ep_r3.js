/* 第125版: 第4地方 ヴォルカ（ようがんの 里 ラヴィ・鍛冶王の 城 フォルジア）の 5話
   1話 外れの 鍛冶場（新）→ 2話 火祭りの 支度（新。鉱山・カグラと 鍛冶組合の 仲たがい）→ 3話 火薬の におい（新。爆弾班と 赤い 外套の 女）
   → 4話 炎の 幹部（今の 段: 燃える 鍛冶場・ヴァルカ）＋ 鍛冶場の 夜（新。ヴァルカが トンボを 見る・父の 未完の 刀）
   → 5話 火祭り（今の 段: カグラとの 勝負 → 新: 火祭りで トンボの 初めての 刀を もらう）
   書き方は ep_r0.js の 頭の 説明の とおり。場所は 里の 外れ（噴水・町の 中の 道・坂の 途中は 使わない）*/
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, spotOf, decorPlace } from "./storyplace.js";
import { TOWNS, getTown, townPos, castleSpot } from "./structures.js";
import { regionIdx } from "./worldmap.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok } from "./ui.js";
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* b の そば k マス（a の 側）*/
const turnTo = (K, e, q) => { if (K.turn) return K.turn(e, q); if (!ok(e) || !q) return; try { e.teleport(e.location, { facingLocation: { x: q.x, y: e.location.y + 1.5, z: q.z } }); e.setDynamicProperty("mrpg:away", true); } catch {} };   /* K.turn が まだ ない ときの 代わり */

/* ---------- 場所: ラヴィの 外れ ---------- */
const TID = "t30", REG = 3;
const SP0 = () => { try { return world.getDefaultSpawnLocation(); } catch { return { x: 0, y: 64, z: 0 }; } };
const TC = () => { const t = TOWNS.find((u) => u.id === TID); if (!t) return null; const q = getTown(TID); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const PLQ = {};
function ring(key, R, nm, near = []) {
  if (PLQ[key]) return PLQ[key];
  const c = TC(); if (!c) return null; const s0 = SP0(), avoid = near.filter(Boolean);
  for (const t of TOWNS) if (t.id !== TID) { const q = townPos(t); avoid.push([q.x, q.z, 44]); }
  for (let i = 0; i < 11; i++) { const k = castleSpot(i); if (k) avoid.push([k.x, k.z, 72]); }
  for (const k of ["out", "road", "hall", "stage", "forge"]) { const q = placeOf(k, REG); if (q) avoid.push([q.x, q.z, 26]); }
  let best = null;
  for (let a = 0; a < 16; a++) { const t = (a / 16) * Math.PI * 2, x = Math.floor(c.x + Math.cos(t) * R), z = Math.floor(c.z + Math.sin(t) * R); if (regionIdx(x - s0.x, z - s0.z) !== REG) continue; let m = 1e9; for (const [X, Z, D] of avoid) m = Math.min(m, Math.hypot(X - x, Z - z) - D); if (!best || m > best.m) best = { x, z, m }; }
  if (!best) best = townOut(TID, -0.4, nm);
  return (PLQ[key] = best ? { x: best.x, z: best.z, nm } : null);
}
const FORGE = () => { const q = placeOf("forge", REG); return q ? { x: q.x, z: q.z, nm: q.nm } : null; };   /* 今の 段（4話）と 同じ 鍛冶場 */
const MINE = () => ring("mine", 60, "ようがんの 里 ラヴィの 外れの 鉱山の 入口");
const HAUL = () => { const a = MINE(); return ring("haul", 76, "ラヴィの 外れの 鉄の 運び道", [a && [a.x, a.z, 34]]); };
const FEST = () => { const a = MINE(), b = HAUL(); return ring("fest", 52, "ラヴィの 外れの 火祭りの 広場", [a && [a.x, a.z, 32], b && [b.x, b.z, 32]]); };
const standAt = (k, dx, dz, f) => () => { const q = spotOf(TID, k); if (q) return { x: q.x + dx, y: q.y, z: q.z + dz }; const o = f(); return o ? { x: o.x + dx, z: o.z + dz } : null; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
const fall = (s) => !!s.heroDead && !s.ending;   /* 世界が 滅びかける ころ（第10章の あと 〜 終章の 前）*/
castAdd("r3tombo", { nm: "トンボ", role: "見習い鍛冶", gobi: "ッス", skin: "tetsu", town: TID, from: "r3e1", at: standAt("inn", 3, 2, FEST),
  pre: ["{smile}いらっしゃいッス！ 鍛冶の ご用ッスか？"],
  after: [
    [(s) => !!s.heroBack, ["{smile,☆}あっ、二人とも！ ……よかったッス、ほんとに よかったッス！", "{smile}刀の 手入れ、させて ほしいッス！ ただで いいッス！"]],
    [(s) => !!s.ending, ["{closed}ヴァルカさんの 刀、最後に 結びが 打たれたって 聞いたッス。", "{smile}おれも、いつか あんな 刀を 打つッス。……あの 人の 火、忘れないッス。"]],
    [fall, ["{angry,up}影払いの 鈴、親方と 打ってるッス！ 鉱石を 持って きて くれたら、すぐ 打つッス！", "{sad}……鈴の 音が 届く うちは、だれも 石に させないッス。"]],
    [(s) => !!st(s).fest3, ["{smile,♪}あの 刀、使って くれてるッスか！？", "{smile,☆}まだまだッスけど、次は もっと いいのを 打つッス！"]],
    [(s) => !!st(s).tomboVow, ["{angry}親方の 腕が 治るまで、炉は おれが 守るッス！"]],
    [() => true, ["{smile}火祭りの 刀、いつか 打たせて もらうのが 夢ッス！"]],
  ] });
castAdd("r3gen", { nm: "ゲン", role: "親方", gobi: "でい", skin: "m6_bolt", town: TID, from: "r3e1", at: standAt("inn", -3, 2, FEST),
  pre: ["{angry}鍛冶屋に 何の 用でい。"],
  after: [
    [(s) => !!s.heroBack, ["{smile,tears}……ちくしょう、二人で 来やがって。泣かせるんじゃ ねえでい。"]],
    [(s) => !!s.ending, ["{closed}空が 晴れたでい。……炉の 火は、一度も 消さずに 守ったでい。"]],
    [fall, ["{angry}鈴なら 打って やるでい。トンボの 腕も、もう 一人前でい。", "{sad}……あの 旅の 嬢ちゃんの ぶんまで、打つでい。"]],
    [(s) => !!st(s).fest3, ["{smile,tears}トンボの 初打ちを、おまえさんが 持って いって くれる。……鍛冶屋 冥利に つきるでい。"]],
    [(s) => !!st(s).tomboVow, ["{sweat,汗}腕？ こんな やけど、つばを つけときゃ 治るでい。……いてて。"]],
    [() => true, ["{angry}火祭りの 刀は、戦の 刀じゃ ねえでい。"]],
  ] });
castAdd("r3kagura", { nm: "カグラ", role: "地方マスター", col: "§6", gobi: "", skin: "kagura" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const out = async (K, p, e, run = false) => { if (!ok(e)) return; const q = K.away(e, p, 12), l = e.location; if (!q || Math.hypot(q.x - l.x, q.z - l.z) < 4) return K.bye(p, e); return K.leave(e, p, 12, run); };   /* 歩いて 去る（道が ふさがって いる ときは 暗転で 下げる）*/
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
const VALKA = (K, p, w = false) => K.npcNear(p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), w);
async function hammer(K, p, e, n = 3) { for (let i = 0; i < n; i++) { K.act(e, "raise"); await K.wait(4); K.act(e, "hold"); if (ok(e)) { const l = e.location; try { p.dimension.spawnParticle("mrpg:sparks", { x: l.x, y: l.y + 1, z: l.z }); } catch {} K.burst(p.dimension, l, "minecraft:lava_particle", 3, 0.5, 0.9); } K.sound(p, "random.anvil_use", 0.5); await K.wait(5); } K.act(e, 0); }

/* ---------- 1話 外れの 鍛冶場 ---------- */
const E1 = { id: "r3e1", n: 1, t: "外れの 鍛冶場", at: 0, ord: 0, place: FORGE,
  hint: "§fヴォルカ火山帯の §eようがんの 里 ラヴィの 外れの 鍛冶場§f へ 行こう §7（ジンの 伝言。右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "ラヴィの 外れの 鍛冶場で、見習い鍛冶の トンボと、口の 悪い 親方 ゲンに 出会った。ゲンは 六影の「台座を 打て」と いう 注文を 叩き出したが、兄弟子の ザクは 金に 困って 迷って いた。トンボの 夢は、火祭りで 初めての 刀を 打つ こと。ゲンは こっそり「あいつの 槌の 音は、わしの 若い ころより いい」と 言った。",
  set: { met3: 1 },
  async run(p, d, K) {
    { const S = K.S(p); if (S) try { decorPlace(p.dimension, "forge", S.P); } catch {} }
    await K.open(p, "ようがんの 里 ラヴィの 外れの 鍛冶場", "day");
    const eH = K.hero(p), eT = K.cast(p, "r3tombo");
    await hammer(K, p, eT, 3);
    await K.hsay(p, K.V(["{shock,!,jump,up}あつっ！ ……でも、いい 音！ カーン、カーンって！"], ["{smile}……熱いけど、きれいな 音ね。"], ["{closed}……いい 音。迷いが ない。"], ["{smile,!}まあ……澄んだ 槌の 音です。"]));
    await K.csay(p, "r3tombo", ["{smile,!}いらっしゃいッス！ ……あっ、お客さんじゃ ないッスか？"], eH);
    await K.hsay(p, K.V(["{smile}ジンさんの 伝言で 来たの。この 鍛冶場で、六影が 何か 頼んだって。"], ["{smile}ジンさんの 伝言で 来たの。六影の ことで、少し 聞きたくて。"], ["{closed}ジンの 伝言。六影が ここで 何か 注文した、って。"], ["{smile}ジンさんの ご伝言で 参りました。六影の ことで。"]));
    const eG = K.cast(p, "r3gen"); K.act(eG, "hold");
    await K.low(p, eG, 12);
    await K.csay(p, "r3gen", ["{closed}わしが この 鍛冶場の 親方、ゲンでい。", "{angry,up}六影？ ……ああ、来たでい。妙な 台座を 打てと 言いやがった。もちろん 叩き出して やったでい！"], eH);
    K.act(eG, 0);
    await K.csay(p, "r3tombo", ["{sweat,汗}兄弟子の ザクさんは、お金に 困ってて……ちょっと、迷ってたッス。"]);
    K.act(eG, "point");
    await K.csay(p, "r3gen", ["{angry,怒,up}トンボ！ 余計な ことを 言うんじゃ ねえでい！"]);
    K.act(eG, 0);
    await K.csay(p, "r3tombo", ["{sweat,汗}ひっ……す、すまないッス！"]);
    K.act(eT, "raise");
    await K.csay(p, "r3tombo", ["{smile,☆,up}お、おれ、トンボって いうッス！ 夢は、火祭りで 初めての 刀を 打つ ことッス！"], eH);
    K.act(eT, 0);
    await K.csay(p, "r3gen", ["{closed}十年 早いでい。"]);
    await K.csay(p, "r3tombo", ["{sad,…}……ッス。"]);
    if (ok(eG) && ok(eH)) { const q = eH.location; await K.go(eG, { x: q.x + 1.4, y: q.y, z: q.z - 0.6 }, 12); }
    await K.up(p, eG, 12);
    await K.csay(p, "r3gen", ["{smile,low}……あいつの 槌の 音は、わしの 若い ころより いいでい。", "{closed}本人には 言うなよ。調子に 乗るでい。"]);
    await K.hsay(p, K.V(["{smile,♪,up}ふふ、ないしょに しとく！"], ["{smile,up}……ふふ。ないしょね。"], ["{closed,up}……言わない。"], ["{smile,up}……はい。ないしょに いたします。"]), eG);
    await K.csay(p, "r3gen", ["{closed}七日後は 火祭りでい。鉱山で 祭りの 鉄を 掘るのが、毎年の 習わしでい。", "{smile}トンボ、旅の 人を 案内して やれ。人手は 多い ほうが いいでい。"], eT);
    K.act(eT, "raise");
    await K.csay(p, "r3tombo", ["{smile,☆,jump,up}ッス！ あした、鉱山の 入口で 待ってるッス！"]);
    K.act(eT, 0);
    K.pay(p, E1, 150, [["c_fruit", 2]]);
    await K.end(p, { leave: [eT], bye: [eG], card: "§7→ あした、ラヴィの 外れの 鉱山の 入口で トンボと 祭りの 鉄を 掘ろう（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 2話 火祭りの 支度（鉱山・カグラと 鍛冶組合）---------- */
const E2 = { id: "r3e2", n: 2, t: "火祭りの 支度", at: 0, ord: 1, place: MINE,
  hint: "§fラヴィの 外れの §e鉱山の 入口§f へ 行こう §7（右上の 案内。トンボと 火祭りの 鉄を 掘る。「！」の 目印の そばで 立ち止まろう）",
  syn: "鉱山で トンボと 火祭りの 鉄を 掘って いると、地方マスターの カグラが 来て「六影が いる 今、人の 集まる 祭りは やめなさい」と 告げた。親方 ゲンは「火祭りの 刀は、戦の 刀じゃ ねえ」と ゆずらない。カグラが 去った あと、ゲンは ぽつりと 話した。カグラの 母は 祭りの 夜、舞いながら 足が 炭に なったのだ と。",
  set: { met3: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    await K.open(p, "ラヴィの 外れ 鉱山の 入口", "day");
    let eH = K.hero(p); const eT = K.cast(p, "r3tombo"); K.act(eT, "raise");
    await K.csay(p, "r3tombo", ["{smile,♪,jump}来て くれたッス！ 今日は 祭りの 鉄、どっさり 掘るッス！"]);
    K.act(eT, 0);
    const oq = { x: c.x + 7, y: y0, z: c.z - 3 };
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, oq, "minecraft:lava_particle", 4, 0.6, 0.6); K.sound(p, "dig.stone", 1); await K.wait(5); }
    await K.at(p, oq, 14, 3.5, 0.8);
    await K.csay(p, "r3tombo", ["{smile,☆,up}この 赤い 筋が『火の 鉄』ッス！ 火祭りの 刀は、これで 打つッス！"]);
    await K.hsay(p, K.V(["{smile,☆}きれい……！ 石の 中で 火が 光ってるみたい！"], ["{smile}……きれいね。石の 中に、火が 眠ってる みたい。"], ["{closed}……赤い 鉄。熱を 持ってる。"], ["{smile}まあ……石の 中に 火が 宿って いる よう。"]));
    /* カグラ */
    K.sound(p, "note.bell", 0.6);
    const eK = K.cast(p, "r3kagura"); K.act(eK, "hold");
    await K.low(p, eK, 12);
    await K.csay(p, "r3kagura", ["{closed}……鍛冶組合の 子ね。ゲン親方に 伝えて。", "{angry,up}今年の 火祭りは、取りやめなさい。"], eT);
    await K.csay(p, "r3tombo", ["{shock,!,up}えっ……！？ な、なんでッスか！"]);
    K.act(eK, 0);
    await K.csay(p, "r3kagura", ["{sad}六影が この 地方に 入って いる。人が 集まる 夜を 狙われたら、どう するの。", "{angry,up}それに 組合には、城の 守りの 武器を 打って ほしいと 頼んだはず。返事は『祭りが 先だ』。"], eH);
    const eG = K.cast(p, "r3gen"); K.act(eG, "guard");
    await K.csay(p, "r3gen", ["{angry,怒,up}火祭りの 刀は、戦の 刀じゃ ねえでい！ 城の 注文は、祭りの あとでい！"], eK);
    await K.two(p, eK, eG, 12);
    await K.csay(p, "r3kagura", ["{angry}……親方の 頑固は、母の 代から 変わらないのね。"]);
    K.act(eG, 0);
    await K.csay(p, "r3gen", ["{closed}おまえさんの 母さんは、毎年 火祭りで 舞って くれたでい。", "{closed}祭りを やめろとは、一度も 言わなかったでい。"], eK);
    await K.up(p, eK, 12);
    await K.csay(p, "r3kagura", ["{sad,…,up}…………母の 話は、しないで。"]);
    await out(K, p, eK, false);
    await K.hsay(p, K.V(["{sad,up}……カグラさん、何か 抱えてる 顔 してた。"], ["{sad,up}……つらそうな 目を してたわ。"], ["{closed,up}……あれは 怒りじゃ ない。こわがってる 顔。"], ["{sad,up}……カグラさま、お つらそうでした。"]));
    /* 第124版(合議): 鉱山の 野生との 戦いは 切った（「おびえた 野生を しずめる」の くり返しを へらす）。古い 印 r3e2w は そのまま 残る */
    eH = K.hero(p, false);
    const eT2 = K.cast(p, "r3tombo", true), eG2 = K.cast(p, "r3gen", true);
    await K.csay(p, "r3tombo", ["{smile,☆,up}鉄、たくさん 取れたッス！", "{sad}……でも、祭り、どう なるッスか……。"], eG2);
    await K.csay(p, "r3gen", ["{closed}やるでい。……わしらが 打つのは、人を 守る 火でい。"]);
    if (ok(eG2) && ok(eH)) { const q = eH.location; await K.go(eG2, { x: q.x + 1.4, y: q.y, z: q.z + 0.6 }, 12); }
    await K.up(p, eG2, 12);
    await K.csay(p, "r3gen", ["{sad,low}……カグラの 嬢ちゃんの 母さんはな、祭りの 夜に 舞いながら、足が 炭に なったんでい。", "{closed,up}あの子が 祭りを 嫌うのは、こわいからでい。……わしは それを 知ってて、祭りを やめねえ。ひでえ じじいでい。"]);
    await K.hsay(p, K.V(["{sad,up}……ゲンさん。"], ["{sad,up}……ゲンさん。"], ["{closed,up}……ゲン。"], ["{sad,up}……ゲンさま。"]), eG2);
    await K.csay(p, "r3gen", ["{closed,up}……十二年前、火で 焼けた 村から、泣いてる 子を 一人 拾ったんでい。", "{smile}……今じゃ 生意気な 見習いでい。"], eT2);
    K.pay(p, E2, 250, [["c_fruit", 2], ["e_golem1", 1]]);
    await K.end(p, { leave: [eT2, eG2], card: "§7→ ラヴィの 外れの 鉄の 運び道へ。祭りの 鉄を 運ぼう（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 3話 火薬の におい（爆弾班・赤い 外套の 女）---------- */
const E3 = { id: "r3e3", n: 3, t: "火薬の におい", at: 0, ord: 2, place: HAUL,
  hint: "§fラヴィの 外れの §e鉄の 運び道§f へ 行こう §7（右上の 案内。トンボと 祭りの 鉄を 運ぶ。「！」の 目印の そばで 立ち止まろう）",
  syn: "祭りの 鉄を 運ぶ とちゅう、六影 爆弾班の 下っぱが 鉄を 奪おうと した。「台座が できなきゃ、鍛冶場の 炉に 火薬だ」。下っぱを 退けると、赤い 外套の 女が 現れ「鍛冶の 火を、脅しに 使うんじゃ ない」と 叱りつけた。女は トンボの 焦げだらけの 手を 見て「アタシも 昔、そういう 手を してた」と つぶやき、去って いった。",
  set: { valkaSeen: 1, met3: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    await K.open(p, "ラヴィの 外れ 鉄の 運び道", "day");
    let eH = K.hero(p), eT = K.cast(p, "r3tombo"); K.act(eT, "hold");
    await K.csay(p, "r3tombo", ["{smile,♪}よいしょ、よいしょッス……！ 祭りの 鉄、重いッス！"]);
    await K.hsay(p, K.V(["{smile,♪}がんばれ トンボくん！ ……あれ？ なんか、変な におい。"], ["{smile}あと 少しね。……あら？ 焦げた ような におい。"], ["{closed}……におう。火薬。"], ["{smile}あと 少しです。……あの、何か 焦げた においが。"]));
    K.act(eT, 0);
    K.sound(p, "random.fuse", 1);
    const eA = K.npcNear(p, "§c爆弾班 ドカン", K.PJ("noxa", 9)), eB = K.npcNear(p, "§c爆弾班 パチ", K.PJ("noxb", 9));
    K.act(eA, "point");
    await K.low(p, eA, 12);
    await K.say(p, "ドカン", ["{smile,low}へっへ。いい 鉄じゃ ねえか。祭りの 鉄は、六影 爆弾班が いただくぜ。"]);
    await K.say(p, "パチ", ["{angry}台座の 材料に ちょうど いいって、ボムの 兄貴が 言ってたぜ！"], eA);
    await K.csay(p, "r3tombo", ["{angry,怒,up}だめッス！ これは 火祭りの 鉄ッス！！"]);
    await K.say(p, "ドカン", ["{angry}鍛冶場の ザクにも 言っとけ。台座が できなきゃ、炉に 火薬を ぶちこむってな！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,怒,up}鉄は 渡さない！ 火薬なんて、ぜったい させない！"], ["{angry,up}……鉄も、炉も、渡さないわ。"], ["{angry,up}……渡さない。帰れ。"], ["{angry,怒,up}鉄は お渡し できません！ 火薬など、もってのほか です！"]));
    if (!K.flag(p, "r3e3w")) {
      const r = await K.battle(p, K.team(["nether", "golem"], 26, 3), { name: "六影 爆弾班の 下っぱ", arena: "鉄の 運び道", theme: "volcano", speaker: "ドカン", lines: { half: "あちちっ……こ、こいつ 強えぞ！", low: "ボ、ボムの 兄貴ぃーっ！" } });
      if (r !== "win") return lose(K, p, "§c爆弾班 ドカン", K.PJ("noxa", 9), "ドカン", "{smile}へっへ、鉄は もらって いくぜ。");
      K.setFlag(p, "r3e3w");
    }
    eH = K.hero(p, false); eT = K.cast(p, "r3tombo", true);
    const eA2 = K.npcNear(p, "§c爆弾班 ドカン", K.PJ("noxa", 9), true), eB2 = K.npcNear(p, "§c爆弾班 パチ", K.PJ("noxb", 9), true);
    K.act(eA2, "recoil"); K.act(eB2, "kneel");
    await K.say(p, "ドカン", ["{sweat,汗}く、くそっ……！ こうなりゃ、ここで 火薬を……！"]);
    /* 赤い 外套の 女 */
    K.sound(p, "mob.blaze.shoot", 0.5);
    const eV = K.npcNear(p, "§c赤い 外套の 女", K.PJ("valka", 10));
    if (ok(eV)) K.burst(p.dimension, eV.location, "minecraft:basic_flame_particle", 6, 0.6, 0.2);
    await K.low(p, eV, 16);
    await K.say(p, "赤い 外套の 女", ["{angry,low}……火薬で 遊ぶなと、言った はずだよ。", "{closed}鉄の 出来を 見に 来たら、この ざまだ。"]);
    await K.say(p, "パチ", ["{shock,!,up}ひっ……！ あ、あ、あの 赤い 髪……！"]);
    K.act(eV, "guard");
    await K.say(p, "赤い 外套の 女", ["{angry,up}鍛冶の 火を、脅しに 使うんじゃ ない。……火を 汚すな。", "{angry,low}失せな。"], eA2);
    await K.say(p, "ドカン", ["{shock,!}に、逃げろーっ！"]);
    await Promise.all([out(K, p, eA2, true), out(K, p, eB2, true)]);
    K.act(eV, 0);
    if (ok(eV) && ok(eT)) { const q = eT.location; await K.go(eV, { x: q.x + 1.4, y: q.y, z: q.z + 0.5 }, 14); }
    K.act(eV, "hold");
    await K.up(p, eV, 12);
    await K.say(p, "赤い 外套の 女", ["{closed}……いい 鉄だ。これを 打つのは、アンタかい？"], eT);
    await K.csay(p, "r3tombo", ["{sweat,汗,up}は、はいッス！ ……まだ 見習いッスけど。"]);
    await K.say(p, "赤い 外套の 女", ["{smile,low}……見習いの 手だね。焦げた 跡が いっぱいだ。", "{sad,…,up}……アタシも 昔、そういう 手を してた。"]);
    K.act(eV, 0);
    await K.say(p, "赤い 外套の 女", ["{closed}祭り、やれると いいね。"], eH);
    await out(K, p, eV, false);
    await K.hsay(p, K.V(["{?,up}……だれ、今の 人？ 下っぱが すごく こわがってた。"], ["{?,up}……今の 人、だれかしら。"], ["{?,up}……何者。"], ["{?,up}……今の 方は、どなたでしょう。"]));
    await K.csay(p, "r3tombo", ["{shock,…,up}……あの 人の 手、すごい 鍛冶だこ だったッス。小さい ころから、ずっと 槌を 振って きた 手ッス。"]);
    await K.hsay(p, K.V(["{closed}……鍛冶場へ 急ごう。火薬の こと、ゲンさんに 知らせなきゃ。"], ["{closed}……鍛冶場へ 急ぎましょう。ゲンさんに 知らせなきゃ。"], ["{closed}……鍛冶場へ。急ぐ。"], ["{closed}……鍛冶場へ 急ぎましょう。ゲンさんに お知らせ しなくては。"]), eT);
    K.pay(p, E3, 300, [["c_fruit", 2], ["e_nether1", 1]]);
    await K.end(p, { leave: [eT], card: "§7→ ラヴィの 外れの 鍛冶場へ 急ごう（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 4話 つづき 鍛冶場の 夜（ヴァルカが トンボを 見る・父の 未完の 刀）---------- */
const E4 = { id: "r3e4", n: 4, t: "鍛冶場の 夜", at: 1, ord: 0, place: FORGE,
  hint: "§fラヴィの 外れの §e焼けた 鍛冶場§f へ もどろう §7（右上の 案内。夜、まだ 槌の 音が する。「！」の 目印の そばで 立ち止まろう）",
  syn: "火事で 腕に やけどを した ゲンに かわり、トンボは「火祭りの 刀は、おれが 打つ」と 決めた。その 夜、ヴァルカが 焼けた 鍛冶場に 現れ、鉄を 盗みに 来た 爆弾班の 下っぱを 止めた。背の 布に 巻かれて いたのは、父の 最後の、結びの ない 刀。ヴァルカは トンボに 一度だけ 槌の 振り方を 教え「アタシは 自分の 分しか 知らない。それで いいんだ」と 去った。",
  set: { tomboVow: 1, met3: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), tomboVow: 1 }; },
  async run(p, d, K) {
    { const S = K.S(p); if (S) try { decorPlace(p.dimension, "forge", S.P); } catch {} }
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    await K.open(p, "焼けた 鍛冶場（夜）", "night");
    K.ambient(p, "ash", { x: c.x, y: y0, z: c.z });
    let eH = K.hero(p); const eT = K.cast(p, "r3tombo");
    await K.narr(p, ["§7火事の 夜から 二日。焼けた 鍛冶場に、まだ 槌の 音が 響いて いた。"], eT);
    await hammer(K, p, eT, 3);
    const eG = K.cast(p, "r3gen"); K.act(eG, "kneel");
    await K.csay(p, "r3gen", ["{sweat,汗}……来たか。わしは この ざまでい。", "{closed}火事の とき、炉の 前で トンボを かばってな。腕が、言う ことを きかねえでい。"], eH);
    await K.hsay(p, K.V(["{sad,up}ゲンさん……その 腕……。"], ["{sad,up}……ひどい やけど。"], ["{sad,up}……その 腕。"], ["{sad,up}ゲンさま、その お腕……。"]));
    K.act(eT, "raise");
    await K.up(p, eT, 12);
    await K.csay(p, "r3tombo", ["{angry,!,up}……決めたッス！ 親方の 腕が 治るまで、おれが 打つッス！", "{angry,up}火祭りの 刀も、おれ 一人で 打つッス！"], eG);
    await K.csay(p, "r3gen", ["{angry}……十年 早いと 言ったでい。"]);
    K.act(eT, "guard");
    await K.csay(p, "r3tombo", ["{cry,tears,up}でも、だれかが 打たなきゃ、祭りが なくなるッス！！"]);
    await K.up(p, eG, 12); turnTo(K, eG, K.away(eG, p, 3));   /* 背を 向けたまま 言う */
    await K.csay(p, "r3gen", ["{closed,…}…………。", "{smile,tears,up}……勝手に しやがれってんでい。"]);
    K.act(eT, 0);
    /* 鉄を 盗みに 来た 下っぱ */
    K.sound(p, "random.fuse", 0.6);
    const eA = K.npcNear(p, "§c爆弾班 ドカン", K.PJ("noxa", 9)), eB = K.npcNear(p, "§c爆弾班 パチ", K.PJ("noxb", 9));
    await K.say(p, "ドカン", ["{smile,low}へへ……親方が 寝てる うちに、祭りの 鉄を……"]);
    const eV = VALKA(K, p);
    if (ok(eV)) { K.burst(p.dimension, eV.location, "minecraft:basic_flame_particle", 8, 0.8, 0.2); K.flash(p, true); }
    await K.sixMark(p, eV, "valka");
    await K.up(p, eV, 10);
    await K.say(p, "ヴァルカ", ["{angry,怒,up}ドカン、パチ。……祭りの 鉄から、手を 離しな。"], eA);
    await K.say(p, "パチ", ["{sweat,汗}ひっ……ヴァ、ヴァルカ様！ で、でも ボムの 兄貴が……"]);
    await K.say(p, "ヴァルカ", ["{angry,low}ボムは 城の 兵に 引きわたされて、今は 牢だ。……アンタらも 入るかい？"]);
    await K.say(p, "ドカン", ["{rage,怒,up}う、うるせえ！ 手ぶらで 帰れるかよ！ ガキ、勝負だ！"]);
    await K.csay(p, "r3tombo", ["{shock,!,up}あ……！ 運び道の、赤い 外套の 人ッス……！"]);
    K.act(eV, "hold");
    await K.say(p, "ヴァルカ", ["{closed}……アタシは 手を 出さないよ。アンタが 追い払いな。", "{smile,low}……試しだ。"], eH);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,up}言われなくても！ 鉄は 渡さない！"], ["{angry,up}……言われなくても、守るわ。"], ["{angry,up}……言われなくても。"], ["{angry,up}言われずとも、お守り します！"]));
    if (!K.flag(p, "r3e4w")) {
      const r = await K.battle(p, K.team(["nether", "dragon"], 30, 3), { name: "六影 爆弾班の 下っぱ", arena: "鍛冶場の 夜", theme: "volcano", speaker: "ドカン", lines: { half: "ヴァ、ヴァルカ様が 見てる……！", low: "ひぃっ、退却ーっ！" } });
      if (r !== "win") return lose(K, p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), "ヴァルカ", "{closed,low}……まだまだ だね。出直して きな。");
      K.setFlag(p, "r3e4w");
    }
    eH = K.hero(p, false);
    { const a = K.npcNear(p, "§c爆弾班 ドカン", K.PJ("noxa", 9), true), b = K.npcNear(p, "§c爆弾班 パチ", K.PJ("noxb", 9), true); K.act(a, "recoil"); await Promise.all([out(K, p, a, true), out(K, p, b, true)]); }
    const eV2 = VALKA(K, p, true), eT2 = K.cast(p, "r3tombo", true), eG2 = K.cast(p, "r3gen", true);
    K.act(eG2, "kneel");
    await K.hsay(p, K.V(["{angry,up}……ヴァルカ。何しに 来たの。"], ["{angry,up}……何しに 来たの。"], ["{angry,up}……用は 何。"], ["{angry,up}……何の ご用ですか。"]), eV2);
    await K.say(p, "ヴァルカ", ["{closed}今夜は 戦いに 来たんじゃ ない。……槌の 音を、聞きに 来ただけさ。"]);
    await hammer(K, p, eT2, 2);
    await K.memory(p, eV2, "ヴァルカの 背の 刀", ["§7ヴァルカの 背に、布で 巻いた 一振りの 刀。§f柄も 鍔も なく、刃の 結びが 打たれて いない§7。", "§7……未完の 刀だった。"]);
    await K.up(p, eV2, 12);
    await K.say(p, "ヴァルカ", ["{closed,…,up}……親父の 最後の 刀さ。結びを 打つ 前に、親父は 影に 飲まれた。", "{sad,low}親父が 打った 刀で、村が 一つ 焼けた。……火は 罪じゃ ない。打つ やつの 心だ。"], eT2);
    await K.say(p, "ヴァルカ", ["{sad,up}親父は 最後に『この 刀は 人を 守る』って、嘘を ついた。", "{closed,up}……だから アタシは、嘘を つかない。"]);
    await K.up(p, eV2, 24);   /* 第124版(dir#10): ヴァルカが トンボを 見つめる（台詞なし。出自は ここで 言わない）*/
    K.re(eV2, "sad", "…");
    await K.two(p, eV2, eT2, 20);
    await K.say(p, "ヴァルカ", ["{shock,…,up}…………。"]);
    await K.csay(p, "r3tombo", ["{sad,up}……その 刀、結びを 打たないんスか？"]);
    await K.say(p, "ヴァルカ", ["{closed}……まだ、打てないんだよ。"]);
    K.act(eV2, "point");
    await K.say(p, "ヴァルカ", ["{angry}トンボ。槌を 振る とき、息を 止めるな。火に 合わせて 吐け。", "{smile,low}もう 一度 打って みな。……試しだ。"], eT2);
    K.act(eV2, 0);
    await hammer(K, p, eT2, 3);
    for (let i = 0; i < 3; i++) { if (ok(eT2)) K.burst(p.dimension, eT2.location, "minecraft:basic_flame_particle", 8, 0.8, 1); await K.wait(3); }
    await K.csay(p, "r3tombo", ["{shock,!,up}……音が、ちがうッス！ 鉄が、歌ってるッス！"]);
    await K.say(p, "ヴァルカ", ["{smile,up}……いい 音だ。昔の アタシより、いい。"]);
    await K.hsay(p, K.V(["{?,up}……ヴァルカ。なんで 六影に いるの？ 何を しようと してるの？"], ["{?,up}……あなたは、何の ために 六影に いるの？"], ["{?,up}……六影で、何を してる。"], ["{?,up}……あなたは なぜ、六影に？"]), eV2);
    await K.say(p, "ヴァルカ", ["{closed}さあね。アタシは 自分の 分しか 知らない。", "{smile,low}……それで いいんだ。"]);
    K.act(eV2, 0);
    await K.say(p, "ヴァルカ", ["{closed}……祭り、やれると いいね。"], eT2);
    await out(K, p, eV2, false);
    await K.up(p, eG2, 12);
    await K.csay(p, "r3gen", ["{closed,…}……あの 女、鍛冶の 家の 子でい。槌の 握りで わかるんでい。"]);
    K.act(eT2, "raise");
    await K.csay(p, "r3tombo", ["{angry,!,up}親方！ おれ、打つッス！ 火祭りまでに、ぜったい 刀を 打つッス！"], eG2);
    await K.csay(p, "r3gen", ["{smile,tears,up}……ああ。打て。わしが 横で 見てるんでい。"]);
    K.act(eT2, 0);
    await K.hsay(p, K.V(["{smile,up}……じゃあ わたしたちは、カグラさんに 勝って 石板を。祭りまでに、ぜったい もどる！"], ["{smile,up}……わたしたちは、カグラさんの ところへ。祭りまでに、もどるわ。"], ["{closed,up}……カグラに 勝って くる。祭りには、もどる。"], ["{smile,up}わたしたちは カグラさまの もとへ。祭りまでに、必ず もどります。"]));
    K.pay(p, E4, 400, [["c_fruit2", 1], ["e_dragon1", 1]]);
    await K.end(p, { leave: [eT2], bye: [eG2], card: "§7→ 鍛冶王の 城 フォルジアの 中庭で §6カグラ§7 に 話しかけて 勝負（勝つと 石板。火祭りは そのあと）", kind: "night" });
    return true;
  } };

/* ---------- 5話 火祭り（カグラに 勝った あと。トンボの 初めての 刀・里の 発展度・祭り）---------- */
const E5 = { id: "r3e5", n: 5, t: "火祭り", at: 2, ord: 0, place: FEST,
  hint: "§fラヴィの 外れの §e火祭りの 広場§f で §6火祭り§f が 開かれる §7（右上の 案内。トンボが 刀を 打ち上げた。そのあと サンドリアへ）",
  syn: "カグラに 勝った 夜、ラヴィで 火祭りが 開かれた。カグラは「燃やすんじゃ なく、聞いた うえで 選ぶ」と 言い、母の 好きだった 祭りの 舞を 舞った。鍛冶組合は 城の 守りの 武器を 打つ ことに なった。トンボは 初めての 刀『ホムラ』を あなたたちに 託した。祭りの 灯りの 向こう、岩の 上に、赤い 外套が 一つ 見えた。",
  set: { fest3: 1, met3: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest3: 1 }; },
  fx: { xp: [TID, 160], fest: TID },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), C = { x: c.x, y: y0, z: c.z };
    K.deco(p, "t30fest", 1, c, y0); K.deco(p, "t30fest", 2, c, y0);
    await K.open(p, "ラヴィの 火祭り", "fest");
    K.sound(p, "note.bd", 1); K.sound(p, "firework.blast", 0.6);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, C, "minecraft:basic_flame_particle", 12, 6, 2); await K.wait(4); }
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{smile,☆,jump,up}わあ……！ 火の 粉が 星みたい！"], ["{smile,up}……きれい。火が 踊ってる みたい。"], ["{smile,up}……悪くない。火が きれいだ。"], ["{smile,☆,up}まあ……火の 粉が、まるで 星の よう。"]));
    const eT = K.cast(p, "r3tombo"), eG = K.cast(p, "r3gen");
    await K.csay(p, "r3gen", ["{smile}来たか、石板の。……カグラの 嬢ちゃんに、勝ったそうでい。"], eH);
    const eK = K.cast(p, "r3kagura"); K.act(eK, "hold");
    await K.csay(p, "r3kagura", ["{closed}……来たわ。組合の 祭りを、見に。"]);
    await K.csay(p, "r3gen", ["{shock,!,up}……カグラの 嬢ちゃん。"]);
    await K.up(p, eK, 12);
    await K.csay(p, "r3kagura", ["{sad,up}あなたたちに 負けて、わかったの。燃やすんじゃ なく、聞いた うえで 選ぶ。", "{smile,tears,up}母は、この 祭りが 好きだった。……だから わたしも、今夜は 舞うわ。封じの 舞じゃ なくて、祭りの 舞を。"], eG);
    await K.csay(p, "r3gen", ["{smile,tears,up}……城の 注文、あしたから 打つでい。組合 総出でな。"]);
    await K.csay(p, "r3kagura", ["{smile,up}ええ。……ありがとう、親方。"]);
    K.act(eK, 0);
    /* 祭りの 舞 */
    K.act(eK, 9);
    for (const e of [eT, eG, eH]) K.act(e, 9);
    K.ambient(p, "fest", C); K.sound(p, "note.bd", 1); K.sound(p, "note.harp", 0.8);
    for (let i = 0; i < 3; i++) { if (ok(eK)) K.burst(p.dimension, eK.location, "minecraft:basic_flame_particle", 10, 1.2, 1); await K.wait(4); }
    await K.wide(p, 24);
    for (const e of [eK, eT, eG, eH]) K.act(e, 0);
    /* トンボの 刀 */
    K.act(eT, "hold");
    await K.up(p, eT, 12);
    await K.csay(p, "r3tombo", ["{sweat,汗,up}あ、あの……！ これ、おれの 初めての 刀ッス！！", "{smile,tears,up}石板を 守る 旅に、持って いって ほしいッス！"], eH);
    if (ok(eT)) { const l = eT.location; try { p.dimension.spawnParticle("mrpg:sparks", { x: l.x, y: l.y + 1.2, z: l.z }); } catch {} K.burst(p.dimension, l, "minecraft:endrod", 4, 0.4, 1.2); K.sound(p, "random.orb", 1.2); }
    await K.hsay(p, K.V(["{shock,!,up}……わたしたちに！？ ありがとう、トンボくん！ 大事に する！"], ["{smile,tears,up}……わたしたちに？ ありがとう、トンボくん。大切に するわ。"], ["{shock,…,up}……いいの？ ……ありがとう。大事に する。"], ["{smile,tears,up}わたしたちに……！？ ありがとう ございます。大切に いたします！"]));
    await K.csay(p, "r3gen", ["{closed}……銘は『ホムラ』。トンボが 付けたでい。", "{smile,tears,nod}……いい 刀でい。わしの 初打ちより、ずっと いいでい。"], eT);
    { const q = nearPt(eT, eG, 0.9); if (q) await K.go(eT, q, 8, true); } K.act(eT, 23); K.act(eG, 23); await K.two(p, eT, eG, 10);   /* 親方に だきつく */
    await K.csay(p, "r3tombo", ["{cry,tears,up}お、親方ぁ……！！"]);
    const got = K.pay(p, E5, 800, [["wp_sword1_fire", 1], ["mei_volka", 2]]);
    if (got.length) K.big(p, "§c§lトンボの 刀", `§e${got.join("・")}`);
    K.act(eT, 0);
    /* 岩の 上の 赤い 外套 */
    const rq = { x: c.x - 12, y: y0 + 3, z: c.z + 8 };
    K.burst(p.dimension, rq, "minecraft:basic_flame_particle", 4, 0.3, 0.6);
    await K.at(p, rq, 14, 8, 1);
    await K.narr(p, ["§7祭りの 灯りの 向こう。岩の 上に、赤い 外套が 一つ……。", "§7気づいた ときには、もう いなかった。"], rq);
    K.act(eT, 5); K.act(eG, 5);   /* 手を ふる */
    await K.csay(p, "r3tombo", ["{smile,♪,up}いって らっしゃいッス！ 次は もっと いい 刀を 打って 待ってるッス！"]);
    await K.csay(p, "r3gen", ["{smile,up}いって こい！ 刀が 欠けたら、いつでも 持って くるんでい！"]);
    K.act(eH, 5);
    await K.hsay(p, K.V(["{smile,tears,up}……いって きます！！"], ["{smile,tears,up}……いって きます。"], ["{smile,up}……いって きます。"], ["{smile,tears,up}……いって まいります！"]));
    await K.end(p, { leave: [eK], bye: [eT, eG], card: "§f― 第4章 炎の 幹部 おわり ―\n§7→ 次は サンドリア砂漠へ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(3, [E1, E2, E3, E4, E5], { steps: { 0: [4, "炎の 幹部（燃える 鍛冶場）"], 1: [5, "火祭り（カグラとの 勝負）"] } });
