// 第106版: 城下町（都）と 町の 設計図。ブロックを 置く コマンドだけを 作る（置くのは structures.js の キュー）
// 座標は 中心（x,z）と 地面の 高さ（y=0）からの ずれ。高低差の ある 台地・崖・森の 上に 建てる
// 重く ならない ように: 地面は 行ごとに まとめた fill、建物は 箱の fill を 組み合わせる

/* ---------- 乱数と ノイズ（同じ 町は 毎回 同じ 形）---------- */
export function rng(seed) { let s = (seed >>> 0) || 1; return () => { s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const hash2 = (x, z, s) => { let h = (x * 374761393 + z * 668265263 + s * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
function noise(x, z, s, sc) { const fx = x / sc, fz = z / sc, x0 = Math.floor(fx), z0 = Math.floor(fz), tx = fx - x0, tz = fz - z0, sm = (t) => t * t * (3 - 2 * t);
  const a = hash2(x0, z0, s), b = hash2(x0 + 1, z0, s), c = hash2(x0, z0 + 1, s), d = hash2(x0 + 1, z0 + 1, s), u = sm(tx), v = sm(tz);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v; }

/* ---------- 地方ごとの 素材 ---------- */
export const PAL = {
  village: { wall: "white_terracotta", base: "stone_bricks", beam: "dark_oak_log", floor: "spruce_planks", roof: "red_nether_bricks", roof2: "brick_block", trim: "stripped_dark_oak_log", stone: "stone_bricks", stone2: "andesite", cw: "stone_bricks", cw2: "mossy_stone_bricks", path: "polished_andesite", path2: "stone_bricks", plaza: "smooth_stone", ground: "grass_block", leaf: "oak_leaves", log: "oak_log", leaf2: "birch_leaves", log2: "birch_log", lamp: "lantern", glass: "glass_pane", flower: ["poppy", "dandelion", "cornflower", "oxeye_daisy", "azure_bluet", "allium"], cliff: ["stone", "andesite", "stone", "cobblestone", "mossy_cobblestone"], banner: "red_wool", accent: "blue_wool", water: "water" },
  forest: { wall: "stripped_spruce_log", base: "mossy_cobblestone", beam: "spruce_log", floor: "spruce_planks", roof: "dark_oak_planks", roof2: "spruce_planks", trim: "stripped_spruce_log", stone: "mossy_stone_bricks", stone2: "cobblestone", cw: "mossy_stone_bricks", cw2: "mossy_cobblestone", path: "coarse_dirt", path2: "mossy_cobblestone", plaza: "mossy_stone_bricks", ground: "podzol", leaf: "spruce_leaves", log: "spruce_log", leaf2: "dark_oak_leaves", log2: "dark_oak_log", lamp: "lantern", glass: "glass_pane", flower: ["lily_of_the_valley", "fern", "azure_bluet"], cliff: ["stone", "mossy_cobblestone", "andesite", "tuff"], banner: "green_wool", accent: "brown_wool", water: "water" },
  castle: { wall: "smooth_stone", base: "cobblestone", beam: "dark_oak_log", floor: "dark_oak_planks", roof: "deepslate_tiles", roof2: "polished_deepslate", trim: "chiseled_stone_bricks", stone: "stone_bricks", stone2: "cracked_stone_bricks", cw: "stone_bricks", cw2: "cracked_stone_bricks", path: "stone_bricks", path2: "cobblestone", plaza: "polished_andesite", ground: "grass_block", leaf: "dark_oak_leaves", log: "dark_oak_log", leaf2: "oak_leaves", log2: "oak_log", lamp: "lantern", glass: "glass_pane", flower: ["poppy", "red_tulip", "allium"], cliff: ["stone", "andesite", "cobblestone", "gravel"], banner: "purple_wool", accent: "yellow_wool", water: "water" },
  volcano: { wall: "polished_blackstone_bricks", base: "blackstone", beam: "crimson_stem", floor: "crimson_planks", roof: "red_nether_bricks", roof2: "nether_bricks", trim: "gilded_blackstone", stone: "polished_blackstone_bricks", stone2: "blackstone", cw: "polished_blackstone_bricks", cw2: "cracked_polished_blackstone_bricks", path: "polished_blackstone", path2: "basalt", plaza: "polished_basalt", ground: "blackstone", leaf: "shroomlight", log: "crimson_stem", leaf2: "nether_wart_block", log2: "crimson_stem", lamp: "shroomlight", glass: "red_stained_glass", flower: ["crimson_roots"], cliff: ["basalt", "blackstone", "magma", "basalt", "smooth_basalt"], banner: "orange_wool", accent: "black_wool", water: "lava" },
  desert: { wall: "smooth_sandstone", base: "cut_sandstone", beam: "stripped_jungle_log", floor: "smooth_sandstone", roof: "cut_red_sandstone", roof2: "orange_terracotta", trim: "chiseled_sandstone", stone: "cut_sandstone", stone2: "sandstone", cw: "cut_sandstone", cw2: "chiseled_sandstone", path: "smooth_sandstone", path2: "cut_sandstone", plaza: "smooth_red_sandstone", ground: "sand", leaf: "jungle_leaves", log: "jungle_log", leaf2: "jungle_leaves", log2: "jungle_log", lamp: "lantern", glass: "orange_stained_glass", flower: ["deadbush", "cactus"], cliff: ["sandstone", "smooth_sandstone", "red_sandstone", "sandstone", "terracotta"], banner: "cyan_wool", accent: "orange_wool", water: "water", flat: true },
  crystal: { wall: "calcite", base: "smooth_basalt", beam: "amethyst_block", floor: "polished_deepslate", roof: "purple_terracotta", roof2: "amethyst_block", trim: "smooth_quartz", stone: "polished_deepslate", stone2: "calcite", cw: "polished_deepslate_bricks", cw2: "deepslate_bricks", path: "smooth_basalt", path2: "calcite", plaza: "polished_diorite", ground: "calcite", leaf: "azalea_leaves", log: "birch_log", leaf2: "flowering_azalea_leaves", log2: "birch_log", lamp: "end_rod", glass: "purple_stained_glass", flower: ["amethyst_cluster"], cliff: ["calcite", "tuff", "smooth_basalt", "deepslate"], banner: "magenta_wool", accent: "light_blue_wool", water: "water" },
  port: { wall: "white_terracotta", base: "prismarine_bricks", beam: "stripped_birch_log", floor: "birch_planks", roof: "light_blue_terracotta", roof2: "blue_terracotta", trim: "dark_prismarine", stone: "prismarine_bricks", stone2: "smooth_sandstone", cw: "prismarine_bricks", cw2: "dark_prismarine", path: "smooth_sandstone", path2: "birch_planks", plaza: "cut_sandstone", ground: "grass_block", leaf: "birch_leaves", log: "birch_log", leaf2: "jungle_leaves", log2: "jungle_log", lamp: "sea_lantern", glass: "light_blue_stained_glass_pane", flower: ["blue_orchid", "cornflower", "azure_bluet"], cliff: ["sandstone", "stone", "smooth_sandstone", "diorite"], banner: "blue_wool", accent: "white_wool", water: "water", sea: true },
  dark: { wall: "polished_blackstone_bricks", base: "deepslate_bricks", beam: "warped_stem", floor: "warped_planks", roof: "crimson_planks", roof2: "nether_bricks", trim: "polished_deepslate", stone: "deepslate_bricks", stone2: "cracked_deepslate_bricks", cw: "deepslate_bricks", cw2: "cracked_deepslate_bricks", path: "polished_deepslate", path2: "deepslate_tiles", plaza: "polished_blackstone", ground: "soul_soil", leaf: "warped_wart_block", log: "warped_stem", leaf2: "nether_wart_block", log2: "crimson_stem", lamp: "soul_lantern", glass: "purple_stained_glass", flower: ["wither_rose", "crimson_roots"], cliff: ["deepslate", "blackstone", "tuff", "basalt"], banner: "purple_wool", accent: "black_wool", water: "water" },
  snow: { wall: "white_concrete", base: "polished_diorite", beam: "spruce_log", floor: "spruce_planks", roof: "blue_terracotta", roof2: "packed_ice", trim: "stripped_spruce_log", stone: "polished_diorite", stone2: "stone_bricks", cw: "stone_bricks", cw2: "polished_diorite", path: "packed_ice", path2: "snow", plaza: "polished_diorite", ground: "snow", leaf: "spruce_leaves", log: "spruce_log", leaf2: "spruce_leaves", log2: "spruce_log", lamp: "lantern", glass: "glass_pane", flower: ["white_tulip"], cliff: ["stone", "packed_ice", "snow", "diorite", "stone"], banner: "light_blue_wool", accent: "white_wool", water: "water" },
  sky: { wall: "quartz_bricks", base: "smooth_quartz", beam: "quartz_pillar", floor: "birch_planks", roof: "light_blue_terracotta", roof2: "white_terracotta", trim: "gold_block", stone: "quartz_bricks", stone2: "smooth_quartz", cw: "quartz_bricks", cw2: "smooth_quartz", path: "smooth_quartz", path2: "birch_planks", plaza: "quartz_block", ground: "grass_block", leaf: "azalea_leaves", log: "birch_log", leaf2: "cherry_leaves", log2: "cherry_log", lamp: "end_rod", glass: "glass", flower: ["azure_bluet", "white_tulip", "lily_of_the_valley"], cliff: ["calcite", "diorite", "smooth_quartz", "stone"], banner: "light_blue_wool", accent: "yellow_wool", water: "water" },
  garden: null, farm: null,
};
for (const [k, L] of Object.entries({ village: ["red_nether_bricks", "brick_block", "dark_oak_planks", "deepslate_tiles", "red_nether_bricks"], forest: ["dark_oak_planks", "spruce_planks", "mossy_cobblestone"], castle: ["deepslate_tiles", "polished_deepslate", "dark_oak_planks", "red_nether_bricks"], port: ["light_blue_terracotta", "blue_terracotta", "cyan_terracotta", "white_terracotta"], desert: ["cut_red_sandstone", "orange_terracotta", "smooth_sandstone"], snow: ["blue_terracotta", "dark_oak_planks", "spruce_planks"], volcano: ["red_nether_bricks", "nether_bricks", "blackstone"], crystal: ["purple_terracotta", "magenta_terracotta", "light_blue_terracotta"], dark: ["crimson_planks", "nether_bricks", "warped_planks"], sky: ["light_blue_terracotta", "white_terracotta", "yellow_terracotta"] })) PAL[k].roofs = L;
PAL.garden = { ...PAL.village, roof: "pink_terracotta", leaf: "cherry_leaves", log: "cherry_log", leaf2: "cherry_leaves", log2: "cherry_log", flower: ["pink_tulip", "allium", "orange_tulip", "red_tulip"] };
PAL.farm = { ...PAL.village, roof: "dark_oak_planks", wall: "stripped_oak_log", ground: "grass_block", path: "dirt_path" };
export const palOf = (style) => PAL[style] || PAL.village;

/* ---------- 第106版: まわりの 自然の 地面に なじませる ---------- */
/* EDGE(x,z) = その 方向の 外の 地面の 高さ（町の 高さからの ずれ）。建てる 前に structures.js が はかって わたす */
let EDGE = null;
export function setEdge(f) { EDGE = f; }
function blendOut(h, x, z, rin, rout) {
  if (h === null || !EDGE) return h;
  const d = Math.hypot(x, z); if (d <= rin) return h;
  const n = EDGE(x, z); if (n === null || n === undefined) return h;
  const t = Math.min(1, (d - rin) / Math.max(1, rout - rin)), k = t * t * (3 - 2 * t);
  return Math.round(h * (1 - k) + n * k);
}

/* ---------- 設計図 ---------- */
/* 第106版: 統合版に ない 名前を 直す（ない ブロックの fill は 失敗して 屋根や 壁が ぬけて いた） */
const BEDROCK = { red_nether_bricks: "red_nether_brick", nether_bricks: "nether_brick", red_bed: "bed", melon: "melon_block", dirt_path: "grass_path", flowering_azalea_leaves: "azalea_leaves_flowered", polished_deepslate_bricks: "deepslate_bricks" };
const nb = (b) => { const m = String(b).match(/^\s*([a-z_]+)(.*)$/); return m && BEDROCK[m[1]] ? BEDROCK[m[1]] + m[2] : b; };
export class Blue {
  constructor(seed) { this.c = []; this.r = rng(seed); this.npc = []; this.walk = []; this.mark = {}; this.chk = []; }
  fill(x1, y1, z1, x2, y2, z2, b, mode) {
    const ax = Math.min(x1, x2), bx = Math.max(x1, x2), ay = Math.min(y1, y2), by = Math.max(y1, y2), az = Math.min(z1, z2), bz = Math.max(z1, z2);
    const v = (bx - ax + 1) * (by - ay + 1) * (bz - az + 1);
    if (v > 30000) { const my = Math.floor((ay + by) / 2); if (by > ay) { this.fill(ax, ay, az, bx, my, bz, b, mode); this.fill(ax, my + 1, az, bx, by, bz, b, mode); return; } const mx = Math.floor((ax + bx) / 2); this.fill(ax, ay, az, mx, by, bz, b, mode); this.fill(mx + 1, ay, az, bx, by, bz, b, mode); return; }
    this.c.push([0, ax, ay, az, bx, by, bz, nb(b), mode ? String(mode).replace(/^replace ([a-z_]+)/, (_, x) => "replace " + nb(x)) : ""]);
  }
  set(x, y, z, b) { this.c.push([1, x, y, z, nb(b)]); }
  pick(a) { return a[Math.floor(this.r() * a.length)]; }
  ri(a, b) { return a + Math.floor(this.r() * (b - a + 1)); }
  /* 絶対座標の コマンドに */
  cmds(cx, cy, cz) {
    cx = Math.floor(cx); cy = Math.floor(cy); cz = Math.floor(cz);
    return this.c.map((q) => q[0] ? `setblock ${cx + q[1]} ${cy + q[2]} ${cz + q[3]} ${q[4]}` : `fill ${cx + q[1]} ${cy + q[2]} ${cz + q[3]} ${cx + q[4]} ${cy + q[5]} ${cz + q[6]} ${q[7]}${q[8] ? " " + q[8] : ""}`);
  }
}

/* ---------- 地形: 台地・崖・段（高さの 地図 → 行ごとの fill）---------- */
/* H(x,z) は 地面の 高さ（null は さわらない）。崖の 面は 石の まだら・上は 草 */
function terrain(B, R, H, pal, floor = -16) {
  const cl = pal.cliff; let lo = 99;
  for (let z = -R; z <= R; z += 2) for (let x = -R; x <= R; x += 2) { const h = H(x, z); if (h !== null && h < lo) lo = h; }
  rowFill(B, R, (x, z) => H(x, z) !== null, lo, lo + 44, "air");   /* まず 上を あける（第106版: 円の 中だけ。四すみの 外の 地面を 消して 穴に なって いた） */
  for (let z = -R; z <= R; z++) {
    let x = -R;
    while (x <= R) {
      const h = H(x, z); if (h === null) { x++; continue; }
      let x2 = x; while (x2 + 1 <= R && H(x2 + 1, z) === h) x2++;
      B.fill(x, floor, z, x2, h - 2, z, cl[(z & 1) ? 0 : 1 % cl.length]);
      B.fill(x, h - 1, z, x2, h - 1, z, pal.ground);
      x = x2 + 1;
    }
  }
}
/* 行ごとに 条件の 合う 区間を まとめて fill */
function rowFill(B, R, test, y1, y2, b) {
  for (let z = -R; z <= R; z++) { let x = -R; while (x <= R) { if (!test(x, z)) { x++; continue; } let x2 = x; while (x2 + 1 <= R && test(x2 + 1, z)) x2++; B.fill(x, y1, z, x2, y2, z, b); x = x2 + 1; } }
}
/* 第108版: 砂浜（海の 手前を 砂に。水着の 人たちが 遊びに 来る）*/
function beachSand(B, R, test, H) {
  for (let z = -R; z <= R; z++) { let x = -R; while (x <= R) { const h = test(x, z) ? H(x, z) : null; if (h === null || h === undefined) { x++; continue; } let x2 = x; while (x2 + 1 <= R && test(x2 + 1, z) && H(x2 + 1, z) === h) x2++; B.fill(x, h - 2, z, x2, h - 1, z, "sand"); x = x2 + 1; } }
}
/* 崖の 面に 石の まだら（上から 見て 外がわの ふち）*/
function cliffFace(B, R, H, pal) {
  const cl = pal.cliff;
  for (let z = -R; z <= R; z += 1) for (let x = -R; x <= R; x += 1) {
    const h = H(x, z); if (h === null) continue;
    let low = h; for (const [a, b] of [[x + 1, z], [x - 1, z], [x, z + 1], [x, z - 1]]) { const g = H(a, b); if (g !== null && g < low) low = g; }
    if (low <= h - 3) B.fill(x, low, z, x, h - 2, z, cl[(x * 13 + z * 7) % cl.length]);
  }
}

/* ---------- 木・岩・草花 ---------- */
export function bigTree(B, x, y, z, pal, kind = 0) {
  const r = B.r, log = kind ? pal.log2 : pal.log, leaf = kind ? pal.leaf2 : pal.leaf, h = 6 + Math.floor(r() * 5);
  if (pal === PAL.desert) { B.fill(x, y, z, x, y + h, z, log); for (const [a, c] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { B.fill(x + a, y + h, z + c, x + a * 3, y + h - 1, z + c * 3, leaf); } return; }
  if (log.includes("spruce")) { B.fill(x, y, z, x, y + h + 2, z, log); for (let k = 0; k < 5; k++) { const rr = Math.max(0, 3 - Math.floor(k * 0.7)); B.fill(x - rr, y + 3 + k * 2, z - rr, x + rr, y + 3 + k * 2, z + rr, leaf); } B.set(x, y + h + 3, z, leaf); return; }
  B.fill(x, y, z, x, y + h, z, log);
  if (h > 7) { B.fill(x + 1, y + h - 3, z, x + 2, y + h - 3, z, log); B.fill(x - 2, y + h - 2, z, x - 1, y + h - 2, z, log); }
  B.fill(x - 3, y + h - 2, z - 3, x + 3, y + h, z + 3, leaf); B.fill(x - 2, y + h + 1, z - 2, x + 2, y + h + 2, z + 2, leaf); B.fill(x - 4, y + h - 1, z - 1, x + 4, y + h - 1, z + 1, leaf); B.fill(x - 1, y + h - 1, z - 4, x + 1, y + h - 1, z + 4, leaf);
  B.fill(x - 3, y + h - 2, z - 3, x - 3, y + h - 2, z - 3, "air"); B.fill(x + 3, y + h, z + 3, x + 3, y + h, z + 3, "air");
}
function rock(B, x, y, z, pal) { const s = 1 + Math.floor(B.r() * 2); B.fill(x - s, y, z - s + 1, x + s, y + s - 1, z + s - 1, pal.cliff[1] || "stone"); B.fill(x - s + 1, y + s, z - s + 1, x + s - 1, y + s, z + s - 1, pal.cliff[0]); }
function flowerAt(B, x, y, z, pal) { const f = B.pick(pal.flower); if (/cactus/.test(f)) { B.set(x, y - 1, z, "sand"); B.fill(x, y, z, x, y + 1, z, "cactus"); return; } if (/deadbush/.test(f)) { B.set(x, y - 1, z, "sand"); } else if (/crimson|warped|wither/.test(f)) B.set(x, y - 1, z, f.includes("wither") ? "soul_soil" : "crimson_nylium"); else if (!/amethyst/.test(f)) B.set(x, y - 1, z, "grass_block"); B.set(x, y, z, f); }

/* ---------- 建物の 部品 ---------- */
/* 切妻の 屋根（棟は 長い ほう）。張り出し 1・破風に 木の 枠 */
function roof(B, x1, z1, x2, z2, y, pal, mat) {
  mat = mat || pal.roof; const alongX = (x2 - x1) >= (z2 - z1);
  const half = Math.ceil(((alongX ? z2 - z1 : x2 - x1) + 3) / 2);
  for (let k = 0; k < half; k++) {
    if (alongX) { const a = z1 - 1 + k, b = z2 + 1 - k; if (a > b) break; B.fill(x1 - 1, y + k, a, x2 + 1, y + k, a, mat); B.fill(x1 - 1, y + k, b, x2 + 1, y + k, b, mat); if (b - a > 1) { B.fill(x1, y + k, a + 1, x1, y + k, b - 1, pal.wall); B.fill(x2, y + k, a + 1, x2, y + k, b - 1, pal.wall); } }
    else { const a = x1 - 1 + k, b = x2 + 1 - k; if (a > b) break; B.fill(a, y + k, z1 - 1, a, y + k, z2 + 1, mat); B.fill(b, y + k, z1 - 1, b, y + k, z2 + 1, mat); if (b - a > 1) { B.fill(a + 1, y + k, z1, b - 1, y + k, z1, pal.wall); B.fill(a + 1, y + k, z2, b - 1, y + k, z2, pal.wall); } }
  }
  return y + half;
}
/* 木組みの 家（何階でも）。face=扉の 向き。kind で 中の かざり */
export function house(B, x, y, z, w, d, floors, face, pal, kind = "home", opt = {}) {
  const x1 = x - Math.floor(w / 2), x2 = x1 + w - 1, z1 = z - Math.floor(d / 2), z2 = z1 + d - 1, fh = 5, top = y + floors * fh;   /* 第106版: 天井を 1つ 高く */
  B.fill(x1 - 1, y - 1, z1 - 1, x2 + 1, y - 1, z2 + 1, pal.base);
  B.fill(x1, y, z1, x2, top - 1, z2, pal.wall, "hollow");
  B.fill(x1, y, z1, x2, y, z2, pal.base, "outline"); B.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, "air");   /* 第108版: hollow の 底で 床が 1段 上がり NPC が 埋まって いた */
  for (let f = 0; f < floors; f++) { const fy = y + f * fh; if (f) B.fill(x1 + 1, fy - 1, z1 + 1, x2 - 1, fy - 1, z2 - 1, pal.floor); B.fill(x1, fy - 1 + (f ? 0 : 1), z1, x2, fy - 1 + (f ? 0 : 1), z1, pal.beam); B.fill(x1, fy - 1 + (f ? 0 : 1), z2, x2, fy - 1 + (f ? 0 : 1), z2, pal.beam); }
  B.fill(x1 + 1, y - 1, z1 + 1, x2 - 1, y - 1, z2 - 1, pal.floor);
  for (const [a, b] of [[x1, z1], [x2, z1], [x1, z2], [x2, z2]]) B.fill(a, y, b, a, top - 1, b, pal.beam);
  for (let a = x1 + 3; a < x2 - 1; a += 3) { B.fill(a, y + 1, z1, a, top - 1, z1, pal.beam); B.fill(a, y + 1, z2, a, top - 1, z2, pal.beam); }
  for (let b = z1 + 3; b < z2 - 1; b += 3) { B.fill(x1, y + 1, b, x1, top - 1, b, pal.beam); B.fill(x2, y + 1, b, x2, top - 1, b, pal.beam); }
  /* 窓（各階 2つずつ・下に 花箱）*/
  for (let f = 0; f < floors; f++) { const wy = y + f * fh + 1;
    for (let a = x1 + 2; a <= x2 - 2; a += 3) for (const b of [z1, z2]) { B.fill(a, wy, b, a, wy + 1, b, pal.glass); if (f && pal.leaf) B.set(a, wy - 1, b + (b === z1 ? -1 : 1), "azalea_leaves"); }
    for (let b = z1 + 2; b <= z2 - 2; b += 3) for (const a of [x1, x2]) B.fill(a, wy, b, a, wy + 1, b, pal.glass); }
  const rt = roof(B, x1, z1, x2, z2, top, pal, opt.roof || (pal.roofs ? B.pick(pal.roofs) : pal.roof));
  if (!opt.nochim) { const cx2 = x2 - 1, cz2 = z1 + 1; B.fill(cx2, top, cz2, cx2, rt + 1, cz2, "brick_block"); B.set(cx2, rt + 2, cz2, "campfire"); }
  /* 扉と 入口 */
  const door = face === "s" ? [x, z2] : face === "n" ? [x, z1] : face === "e" ? [x2, z] : [x1, z];
  B.fill(door[0], y, door[1], door[0], y + 2, door[1], "air");
  const out = face === "s" ? [x, z2 + 1] : face === "n" ? [x, z1 - 1] : face === "e" ? [x2 + 1, z] : [x1 - 1, z];
  B.set(out[0], y + 3, out[1], pal.lamp === "lantern" ? 'lantern ["hanging"=true]' : pal.lamp);
  if (opt.sign) { const sx = out[0] + (face === "s" || face === "n" ? 1 : 0), sz = out[1] + (face === "e" || face === "w" ? 1 : 0); B.fill(sx, y + 3, sz, sx, y + 3, sz, opt.sign); }
  /* 中: 明かり・家具 */
  B.set(x, top - 2, z, pal.lamp === "end_rod" ? "sea_lantern" : "glowstone");
  const ins = { home: [["crafting_table", -1, 1], ["barrel", 1, 1], ["red_bed", 1, -1]], shop: [["barrel", -1, 1], ["barrel", 1, 1], ["chest", 0, 1]], tavern: [["barrel", -2, 2], ["barrel", -2, 1], ["oak_fence", 1, 0], ["oak_fence", 2, 0], ["oak_fence", 1, -2]], kitchen: [["smoker", -1, 2], ["furnace", 0, 2], ["cauldron", 1, 2]], forge: [["anvil", -1, 1], ["blast_furnace", 1, 1], ["grindstone", 0, 2]], books: [["bookshelf", -2, 2], ["bookshelf", -1, 2], ["lectern", 0, 0], ["bookshelf", 1, 2]] }[kind] || [];
  for (const [b, dx, dz] of ins) if (Math.abs(dx) < w / 2 - 1 && Math.abs(dz) < d / 2 - 1) B.set(x + dx, y, z + dz, b);
  /* 第106版: 店の 人が 立つ 所（扉の 2マス 内がわ・空けて おく）*/
  const ins2 = face === "s" ? [x, z2 - 2] : face === "n" ? [x, z1 + 2] : face === "e" ? [x2 - 2, z] : [x1 + 2, z];
  B.fill(ins2[0], y, ins2[1], ins2[0], y + 1, ins2[1], "air");
  B.chk.push({ name: "建物 " + kind, pos: { x: ins2[0] + 0.5, y, z: ins2[1] + 0.5 } });   /* 第108版: 中に 入れるか の 点検用 */
  return { door: out, inside: ins2, top: rt, x1, x2, z1, z2 };
}
/* 屋台（色つきの 屋根）*/
function stall(B, x, y, z, col, pal) {
  for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) B.fill(x + a, y, z + b, x + a, y + 2, z + b, "oak_fence");
  B.fill(x - 2, y + 3, z - 2, x + 2, y + 3, z + 2, col); B.fill(x - 1, y + 4, z - 1, x + 1, y + 4, z + 1, col);
  B.fill(x - 1, y, z, x + 1, y, z, "barrel"); B.set(x, y + 1, z, B.pick(["melon", "pumpkin", "hay_block", "cake", "flower_pot", "barrel"]));
}
/* 街灯・ベンチ */
function lampPost(B, x, y, z, pal) { B.fill(x, y, z, x, y + 3, z, pal.lamp === "shroomlight" ? "nether_brick_fence" : "dark_oak_fence"); B.set(x, y + 4, z, pal.lamp === "lantern" ? "lantern" : pal.lamp); }
function bench(B, x, y, z, ax) { if (ax) B.fill(x, y, z, x + 2, y, z, 'oak_stairs ["weirdo_direction"=2]'); else B.fill(x, y, z, x, y, z + 2, 'oak_stairs ["weirdo_direction"=1]'); }
/* 噴水（3段）*/
function fountain(B, x, y, z, pal) {
  B.fill(x - 5, y - 1, z - 5, x + 5, y, z + 5, pal.stone, "outline"); B.fill(x - 4, y - 1, z - 4, x + 4, y - 1, z + 4, pal.water === "lava" ? "lava" : "water");
  B.fill(x - 4, y, z - 4, x + 4, y, z + 4, pal.stone, "outline"); B.fill(x - 3, y, z - 3, x + 3, y, z + 3, "air");
  B.fill(x - 1, y - 1, z - 1, x + 1, y + 2, z + 1, pal.trim); B.fill(x - 2, y + 3, z - 2, x + 2, y + 3, z + 2, pal.stone); B.fill(x - 1, y + 3, z - 1, x + 1, y + 3, z + 1, pal.water === "lava" ? "lava" : "water");
  B.fill(x, y + 4, z, x, y + 5, z, pal.trim); B.set(x, y + 6, z, pal.water === "lava" ? "lava" : "water");
}
/* 像（英雄の 像: 台座＋人の 形）*/
function statue(B, x, y, z, pal) {
  B.fill(x - 2, y, z - 2, x + 2, y + 2, z + 2, pal.stone); B.fill(x - 1, y + 3, z - 1, x + 1, y + 3, z + 1, pal.trim);
  B.fill(x, y + 4, z, x, y + 6, z, "polished_andesite"); B.set(x - 1, y + 6, z, "polished_andesite"); B.set(x + 1, y + 6, z, "polished_andesite"); B.set(x, y + 7, z, "polished_diorite");
  B.fill(x + 1, y + 7, z, x + 1, y + 9, z, "iron_bars"); B.set(x - 1, y + 5, z, "polished_andesite");
}
/* 風車 */
function windmill(B, x, y, z, pal, face = "s") {
  B.fill(x - 3, y, z - 3, x + 3, y + 10, z + 3, pal.base, "hollow"); B.fill(x - 2, y, z - 2, x + 2, y, z + 2, "air"); B.fill(x - 2, y + 11, z - 2, x + 2, y + 12, z + 2, pal.wall, "hollow");
  roof(B, x - 2, z - 2, x + 2, z + 2, y + 13, pal, pal.roof2); B.fill(x, y, z + 3, x, y + 2, z + 3, "air");
  const sz = z - 4; B.set(x, y + 11, sz, pal.beam);
  for (let k = 1; k <= 7; k++) { B.set(x + k, y + 11, sz, "oak_fence"); B.set(x - k, y + 11, sz, "oak_fence"); B.set(x, y + 11 + k, sz, "oak_fence"); B.set(x, y + 11 - k, sz, "oak_fence");
    if (k > 1) { B.set(x + k, y + 12, sz, "white_wool"); B.set(x - k, y + 10, sz, "white_wool"); B.set(x - 1, y + 11 + k, sz, "white_wool"); B.set(x + 1, y + 11 - k, sz, "white_wool"); } }
  for (let k = 3; k <= 10; k += 3) for (const [a, b] of [[x - 3, z], [x + 3, z]]) B.set(a, y + k, b, pal.glass);
}
/* 丸い 塔（円すいの 屋根）*/
function roundTower(B, x, y, z, r, h, pal, mat) {   /* 八角形の 塔（fill 2つで 丸く 見せる）*/
  const m = mat || pal.cw, c = Math.max(1, Math.round(r * 0.42));
  B.fill(x - r + c, y, z - r, x + r - c, y + h, z + r, m); B.fill(x - r, y, z - r + c, x + r, y + h, z + r - c, m);
  if (r > 2) { B.fill(x - r + c + 1, y + 1, z - r + 1, x + r - c - 1, y + h - 1, z + r - 1, "air"); B.fill(x - r + 1, y + 1, z - r + c + 1, x + r - 1, y + h - 1, z + r - c - 1, "air"); }
  B.fill(x - r + c, y + h + 1, z - r, x + r - c, y + h + 1, z + r, m); B.fill(x - r, y + h + 1, z - r + c, x + r, y + h + 1, z + r - c, m);
  for (let k = 0; k <= r + 1; k++) { const rr = r + 1 - k, cc = Math.max(0, Math.round(rr * 0.42)), yy = y + h + 2 + Math.floor(k * 1.6);
    B.fill(x - rr + cc, yy, z - rr, x + rr - cc, yy, z + rr, pal.roof); if (rr > 0) B.fill(x - rr, yy, z - rr + cc, x + rr, yy, z + rr - cc, pal.roof);
    if (k % 2 === 1 && yy + 1 < y + h + 2 + Math.floor((k + 1) * 1.6)) { B.fill(x - rr + cc, yy + 1, z - rr, x + rr - cc, yy + 1, z + rr, pal.roof); if (rr > 0) B.fill(x - rr, yy + 1, z - rr + cc, x + rr, yy + 1, z + rr - cc, pal.roof); } }
  B.fill(x - r, y + h - 4, z, x + r, y + h - 3, z, pal.glass); B.fill(x, y + h - 4, z - r, x, y + h - 3, z + r, pal.glass);
  if (r > 2) { B.fill(x - r + 1, y + h - 4, z, x + r - 1, y + h - 3, z, "air"); B.fill(x, y + h - 4, z - r + 1, x, y + h - 3, z + r - 1, "air"); }
  B.set(x, y + h + 3 + Math.floor((r + 1) * 1.6), z, pal.banner);
}
/* 大聖堂（尖塔・ばら窓）*/
function cathedral(B, x, y, z, pal) {
  const w = 13, d = 19, x1 = x - 6, x2 = x + 6, z1 = z - 9, z2 = z + 9;   /* 第108版: 少し 短く（ほかの 建物と 重なって いた）*/
  B.fill(x1 - 1, y - 1, z1 - 1, x2 + 1, y - 1, z2 + 1, pal.stone);
  B.fill(x1, y, z1, x2, y + 11, z2, pal.wall, "hollow"); B.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, "air"); B.fill(x1 + 1, y - 1, z1 + 1, x2 - 1, y - 1, z2 - 1, pal.plaza);
  for (let b = z1; b <= z2; b += 4) { B.fill(x1 - 1, y, b, x1 - 1, y + 9, b, pal.stone); B.fill(x2 + 1, y, b, x2 + 1, y + 9, b, pal.stone); B.fill(x1, y + 3, b + 2, x1, y + 8, b + 2, "stained_glass" === "x" ? "glass" : B.pick(["blue_stained_glass", "red_stained_glass", "yellow_stained_glass", "purple_stained_glass"])); B.fill(x2, y + 3, b + 2, x2, y + 8, b + 2, B.pick(["blue_stained_glass", "red_stained_glass", "yellow_stained_glass", "purple_stained_glass"])); }
  roof(B, x1, z1, x2, z2, y + 12, pal, pal.roof2);
  /* 正面の 塔と ばら窓 */
  B.fill(x - 3, y, z2 - 2, x + 3, y + 22, z2 + 2, pal.stone, "hollow"); B.fill(x - 2, y, z2 - 1, x + 2, y, z2 + 1, "air");
  for (let k = 0; k < 6; k++) B.fill(x - 3 + Math.floor(k / 2), y + 23 + k * 2, z2 - 2 + Math.floor(k / 2), x + 3 - Math.floor(k / 2), y + 24 + k * 2, z2 + 2 - Math.floor(k / 2), pal.roof2);
  B.fill(x, y + 35, z2, x, y + 37, z2, pal.trim); B.set(x, y + 38, z2, "lightning_rod");
  B.fill(x - 2, y + 13, z2 + 2, x + 2, y + 17, z2 + 2, "white_stained_glass"); B.fill(x - 1, y + 14, z2 + 2, x + 1, y + 16, z2 + 2, "light_blue_stained_glass"); B.set(x, y + 15, z2 + 2, "yellow_stained_glass");
  B.fill(x - 1, y, z2 - 2, x + 1, y + 4, z2 + 2, "air");   /* 第108版: 塔から 聖堂の 中へ 通れる（前は 壁で ふさがって いた）*/
  B.chk.push({ name: "大聖堂", pos: { x: x + 0.5, y, z: z + 0.5 } });
  B.set(x, y + 20, z2, "bell");
  /* 中: 長いす と 祭壇 */
  for (let b = z1 + 4; b <= z2 - 5; b += 2) { B.fill(x1 + 2, y, b, x - 2, y, b, 'dark_oak_stairs ["weirdo_direction"=2]'); B.fill(x + 2, y, b, x2 - 2, y, b, 'dark_oak_stairs ["weirdo_direction"=2]'); }
  B.fill(x - 2, y, z1 + 1, x + 2, y, z1 + 2, pal.trim); B.set(x, y + 1, z1 + 1, "candle"); B.fill(x - 3, y + 6, z, x + 3, y + 6, z, "air"); B.set(x, y + 9, z, "sea_lantern"); B.set(x, y + 9, z1 + 5, "sea_lantern"); B.set(x, y + 9, z2 - 5, "sea_lantern");
  return { door: [x, z2 + 3] };
}
/* 城（天守・4つの 塔・城壁・中庭・玉座の 間）*/
function palace(B, x, y, z, pal) {
  const R = 14;
  B.fill(x - R, y - 1, z - R, x + R, y - 1, z + R, pal.plaza);
  B.fill(x - R, y, z - R, x + R, y + 7, z + R, pal.cw, "hollow"); B.fill(x - R + 1, y, z - R + 1, x + R - 1, y + 7, z + R - 1, "air");
  B.fill(x - R + 1, y - 1, z - R + 1, x + R - 1, y - 1, z + R - 1, pal.plaza);
  for (let k = -R; k <= R; k += 2) { B.set(x + k, y + 8, z - R, pal.cw); B.set(x + k, y + 8, z + R, pal.cw); B.set(x - R, y + 8, z + k, pal.cw); B.set(x + R, y + 8, z + k, pal.cw); }
  for (const [a, b] of [[-R, -R], [R, -R], [-R, R], [R, R]]) roundTower(B, x + a, y, z + b, 4, 14, pal);
  /* 天守（奥）*/
  const kz1 = z - R + 2, kz2 = z - 2;
  B.fill(x - 10, y, kz1, x + 10, y + 16, kz2, pal.stone, "hollow"); B.fill(x - 9, y, kz1 + 1, x + 9, y, kz2 - 1, "air");
  for (let a = x - 10; a <= x + 10; a += 4) B.fill(a, y + 3, kz2, a, y + 12, kz2, pal.glass);
  B.fill(x - 2, y, kz2, x + 2, y + 6, kz2, "air"); B.fill(x - 3, y + 7, kz2 + 1, x + 3, y + 7, kz2 + 1, pal.trim);
  roof(B, x - 10, kz1, x + 10, kz2, y + 17, pal);
  roundTower(B, x, y + 16, z - 9, 4, 12, pal, pal.stone);
  for (const a of [x - 10, x + 10]) roundTower(B, a, y + 10, kz1 + 1, 3, 10, pal, pal.stone);
  /* 玉座の 間 */
  B.fill(x - 1, y - 1, kz1 + 2, x + 1, y - 1, kz2, "red_carpet" === "x" ? "x" : "red_wool"); B.fill(x - 1, y, kz1 + 2, x + 1, y, kz2 - 1, "red_carpet");
  B.fill(x - 1, y, kz1 + 1, x + 1, y + 1, kz1 + 1, "gold_block"); B.set(x, y + 2, kz1 + 1, "gold_block");
  for (const a of [x - 6, x + 6]) for (let b = kz1 + 3; b < kz2; b += 3) { B.fill(a, y, b, a, y + 14, b, pal.trim); B.set(a, y + 5, b + 1, "lantern"); }
  B.set(x, y + 14, z - 9, "sea_lantern");
  /* 門（南）・旗 */
  B.fill(x - 3, y, z + R, x + 3, y + 5, z + R, "air"); B.fill(x - 4, y, z + R + 1, x - 4, y + 9, z + R + 1, pal.trim); B.fill(x + 4, y, z + R + 1, x + 4, y + 9, z + R + 1, pal.trim); B.fill(x - 4, y + 9, z + R + 1, x + 4, y + 10, z + R + 1, pal.cw);
  B.fill(x - 3, y + 6, z + R, x + 3, y + 7, z + R, "iron_bars");
  for (const a of [x - 8, x + 8]) { B.fill(a, y + 2, z + R + 1, a, y + 7, z + R + 1, pal.banner); }
  /* 中庭の 花と 木 */
  for (const a of [x - 11, x + 11]) { bigTree(B, a, y, z + 8, pal, 1); B.fill(a - 2, y - 1, z + 4, a + 2, y - 1, z + 12, pal.ground); }
  return { throne: { x: x + 0.5, y, z: kz1 + 3.5 }, master: { x: x + 0.5, y, z: z + 6.5 }, gate: { x: x + 0.5, y, z: z + R + 2.5 } };
}
/* 城壁（八角形・歩廊・胸壁・角に 塔）*/
function cityWall(B, r, y, pal, gates, H) {   /* 四角い 城壁（角を 落とす）。高さは 一定・胸壁つき */
  const c = 10, top = y + 8;
  const edges = [[-r + c, -r, r - c, -r], [-r + c, r, r - c, r], [-r, -r + c, -r, r - c], [r, -r + c, r, r - c]];
  for (const [ax, az, bx, bz] of edges) { B.fill(ax - (ax === bx ? 1 : 0), y - 4, az - (az === bz ? 1 : 0), bx + (ax === bx ? 1 : 0), top, bz + (az === bz ? 1 : 0), pal.cw); B.fill(ax, top + 1, az, bx, top + 1, bz, pal.cw2); B.fill(ax - (ax === bx ? 1 : 0), top + 1, az - (az === bz ? 1 : 0), ax - (ax === bx ? 1 : 0), top + 1, az - (az === bz ? 1 : 0), pal.cw); }
  for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { for (let k = 0; k <= c; k++) { const x = sx * (r - c + k), z = sz * (r - k); B.fill(x - 1, y - 4, z - 1, x + 1, top, z + 1, pal.cw); } roundTower(B, sx * (r - c / 2), y - 4, sz * (r - c / 2), 4, 16, pal); }
  for (const [gx, gz] of gates) { const ax = Math.abs(gx) > Math.abs(gz);
    if (ax) { B.fill(gx - 1, y, gz - 3, gx + 1, y + 5, gz + 3, "air"); for (const s of [-5, 5]) roundTower(B, gx, y - 4, gz + s, 3, 16, pal, pal.stone); B.fill(gx - 1, y + 6, gz - 3, gx + 1, y + 6, gz + 3, "iron_bars"); }
    else { B.fill(gx - 3, y, gz - 1, gx + 3, y + 5, gz + 1, "air"); for (const s of [-5, 5]) roundTower(B, gx + s, y - 4, gz, 3, 16, pal, pal.stone); B.fill(gx - 3, y + 6, gz - 1, gx + 3, y + 6, gz + 1, "iron_bars"); } }
}
/* 道（幅 w。石の まだら）*/
function road(B, x1, z1, x2, z2, w, H, pal) {
  const n = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1)); for (let i = 0; i <= n; i++) { const x = Math.round(x1 + (x2 - x1) * i / n), z = Math.round(z1 + (z2 - z1) * i / n), h = H(x, z); if (h === null) continue;
    B.fill(x - w, h - 1, z - w, x + w, h - 1, z + w, (i % 5 === 0) ? pal.path2 : pal.path); }
}

/* ======================= 都（城下町）======================= */
/* r=64 の 台地。北が 高い 丘（城）、南に 城下町。外は 崖と 森と 堀 */
export function capitalPlan(i, style, seed) {
  const pal = palOf(style), B = new Blue(seed || 1000 + i), R = 72, WALL = 50, s = (seed || i) * 31 + 7;
  const sea = !!pal.sea;
  const GZ = sea ? 4 : 26, GY = sea ? 5 : 0;   /* 第108版: 東西の 門の 位置と 高さ（海の 都は 南が 海なので 中段の 高さで 入る）*/
  /* 高さ: 城の 丘 +12（北）・中段 +5（広場）・下段 0（南）。外は 崖で -6 まで 下がり、まわりは 森の 丘 */
  const sq = (x, z) => Math.max(Math.abs(x), Math.abs(z), Math.abs(x) + Math.abs(z) - (WALL - 10));   /* 城壁と 同じ 形の きょり */
  const H0 = (x, z) => {
    const d = Math.hypot(x, z), q = sq(x, z), n = noise(x + 500, z + 500, s, 14);
    if (d > R) return null;
    if (q > WALL + 9) { const t = Math.min(1, (q - WALL - 9) / 8); if (sea && z > 10) return -4;   /* 外: 湖を かこむ 森の 丘（第108版: 北の 崖を 低く）*/
      if (Math.abs(x) <= 4 && z > 0) return 0; if (Math.abs(z - GZ) <= 4 && Math.abs(x) > WALL) return GY;   /* 第108版: 門の 前は 橋と 同じ 高さ（飛び降りずに 入れる。外へは なだらかに）*/
      const north = z < -6 ? Math.min(1, (-6 - z) / 26) : 0; return 2 * Math.round((-1 + t * (3 + north * 8) + n * 3 - (d > R - 4 ? (d - R + 4) * 1.5 : 0)) / 2); }
    if (q > WALL + 1) return sea && z > 10 ? -4 : -4;   /* 湖（あとで 水）*/
    if (z < -19) return 12;   /* 城の 丘 */
    if (z < -12) return 5 + (-12 - z);   /* 坂（階段）第108版: 1マスずつ（前は 2マスの 段が あって 登れなかった）*/
    if (z < 14) return 5;   /* 中段（広場）*/
    if (z < 19) return 5 - (z - 13);   /* 第108版: 1マスずつ */
    return 0;   /* 下段 */
  };
  const H = (x, z) => blendOut(H0(x, z), x, z, WALL + 12, R);
  terrain(B, R, H, pal, -18);
  /* 堀（城壁の 外）*/
  { const lake = (x, z) => { const q = sq(x, z); return q > WALL + 1.5 && q <= WALL + 9 && Math.hypot(x, z) <= R; }; rowFill(B, R, lake, -8, -6, pal.cliff[1] === "tuff" ? "gravel" : "sand"); rowFill(B, R, lake, -5, -4, pal.water === "lava" ? "lava" : "water"); }   /* 都を かこむ 湖 */
  /* 海の 都: 南は 港（海）*/
  if (sea) { const sw = (x, z) => z >= 26 && sq(x, z) > WALL + 1 && Math.hypot(x, z) <= R; rowFill(B, R, sw, -9, -4, "water"); rowFill(B, R, sw, -3, 6, "air"); } if (sea) beachSand(B, R, (x, z) => z >= 19 && z <= 25 && sq(x, z) > WALL + 2 && Math.abs(x) > 4 && Math.hypot(x, z) <= R - 4, H);
  /* 城（北の 丘）*/
  const pc = palace(B, 0, 12, -33, pal);
  /* 丘の 上の 貴族の 館と 庭園（城の 左右）*/
  for (const sx of [-1, 1]) { const x = sx * 31; house(B, x, 12, -34, 13, 11, 3, sx < 0 ? "e" : "w", pal, "books", { nochim: false });
    B.fill(x - 6, 11, -24, x + 6, 11, -20, pal.path); for (let k = -6; k <= 6; k += 3) { B.fill(x + k, 12, -27, x + k, 12, -27, "azalea_leaves"); B.set(x + k, 12, -22, B.pick(pal.flower.filter((f) => !/cactus|amethyst/.test(f))) || "poppy"); }
    bigTree(B, x + sx * 8, 12, -24, pal, 1); B.fill(x - 1, 11, -45, x + 1, 11, -45, pal.stone); }
  /* 大階段（坂）と 噴水の 広場 */
  for (let z = -19; z <= -12; z++) { const h = H(0, z); B.fill(-4, h - 1, z, 4, h - 1, z, pal.stone); for (const a of [-5, 5]) { B.fill(a, h - 1, z, a, h, z, pal.trim); } }
  for (let z = -12; z <= -11; z++) B.fill(-4, 4, z, 4, 4, z, pal.stone);
  B.fill(-14, 4, -10, 14, 4, 12, pal.plaza); for (let a = -14; a <= 14; a += 4) for (let b = -10; b <= 12; b += 4) B.set(a, 4, b, pal.path2);
  fountain(B, 0, 5, 1, pal); statue(B, 0, 5, -8, pal);
  for (const [a, b] of [[-13, -9], [13, -9], [-13, 11], [13, 11], [-7, 11], [7, 11]]) lampPost(B, a, 5, b, pal);
  for (const [a, b, ax] of [[-10, 5, 0], [10, 5, 0], [-4, 10, 1], [2, 10, 1]]) bench(B, a, 5, b, ax);
  /* 坂の 下: 中段 → 下段 の 階段 */
  for (let z = 14; z <= 18; z++) { const h = H(0, z); B.fill(-3, h - 1, z, 3, h - 1, z, pal.stone); }
  /* 大通り（南の 門 → 広場）*/
  road(B, 0, 18, 0, WALL + 2, 2, H, pal); road(B, -WALL + 2, 26, WALL - 2, 26, 1, H, pal); road(B, -WALL + 4, 40, WALL - 4, 40, 1, H, pal);
  road(B, -20, 4, -WALL + 2, 4, 1, H, pal); road(B, 20, 4, WALL - 2, 4, 1, H, pal);
  /* 中段の 名所: 冒険者協会（西）・酒場（東）・レストラン（東の 南）・大聖堂（西の 北）*/
  const N = (job, pos, name, kind) => B.npc.push({ job, pos, name, kind });
  const RC = [[-WALL, 24, WALL, 28], [-WALL, 38, WALL, 42], [-3, 14, 3, WALL], [-15, -11, 15, 13], [-WALL, -WALL, WALL, -19]];   /* 第108版: 道・広場・城の 丘（家を 置かない 所）*/
  const hitC = (a) => RC.some((q) => a[0] - 1 <= q[2] && a[2] + 1 >= q[0] && a[1] - 1 <= q[3] && a[3] + 1 >= q[1]);
  const g1 = house(B, -24, 5, 4, 15, 11, 3, "e", { ...pal, roof: pal.roof2 }, "books", { sign: pal.banner, nochim: true }); N(22, { x: g1.inside[0] + 0.5, y: 5, z: g1.inside[1] + 0.5 }, "§e冒険者協会の 受付", "guild"); RC.push([g1.x1 - 1, g1.z1 - 1, g1.x2 + 1, g1.z2 + 1]);
  for (const b of [0, 8]) B.fill(-17, 5, b - 3, -17, 10, b - 3, pal.banner);
  const tv = house(B, 24, 5, -4, 13, 11, 2, "w", pal, "tavern", { sign: "orange_wool" }); N(20, { x: tv.inside[0] + 0.5, y: 5, z: tv.inside[1] + 0.5 }, "§e酒場の マスター", "tavern"); RC.push([tv.x1 - 2, tv.z1 - 1, tv.x2 + 1, tv.z2 + 1]);
  B.fill(17, 5, -8, 17, 5, -6, "oak_fence"); B.fill(17, 5, -2, 17, 5, -2, "oak_fence");   /* 第108版: 酒場の 入口を ふさいで いた */ B.fill(16, 5, -8, 16, 5, -8, "barrel"); B.set(16, 5, -1, "barrel");
  const rs = house(B, 24, 5, 10, 11, 9, 2, "w", { ...pal, roof: pal.roof2 }, "kitchen", { sign: "lime_wool" }); N(21, { x: rs.inside[0] + 0.5, y: 5, z: rs.inside[1] + 0.5 }, "§eレストランの 料理人", "food"); RC.push([rs.x1 - 2, rs.z1 - 1, rs.x2 + 1, rs.z2 + 1]);
  for (const [a, b] of [[15, 7], [15, 13]]) { B.set(a, 5, b, "oak_fence"); B.set(a, 6, b, "white_carpet"); B.set(a - 1, 5, b, 'oak_stairs ["weirdo_direction"=0]'); B.set(a + 0, 8, b, "red_wool"); B.fill(a, 6, b, a, 7, b, "oak_fence"); }
  cathedral(B, -38, 5, -4, pal); RC.push([-47, -14, -31, 10]);   /* 第108版: 冒険者協会と 重なって 入れなかった */
  /* 下段: 店・家・屋台・風車 */
  const shops = [[0, "武器屋", -9, 30, "e"], [1, "防具屋", 9, 30, "w"], [3, "道具屋", -9, 46, "e"], [4, "タマゴ屋", 9, 46, "w"], [2, "宿屋", -24, 33, "e"], [11, "モンスター屋", 24, 33, "w"], [6, "預かり屋", -24, 47, "e"], [12, "図書館", 24, 47, "w"], [14, "釣り屋", -38, 33, "e"], [5, "闘技場", 38, 33, "w"]];   /* 第108版: 下段へ（大聖堂と 重なって いた）*/
  for (const [job, nm, x, z, f] of shops) { const h = H(x, z); const w = job === 2 ? 11 : 9; const r = house(B, x, h, z, w, 9, job === 2 ? 3 : 2, f, pal, job <= 1 ? "forge" : job === 12 ? "books" : "shop", { sign: B.pick(["red_wool", "yellow_wool", "blue_wool", "lime_wool", "orange_wool"]) }); N(job, { x: r.inside[0] + 0.5, y: h, z: r.inside[1] + 0.5 }, `§e${nm}`); RC.push([r.x1, r.z1, r.x2, r.z2]); }
  const used = shops.map(([, , x, z]) => [x, z]);
  for (let z = 22; z <= WALL - 7; z += 10) for (let x = -WALL + 8; x <= WALL - 8; x += 10) { if (Math.abs(x) < 15 || Math.abs(z - 26) < 3 || Math.abs(z - 40) < 3 || used.some(([a, b]) => Math.abs(a - x) < 9 && Math.abs(b - z) < 9) || sq(x, z) > WALL - 7 || B.r() < 0.15) continue; const h = H(x, z); if (h !== 0) continue; const xx = x + B.ri(-1, 1), ww = B.pick([7, 7, 9]), dd = B.pick([7, 9]), rc = [xx - Math.floor(ww / 2), z - Math.floor(dd / 2), xx - Math.floor(ww / 2) + ww - 1, z - Math.floor(dd / 2) + dd - 1]; if (hitC(rc)) continue; RC.push(rc); house(B, xx, h, z, ww, dd, B.pick([1, 2, 2, 3]), B.pick(z < 33 ? ["n", "s"] : ["s", "n"]), pal, "home"); }
  for (let k = 0; k < 6; k++) { const x = B.pick([-40, -36, -30, 30, 36, 40]) + B.ri(-2, 2), z = B.pick([-6, 2, 8]) + B.ri(-2, 2); const h = H(x, z); if (h === null || Math.hypot(x, z) > WALL - 8 || Math.abs(x) < 16) continue; const ww = B.pick([7, 9]), dd = B.pick([7, 9]), rc = [x - Math.floor(ww / 2), z - Math.floor(dd / 2), x - Math.floor(ww / 2) + ww - 1, z - Math.floor(dd / 2) + dd - 1]; if (hitC(rc)) continue; RC.push(rc); house(B, x, h, z, ww, dd, B.pick([1, 2, 2, 3]), x < 0 ? "e" : "w", pal, "home"); }
  for (const [x, z, c] of [[-4, 36, "red_wool"], [4, 36, "yellow_wool"], [-4, 52, "blue_wool"], [4, 52, "lime_wool"]]) stall(B, x, H(x, z), z, c, pal);   /* 第108版: 東西の 門の 道を ふさがない */
  if (!sea) { if (!hitC([-46, 26, -38, 34])) windmill(B, -42, H(-42, 30), 30, pal); if (!hitC([40, -14, 48, -6])) windmill(B, 44, H(44, -10), -10, pal); }
  for (const [x, z] of [[-6, 22], [6, 22], [-6, 58], [6, 58], [-20, 26], [20, 26], [-20, 40], [20, 40]]) { const h = H(x, z); if (h !== null) lampPost(B, x, h, z, pal); }
  /* 城壁と 門 */
  const gates = [[0, WALL], [-WALL, GZ], [WALL, GZ]];   /* 第108版: 東西の 門は 下段（高さ 0）の 大通りへ（前は 高さ 5 の 崖に ぶつかって いた）*/
  cityWall(B, WALL, 0, pal, sea ? gates.slice(0, 1) : gates, H);
  if (sea) for (const gx of [-WALL, WALL]) { B.fill(gx - 1, GY, GZ - 3, gx + 1, GY + 4, GZ + 3, "air"); B.fill(gx - 1, GY - 1, GZ - 2, gx + 1, GY - 1, GZ + 2, pal.path); }
  /* 湖を こえる 橋（3つの 門から）*/
  const bridge = (ax, az, bx, bz, alongZ, by = 0) => { const fence = pal.lamp === "shroomlight" ? "nether_brick_fence" : "dark_oak_fence";
    if (alongZ) { B.fill(ax - 2, -1, az, ax + 2, -1, bz, pal.floor); B.fill(ax - 3, 0, az, ax - 3, 0, bz, fence); B.fill(ax + 3, 0, az, ax + 3, 0, bz, fence); for (let k = az; k <= bz; k += 5) { B.fill(ax - 2, -8, k, ax - 2, -4, k, pal.stone); B.fill(ax + 2, -8, k, ax + 2, -4, k, pal.stone); B.set(ax - 3, -1, k, pal.lamp === "lantern" ? "lantern" : pal.lamp); B.set(ax + 3, -1, k, pal.lamp === "lantern" ? "lantern" : pal.lamp); } }
    else { B.fill(ax, by - 1, az - 2, bx, by - 1, az + 2, pal.floor); B.fill(ax, by, az - 3, bx, by, az - 3, fence); B.fill(ax, by, az + 3, bx, by, az + 3, fence); for (let k = Math.min(ax, bx); k <= Math.max(ax, bx); k += 5) { B.fill(k, -8, az - 2, k, by - 4, az - 2, pal.stone); B.fill(k, -8, az + 2, k, by - 4, az + 2, pal.stone); B.set(k, by - 1, az - 3, pal.lamp === "lantern" ? "lantern" : pal.lamp); B.set(k, by - 1, az + 3, pal.lamp === "lantern" ? "lantern" : pal.lamp); } } };
  if (!sea) bridge(0, WALL + 1, 0, WALL + 12, true);   /* 第108版: 南の 橋が 向きの まちがいで できて いなかった */
  bridge(-WALL - 1, GZ, -WALL - 12, GZ, false, GY); bridge(WALL + 1, GZ, WALL + 12, GZ, false, GY);
  for (const [x1, z1, x2, z2] of [[-2, WALL - 3, 2, WALL + 1], ...(sea ? [] : [[-WALL - 1, GZ - 2, -WALL + 3, GZ + 2], [WALL - 3, GZ - 2, WALL + 1, GZ + 2]])]) B.fill(x1, -1, z1, x2, -1, z2, pal.path);   /* 門の 中の 坂 */
  for (const [x1, z1, x2, z2] of [[-2, WALL - 1, 2, WALL], ...(sea ? [] : [[-WALL, GZ - 2, -WALL + 1, GZ + 2], [WALL - 1, GZ - 2, WALL, GZ + 2]])]) { B.fill(x1, -1, z1, x2, -1, z2, pal.path); B.fill(x1, 0, z1, x2, 3, z2, "air"); }   /* 第108版: 門の 床も 0 の 高さ */
  /* 北の 崖から 湖へ 流れる 滝 */
  if (!sea) for (const x of [-14, 15]) { const z = -(WALL + 10), h = H(x, z - 2) ?? 8; B.fill(x, -4, z, x + 1, h, z - 1, "air"); B.fill(x, h - 1, z - 2, x + 1, h - 1, z - 2, pal.water === "lava" ? "lava" : "water"); }
  /* 港（海の 都）*/
  if (sea) harbor(B, 0, WALL + 4, pal);
  /* まわりの 森・岩・草花 */
  for (let n = 0; n < 120; n++) { const a = B.r() * Math.PI * 2, d = WALL + 7 + B.r() * (R - WALL - 9), x = Math.round(Math.cos(a) * d), z = Math.round(Math.sin(a) * d), h = H(x, z); if (h === null || (sea && z > 20)) continue;
    if (Math.abs(x) < 6 && z > WALL) continue; if (Math.abs(z - GZ) < 5 && Math.abs(x) > WALL) continue;
    if (B.r() < 0.72) bigTree(B, x, h, z, pal, B.r() < 0.4 ? 1 : 0); else if (B.r() < 0.6) rock(B, x, h, z, pal); else flowerAt(B, x, h, z, pal); }
  for (let n = 0; n < 50; n++) { const x = B.ri(-WALL + 6, WALL - 6), z = B.ri(-10, WALL - 6), h = H(x, z); if (h === null || Math.abs(x) < 5 || (h === 5 && Math.abs(x) < 15 && z < 13)) continue; flowerAt(B, x, h, z, pal); }
  for (const [x, z] of [[-34, -20], [34, -20], [-44, 22], [46, 22], [-30, 52], [30, 52]]) { const h = H(x, z); if (h !== null) bigTree(B, x, h, z, pal, 1); }
  /* 歩く 人の 道（広場・大通り・門の 前）*/
  B.walk = [[[0, 5, 8], [-10, 5, 8], [-10, 5, -6], [10, 5, -6], [10, 5, 8]], [[0, 0, 24], [0, 0, 50], [-12, 0, 40], [12, 0, 40], [0, 0, 24]], [[-20, 0, 26], [20, 0, 26], [20, 0, 40], [-20, 0, 40]], [[-3, 5, 12], [-3, 2, 16], [-3, 0, 22], [3, 0, 22], [3, 2, 16], [3, 5, 12]]];
  B.mark = { throne: pc.throne, master: pc.master, gate: { x: 0.5, y: 0, z: WALL + 6.5 }, r: R, y12: 12 };
  return B;
}
/* 港: 桟橋・停泊する 船・灯台・魚市場 */
function harbor(B, x, z, pal) {
  for (let k = -24; k <= 24; k += 12) { B.fill(x + k - 1, -4, z, x + k + 1, -4, z + 16, pal.floor); for (let b = z; b <= z + 16; b += 4) { B.fill(x + k - 1, -9, b, x + k - 1, -4, b, pal.beam); B.fill(x + k + 1, -9, b, x + k + 1, -4, b, pal.beam); } B.set(x + k, -3, z + 16, pal.lamp); }
  ship(B, x - 18, -4, z + 10, pal); ship(B, x + 18, -4, z + 12, pal);
  roundTower(B, x + 34, -6, z + 6, 3, 16, { ...pal, roof: "red_terracotta" }, "white_concrete"); B.set(x + 34, 12, z + 6, "sea_lantern");
  for (const [a, c] of [[-8, "blue_wool"], [8, "white_wool"]]) stall(B, x + a, -3, z + 1, c, pal);
}
function ship(B, x, y, z, pal) {
  for (let k = -5; k <= 5; k++) { const w = Math.max(1, 3 - Math.floor(Math.abs(k) / 2)); B.fill(x - w, y - 1, z + k, x + w, y, z + k, "dark_oak_planks"); B.fill(x - w + 1, y, z + k, x + w - 1, y, z + k, "air"); B.fill(x - w + 1, y - 1, z + k, x + w - 1, y - 1, z + k, "spruce_planks"); }
  B.fill(x, y, z - 1, x, y + 9, z - 1, "spruce_log"); B.fill(x - 3, y + 4, z - 1, x + 3, y + 8, z - 1, "white_wool"); B.fill(x, y + 3, z + 3, x, y + 6, z + 3, "spruce_log"); B.fill(x - 2, y + 4, z + 3, x + 2, y + 6, z + 3, "white_wool"); B.set(x, y + 10, z - 1, pal.banner);
}

/* ======================= 町（R=46）======================= */
/* 種類: village（農村: 畑・風車）/ port（港町: 入り江と 桟橋）/ forest（森の 村: 大木）/ mine（石の 町: 崖の 段々）/ desert / snow / volcano / crystal / dark / sky */
export function townPlan(t, seed) {
  const style = t.style || "village", pal = palOf(style), B = new Blue(seed), R = 44, IN = 34, s = seed % 997;
  const sea = style === "port", hilly = ["castle", "volcano", "crystal", "dark", "snow", "sky"].includes(style);
  /* 高さ: 町の 中は 2段（東が +3 の 段）。まわりは 丘と 崖で 下がる */
  const H = (x, z) => blendOut(Ht(x, z), x, z, IN + 1, R);
  const Ht = (x, z) => { const d = Math.hypot(x, z), n = noise(x + 300, z + 300, s, 8) * 3;
    if (d > R) return null;
    if (sea && z > 14 && d > 10) return d > IN ? -4 : -1;
    const inn = hilly ? Math.max(0, Math.min(4, x - 5)) : 0;   /* 第108版: 東の 段は 1マスずつ 上がる（前は 2マス 段差が あった）*/
    if (d > IN) { const t2 = (d - IN) / (R - IN), k = Math.min(1, (d - IN) / 7); return Math.round(inn * (1 - k) + (-1 + (hilly ? 4 - t2 * 8 : 1 - t2 * 4) + n * 1.4) * k); }   /* 町の ふちで 急に 3〜5マス 上がる 崖を なくした */
    return inn; };
  terrain(B, R, H, pal, -14);
  if (sea) { const sw = (x, z) => z >= 14 && Math.hypot(x, z) > 12 && Math.hypot(x, z) <= R && (Math.hypot(x, z) > IN || z > 22); rowFill(B, R, sw, -9, -3, "water"); rowFill(B, R, sw, -2, 6, "air"); } if (sea) beachSand(B, R, (x, z) => z >= 12 && z <= 22 && Math.abs(x) > 3 && Math.hypot(x, z) > 11 && Math.hypot(x, z) <= IN, H);
  /* 広場と 十字の 道 */
  B.fill(-9, -1, -9, 9, -1, 9, pal.plaza); for (let a = -8; a <= 8; a += 4) for (let b = -8; b <= 8; b += 4) B.set(a, -1, b, pal.path2);
  road(B, 0, -IN, 0, IN, 1, H, pal); road(B, -IN, 0, IN, 0, 1, H, pal);
  if (hilly) for (let z = -2; z <= 2; z++) for (let x = 5; x <= 8; x++) B.fill(x, H(x, z) - 1, z, x, H(x, z) - 1, z, pal.stone);
  fountain(B, 0, 0, 0, pal);
  for (const [a, b] of [[-8, -8], [8, -8], [-8, 8], [8, 8]]) lampPost(B, a, H(a, b), b, pal);
  const N = (job, pos, name, kind) => B.npc.push({ job, pos, name, kind });
  const RECT = [];
  const shops = [[0, "武器屋", 14, -13, "w"], [1, "防具屋", 27, -13, "w"], [3, "道具屋", -14, -13, "e"], [4, "タマゴ屋", -27, -13, "e"], [2, "宿屋", 14, 14, "n"], [5, "闘技場", 27, 14, "n"], [6, "預かり屋", -14, 14, "n"], [7, "案内人", -27, 14, "n"], [11, "モンスター屋", -13, -26, "s"], [12, "図書館", 13, -26, "s"], [20, "酒場の マスター", 0, -28, "s"]];
  for (const [job, nm, x, z, f] of shops) { if (sea && z > 10) continue; const h = H(x, z); const tavern = job === 20; const r = house(B, x, h, z, tavern ? 15 : 11, tavern ? 11 : 11, tavern || job === 2 ? 2 : B.pick([1, 2]), f, pal, tavern ? "tavern" : job <= 1 ? "forge" : job === 12 ? "books" : "shop", { sign: B.pick(["red_wool", "yellow_wool", "blue_wool", "lime_wool", "orange_wool"]) });
    N(job, { x: r.inside[0] + 0.5, y: h, z: r.inside[1] + 0.5 }, `§e${nm}`, tavern ? "tavern" : null); RECT.push([r.x1, r.z1, r.x2, r.z2]); }
  if (sea) { const ri = house(B, 15, 0, -2, 9, 7, 2, "w", pal, "home"); RECT.push([ri.x1, ri.z1, ri.x2, ri.z2]); N(2, { x: ri.inside[0] + 0.5, y: 0, z: ri.inside[1] + 0.5 }, "§e宿屋"); }
  /* 民家（重ならない ように）。物知り・釣り屋は 民家の 中に 住む（第106版: 外の 広場に 立って いた） */
  const homes = [], hit = (a, b) => RECT.some((q) => a[0] - 2 <= q[2] && a[2] + 2 >= q[0] && a[1] - 2 <= q[3] && a[3] + 2 >= q[1]);
  for (let k = 0; k < 24 && homes.length < 7; k++) { const x = B.pick([-34, -30, 30, 34, -22, 22]) + B.ri(-1, 1), z = B.pick([-34, -24, 24, 34, -2, 4]) + B.ri(-1, 1); if (sea && z > 10) continue; const h = H(x, z); if (h === null || Math.hypot(x, z) > IN - 4) continue;
    if (hit([x - 5, z - 5, x + 5, z + 5])) continue;
    const r = house(B, x, h, z, 9, 9, B.pick([1, 1, 2]), x < 0 ? "e" : "w", pal, "home"); RECT.push([r.x1, r.z1, r.x2, r.z2]); homes.push([r, h]); }
  for (const [job, nm, k, fx, fz] of [[13, "物知り", 0, 5.5, -6.5], [14, "釣り屋", 1, sea ? 0.5 : -5.5, sea ? 20.5 : 6.5]]) {
    const hm = homes[k]; if (hm) N(job, { x: hm[0].inside[0] + 0.5, y: hm[1], z: hm[0].inside[1] + 0.5 }, `§e${nm}`); else { stall(B, Math.floor(fx), sea && job === 14 ? -1 : 0, Math.floor(fz) - 1, "light_blue_wool", pal); N(job, { x: fx, y: sea && job === 14 ? -1 : 0, z: fz }, `§e${nm}`); } }
  /* 名物 */
  if (sea) { harbor(B, 0, 18, pal); }
  else if (style === "village" || style === "farm" || style === "garden") { windmill(B, -32, H(-32, 30), 30, pal); for (let k = 0; k < 3; k++) { const z0 = 20 + k * 4; B.fill(14, -1, z0, 30, -1, z0 + 2, "farmland"); B.fill(14, 0, z0, 30, 0, z0 + 2, B.pick(["wheat", "carrots", "potatoes"])); B.fill(14, -1, z0 + 3, 30, -1, z0 + 3, "water"); } }
  else if (style === "forest") { for (const [x, z] of [[24, 24], [-24, 26], [30, -2]]) { bigTree(B, x, H(x, z), z, pal, 0); bigTree(B, x + 3, H(x, z), z + 3, pal, 1); } }
  else if (style === "desert") { B.fill(18, -2, 18, 30, -1, 30, "water"); B.fill(17, -1, 17, 31, -1, 31, pal.stone, "outline"); for (const [x, z] of [[17, 17], [31, 31], [17, 31]]) bigTree(B, x, 0, z, pal); }
  else roundTower(B, 26, H(26, 26), 26, 4, 16, pal, pal.stone);
  for (const [x, z, c] of [[-5, 15, "red_wool"], [5, 15, "yellow_wool"], [-15, 5, "blue_wool"]]) if (!(sea && z > 10)) stall(B, x, H(x, z), z, c, pal);
  /* 低い 外壁と 4つの 門・まわりの 森 */
  for (let a = 0; a < 360; a += 2) { const r = IN + 1, x = Math.round(Math.cos(a * Math.PI / 180) * r), z = Math.round(Math.sin(a * Math.PI / 180) * r); if (Math.abs(x) < 3 || Math.abs(z) < 3 || (sea && z > 12)) continue; const h = H(x, z); if (h === null) continue; B.fill(x, h, z, x, h + 1, z, pal.cw); if (a % 30 === 0) { B.fill(x, h, z, x, h + 3, z, pal.cw); B.set(x, h + 4, z, pal.lamp); } }
  for (let n = 0; n < 70; n++) { const a = B.r() * Math.PI * 2, d = IN + 3 + B.r() * (R - IN - 4), x = Math.round(Math.cos(a) * d), z = Math.round(Math.sin(a) * d), h = H(x, z); if (h === null || h < -2 || Math.abs(x) < 4 || Math.abs(z) < 4) continue; if (B.r() < 0.7) bigTree(B, x, h, z, pal, B.r() < 0.4 ? 1 : 0); else if (B.r() < 0.5) rock(B, x, h, z, pal); else flowerAt(B, x, h, z, pal); }
  for (let n = 0; n < 30; n++) { const x = B.ri(-IN + 4, IN - 4), z = B.ri(-IN + 4, IN - 4), h = H(x, z); if (h === null || Math.abs(x) < 3 || Math.abs(z) < 3 || Math.hypot(x, z) < 11 || (sea && z > 10)) continue; flowerAt(B, x, h, z, pal); }
  B.walk = [[[0, 0, 10], [10, 0, 10], [10, 0, -10], [-10, 0, -10], [-10, 0, 10]], [[0, 0, -12], [0, 0, -34], [0, 0, -12]], [[-12, 0, 0], [-34, 0, 0], [-12, 0, 0]], hilly ? [[12, 4, 0], [30, 4, 0], [12, 4, 0]] : [[12, 0, 0], [34, 0, 0], [12, 0, 0]]];
  B.mark = { r: R };
  return B;
}
