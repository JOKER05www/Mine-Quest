// 第106版: 城下町（都）と 町の 設計図。ブロックを 置く コマンドだけを 作る（置くのは structures.js の キュー）
// 座標は 中心（x,z）と 地面の 高さ（y=0）からの ずれ。高低差の ある 台地・崖・森の 上に 建てる
// 重く ならない ように: 地面は 行ごとに まとめた fill、建物は 箱の fill を 組み合わせる

/* ---------- 乱数と ノイズ（同じ 町は 毎回 同じ 形）---------- */
export function rng(seed) { let s = (seed >>> 0) || 1; return () => { s = (s + 0x6d2b79f5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const hash2 = (x, z, s) => { let h = (x * 374761393 + z * 668265263 + s * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
function noise(x, z, s, sc) { const fx = x / sc, fz = z / sc, x0 = Math.floor(fx), z0 = Math.floor(fz), tx = fx - x0, tz = fz - z0, sm = (t) => t * t * (3 - 2 * t);
  const a = hash2(x0, z0, s), b = hash2(x0 + 1, z0, s), c = hash2(x0, z0 + 1, s), d = hash2(x0 + 1, z0 + 1, s), u = sm(tx), v = sm(tz);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v; }

/* ---------- 地方ごとの 素材 ---------- */
export const PAL = {
  village: { wall: "white_terracotta", base: "stone_bricks", beam: "dark_oak_log", floor: "spruce_planks", roof: "red_nether_bricks", roof2: "brick_block", trim: "stripped_dark_oak_log", stone: "stone_bricks", stone2: "andesite", cw: "stone_bricks", cw2: "mossy_stone_bricks", path: "polished_andesite", path2: "stone_bricks", plaza: "smooth_stone", ground: "grass_block", leaf: "oak_leaves", log: "oak_log", leaf2: "birch_leaves", log2: "birch_log", lamp: "lantern", glass: "glass_pane", flower: ["poppy", "dandelion", "cornflower", "oxeye_daisy", "azure_bluet", "allium"], cliff: ["stone", "andesite", "stone", "cobblestone", "mossy_cobblestone"], banner: "red_wool", accent: "blue_wool", water: "water" },
  forest: { wall: "stripped_spruce_log", base: "mossy_cobblestone", beam: "spruce_log", floor: "spruce_planks", roof: "dark_oak_planks", roof2: "spruce_planks", trim: "stripped_spruce_log", stone: "mossy_stone_bricks", stone2: "cobblestone", cw: "mossy_stone_bricks", cw2: "mossy_cobblestone", path: "coarse_dirt", path2: "mossy_cobblestone", plaza: "mossy_stone_bricks", ground: "podzol", leaf: "spruce_leaves", log: "spruce_log", leaf2: "dark_oak_leaves", log2: "dark_oak_log", lamp: "lantern", glass: "glass_pane", flower: ["lily_of_the_valley", "fern", "azure_bluet"], cliff: ["stone", "mossy_cobblestone", "andesite", "tuff"], banner: "green_wool", accent: "brown_wool", water: "water" },
  castle: { wall: "smooth_stone", base: "cobblestone", beam: "dark_oak_log", floor: "dark_oak_planks", roof: "deepslate_tiles", roof2: "polished_deepslate", trim: "chiseled_stone_bricks", stone: "stone_bricks", stone2: "cracked_stone_bricks", cw: "stone_bricks", cw2: "cracked_stone_bricks", path: "stone_bricks", path2: "cobblestone", plaza: "polished_andesite", ground: "grass_block", leaf: "dark_oak_leaves", log: "dark_oak_log", leaf2: "oak_leaves", log2: "oak_log", lamp: "lantern", glass: "glass_pane", flower: ["poppy", "red_tulip", "allium"], cliff: ["stone", "andesite", "cobblestone", "gravel"], banner: "purple_wool", accent: "yellow_wool", water: "water" },
  volcano: { wall: "polished_blackstone_bricks", base: "blackstone", beam: "crimson_stem", floor: "crimson_planks", roof: "red_nether_bricks", roof2: "nether_bricks", trim: "gilded_blackstone", stone: "polished_blackstone_bricks", stone2: "blackstone", cw: "polished_blackstone_bricks", cw2: "cracked_polished_blackstone_bricks", path: "polished_blackstone", path2: "basalt", plaza: "polished_basalt", ground: "blackstone", leaf: "shroomlight", log: "crimson_stem", leaf2: "nether_wart_block", log2: "crimson_stem", lamp: "shroomlight", glass: "red_stained_glass", flower: ["crimson_roots"], cliff: ["basalt", "blackstone", "magma", "basalt", "smooth_basalt"], banner: "orange_wool", accent: "black_wool", water: "lava" },
  desert: { wall: "smooth_sandstone", base: "cut_sandstone", beam: "stripped_jungle_log", floor: "smooth_sandstone", roof: "cut_red_sandstone", roof2: "orange_terracotta", trim: "chiseled_sandstone", stone: "cut_sandstone", stone2: "sandstone", cw: "cut_sandstone", cw2: "chiseled_sandstone", path: "smooth_sandstone", path2: "cut_sandstone", plaza: "smooth_red_sandstone", ground: "sand", leaf: "jungle_leaves", log: "jungle_log", leaf2: "jungle_leaves", log2: "jungle_log", lamp: "lantern", glass: "orange_stained_glass", flower: ["deadbush", "cactus"], cliff: ["sandstone", "smooth_sandstone", "red_sandstone", "sandstone", "terracotta"], banner: "cyan_wool", accent: "orange_wool", water: "water", flat: true },
  crystal: { wall: "calcite", base: "smooth_basalt", beam: "amethyst_block", floor: "polished_deepslate", roof: "purple_terracotta", roof2: "amethyst_block", trim: "smooth_quartz", stone: "polished_deepslate", stone2: "calcite", cw: "polished_deepslate_bricks", cw2: "deepslate_bricks", path: "smooth_basalt", path2: "calcite", plaza: "polished_diorite", ground: "calcite", leaf: "azalea_leaves", log: "birch_log", leaf2: "flowering_azalea_leaves", log2: "birch_log", lamp: "end_rod", glass: "purple_stained_glass", flower: ["amethyst_cluster"], cliff: ["calcite", "tuff", "smooth_basalt", "deepslate"], banner: "magenta_wool", accent: "light_blue_wool", water: "water" },
  port: { wall: "white_terracotta", base: "prismarine_bricks", beam: "stripped_birch_log", floor: "birch_planks", roof: "light_blue_terracotta", roof2: "blue_terracotta", trim: "dark_prismarine", stone: "prismarine_bricks", stone2: "smooth_sandstone", cw: "prismarine_bricks", cw2: "dark_prismarine", path: "smooth_sandstone", path2: "birch_planks", plaza: "cut_sandstone", ground: "grass_block", leaf: "birch_leaves", log: "birch_log", leaf2: "jungle_leaves", log2: "jungle_log", lamp: "sea_lantern", glass: "light_blue_stained_glass_pane", flower: ["blue_orchid", "cornflower", "azure_bluet"], cliff: ["sandstone", "stone", "smooth_sandstone", "diorite"], banner: "blue_wool", accent: "white_wool", water: "water", sea: true },
  dark: { wall: "polished_blackstone_bricks", base: "deepslate_bricks", beam: "warped_stem", floor: "warped_planks", roof: "crimson_planks", roof2: "nether_bricks", trim: "polished_deepslate", stone: "deepslate_bricks", stone2: "cracked_deepslate_bricks", cw: "deepslate_bricks", cw2: "cracked_deepslate_bricks", path: "polished_deepslate", path2: "deepslate_tiles", plaza: "polished_blackstone", ground: "soul_soil", leaf: "warped_wart_block", log: "warped_stem", leaf2: "nether_wart_block", log2: "crimson_stem", lamp: "soul_lantern", glass: "purple_stained_glass", flower: ["wither_rose", "crimson_roots"], cliff: ["deepslate", "blackstone", "tuff", "basalt"], banner: "purple_wool", accent: "black_wool", water: "water" },
  snow: { wall: "white_concrete", base: "polished_diorite", beam: "spruce_log", floor: "spruce_planks", roof: "blue_terracotta", roof2: "packed_ice", trim: "stripped_spruce_log", stone: "polished_diorite", stone2: "stone_bricks", cw: "stone_bricks", cw2: "polished_diorite", path: "packed_ice", path2: "snow", plaza: "polished_diorite", ground: "snow", leaf: "spruce_leaves", log: "spruce_log", leaf2: "spruce_leaves", log2: "spruce_log", lamp: "lantern", glass: "glass_pane", flower: ["white_tulip"], cliff: ["stone", "packed_ice", "snow", "diorite", "stone"], banner: "light_blue_wool", accent: "white_wool", water: "water" },
  sky: { wall: "quartz_bricks", base: "smooth_quartz", beam: "quartz_pillar", floor: "birch_planks", roof: "light_blue_terracotta", roof2: "white_terracotta", trim: "gold_block", stone: "quartz_bricks", stone2: "smooth_quartz", cw: "quartz_bricks", cw2: "smooth_quartz", path: "smooth_quartz", path2: "birch_planks", plaza: "quartz_block", ground: "grass_block", leaf: "azalea_leaves", log: "birch_log", leaf2: "cherry_leaves", log2: "cherry_log", lamp: "end_rod", glass: "glass", flower: ["azure_bluet", "white_tulip", "lily_of_the_valley"], cliff: ["calcite", "diorite", "smooth_quartz", "stone"], banner: "light_blue_wool", accent: "yellow_wool", water: "water" },
  garden: null, farm: null,
};
for (const [k, L] of Object.entries({ village: ["red_nether_bricks", "brick_block", "dark_oak_planks", "deepslate_tiles", "red_nether_bricks"], forest: ["dark_oak_planks", "spruce_planks", "mossy_cobblestone"], castle: ["deepslate_tiles", "polished_deepslate", "dark_oak_planks", "red_nether_bricks"], port: ["light_blue_terracotta", "blue_terracotta", "cyan_terracotta", "white_terracotta"], desert: ["cut_red_sandstone", "orange_terracotta", "smooth_sandstone"], snow: ["blue_terracotta", "dark_oak_planks", "spruce_planks"], volcano: ["red_nether_bricks", "nether_bricks", "blackstone"], crystal: ["purple_terracotta", "magenta_terracotta", "light_blue_terracotta"], dark: ["crimson_planks", "nether_bricks", "warped_planks"], sky: ["light_blue_terracotta", "white_terracotta", "yellow_terracotta"] })) PAL[k].roofs = L;
PAL.garden = { ...PAL.village, roof: "pink_terracotta", leaf: "cherry_leaves", log: "cherry_log", leaf2: "cherry_leaves", log2: "cherry_log", flower: ["pink_tulip", "allium", "orange_tulip", "red_tulip"] };
PAL.farm = { ...PAL.village, roof: "dark_oak_planks", wall: "stripped_oak_log", ground: "grass_block", path: "dirt_path" };
export const palOf = (style) => PAL[style] || PAL.village;

/* ---------- 第106版: まわりの 自然の 地面に なじませる ---------- */
/* EDGE(x,z) = その 方向の 外の 地面の 高さ（町の 高さからの ずれ）。建てる 前に structures.js が はかって わたす */
let EDGE = null;
export function setEdge(f) { EDGE = f; }
function blendOut(h, x, z, rin, rout) {
  if (h === null || !EDGE) return h;
  const d = Math.hypot(x, z); if (d <= rin) return h;
  const n = EDGE(x, z); if (n === null || n === undefined) return h;
  const t = Math.min(1, (d - rin) / Math.max(1, rout - rin)), k = t * t * (3 - 2 * t);
  return Math.round(h * (1 - k) + n * k);
}

/* ---------- 設計図 ---------- */
/* 第106版: 統合版に ない 名前を 直す（ない ブロックの fill は 失敗して 屋根や 壁が ぬけて いた） */
const BEDROCK = { red_nether_bricks: "red_nether_brick", nether_bricks: "nether_brick", red_bed: "bed", melon: "melon_block", dirt_path: "grass_path", flowering_azalea_leaves: "azalea_leaves_flowered", polished_deepslate_bricks: "deepslate_bricks" };
const nb = (b) => { const m = String(b).match(/^\s*([a-z_]+)(.*)$/); return m && BEDROCK[m[1]] ? BEDROCK[m[1]] + m[2] : b; };
export class Blue {
  constructor(seed) { this.c = []; this.r = rng(seed); this.npc = []; this.walk = []; this.seat = []; this.keep = []; this.spots = []; this.mark = {}; this.chk = []; }
  fill(x1, y1, z1, x2, y2, z2, b, mode) {
    const ax = Math.min(x1, x2), bx = Math.max(x1, x2), ay = Math.min(y1, y2), by = Math.max(y1, y2), az = Math.min(z1, z2), bz = Math.max(z1, z2);
    const v = (bx - ax + 1) * (by - ay + 1) * (bz - az + 1);
    if (v > 30000) { const my = Math.floor((ay + by) / 2); if (by > ay) { this.fill(ax, ay, az, bx, my, bz, b, mode); this.fill(ax, my + 1, az, bx, by, bz, b, mode); return; } const mx = Math.floor((ax + bx) / 2); this.fill(ax, ay, az, mx, by, bz, b, mode); this.fill(mx + 1, ay, az, bx, by, bz, b, mode); return; }
    this.c.push([0, ax, ay, az, bx, by, bz, nb(b), mode ? String(mode).replace(/^replace ([a-z_]+)/, (_, x) => "replace " + nb(x)) : ""]);
  }
  set(x, y, z, b) { this.c.push([1, x, y, z, nb(b)]); }
  raw(x, y, z, t) { this.c.push([2, x, y, z, t]); }
  lootC(x, y, z, main) { this.c.push([3, x, y, z, main ? 2 : 1]); }   /* 第111版: 宝箱に 冒険の 道具（段は 土地の 強さで 上がる）*/   /* 第109版: {x}{y}{z} を 入れる コマンド（宝箱の 中身など）*/
  pick(a) { return a[Math.floor(this.r() * a.length)]; }
  ri(a, b) { return a + Math.floor(this.r() * (b - a + 1)); }
  /* 絶対座標の コマンドに */
  cmds(cx, cy, cz) {
    cx = Math.floor(cx); cy = Math.floor(cy); cz = Math.floor(cz);
    return this.c.filter((q) => q[0] !== 3).map((q) => q[0] === 2 ? q[4].replace(/\{x\}/g, cx + q[1]).replace(/\{y\}/g, cy + q[2]).replace(/\{z\}/g, cz + q[3]) : q[0] ? `setblock ${cx + q[1]} ${cy + q[2]} ${cz + q[3]} ${q[4]}` : `fill ${cx + q[1]} ${cy + q[2]} ${cz + q[3]} ${cx + q[4]} ${cy + q[5]} ${cz + q[6]} ${q[7]}${q[8] ? " " + q[8] : ""}`);
  }
}

/* ---------- 地形: 台地・崖・段（高さの 地図 → 行ごとの fill）---------- */
/* H(x,z) は 地面の 高さ（null は さわらない）。崖の 面は 石の まだら・上は 草 */
function terrain(B, R, H, pal, floor = -16) {
  const cl = pal.cliff; let lo = 99;
  for (let z = -R; z <= R; z += 2) for (let x = -R; x <= R; x += 2) { const h = H(x, z); if (h !== null && h < lo) lo = h; }
  rowFill(B, R, (x, z) => H(x, z) !== null, lo, lo + 44, "air");   /* まず 上を あける（第106版: 円の 中だけ。四すみの 外の 地面を 消して 穴に なって いた） */
  for (let z = -R; z <= R; z++) {
    let x = -R;
    while (x <= R) {
      const h = H(x, z); if (h === null) { x++; continue; }
      let x2 = x; while (x2 + 1 <= R && H(x2 + 1, z) === h) x2++;
      B.fill(x, floor, z, x2, h - 2, z, cl[(z & 1) ? 0 : 1 % cl.length]);
      B.fill(x, h - 1, z, x2, h - 1, z, pal.ground);
      x = x2 + 1;
    }
  }
}
/* 行ごとに 条件の 合う 区間を まとめて fill */
function rowFill(B, R, test, y1, y2, b) {
  for (let z = -R; z <= R; z++) { let x = -R; while (x <= R) { if (!test(x, z)) { x++; continue; } let x2 = x; while (x2 + 1 <= R && test(x2 + 1, z)) x2++; B.fill(x, y1, z, x2, y2, z, b); x = x2 + 1; } }
}
/* 第108版: 砂浜（海の 手前を 砂に。水着の 人たちが 遊びに 来る）*/
function beachSand(B, R, test, H) {
  for (let z = -R; z <= R; z++) { let x = -R; while (x <= R) { const h = test(x, z) ? H(x, z) : null; if (h === null || h === undefined) { x++; continue; } let x2 = x; while (x2 + 1 <= R && test(x2 + 1, z) && H(x2 + 1, z) === h) x2++; B.fill(x, h - 2, z, x2, h - 1, z, "sand"); x = x2 + 1; } }
}
function pave(B, R, test, H, blk) {   /* 第112版: 地面の 一番 上を 石だたみに（同じ 高さ・同じ ブロックを まとめて fill）*/
  for (let z = -R; z <= R; z++) { let x = -R; while (x <= R) { const h = test(x, z) ? H(x, z) : null; if (h === null || h === undefined) { x++; continue; } const b = blk(x, z); let x2 = x; while (x2 + 1 <= R && test(x2 + 1, z) && H(x2 + 1, z) === h && blk(x2 + 1, z) === b) x2++; B.fill(x, h - 1, z, x2, h - 1, z, b); x = x2 + 1; } }
}
/* 崖の 面に 石の まだら（上から 見て 外がわの ふち）*/
function cliffFace(B, R, H, pal) {
  const cl = pal.cliff;
  for (let z = -R; z <= R; z += 1) for (let x = -R; x <= R; x += 1) {
    const h = H(x, z); if (h === null) continue;
    let low = h; for (const [a, b] of [[x + 1, z], [x - 1, z], [x, z + 1], [x, z - 1]]) { const g = H(a, b); if (g !== null && g < low) low = g; }
    if (low <= h - 3) B.fill(x, low, z, x, h - 2, z, cl[(x * 13 + z * 7) % cl.length]);
  }
}

/* ---------- 木・岩・草花 ---------- */
export function bigTree(B, x, y, z, pal, kind = 0) {
  if (B.keep && B.keep.some((q) => x >= q[0] - 6 && x <= q[2] + 6 && z >= q[1] - 6 && z <= q[3] + 6)) return;   /* 第109版: 建物に 木を かぶせない */
  const r = B.r, log = kind ? pal.log2 : pal.log, leaf = kind ? pal.leaf2 : pal.leaf, h = 6 + Math.floor(r() * 5);
  if (pal === PAL.desert) { B.fill(x, y, z, x, y + h, z, log); for (const [a, c] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { B.fill(x + a, y + h, z + c, x + a * 3, y + h - 1, z + c * 3, leaf); } return; }
  if (log.includes("spruce")) { B.fill(x, y, z, x, y + h + 2, z, log); for (let k = 0; k < 5; k++) { const rr = Math.max(0, 3 - Math.floor(k * 0.7)); B.fill(x - rr, y + 3 + k * 2, z - rr, x + rr, y + 3 + k * 2, z + rr, leaf); } B.set(x, y + h + 3, z, leaf); return; }
  B.fill(x, y, z, x, y + h, z, log);
  if (h > 7) { B.fill(x + 1, y + h - 3, z, x + 2, y + h - 3, z, log); B.fill(x - 2, y + h - 2, z, x - 1, y + h - 2, z, log); }
  B.fill(x - 3, y + h - 2, z - 3, x + 3, y + h, z + 3, leaf); B.fill(x - 2, y + h + 1, z - 2, x + 2, y + h + 2, z + 2, leaf); B.fill(x - 4, y + h - 1, z - 1, x + 4, y + h - 1, z + 1, leaf); B.fill(x - 1, y + h - 1, z - 4, x + 1, y + h - 1, z + 4, leaf);
  B.fill(x - 3, y + h - 2, z - 3, x - 3, y + h - 2, z - 3, "air"); B.fill(x + 3, y + h, z + 3, x + 3, y + h, z + 3, "air");
}
function rock(B, x, y, z, pal) { if (B.keep && B.keep.some((q) => x >= q[0] - 2 && x <= q[2] + 2 && z >= q[1] - 2 && z <= q[3] + 2)) return; const s = 1 + Math.floor(B.r() * 2); B.fill(x - s, y, z - s + 1, x + s, y + s - 1, z + s - 1, pal.cliff[1] || "stone"); B.fill(x - s + 1, y + s, z - s + 1, x + s - 1, y + s, z + s - 1, pal.cliff[0]); }
function flowerAt(B, x, y, z, pal) { if (B.keep && B.keep.some((q) => x >= q[0] - 1 && x <= q[2] + 1 && z >= q[1] - 1 && z <= q[3] + 1)) return; const f = B.pick(pal.flower); if (/cactus/.test(f)) { B.set(x, y - 1, z, "sand"); B.fill(x, y, z, x, y + 1, z, "cactus"); return; } if (/deadbush/.test(f)) { B.set(x, y - 1, z, "sand"); } else if (/crimson|warped|wither/.test(f)) B.set(x, y - 1, z, f.includes("wither") ? "soul_soil" : "crimson_nylium"); else if (!/amethyst/.test(f)) B.set(x, y - 1, z, "grass_block"); B.set(x, y, z, f); }

/* ---------- 建物の 部品 ---------- */
/* 切妻の 屋根（棟は 長い ほう）。張り出し 1・破風に 木の 枠 */
function roof(B, x1, z1, x2, z2, y, pal, mat) {
  mat = mat || pal.roof; const alongX = (x2 - x1) >= (z2 - z1);
  const half = Math.ceil(((alongX ? z2 - z1 : x2 - x1) + 3) / 2);
  for (let k = 0; k < half; k++) {
    if (alongX) { const a = z1 - 1 + k, b = z2 + 1 - k; if (a > b) break; B.fill(x1 - 1, y + k, a, x2 + 1, y + k, a, mat); B.fill(x1 - 1, y + k, b, x2 + 1, y + k, b, mat); if (b - a > 1) { B.fill(x1, y + k, a + 1, x1, y + k, b - 1, pal.wall); B.fill(x2, y + k, a + 1, x2, y + k, b - 1, pal.wall); } }
    else { const a = x1 - 1 + k, b = x2 + 1 - k; if (a > b) break; B.fill(a, y + k, z1 - 1, a, y + k, z2 + 1, mat); B.fill(b, y + k, z1 - 1, b, y + k, z2 + 1, mat); if (b - a > 1) { B.fill(a + 1, y + k, z1, b - 1, y + k, z1, pal.wall); B.fill(a + 1, y + k, z2, b - 1, y + k, z2, pal.wall); } }
  }
  return y + half;
}
/* 木組みの 家（何階でも）。face=扉の 向き。kind で 中の かざり */
const BSK = { 0: "forge", 1: "armor", 3: "shop", 4: "eggs", 12: "library", 20: "tavern" };   /* 第125版(pl): 店の 仕事 → 物語の 場所の 名前 */
export function house(B, x, y, z, w, d, floors, face, pal, kind = "home", opt = {}) {
  if (floors > 1 && ((face === "s" || face === "n") ? w : d) - 2 < 6) floors = 1;   /* 第109版: 階段が 置けない 細い 家は 1階建て */
  const x1 = x - Math.floor(w / 2), x2 = x1 + w - 1, z1 = z - Math.floor(d / 2), z2 = z1 + d - 1, fh = 5, top = y + floors * fh;   /* 第106版: 天井を 1つ 高く */
  B.fill(x1 - 1, y - 1, z1 - 1, x2 + 1, y - 1, z2 + 1, pal.base);
  B.fill(x1, y, z1, x2, top - 1, z2, pal.wall, "hollow");
  B.fill(x1, y, z1, x2, y, z2, pal.base, "outline"); B.fill(x1 + 1, y, z1 + 1, x2 - 1, top - 1, z2 - 1, "air"); B.keep.push([x1, z1, x2, z2]);   /* 第109版: 中を 全部 空ける（木の 葉が 2階に 入りこんで いた）*/   /* 第108版: hollow の 底で 床が 1段 上がり NPC が 埋まって いた */
  for (let f = 0; f < floors; f++) { const fy = y + f * fh; if (f) B.fill(x1 + 1, fy - 1, z1 + 1, x2 - 1, fy - 1, z2 - 1, pal.floor); B.fill(x1, fy - 1 + (f ? 0 : 1), z1, x2, fy - 1 + (f ? 0 : 1), z1, pal.beam); B.fill(x1, fy - 1 + (f ? 0 : 1), z2, x2, fy - 1 + (f ? 0 : 1), z2, pal.beam); }
  B.fill(x1 + 1, y - 1, z1 + 1, x2 - 1, y - 1, z2 - 1, pal.floor);
  for (const [a, b] of [[x1, z1], [x2, z1], [x1, z2], [x2, z2]]) B.fill(a, y, b, a, top - 1, b, pal.beam);
  for (let a = x1 + 3; a < x2 - 1; a += 3) { B.fill(a, y + 1, z1, a, top - 1, z1, pal.beam); B.fill(a, y + 1, z2, a, top - 1, z2, pal.beam); }
  for (let b = z1 + 3; b < z2 - 1; b += 3) { B.fill(x1, y + 1, b, x1, top - 1, b, pal.beam); B.fill(x2, y + 1, b, x2, top - 1, b, pal.beam); }
  /* 窓（各階 2つずつ・下に 花箱）*/
  for (let f = 0; f < floors; f++) { const wy = y + f * fh + 1;
    for (let a = x1 + 2; a <= x2 - 2; a += 3) for (const b of [z1, z2]) { B.fill(a, wy, b, a, wy + 1, b, pal.glass); if (f && pal.leaf) B.set(a, wy - 1, b + (b === z1 ? -1 : 1), "azalea_leaves"); }
    for (let b = z1 + 2; b <= z2 - 2; b += 3) for (const a of [x1, x2]) B.fill(a, wy, b, a, wy + 1, b, pal.glass); }
  const rt = roof(B, x1, z1, x2, z2, top, pal, opt.roof || (pal.roofs ? B.pick(pal.roofs) : pal.roof));
  if (!opt.nochim) { const cx2 = x2 - 1, cz2 = z1 + 1; B.fill(cx2, top, cz2, cx2, rt + 1, cz2, "brick_block"); B.set(cx2, rt + 2, cz2, "campfire"); }
  /* 扉と 入口 */
  const door = face === "s" ? [x, z2] : face === "n" ? [x, z1] : face === "e" ? [x2, z] : [x1, z];
  B.fill(door[0], y, door[1], door[0], y + 2, door[1], "air");
  const out = face === "s" ? [x, z2 + 1] : face === "n" ? [x, z1 - 1] : face === "e" ? [x2 + 1, z] : [x1 - 1, z];
  B.set(out[0], y + 3, out[1], pal.lamp === "lantern" ? 'lantern ["hanging"=true]' : pal.lamp);
  if (opt.sign) { const sx = out[0] + (face === "s" || face === "n" ? 1 : 0), sz = out[1] + (face === "e" || face === "w" ? 1 : 0); B.fill(sx, y + 3, sz, sx, y + 3, sz, opt.sign); }
  /* 中: 明かり・家具 */
  B.set(x, top - 2, z, pal.lamp === "end_rod" ? "sea_lantern" : "glowstone");
  furnish(B, { x, y, z, x1, x2, z1, z2, face, floors, fh, kind, top });   /* 第109版: 内装を 作りこむ（2階への 階段・寝室・宝箱・カフェの 客 など）*/
  /* 第106版: 店の 人が 立つ 所（扉の 2マス 内がわ・空けて おく）*/
  const ins2 = face === "s" ? [x, z2 - 2] : face === "n" ? [x, z1 + 2] : face === "e" ? [x2 - 2, z] : [x1 + 2, z];
  B.fill(ins2[0], y, ins2[1], ins2[0], y + 1, ins2[1], "air");
  B.chk.push({ name: "建物 " + kind, pos: { x: ins2[0] + 0.5, y, z: ins2[1] + 0.5 } });   /* 第108版: 中に 入れるか の 点検用 */
  return { door: out, inside: ins2, top: rt, x1, x2, z1, z2 };
}
/* ---------- 第109版: 内装 ----------
   扉から 見た 向きで 置く: u = 左右（-が 左）、v = 奥行き（1 = 扉の すぐ 内がわ）。扉の 列（u=0）の 手前 2マスは 通路として 空ける */
const SEAT = "oak_slab", TABLE = "oak_fence", TOP = "wooden_pressure_plate";
const CHEST_ITEMS = ["bread 3", "cookie 6", "apple 4", "book 2", "paper 5", "candle 2", "cake 1", "pumpkin_pie 2", "emerald 1", "poppy 3", "sweet_berries 6", "honey_bottle 1"];
function furnish(B, h) {
  const { x, y, z, x1, x2, z1, z2, face, floors, fh, kind } = h;
  const sn = face === "s" || face === "n", W = (sn ? x2 - x1 : z2 - z1) - 1, D = (sn ? z2 - z1 : x2 - x1) - 1;
  const uMin = -Math.floor((W - 1) / 2), uMax = uMin + W - 1;
  /* 局所 → 世界 */
  const L = (u, v) => face === "s" ? [x + u, z2 - v] : face === "n" ? [x - u, z1 + v] : face === "e" ? [x2 - v, z - u] : [x1 + v, z + u];
  const dirU = face === "s" ? 0 : face === "n" ? 1 : face === "e" ? 3 : 2;   /* u が ふえる 向きの 階段の 向き（0 東 1 西 2 南 3 北）*/
  const put = (u, v, dy, b) => { const [a, c] = L(u, v); B.set(a, y + dy, c, b); };
  const used = new Set(), key = (u, v, f) => `${f}:${u}:${v}`, free = (u, v, f = 0) => u >= uMin && u <= uMax && v >= 1 && v <= D && !used.has(key(u, v, f)) && !(f === 0 && u === 0 && v <= 3);
  const P = (u, v, b, f = 0, dy = 0) => { if (!free(u, v, f) && dy === 0) return false; used.add(key(u, v, f)); put(u, v, f * fh + dy, b); return true; };
  const pat = [];   /* 座る 客 */
  const seat = (u, v, act, f = 0) => { if (P(u, v, SEAT, f)) { const [a, c] = L(u, v); pat.push({ pos: { x: a + 0.5, y: y + f * fh + 0.5, z: c + 0.5 }, act }); } };
  const stand = (u, v, place) => { if (!free(u, v)) return; used.add(key(u, v, 0)); const [a, c] = L(u, v); B.npc.push({ pos: { x: a + 0.5, y, z: c + 0.5 }, job: 24, act: 14, patron: place }); };   /* 立って 働く 店の 人 */
  const table = (u, v, f = 0, deco) => { if (P(u, v, TABLE, f)) put(u, v, f * fh + 1, deco || B.pick([TOP, TOP, "flower_pot", "cake", "candle"])); };
  /* ベッドは 2マス（足と 頭）。頭は 扉の ほう */
  const bed = (u, v, f = 0) => { if (!free(u, v, f) || !free(u, v - 1, f)) return; used.add(key(u, v, f)); used.add(key(u, v - 1, f)); const [a, c] = L(u, v), [a2, c2] = L(u, v - 1), dir = c2 > c ? 0 : a2 < a ? 1 : c2 < c ? 2 : 3;
    B.set(a, y + f * fh, c, `bed ["direction"=${dir},"head_piece_bit"=false]`); B.set(a2, y + f * fh, c2, `bed ["direction"=${dir},"head_piece_bit"=true]`); };
  let nMain = 0;
  const chest = (u, v, f) => { if (!P(u, v, "chest", f)) return; const [a, c] = L(u, v); B.lootC(a, y + f * fh, c, nMain++ === 0); if (B.r() < 0.5) B.raw(a, y + f * fh, c, `replaceitem block {x} {y} {z} slot.container 26 ${B.pick(CHEST_ITEMS)}`); };
  /* 2階への 階段（奥の 壁ぞい・1マスずつ）*/
  if (floors > 1 && W >= 6) for (let f = 0; f < floors - 1; f++) {
    const fy = f * fh; for (let k = 0; k < fh; k++) { const u = uMin + k; used.add(key(u, D, f)); used.add(key(u, D, f + 1)); put(u, D, fy + k, `oak_stairs ["weirdo_direction"=${dirU}]`); if (k >= 1 && k <= 3) put(u, D, fy + fh - 1, "air"); }
    for (let k = 0; k < fh - 1; k++) { const [a, c] = L(uMin + k, D), t = Math.min(fh - 2, k + 2); if (k + 1 <= t) B.fill(a, y + fy + k + 1, c, a, y + fy + t, c, "air"); }
    B.chk.push({ name: `${kind} ${f + 2}階`, pos: (() => { const [a, c] = L(uMin + fh, D); return { x: a + 0.5, y: y + fy + fh, z: c + 0.5 }; })() });
  }
  const G = (f) => f * fh;
  /* 1階 */
  if (kind === "home") {
    P(uMin, 1, "crafting_table"); P(uMax, 1, "furnace"); P(uMax, 2, "barrel"); P(uMin, 2, "bookshelf"); P(uMin, 3, "bookshelf");
    table(uMax - 1, 4); seat(uMax - 2, 4, 0); seat(uMax, 4, 0); put(0, 4, 0, B.pick(["red_carpet", "orange_carpet", "light_blue_carpet", "lime_carpet"]));
    if (floors === 1) { bed(uMax, D); chest(uMax - 1, D, 0); P(uMin, D, "flower_pot"); }
  } else if (kind === "shop") {
    for (let u = uMin; u <= uMax; u++) if (free(u, D)) P(u, D, B.pick(["barrel", "bookshelf", "chest", "barrel"]));
    for (let u = -2; u <= 2; u++) if (u !== 0) P(u, 5, B.pick(["barrel", "oak_planks", "spruce_planks"])); put(-2, 5, 1, "flower_pot"); put(2, 5, 1, "lantern");
    P(uMin, 1, "flower_pot"); P(uMax, 1, "flower_pot");
  } else if (kind === "forge") {
    P(uMin, 2, "anvil"); P(uMin, 4, "smithing_table"); P(uMax, 2, "blast_furnace"); P(uMax, 3, "furnace"); P(uMax, 4, "grindstone"); P(uMin, 5, "cauldron"); P(uMax, 5, "barrel");
  } else if (kind === "guild") {   /* 第111版: 冒険者協会（掲示板・作戦机・トロフィー棚・冒険者の 客）*/
    for (let u = uMin; u <= uMax; u++) if (free(u, D)) P(u, D, u % 2 ? "bookshelf" : "barrel");
    for (const u of [uMin + 1, uMax - 1]) { P(u, D - 1, "cartography_table"); }
    P(uMin, 2, "gold_block"); put(uMin, 2, 1, "flower_pot"); P(uMin, 3, "emerald_block"); P(uMax, 2, "lectern"); P(uMax, 3, "chest");
    for (const [u, v] of [[-2, 5], [2, 5]]) { table(u, v, 0, B.pick(["candle", TOP, "flower_pot"])); seat(u - 1, v, B.pick([3, 13, 4])); seat(u + 1, v, B.pick([3, 4, 11])); }
  } else if (kind === "bakery") {   /* パン屋 */
    P(uMin, D, "furnace"); P(uMin + 1, D, "smoker"); P(uMax, D, "barrel"); P(uMax - 1, D, "hay_block");
    for (let u = -2; u <= 2; u++) if (u !== 0) { P(u, 4, "spruce_planks"); put(u, 4, 1, B.pick(["cake", "candle", TOP, "flower_pot"])); }
    stand(1, 5, "bakery");
  } else if (kind === "flower") {   /* 花屋 */
    for (let u = uMin; u <= uMax; u++) for (const v of [D, D - 2]) if (free(u, v)) { P(u, v, B.pick(["moss_block", "grass", "moss_block"])); put(u, v, 1, B.pick(["red_tulip", "poppy", "dandelion", "azure_bluet", "cornflower", "oxeye_daisy", "allium"])); }
    P(uMin, 1, "flower_pot"); P(uMax, 1, "flower_pot"); stand(0, 4, "flower");
  } else if (kind === "tailor") {   /* 仕立て屋 */
    P(uMin, D, "loom"); P(uMin + 1, D, "loom"); P(uMax, D, "white_wool"); P(uMax - 1, D, "red_wool"); P(uMax, D - 1, "light_blue_wool"); P(uMin, 3, "cartography_table"); P(uMax, 3, "barrel");
    stand(-1, 4, "tailor");
  } else if (kind === "books") {
    for (let v = 2; v <= D - 1; v += 2) for (const u of [uMin, uMax]) P(u, v, "bookshelf"); for (let v = 2; v <= D - 1; v++) for (const u of [uMin, uMax]) P(u, v, "bookshelf");
    P(0, 5, "lectern"); table(-2, 5, 0, "candle"); seat(-3, 5, 11); table(2, 5, 0, "candle"); seat(3, 5, 11);
  } else if (kind === "tavern") {
    for (let v = 2; v <= D - 2; v++) P(uMax - 1, v, "spruce_planks"); for (let v = 2; v <= D - 2; v += 2) seat(uMax - 2, v, 13);
    for (let v = 2; v <= D - 1; v++) P(uMax, v, B.pick(["barrel", "barrel", "bookshelf"]));
    for (const [u, v] of [[uMin + 1, 3], [uMin + 1, 6], [-1, 6]]) { table(u, v); seat(u - 1, v, B.pick([3, 13, 2])); seat(u + 1, v, B.pick([3, 13, 4])); }
    P(uMin, 1, "barrel"); P(uMin, 2, "barrel");
  } else if (kind === "kitchen") {
    P(uMin, D, "smoker"); P(uMin + 1, D, "furnace"); P(uMin + 2, D, "cauldron"); P(uMin, D - 1, "barrel");
    for (let u = -2; u <= uMax - 1; u++) P(u, 4, "spruce_planks"); for (let u = -2; u <= uMax - 1; u += 2) { put(u, 4, 1, B.pick(["cake", "flower_pot", "candle", TOP])); seat(u, 3, 2); seat(u, 5, B.pick([2, 3, 4])); }
  } else if (kind === "cafe") {
    P(uMin, D, "barrel"); P(uMin + 1, D, "spruce_planks"); put(uMin + 1, D, 1, "cake"); P(uMin + 2, D, "spruce_planks"); put(uMin + 2, D, 1, "flower_pot");
    for (const [u, v] of [[uMin + 1, 2], [uMax - 1, 2], [uMax - 1, 5], [-1, 5]]) { table(u, v, 0, B.pick(["cake", "flower_pot", "candle", TOP])); seat(u - 1, v, B.pick([2, 3, 4])); seat(u + 1, v, B.pick([3, 2, 1])); }
    for (const u of [uMin, uMax]) P(u, 1, "flower_pot");
  }
  /* 2階より 上: 寝室（ベッド・宝箱・本棚・じゅうたん・明かり）*/
  for (let f = 1; f < floors; f++) {
    bed(uMax, D, f); bed(uMax - 2, D, f); chest(uMax, 1, f); chest(uMin, 1, f); P(uMin, 2, "bookshelf", f); P(uMax, 2, "crafting_table", f);
    table(-1, 3, f, "flower_pot"); seat(0, 3, 0, f); put(1, 3, G(f), B.pick(["white_carpet", "red_carpet", "light_gray_carpet"]));
    if (kind === "tavern" || kind === "shop") { bed(uMin + 1, 5, f); chest(uMin, 4, f); }
  }
  if (["cafe", "kitchen", "tavern", "books", "guild"].includes(kind)) for (const q of pat) if (q.act) B.npc.push({ pos: q.pos, job: 23, act: q.act, patron: kind });
}
/* 第111版: 海の家（屋根だけの 店。テーブルと 客）*/
function beachHouse(B, x, z, pal) {
  const y = -1;
  for (const [a, b] of [[-3, -2], [3, -2], [-3, 2], [3, 2]]) B.fill(x + a, y, z + b, x + a, y + 3, z + b, "stripped_birch_log");
  B.fill(x - 4, y + 4, z - 3, x + 4, y + 4, z + 3, B.pick(["light_blue_wool", "orange_wool", "white_wool"])); B.fill(x - 2, y + 5, z - 1, x + 2, y + 5, z + 1, "white_wool");
  B.fill(x - 2, y, z - 2, x + 2, y, z - 2, "birch_planks"); B.set(x - 1, y + 1, z - 2, "cake"); B.set(x + 1, y + 1, z - 2, "flower_pot"); B.set(x, y + 3, z, "lantern");
  for (const tx of [x - 2, x + 2]) { B.set(tx, y, z + 1, TABLE); B.set(tx, y + 1, z + 1, TOP); for (const sx of [tx - 1, tx + 1]) { B.set(sx, y, z + 1, SEAT); B.npc.push({ pos: { x: sx + 0.5, y: y + 0.5, z: z + 1.5 }, job: 23, act: B.pick([2, 3, 4]), patron: "cafe" }); } }
  B.npc.push({ pos: { x: x + 0.5, y, z: z - 2.5 + 1 }, job: 24, act: 14, patron: "bakery" });
  B.keep.push([x - 4, z - 3, x + 4, z + 3]); B.spots.push(["cafe", x, y, z + 3]);
}
/* 屋台（色つきの 屋根）*/
function stall(B, x, y, z, col, pal) {
  for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) B.fill(x + a, y, z + b, x + a, y + 2, z + b, "oak_fence");
  B.fill(x - 2, y + 3, z - 2, x + 2, y + 3, z + 2, col); B.fill(x - 1, y + 4, z - 1, x + 1, y + 4, z + 1, col);
  B.fill(x - 1, y, z, x + 1, y, z, "barrel"); B.set(x, y + 1, z, B.pick(["melon", "pumpkin", "hay_block", "cake", "flower_pot", "barrel"]));
}
/* 街灯・ベンチ */
function lampPost(B, x, y, z, pal) { B.fill(x, y, z, x, y + 3, z, pal.lamp === "shroomlight" ? "nether_brick_fence" : "dark_oak_fence"); B.set(x, y + 4, z, pal.lamp === "lantern" ? "lantern" : pal.lamp); }
function bench(B, x, y, z, ax, fx = 0, fz = 0) {   /* 第109版: 板の ベンチ（町の 人が 座る）。fx,fz = 向く 先 */
  if (ax) B.fill(x, y, z, x + 2, y, z, SEAT); else B.fill(x, y, z, x, y, z + 2, SEAT);
  for (let k = 0; k < 3; k += 2) B.seat.push([ax ? x + k : x, y, ax ? z : z + k, fx, fz]);
}
/* 噴水（3段）*/
function fountain(B, x, y, z, pal) {
  B.fill(x - 5, y - 1, z - 5, x + 5, y, z + 5, pal.stone, "outline"); B.fill(x - 4, y - 1, z - 4, x + 4, y - 1, z + 4, pal.water === "lava" ? "lava" : "water");
  B.fill(x - 4, y, z - 4, x + 4, y, z + 4, pal.stone, "outline"); B.fill(x - 3, y, z - 3, x + 3, y, z + 3, "air");
  B.fill(x - 1, y - 1, z - 1, x + 1, y + 2, z + 1, pal.trim); B.fill(x - 2, y + 3, z - 2, x + 2, y + 3, z + 2, pal.stone); B.fill(x - 1, y + 3, z - 1, x + 1, y + 3, z + 1, pal.water === "lava" ? "lava" : "water");
  B.fill(x, y + 4, z, x, y + 5, z, pal.trim); B.set(x, y + 6, z, pal.water === "lava" ? "lava" : "water");
}
/* 像（英雄の 像: 台座＋人の 形）*/
function statue(B, x, y, z, pal) {
  B.fill(x - 2, y, z - 2, x + 2, y + 2, z + 2, pal.stone); B.fill(x - 1, y + 3, z - 1, x + 1, y + 3, z + 1, pal.trim);
  B.fill(x, y + 4, z, x, y + 6, z, "polished_andesite"); B.set(x - 1, y + 6, z, "polished_andesite"); B.set(x + 1, y + 6, z, "polished_andesite"); B.set(x, y + 7, z, "polished_diorite");
  B.fill(x + 1, y + 7, z, x + 1, y + 9, z, "iron_bars"); B.set(x - 1, y + 5, z, "polished_andesite");
}
/* 風車 */
function windmill(B, x, y, z, pal, face = "s") {
  B.fill(x - 3, y, z - 3, x + 3, y + 10, z + 3, pal.base, "hollow"); B.fill(x - 2, y, z - 2, x + 2, y, z + 2, "air"); B.fill(x - 2, y + 11, z - 2, x + 2, y + 12, z + 2, pal.wall, "hollow");
  roof(B, x - 2, z - 2, x + 2, z + 2, y + 13, pal, pal.roof2); B.fill(x, y, z + 3, x, y + 2, z + 3, "air");
  const sz = z - 4; B.set(x, y + 11, sz, pal.beam);
  for (let k = 1; k <= 7; k++) { B.set(x + k, y + 11, sz, "oak_fence"); B.set(x - k, y + 11, sz, "oak_fence"); B.set(x, y + 11 + k, sz, "oak_fence"); B.set(x, y + 11 - k, sz, "oak_fence");
    if (k > 1) { B.set(x + k, y + 12, sz, "white_wool"); B.set(x - k, y + 10, sz, "white_wool"); B.set(x - 1, y + 11 + k, sz, "white_wool"); B.set(x + 1, y + 11 - k, sz, "white_wool"); } }
  for (let k = 3; k <= 10; k += 3) for (const [a, b] of [[x - 3, z], [x + 3, z]]) B.set(a, y + k, b, pal.glass);
}
/* 丸い 塔（円すいの 屋根）*/
function roundTower(B, x, y, z, r, h, pal, mat) {   /* 八角形の 塔（fill 2つで 丸く 見せる）*/
  const m = mat || pal.cw, c = Math.max(1, Math.round(r * 0.42));
  B.fill(x - r + c, y, z - r, x + r - c, y + h, z + r, m); B.fill(x - r, y, z - r + c, x + r, y + h, z + r - c, m);
  if (r > 2) { B.fill(x - r + c + 1, y + 1, z - r + 1, x + r - c - 1, y + h - 1, z + r - 1, "air"); B.fill(x - r + 1, y + 1, z - r + c + 1, x + r - 1, y + h - 1, z + r - c - 1, "air"); }
  B.fill(x - r + c, y + h + 1, z - r, x + r - c, y + h + 1, z + r, m); B.fill(x - r, y + h + 1, z - r + c, x + r, y + h + 1, z + r - c, m);
  for (let k = 0; k <= r + 1; k++) { const rr = r + 1 - k, cc = Math.max(0, Math.round(rr * 0.42)), yy = y + h + 2 + Math.floor(k * 1.6);
    B.fill(x - rr + cc, yy, z - rr, x + rr - cc, yy, z + rr, pal.roof); if (rr > 0) B.fill(x - rr, yy, z - rr + cc, x + rr, yy, z + rr - cc, pal.roof);
    if (k % 2 === 1 && yy + 1 < y + h + 2 + Math.floor((k + 1) * 1.6)) { B.fill(x - rr + cc, yy + 1, z - rr, x + rr - cc, yy + 1, z + rr, pal.roof); if (rr > 0) B.fill(x - rr, yy + 1, z - rr + cc, x + rr, yy + 1, z + rr - cc, pal.roof); } }
  B.fill(x - r, y + h - 4, z, x + r, y + h - 3, z, pal.glass); B.fill(x, y + h - 4, z - r, x, y + h - 3, z + r, pal.glass);
  if (r > 2) { B.fill(x - r + 1, y + h - 4, z, x + r - 1, y + h - 3, z, "air"); B.fill(x, y + h - 4, z - r + 1, x, y + h - 3, z + r - 1, "air"); }
  B.set(x, y + h + 3 + Math.floor((r + 1) * 1.6), z, pal.banner);
}
/* 大聖堂（尖塔・ばら窓）*/
function cathedral(B, x, y, z, pal) {
  const w = 13, d = 19, x1 = x - 6, x2 = x + 6, z1 = z - 9, z2 = z + 9;   /* 第108版: 少し 短く（ほかの 建物と 重なって いた）*/
  B.fill(x1 - 1, y - 1, z1 - 1, x2 + 1, y - 1, z2 + 1, pal.stone);
  B.fill(x1, y, z1, x2, y + 11, z2, pal.wall, "hollow"); B.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, "air"); B.fill(x1 + 1, y - 1, z1 + 1, x2 - 1, y - 1, z2 - 1, pal.plaza);
  for (let b = z1; b <= z2; b += 4) { B.fill(x1 - 1, y, b, x1 - 1, y + 9, b, pal.stone); B.fill(x2 + 1, y, b, x2 + 1, y + 9, b, pal.stone); B.fill(x1, y + 3, b + 2, x1, y + 8, b + 2, "stained_glass" === "x" ? "glass" : B.pick(["blue_stained_glass", "red_stained_glass", "yellow_stained_glass", "purple_stained_glass"])); B.fill(x2, y + 3, b + 2, x2, y + 8, b + 2, B.pick(["blue_stained_glass", "red_stained_glass", "yellow_stained_glass", "purple_stained_glass"])); }
  roof(B, x1, z1, x2, z2, y + 12, pal, pal.roof2);
  /* 正面の 塔と ばら窓 */
  B.fill(x - 3, y, z2 - 2, x + 3, y + 22, z2 + 2, pal.stone, "hollow"); B.fill(x - 2, y, z2 - 1, x + 2, y, z2 + 1, "air");
  for (let k = 0; k < 6; k++) B.fill(x - 3 + Math.floor(k / 2), y + 23 + k * 2, z2 - 2 + Math.floor(k / 2), x + 3 - Math.floor(k / 2), y + 24 + k * 2, z2 + 2 - Math.floor(k / 2), pal.roof2);
  B.fill(x, y + 35, z2, x, y + 37, z2, pal.trim); B.set(x, y + 38, z2, "lightning_rod");
  B.fill(x - 2, y + 13, z2 + 2, x + 2, y + 17, z2 + 2, "white_stained_glass"); B.fill(x - 1, y + 14, z2 + 2, x + 1, y + 16, z2 + 2, "light_blue_stained_glass"); B.set(x, y + 15, z2 + 2, "yellow_stained_glass");
  B.fill(x - 1, y, z2 - 2, x + 1, y + 4, z2 + 2, "air");   /* 第108版: 塔から 聖堂の 中へ 通れる（前は 壁で ふさがって いた）*/
  B.chk.push({ name: "大聖堂", pos: { x: x + 0.5, y, z: z + 0.5 } });
  B.set(x, y + 20, z2, "bell");
  /* 中: 長いす と 祭壇 */
  for (let b = z1 + 4; b <= z2 - 5; b += 2) { B.fill(x1 + 2, y, b, x - 2, y, b, 'dark_oak_stairs ["weirdo_direction"=2]'); B.fill(x + 2, y, b, x2 - 2, y, b, 'dark_oak_stairs ["weirdo_direction"=2]'); }
  B.fill(x - 2, y, z1 + 1, x + 2, y, z1 + 2, pal.trim); B.set(x, y + 1, z1 + 1, "candle"); B.fill(x - 3, y + 6, z, x + 3, y + 6, z, "air"); B.set(x, y + 9, z, "sea_lantern"); B.set(x, y + 9, z1 + 5, "sea_lantern"); B.set(x, y + 9, z2 - 5, "sea_lantern");
  /* 第111版: 聖歌隊（祭壇の 前に 立つ）と 長いすで 祈る 人 */
  for (const dx of [-2, -1, 1, 2]) B.npc.push({ pos: { x: x + dx + 0.5, y, z: z1 + 3.5 }, job: 24, act: 14, patron: "choir" });
  for (const b of [z1 + 6, z1 + 10]) for (const dx of [-4, 3]) B.npc.push({ pos: { x: x + dx + 0.5, y: y + 0.5, z: b + 0.5 }, job: 23, act: 1, patron: "church" });
  B.spots.push(["church", x, y, z2 + 3]);
  return { door: [x, z2 + 3] };
}
/* 城（天守・4つの 塔・城壁・中庭・玉座の 間）*/
function palace(B, x, y, z, pal) {
  const R = 14;
  B.fill(x - R, y - 1, z - R, x + R, y - 1, z + R, pal.plaza);
  B.fill(x - R, y, z - R, x + R, y + 7, z + R, pal.cw, "hollow"); B.fill(x - R + 1, y, z - R + 1, x + R - 1, y + 7, z + R - 1, "air");
  B.fill(x - R + 1, y - 1, z - R + 1, x + R - 1, y - 1, z + R - 1, pal.plaza);
  for (let k = -R; k <= R; k += 2) { B.set(x + k, y + 8, z - R, pal.cw); B.set(x + k, y + 8, z + R, pal.cw); B.set(x - R, y + 8, z + k, pal.cw); B.set(x + R, y + 8, z + k, pal.cw); }
  for (const [a, b] of [[-R, -R], [R, -R], [-R, R], [R, R]]) roundTower(B, x + a, y, z + b, 4, 14, pal);
  /* 天守（奥）*/
  const kz1 = z - R + 2, kz2 = z - 2;
  B.fill(x - 10, y, kz1, x + 10, y + 16, kz2, pal.stone, "hollow"); B.fill(x - 9, y, kz1 + 1, x + 9, y, kz2 - 1, "air");
  for (let a = x - 10; a <= x + 10; a += 4) B.fill(a, y + 3, kz2, a, y + 12, kz2, pal.glass);
  B.fill(x - 2, y, kz2, x + 2, y + 6, kz2, "air"); B.fill(x - 3, y + 7, kz2 + 1, x + 3, y + 7, kz2 + 1, pal.trim);
  roof(B, x - 10, kz1, x + 10, kz2, y + 17, pal);
  roundTower(B, x, y + 16, z - 9, 4, 12, pal, pal.stone);
  for (const a of [x - 10, x + 10]) roundTower(B, a, y + 10, kz1 + 1, 3, 10, pal, pal.stone);
  /* 玉座の 間 */
  B.fill(x - 1, y - 1, kz1 + 2, x + 1, y - 1, kz2, "red_carpet" === "x" ? "x" : "red_wool"); B.fill(x - 1, y, kz1 + 2, x + 1, y, kz2 - 1, "red_carpet");
  B.fill(x - 1, y, kz1 + 1, x + 1, y + 1, kz1 + 1, "gold_block"); B.set(x, y + 2, kz1 + 1, "gold_block");
  for (const a of [x - 6, x + 6]) for (let b = kz1 + 3; b < kz2; b += 3) { B.fill(a, y, b, a, y + 14, b, pal.trim); B.set(a, y + 5, b + 1, "lantern"); }
  B.set(x, y + 14, z - 9, "sea_lantern");
  /* 門（南）・旗 */
  B.fill(x - 3, y, z + R, x + 3, y + 5, z + R, "air"); B.fill(x - 4, y, z + R + 1, x - 4, y + 9, z + R + 1, pal.trim); B.fill(x + 4, y, z + R + 1, x + 4, y + 9, z + R + 1, pal.trim); B.fill(x - 4, y + 9, z + R + 1, x + 4, y + 10, z + R + 1, pal.cw);
  B.fill(x - 3, y + 6, z + R, x + 3, y + 7, z + R, "iron_bars");
  for (const a of [x - 8, x + 8]) { B.fill(a, y + 2, z + R + 1, a, y + 7, z + R + 1, pal.banner); }
  /* 中庭の 花と 木 */
  for (const a of [x - 11, x + 11]) { bigTree(B, a, y, z + 8, pal, 1); B.fill(a - 2, y - 1, z + 4, a + 2, y - 1, z + 12, pal.ground); }
  return { throne: { x: x + 0.5, y, z: kz1 + 3.5 }, master: { x: x + 0.5, y, z: z + 6.5 }, gate: { x: x + 0.5, y, z: z + R + 2.5 } };
}
/* 城壁（八角形・歩廊・胸壁・角に 塔）*/
function cityWall(B, r, y, pal, gates, H) {   /* 四角い 城壁（角を 落とす）。高さは 一定・胸壁つき */
  const c = 10, top = y + 8;
  const edges = [[-r + c, -r, r - c, -r], [-r + c, r, r - c, r], [-r, -r + c, -r, r - c], [r, -r + c, r, r - c]];
  for (const [ax, az, bx, bz] of edges) { B.fill(ax - (ax === bx ? 1 : 0), y - 4, az - (az === bz ? 1 : 0), bx + (ax === bx ? 1 : 0), top, bz + (az === bz ? 1 : 0), pal.cw); B.fill(ax, top + 1, az, bx, top + 1, bz, pal.cw2); B.fill(ax - (ax === bx ? 1 : 0), top + 1, az - (az === bz ? 1 : 0), ax - (ax === bx ? 1 : 0), top + 1, az - (az === bz ? 1 : 0), pal.cw); }
  for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { for (let k = 0; k <= c; k++) { const x = sx * (r - c + k), z = sz * (r - k); B.fill(x - 1, y - 4, z - 1, x + 1, top, z + 1, pal.cw); } roundTower(B, sx * (r - c / 2), y - 4, sz * (r - c / 2), 4, 16, pal); }
  for (const [gx, gz] of gates) { const ax = Math.abs(gx) > Math.abs(gz);
    if (ax) { B.fill(gx - 1, y, gz - 3, gx + 1, y + 5, gz + 3, "air"); for (const s of [-5, 5]) roundTower(B, gx, y - 4, gz + s, 3, 16, pal, pal.stone); B.fill(gx - 1, y + 6, gz - 3, gx + 1, y + 6, gz + 3, "iron_bars"); }
    else { B.fill(gx - 3, y, gz - 1, gx + 3, y + 5, gz + 1, "air"); for (const s of [-5, 5]) roundTower(B, gx + s, y - 4, gz, 3, 16, pal, pal.stone); B.fill(gx - 3, y + 6, gz - 1, gx + 3, y + 6, gz + 1, "iron_bars"); } }
}
/* 道（幅 w。石の まだら）*/
function road(B, x1, z1, x2, z2, w, H, pal) {
  const n = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1)); for (let i = 0; i <= n; i++) { const x = Math.round(x1 + (x2 - x1) * i / n), z = Math.round(z1 + (z2 - z1) * i / n), h = H(x, z); if (h === null) continue;
    B.fill(x - w, h - 1, z - w, x + w, h - 1, z + w, (i % 5 === 0) ? pal.path2 : pal.path); }
}

/* ======================= 都（城下町）======================= */
/* r=64 の 台地。北が 高い 丘（城）、南に 城下町。外は 崖と 森と 堀 */
export function capitalPlan(i, style, seed) {
  const pal = palOf(style), B = new Blue(seed || 1000 + i), R = 72, WALL = 50, s = (seed || i) * 31 + 7;
  const sea = !!pal.sea;
  const GZ = sea ? 4 : 26, GY = sea ? 5 : 0;   /* 第108版: 東西の 門の 位置と 高さ（海の 都は 南が 海なので 中段の 高さで 入る）*/
  /* 高さ: 城の 丘 +12（北）・中段 +5（広場）・下段 0（南）。外は 崖で -6 まで 下がり、まわりは 森の 丘 */
  const sq = (x, z) => Math.max(Math.abs(x), Math.abs(z), Math.abs(x) + Math.abs(z) - (WALL - 10));   /* 城壁と 同じ 形の きょり */
  const H0 = (x, z) => {
    const d = Math.hypot(x, z), q = sq(x, z), n = noise(x + 500, z + 500, s, 14);
    if (d > R) return null;
    if (q > WALL + 9) { const t = Math.min(1, (q - WALL - 9) / 8); if (sea && z > 10) return -4;   /* 外: 湖を かこむ 森の 丘（第108版: 北の 崖を 低く）*/
      if (Math.abs(x) <= 4 && z > 0) return 0; if (Math.abs(z - GZ) <= 4 && Math.abs(x) > WALL) return GY;   /* 第108版: 門の 前は 橋と 同じ 高さ（飛び降りずに 入れる。外へは なだらかに）*/
      const north = z < -6 ? Math.min(1, (-6 - z) / 26) : 0; return 2 * Math.round((-1 + t * (3 + north * 8) + n * 3 - (d > R - 4 ? (d - R + 4) * 1.5 : 0)) / 2); }
    if (q > WALL + 1) return sea && z > 10 ? -4 : -4;   /* 湖（あとで 水）*/
    if (z < -19) return 12;   /* 城の 丘 */
    if (z < -12) return 5 + (-12 - z);   /* 坂（階段）第108版: 1マスずつ（前は 2マスの 段が あって 登れなかった）*/
    if (z < 14) return 5;   /* 中段（広場）*/
    if (z < 19) return 5 - (z - 13);   /* 第108版: 1マスずつ */
    return 0;   /* 下段 */
  };
  const H = (x, z) => blendOut(H0(x, z), x, z, WALL + 12, R);
  terrain(B, R, H, pal, -18);
  /* 堀（城壁の 外）*/
  { const lake = (x, z) => { const q = sq(x, z); return q > WALL + 1.5 && q <= WALL + 9 && Math.hypot(x, z) <= R; }; rowFill(B, R, lake, -8, -6, pal.cliff[1] === "tuff" ? "gravel" : "sand"); rowFill(B, R, lake, -5, -4, pal.water === "lava" ? "lava" : "water"); }   /* 都を かこむ 湖 */
  /* 海の 都: 南は 港（海）*/
  if (sea) { const sw = (x, z) => z >= 26 && sq(x, z) > WALL + 1 && Math.hypot(x, z) <= R; rowFill(B, R, sw, -9, -4, "water"); rowFill(B, R, sw, -3, 6, "air"); } if (sea) beachSand(B, R, (x, z) => z >= 19 && z <= 25 && sq(x, z) > WALL + 2 && Math.abs(x) > 4 && Math.hypot(x, z) <= R - 4, H);
  /* 城（北の 丘）*/
  const pc = palace(B, 0, 12, -33, pal);
  /* 丘の 上の 貴族の 館と 庭園（城の 左右）*/
  for (const sx of [-1, 1]) { const x = sx * 31; house(B, x, 12, -34, 13, 11, 3, sx < 0 ? "e" : "w", pal, "books", { nochim: false });
    B.fill(x - 6, 11, -24, x + 6, 11, -20, pal.path); for (let k = -6; k <= 6; k += 3) { B.fill(x + k, 12, -27, x + k, 12, -27, "azalea_leaves"); B.set(x + k, 12, -22, B.pick(pal.flower.filter((f) => !/cactus|amethyst/.test(f))) || "poppy"); }
    bigTree(B, x + sx * 8, 12, -24, pal, 1); B.fill(x - 1, 11, -45, x + 1, 11, -45, pal.stone); }
  /* 大階段（坂）と 噴水の 広場 */
  for (let z = -19; z <= -12; z++) { const h = H(0, z); B.fill(-4, h - 1, z, 4, h - 1, z, pal.stone); for (const a of [-5, 5]) { B.fill(a, h - 1, z, a, h, z, pal.trim); } }
  for (let z = -12; z <= -11; z++) B.fill(-4, 4, z, 4, 4, z, pal.stone);
  B.fill(-14, 4, -10, 14, 4, 12, pal.plaza); for (let a = -14; a <= 14; a += 4) for (let b = -10; b <= 12; b += 4) B.set(a, 4, b, pal.path2);
  fountain(B, 0, 5, 1, pal); statue(B, 0, 5, -8, pal);
  for (const [a, b] of [[-13, -9], [13, -9], [-13, 11], [13, 11], [-7, 11], [7, 11]]) lampPost(B, a, 5, b, pal);
  for (const [a, b, ax] of [[-10, 5, 0], [10, 5, 0], [-4, 10, 1], [2, 10, 1]]) bench(B, a, 5, b, ax, 0, 6);
  /* 坂の 下: 中段 → 下段 の 階段 */
  for (let z = 14; z <= 18; z++) { const h = H(0, z); B.fill(-3, h - 1, z, 3, h - 1, z, pal.stone); }
  /* 大通り（南の 門 → 広場）*/
  road(B, 0, 18, 0, WALL + 2, 2, H, pal); road(B, -WALL + 2, 26, WALL - 2, 26, 1, H, pal); road(B, -WALL + 4, 40, WALL - 4, 40, 1, H, pal);
  road(B, -20, 4, -WALL + 2, 4, 1, H, pal); road(B, 20, 4, WALL - 2, 4, 1, H, pal);
  /* 中段の 名所: 冒険者協会（西）・酒場（東）・レストラン（東の 南）・大聖堂（西の 北）*/
  const N = (job, pos, name, kind) => B.npc.push({ job, pos, name, kind });
  const RC = [[-WALL, 24, WALL, 28], [-WALL, 38, WALL, 42], [-3, 14, 3, WALL], [-15, -11, 15, 13], [-WALL, -WALL, WALL, -19]];   /* 第108版: 道・広場・城の 丘（家を 置かない 所）*/
  const hitC = (a) => RC.some((q) => a[0] - 1 <= q[2] && a[2] + 1 >= q[0] && a[1] - 1 <= q[3] && a[3] + 1 >= q[1]);
  const g1 = house(B, -24, 5, 4, 15, 11, 3, "e", { ...pal, roof: pal.roof2 }, "guild", { sign: pal.banner, nochim: true }); N(22, { x: g1.inside[0] + 0.5, y: 5, z: g1.inside[1] + 0.5 }, "§e冒険者協会の 受付", "guild"); RC.push([g1.x1 - 1, g1.z1 - 1, g1.x2 + 1, g1.z2 + 1]);
  for (const b of [0, 8]) B.fill(-17, 5, b - 3, -17, 10, b - 3, pal.banner);
  const tv = house(B, 24, 5, -4, 13, 11, 2, "w", pal, "tavern", { sign: "orange_wool" }); N(20, { x: tv.inside[0] + 0.5, y: 5, z: tv.inside[1] + 0.5 }, "§e酒場の マスター", "tavern"); RC.push([tv.x1 - 2, tv.z1 - 1, tv.x2 + 1, tv.z2 + 1]);
  B.fill(17, 5, -8, 17, 5, -6, "oak_fence"); B.fill(17, 5, -2, 17, 5, -2, "oak_fence");   /* 第108版: 酒場の 入口を ふさいで いた */ B.fill(16, 5, -8, 16, 5, -8, "barrel"); B.set(16, 5, -1, "barrel");
  const rs = house(B, 24, 5, 10, 11, 9, 2, "w", { ...pal, roof: pal.roof2 }, "kitchen", { sign: "lime_wool" }); B.spots.push(["diner", rs.door[0], 5, rs.door[1]]); N(21, { x: rs.inside[0] + 0.5, y: 5, z: rs.inside[1] + 0.5 }, "§eレストランの 料理人", "food"); RC.push([rs.x1 - 2, rs.z1 - 1, rs.x2 + 1, rs.z2 + 1]);
  for (const [a, b] of [[15, 7], [15, 13]]) { B.set(a, 5, b, "oak_fence"); B.set(a, 6, b, "white_carpet"); B.set(a - 1, 5, b, 'oak_stairs ["weirdo_direction"=0]'); B.set(a + 0, 8, b, "red_wool"); B.fill(a, 6, b, a, 7, b, "oak_fence"); }
  cathedral(B, -38, 5, -4, pal); RC.push([-47, -14, -31, 10]);   /* 第108版: 冒険者協会と 重なって 入れなかった */
  /* 下段: 店・家・屋台・風車 */
  const shops = [[0, "武器屋", -9, 30, "e"], [1, "防具屋", 9, 30, "w"], [3, "道具屋", -13, 45, "e"], [4, "タマゴ屋", 13, 45, "w"], [2, "宿屋", -24, 33, "e"], [11, "モンスター屋", 24, 33, "w"], [6, "預かり屋", -24, 45, "e"], [12, "図書館", 24, 45, "w"], [14, "釣り屋", -38, 33, "e"], [5, "闘技場", 38, 33, "w"]];   /* 第108版: 下段へ（大聖堂と 重なって いた）*/
  for (const [job, nm, x, z, f] of shops) { const h = H(x, z); const w = job === 2 ? 11 : 9; const r = house(B, x, h, z, w, z >= 45 ? 7 : 9, job === 2 ? 3 : 2, f, pal, job <= 1 ? "forge" : job === 12 ? "books" : "shop", { sign: B.pick(["red_wool", "yellow_wool", "blue_wool", "lime_wool", "orange_wool"]) }); N(job, { x: r.inside[0] + 0.5, y: h, z: r.inside[1] + 0.5 }, `§e${nm}`); RC.push([r.x1, r.z1, r.x2, r.z2]); if (job === 2) B.spots.push(["inn", r.door[0], h, r.door[1]]); }
  const used = shops.map(([, , x, z]) => [x, z]);
  /* 第112版: 地方ごとの 名物（下段の 空き地に）・通りの 旗飾り・店の 日よけ */
  const freeC = (w, d, z0 = 20) => { for (let k = 0; k < 160; k++) { const x = B.ri(-WALL + 6 + w, WALL - 6 - w), z = B.ri(z0, WALL - 6 - d), rc = [x - w, z - d, x + w, z + d]; if (Math.abs(x) < 6 + w || hitC(rc) || sq(x - w, z - d) > WALL - 5 || sq(x + w, z + d) > WALL - 5 || sq(x - w, z + d) > WALL - 5 || sq(x + w, z - d) > WALL - 5) continue; if ([[x - w, z - d], [x + w, z + d], [x - w, z + d], [x + w, z - d], [x, z]].some(([a, b]) => H(a, b) !== 0)) continue; RC.push([rc[0] - 1, rc[1] - 1, rc[2] + 1, rc[3] + 1]); return { x, z }; } return null; };
  const sty = style;
  if (sty === "desert") { const q = freeC(5, 4); if (q) { B.fill(q.x - 4, -2, q.z - 3, q.x + 4, -1, q.z + 3, "water"); B.fill(q.x - 5, -1, q.z - 4, q.x + 5, -1, q.z + 4, pal.stone, "outline"); for (const [a, b] of [[-5, -4], [5, 4], [-5, 4], [5, -4]]) bigTree(B, q.x + a, 0, q.z + b, pal); }   /* オアシスの 泉 */
    for (let k = 0; k < 6; k++) { const q2 = freeC(2, 2); if (q2) stall(B, q2.x, 0, q2.z, B.pick(["orange_wool", "yellow_wool", "red_wool", "white_wool"]), pal); } }   /* 市場 */
  else if (sty === "snow") { const q = freeC(5, 4); if (q) { B.fill(q.x - 4, -1, q.z - 3, q.x + 4, -1, q.z + 3, "packed_ice"); B.fill(q.x - 5, 0, q.z - 4, q.x + 5, 0, q.z + 4, "spruce_fence", "outline"); B.fill(q.x, 0, q.z - 4, q.x, 0, q.z - 4, "air"); for (const a of [-3, 3]) { B.fill(q.x + a, 0, q.z, q.x + a, 1, q.z, "snow"); B.set(q.x + a, 2, q.z, "carved_pumpkin"); } }   /* 氷の すべり場と 雪だるま */
    for (let k = 0; k < 4; k++) { const q2 = freeC(1, 1); if (q2) { B.fill(q2.x, 0, q2.z, q2.x, 1, q2.z, "spruce_log"); B.fill(q2.x - 1, 2, q2.z - 1, q2.x + 1, 4, q2.z + 1, "spruce_leaves"); B.set(q2.x, 5, q2.z, "spruce_leaves"); B.set(q2.x, 6, q2.z, "glowstone"); } } }   /* 光る もみの木 */
  else if (sty === "volcano") { const q = freeC(3, 3); if (q) { roundTower(B, q.x, 0, q.z, 3, 10, { ...pal, roof: "blackstone" }, "polished_blackstone_bricks"); for (const [a, b] of [[-2, 0], [2, 0]]) B.set(q.x + a, 1, q.z + b + 3, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'); B.set(q.x, 14, q.z, "campfire"); } }   /* 大かじ場の 塔 */
  else if (sty === "crystal") for (let k = 0; k < 5; k++) { const q = freeC(1, 1); if (!q) continue; const h = B.ri(4, 8); B.fill(q.x, 0, q.z, q.x, h, q.z, "amethyst_block"); B.set(q.x, h + 1, q.z, "amethyst_cluster"); B.set(q.x + 1, 0, q.z, "budding_amethyst"); B.set(q.x - 1, 0, q.z, "tinted_glass"); }   /* 水晶の 柱 */
  else if (sty === "dark") { const q = freeC(5, 4); if (q) { B.fill(q.x - 5, 0, q.z - 4, q.x + 5, 0, q.z + 4, "cobblestone_wall", "outline"); B.fill(q.x, 0, q.z - 4, q.x, 0, q.z - 4, "air"); for (let a = -3; a <= 3; a += 3) for (let b = -2; b <= 2; b += 2) { B.set(q.x + a, 0, q.z + b, "stone_brick_wall"); B.set(q.x + a, 1, q.z + b, "candle"); } }   /* 墓地 */
    for (let k = 0; k < 4; k++) { const q2 = freeC(0, 0); if (q2) { B.fill(q2.x, 0, q2.z, q2.x, 2, q2.z, "nether_brick_fence"); B.set(q2.x, 3, q2.z, "soul_lantern"); } } }
  else if (sty === "forest") { const q = freeC(4, 4); if (q) { B.fill(q.x - 1, 0, q.z - 1, q.x + 1, 14, q.z + 1, pal.log || "spruce_log"); B.fill(q.x - 6, 12, q.z - 6, q.x + 6, 16, q.z + 6, pal.leaf || "oak_leaves"); B.fill(q.x - 4, 17, q.z - 4, q.x + 4, 18, q.z + 4, pal.leaf || "oak_leaves"); B.fill(q.x - 1, 0, q.z - 2, q.x - 1, 1, q.z - 2, "air"); } }   /* 町の 大樹 */
  else if (sty === "castle") for (let k = 0; k < 5; k++) { const q = freeC(0, 0); if (q) { const h = B.ri(2, 6); B.fill(q.x, 0, q.z, q.x, h, q.z, B.pick(["cracked_stone_bricks", "mossy_stone_bricks", "stone_bricks"])); if (h > 4) B.set(q.x, h + 1, q.z, "stone_brick_slab"); } }   /* 古い 柱 */
  else if (sty === "sky") for (let k = 0; k < 4; k++) { const q = freeC(2, 2); if (!q) continue; const y = B.ri(12, 18); B.fill(q.x - 2, y, q.z - 2, q.x + 2, y, q.z + 2, "grass_block"); B.fill(q.x - 1, y - 2, q.z - 1, q.x + 1, y - 1, q.z + 1, "stone"); B.set(q.x, y - 3, q.z, "stone"); B.set(q.x, y + 1, q.z, B.pick(["azalea", "flowering_azalea"])); RC.pop(); }   /* 浮かぶ 小島（下は 歩ける）*/
  else if (sty === "port") { for (let k = 0; k < 6; k++) { const q2 = freeC(2, 2); if (q2) stall(B, q2.x, 0, q2.z, B.pick(["light_blue_wool", "white_wool", "orange_wool", "cyan_wool"]), pal); } }   /* 港の 朝市（家は 色とりどり）*/
  else { for (let k = 0; k < 3; k++) { const q = freeC(3, 2); if (q) { B.fill(q.x - 3, -1, q.z - 2, q.x + 3, -1, q.z + 2, "farmland"); B.fill(q.x - 3, 0, q.z - 2, q.x + 3, 0, q.z + 2, B.pick(["wheat", "carrots", "potatoes"])); B.fill(q.x - 4, -1, q.z, q.x + 4, -1, q.z, "water"); } } }   /* 畑 */
  /* 第113版: コンテスト会場と おもちゃの 店 */
  { const q = !hitC([34, -9, 46, 5]) && sq(46, 5) < WALL - 2 ? { x: 40, z: -2, y: 5 } : null; if (q) { RC.push([33, -10, 47, 6]); const r = house(B, q.x, 5, q.z, 13, 15, 2, "w", { ...pal, roof: "purple_terracotta" }, "guild", { sign: "purple_wool", nochim: true }); awning(B, r, 5, "purple_wool"); B.npc.push({ job: 5, role: "contest", pos: { x: r.inside[0] + 0.5, y: 5, z: r.inside[1] + 0.5 }, name: "§dコンテスト係" }); } }
  { stall(B, 9, 5, -4, "magenta_wool", pal); B.npc.push({ job: 3, role: "toy", pos: { x: 9.5, y: 5, z: -4.5 }, name: "§eおもちゃと 名物の 店" }); }   /* 広場の 屋台 */
  let ncafe = 0;
  for (let z = 22; z <= WALL - 7; z += 10) for (let x = -WALL + 8; x <= WALL - 8; x += 12) { if (Math.abs(x) < 15 || Math.abs(z - 26) < 3 || Math.abs(z - 40) < 3 || used.some(([a, b]) => Math.abs(a - x) < 11 && Math.abs(b - z) < 11) || sq(x, z) > WALL - 7 || (ncafe >= 5 && B.r() < 0.5)) continue;   /* 第115版: 家を へらして 広く */ const h = H(x, z); if (h !== 0) continue; const xx = x + B.ri(-1, 1), ww = B.pick([7, 7, 9]), dd = B.pick([7, 9]), rc = [xx - Math.floor(ww / 2), z - Math.floor(dd / 2), xx - Math.floor(ww / 2) + ww - 1, z - Math.floor(dd / 2) + dd - 1]; if (hitC(rc)) continue; RC.push(rc); const kd = ww === 9 ? ([null, "cafe", "bakery", "flower", "tailor"][ncafe++] || "home") : "home"; const hr = house(B, xx, h, z, ww, dd, kd !== "home" ? 2 : B.pick([1, 2, 2, 3]), B.pick(z < 33 ? ["n", "s"] : ["s", "n"]), sea ? { ...pal, wall: B.pick(["orange_terracotta", "yellow_terracotta", "pink_terracotta", "white_terracotta", "light_blue_terracotta"]), roofs: null, roof: B.pick(["brick_block", "red_terracotta", "orange_terracotta"]) } : pal, kd, kd !== "home" ? { sign: { cafe: "pink_wool", bakery: "orange_wool", flower: "lime_wool", tailor: "purple_wool" }[kd] } : {}); if (kd === "cafe") B.spots.push(["cafe", hr.door[0], h, hr.door[1]]); }
  for (let k = 0; k < 3; k++) { const x = B.pick([-40, -36, -30, 30, 36, 40]) + B.ri(-2, 2), z = B.pick([-6, 2, 8]) + B.ri(-2, 2); const h = H(x, z); if (h === null || Math.hypot(x, z) > WALL - 8 || Math.abs(x) < 16) continue; const ww = B.pick([7, 9]), dd = B.pick([7, 9]), rc = [x - Math.floor(ww / 2), z - Math.floor(dd / 2), x - Math.floor(ww / 2) + ww - 1, z - Math.floor(dd / 2) + dd - 1]; if (hitC(rc)) continue; RC.push(rc); house(B, x, h, z, ww, dd, B.pick([1, 2, 2, 3]), x < 0 ? "e" : "w", pal, "home"); }
  for (const [x, z, c] of [[-5, 36, "red_wool"], [5, 36, "yellow_wool"], [-5, 44, "blue_wool"], [5, 44, "lime_wool"]]) stall(B, x, H(x, z), z, c, pal);   /* 第108版: 東西の 門の 道を ふさがない */
  if (!sea) { if (!hitC([-46, 26, -38, 34])) windmill(B, -42, H(-42, 30), 30, pal); if (!hitC([40, -14, 48, -6])) windmill(B, 44, H(44, -10), -10, pal); }
  for (const [x, z] of [[-6, 22], [6, 22], [-6, 58], [6, 58], [-20, 23], [20, 29], [-20, 37], [20, 43]]) { const h = H(x, z); if (h !== null) lampPost(B, x, h, z, pal); }
  /* 城壁と 門 */
  const gates = [[0, WALL], [-WALL, GZ], [WALL, GZ]];   /* 第108版: 東西の 門は 下段（高さ 0）の 大通りへ（前は 高さ 5 の 崖に ぶつかって いた）*/
  cityWall(B, WALL, 0, pal, sea ? gates.slice(0, 1) : gates, H);
  if (sea) for (const gx of [-WALL, WALL]) { B.fill(gx - 1, GY, GZ - 3, gx + 1, GY + 4, GZ + 3, "air"); B.fill(gx - 1, GY - 1, GZ - 2, gx + 1, GY - 1, GZ + 2, pal.path); }
  /* 湖を こえる 橋（3つの 門から）*/
  const bridge = (ax, az, bx, bz, alongZ, by = 0) => { const fence = pal.lamp === "shroomlight" ? "nether_brick_fence" : "dark_oak_fence";
    if (alongZ) { B.fill(ax - 2, -1, az, ax + 2, -1, bz, pal.floor); B.fill(ax - 3, 0, az, ax - 3, 0, bz, fence); B.fill(ax + 3, 0, az, ax + 3, 0, bz, fence); for (let k = az; k <= bz; k += 5) { B.fill(ax - 2, -8, k, ax - 2, -4, k, pal.stone); B.fill(ax + 2, -8, k, ax + 2, -4, k, pal.stone); B.set(ax - 3, -1, k, pal.lamp === "lantern" ? "lantern" : pal.lamp); B.set(ax + 3, -1, k, pal.lamp === "lantern" ? "lantern" : pal.lamp); } }
    else { B.fill(ax, by - 1, az - 2, bx, by - 1, az + 2, pal.floor); B.fill(ax, by, az - 3, bx, by, az - 3, fence); B.fill(ax, by, az + 3, bx, by, az + 3, fence); for (let k = Math.min(ax, bx); k <= Math.max(ax, bx); k += 5) { B.fill(k, -8, az - 2, k, by - 4, az - 2, pal.stone); B.fill(k, -8, az + 2, k, by - 4, az + 2, pal.stone); B.set(k, by - 1, az - 3, pal.lamp === "lantern" ? "lantern" : pal.lamp); B.set(k, by - 1, az + 3, pal.lamp === "lantern" ? "lantern" : pal.lamp); } } };
  if (!sea) bridge(0, WALL + 1, 0, WALL + 12, true);   /* 第108版: 南の 橋が 向きの まちがいで できて いなかった */
  bridge(-WALL - 1, GZ, -WALL - 12, GZ, false, GY); bridge(WALL + 1, GZ, WALL + 12, GZ, false, GY);
  for (const [x1, z1, x2, z2] of [[-2, WALL - 3, 2, WALL + 1], ...(sea ? [] : [[-WALL - 1, GZ - 2, -WALL + 3, GZ + 2], [WALL - 3, GZ - 2, WALL + 1, GZ + 2]])]) B.fill(x1, -1, z1, x2, -1, z2, pal.path);   /* 門の 中の 坂 */
  for (const [x1, z1, x2, z2] of [[-2, WALL - 1, 2, WALL], ...(sea ? [] : [[-WALL, GZ - 2, -WALL + 1, GZ + 2], [WALL - 1, GZ - 2, WALL, GZ + 2]])]) { B.fill(x1, -1, z1, x2, -1, z2, pal.path); B.fill(x1, 0, z1, x2, 3, z2, "air"); }   /* 第108版: 門の 床も 0 の 高さ */
  /* 北の 崖から 湖へ 流れる 滝 */
  if (!sea) for (const x of [-14, 15]) { const z = -(WALL + 10), h = H(x, z - 2) ?? 8; B.fill(x, -4, z, x + 1, h, z - 1, "air"); B.fill(x, h - 1, z - 2, x + 1, h - 1, z - 2, pal.water === "lava" ? "lava" : "water"); }
  /* 港（海の 都）*/
  if (sea) harbor(B, 0, WALL + 4, pal);
  /* まわりの 森・岩・草花 */
  for (let n = 0; n < 120; n++) { const a = B.r() * Math.PI * 2, d = WALL + 7 + B.r() * (R - WALL - 9), x = Math.round(Math.cos(a) * d), z = Math.round(Math.sin(a) * d), h = H(x, z); if (h === null || (sea && z > 20)) continue;
    if (Math.abs(x) < 6 && z > WALL) continue; if (Math.abs(z - GZ) < 5 && Math.abs(x) > WALL) continue;
    if (B.r() < 0.72) bigTree(B, x, h, z, pal, B.r() < 0.4 ? 1 : 0); else if (B.r() < 0.6) rock(B, x, h, z, pal); else flowerAt(B, x, h, z, pal); }
  for (let n = 0; n < 50; n++) { const x = B.ri(-WALL + 6, WALL - 6), z = B.ri(-10, WALL - 6), h = H(x, z); if (h === null || Math.abs(x) < 5 || (h === 5 && Math.abs(x) < 15 && z < 13)) continue; flowerAt(B, x, h, z, pal); }
  for (const [x, z] of [[-34, -20], [34, -20], [-44, 22], [46, 22], [-30, 52], [30, 52]]) { const h = H(x, z); if (h !== null) bigTree(B, x, h, z, pal, 1); }
  /* 歩く 人の 道（広場・大通り・門の 前）*/
  B.walk = [[[0, 5, 8], [-10, 5, 8], [-10, 5, -6], [10, 5, -6], [10, 5, 8]], [[0, 0, 24], [0, 0, 50], [-12, 0, 40], [12, 0, 40], [0, 0, 24]], [[-20, 0, 26], [20, 0, 26], [20, 0, 40], [-20, 0, 40]], [[-3, 5, 12], [-3, 2, 16], [-3, 0, 22], [3, 0, 22], [3, 2, 16], [3, 5, 12]]];
  B.mark = { throne: pc.throne, master: pc.master, gate: { x: 0.5, y: 0, z: WALL + 6.5 }, r: R, y12: 12 };
  return B;
}
/* 港: 桟橋・停泊する 船・灯台・魚市場 */
function harbor(B, x, z, pal) {
  for (let k = -24; k <= 24; k += 12) { B.fill(x + k - 1, -4, z, x + k + 1, -4, z + 16, pal.floor); for (let b = z; b <= z + 16; b += 4) { B.fill(x + k - 1, -9, b, x + k - 1, -4, b, pal.beam); B.fill(x + k + 1, -9, b, x + k + 1, -4, b, pal.beam); } B.set(x + k, -3, z + 16, pal.lamp); }
  ship(B, x - 18, -4, z + 10, pal); ship(B, x + 18, -4, z + 12, pal);
  lighthouse(B, x + 34, -6, z + 6);
  for (const [a, c] of [[-8, "blue_wool"], [8, "white_wool"]]) stall(B, x + a, -3, z + 1, c, pal);
}
function ship(B, x, y, z, pal) {
  for (let k = -5; k <= 5; k++) { const w = Math.max(1, 3 - Math.floor(Math.abs(k) / 2)); B.fill(x - w, y - 1, z + k, x + w, y, z + k, "dark_oak_planks"); B.fill(x - w + 1, y, z + k, x + w - 1, y, z + k, "air"); B.fill(x - w + 1, y - 1, z + k, x + w - 1, y - 1, z + k, "spruce_planks"); }
  B.fill(x, y, z - 1, x, y + 9, z - 1, "spruce_log"); B.fill(x - 3, y + 4, z - 1, x + 3, y + 8, z - 1, "white_wool"); B.fill(x, y + 3, z + 3, x, y + 6, z + 3, "spruce_log"); B.fill(x - 2, y + 4, z + 3, x + 2, y + 6, z + 3, "white_wool"); B.set(x, y + 10, z - 1, pal.banner);
}

/* ======================= 町（R=46）======================= */
/* 種類: village（農村: 畑・風車）/ port（港町: 入り江と 桟橋）/ forest（森の 村: 大木）/ mine（石の 町: 崖の 段々）/ desert / snow / volcano / crystal / dark / sky */

/* ======================= 第112版: 町の 作りなおし（型と 道と 区画）=======================
   型（丘・川・水路・城塞・森・オアシス・湖・溶岩・平地）ごとに 地形・道・水を 変え、店や 家は 道ぞいの 区画に 並べる。
   同じ 型でも 町ごとに 広場の 位置・道の 形・並びが ちがう。高さの 変化は 1マスに 0.5 まで（どこでも 歩ける）*/
/* 第112版: 店の 日よけ（しま模様）・通りの 旗飾り・灯台・運河の 岸 */
function awning(B, r, y, col) {
  const [ox, oz] = r.door, ns = oz > r.z2 || oz < r.z1, dz = oz > r.z2 ? 1 : -1, dx = ox > r.x2 ? 1 : -1;
  for (let k = -2; k <= 2; k++) for (let d = 0; d < 2; d++) { const b = (k + 2) % 2 ? "white_wool" : col; if (ns) B.set(ox + k, y + 3, oz + dz * d, b); else B.set(ox + dx * d, y + 3, oz + k, b); }
}
const FLAG = ["red_stained_glass_pane", "yellow_stained_glass_pane", "lime_stained_glass_pane", "light_blue_stained_glass_pane", "orange_stained_glass_pane", "magenta_stained_glass_pane"];
function bunting(B, x1, z1, x2, z2, y, post1, post2) {
  const n = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1)); const o = B.ri(0, 5);
  if (post1) B.fill(x1, y - 5, z1, x1, y, z1, "dark_oak_fence"); if (post2) B.fill(x2, y - 5, z2, x2, y, z2, "dark_oak_fence");
  for (let i = 1; i < n; i++) { const x = x1 + Math.sign(x2 - x1) * i, z = z1 + Math.sign(z2 - z1) * i, sag = (i === 1 || i === n - 1) ? 0 : 1; B.set(x, y - sag, z, FLAG[(i + o) % FLAG.length]); }
}
function lighthouse(B, x, y, z) {
  roundTower(B, x, y, z, 3, 17, { roof: "oxidized_cut_copper", glass: "glass", banner: "lightning_rod" }, "white_concrete");
  for (let k = 3; k < 13; k += 5) B.fill(x - 3, y + k, z - 3, x + 3, y + k + 1, z + 3, "red_concrete", "replace white_concrete");
  B.set(x, y + 13, z, "sea_lantern"); B.fill(x - 1, y + 12, z - 1, x + 1, y + 12, z + 1, "white_concrete");
}
const TYPES_OF = { village: ["hill", "river", "plain"], farm: ["plain", "river"], garden: ["hill", "lake"], forest: ["grove", "river"], castle: ["fort", "hill"], volcano: ["lava", "fort"], desert: ["oasis", "plain"], crystal: ["hill", "fort"], port: ["canal", "terrace"], dark: ["fort", "river"], snow: ["lake", "hill"], sky: ["hill", "lake"] };
export function townType(style, seed) { const L = TYPES_OF[style] || TYPES_OF.village; return L[seed % L.length]; }
export function townPlan2(t, seed) {
  const style = t.style || "village", pal = palOf(style), B = new Blue(seed), R = 44, IN = 38, s = seed % 997;
  const type = townType(style, Math.floor(seed / 7)), sea = style === "port";
  /* 広場の 中心（少し ずらす）と 道の 形 */
  const px = B.ri(-6, 6), pz = sea ? B.ri(-8, -2) : B.ri(-6, 6), PW = 7;   /* 第115版: はじまりの 町は 広場を 広く */
  const pat = B.ri(0, 3);   /* 0: 十字 1: T 2: 環状 3: S */
  const segs = [];   /* [x1,z1,x2,z2] 道（軸に 平行）*/
  const E = IN - 2;
  if (pat === 0) segs.push([-E, pz, E, pz], [px, -E, px, sea ? 16 : E]);
  else if (pat === 1) { segs.push([-E, pz, E, pz], [px, pz, px, B.r() < 0.5 || sea ? -E : E]); segs.push([-E + 6, pz + (pz > 0 ? -16 : 16), E - 6, pz + (pz > 0 ? -16 : 16)].map((v, i) => (i % 2 ? Math.max(-E + 4, Math.min(sea ? 14 : E - 4, v)) : v))); }
  else if (pat === 2) { const r = 15; segs.push([px - r, pz - r, px + r, pz - r], [px - r, pz + r, px + r, pz + r], [px - r, pz - r, px - r, pz + r], [px + r, pz - r, px + r, pz + r], [-E, pz, px - r, pz], [px + r, pz, E, pz], [px, -E, px, pz - r]); if (!sea) segs.push([px, pz + r, px, E]); }
  else { const z1 = pz - 12, z2 = Math.min(sea ? 14 : E - 4, pz + 12); segs.push([-E, z1, E - 8, z1], [-E + 8, z2, E, z2], [E - 8, z1, E - 8, z2], [-E + 8, z1, -E + 8, z2], [px, z1, px, -E]); }
  /* 裏通り（区画を ふやす）: 横か 縦に 1本、位置は 町ごとに ちがう */
  { const oz = B.pick([-20, 20]), ox = B.pick([-20, 20]);   /* 第112版: 横と 縦の 裏通りを 1本ずつ */
    { const z = pz + oz, w = Math.floor(Math.sqrt(Math.max(0, (IN - 5) ** 2 - z * z))); if (w > 10 && !(sea && z > 14) && !segs.some((g) => g[1] === g[3] && Math.abs(g[1] - z) < 7)) segs.push([-w, z, w, z]); }
    { const x = px + ox, w = Math.floor(Math.sqrt(Math.max(0, (IN - 5) ** 2 - x * x))); if (w > 10 && !segs.some((g) => g[0] === g[2] && Math.abs(g[0] - x) < 7)) segs.push([x, -w, x, sea ? Math.min(w, 14) : w]); } }
  for (const g of segs) for (let i = 0; i < 4; i++) g[i] = Math.max(-E, Math.min(E, g[i]));
  const RW = 2;   /* 第115版: 道の 半はば（5マスの 道）*/
  const onRoad = (x, z, m = 1) => { m += RW - 1; return segs.some(([a, b, c, d]) => x >= Math.min(a, c) - m && x <= Math.max(a, c) + m && z >= Math.min(b, d) - m && z <= Math.max(b, d) + m); };
  /* 水（川・水路・湖・オアシス・溶岩）*/
  const ang = B.r() * Math.PI, ca = Math.cos(ang), sa = Math.sin(ang), off = B.ri(-8, 8);
  const lq = type === "lava" ? "lava" : "water";
  const lakeC = [B.pick([-1, 1]) * 18, B.pick([-1, 1]) * 18];
  const water = (x, z) => {
    const d = Math.hypot(x, z); if (d > IN - 1) return false;
    if (Math.abs(x - px) <= PW + 1 && Math.abs(z - pz) <= PW + 1) return false;
    if (type === "river" || type === "lava") return Math.abs((x * sa - z * ca) - off) <= 2;
    if (type === "canal") return Math.abs(x - px - 14) <= 2 && z > pz - 24 && z < 23;
    if (type === "lake") return Math.hypot(x - lakeC[0], z - lakeC[1]) <= 7;
    if (type === "oasis") return Math.hypot(x - px, z - pz - 16) <= 5;
    return false;
  };
  /* 高さ（傾きは 0.5 まで）*/
  const peak = [B.ri(-14, 14), B.ri(-14, 14)];
  const H0 = (x, z) => {
    const n = noise(x + 300, z + 300, s, 9) * 1.2;
    if (sea && z > 17) return Math.hypot(x, z) > 12 ? -1 : 0;
    if (type === "terrace") return Math.round(Math.max(0, Math.min(8, (14 - z) * 0.3)) + n * 0.3);   /* 第112版: 海へ 下りる 坂の 町 */
    if (type === "hill") return Math.round(Math.max(0, 9 - Math.hypot(x - peak[0], z - peak[1]) * 0.42) + n * 0.5);
    if (type === "fort") { const d = Math.hypot(x - px, z - pz); return Math.round(d < 13 ? 5 : Math.max(0, 5 - (d - 13) * 0.45)); }
    if (type === "river" || type === "lava") { const d = Math.abs((x * sa - z * ca) - off); return Math.round(Math.min(4, Math.max(0, (d - 4) * 0.35)) + n * 0.4); }
    return Math.round(n * 0.45);   /* 第112版: 平らな 町の 中は ほぼ 平ら（作る 量を へらす）*/
  };
  const Hn = (x, z) => { const d = Math.hypot(x, z); if (d > R) return null; if (d > IN) { const o = -1 + noise(x + 300, z + 300, s, 8) * 4.2; const k = Math.min(1, (d - IN) / 7); return Math.round(H0(x, z) * (1 - k) + o * k); } return H0(x, z); };
  const H = (x, z) => blendOut(Hn(x, z), x, z, IN + 1, R);
  terrain(B, R, H, pal, -14);
  /* 水を 掘る（岸は 石）*/
  rowFill(B, IN, (x, z) => water(x, z) && !onRoad(x, z, 0), -3, -2, lq); rowFill(B, IN, (x, z) => water(x, z) && !onRoad(x, z, 0), -1, 8, "air");
  if (sea) { const sw = (x, z) => z >= 21 && Math.hypot(x, z) > 12 && Math.hypot(x, z) <= R && (Math.hypot(x, z) > IN || z > 22); rowFill(B, R, sw, -9, -4, "water"); rowFill(B, R, sw, -3, 6, "air"); if (type === "terrace") beachSand(B, R, (x, z) => z >= 16 && z <= 24 && Math.hypot(x, z) > 11 && Math.hypot(x, z) <= IN, H); }
  /* 第112版: 港町の 中は 石だたみ（運河の 町 = 赤みの 石 ／ 坂の 町 = 砂岩）。海ぞいは 石の 岸壁 */
  if (sea) { pave(B, IN, (x, z) => Math.hypot(x, z) <= IN && !water(x, z) && (type === "terrace" ? z < 16 : true) && !(z >= 21 && (Math.hypot(x, z) > IN || z > 22)), H, () => (type === "terrace" ? "cut_sandstone" : "polished_granite"));   /* 1行 まとめて fill（軽く）*/
    if (type === "canal") for (let x = -IN; x <= IN; x++) { const z = 22; if (Math.hypot(x, z) > IN || water(x, z) || [-24, -12, 0, 12, 24].some((k) => Math.abs(x - k) <= 1)) continue; const h = H(x, z); if (h !== null) { B.set(x, h, z, "stone_brick_wall"); if (x % 6 === 0) B.set(x, h + 1, z, "lantern"); } } }
  const Hr = (x, z) => (water(x, z) ? 0 : H(x, z));   /* 道の 高さ（水の 上は 橋）*/
  /* 道（3マス はば）と 橋 */
  /* 道（3マス はば）と 橋。第112版: 同じ 高さの 区間は まとめて fill（コマンドを へらす）*/
  const RT = new Map();   /* 道の 表面の 高さ（歩く 人の 点に 使う）*/
  for (const [a, b, c, d] of segs) { const n = Math.max(Math.abs(c - a), Math.abs(d - b)); let st = null;
    const flush = () => { if (!st) return; const [x1, z1, x2, z2, h, wet] = st; for (let x = x1 - RW; x <= x2 + RW; x++) for (let z = z1 - RW; z <= z2 + RW; z++) RT.set(x * 1000 + z, h); B.fill(x1 - RW, h - 1, z1 - RW, x2 + RW, h - 1, z2 + RW, wet ? pal.floor : pal.path); B.fill(x1 - RW, h, z1 - RW, x2 + RW, h + 2, z2 + RW, "air");
      if (wet) { if (a === c) { B.fill(x1 - RW - 1, h, z1, x1 - RW - 1, h, z2, "oak_fence"); B.fill(x1 + RW + 1, h, z1, x1 + RW + 1, h, z2, "oak_fence"); } else { B.fill(x1, h, z1 - RW - 1, x2, h, z1 - RW - 1, "oak_fence"); B.fill(x1, h, z1 + RW + 1, x2, h, z1 + RW + 1, "oak_fence"); } B.fill(x1 - RW, h - 3, z1 - RW, x2 + RW, h - 2, z2 + RW, lq); } st = null; };
    for (let i = 0; i <= n; i++) { const x = Math.round(a + (c - a) * i / n), z = Math.round(b + (d - b) * i / n), h = Hr(x, z); if (h === null) { flush(); continue; } const wet = water(x, z);
      if (st && st[4] === h && st[5] === wet) { st[2] = Math.max(st[2], x); st[3] = Math.max(st[3], z); st[0] = Math.min(st[0], x); st[1] = Math.min(st[1], z); } else { flush(); st = [x, z, x, z, h, wet]; } }
    flush(); }
  /* 第113版: 道の 交わる 所を 同じ 高さに（2段の 段差を なくす）*/
  for (let i = 0; i < segs.length; i++) for (let j = i + 1; j < segs.length; j++) { const A = segs[i], C = segs[j]; if ((A[1] === A[3]) === (C[1] === C[3])) continue; const h0 = A[1] === A[3] ? A : C, v0 = A[1] === A[3] ? C : A, x = v0[0], z = h0[1];
    if (x < Math.min(h0[0], h0[2]) || x > Math.max(h0[0], h0[2]) || z < Math.min(v0[1], v0[3]) || z > Math.max(v0[1], v0[3])) continue; const h = Hr(x, z); if (h === null || water(x, z)) continue; B.fill(x - RW, h - 1, z - RW, x + RW, h - 1, z + RW, pal.path); B.fill(x - RW, h, z - RW, x + RW, h + 2, z + RW, "air"); for (let u = -RW; u <= RW; u++) for (let v = -RW; v <= RW; v++) RT.set((x + u) * 1000 + z + v, h); }
  /* 広場（噴水・井戸・像 の どれか）*/
  const ph = Hr(px, pz) ?? 0;
  B.fill(px - PW, ph - 1, pz - PW, px + PW, ph - 1, pz + PW, pal.plaza); B.fill(px - PW, ph, pz - PW, px + PW, ph + 4, pz + PW, "air");
  for (let a = -PW + 1; a < PW; a += 4) for (let b = -PW + 1; b < PW; b += 4) B.set(px + a, ph - 1, pz + b, pal.path2);
  const cen = B.ri(0, 2);
  if (cen === 0) fountain(B, px, ph, pz, pal);
  else if (cen === 1) { B.fill(px - 2, ph, pz - 2, px + 2, ph, pz + 2, pal.stone, "outline"); B.fill(px - 1, ph - 3, pz - 1, px + 1, ph - 1, pz + 1, "water"); for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) B.fill(px + a, ph + 1, pz + b, px + a, ph + 2, pz + b, "oak_fence"); B.fill(px - 2, ph + 3, pz - 2, px + 2, ph + 3, pz + 2, pal.roof2); }
  else { B.fill(px - 1, ph, pz - 1, px + 1, ph + 1, pz + 1, pal.stone); B.fill(px, ph + 2, pz, px, ph + 4, pz, pal.trim); B.set(px, ph + 5, pz, pal.lamp); for (const [a, b] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) B.set(px + a, ph, pz + b, B.pick(["flower_pot", "azalea"])); }
  for (const [a, b] of [[-PW, -PW], [PW, -PW], [-PW, PW], [PW, PW]]) lampPost(B, px + a, ph, pz + b, pal);
  for (const [a, b, ax] of [[-PW + 1, -3, 0], [PW - 1, 1, 0], [-3, PW - 1, 1], [1, -PW + 1, 1]]) bench(B, px + a, ph, pz + b, ax, px, pz);
  /* 区画（道の 両がわ。扉は 道へ）*/
  const RECT = [], GAP = 3, OCC = (x1, z1, x2, z2, g = 1) => RECT.some((q) => x1 - g <= q[2] && x2 + g >= q[0] && z1 - g <= q[3] && z2 + g >= q[1]);   /* 第115版: 建物どうしは GAP だけ はなす（ごちゃごちゃ しない）*/
  const lotOk = (x1, z1, x2, z2) => { if (OCC(x1, z1, x2, z2, GAP)) return false; for (const [x, z] of [[x1, z1], [x2, z1], [x1, z2], [x2, z2]]) if (Math.hypot(x, z) > IN - 1) return false; for (let x = x1; x <= x2; x++) for (let z = z1; z <= z2; z++) { if (onRoad(x, z, 1) || water(x, z) || water(x - 1, z) || water(x + 1, z) || (Math.abs(x - px) <= PW + 1 && Math.abs(z - pz) <= PW + 1)) return false; if (sea && z > 17) return false; } return true; };
  const cands = [];
  for (const [a, b, c, d] of segs) { const horiz = b === d, n = Math.max(Math.abs(c - a), Math.abs(d - b)); for (let i = 0; i <= n; i += 1) { const x = Math.round(a + (c - a) * i / n), z = Math.round(b + (d - b) * i / n); for (const sd of [-1, 1]) for (const o of [0, 1]) cands.push({ x, z, horiz, sd, o, dist: Math.hypot(x - px, z - pz) + B.r() * 6 + o * 3 }); } }
  cands.sort((u, v) => u.dist - v.dist);
  const N = (job, pos, name, kind) => B.npc.push({ job, pos, name, kind });
  /* 第112版: 港町の 家は 1けんずつ 色が ちがう（運河の 町 = 色とりどりの 壁と 赤い 屋根 ／ 坂の 町 = 白い 壁と 青い 屋根）*/
  const WARM = ["orange_terracotta", "yellow_terracotta", "pink_terracotta", "white_terracotta", "light_gray_terracotta"];
  const tint = () => !sea ? pal : type === "terrace" ? { ...pal, wall: B.pick(["white_concrete", "white_concrete", "calcite", "smooth_quartz"]), beam: "white_concrete", roofs: null, roof: B.pick(["light_blue_terracotta", "cyan_terracotta", "blue_terracotta"]), glass: "blue_stained_glass_pane" }
    : { ...pal, wall: B.pick(WARM), beam: B.pick(["smooth_sandstone", "white_concrete", "stripped_birch_log"]), roofs: null, roof: B.pick(["brick_block", "red_terracotta", "orange_terracotta", "brick_block"]), glass: "glass_pane" };
  const place = (w, d, floors, kind, opt) => {
    for (const c of cands) {
      const dep = c.horiz ? d : w, half = Math.floor(dep / 2) + 2 + RW + (c.o || 0);   /* 道の 中心から 建物の 中心まで */
      const cx = c.horiz ? c.x : c.x + c.sd * half, cz = c.horiz ? c.z + c.sd * half : c.z;
      const face = c.horiz ? (c.sd > 0 ? "n" : "s") : (c.sd > 0 ? "w" : "e");
      const x1 = cx - Math.floor(w / 2), z1 = cz - Math.floor(d / 2), x2 = x1 + w - 1, z2 = z1 + d - 1;
      if (!lotOk(x1, z1, x2, z2)) continue;
      const out = face === "s" ? [cx, z2 + 1] : face === "n" ? [cx, z1 - 1] : face === "e" ? [x2 + 1, cz] : [x1 - 1, cz];
      const h = Hr(out[0], out[1]); if (h === null) continue;
      B.fill(x1 - 1, h - 6, z1 - 1, x2 + 1, h - 2, z2 + 1, pal.base, "keep");   /* 土台（坂でも 浮かない）*/
      B.fill(x1 - 1, h, z1 - 1, x2 + 1, h + 8, z2 + 1, "air");
      const r = house(B, cx, h, cz, w, d, floors, face, tint(), kind, opt || {});
      B.fill(out[0], h - 1, out[1], out[0], h - 1, out[1], pal.path);   /* 戸口の 前 */
      RECT.push([x1, z1, x2, z2]); return { r, h };
    }
    /* 道ぞいに 空きが ない ときは 空き地に 建てて、戸口から 道まで 小道を 引く */
    for (let r0 = 8; r0 < IN; r0 += 2) for (let k = 0; k < 28; k++) {
      const a = (k / 28) * Math.PI * 2 + r0 * 0.7, cx = Math.round(px + Math.cos(a) * r0), cz = Math.round(pz + Math.sin(a) * r0);
      const x1 = cx - Math.floor(w / 2), z1 = cz - Math.floor(d / 2), x2 = x1 + w - 1, z2 = z1 + d - 1;
      if (!lotOk(x1, z1, x2, z2)) continue;
      /* いちばん 近い 道の 方へ 扉 */
      let best = null;
      for (const [face, ox, oz, dx, dz] of [["s", cx, z2 + 1, 0, 1], ["n", cx, z1 - 1, 0, -1], ["e", x2 + 1, cz, 1, 0], ["w", x1 - 1, cz, -1, 0]]) {
        for (let n = 0; n < 14; n++) { const x = ox + dx * n, z = oz + dz * n; if (OCC(x, z, x, z) || water(x, z) || Math.hypot(x, z) > IN) break; if (onRoad(x, z, 0) || (Math.abs(x - px) <= PW && Math.abs(z - pz) <= PW)) { if (!best || n < best.n) best = { face, ox, oz, dx, dz, n }; break; } }
      }
      if (!best) continue;
      const h = Hr(best.ox, best.oz); if (h === null) continue;
      B.fill(x1 - 1, h - 6, z1 - 1, x2 + 1, h - 2, z2 + 1, pal.base, "keep"); B.fill(x1 - 1, h, z1 - 1, x2 + 1, h + 8, z2 + 1, "air");
      const r = house(B, cx, h, cz, w, d, floors, best.face, tint(), kind, opt || {});
      for (let n = 0; n < best.n; n++) { const x = best.ox + best.dx * n, z = best.oz + best.dz * n, hh = Hr(x, z) ?? h; B.set(x, hh - 1, z, pal.path); B.fill(x, hh, z, x, hh + 2, z, "air"); }
      RECT.push([x1, z1, x2, z2]); for (let n = 0; n < best.n; n++) RECT.push([best.ox + best.dx * n, best.oz + best.dz * n, best.ox + best.dx * n, best.oz + best.dz * n]);
      return { r, h };
    }
    return null;
  };
  /* 店（大事な 順）*/
  const shops = [[20, "酒場の マスター", 13, 9, 2, "tavern"], [2, "宿屋", 11, 9, 2, "home"], [3, "道具屋", 9, 9, 2, "shop"], [4, "タマゴ屋", 9, 9, 1, "shop"], [0, "武器屋", 9, 9, 2, "forge"], [1, "防具屋", 9, 9, 1, "forge"], [5, "闘技場", 9, 9, 1, "shop"], [6, "預かり屋", 9, 9, 1, "shop"], [7, "案内人", 9, 9, 1, "shop"], [11, "モンスター屋", 9, 9, 2, "shop"], [12, "図書館", 9, 9, 2, "books"]];
  const misses = [];
  for (const [job, nm, w, d, fl, kd] of shops) {
    const q = place(w, d, fl, kd, { sign: B.pick(["red_wool", "yellow_wool", "blue_wool", "lime_wool", "orange_wool"]) });
    if (!q) { misses.push([job, nm]); continue; }
    N(job, { x: q.r.inside[0] + 0.5, y: q.h, z: q.r.inside[1] + 0.5 }, `§e${nm}`, job === 20 ? "tavern" : null);
    if (job !== 2) awning(B, q.r, q.h, B.pick(["red_wool", "lime_wool", "orange_wool", "light_blue_wool", "yellow_wool"]));
    if (job === 2) B.spots.push(["inn", q.r.door[0], q.h, q.r.door[1], q.r.inside[0], q.r.inside[1]]); else if (BSK[job]) B.spots.push([BSK[job], q.r.door[0], q.h, q.r.door[1], q.r.inside[0], q.r.inside[1]]);   /* 第125版(pl): 物語の 場面で 使う 店の 戸口（5・6番目は 中の 点）*/
  }
  for (const kd of ["cafe", "kitchen"]) { const q = place(9, 9, 2, kd, { sign: kd === "cafe" ? "pink_wool" : "lime_wool" }); if (q) { awning(B, q.r, q.h, kd === "cafe" ? "pink_wool" : "green_wool"); B.spots.push([kd === "cafe" ? "cafe" : "diner", q.r.door[0], q.h, q.r.door[1]]); } }
  if (sea) beachHouse(B, px - 14 < -20 ? px + 14 : px - 14, 17, pal);
  /* 置けなかった 店は 広場の まわりの 屋台 */
  /* 屋台を 置ける 空き地（道・水・建物・広場を さける）*/
  const freeSpot = () => { for (let r = PW + 4; r < IN - 3; r += 2) for (let k = 0; k < 24; k++) { const a = (k / 24) * Math.PI * 2 + r, x = Math.round(px + Math.cos(a) * r), z = Math.round(pz + Math.sin(a) * r); if (Math.hypot(x, z) > IN - 3 || (sea && z > 13)) continue; let okk = true; for (let u = -3; u <= 3 && okk; u++) for (let v = -3; v <= 3; v++) { if (onRoad(x + u, z + v, 0) || water(x + u, z + v) || OCC(x + u, z + v, x + u, z + v) || (Math.abs(x + u - px) <= PW && Math.abs(z + v - pz) <= PW)) { okk = false; break; } } if (!okk) continue; const h = Hr(x, z); if (h === null) continue; let flat = true; for (const [u, v] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) if (Math.abs((Hr(x + u, z + v) ?? h) - h) > 1) flat = false; if (!flat) continue; RECT.push([x - 3, z - 3, x + 3, z + 3]); return { x, z, h }; } return null; };
  let plz = 0; const stallNpc = (job, nm, col, role) => { const q = freeSpot(); const add = (pos) => { N(job, pos, `§e${nm}`); if (role) B.npc[B.npc.length - 1].role = role; }; if (!q) { const P = [[-PW + 1, -PW + 1], [PW - 1, PW - 1], [PW - 1, -PW + 1], [-PW + 1, PW - 1], [-PW + 1, -PW + 3], [PW - 1, PW - 3], [PW - 3, -PW + 1], [-PW + 3, PW - 1]][plz++ % 8]; add({ x: px + P[0] + 0.5, y: ph, z: pz + P[1] + 0.5 }); return; } stall(B, q.x, q.h, q.z - 1, col, pal); add({ x: q.x + 0.5, y: Hr(q.x, q.z + 1) ?? q.h, z: q.z + 1.5 }); };   /* 第113版: 広場の 予備の 場所は 噴水から はなす */
  misses.forEach(([job, nm]) => stallNpc(job, nm, B.pick(["red_wool", "blue_wool", "yellow_wool"])));
  { const q = place(9, 9, 1, "shop", { sign: "magenta_wool" }); if (q) { awning(B, q.r, q.h, "magenta_wool"); B.npc.push({ job: 3, role: "toy", pos: { x: q.r.inside[0] + 0.5, y: q.h, z: q.r.inside[1] + 0.5 }, name: "§eおもちゃと 名物の 店" }); } else stallNpc(3, "おもちゃと 名物の 店", "magenta_wool", "toy"); }   /* 第113版 */
  const homes = []; for (let k = 0; k < (t.id === "t0" ? 3 : sea ? 8 : 5); k++) { const sz = sea ? 9 : B.pick([7, 9]); const q = place(sz, sz, sea ? B.pick([2, 2, 3]) : sz === 9 ? B.pick([1, 2, 2]) : 1, "home"); if (q) homes.push(q); }   /* 第112版: 港町は 2〜3階の 家が 建ちならぶ */
  homes.slice(0, 3).forEach((q, k) => B.spots.push([k ? `home${k + 1}` : "home", q.r.door[0], q.h, q.r.door[1], q.r.inside[0], q.r.inside[1]]));   /* 第125版(pl): 物語の 家の 場面 */
  for (const [job, nm, k] of [[13, "物知り", 0], [14, "釣り屋", 1]]) { const hm = homes[k]; if (hm) N(job, { x: hm.r.inside[0] + 0.5, y: hm.h, z: hm.r.inside[1] + 0.5 }, `§e${nm}`); else stallNpc(job, nm, "light_blue_wool"); }
  /* 屋台通り（広場から のびる 道ぞい）・街灯・花壇・荷車 */
  for (const [a, b, c, d] of segs) { const n = Math.max(Math.abs(c - a), Math.abs(d - b)), horiz = b === d; for (let i = 4; i < n; i += 11) { const x = Math.round(a + (c - a) * i / n), z = Math.round(b + (d - b) * i / n);
    for (const sd of [-1, 1]) { const lx = horiz ? x : x + sd * (RW + 2), lz = horiz ? z + sd * (RW + 2) : z; if (OCC(lx, lz, lx, lz) || onRoad(lx, lz, 1) || water(lx, lz) || Math.hypot(lx, lz) > IN - 2 || (sea && lz > 15)) continue; const h = Hr(lx, lz); if (h === null) continue;
      const r = B.r(); if (Math.hypot(lx - px, lz - pz) < 20 && r < 0.2 && !OCC(lx - 2, lz - 2, lx + 2, lz + 2) && ![[-2, -2], [2, 2], [-2, 2], [2, -2]].some(([u, v]) => onRoad(lx + u, lz + v, 0))) { stall(B, lx, h, lz, B.pick(["red_wool", "yellow_wool", "blue_wool", "lime_wool", "orange_wool", "pink_wool"]), pal); RECT.push([lx - 2, lz - 2, lx + 2, lz + 2]); }
      else if (r < 0.7) lampPost(B, lx, h, lz, pal); else if (r < 0.85) { B.set(lx, h - 1, lz, "grass_block"); B.set(lx, h, lz, B.pick(pal.flower)); } else { B.set(lx, h, lz, "barrel"); B.set(lx, h + 1, lz, B.pick(["hay_block", "pumpkin", "melon", "barrel"])); } } } }
  /* 第112版: 通りの 上に 旗飾り（建物の 壁か 柱に かける）*/
  for (const [a, b, c, d] of segs) { const n = Math.max(Math.abs(c - a), Math.abs(d - b)), horiz = b === d; for (let i = 6; i < n - 2; i += 18) { const x = Math.round(a + (c - a) * i / n), z = Math.round(b + (d - b) * i / n), h = Hr(x, z); if (h === null || Math.hypot(x - px, z - pz) < PW + 2) continue;
    const e1 = horiz ? [x, z - RW - 2] : [x - RW - 2, z], e2 = horiz ? [x, z + RW + 2] : [x + RW + 2, z]; const bad = (q) => Math.hypot(q[0], q[1]) > IN - 2 || water(q[0], q[1]) || onRoad(q[0], q[1], 1);
    if (bad(e1) || bad(e2)) continue; bunting(B, e1[0], e1[1], e2[0], e2[1], h + 5, !OCC(e1[0], e1[1], e1[0], e1[1]), !OCC(e2[0], e2[1], e2[0], e2[1])); } }
  /* 第112版: 運河と 川の 岸を 石で 固めて 手すり・街灯（橋は 石の 手すりに）*/
  if (type === "canal" || type === "river") { let k = 0; for (let x = -IN; x <= IN; x++) for (let z = -IN; z <= IN; z++) { if (water(x, z) || onRoad(x, z, 0) || OCC(x, z, x, z) || Math.hypot(x, z) > IN - 1) continue; if (!(water(x + 1, z) || water(x - 1, z) || water(x, z + 1) || water(x, z - 1))) continue; const h = H(x, z); if (h === null) continue;
    B.fill(x, -3, z, x, h - 1, z, "stone_bricks"); if (onRoad(x, z, 1)) continue; B.set(x, h, z, "stone_brick_wall"); if (k++ % 7 === 0) B.set(x, h + 1, z, "lantern"); }
    for (const [a, b, c, d] of segs) { const n = Math.max(Math.abs(c - a), Math.abs(d - b)); for (let i = 0; i <= n; i++) { const x = Math.round(a + (c - a) * i / n), z = Math.round(b + (d - b) * i / n); if (!water(x, z)) continue; for (const [u, v] of (a === c ? [[-RW - 1, 0], [RW + 1, 0]] : [[0, -RW - 1], [0, RW + 1]])) if (!OCC(x + u, z + v, x + u, z + v) && !onRoad(x + u, z + v, 1)) B.set(x + u, 0, z + v, "stone_brick_wall"); B.fill(x - RW, -1, z - RW, x + RW, -1, z + RW, "stone_bricks"); } }
    if (type === "canal") for (let z = pz - 18; z < 18; z += 13) if (water(px + 14, z) && !onRoad(px + 14, z, 1)) { B.set(px + 14, -2, z, "trapdoor"); B.set(px + 13, -2, z, "barrel"); } }   /* 小舟の かわりに 浮き台（建てなおしで ふえない）*/
  /* 型ごとの 名物 */
  if (type === "hill") { const h = Hr(peak[0], peak[1]); if (h !== null && !OCC(peak[0] - 4, peak[1] - 4, peak[0] + 4, peak[1] + 4) && !onRoad(peak[0], peak[1], 4)) { roundTower(B, peak[0], h, peak[1], 3, 12, pal, pal.stone); RECT.push([peak[0] - 4, peak[1] - 4, peak[0] + 4, peak[1] + 4]); } }
  if (type === "river") { const wx = Math.round(off * sa) + 0, wz = Math.round(-off * ca); if (!OCC(wx + 1, wz - 4, wx + 9, wz + 4) && !onRoad(wx + 5, wz, 4) && !water(wx + 5, wz)) { windmill(B, wx + 5, Hr(wx + 5, wz) ?? 0, wz, pal); RECT.push([wx + 1, wz - 4, wx + 9, wz + 4]); } }
  if (type === "oasis") for (const [a, b] of [[-6, 16], [6, 16], [0, 22]]) { const x = px + a, z = pz + b; if (!OCC(x, z, x, z) && Math.hypot(x, z) < IN - 2) bigTree(B, x, Hr(x, z) ?? 0, z, pal); }
  if (sea) harbor(B, 0, 22, pal); if (sea) { const hh = Hr(0, 18) ?? 0; B.spots.push(["harbor", 0, hh, 18]); }   /* 第112版: 物語の 場面で 使う 港の 場所 */
  if (style === "village" || style === "farm") for (let k = 0; k < 3; k++) { const x0 = B.pick([-28, 18]), z0 = B.pick([-28, 18]); if (OCC(x0, z0, x0 + 9, z0 + 6) || onRoad(x0 + 4, z0 + 3, 4)) continue; const h = Hr(x0, z0) ?? 0; B.fill(x0, h - 1, z0, x0 + 9, h - 1, z0 + 6, "farmland"); B.fill(x0, h, z0, x0 + 9, h, z0 + 6, B.pick(["wheat", "carrots", "potatoes"])); B.fill(x0, h - 1, z0 + 3, x0 + 9, h - 1, z0 + 3, "water"); RECT.push([x0, z0, x0 + 9, z0 + 6]); }
  /* 塀と 門（道の 出口は あける）*/
  for (let a = 0; a < 360; a += 2) { const r = IN + 1, x = Math.round(Math.cos(a * Math.PI / 180) * r), z = Math.round(Math.sin(a * Math.PI / 180) * r); if (onRoad(x, z, 2) || (sea && z > 16) || OCC(x, z, x, z) || water(x, z)) continue; const h = H(x, z); if (h === null) continue; B.fill(x, h, z, x, h + 1, z, pal.cw); if (a % 30 === 0) { B.fill(x, h, z, x, h + 3, z, pal.cw); B.set(x, h + 4, z, pal.lamp); } }
  for (let n = 0; n < 60; n++) { const a = B.r() * Math.PI * 2, d = IN + 3 + B.r() * (R - IN - 4), x = Math.round(Math.cos(a) * d), z = Math.round(Math.sin(a) * d), h = H(x, z); if (h === null || h < -2 || onRoad(x, z, 3) || (sea && z > 8)) continue; if (B.r() < 0.7) bigTree(B, x, h, z, pal, B.r() < 0.4 ? 1 : 0); else rock(B, x, h, z, pal); }
  for (let n = 0; n < 40; n++) { const x = B.ri(-IN + 3, IN - 3), z = B.ri(-IN + 3, IN - 3), h = Hr(x, z); if (h === null || onRoad(x, z, 1) || water(x, z) || OCC(x, z, x, z) || (sea && z > 15) || Math.hypot(x, z) > IN - 2 || (Math.abs(x - px) <= PW && Math.abs(z - pz) <= PW)) continue; flowerAt(B, x, h, z, pal); }
  /* 歩く 道（道の 線を そのまま）*/
  B.walk = segs.map(([a, b, c, d]) => { const n = Math.max(1, Math.floor(Math.max(Math.abs(c - a), Math.abs(d - b)) / 4)), L = []; for (let i = 0; i <= n; i++) { const x = Math.round(a + (c - a) * i / n), z = Math.round(b + (d - b) * i / n); L.push([x, RT.get(x * 1000 + z) ?? Hr(x, z) ?? 0, z]); } return L.filter(([x, , z]) => !(Math.abs(x - px) <= PW && Math.abs(z - pz) <= PW)); }).filter((L) => L.length > 1).map((L) => L.concat(L.slice(0, -1).reverse()));   /* 第113版: 広場の 中（噴水・井戸）の 点は のぞく */
  B.walk.push([[px - PW + 1, ph, pz - PW + 1], [px + PW - 1, ph, pz - PW + 1], [px + PW - 1, ph, pz + PW - 1], [px - PW + 1, ph, pz + PW - 1]]);
  B.spots.push(["plaza", px + 4, ph, pz + 6]);
  B.mark = { r: R, type, plaza: [px, ph, pz] };
  return B;
}

export function townPlan(t, seed) {
  const style = t.style || "village", pal = palOf(style), B = new Blue(seed), R = 44, IN = 34, s = seed % 997;
  const sea = style === "port", hilly = ["castle", "volcano", "crystal", "dark", "snow", "sky"].includes(style);
  /* 高さ: 町の 中は 2段（東が +3 の 段）。まわりは 丘と 崖で 下がる */
  const H = (x, z) => blendOut(Ht(x, z), x, z, IN + 1, R);
  const Ht = (x, z) => { const d = Math.hypot(x, z), n = noise(x + 300, z + 300, s, 8) * 3;
    if (d > R) return null;
    if (sea && z > 14 && d > 10) return d > IN ? -4 : -1;
    const inn = hilly ? Math.max(0, Math.min(4, x - 5)) : 0;   /* 第108版: 東の 段は 1マスずつ 上がる（前は 2マス 段差が あった）*/
    if (d > IN) { const t2 = (d - IN) / (R - IN), k = Math.min(1, (d - IN) / 7); return Math.round(inn * (1 - k) + (-1 + (hilly ? 4 - t2 * 8 : 1 - t2 * 4) + n * 1.4) * k); }   /* 町の ふちで 急に 3〜5マス 上がる 崖を なくした */
    return inn; };
  terrain(B, R, H, pal, -14);
  if (sea) { const sw = (x, z) => z >= 14 && Math.hypot(x, z) > 12 && Math.hypot(x, z) <= R && (Math.hypot(x, z) > IN || z > 22); rowFill(B, R, sw, -9, -3, "water"); rowFill(B, R, sw, -2, 6, "air"); } if (sea) beachSand(B, R, (x, z) => z >= 12 && z <= 22 && Math.abs(x) > 3 && Math.hypot(x, z) > 11 && Math.hypot(x, z) <= IN, H);
  /* 広場と 十字の 道 */
  B.fill(-9, -1, -9, 9, -1, 9, pal.plaza); for (let a = -8; a <= 8; a += 4) for (let b = -8; b <= 8; b += 4) B.set(a, -1, b, pal.path2);
  road(B, 0, -IN, 0, IN, 1, H, pal); road(B, -IN, 0, IN, 0, 1, H, pal);
  if (hilly) for (let z = -2; z <= 2; z++) for (let x = 5; x <= 8; x++) B.fill(x, H(x, z) - 1, z, x, H(x, z) - 1, z, pal.stone);
  fountain(B, 0, 0, 0, pal);
  for (const [a, b, ax] of [[-7, -6, 0], [-7, 3, 0], [-6, 7, 1], [-6, -7, 1]]) bench(B, a, H(a, b) ?? 0, b, ax, 0, 0);   /* 第109版: 広場の ベンチ */
  for (const [a, b] of [[-8, -8], [8, -8], [-8, 8], [8, 8]]) lampPost(B, a, H(a, b), b, pal);
  const N = (job, pos, name, kind) => B.npc.push({ job, pos, name, kind });
  const RECT = [];
  const shops = [[0, "武器屋", 14, -13, "w"], [1, "防具屋", 25, -13, "w"], [3, "道具屋", -14, -13, "e"], [4, "タマゴ屋", -25, -13, "e"], [2, "宿屋", 14, 14, "n"], [5, "闘技場", 25, 13, "n"], [6, "預かり屋", -14, 14, "n"], [7, "案内人", -25, 13, "n"], [11, "モンスター屋", -13, -26, "s"], [12, "図書館", 13, -26, "s"], [20, "酒場の マスター", 0, -28, "s"]];
  for (const [job, nm, x, z, f] of shops) { if (sea && z > 10) continue; const h = H(x, z); const tavern = job === 20; const outer = Math.abs(x) === 25 || z === -26; const r = house(B, x, h, z, tavern ? 15 : outer && (f === "w" || f === "e") ? 9 : 11, tavern ? 11 : outer && (f === "n" || f === "s") ? 9 : 11, tavern || job === 2 ? 2 : B.pick([1, 2]), f, pal, tavern ? "tavern" : job <= 1 ? "forge" : job === 12 ? "books" : "shop", { sign: B.pick(["red_wool", "yellow_wool", "blue_wool", "lime_wool", "orange_wool"]) });
    N(job, { x: r.inside[0] + 0.5, y: h, z: r.inside[1] + 0.5 }, `§e${nm}`, tavern ? "tavern" : null); RECT.push([r.x1, r.z1, r.x2, r.z2]); if (job === 2) B.spots.push(["inn", r.door[0], h, r.door[1], r.inside[0], r.inside[1]]); else if (BSK[job]) B.spots.push([BSK[job], r.door[0], h, r.door[1], r.inside[0], r.inside[1]]); }
  if (sea) { const ri = house(B, 15, 0, -2, 9, 7, 2, "w", pal, "home"); RECT.push([ri.x1, ri.z1, ri.x2, ri.z2]); N(2, { x: ri.inside[0] + 0.5, y: 0, z: ri.inside[1] + 0.5 }, "§e宿屋"); B.spots.push(["inn", ri.door[0], 0, ri.door[1]]); }
  /* 民家（重ならない ように）。物知り・釣り屋は 民家の 中に 住む（第106版: 外の 広場に 立って いた） */
  const homes = [], hit = (a, b) => RECT.some((q) => a[0] - 2 <= q[2] && a[2] + 2 >= q[0] && a[1] - 2 <= q[3] && a[3] + 2 >= q[1]);
  if (t.id === "t0") RECT.push([-28, -29, -16, -14]);   /* 第115版: あなたの 家と その 前の 庭を あけて おく */
  /* 第109版: 南の 通りに カフェと 食堂（港町は 海なので 北の 通りぞいに 小さく）*/
  if (sea) beachHouse(B, -18, 15, pal);   /* 第111版: 港町は 砂浜の 海の家（カフェ）*/
  for (const [x, kd] of [[-10, "cafe"], [10, "kitchen"]]) { const z = sea ? -36 : 26; if (sea) continue; const h = H(x, z); if (h === null) continue; const r = house(B, x, h, z, 9, 9, 2, "n", pal, kd, { sign: kd === "cafe" ? "pink_wool" : "lime_wool" }); RECT.push([r.x1, r.z1, r.x2, r.z2]); B.spots.push([kd === "cafe" ? "cafe" : "diner", r.door[0], h, r.door[1]]); }
  for (let k = 0; k < 24 && homes.length < 7; k++) { const x = B.pick([-34, -30, 30, 34, -22, 22]) + B.ri(-1, 1), z = B.pick([-34, -24, 24, 34, -2, 4]) + B.ri(-1, 1); if (sea && z > 10) continue; const h = H(x, z); if (h === null || Math.hypot(x, z) > IN - 4) continue;
    if (hit([x - 5, z - 5, x + 5, z + 5])) continue;
    const kd = "home";
    const r = house(B, x, h, z, 9, 9, kd === "home" ? B.pick([1, 1, 2]) : 2, x < 0 ? "e" : "w", pal, kd, kd === "home" ? {} : { sign: kd === "cafe" ? "pink_wool" : "lime_wool" }); RECT.push([r.x1, r.z1, r.x2, r.z2]); homes.push([r, h]); B.spots.push([homes.length > 1 ? `home${homes.length}` : "home", r.door[0], h, r.door[1], r.inside[0], r.inside[1]]); }
  for (const [job, nm, k, fx, fz] of [[13, "物知り", 0, 5.5, -6.5], [14, "釣り屋", 1, sea ? 0.5 : -5.5, sea ? 20.5 : 6.5]]) {
    const hm = homes[k]; if (hm) N(job, { x: hm[0].inside[0] + 0.5, y: hm[1], z: hm[0].inside[1] + 0.5 }, `§e${nm}`); else { stall(B, Math.floor(fx), sea && job === 14 ? -1 : 0, Math.floor(fz) - 1, "light_blue_wool", pal); N(job, { x: fx, y: sea && job === 14 ? -1 : 0, z: fz }, `§e${nm}`); } }
  /* 名物 */
  if (sea) { harbor(B, 0, 18, pal); }
  else if (style === "village" || style === "farm" || style === "garden") { windmill(B, -32, H(-32, 30), 30, pal); for (let k = 0; k < 3; k++) { const z0 = 20 + k * 4; B.fill(14, -1, z0, 30, -1, z0 + 2, "farmland"); B.fill(14, 0, z0, 30, 0, z0 + 2, B.pick(["wheat", "carrots", "potatoes"])); B.fill(14, -1, z0 + 3, 30, -1, z0 + 3, "water"); } }
  else if (style === "forest") { for (const [x, z] of [[24, 24], [-24, 26], [30, -2]]) { bigTree(B, x, H(x, z), z, pal, 0); bigTree(B, x + 3, H(x, z), z + 3, pal, 1); } }
  else if (style === "desert") { B.fill(18, -2, 18, 30, -1, 30, "water"); B.fill(17, -1, 17, 31, -1, 31, pal.stone, "outline"); for (const [x, z] of [[17, 17], [31, 31], [17, 31]]) bigTree(B, x, 0, z, pal); }
  else roundTower(B, 26, H(26, 26), 26, 4, 16, pal, pal.stone);
  for (const [x, z, c] of [[-5, 15, "red_wool"], [5, 15, "yellow_wool"], [-15, 5, "blue_wool"]]) if (!(sea && z > 10)) stall(B, x, H(x, z), z, c, pal);
  { const x = 15, z = 5; stall(B, x, H(x, z), z - 1, "magenta_wool", pal); B.npc.push({ job: 3, role: "toy", pos: { x: x + 0.5, y: H(x, z + 1) ?? 0, z: z + 1.5 }, name: "§eおもちゃと 名物の 店" }); }   /* 第113版: おもちゃと 名物の 店 */
  /* 低い 外壁と 4つの 門・まわりの 森 */
  for (let a = 0; a < 360; a += 2) { const r = IN + 1, x = Math.round(Math.cos(a * Math.PI / 180) * r), z = Math.round(Math.sin(a * Math.PI / 180) * r); if (Math.abs(x) < 3 || Math.abs(z) < 3 || (sea && z > 12)) continue; if (RECT.some((q) => x >= q[0] - 1 && x <= q[2] + 1 && z >= q[1] - 1 && z <= q[3] + 1)) continue;   /* 第109版: 建物の 中を 塀が 通らない */
    const h = H(x, z); if (h === null) continue; B.fill(x, h, z, x, h + 1, z, pal.cw); if (a % 30 === 0) { B.fill(x, h, z, x, h + 3, z, pal.cw); B.set(x, h + 4, z, pal.lamp); } }
  for (let n = 0; n < 70; n++) { const a = B.r() * Math.PI * 2, d = IN + 3 + B.r() * (R - IN - 4), x = Math.round(Math.cos(a) * d), z = Math.round(Math.sin(a) * d), h = H(x, z); if (h === null || h < -2 || Math.abs(x) < 4 || Math.abs(z) < 4) continue; if (B.r() < 0.7) bigTree(B, x, h, z, pal, B.r() < 0.4 ? 1 : 0); else if (B.r() < 0.5) rock(B, x, h, z, pal); else flowerAt(B, x, h, z, pal); }
  for (let n = 0; n < 30; n++) { const x = B.ri(-IN + 4, IN - 4), z = B.ri(-IN + 4, IN - 4), h = H(x, z); if (h === null || Math.abs(x) < 3 || Math.abs(z) < 3 || Math.hypot(x, z) < 11 || (sea && z > 10)) continue; flowerAt(B, x, h, z, pal); }
  B.spots.push(["plaza", 4, 0, 6]);   /* 第115版: 物語の 場面で 使う */
  B.walk = [[[0, 0, 10], [10, 0, 10], [10, 0, -10], [-10, 0, -10], [-10, 0, 10]], [[0, 0, -12], [0, 0, -34], [0, 0, -12]], [[-12, 0, 0], [-34, 0, 0], [-12, 0, 0]], hilly ? [[12, 4, 0], [30, 4, 0], [12, 4, 0]] : [[12, 0, 0], [34, 0, 0], [12, 0, 0]]];
  B.mark = { r: R };
  return B;
}
/* 第126版: 廃都（ruincity.js）でも 使う 部品 */
export const __parts = { terrain, rowFill, blendOut, noise };
