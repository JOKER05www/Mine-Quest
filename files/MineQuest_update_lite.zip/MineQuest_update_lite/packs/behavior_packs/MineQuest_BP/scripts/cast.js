// 第125版: 物語の 登場人物（名前・役割・語尾・見た目）。地方の 話（ep_r*.js）の 場面で 使い、話の あとは 町に 立って「その後」を 話す
// ・見た目は 今 ある 町の 人・外の 人の スキン（skinjobs.js の PSKIN の キー か、職業の 番号）から えらぶ。新しい モデルは 作らない
// ・登録: castAdd("mimi", { nm: "ミミ", role: "パン屋の 娘", gobi: "だよっ", skin: "mimi", town: "t0", at: () => ({ x, z }), from: "r0e2", pre: [...], after: [[(s) => 条件, ["せりふ", ...]], ...] })
//     nm 名前 ／ role 役割（名札の 前に つく）／ gobi 語尾（点検で 数える）／ col 名前の 色（§e）／ town 住む 町の id
//     at 立つ 場所（{x,z} を 返す 関数。y は 地面を さがす）／ from この 話（ep の id）を 終えた 人には 町に 見える
//     after 話しかけた 人の 進みで かわる「その後」（上から 順に 見て 最初に 合う もの）／ pre まだ 話の 前の 人への ひとこと
// ・軽く: 5秒ごとに 近く（40マス）の 人だけ 見る。1人 1体。場面の そば（24マス）・遠く（96マス）では 消す
import { world, system } from "@minecraft/server";
import { ok, busy, choose, ICON, setJob, sound } from "./ui.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { PSKIN } from "./skinjobs.js";
import { groundY } from "./structures.js";
import { NPC_HOOKS } from "./npchook.js";
import { stageOf, inCam } from "./stagecore.js";

export const CAST = {};
export const CAST_HOOK = { done: null };   /* (d, ep の id) => 済んだか（sagaep.js が 入れる）*/
export function castAdd(id, o) { CAST[id] = { id, col: "§e", ...o }; return CAST[id]; }
export const castTag = (id) => { const c = CAST[id]; return c ? `${c.col}${c.role ? `${c.role} ` : ""}${c.nm}` : String(id); };
export const castJob = (id) => { const c = CAST[id]; if (!c) return 8; if (typeof c.skin === "number") return c.skin; return PSKIN[c.skin] ? PSKIN[c.skin][0] : 8; };
/* 第125版:「世界が 滅びかける」時期（第10章で 旅の 仲間が 亡くなった あと、終章を 越える 前）。after に [(s) => doomed(s), ["…"]] と 書く（ending より 下・heroDead より 上に 置く）
   doomKnown は 第11章の「空の 声」の あと（町の 人が 影を 知って しまった あと）。この 時期は collapse.js が 空・町・店を かえる */
export const doomed = (s) => !!(s && s.heroDead && !s.ending);
export const doomKnown = (s) => doomed(s) && !!(s.epx && s.epx.voice);
const OW = () => world.getDimension("minecraft:overworld");
const LIVE = new Map();
const POS = new Map();
const rm = (e) => { if (ok(e)) try { e.remove(); } catch {} };
function posOf(c) {
  const v = POS.get(c.id); if (v && Date.now() - v.t < 60000) return v.q;
  let q = null; try { const a = c.at && c.at(); if (a && Number.isFinite(a.x) && Number.isFinite(a.z)) { const y0 = Number.isFinite(a.y) ? a.y : 70; const y = groundY(OW(), Math.floor(a.x), Math.floor(a.z), y0 + 12); q = typeof y === "number" ? { x: Math.floor(a.x) + 0.5, y, z: Math.floor(a.z) + 0.5 } : null; } } catch {}
  POS.set(c.id, { q, t: Date.now() }); return q;
}
const hideFor = (c, d) => { try { return !!c.hide(qs(d), d); } catch { return false; } };
const doneFor = (d, id) => { try { return !id || !!(CAST_HOOK.done && CAST_HOOK.done(d, id)); } catch { return false; } };
function tick() {
  let P = []; try { P = world.getAllPlayers().filter((p) => p.dimension.id === "minecraft:overworld"); } catch { return; }
  for (const c of Object.values(CAST)) {
    if (!c.town || !c.at) continue;
    let e = LIVE.get(c.id); if (e && !ok(e)) { LIVE.delete(c.id); e = null; }
    const q = posOf(c); if (!q) continue;
    let far = true, want = false, scene = false, seen = false;
    for (const p of P) {
      const dd = Math.hypot(p.location.x - q.x, p.location.z - q.z); if (dd < 96) far = false;
      if (dd < 24 && globalThis.__mqScene?.has(p.id)) { scene = true; try { if (e && ok(e) && inCam(p, e.location, stageOf(p)?.C)) seen = true; } catch {} }   /* 第124版(fix2): 映って いる 間は 消さない（あとで 映らなく なってから）*/
      if (dd < 40 && !want) { const d = load(p); if (d && doneFor(d, c.from) && (!c.end || qs(d).ending) && !(c.until && doneFor(d, c.until)) && !(c.hide && hideFor(c, d))) want = true; }   /* 第125版: until（次の 場所へ 移った）・hide（石に なって いる など）*/   /* 第124版: クリア後だけの 人は、近くの クリアした 人にだけ */
    }
    if (far || scene || !want) { if (e && !seen) { rm(e); LIVE.delete(c.id); } continue; }
    if (e) continue;
    try { e = OW().spawnEntity("mrpg:npc", q); setJob(e, castJob(c.id)); e.addTag("mrpg_npc"); e.addTag("mrpg_cast"); e.setDynamicProperty("mrpg:cast", c.id); e.nameTag = castTag(c.id); LIVE.set(c.id, e); } catch {}
  }
}
system.runInterval(tick, 100);
function sweep() { try { const own = new Set([...LIVE.values()].filter(ok).map((e) => e.id)); for (const e of OW().getEntities({ type: "mrpg:npc", tags: ["mrpg_cast"] })) if (!own.has(e.id)) rm(e); } catch {} }
system.runInterval(sweep, 1200); system.runTimeout(sweep, 60);
/* 話しかける: その人の 進みで かわる「その後」*/
export function castLines(p, id) {
  const c = CAST[id]; if (!c) return [];
  const d = load(p); if (!d) return [];
  if (!doneFor(d, c.from)) return [].concat(c.pre || ["……"]);
  const s = qs(d);
  for (const [f, L] of c.after || []) { try { if (f(s, d)) return [].concat(L); } catch {} }
  return [].concat(c.pre || ["……"]);
}
async function castTalk(p, e, id) {
  const c = CAST[id]; if (!c || busy.has(p.id)) return;
  busy.add(p.id);
  try {
    try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); e.setProperty("mrpg:act", 4); } catch {}
    sound(p, "random.pop", 0.6);
    const L = castLines(p, id).map((l) => `${c.col}${c.nm}§f「${String(l).replace(/^\{[^}]*\}/, "")}」`);
    await choose(p, castTag(id).replace(/§./g, ""), L.join("\n\n"), [["§lOK", ICON("i_back")]]);
  } finally { busy.delete(p.id); try { if (ok(e)) e.setProperty("mrpg:act", 0); } catch {} }
}
NPC_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_cast")) return false;
  let id = null; try { id = e.getDynamicProperty("mrpg:cast"); } catch {}
  if (typeof id !== "string" || !CAST[id]) { rm(e); return true; }
  system.run(() => { castTalk(p, e, id).catch(() => {}); });
  return true;
});
export const __cast = { LIVE, tick, sweep, castTalk };
