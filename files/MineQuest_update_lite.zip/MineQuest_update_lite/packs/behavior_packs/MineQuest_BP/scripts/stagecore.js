// 第123版: 物語の 場面の「舞台」
// ・場面ごとに 平らで 開けた 場所（9×9・木や 屋根の 下では ない）を さがし、プレイヤーを 立ち位置へ 移す
// ・役者は 舞台の 決まった 立ち位置（話す 人は 正面の 弧・旅の 仲間は となり・敵は 向こう側）に 立つ。重ならない・葉や 柵の 上に 立たない
// ・まわりの 町の 人や 動物は 場面の あいだ 見えなく して、終わったら もどす（ぬけても 次に 読みこんだ とき もどる）
// ・カメラの 見通し（壁・屋台・木に さえぎられないか）を 調べる 道具
import { world, system } from "@minecraft/server";

const PASS = /^minecraft:(air|cave_air|short_grass|tallgrass|tall_grass|fern|large_fern|deadbush|snow_layer|torch|soul_torch|vine|glow_lichen|red_flower|yellow_flower|poppy|dandelion|cornflower|oxeye_daisy|azure_bluet|allium|blue_orchid|lily_of_the_valley|pink_petals|wildflowers|rail|redstone_wire|light_block|structure_void|seagrass)$|_carpet$|^minecraft:carpet$|_tulip$|_sapling$|_button$|_pressure_plate$/;
const BADG = /leaves|_log$|^minecraft:log2?$|_wood$|_stem$|hyphae|fence|_wall$|cobblestone_wall|pane|iron_bars|cactus|campfire|magma|water|lava|_bed$|^minecraft:bed$|_door$|trapdoor|scaffolding|_sign$|banner|chest|barrel|lectern|anvil|cauldron|brewing_stand|bell$|lantern|_slab$|hopper/;
const VIEW = /glass|pane$|iron_bars|chain$/;
export const passB = (b) => !b || b.isAir || (!b.isLiquid && PASS.test(b.typeId));
export const groundB = (b) => !!b && !b.isAir && !b.isLiquid && !PASS.test(b.typeId) && !BADG.test(b.typeId);
const viewB = (b) => b !== undefined && (passB(b) || VIEW.test(b.typeId));
/* ブロックを 読む（同じ 場面では 覚えておく）。読みこまれて いない 所は undefined */
export function blk(dim, x, y, z, C) {
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  const k = `${x},${y},${z}`; if (C && C.has(k)) return C.get(k);
  let b; try { b = dim.getBlock({ x, y, z }) || null; } catch { b = undefined; }
  if (C) C.set(k, b); return b;
}
/* (x,z) で 立てる 高さ（足の ブロック）。y0 に いちばん 近い 所。葉・丸太・柵・水の 上は だめ */
export function standY(dim, x, z, y0, C) {
  y0 = Math.floor(y0);
  for (const d of [0, 1, -1, 2, -2, 3, -3, -4]) {
    const y = y0 + d, g = blk(dim, x, y - 1, z, C); if (g === undefined) continue;
    if (groundB(g) && passB(blk(dim, x, y, z, C)) && passB(blk(dim, x, y + 1, z, C))) return y;
  }
  return null;
}
/* 頭の 上（2〜3マス上）に 葉・屋根が ある */
export function overhead(dim, x, y, z, C) { for (const k of [2, 3]) { const b = blk(dim, x, y + k, z, C); if (b && !passB(b)) return true; } return false; }
/* a から b が 見えるか（b の 手前 skip マスは 見ない）*/
export function los(dim, a, b, C, skip = 0.45) {
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz); if (!(L > 0.01)) return true;
  const Lc = Math.min(L, 20), n = Math.ceil(Lc / 0.12);   /* 第124版(fix2): 手前 20m だけ 調べる（遠くを 見る 絵で 重く ならない）*/
  for (let i = 0; i <= n; i++) { const t = (i / n) * (Lc / L); if (L * (1 - t) < skip) break; if (!viewB(blk(dim, a.x + dx * t, a.y + dy * t, a.z + dz * t, C))) return false; }
  return true;
}
const polar = (r, D) => D.map((d) => [r * Math.cos((d * Math.PI) / 180), r * Math.sin((d * Math.PI) / 180)]);
/* 立ち位置（前へ, 右へ）。プレイヤーは (0,0) で 前を 向く */
export const SLOTS = {
  hero: [[0.4, -1.6], [0.4, 1.6], [-0.7, -1.8], [-0.7, 1.8], [1.4, -2.4], [1.4, 2.4]],
  ally: [...polar(3.5, [0, -32, 32, -62, 62]), ...polar(4.8, [-16, 16, -44, 44])],
  foe: [...polar(5.4, [0, -26, 26, -50, 50]), ...polar(6.8, [-13, 13])],
};
const EVAL = [[0, 0], SLOTS.hero[0], SLOTS.hero[1], SLOTS.ally[0], SLOTS.ally[1], SLOTS.ally[2], SLOTS.foe[0], SLOTS.foe[1], SLOTS.foe[2], [2.4, 0], [1.2, -0.6], [1.2, 0.6]];
const DIRS = [...Array(8).keys()].map((i) => ({ x: -Math.sin((i * Math.PI) / 4), z: Math.cos((i * Math.PI) / 4), yaw: i * 45 }));
const yawOf = (f) => (Math.atan2(-f.x, f.z) * 180) / Math.PI;
const toW = (P, f, a, b, dy = 0) => ({ x: P.x + f.x * a - f.z * b, y: P.y + dy, z: P.z + f.z * a + f.x * b });
/* 舞台の 良さ（P に 立って f を 向く）*/
function frameScore(dim, P, f, C) {
  let good = 0, must = 0;
  for (let i = 0; i < EVAL.length; i++) {
    const q = toW(P, f, EVAL[i][0], EVAL[i][1]), y = standY(dim, q.x, q.z, P.y, C);
    const okp = y !== null && Math.abs(y - P.y) <= 1 && !overhead(dim, q.x, y, q.z, C) && goodStand(dim, q.x, y, q.z, C);
    if (okp) good += Math.abs(y - P.y) < 0.5 ? 1 : 0.3; else if (i === 0 || i === 3) must++;   /* 第124版(cam): 平らな ほど よい・階段や 噴水の ふちは だめ */
  }
  if (must) return null;
  let cam = 0; for (const s of [1, -1]) { const q = toW(P, f, -2.0, 0.9 * s); if (passB(blk(dim, q.x, P.y + 1, q.z, C)) && passB(blk(dim, q.x, P.y + 2, q.z, C))) cam++; }
  const eye = { x: P.x, y: P.y + 1.6, z: P.z }, h = toW(P, f, 3.5, 0, 1.6), h2 = toW(P, f, 5.4, 0, 1.6);
  const see = (los(dim, eye, h, C) ? 1 : 0) + (los(dim, eye, h2, C) ? 1 : 0);
  return { good, cam, see, perfect: good === EVAL.length && cam > 0 && see === 2, v: good * 10 + cam * 4 + see * 8 };
}
/* 開けた 平らな 場所を さがす（anchor の まわり R マス）。ジェネレーター: 何マスか 調べるごとに 一息つく */
function* search(dim, A, prefYaw, R, C, away = null) {
  const ay = Math.floor(A.y), offs = [];
  for (let dx = -R; dx <= R; dx++) for (let dz = -R; dz <= R; dz++) { const d = Math.hypot(dx, dz); if (d > R) continue; const st = d <= 12 ? 2 : 3; if (dx % st || dz % st) continue; offs.push([dx, dz, d]); }
  offs.sort((a, b) => a[2] - b[2]);
  const dirs = DIRS.map((D) => ({ D, o: Math.abs((((D.yaw - prefYaw) % 360) + 540) % 360 - 180) })).sort((a, b) => a.o - b.o);
  let best = null, n = 0;
  for (const [dx, dz, d] of offs) {
    const x = Math.floor(A.x) + dx, z = Math.floor(A.z) + dz, y = standY(dim, x, z, ay, C) ?? standY(dim, x, z, ay - 6, C) ?? standY(dim, x, z, ay + 6, C);   /* 第124版: 階段の とちゅうからでも 下（上）の 広間を さがす */
    if (y === null || Math.abs(y - ay) > 9) { if (++n % 10 === 0) yield best; continue; }
    const P = { x: x + 0.5, y, z: z + 0.5 };
    for (const { D, o } of dirs) {
      if (away && away(toW(P, D, 2.5, 0))) continue;   /* 第124版: ほかの 人の 舞台の すぐ そば は さける（マルチ）*/
      const s = frameScore(dim, P, D, C); if (!s) continue;
      const v = s.v - d * 0.7 - o / 45 * 2 - Math.max(0, Math.abs(y - ay) - 1) * 3;   /* 同じ 高さを 先に */
      if (!best || v > best.v) best = { P, f: { x: D.x, z: D.z }, v, perfect: s.perfect };
      if (s.perfect) break;
    }
    if (best && best.perfect) return best;
    if (++n % 10 === 0) yield best;
  }
  return best;
}
const run = (g) => { let r; do r = g.next(); while (!r.done); return r.value; };
export const findStage = (dim, A, prefYaw = 0, R = 24, C = new Map()) => run(search(dim, A, prefYaw, R, C));

/* ---------- 舞台 ---------- */
const ST = new Map();   /* プレイヤーの id → 舞台 */
const HID = (globalThis.__mqHid = globalThis.__mqHid || new Set());   /* かくした 人の id（町歩きが 止まる）*/
const ZONE = (globalThis.__mqStageZ = globalThis.__mqStageZ || new Map());   /* 舞台の 円（町歩きが 入って こない）*/
const HOOK = { on() {}, off() {}, idle: () => 1e9, shot() {}, paused: () => false, view: () => null, put: () => false };
export function setStageHooks(h) { Object.assign(HOOK, h); }
const ok = (e) => { try { return !!e && (typeof e.isValid === "function" ? e.isValid() : e.isValid !== false); } catch { return false; } };
const wait = (t) => new Promise((r) => system.runTimeout(r, t));
export const stageOf = (p) => { try { const S = ST.get(p.id); return S && S.on ? S : null; } catch { return null; } };
export const inStage = (p) => !!stageOf(p);
const SKIP_TAG = ["mrpg_saga", "mrpg_cine", "mrpg_temp", "mrpg_preview", "mrpg_autospk", "mrpg_stghid", "mrpg_actor"];
const SKIP_TYPE = /^minecraft:(player|item|xp_orb|arrow|thrown_trident|fireball|small_fireball|painting|leash_knot|armor_stand|minecart|boat|chest_boat|chest_minecart|falling_block|tnt|lightning_bolt|area_effect_cloud|fishing_hook|ender_crystal)$|^mrpg:(popup|ball|tent)$/;
const R_HIDE = 14;
/* ほかの 人の 仲間・だれかが 乗って いる もの（マルチで ほかの 人が 動けなく ならない）*/
const foreign = (S, e) => { try { if (e.hasTag("mrpg_pet") && e.getDynamicProperty("mrpg:owner") !== S.pid) return true; if (e.hasTag("mrpg_busyw")) return true;
    for (const k of ["mrpg:pown", "mrpg:hown", "mrpg:bown", "mrpg:lost", "mrpg:xowner", "mrpg:towner", "mrpg:dmown"]) { const o = e.getDynamicProperty(k); if (typeof o === "string" && o !== S.pid) return true; }   /* 第124版: ほかの 人の 遊び場の 相棒・旅の 仲間（その 人の 遊びを 止めない・消さない）*/ return !!e.getComponent("minecraft:rideable")?.getRiders()?.length; } catch { return false; } };
function hideOne(S, e) {
  try {
    if (e.addEffect) e.addEffect("invisibility", 20 * 1200, { showParticles: false });
    const nm = String(e.nameTag || ""); e.setDynamicProperty("mrpg:stgnm", nm); e.setDynamicProperty("mrpg:stgown", S.pid);
    e.nameTag = ""; e.addTag("mrpg_stghid"); HID.add(e.id); S.hid.push(e);
  } catch {}
}
export function unhide(e) {
  try { HID.delete(e.id); } catch {}   /* 消えた ものの 印も のこさない */
  if (!ok(e)) return;
  try { e.removeEffect("invisibility"); } catch {}
  try { const nm = e.getDynamicProperty("mrpg:stgnm"); if (typeof nm === "string") e.nameTag = nm; e.setDynamicProperty("mrpg:stgnm", undefined); e.setDynamicProperty("mrpg:stgown", undefined); e.removeTag("mrpg_stghid"); } catch {}
  try { HID.delete(e.id); } catch {}
}
/* 第124版: 舞台を 終える とき、ほかの 人の 舞台の 範囲に いる かくした 人は その 舞台が 引きつぐ（もう 一人の 場面に わかない）*/
function release(S) {
  for (const e of S.hid) {
    let T = null; try { if (ok(e)) { const l = e.location; for (const X of ST.values()) if (X !== S && X.on && X.Cn && X.dim?.id === e.dimension.id && Math.hypot(l.x - X.Cn.x, l.z - X.Cn.z) <= R_HIDE + 2) { T = X; break; } } } catch {}
    if (T) { try { e.setDynamicProperty("mrpg:stgown", T.pid); T.hid.push(e); continue; } catch {} }
    unhide(e);
  }
  S.hid.length = 0;
}
/* 第124版: マルチ: 場面に 入って いない ほかの 人の 足もと（3マス 以内の ものは 隠さない・止めない。その 人が 話して いる 人・戦って いる 敵）*/
function otherPs(S) { const L = []; try { for (const q of S.dim.getPlayers()) if (q.id !== S.pid && !ST.get(q.id)?.on) L.push(q.location); } catch {} return L; }
const byOther = (O, l) => O.some((q) => Math.hypot(q.x - l.x, q.z - l.z) < 3 && Math.abs(q.y - l.y) < 3);
function hideAround(S) {
  const c = S.Cn; let L = []; try { L = S.dim.getEntities({ location: { x: c.x, y: c.y, z: c.z }, maxDistance: R_HIDE + 2 }); } catch {}
  const O = otherPs(S);
  let mount = null; try { mount = S.p.getComponent("minecraft:riding")?.entityRidingOn?.id; } catch {}
  for (const e of L) {
    try {
      if (!ok(e) || SKIP_TYPE.test(e.typeId) || e.id === mount || S.ents.includes(e)) continue;
      if (SKIP_TAG.some((t) => e.hasTag(t)) && !e.hasTag("mrpg_field") && !e.hasTag("mrpg_tlev")) continue;   /* 第127版: 野の 人・その モンスター・町の 事件の ものも かくす */
      if (e.hasTag("mrpg_battle") || foreign(S, e) || e.getEffect?.("invisibility")) continue;   /* 戦いの 子・もともと 透明な ものは さわらない */
      const l = e.location; if (Math.hypot(l.x - c.x, l.z - c.z) > R_HIDE || Math.abs(l.y - c.y) > 10 || byOther(O, l)) continue;
      hideOne(S, e);
    } catch {}
  }
  ZONE.set(S.pid, { x: c.x, z: c.z, r: R_HIDE + 2 });
}
const head = (e, dy = 1.6) => { try { const l = e.location; return { x: l.x, y: l.y + dy, z: l.z }; } catch { return null; } };
/* ---------- 第124版: ムービーの あいだ まわりの 生きものを その場で 止める（役者は のぞく）----------
   足を 止める（移動の 遅さ 255）＋ 4tick ごとに 0.3 マス 以上 動いた ものだけ 元の 場所へ もどす（軽い）*/
const FRZ = (globalThis.__mqFrz = globalThis.__mqFrz || new Set());   /* 止めた もの の id（町歩き・野の 人が 動かない）*/
const R_FRZ = 40, FRZ_MAX = 90;
const ACT_TAG = ["mrpg_actor", "mrpg_saga", "mrpg_autospk", "mrpg_preview"];
function freezeOne(S, e) {
  try {
    let r = null; try { r = e.getRotation(); } catch {}
    let had = false; try { had = !!e.getEffect("slowness"); } catch {}
    if (!had) try { e.addEffect("slowness", 20 * 1200, { amplifier: 255, showParticles: false }); } catch {}
    e.addTag("mrpg_frz"); e.setDynamicProperty("mrpg:frzown", S.pid); if (!had) e.setDynamicProperty("mrpg:frzslow", true);
    FRZ.add(e.id); S.frz.push({ e, at: { ...e.location }, r, dim: e.dimension });
  } catch {}
}
export function unfreeze(e) {
  try { FRZ.delete(e.id); } catch {}
  if (!ok(e)) return;
  try { if (e.getDynamicProperty("mrpg:frzslow")) e.removeEffect("slowness"); } catch {}
  try { e.setDynamicProperty("mrpg:frzslow", undefined); e.setDynamicProperty("mrpg:frzown", undefined); e.removeTag("mrpg_frz"); } catch {}
  try { FRZ.delete(e.id); } catch {}
  for (const S of ST.values()) if (S.frz) S.frz = S.frz.filter((x) => x.e !== e);
}
function freezeAround(S) {
  const c = S.Cn; let L = []; try { L = S.dim.getEntities({ location: { x: c.x, y: c.y, z: c.z }, maxDistance: R_FRZ }); } catch {}
  const O = otherPs(S);
  let mount = null; try { mount = S.p.getComponent("minecraft:riding")?.entityRidingOn?.id; } catch {}
  let n = 0;
  for (const e of L) {
    if (n >= FRZ_MAX) break;
    try {
      if (!ok(e) || SKIP_TYPE.test(e.typeId) || e.id === mount || S.ents.includes(e) || FRZ.has(e.id)) continue;
      if (ACT_TAG.some((t) => e.hasTag(t))) continue;
      if ((e.hasTag("mrpg_cine") || e.hasTag("mrpg_temp")) && !e.hasTag("mrpg_field") && !e.hasTag("mrpg_tlev")) continue;   /* 演出の もの（野の 人は 止める）*/
      if (e.hasTag("mrpg_battle") || foreign(S, e)) continue;
      const l = e.location; if (Math.hypot(l.x - c.x, l.z - c.z) > R_FRZ || byOther(O, l)) continue;
      freezeOne(S, e); n++;
    } catch {}
  }
}
function thaw(S) {   /* 第124版: となりの 舞台の 範囲に いる ものは その 舞台が 止めたまま 引きつぐ */
  const L = S.frz || []; S.frz = [];
  for (const x of L) {
    let T = null; try { if (ok(x.e)) { const l = x.e.location; for (const X of ST.values()) if (X !== S && X.on && X.Cn && X.frz && X.dim?.id === x.e.dimension.id && Math.hypot(l.x - X.Cn.x, l.z - X.Cn.z) <= R_FRZ && !foreign(X, x.e)) { T = X; break; } } } catch {}
    if (T) { try { x.e.setDynamicProperty("mrpg:frzown", T.pid); T.frz.push(x); continue; } catch {} }
    unfreeze(x.e);
  }
}
function freezeTick() {
  for (const S of ST.values()) {
    if (!S.on || !S.frz || !S.frz.length || HOOK.paused(S.p)) continue;
    for (const x of S.frz) {
      const e = x.e; if (!ok(e)) continue;
      try { const l = e.location; if (Math.abs(l.x - x.at.x) + Math.abs(l.z - x.at.z) + Math.abs(l.y - x.at.y) > 0.3) { if (e.hasTag("mrpg_pet") || e.hasTag("mrpg_battle")) { unfreeze(e); continue; } e.teleport(x.at, x.r ? { dimension: x.dim, rotation: x.r } : { dimension: x.dim }); } } catch {}
    }
  }
}
system.runInterval(freezeTick, 4);
/* 舞台を 決める（move: プレイヤーを 立ち位置へ 移して よいか）*/
/* 第124版: マルチ: 舞台の まん中（前へ 2.5）が ほかの 人の 舞台（決まった もの・決めかけの もの）の まん中から 11マス 以内か */
function awayOf(S) {
  const L = []; for (const T of ST.values()) { if (T === S) continue; const Q = T.on ? T.Cn : T.resv; try { if (Q && T.dim.id === S.dim.id) L.push(Q); } catch {} }
  const O = otherPs(S);   /* 場面に 入って いない ほかの 人も 舞台に 入れない（6マス）*/
  return L.length || O.length ? (c) => L.some((Q) => Math.hypot(Q.x - c.x, Q.z - c.z) < 11) || O.some((q) => Math.hypot(q.x - c.x, q.z - c.z) < 6) : null;
}
function frameFor(S, A, move) {
  const p = S.p; let yaw = 0; try { yaw = p.getRotation().y; } catch {}
  if (S.opt.face) { const L = p.location; yaw = yawOf({ x: S.opt.face.x - L.x, z: S.opt.face.z - L.z }); }
  if (!move) {   /* その場で 向きだけ えらぶ */
    const L = p.location, P = { x: L.x, y: Math.floor(L.y + 0.01), z: L.z };
    const dirs = DIRS.map((D) => ({ D, o: Math.abs((((D.yaw - yaw) % 360) + 540) % 360 - 180) })).sort((a, b) => a.o - b.o);
    const aw = awayOf(S);
    let best = null; for (const { D, o } of dirs) { const s = frameScore(S.dim, P, D, S.C); if (!s) continue; const v = s.v - o / 45 * 2 - (aw && aw(toW(P, D, 2.5, 0)) ? 40 : 0); if (!best || v > best.v) best = { P, f: { x: D.x, z: D.z }, v }; }
    return best || { P, f: { x: -Math.sin((yaw * Math.PI) / 180), z: Math.cos((yaw * Math.PI) / 180) } };
  }
  return null;
}
function setFrame(S, P, f) {
  const n = Math.hypot(f.x, f.z) || 1; S.P = { x: P.x, y: P.y, z: P.z }; S.f = { x: f.x / n, z: f.z / n }; S.r = { x: -S.f.z, z: S.f.x };
  S.Cn = S.at(2.5, 0); S.side = 1;
  /* カメラを 置く 側（肩ごしが 通る 方）*/
  const eye = S.at(0, 0, 1.6), h = S.at(3.5, 0, 1.6);
  for (const s of [1, -1]) { const c = S.at(-1.9, 0.85 * s, 1.95); if (los(S.dim, c, h, S.C) && los(S.dim, c, eye, S.C, 0.2)) { S.side = s; break; } }
}
async function activate(S, async) {
  const p = S.p, o = S.opt, L = p.location, A = o.anchor && typeof o.anchor.y === "number" ? o.anchor : o.anchor ? { ...o.anchor, y: L.y } : L;
  const move = o.move !== false;
  let fr = null;
  if (move) {
    let yaw = 0; try { yaw = p.getRotation().y; } catch {}
    if (o.face) yaw = yawOf({ x: o.face.x - A.x, z: o.face.z - A.z });
    const g = search(S.dim, A, yaw, o.R || 24, S.C, awayOf(S)); let r, k = 0;
    do { r = g.next(); if (!r.done && async && ++k % 3 === 0) { await wait(1); if (ST.get(S.pid) !== S) return; } } while (!r.done);
    fr = r.value;
    { const aw = awayOf(S); if (fr && aw && aw(toW(fr.P, fr.f, 2.5, 0))) fr = run(search(S.dim, A, yaw, (o.R || 24) + 10, S.C, aw)) || fr; }   /* 同じ ときに 決めた 人が いた */
    if (fr) S.resv = toW(fr.P, fr.f, 2.5, 0);
  }
  if (!fr) fr = frameFor(S, A, false);
  let near = false;
  const hereOk = (() => { const y = standY(S.dim, L.x, L.z, L.y + 0.01, S.C); return y !== null && Math.abs(y - (L.y + 0.01)) < 0.6 && goodStand(S.dim, L.x, y, L.z, S.C); })();   /* 第124版(cam): 階段・噴水の ふち・段差の 上 */
  if (!move && (fr.v === undefined || !hereOk) && !blk(S.dim, L.x, L.y + 1, L.z, S.C)?.isLiquid) { let y0 = 0; try { y0 = p.getRotation().y; } catch {} const g2 = run(search(S.dim, L, y0, 6, S.C, awayOf(S))); if (g2) { fr = g2; near = true; } }   /* 第127版: その場が 木の 下・屋台の 上など なら 6マス 以内の 開けた 所へ */
  setFrame(S, fr.P, fr.f);
  const far = Math.hypot(L.x - S.P.x, L.z - S.P.z) > 0.7 || Math.abs(L.y - S.P.y) > 1.2;
  if (far && (move || near)) {
    try { p.runCommand("camera @s fade time 0 0.35 0.45 color 0 0 0"); } catch {}
    try { p.teleport({ x: S.P.x, y: S.P.y + 0.02, z: S.P.z }, { dimension: S.dim, facingLocation: S.at(3.5, 0, 1.6) }); } catch {}
    if (async) { await wait(2); if (ST.get(S.pid) !== S) return; }   /* とちゅうで ぬけた */
  } else faceP(S, S.at(3.5, 0, 1.6));
  hideAround(S);
  freezeAround(S);
  S.on = true; S.t1 = Date.now();
  try { if (!p.getEffect("resistance")) { p.addEffect("resistance", 20 * 1200, { amplifier: 255, showParticles: false }); p.setDynamicProperty("mrpg:stgres", true); } } catch {}   /* 第127版: 動けない あいだに 矢・爆発で たおれない */
  HOOK.on(p, S);
  if (async && move && !o.noEst) await wait(28);   /* 第124版: 始めの 引きの 絵を 少し 見せる */
}
/* 場面を 始める。lazy: 最初の 役者が 出た ときに 舞台を 決める（その場で・移動なし）*/
export async function stageBegin(p, opt = {}) {
  if (!ok(p)) return null;   /* 第127版: ぬけた 人の 舞台は 作らない（まわりを かくした まま に しない）*/
  let S = ST.get(p.id);
  if (S) { S.depth++; if (!S.on && !opt.lazy) { S.opt = { ...S.opt, ...opt }; S.lazy = false; await activate(S, true); } return S; }
  S = newStage(p, opt);
  if (!opt.lazy) await activate(S, true);
  return S;
}
function newStage(p, opt) {
  const S = { pid: p.id, p, depth: 1, dim: p.dimension, opt, on: false, ents: [], mem: new Map(), dest: new Map(), hid: [], frz: [], last: null, side: 1, C: new Map(), t0: Date.now(), lazy: !!opt.lazy, auto: !!opt.auto };
  S.at = (a, b, dy = 0) => toW(S.P, S.f, a, b, dy);
  ST.set(p.id, S); return S;
}
/* 役者を 出す 前に 呼ぶ: 舞台が なければ その場に 作る（移動なし）*/
export function stageNow(p) {
  if (!ok(p)) return null;
  let S = ST.get(p.id);
  if (!S) S = newStage(p, { lazy: true, move: false, auto: true });
  if (!S.on) { S.opt = { ...S.opt, move: false }; activate(S, false); }
  return S;
}
export function stageEnd(p, all = false) {
  const S = ST.get(p.id); if (!S) return;
  if (!all && --S.depth > 0) return;
  ST.delete(p.id); closeStage(S);
}
function closeStage(S) {
  release(S); thaw(S);
  ZONE.delete(S.pid);
  noRes(S.p);
  if (S.on) { S.on = false; try { HOOK.off(S.p, S); } catch {} }
}
export function noRes(p) { try { if (ok(p) && p.getDynamicProperty("mrpg:stgres")) { p.removeEffect("resistance"); p.setDynamicProperty("mrpg:stgres", undefined); } } catch {} }
/* 舞台を 別の 場所へ 移す（場面の とちゅうで 城などへ 行く）*/
export async function stageMove(p, anchor, opt = {}) {
  const S = ST.get(p.id); if (!S) return null;
  release(S); ZONE.delete(S.pid); thaw(S);
  S.C = new Map(); S.mem.clear(); S.dest.clear(); S.ents = S.ents.filter(ok); S.last = null;
  S.opt = { ...S.opt, ...opt, anchor, move: true }; S.dim = p.dimension;
  S.on = false; await activate(S, true);
  return S;
}
/* ---------- 立ち位置 ---------- */
const distXZ = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
function others(S, self) {
  const L = [];
  try { L.push(S.p.location); } catch {}
  for (const e of S.ents) if (ok(e) && e !== self) try { L.push(e.location); const d = S.dest.get(e.id); if (d) L.push(d); } catch {}
  return L;
}
function crowd(S, q) {
  const L = []; let E = [];
  try { E = S.dim.getEntities({ location: q, maxDistance: 3 }); } catch {}
  for (const e of E) { try { if (!ok(e) || (SKIP_TYPE.test(e.typeId) && !(e.typeId === "minecraft:player" && e.id !== S.pid)) || HID.has(e.id)) continue;   /* 第124版: ほかの 人（プレイヤー）の 上にも 立たせない */ const l = e.location; if (distXZ(l, q) < 3 && Math.abs(l.y - q.y) < 3) L.push({ id: e.id, l }); } catch {} }
  return L;
}
export function freeAt(S, q, self, min = 1.5) {
  for (const l of others(S, self)) if (distXZ(l, q) < min && Math.abs(l.y - q.y) < 2.5) return false;
  for (const o of crowd(S, q)) if ((!self || o.id !== self.id) && distXZ(o.l, q) < min) return false;
  for (const r of S.res || []) if (r !== q && distXZ(r, q) < min) return false;
  return true;
}
const okSpot = (S, q, y0, lim = 1.5) => { const y = standY(S.dim, q.x, q.z, y0, S.C); return y !== null && Math.abs(y - y0) <= lim ? y : null; };
/* 第124版(cam): 役者が 立つ 所: 階段の 上・噴水や 池の ふちは だめ（歩いて 通るのは よい）*/
export function goodStand(dim, x, y, z, C) {
  const g = blk(dim, x, y - 1, z, C); if (!g || /stairs/.test(g.typeId)) return false;
  for (const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = blk(dim, x + a, y - 1, z + b, C), m = blk(dim, x + a, y, z + b, C); if ((n && n.isLiquid) || (m && m.isLiquid)) return false; }
  return true;
}
const okStand = (S, q, y0, lim = 0.5) => { const y = okSpot(S, q, y0, lim); return y !== null && goodStand(S.dim, q.x, y, q.z, S.C) ? y : null; };
/* q の 近くで 立てて 空いて いる 所 */
export function freeNear(S, q, self, min = 1.5, maxR = 2.8) {
  if (!S || !q) return q;
  const y0 = typeof q.y === "number" ? q.y : S.P.y;
  for (const r of [0, 0.7, 1.4, 2.1, 2.8]) {
    if (r > maxR) break;
    for (let i = 0; i < (r ? 8 : 1); i++) {
      const a = (i * Math.PI) / 4, c = { x: q.x + Math.cos(a) * r, y: y0, z: q.z + Math.sin(a) * r }, y = okStand(S, c, y0);   /* 第124版(cam): 平らな 所（高さ ±0.5）を 先に */
      if (y === null) continue; c.y = y;
      if (freeAt(S, c, self, min)) return c;
    }
  }
  for (const r of [0, 0.7, 1.4, 2.1, 2.8]) {
    if (r > maxR) break;
    for (let i = 0; i < (r ? 8 : 1); i++) {
      const a = (i * Math.PI) / 4, c = { x: q.x + Math.cos(a) * r, y: y0, z: q.z + Math.sin(a) * r }, y = okSpot(S, c, y0);
      if (y === null) continue; c.y = y;
      if (freeAt(S, c, self, min)) return c;
    }
  }
  return null;
}
/* プレイヤーから 見て ほかの 人の 真後ろ・真ん前（顔が かくれる）*/
function hidden(S, q, self) {
  const P = S.P, aq = Math.atan2(q.z - P.z, q.x - P.x);
  for (const e of S.ents) { if (!ok(e) || e === self) continue; const d = S.dest.get(e.id) || e.location; let x = Math.abs(Math.atan2(d.z - P.z, d.x - P.x) - aq); if (x > Math.PI) x = 2 * Math.PI - x; if (x < 0.24) return true; }
  return false;
}
/* 役の 立ち位置 */
export function slotOf(S, role, name, self) {
  const L = SLOTS[role] || SLOTS.ally, eye = S.at(0, 0, 1.6);
  const m = name && S.mem.get(name);
  if (m && freeAt(S, m, self)) return { ...m };
  for (const pass of [0, 1]) {
    for (const [a, b] of L) {
      const q = S.at(a, b), y = okStand(S, q, S.P.y, 0.5); if (y === null) continue; q.y = y;   /* 第124版(cam): 立ち位置は 舞台と 同じ 高さ（±0.5）・階段や 噴水の ふちは だめ */
      if (!pass && overhead(S.dim, q.x, y, q.z, S.C)) continue;
      if (role !== "hero" && !los(S.dim, eye, { x: q.x, y: y + 1.5, z: q.z }, S.C)) continue;
      if (!freeAt(S, q, self)) continue;
      if (!pass && hidden(S, q, self)) continue;
      return q;
    }
  }
  return freeNear(S, S.at(role === "foe" ? 5 : 3.2, 0), self, 1.5, 2.8) || freeNear(S, S.at(2.5, 0), self, 1.2, 2.8) || S.at(3, 0);
}
/* その 役者が いる 舞台 */
export function stageFor(e) { if (!e) return null; for (const S of ST.values()) if (S.on && S.ents.includes(e)) return S; return null; }
export function addActor(S, e, name, q) {
  if (!S || !e) return;
  S.ents = S.ents.filter(ok); if (!S.ents.includes(e)) S.ents.push(e);
  if (FRZ.has(e.id)) unfreeze(e);
  try { e.addTag("mrpg_actor"); } catch {}
  try { if (e.typeId === "mrpg:npc") e.triggerEvent("mrpg:still"); else if (e.typeId === "mrpg:monster" && !e.hasTag("mrpg_pet") && !e.hasTag("mrpg_battle")) e.triggerEvent("mrpg:make_battle"); } catch {}   /* 第127版: 演出の モンスターが 歩き回らない・消えない */
  if (name && q) S.mem.set(name, { x: q.x, y: q.y, z: q.z });
  if (q) S.dest.set(e.id, { x: q.x, y: q.y, z: q.z });
}
/* 役者の 行き先を 覚える（歩いて いる とちゅうでも ほかの 人が その 場所に 立たない）*/
export function setDest(e, q) { const S = stageFor(e); if (S && q) S.dest.set(e.id, { x: q.x, y: q.y, z: q.z }); }
/* 歩きはじめる 所（立ち位置から 外へ 5マス・道が ふさがって いれば 近く）*/
const segD = (a, b, c) => { const vx = b.x - a.x, vz = b.z - a.z, L2 = vx * vx + vz * vz || 1, t = Math.max(0, Math.min(1, ((c.x - a.x) * vx + (c.z - a.z) * vz) / L2)); return Math.hypot(a.x + vx * t - c.x, a.z + vz * t - c.z); };
export function walkFrom(S, to, self) {
  const dx = to.x - S.P.x, dz = to.z - S.P.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L, O = others(S, self);
  const v0 = camView(S.p);
  const fixed = (hid) => {   /* 第128版: 出て くる 所が 決まった 舞台（洞くつの 入口・柱の 陰）。道が 通る いちばん 近い 所。第124版(cam): 映らない 所を 先に */
    if (!(S.opt && S.opt.from && S.opt.from.length)) return null;
    const U = (S.fu = S.fu || new Map()), now = Date.now(); let best = null, bd = 1e9, bi = -1;
    for (const fresh of [true, false]) { if (best) break; S.opt.from.forEach((c, i) => { if (fresh && now - (U.get(i) || 0) < 1500) return; const y = okSpot(S, c, c.y, 1); if (y === null) return; const q = { x: c.x, y, z: c.z }, d = distXZ(q, to); if (d < 2 || d > 20 || d >= bd) return; if (O.some((o) => segD(q, to, o) < 1.0)) return; if (hid && v0 && inCam(S.p, q, S.C)) return; if (clearPath(S, q, to)) { best = q; bd = d; bi = i; } }); }
    if (best) U.set(bi, now); return best;
  };
  { const f = fixed(true); if (f) return f; }
  { const v = v0; if (v) {   /* 第124版(cam): カメラに 映らない 所（後ろ・横・物かげ）から 歩いて 来る。近い 所を 先に */
    let best = null, bd = 1e9;
    for (const d of [0, 50, -50, 90, -90, 130, -130, 180]) { const a = (d * Math.PI) / 180, vx = ux * Math.cos(a) - uz * Math.sin(a), vz = ux * Math.sin(a) + uz * Math.cos(a);
      for (const k of [3.5, 5, 7, 9, 12, 14]) { if (k >= bd) break; const q = { x: to.x + vx * k, y: to.y, z: to.z + vz * k }, y = okSpot(S, q, to.y, 1); if (y === null) continue; q.y = y;
        if (O.some((o) => segD(q, to, o) < 1.3) || inCam(S.p, q, S.C) || !clearPath(S, q, to)) continue; best = q; bd = k; break; } }
    if (best) return best; } }
  { const f = fixed(false); if (f) return f; }
  for (const d of [0, 50, -50, 90, -90]) {
    const a = (d * Math.PI) / 180, vx = ux * Math.cos(a) - uz * Math.sin(a), vz = ux * Math.sin(a) + uz * Math.cos(a);
    for (const k of [5, 3.5, 2]) {
      const q = { x: to.x + vx * k, y: to.y, z: to.z + vz * k }, y = okSpot(S, q, to.y, 1); if (y === null) continue; q.y = y;
      if (O.some((o) => segD(q, to, o) < 1.3)) continue;   /* ほかの 人を 通りぬけない */
      if (clearPath(S, q, to)) return q;
    }
  }
  return null;
}
/* 第124版(cam): 今の カメラ（talk.js が 教える {pos, look}）と、そこに 映るか（はば 53°・28マス・見通し）*/
export function camView(p) { try { return HOOK.view(p) || null; } catch { return null; } }
export function inCam(p, q, C, v, noLos = false) {
  if (v === undefined) { let pv = null; try { pv = HOOK.prev ? HOOK.prev(p) : null; } catch {} if (pv && inCam(p, q, C, pv, noLos)) return true; v = camView(p); }   /* 第124版(fix2): カメラが 動いて いる とちゅうは 前の 絵にも 映る */
  if (!v || !q) return false;
  const lx = v.look.x - v.pos.x, ly = v.look.y - v.pos.y, lz = v.look.z - v.pos.z, n = Math.hypot(lx, ly, lz) || 1;
  const fh = Math.atan2(lx, lz), fv = Math.atan2(ly, Math.hypot(lx, lz));
  for (const h of [0.2, 1, 1.8]) { const t = { x: q.x, y: q.y + h, z: q.z }, dx = t.x - v.pos.x, dy = t.y - v.pos.y, dz = t.z - v.pos.z, d = Math.hypot(dx, dy, dz) || 1;
    let ah = Math.abs(Math.atan2(dx, dz) - fh) * 57.3; if (ah > 180) ah = 360 - ah; const av = Math.abs(Math.atan2(dy, Math.hypot(dx, dz)) - fv) * 57.3;   /* 第124版(fix2): 本物の 画面の 四すみ（横 ±50°・縦 ±32°・40m）*/
    if (d < 40 && ah < 50 && av < 32 && (noLos || losC(p.dimension, v.pos, t, C))) return true; }
  return false;
}
function losC(dim, a, b, C) { const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz), n = Math.ceil(L / 0.4); for (let i = 1; i < n; i++) { const t = i / n; if (L * (1 - t) < 0.3) break; if (!viewB(blk(dim, a.x + dx * t, a.y + dy * t, a.z + dz * t, C))) return false; } return true; }   /* 粗い 見通し（軽く）*/
/* 歩いて 来る 人が 着くまで 待つ（寄りの 絵は 着いてから）*/
export async function arrive(e, max = 60) { const W = globalThis.__mqWalk; for (let i = 0; i < max && W && e && W.has(e.id); i++) await wait(1); }
/* 着く 所（歩いて いる とちゅうなら 行き先）*/
export function destOf(e) { try { const S = stageFor(e), W = globalThis.__mqWalk; if (S && W && W.has(e.id) && S.dest.get(e.id)) return S.dest.get(e.id); return e.location; } catch { return null; } }
/* 煙の 中で あらわれる ／ 消える（モンスター・魔将）*/
function puff(e) { try { const l = e.location, dim = e.dimension; try { dim.spawnParticle("mrpg:dust_puff", { x: l.x, y: l.y + 0.1, z: l.z }); } catch {} for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2; try { dim.spawnParticle(i % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(a) * 1.1, y: l.y + 0.3 + (i % 3) * 0.5, z: l.z + Math.sin(a) * 1.1 }); } catch {} } } catch {} }
export function smokeIn(e, t = 8) { if (!ok(e)) return e; try { e.addEffect("invisibility", t + 6, { showParticles: false }); } catch {} puff(e); system.runTimeout(() => { if (ok(e)) { puff(e); try { e.removeEffect("invisibility"); } catch {} } }, t); return e; }
export function smokeOut(e, t = 6) { if (!ok(e)) return; puff(e); try { e.addEffect("invisibility", 40, { showParticles: false }); } catch {} system.runTimeout(() => { try { if (ok(e)) e.remove(); } catch {} }, t); }
/* 立ち去る 先: カメラに 映らない 所（なければ いちばん 遠い 所）*/
export function exitPt(p, e, k = 9) {
  const S = stageFor(e) || stageOf(p); if (!S || !ok(e)) return null; const a = e.location, v = camView(p);
  const b = p.location, dx = a.x - b.x, dz = a.z - b.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L; let far = null, fd = 0;
  for (const d of [0, 40, -40, 80, -80, 120, -120, 160, -160]) { const r = (d * Math.PI) / 180, vx = ux * Math.cos(r) - uz * Math.sin(r), vz = ux * Math.sin(r) + uz * Math.cos(r);
    for (const kk of [k * 0.6, k, k * 1.4]) { const q = clampPath(S, a, { x: a.x + vx * kk, y: a.y, z: a.z + vz * kk }), m = distXZ(q, a); if (m < 2.5) continue; if (!inCam(p, q, S.C)) return q; if (m > fd) { fd = m; far = q; } } }
  return far;
}
const cmdP = (p, c) => { try { p.runCommand(c); } catch {} };
/* 入って くる 所の 絵: 着く 所の 横から 寄り（歩き出す 所が 映らない 向き）*/
function entrance(S, from, to) {
  const dx = from.x - to.x, dz = from.z - to.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n, look = { x: to.x, y: to.y + 1.3, z: to.z };
  for (const deg of [115, -115, 150, -150]) for (const k of [3.2, 4.5]) {
    const a = (deg * Math.PI) / 180, pos = { x: to.x + (ux * Math.cos(a) - uz * Math.sin(a)) * k, y: to.y + 1.8, z: to.z + (ux * Math.sin(a) + uz * Math.cos(a)) * k };
    if (inCam(S.p, from, S.C, { pos, look })) continue;
    try { if (HOOK.put(S.p, pos, look, 0.5)) return true; } catch {}
  }
  return false;
}
/* 立ち位置の 外側（映らない 所）から 歩いて 来る（saga.js・stage2.js 共通）*/
export function walkIn(S, e, to, look) {
  try {
    let from = walkFrom(S, to, e); if (!from) return false;
    const N = Math.max(12, Math.min(40, Math.round(Math.hypot(to.x - from.x, to.z - from.z) * 2.2)));
    let delay = 0, chk = false, need = false, tries = 0;
    e.teleport(from, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } });
    if (!S.auto && inCam(S.p, from, S.C)) {   /* 第124版(cam): 映らない 所が ない（せまい 広間など）: 着く 所を 寄りで 映し、その 外から 歩いて 入る（だめなら 短い 暗転）*/
      try { e.addEffect("invisibility", 40, { showParticles: false }); } catch {}
      if (entrance(S, from, to)) delay = 11; else { need = true; delay = 1; }   /* 第124版(fix2): 暗い うちに 透明を 外す ／ 明るく なりかけの ときは 待ってから 暗転（重ねない）*/
    }
    else if (!S.auto) { try { e.addEffect("invisibility", 10, { showParticles: false }); } catch {} delay = 1; chk = true; }   /* 第124版(fix2): 同じ tick に カメラが かわっても 出る 所が 映らない ように、2tick 後に もう一度 調べる */
    e.teleport(from, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } }); try { e.setProperty("mrpg:mv", true); } catch {}
    const W = (globalThis.__mqWalk = globalThis.__mqWalk || new Map()), wid = e.id; W.set(wid, Date.now()); S.dest.set(e.id, { x: to.x, y: to.y, z: to.z });
    let k = -delay; const id = system.runInterval(function stepWalk() { if (k < 0) { if (++k === 0) { if (chk && ok(e) && inCam(S.p, from, S.C)) { const f2 = walkFrom(S, to, e); if (f2 && !inCam(S.p, f2, S.C)) { from = f2; try { e.teleport(from, { facingLocation: to }); } catch {} } else need = true; } chk = false;
          if (need && ok(e)) { try { e.addEffect("invisibility", 14, { showParticles: false }); } catch {} let r = true; try { r = HOOK.fadeTry ? HOOK.fadeTry(S.p, "0.15 0.3 0.35") : true; } catch {} if (r || ++tries > 20) { need = false; k = -3; } else k = -1; return; }
          try { e.removeEffect("invisibility"); } catch {} } return; } k++; if (!ok(e) || k > N) { system.clearRun(id); W.delete(wid); try { if (ok(e)) { e.teleport(to, { facingLocation: look }); e.setProperty("mrpg:mv", false); } } catch {} return; }
      const t = k / N, x = from.x + (to.x - from.x) * t, z = from.z + (to.z - from.z) * t; let y = from.y + (to.y - from.y) * t; { const g = standY(S.dim, x, z, y, S.C); if (g !== null && g > y && g - y < 1.2) y = g; }
      try { e.teleport({ x, y, z }, { facingLocation: to }); } catch {} }, 2);
    return true;
  } catch { return false; }
}
/* 2点の あいだを 歩けるか（とちゅうの 足もとが あるか）*/
export function clearPath(S, a, b) {
  const L = distXZ(a, b), n = Math.max(1, Math.ceil(L / 0.25));   /* 第124版(fix2): 柵・街灯の 角を 通りぬけない */
  const px = L > 0.01 ? (-(b.z - a.z) / L) * 0.3 : 0, pz = L > 0.01 ? ((b.x - a.x) / L) * 0.3 : 0;   /* 体の はば（左右 0.3）も 柵・壁に かからない */
  let y = a.y; for (let i = 1; i <= n; i++) { const t = i / n, q = { x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t }, yy = okSpot(S, q, y, 1); if (yy === null) return false; y = yy;
    for (const s of [1, -1]) for (const h of [0.1, 1.2]) { const k = blk(S.dim, q.x + px * s, y + h, q.z + pz * s, S.C); if (k !== undefined && !passB(k)) return false; } }
  return true;
}
/* a から b へ 進める ところまで（壁の 手前で 止まる）*/
export function clampPath(S, a, b) {
  if (!S) return b;
  const L = distXZ(a, b), n = Math.max(1, Math.ceil(L / 0.25)); let last = { ...a }, y = a.y;
  for (let i = 1; i <= n; i++) { const t = i / n, q = { x: a.x + (b.x - a.x) * t, y, z: a.z + (b.z - a.z) * t }, yy = okSpot(S, q, y, 1); if (yy === null) break; q.y = yy; y = yy; last = q; }
  return last;
}
/* 舞台の 向きで 前へ k・右へ sd（地面に 合わせる）*/
export function stagePt(S, k, sd = 0, dy = 0) {
  const q = S.at(k, sd); let y = okStand(S, q, S.P.y, 0.5);
  if (y === null) {   /* 屋台や 壁の 上に ならない: 近くの 立てる 地面へ */
    let c = null; for (const r of [0.8, 1.6, 2.4]) { for (let i = 0; i < 8 && !c; i++) { const a = (i * Math.PI) / 4, w = { x: q.x + Math.cos(a) * r, z: q.z + Math.sin(a) * r }, yy = okStand(S, w, S.P.y, 0.5) ?? okSpot(S, w, S.P.y, 1); if (yy !== null) c = { ...w, y: yy }; } if (c) break; }
    if (c) { q.x = c.x; q.z = c.z; y = c.y; } else { const yy = standY(S.dim, q.x, q.z, S.P.y, S.C); y = yy !== null ? yy : S.P.y; }   /* 第127版: 坂では その場の 地面の 高さ */
  }
  q.y = y + dy; return q;
}
/* 戦いの あとなど: 立ち位置から はなれて いたら もどす */
export function stageReturn(p) {
  const S = stageOf(p); if (!S) return;
  try { if (p.getDynamicProperty("mrpg:stgres") && !p.getEffect("resistance")) p.addEffect("resistance", 20 * 1200, { amplifier: 255, showParticles: false }); } catch {}   /* 第127版: 戦いの あと・生きかえった あとも 守る */
  try { const l = p.location; if (p.dimension.id !== S.dim.id || distXZ(l, S.P) > 2 || Math.abs(l.y - S.P.y) > 2) p.teleport({ x: S.P.x, y: S.P.y + 0.02, z: S.P.z }, { dimension: S.dim, facingLocation: S.at(3.5, 0, 1.6) }); } catch {}
}
/* ---------- 向き ---------- */
function faceP(S, at) { const p = S.p; try { const l = p.location; if (distXZ(l, S.P) > 3) return; p.teleport(l, { facingLocation: at }); } catch {} }
const DOWN = new Set([8, 15, 20]);
/* 話す 人が 話す 相手を 向き、まわりの 人は 話す 人を 見る。話す 相手を かえす（カメラが 使う）*/
/* 第124版(fix2): 話す 相手: 同じ 人が 続けて 話す あいだは 同じ 相手 ／ 旅の 仲間は 前に 話した 人へ ／ 旅の 仲間に 答える ／ NPC どうしは 前に 話した 人へ */
function lisOf(S, sp, hero) {
  if (S.prev === sp) return ok(S.pl) ? S.pl : null;
  if (hero && ok(S.last) && S.last !== sp && distXZ(S.last.location, sp.location) < 9) return S.last;
  if (!hero && ok(S.prev) && S.prev !== sp && S.prev.hasTag?.("mrpg_hero") && distXZ(S.prev.location, sp.location) < 9) return S.prev;
  if (!hero && ok(S.last) && S.last !== sp && distXZ(S.last.location, sp.location) < 6) return S.last;
  return null;
}
export function listenerOf(p, sp) { try { const S = stageOf(p); if (!S || !ok(sp)) return null; let hero = false; try { hero = sp.hasTag("mrpg_hero"); } catch {} return lisOf(S, sp, hero); } catch { return null; } }
export function speakTurn(p, sp) {
  const S = stageOf(p); if (!S || !ok(sp)) return null;
  S.ents = S.ents.filter(ok); if (!S.ents.includes(sp)) return null;
  let hero = false; try { hero = sp.hasTag("mrpg_hero"); } catch {}
  const lis = lisOf(S, sp, hero);
  const H = head(sp, 1.5);
  const tg = lis ? head(lis, 1.5) : head(p, 1.5);   /* 第127版: 聞く 人が いない ときの 旅の 仲間は 前の 空き地ではなく あなたを 向く */
  const still = (e) => { try { return !!(e.getDynamicProperty("mrpg:still") || e.getDynamicProperty("mrpg:away")) || /石/.test(String(e.nameTag || "")); } catch { return false; } };   /* 第124版(fix2): 石像・わざと 背を 向けた 人は 向きを かえない */
  if (!still(sp)) try { sp.teleport(sp.location, { facingLocation: tg }); } catch {}
  for (const e of S.ents) {
    if (e === sp) continue; let a = 0; try { a = e.getProperty("mrpg:act"); } catch {}
    if (DOWN.has(a) || still(e)) continue;
    try { e.teleport(e.location, { facingLocation: H }); } catch {}
  }
  faceP(S, H);
  if (!hero) S.last = sp;
  S.prev = sp; S.pl = lis;
  return lis || p;
}
/* ---------- 片づけ（ぬけた・ワールドを 閉じた とき）---------- */
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { const S = ST.get(playerId); if (S) { ST.delete(playerId); release(S); ZONE.delete(playerId); thaw(S); } }); } catch {}
/* 第127版: 入りなおし → 場面の 守りを 外す ／ 場面の とちゅうで たおれて 生きかえった → 舞台へ もどす */
try { world.afterEvents.playerSpawn.subscribe(({ player: p }) => { if (!ST.has(p.id)) noRes(p); else system.runTimeout(() => stageReturn(p), 2); }); } catch {}
let sweepN = 0;
system.runInterval(() => {
  sweepN++;
  /* 自動で 作った 舞台は 会話が 5秒 止まったら おわり。どの 舞台も 20分で おわり */
  for (const [id, S] of ST) {
    if (!ok(S.p)) { ST.delete(id); closeStage(S); continue; }
    if ((S.auto && S.on && HOOK.idle(S.p) > 5000) || Date.now() - S.t0 > 1200000) { ST.delete(id); closeStage(S); continue; }
    if (S.on && S.Cn && !HOOK.paused(S.p)) { hideAround(S); freezeAround(S); }   /* 第127版: 場面の とちゅうで 来た・わいた ものも かくす（2秒ごと）*/
  }
  if (sweepN % 5 !== 1) return;
  sweepOrphans();
}, 40);
/* 持ち主の 舞台が ない（ぬけた・ワールドを 閉じた）印を もどす */
function sweepOrphans() {
  for (const d of ["overworld", "nether", "the_end"]) {
    let L = []; try { L = world.getDimension(d).getEntities({ tags: ["mrpg_stghid"] }); } catch {}
    for (const e of L) { let o; try { o = e.getDynamicProperty("mrpg:stgown"); } catch {} if (!o || !ST.has(o)) unhide(e); }
    let F = []; try { F = world.getDimension(d).getEntities({ tags: ["mrpg_frz"] }); } catch {}
    for (const e of F) { let o; try { o = e.getDynamicProperty("mrpg:frzown"); } catch {} if (!o || !ST.has(o)) unfreeze(e); }
  }
}
export const __stage = { freezeTick, sweepOrphans, ST, HID, FRZ, ZONE, SLOTS, EVAL, frameScore, toW, wait };
