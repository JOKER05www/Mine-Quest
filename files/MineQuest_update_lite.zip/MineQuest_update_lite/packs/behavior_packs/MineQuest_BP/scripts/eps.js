/* 第125版: 地方ごとの 5話を 読みこむ（ファイルは 地方ごとに 分ける。ここは さわらなくて よい）*/
import "./sagaep.js";
import "./ep_r0.js"; import "./ep_r1.js"; import "./ep_r2.js"; import "./ep_r3.js"; import "./ep_r4.js"; import "./ep_r5.js";
import "./ep_r6.js"; import "./ep_r7.js"; import "./ep_r8.js"; import "./ep_r9.js"; import "./ep_r10.js";
import "./links.js";   /* 第125版: すべてが つながる（終章・エンディング・クリア後の 回収）*/
