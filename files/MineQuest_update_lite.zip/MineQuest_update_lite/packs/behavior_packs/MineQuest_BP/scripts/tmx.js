// 第125版: 闘魔解放（戦いの 中で 1回・1体だけ。その 戦いの 終わりまで 闘魔の 姿）
// 使える 条件: 「闘魔の 腕輪」を 持つ ＋ 闘魔覚醒した 子（または 同じ 系統の 闘魔石を 持っている 子）。神系は できない
// 敵: 邪闘十魔将・六影の 幹部（ガロ・ベリル・ヴァルカ・双子・アルゴ・セオ・ゼファード）・物語の あとの レイ も 1回 使う
import { MolangVariableMap } from "@minecraft/server";
import { SPECIES } from "./data.js";
import { tmUnleash, TM_FAM } from "./core.js";
import { countItem, anim, sound, isLite, ok } from "./ui.js";
import { setLook } from "./field.js";
import { load } from "./store.js";

export const TM_BR = "mrpg:k_tmbr";
export const TM_FAMS = ["blob", "beast", "bird", "plant", "insect", "aqua", "golem", "undead", "demon", "sword", "dragon", "king"];
const PURPLE = [0.55, 0.15, 0.85];
const TK_NAME = ["ヒフミ＆シゴロ", "イトマ", "テルグ", "サイオウバ", "ハドラ", "ザキュラス", "ガムラ", "リョウマ", "ギレンドドロス", "ベルガ"];

/* 腕輪・闘魔石は 戦いごとに 1回だけ 数える（軽く）*/
function invOf(B, p) {
  B.tmInv = B.tmInv || {};
  let v = B.tmInv[p.id];
  if (!v) {
    let br = false; try { br = countItem(p, TM_BR) > 0 || !!(load(p) || {}).tmb; } catch {}
    const st = new Set(); if (br) for (const k of TM_FAMS) { try { if (countItem(p, `mrpg:tms_${k}`) > 0) st.add(k); } catch {} }
    v = B.tmInv[p.id] = { br, st };
  }
  return v;
}
export const tmUsed = (B, p) => !!(B && B.tmUsed && B.tmUsed[p.id]);
export function tmCan(B, p, f) {
  try {
    if (!B || !p || !f || !f.m || f.hp <= 0 || f.tmx || f.lookAs || f.guest || f.out) return false;
    if (tmUsed(B, p) || (B.master && B.master.rules && B.master.rules.notm)) return false;
    if (f.owner && f.owner !== p.id) return false;
    if (SPECIES[f.m.sp]?.fam === "god") return false;
    const v = invOf(B, p); if (!v.br) return false;
    return !!(f.m.tm || f.m.awk || v.st.has(TM_FAM(f.m.sp)) || (B.master && B.master.tmAny));   /* tmAny: 腕輪を 打った 日の 試し（どの 子でも）*/
  } catch { return false; }
}
export const tmHas = (B, p) => { try { return invOf(B, p).br; } catch { return false; } };

/* 見た目: 光の 柱・咆哮・紫の 色・少し 大きく */
function vfx(e, id, dy, col, scale) {
  if (!ok(e) || isLite()) return;
  try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: col[0], green: col[1], blue: col[2] }); m.setFloat("variable.scale", scale); const l = e.location; e.dimension.spawnParticle(`mrpg:${id}`, { x: l.x, y: l.y + dy, z: l.z }, m); } catch {}
}
function lookM(f) { return f.lookAs ? { ...f.m, sp: f.lookAs, look: null, tint: null } : f.m; }
export function tmFx(B, f) {
  const e = f && f.ent; if (!ok(e)) return;
  try { f.tmSz0 = e.getProperty("mrpg:size"); } catch {}
  try { const m = lookM(f); setLook(e, f.lookAs || f.m.sp, { ...m, tint: { ...(m.tint || {}), b: 12, c: 16 } }); } catch {}
  try { const s = e.getProperty("mrpg:size"); if (typeof s === "number" && s > 0) e.setProperty("mrpg:size", Math.min(2500, Math.round(s * 1.15))); } catch {}
  vfx(e, "pillar", 0, PURPLE, 2); vfx(e, "rise", 0.1, PURPLE, 1.4); vfx(e, "orb", 1.2, PURPLE, 2);
  try { anim(e, "g_roar"); } catch {}
  for (const x of (B && B.players) || []) { try { sound(x.p, "mob.enderdragon.growl", 0.9); sound(x.p, "beacon.power", 0.7); } catch {} }
}
/* 闘魔の オーラ（画面の 更新ごとに 少しだけ）*/
export function tmAura(B) {
  if (!B || isLite()) return;
  for (const f of [...(B.allies || []), ...(B.enemies || [])]) if (f && f.tmx && f.hp > 0 && ok(f.ent)) vfx(f.ent, "rise", 0.1, PURPLE, 0.8);
}
/* 戦いの あと: 外に 残る 子（相棒・野生）の 見た目を もどす */
export function tmRestore(B) {
  for (const f of [...((B && B.allies) || []), ...((B && B.enemies) || [])]) {
    if (!f || !f.tmx || !ok(f.ent)) continue;
    try { setLook(f.ent, f.lookAs || f.m.sp, lookM(f)); } catch {}
    try { if (typeof f.tmSz0 === "number") f.ent.setProperty("mrpg:size", f.tmSz0); } catch {}
  }
}
/* プレイヤーの 闘魔解放 */
export function tmRelease(B, p, f, log) {
  if (!tmCan(B, p, f)) return false;
  B.tmUsed = B.tmUsed || {}; B.tmUsed[p.id] = 1;
  const L = [`§5§l${B.players && B.players.length > 1 ? p.name + "の " : ""}闘魔の 腕輪が ${f.name}と 共鳴した！`];
  if (!tmUnleash(f, L)) return false;
  log.push(...L); tmFx(B, f);
  return true;
}

/* ---- 敵の 闘魔解放 ---- */
function reiOk(B) {
  if (B.master && B.master.tmx === "rei") return true;
  try { for (const x of B.players || []) { const s = (load(x.p) || {}).story || {}; if (s.reiFinal) return true; } } catch {}
  return false;
}
/* 戦いの はじめに 1回: だれが 使うか */
export function tmFoeSetup(B) {
  try {
    if (!B || B.pvp || B.spar) return;
    const nm = String((B.master && B.master.name) || "").replace(/§./g, "");
    let k = null;
    if (B.tk && B.tk.i >= 0) k = "tk";
    else if (/^六影.*ガロ/.test(nm)) k = "garo";
    else if (/^六影 七番目/.test(nm)) k = "beryl";
    else if (/^六影 三の座/.test(nm)) k = "valka";
    else if (/^六影 四・五の座/.test(nm)) k = "twins";
    else if (/^六影 六の座/.test(nm)) k = "argo";
    else if (/^六影 二の座/.test(nm)) k = "theo";
    else if (/暴走セオ|影王セオ/.test(nm)) k = "theo2";
    else if (/^六影 一の座|星冠王/.test(nm)) k = "zeph";
    else if (/^ライバル レイ/.test(nm) && reiOk(B)) k = "rei";
    if (k) B.tmFoe = k;
  } catch {}
}
const FOE_LINE = {
  garo: ["§c§lガロ§r§f「へへっ、ヴァルカの 姐さんが 打った 写しの 腕輪だ！ 見せて やるぜ――闘魔解放！」"],
  beryl: ["§8§lベリル§r§f「……この 腕輪の 行も、わたしが 書く。――闘魔解放。」"],
  valka: ["§c§lヴァルカ§r§f「アタシが 打った 腕輪さ。……燃えな、相棒！ 闘魔解放！」"],
  twins: ["§9§lロウ§r§f「ルウ、腕輪を。いっしょに いくよ。」", "§d§lルウ§r§f「うん、ロウ！ ――闘魔解放！」"],
  argo: ["§7§lアルゴ§r§f「…………。」", "§7（仮面の 下で、腕輪が 鈍く 光った）"],
  theo: ["§5§lセオ§r§f「記録に ある……闘魔解放。写しでも、十分です。」"],
  theo2: ["§5§l暴走セオ§r§f「……キロク……カイホウ……！」"],
  zeph: ["§6§lゼファード§r§f「四十年、外さなかった 腕輪だ。……幕引きに ふさわしい。闘魔解放！」"],
  rei: ["§b§lレイ§r§f「じいちゃんの 腕輪……力を 貸して くれ！ 闘魔解放！」"],
};
/* 敵の 番の 前に: HPが 6割を 切るか 3ターン目から 1回だけ。いちばん 強い 子に */
export function tmFoeTurn(B, log) {
  try {
    if (!B || !B.tmFoe || B.tmUsedE) return false;
    const live = (B.enemies || []).filter((f) => f && f.hp > 0 && !f.tmx && f.m && !f.out);
    if (!live.length) return false;
    const low = live.some((f) => f.hp <= f.mx.hp * 0.6);
    if (!(low || (B.turn || 1) >= 3)) return false;
    const f = [...live].sort((a, b) => (b.isBoss ? 1 : 0) - (a.isBoss ? 1 : 0) || b.mx.hp - a.mx.hp)[0];
    B.tmUsedE = 1;
    const L = B.tmFoe === "tk" ? [`§4§l${TK_NAME[B.tk.i] || f.name}§r§f「腕輪の 戦士どもの 技……千年ぶりに 返して やろう！ 闘魔解放！」`] : [...(FOE_LINE[B.tmFoe] || [])];
    if (!tmUnleash(f, L)) return false;
    log.push(...L); tmFx(B, f);
    return true;
  } catch { return false; }
}
