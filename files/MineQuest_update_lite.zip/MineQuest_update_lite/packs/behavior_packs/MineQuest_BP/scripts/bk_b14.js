/* 第126版 本14「竜骨の決戦」（竜骨の祭壇）— 作業 MD
   1 セオとアルゴ（命令書・落ちた手帳の写生）→ 2 守り手（セオは手を出さない）→ 3 六つのくぼみ（留め金・赤い鍵・仮面の刃・指輪の半分。C04 台座／C11 手袋）
   → 4 丸いくぼみ（主人公と相棒の足もとで光る）→ 5 南の空が紫・赤い鍵が割れる → 6 影の槍・幼なじみが石に（コンパスの針が回る）
   → 7 レイの竜が翼でかばって石に・アルゴ「また、守れなかった」・影のセオは空へ → 8 静けさ（ヴァルカが鍵を拾う・からっぽの音）
   → 9 見晴らし台の夕暮れ（鱗の墓標・手帳とコンパス・名を三度。ソラの試しの言葉）
   MQ21 = b13e5〜b14e8（mqOver）。引きとった古い話: r9e5→b14e9（墓標は見晴らし台。ソラの試しは見晴らし台で言葉だけ、戦いは本15-6 城の塔）*/
import { bkAdd, mqOver } from "./bkeng.js";
import { facMark } from "./epfac.js";
import { world } from "@minecraft/server";
import { ok } from "./ui.js";
import { knockSafe } from "./bk_b01.js";
import { LOOK, Y, REI, DRAG, HNm, lose, won, stoneFx, heroStone, grave, graveSpot, lookFront, hall9, sixT } from "./bk_b13.js";

/* ---------- 祭壇の 場所: 洞くつの 広間（あれば）か、骨の 祭壇の セット ---------- */
async function goAltar(K, p) {
  const v = hall9();
  if (v) {
    const h = v.hall, al = v.altar || { x: h.x, y: h.y, z: h.z + 6 };
    const far = Math.hypot(p.location.x - h.x, p.location.z - h.z) > 9 || Math.abs(p.location.y - h.y) > 3;
    if (far) { try { p.teleport({ x: v.entry.x, y: v.entry.y + 0.1, z: v.entry.z + 1 }); } catch {} await K.wait(6); await K.moveTo(p, { x: h.x, y: h.y, z: h.z }, "竜骨の 祭壇", [], { x: al.x, y: al.y + 1, z: al.z }, 4); }
    const ux = al.x - h.x, uz = al.z - h.z, n = Math.hypot(ux, uz) || 1, fx = ux / n, fz = uz / n, at = (a, b) => ({ x: h.x + fx * a - fz * b, y: h.y, z: h.z + fz * a + fx * b });
    return { altar: { x: al.x, y: h.y, z: al.z }, round: at(n * 0.45, 0), back: at(n - 1.2, 0), left: at(n * 0.6, -3), right: at(n * 0.6, 3), hall: true };
  }
  const q = K.fac(p, "r9keys", "keyaltar", 9, Y(K, p));
  const M = (k, a, b) => facMark("r9keys", k) || K.fwd(p, a, b);
  return { altar: M("altar", 6, 0), round: M("round", 4, 0), back: M("back", 8, 0), left: M("left", 5, -3), right: M("right", 5, 3), set: q };
}
const ALT = (K, p) => goAltar(K, p);
const TH = (K, p, w = false) => K.npcNear(p, "§5六影 参謀 セオ", 18, w);
const ARGO = (K, p, w = false) => sixT(K, p, "argo", "§4仮面の 戦士 アルゴ", 10, w);
const VALKA = (K, p, w = false) => sixT(K, p, "valka", "§c六影 幹部 ヴァルカ", 9, w);
const ROU = (K, p) => sixT(K, p, "rou", "§9六影 四の座 ロウ", 9, true);
const RUU = (K, p, w = false) => sixT(K, p, "ruu", "§d六影 五の座 ルウ", 9, w);
const near = (q, a, b = 0) => (q ? { x: q.x + a, y: q.y, z: q.z + b } : null);

/* ---------- 1話 セオと アルゴ ---------- */
const E1 = { id: "b14e1", t: "竜骨の 祭壇",
  hint: "§f§e竜骨の 祭壇§f へ",
  syn: "竜骨の 祭壇に、セオと 仮面の 戦士が いた。セオは 仮面の 戦士を「アルゴ」と 呼んだ。アルゴは 命令書を 握った まま、双子の 前に 立って いる。セオの 手帳が 開いて 落ちた。十二年分の、石の 弟の 写生。どれも 同じ 距離から。",
  battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    K.big(p, "§4§l竜骨の 祭壇", "§f竜の 骨の 根もと。紫の 壇に、形の ちがう くぼみが 並ぶ", "mob.enderdragon.growl");
    await K.at(p, A.altar, 18, 9, 3);
    const eT = await K.put(p, "§5六影 参謀 セオ", near(A.back, 0, 0), A.altar, 18); if (ok(eT)) K.turn(eT, A.altar);
    const eA = await K.put(p, "§4仮面の 戦士 アルゴ", A.right, null, K.PJ("argo", 10)); K.act(eA, "guard");
    const eRo = await K.put(p, "§9六影 四の座 ロウ", near(A.right, 2.4, 1.6), near(A.right, 1.2, 0.4), K.PJ("rou", 9)); K.act(eRo, "down");   /* 第126版(PV): 倒れた 体が ルウの 足もとに かからない（頭は 外へ）*/
    const eRu = await K.put(p, "§d六影 五の座 ルウ", near(A.right, 1.2, 0.4), null, K.PJ("ruu", 9)); K.act(eRu, "kneel");
    const eH = K.hero(p), eR = REI(K, p);
    await K.say(p, "セオ", ["{closed,low}……来ましたね。"], eH);
    K.turn(eT); await K.up(p, eT, 10);
    await K.say(p, "セオ", ["{sad,up}……すみません。本当に。……君は、必ず 来ると 思って いました。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}セオさん、もう やめて！ ここで 何を する つもりなの！"], ["{sad,up}セオさん……もう やめて。ここで、何を するの？"], ["{angry}セオ。ここで 何を する。"], ["{angry,up}セオさん、どうか おやめ ください！ 何を なさる おつもりですか！"]), eT);
    K.act(eA, "hold"); K.hold(eA, "letter");
    await K.at(p, ok(eA) ? { x: eA.location.x, y: eA.location.y + 1.2, z: eA.location.z } : A.right, 12, 1.6, 0);
    await K.narr(p, ["§7仮面の 戦士の 手に、くしゃくしゃに 握られた 命令書。", "§7……その 体は、ずっと 双子と 祭壇の あいだに ある。"], eA);
    await K.say(p, "セオ", ["{closed}アルゴ。……命令書の とおり、鍵を 届けて くれて ありがとう。"], eA);
    await K.say(p, "アルゴ", ["{closed,low}……命令だ。……子らには、さわるな。"], eT);
    K.hold(eA);
    /* 落ちた 手帳 */
    K.act(eT, "hold"); K.hold(eT, "notebook"); K.sound(p, "item.book.put", 1);
    if (ok(eT)) { K.act(eT, "recoil"); }
    const nq = near(A.altar, -1.2, 0.4);
    await K.at(p, nq, 14, 1.8, 0.2);
    await K.narr(p, ["§7セオの 手から 手帳が すべり落ち、床で 開いた。", "§7頁いっぱいの 写生。石の 小さな 男の子。……どの 頁も、同じ 距離から 描かれて いる。"], nq);
    await K.hsay(p, K.V(["{sad,…}……ルミエの 小川の、あの 子……。何枚も……。"], ["{sad,…}……ルミエの、石の 男の子……。こんなに。"], ["{closed}……同じ 距離。何年分。"], ["{sad,…}……ルミエの、あの 子を……こんなに 何枚も……。"]), eT);
    await K.say(p, "セオ", ["{closed,low}……十二年。毎月。……近づけなかった。それだけです。"], eH);
    K.act(eT, "kneel"); K.hold(eT, "notebook"); K.act(eT, 0);
    await K.say(p, "レイ", ["{angry,low}……拾えよ、それ。大事なもんだろ。"], eT);
    K.pay(p, E1, 1000, []);
    await K.end(p, { card: "§7― 祭壇 ―", kind: "ash", t: 20 });
    return true;
  } };

/* ---------- 2話 守り手 ---------- */
const E2 = { id: "b14e2", t: "祭壇の 守り手",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "祭壇の 骨が 起きあがり、竜骨の 守り手が 立ちはだかった。セオは 手を 出さず、ただ 見て いた。",
  battles: 1,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const eT = TH(K, p, true); K.act(eT, "hold");
    const eH = K.hero(p), eR = REI(K, p);
    K.boom(p.dimension, A.altar); K.sound(p, "mob.enderdragon.growl", 1); K.shake(p, 0.6, 0.8);
    const g1 = K.monEnt(p, near(A.altar, 0, 0), DRAG(), "§6竜骨の 守り手");
    await K.at(p, A.altar, 14, 7, 2);
    await K.say(p, "竜骨の 守り手", ["{angry,low}……カギヲ……ハメル……ナ……"]);
    await K.say(p, "セオ", ["{closed}……守り手が、君たちに 道を あけるか どうか。僕は、見て いるだけ です。"], eR);
    K.act(eR, "guard"); K.act(eH, "guard");
    await K.say(p, "レイ", ["{angry,!,up}見てるだけかよ……！ ……背中は 任せた！"], eT);
    K.rmCine(g1);
    if (!(won(K, p, "ch10g") || K.flag(p, "b14e2a"))) {
      await K.duel(p, "§6§l祭壇の 守り手", "§f竜骨の 祭壇を 千年 守る 骨が、翼を ひろげる！", { fams: ["dragon", "golem"] });
      const r = await K.battle(p, [...K.bossOne(["dragon", "golem"], 72, 60, 1), ...K.team(["dragon", "golem"], 72, 2, 40)], { name: "竜骨の 守り手", arena: "竜骨の 祭壇", theme: "endcity", hpk: 3.2, extra: 0.35, sboss: true, tag: "守り手", speaker: "守り手", guests: K.team(["dragon"], 72, 1, 30).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……カギ……カ……？", low: "……トオレ……" } });
      if (r !== "win") return lose(K, p, "§bレイ", 17, "レイ", "……くそ、いったん 引こう！ 立てなおして、もう一度だ！");
      K.setFlag(p, "b14e2a");
    }
    const g2 = K.monEnt(p, A.altar, DRAG(), "§6竜骨の 守り手"); K.burst(p.dimension, A.altar, "minecraft:white_smoke_particle", 10, 1.6, 0.4);
    await K.narr(p, ["§7守り手は 骨の 首を たれ、祭壇の 奥へ 沈んで いった。"], g2);
    K.rmCine(g2);
    await K.say(p, "セオ", ["{smile,…}……やはり。守り手が、君たちに 道を あけた。"], eH);
    K.pay(p, E2, 3000, [["c_revive2", 1]]);
    await K.end(p, { card: "§7― 六つの くぼみ ―", kind: "ash", t: 20 });
    return true;
  } };

/* ---------- 3話 六つの くぼみ ---------- */
const E3 = { id: "b14e3", t: "六つの くぼみ",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "祭壇には 六つの くぼみ。本4の 鋳造所で 見た 台座と 同じ 形。セオが 手帳の 留め金、ヴァルカが 赤い 鍵、アルゴが 仮面の 刃を 置いた。ルウが 眠る ロウの 手を 取ると、白と 黒の 指輪の 半分が 合った。「ロウの 手、つめたいんだもん……」。くぼみの 横には、マリノアで 破られた 頁。鍵穴の 図だった。",
  F: ["F07", "F67"], ans: ["qb041", "qb121", "qb111"], battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const s = K.qs(K.load(p) || d);
    const eT = TH(K, p, true), eV = VALKA(K, p), eA = ARGO(K, p, true), eRo = ROU(K, p), eRu = RUU(K, p, true), eH = K.hero(p), eR = REI(K, p);
    K.act(eRo, "down"); K.act(eRu, "kneel");
    await K.push(p, A.altar, 24, 4, 1.2);
    await K.narr(p, ["§7紫の 壇に、形の ちがう くぼみが 五つ。……そして 床に、空っぽの 丸い くぼみが 一つ。", K.chV(s, "c04", { p: "§7壇の 縁は 打ちたての まま、ひびだらけ。急いで 打った 仮の 台座だ。", s: "§7壇の 縁に、ラヴィの 鍛冶の 刻み。鋳造所から 運ばれた、本物の 台座だ。", _: "§7鋳造所で 見た 台座と、同じ 形。" })], A.altar);   /*（台座 回）*/
    await K.hsay(p, K.V(["{shock,!,up}この 形……ヴォルカの 鋳造所の 台座と 同じ！"], ["{shock,up}……この 形。鋳造所の、あの 台座……"], ["{shock}……鋳造所の 台座。同じ 形。"], ["{shock,up}この 形は……鋳造所の 台座と 同じ……！"]), eT);
    /* 鍵を 置く */
    K.act(eT, "give"); K.sound(p, "random.anvil_land", 0.6);
    await K.say(p, "セオ", ["{closed}……二の座。手帳の 留め金。"], eV);
    if (ok(eV)) await K.approach(p, eV, A.altar, 1.4);
    K.act(eV, "give"); K.sound(p, "random.anvil_land", 0.7);
    await K.say(p, "ヴァルカ", ["{closed}……三の座。親父の 刀の、赤い 鍵だ。……命令書の とおりに 来たよ。アタシは 嘘は つかない。"], eT);
    if (ok(eA)) await K.approach(p, eA, A.altar, 1.4);
    K.act(eA, "give"); K.sound(p, "random.anvil_land", 0.8);
    await K.say(p, "アルゴ", ["{closed,low}……六の座。仮面の 刃。"], eT);
    /* 双子 */
    K.act(eRu, "kneel");
    await K.ots(p, eRu, eRo, 10);
    await K.narr(p, [K.chV(s, "c11", { r: "§7眠る ロウの 胸に、黒い 右手の 手袋が のせて ある。……ルウが ずっと 持って いた もの。", k: "§7ルウは 素手で、眠る ロウの 素手を 握った。……手袋は、どこにも ない。", _: "§7ルウが、眠る ロウの 手を 取った。" })], eRo);
    await K.say(p, "ルウ", ["{cry,tears}……ロウの 手、つめたいんだもん……。"], eRo);
    K.sound(p, "block.amethyst_block.chime", 1); if (ok(eRu)) K.burst(p.dimension, eRu.location, "minecraft:endrod", 8, 0.4, 1);
    await K.narr(p, ["§7白と 黒の 指輪の 半分が、二人の 素手の あいだで 一つに 合わさった。", "§7……くぼみの 一つが、白と 黒に 光った。"], eRu);
    await K.say(p, "アルゴ", ["{angry,low}……それ以上は、さわらせない。"], eRu);
    /* 破られた 頁（鍵穴の 図）*/
    const pq = near(A.altar, -0.8, -1.3);
    await K.at(p, pq, 14, 1.6, 0.2);
    await K.narr(p, ["§7くぼみの 横に、一枚の 古い 頁が 置かれて いた。", "§7……マリノアの 夜の 浜で、セオが 破った 頁。描かれて いるのは、この 祭壇の 形。§f鍵穴の 図§7。"], pq);   /*F07 回 */
    await K.hsay(p, K.V(["{shock,!}……あの 夜、破った 頁……！ ずっと、ここの 図だったんだ……"], ["{shock}……あの 浜で 破った 頁……この 図だったのね。"], ["{shock}破った 頁。……鍵穴の 図。"], ["{shock}あの 浜で お破りに なった 頁が……"]), eT);
    await K.say(p, "セオ", ["{closed}……竜骨は 鍵穴。ルミナに 錠。千年前の 地図の とおりです。", "{closed,low}五本の 鍵が そろえば、残りは 一つ。"], eH);   /*（鍵穴と錠 回）*/
    K.pay(p, E3, 1000, []);
    await K.end(p, { card: "§7― 丸い くぼみ ―", kind: "ash", t: 20 });
    return true;
  } };

/* ---------- 4話 丸い くぼみ ---------- */
const E4 = { id: "b14e4", t: "空っぽの くぼみ",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "残る 一つは、空っぽの 丸い くぼみ。セオ「君は、僕を 止めに、必ず ここへ 来る」。止めに 円へ 踏みこんだ 主人公と 相棒の 足もとで、丸い くぼみが 光った。六つ目は、鍵を 持たない 者と、言葉を 持たない ものだった。",
  ans: ["qb131", "qb091"], battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const eT = TH(K, p, true), eH = K.hero(p), eR = REI(K, p);
    await K.at(p, A.round, 14, 3.2, 0.4);
    await K.narr(p, ["§7床の 丸い くぼみは、空っぽの まま。……何も、はまる 物が ない。"], A.round);
    await K.hsay(p, K.V(["{?,up}……六つ目の 鍵は？ ……持って ないの？"], ["{?,up}六つ目は……？"], ["{?}六つ目。どこに ある。"], ["{?,up}六つ目の 鍵は……？"]), eT);
    await K.up(p, eT, 10);
    await K.say(p, "セオ", ["{closed}……打てないんです。六つ目だけは。鍵を 持たず、言葉を 持たない ものと 結ばれた 人が、要る。", "{sad,up}町を 追われる ように したのも、張り紙も。……君は、僕を 止めに、必ず ここへ 来る。そう 書きました。"], eH);
    await K.say(p, "レイ", ["{angry,!,up}……おまえ、全部 わかってて――！"], eT);
    await K.hsay(p, K.V(["{angry,up}止めよう！ 今なら まだ！"], ["{angry,up}止めましょう……今なら！"], ["{angry}止める。今。"], ["{angry,up}お止め しましょう、今のうちに！"]));
    /* 踏みこむ */
    const g = K.palEnt(p);
    if (ok(eT)) K.turn(eT, A.round);
    if (g) await K.go(g, near(A.round, 1.4, 0.6), 12, true);   /* 第126版(PV): あなたと 重ならない */
    try { p.teleport({ x: A.round.x - 0.3, y: A.round.y, z: A.round.z - 0.3 }); } catch {}
    K.sound(p, "block.end_portal.spawn", 0.6); K.flash(p, true);
    for (let k = 0; k < 6; k++) { const a = (k / 6) * Math.PI * 2; K.burst(p.dimension, { x: A.round.x + Math.cos(a) * 1.2, y: A.round.y + 0.2, z: A.round.z + Math.sin(a) * 1.2 }, "minecraft:totem_particle", 4, 0.2, 0.2); await K.wait(2); }
    await K.at(p, A.round, 16, 4, 0.6);
    await K.narr(p, ["§7あなたと 相棒が 円に 踏みこんだ とたん、足もとの 丸い くぼみが 光った。", "§7……鍵を 持たない 手と、言葉を 持たない 体。六つ目。"], g || A.round);   /*（台座の 丸 回）*/
    await K.pal(p, ["……ここ、あったかい。……いやな あったかさ。"]);
    K.rmCine(g);
    await K.say(p, "セオ", ["{closed,low}……ありがとう。そして、すみません。"], eH);
    K.pay(p, E4, 1000, []);
    await K.end(p, { card: "§7― 南の 空 ―", kind: "ash", t: 20 });
    return true;
  } };

/* ---------- 5話 南の 空 ---------- */
const E5 = { id: "b14e5", t: "紫の 文字",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "遠い 南、ルミナの 方角の 空が 紫に 染まった。セオは 光る 頁を 読み、目に 紫の 文字が 満ちた。セオが 知りたかった 全部が、そこに 書いて あった。赤い 鍵が 割れて 転がった。",
  ans: ["qb082"], battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const eT = TH(K, p, true), eH = K.hero(p), eR = REI(K, p), eV = VALKA(K, p, true);
    const S = K.S(p), south = S ? S.at(-30, 0, 16) : K.fwd(p, -24, 0, 16);
    K.sound(p, "mob.wither.ambient", 0.6); K.mood(p, "shadow");
    await K.at(p, south, 18, 14, 0);
    await K.narr(p, ["§7はるか 南。……ルミナの 方角の 空が、じわりと 紫に 染まって いく。"], south);
    await K.say(p, "レイ", ["{shock,!,up}……南の 空……！ ルミナの 方だぞ！"], eH);
    K.act(eT, "hold"); K.hold(eT, "notebook"); K.sound(p, "item.book.page_turn", 1);
    await K.up(p, eT, 12);
    await K.say(p, "セオ", ["{closed,low}……『王冠の 石板の 奥。影の 鍵の、ほんとうの 名は――』"], eH);
    if (ok(eT)) { K.burst(p.dimension, { x: eT.location.x, y: eT.location.y + 1.7, z: eT.location.z }, "minecraft:portal_reverse_particle", 10, 0.3, 0); }
    await K.narr(p, ["§7頁が 光り、セオの 目に 紫の 文字が 流れこんで いく。", "§7……弟の ことも、母の ことも、十二年前の 冬の ことも。セオが 知りたかった 全部が、そこに 書いて あった。"], eT);
    await K.say(p, "セオ", ["{shock,…,up}……ああ。……全部、わかった。……わかって、しまった。"], eH);
    K.sound(p, "random.glass", 1);
    const kq = near(A.altar, 0.6, -0.6);
    await K.at(p, kq, 12, 1.6, 0.2);
    await K.narr(p, ["§7くぼみの 赤い 鍵に ひびが 走り……ぱきり、と 割れて 転がった。"], kq);
    await K.say(p, "ヴァルカ", ["{shock,!,up}……親父の 鍵が……！"], eT);
    K.pay(p, E5, 1000, []);
    await K.end(p, { card: "§4― 影 ―", kind: "ash", t: 20 });
    return true;
  } };

/* ---------- 6話 影の 槍 ---------- */
const E6 = { id: "b14e6", t: "影の 槍",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "セオの 背から 影が あふれ、影の 槍が まっすぐ あなたへ 伸びた。旅の 仲間が 前に 出た。「よかった。あなたに、当たらなくて」。仲間の 体は 石に なった。胸に 小さな 穴。首から 落ちた コンパスの 針は、回りつづけた。",
  F: ["F03", "F48"], battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const eT = TH(K, p, true), eH = K.hero(p), eR = REI(K, p);
    if (ok(eT)) { try { eT.nameTag = "§4影に 宿られた セオ"; } catch {} K.act(eT, "up"); }
    K.big(p, "§4§l影", "§fセオの 背中から、影が あふれ出す", "mob.wither.spawn"); K.flash(p, false); K.shake(p, 0.8, 1);
    await K.up(p, eT, 12);
    await K.say(p, "セオ", ["{rage,low}……ア……アア……", "{rage,up}……ミツ……ケタ……ムツ……メ……"], eH);
    K.big(p, "§c§l！", "§f影の 槍が、まっすぐ あなたへ", "mob.wither.shoot");
    if (ok(eH)) { await K.go(eH, K.fwd(p, 2), 4, true); K.act(eH, "guard"); if (ok(eT)) K.turn(eH, eT.location); }
    if (ok(eT) && ok(eH)) await K.shadowFlow(p, eT.location, eH.location, 8);
    K.flash(p, false); K.shake(p, 1, 0.8); K.sound(p, "mob.wither.break_block", 0.8);
    if (ok(eH)) { K.turn(eH, null); if (ok(eT)) await knockSafe(K, p, eH, eT.location, 3); else K.act(eH, "down"); }   /* 第126版(PV): 吹っ飛んで あなたの 足もとに 来ない（斜め 横・2マス 以上）*/
    await K.up(p, eH, 18);
    await K.hsay(p, K.V(["{smile,…}……よかった。あなたに、当たらなくて。"], ["{smile,…}……よかった。あなたに、当たらなくて。"], ["{closed}……よかった。あなたに、当たらなくて。"], ["{smile,…}……よかった。あなたさまに、当たらなくて。"]));
    const g = K.palEnt(p); if (g && ok(eH)) { const l = eH.location; await K.go(g, { x: l.x + 0.7, y: l.y, z: l.z + 0.5 }, 10); await K.up(p, g, 10); }
    await K.hsay(p, K.V(["{smile,…}……手帳、続き……書いてね。"], ["{smile,…}……手帳の 続き……おねがい、ね。"], ["{smile,…}……続きは、あなたが。"], ["{smile,…}……手帳の 続きを、どうか……"]));
    /* 石に なる（願った 顔の まま）*/
    await stoneFx(K, p, eH, `§7石の ${HNm(K, p)}`);   /*F03 回: 願った 顔の まま */
    await K.at(p, ok(eH) ? { x: eH.location.x, y: eH.location.y + 1.2, z: eH.location.z } : A.round, 14, 1.4, 0);
    await K.narr(p, ["§7仲間の 体が、ほほえんだ 顔の まま、灰色の 石に なった。", "§7胸に、指先ほどの 小さな 穴。"], eH);
    K.sound(p, "item.book.put", 1);
    const cq = ok(eH) ? { x: eH.location.x + 0.5, y: eH.location.y, z: eH.location.z + 0.4 } : A.round;
    await K.at(p, cq, 16, 1.2, 0);
    await K.narr(p, ["§7首から 落ちた コンパスの 針が、どこも 指さずに 回りつづけて いる。"], cq);   /*F48 強 */
    K.cmd(p, "stopsound @s"); await K.wait(20);
    await K.pal(p, ["……ねえ。……おきて。"]);
    K.rmCine(g);
    K.pay(p, E6, 0, []);
    await K.end(p, { card: "§8……", kind: "ash", t: 26 });
    return true;
  } };

/* ---------- 7話 竜の 翼 ---------- */
const E7 = { id: "b14e7", t: "竜の 翼",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "影は さらに 広がった。レイの 竜が 翼で レイと あなたを かばい、石に なった。アルゴは 双子の 前に 立った まま「……また、守れなかった」。影の セオは 紫の 尾を 引いて、空へ 飛んで いった。",
  F: ["F49"], battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const eT = K.npcNear(p, "§4影に 宿られた セオ", 18, true), eR = REI(K, p), eA = ARGO(K, p, true), eRu = RUU(K, p, true), eRo = ROU(K, p);
    K.act(eRo, "down"); K.act(eRu, "kneel");
    const dq = K.fwd(p, 2.4, 1.8), dr = K.monEnt(p, K.fwd(p, 2.6, 6), DRAG(), "§bレイの 竜");
    K.sound(p, "mob.wither.ambient", 1); K.shake(p, 0.7, 1);
    if (ok(eT)) await K.shadowFlow(p, eT.location, K.fwd(p, 1, 0), 10);
    await K.say(p, "レイ", ["{shock,!,up}……来る！ 伏せろ！！"]);
    if (dr) { await K.go(dr, dq, 6, true); K.sound(p, "mob.enderdragon.flap", 1); await K.at(p, dq, 12, 3.5, 1.4); }
    await K.narr(p, ["§7レイの 竜が 二人の 前に 降り、大きく 翼を 広げた。", "§7影が 翼に ぶつかって 弾け……翼の 先から、灰色に かわって いく。"], dr);
    await stoneFx(K, p, dr, "§7石の 竜");
    await K.say(p, "レイ", ["{cry,!,up}……おい！ おい、動け……！"], dr);
    /* アルゴ */
    if (ok(eA)) { K.act(eA, "guard"); await K.ots(p, eA, eRu || eRo, 10); }
    K.sound(p, "random.glass", 0.8); if (ok(eA)) K.burst(p.dimension, { x: eA.location.x, y: eA.location.y + 1.6, z: eA.location.z }, "minecraft:critical_hit_emitter", 4, 0.2, 0);
    await K.narr(p, ["§7仮面の ひびが、また 一本 走った。……アルゴは 双子の 前から、一歩も 動かなかった。"], eA);   /*F49 強 */
    await K.say(p, "アルゴ", ["{sad,low}……また、守れなかった。"], eRu);
    /* 影の セオは 空へ */
    if (ok(eT)) { const l = eT.location, up = { x: l.x, y: l.y + 14, z: l.z }; await K.shadowFlow(p, l, up, 14); K.rm(eT); await K.at(p, up, 16, 10, 0); }
    K.big(p, "§8……", "§7影の セオは 紫の 尾を 引いて、北の 空へ 飛んだ", "mob.wither.death");
    await K.narr(p, ["§7紫の 尾が、北の 空へ 細く 伸びて……雲の 向こうに 消えた。"]);
    K.rmCine(dr);
    K.pay(p, E7, 0, []);
    await K.end(p, { card: "§8― 静けさ ―", kind: "ash", t: 24 });
    return true;
  } };

/* ---------- 8話 静けさ ---------- */
const E8 = { id: "b14e8", t: "からっぽの 音",
  hint: "§f§e竜骨の 祭壇§f",
  syn: "静けさ。ヴァルカが 割れた 赤い 鍵を 拾った。相棒が 仲間の 石に 耳を 当てた。「……からっぽの、おと」。レイの 竜の 石を 叩くと、鈍く 鳴った。中に、いる 音。",
  battles: 0,
  async run(p, d, K) {
    const A = await ALT(K, p);
    await K.open(p, "竜骨の 祭壇", "ash");
    const eR = REI(K, p), eV = VALKA(K, p, true), eA = ARGO(K, p, true), eRu = RUU(K, p, true), eRo = ROU(K, p);
    K.act(eRo, "down");
    const hq = K.fwd(p, 1.6, -1.4), eHs = await heroStone(K, p, hq);
    const dq = K.fwd(p, 2.6, 2.2), dr = K.monEnt(p, dq, DRAG(), "§7石の 竜");
    await K.wide(p, 16);
    await K.narr(p, ["§7……風の 音だけが、骨の あいだを 抜けて いく。"]);
    const kq = near(A.altar, 0.6, -0.6);
    if (ok(eV)) { await K.walkCam(p, eV, kq, 14); K.act(eV, "kneel"); }
    await K.at(p, kq, 12, 1.6, 0.4);
    await K.narr(p, ["§7ヴァルカが、割れた 赤い 鍵を 拾って、外套の 内に しまった。"], eV);
    await K.say(p, "ヴァルカ", ["{closed,low}……打ち直す。いつか。……今日は、帰るよ。"], eR);
    if (ok(eV)) K.go(eV, K.fwd(p, -6, 5), 24);
    /* 双子と アルゴ */
    K.act(eA, "hold");
    await K.narr(p, ["§7白と 黒の 指輪の 半分は、二人の 指に 戻って いた。……ロウは、まだ 目を 覚まさない。"], eRo);
    await K.say(p, "アルゴ", ["{closed,low}……帰る。……子らを、休ませる。"], eRu);
    K.act(eA, "hold");
    /* からっぽの 音 */
    const g = K.palEnt(p);
    if (g && ok(eHs)) { await K.go(g, { x: eHs.location.x + 0.6, y: eHs.location.y, z: eHs.location.z + 0.4 }, 12); await K.up(p, g, 10); }
    K.sound(p, "block.amethyst_block.hit", 0.6);
    await K.pal(p, ["……からっぽの、おと。"]);
    if (ok(eR) && dr) { await K.approach(p, eR, dr, 1.2); K.act(eR, "hold"); }
    K.sound(p, "dig.stone", 0.5);
    await K.at(p, dq, 12, 2.2, 1.2);
    await K.pal(p, ["……こっちは、いる。なかに、いる おと。"]);
    K.rmCine(g);
    await K.say(p, "レイ", ["{cry,tears}……いるのかよ。……なら、待ってろ。", "{sad,low}……あいつは、からっぽ なのか。"], eHs);
    K.pay(p, E8, 40000, [["e_king", 1], ["i_awaken", 1], ["SEED3", 2], ["s_all3", 1], ["tms_king", 1]]);
    await K.end(p, { leave: [eA, eRu], bye: [eHs, eRo, eV], card: "§7― 夕暮れ ―\n§7→ エンドの §e竜の 見晴らし台§7 へ（右上の 案内）", kind: "dusk", t: 50 });
    K.rmCine(dr);
    return true;
  } };

/* ---------- 9話 見晴らし台（夕暮れ）: 鱗の 墓標（r9e5 を 引きとる）---------- */
const E9 = { id: "b14e9", t: "鱗の 墓標", snd: "item.book.page_turn", place: () => LOOK("エンドの 竜の 見晴らし台（夕暮れ）"), fac: "r9look",
  hint: "§fさいはての 村 §eエンドの 竜の 見晴らし台§f へ もどろう §7（右上の 案内。シズクが 待って いる）",
  syn: "シズクの 竜が、仲間の 石と レイの 竜の 石を 見晴らし台まで 運んだ。シズクは 竜骨の 鱗で 墓標を 立て、石の 横に 置いた。レイが 仲間の 名を 三度 呼んだ。……石は、答えなかった。あなたは 仲間の 旅の 手帳と コンパスを 受け取った。最後の 頁は 白紙の まま。レイ「なんで、白紙なんだよ」。見て いた ソラが 言った。「墓標に 名を 刻む 者は、自分の 足で 立って いられる 者で なければ ならない。……城の 塔で 待つ」。",
  F: ["F29", "F30"], keys: ["k_hnote", "k_compass"], set: { grave9: 1 }, battles: 0,
  skip: (s) => { s.epx = { ...(s.epx || {}), grave9: 1 }; },
  async run(p, d, K) {
    const FQ = K.fac(p, "r9look", "lookout", 9, Y(K, p));
    await K.open(p, "エンドの 竜の 見晴らし台（夕暮れ）", "dusk", "dusk");
    if (FQ) await K.at(p, FQ, 12, 7, 1.5);
    const hn = HNm(K, p), gq = graveSpot(K, p), FS = lookFront(K, p, FQ);
    const eHs = await heroStone(K, p, { x: gq.x + 1.4, y: gq.y, z: gq.z + 0.8 });
    const dr = K.monEnt(p, { x: gq.x - 3.5, y: gq.y, z: gq.z + 2 }, DRAG(), "§7石の 竜");
    await K.narr(p, ["§7シズクの 竜が、二つの 石を 祭壇から 運んで きた。", "§7……ほほえんだ 顔の 石と、翼を 広げた 竜の 石。"], eHs);
    const eR = REI(K, p); K.act(eR, "kneel");
    if (ok(eR) && FS) await K.walkCam(p, eR, FS(-1.2), 14);
    await K.say(p, "レイ", ["{closed,low}……来たか。", "{sad}……ここに、置いて やりたかった。あいつ、地図を 描くの 好きだったろ。ここ、遠くまで 見える。"], eHs);
    const eS = K.cast(p, "shizuku"); K.act(eS, "show"); K.hold(eS, "tablet");
    await K.csay(p, "shizuku", ["{sad}……竜骨から、鱗を 一枚 いただいて まいりました。", "{closed,up}竜が 許して くださいました。……あの方の 名前を、覚えて おきたいと。"], eR);
    /* 墓標を 立てる */
    K.act(eS, "raise");
    if (ok(eS)) { await K.walkCam(p, eS, { x: gq.x - 1.2, y: gq.y, z: gq.z }, 16); K.act(eS, "kneel"); }
    await K.at(p, gq, 10, 3.5, 1);
    if (ok(eS) && ok(dr)) K.turn(eS, dr.location); await K.csay(p, "shizuku", ["{closed}竜よ。いま ひとつ、名を あずけます。"], ok(dr) ? dr : gq); K.turn(eS, null);   /* 第126版(PV): 竜（の 石）へ 向けて */
    await grave(K, p, gq);
    K.sound(p, "note.chime", 0.6); K.burst(p.dimension, gq, "minecraft:endrod", 8, 0.8, 2.6);
    await K.at(p, gq, 16, 3, 1.4);
    await K.narr(p, ["§7青い 鱗の 墓標が、夕日を うけて 光った。", "§7鱗の まわりに、白い すずらんと 青い 花が 咲いた。"], gq);
    K.act(eS, 0);
    /* 名を 三度 */
    K.act(eR, "up"); if (ok(eR)) await K.approach(p, eR, eHs, 1.4);
    await K.ots(p, eR, eHs, 10);
    await K.say(p, "レイ", [`{sad,up}……${hn}。`], eHs);
    await K.say(p, "レイ", [`{sad,up}……${hn}。`, `{cry,tears,up}${hn}……！`], eHs);
    K.sound(p, "block.amethyst_block.hit", 0.5);
    await K.narr(p, ["§7三度。……石は、答えなかった。胸の 小さな 穴を、夕方の 風が 鳴らして いった。"], eHs);
    await K.csay(p, "shizuku", ["{sad,closed}……竜が 申します。この 石は、からっぽで ございますと。……体は ここに。でも、どこかへ 行って しまわれたと。"], eR);
    /* 手帳と コンパス */
    K.act(eS, "give"); K.hold(eS, "notebook");
    if (ok(eS)) await K.approach(p, eS, K.S(p) ? K.S(p).P : p.location, 1.8);
    await K.csay(p, "shizuku", ["{sad}……あの方の 腰に、これが。……あなたさまが お持ちに なるのが よいと、竜も 申します。"]);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7あなたは、紐で 巻いた §f旅の 手帳§7 と、針の 回りつづける §fコンパス§7 を 受け取った。", "§7コンパスを 首に、手帳を 腰に。"], eS);
    K.hold(eS);
    K.key(p, "k_hnote"); K.key(p, "k_compass");
    K.techo(p, hn);
    await K.narr(p, ["§7手帳を 開いた。名前の 頁の いちばん 上に、あなたと 相棒の 名前。……最後の 頁は、白紙の まま だった。", "§8『旅の 最後に、二人で 書こう』"]);   /*F30 強 */
    K.act(eR, "kneel");
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{cry,tears,up}……なんで、白紙なんだよ……。二人で 書くって、言ったんだろ……！"]);
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:heart_particle", 3, 0.4, 0.9); await K.up(p, g, 12); }
    await K.pal(p, ["……あの子の におい、まだ 手帳に のこってる。"]);
    K.rmCine(g);
    await K.csay(p, "shizuku", ["{closed,up}……竜は、その 名を 千年 守ります。", "{sad}あの日の 祭りで 一つ 消えた 灯り。……竜は、あの とき もう 数えなおして いたので ございます。"], eR);   /*F29 回 */
    /* ソラ（試しの 言葉）*/
    const eSo = K.cast(p, "sora"); K.act(eSo, "hold");
    if (ok(eSo) && ok(eR)) { await K.approach(p, eSo, eR, 2.2); K.turn(eSo, gq); }
    await K.csay(p, "sora", ["{closed}……竜骨の 城の 見張り台から、見て いた。……鱗の 墓標を 立てるのは、ひさしぶりだ。"], eR);
    K.turn(eSo); await K.push(p, eSo, 22, 4.2, 1.7);
    await K.csay(p, "sora", ["{closed,up}……竜は 教える。墓標に 名を 刻む 者は、自分の 足で 立って いられる 者で なければ ならない、と。", "{angry,up}名は 今日 刻んで いい。……立てるか どうかは、竜骨の 城 ラグナロクの 塔で 見せて くれ。"], eR);
    await K.say(p, "レイ", ["{angry,tears,up}……今かよ。こんな ときに。"], eSo);
    await K.csay(p, "sora", ["{closed}今じゃ ない。……泣き終わったら、来い。泣きながらでも いい。"], eR);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, [`§7あなたは 鱗に §f${hn}§7 と 刻んだ。`], gq);
    K.pay(p, E9, 5000, [["c_revive2", 2], ["x_ragna", 3]]);
    await K.end(p, { leave: [eSo, eS], bye: [eR, eHs], card: "§f― 第14章 竜骨の決戦 おわり ―\n§7→ 夜が 明けたら、エンドで（右上の 案内）", kind: "dusk", t: 60 });
    K.rmCine(dr);
    return true;
  } };

bkAdd("b14", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ21: 門〜祭壇の 13話を 順に（済んで いる 話は とばす）。全部 済んで いる 古い セーブは 条件なし */
mqOver(21, null, { cond: async () => true });
