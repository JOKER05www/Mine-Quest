/* 第126版 裏5「斬り跡・上」（ポカラの 丘／おがわの 里 リール）— 作業 UA。段なし（前27 の 自由な 話）*/
import { bkAdd, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, fac, facMark } from "./epfac.js";
import { ok } from "./ui.js";
import { UA } from "./bk_u01.js";
const { F, S1 } = FAC_OPS;

/* 斬り跡（地面の 細い 割れ目。底は 黒い 石。そばに 一輪の 花）*/
facAdd("u_crack", { D: [9, 11, 8], box: [-1, -5, 5, 5], H: 3, look: [2, 0, 0], marks: { crack: [2, 0, 0], flower: [4, 1, 0] }, build: (P) => [
  F(1, -4, -3, 2, 4, -1, "air"), F(1, -4, -4, 2, 4, -4, "deepslate"), F(0, -4, -1, 0, 4, -1, "cobbled_deepslate"), F(3, -4, -1, 3, 4, -1, "cobbled_deepslate"),
  S1(4, 1, 0, "poppy"), S1(4, -3, 0, P.plant || "short_grass"), S1(0, 4, 0, "dandelion"),
] });
/* 川辺の 斬り跡（川の 流れ・岸の 石・板の 橋・岸に 走る 割れ目）*/
facAdd("u_rivercrack", { D: [10, 12, 9], box: [-1, -6, 7, 6], H: 3, look: [3, 0, 0], marks: { crack: [2, -2, 0], bridge: [5, 0, 1] }, build: () => [
  F(4, -6, -1, 6, 6, -1, "water"), F(4, -6, -2, 6, 6, -2, "gravel"), F(3, -6, -1, 3, 6, -1, "stone"), F(7, -6, -1, 7, 6, -1, "stone"),
  F(4, 0, 0, 6, 1, 0, "spruce_slab"), F(1, -4, -3, 2, -1, -1, "air"), F(1, -4, -4, 2, -1, -4, "deepslate"), S1(2, 3, 0, "blue_orchid"), S1(1, 4, 0, "short_grass"),
] });

castAdd("u_pkid", { nm: "ポポ", role: "ポカラの 子", gobi: "", skin: "m6_sota", town: "t4", at: () => { const q = UA.bld("t4", ["plaza", "home"], "")(); return q ? { x: q.x + 2, z: q.z + 2 } : null; },
  hide: (s) => !bkHas(s, "u05e3"),
  after: [[() => true, ["{smile}あの 侍の 小さい 槌、ほしかったなあ。……でも 人は 叩かないって。じゃあ 何を 叩くんだろ？"]]] });
castAdd("u_rinn", { nm: "セキ", role: "リールの 宿の 主", gobi: "", skin: "m6_dario", town: "t3", at: () => { const q = UA.bld("t3", ["inn"], "")(); return q ? { x: q.x + 2, z: q.z } : null; },
  hide: (s) => !bkHas(s, "u05e7"),
  after: [[() => true, ["{smile}宿帳に あの 侍の 名、書いて やったよ。じっと 見て『細えな』だと。……字は、細い もんさ。"]]] });

const C1 = UA.out("crack1", "t4", 0.6, "ポカラの 丘の 割れ目");
const PKV = UA.bld("t4", ["plaza", "home", "shop"], "ひだまりの 村 ポカラ");
const C2 = UA.out("crack2", "t3", 0.6, "リールの 川辺の 斬り跡");
const RINN = UA.bld("t3", ["inn"], "おがわの 里 リールの 宿");
const crack = (K, p) => fac(K, p, "u_crack1", "u_crack", 0, UA.Y(K, p));
const river = (K, p) => fac(K, p, "u_crack2", "u_rivercrack", 0, UA.Y(K, p));
/* 残像（千年前の 人の 姿。煙の 中で 立ち、消える）*/
function ghost(K, p, q, nm, job) { const e = K.npcNear(p, nm, job, true); if (ok(e) && q) try { e.teleport({ x: q.x, y: q.y ?? e.location.y, z: q.z }); } catch {} if (ok(e)) K.burst(p.dimension, e.location, "minecraft:white_smoke_particle", 10, 0.6, 1); return e; }

bkAdd("u05", [
  { id: "u05e1", t: "斬った 音", place: C1, fac: "u_crack1", battles: 0,
    hint: "§fアルカトラス地方 §eひだまりの 村 ポカラの 丘§f の 割れ目へ 行こう §7（斬り跡 1）",
    syn: "ポカラの 丘の 割れ目。ムサシが 耳を 当てた。「斬った 音が、まだ 残ってる」。",
    async run(p, d, K) {
      const Q = crack(K, p);
      await K.open(p, "ポカラの 丘の 割れ目", "day");
      if (Q) await K.push(p, Q, 22, 6, 0.4);
      await K.narr(p, ["§7丘の 草の 中に、まっすぐな 細い 割れ目。§8刀で 一筋、地面を 引いた ような。"], Q);
      const eM = UA.mu(K, p, true);
      await UA.ear(K, p, eM, Q);
      await K.say(p, "ムサシ", ["{shock,…}……斬った 音が、まだ 残ってる。", "{closed}千年 前の 音だ。……地面が 覚えてやがる。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 割れ目から 何かが 立ち上がる（もう一度 割れ目へ）" });
      return true;
    } },
  { id: "u05e2", t: "花を かばう 形", place: C1, fac: "u_crack1", battles: 1,
    hint: "§fポカラの 丘の §e割れ目§f で、残像と 向き合おう",
    syn: "割れ目から 残像が 立ち上がり、戦いに なった。消える 前、残像は 花を 一輪 かばう 形を なぞった。",
    async run(p, d, K) {
      const Q = crack(K, p), fq = facMark("u_crack1", "flower", p.location);
      await K.open(p, "ポカラの 丘の 割れ目", "day");
      const eM = UA.mu(K, p, true);
      if (Q) K.burst(p.dimension, Q, "minecraft:white_smoke_particle", 14, 0.8, 1.2);
      await K.say(p, "ムサシ", ["{angry,!}……立った。残像だ。", "{closed}斬るんじゃ ねえ、止めるだけだ！ 行くぞ！"], null);
      const r = await K.battle(p, K.team(["nether", "beast", "nether"], 90, 3, 46), { name: "斬り跡の 残像（千年前）", arena: "丘の 割れ目", theme: "ruins", speaker: "残像", lines: { half: "……サセヌ……", low: "……ハナ……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……強え。一度 引く。", K.RT(p)], null); await K.end(p, { bye: [eM] }); return false; }
      const eG = ghost(K, p, fq ? { x: fq.x - 0.8, y: fq.y, z: fq.z } : null, "§7残像", K.PJ("m6_takeru", 8));
      if (fq) await K.push(p, fq, 22, 3.5, 0.5);
      K.act(eG, "kneel");
      await K.narr(p, ["§7消える 前に、残像は 一輪の 花の 上に 体を 丸めた。§8……斬撃から、花を かばう 形。"], fq || eG);
      if (ok(eG)) K.burst(p.dimension, eG.location, "minecraft:white_smoke_particle", 10, 0.5, 1);
      await K.say(p, "ムサシ", ["{closed,…}……斬った やつが、花を かばったのか。", "{?}何から 守ったんだ。"], null);
      K.pay(p, this, 1500, [["c_fruit", 2]]);
      await K.end(p, { leave: [eM], bye: [eG], card: "§7→ ポカラの 村で 一休み" });
      return true;
    } },
  { id: "u05e3", t: "人を 叩く もんじゃ ねえ", place: PKV, battles: 0,
    hint: "§fひだまりの 村 §eポカラ§f へ 行こう",
    syn: "ポカラの 村で、子どもが 聞き槌を ほしがった。ムサシ「これは 人を 叩く もんじゃ ねえ」。",
    async run(p, d, K) {
      await K.open(p, "ひだまりの 村 ポカラ", "day");
      const eK = K.cast(p, "u_pkid"), eM = UA.mu(K, p, true);
      await K.up(p, eK, 10);
      await K.csay(p, "u_pkid", ["{smile,☆}ねえ、その 小さい 槌 ちょうだい！", "{smile}それで 兄ちゃんの 頭 コンって したい！"], eM);
      K.act(eM, "no");
      await K.say(p, "ムサシ", ["{sweat}だめだ。これは 人を 叩く もんじゃ ねえ。", "{closed}物に 聞く 槌だ。人には、耳を 寄せる。"], eK);
      await K.csay(p, "u_pkid", ["{?}……耳？"], eM);
      K.act(eM, "kneel"); await K.wait(8);
      await K.say(p, "ムサシ", ["{smile}……ほら。おまえの 腹、鳴ってる。家に 帰れ。"], eK);
      K.act(eM, 0);
      await K.csay(p, "u_pkid", ["{shock,!}ほんとに 聞こえた！？ ……帰る！"], eM);
      await K.end(p, { leave: [eK, eM], card: "§7→ おがわの 里 リールの 川辺へ（斬り跡 2）" });
      return true;
    } },
  { id: "u05e4", t: "載らないでね", place: C2, fac: "u_crack2", F: ["F41"], battles: 0,
    hint: "§fアルカトラス地方 §eおがわの 里 リールの 川辺§f の 斬り跡へ 行こう",
    syn: "リールの 川辺の 斬り跡。サヤの 残像が 笑った。「兄さまの 帳に、わたしの 名前は 載らないでね」。",
    async run(p, d, K) {
      const Q = river(K, p), cq = facMark("u_crack2", "crack", p.location);
      await K.open(p, "リールの 川辺の 斬り跡", "day");
      if (Q) await K.at(p, Q, 14, 6, 1.4);
      const eM = UA.mu(K, p, true);
      await UA.ear(K, p, eM, cq);
      await K.past(p, "§7―― 昔");
      const eS = ghost(K, p, cq ? { x: cq.x + 1, y: cq.y, z: cq.z + 1 } : null, "§7残像の 娘", K.PJ("sakura", 9));
      await K.up(p, eS, 12);
      /*F41*/ await K.say(p, "サヤ", ["{smile}兄さまの 帳に、わたしの 名前は 載らないでね。", "{smile,♪}……ずっと 先まで。"], eM);
      if (ok(eS)) K.burst(p.dimension, eS.location, "minecraft:white_smoke_particle", 10, 0.5, 1);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{shock,…}……工房の 石の 娘だ。こんな 顔で 笑うのか。", "{closed}帳に 名が 載るのは、死んだ 時だろ。……載らないで、って。"], null);
      await K.end(p, { leave: [eM], bye: [eS], card: "§7→ 川辺に 残像が 立つ（もう一度 川辺へ）" });
      return true;
    } },
  { id: "u05e5", t: "川辺の 残像", place: C2, fac: "u_crack2", battles: 1,
    hint: "§fリールの §e川辺§f で 残像と 戦おう",
    syn: "川辺の 割れ目から 残像が あふれ、戦った。",
    async run(p, d, K) {
      const Q = river(K, p);
      await K.open(p, "リールの 川辺の 斬り跡", "day");
      const eM = UA.mu(K, p, true);
      if (Q) K.burst(p.dimension, Q, "minecraft:white_smoke_particle", 14, 0.8, 1.2);
      await K.say(p, "ムサシ", ["{angry}来るぞ。……川の 音に まぎれて、足音が しねえ。気を つけろ！"], null);
      const r = await K.battle(p, K.team(["nether", "golem", "nether"], 91, 3, 48), { name: "川辺の 残像（千年前）", arena: "リールの 川辺", theme: "ruins", speaker: "残像", lines: { half: "……カクナ……", low: "……カクナ……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……一度 引く。", K.RT(p)], null); await K.end(p, { bye: [eM] }); return false; }
      await K.say(p, "ムサシ", ["{closed}……「書くな」って 言ってた。何度も。", "{?}誰に 言ってたんだ。……王さまに か。"], null);
      K.pay(p, this, 1500, [["c_fruit", 2]]);
      await K.end(p, { leave: [eM], card: "§7→ リールの 宿で 休もう" });
      return true;
    } },
  { id: "u05e6", t: "字は 嘘を つかぬ", place: RINN, battles: 0,
    hint: "§fおがわの 里 §eリールの 宿§f で 休もう",
    syn: "宿で、ムサシと エンマが 言い合った。エンマ「字は 嘘を つかぬ」ムサシ「書いた やつは つく」。",
    async run(p, d, K) {
      await K.open(p, "リールの 宿（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      await K.narr(p, ["§7宿の 部屋。ムサシは 壁の 張り紙を にらんで いる。§8読めないのに。"], eM);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{rage,low}§4……『川で 遊ぶ ときは、大人と』。そう 書いて ある。"], null);
      await K.say(p, "ムサシ", ["{sweat}勝手に 読むな、エンマ。", "{closed}……書いて あるだけだろ。"], null);
      await K.say(p, "ムサシ", ["{rage,low}§4字は、嘘を つかぬ。"], null);
      await K.push(p, eM, 16, 3, 1.4);
      await K.say(p, "ムサシ", ["{angry,up}書いた やつは つく。", "{closed}……音は つかねえ。叩けば、中身の とおりに 鳴る。"], null);
      await K.say(p, "ムサシ", ["{rage,low}§4……小僧。だから われは、書かなかった。"], null);
      await K.say(p, "ムサシ", ["{shock}……何を。……おい、寝るな。……寝やがった。"], null);
      await K.end(p, { leave: [eM], kind: "night", card: "§7→ 朝" });
      return true;
    } },
  { id: "u05e7", t: "細い 字", place: RINN, battles: 0,
    hint: "§fリールの §e宿§f の 朝",
    syn: "朝、宿の 主が ムサシの 代わりに 宿帳に 名を 書いて くれた。ムサシは 書かれた 字を じっと 見て「……これが 俺か。細えな」。",
    async run(p, d, K) {
      await K.open(p, "リールの 宿の 朝", "day");
      const eI = K.cast(p, "u_rinn"), eM = UA.mu(K, p, true);
      await K.csay(p, "u_rinn", ["{smile}お侍さん、宿帳に 名前を。……あ、書けないのかい。じゃあ 言いな。", "{closed}む、さ、し、と。"], eM);
      K.sound(p, "item.book.page_turn", 0.7); K.hold(eI, "book");
      await K.give(eI, eM, "book");
      await K.push(p, eM, 18, 2.8, 1.4);
      await K.say(p, "ムサシ", ["{closed,…}……これが 俺か。", "{smile}細えな。"], eI);
      await K.say(p, "ムサシ", ["{closed}……書いた 名前は 信じねえ。けど、おまえの 口から 言って 書いたなら、まあ いい。"], eI);
      await K.end(p, { leave: [eM], bye: [eI], card: "§7→ 川を 渡って 次の 斬り跡へ" });
      return true;
    } },
  { id: "u05e8", t: "川を 渡る", place: C2, fac: "u_crack2", battles: 0,
    hint: "§fリールの §e川辺§f の 橋を 渡ろう",
    syn: "板の 橋で 川を 渡った。次の 斬り跡は、こもれびの 森。",
    async run(p, d, K) {
      const Q = river(K, p), bq = facMark("u_crack2", "bridge", p.location);
      await K.open(p, "リールの 川辺", "day");
      const eM = UA.mu(K, p, true);
      if (bq) { await K.walkCam(p, eM, bq, 20); await K.at(p, bq, 14, 5, 1.4); }
      await K.say(p, "ムサシ", ["{smile}……橋が 鳴る。古い けど、まだ 渡れる 音だ。", "{closed}森へ 行く。残像が、だんだん 近く なってる。"], null);
      await UA.zeph(K, p);
      await K.end(p, { leave: [eM], card: "§7→ シルヴァ大森林 §eこもれびの 森§7 の 斬り跡へ（右上の 案内）" });
      return true;
    } },
]);
