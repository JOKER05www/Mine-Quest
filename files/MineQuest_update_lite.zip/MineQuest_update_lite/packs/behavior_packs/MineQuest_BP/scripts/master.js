// モンスターマスター（NPCトレーナー）・石板ボス・ボスのけはい
import { world, system } from "@minecraft/server";
import { inRuins } from "./ruinsarea.js";
import { SPECIES, ORDER, FAMILIES, ITEMS } from "./data.js";
import { ri, pick } from "./core.js";
import { load, save } from "./store.js";
import { busy, ok, sound, particle, choose, notice, ICON, MON_ICON, isLite, rankOf, warming, barNote, setJob } from "./ui.js";
import { TYPE, setLook, hBucket, biomeAt, hooks, SIZE_UP, sizeUp } from "./field.js";
import { townAt, siteOf, getRuin, REGION, groundY, ruinBlocked, TOWNS, townPos } from "./structures.js";
import { startBattle } from "./battle.js";
import { rankCap } from "./quest.js";

const NPC = "mrpg:npc";
const DIMS = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];
const RI = ["F", "E", "D", "C", "B", "A", "S", "SS"];
const NOFAM = new Set(["king", "god"]);
export const MASTER_TIER = ["ルーキー", "ベテラン", "チャンピオン"];
const MASTER_COL = ["§a", "§b", "§6"];
const NAMES = ["レン", "カイ", "ミオ", "ソラ", "ユウ", "ハル", "リク", "ナギ", "アオイ", "トウマ", "シズク", "ヒナタ", "ジン", "コハク", "セナ", "ルカ", "ツバキ", "イブキ", "サクヤ", "クオン", "ヨミ", "アマネ", "ライ", "シオン"];
const LINES = [
  ["きみも モンスターマスター？ 一緒に 強く なろう！", "初めての 勝負だ！ よろしくね！", "負けないぞー！"],
  ["その めつき…… ただものじゃないな。", "わたしの 仲間たちは 育てかたが 違うよ。", "うでだめしと いこうか。"],
  ["ここまで きたか。チャンピオンの 力 見せてやろう。", "厳選に 厳選を かさねた 最強の チームだ。", "伝説の 始まりに なるのは どちらかな。"],
];
const famsNoKing = () => FAMILIES.map((f) => f.id).filter((f) => !NOFAM.has(f));
const famName = (id) => FAMILIES.find((f) => f.id === id)?.name.replace("系", "") || "";
const RCAP = (d) => { try { return Math.max(1, Math.min(7, rankCap(d))); } catch { return 7; } };
const rankIdx = (sid) => { const i = RI.indexOf(SPECIES[sid].rank); return i < 0 ? 7 : i; };

export function masterInfo(e) {
  try { const v = e.getDynamicProperty("mrpg:master"); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; }
}
const setInfo = (e, v) => { try { e.setDynamicProperty("mrpg:master", JSON.stringify(v)); } catch {} };
export const masterTitle = (info) => `${MASTER_COL[info.tier]}${MASTER_TIER[info.tier]}§f ${famName(info.fam)}使いの ${info.name}`;

// こちらの パーティの ランクと レベルに あわせて チームを 作る
export function masterTeam(d, tier, fav) {
  const best = Math.max(...[...d.party, ...(d.bench || [])].map((m) => rankIdx(m.sp)));
  const avg = (() => { const L = [...d.party, ...(d.bench || [])].map((m) => m.lv || 1).sort((a, b) => b - a).slice(0, 3); return Math.round(L.reduce((a, b) => a + b, 0) / Math.max(1, L.length)); })();   /* 第69版: 表と 裏の 上位3体の 平均 */
  const n = [ri(2, 3), 3, ri(3, 4)][tier];
  const off = [[-2, -1, -1, 0], [-1, 0, 0, 1], [0, 0, 1]][tier];
  const team = [];
  for (let i = 0; i < n; i++) {
    let r = Math.max(0, Math.min(7, best + pick(off)));
    if (tier === 2 && i === 0) r = Math.min(7, best + 1); // エース
    r = Math.min(r, RCAP(d));   // v2.9.7: 物語の 進みより 上の ランクは 出さない
    let pool = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].rank === RI[r] && SPECIES[s].fam === fav);
    if (!pool.length || Math.random() < 0.35) pool = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].rank === RI[r] && !NOFAM.has(SPECIES[s].fam));
    const lv = Math.max(1, Math.min(100, avg + [ri(-4, 0), ri(0, 3), ri(3, 8)][tier] + (i === 0 ? 1 : 0)));
    team.push({ sid: pick(pool), lv, q: [0.3, 0.55, 0.85][tier] + (i === 0 ? 0.1 : 0) });
  }
  return team;
}

function chooseTier(d) {
  const w = (d.stats && d.stats.masters) || 0;
  const r = Math.random();
  if (w >= 10 && r < 0.3) return 2;
  if (w >= 3 && r < 0.55) return 1;
  return 0;
}

// ---------- ライバル（いちど 戦った マスター）の きろく ----------
export function recordRival(d, m, won) {
  if (!m || m.arena || !m.name) return;
  d.rivals = d.rivals || {};
  const r = d.rivals[m.name] || { fam: m.fam, tier: m.tier, w: 0, l: 0 };
  r.fam = m.fam || r.fam; r.tier = Math.max(r.tier || 0, m.tier || 0);
  if (won) r.w++; else r.l++;
  d.rivals[m.name] = r;
  const keys = Object.keys(d.rivals);
  if (keys.length > 20) delete d.rivals[keys[0]];
}
const REVENGE = [
  ["{p}！ このまえの リベンジだ！ {f}たちと とっくんしてきたんだから！", "待ってたよ、{p}。こんどこそ 負けないからね！", "あのときの 負け、ずっと くやしかったんだ…！"],
  ["また あったね、{p}。きみに 負けてから ねむれない ひが つづいたよ。", "{p}…！ きみを 倒す ために ここまで きた！", "これで {n}かいめの 勝負だね。そろそろ かたせて もらうよ！"],
  ["ふっ、{p}か。きみとの 勝負は いつも むねが あつくなる。", "チャンピオンに なった わたしを 見てくれ、{p}！", "{n}かいめの 再戦だ。ほんきで いくぞ！"],
];
const GLOAT = ["また きたのか {p}。このまえと 同じ けっかに なるだけさ。", "ふふ、{p}。リベンジ かい？ 受けて たとう！", "まだ あきらめて ないんだね、{p}。いいね、そういうの すきだよ。"];
export function rivalLine(d, info, pname) {
  const r = (d.rivals || {})[info.name];
  if (!r) return null;
  const n = r.w + r.l + 1;
  const t = r.w >= r.l ? pick(REVENGE[info.tier]) : pick(GLOAT);
  return t.replace(/\{p\}/g, pname).replace(/\{f\}/g, famName(info.fam)).replace(/\{n\}/g, String(n));
}

// ---------- マスターランキング（ワールド共通） ----------
export function loadMRank() { try { const v = world.getDynamicProperty("mrpg:mrank"); return typeof v === "string" ? JSON.parse(v) : {}; } catch { return {}; } }
export function addMasterRank(name, d) {
  const r = loadMRank();
  const s = d.story || {};
  r[name] = { pt: d.mpt || 0, cup: Math.min(8, s.cup || 0), crown: !!s.final, w: (d.stats && d.stats.masters) || 0 };
  const keys = Object.keys(r);
  if (keys.length > 60) { keys.sort((a, b) => r[a].pt - r[b].pt); delete r[keys[0]]; }
  try { world.setDynamicProperty("mrpg:mrank", JSON.stringify(r)); } catch {}
}
export function mrankText() {
  const r = Object.entries(loadMRank()).sort((a, b) => (b[1].crown - a[1].crown) || b[1].cup - a[1].cup || b[1].pt - a[1].pt).slice(0, 10);
  if (!r.length) return "§7まだ きろくが ありません。フィールドの モンスターマスターに かとう！";
  return ["§l§eマスターランキング", "§7（星冠 → カップ → マスターポイント の じゅん）", "", ...r.map(([n, v], i) => `${i < 3 ? ["§6", "§f", "§c"][i] : "§7"}${i + 1}い §f${v.crown ? "§6★星冠王 §f" : ""}${n}  §eカップ${v.cup}/8  §b${v.pt}pt  §7${v.w}しょう`)].join("\n");
}

export function spawnMaster(p, d) {
  const dim = p.dimension;
  for (let k = 0; k < 6; k++) {
    const a = Math.random() * Math.PI * 2, r = 14 + Math.random() * 8;
    const x = p.location.x + Math.cos(a) * r, z = p.location.z + Math.sin(a) * r;
    if (townAt({ x, z }, 60) || hooks.inTown({ x, z }, dim.id) || (hooks.noSpawn && hooks.noSpawn(p))) continue;   // v2.9.12: 城・石板の 中にも 出さない
    const y = groundY(dim, x, z, Math.floor(p.location.y));
    if (y === null) continue;
    let tier = chooseTier(d);
    const rv = Object.entries(d.rivals || {});
    let info;
    if (rv.length && Math.random() < 0.35) {
      // ライバルが リベンジに くる（負けるたびに 強くなる）
      const [name, r] = pick(rv);
      tier = Math.min(2, Math.max(tier, r.tier + (r.w >= 2 ? 1 : 0)));
      info = { tier, name, fam: r.fam, until: Date.now() + 5 * 60 * 1000, owner: p.id, rival: true };
    } else {
      const free = NAMES.filter((n) => !(d.rivals || {})[n]);
      info = { tier, name: pick(free.length ? free : NAMES), fam: pick(famsNoKing()), until: Date.now() + 5 * 60 * 1000, owner: p.id };
    }
    let e;
    try { e = dim.spawnEntity(NPC, { x: Math.floor(x) + 0.5, y, z: Math.floor(z) + 0.5 }); } catch { continue; }
    try { setJob(e, 8 + tier); } catch {}
    e.addTag("mrpg_master");
    setInfo(e, info);
    e.nameTag = `${masterTitle(info)}\n§7話しかけて 勝負`;
    p.sendMessage(info.rival ? `§d◆ ライバル ${masterTitle(info)}§d が リベンジに 現れた！ §7（${dirText(p.location, e.location)}）` : `§b◆ モンスターマスター ${masterTitle(info)}§b が 勝負を 待っている！ §7（${dirText(p.location, e.location)}）`);
    sound(p, "note.pling", 1.4);
    return true;
  }
  return false;
}

// 30びょうごとに 出現チェック・おそうじ
system.runInterval(() => {
  const players = world.getAllPlayers();
  for (const id of DIMS) {
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: NPC, tags: ["mrpg_master"] }); } catch {}
    for (const e of list) {
      const info = masterInfo(e);
      const near = players.some((p) => p.dimension.id === id && Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) < 96);
      if (!info || (info.until < Date.now() && !info.fighting) || !near) { try { particle(e, "minecraft:white_smoke_particle"); e.remove(); } catch {} }
    }
  }
  for (const p of players) {
    if (warming() || busy.has(p.id) || p.dimension.id !== "minecraft:overworld" || Math.random() > 0.15) continue;
    if (townAt(p.location, 60) || inRuins(p.location)) continue;   /* 第76版: 滅びた 世界には マスターは いない */
    const d = load(p);
    if (!d || !d.party.length) continue;
    let near = [];
    try { near = p.dimension.getEntities({ type: NPC, tags: ["mrpg_master"], location: p.location, maxDistance: 80 }); } catch {}
    if (near.length) continue;
    spawnMaster(p, d);
  }
}, 600);

// 話しかけた とき（menu から）。戦うなら true
export async function masterTalk(p, d, e) {
  const info = masterInfo(e);
  if (!info) return false;
  if (!info.team) { info.team = masterTeam(d, info.tier, info.fam); setInfo(e, info); }
  const stars = info.team.map((t) => SPECIES[t.sid].rank).join(" ");
  const prize = [`マスターポイント${1 + (info.rival ? 1 : 0)}・ゴールド×3・まれに どうの石板`, `マスターポイント${2 + (info.rival ? 1 : 0)}・ゴールド×4・時々 ぎんの石板`, `マスターポイント${4 + (info.rival ? 1 : 0)}・ゴールド×5・きんの石板・ごくまれに 王/神のタマゴ`][info.tier];
  const s = await choose(p, `モンスターマスター`, [
    `§l${masterTitle(info)}`,
    `§f「${rivalLine(d, info, p.name) || pick(LINES[info.tier])}」`,
    ...((d.rivals || {})[info.name] ? [`§d（ライバル: これまで ${d.rivals[info.name].w}しょう ${d.rivals[info.name].l}はい）`] : []),
    "",
    `§7てもち: ${info.team.length}たい  ランク §e${stars}`,
    `§7報酬: ${prize}`,
    "§7※ マスターの モンスターも スカウトできる（少し むずかしい）。逃げられない。",
  ].join("\n"), [["§l§c勝負する！", ICON("i_fight")], ["§7やめておく", ICON("i_back")]]);
  return s === 0;
}

export async function challengeMaster(p, npc) {
  if (!ok(npc) || busy.has(p.id)) return;
  const info = masterInfo(npc);
  if (!info || !info.team) return;
  const P = p.location, N = npc.location;
  let dx = P.x - N.x, dz = P.z - N.z; const len = Math.hypot(dx, dz) || 1; dx /= len; dz /= len;
  const pos = { x: N.x + dx * Math.min(3, len * 0.45), y: N.y, z: N.z + dz * Math.min(3, len * 0.45) };
  const lead = info.team[0];
  let e;
  try { e = npc.dimension.spawnEntity(TYPE, pos); } catch { return; }
  setLook(e, lead.sid);
  e.triggerEvent("mrpg:make_battle");
  e.addTag("mrpg_masterteam");
  e.setDynamicProperty("mrpg:lv", lead.lv);
  e.setDynamicProperty("mrpg:q", lead.q);
  e.setDynamicProperty("mrpg:team", JSON.stringify(info.team));
  e.setDynamicProperty("mrpg:mref", JSON.stringify({ tier: info.tier, name: info.name, fam: info.fam, npc: npc.id, rival: !!info.rival }));
  particle(e, "minecraft:knockback_roar_particle", 1);
  info.fighting = true; setInfo(npc, info);
  try { await startBattle(p, e); } finally {
    if (ok(npc)) { const i2 = masterInfo(npc); if (i2) { i2.fighting = false; i2.until = Math.max(i2.until, Date.now() + 60 * 1000); setInfo(npc, i2); } }
    if (ok(e)) try { e.remove(); } catch {}
  }
}

// バトルで かったとき（battle から よばれる）
export function masterDefeated(npcId, dim, pName) {
  let list = [];
  try { list = dim.getEntities({ type: NPC, tags: ["mrpg_master"] }); } catch {}
  const e = list.find((x) => x.id === npcId);
  if (!e) return;
  const info = masterInfo(e);
  for (const q of world.getAllPlayers()) if (q.dimension.id === dim.id && Math.hypot(q.location.x - e.location.x, q.location.z - e.location.z) < 32)
    q.sendMessage(`§b${info ? info.name : "マスター"}「${pName}、きみの 勝ちだ！ また どこかで 勝負しよう！」`);
  system.runTimeout(() => { if (ok(e)) { particle(e, "minecraft:totem_particle", 1); try { e.remove(); } catch {} } }, 60);
}

// ---------- 石板 ----------
export const SLAB_NAME = ["どうの石板", "ぎんの石板", "きんの石板", "にじの石板"];
const SLAB_LV = [2, 5, 8, 12];
export function spawnSlabBoss(p, d, t, fam) {
  let rank = RI.indexOf(["B", "A", "S", "SS"][t]);
  if (Math.random() < 0.1) rank = Math.min(7, rank + 1);
  const f = fam && !NOFAM.has(fam) ? fam : pick(famsNoKing());
  let pool = ORDER.filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && SPECIES[s].rank === RI[rank] && SPECIES[s].fam === f);
  if (!pool.length) pool = ORDER.filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && SPECIES[s].rank === RI[rank] && !NOFAM.has(SPECIES[s].fam));
  const sid = pick(pool);
  const avg = (() => { const L = [...d.party, ...(d.bench || [])].map((m) => m.lv || 1).sort((a, b) => b - a).slice(0, 3); return Math.round(L.reduce((a, b) => a + b, 0) / Math.max(1, L.length)); })();   /* 第69版: 表と 裏の 上位3体の 平均 */
  const lv = Math.max(5, Math.min(100, avg + SLAB_LV[t]));
  const yaw = (p.getRotation().y * Math.PI) / 180;
  const x = p.location.x - Math.sin(yaw) * 6, z = p.location.z + Math.cos(yaw) * 6;
  const y = groundY(p.dimension, x, z, Math.floor(p.location.y)) ?? Math.floor(p.location.y);
  const e = p.dimension.spawnEntity(TYPE, { x, y, z });
  e.addTag("mrpg_boss"); e.addTag("mrpg_slab");
  setLook(e, sid);
  const bk = SPECIES[sid].mh > 3 ? 1.15 : 1.5;
  const bsz = Math.min(2250, Math.floor(SPECIES[sid].size * bk * sizeUp(SPECIES[sid].sz)));   /* 第81版: 1.5倍 */
  e.setProperty("mrpg:size", bsz);
  e.setDynamicProperty("mrpg:bsize", bsz);
  e.triggerEvent("mrpg:make_battle");
  e.triggerEvent(`mrpg:size_h${hBucket(SPECIES[sid].mh * bk * sizeUp(SPECIES[sid].sz))}`);
  e.setDynamicProperty("mrpg:lv", lv);
  e.setDynamicProperty("mrpg:slab", t);
  e.setDynamicProperty("mrpg:q", [0.6, 0.72, 0.85, 0.95][t]);
  e.setDynamicProperty("mrpg:raidUntil", Date.now() + 10 * 60 * 1000);
  e.nameTag = `§d【石板ボス】§f${SPECIES[sid].name} §7Lv${lv} ${rankOf(sid)}`;
  for (const q of world.getAllPlayers()) {
    if (q.dimension.id !== p.dimension.id || Math.hypot(q.location.x - x, q.location.z - z) > 64) continue;
    q.sendMessage(`§d§l【石板】§r§d ${p.name}が ${SLAB_NAME[t]}を かかげた！ §f${SPECIES[sid].name}（${SPECIES[sid].rank}）§d が 現れた！ 殴って さんせんしよう（10ぷん）`);
    sound(q, "mob.evocation_illager.prepare_summon", 1);
  }
  return e;
}

// 石板ボスの 時間ぎれ
system.runInterval(() => {
  for (const id of DIMS) {
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_slab"] }); } catch {}
    for (const e of list) { const u = e.getDynamicProperty("mrpg:raidUntil"); if (typeof u === "number" && u < Date.now() && !e.hasTag("mrpg_battle")) { try { e.remove(); } catch {} } }
  }
}, 400);

// ---------- ボスの 気配（アクションバー） ----------
const DIR8 = ["みなみ", "なんせい", "にし", "ほくせい", "きた", "ほくとう", "ひがし", "なんとう"];
function dirText(from, to) {
  const a = Math.atan2(-(to.x - from.x), to.z - from.z); // minecraft yaw 0 = 南(+z)
  const i = ((Math.round((a * 180) / Math.PI / 45) % 8) + 8) % 8;
  return `${DIR8[i]} ${Math.round(Math.hypot(to.x - from.x, to.z - from.z))}m`;
}
function relArrow(p, to) {
  const yaw = p.getRotation().y;
  const want = (Math.atan2(-(to.x - p.location.x), to.z - p.location.z) * 180) / Math.PI;
  const d = ((((want - yaw) % 360) + 540) % 360) - 180;
  const ar = ["↑", "右↑", "→", "右↓", "↓", "左↓", "←", "左↑"];
  return ar[((Math.round(d / 45) % 8) + 8) % 8];
}
// v2.9.12: 遺跡を 作らない 場所の 判定は おぼえて おく（毎回 しらべると 重い）
const BLKC = new Map();
function blockedC(dimId, s) { if (BLKC.size > 400) { const now = Date.now(); for (const [k0, v0] of BLKC) if (now - v0[1] > 120000) BLKC.delete(k0); }   /* 第63版: 古い 記録を すてる */
  const k = s.key, c = BLKC.get(k); if (c && Date.now() - c[1] < 120000) return c[0]; const v = ruinBlocked(dimId, s) || (dimId === "minecraft:overworld" && TOWNS.some((t) => { const q = townPos(t); return Math.hypot(q.x - s.x, q.z - s.z) < 140; })); if (BLKC.size > 2000) BLKC.clear(); BLKC.set(k, [v, Date.now()]); return v; }
system.runInterval(() => {
  const BC = {};   // 第63版: ボスの 一覧は ディメンションごとに 1回だけ しらべる
  for (const p of world.getAllPlayers()) {
    if (busy.has(p.id)) continue;
    const L = p.location;
    let best = null, bd = 1e9, kind = "";
    try {
      const did = p.dimension.id; if (!BC[did]) { BC[did] = []; try { BC[did] = p.dimension.getEntities({ type: TYPE, tags: ["mrpg_boss"] }); } catch {} }
      for (const e of BC[did]) {
        let ok3 = false; try { ok3 = e.isValid() && Math.hypot(e.location.x - L.x, e.location.z - L.z) <= 300; } catch {} if (!ok3) continue;
        const dd = Math.hypot(e.location.x - L.x, e.location.z - L.z);
        if (dd < bd) { bd = dd; best = e.location; kind = e.hasTag("mrpg_slab") ? "石板ボス" : e.hasTag("mrpg_raid") ? "レイドボス" : "ボス"; }
      }
    } catch {}
    const R = REGION[p.dimension.id];
    if (R) {
      const rx0 = Math.floor(L.x / R), rz0 = Math.floor(L.z / R);
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const s = siteOf(p.dimension.id, rx0 + dx, rz0 + dz);
        const r = getRuin(s.key);
        if (r && (r.skip || (r.cleared && (!r.by || r.by.includes(p.id))))) continue;
        if (!r && blockedC(p.dimension.id, s)) continue;   // v2.9.12: できない 遺跡は 指さない
        const dd = Math.hypot(s.x - L.x, s.z - L.z);
        if (dd < 300 && dd < bd) { bd = dd; best = { x: s.x, z: s.z }; kind = r ? "遺跡の ボス" : "みしらぬ 遺跡"; }
      }
    }
    try {
      let master = null;
      for (const e of p.dimension.getEntities({ type: NPC, tags: ["mrpg_master"], location: L, maxDistance: 60 })) master = e;
      if (master && (!best || Math.hypot(master.location.x - L.x, master.location.z - L.z) < bd)) {
        barNote(p).setActionBar(`§b◆ モンスターマスター ${relArrow(p, master.location)} §f${dirText(L, master.location)}`);
        continue;
      }
    } catch {}
    if (!best || bd < 6) continue;
    const heat = bd < 60 ? "§c§l" : bd < 150 ? "§c" : "§7";
    try { barNote(p).setActionBar(`${heat}◆ ${kind}の 気配 ${relArrow(p, best)} §f${dirText(L, best)}`); } catch {}
  }
}, 40);

// レア・いろちがいの オーラ
system.runInterval(() => {
  if (isLite()) return;
  for (const p of world.getAllPlayers()) {
    let list = [];
    try { list = p.dimension.getEntities({ type: TYPE, location: p.location, maxDistance: 32, excludeTags: ["mrpg_pet", "mrpg_battle"] }); } catch {}
    for (const e of list) {
      if (e.hasTag("mrpg_shiny")) particle(e, "minecraft:totem_particle", 1.2);
      else if (e.hasTag("mrpg_rare") || e.hasTag("mrpg_slab")) particle(e, "minecraft:villager_happy", 1.4);
    }
  }
}, 30);
