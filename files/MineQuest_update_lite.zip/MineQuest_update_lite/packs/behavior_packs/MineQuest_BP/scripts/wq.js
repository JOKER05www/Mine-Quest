/* 第125版: 世界の 依頼（町の 名前の ある 人に 話しかけると 始まる 寄り道。物語に つながる 話）
   ■ 依頼を 足す 方法（地方ごとに wq_r地方.js に 書き、wqs.js に import を 1行 足す）
     import { wqAdd, G, wqPlace, wqStand } from "./wq.js";
     wqAdd(地方の 番号, [依頼, ...]);
   ■ 依頼の 形
     { id: "wq0a",            一度 出したら かえない（セーブに 残る）。ほかと かぶらない
       t: "題",               ガイドブックと 始まりの 札
       npc: "wq0kabu",        依頼主（cast.js の 人の id）。cast を 書けば wqAdd が castAdd する（町に 立つのは 門が 開いた あとだけ）
       cast: { nm, role, gobi, skin, town, at },   gobi（語尾・口ぐせ）は 必ず
       gate: (s, d) => 真偽,  門。物語の どこまで 進めば 出るか（下の G を 使う）。門が 開くまで 人も「！」も 出ない（ネタバレ 防ぎ）
       need: ["wq0a"],        先に 済ませる 依頼（つづきの 話・闘魔の 腕輪の 連作など）
       tier: "小" | "中" | "大",  ほうびの 格（下の TIER）。pay: { g, items: [[道具の id, 数]] } で 中身を 決める（1回だけ。人ごと）
       hint: "ガイドブックの 一行（どこで・何を）",
       ask: ["頼む ときの せりふ"], wait: ["とちゅうで 話しかけた ときの せりふ"], after: ["済んだ あとの せりふ"],
       link: "本編との つながり（文には 出ない。点検用）",
       steps: [ 段, ... ] }   2〜4段。戦いは 依頼 全体で 2回まで
   ■ 段の 形
     { at: "npc"（依頼主に 話しかける。1段目は いつも これ）| "npc:キャストid"（別の 人）| (p) => ({ x, z, nm })（その 場所で 立ち止まる）,
       hint: "右上の 案内の 文",
       nm: "場面の 始まりの 場所の 名前",
       play: [ 台本の 行, ... ]  か  run: async (p, d, K, C) => true（済み）／false（負け・あとで） }
   ■ 台本の 行（play）: カメラの 決まり（2行ごとに 切りかえ・歩いて 出入り・終わりは 引き）は K の 部品が 守る
     ["open", "day"|"dusk"|"night"|"fest"|"ash"]   始まりの 引きの 絵（場所の 名前は 段の nm か 依頼主の 町）
     ["in", "キャストid" | "hero", ...]           歩いて 来る（hero は 旅の 仲間。石に なって いる 間は 来ない）
     ["キャストid", ["せりふ", ...]]                その 人が 話す（2行ごとに 聞き手の 顔へ）
     ["h", 元気, おっとり, クール, ていねい, 相棒]   旅の 仲間の 4つの 話し方（文字列 か 配列）。仲間が いない ときは 相棒（5つ目）が 話す
     ["x", "かぎ", "§7名札", 職業]  名前の ない 人を 歩かせて 呼ぶ ／ ["say", "名札の 名前", ["せりふ"]]
     ["hold", "かぎ", "小道具"]（手に 持つ。hold.js の 名前・"" で 空）／ ["give", "わたす かぎ", "受け取る かぎ"|null, "小道具"]（両手を 前へ → 受け取る 人が 持つ）
     ["n", ["地の文"]]  ／ ["act", "かぎ", "しぐさ"] ／ ["up"|"low", "かぎ"] ／ ["two", "かぎ", "かぎ"] ／ ["wide"]
     ["mon", "かぎ", "系統", 前, 横]   見せる だけの 野生（戦いの 前に 煙で 消える）
     ["fight", { fams: [...], lv, n, name, theme, boss, speaker, lines }]   戦い（勝ったら 印。抜けて 入りなおしても くり返さない。負けたら この 段は 済まない）
     ["end", ["去る かぎ"], "最後の 札"]   終わりの 引きの 絵（セリフと 画面を 消す）
     async (p, K, C) => {...}   そのほかの 演出（false を 返すと 段は 済まない）。C.E は 場面の 人
   ■ 門（G）: 第126版は G.bk("b08")（第8章に 入った）・G.bk("b08e7")（その 話を 済ませた）を 使う。前の 版の G.ep("r0e2")（地方の 話を 済ませた）・G.mq(地方, k)（地方の k番目の 段を 越えた）・G.seal(n)・G.flag("epx の 印")・G.wq("依頼の id")・G.end（エンディング後）・G.all(...)
   ■ 場所: wqPlace(町の id, 半径, "名前", "かぎ")（町の 外れ。ほかの 町・城・物語の 場所から はなれた 平らな 向き）／ wqStand(町の id, "inn", dx, dz)（人の 立つ 所）
   ■ 記録（人ごと）: s.wq[id] = 済んだ 段の 数（ない = まだ）・s.wqPaid[id] = ほうびを わたした・s.wqPick = 右上に 出す 依頼・s.wqPin = 自分で えらんだ・s.wqSpot = 段の 場所
   ■ ほかの 仕組みから: wqDone(s, id)・wqState(s, d, q) ("lock" "open" "on" "done")・wqPay(p, d, q)・WQ・WQR */
import { world, system, MolangVariableMap } from "@minecraft/server";
import { SGK, MQ, GOAL_HOOKS, KEYSRC } from "./saga.js";
import { ITEMS } from "./data.js";
import { STORY_EXTRA } from "./story.js";
import { qs } from "./quest.js";
import { load, save } from "./store.js";
import { ok, busy, choose, ICON, sound } from "./ui.js";
import { stageBegin } from "./stagecore.js";
import { K, epDone } from "./sagaep.js";
import { CAST, castAdd, castTag, __cast } from "./cast.js";
import { NPC_HOOKS } from "./npchook.js";
import { TOWNS, getTown, townPos, castleSpot } from "./structures.js";
import { spotOf, placeOf } from "./storyplace.js";
import { regionIdx, WREGIONS } from "./worldmap.js";
import { canFight } from "./core.js";
import { WQN, WLG, WLB, WHY, FRAG, TECHO } from "./wqlore.js";   /* 第125版: 記録の 断片・頼む わけ・本編の 回収 */
import { fac, facAt, wqKind, facKind, facSwap } from "./epfac.js";
import { bkHas } from "./bkeng.js";   /* 第126版: 門は 本の 話の 済み印 */
import { BKID } from "./book.js";

/* ---------- 登録 ---------- */
export const WQ = {}, WQR = {};
const BYNPC = {}, OWN = new Set();   /* OWN: wqAdd が castAdd した 人（用が ない ときも 依頼の 話を する）*/
export const TIER = { "小": { g: 300, items: [["SEED2", 1]] }, "中": { g: 800, items: [["e_silver", 1], ["SEED3", 1]] }, "大": { g: 1500, items: [["i_awaken", 1]] } };
const TIER_TX = { "小": "§aほうび: 小", "中": "§bほうび: 中（めずらしい タマゴ・秘果・スキル書）", "大": "§6§lほうび: 大（とびきり 豪華）" };
export function wqAdd(r, list) {
  const L = WQR[r] || (WQR[r] = []);
  for (const q0 of list) {
    if (!q0 || !q0.id || WQ[q0.id] || !Array.isArray(q0.steps) || !q0.steps.length) { console.warn(`[MonsterRPG] wq: 同じ id か 段なし ${q0 && q0.id}`); continue; }
    const q = { r, tier: "小", gate: () => true, ...q0 }; WQ[q.id] = q; L.push(q); WQN[q.id] = q.steps.length;
    (BYNPC[q.npc] || (BYNPC[q.npc] = [])).push(q);
    if (q.cast && !CAST[q.npc]) OWN.add(q.npc);
    if (q.cast && !CAST[q.npc]) { const w = q.cast.at && q.cast.at.wqs, at = w && w.k === "inn" ? wqStand(w.tid, roleKinds(q.cast.role, w.dx), w.dx, w.dz) : q.cast.at; castAdd(q.npc, { ...q.cast, at, hide: (s, d) => !npcSeen(s, d, q.npc), pre: q.ask || ["……"] }); }
  }
}
/* ---------- 門 ---------- */
const regIdx = (r) => { const o = []; MQ.forEach((x, i) => { if (x.r === r) o.push(i); }); return o; };
/* 第126版: G.bk("b08") = 第8章に 入った（b08e1 が 済んだ）／G.bk("b08e7") = その 話が 済んだ。本編は エンディング後なら 全部 開く */
const BK1 = (c) => (/e\d+$/.test(c) ? c : `${c}e1`);
const BKLAST = {}; for (const id of BKID) BKLAST[id.slice(0, 3)] = id;
export const bkPast = (s, c) => { if (!s || !c) return false; if (c[0] === "b" && s.ending) return true; try { return bkHas(s, /e\d+$/.test(c) ? c : BKLAST[c] || c); } catch { return false; } };   /* その 章を 終えた */
export const G = {
  bk: (c) => (s) => { if (!s) return false; if (c[0] === "b" && s.ending) return true; try { return bkHas(s, BK1(c)); } catch { return false; } },
  ep: (id) => (s, d) => epDone(d, id),
  mq: (r, k) => (s) => { if (s.ending) return true; const L = regIdx(r); const i = L[Math.min(k, L.length - 1)]; return i !== undefined && (s.mq ?? 0) > i; },
  seal: (n) => (s) => !!s.ending || (s.bsg || []).includes(n),
  flag: (k) => (s) => !!(s.epx || {})[k],
  wq: (id) => (s) => wqDone(s, id),
  end: (s) => !!s.ending,
  all: (...f) => (s, d) => f.every((g) => g(s, d)),
};
/* ---------- 記録 ---------- */
const W = (s) => (s.wq && typeof s.wq === "object" && !Array.isArray(s.wq) ? s.wq : (s.wq = {}));
const WP = (s) => (s.wqPaid && typeof s.wqPaid === "object" && !Array.isArray(s.wqPaid) ? s.wqPaid : (s.wqPaid = {}));
export const wqStep = (s, id) => { const v = (s.wq || {})[id]; return typeof v === "number" ? v : -1; };
export const wqDone = (s, id) => { const q = WQ[id]; return !!q && wqStep(s, id) >= q.steps.length; };
export function wqOpen(s, d, q) { try { if (q.need && !q.need.every((x) => wqDone(s, x))) return false; return !!q.gate(s, d); } catch { return false; } }
export function wqState(s, d, q) { const k = wqStep(s, q.id); if (k >= q.steps.length) return "done"; if (k >= 0) return "on"; return wqOpen(s, d, q) ? "open" : "lock"; }
const whoOf = (q, k) => { const a = q.steps[k] && q.steps[k].at; return !a || a === "npc" ? q.npc : typeof a === "string" && a.startsWith("npc:") ? a.slice(4) : null; };
function npcSeen(s, d, npc) { for (const q of BYNPC[npc] || []) if (wqState(s, d, q) !== "lock") return true; for (const q of Object.values(WQ)) { const k = wqStep(s, q.id); if (k >= 0 && k < q.steps.length && whoOf(q, k) === npc) return true; } return false; }
/* その 人に 今 話しかけると 動く 依頼（なければ null）*/
function npcQuest(s, d, npc) {
  for (const q of Object.values(WQ)) { const k = wqStep(s, q.id); if (k >= 0 && k < q.steps.length && whoOf(q, k) === npc) return q; }
  for (const q of BYNPC[npc] || []) if (wqState(s, d, q) === "open") return q;
  return null;
}
export function wqPay(p, d, q) {
  const s = qs(d), P = WP(s); if (P[q.id]) return [];
  const r = q.pay || TIER[q.tier] || TIER["小"];
  P[q.id] = 1;
  const got = SGK.reward(p, d, r.g || 0, r.items || [], false);
  for (const k of WQK[q.id] || []) if (ITEMS[k] && !(s.keys || []).includes(k)) { SGK.giveKey(p, d, k); got.push(`§6${ITEMS[k].name}`); }   /* 第125版: 依頼の 終わりの だいじなもの（データだけ）*/
  return got;
}
const WQK = { wq0e: ["k_wq0"], wq1e: ["k_wq1"], wq2e: ["k_wq2"], wq3e: ["k_wq3"], wq4e: ["k_wq4"], wq5e: ["k_wq5"], wq6e: ["k_wq6"], wq7e: ["k_wq7"], wq8e: ["k_wq8"], wq9e: ["k_wq9"], wq10e: ["k_wq10"] };
KEYSRC.push((d) => { const P = WP(qs(d)); return Object.entries(WQK).filter(([id]) => P[id]).flatMap(([, L]) => L); });   /* 前の 版で 済ませた 依頼 */

/* ---------- 場所 ---------- */
const SP0 = () => { try { return world.getDefaultSpawnLocation(); } catch { return { x: 0, y: 64, z: 0 }; } };
const townC = (tid) => { const t = TOWNS.find((u) => u.id === tid); if (!t) return null; const q = getTown(tid); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const PLQ = {};
export function wqPlace(tid, R, nm, key = `${tid}_${R}`) {
  if (PLQ[key]) return PLQ[key];
  const t = TOWNS.find((u) => u.id === tid), c = townC(tid); if (!t || !c) return null;
  const s0 = SP0(), avoid = [];
  for (const u of TOWNS) if (u.id !== tid) { const q = townPos(u); avoid.push([q.x, q.z, 44]); }
  for (let i = 0; i < 11; i++) { const k = castleSpot(i); if (k) avoid.push([k.x, k.z, 72]); }
  for (const k of ["out", "road", "hall", "stage", "forge", "gate", "ranch"]) { try { const q = placeOf(k, t.reg); if (q) avoid.push([q.x, q.z, 26]); } catch {} }
  for (const q of Object.values(PLQ)) if (q) avoid.push([q.x, q.z, 20]);
  let best = null;
  for (let a = 0; a < 16; a++) { const th = ((a + (key.length % 3) * 0.33) / 16) * Math.PI * 2, x = Math.floor(c.x + Math.cos(th) * R), z = Math.floor(c.z + Math.sin(th) * R); if (regionIdx(x - s0.x, z - s0.z) !== t.reg) continue; let m = 1e9; for (const [X, Z, D] of avoid) m = Math.min(m, Math.hypot(X - x, Z - z) - D); if (!best || m > best.m) best = { x, z, m }; }
  if (!best) best = { x: Math.floor(c.x + R), z: Math.floor(c.z) };
  return (PLQ[key] = { x: best.x, z: best.z, nm });
}
export const wqStand = (tid, k, dx, dz) => { const f = () => { for (const kk of [].concat(k, "inn")) { const q = spotOf(tid, kk); if (q) return { x: q.x + dx, y: q.y, z: q.z + dz }; } const c = townC(tid); return c ? { x: c.x + dx * 3, y: c.y ?? undefined, z: c.z + dz * 3 } : null; }; f.wqs = { tid, k, dx, dz }; return f; };
/* 第125版(pl): 依頼主は 仕事に 合う 建物の 前に 立つ（店の 人は 店・鍛冶は 鍛冶屋・漁師は 港・宿の 人は 宿・ほかは 自分の 家）。話しかけた 場面も そこで 始まる */
const ROLE_K = [[/鍛冶|鞘師/, ["forge", "armor"]], [/貸本|書庫|書記|写し手/, ["library", "home"]], [/宿/, ["inn"]], [/漁師|真珠|海女|歌い手|灯台守|渡し守|網元/, ["harbor", "home"]],
  [/仕立て|古道具|宝石|灯り屋|灯籠職人|薬売り|鏡職人|面打ち|木彫り|雷石|鱗彫り|編み物|花売り|隊商|商/, ["shop", "eggs"]], [/情報屋|唄うたい|太鼓/, ["tavern", "plaza"]]];
export function roleKinds(role, dx = 1) { const r = String(role || ""); for (const [re, k] of ROLE_K) if (re.test(r)) return k; return dx < 0 ? ["home2", "home", "plaza"] : ["home", "home2", "plaza"]; }
function spotFor(p, d, q, k) {
  const s = qs(d), st = q.steps[k];
  if (s.wqSpot && s.wqSpot.id === q.id && s.wqSpot.k === k) return s.wqSpot;
  let o = null; try { o = st.at(p); } catch {}
  if (!o || !Number.isFinite(o.x) || !Number.isFinite(o.z)) return null;
  s.wqSpot = { id: q.id, k, x: Math.floor(o.x), y: Number.isFinite(o.y) ? Math.floor(o.y) : null, z: Math.floor(o.z), nm: o.nm || st.nm || "" };
  save(p, d); return s.wqSpot;
}

/* ---------- 台本 ---------- */
const arr = (x) => [].concat(x);
async function fightStep(p, C, f) {
  const key = `wq_${C.q.id}_${C.k}_${f.key || "w"}`;
  for (const e of Object.values(C.E)) if (ok(e) && e.typeId !== "mrpg:npc") K.rmCine(e);
  if (K.flag(p, key)) return true;
  const team = K.team(f.fams || ["beast"], f.lv || 5, f.n || 2, ...(f.boss ? [12, K.leadOf(f.fams[0], f.lv || 5)] : []));
  const r = await K.battle(p, team, { name: f.name || "野生の モンスター", arena: C.q.t, ...(f.theme ? { theme: f.theme } : {}), ...(f.boss ? { hpk: 2, sboss: true } : { easy: !!f.easy }), speaker: f.speaker || f.name || "野生の モンスター", lines: f.lines || { half: "……グルル……", low: "……キュウ……" } });
  if (r !== "win") return false;
  K.setFlag(p, key); C.won = true; return true;
}
async function play(p, C, ops) {
  const E = C.E;
  for (const o of ops) {
    if (!ok(p)) return false;
    if (typeof o === "function") { if ((await o(p, K, C)) === false) return false; continue; }
    const [op, a, b, c, d, e] = o;
    switch (op) {
      case "open": await K.open(p, C.nm, a || "day"); if (C.fq) await K.at(p, C.fq, 16, 7, 1.4); break;   /* 第125版(pl): 引きの あと 場所の 建物を 映す */
      case "in": for (const id of o.slice(1)) { if (id === "hero") { if (SGK.heroOf(p)) E.hero = K.hero(p); } else if (CAST[id]) { E[id] = K.cast(p, id); K.act(E[id], "talk"); } } break;
      case "x": E[a] = K.npcNear(p, b, c ?? 8); break;
      case "say": await K.say(p, a, arr(b), E.hero || null); break;
      case "h": if (SGK.heroOf(p)) await K.hsay(p, K.V(arr(a), arr(b ?? a), arr(c ?? a), arr(d ?? a)), null); else if (e) await SGK.pal(p, arr(e)); break;
      case "n": await K.narr(p, arr(a), b ? E[b] || null : null); break;
      case "act": K.act(E[a], b); break;
      case "hold": K.hold(E[a], b || 0); break;
      case "give": await K.give(E[a], b ? E[b] : null, c); break;
      case "up": await K.up(p, E[a]); break;
      case "low": await K.low(p, E[a]); break;
      case "two": await K.two(p, E[a], E[b]); break;
      case "wide": await K.wide(p); break;
      case "mon": { const S = K.S(p); const q = S ? S.at(c || 6, d || 0, 0) : null; if (q) E[a] = K.monEnt(p, q, K.wildSp(b || "beast"), ""); break; }
      case "fight": if (!(await fightStep(p, C, a))) return false; break;
      case "end": await K.end(p, { leave: arr(a || []).map((x) => E[x]).filter(ok), card: b }); break;
      default: if (CAST[op]) await K.csay(p, op, arr(a), E.hero || null); else console.warn(`[MonsterRPG] wq: 台本の 行が わからない ${op}`);
    }
  }
  return true;
}

/* ---------- 場面を 流す ---------- */
const RUN = new Map();
function start(p, q, k, at) {
  if (SGK.EVT.has(p.id)) return;
  SGK.runEvt(p, async () => {
    const d = load(p); if (!d) return;
    const st = q.steps[k];
    if (k === 0) { SGK.big(p, "§2§l世界の 依頼", q.t, "random.levelup"); await K.wait(40); }
    const A = { x: at.x, y: Number.isFinite(at.y) ? at.y : p.location.y, z: at.z };
    const fk = `wq_${q.id}_${k}`, kd = typeof st.at === "function" && st.fac !== false ? st.fac || wqKind(at.nm || st.nm) : null;
    if (kd && facKind(fk) && facKind(fk) !== kd) facSwap(fk, kd, q.r);   /* 第125版(tp): 前の 版で 別の 形（道しるべ）が 建った 場所は、同じ 所に 文に 合う 形を 建てなおす */
    const f0 = kd ? facAt(fk, A, 60) : null;   /* 第125版(pl): 外れの 場所には 地名に 合う 建物・目印を 建てる（ワールドに 1回）*/
    await stageBegin(p, { anchor: A, move: true, noEst: true, ...(f0 ? { face: f0 } : {}) });
    let done = false, later = false; SGK.MQASK.add(p.id); RUN.set(p.id, q.id);
    const C = { q, k, E: {}, nm: st.nm || (k === 0 || whoOf(q, k) ? (CAST[q.npc] && TOWNS.find((u) => u.id === CAST[q.npc].town)?.name) || q.t : q.t) };
    if (kd) { const S0 = K.S(p); C.fq = fac(K, p, fk, kd, q.r, S0 ? Math.floor(S0.P.y) : Math.floor(p.location.y)); C.nm = at.nm || C.nm; }
    try { done = (st.run ? await st.run(p, load(p) || d, K, C) : await play(p, C, st.play || [])) === true; }
    catch (x) { if (x === SGK.LATER) later = true; else console.warn(`[MonsterRPG] wq ${q.id}: ${x} ${x?.stack || ""}`); }
    finally { SGK.MQASK.delete(p.id); RUN.delete(p.id); SGK.heroTmpClean(p); }
    if (later) SGK.laterClean(p);
    SGK.SPAWNED.delete(p.id);
    if (!ok(p)) return;
    const d2 = load(p); if (!d2) return; const s2 = qs(d2);
    if (done && wqStep(s2, q.id) === k) {
      W(s2)[q.id] = k + 1; delete s2.wqSpot;
      let got = null, fr = null;
      if (k + 1 >= q.steps.length) { got = wqPay(p, d2, q); fr = fragAdd(s2, q.id); if (s2.wqPick === q.id) { delete s2.wqPick; delete s2.wqPin; } }
      save(p, d2);
      if (got) { SGK.big(p, "§2§l依頼 達成", q.t, "ui.toast.challenge_complete"); try { p.sendMessage(`§2§l世界の 依頼「${q.t}」達成！§r §fほうび: §e${got.join("・") || "なし"}`); } catch {} }
      if (fr) try { p.sendMessage(fr); } catch {}
      else { const n = q.steps[k + 1]; try { p.sendMessage(`§2世界の 依頼「${q.t}」§f ${String(n.hint || "").replace(/§./g, "")}`); } catch {} }
    } else if (!done) try { p.sendMessage(`§7世界の 依頼「${q.t}」: 準備が できたら、もう一度 ${whoOf(q, k) ? "話しかけよう" : "その 場所へ 行こう"}。`); } catch {}
  });
}

/* ---------- 話しかける ---------- */
async function wqTalk(p, e, npc) {
  if (busy.has(p.id) || SGK.EVT.has(p.id)) return;
  const d = load(p); if (!d) return; const s = qs(d), c = CAST[npc];
  const q = npcQuest(s, d, npc);
  try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {}
  sound(p, "random.pop", 0.6);
  const line = (L) => arr(L).map((l) => `${c.col}${c.nm}§f「${String(l).replace(/^\{[^}]*\}/, "")}」`).join("\n\n");
  if (!q) {
    const last = [...(BYNPC[npc] || [])].reverse().find((x) => wqDone(s, x.id)), on = (BYNPC[npc] || []).find((x) => wqState(s, d, x) === "on");
    busy.add(p.id); try { await choose(p, castTag(npc).replace(/§./g, ""), line(on ? on.wait || [on.steps[wqStep(s, on.id)].hint] : last ? last.after || c.pre : c.pre || ["……"]) + (on ? `\n\n§7${on.steps[wqStep(s, on.id)].hint}` : ""), [["§lOK", ICON("i_back")]]); } finally { busy.delete(p.id); }
    return;
  }
  const k = wqStep(s, q.id);
  if (k < 0) {
    busy.add(p.id); let sel = -1;
    try { sel = await choose(p, `世界の 依頼「${q.t}」`, `${line([...arr(q.ask || c.pre || ["……"]), ...(WHY[q.id] ? [WHY[q.id]] : [])])}\n\n§7${q.hint}\n${TIER_TX[q.tier] || ""}${FRAG[q.id] ? "\n§d（済ませると「記録の 断片」が 手帳に 残る）" : ""}`, [["§l引き受ける", ICON("i_walk")], ["§7今は やめておく", ICON("i_back")]]); } finally { busy.delete(p.id); }
    if (sel !== 0 || !ok(p)) return;
    const d2 = load(p); if (!d2) return; const s2 = qs(d2); if (wqStep(s2, q.id) >= 0) return;
    W(s2)[q.id] = 0; if (!s2.wqPin) s2.wqPick = q.id; else if (s2.wqPick === q.id) delete s2.wqPin;   /* 第125版(pk): 依頼主へ 案内中に 引き受けたら 右上は 物語に もどす（近くでは 依頼の 段を 出す）*/
    save(p, d2);
  }
  start(p, q, Math.max(0, k), e.location);
}
NPC_HOOKS.unshift((p, e) => {
  try {
    if (!e.hasTag("mrpg_cast")) return false;
    const id = e.getDynamicProperty("mrpg:cast"); if (typeof id !== "string" || !CAST[id]) return false;
    const d = load(p); if (!d) return false; const s = qs(d);
    if (!npcQuest(s, d, id) && !(OWN.has(id) && (BYNPC[id] || []).some((x) => wqState(s, d, x) !== "lock"))) return false;   /* 本編の 人は 用が ない ときは いつもの「その後」*/
    system.run(() => { wqTalk(p, e, id).catch(() => {}); });
    return true;
  } catch { return false; }
});

/* ---------- 目印と 場所（1秒ごと。近くの 人だけ）---------- */
const mark = (p, q, y, id = "mrpg:emote_bang") => { const at = { x: q.x, y: q.y + y, z: q.z }; try { if (p.spawnParticle) p.spawnParticle(id, at); else p.dimension.spawnParticle(id, at); } catch {} };
const near = (a, b, r) => Math.hypot(a.x - b.x, a.z - b.z) <= r;
/* 第125版(pk): 依頼主の 場所（1分 おぼえる）・名札「町・役 名前」・向きと 距離 */
const GP = new Map();
function giverAt(npc) { const v = GP.get(npc), now = Date.now(); if (v && now - v.t < 60000) return v.q; let q = null; try { const a = CAST[npc] && CAST[npc].at && CAST[npc].at(); if (a && Number.isFinite(a.x) && Number.isFinite(a.z)) q = { x: Math.floor(a.x) + 0.5, y: Number.isFinite(a.y) ? a.y : null, z: Math.floor(a.z) + 0.5 }; } catch {} GP.set(npc, { q, t: now }); return q; }
export const wqWho = (npc) => { const c = CAST[npc], t = c && TOWNS.find((u) => u.id === c.town); return `${t ? `${String(t.name).split(" ").pop()}・` : ""}${castTag(npc).replace(/§./g, "")}`; };
const DIR8 = ["東", "南東", "南", "南西", "西", "北西", "北", "北東"];
export const wqDir = (l, a) => { const dx = a.x - l.x, dz = a.z - l.z, m = Math.round(Math.hypot(dx, dz)); return m < 6 ? "すぐ そば" : `${DIR8[(Math.round(Math.atan2(dz, dx) / (Math.PI / 4)) + 8) % 8]} ${m}m`; };
/* 今 話しかけると 動く 人 → [依頼, 1=とちゅう 0=新しい] */
function wqLive(s, d) {
  const o = new Map();
  for (const id in s.wq || {}) { const q = WQ[id], k = wqStep(s, id); if (q && k >= 0 && k < q.steps.length) { const w = whoOf(q, k); if (w) o.set(w, [q, 1]); } }
  for (const q of Object.values(WQ)) if (!o.has(q.npc) && wqStep(s, q.id) < 0 && wqOpen(s, d, q)) o.set(q.npc, [q, 0]);
  return o;
}
/* 遠くの 依頼主（32〜96）に 細い 光の 柱。3秒ごと・近い 3人だけ・その 人にだけ 見える。緑 = 新しい 依頼・紫 = とちゅう */
const BC = [{ red: 0.35, green: 1, blue: 0.45 }, { red: 0.8, green: 0.45, blue: 1 }], NXT = new Map();
function beams(p, L, l) {
  const A = [];
  for (const [npc, v] of L) { const a = giverAt(npc); if (!a) continue; const m = Math.hypot(a.x - l.x, a.z - l.z); if (m > 32 && m <= 96) A.push([m, a, v[1]]); }
  A.sort((x, y) => x[0] - y[0]);
  for (const [, a, on] of A.slice(0, 3)) {
    let y = a.y; if (!Number.isFinite(y)) { try { const t = p.dimension.getTopmostBlock({ x: Math.floor(a.x), z: Math.floor(a.z) }); y = t ? t.location.y + 1 : l.y; } catch { y = l.y; } a.y = y; }
    try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", BC[on]); m.setFloat("variable.scale", 0.7); if (p.spawnParticle) p.spawnParticle("mrpg:beacon", { x: a.x, y: y + 14, z: a.z }, m); } catch {}
  }
}
/* はじめて 依頼が 出た ときに 1回だけ（人ごと）*/
function intro(p, d, s, L, l) {
  if (s.wqIntro) return; const op = [...L].filter(([, v]) => !v[1]); if (!op.length) return;
  s.wqIntro = 1; save(p, d); if (Object.keys(s.wq || {}).length) return;
  let nb = null; for (const [npc] of op) { const a = giverAt(npc); if (a && near(a, l, 160) && (!nb || Math.hypot(a.x - l.x, a.z - l.z) < nb[0])) nb = [Math.hypot(a.x - l.x, a.z - l.z), `${wqWho(npc)}　${wqDir(l, a)}`]; }
  SGK.big(p, "§2§l世界の 依頼", "§f町の 人の 頭に「！」→ 話しかけて 引き受けよう", "random.levelup");
  try { p.sendMessage(`§2§l世界の 依頼が 出た！§r\n§f① 町の 人の 頭に §e「！」§f（遠くは §a緑の 光の 柱§f）\n§f② その 人に 話しかけて「引き受ける」（物語の 寄り道。やらなくても 物語は 進む）\n§f③ ガイドブック → ストーリー →「世界の 依頼」で 一覧と 向き・距離。「案内する」で 右上の 案内が その 人を 指す${nb ? `\n§a近くの 依頼主: ${nb[1]}` : ""}`); } catch {}
}
function busyMain(s, sp) { for (const m of [s.epSpot, s.mqSpot]) if (m && Number.isFinite(m.x) && Math.hypot(m.x - sp.x, m.z - sp.z) < 24) return true; return false; }
export function wqTick() {
  let P = []; try { P = world.getAllPlayers(); } catch { return; }
  for (const p of P) {
    try {
      if (p.dimension.id !== "minecraft:overworld") continue;
      const d = load(p); if (!d) continue; const s = qs(d), l = p.location;
      const free = !busy.has(p.id) && !SGK.EVT.has(p.id) && !globalThis.__mqScene?.has(p.id);
      for (const [npc, e] of __cast.LIVE) { if (!ok(e) || !near(e.location, l, 32)) continue; if (!BYNPC[npc] && !Object.values(WQ).some((q) => whoOf(q, Math.max(0, wqStep(s, q.id))) === npc)) continue; const nq = npcQuest(s, d, npc); if (nq) mark(p, e.location, 2.6, wqStep(s, nq.id) >= 0 ? "mrpg:emote_q" : "mrpg:emote_bang"); }   /* 第125版(pk): とちゅうの 依頼の 人は「？」*/
      for (const id in s.wq || {}) {
        const q = WQ[id], k = wqStep(s, id); if (!q || k < 0 || k >= q.steps.length || typeof q.steps[k].at !== "function") continue;
        const sp = spotFor(p, d, q, k); if (!sp || !near(sp, l, 56)) continue;
        if (sp.y === null || sp.y === undefined) { const g = SGK.goodSpot(sp.x, sp.z, Math.floor(l.y) + 20); if (!g) continue; Object.assign(sp, g); save(p, d); }
        mark(p, sp, 1.6);
        if (free && near(sp, l, 4) && Math.abs(sp.y - l.y) < 6 && canFight(d) && SGK.steady(p) && !busyMain(s, sp)) { start(p, q, k, sp); break; }
      }
      const now = system.currentTick || 0; if ((NXT.get(p.id) || 0) > now) continue; NXT.set(p.id, now + 60);   /* 第125版(pk): 3秒ごと */
      const L = wqLive(s, d); beams(p, L, l); if (free && !SGK.EVT.has(p.id)) intro(p, d, s, L, l);
    } catch {}
  }
}
system.runInterval(wqTick, 20);

/* ---------- 右上の 案内: 自分で えらんだ 依頼、または 物語の 場所が 近くに ない ときの 近くの 依頼 ---------- */
function goalOf(p, d, q) {
  const s = qs(d), k = wqStep(s, q.id); if (k < 0 || k >= q.steps.length) return null;
  const st = q.steps[k], who = whoOf(q, k); let x = null, z = null, nm = "";
  if (who) { try { const a = CAST[who] && CAST[who].at && CAST[who].at(); if (a) { x = a.x; z = a.z; nm = CAST[who].nm; } } catch {} }
  else { const sp = spotFor(p, d, q, k); if (sp) { x = sp.x + 0.5; z = sp.z + 0.5; nm = sp.nm; } }
  return { text: `世界の 依頼「${q.t}」 ${String(st.hint || "").replace(/§./g, "")}`, name: nm, near: who ? "§a「！」の 人に 話しかけよう" : "§a「！」の 目印の そばで 立ち止まろう", x, z, key: `wq:${q.id}:${k}` };
}
GOAL_HOOKS.unshift((p, d) => {
  const s = qs(d), q = s.wqPick && WQ[s.wqPick], st = q ? wqState(s, d, q) : "";
  if (st === "open" && s.wqPin) { const a = giverAt(q.npc); return a ? { text: `世界の 依頼「${q.t}」 ${wqWho(q.npc)} に 話しかけよう`, name: wqWho(q.npc), near: "§a頭に「！」の 人に 話しかけて 引き受けよう", x: a.x, z: a.z, key: `wq:${q.id}:o` } : null; }   /* 第125版(pk): ガイドブックで「案内する」を えらんだ 依頼主 */
  if (st !== "on") return null;
  const g = goalOf(p, d, q); if (!g || g.x === null) return null;
  if (s.wqPin) return g;
  const l = p.location; if (Math.hypot(g.x - l.x, g.z - l.z) > 64) return null;
  for (const m of [s.epSpot, s.mqSpot]) if (m && Number.isFinite(m.x) && Math.hypot(m.x - l.x, m.z - l.z) < 160) return null;
  return g;
});

/* ---------- ガイドブック ＞ ストーリー ＞ 世界の 依頼 ---------- */
const whereOf = (p, d, q, st) => { if (!p) return ""; const l = p.location; if (st === "open") { const a = giverAt(q.npc); return a ? `${wqWho(q.npc)}　${wqDir(l, a)}` : wqWho(q.npc); } const g = goalOf(p, d, q); return g && g.x !== null ? `行き先: ${g.name || "目印"}　${wqDir(l, g)}` : ""; };   /* 第125版(pk) */
export function wqBookText(d, p) {
  const s = qs(d), L = ["§l§2世界の 依頼", "§7受け方: 町の 人の 頭に §e「！」§7 → 話しかける →「引き受ける」。遠くの 依頼主には §a緑の 光の 柱§7（とちゅうは §d紫§7）。下の「案内する」で 右上の 案内が その 人を 指す。物語の 寄り道（やらなくても 物語は 進む）。", ""];
  for (const r of Object.keys(WQR).map(Number).sort((a, b) => a - b)) {
    const Q = WQR[r], seen = Q.filter((q) => wqState(s, d, q) !== "lock"); if (!seen.length) continue;
    L.push(`§6§l${(WREGIONS[r] && WREGIONS[r].name) || `地方${r + 1}`}§r §7（${Q.filter((q) => wqDone(s, q.id)).length}/${Q.length}）`);
    for (const q of seen) { const st = wqState(s, d, q), k = wqStep(s, q.id);
      if (st === "done") L.push(`  §a★ ${q.t} §7（済み）`);
      else if (st === "on") { const w = whereOf(p, d, q, st); L.push(`  §e▶ ${q.t}${s.wqPick === q.id && s.wqPin ? " §d（案内中）" : ""}\n     §f今: ${String(q.steps[k].hint || "").replace(/§./g, "")}${w ? `\n     §7${w}` : ""}`); }
      else { const w = whereOf(p, d, q, st); L.push(`  §b！ ${q.t}${s.wqPick === q.id && s.wqPin ? " §d（案内中）" : ""} §7― ${String(q.hint || "").replace(/§./g, "")}${w ? `\n     §f${w}` : ""}`); } }
    const n = Q.length - seen.length; if (n > 0) L.push(`  §8まだ 見つかって いない 依頼 ×${n}`);
  }
  return L.join("\n");
}
export async function wqBook(p, d) {
  for (;;) {
    d = load(p) || d; const s = qs(d);
    const on = Object.values(WQ).filter((q) => wqState(s, d, q) === "on");
    const nf = fragN(s);
    const l = p.location, dist = (q) => { const a = giverAt(q.npc); return a ? Math.hypot(a.x - l.x, a.z - l.z) : 1e9; };
    const op = Object.values(WQ).filter((q) => wqState(s, d, q) === "open").sort((a, b) => dist(a) - dist(b)).slice(0, 6), G2 = [...on, ...op];   /* 第125版(pk): 新しい 依頼は 近い 6件に「案内する」*/
    const B = [...on.map((q) => [`§e案内: ${q.t}\n§8${whereOf(p, d, q, "on")}`, ICON("i_walk")]), ...op.map((q) => [`§b案内する: ${wqWho(q.npc)}\n§8${whereOf(p, d, q, "open").split("　").pop()}・${q.t}`, ICON("i_walk")]), ...(s.wqPin ? [["§7物語の 案内に 戻す", ICON("i_back")]] : []), ...(nf ? [[`§d§l記録の 断片 §r§8${nf}`, ICON("i_zukan")]] : []), ["§7戻る", ICON("i_back")]];
    const sel = await choose(p, "世界の 依頼", wqBookText(d, p), B);
    if (sel < 0 || !ok(p)) return;
    const d2 = load(p); if (!d2) return; const s2 = qs(d2);
    if (sel < G2.length) { s2.wqPick = G2[sel].id; s2.wqPin = 1; save(p, d2); try { p.sendMessage(sel < on.length ? `§2右上の 案内を「${G2[sel].t}」に した。` : `§2右上の 案内を 依頼主「${wqWho(G2[sel].npc)}」に した。§7（引き受けると 物語の 案内に もどる）`); } catch {} continue; }
    if (s.wqPin && sel === G2.length) { delete s2.wqPin; save(p, d2); try { p.sendMessage("§2右上の 案内を 物語に 戻した。"); } catch {} continue; }
    if (nf && sel === G2.length + (s.wqPin ? 1 : 0)) { await fragBook(p, d2); continue; }
    return;
  }
}
/* ---------- 第125版: 記録の 断片（依頼を 済ませると 1つ。後で 分かった ことは 本編の その 場面を 越えて から）---------- */
WLG.past = (s, k) => { if (!s || !k) return false;   /* 第126版: 後の 門は 章の id（その 章を 終えた）。前の 版の 名も 読む */
  const M = { theo: "b08", ch10: "b14", zeph: "b20", end: "u15" }; const c = M[k] || k;
  if (c === "u15") return bkPast(s, "u15") || (s.ru && s.ru.st >= 4) || false;
  return bkPast(s, c); };
const fragIds = (s) => Object.keys(FRAG).filter((id) => wqDone(s, id));
const fragN = (s) => fragIds(s).length;
/* 達成した ときに 1回だけ（印 s.wlF）。旅の 手帳にも 名を 残す */
function fragAdd(s, id) {
  const f = FRAG[id]; if (!f) return null; const F = s.wlF && typeof s.wlF === "object" ? s.wlF : (s.wlF = {}); if (F[id]) return null; F[id] = 1;
  const nm = TECHO[id]; if (nm) s.techo = [...new Set([...(s.techo || []), nm])];
  return `§d記録の 断片「${f[0]}」を 手帳に 書きとめた${nm ? `§7（旅の 手帳に「${nm}」）` : ""} §8― ガイドブック → ストーリー → 世界の 依頼 → 記録の 断片`;
}
export async function fragBook(p, d) {
  for (;;) {
    d = load(p) || d; const s = qs(d), ids = fragIds(s), all = Object.keys(FRAG).length;
    const B = [["§6§l旅の 手帳 §r§8会った 人の 名前", ICON("i_zukan")], ...ids.map((id) => [`§d${FRAG[id][0]}\n§8${(WREGIONS[WQ[id].r] && WREGIONS[WQ[id].r].short) || ""}${FRAG[id][2] && WLG.past(s, FRAG[id][2]) ? " §e★後で 分かった こと" : ""}`, ICON("i_zukan")]), ["§7戻る", ICON("i_back")]];
    const sel = await choose(p, "記録の 断片", `§7世界の 依頼で 書きとめた、物語の かけら。§8（${ids.length}/${all}）\n§7本編の あの 場面を 越えると、§e後で 分かった こと§7 が 足される。`, B);
    if (sel < 0 || sel >= B.length - 1 || !ok(p)) return;
    if (sel === 0) { const T = s.techo || []; await choose(p, "旅の 手帳", T.length ? `§7手帳に 書きとめた 名前（${T.length}）\n\n§f${T.join("\n§f")}` : "§7まだ 名前は ない。", [["§lOK", ICON("i_back")]]); continue; }
    const id = ids[sel - 1], f = FRAG[id], q = WQ[id];
    const later = f[2] && WLG.past(s, f[2]) ? `\n\n§e§l後で 分かった こと§r\n§f${f[3]}` : "";
    await choose(p, f[0], `§d§l${f[0]}§r\n§7（${(WREGIONS[q.r] && WREGIONS[q.r].name) || ""}・世界の 依頼「${q.t}」）\n\n§f${f[1].join("\n§f")}${later}`, [["§lOK", ICON("i_back")]]);
  }
}
WLB.book = fragBook; WLB.n = (p, d) => fragN(qs(d));
STORY_EXTRA.push({ label: "§2§l世界の 依頼", cond: (p, d) => { const s = qs(d); return Object.values(WQ).some((q) => wqState(s, d, q) !== "lock"); }, run: (p, d) => wqBook(p, d) });
export const __wq = { WQ, WQR, BYNPC, start, play, spotFor, npcQuest, npcSeen, wqTalk, goalOf, RUN, PLQ, fragAdd, fragN };
