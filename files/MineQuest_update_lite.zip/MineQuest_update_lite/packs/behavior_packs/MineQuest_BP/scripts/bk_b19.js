/* 第126版 本19「闘技場の杯」（ルミナの 闘技場）— 作業 ME
   分かる: 仮面の 王者は オルド。二十年、王冠の 間への 扉を 守って きた。四歳の 冬、主人公を 呼び戻したのは 幼なじみの 声だった（柱の 絵の 丸）。
   問い: 扉の 向こうに 誰が いるのか（→本20 qb191）。前の 章までの 問い qb011・qb012（本1）に 答える（b19e8）
   今日の 闘技場の 積み上げ（受付の 掟・すり減った 石像・アスカ「杯は ふるい」・仮面の 王者の わけ）を 引きとる。cupScene の「mask」「ordoWin」の 場面は ここ（b19e6・b19e7）
   せいかん杯は 物語の 中で 戦う（1回戦 → レイ → 準決勝 → 決勝）。勝つと s.cup = 8（下の カップの 石板は syncQuest が 渡す）。メニューの せいかんカップは 再戦だけ（story.js ARENA126）
   場所: 受付（ルミナの 広場・b19desk）／闘技場（b19ring = cupring: 石像・表彰台・床の 格子・奥の 扉・最上段の 席）／控え室（b19room = hut）*/
import { bkAdd } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS } from "./epfac.js";
import { spotOf, townOut } from "./storyplace.js";
import { ok } from "./ui.js";
import { load, save } from "./store.js";
import { qs, syncQuest } from "./quest.js";
import { ARENA126 } from "./story.js";
import { J, MK, setB, sOf, REI, ORDO, NP, fade, Yof, afterAdd, fin, again, face, toP, LUM } from "./bk_b17.js";

ARENA126.on = true;
const { F, S1 } = FAC_OPS;
/* 闘技場の 一角（砂岩の 床・観客席・入口の 石像・表彰台と 床の 格子・奥の 扉・最上段の 席。約 250 ブロック）*/
facAdd("cupring", { D: [10, 12, 9], box: [-1, -6, 11, 6], H: 6, look: [5, 0, 1.2], marks: { statue: [1, -5, 1], podium: [8, 0, 1], grate: [8, 0, 0], door: [10, 0, 0], top: [9, 5, 3], center: [5, 0, 0], champ: [8, 2, 0], worn: [10, 0, 0] }, build: () => [
  F(0, -5, -1, 10, 5, -1, "smooth_sandstone"), F(0, -6, 0, 10, -6, 0, "smooth_stone_slab"), F(0, 6, 0, 10, 6, 0, "smooth_stone_slab"),
  F(2, -6, 1, 9, -6, 1, "smooth_stone_slab"), F(2, 6, 1, 9, 6, 1, "smooth_stone_slab"),
  F(11, -6, 0, 11, 6, 3, "cut_red_sandstone"), F(11, -1, 0, 11, 1, 2, "dark_oak_planks"), F(10, -1, -1, 10, 1, -1, "cobblestone"),
  S1(1, -5, 0, "chiseled_stone_bricks"), F(1, -5, 1, 1, -5, 2, "stone"), S1(1, -5, 3, "stone_button"),
  F(7, -1, 0, 9, 1, 0, "quartz_slab"), S1(8, 0, 0, "iron_trapdoor"), S1(8, 0, -1, "lantern"),
  F(9, 5, 2, 10, 5, 2, "smooth_stone"), S1(9, 5, 3, "red_carpet"), S1(0, -6, 1, "lantern"), S1(0, 6, 1, "lantern"), S1(11, -6, 4, "red_wool"), S1(11, 6, 4, "yellow_wool")] });

/* ---------- 場所 ---------- */
export const ARENA = () => { const o = townOut("t0", 2.4, "闘技場"); return o ? { x: o.x, z: o.z, nm: "ルミナの 闘技場" } : null; };
const DESK = () => { const q = spotOf("t0", "plaza"), c = LUM(); return q ? { x: Math.floor(q.x), z: Math.floor(q.z), nm: "ルミナの 闘技場の 受付" } : c ? { x: Math.floor(c.x), z: Math.floor(c.z), nm: "ルミナの 闘技場の 受付" } : null; };
const RV = () => J("mrpg:epdeco:b19ringat");
const RPT = (n, nm) => () => { const v = RV(), m = v && MK(v, n); if (m) return { x: Math.floor(m.x), z: Math.floor(m.z), nm }; const a = ARENA(); return a ? { ...a, nm } : null; };
const CUP = RPT("center", "ルミナの 闘技場（せいかん杯）"), DOOR = RPT("worn", "闘技場の 奥の 扉");
const ROOM = () => { const v = RV(); if (v && Array.isArray(v.o)) return { x: v.o[0] - v.f[1] * 14, z: v.o[2] + v.f[0] * 14, nm: "闘技場の 控え室" }; const a = ARENA(); return a ? { x: a.x + 14, z: a.z, nm: "闘技場の 控え室" } : null; };
export const ring = (K, p) => { K.fac(p, "b19ring", "cupring", 0, Yof(K, p)); return RV(); };
const deskSet = (K, p) => setB(K, p, "b19desk", [[4, -1, 0, 4, 1, 0, "barrel"], [4, 0, 1, 4, 0, 1, "lectern"], [4, -2, 0, 4, -2, 2, "oak_fence"], [4, 2, 0, 4, 2, 2, "oak_fence"], [4, -2, 3, 4, 2, 3, "red_wool"]], { D: 2, look: [4, 0], marks: { desk: [4, 0, 1], clerk: [5.5, 0, 0] } });
const cheer = async (K, p, v) => {   /* 客席が 名前を 三度 呼ぶ */
  const q = MK(v, "center") || K.fwd(p, 6, 0, 1);
  for (let i = 0; i < 3; i++) { K.sound(p, "random.levelup", 0.3 + i * 0.1); K.burst(p.dimension, q, "minecraft:villager_happy", 10, 5, 1.5); if (i < 2) await K.narr(p, [`§f「${p.name}${"！".repeat(i + 1)}」`], q); }
  await K.wide(p, 10);
  await K.narr(p, [`§f「${p.name}――！！」`, "§7客席が、三度、あなたの 名前を 呼んだ。"]);
};

/* ---------- 町の 人 ---------- */
castAdd("b19asuka", { nm: "アスカ", role: "杯の 審判", gobi: "", skin: "sakura", town: "t0", from: "b19e2", at: () => { const c = LUM(); return c ? { x: c.x - 6, z: c.z + 4 } : null; },
  pre: ["{smile}審判の アスカよ。旗は いつでも 振れるわ。"],
  after: [[(s) => !!s.ending, ["{smile}闘技場の 歓声、前より 大きく なったの。……名前を 呼ぶ 意味を、みんな 知ったから。", "{closed}あの 石像の 台座、だれか 新しく 名前を 彫り直したいって 言ってるわ。"]],
    [(s) => !!(s.epx && s.epx.ordoMask) || !!s.ordoMask, ["{smile}仮面の 王者の 正体？ ……わたしは ずっと 知ってたわよ。腰を たたく 癖で。"]],
    [() => true, ["{closed}杯は、ふるいでも あるの。……だれが 残るかを 見る ための。"]]] });
afterAdd("nol", [[(s) => !!(s.epx && s.epx.ordoMask) || !!s.ordoMask, ["{smile}オルドの やつ、仮面を 取ったそうじゃな。……二十年、よう 腰が もったもんじゃよ。"]]]);

/* ---------- 話 ---------- */
const E1 = { id: "b19e1", t: "名乗りは 三度", place: DESK, F: ["F12", "F25"],
  hint: "§fルミナの §e闘技場の 受付§f へ 行こう §7（オルドと レイが 待って いる）",
  syn: "影は 闘技場の 下へ 沈んだ。下へ 行けるのは、せいかん杯の 勝者だけ。掟は「名乗りは 三度」。オルドは「上の 席の 寝ぼすけには 近づくなよ」と 笑った。",
  async run(p, d, K) {
    const V = deskSet(K, p);
    await K.open(p, "ルミナの 闘技場の 受付", "day");
    const eC = await K.put(p, "§e闘技場の 受付", MK(V, "clerk") || K.fwd(p, 5), null, 5); K.act(eC, "hold");
    if (V) await K.at(p, MK(V, "desk"), 12, 3, 1.2);
    await K.say(p, "闘技場の 受付", ["{closed}……影が 闘技場の 床の 下へ 沈んだのは、見ました。", "{closed,up}でも、下へ 通じる 扉は 掟で 閉じて います。§eせいかん杯の 勝者だけ§f が 通れるんです。"]);
    const eR = REI(K, p), eO = ORDO(K, p);
    await K.say(p, "レイ", ["{angry,?}……掟だと？ 町が 石に なりかけてるって 時に。"], eC);
    await K.say(p, "闘技場の 受付", ["{sweat,汗}掟は もう 一つ あります。§e『名乗りは 三度。勝った 者の 名は、客席の みんなで 呼ぶ』§f。……これは 開いた 方が 決めた ことです。"]);   /*F12*/
    face(K, eO, eR);
    await K.say(p, "オルド", ["{smile}ほっほ。決まりは 決まりじゃ。……出るんじゃろう？ 名前は もう 書いて おいたわい。"], eR);
    await K.say(p, "レイ", ["{shock,!}……じいちゃん、勝手に！ ……オレの 名前も かよ。"]);
    await K.up(p, eO, 10);
    await K.say(p, "オルド", ["{smile,up}それと、客席の いちばん 上の 席の 寝ぼすけには 近づくなよ。", "{sweat,汗}あれとは 勝ったり 負けたり、百と 少しじゃ。……起こすと うるさいでな。"]);   /*F25*/
    await K.say(p, "レイ", ["{?}……百と 少し？ じいちゃん、闘技場で そんなに 戦ってたのか。"], eO);
    await K.say(p, "オルド", ["{sweat,汗}……昔、ちょっとな。わしは 用事が ある。決勝で 会えたら、ええのう。"]);
    K.pay(p, E1, 1000, []);
    await fin(K, p, { leave: [eO, eR], bye: [eC], card: "§7→ §eルミナの 闘技場§7 で、せいかん杯（右上の 案内）", kind: "day" });
    return true;
  } };

const E2 = { id: "b19e2", t: "すり減った 名前", place: () => { const a = ARENA(); return a ? { ...a, nm: "ルミナの 闘技場（せいかん杯）" } : null; }, fac: "b19ring", F: ["F11"],
  hint: "§fルミナの §e闘技場§f へ 行こう §7（せいかん杯が 始まる）",
  syn: "闘技場の 入口の 石像は、台座の 名前だけが すり減って 読めない。審判の アスカは「杯は、ふるいでも あるの」と 言った。",
  async run(p, d, K) {
    const v = ring(K, p);
    await K.open(p, "ルミナの 闘技場", "day");
    const st = MK(v, "statue") || K.fwd(p, 4, -3, 1);
    await K.at(p, st, 16, 2.4, 0.6);
    await K.narr(p, ["§7入口の 石像。闘技場を 開いた 人の 像だと いう。", "§7台座の 名前の ところだけ、きれいに §fすり減って§7 読めない。……風の せいとは 思えない。"], st);   /*F11*/
    const eA = K.cast(p, "b19asuka"); K.act(eA, "hold"); K.hold(eA, "staff");
    await K.csay(p, "b19asuka", ["{smile,up}せいかん杯の 審判、アスカよ。……その 像が 気に なる？", "{closed}名前は、開いた 本人が 削ったって 話よ。"]);
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{?}……自分で？ なんで 自分の 名前を 消すんだよ。"], eA);
    await K.csay(p, "b19asuka", ["{closed}さあ。でも その 人の 言葉は 残ってるわ。", "{closed,up}『杯は、ふるいでも ある』。……最後に だれが 残るかを 見る ための。"]);
    await K.say(p, "レイ", ["{closed}……ふるい、か。上等だ。最後まで 残って やる。"]);
    K.act(eA, 0);
    await fin(K, p, { leave: [eR], bye: [eA], card: "§7→ せいかん杯 1回戦", kind: "day" });
    return true;
  } };

const fightAt = async (K, p, team, info) => { const r = await K.battle(p, team, { arena: "せいかん杯", theme: "arena", ...info }); return r === "win"; };
const E3 = { id: "b19e3", t: "1回戦", place: CUP, fac: "b19ring", battles: 1, F: ["F12", "F57"],
  hint: "§fルミナの §e闘技場§f で せいかん杯の 1回戦 §7（王座の 門番 ヴァイス）",
  syn: "1回戦は 王座の 門番 ヴァイス。勝つと 客席が 名前を 三度 呼んだ。表彰台の 床の 格子の 下に、灯りが 一つ 見えた。",
  async run(p, d, K) {
    const v = ring(K, p);
    await K.open(p, "ルミナの 闘技場（せいかん杯）", "day");
    let eV = NP(K, p, "§c王座の 門番 ヴァイス", "leon"); K.act(eV, "guard");
    await K.say(p, "ヴァイス", ["{angry,up}ここからは 本物の 最強だ。……名乗れ。三度な。"]);
    if (!(await fightAt(K, p, K.team(["sword", "golem", "beast"], 84, 3, 30), { name: "王座の 門番 ヴァイス", speaker: "ヴァイス", lines: { half: "まだまだ！", low: "……名を 呼ばれる だけの ことは ある。" } }))) { await K.say(p, "ヴァイス", ["{closed}……また 来い。"]); return false; }
    eV = again(K, p, eV, "§c王座の 門番 ヴァイス", K.PJ("leon", 8)); K.act(eV, "bow");
    await cheer(K, p, v);   /*F12*/
    const g = MK(v, "grate") || K.fwd(p, 6, 0, 0.2);
    await K.at(p, g, 18, 1.6, 0.3);
    await K.narr(p, ["§7表彰台の 床に、四角い §f格子§7。……その ずっと 下に、灯りが 一つ ともって いる。", "§8歓声が 上がる たびに、灯りが ふるえた 気が した。"], g);   /*F57*/
    { const pe = K.palEnt(p); if (pe) await K.up(p, pe, 10); await K.pal(p, ["……したに、だれか いる。……ずっと、すわってる におい。"]); K.rmCine(pe); }
    await fin(K, p, { bye: [eV], card: "§7→ 2回戦（レイ）", kind: "day" });
    return true;
  } };

const E4 = { id: "b19e4", t: "竜の いない 杯", place: CUP, fac: "b19ring", battles: 1,
  hint: "§fルミナの §e闘技場§f で せいかん杯の 2回戦 §7（レイ）",
  syn: "2回戦の 相手は レイ。竜の いない、借りた 名を 呼ぶ 新しい 戦い方だった。",
  async run(p, d, K) {
    ring(K, p);
    await K.open(p, "ルミナの 闘技場（せいかん杯）", "day");
    let eR = REI(K, p); K.act(eR, "raise");
    await K.low(p, eR, 12);
    await K.say(p, "レイ", ["{smile,up}……雲の 上の 続きだ。今度は 客席の 前でな。", "{closed}竜は いない。でも、一体ずつ 名前を 呼んで 組んで きた。"]);
    if (!(await fightAt(K, p, K.team(["animal", "beast", "golem"], 84, 4, 12, K.leadOf("beast", 84)), { name: "ライバル レイ（せいかん杯）", tmx: "rei", speaker: "レイ", tag: "ライバル", lines: { half: "……まだ 呼べる 名前が ある！", low: "……ハハ、また 負けか。" } }))) { await K.say(p, "レイ", ["{closed}……もう一度だ。"]); return false; }
    eR = again(K, p, eR, "§bレイ", 17); K.act(eR, 0);
    await K.say(p, "レイ", ["{smile,…}……また 負けた。でも、今日の 負けは 気持ち いい。", "{closed}準決勝、行け。客席で 一番 でかい 声で 呼んで やる。"]);
    await fin(K, p, { leave: [eR], card: "§7→ 準決勝", kind: "day" });
    return true;
  } };

const E5 = { id: "b19e5", t: "準決勝", place: CUP, fac: "b19ring", battles: 1, F: ["F12"],
  hint: "§fルミナの §e闘技場§f で せいかん杯の 準決勝 §7（王座の 門番 カゲロウ）",
  syn: "準決勝。客席の 歓声が 上がる たびに、床の ひびが 少しずつ 閉じて いった。",
  async run(p, d, K) {
    const v = ring(K, p);
    await K.open(p, "ルミナの 闘技場（せいかん杯）", "day");
    const fl = MK(v, "center") || K.fwd(p, 5, 0, 0.1);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, fl, "minecraft:portal_reverse_particle", 6, 1.5, 0); await K.wait(3); }
    await K.at(p, fl, 14, 2.4, 0.2);
    await K.narr(p, ["§7闘技場の 床に、細い §fひび§7。すき間から、紫の 影が にじんで いる。"], fl);
    let eK = NP(K, p, "§c王座の 門番 カゲロウ", "yoru"); K.act(eK, "guard");
    await K.say(p, "カゲロウ", ["{smile}まぼろしに まどわされないでね。……床の 下のも、ね。"]);
    if (!(await fightAt(K, p, K.team(["nether", "dragon", "sword"], 86, 3, 34), { name: "王座の 門番 カゲロウ", speaker: "カゲロウ", lines: { half: "ふふ、やるわね。", low: "……名前、呼ばれて いいわよ。" } }))) { await K.say(p, "カゲロウ", ["{closed}……また いらっしゃい。"]); return false; }
    eK = again(K, p, eK, "§c王座の 門番 カゲロウ", K.PJ("yoru", 8));
    await cheer(K, p, v);
    await K.at(p, fl, 16, 2.2, 0.2);
    await K.narr(p, ["§7歓声が 上がる たびに、床の ひびが 少しずつ 閉じて いく。……三度目で、紫の にじみは 消えた。"], fl);   /*F12*/
    await K.say(p, "カゲロウ", ["{shock,…}……歓声で、ふさがった？"]);
    await fin(K, p, { bye: [eK], card: "§7→ 決勝（仮面の 王者）", kind: "day" });
    return true;
  } };

const E6 = { id: "b19e6", t: "仮面の 王者", place: CUP, fac: "b19ring", battles: 1, F: ["F32"],
  hint: "§fルミナの §e闘技場§f で せいかん杯の 決勝 §7（仮面の 王者）",
  syn: "決勝の 相手は 仮面の 王者。つえを つき、腰が 少し 曲がって いた。手持ちに 白い 大きな 子は いない。手首に 干し草の 紐。",
  async run(p, d, K) {
    const v = ring(K, p);
    await K.open(p, "ルミナの 闘技場（せいかん杯）", "day");
    K.big(p, "§6§lけっしょう", "§f反対側の 門から、仮面の 人影が 歩いて くる", "raid.horn");
    let eM = NP(K, p, "§7仮面の 王者", "ordo"); K.act(eM, "hold"); K.hold(eM, "staff");
    if (ok(eM)) await K.walkCam(p, eM, MK(v, "champ") || K.fwd(p, 4), 18);
    await K.up(p, eM, 10);
    const wq = ok(eM) ? { x: eM.location.x, y: eM.location.y + 1, z: eM.location.z } : null;
    await K.at(p, wq, 14, 1.2, 0.1);
    await K.narr(p, ["§7仮面の 王者の 手首に、§f干し草で 編んだ 紐§7。三つ 編んで 一つ 返す、ふしぎな 編み目。"], wq);   /*F32*/
    let eR = REI(K, p);
    await K.say(p, "レイ", ["{?,…}……白い 大きいのが、いない。……あの 歩き方。あの 紐。"], eM);
    K.act(eM, "guard");
    if (!(await fightAt(K, p, K.team(["beast", "animal", "golem"], 88, 4, 40, K.leadOf("beast", 88)), { name: "仮面の 王者", speaker: "仮面の 王者", sboss: true, tag: "王者", lines: { half: "ほっほ。まだまだ！", low: "……よう 育ったのう" } }))) { await K.say(p, "仮面の 王者", ["{closed}……また 来なされ。"]); return false; }
    eM = again(K, p, eM, "§7仮面の 王者", K.PJ("ordo", 8)); eR = again(K, p, eR, "§bレイ", 17); K.act(eM, "kneel");
    await fin(K, p, { bye: [eM], leave: [eR], card: "§7→ 決勝の あと", kind: "day" });
    return true;
  } };

const E7 = { id: "b19e7", t: "二十年ぶりの 負け", place: CUP, fac: "b19ring", F: ["F09"],
  hint: "§fルミナの §e闘技場§f に 残ろう §7（仮面の 王者が 仮面に 手を かけた）",
  syn: "仮面の 王者は 仮面を 取った。オルドだった。「二十年ぶりに、負けたわい」。奥の 扉の 前の 床だけ、二十年分 すり減って いた。",
  async run(p, d, K) {
    const v = ring(K, p);
    await K.open(p, "ルミナの 闘技場（せいかん杯）", "day");
    const eO = NP(K, p, "§7仮面の 王者", "ordo"); K.act(eO, "kneel");
    await K.up(p, eO, 14);
    K.act(eO, "raise"); K.flash(p, true); K.sound(p, "random.orb", 1);
    try { if (ok(eO)) eO.nameTag = "§eオルド"; } catch {}
    K.act(eO, 0);
    await K.say(p, "オルド", ["{smile,…}……ほっほ。二十年ぶりに、負けたわい。"]);
    const eR = REI(K, p); K.re(eR, "shock", "!");
    await K.say(p, "レイ", ["{shock,!,up}……じいちゃん！？ 腰、痛いんじゃ なかったのかよ！"], eO);
    await K.say(p, "オルド", ["{smile,汗}痛いとも。……ほっほ。"]);
    K.sound(p, "random.levelup", 0.4); K.burst(p.dimension, MK(v, "center") || p.location, "minecraft:villager_happy", 10, 6, 1.5);
    const w = MK(v, "worn") || K.fwd(p, 9, 0, 0.1);
    await K.at(p, w, 18, 2.6, 0.2);
    await K.narr(p, ["§7闘技場の 奥の 扉。その 前の 床だけ、石が 丸く §fすり減って§7 いた。", "§7二十年、毎日 だれかが そこに 立って いた 跡だった。"], w);   /*F09*/
    await K.say(p, "レイ", ["{sad,?}……じいちゃん、ずっと あそこに 立ってたのか。"], eO);
    await K.say(p, "オルド", ["{closed}杯が 止まれば、扉の 前に 立つ 者が いなく なる。……仮面は、そのためじゃ。", "{sad}ハクを 連れて 出られん 決勝は、今日が 初めてじゃった。"]);
    setS0(p);
    K.pay(p, E7, 60000, [["e_rainbow", 1], ["e_king", 1]]);
    await fin(K, p, { leave: [eO, eR], card: "§6せいかん杯 優勝！ §7→ 闘技場の §e控え室§7 へ", kind: "day" });
    return true;
  } };
function setS0(p) { const d = load(p); if (!d) return; const s = qs(d); s.cup = Math.max(s.cup || 0, 8); s.ordoMask = 2; try { syncQuest(p, d); } catch {} save(p, d); }

const E8 = { id: "b19e8", t: "丸 ひとつが 一回", place: ROOM, fac: "b19room", F: ["F02"], keys: ["k_pic"], ans: ["qb011", "qb012"],
  hint: "§f闘技場の §e控え室§f へ 行こう §7（オルドが 待って いる）",
  syn: "控え室で、オルドは 小屋の 柱の 絵を 出した。丸ひとつが、名前を 一回 呼んだ 印。四歳の 冬、目を 覚まさない あなたを、あの 子が 朝まで 呼んだ。",
  async run(p, d, K) {
    const H = K.fac(p, "b19room", "hut", 0, Yof(K, p));
    await K.open(p, "闘技場の 控え室", "day");
    if (H) await K.at(p, H, 12, 5, 1.4);
    const eO = ORDO(K, p); K.act(eO, "show"); K.hold(eO, "scroll");
    await K.say(p, "オルド", ["{closed}……牧場の 柱の 絵じゃ。はがして 持って きた。"]);
    const q = ok(eO) ? { x: eO.location.x, y: eO.location.y + 1.1, z: eO.location.z } : K.fwd(p, 3, 0, 1);
    await K.at(p, q, 14, 1.3, 0.1);
    await K.narr(p, ["§7紙いっぱいの §f丸§7。小さな 手で、一つずつ 描いた 丸。"], q);
    const g = K.palEnt(p); if (g && ok(eO)) await K.approach(p, g, eO, 1);
    if (g) await K.up(p, g, 10);
    await K.narr(p, ["§7相棒が 鼻先で、丸を 一つずつ 数え はじめた。……十、二十……", "§7……とちゅうで、あきらめて 座りこんだ。"], g);
    K.rmCine(g);
    await K.say(p, "オルド", ["{closed}§e丸 ひとつが、一回じゃ§f。……名前を 一回 呼んだ 印じゃ。", "{sad}おまえさんが 四つの 冬じゃ。灰の 降った 晩、熱で 目を 覚まさなんだ。", "{closed,up}あの 子が、一晩じゅう 枕元で おまえさんの 名を 呼んだ。……§e朝まで 呼んだ§f。"]);   /*F02*/
    await K.push(p, eO, 22, 4.2, 1.7);
    await K.say(p, "オルド", ["{closed}朝、おまえさんは 目を 開けた。……あの 子は、呼んだ 数だけ 丸を 描いた。忘れんように、と 言うてな。", "{sad,low}それから じゃ。石板が、おまえさんの 名を 書けんのは。……一度 声で 呼び戻された 者の 名は、書けん。"]);
    await K.say(p, "レイ", ["{shock,…}……書けない、って そういう ことか。……選ばれたんじゃ ない。呼ばれて、戻ったんだ。"], eO);
    K.hold(eO); await K.give(eO, null, "scroll");
    await K.narr(p, ["§7オルドは 絵を たたんで、あなたに 渡した。§f柱の 丸の 絵§7。"]);
    K.key(p, "k_pic");
    K.pay(p, E8, 3000, []);
    await fin(K, p, { leave: [eO], card: "§7（だいじなもの: 柱の 丸の 絵）", kind: "day" });
    return true;
  } };

const E9 = { id: "b19e9", t: "引き返した", place: ROOM, fac: "b19room", F: ["F45"],
  hint: "§f闘技場の §e控え室§f に 残ろう §7（レイが じいちゃんに 聞きたい ことが ある）",
  syn: "オルドは レイに 一つだけ 言った。「わしは 引き返した。ハクを 選んだ」。それ以上は 言わなかった。",
  async run(p, d, K) {
    K.fac(p, "b19room", "hut", 0, Yof(K, p));
    await K.open(p, "闘技場の 控え室", "day");
    const eO = ORDO(K, p), eR = REI(K, p);
    face(K, eR, eO);
    await K.say(p, "レイ", ["{closed}……じいちゃん。しくじり帳に 写した じいちゃんの しくじり、一つだけ 白紙の 頁が あった。", "{?,up}二十年前。……何が あった。"], eO);
    await K.two(p, eO, eR, 14);
    K.act(eO, "kneel");
    await K.say(p, "オルド", ["{closed,low}……わしは 引き返した。", "{sad}ハクを 選んだ。"]);   /*F45*/
    await K.low(p, eR, 16);
    await K.say(p, "レイ", ["{sad,…}……それだけ、か。"]);
    await K.say(p, "オルド", ["{closed}……それだけじゃ。"], eR);
    K.act(eR, "show"); K.hold(eR, "notebook"); K.sound(p, "item.book.page_turn", 0.8);
    await K.narr(p, ["§7レイは 白紙の 頁に、一行だけ 書いた。§f『じいちゃんは、ハクを 選んだ』", "§7……しくじり、とは 書かなかった。"], eR);
    K.act(eR, 0); K.hold(eR); K.act(eO, 0);
    await fin(K, p, { leave: [eO, eR], card: "§7→ 闘技場の 奥の §e扉§7 へ", kind: "day" });
    return true;
  } };

const E10 = { id: "b19e10", t: "二度目", place: DOOR, fac: "b19ring", ans: [],
  hint: "§f闘技場の §e奥の 扉§f へ 行こう §7（オルドが 扉を 開ける）",
  syn: "オルドは 奥の 扉を 開けた。「わしは、ここまでじゃ。……二度目は、おまえさんが 行け」。",
  async run(p, d, K) {
    const v = ring(K, p);
    await K.open(p, "闘技場の 奥の 扉", "day");
    const dq = MK(v, "door") || K.fwd(p, 4, 0, 1);
    await K.at(p, dq, 14, 3, 1.2);
    const eO = ORDO(K, p), eR = REI(K, p);
    if (ok(eO)) await K.approach(p, eO, dq, 1);
    K.act(eO, "raise"); K.sound(p, "random.door_open", 0.8);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, dq, "minecraft:white_smoke_particle", 6, 0.8, 0.5); await K.wait(4); }
    await K.narr(p, ["§7重い 扉が 開いた。下へ 続く 石段。冷たい 風に、灰の においが 混じって いる。"], dq);
    toP(K, p, eO); await K.up(p, eO, 12);
    await K.say(p, "オルド", ["{closed}わしは、ここまでじゃ。", "{smile,…,up}……二度目は、おまえさんが 行け。"]);
    await K.say(p, "レイ", ["{closed}……オレは 上だ。客席で、呼ぶ 声が いる なら、一番 でかいのを 出す。"], eO);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……したの におい、ほしの においと、はいの におい。"]); K.rmCine(g); }
    K.act(eO, 0);
    await fin(K, p, { leave: [eO, eR], card: "§f― 第19章 闘技場の杯 おわり ―\n§7→ 扉の 下へ（右上の 案内）", kind: "day", t: 56 });
    return true;
  } };

bkAdd("b19", [E1, E2, E3, E4, E5, E6, E7, E8, E9, E10]);
