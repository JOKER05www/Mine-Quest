// 第124版: 遊び場の 遊びを 作り直す（かくれんぼ・おにごっこ・かけっこ・水泳・迷路・宝さがし・相撲・足場わたり）
// ・相棒と 旅の 仲間（ヒロイン）も 選手として 走る・泳ぐ・隠れる・探す。宝さがしは ヒント、相撲は 応援
// ・動きは 毎tick（遊んで いる 人の ぶんだけ。だれも 遊んで いなければ すぐ 戻る）。小さく 進めて 向きを 合わせる。壁は よけて すべる
// ・難易度は やさしい・ふつう・むずかしい。記録・称号・なつき度・たまに 道具（1日 3回まで）
// ・終わる とき（勝ち・負け・抜ける・倒れる・時間切れ）は 出した もの・止めた 状態・効果を ぜんぶ 片づける
import { world, system, MolangVariableMap, BlockPermutation } from "@minecraft/server";
import { load, save } from "./store.js";
import { SPECIES, ITEMS } from "./data.js";
import { choose, ICON, barNote, showTitle, anim, busy, giveItem } from "./ui.js";
import { setLook, TYPE, hooks } from "./field.js";
import { HIT_HOOKS } from "./battle.js";
import { NPC_HOOKS } from "./npchook.js";
import { emote, face } from "./direct.js";
import { heroInfo, heroSpawn, heroDespawn, heroSwim, heroLine } from "./heroswim.js";
import * as EG from "./endgame.js";

const OWID = "minecraft:overworld", OW = () => world.getDimension(OWID);
const run = (c) => { try { OW().runCommand(c); return true; } catch { return false; } };
const bk = (...ids) => { for (const id of ids) { try { BlockPermutation.resolve(`minecraft:${id}`); return id; } catch {} } return "stone"; };
const wait = (t) => new Promise((r) => system.runTimeout(r, Math.max(1, t)));
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const H = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const shuf = (L) => { for (let i = L.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [L[i], L[j]] = [L[j], L[i]]; } return L; };
const sec = (t) => Math.max(0, Math.ceil(t / 20));
const LEAF = () => `${bk("oak_leaves", "leaves")} ["persistent_bit"=true]`;

export const NAME = { hide: "かくれんぼ", tag: "おにごっこ", race: "かけっこ", swim: "水泳競争", maze: "迷路", sand: "宝さがし", sumo: "相撲", park: "足場わたり" };
const DV = [["やさしい", "§a"], ["ふつう", "§e"], ["むずかしい", "§c"]];
const DESC = {
  hide: ["ヒント 多め・ゆっくり 探す", "ちょうど いい", "ヒント 少なめ・よく 見る 鬼"], tag: ["相棒は 少し ゆっくり", "ダッシュと 同じ 速さ", "ダッシュより 少し 速い"],
  race: ["相手は ゆっくり", "いい 勝負", "ダッシュジャンプで やっと"], swim: ["相手は ゆっくり", "いい 勝負", "全力で 泳いで やっと"],
  maze: ["7×7・道を よく 教える", "9×9", "11×11・道案内は 少し"], sand: ["宝 2つ・ヒント くわしい", "宝 3つ", "宝 4つ・ヒント 少し"],
  sumo: ["押しの 合図が ゆっくり", "ふつう", "相棒が 強い"], park: ["くずれる 足場 なし", "くずれる 足場 2つ", "くずれる 足場 3つ"],
};

/* ================= 記録・ほうび ================= */
const RK = "mrpg:pg";
const today = () => Math.floor((Date.now() + 9 * 3600e3) / 86400e3);
function recLoad(p) { let o = null; try { const v = p.getDynamicProperty(RK); if (typeof v === "string") o = JSON.parse(v); } catch {} o = o && typeof o === "object" ? o : {}; o.b = o.b || {}; o.w = o.w || {}; o.c = o.c || {}; return o; }
function recSave(p, o) { try { p.setDynamicProperty(RK, JSON.stringify(o)); } catch {} }
const recKey = (g) => `${g.kind}:${g.dv}${g.kind === "hide" || g.kind === "tag" ? `:${g.role}` : ""}`;
const PG_TITLES = {
  pg_win: ["遊び場の 友だち", "遊び場の 遊びで はじめて 勝つ"], pg_hide: ["かくれんぼ名人", "かくれんぼ（むずかしい）で 勝つ"], pg_tag: ["にげ足の 達人", "おにごっこ（むずかしい）で 勝つ"],
  pg_race: ["風の 走り手", "かけっこ（むずかしい）で 1位"], pg_swim: ["水の 走り手", "水泳競争（むずかしい）で 1位"], pg_maze: ["迷路の 主", "迷路（むずかしい）で 勝つ"],
  pg_sand: ["砂浜の 探検家", "宝さがし（むずかしい）で 全部 見つける"], pg_sumo: ["土俵の 主", "相撲（むずかしい）で 勝つ"], pg_park: ["身軽な 足", "足場わたり（むずかしい）で 勝つ"],
  pg_all: ["遊び場の 王", "8つの 遊び すべてで 勝つ"],
};
system.run(() => { try { for (const [k, v] of Object.entries(PG_TITLES)) if (EG.TITLES && !EG.TITLES[k]) EG.TITLES[k] = v; } catch {} });
const fmtRec = (kind, v) => (kind === "sand" ? `${v}点` : kind === "sumo" ? `${v}勝` : `${v}秒`);
function reward(g, res) {
  const p = g.p, R = recLoad(p), key = recKey(g), out = []; let isNew = false;
  if (R.d !== today()) { R.d = today(); R.c = {}; }
  if (typeof res.rec === "number" && Number.isFinite(res.rec)) { const b = R.b[key]; if (b === undefined || (res.low ? res.rec < b : res.rec > b)) { R.b[key] = res.rec; isNew = b !== undefined; if (b === undefined) out.push(`§b記録: ${fmtRec(g.kind, res.rec)}`); } }
  if (isNew) out.push(`§b§l新記録！ §r§b${fmtRec(g.kind, res.rec)}`);
  if (res.win) {
    R.w[g.kind] = (R.w[g.kind] || 0) + 1;
    const n = R.c[g.kind] || 0;
    if (n < 3) {
      R.c[g.kind] = n + 1;
      try { if (hooks.addNkOut) hooks.addNkOut(p, 3 + g.dv, `遊び場:${NAME[g.kind]}`); } catch {}
      if (Math.random() < [0.15, 0.3, 0.5][g.dv]) { const id = pick(g.dv === 2 ? ["c_fruit", "c_water", "c_herb2"] : ["c_herb2", "c_water"]); if (ITEMS[id]) { try { giveItem(p, `mrpg:${id}`, 1); out.push(`§aごほうび: ${ITEMS[id].name}`); } catch {} } }
      out.push(`§d${g.m ? g.m.nm : "相棒"}が とても よろこんで いる §7（今日の ごほうび あと ${2 - n}回）`);
    } else out.push("§7（今日の ごほうびは おしまい。記録は のこる）");
    try { const d = load(p); if (d && EG.award) { let a = EG.award(p, d, "pg_win"); if (g.dv === 2) a = EG.award(p, d, `pg_${g.kind}`) || a; if (Object.keys(NAME).every((k) => R.w[k])) a = EG.award(p, d, "pg_all") || a; if (a) save(p, d); } } catch {}
  }
  recSave(p, R);
  for (const s of out) try { p.sendMessage(s); } catch {}
  return isNew;
}
export function recText(p, kind) {
  const R = recLoad(p), L = [];
  for (let dv = 0; dv < 3; dv++) for (const r of kind === "hide" || kind === "tag" ? [0, 1] : [null]) { const k = `${kind}:${dv}${r === null ? "" : `:${r}`}`; if (R.b[k] !== undefined) L.push(`${DV[dv][1]}${DV[dv][0]}${r === null ? "" : r ? "（隠れる）" : "（鬼）"} §f${fmtRec(kind, R.b[k])}`); }
  const left = R.d === today() ? 3 - (R.c[kind] || 0) : 3;
  return `§7勝った 回数 ${R.w[kind] || 0}  今日の ごほうび あと ${Math.max(0, left)}回\n${L.length ? L.join("\n") : "§8記録 なし"}`;
}

/* ================= 共通: 粒・音・字幕 ================= */
const COL = { gold: [1, 0.85, 0.3], red: [1, 0.35, 0.3], pink: [1, 0.6, 0.8], green: [0.5, 1, 0.5], sky: [0.6, 0.85, 1], white: [1, 1, 1], purple: [0.8, 0.5, 1], yellow: [1, 1, 0.4] };
function fx(id, at, c = COL.white, sc = 1) { try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: c[0], green: c[1], blue: c[2] }); m.setFloat("variable.scale", sc); OW().spawnParticle(`mrpg:${id}`, at, m); } catch {} }
function vfx(id, at) { try { OW().spawnParticle(id, at); } catch {} }
function snd(p, id, pitch = 1, vol = 0.8, at) { try { if (at) OW().playSound(id, at, { pitch, volume: vol }); else p.playSound(id, { pitch, volume: vol }); } catch { try { p.playSound(id, { pitch, volume: vol }); } catch {} } }
const big = (p, t, s = "", st = 30) => { try { showTitle(p, t, { subtitle: s, fadeInDuration: 0, stayDuration: st, fadeOutDuration: 6 }); } catch {} };
function bar(g, s) { if ((g.noteT || -1e9) > g.t) return; if (g.hudS === s && g.t - (g.hudT || 0) < 30) return; g.hudS = s; g.hudT = g.t; try { barNote(g.p).setActionBar(s); } catch {} }
const note = (g, s) => { g.hudS = s; g.hudT = g.t; g.noteT = g.t + 30; try { barNote(g.p).setActionBar(s); } catch {} };   /* お知らせは 1.5秒 のこす */
/* 花火と 紙吹雪 */
function confetti(at, n = 10) { const C = [COL.gold, COL.red, COL.pink, COL.green, COL.sky, COL.purple]; for (let k = 0; k < n; k++) { const a = Math.random() * 6.28, r = rnd(0.5, 2.2); fx(k % 3 ? "star" : "shards", { x: at.x + Math.cos(a) * r, y: at.y + rnd(1.5, 3.2), z: at.z + Math.sin(a) * r }, pick(C), rnd(0.5, 0.9)); } }
function firework(p, at) { const C = pick([COL.gold, COL.red, COL.sky, COL.pink, COL.green]), q = { x: at.x + rnd(-3, 3), y: at.y + rnd(6, 9), z: at.z + rnd(-3, 3) }; for (let k = 0; k < 12; k++) { const a = (k / 12) * 6.28; fx("sparks", { x: q.x + Math.cos(a) * 1.6, y: q.y + Math.sin(k) * 0.6, z: q.z + Math.sin(a) * 1.6 }, C, 0.8); } snd(p, "firework.blast", rnd(0.9, 1.2), 0.7); }

/* ================= ヒロインの ひとこと（4つの 型・短く）================= */
const HL = {
  start: { g: ["負けないよ！", "よーし、いっくよー！"], o: ["のんびり がんばろうね〜", "ふふ、楽しみ〜"], c: ["手加減は しないから", "ま、勝つのは わたしだけど"], t: ["よろしく お願いします！", "全力で まいります"] },
  win: { g: ["くやしー！ もう一回！", "すごい すごい！"], o: ["わあ、すごいねえ〜", "負けちゃった〜"], c: ["……やるじゃない", "次は 負けないから"], t: ["お見事です！", "さすがです"] },
  lose: { g: ["やったー！ わたしの 勝ち！", "へへーん！"], o: ["あら、勝っちゃった〜", "ふふ、ごめんね〜"], c: ["当然の 結果ね", "まだまだね"], t: ["勝たせて いただきました", "次も 負けません"] },
  found: { g: ["わっ！ 見つかった〜！", "ずるーい、早いよ！"], o: ["あらあら、見つかっちゃった〜", "ふふ、見つけてくれた〜"], c: ["……ちっ、見つかった", "いい目 してるじゃない"], t: ["見つかって しまいました", "お見事な 目です"] },
  seek: { g: ["みーつけた！", "そこだー！"], o: ["みつけた〜", "ふふ、そこね〜"], c: ["そこ、丸見え", "見えてるわよ"], t: ["見つけましたよ", "そちらですね"] },
  count: { g: ["いーち、にーい……", "10 数えるよー！"], o: ["ゆっくり 数えるね〜", "いーち……にーい……"], c: ["10 数えるから", "早く 隠れなさい"], t: ["10 数えます", "どうぞ、お隠れください"] },
  lost: { g: ["あれー？ どこ いった？"], o: ["あら〜？ 見えなくなっちゃった"], c: ["……逃げ足だけは 速いわね"], t: ["見失いました……"] },
  tagYou: { g: ["タッチ！ 鬼だよ〜！"], o: ["タッチ〜 鬼さんね〜"], c: ["タッチ。次は あなた"], t: ["タッチです！ 鬼を どうぞ"] },
  tagged: { g: ["きゃー！ つかまった！"], o: ["あら〜 つかまっちゃった"], c: ["……油断した"], t: ["くっ、不覚です"] },
  taunt: { g: ["こっち こっち〜！"], o: ["鬼さん こちら〜"], c: ["遅いわね"], t: ["こちらですよ"] },
  hint: { g: ["{d}が あやしい！", "{d}かな？ ピンと きた！"], o: ["{d}かしら〜", "なんとなく {d}……"], c: ["{d}。たぶんね", "勘だけど {d}"], t: ["{d}が 気に なります", "{d}を 調べて みては"] },
  dug: { g: ["やったね！ 宝だ！"], o: ["わあ、きらきら〜"], c: ["……やるじゃない"], t: ["お見事です！"] },
  cheer: { g: ["いけー！ 押せー！", "がんばれー！"], o: ["がんばって〜", "ふぁいと〜"], c: ["押しなさいよ", "ほら、そこよ"], t: ["がんばって ください！", "あと 一息です！"] },
  cp: { g: ["まだまだ！"], o: ["待って〜"], c: ["ふん、まだよ"], t: ["追いつきます！"] },
};
function hl(g, key, o = {}) {
  const a = g.hero; if (!a || !okE(a.e)) return;
  if (!o.force && g.t - (g.hlT ?? -999) < 50) return; g.hlT = g.t;
  const L = HL[key]; if (!L) return; const L2 = {}; for (const k of Object.keys(L)) L2[k] = L[k].map((s) => s.replace("{d}", o.d || ""));
  try { heroLine(g.p, L2, a.e, o.act); } catch {}
  if (o.face) face(a.e, o.face, 40);
}

/* ================= 共通: 選手（相棒・ヒロイン）================= */
const outMon = (p) => { const d = load(p); if (!d || !d.out) return null; return [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out) || null; };
const spdK = (sid) => { const b = SPECIES[sid]?.base || {}; return Math.max(0.94, Math.min(1.06, 0.92 + (b.spd || 5) * 0.02)); };
function mkA(g, e, who, nm, k, at) { const a = { e, who, nm, k, x: at.x, y: at.y, z: at.z, yaw: 0, v: 0, vx: 0, vz: 0, mv: false, run: false, side: Math.random() < 0.5 ? 1 : -1, st: "", tt: 0, stuck: 0 }; g.A.push(a); return a; }
function mkPal(g, at, look) {
  const m = g.m; let e = null; try { e = OW().spawnEntity(TYPE, at); } catch { return null; } g.ents.push(e);
  try { e.addTag("mrpg_play"); e.addTag("mrpg_pg"); e.setDynamicProperty("mrpg:pown", g.pid); setLook(e, m.sp, m); e.triggerEvent("mrpg:make_battle"); e.nameTag = `§e${m.nm}`; } catch {}
  const a = mkA(g, e, "pal", m.nm, spdK(m.sp), at); g.pal = a; if (look) put(a, at.x, at.y, at.z, look.x, look.z); return a;
}
function mkHero(g, at, look) {
  const h = heroInfo(g.p); if (!h) return null;
  let e = null; try { e = heroSpawn(g.p, at, { swim: g.kind === "swim", tags: ["mrpg_play", "mrpg_pg"] }); } catch {} if (!e) return null;
  try { e.setDynamicProperty("mrpg:pown", g.pid); } catch {} g.ents.push(e);
  const a = mkA(g, e, "hero", h.name, 1, at); a.ht = h.t; g.hero = a; if (look) put(a, at.x, at.y, at.z, look.x, look.z); return a;
}
const yawTo = (a, x, z) => Math.atan2(z - a.z, x - a.x);
function put(a, x, y, z, lx, lz, ly) {
  a.vx = x - a.x; a.vz = z - a.z; a.x = x; a.y = y; a.z = z;
  if (lx !== undefined && (Math.abs(lx - x) > 0.01 || Math.abs(lz - z) > 0.01)) a.yaw = Math.atan2(lz - z, lx - x);
  try { a.e.teleport({ x, y, z }, { facingLocation: { x: x + Math.cos(a.yaw) * 2, y: ly ?? y + 0.9, z: z + Math.sin(a.yaw) * 2 } }); } catch {}
}
function moving(a, on, runK = false) {
  if (a.who !== "hero") return;
  if (a.mv !== on) { a.mv = on; try { a.e.setProperty("mrpg:mv", on); } catch {} }
  const r = on && runK; if (a.run !== r) { a.run = r; try { a.e.setProperty("mrpg:act", r ? 19 : 0); } catch {} }
}
const pose = (a, n) => { if (a && a.who === "hero") { a.run = false; try { a.e.setProperty("mrpg:act", n); } catch {} } };
const joy = (g, a) => { if (!a || !okE(a.e)) return; if (a.who === "pal") anim(a.e, "happy"); else { pose(a, 9); face(a.e, "smile", 60); } emote(a.e, pick(["heart", "note", "spark"])); };
const sulk = (g, a) => { if (!a || !okE(a.e)) return; if (a.who === "pal") anim(a.e, "hurt"); else { pose(a, 12); face(a.e, "sad", 60); } emote(a.e, pick(["sweat", "sigh"])); };

/* ブロックの 見分け（0 とおれる・1 かたい・2 水）。遊びの 間は 島の 形が 変わらないので おぼえて おく */
const NS = /(^minecraft:(short_|tall_)?grass$)|flower|poppy|dandelion|daisy|cornflower|tulip|allium|orchid|bluet|fern|carpet|torch|lily|button|rail|sign|vine|sapling|mushroom|snow_layer|seagrass|kelp|pressure|bush|lantern/;
function bt(x, y, z) { try { const b = OW().getBlock({ x, y, z }); if (!b || b.isAir) return 0; const t = b.typeId || ""; if (b.isLiquid || /water/.test(t)) return 2; if (b.isSolid === false || NS.test(t)) return 0; return 1; } catch { return 1; } }
function sol(g, x, y, z) { const X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z), k = `${X},${Y},${Z}`; let v = g.bc.get(k); if (v === undefined) { v = bt(X, Y, Z); if (g.bc.size > 6000) g.bc.clear(); g.bc.set(k, v); } return v; }
const inR = (g, x, z, r = 29.5) => Math.hypot(x - g.c.x - 0.5, z - g.c.z - 0.5) < r;
const clear = (g, x, z) => inR(g, x, z) && sol(g, x, g.c.y, z) !== 1 && sol(g, x, g.c.y + 1, z) !== 1;
const floorY = (g, x, z) => (sol(g, x, g.c.y - 1, z) === 2 ? g.c.y - 0.45 : g.c.y);
function turnTo(y0, y1, mx) { let d = y1 - y0; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return y0 + Math.max(-mx, Math.min(mx, d)); }
function detour(g, a, want) {
  for (const o of [0.5, 1.0, 1.5, 2.1, 2.7]) for (const s of [a.side, -a.side]) { const h = want + o * s; if (clear(g, a.x + Math.cos(h) * 0.8, a.z + Math.sin(h) * 0.8) && clear(g, a.x + Math.cos(h) * 1.6, a.z + Math.sin(h) * 1.6)) { if (o >= 1.0) a.side = s; return h; } }
  return want + Math.PI;
}
/* 1歩: 向きの 先が かたければ 横に すべる。それも だめなら 止まって 向きを 変える */
function step(g, a, v) {
  const cx = Math.cos(a.yaw), cz = Math.sin(a.yaw), r = 0.32;
  let nx = a.x + cx * v, nz = a.z + cz * v;
  if (!clear(g, nx + cx * r, nz + cz * r) || !clear(g, nx, nz)) {
    if (clear(g, nx + cx * r, a.z) && clear(g, nx, a.z)) nz = a.z;
    else if (clear(g, a.x, nz + cz * r) && clear(g, a.x, nz)) nx = a.x;
    else { nx = a.x; nz = a.z; a.v *= 0.3; if (++a.stuck > 6) { a.yaw += (Math.PI / 2) * a.side; a.stuck = 0; } }
  } else a.stuck = 0;
  let y = floorY(g, nx, nz); if (a.hop > 0) { a.hop--; y += Math.sin(Math.PI * (1 - a.hop / 8)) * 0.7; }
  const sw = y < g.c.y - 0.1; if (sw) a.v = Math.min(a.v, 0.12);
  put(a, nx, y, nz, nx + cx, nz + cz);
  moving(a, v > 0.02, v > 0.18 && !sw);
}
/* (tx,tz) へ むかう（加速・曲がる 速さ つき）。のこりの きょりを 返す */
function drive(g, a, tx, tz, spd, turn = 0.4) {
  const dx = tx - a.x, dz = tz - a.z, d = Math.hypot(dx, dz);
  if (d < 0.1) { a.v = 0; moving(a, false); return 0; }
  let want = Math.atan2(dz, dx);
  if (!clear(g, a.x + Math.cos(want) * 0.8, a.z + Math.sin(want) * 0.8)) want = detour(g, a, want);
  const y0 = a.yaw; a.yaw = turnTo(a.yaw, want, turn); if (Math.abs(a.yaw - y0) > 0.3) a.v *= 0.92;
  const tv = Math.min(spd, d); a.v += Math.max(-0.08, Math.min(0.045, tv - a.v));
  step(g, a, a.v); return d;
}
/* 決まった 線の 上を 動く（迷路の 通路・コース）。ぶつかりは 見ない */
function glide(a, tx, ty, tz, spd) { const dx = tx - a.x, dz = tz - a.z, d = Math.hypot(dx, dz); if (d < 0.02) { moving(a, false); return 0; } const k = Math.min(spd, d) / d; put(a, a.x + dx * k, ty, a.z + dz * k, tx, tz); moving(a, true, spd > 0.18); return d - Math.min(spd, d); }

/* ================= 共通: はじまり・おわり ================= */
export const G = new Map();   /* pid -> 遊びの 状態 */
const ASK = new Set(), COOL = new Map(), LOCK = new Map();   /* LOCK: "sumo:島" / "maze:島" -> pid の Set */
const GAMES = {};
export const cool = (pid) => (COOL.get(pid) || 0) > system.currentTick || ASK.has(pid);
export const owns = (id) => { for (const g of G.values()) if (g.ents.some((e) => { try { return e.id === id; } catch { return false; } })) return true; return false; };

/* 台に 立つと: 難易度を えらんで はじめる */
export async function ask(p, kind, c, k) {
  if (G.has(p.id) || ASK.has(p.id) || !GAMES[kind]) return;
  ASK.add(p.id);
  try {
    const btn = DV.map(([n, col], i) => [`${col}§l${n}§r\n§8${DESC[kind][i]}`, ICON("i_run")]);
    const dv = await choose(p, `§l${NAME[kind]}`, `${INTRO[kind]}\n${recText(p, kind)}`, [...btn, ["§7やめる", ICON("i_back")]], false);
    if (!(dv >= 0 && dv < 3)) return;
    let role = 0;
    if (kind === "hide" || kind === "tag") {
      const R = kind === "hide" ? [["§l探す §8あなたが 鬼", ICON("i_zukan")], ["§lかくれる §8相棒たちが 鬼", ICON("i_run")]] : [["§lにげる §8相棒が 鬼", ICON("i_run")], ["§l追う §8あなたが 鬼", ICON("i_zukan")]];
      role = await choose(p, `§l${NAME[kind]}`, "§fどっちを やる？", [...R, ["§7やめる", ICON("i_back")]], false);
      if (!(role === 0 || role === 1)) return;
    }
    begin(p, kind, c, k, dv, role);
  } finally { ASK.delete(p.id); }
}
const INTRO = {
  hide: "§f鬼は 隠れた 子を 時間内に ぜんぶ 見つける。\n§7隠れる ときは しゃがむと 見つかりにくい・走ると 音で ばれる",
  tag: "§f鬼に さわられたら 鬼の 交代。終わった ときに 鬼で なければ 勝ち",
  race: "§fチェックポイントの 門を 通って 1周。ハードル・ジャンプ台・水路が ある", swim: "§f水路を 1周。門を 通る・低い 橋は もぐって くぐる",
  maze: "§f毎回 ちがう 迷路。宝箱を ひろって ゴールへ。行き止まりの 罠に 注意", sand: "§f砂を こわして 宝を ほる。相棒の 鼻と 仲間の 勘が たより",
  sumo: "§f相棒を たたいて 押しだす。合図が 緑の ときに たたくと 強い。しゃがむと 踏ん張る。2本 先取", park: "§f足場を とんで 南の 金へ。落ちたら やりなおし",
};
export function begin(p, kind, c, k, dv, role = 0) {
  if (G.has(p.id)) return null;
  const m = outMon(p); if (!m) { try { barNote(p).setActionBar("§7連れ歩きの 子が いないと 遊べない"); } catch {} return null; }
  const g = { p, pid: p.id, kind, c, k, dv, role, m, t: -60, A: [], ents: [], rest: [], effs: new Set(), fin: [], bc: new Map(), sc: 0, lim: 0, hero: null, pal: null };
  G.set(p.id, g);
  try { if (GAMES[kind].init(g) === false) { cleanup(g); G.delete(p.id); return null; } } catch (e) { console.warn(`[MonsterRPG] pgame init ${kind}: ${e} ${e?.stack || ""}`); cleanup(g); G.delete(p.id); return null; }
  if (!g.noIntro) big(p, `§e§l${NAME[kind]}`, `${DV[dv][1]}${DV[dv][0]}`, 40);
  if (g.hero && kind !== "sumo" && kind !== "sand") hl(g, "start", { force: true, act: 9 });
  return g;
}
function addEff(g, id, t, amp = 0) { try { g.p.addEffect(id, t, { amplifier: amp, showParticles: false }); g.effs.add(id); } catch {} }
/* おわり（res.win: true 勝ち・false 負け・null 引き分け）。少し 喜んで から 片づける */
function end(g, res) {
  if (g.post !== undefined) return;
  g.post = 50; g.res = res; const p = g.p;
  big(p, res.win ? "§a§l勝ち！" : res.win === false ? "§c§l負け…" : "§7§lおしまい", res.msg || "", 50);
  snd(p, res.win ? "random.levelup" : res.win === false ? "note.bass" : "random.orb", res.win === false ? 0.6 : 1, 1);
  if (res.win) snd(p, "firework.launch", 1, 0.8);
  for (const a of g.A) { a.v = 0; moving(a, false); }
  if (g.hero) { if (g.kind === "sand" || g.kind === "sumo") { if (res.win) { joy(g, g.hero); hl(g, "dug", { force: true }); } else sulk(g, g.hero); } else if (res.win) { sulk(g, g.hero); hl(g, "win", { force: true }); system.runTimeout(() => { try { if (okE(g.hero?.e)) pose(g.hero, 6); } catch {} }, 30); } else { joy(g, g.hero); hl(g, "lose", { force: true }); } }
  if (g.pal) { if (res.win || g.kind !== "maze") joy(g, g.pal); else sulk(g, g.pal); }
  try { g.isNew = reward(g, res); } catch {}
}
function post(g) {
  const p = g.p, l = p.location;
  if (g.res.win && g.post % 8 === 0) { confetti(l, 8); if (g.post % 16 === 0) firework(p, l); }
  if (g.isNew && g.post === 40) { big(p, "§b§l新記録！", g.res.msg || "", 30); snd(p, "random.toast", 1, 1); }
  for (const a of g.A) if (g.post % 10 === 0 && okE(a.e)) { if (g.res.win === false || (a.who === "pal" && g.kind !== "maze")) { if (a.who === "pal") anim(a.e, "atk_jump"); } }
  if (--g.post <= 0) { cleanup(g); G.delete(g.pid); COOL.set(g.pid, system.currentTick + 60); again(g); }
}
/* もう一回？ */
async function again(g) {
  const p = g.p; if (!okE(p)) return;
  await wait(10);
  if (G.has(p.id) || ASK.has(p.id) || busy.has(p.id)) return;
  try { if (typeof p.getDynamicProperty("mrpg:pret") !== "string") return; } catch { return; }
  ASK.add(p.id);
  try {
    const r = await choose(p, `§l${NAME[g.kind]}`, `${g.res.msg || ""}\n${recText(p, g.kind)}`, [["§l§aもう一回", ICON("i_run")], ["§l難易度を かえる", ICON("i_skill")], ["§7おわる", ICON("i_back")]], false);
    if (r === 0) { ASK.delete(p.id); begin(p, g.kind, g.c, g.k, g.dv, g.role); }
    else if (r === 1) { ASK.delete(p.id); await ask(p, g.kind, g.c, g.k); }
  } finally { ASK.delete(p.id); }
}
/* 片づけ（何回 呼んでも よい）*/
function cleanup(g) {
  if (g.clean) return; g.clean = true;
  for (const f of g.fin) try { f(); } catch {}
  for (const a of g.A) if (a.who === "hero") try { heroDespawn(g.p, a.e); } catch {}
  for (const e of g.ents) try { if (okE(e)) e.remove(); } catch {}
  for (let i = g.rest.length - 1; i >= 0; i--) { const [x, y, z, b] = g.rest[i]; run(`setblock ${x} ${y} ${z} ${b}`); }
  g.rest = [];
  for (const id of g.effs) try { g.p.removeEffect(id); } catch {}
  if (g.swimOn) try { heroSwim(g.p, false); } catch {}
  for (const [k, S] of LOCK) { S.delete(g.pid); if (!S.size) LOCK.delete(k); }
  try { barNote(g.p).setActionBar(""); } catch {}
}
/* とちゅうで やめる（抜けた・倒れた・戦い・島を はなれた）。ほうびは なし */
export function stop(pid, why) {
  const g = G.get(pid); if (!g) { ASK.delete(pid); return; }
  G.delete(pid); cleanup(g);
  if (why && okE(g.p)) try { barNote(g.p).setActionBar(`§7${NAME[g.kind]}は おしまい（${why}）`); } catch {}
}
export const has = (pid) => G.has(pid);
const lockTake = (key, pid) => { const S = LOCK.get(key) || new Set(); if (S.size && !S.has(pid) && key.startsWith("sumo")) return false; S.add(pid); LOCK.set(key, S); return true; };

/* 毎tick（遊んで いる 人だけ）*/
system.runInterval(() => {
  if (!G.size) return;
  for (const g of [...G.values()]) {
    if (!okE(g.p)) { stop(g.pid); continue; }
    if (g.post !== undefined) { try { post(g); } catch { cleanup(g); G.delete(g.pid); } continue; }
    if (busy.has(g.pid)) continue;   /* 画面を 開いて いる 間は 止める */
    try { tick(g); } catch (e) { console.warn(`[MonsterRPG] pgame ${g.kind}: ${e} ${e?.stack || ""}`); stop(g.pid, "エラー"); }
  }
}, 1);
function tick(g) {
  const p = g.p, l = p.location, GM = GAMES[g.kind];
  g.t++;
  if (g.t < 0) {
    if (!g.noCount && (g.t === -60 || g.t === -40 || g.t === -20)) { big(p, g.t === -60 ? "§c§l3" : g.t === -40 ? "§6§l2" : "§e§l1", "", 14); snd(p, "note.hat", 1, 1); }
    if (GM.pre) GM.pre(g, l); return;
  }
  if (g.t === 0 && !g.noCount) { big(p, "§a§lスタート！", "", 20); snd(p, "note.pling", 1.4, 1); }
  if (g.t === 0 && GM.go) GM.go(g, l);
  GM.tick(g, l);
  if (g.post !== undefined || G.get(g.pid) !== g) return;
  if (g.lim && g.t >= g.lim) { GM.timeup(g, l); return; }
  if (g.t % (g.kind === "sumo" ? 1 : 4) === 0) bar(g, GM.hud(g, l));   /* 相撲は 押しの 合図が 速いので 毎tick */
}
const left = (g) => `のこり ${sec(g.lim - g.t)}秒`;
const holdAt = (g, at, r = 1.2) => { try { const l = g.p.location; if (H(l, at) > r) g.p.teleport({ x: at.x, y: at.y ?? l.y, z: at.z }, at.f ? { facingLocation: at.f } : undefined); } catch {} };

/* たたいた・話しかけた（相棒の 写しは 戦いに しない・ヒロインは 店の 画面を 出さない）*/
function onHit(p, e) {
  let own = null; try { own = e.getDynamicProperty("mrpg:pown"); } catch {}
  const g = G.get(p.id); if (!g || own !== p.id || g.post !== undefined || g.t < 0) return true;
  const a = g.A.find((x) => { try { return x.e.id === e.id; } catch { return false; } }); if (!a) return true;
  const GM = GAMES[g.kind]; if (GM.hit) try { GM.hit(g, a, p.location); } catch {}
  return true;
}
system.run(() => {
  HIT_HOOKS.unshift((p, e) => { try { if (!e.hasTag("mrpg_pg")) return false; e.getComponent("minecraft:health")?.resetToMaxValue(); } catch { return false; } return onHit(p, e); });
  NPC_HOOKS.unshift((p, e) => { try { if (e.hasTag("mrpg_isleh")) return true; if (!e.hasTag("mrpg_pg")) return false; } catch { return false; } system.run(() => { try { onHit(p, e); } catch {} }); return true; });
});
try { world.afterEvents.entityDie.subscribe(({ deadEntity: e }) => { try { if (e?.typeId === "minecraft:player" && G.has(e.id)) stop(e.id, "倒れた"); } catch {} }); } catch {}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { stop(playerId); COOL.delete(playerId); ASK.delete(playerId); LAST.delete(playerId); }); } catch {}
/* 起動した とき: 前に 残った 遊びの 選手を 片づける */
system.runTimeout(() => { try { for (const e of OW().getEntities({ tags: ["mrpg_pg"] })) if (!owns(e.id)) e.remove(); } catch {} }, 120);   /* 島の そばに いる 仲間（mrpg_isleh）は heroswim.js が 片づける */

/* ================= 島の 形（islands.js の build から 呼ぶ）================= */
const F = (c, x1, y1, z1, x2, y2, z2, b) => run(`fill ${c.x + x1} ${c.y + y1} ${c.z + z1} ${c.x + x2} ${c.y + y2} ${c.z + z2} ${b}`);
const S1 = (c, x, y, z, b) => run(`setblock ${c.x + x} ${c.y + y} ${c.z + z} ${b}`);
function palm(c, x, z) { const log = bk("jungle_log", "log"), leaf = LEAF().replace("oak_leaves", bk("jungle_leaves", "oak_leaves")); F(c, x, 0, z, x, 4, z, log); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) S1(c, x + dx, 4 - (Math.abs(dx) + Math.abs(dz) > 1 ? 1 : 0), z + dz, leaf); S1(c, x, 5, z, leaf); }
/* 角の まるい 四角（コースの 中心線までの きょり）*/
function sdRR(x, z, hx, hz, r) { const qx = Math.abs(x) - (hx - r), qz = Math.abs(z) - (hz - r); return Math.hypot(Math.max(qx, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, qz), 0) - r; }
async function rows(c, y1, y2, pred, b) {
  for (let z = -33; z <= 33; z++) {
    let x0 = null;
    for (let x = -33; x <= 34; x++) { const on = x <= 33 && pred(x + 0.5, z + 0.5); if (on && x0 === null) x0 = x; if (!on && x0 !== null) { F(c, x0, y1, z, x - 1, y2, z, b); x0 = null; } }
    if (z % 8 === 0) await wait(1);
  }
}
/* かくれ場所（原っぱの 島）。o は 外向き（口の 向き）*/
export const HS_DEF = [["bush", -18, -8], ["bush", 12, -14], ["bush", -8, 8], ["bush", 20, 4], ["bush", -22, 12], ["bush", 4, 22], ["barrel", -12, -18], ["barrel", 18, -6], ["barrel", -4, 16],
  ["shed", -20, -1], ["shed", 14, 16], ["tree", -14, 20], ["tree", 22, -12], ["tree", 6, -22], ["pond", 8, 4], ["pond", 11, 7], ["hay", -26, 0], ["hay", 24, 10], ["stall", -10, -24], ["stall", 0, 26]];
const HS_NM = { bush: "茂みの 中", barrel: "樽の 陰", shed: "小屋の 中", tree: "木の 上", pond: "池の 中", hay: "干し草の 陰", stall: "屋台の 陰" };
const outv = (x, z) => (Math.abs(x) >= Math.abs(z) ? [Math.sign(x) || 1, 0] : [0, Math.sign(z) || 1]);
export const TAG_OBS = { pil: [[-6, -8], [6, -8], [-12, 4], [16, -18]], wall: [[-2, 10, 2, 10], [23, -3, 23, 1], [-16, -16, -16, -12]], tun: [-3, -2, 2, 2] };
export function hideSpots(c) {
  return HS_DEF.map(([t, x, z], i) => {
    const [ox, oz] = outv(x, z); let at, pk, r = 1.9;
    if (t === "pond") { const s = x === 8 ? -1 : 1; at = { x: c.x + x + 0.5, y: c.y - 2.6, z: c.z + z + 0.5 }; pk = { x: c.x + x + 0.5 + s * 2, z: c.z + z + 0.5 }; r = 1.8; }
    else if (t === "tree") { at = { x: c.x + x + ox + 0.5, y: c.y + 5, z: c.z + z + oz + 0.5 }; pk = { x: c.x + x + ox * 3 + 0.5, z: c.z + z + oz * 3 + 0.5 }; r = 2.4; }
    else if (t === "shed") { at = { x: c.x + x + 0.5, y: c.y, z: c.z + z + 0.5 }; pk = { x: c.x + x + ox * 3 + 0.5, z: c.z + z + oz * 3 + 0.5 }; r = 2.2; }
    else { at = { x: c.x + x + 0.5, y: c.y, z: c.z + z + 0.5 }; pk = { x: c.x + x + ox * 2.3 + 0.5, z: c.z + z + oz * 2.3 + 0.5 }; }
    return { i, t, nm: HS_NM[t], at, pk, r, o: [ox, oz] };
  });
}
async function decoField(c) {
  const leaf = LEAF(), log = bk("oak_log", "log"), plank = bk("oak_planks", "planks"), roof = bk("spruce_planks", "planks"), barrel = bk("barrel", "chest"), hay = bk("hay_block", "sandstone"), fence = bk("oak_fence", "fence"), brick = bk("stone_bricks", "stone");
  const red = bk("red_wool", "white_wool"), white = bk("white_wool", "snow");
  let n = 0;
  for (const [t, x, z] of HS_DEF) {
    const [ox, oz] = outv(x, z), ix = -ox, iz = -oz, px = Math.abs(oz), pz = Math.abs(ox);
    if (t === "bush") { F(c, x - 1, 0, z - 1, x + 1, 1, z + 1, leaf); F(c, x, 0, z, x, 1, z, "air"); F(c, x + ox, 0, z + oz, x + ox, 1, z + oz, "air"); }
    if (t === "barrel" || t === "hay") { const b = t === "barrel" ? barrel : hay; F(c, x + ix - px, 0, z + iz - pz, x + ix + px, 1, z + iz + pz, b); S1(c, x + px, 0, z + pz, b); S1(c, x - px, 0, z - pz, b); if (t === "hay") { S1(c, x + px, 1, z + pz, b); S1(c, x - px, 1, z - pz, b); } }
    if (t === "shed") { F(c, x - 2, 0, z - 2, x + 2, 2, z + 2, plank); F(c, x - 1, 0, z - 1, x + 1, 2, z + 1, "air"); F(c, x - 2, 3, z - 2, x + 2, 3, z + 2, roof); F(c, x + ox * 2, 0, z + oz * 2, x + ox * 2, 1, z + oz * 2, "air"); }
    if (t === "tree") { F(c, x - 2, 4, z - 2, x + 2, 5, z + 2, leaf); F(c, x - 1, 6, z - 1, x + 1, 6, z + 1, leaf); F(c, x, 0, z, x, 5, z, log); F(c, x + ox, 5, z + oz, x + ox, 6, z + oz, "air"); }
    if (t === "pond" && x === 8) { F(c, 8, -4, 4, 11, -4, 7, bk("sand")); F(c, 8, -3, 4, 11, -1, 7, "water"); }
    if (t === "stall") { F(c, x + ix - px, 0, z + iz - pz, x + ix + px, 0, z + iz + pz, plank); S1(c, x + ix - px, 1, z + iz - pz, fence); S1(c, x + ix + px, 1, z + iz + pz, fence); S1(c, x + ix - px, 2, z + iz - pz, fence); S1(c, x + ix + px, 2, z + iz + pz, fence); F(c, x - 1, 3, z - 1, x + 1, 3, z + 1, red); S1(c, x, 3, z, white); }
    if (++n % 4 === 0) await wait(1);
  }
  for (const [x, z] of TAG_OBS.pil) F(c, x, 0, z, x, 2, z, brick);
  for (const [x1, z1, x2, z2] of TAG_OBS.wall) F(c, x1, 0, z1, x2, 1, z2, brick);
  { const [x1, z1, x2, z2] = TAG_OBS.tun; F(c, x1, 0, z1, x2, 2, z2, brick); F(c, x1, 0, z1 + 1, x2, 1, z2 - 1, "air"); }
  const fl = ["poppy", "dandelion", "oxeye_daisy", "cornflower"].map((f) => bk(f, "red_flower"));
  for (let k = 0; k < 50; k++) { const a = k * 2.4, r = 3 + ((k * 7) % 24), x = Math.round(Math.cos(a) * r), z = Math.round(Math.sin(a) * r); run(`setblock ${c.x + x} ${c.y} ${c.z + z} ${fl[k % 4]} replace air`); }
  F(c, -5, -1, -15, -4, -1, -14, bk("lime_concrete", "concrete")); F(c, 4, -1, -15, 5, -1, -14, bk("purple_concrete", "concrete"));
}
/* コース（運動場・プール）*/
export const TRACK = { hx: 22, hz: 18, r: 8, w: 3, x0: -9.5 }, POOL = { hx: 20, hz: 15, r: 7, w: 2.5, x0: -9.5 };
export const TRACK_F = { hurdle: [[22, -5], [22, 5]], pad: [8, 7], chan: [6, 3], cones: [[-24, 6], [-20, 2], [-24, -2], [-20, -6]], gates: [[22, 0], [0, 18], [-22, 0]] };
export const POOL_F = { bridge: [20, -1, 0], gates: [[20, 0], [0, 15], [-20, 0]] };
async function decoTrack(c) {
  const T = TRACK, rt = bk("red_terracotta", "hardened_clay"), wh = bk("white_concrete", "concrete"), gold = bk("gold_block"), wool = [bk("yellow_wool", "white_wool"), bk("light_blue_wool", "white_wool"), bk("lime_wool", "white_wool")];
  await rows(c, -1, -1, (x, z) => Math.abs(sdRR(x, z, T.hx, T.hz, T.r)) <= 3.2, wh);
  await rows(c, -1, -1, (x, z) => Math.abs(sdRR(x, z, T.hx, T.hz, T.r)) <= 2.6, rt);
  F(c, -8, -1, -21, -8, -1, -15, gold);
  for (const [x, z] of TRACK_F.hurdle) F(c, x - 3, 0, z, x + 3, 0, z, bk("white_wool", "snow"));
  F(c, 7, 0, 15, 8, 0, 21, bk("yellow_concrete", "concrete")); F(c, 3, -3, 15, 6, -3, 21, bk("light_blue_concrete", "concrete")); F(c, 3, -2, 15, 6, -1, 21, "water");
  for (const [x, z] of TRACK_F.cones) S1(c, x, 0, z, bk("orange_wool", "white_wool"));
  TRACK_F.gates.forEach(([x, z], i) => { const ax = Math.abs(x) > Math.abs(z), q = bk("quartz_block", "stone"); if (ax) { F(c, x - 4, 0, z, x - 4, 2, z, q); F(c, x + 4, 0, z, x + 4, 2, z, q); F(c, x - 4, 3, z, x + 4, 3, z, wool[i]); } else { F(c, x, 0, z - 4, x, 2, z - 4, q); F(c, x, 0, z + 4, x, 2, z + 4, q); F(c, x, 3, z - 4, x, 3, z + 4, wool[i]); } });
  const st = bk("spruce_planks", "planks"); F(c, 10, 0, -25, 20, 0, -25, st); F(c, 10, 0, -26, 20, 1, -26, st); F(c, 10, 0, -27, 20, 2, -27, st);
  F(c, -11, -1, -25, -9, -1, -24, bk("lime_concrete", "concrete"));
  for (let k = 0; k < 24; k++) { const x = Math.round(rnd(-12, 12)), z = Math.round(rnd(-8, 8)); run(`setblock ${c.x + x} ${c.y} ${c.z + z} ${bk("dandelion", "red_flower")} replace air`); }
}
async function decoPool(c) {
  const P = POOL, lb = bk("light_blue_concrete", "concrete"), wool = [bk("yellow_wool", "white_wool"), bk("pink_wool", "white_wool"), bk("lime_wool", "white_wool")];
  await rows(c, -4, -1, (x, z) => Math.abs(sdRR(x, z, P.hx, P.hz, P.r)) <= 3.5, lb);
  await rows(c, -3, -1, (x, z) => Math.abs(sdRR(x, z, P.hx, P.hz, P.r)) <= 2.5, "water");
  { const [x, z1, z2] = POOL_F.bridge; F(c, x - 4, -1, z1, x + 4, -1, z2, bk("oak_planks", "planks")); F(c, x - 4, 0, z1, x - 4, 0, z2, bk("oak_fence", "fence")); F(c, x + 4, 0, z1, x + 4, 0, z2, bk("oak_fence", "fence")); }
  POOL_F.gates.forEach(([x, z], i) => { if (i === 0) return; const ax = Math.abs(x) > Math.abs(z), q = bk("quartz_block", "stone"); if (ax) { F(c, x - 4, 0, z, x - 4, 1, z, q); F(c, x + 4, 0, z, x + 4, 1, z, q); F(c, x - 4, 2, z, x + 4, 2, z, wool[i]); } else { F(c, x, 0, z - 4, x, 1, z - 4, q); F(c, x, 0, z + 4, x, 1, z + 4, q); F(c, x, 2, z - 4, x, 2, z + 4, wool[i]); } });
  F(c, -8, -4, -18, -8, -4, -12, bk("gold_block")); S1(c, -8, -1, -19, bk("gold_block")); S1(c, -8, -1, -11, bk("gold_block"));   /* スタートの 線は 水の 底と 両岸（水面には 置かない）*/
  F(c, -11, -1, -21, -9, -1, -20, bk("lime_concrete", "concrete"));
  for (const [x, z] of [[-6, 0], [6, 0], [0, -4], [0, 4], [-26, -12], [26, 12]]) palm(c, x, z);
}
async function decoSand(c) {
  const ss = bk("sandstone", "sand"); F(c, 5, 0, 9, 7, 0, 11, ss); for (const [x, z] of [[5, 9], [7, 9], [5, 11], [7, 11]]) S1(c, x, 1, z, ss); S1(c, 6, 1, 10, ss); S1(c, 6, 2, 10, bk("red_wool", "white_wool"));
  const pl = bk("oak_planks", "planks"); F(c, -16, 0, -5, -12, 0, -3, pl); F(c, -15, 0, -4, -13, 0, -4, "air"); S1(c, -14, 1, -4, bk("oak_fence", "fence"));
}
async function decoStage(c) {
  const q = bk("quartz_pillar", "quartz_block"), w = bk("red_wool", "white_wool");
  for (const [x, z] of [[-7, -7], [7, -7], [-7, 7], [7, 7]]) F(c, x, 0, z, x, 4, z, q);
  F(c, -7, 5, -7, 7, 5, -7, w); F(c, -7, 5, 7, 7, 5, 7, w); F(c, -7, 5, -7, -7, 5, 7, w); F(c, 7, 5, -7, 7, 5, 7, w);
}
async function decoMaze(c) { F(c, -1, -1, -23, 1, -1, -22, bk("lime_concrete", "concrete")); await mazeBuild(c, mazeMake(9, 3)); }
export async function deco(key, c) {
  if (key === "field") await decoField(c); if (key === "track") await decoTrack(c); if (key === "pool") await decoPool(c);
  if (key === "sand") await decoSand(c); if (key === "stage") await decoStage(c); if (key === "maze") await decoMaze(c);
}
/* 台の 場所 */
export function padAt(key, c, l) {
  if (Math.abs(l.y - c.y) > 1.6) return null; const x = l.x - c.x, z = l.z - c.z;
  if (key === "track" && x >= -11 && x < -8 && z >= -25 && z < -23) return "race";
  if (key === "pool" && x >= -11 && x < -8 && z >= -21 && z < -19) return "swim";
  if (key === "maze" && x >= -1 && x < 2 && z >= -23 && z < -21) return "maze";
  if (key === "park" && Math.abs(z + 14.5) < 0.8 && x > -1.5 && x < 2.5) return "park";
  if (key === "sand" && z > -15.2 && z < -12.8 && x > -1.2 && x < 2.2) return "sand";
  if (key === "field" && z > -15.2 && z < -12.8 && x > -5.2 && x < -2.8) return "hide";
  if (key === "field" && z > -15.2 && z < -12.8 && x > 3.8 && x < 6.2) return "tag";
  if (key === "stage" && Math.hypot(x - 0.5, z - 0.5) < 3) return "sumo";
  return null;
}

/* ================= 1) かくれんぼ ================= */
const LAST = new Map();   /* pid -> この前 使った かくれ場所 */
const HIDE_P = { peekGap: [110, 200, 320], peekLen: [30, 15, 8], gig: [100, 180, 280], see: [7, 10, 13], noise: [6, 9, 12], walk: [0.13, 0.16, 0.19], rush: [0.22, 0.255, 0.285], seekT: [120, 90, 75], hideT: [45, 60, 75], prep: [400, 340, 300] };
function usedSpots(g) { const S = new Set(); for (const o of G.values()) if (o !== g && o.kind === "hide" && o.k === g.k) for (const a of o.A) if (a.spot) S.add(a.spot.i); return S; }
function invis(a, on) { try { if (on) a.e.addEffect("invisibility", 20 * 400, { amplifier: 0, showParticles: false }); else a.e.removeEffect("invisibility"); } catch {} try { a.e.nameTag = on ? "" : a.who === "hero" ? `§d${a.nm}` : `§e${a.nm}`; } catch {} a.inv = on; }
GAMES.hide = {
  init(g) {
    const c = g.c; g.noCount = true; g.mel = "b"; g.spots = hideSpots(c); g.st0 = { x: c.x - 3.5, y: c.y, z: c.z - 13.5, f: { x: c.x, y: c.y + 1, z: c.z } };
    if (g.role === 0) {
      g.t = -100; g.lim = HIDE_P.seekT[g.dv] * 20;
      mkPal(g, { x: c.x - 2, y: c.y, z: c.z - 11 }, c); mkHero(g, { x: c.x - 5, y: c.y, z: c.z - 11 }, c);
      const used = usedSpots(g), last = LAST.get(g.pid) || [], pool = shuf(g.spots.filter((s) => !used.has(s.i)));
      const pref = pool.filter((s) => !last.includes(s.i)), L = [...pref, ...pool.filter((s) => last.includes(s.i))];
      g.A.forEach((a, i) => { a.spot = L[i] || pool[i]; a.st = "away"; });
      LAST.set(g.pid, [...g.A.map((a) => a.spot.i), ...last].slice(0, 8));
      addEff(g, "blindness", 120); holdAt(g, g.st0, 0);
      big(g.p, "§a§lかくれんぼ", "§f目を つぶって 10 かぞえて……", 40);
    } else {
      g.t = -HIDE_P.prep[g.dv]; g.lim = HIDE_P.hideT[g.dv] * 20;
      const q = { x: c.x + 0.5, y: c.y, z: c.z - 11 };
      mkPal(g, { x: q.x + 1.2, y: c.y, z: q.z }, { x: q.x + 1.2, z: q.z - 5 }); mkHero(g, { x: q.x - 1.2, y: c.y, z: q.z }, { x: q.x - 1.2, z: q.z - 5 });
      for (const a of g.A) { a.st = "count"; a.plan = []; a.seen = 0; }
      if (g.hero) { pose(g.hero, 15); hl(g, "count", { force: true }); }
      big(g.p, "§a§lかくれんぼ", `§f${sec(-g.t)}秒で かくれて！ §7しゃがむと 見つかりにくい`, 50);
    }
  },
  pre(g, l) {
    if (g.role === 0) {
      holdAt(g, g.st0, 1.5);
      if (g.t > -95) { for (const a of g.A) if (a.st === "away") { a.st = "hid"; put(a, a.spot.at.x, a.spot.at.y, a.spot.at.z, a.spot.at.x + a.spot.o[0], a.spot.at.z + a.spot.o[1]); invis(a, true); pose(a, 15); a.peek = rnd(0.5, 1) * HIDE_P.peekGap[g.dv]; a.gig = rnd(0.4, 1) * HIDE_P.gig[g.dv]; a.vis = 0; } }
      else for (const a of g.A) if (a.st === "away") drive(g, a, a.spot.pk.x, a.spot.pk.z, 0.26);
      if (g.t % 10 === 0) { const n = Math.ceil(-g.t / 10); bar(g, `§a${n}……`); snd(g.p, "note.hat", 0.8 + (10 - n) * 0.05, 0.6); }
      return;
    }
    if (g.t % 20 === 0) { bar(g, `§aかくれて！ §fのこり ${sec(-g.t)}秒  §7しゃがむと 見つかりにくい・走ると 音で ばれる`); if (-g.t <= 60) snd(g.p, "note.hat", 1, 0.7); }
    for (const a of g.A) put(a, a.x, a.y, a.z, a.x, a.z - 3);
  },
  go(g) {
    if (g.role === 0) { big(g.p, "§a§lもういいよ！", `§f${sec(g.lim)}秒で ${g.A.length}人 見つけよう`, 30); snd(g.p, "note.pling", 1.4, 1); try { g.p.removeEffect("blindness"); } catch {} g.effs.delete("blindness"); }
    else { big(g.p, "§c§lさがしに いくよー！", "§f見つからずに 逃げきれ", 30); snd(g.p, "note.pling", 0.9, 1); for (const a of g.A) { a.st = "search"; pose(a, 0); a.plan = shuf(g.spots.slice()).sort((s, t) => H(s.pk, a) - H(t.pk, a)); } }
  },
  tick(g, l) { if (g.role === 0) seekTick(g, l); else hideTick(g, l); },
  timeup(g) {
    if (g.role === 0) { for (const a of g.A) if (a.st === "hid") { popOut(g, a, g.p.location); } end(g, { win: false, msg: `§f時間切れ。見つけたのは ${g.A.filter((a) => a.found).length}/${g.A.length}`, rec: null }); }
    else end(g, { win: true, msg: `§f${sec(g.lim)}秒 かくれきった！`, rec: sec(g.lim) });
  },
  hud(g, l) {
    if (g.role === 1) { const sp = g.A.some((a) => a.st === "rush"); return `§aかくれんぼ §f${left(g)}  ${sp ? "§c§l見つかりそう！ にげろ！" : g.p.isSneaking ? "§7しゃがみ中（見つかりにくい）" : "§7しゃがむと 見つかりにくい"}`; }
    const hid = g.A.filter((a) => a.st === "hid" || a.st === "move"); let hint = "";
    if (hid.length) { const d = Math.min(...hid.map((a) => H(l, a))); const lv = d < 3 ? 0 : d < 6 ? 1 : d < 10 ? 2 : d < 16 ? 3 : 4;
      hint = g.dv === 0 ? ["§c§lあつい！", "§6あったかい", "§eぬるい", "§bつめたい", "§9こおりそう"][lv] : g.dv === 1 ? (lv <= 1 ? ["§c§lあつい！", "§6あったかい"][lv] : "") : lv === 0 ? "§7……けはいが する" : ""; }
    return `§aかくれんぼ §f見つけた ${g.A.length - hid.length}/${g.A.length}  ${left(g)}  ${hint}`;
  },
  hit(g, a, l) { if (g.role === 0 && (a.st === "hid" || a.st === "move") && H(l, a) < 4.5) found(g, a); },
};
function popOut(g, a, l) { invis(a, false); a.st = "out"; a.tt = 0; a.from = { x: a.x, y: a.y, z: a.z }; const pk = a.spot ? a.spot.pk : l; a.to = { x: pk.x, z: pk.z }; emote(a.e, "bang"); snd(g.p, "random.pop", 1.3, 1, { x: a.x, y: a.y, z: a.z }); if (a.who === "hero") { face(a.e, "shock", 30); pose(a, 22); } else anim(a.e, "atk_jump"); }
function found(g, a) {
  a.found = true; popOut(g, a, g.p.location); snd(g.p, "note.pling", 1.6, 1);
  for (let k = 0; k < 6; k++) fx("star", { x: a.x + rnd(-0.6, 0.6), y: a.y + rnd(0.5, 1.8), z: a.z + rnd(-0.6, 0.6) }, COL.gold, 0.7);
  note(g, `§e§l見つけた！ §f${a.nm}は ${a.spot.nm}に いた`);
  if (a.who === "hero") hl(g, "found", { force: true });
}
function seekTick(g, l) {
  for (const a of g.A) {
    if (a.st === "hid") {
      if (a.vis > 0 && --a.vis === 0) invis(a, true);
      if (--a.peek <= 0) { a.peek = HIDE_P.peekGap[g.dv] * rnd(0.8, 1.2); a.vis = HIDE_P.peekLen[g.dv]; invis(a, false); try { a.e.nameTag = ""; } catch {} fx("orb", { x: a.x, y: a.y + 0.6, z: a.z }, a.who === "hero" ? COL.pink : COL.yellow, 0.3); }
      if (--a.gig <= 0) { a.gig = HIDE_P.gig[g.dv] * rnd(0.8, 1.2); const at = { x: a.x, y: a.y + 1, z: a.z }; snd(g.p, "random.pop", a.who === "hero" ? 1.9 : 1.4, 0.5, at); system.runTimeout(() => snd(g.p, "random.pop", a.who === "hero" ? 2 : 1.5, 0.4, at), 4); fx("notes", at, COL.pink, 0.4); if (a.spot.t === "pond") vfx("minecraft:basic_bubble_particle", { x: a.x, y: g.c.y - 0.2, z: a.z }); }
      if (g.dv === 2 && !a.moved && g.t > 200 && H(l, a) < 5 && Math.random() < 0.01) {
        const used = new Set(g.A.map((b) => b.spot && b.spot.i)), far = g.spots.filter((s) => !used.has(s.i) && H(s.pk, l) > 12 && s.t !== "tree" && s.t !== "pond").sort((s, t) => H(s.pk, a) - H(t.pk, a))[0];
        if (far) { a.moved = true; a.st = "move"; a.spot = far; invis(a, false); try { a.e.nameTag = ""; } catch {} put(a, a.x, floorY(g, a.x, a.z), a.z); a.go = far.pk; note(g, "§7がさがさっ…… なにかが 走った！"); snd(g.p, "dig.grass", 1, 1, { x: a.x, y: a.y, z: a.z }); }
      }
      const hd = H(l, a.spot.at), dy = Math.abs(l.y - a.spot.at.y);
      if (hd < a.spot.r && (dy < 2.5 || a.spot.t === "tree" || a.spot.t === "pond")) found(g, a);
      continue;
    }
    if (a.st === "move") { if (drive(g, a, a.go.x, a.go.z, 0.24) < 0.5) { a.st = "hid"; put(a, a.spot.at.x, a.spot.at.y, a.spot.at.z, a.spot.at.x + a.spot.o[0], a.spot.at.z + a.spot.o[1]); invis(a, true); } else if (H(l, a) < 1.8) found(g, a); continue; }
    if (a.st === "out") { a.tt++; const f = Math.min(1, a.tt / 10); put(a, a.from.x + (a.to.x - a.from.x) * f, a.from.y + (g.c.y - a.from.y) * f + Math.sin(Math.PI * f) * 1.2, a.from.z + (a.to.z - a.from.z) * f, l.x, l.z); if (f >= 1) { a.st = "fol"; if (a.who === "hero") pose(a, 9); } continue; }
    if (a.st === "fol") { const d = H(a, l); if (d > 3) drive(g, a, l.x, l.z, Math.min(0.26, 0.1 + d * 0.03)); else { a.v = 0; moving(a, false); put(a, a.x, floorY(g, a.x, a.z), a.z, l.x, l.z); } if (g.t % 60 === 0) emote(a.e, "note"); }
  }
  if (g.A.every((a) => a.found)) end(g, { win: true, msg: `§f${g.A.length}人 ぜんぶ 見つけた！（${sec(g.t)}秒）`, rec: sec(g.t), low: true });
}
/* 見える？（目の 向き・きょり・しゃがみ・さえぎる ブロック・水の 中）*/
function canSee(g, a, l) {
  const sn = !!g.p.isSneaking, rng = HIDE_P.see[g.dv] * (sn ? 0.5 : 1), d = H(a, l);
  if (d < 1.4) return true; if (d > rng) return false;
  const dx = (l.x - a.x) / d, dz = (l.z - a.z) / d; if (dx * Math.cos(a.yaw) + dz * Math.sin(a.yaw) < 0.34) return false;
  const y0 = a.y + 1.3, y1 = l.y + (sn ? 0.9 : 1.5), n = Math.ceil(d / 0.5); let wet = 0;
  for (let i = 1; i < n; i++) { const f = i / n, k = sol(g, a.x + (l.x - a.x) * f, y0 + (y1 - y0) * f, a.z + (l.z - a.z) * f); if (k === 1) return false; if (k === 2 && ++wet >= 2) return false; }
  return true;
}
function hideTick(g, l) {
  const pv = g.lp ? Math.hypot(l.x - g.lp.x, l.z - g.lp.z) : 0; g.lp = { x: l.x, z: l.z };
  const loud = !g.p.isSneaking && (g.p.isSprinting || pv > 0.22);
  g.A.forEach((a, i) => {
    if (a.st === "rush") {
      drive(g, a, l.x, l.z, HIDE_P.rush[g.dv]);
      if (H(a, l) < 1.3 && Math.abs(a.y - l.y) < 2.5) { emote(a.e, "bang"); if (a.who === "hero") hl(g, "seek", { force: true, act: 16 }); else anim(a.e, "atk_jump"); return end(g, { win: false, msg: `§f${a.nm}に 見つかった（${sec(g.t)}秒 かくれた）`, rec: sec(g.t) }); }
      if ((g.t + i) % 4 === 0) { if (canSee(g, a, l)) { a.lost = 0; a.lastSeen = { x: l.x, z: l.z }; } else if ((a.lost = (a.lost || 0) + 4) >= 40) { a.st = "listen"; a.noise = a.lastSeen; emote(a.e, "q"); if (a.who === "hero") hl(g, "lost"); } }
      return;
    }
    if ((g.t + i) % 4 === 0 && canSee(g, a, l)) { a.st = "rush"; a.lost = 0; a.lastSeen = { x: l.x, z: l.z }; emote(a.e, "bang"); snd(g.p, "note.bit", 1.6, 1, { x: a.x, y: a.y + 1, z: a.z }); note(g, `§c§l${a.nm}に 見られた！ にげろ！`); return; }
    if (loud && H(a, l) < HIDE_P.noise[g.dv] && (a.ncd = (a.ncd || 0) - 1) < 0) { a.ncd = 40; a.st = "listen"; a.noise = { x: l.x + rnd(-2, 2), z: l.z + rnd(-2, 2) }; emote(a.e, "q"); }
    if (a.st === "listen") { if (drive(g, a, a.noise.x, a.noise.z, 0.2) < 0.8 || a.stuck > 4) { a.st = "check"; a.tt = 20; } return; }
    if (a.st === "check") { a.yaw += 0.15 * a.side; put(a, a.x, a.y, a.z, a.x + Math.cos(a.yaw), a.z + Math.sin(a.yaw)); moving(a, false); if (--a.tt <= 0) { a.st = "search"; a.tgt = null; } return; }
    if (a.st === "search") {
      if (!a.tgt) { if (!a.plan.length) a.plan = shuf(g.spots.slice()); a.tgt = a.plan.shift(); a.tl = 0; }
      if (drive(g, a, a.tgt.pk.x, a.tgt.pk.z, HIDE_P.walk[g.dv]) < 0.6 || ++a.tl > 400) {
        a.st = "check"; a.tt = 18; put(a, a.x, a.y, a.z, a.tgt.at.x, a.tgt.at.z); if (Math.random() < 0.4) emote(a.e, "q");
        if (H(l, a.tgt.at) < 2.0 && Math.abs(l.y - a.tgt.at.y) < 3) { a.st = "rush"; a.lastSeen = { x: l.x, z: l.z }; emote(a.e, "bang"); }
      }
    }
  });
}

/* ================= 2) おにごっこ ================= */
const TAG_P = { ch: [0.235, 0.275, 0.3], bur: [0.04, 0.07, 0.09], fl: [0.2, 0.24, 0.27], pan: [0.02, 0.03, 0.03], feint: [0.02, 0.05, 0.09], lim: [60, 90, 90] };
const pos = (g, w) => (w === "p" ? g.p.location : w);
const nmOf = (g, w) => (w === "p" ? "あなた" : w.nm);
GAMES.tag = {
  init(g) {
    const c = g.c; g.lim = TAG_P.lim[g.dv] * 20; g.mel = "c";
    mkPal(g, { x: c.x + 3.5, y: c.y, z: c.z - 7 }, c); mkHero(g, { x: c.x - 2.5, y: c.y, z: c.z - 7 }, c);
    g.oni = g.role === 0 ? g.pal : "p"; g.frz = 0; g.imm = null; g.immT = 0; g.otime = 0; g.ptags = 0; g.st0 = { x: c.x + 5, y: c.y, z: c.z - 14, f: c };
    for (const a of g.A) { a.ft = 0; a.fcd = 0; a.bcd = 0; a.burst = 0; a.fh = 0; a.px = a.x; a.pz = a.z; }
    big(g.p, "§5§lおにごっこ", g.oni === "p" ? "§fあなたが 鬼！ さわって 交代" : `§f${g.oni.nm}が 鬼！ にげろ`, 40);
  },
  pre(g) { holdAt(g, g.st0, 1.5); for (const a of g.A) put(a, a.x, a.y, a.z, g.p.location.x, g.p.location.z); },
  go(g) { if (g.oni !== "p") { g.frz = 30; note(g, `§c${g.oni.nm}が 10 かぞえ……ない！ 1.5秒で 追って くる`); } },
  tick(g, l) {
    const pv = g.lp ? { x: l.x - g.lp.x, z: l.z - g.lp.z } : { x: 0, z: 0 }; g.lp = { x: l.x, z: l.z };
    if (g.frz > 0) g.frz--; if (g.immT > 0 && --g.immT === 0) g.imm = null;
    if (g.oni === "p") g.otime++;
    for (const a of g.A) {
      if (a.kb && a.kb.t > 0) { a.kb.t--; a.yaw = Math.atan2(a.kb.z, a.kb.x); a.hop = a.kb.t === 7 ? 8 : a.hop; step(g, a, 0.22); a.yaw += Math.PI; continue; }
      if (a === g.oni) chase(g, a, l, pv); else flee(g, a, l);
    }
    if (g.oni === "p" && g.frz <= 0) for (const a of g.A) if (a !== g.imm && H(l, a) < 1.5 && Math.abs(l.y - a.y) < 2) { tagged(g, a, "p"); break; }
    if (g.t % 100 === 50 && g.oni !== "p" && g.oni !== g.hero && g.hero && H(g.hero, l) < 12) hl(g, "taunt", { act: 5 });
  },
  timeup(g) {
    const win = g.oni !== "p";
    end(g, { win, msg: win ? `§f鬼は ${nmOf(g, g.oni)}！ §7あなたの タッチ ${g.ptags}回・鬼の 時間 ${sec(g.otime)}秒` : `§f鬼の まま 時間切れ…… §7タッチ ${g.ptags}回`, rec: sec(g.otime), low: true });
  },
  hud(g, l) {
    const o = g.oni, me = o === "p", d = me ? 0 : H(o, l);
    return `§5おにごっこ §f${left(g)}  §c鬼: ${nmOf(g, o)}${me ? (g.frz > 0 ? " §e（3秒 まって）" : " §e（さわって 交代）") : ` §7（${Math.round(d)}m）`}  §7タッチ ${g.ptags}`;
  },
  hit(g, a, l) { if (g.oni === "p" && g.frz <= 0 && a !== g.imm && H(l, a) < 3.2) tagged(g, a, "p"); },
};
function chase(g, a, l, pv) {
  if (g.frz > 0) { a.v = 0; moving(a, false); if (g.frz % 10 === 0) emote(a.e, "dots"); put(a, a.x, floorY(g, a.x, a.z), a.z, l.x, l.z); return; }
  let tw = null, td = 1e9;
  for (const w of ["p", ...g.A]) { if (w === a || w === g.imm) continue; const q = pos(g, w), d = H(a, q) * (w === "p" ? 0.75 : 1); if (d < td) { td = d; tw = w; } }
  if (!tw) return;
  const q = pos(g, tw), tv = tw === "p" ? pv : { x: tw.vx, z: tw.vz }, d = H(a, q);
  let spd = TAG_P.ch[g.dv] * a.k;
  if (a.burst > 0) { a.burst--; spd += TAG_P.bur[g.dv]; if (a.burst % 3 === 0) fx("speed_line", { x: a.x, y: a.y + 0.8, z: a.z }, COL.white, 0.6); }
  else if (d < 4.5 && --a.bcd <= 0) { a.burst = 18; a.bcd = 70; emote(a.e, "anger"); snd(g.p, "random.bow", 0.7, 0.6, { x: a.x, y: a.y, z: a.z }); }
  else a.bcd--;
  const lead = d < 2.5 ? 0 : Math.min(14, d / spd) * 0.6; let ax = q.x + tv.x * lead, az = q.z + tv.z * lead;
  if (!inR(g, ax, az, 27)) { ax = q.x; az = q.z; }
  drive(g, a, ax, az, spd, 0.32);
  if (H(a, q) < 1.25 && Math.abs((q.y ?? a.y) - a.y) < 2) tagged(g, tw, a);
}
function flee(g, a, l) {
  const o = pos(g, g.oni), d = H(a, o);
  if (d > 13) {
    if (!a.wp || H(a, a.wp) < 1 || (a.wt = (a.wt || 0) + 1) > 120) { a.wt = 0; for (let k = 0; k < 6; k++) { const r = rnd(4, 24), t = rnd(0, 6.28), w = { x: g.c.x + Math.cos(t) * r, z: g.c.z + Math.sin(t) * r }; if (clear(g, w.x, w.z) && H(w, o) > 10) { a.wp = w; break; } } }
    if (a.wp) drive(g, a, a.wp.x, a.wp.z, TAG_P.fl[g.dv] * 0.55); return;
  }
  if (--a.ft <= 0) {
    a.ft = 4; const away = Math.atan2(a.z - o.z, a.x - o.x); let best = away, bs = -1e9;
    for (let k = 0; k < 12; k++) {
      const h = (k / 12) * 2 * Math.PI, ca = Math.cos(h), sa = Math.sin(h);
      let free = 0; for (let s = 1; s <= 3; s++) if (clear(g, a.x + ca * s, a.z + sa * s)) free++; else break;
      const ex = a.x + ca * 4, ez = a.z + sa * 4, er = Math.hypot(ex - g.c.x, ez - g.c.z);
      const sc = Math.cos(h - away) + 0.55 * (free / 3) + 0.3 * Math.cos(h - a.yaw) - (free === 0 ? 2 : 0) - (er > 24 ? (er - 24) * 0.45 : 0);
      if (sc > bs) { bs = sc; best = h; }
    }
    a.fh = best;
  }
  if (d < 3.2 && --a.fcd <= 0 && Math.random() < TAG_P.feint[g.dv]) { const s = Math.random() < 0.5 ? 1 : -1, h = a.fh + 1.3 * s; if (clear(g, a.x + Math.cos(h) * 1.5, a.z + Math.sin(h) * 1.5)) { a.fh = h; a.ft = 8; a.fcd = 45; g.feints = (g.feints || 0) + 1; a.yaw = turnTo(a.yaw, h, 1.2); } }
  else a.fcd--;
  let spd = TAG_P.fl[g.dv] * a.k + (d < 3.5 ? TAG_P.pan[g.dv] : 0); if (g.oni !== "p") spd *= 0.9;
  drive(g, a, a.x + Math.cos(a.fh) * 3, a.z + Math.sin(a.fh) * 3, spd, 0.45);
}
function tagged(g, v, by) {
  const vp = pos(g, v), bp = pos(g, by), at = { x: vp.x, y: (vp.y ?? g.c.y) + 1, z: vp.z };
  snd(g.p, "random.pop", 1.7, 1, at); snd(g.p, "random.hurt", 1.4, 0.5, at); fx("impact", at, COL.yellow, 0.8);
  const dx = vp.x - bp.x, dz = vp.z - bp.z, n = Math.hypot(dx, dz) || 1;
  if (v === "p") { try { g.p.applyKnockback(dx / n, dz / n, 0.7, 0.3); } catch {} if (by === g.hero) hl(g, "tagYou", { force: true, act: 9 }); else if (by.who === "pal") anim(by.e, "happy"); big(g.p, "§c§lタッチ！", "§fあなたが 鬼。2秒 まって 追いかけろ", 30); }
  else { v.kb = { x: dx / n, z: dz / n, t: 8 }; if (v.who === "hero") { pose(v, 22); face(v.e, "shock", 30); if (by === "p") hl(g, "tagged", { force: true }); } else anim(v.e, "hurt"); emote(v.e, "bang"); if (by === "p") { g.ptags++; note(g, `§e§lタッチ！ §f${v.nm}が 鬼に なった`); } else note(g, `§7${by.nm}が ${v.nm}に タッチ！ 鬼は ${v.nm}`); }
  g.oni = v; g.frz = 40; g.imm = by; g.immT = 70;
}

/* ================= 3) かけっこ・水泳 ================= */
const PATHS = new Map();
function loopPath(P) {
  const k = `${P.hx},${P.hz},${P.r},${P.x0}`; if (PATHS.has(k)) return PATHS.get(k);
  const ax = P.hx - P.r, az = P.hz - P.r, pts = [];
  const line = (x1, z1, x2, z2) => { const n = Math.max(1, Math.round(Math.hypot(x2 - x1, z2 - z1))); for (let i = 0; i < n; i++) pts.push({ x: x1 + ((x2 - x1) * i) / n, z: z1 + ((z2 - z1) * i) / n }); };
  const arc = (cx, cz, t1, t2) => { const n = Math.max(2, Math.round((P.r * Math.abs(t2 - t1)) / 1)); for (let i = 0; i < n; i++) { const t = t1 + ((t2 - t1) * i) / n; pts.push({ x: cx + Math.cos(t) * P.r, z: cz + Math.sin(t) * P.r }); } };
  line(P.x0, -P.hz, ax, -P.hz); arc(ax, -az, -Math.PI / 2, 0); line(P.hx, -az, P.hx, az); arc(ax, az, 0, Math.PI / 2); line(ax, P.hz, -ax, P.hz); arc(-ax, az, Math.PI / 2, Math.PI); line(-P.hx, az, -P.hx, -az); arc(-ax, -az, Math.PI, 1.5 * Math.PI); line(-ax, -P.hz, P.x0, -P.hz);
  let s = 0; pts.forEach((q, i) => { if (i) s += Math.hypot(q.x - pts[i - 1].x, q.z - pts[i - 1].z); q.s = s; });
  const N = pts.length; pts.forEach((q, i) => { const a = pts[(i - 1 + N) % N], b = pts[(i + 1) % N], tx = b.x - a.x, tz = b.z - a.z, tn = Math.hypot(tx, tz) || 1; q.nx = -tz / tn; q.nz = tx / tn; });   /* 曲がり角で 横の ずれが とばない ように 前後で 平均した 向き */
  const L = s + Math.hypot(pts[0].x - pts[pts.length - 1].x, pts[0].z - pts[pts.length - 1].z);
  const o = { pts, L }; PATHS.set(k, o); return o;
}
function pathAt(path, s, lat) {
  const { pts, L } = path; s = ((s % L) + L) % L; let lo = 0, hi = pts.length - 1;
  while (lo < hi) { const m = (lo + hi + 1) >> 1; if (pts[m].s <= s) lo = m; else hi = m - 1; }
  const a = pts[lo], b = pts[(lo + 1) % pts.length], seg = (lo + 1 < pts.length ? b.s : L) - a.s || 1, f = (s - a.s) / seg, tx = b.x - a.x, tz = b.z - a.z, tn = Math.hypot(tx, tz) || 1;
  const nx = a.nx + (b.nx - a.nx) * f, nz = a.nz + (b.nz - a.nz) * f;
  return { x: a.x + tx * f + nx * lat, z: a.z + tz * f + nz * lat, tx: tx / tn, tz: tz / tn };
}
const nearS = (path, x, z) => { let bi = 0, bd = 1e9; path.pts.forEach((q, i) => { const d = Math.hypot(q.x - x, q.z - z); if (d < bd) { bd = d; bi = i; } }); return path.pts[bi].s; };
const RACE_P = { run: [0.205, 0.25, 0.285], swim: [0.11, 0.15, 0.19], jump: [0.5, 0.75, 0.95] };
function raceInit(g, swim) {
  const c = g.c, P = swim ? POOL : TRACK, path = loopPath(P); g.path = path; g.swim = swim; g.lim = 20 * 150; g.mel = swim ? "b" : "a";
  const W = (q) => ({ x: c.x + q.x, z: c.z + q.z });
  const F0 = swim ? POOL_F : TRACK_F; g.cps = F0.gates.map(([x, z]) => nearS(path, x, z)).sort((a, b) => a - b); g.cp = 0;
  if (!swim) { g.hur = TRACK_F.hurdle.map(([x, z]) => nearS(path, x, z)); const sp = nearS(path, TRACK_F.pad[0] + 0.99, 18), sc0 = nearS(path, TRACK_F.chan[0] + 0.99, 18), sc1 = nearS(path, TRACK_F.chan[1], 18); g.jp = [sp, sc0, sc1]; }
  else { const [x, z1, z2] = POOL_F.bridge; g.br = [nearS(path, x, z1) - 0.6, nearS(path, x, z2 + 1) + 0.6]; }
  g.y0 = swim ? c.y - 0.9 : c.y;
  const s0 = pathAt(path, 0, 0), st = W(s0); g.st0 = { x: st.x, y: g.y0, z: st.z, f: W(pathAt(path, 4, 0)) };
  try { g.p.teleport({ x: st.x, y: g.y0 + (swim ? 0.2 : 0), z: st.z }, { facingLocation: { ...g.st0.f, y: g.y0 + 1 } }); } catch {}
  const mk = (fn, lat) => { const q = W(pathAt(path, 0, lat)), a = fn(g, { x: q.x, y: g.y0, z: q.z }, g.st0.f); if (a) { a.s = 0; a.lat = lat; a.v = 0; a.var = rnd(0.97, 1.03); } return a; };
  mk(mkPal, -1.6); mk(mkHero, 1.6);
  if (swim) { g.swimOn = true; try { heroSwim(g.p, true, g.hero?.e); } catch {} for (const a of g.A) if (a.who === "pal") try { a.e.triggerEvent("mrpg:swim_on"); } catch {} }
  g.pi = 0; g.prog = 0; g.order = [];
  big(g.p, swim ? "§b§l水泳競争" : "§e§lかけっこ", swim ? "§f門を 通って 1周・橋は もぐる" : "§f門を 通って 1周", 40);
}
function raceActor(g, a) {
  const c = g.c, sw = g.swim; let v = (sw ? RACE_P.swim : RACE_P.run)[g.dv] * a.k * a.var;
  const gap = a.s - g.prog; if (gap > 15) v *= g.dv === 0 ? 0.88 : 0.95; else if (gap < -15) v *= 1.05;
  if (Math.random() < 0.004) { a.trip = 14; if (a.who === "hero") face(a.e, "sweat", 30); emote(a.e, "sweat"); }
  if (a.trip > 0) { a.trip--; v *= 0.35; }
  let y = g.y0;
  if (!sw) {
    for (const hs of g.hur) { const f = (a.s - hs + 1.2) / 2.4; if (f > 0 && f < 1) { y += Math.sin(Math.PI * f) * 1.35; if (f < 0.12 && a.who === "pal") anim(a.e, "atk_jump"); } }
    const [s0, s1, s2] = g.jp;
    if (a.s >= s0 && a.s < s1) { y += 1; a.jok = undefined; }
    else if (a.s >= s1 && a.s < s2) { if (a.jok === undefined) { a.jok = Math.random() < RACE_P.jump[g.dv]; if (a.jok) { if (a.who === "pal") anim(a.e, "atk_jump"); } } const f = (a.s - s1) / (s2 - s1); if (a.jok) y += 1 - f + Math.sin(Math.PI * f) * 1.1; else { y = c.y - 0.6; v *= 0.45; if (!a.spl) { a.spl = true; snd(g.p, "random.splash", 1, 0.8, { x: a.x, y: c.y, z: a.z }); } } }
    else a.spl = false;
  } else {
    const [b0, b1] = g.br; if (a.s > b0 - 1.5 && a.s < b1 + 1.5) { const f = Math.min(1, Math.min(a.s - (b0 - 1.5), b1 + 1.5 - a.s) / 1.5); y -= 1.7 * Math.max(0, f); }
    if (g.t % 6 === 0) fx("orb", { x: a.x, y: c.y - 0.1, z: a.z }, COL.white, 0.3);
  }
  a.v += Math.max(-0.03, Math.min(0.015, v - a.v)); a.s += a.v;
  const q = pathAt(g.path, a.s, a.lat), ah = pathAt(g.path, a.s + 2, a.lat);
  put(a, c.x + q.x, y, c.z + q.z, c.x + ah.x, c.z + ah.z, y + 0.9); moving(a, a.v > 0.02, !sw);
  if (a.s >= g.path.L + 1.5 && !a.fin) { a.fin = g.t; g.order.push(a); if (a.who === "hero") hl(g, "lose"); emote(a.e, "spark"); }
}
function raceTick(g, l) {
  const c = g.c;
  for (const a of g.A) if (!a.fin) raceActor(g, a); else { put(a, a.x, a.y, a.z, l.x, l.z); moving(a, false); }
  const path = g.path, n = path.pts.length, lx = l.x - c.x, lz = l.z - c.z;
  let bj = g.pi, bd = 1e9; for (let j = g.pi - 3; j <= g.pi + 10; j++) { const q = path.pts[((j % n) + n) % n], d = Math.hypot(q.x - lx, q.z - lz); if (d < bd) { bd = d; bj = j; } }
  const wet = !g.swim || sol(g, l.x, l.y, l.z) === 2 || sol(g, l.x, l.y + 0.5, l.z) === 2 || l.y < c.y - 0.3;
  if (bd < (g.swim ? 4 : 5) && wet) { g.pi = Math.max(g.pi, bj); g.off = 0; } else if (g.t % 20 === 0) note(g, g.swim && bd < 4 ? "§b水の 中を 泳いで！" : "§cコースに もどって！");
  g.prog = Math.floor(g.pi / n) * path.L + path.pts[((g.pi % n) + n) % n].s;
  if (g.cp < g.cps.length && g.prog >= g.cps[g.cp]) { g.cp++; snd(g.p, "random.orb", 1 + g.cp * 0.15, 1); note(g, `§b§lチェックポイント ${g.cp}/${g.cps.length}`); fx("star", { x: l.x, y: l.y + 1.5, z: l.z }, COL.sky, 0.8); if (g.hero && !g.hero.fin && g.hero.s < g.prog) hl(g, "cp"); }
  if (g.cp >= g.cps.length && g.prog >= path.L + 1.5 - 1) {
    const rank = g.order.length + 1, t = Math.round(g.t / 2) / 10;
    return end(g, { win: rank === 1, msg: `§f${rank}位！ ${t}秒`, rec: t, low: true });
  }
  if (g.order.length >= g.A.length && g.A.length && (g.waitEnd = (g.waitEnd || 0) + 1) > 40) end(g, { win: false, msg: `§f${g.A.length + 1}位…… §7${g.order.map((a) => a.nm).join("・")}が 先に ゴール` });
}
const rankOf = (g) => 1 + g.A.filter((a) => a.fin || a.s > g.prog).length;
GAMES.race = {
  init(g) { raceInit(g, false); }, pre(g) { holdAt(g, g.st0, 1); }, tick: raceTick,
  timeup(g) { end(g, { win: false, msg: "§f時間切れ" }); },
  hud(g) { const r = rankOf(g), ah = g.A.filter((a) => !a.fin && a.s > g.prog).sort((a, b) => a.s - b.s)[0]; return `${g.swim ? "§b水泳" : "§eかけっこ"} §l${r}位§r§f/${g.A.length + 1}  門 ${g.cp}/${g.cps.length}  ${Math.round(g.t / 2) / 10}秒${ah ? `  §7${ah.nm}まで ${Math.round(ah.s - g.prog)}m` : ""}`; },
};
GAMES.swim = { ...GAMES.race, init(g) { raceInit(g, true); }, pre(g) { holdAt(g, g.st0, 1.2); } };

/* ================= 4) 迷路（毎回 ちがう 形）================= */
const MZS = new Map();   /* 島 -> 今の 迷路 */
function mazeMake(n, loops) {
  const adj = Array.from({ length: n * n }, () => []), mid = n >> 1, s = mid, seen = new Set([s]), st = [s];
  while (st.length) { const u = st[st.length - 1], i = u % n, j = Math.floor(u / n); const nb = [[i + 1, j], [i - 1, j], [i, j + 1], [i, j - 1]].filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n && !seen.has(b * n + a)); if (!nb.length) { st.pop(); continue; } const [a, b] = pick(nb), v = b * n + a; adj[u].push(v); adj[v].push(u); seen.add(v); st.push(v); }
  for (let k = 0, t = 0; k < loops && t < 200; t++) { const u = Math.floor(Math.random() * n * n), i = u % n, v = Math.random() < 0.5 ? (i < n - 1 ? u + 1 : -1) : u + n < n * n ? u + n : -1; if (v >= 0 && !adj[u].includes(v)) { adj[u].push(v); adj[v].push(u); k++; } }
  const W = 3 * n + 1, M = { n, adj, W, ox: -Math.floor(W / 2), oz: -Math.floor(W / 2), start: mid, goal: (n - 1) * n + mid, chests: [], traps: [] };
  const dead = shuf(adj.map((L, u) => (L.length === 1 && u !== M.start && u !== M.goal ? u : -1)).filter((u) => u >= 0));
  M.chests = dead.slice(0, 3).map((u) => ({ u, taken: false }));
  { const sol = new Set(mzPath(M, M.start, M.goal)), T0 = dead.slice(3, 6); for (const u of shuf([...Array(n * n).keys()])) { if (T0.length >= 2) break; if (!sol.has(u) && !M.chests.some((h) => h.u === u) && !T0.includes(u)) T0.push(u); } M.traps = T0.map((u, i) => ({ u, ty: i % 2 ? "fog" : "warp" })); }   /* 罠は 正しい 道の 外（行き止まりが 少ない ときは わき道に）*/
  return M;
}
const mzC = (c, M, u) => ({ x: c.x + M.ox + 3 * (u % M.n) + 2, z: c.z + M.oz + 3 * Math.floor(u / M.n) + 2 });
const mzU = (c, M, l) => { const i = Math.floor((l.x - c.x - M.ox - 1) / 3), j = Math.floor((l.z - c.z - M.oz - 1) / 3); return i >= 0 && j >= 0 && i < M.n && j < M.n ? j * M.n + i : -1; };
async function mazeBuild(c, M) {
  const hedge = bk("moss_block", "oak_leaves"), x0 = M.ox, z0 = M.oz, W = M.W, n = M.n;
  F(c, -18, 0, -18, 17, 3, 17, "air"); F(c, -18, -1, -18, 17, -1, 17, bk("grass_block", "dirt"));
  F(c, x0, 0, z0, x0 + W - 1, 2, z0 + W - 1, hedge);
  let k = 0;
  for (let u = 0; u < n * n; u++) {
    const i = u % n, j = Math.floor(u / n), ax = x0 + 1 + 3 * i, az = z0 + 1 + 3 * j; F(c, ax, 0, az, ax + 1, 2, az + 1, "air");
    for (const v of M.adj[u]) { if (v === u + 1) F(c, ax + 2, 0, az, ax + 2, 2, az + 1, "air"); if (v === u + n) F(c, ax, 0, az + 2, ax + 1, 2, az + 2, "air"); }
    if (++k % 24 === 0) await wait(1);
  }
  { const i = M.start % n; F(c, x0 + 1 + 3 * i, 0, z0, x0 + 2 + 3 * i, 2, z0, "air"); }
  { const i = M.goal % n, j = n - 1; F(c, x0 + 1 + 3 * i, -1, z0 + 1 + 3 * j, x0 + 2 + 3 * i, -1, z0 + 2 + 3 * j, bk("gold_block")); }
  for (const t of M.traps) { const i = t.u % n, j = Math.floor(t.u / n); F(c, x0 + 1 + 3 * i, -1, z0 + 1 + 3 * j, x0 + 2 + 3 * i, -1, z0 + 2 + 3 * j, bk("mossy_cobblestone", "cobblestone")); }
  for (const h of M.chests) { const i = h.u % n, j = Math.floor(h.u / n); S1(c, x0 + 1 + 3 * i, 0, z0 + 1 + 3 * j, bk("chest")); }
}
function mzPath(M, a, b) { const prev = new Map([[a, -1]]), q = [a]; while (q.length) { const u = q.shift(); if (u === b) break; for (const v of M.adj[u]) if (!prev.has(v)) { prev.set(v, u); q.push(v); } } if (!prev.has(b)) return [a]; const P = []; for (let u = b; u !== -1; u = prev.get(u)) P.unshift(u); return P; }
GAMES.maze = {
  init(g) {
    const c = g.c, key = `maze:${g.k}`, S = LOCK.get(key); lockTake(key, g.pid); g.t = -80; g.lim = 20 * 240; g.mel = "b";
    let M = MZS.get(g.k);
    if (!M || !S || !S.size) { M = mazeMake([7, 9, 11][g.dv], [6, 3, 1][g.dv]); MZS.set(g.k, M); g.ready = false; mazeBuild(c, M).then(() => { g.ready = true; }, () => { g.ready = true; }); } else { g.ready = true; note(g, "§7ほかの 人と 同じ 迷路で 遊ぶ"); }
    g.M = M; g.got = 0; g.trapDone = new Set();
    const s = mzC(c, M, M.start); g.st0 = { x: s.x, y: c.y, z: s.z, f: { x: s.x, y: c.y + 1, z: s.z + 5 } };
    const pa = mkPal(g, { x: s.x + 0.6, y: c.y, z: s.z - 0.5 }, g.st0.f); if (pa) { pa.cell = M.start; pa.route = []; }
    const he = mkHero(g, { x: s.x - 0.6, y: c.y, z: s.z - 0.5 }, g.st0.f); if (he) { he.cell = M.start; he.route = heroRoute(g, M); he.ri = 0; he.wait = 0; }
    g.nextHint = [300, 500, 800][g.dv]; g.dead = 0;
    big(g.p, "§e§l迷路", `§f${M.n}×${M.n}・南の 金が ゴール`, 40);
  },
  pre(g) { if (!g.ready && g.t > -10) g.t = -10; if (g.ready) holdAt(g, g.st0, 0.8); for (const a of g.A) put(a, a.x, a.y, a.z, g.st0.f.x, g.st0.f.z); },
  tick(g, l) {
    const c = g.c, M = g.M, pu = mzU(c, M, l);
    /* 宝箱・罠・ゴール */
    for (const h of M.chests) if (!h.taken && pu === h.u) { const q = mzC(c, M, h.u); if (H(l, { x: q.x - 0.5, z: q.z - 0.5 }) < 1.6) { h.taken = true; g.got++; g.sc += 50; S1(c, M.ox + 1 + 3 * (h.u % M.n), 0, M.oz + 1 + 3 * Math.floor(h.u / M.n), "air"); snd(g.p, "random.chestopen", 1, 1); snd(g.p, "random.orb", 1.3, 1); confetti(l, 6); note(g, `§6§l宝箱！ §f（${g.got}こ目）`); } }
    for (const t of M.traps) if (pu === t.u && !g.trapDone.has(t.u)) { g.trapDone.add(t.u); snd(g.p, "mob.endermen.portal", 1.2, 0.8);
      if (t.ty === "fog") { addEff(g, "blindness", 50); addEff(g, "slowness", 50, 1); note(g, "§5罠！ 霧に まかれた"); }
      else { const P = mzPath(M, M.start, pu), back = P[Math.max(0, P.length - 4)], q = mzC(c, M, back); try { g.p.teleport({ x: q.x, y: c.y, z: q.z }); } catch {} for (let k = 0; k < 6; k++) fx("swirl", { x: q.x, y: c.y + 0.5 + k * 0.3, z: q.z }, COL.purple, 0.6); note(g, "§5罠！ ワープで もどされた"); } }
    if (pu === M.goal) { const t = Math.round(g.t / 2) / 10; return end(g, { win: true, msg: `§fゴール！ ${t}秒 §6宝箱 ${g.got}こ`, rec: t, low: true }); }
    /* 道案内（相棒）*/
    const pal = g.pal;
    if (pu >= 0) { if (M.adj[pu].length === 1 && pu !== M.start) g.dead++; else g.dead = 0; }
    if (pal) {
      if ((g.t >= g.nextHint || g.dead > 60) && pu >= 0) { g.nextHint = g.t + [300, 500, 800][g.dv]; g.dead = -200; const P = mzPath(M, pu, M.goal); g.trail = P.slice(1, 1 + [8, 5, 3][g.dv]); g.trailT = 90; pal.route = mzPath(M, pal.cell, P[Math.min(2, P.length - 1)]); pal.guide = 60; emote(pal.e, "bang"); snd(g.p, "note.pling", 1.8, 1, { x: pal.x, y: pal.y + 1, z: pal.z }); note(g, `§e${pal.nm}が 「こっち！」と 呼んで いる`); }
      if (g.trailT > 0) { g.trailT--; if (g.trailT % 6 === 0) g.trail.forEach((u, i) => { const q = mzC(c, M, u); fx("orb", { x: q.x, y: c.y + 0.3 + i * 0.05, z: q.z }, COL.gold, 0.4); }); }
      if (pal.guide > 0) pal.guide--;
      if (!pal.route.length && pal.guide <= 0 && g.t % 10 === 0 && pu >= 0 && pu !== pal.cell) { const P = mzPath(M, pal.cell, pu); pal.route = P.slice(1, Math.max(1, P.length - 1)); }
      if (pal.route.length) { const q = mzC(c, M, pal.route[0]); if (glide(pal, q.x, c.y, q.z, 0.24) <= 0) pal.cell = pal.route.shift(); } else put(pal, pal.x, c.y, pal.z, l.x, l.z);
    }
    /* 相手（ヒロイン）*/
    const he = g.hero;
    if (he && !he.fin) {
      if (he.wait > 0) { he.wait--; moving(he, false); }
      else if (he.ri < he.route.length) { const q = mzC(c, M, he.route[he.ri]); if (glide(he, q.x, c.y, q.z, [0.13, 0.16, 0.19][g.dv]) <= 0) { he.cell = he.route[he.ri++]; if (Math.random() < 0.08) { he.wait = 16; face(he.e, "closed", 16); } } }
      else { he.fin = true; return end(g, { win: false, msg: `§f${he.nm}が 先に ゴール` }); }
    }
  },
  timeup(g) { end(g, { win: false, msg: "§f時間切れ" }); },
  hud(g) { const he = g.hero, pc = he ? Math.round((he.ri / Math.max(1, he.route.length)) * 100) : null; return `§e迷路 §f${Math.round(g.t / 20)}秒  §6宝箱 ${g.got}/${g.M.chests.length}${pc !== null ? `  §d${he.nm} ${pc}%` : ""}`; },
};
function heroRoute(g, M) {
  const path = mzPath(M, M.start, M.goal), out = [], wr = [0.45, 0.3, 0.15][g.dv];
  for (let k = 0; k < path.length; k++) { const u = path[k]; out.push(u); const wrong = M.adj[u].filter((v) => v !== path[k + 1] && v !== path[k - 1] && !M.chests.some((h) => h.u === v));   /* 宝箱の 行き止まりには 入らない（箱と 重ならない）*/ if (wrong.length && Math.random() < wr) { const w = pick(wrong); out.push(w); const w2 = M.adj[w].find((x) => x !== u && !M.chests.some((h) => h.u === x)); if (w2 !== undefined && Math.random() < 0.5) out.push(w2, w); out.push(u); } }
  return out.slice(1);
}

/* ================= 5) 宝さがし ================= */
const SAND_P = { n: [2, 3, 4], lim: [120, 120, 100], hint: [240, 360, 500], err: [0.3, 1.2, 2.2] };
const DIR8 = ["東", "南東", "南", "南西", "西", "北西", "北", "北東"];
GAMES.sand = {
  init(g) {
    const c = g.c; g.lim = SAND_P.lim[g.dv] * 20; g.mel = "a"; g.tr = []; g.dug = new Set();
    for (let t = 0; t < 200 && g.tr.length < SAND_P.n[g.dv]; t++) {
      const a = Math.random() * 6.28, r = rnd(4, 20), x = Math.floor(c.x + Math.cos(a) * r), z = Math.floor(c.z + Math.sin(a) * r);
      if (Math.abs(x - c.x) < 3 && z - c.z < -10) continue; if (g.tr.some((q) => Math.abs(q.x - x) + Math.abs(q.z - z) < 6)) continue;
      if ([...G.values()].some((o) => o !== g && o.kind === "sand" && o.tr && o.tr.some((q) => q.x === x && q.z === z))) continue;
      if (bt(x, c.y - 1, z) === 1 && bt(x, c.y, z) === 0 && /sand/.test(OW().getBlock({ x, y: c.y - 1, z })?.typeId || "")) g.tr.push({ x, z, f: false });
    }
    if (!g.tr.length) g.tr.push({ x: c.x + 3, z: c.z + 3, f: false });
    g.st0 = { x: c.x + 0.5, y: c.y, z: c.z - 13.5 };
    const pa = mkPal(g, { x: c.x + 2, y: c.y, z: c.z - 12 }, c); if (pa) { pa.st = "sniff"; pa.rad = 8; }
    mkHero(g, { x: c.x - 1.5, y: c.y, z: c.z - 12 }, c); g.nextHint = 60;
    big(g.p, "§e§l宝さがし", `§f砂の 下に 宝が ${g.tr.length}こ`, 40);
  },
  pre(g) { holdAt(g, g.st0, 2); },
  tick(g, l) {
    const c = g.c, rest = g.tr.filter((q) => !q.f);
    const near = rest.sort((a, b) => H(a, l) - H(b, l))[0];
    /* 相棒の 鼻 */
    const pa = g.pal;
    if (pa && near) {
      if (pa.st === "dig") { if (--pa.tt <= 0) { pa.st = "sniff"; pa.rad = 5; pa.wp = null; } else { if (pa.tt % 8 === 0) { anim(pa.e, "atk_claw"); fx("dust_puff", { x: pa.x, y: c.y, z: pa.z }, COL.yellow, 0.5); } put(pa, pa.x, c.y, pa.z, pa.tx, pa.tz); moving(pa, false); } }
      else {
        const T = { x: near.x + 0.5, z: near.z + 0.5 }; pa.rad = Math.max(SAND_P.err[g.dv], pa.rad - 0.012);
        if (!pa.wp || H(pa, pa.wp) < 0.5 || ++pa.wt > 90) { pa.wt = 0; for (let k = 0; k < 6; k++) { const a = Math.random() * 6.28, r = pa.rad * Math.random(); pa.wp = { x: T.x + Math.cos(a) * r, z: T.z + Math.sin(a) * r }; if (clear(g, pa.wp.x, pa.wp.z)) break; } if (Math.random() < 0.3) fx("swirl", { x: pa.x, y: c.y + 0.6, z: pa.z }, COL.white, 0.3); }
        drive(g, pa, pa.wp.x, pa.wp.z, 0.13);
        if (pa.rad <= SAND_P.err[g.dv] + 0.05 && H(pa, T) < SAND_P.err[g.dv] + 1 && (pa.cd = (pa.cd || 0) - 1) < 0) { pa.cd = 200; pa.st = "dig"; pa.tt = 40; pa.tx = T.x; pa.tz = T.z; emote(pa.e, "bang"); snd(g.p, "random.pop", 1.2, 1, { x: pa.x, y: c.y + 1, z: pa.z }); note(g, `§e${pa.nm}が ここ ほれ わんわん……？ と 砂を かいて いる`); }
      }
    }
    /* 仲間の 勘 */
    const he = g.hero;
    if (he && near) {
      const d = H(he, l); if (d > 3.5) drive(g, he, l.x, l.z, 0.2); else { he.v = 0; moving(he, false); put(he, he.x, c.y, he.z, near.x + 0.5, near.z + 0.5); }
      if (g.t >= g.nextHint) {
        g.nextHint = g.t + SAND_P.hint[g.dv]; const ang = Math.atan2(near.z + 0.5 - l.z, near.x + 0.5 - l.x), di = DIR8[((Math.round(ang / (Math.PI / 4)) % 8) + 8) % 8], dd = H(near, l);
        const w = g.dv === 2 ? `${di}の 方` : `${di}の ${dd < 6 ? "すぐ 近く" : dd < 12 ? "少し 先" : "遠く"}`;
        hl(g, "hint", { d: w, force: true, act: 16 }); put(he, he.x, c.y, he.z, near.x + 0.5, near.z + 0.5);
      }
    }
  },
  timeup(g) { const n = g.tr.filter((q) => q.f).length; for (const q of g.tr) if (!q.f) for (let k = 0; k < 4; k++) fx("pillar", { x: q.x + 0.5, y: g.c.y, z: q.z + 0.5 }, COL.gold, 0.5); end(g, { win: false, msg: `§f時間切れ。宝 ${n}/${g.tr.length}  §e${g.sc}点`, rec: g.sc }); },
  hud(g, l) {
    const rest = g.tr.filter((q) => !q.f), d = rest.length ? Math.min(...rest.map((q) => H({ x: q.x + 0.5, z: q.z + 0.5 }, l))) : 99, lv = d < 2 ? 0 : d < 4 ? 1 : d < 7 ? 2 : 3;
    const hint = g.dv === 0 ? ["§c§lあつい！", "§6あたたかい", "§eぬるい", "§bつめたい"][lv] : g.dv === 1 ? (lv <= 1 ? ["§c§lあつい！", "§6あたたかい"][lv] : "§7……") : "";
    return `§e宝さがし §f${g.tr.length - rest.length}/${g.tr.length}  §e${g.sc}点  §f${left(g)}  ${hint}`;
  },
};
/* 砂を ほる（islands.js の こわす 受け口から）*/
export function dig(p, pos) {
  const g = G.get(p.id); if (!g || g.kind !== "sand" || g.t < 0 || g.post !== undefined) return;
  const c = g.c, k = `${pos.x},${pos.z}`;
  if (pos.y !== c.y - 1 || g.dug.has(k) || Math.hypot(pos.x - c.x, pos.z - c.z) > 26) return;
  let t = ""; try { t = OW().getBlock(pos)?.typeId || ""; } catch {} if (!/sand/.test(t)) return;
  g.dug.add(k); g.rest.push([pos.x, pos.y, pos.z, t.replace("minecraft:", "") || "sand"]); run(`setblock ${pos.x} ${pos.y} ${pos.z} air`); snd(p, "dig.sand", 1, 1);
  const q = g.tr.find((x) => !x.f && x.x === pos.x && x.z === pos.z), at = { x: pos.x + 0.5, y: c.y, z: pos.z + 0.5 };
  if (q) {
    q.f = true; g.sc += 100; run(`setblock ${pos.x} ${pos.y} ${pos.z} ${bk("gold_block")}`);
    snd(p, "random.chestopen", 1, 1); snd(p, "random.levelup", 1.4, 0.8); for (let i = 0; i < 6; i++) fx("rise", { x: at.x + rnd(-0.4, 0.4), y: at.y + i * 0.3, z: at.z + rnd(-0.4, 0.4) }, COL.gold, 0.6); confetti(at, 8);
    const n = g.tr.filter((x) => x.f).length; big(p, "§6§l宝 発見！", `§f${n}/${g.tr.length}`, 25);
    if (g.hero) { joy(g, g.hero); hl(g, "dug", { force: true }); } if (g.pal) { joy(g, g.pal); g.pal.st = "sniff"; g.pal.rad = 8; g.pal.wp = null; }
    if (n >= g.tr.length) { g.sc += sec(g.lim - g.t) * 2; end(g, { win: true, msg: `§f宝 ${n}こ ぜんぶ！ §e${g.sc}点`, rec: g.sc }); }
  } else if (Math.random() < 0.15) { g.sc += 10; snd(p, "note.chime", 1.6, 0.8); fx("star", { x: at.x, y: at.y + 0.3, z: at.z }, COL.pink, 0.4); note(g, "§d小さな 貝がらを 見つけた §7（+10点）"); }
}

/* ================= 6) 相撲 ================= */
const SUMO_P = { per: [44, 32, 24], win: [0.18, 0.12, 0.08], tele: [16, 11, 8], pow: [0.55, 0.8, 1.0], dodge: [0.08, 0.16, 0.25], brace: [0.05, 0.15, 0.3], R: 5.3 };
GAMES.sumo = {
  init(g) {
    const c = g.c; if (!lockTake(`sumo:${g.k}`, g.pid)) { try { barNote(g.p).setActionBar("§7土俵は ほかの 人が 使って いる"); } catch {} return false; }
    g.noCount = true; g.t = -40; g.mel = "c"; g.pw = 0; g.ew = 0; g.ctr = { x: c.x + 0.5, z: c.z + 0.5 }; g.wt = { S: 1.25, M: 1, L: 0.75, G: 0.55 }[SPECIES[g.m.sp]?.sz || "M"] || 1;
    mkPal(g, { x: g.ctr.x, y: c.y, z: g.ctr.z + 2 }, g.ctr); const he = mkHero(g, { x: c.x + 9, y: c.y, z: g.ctr.z }, g.ctr); if (he) pose(he, 9);
    sumoReset(g); big(g.p, "§e§l相撲", "§f2本 先取。緑の 合図で たたけ！", 40);
  },
  pre(g, l) { if (g.t === -30) big(g.p, "§cはっけよい……", "", 20); if (g.t === -1) { big(g.p, "§e§lのこった！", "", 15); snd(g.p, "note.pling", 1.2, 1); } holdAt(g, { x: g.ctr.x, y: g.c.y, z: g.ctr.z - 2, f: { x: g.ctr.x, y: g.c.y + 1, z: g.ctr.z } }, 0.6); if (g.pal) put(g.pal, g.pal.x, g.c.y, g.pal.z, l.x, l.z); },
  tick(g, l) {
    const c = g.c, e = g.pal; if (!e) return;
    if (g.pause > 0) { g.pause--; if (g.pause === 30) sumoReset(g); if (g.pause === 20) big(g.p, "§cはっけよい……", "", 15); if (g.pause === 1) { big(g.p, "§e§lのこった！", "", 15); snd(g.p, "note.pling", 1.2, 1); } if (g.pause > 0 && g.pause <= 30) holdAt(g, { x: g.ctr.x, y: c.y, z: g.ctr.z - 2 }, 0.6); return; }
    g.bt++; g.gv = 1 - Math.abs(((g.bt / SUMO_P.per[g.dv]) % 2) - 1);
    const rE = H(e, g.ctr), rP = H(l, g.ctr);
    if (rE > SUMO_P.R || rP > SUMO_P.R || l.y < c.y - 1) return sumoPoint(g, rE > SUMO_P.R && !(rP > SUMO_P.R));
    if (g.bt > 20 * 40) { g.pause = 40; big(g.p, "§7引き分け", "§fもう一番", 20); return; }
    const dx = l.x - e.x, dz = l.z - e.z, d = Math.hypot(dx, dz) || 1;
    if (e.st === "stun") { if (--e.tt <= 0) e.st = "idle"; if (e.tt % 6 === 0) emote(e.e, "dots"); return; }
    if (e.st === "tele") { if (--e.tt <= 0) { e.st = "lunge"; e.tt = 8; e.dir = { x: dx / d, z: dz / d }; anim(e.e, "atk_charge"); } else put(e, e.x - (dx / d) * 0.03, c.y, e.z - (dz / d) * 0.03, l.x, l.z); return; }
    if (e.st === "lunge") {
      e.tt--; put(e, e.x + e.dir.x * 0.42, c.y, e.z + e.dir.z * 0.42, l.x, l.z);
      if (H(e, l) < 1.3) {
        const sn = !!g.p.isSneaking, pw = SUMO_P.pow[g.dv] / Math.max(0.6, g.wt) * (sn ? 0.3 : 1);
        try { g.p.applyKnockback(e.dir.x, e.dir.z, pw, 0.2); } catch {} snd(g.p, "random.anvil_land", sn ? 1.9 : 1.5, 0.8); fx("impact", { x: l.x, y: l.y + 1, z: l.z }, COL.white, 0.7);
        if (sn) { e.st = "stun"; e.tt = 14; put(e, e.x - e.dir.x * 0.9, c.y, e.z - e.dir.z * 0.9, l.x, l.z); note(g, "§b§l踏ん張った！ §f今だ、押せ！"); hl(g, "cheer", { act: 9 }); } else { e.st = "idle"; e.cd = 26; }
        return;
      }
      if (e.tt <= 0) { e.st = "idle"; e.cd = 18; } return;
    }
    if (e.st === "side") { if (--e.tt <= 0) e.st = "idle"; const n = { x: e.x + e.dir.x * 0.3, z: e.z + e.dir.z * 0.3 }; if (H(n, g.ctr) < SUMO_P.R - 1) put(e, n.x, c.y, n.z, l.x, l.z); return; }
    e.cd = (e.cd ?? 30) - 1;
    if (rE > SUMO_P.R - 1.6) { glide(e, g.ctr.x, c.y, g.ctr.z, 0.14); return; }
    if (d > 2.2) glide(e, l.x - (dx / d) * 1.8, c.y, l.z - (dz / d) * 1.8, 0.11);
    else { put(e, e.x, c.y, e.z, l.x, l.z); moving(e, false); }
    if (e.cd <= 0 && d < 4.5) { e.st = "tele"; e.tt = SUMO_P.tele[g.dv]; emote(e.e, "bang"); note(g, `§c${e.nm}が 体当たりの かまえ！ §7しゃがんで 踏ん張れ・よこへ よけろ`); }
    if (g.t % 120 === 60) hl(g, "cheer", { act: 9 });
  },
  timeup() {},
  hud(g) { const n = 12, k = Math.round(g.gv * (n - 1)), w0 = Math.round((0.8 - SUMO_P.win[g.dv]) * (n - 1)), w1 = Math.round((0.8 + SUMO_P.win[g.dv]) * (n - 1)); let s = ""; for (let i = 0; i < n; i++) s += i === k ? "§f§l|§r" : i >= w0 && i <= w1 ? "§a■" : "§8■"; return `§e相撲 §f${g.pw} - ${g.ew}  押し ${s}  §7しゃがむと 踏ん張る`; },
  hit(g, a, l) {
    if (a !== g.pal || g.pause > 0) return; const e = a, c = g.c, dx = e.x - l.x, dz = e.z - l.z, d = Math.hypot(dx, dz) || 1; if (d > 3.5) return;
    if (e.st === "idle" && Math.random() < SUMO_P.dodge[g.dv]) { e.st = "side"; e.tt = 6; const s = Math.random() < 0.5 ? 1 : -1; e.dir = { x: (-dz / d) * s, z: (dx / d) * s }; note(g, `§7${e.nm}が ひらりと よけた！`); return; }
    const good = Math.abs(g.gv - 0.8) <= SUMO_P.win[g.dv]; let push = (good ? 1.5 : 0.6) * g.wt;
    if (e.st === "tele") { push = 1.8 * g.wt; e.st = "stun"; e.tt = 20; note(g, "§e§lため中を くずした！"); }
    else if (e.st === "idle" && Math.random() < SUMO_P.brace[g.dv]) { push *= 0.4; anim(e.e, "guard"); note(g, `§7${e.nm}が 踏ん張った！`); }
    else if (good) { note(g, "§a§l会心の 押し！"); fx("impact", { x: e.x, y: e.y + 1, z: e.z }, COL.green, 0.8); }
    for (let i = 1; i <= 3; i++) system.runTimeout(() => { try { if (G.get(g.pid) === g && okE(e.e)) put(e, e.x + (dx / d) * push / 3, c.y, e.z + (dz / d) * push / 3, l.x, l.z); } catch {} }, i);
    anim(e.e, "hurt"); snd(g.p, "random.anvil_land", good ? 1.4 : 1.8, 0.7);
  },
};
function sumoReset(g) { const c = g.c; g.bt = 0; g.gv = 0; if (g.pal) { g.pal.st = "idle"; g.pal.cd = 30; put(g.pal, g.ctr.x, c.y, g.ctr.z + 2, g.ctr.x, g.ctr.z - 2); } try { g.p.teleport({ x: g.ctr.x, y: c.y, z: g.ctr.z - 2 }, { facingLocation: { x: g.ctr.x, y: c.y + 1, z: g.ctr.z + 2 } }); } catch {} }
function sumoPoint(g, pWin) {
  if (pWin) { g.pw++; snd(g.p, "random.orb", 1.2, 1); confetti(g.p.location, 5); if (g.hero) { pose(g.hero, 6); hl(g, "cheer", { force: true }); } }
  else { g.ew++; snd(g.p, "note.bass", 0.8, 1); if (g.hero) { face(g.hero.e, "sweat", 30); } }
  if (g.pw >= 2) return end(g, { win: true, msg: `§f${g.pw} - ${g.ew} で 勝ち！ §7${g.pal.nm}を 押しだした`, rec: (recLoad(g.p).w.sumo || 0) + 1 });
  if (g.ew >= 2) return end(g, { win: false, msg: `§f${g.pw} - ${g.ew} §7土俵の 外に 出て しまった` });
  g.pause = 50; big(g.p, pWin ? "§a一本！" : "§c一本 とられた", `§f${g.pw} - ${g.ew}`, 25);
}

/* ================= 7) 足場わたり ================= */
export const PARK_ST = [[-1, -12, 0], [1, -9, 0], [2, -6, 1], [0, -3, 0], [-2, 0, 0], [-1, 3, 1], [1, 6, 0], [2, 9, 0], [0, 12, 1], [-1, 15, 0]];
const PARK_P = { wait: [[8, 14], [5, 10], [3, 6]], slip: [0.12, 0.07, 0.03], crum: [0, 2, 3] };
GAMES.park = {
  init(g) {
    const c = g.c; g.lim = 20 * 120; g.mel = "a"; g.st0 = { x: c.x + 0.5, y: c.y, z: c.z - 14.5, f: { x: c.x, y: c.y, z: c.z + 18 } }; g.ps = -1; g.falls = 0; g.cr = new Map();
    g.crum = new Set(shuf([2, 3, 4, 5, 6, 7, 8]).slice(0, PARK_P.crum[g.dv]));
    const mk = (fn, dx) => { const a = fn(g, { x: c.x + dx, y: c.y, z: c.z - 14.5 }, g.st0.f); if (a) { a.si = -1; a.hp = 0; a.wait = 0; } };
    mk(mkPal, 2); mk(mkHero, -1.2);
    big(g.p, "§e§l足場わたり", g.crum.size ? `§fくずれる 足場が ${g.crum.size}つ` : "§f南の 金へ", 40);
  },
  pre(g) { holdAt(g, g.st0, 1); },
  tick(g, l) {
    const c = g.c, stP = (i) => (i < PARK_ST.length ? { x: c.x + PARK_ST[i][0] + 0.5, z: c.z + PARK_ST[i][1] + 0.5, y: c.y + PARK_ST[i][2] } : { x: c.x + 0.5, z: c.z + 18.5, y: c.y });
    if (Math.abs(l.x - c.x) <= 4.5 && l.z > c.z - 14.5 && l.z < c.z + 16.5 && l.y < c.y - 0.4) {
      g.falls++; const cp = g.dv === 0 && g.ps >= 4 ? stP(4) : null; try { g.p.teleport(cp ? { x: cp.x, y: cp.y + 0.1, z: cp.z } : g.st0, { facingLocation: g.st0.f }); } catch {} snd(g.p, "random.splash", 1, 1); note(g, cp ? "§b落ちた！ 中間から" : "§b落ちた！ スタートから"); if (!cp) g.ps = -1;
    }
    PARK_ST.forEach((q, i) => { if (Math.abs(l.x - (c.x + q[0] + 0.5)) < 0.9 && Math.abs(l.z - (c.z + q[1] + 0.5)) < 0.9 && l.y >= c.y + q[2] - 0.2 && l.y < c.y + q[2] + 0.6) { if (i > g.ps) g.ps = i; if (g.crum.has(i) && !g.cr.has(i)) g.cr.set(i, 14); } });
    for (const [i, t] of g.cr) {
      const q = PARK_ST[i], b = { x: c.x + q[0], y: c.y - 1 + q[2], z: c.z + q[1] };
      if (t > 0) { g.cr.set(i, t - 1); if (t % 4 === 0) { fx("dust_puff", { x: b.x + 0.5, y: b.y + 1, z: b.z + 0.5 }, COL.white, 0.5); snd(g.p, "dig.gravel", 1.4, 0.6, b); } if (t === 1) { const id = q[2] ? bk("oak_log", "log") : bk("mossy_stone_bricks", "stone"); g.rest.push([b.x, b.y, b.z, id]); run(`setblock ${b.x} ${b.y} ${b.z} air`); snd(g.p, "dig.stone", 0.8, 1, b); } }
      else if (t > -80) g.cr.set(i, t - 1); else { const r = g.rest.findIndex((x) => x[0] === b.x && x[1] === b.y && x[2] === b.z); if (r >= 0) { const [x, y, z, id] = g.rest.splice(r, 1)[0]; run(`setblock ${x} ${y} ${z} ${id}`); } g.cr.delete(i); }
    }
    for (const a of g.A) {
      if (a.fin) { put(a, a.x, a.y, a.z, l.x, l.z); continue; }
      if (a.wait > 0) { a.wait--; continue; }
      if (a.hp > 0) { a.hp--; const to = stP(a.si + 1), f = 1 - a.hp / 8; put(a, a.from.x + (to.x - a.from.x) * f, a.from.y + (to.y - a.from.y) * f + Math.sin(f * Math.PI) * 1.3, a.from.z + (to.z - a.from.z) * f, to.x, to.z, to.y + 0.9);
        if (a.hp === 0) { a.si++; const W = PARK_P.wait[g.dv]; a.wait = Math.round(rnd(W[0], W[1]) / a.k); if (Math.random() < PARK_P.slip[g.dv]) { a.wait += 30; emote(a.e, "sweat"); if (a.who === "hero") face(a.e, "sweat", 30); note(g, `§7${a.nm}が 足を すべらせた！`); } if (a.si >= PARK_ST.length) { a.fin = g.t; emote(a.e, "spark"); } } continue; }
      const nx = a.si + 1; if (nx < PARK_ST.length && g.cr.has(nx) && g.cr.get(nx) <= 0) { a.wait = 10; continue; }
      a.from = { x: a.x, y: a.y, z: a.z }; a.hp = 8; if (a.who === "pal") anim(a.e, "atk_jump");
    }
    if (l.z >= c.z + 17.5 && Math.abs(l.x - c.x) < 3 && l.y >= c.y - 0.5 && g.ps >= PARK_ST.length - 1) { const rank = 1 + g.A.filter((a) => a.fin).length, t = Math.round(g.t / 2) / 10; return end(g, { win: rank === 1, msg: `§f${rank}位！ ${t}秒 §7（落ちた ${g.falls}回）`, rec: t, low: true }); }
    if (g.A.length && g.A.every((a) => a.fin)) end(g, { win: false, msg: `§f${g.A.map((a) => a.nm).join("・")}が 先に ゴール` });
  },
  timeup(g) { end(g, { win: false, msg: "§f時間切れ" }); },
  hud(g) { const best = Math.max(-1, ...g.A.map((a) => (a.fin ? PARK_ST.length : a.si))); return `§e足場わたり §f${Math.max(0, g.ps + 1)}/${PARK_ST.length}  §7相手 ${Math.max(0, best + 1)}/${PARK_ST.length}  §f${Math.round(g.t / 20)}秒`; },
};

export const __pg = { G, GAMES, MZS, LOCK, LAST, HIDE_P, TAG_P, RACE_P, SUMO_P, SAND_P, loopPath, pathAt, mazeMake, mazeBuild, mzC, mzU, mzPath, hideSpots, recLoad, begin, stop, ask, padAt, deco, dig, end, cleanup, TRACK, POOL, TRACK_F, POOL_F };
