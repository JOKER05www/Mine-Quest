// 第121版: 演出の 共通道具（地方マスター・常世編・魔神編・滅びた世界 で つかう）
// 場面ごとに cast(p) を 作り、人を 立たせ、動かし、最後に end() で ぜんぶ 片づける
import { world, system } from "@minecraft/server";
import { setJob, sound, ok, wait } from "./ui.js";
import { setLook, TYPE as MON_TYPE } from "./field.js";
import { groundY } from "./structures.js";
import { camAt, lookAt, mood, inScene, fadeOn, fadeHide, fading } from "./talk.js";
import { stageBegin, stageEnd, stageOf, stageFor, slotOf, addActor, freeNear, clampPath, stagePt, unhide, unfreeze, standY, walkIn as walkIn0, smokeIn, exitPt, arrive, inCam } from "./stagecore.js";   /* 第123版: 場面の 舞台 */
import { face, emote, tears, shockJump } from "./direct.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { PSKIN } from "./skinjobs.js";
import { HEROES } from "./saga.js";
import { hold } from "./hold.js";

const LIVE = (globalThis.__mqCine = globalThis.__mqCine || new Set());
export const FAST = () => !!(globalThis.__MQ_TEST && !globalThis.__TALK_LIVE);   /* 模擬テストでは 待たない */
export const pause = (t) => (FAST() ? Promise.resolve() : wait(t));
export const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
export const PJ = (k, d = 8) => (PSKIN[k] ? PSKIN[k][0] : d);
/* 第116版: オルドの 相棒 ハク（白い 獅子）と レイの 竜の 見た目 */
export const HAKU_SP = "hbea14", REI_DRAGON_SP = "hdra12";   /* saga.js の ハクと 同じ 見た目 */
export function stoneFx(p, e, n = 6) { if (!ok(e)) return; try { const l = e.location; fx(p.dimension, "minecraft:basic_smoke_particle", { x: l.x, y: l.y + 0.6, z: l.z }, n, 0.7); } catch {} }
export { face, emote, tears, shockJump, lookAt, camAt };

/* ポーズ（mrpg:act）*/
export const ACT = { talk: 4, wave: 5, clap: 6, down: 8, cheer: 9, bow: 10, sad: 12, kneel: 15, point: 16, guard: 17, raise: 18, run: 19, knocked: 20, recoil: 22, hold: 23, up: 24, prone: 21, nod: 25, no: 26, arms: 27, hips: 28, pump: 29, palm: 30, stagger: 31, give: 32, show: 33, work: 34 };
export function act(e, k, keep = true) { if (!ok(e)) return; try { const n = typeof k === "number" ? k : ACT[k] ?? 0; e.setProperty("mrpg:act", n); if (keep) e.setDynamicProperty("mrpg:act0", n); } catch {} }
/* 第125版: 手に 持つ 小道具（hold.js）。give は 渡す 人が 持って 両手を 前へ → 受け取る 人が 持つ */
export { hold };
export async function give(a, b, n, t = 14) { if (!ok(a)) { hold(b, n); return; } let a0 = 0; try { a0 = a.getDynamicProperty("mrpg:act0") || 0; } catch {} hold(a, n); act(a, "give", false); await pause(t); hold(a, 0); act(a, a0, false); if (ok(b)) hold(b, n); }
/* 歩く・走る（ticks で 着く）*/
export async function go(e, to, ticks = 14, run = false) {
  if (!ok(e) || !to) return; if (!FAST()) await arrive(e); if (!ok(e)) return; const f = e.location;   /* 第124版(cam): 歩いて 来る とちゅうなら 着いてから */
  { const S = stageFor(e); if (S && Math.abs(to.y - f.y) < 1.6) { to = clampPath(S, f, to); to = freeNear(S, to, e, 1.25, 2.1) || to; to = clampPath(S, f, to); S.dest.set(e.id, to); }   /* 第124版(fix2): よけた 先までの 道も 調べる（噴水の 石を 通りぬけない）*/ else if (S) { const y = standY(S.dim, to.x, to.z, to.y, S.C); if (y !== null && Math.abs(y - to.y) <= 1.2) { to = { ...to, y }; to = freeNear(S, to, e, 1.25, 2.1) || to; S.dest.set(e.id, to); } } }   /* 第123版: 壁を ぬけない・人に 重ならない。第127版: 坂で うまらない */
  if (FAST()) { try { e.teleport(to); } catch {} return; }
  try { e.setProperty("mrpg:mv", true); if (run) e.setProperty("mrpg:act", ACT.run); } catch {}
  for (let k = 1; k <= ticks; k++) { if (!ok(e)) return; const t = k / ticks; try { e.teleport({ x: f.x + (to.x - f.x) * t, y: f.y + (to.y - f.y) * t, z: f.z + (to.z - f.z) * t }, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } }); } catch {} await wait(1); }
  try { e.setProperty("mrpg:mv", false); if (run) e.setProperty("mrpg:act", 0); } catch {}
}
/* 吹っ飛んで 倒れる */
export async function knock(e, from, dist = 3.5) {
  if (!ok(e) || !from) return; const l = e.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L; act(e, "knocked", false);
  let to = { x: l.x + ux * dist, y: l.y, z: l.z + uz * dist }; { const S = stageFor(e); if (S) { to = clampPath(S, l, to); to = freeNear(S, to, e, 1.25, 1.4) || to; S.dest.set(e.id, to); } }
  for (let k = 1; k <= 8; k++) { if (!ok(e)) return; const t = k / 8; try { e.teleport({ x: l.x + (to.x - l.x) * t, y: l.y + (to.y - l.y) * t + Math.sin(t * Math.PI) * 1.4, z: l.z + (to.z - l.z) * t }, { facingLocation: from }); } catch {} if (!FAST()) await wait(1); }
  act(e, "down");
}
/* プレイヤーが 後ろへ はじかれる */
export function knockP(p, from, h = 1.0, v = 0.4) { try { const l = p.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1; cmd(p, "inputpermission set @s lateral_movement enabled"); p.applyKnockback(dx / L, dz / L, h, v); system.runTimeout(() => { if (inScene(p)) cmd(p, "inputpermission set @s lateral_movement disabled"); }, 12); } catch {} }
export function shake(p, pw = 0.5, t = 0.6) { cmd(p, `camerashake add @s ${pw} ${t} positional`); }
export function flash(p, col = "255 255 255") { if (col !== "0 0 0" && fading(p)) return;   /* 第124版(cam): 暗転の 中・明けかけに 白い 光を 重ねない */ fadeOn(p, col === "0 0 0" ? "0.05 0.6 0.4" : "0.05 0.15 0.4", col, true); }   /* 第124版(fix2): 暗転を 覚える。黒は 場面の 切りかえ（暗い あいだに 人を 入れかえる）*/
export function fx(dim, id, at, n = 1, r = 0) { for (let i = 0; i < n; i++) try { dim.spawnParticle(id, { x: at.x + (Math.random() - 0.5) * r * 2, y: at.y + Math.random() * (r ? 1.6 : 0), z: at.z + (Math.random() - 0.5) * r * 2 }); } catch {} }
/* 衝撃波（中心から 輪が ひろがる）*/
export async function wave(p, at, id = "minecraft:white_smoke_particle") {
  if (!at) return;
  try { p.dimension.spawnParticle("minecraft:explosion_particle", { x: at.x, y: at.y + 0.5, z: at.z }); p.dimension.spawnParticle("mrpg:shock_ring", { x: at.x, y: at.y + 0.1, z: at.z }); p.dimension.spawnParticle("mrpg:dust_puff", { x: at.x, y: at.y + 0.1, z: at.z }); } catch {}
  for (let r = 1; r <= 4; r++) { for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; fx(p.dimension, id, { x: at.x + Math.cos(a) * r, y: at.y + 0.2, z: at.z + Math.sin(a) * r }); } await pause(1); }
}
/* 黒い 影が 地面を すべる */
export async function shadowFlow(p, from, to, ticks = 16, id = "minecraft:soul_particle") {
  if (!from || !to) return; mood(p, "shadow");   /* 第125版: 紫の 霧と 暗がり・やわらかい 煙 */
  for (let k = 0; k <= ticks; k++) { if (!ok(p)) return; const t = k / ticks; const q = { x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t + 0.2, z: from.z + (to.z - from.z) * t }; fx(p.dimension, k % 2 ? id : "minecraft:basic_smoke_particle", q, 2, 0.9); if (k % 2 === 0) fx(p.dimension, "mrpg:shadow_smoke", { ...q, y: q.y + 0.4 }); if (k % 4 === 0) fx(p.dimension, "mrpg:glow_mote", { ...q, y: q.y + 0.6 }); if (k % 6 === 0) sound(p, "mob.wither.ambient", 0.25); await pause(1); }
}
/* 人が 粒に なって 消える（灰・光）*/
export async function fade(e, id = "minecraft:white_smoke_particle") { if (!ok(e)) return; const l = e.location; for (let k = 0; k < 4; k++) { fx(e.dimension, id, { x: l.x, y: l.y + k * 0.5, z: l.z }, 5, 0.5); if (k === 3) try { e.addEffect("invisibility", 20, { showParticles: false }); } catch {} await pause(2); } rmE(e); }   /* 第124版(cam): 粒の 中で 見えなく なってから 消す */
/* 第124版(cam): 暗転の 中で あらわれる（もとから そこに いた 人・石の 人）。続けて 出す ときは 暗転は 1回 */
const VEIL = new Map();
export function veil(p, e) { if (!ok(e) || !inScene(p)) return e; const t = system.currentTick; if ((VEIL.get(p.id) ?? -99) < t - 4) { fadeOn(p, "0.15 0.25 0.35"); VEIL.set(p.id, t); } try { e.addEffect("invisibility", 12, { showParticles: false }); } catch {} system.runTimeout(() => { try { if (ok(e)) e.removeEffect("invisibility"); } catch {} }, 5); return e; }
/* 第124版(cam): 立ち去る: カメラに 映らない 所まで 歩いて 消える（映った ままなら 暗く して から）*/
export async function exit(p, e, k = 9, ticks = null) {
  if (!ok(e)) return; const q = exitPt(p, e, k);
  if (q) { const d = Math.hypot(q.x - e.location.x, q.z - e.location.z); await go(e, q, ticks ?? Math.max(14, Math.round(d * 2.6))); }
  if (ok(e) && inScene(p) && inCam(p, e.location, stageOf(p)?.C)) await fadeHide(p, "0.25 0.2 0.4");
  rmE(e);
}
export function rmE(e) { if (!e) return; try { LIVE.delete(e.id); } catch {} try { if (ok(e)) e.remove(); } catch {} }

/* ヒロイン（旅の 仲間）*/
export function heroOf(p) { try { const d = load(p), k = d && qs(d).hero; const h = (HEROES || []).find((x) => x[0] === k); return h ? { key: h[0], name: h[1] } : null; } catch { return null; } }

/* プレイヤーの 向きを 基準に した 位置（dist 前へ・side 右へ）*/
export function spot(p, dist = 3.5, side = 0, dy = 0) {
  try {
    { const S = stageOf(p); if (S) return stagePt(S, dist, side, dy); }   /* 第123版: 舞台の 向きで（プレイヤーの 見て いる 方では ない）*/
    const yaw = (p.getRotation().y * Math.PI) / 180, l = p.location, fx0 = -Math.sin(yaw), fz0 = Math.cos(yaw), rx = -fz0, rz = fx0;
    const q = { x: l.x + fx0 * dist + rx * side, y: l.y + dy, z: l.z + fz0 * dist + rz * side };
    if (!dy) { const gy = groundY(p.dimension, q.x, q.z, Math.floor(l.y)); if (typeof gy === "number" && Math.abs(gy - l.y) <= 3) q.y = gy; }
    return q;
  } catch { return null; }
}
const eye = (p) => { try { const l = p.location; return { x: l.x, y: l.y + 1.5, z: l.z }; } catch { return null; } };

/* 1つの 場面の 出演者。end() で ぜんぶ 消す（ぬけても 海辺の 片づけ mrpg_cine で 消える）*/
export function cast(p) {
  const list = [], kept = [];
  const C = {
    list,
    npc(name, job, dist = 3.5, side = 0, dy = 0, how = null) {   /* 第124版(cam): how: walk（映らない 所から 歩く）・veil（暗転）・smoke（煙）・none */
      let q = spot(p, dist, side, dy); if (!q) return null;
      const S = stageOf(p); if (S && !dy) q = freeNear(S, q, null, 1.5) || slotOf(S, "ally", name, null);
      if (S && !dy && Math.abs(q.y - S.P.y) >= 1) q = slotOf(S, "ally", name, null) || q;   /* 第124版(fix2): 坂で 段の 上下に 立たせない */
      try {
        const e = p.dimension.spawnEntity("mrpg:npc", q); LIVE.add(e.id); list.push(e); if (S) addActor(S, e, name, q);
        try { setJob(e, job); } catch {}
        e.addTag("mrpg_npc"); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); e.nameTag = name;
        try { e.teleport(q, { facingLocation: eye(p) }); } catch {}
        if (S && !dy && inScene(p)) { const h = how ?? (name ? "walk" : "veil"); if (h === "walk") { if (!walkIn0(S, e, q, eye(p))) veil(p, e); } else if (h === "veil") veil(p, e); else if (h === "smoke") smokeIn(e); }
        return e;
      } catch { return null; }
    },
    mon(sid, dist = 4, side = 0, dy = 0, how = "smoke") {
      let q = spot(p, dist, side, dy); if (!q) return null;
      const S = stageOf(p); if (S && !dy) q = freeNear(S, q, null, 1.6, 3) || q;
      try { const e = p.dimension.spawnEntity(MON_TYPE, q); LIVE.add(e.id); list.push(e); if (S) addActor(S, e, null, q); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); try { setLook(e, sid); } catch {} try { e.teleport(q, { facingLocation: eye(p) }); } catch {} if (inScene(p)) { if (how === "smoke") smokeIn(e); else if (how === "veil") veil(p, e); } return e; } catch { return null; }
    },
    /* ヒロインを 横に 立たせる（えらんで いなければ null）*/
    hero(dist = 1.8, side = -1.6) { const h = heroOf(p); if (!h) return null; const S = stageOf(p), e = C.npc(`§d${h.name}`, PJ(h.key, 9), dist, side, 0, "none"); if (e) { C.hn = h.name; try { e.addTag("mrpg_hero"); let q = { ...e.location }; if (S && dist < 2.5) { q = slotOf(S, "hero", `§d${h.name}`, e); e.teleport(q, { facingLocation: S.at(3.5, 0, 1.5) }); S.mem.set(`§d${h.name}`, q); } if (S && inScene(p) && !walkIn0(S, e, q, S.at(3.5, 0, 1.5))) veil(p, e); } catch {} } return e; },   /* 第124版(cam): 旅の 仲間も 歩いて 来る */
    /* もとから いる 人（城の マスター など）。最後に ポーズを もどす */
    keep(e) { if (ok(e)) { let hid = false; try { hid = e.hasTag("mrpg_stghid"); } catch {} unhide(e); if (hid) veil(p, e); unfreeze(e);   /* 第124版(cam): 舞台が 隠して いた 人は 暗い 中で あらわす */ let a0 = 0; try { a0 = e.getDynamicProperty("mrpg:act0"); } catch {} kept.push([e, typeof a0 === "number" ? a0 : 0, e.nameTag, { ...e.location }]);
        const S = stageOf(p); if (S) { try { const q = slotOf(S, "ally", e.nameTag, e), l = e.location, d = Math.hypot(q.x - l.x, q.z - l.z); S.ents.push(e); S.mem.set(e.nameTag, q); S.dest.set(e.id, q); if (d > 1.2 && inScene(p) && !FAST()) go(e, q, Math.max(12, Math.round(d * 3))); else e.teleport(q, { facingLocation: S.at(0, 0, 1.5) }); } catch {} } } return e; },   /* 第124版(cam): 飛ばさず 歩いて 立ち位置へ */   /* 第123版: もとから いる 人も 舞台の 立ち位置へ（終われば もとの 場所へ）*/
    end() {
      for (const e of list) rmE(e); list.length = 0;
      for (const [e, a0, nm, at] of kept) if (ok(e)) try { e.teleport(at); e.setProperty("mrpg:act", a0); e.setDynamicProperty("mrpg:act0", a0); e.setProperty("mrpg:face", 0); hold(e, 0); e.nameTag = nm; } catch {}
      try { for (const e of p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_autospk"] })) if (e.getDynamicProperty("mrpg:spkOwner") === p.id) e.remove(); } catch {}
      { const S = stageOf(p); if (!S || S.depth <= 1) { cmd(p, "camera @s clear"); cmd(p, "inputpermission set @s lateral_movement enabled"); } }   /* 第123版: 外の 場面の とちゅうなら カメラは そのまま */
    },
  };
  return C;
}
/* 出演者つきで 場面を 走らせる（途中で 落ちても 必ず 片づける）*/
export async function scene(p, fn) { await stageBegin(p, { move: true, R: 12 }); const C = cast(p); try { return await fn(C); } finally { { const S = stageOf(p); if (S && S.depth <= 1 && inScene(p) && !FAST() && ok(p)) { fadeOn(p, "0.3 0.3 0.5"); await wait(7); } } C.end(); stageEnd(p); } }   /* 第124版(cam): 終わりは 暗く して から 片づける */   /* 第123版: 場面ごとに 舞台（近くの 開けた 所）*/
/* 近くの 決まった 人（タグ）をさがす */
export function near(p, tag, r = 16) { try { return p.dimension.getEntities({ type: "mrpg:npc", tags: [tag], location: p.location, maxDistance: r }).find((e) => ok(e)) || null; } catch { return null; } }
/* 2人の あいだを 横から（会話の 外の 動きを 見せる）*/
export function side(p, e, k = 6) {
  try { const P = p.location, S = e.location, m = { x: (P.x + S.x) / 2, y: (P.y + S.y) / 2 + 1.2, z: (P.z + S.z) / 2 }, dx = S.x - P.x, dz = S.z - P.z, L = Math.hypot(dx, dz) || 1; return camAt(p, { x: m.x - (dz / L) * k, y: m.y + 1.5, z: m.z + (dx / L) * k }, m) || camAt(p, { x: m.x + (dz / L) * k, y: m.y + 1.5, z: m.z - (dx / L) * k }, m); } catch { return false; }
}
/* 下から 見上げる（高い 所の もの）*/
export function lookUp(p, at) { try { const l = p.location; return camAt(p, { x: l.x, y: l.y + 0.6, z: l.z }, at); } catch { return false; } }
