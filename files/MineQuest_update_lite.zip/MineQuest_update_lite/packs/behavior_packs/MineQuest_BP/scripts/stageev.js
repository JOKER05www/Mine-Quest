// 第125版: ステージの 出来事（11か所）。各地方の 2つ目か 3つ目の ステージ（大地）に「入れる 場所」と「そこで 起きる 出来事」を 足す
// 物語とは 別の 寄り道。こなすと その 地方らしい ほうび（タマゴ・能力の 実・装備）を 1人 1回だけ もらえる（物語の 制限を 通す）
// 進みは プレイヤーごと（mrpg:sev）。とちゅうで 抜けた・負けた・たおれた ときは、その 段の 場所に もどれば 続きから
// 軽く: 10tick ごとに 近い 1か所だけ 見る・建物は 1回だけ 作る（enqueue）・4tick の 見回りは 氷の 床・浮島・海の 入口に いる 人だけ
import { world, system, ItemStack } from "@minecraft/server";
import { ITEMS, EGGS, SPECIES, ORDER } from "./data.js";
import { load, save } from "./store.js";
import { ok, busy, sound, barNote, setJob, warming, heavy, countItem, giveItem } from "./ui.js";
import { PSKIN } from "./skinjobs.js";
import { calcStats } from "./core.js";
import { WREGIONS, landSites, regionLv } from "./worldmap.js";
import { enqueue, building, landInfo, TOWNS, townPos, castleInfo, castleSpot, caveBox, CAVE_R, LAND_HOOK } from "./structures.js";
import { setLook, TYPE, hooks } from "./field.js";
import { inBattle } from "./battle.js";
import { stageBegin, stageEnd, stageOf, slotOf, addActor, walkIn as walkIn0, smokeIn, smokeOut, exitPt, inCam } from "./stagecore.js";
import { talk, tell, scenePause, sceneResume, inScene, cineSting, camFade, fadeOn } from "./talk.js";
import { rankCap, storyLootOk, storyItemOk } from "./quest.js";
import { rollGear, capRoll, giveGear, gearName } from "./gear.js";
import { boon } from "./boon.js";
import { fight, holdBusy } from "./story.js";
import { team, hasKey } from "./saga.js";
import { ORG, gruntOf, fmtO } from "./gangnames.js";

export const SEV_V = 1;
export const SE = { fight: null };   /* テストで 戦いを 差しかえ できる */
const OW = () => world.getDimension("minecraft:overworld");
const wait = (t) => new Promise((r) => system.runTimeout(r, Math.max(1, t)));
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const U = -16;   /* 地下の 部屋の 足の 高さ（ステージの 床からの 差）*/
const DIRV = [{ x: 0, z: 1 }, { x: -1, z: 0 }, { x: 0, z: -1 }, { x: 1, z: 0 }];
const WD = (v) => (v.x > 0 ? 0 : v.x < 0 ? 1 : v.z > 0 ? 2 : 3);   /* 階段が 上る 向き（0 東 1 西 2 南 3 北）*/
const FD = (v) => (v.z > 0 ? 3 : v.z < 0 ? 2 : v.x > 0 ? 5 : 4);   /* はしごの 向き */
const RD = (v) => (v.z !== 0 ? 0 : 1);   /* レールの 向き */
const d2 = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const near = (p, q, r, dy = 1.6) => { try { const l = p.location; return !!q && d2(l, q) <= r && Math.abs(l.y - q.y) <= dy; } catch { return false; } };

/* ---------- 形（ローカル座標 a: 横・b: 前・h: 高さ）---------- */
function frame(x, y, z, dir) {
  const F = DIRV[dir], R = { x: -F.z, z: F.x };
  const W = (a, b, h = 0) => ({ x: x + R.x * a + F.x * b, y: y + h, z: z + R.z * a + F.z * b });
  return { x, y, z, dir, F, R, W, P: (a, b, h) => { const q = W(a, b, h); return { x: q.x + 0.5, y: q.y, z: q.z + 0.5 }; },
    loc: (l) => { const dx = l.x - x - 0.5, dz = l.z - z - 0.5; return { a: Math.round(dx * R.x + dz * R.z), b: Math.round(dx * F.x + dz * F.z), h: Math.floor(l.y + 0.01) - y }; } };
}
function CB(fr) {
  const C = [];
  const box = (a1, b1, h1, a2, b2, h2, blk, mode) => { const p = fr.W(a1, b1, h1), q = fr.W(a2, b2, h2); C.push(`fill ${Math.min(p.x, q.x)} ${Math.min(p.y, q.y)} ${Math.min(p.z, q.z)} ${Math.max(p.x, q.x)} ${Math.max(p.y, q.y)} ${Math.max(p.z, q.z)} ${blk}${mode ? " " + mode : ""}`); };
  const set = (a, b, h, blk) => { const p = fr.W(a, b, h); C.push(`setblock ${p.x} ${p.y} ${p.z} ${blk}`); };
  return { C, box, set, fr };
}
/* 地方ごとの 見た目（w 壁・w2 壁の 下・f 床・lt 灯り・st 階段・rl 手すり）*/
const PAL = [
  { w: "stone_bricks", w2: "mossy_stone_bricks", f: "cobblestone", lt: "glowstone", st: "stone_brick_stairs", rl: "cobblestone_wall" },
  { w: "dirt", w2: "rooted_dirt", f: "moss_block", lt: "shroomlight", st: "spruce_stairs", rl: "spruce_fence" },
  { w: "cracked_stone_bricks", w2: "mossy_stone_bricks", f: "stone_bricks", lt: "glowstone", st: "stone_brick_stairs", rl: "cobblestone_wall" },
  { w: "blackstone", w2: "basalt", f: "polished_blackstone", lt: "shroomlight", st: "polished_blackstone_stairs", rl: "blackstone_wall" },
  { w: "sandstone", w2: "cut_sandstone", f: "smooth_sandstone", lt: "glowstone", st: "sandstone_stairs", rl: "birch_fence" },
  { w: "calcite", w2: "tuff", f: "smooth_basalt", lt: "sea_lantern", st: "cobbled_deepslate_stairs", rl: "polished_blackstone_wall" },
  { w: "prismarine_bricks", w2: "dark_prismarine", f: "prismarine", lt: "sea_lantern", st: "prismarine_bricks_stairs", rl: "dark_oak_fence" },
  { w: "polished_blackstone_bricks", w2: "deepslate_bricks", f: "deepslate_tiles", lt: "crying_obsidian", st: "polished_blackstone_brick_stairs", rl: "polished_blackstone_brick_wall" },
  { w: "packed_ice", w2: "snow", f: "snow", lt: "sea_lantern", st: "spruce_stairs", rl: "spruce_fence" },
  { w: "end_stone", w2: "obsidian", f: "end_bricks", lt: "pearlescent_froglight", st: "end_brick_stairs", rl: "nether_brick_fence" },
  { w: "quartz_block", w2: "smooth_quartz", f: "grass_block", lt: "sea_lantern", st: "quartz_stairs", rl: "birch_fence" },
];
const ROOMS = { A: [-6, -5, 6, 7], B: [-6, 10, 6, 22], C: [-7, 25, 7, 39] };
function room(B, P, k, fill = "air", top = U + 5) { const [a1, b1, a2, b2] = ROOMS[k]; B.box(a1, b1, U - 1, a2, b2, U - 1, P.f); B.box(a1, b1, U, a2, b2, top, fill); }
function hall(B, P, b1, b2, fill = "air", a1 = -1, a2 = 1) { B.box(a1, b1, U - 1, a2, b2, U - 1, P.f); B.box(a1, b1, U, a2, b2, U + 3, fill); }
function lights(B, P, k, lt = P.lt, h = U + 3) { const [a1, b1, a2, b2] = ROOMS[k]; for (const b of [b1 + 2, b2 - 2]) { B.set(a1 - 1, b, h, lt); B.set(a2 + 1, b, h, lt); } }
/* 地上から 地下の 部屋 A へ 下りる 階段（b -23 → -6）*/
function stair(B, P, rail = true) {
  const F = B.fr.F, wd = WD({ x: -F.x, z: -F.z });
  B.box(-2, -23, -17, 2, -6, -1, P.w);
  for (let i = 0; i <= 17; i++) {
    const b = -23 + i, fh = 1 - i;
    B.box(-1, b, fh, 1, b, fh + 4, "air");
    if (i > 0) B.box(-1, b, fh - 1, 1, b, fh - 1, `${P.st} ["weirdo_direction"=${wd}]`);
    if (rail && i >= 1 && i <= 5) { B.set(-2, b, 1, P.rl); B.set(2, b, 1, P.rl); }
    if (i % 5 === 3 && fh + 2 <= -1) B.set(-2, b, fh + 2, P.lt);
  }
}
/* 迷路（7×7 の 部屋。シードで 毎回 同じ 形）。true = 壁 */
function mazeGrid(seed) {
  let s = seed >>> 0 || 7; const r = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
  const g = [...Array(13)].map((_, i) => [...Array(13)].map((__, j) => i % 2 === 1 || j % 2 === 1));
  const seen = new Set(["3,0"]), st = [[3, 0]];
  while (st.length) {
    const [ci, cj] = st[st.length - 1], nb = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([a, b]) => [ci + a, cj + b, a, b]).filter(([a, b]) => a >= 0 && a < 7 && b >= 0 && b < 7 && !seen.has(`${a},${b}`));
    if (!nb.length) { st.pop(); continue; }
    const [ni, nj, da, db] = nb[Math.floor(r() * nb.length)]; g[ci * 2 + da][cj * 2 + db] = false; seen.add(`${ni},${nj}`); st.push([ni, nj]);
  }
  return g;   /* g[列][行]（列 = a+6・行 = b-10）*/
}
/* 氷の 床の 安全な 道（行 = b 11〜21・列 = a -6〜6。# = 白く くもった 氷）*/
const ICE = ["......#......", "......#......", "....###......", "....#........", "....#........", "....#####....", "........#....", "........#....", ".....####....", ".....#.......", ".....###....."];
const iceSafe = (a, b) => { const row = ICE[b - 11]; return !!row && row[a + 6] === "#"; };
/* 鏡の 仕掛け（水晶の 地底湖）*/
const MIR = [{ a: -3, b: 14, pa: -2, pb: 14 }, { a: -3, b: 19, pa: -3, pb: 20 }, { a: 0, b: 19, pa: 1, pb: 19 }];
const MIR0 = [1, 1, 1];
function beam(st) {
  let a = -5, b = 14, da = 1, db = 0; const path = [];
  for (let k = 0; k < 80; k++) {
    if (a < -6 || a > 6 || b < 10 || b > 22) return { path, hit: false };
    const m = MIR.findIndex((q) => q.a === a && q.b === b);
    if (m >= 0) { [da, db] = st[m] === 0 ? [db, da] : [-db, -da]; }
    else if (!MIR.some((q) => q.pa === a && q.pb === b)) path.push([a, b]);
    if (a === 0 && b === 22) return { path, hit: true };
    a += da; b += db;
  }
  return { path, hit: false };
}
function beamCmds(B, st) {
  B.box(-6, 10, U, 6, 22, U, "air", "replace yellow_carpet"); B.box(-6, 10, U, 6, 22, U, "air", "replace lime_carpet");
  const R = beam(st); for (const [a, b] of R.path) B.set(a, b, U, R.hit && a === 0 && b === 22 ? "lime_carpet" : "yellow_carpet");
  MIR.forEach((q, i) => B.set(q.a, q.b, U, st[i] === 0 ? "light_blue_stained_glass" : "purple_stained_glass"));
  return R.hit;
}
const NESTS = [[-4, 12], [4, 15], [-3, 20]];
const nestCmds = (B, on) => { for (const [a, b] of NESTS) { B.set(a, b, U, on ? "web" : "air"); B.set(a, b, U + 1, on ? "web" : "air"); B.set(a + 1, b, U, on ? "moss_carpet" : "air"); } };
const GRAVES = [[-4, 13, 100], [4, 13, 300], [-4, 19, 50], [4, 19, 200]];
const GORDER = [1, 3, 0, 2];
const GHOSTS = [[-4, 13], [4, 17], [-2, 21]];
const LANE = 4;   /* 砂の 神殿の 本物の 道（a = 4）*/
const ISLES = [[0, 21, 5, 12], [2, 32, 3, 13], [-1, 43, 3, 14], [0, 57, 6, 15]];
const STONES = [[1, 28, 12], [1, 37, 13], [0, 39, 13], [0, 48, 14], [-1, 50, 14]];

/* ---------- 11の 出来事 ---------- */
const N = (nm, sk) => ({ nm, sk });
export const EVS = [
  { r: 0, k: 1, ent: "well", nm: "古井戸の 下の 地下水路", rooms: "AB", fams: ["blob", "animal"], rew: { egg: ["blob"], seed: "hp" } },
  { r: 1, k: 1, ent: "tree", nm: "大樹の 根の 下の 洞", rooms: "ABC", fams: ["animal", "beast"], rew: { egg: ["animal"], seed: "spd" } },
  { r: 2, k: 2, ent: "crypt", nm: "崩れた 地下墓所", rooms: "ABC", fams: ["sword", "golem"], rew: { egg: ["sword"], gear: ["weapon", /^wp_sword/] } },
  { r: 3, k: 1, ent: "mine", nm: "溶岩の 坑道", rooms: "ABC", fams: ["dragon", "golem"], rew: { egg: ["dragon"], gear: ["armor", /_fire$/] } },
  { r: 4, k: 1, ent: "buried", nm: "砂に 埋もれた 小さな 神殿", rooms: "ABC", fams: ["golem", "nether"], rew: { egg: ["golem"], gear: ["acc", null] } },
  { r: 5, k: 2, ent: "crystal", nm: "水晶の 地底湖", rooms: "ABC", fams: ["golem", "blob"], rew: { egg: ["blob"], seed: "mdf" } },
  { r: 6, k: 1, ent: "sea", nm: "海に しずんだ 神殿", rooms: "ABC", fams: ["aqua"], rew: { egg: ["aqua"], gear: ["acc", null] } },
  { r: 7, k: 1, ent: "tomb", nm: "霊廟の 地下", rooms: "ABC", fams: ["nether"], rew: { egg: ["nether"], seed: "mp" } },
  { r: 8, k: 1, ent: "icecave", nm: "氷の 洞窟", rooms: "ABC", fams: ["beast", "aqua"], rew: { egg: ["beast"], seed: "def" } },
  { r: 9, k: 2, ent: "ribs", nm: "竜の 肋骨の 中", rooms: "ABC", fams: ["dragon"], rew: { egg: ["dragon"], seed: "atk" } },
  { r: 10, k: 1, ent: "sky", nm: "雲の 下の 浮島", rooms: "", fams: ["animal", "dragon"], rew: { egg: ["rainbow", "animal"], gear: ["weapon", /_wind$/] } },
];
const EV_OF = (r) => EVS.find((E) => E.r === r);

/* 形と 点（作る コマンド・場面の 点・扉・箱）。ent ごとに 少しずつ ちがう */
export function geo(E, I) {
  const fr = frame(I.x, I.y, I.z, I.dir), B = CB(fr), P = PAL[E.r], { box, set } = B, F = fr.F;
  const pts = {}, gates = [], extra = {};
  const pt = (k, a, b, h, fa, fb) => { pts[k] = fr.P(a, b, h); if (fa !== undefined) pts[k].face = fr.P(fa, fb, h); };
  if (E.ent === "sky") {
    /* 雲の 道 → 浮島 4つ（石の 足場で 乗りつぐ）*/
    box(-1, 9, 12, 1, 16, 12, "white_wool");
    for (const [a, b, r, h] of ISLES) for (let db = -r; db <= r; db++) {
      const w = Math.floor(Math.sqrt(r * r - db * db)); box(a - w, b + db, h, a + w, b + db, h, "grass_block");
      if (r > 1 && Math.abs(db) <= r - 1) { const w2 = Math.floor(Math.sqrt((r - 1) ** 2 - db * db)); box(a - w2, b + db, h - 1, a + w2, b + db, h - 1, "dirt"); }
      if (r > 2 && Math.abs(db) <= r - 2) { const w3 = Math.floor(Math.sqrt((r - 2) ** 2 - db * db)); box(a - w3, b + db, h - 2, a + w3, b + db, h - 2, "stone"); }
    }
    for (const [a, b, h] of STONES) box(a - 1, b, h, a + 1, b, h, "white_wool");
    for (const [a, b, r, h] of ISLES) { set(a + r - 1, b, h + 1, "birch_fence"); set(a + r - 1, b, h + 2, "lantern"); }
    pt("I1", 0, 19, 13, 0, 23); pt("I4", 0, 54, 16, 0, 59);
    extra.cps = ISLES.map(([a, b, r, h]) => fr.P(a, b, h + 1)); extra.cps.unshift(fr.P(0, 6, 13));
    const q1 = fr.W(-9, 6, 0), q2 = fr.W(9, 66, 30);
    return { fr, C: B.C, pts, gates, extra, box: bx(q1, q2), fast: true };
  }
  /* 地下: まわりを かためる → 部屋 → 通路 → 階段 */
  const deep = E.ent === "icecave" ? -21 : -20;
  box(-8, -7, deep, 8, 41, -9, P.w);
  box(-8, -7, U, 8, 41, U + 1, P.w2, `replace ${P.w}`);
  if (E.ent === "sea") box(-8, 24, -9, 8, 41, -4, P.w);
  const wet = E.ent === "sea" ? "water" : "air";
  room(B, P, "A", wet); room(B, P, "B", wet);
  if (E.rooms.includes("C")) { if (E.ent === "sea") { box(-7, 25, U + 4, 7, 39, U + 4, P.f); box(-7, 25, U + 5, 7, 39, U + 10, "air"); } else room(B, P, "C"); }
  hall(B, P, 8, 9, wet);
  if (E.rooms.includes("C") && E.ent !== "buried") hall(B, P, 23, 24, wet);
  if (E.ent !== "tomb" && E.ent !== "mine" && E.ent !== "icecave") lights(B, P, "B");
  lights(B, P, "A"); if (E.rooms.includes("C")) { if (E.ent === "sea") { for (const b of [28, 36]) { set(-8, b, U + 7, P.lt); set(8, b, U + 7, P.lt); } } else lights(B, P, "C", P.lt); }
  pt("A", 0, 1, U, 0, 7); pt("B", 0, 15, U, 0, 21); pt("C", 0, 30, E.ent === "sea" ? U + 5 : U, 0, 36);
  const G1 = [-1, 9, U, 1, 9, U + 3], G2 = [-1, 24, U, 1, 24, U + 3];
  const gate = (id, after, b6, shut, open = "air") => { const o = CB(fr), s = CB(fr); o.box(...b6, open); s.box(...b6, shut); gates.push({ id, after, open: o.C, shut: s.C }); };
  /* 入口 */
  if (E.ent === "well") {
    box(-1, -21, -17, 1, -19, -1, P.w); hall(B, P, -20, -6);
    box(0, -20, U, 0, -20, 1, "air"); box(-1, -21, 1, 1, -19, 1, "cobblestone");
    box(0, -20, U, 0, -20, 1, `ladder ["facing_direction"=${FD(F)}]`);
    for (const [a, b] of [[-1, -21], [1, -21], [-1, -19], [1, -19]]) box(a, b, 2, a, b, 3, "oak_fence");
    box(-1, -21, 4, 1, -19, 4, "oak_slab");
    box(3, -5, U - 1, 4, 7, U - 1, "water"); set(5, 0, U, "barrel"); set(-5, 6, U, "barrel");
    pt("top", 3, -16, 1, 0, -20);
  } else {
    stair(B, P, !["tree", "crypt", "buried", "tomb", "icecave"].includes(E.ent));
    pt("top", 5, -16, 1, 0, -22);
  }
  if (E.ent === "tree") {
    box(-3, -25, 1, 3, -19, 14, "dark_oak_log", "replace air"); box(-3, -25, 1, 3, -19, 14, "dark_oak_log", "replace short_grass");
    box(-1, -25, 1, 1, -24, 4, "air"); stair(B, P, false);
    box(-7, -29, 13, 7, -15, 17, `oak_leaves ["persistent_bit"=true]`, "replace air");
    for (const [a, b] of [[-4, 0], [3, 4], [-2, 6], [5, -3]]) set(a, b, U + 5, "hanging_roots");
    for (const b of [27, 31, 35]) { box(-7, b, U, -7, b, U + 5, "dark_oak_log"); box(7, b, U, 7, b, U + 5, "dark_oak_log"); }
    nestCmds(B, true);
    pts.nests = NESTS.map(([a, b]) => fr.P(a, b, U));
    gate("G2", 1, G2, P.w2);
    pt("top", 5, -21, 1, 0, -25);
  }
  if (E.ent === "crypt" || E.ent === "tomb") {
    const wall = E.ent === "crypt" ? "cracked_stone_bricks" : P.w;
    box(-3, -25, 1, 3, -18, 5, wall); box(-2, -24, 1, 2, -19, 4, "air"); box(-1, -25, 1, 1, -25, 3, "air");
    stair(B, P, false);
    box(-3, -25, 6, 3, -18, 6, E.ent === "crypt" ? "stone_brick_slab" : "polished_blackstone_brick_slab");
    if (E.ent === "crypt") { set(2, -20, 6, "air"); set(-3, -22, 3, "air"); set(3, -23, 4, "mossy_stone_bricks"); set(-3, -19, 5, "air"); }
    else { set(-2, -26, 1, "soul_lantern"); set(2, -26, 1, "soul_lantern"); }
    pt("top", 5, -21, 1, 0, -25);
  }
  if (E.ent === "crypt") {
    for (const [a, b] of [[-4, 4], [4, 2], [-3, -2]]) { set(a, b, U, "coarse_dirt"); set(a, b + 1, U, "gravel"); }
    extra.btn = [];
    for (const [a, b] of GRAVES) { box(a - 1, b, U - 1, a + 1, b + 2, U - 1, "coarse_dirt"); box(a, b + 2, U, a, b + 2, U + 1, "chiseled_stone_bricks"); set(a, b - 1, U, "polished_andesite"); set(a, b - 1, U + 1, `stone_button ["facing_direction"=1]`); extra.btn.push(fr.W(a, b - 1, U + 1)); }
    pts.graves = GRAVES.map(([a, b]) => fr.P(a, b - 2, U)); pt("tablet", 0, 11, U);
    box(-1, 35, U, 1, 37, U, "polished_andesite"); set(-2, 37, U, "candle"); set(2, 37, U, "candle");
    gate("G1", 0, G1, P.w2); gate("G2", 1, G2, P.w2);
  }
  if (E.ent === "tomb") {
    for (const [a, b] of [[-6, 10], [6, 22], [-6, 22], [6, 10]]) set(a, b, U + 5, "web");
    for (const [a, b] of [[-5, 16], [5, 12], [3, 21]]) box(a, b, U, a, b + 1, U, "polished_blackstone_slab");
    pts.ghosts = GHOSTS.map(([a, b]) => fr.P(a, b, U));
    gate("G2", 1, G2, P.w2);
  }
  if (E.ent === "mine") {
    for (const b of [-23, -20]) { box(-2, b, 1, -2, b, 4, "dark_oak_log"); box(2, b, 1, 2, b, 4, "dark_oak_log"); box(-2, b, 4, 2, b, 4, "dark_oak_log"); }
    box(0, -4, U, 0, 38, U, `rail ["rail_direction"=${RD(F)}]`);
    for (let b = 0; b <= 36; b += 6) { set(0, b, U - 1, "redstone_block"); set(0, b, U, `golden_rail ["rail_direction"=${RD(F)},"rail_data_bit"=true]`); }
    for (const [a, b] of [[-7, 12], [7, 15], [-7, 19], [7, 21]]) set(a, b, U + 1, "lava_cauldron");
    for (const [a, b] of [[-5, 34], [-5, 35], [-4, 35], [5, 36]]) set(a, b, U, a < 0 ? "iron_ore" : "gold_ore");
    { const q = fr.P(0, -3, U); B.C.push(`summon minecart ${Math.floor(q.x)} ${q.y} ${Math.floor(q.z)}`); }
    pts.ch = [fr.P(0, 12, U), fr.P(0, 17, U), fr.P(0, 21, U), fr.P(0, 31, U)];
  }
  if (E.ent === "buried") {
    box(5, -19, 1, 5, -19, 6, "chiseled_sandstone"); set(5, -19, 7, "glowstone");
    const sh = CB(fr), op = CB(fr);
    for (let i = 1; i <= 5; i++) { sh.box(-1, -23 + i, 1 - i, 1, -23 + i, 0, "sand"); op.box(-1, -23 + i, 1 - i, 1, -23 + i, 0, "air"); }
    B.C.push(...sh.C); gates.push({ id: "S", after: 0, open: op.C, shut: sh.C });
    box(-2, 12, U, -2, 21, U + 3, P.w2); box(2, 12, U, 2, 21, U + 3, P.w2);
    box(-6, 22, U, -3, 22, U + 3, P.w); box(-1, 22, U, 1, 22, U + 3, P.w);
    box(3, 12, U - 1, 6, 21, U - 1, "brown_terracotta"); for (const a of [-5, 0]) set(a, 21, U + 3, "glowstone");
    hall(B, P, 23, 24, "air", 3, 5);
    pt("top", 3, -15, 1, 5, -19); pt("tablet", 0, 11, U); pt("end", LANE + 1, 22, U);
  }
  if (E.ent === "crystal") {
    box(-2, -23, 1, -2, -23, 4, "amethyst_block"); box(2, -23, 1, 2, -23, 4, "amethyst_block"); box(-2, -23, 5, 2, -23, 5, "calcite"); set(-2, -24, 1, "amethyst_cluster"); set(2, -24, 1, "amethyst_cluster");
    box(2, -3, U - 2, 5, 5, U - 1, "water");
    set(-6, 14, U, "sea_lantern"); set(-6, 14, U + 1, "sea_lantern");
    extra.btn = [];
    MIR.forEach((q) => { set(q.a, q.b, U + 1, "amethyst_block"); set(q.pa, q.pb, U, "polished_basalt"); set(q.pa, q.pb, U + 1, `stone_button ["facing_direction"=1]`); extra.btn.push(fr.W(q.pa, q.pb, U + 1)); });
    beamCmds(B, MIR0); set(0, 23, U + 4, "amethyst_cluster");
    for (const [a, b] of [[-6, 27], [6, 37], [-5, 37], [5, 27]]) { set(a, b, U, "amethyst_block"); set(a, b, U + 1, "amethyst_cluster"); }
    gate("G2", 1, G2, "amethyst_block");
  }
  if (E.ent === "sea") {
    box(-2, -23, -17, 2, -19, -1, P.w); box(-1, -22, U, 1, -20, 0, "water"); hall(B, P, -20, -6, "water");
    box(3, -22, 1, 7, -18, 1, "prismarine_bricks");
    for (const [a, b] of [[-2, -23], [2, -23], [-2, -19], [2, -19]]) { box(a, b, 1, a, b, 3, "prismarine"); set(a, b, 4, "sea_lantern"); }
    box(2, 3, U + 8, 6, 7, U + 8, P.w); box(3, 4, U + 6, 5, 6, U + 7, "air"); set(4, 5, U + 8, "sea_lantern");
    box(-6, 18, U + 8, -2, 22, U + 8, P.w); box(-5, 19, U + 6, -3, 21, U + 7, "air"); set(-4, 20, U + 8, "sea_lantern");
    box(-1, 23, U, 1, 27, U + 4, "water");
    pt("top", 5, -20, 2, 0, -21); pts.pk1 = fr.P(4, 5, U + 5); pts.pk2 = fr.P(-4, 20, U + 5);
    gate("G1", 1, G1, P.w, "water"); gate("G2", 2, G2, P.w, "water");
  }
  if (E.ent === "icecave") {
    box(-2, -24, 1, 2, -19, 4, "packed_ice"); box(-1, -24, 1, 1, -19, 3, "air"); stair(B, P, false); box(-2, -24, 5, 2, -19, 5, "snow");
    box(-6, 11, U - 3, 6, 21, U - 3, "water"); box(-6, 11, U - 2, 6, 21, U - 2, "air"); box(-6, 11, U - 1, 6, 21, U - 1, "ice");
    for (let b = 11; b <= 21; b++) for (let a = -6; a <= 6; a++) if (iceSafe(a, b)) set(a, b, U - 1, "packed_ice");
    for (const [a, b] of [[-6, 10], [6, 10], [-6, 22], [6, 22]]) set(a, b, U, "soul_lantern");
    for (const [a, b] of [[-5, 0], [5, 4], [-5, 30], [5, 33]]) box(a, b, U, a, b, U + 1, "blue_ice");
    const cs = CB(fr), co = CB(fr); cs.box(-1, 35, U, 1, 37, U + 2, "light_blue_stained_glass"); cs.box(0, 36, U, 0, 36, U + 1, "air"); co.box(-1, 35, U, 1, 37, U + 2, "air");
    B.C.push(...cs.C); gates.push({ id: "cage", after: 2, open: co.C, shut: cs.C });
    pt("end", 0, 22, U); pt("cage", 0, 36, U); pt("C", 0, 31, U, 0, 36); pts.tiles = { a1: -6, a2: 6, b1: 11, b2: 21 };
    pt("top", 4, -21, 1, 0, -24);
  }
  if (E.ent === "ribs") {
    for (const b of [-22, -18]) for (let k = 0; k <= 12; k++) { const t = (Math.PI * k) / 12, a = Math.round(5 * Math.cos(t)), h = 1 + Math.round(8 * Math.sin(t)); set(a, b, h, "bone_block"); if (k === 0 || k === 12) box(a, b, 1, a, b, 3, "bone_block"); }
    const g = mazeGrid(9001 + I.dir);
    for (let c = 0; c < 13; c++) for (let rw = 0; rw < 13; rw++) if (g[c][rw]) box(c - 6, rw + 10, U, c - 6, rw + 10, U + 2, "bone_block");
    extra.maze = g;
    for (let b = 27; b <= 37; b += 3) { box(-7, b, U, -7, b, U + 4, "bone_block"); box(7, b, U, 7, b, U + 4, "bone_block"); }
    pt("end", 0, 22, U);
  }
  if (E.ent === "well") pt("A", 0, 1, U, 0, 6);
  const q1 = fr.W(-9, -27, -21), q2 = fr.W(9, 42, 18);
  return { fr, C: B.C, pts, gates, extra, box: bx(q1, q2), fast: E.ent === "icecave" || E.ent === "sea" };
}
const bx = (a, b) => ({ x1: Math.min(a.x, b.x), x2: Math.max(a.x, b.x) + 1, y1: Math.min(a.y, b.y), y2: Math.max(a.y, b.y) + 1, z1: Math.min(a.z, b.z), z2: Math.max(a.z, b.z) + 1 });
const inBox = (B, l) => !!B && l.x >= B.x1 && l.x < B.x2 && l.z >= B.z1 && l.z < B.z2 && l.y >= B.y1 && l.y < B.y2;

/* ---------- 世界の 記録 ---------- */
const KEY = (r) => `mrpg:sev:${r}`;
const INFO = new Map();
export function evInfo(r) { if (INFO.has(r)) return INFO.get(r); let v = null; try { const s = world.getDynamicProperty(KEY(r)); v = typeof s === "string" ? JSON.parse(s) : null; } catch { return null; } INFO.set(r, v); return v; }
function setInfo(r, v) { INFO.delete(r); try { world.setDynamicProperty(KEY(r), v ? JSON.stringify(v) : undefined); } catch { return false; } INFO.set(r, v || null); return true; }
const GEO = new Map();
export function geoOf(E) { const I = evInfo(E.r); if (!I) return null; const c = GEO.get(E.r); if (c && c.I.x === I.x && c.I.z === I.z && c.I.dir === I.dir && c.I.y === I.y) return c; const G = { ...geo(E, I), I }; GEO.set(E.r, G); return G; }
const siteOf = (E) => landSites(E.r)[E.k];
/* 町・城・洞くつ・ほかの ステージから いちばん はなれる 向き */
export function chooseDir(E, cx, cz) {
  const obs = [];
  for (const t of TOWNS) { try { const q = townPos(t); obs.push([q.x, q.z, 56]); } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) {
    try { const c = castleInfo(i) || castleSpot(i); if (c) obs.push([c.x, c.z, 80]); } catch {}
    try { for (const L of landSites(i)) if (Math.hypot(L.x - cx, L.z - cz) > 2) obs.push([L.x, L.z, 30]); } catch {}
  }
  for (const i of CAVE_R) { try { const b = caveBox(i); obs.push([(b.x1 + b.x2) / 2, (b.z1 + b.z2) / 2, Math.hypot(b.x2 - b.x1, b.z2 - b.z1) / 2 + 12]); } catch {} }
  const far = E.ent === "sky" ? [20, 40, 60] : [-24, 5, 22, 40];
  let best = 0, bv = -1e9;
  for (const d of E.ent === "sky" ? [0, 1] : [0, 1, 2, 3]) {
    const F = DIRV[d], R = { x: -F.z, z: F.x }; let v = 1e9;
    for (const k of far) for (const s of [-9, 9]) { const x = cx + F.x * k + R.x * s, z = cz + F.z * k + R.z * s; for (const [ox, oz, rr] of obs) v = Math.min(v, Math.hypot(ox - x, oz - z) - rr); }
    if (v > bv + 0.01) { bv = v; best = d; }
  }
  return best;
}
hooks.sevBox = (r) => { try { const E = EV_OF(r), I = E && evInfo(r); if (!I) return null; const G = geoOf(E); return G ? G.box : null; } catch { return null; } };   /* 第124版: 新しい アジト（洞くつ）は もう ある 地下部屋を さける */
/* 第124版(tr): 新しい 地形の ステージは、作る ときに 出来事の 入口の 向きを 決めて そこを 平らに 残す（あとで 同じ 向きに 建てる）*/
LAND_HOOK.dir = (r, k, x, z) => { const E = EVS.find((e) => e.r === r && e.k === k); if (!E) return -1; const I = evInfo(r); return I && typeof I.dir === "number" ? I.dir : chooseDir(E, x, z); };
const BLD = new Set();
function tryBuild(E) {
  if (BLD.has(E.r) || building() || warming() || heavy() >= 2) return;
  const L = siteOf(E); if (!L) return; const LI = landInfo(L.key); if (!LI || !LI.built || typeof LI.y !== "number") return;
  const I = { v: SEV_V, x: Math.floor(L.x), y: Math.floor(LI.y), z: Math.floor(L.z), dir: LI.tv && LI.ed >= 0 && LI.ed <= 3 ? LI.ed : chooseDir(E, L.x, L.z), built: false };
  if (!setInfo(E.r, I)) return;
  GEO.delete(E.r);
  const G = geoOf(E); if (!G) return;
  BLD.add(E.r);
  const a = { x: G.box.x1, y: Math.max(-60, G.box.y1), z: G.box.z1 }, b = { x: G.box.x2, y: Math.min(300, G.box.y2), z: G.box.z2 };
  enqueue(OW(), G.C, () => { BLD.delete(E.r); setInfo(E.r, { ...I, built: true }); WS.delete(E.r);
    for (const q of world.getAllPlayers()) if (Math.hypot(q.location.x - I.x, q.location.z - I.z) < 140) try { q.sendMessage(`§b${WREGIONS[E.r].short}の 大地に「${E.nm}」が あるらしい……`); } catch {} },
  [a, b], () => { BLD.delete(E.r); setInfo(E.r, null); GEO.delete(E.r); });
}

/* ---------- プレイヤーの 進み ---------- */
function stAll(p) { try { const v = JSON.parse(p.getDynamicProperty("mrpg:sev") || "{}"); return v && typeof v === "object" ? v : {}; } catch { return {}; } }
export const stOf = (p, r) => { const v = stAll(p)[r]; return typeof v === "number" ? v : 0; };
function setSt(p, r, n) { const v = stAll(p); v[r] = n; try { p.setDynamicProperty("mrpg:sev", JSON.stringify(v)); } catch {} }
const PM = new Map();   /* プレイヤーごとの いまの 仕掛けの 記録（ぬけたら 消える）*/
function pm(p, E) { let M = PM.get(p.id); if (!M || M.r !== E.r || M.st !== stOf(p, E.r)) { if (M) pmClean(M); M = { r: E.r, st: stOf(p, E.r) }; PM.set(p.id, M); } return M; }
function pmClean(M) { if (M && M.ch) rmE(M.ch); }
function advance(p, E, st, msg) {
  if (stOf(p, E.r) !== st) return false;
  setSt(p, E.r, st + 1); sound(p, "random.orb", 1.2);
  if (msg) try { barNote(p).setActionBar(msg); } catch {}
  return true;
}
const WS = new Map();   /* 出来事ごとの 仕掛けの ようす（扉・鏡・順番）*/
function wsOf(E) { let W = WS.get(E.r); if (!W) { W = { gate: {}, last: 0, dirty: false, mir: [...MIR0], seq: [], solvers: new Set(), tiles: new Map() }; WS.set(E.r, W); } return W; }
function runCmds(L) { const D = OW(); let okk = true; for (const c of L) { try { D.runCommand(c); } catch { okk = false; } } return okk; }

/* ---------- ほうび ---------- */
function eggFor(fams, cap) {
  for (const f of fams) { const ids = f === "rainbow" ? ["e_rainbow"] : [4, 3, 2, 1, 0].map((k) => `e_${f}${k}`); for (const id of ids) if (ITEMS[id] && EGGS[id] && storyLootOk(ITEMS[id], EGGS[id].ranks, cap)) return id; }
  return null;
}
function seedFor(s, cap) { for (const id of [`s_${s}2`, `s_${s}`]) if (ITEMS[id] && storyLootOk(ITEMS[id], null, cap)) return id; return null; }
function gearFor(kind, re, cap) {
  const L = Object.keys(ITEMS).filter((id) => { const it = ITEMS[id]; return it.kind === kind && id !== "wp_tokoyo" && (it.price || 0) > 0 && storyItemOk(it, null, cap) && (!re || re.test(id)); });
  if (!L.length) return null; const lv = (id) => ITEMS[id].wt ?? ITEMS[id].tier ?? 0, top = Math.max(...L.map(lv));
  return pick(L.filter((id) => lv(id) === top));
}
export function giveRew(p, d, R) {
  const cap = rankCap(d), got = [];
  const eg = R.egg && eggFor(R.egg, cap); if (eg) { giveItem(p, `mrpg:${eg}`, 1); got.push(`§b${ITEMS[eg].name}`); }
  if (R.seed) { const s = seedFor(R.seed, cap); if (s) { giveItem(p, `mrpg:${s}`, 2); got.push(`§b${ITEMS[s].name} ×2`); } else got.push(boon(p, d, 1)); }
  if (R.gear) { const g = gearFor(R.gear[0], R.gear[1], cap) || gearFor(R.gear[0], null, cap); if (g) { const roll = capRoll(p, g, rollGear(g, "boss")); giveGear(p, g, roll); got.push(gearName(g, roll)); } else got.push(boon(p, d, 1)); }
  if (!got.length) got.push(boon(p, d, 2));
  return got;
}

/* ---------- 戦いの 相手 ---------- */
const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
const rankForLv = (lv) => (lv < 8 ? 0 : lv < 14 ? 1 : lv < 22 ? 2 : lv < 32 ? 3 : lv < 44 ? 4 : lv < 56 ? 5 : lv < 70 ? 6 : 7);
function bigOf(fams, lv) {
  for (const up of [1, 0, 2, -1]) { const rk = Math.max(0, Math.min(7, rankForLv(lv) + up)); const c = ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !S.giant && fams.includes(S.fam) && S.rank === RK[rk] && (S.sz === "L" || S.sz === "G"); }); if (c.length) return pick(c); }
  return null;
}
function smallOf(fams) { const c = ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && fams.includes(S.fam) && /^[FED]$/.test(S.rank || "") && (S.sz === "S" || S.sz === "M"); }); return c.length ? pick(c) : ORDER[0]; }
function lvOf(E) { try { const L = siteOf(E); return Math.max(3, Math.floor(regionLv({ x: L.x, y: 64, z: L.z })) + 1); } catch { const R = WREGIONS[E.r]; return Math.round((R.lv[0] + R.lv[1]) / 2); } }
const wildT = (E, lv, n = 2) => team(E.fams, lv, n);
const bossT = (E, lv) => { const lead = bigOf(E.fams, lv + 2); return team(E.fams, lv + 2, 2, 3, lead); };
const gruntT = (id, lv) => { const g = gruntOf(id); return team(g ? g.fams : ["beast"], lv, 2); };

/* ---------- 場面の 道具 ---------- */
function rmE(e) { if (ok(e)) try { globalThis.__mqCine?.delete(e.id); e.remove(); } catch {} }
function walkIn(S, e, to) { walkIn0(S, e, to, { x: S.P.x, y: S.P.y + 1.5, z: S.P.z }); }   /* 第124版(cam): 映らない 所から 歩いて 来る（stagecore）*/
function healHalf(p) { try { const d = load(p); if (!d) return; for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = Math.max(m.hp, Math.floor(c.hp / 2)); m.mp = Math.max(m.mp, Math.floor(c.mp / 2)); } save(p, d); } catch {} }
function mkCtx(p, E, G) {
  const X = { p, E, G, acts: [], going: [], lv: lvOf(E) };
  const WK = `${E.r}:${stOf(p, E.r)}`; try { X.won = p.getDynamicProperty("mrpg:sevw") === WK; } catch {}   /* 第124版: 勝った あとで ぬけたら、次は 戦いを とばして 勝った あとの 話から */
  const tagE = (e) => { try { e.addTag("mrpg_temp"); e.addTag("mrpg_sev"); e.setDynamicProperty("mrpg:sevOwner", p.id); } catch {} };
  X.npc = (name, skin, role = "ally", at = null, walk = true) => {
    const S = stageOf(p); if (!S) return null;
    const pos = at || slotOf(S, role, name, null); let e;
    try { e = p.dimension.spawnEntity("mrpg:npc", pos); } catch { return null; }
    try { const k = PSKIN[skin]; if (k) setJob(e, k[0]); e.addTag("mrpg_npc"); e.nameTag = name; } catch {}
    tagE(e); addActor(S, e, name, pos);
    try { e.teleport(pos, { facingLocation: { x: S.P.x, y: S.P.y + 1.5, z: S.P.z } }); } catch {}
    if (walk && !at) walkIn(S, e, pos);
    else if (!at && inScene(p)) { try { e.addEffect("invisibility", 12, { showParticles: false }); fadeOn(p, "0.15 0.25 0.35"); } catch {} system.runTimeout(() => { try { if (ok(e)) e.removeEffect("invisibility"); } catch {} }, 5); }   /* 第124版(cam): もとから そこに いた 人は 暗転の 中で */
    X.acts.push({ e, name, skin, role, at: pos }); return e;
  };
  X.mon = (sid, role = "foe", at = null, name = "", how = "smoke") => {
    const S = stageOf(p); if (!S || !sid) return null;
    const pos = at || slotOf(S, role, name || sid, null); let e;
    try { e = p.dimension.spawnEntity(TYPE, pos); } catch { return null; }
    try { (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(e.id); e.addTag("mrpg_cine"); setLook(e, sid); e.teleport(pos, { facingLocation: { x: S.P.x, y: S.P.y + 1, z: S.P.z } }); } catch {}
    tagE(e); addActor(S, e, name || sid, pos); if (how === "smoke" && inScene(p)) smokeIn(e);   /* 第124版(cam): 煙の 中で あらわれる */
    X.acts.push({ e, sid, role, at: pos, mon: true, name }); return e;
  };
  X.act = (e, n) => { try { if (ok(e)) { e.setProperty("mrpg:act", n); e.setDynamicProperty("mrpg:act0", n); } } catch {} };
  X.say = async (who, lines, col = "§e") => { if (!X.won) return talk(p, who, lines.map(fmtO), col); };
  X.tell = async (lines) => { if (!X.won) return tell(p, E.nm, lines.map(fmtO)); };
  X.leave = (e) => {   /* 第124版(cam): 人は カメラに 映らない 所まで 歩いて 去る（映った ままなら 暗く して から）・モンスターは 煙の 中で */
    if (!ok(e)) return; const mon = X.acts.some((a) => a.e === e && a.mon); X.acts = X.acts.filter((a) => a.e !== e);
    if (mon || !inScene(p)) { try { globalThis.__mqCine?.delete(e.id); } catch {} if (inScene(p)) smokeOut(e, 6); else rmE(e); return; }
    const f = { ...e.location }, q = exitPt(p, e, 9) || f, N = Math.max(10, Math.round(d2(f, q) * 2)); X.act(e, 19); try { e.setProperty("mrpg:mv", true); } catch {} X.going.push(e);
    let k = 0; const id = system.runInterval(() => { k++; if (!ok(e)) { system.clearRun(id); return; }
      if (k > N) { system.clearRun(id); if (inScene(p) && inCam(p, e.location, stageOf(p)?.C)) { fadeOn(p, "0.25 0.2 0.4"); system.runTimeout(() => rmE(e), 6); } else rmE(e); return; }
      const t = k / N; try { e.teleport({ x: f.x + (q.x - f.x) * t, y: f.y + (q.y - f.y) * t, z: f.z + (q.z - f.z) * t }, { facingLocation: { x: q.x, y: q.y + 1.5, z: q.z } }); } catch {} }, 1);
  };
  X.duel = async (foe, name, lines = {}) => {
    if (X.won) { X.won = false; return "win"; }
    if (!foe || !foe.length) return "win";
    if (inScene(p)) { try { cineSting(p, "§e§lBATTLE", 26); } catch {} await wait(22); try { camFade(p); } catch {} await wait(9); }
    const keep = X.acts.filter((a) => ok(a.e)).map((a) => { let at = a.at; try { at = { ...a.e.location }; } catch {} return { ...a, at }; });
    for (const a of keep) rmE(a.e); X.acts = [];
    try { scenePause(p); } catch {}
    let res = null;
    try { res = await (SE.fight || fight)(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", name, arena: "ステージの 出来事", speaker: name, lines, friends: true }); } catch (e) { console.warn(`[MonsterRPG] sev fight: ${e}`); }
    if (ok(p) && stageOf(p)) { for (const a of keep) a.mon ? X.mon(a.sid, a.role, a.at, a.name, "none") : X.npc(a.name, a.skin, a.role, a.at, false); try { sceneResume(p); } catch {} }
    if (res === "win") try { p.setDynamicProperty("mrpg:sevw", WK); } catch {}
    if (res !== "win") { healHalf(p); try { barNote(p).setActionBar("§7負けて しまった……準備を して、もう一度 ここへ 来よう（続きから できる）"); } catch {} }
    return res;
  };
  X.gift = async (lines = []) => {
    const d = load(p); if (!d || stOf(p, E.r) >= STEPS[E.r].length) return false;
    const got = giveRew(p, d, E.rew);
    setSt(p, E.r, STEPS[E.r].length); save(p, d);
    sound(p, "random.levelup", 1);
    try { p.sendMessage(`§e§l「${E.nm}」§r§e を やりとげた！ §fもらった: ${got.join("§f・")}`); } catch {}
    await tell(p, "ほうび", [...lines.map(fmtO), `§aもらった: ${got.join("§f・")}`, "§7（持ち物か バッグに 入った）"]);
    return true;
  };
  X.clear = () => { for (const a of X.acts) rmE(a.e); X.acts = []; for (const e of X.going) rmE(e); X.going = []; };   /* 第124版(cam): 去る とちゅうの 人も（場面の 終わりの 暗転の 中で）*/
  return X;
}

/* ---------- 段（scene: 立ち止まって 始まる 場面・reach: 着けば よい・puzzle: 仕掛け）---------- */
const G_ = (id) => gruntOf(id) || { nm: id, sk: "noxa", fams: ["beast"] };
const STEPS = {
  0: [
    { k: "scene", at: "top", hint: "§e古井戸の そばで 困って いる 人が いる §7（井戸の 近くで 立ち止まろう）", run: async (X) => {
      X.npc("§eハンナ", "hanna2");
      await X.say("ハンナ", ["{sad}たいへん！ うちの 子が 古井戸に 落ちちゃったの！", "あの子の モンスターも いっしょに……下の 水路から 泣き声が するの。", "はしごで 下りられるわ。お願い、あの子を 助けて！"]);
      await X.tell(["§7→ 古井戸の はしごを 下りて、地下水路の 奥の 部屋へ 行こう"]);
      return true; } },
    { k: "scene", at: "B", hint: "§f古井戸の はしごを 下りて、地下水路の §e奥の 部屋§f へ 行こう", run: async (X) => {
      const foe = wildT(X.E, X.lv, 2), pet = smallOf(["blob"]);
      X.npc("§eタロ", "taro", "ally"); X.mon(pet, "ally", null, "タロの モンスター"); X.mon(foe[0]?.sid, "foe", null, "野生の モンスター");
      await X.say("タロ", ["{sad}うわーん！ だれか〜！", "ぼくの モンスターが、こわい 野生の モンスターに かこまれて いるの！"]);
      const res = await X.duel(foe, "水路の 野生モンスター");
      if (res !== "win") { await X.say("タロ", ["{sad}まだ いる……！ でも、待ってるね……"]); return false; }
      await X.say("タロ", ["{smile}やったあ！ ありがとう！", "ぼくも この子も けがは ないよ。はしごは ひとりで のぼれるから、先に 上で 待ってるね！"]);
      for (const a of [...X.acts]) X.leave(a.e);
      await X.tell(["§7→ 井戸の 上に もどって、おかあさんに 知らせよう"]);
      return true; } },
    { k: "scene", at: "top", hint: "§f井戸の 上へ もどって、§eおかあさん§f に 知らせよう", run: async (X) => {
      X.npc("§eハンナ", "hanna2"); X.npc("§eタロ", "taro");
      await X.say("ハンナ", ["{smile}ああ、よかった……！ 本当に ありがとう！"]);
      await X.say("タロ", ["{smile}旅の 人、すっごく 強かったんだよ！"]);
      await X.say("ハンナ", ["これは うちの 牧場で 大事に して いた タマゴと、元気の 出る 木の実よ。旅に 役立てて。"]);
      return X.gift(); } },
  ],
  1: [
    { k: "scene", at: "A", hint: "§f大樹の 根もとの 穴から 下りて、§e根の 下の 洞§f へ 行こう", run: async (X) => {
      X.npc("§e森番ルー", "m6_lugh");
      await X.say("森番ルー", ["{sad}よく 来て くれた。大樹の 根が、虫たちに かじられて いるんだ。", "奥の 部屋に 虫の 巣が 3つ ある。近づけば、この 虫よけの 草で はらえる。", "巣を はらうと、根の 奥の 扉が ひらく はずだ。"]);
      await X.tell(["§7→ 奥の 部屋の 虫の 巣を 3つ はらおう（近づくだけで よい）"]);
      return true; } },
    { k: "puzzle", hint: "§f奥の 部屋の §e虫の 巣§f を 3つ はらおう §7（近づくだけで よい）", msg: "§a巣を ぜんぶ はらった！ §f根の 奥で 大きな 何かが 動いた……", tick: (p, E, G, W) => {
      const M = pm(p, E); M.n = M.n || new Set();
      G.pts.nests.forEach((q, i) => { if (M.n.has(i) || !near(p, q, 2.2)) return; M.n.add(i); W.dirty = true; const c = CB(G.fr); c.set(NESTS[i][0], NESTS[i][1], U, "air"); c.set(NESTS[i][0], NESTS[i][1], U + 1, "air"); runCmds(c.C); try { p.dimension.spawnParticle("minecraft:villager_happy", { x: q.x, y: q.y + 1, z: q.z }); } catch {} sound(p, "dig.grass", 1); try { barNote(p).setActionBar(`§a虫の 巣を はらった §f（${M.n.size}/3）`); } catch {} });
      return M.n.size >= 3; } },
    { k: "scene", at: "C", hint: "§f根の いちばん 奥の 部屋で §e虫の 主§f を しずめよう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "虫の 主");
      await X.tell(["§7（根の 奥で、大きな 虫の 主が こちらを にらんで いる……）", "§7→ 虫の 主を しずめよう！"]);
      const res = await X.duel(foe, "根を 食い荒らす 虫の 主");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      await X.tell(["§7（虫の 主は おとなしく なって、根の 奥へ 帰って いった）"]);
      X.npc("§e森番ルー", "m6_lugh");
      await X.say("森番ルー", ["{smile}ありがとう！ これで 大樹も 元気を 取りもどす。", "森で 見つけた タマゴと、足の 速く なる 木の実だ。持って いって くれ。"]);
      return X.gift(); } },
  ],
  2: [
    { k: "scene", at: "A", hint: "§f崩れた 墓の 建物から 地下へ 下りよう §7（地下で 何か 物音が する）", run: async (X) => {
      const g = G_("gametsu"); X.npc(`§5${ORG}の ${g.nm}`, g.sk, "foe");
      await X.say(g.nm, ["タダより 高い ものは ない！ だから 墓の お宝は タダで いただく！", "なんだ お前、{o}の じゃまを する 気か？"], "§5");
      const res = await X.duel(gruntT("gametsu", X.lv), `${ORG}の ${g.nm}`, { half: g.kuchi, low: g.lose[0] });
      if (res !== "win") { await X.say(g.nm, ["もうけ もうけ！ 出直して きな！"], "§5"); return false; }
      await X.say(g.nm, ["大赤字だ……！ おぼえてろ〜！"], "§5");
      for (const a of [...X.acts]) X.leave(a.e);
      await X.tell(["§7（ガメツは 逃げて いった。奥の 扉の 石が ずれた ようだ）", "§7→ 奥の 墓の 部屋へ 進もう"]);
      return true; } },
    { k: "puzzle", hint: "§f墓の 部屋: §e石碑と 墓の 文字§f を 読んで、ボタンを 正しい 順に 押そう", msg: "§a奥の 扉が ひらいた！", tick: (p, E, G, W) => {
      const M = pm(p, E), now = Date.now();
      if (now - (M.rt || 0) > 2500) {
        if (near(p, G.pts.tablet, 1.8)) { M.rt = now; try { barNote(p).setActionBar("§7石碑:『いちばん 古い 墓から 順に 祈れ。そう すれば 道は ひらく』"); } catch {} }
        else G.pts.graves.forEach((q, i) => { if (near(p, q, 1.6)) { M.rt = now; try { barNote(p).setActionBar(`§7墓の 文字:『${GRAVES[i][2]}年 前に ねむる 者』 §8（ボタンを 押すと 祈る）`); } catch {} } });
      }
      return W.solvers.has(p.id); } },
    { k: "scene", at: "C", hint: "§fいちばん 奥の §e騎士の 墓§f へ 行こう", run: async (X) => {
      X.npc("§e墓守の 騎士", "stoneknight", "ally");
      await X.say("墓守の 騎士", ["よくぞ 墓荒らしを 追いはらい、古い 者を うやまう 心を 見せて くれた。", "わしは この 墓所を 守る 騎士の 魂。", "生きて いた ころの 剣と、守って きた タマゴを おまえに たくそう。"]);
      return X.gift(["§7（騎士の 姿は、静かに 光の 中へ 消えて いった）"]); } },
  ],
  3: [
    { k: "scene", at: "A", hint: "§f坑道の 入口から 下りよう §7（中から 走る 音が する）", run: async (X) => {
      const g = G_("choro"); const e = X.npc(`§5${ORG}の ${g.nm}`, g.sk, "foe");
      await X.say(g.nm, ["げっ、見つかったっす！ この 鉱石は ……ひ、拾った だけっす！", "逃げるが 勝ちっす〜！"], "§5");
      X.leave(e);
      await X.tell(["§7→ 暗い 坑道を 進んで、チョロを 追いかけよう！"]);
      return true; } },
    { k: "puzzle", hint: "§f暗い 坑道を 進んで §e逃げる チョロ§f を 追いかけよう", msg: "§aチョロを 追いつめた！", tick: (p, E, G) => {
      const M = pm(p, E), L = G.pts.ch; M.i = M.i || 0;
      if (!ok(M.ch)) { try { const e = p.dimension.spawnEntity("mrpg:npc", L[M.i]); setJob(e, PSKIN.noxa[0]); e.addTag("mrpg_npc"); e.addTag("mrpg_temp"); e.addTag("mrpg_sev"); e.setDynamicProperty("mrpg:sevOwner", p.id); e.nameTag = `§5${ORG}の チョロ`; e.triggerEvent("mrpg:still"); M.ch = e; } catch {} }
      if (ok(M.ch) && M.i < L.length - 1 && d2(p.location, M.ch.location) < 6) {
        M.i++; try { M.ch.dimension.spawnParticle("minecraft:white_smoke_particle", M.ch.location); M.ch.teleport(L[M.i], { facingLocation: G.pts.C }); M.ch.setProperty("mrpg:act", 19); } catch {}
        sound(p, "mob.horse.gallop", 1.4); try { barNote(p).setActionBar(`§5チョロ§f「${pick(["逃げるが 勝ちっす！", "しつこいっす〜！", "こっちは 行き止まり……じゃ ないっす！"])}」`); } catch {}
      }
      if (M.i >= L.length - 1 && near(p, G.pts.C, 4)) { rmE(M.ch); M.ch = null; return true; }
      return false; } },
    { k: "scene", at: "C", hint: "§f坑道の いちばん 奥で §eチョロ§f を つかまえよう", run: async (X) => {
      const g = G_("choro"); X.npc(`§5${ORG}の ${g.nm}`, g.sk, "foe", null, false);
      await X.say(g.nm, ["ひいっ、行き止まりっす……！", "こ、こうなったら 戦うっす！ 逃げるのは そのあとっす！"], "§5");
      const res = await X.duel(gruntT("choro", X.lv + 1), `${ORG}の ${g.nm}`, { half: g.kuchi, low: g.lose[0] });
      if (res !== "win") { await X.say(g.nm, ["や、やったっす！ 逃げなくて よかったっす！"], "§5"); return false; }
      await X.say(g.nm, ["逃げるが 勝ちっす……負けたけど……", "鉱石は 返すっす！ ついでに 拾った ヨロイと タマゴも 置いて いくっす〜！"], "§5");
      for (const a of [...X.acts]) X.leave(a.e);
      return X.gift(["§7（チョロは 坑道の 外へ 逃げて いった）"]); } },
  ],
  4: [
    { k: "scene", at: "top", hint: "§e砂の 大地の 石の 柱§f の そばで 立ち止まろう", run: async (X) => {
      X.npc("§e砂の 商人サミール", "m6_samir");
      await X.say("砂の 商人サミール", ["この 石の 柱の 下に、むかしの 小さな 神殿が 眠って いるんだ。", "入口は 砂の 下。砂嵐が 来ると、風が 砂を はらって くれるんだが……", "{surprise}……おっと、来たぞ！ 砂嵐だ！"]);
      try { X.p.addEffect("blindness", 50, { showParticles: false }); } catch {} sound(X.p, "mob.horse.breathe", 0.5);
      for (let k = 0; k < 6; k++) { try { const l = X.p.location; X.p.dimension.spawnParticle("minecraft:basic_smoke_particle", { x: l.x + (Math.random() - 0.5) * 6, y: l.y + 1, z: l.z + (Math.random() - 0.5) * 6 }); } catch {} await wait(6); }
      await X.tell(["§7（砂嵐が 去ると、砂の 下から 階段が あらわれた！）", "§7→ 階段を 下りて 神殿へ 入ろう"]);
      return true; } },
    { k: "puzzle", hint: "§f神殿の 中: §e本物の 道§f を 進もう §7（石碑を 読もう）", msg: "§a本物の 道を 見つけた！", tick: (p, E, G) => {
      const M = pm(p, E), q = G.fr.loc(p.location), now = Date.now();
      if (near(p, G.pts.tablet, 1.8) && now - (M.rt || 0) > 3000) { M.rt = now; try { barNote(p).setActionBar("§7石碑:『本物の 道には 影が ある。光る 道は まぼろし』"); } catch {} }
      if (q.h >= U - 1 && q.h <= U + 3 && q.b >= 19 && q.b <= 22 && q.a <= 1 && q.a >= -6) { const back = G.fr.P(q.a <= -2 ? -4 : 0, 11, U); try { p.teleport(back, { facingLocation: G.fr.P(q.a <= -2 ? -4 : 0, 16, U + 1) }); p.dimension.spawnParticle("minecraft:basic_smoke_particle", back); } catch {} sound(p, "mob.endermen.portal", 1); try { barNote(p).setActionBar("§eゆらゆら……§f蜃気楼だった！ §7入口に もどされた"); } catch {} return false; }
      return near(p, G.pts.end, 2.4); } },
    { k: "scene", at: "C", hint: "§f神殿の いちばん 奥の 部屋へ 行こう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "砂の 守り神");
      await X.tell(["§7（砂が 集まって、大きな 守り神の 姿に なった……）", "§e？？？§f「……まぼろしを 見やぶった 者よ。その 力、ためさせて もらう」"]);
      const res = await X.duel(foe, "砂の 守り神");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      return X.gift(["§e砂の 守り神§f「みごと。神殿の 宝を 持って いくが よい」", "§7（守り神は さらさらと 砂に もどって いった）"]); } },
  ],
  5: [
    { k: "scene", at: "A", hint: "§f水晶の 入口から 下りて、§e地底湖§f へ 行こう", run: async (X) => {
      X.npc("§e水晶掘りの クオン", "m6_crystal");
      await X.say("水晶掘りの クオン", ["ここは 水晶の 地底湖。奥の 部屋には、光で ひらく 扉が あるんだ。", "鏡の 柱の そばの 台の ボタンを 押すと、鏡の 向きが かわる。", "黄色い 光の すじを、扉の 前の 床まで とどけて ごらん。"]);
      return true; } },
    { k: "puzzle", hint: "§f鏡の 部屋: §eボタン§f で 鏡の 向きを かえて、光を 扉の 前まで とどけよう", msg: "§a光が とどいた！ 水晶の 扉が ひらく……", tick: (p, E, G, W) => { if (W.solvers.has(p.id)) return true; const q = G.fr.loc(p.location); return q.b >= 10 && q.b <= 22 && Math.abs(q.h - U) <= 1 && beam(W.mir).hit; } },
    { k: "scene", at: "C", hint: "§f水晶の 扉の 先の §e地底湖の 奥§f へ 行こう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "水晶の 番人");
      await X.tell(["§7（水晶の 光の 中から、番人が 立ち上がった……）"]);
      const res = await X.duel(foe, "水晶の 番人");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      X.npc("§e水晶掘りの クオン", "m6_crystal");
      await X.say("水晶掘りの クオン", ["{surprise}扉の 向こうに こんな 所が……！ きみの おかげだ。", "湖の 底で 見つけた タマゴと、守りの 木の実だ。もらって くれ。"]);
      return X.gift(); } },
  ],
  6: [
    { k: "scene", at: "top", hint: "§e海の 大地の 桟橋§f で 立ち止まろう", run: async (X) => {
      X.npc("§e漁師ウミオ", "m6_umi");
      await X.say("漁師ウミオ", ["この 下に、海に しずんだ 神殿が あるんだ。"]);
      if (!hasKey(X.p, "k_goggle")) { await X.say("漁師ウミオ", ["でも、潜水ゴーグルが ないと 暗くて 息も つづかない。", "ゴーグルを 手に 入れてから、また 来な。"]); await X.tell(["§7（潜水ゴーグルは 物語の 中で 手に 入る）"]); return false; }
      await X.say("漁師ウミオ", ["その ゴーグルが あれば もぐれるな。", "中の §b空気だまり§f に 顔を 出すと、仕掛けが 動いて 道が ひらくらしい。", "いちばん 奥に 神殿の 主が いる。気を つけてな。"]);
      await X.tell(["§7→ 入口の 穴から もぐって、空気だまりを 2つ 見つけよう"]);
      return true; } },
    { k: "reach", hint: "§f水の 中を 進んで、天井の §b空気だまり§f（1つ目）に 顔を 出そう", msg: "§b空気だまりで 息を ついた！ §fどこかで 扉の ひらく 音が した", ok: (p, E, G) => { const l = p.location, q = G.pts.pk1; return d2(l, q) <= 1.8 && l.y >= q.y - 0.6; } },
    { k: "reach", hint: "§f次の 部屋の 天井の §b空気だまり§f（2つ目）に 顔を 出そう", msg: "§b空気だまりで 息を ついた！ §f奥への 扉が ひらいた", ok: (p, E, G) => { const l = p.location, q = G.pts.pk2; return d2(l, q) <= 1.8 && l.y >= q.y - 0.6; } },
    { k: "scene", at: "C", hint: "§f水の 道を 上って、§e神殿の いちばん 奥§f へ 行こう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "神殿の 主");
      await X.tell(["§7（神殿の 主が、水しぶきを 上げて 立ちはだかった！）"]);
      const res = await X.duel(foe, "しずんだ 神殿の 主");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      return X.gift(["§7（主は 海の 奥へ 帰って いった。祭壇に 宝が のこされて いる）"]); } },
  ],
  7: [
    { k: "scene", at: "A", hint: "§f霊廟の 中の 階段から 地下へ 下りよう", run: async (X) => {
      X.npc("§e墓守ノクト", "m6_noct");
      await X.say("墓守ノクト", ["この 下の 部屋に、姿の 見えない 亡霊が 3人 さまよって いる。", "灯り……たいまつや ランタンを 手に 持って 近づけば、姿が 見える。", "これを 持って いけ。"]);
      let tg = false; try { tg = !X.p.getDynamicProperty("mrpg:sev7t"); if (tg) { X.p.setDynamicProperty("mrpg:sev7t", true); const c = X.p.getComponent("minecraft:inventory")?.container; const rest = c?.addItem(new ItemStack("minecraft:torch", 8)); if (rest) X.p.dimension.spawnItem(rest, X.p.location); } } catch {}   /* 第124版: たいまつは 1回だけ */
      await X.tell([tg ? "§eたいまつ ×8§f を もらった。" : "§7（たいまつは さっき もらった ものを 使おう）", "§7→ たいまつを 手に 持って、奥の 暗い 部屋で 亡霊を 3人 さがそう"]);
      return true; } },
    { k: "puzzle", hint: "§fたいまつを §e手に 持って§f、暗い 部屋で 亡霊を 3人 さがそう", msg: "§a亡霊を 3人 見つけた！ §f奥の 扉が きしんで ひらいた", tick: (p, E, G) => {
      const M = pm(p, E); M.g = M.g || new Set(); const now = Date.now(); const lit = lightIn(p);
      G.pts.ghosts.forEach((q, i) => {
        if (M.g.has(i)) return; const dd = d2(p.location, q);
        if (dd < 3.6 && lit) { M.g.add(i); try { p.dimension.spawnParticle("minecraft:soul_particle", { x: q.x, y: q.y + 1, z: q.z }); p.dimension.spawnParticle("minecraft:basic_smoke_particle", { x: q.x, y: q.y + 1.4, z: q.z }); } catch {} sound(p, "mob.vex.ambient", 0.7); try { barNote(p).setActionBar(`§b亡霊§f「${["……見つかって しまった……", "……あたたかい 光だ……", "……もう、ねむれる……"][i]}」 §7（${M.g.size}/3）`); } catch {} }
        else if (dd < 6 && now - (M.ht || 0) > 4000) { M.ht = now; try { p.dimension.spawnParticle("minecraft:soul_particle", { x: q.x, y: q.y + 1.2, z: q.z }); barNote(p).setActionBar(lit ? "§7ひやり と した……もっと 近くに 何か いる" : "§7ひやり と した……何かが いる。§eたいまつを 手に 持とう"); } catch {} }
      });
      return M.g.size >= 3; } },
    { k: "scene", at: "C", hint: "§f霊廟の いちばん 奥の 部屋へ 行こう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "亡霊の 主");
      await X.tell(["§e亡霊の 主§f「……わしの 眠りを さまたげるのは だれだ……」"]);
      const res = await X.duel(foe, "霊廟の 亡霊の 主");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      await X.tell(["§7（亡霊の 主は、静かに 消えて いった……）"]);
      X.npc("§e墓守ノクト", "m6_noct");
      await X.say("墓守ノクト", ["これで 霊廟も 静かに なる。礼を 言う。", "墓に そなえられて いた タマゴと、心を 強く する 木の実だ。"]);
      return X.gift(); } },
  ],
  8: [
    { k: "scene", at: "A", hint: "§f氷の 洞窟の 入口から 下りよう", run: async (X) => {
      X.npc("§e雪国の エイリク", "m6_eirik");
      await X.say("雪国の エイリク", ["奥の 氷の 中に、モンスターが 閉じこめられて いるんだ。", "でも さっき、変な やつが 奥へ 入って いった……", "床の 氷に 気を つけろ。§bすきとおった 氷§f は うすくて 割れる。§f白く くもった 氷§f の 上を 歩くんだ。"]);
      return true; } },
    { k: "puzzle", hint: "§f氷の 床: §f白く くもった 氷§f の 上だけを 歩いて 向こうへ わたろう", msg: "§a氷の 床を わたりきった！", tick: (p, E, G) => near(p, G.pts.end, 1.8) },
    { k: "scene", at: "C", hint: "§f洞窟の いちばん 奥の §e氷づけの モンスター§f の ところへ 行こう", run: async (X) => {
      const g = G_("dongo"), pet = smallOf(["beast"]);
      X.mon(pet, "ally", X.G.pts.cage, "氷づけの モンスター"); X.npc(`§5${ORG}の ${g.nm}`, g.sk, "foe");
      await X.say(g.nm, ["オレさまを だれだと 思ってる！ {o}の ドンゴさまだぞ！", "この 氷づけの モンスターは、オレさまが いただく！"], "§5");
      const res = await X.duel(gruntT("dongo", X.lv + 1), `${ORG}の ${g.nm}`, { half: g.kuchi, low: g.lose[0] });
      if (res !== "win") { await X.say(g.nm, ["見たか！ オレさまは えらいんだぞ！"], "§5"); return false; }
      await X.say(g.nm, ["ぐぬぬ……オレさまを だれだと 思ってる……！ おぼえてろ！"], "§5");
      for (const a of X.acts.filter((a) => !a.mon)) X.leave(a.e);
      await X.tell(["§7（氷に そっと ふれると、手の ぬくもりで 少しずつ とけて いく……）", "§7（モンスターは うれしそうに 鳴くと、氷の 奥に 眠って いた タマゴを 鼻で おして きた）"]);
      return X.gift(["§7（モンスターは 雪山へ 帰って いった）"]); } },
  ],
  9: [
    { k: "scene", at: "A", hint: "§f大きな 骨の 門の 下の 階段から 下りよう", run: async (X) => {
      await X.tell(["§e竜の 声§f「……人の 子よ。よく 来た」", "§e竜の 声§f「ここは 古い 竜の 骨の 中。骨の 迷い道を ぬけて、奥へ 来い」", "§e竜の 声§f「わが 魂の 試しを 受ける 気が あるならな」", "§7→ 骨の 迷路を ぬけて、いちばん 奥の 部屋へ 行こう"]);
      return true; } },
    { k: "reach", at: "end", r: 2, hint: "§f骨の 迷路を ぬけて、§e向こう側の 出口§f へ 行こう", msg: "§a迷路を ぬけた！" },
    { k: "scene", at: "C", hint: "§f竜の 骨の いちばん 奥の 部屋へ 行こう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "竜の 魂");
      await X.tell(["§e竜の 魂§f「見せて みよ。おまえと 仲間の 力を！」"]);
      const res = await X.duel(foe, "竜の 魂の 試し");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      return X.gift(["§e竜の 魂§f「……見事だ。わが 力の 一部を、おまえに あずけよう」"]); } },
  ],
  10: [
    { k: "scene", at: "I1", hint: "§f雲の 道を わたって、§e最初の 浮島§f へ 行こう", run: async (X) => {
      const g = G_("pette"); X.npc(`§5${ORG}の ${g.nm}`, g.sk, "foe");
      await X.say(g.nm, ["ガロさまなら こう 言う！『こんな 島、ひとっとびだ』って！", "……でも わたし、こわくて 動けないの！", "あんたも ここを 通る 気？ 通りたかったら、わたしに 勝って いきなさい！"], "§5");
      const res = await X.duel(gruntT("pette", X.lv), `${ORG}の ${g.nm}`, { half: g.kuchi, low: g.lose[0] });
      if (res !== "win") { await X.say(g.nm, ["ガロさま、見てて くれましたか〜！"], "§5"); return false; }
      await X.say(g.nm, ["ガロさま〜……ペッテ、空の 上で 負けました〜……", "……帰りの 雲の 道は こわく ないから 帰る！"], "§5");
      for (const a of [...X.acts]) X.leave(a.e);
      await X.tell(["§7→ 足場を 乗りついで、いちばん 奥の 大きな 浮島へ 行こう §8（落ちても 雲が 受けとめて くれる）"]);
      return true; } },
    { k: "scene", at: "I4", hint: "§f足場を 乗りついで、§eいちばん 奥の 浮島§f の 空の 主に 会おう", run: async (X) => {
      const foe = bossT(X.E, X.lv); X.mon(foe[0]?.sid, "foe", null, "空の 主");
      await X.tell(["§7（大きな 羽音と ともに、空の 主が 舞いおりた！）"]);
      const res = await X.duel(foe, "雲の 下の 空の 主");
      if (res !== "win") return false;
      for (const a of [...X.acts]) X.leave(a.e);
      return X.gift(["§7（空の 主は 高く 舞い上がり、島に 宝を のこして いった）"]); } },
  ],
};
export { STEPS };
/* 灯りを 持って いるか（手の たいまつ・ランタン、または 懐中電灯）*/
function lightIn(p) {
  try { const it = p.getComponent("minecraft:inventory")?.container?.getItem(p.selectedSlotIndex ?? 0); if (it && /torch|lantern|candle|glowstone|shroomlight|froglight|sea_lantern|campfire/.test(it.typeId)) return true; } catch {}
  try { return countItem(p, "mrpg:k_light") > 0; } catch { return false; }
}

/* ---------- 場面を 動かす ---------- */
const RUN = new Set(), LOCK = new Map(), HT = new Map();
function steady(p) {
  try { if (p.isOnGround === false || p.isSwimming || p.isFalling || p.isGliding || p.isSprinting) return false; } catch {}
  try { if (p.getComponent("minecraft:riding")?.entityRidingOn) return false; } catch {}
  try { const v = p.getVelocity?.(); if (v && Math.hypot(v.x, v.z) > 0.12) return false; } catch {}
  return true;
}
function free(p) { if (busy.has(p.id) || RUN.has(p.id)) return false; try { if (inBattle(p) || stageOf(p)) return false; } catch {} return true; }
export async function runScene(p, E, G, st) {
  const step = STEPS[E.r][st], lk = `${E.r}:${step.at}`, pt = G.pts[step.at];
  if (LOCK.has(lk) && LOCK.get(lk) !== p.id) { const now = Date.now(); if (now - (HT.get(p.id) || 0) > 6000) { HT.set(p.id, now); try { barNote(p).setActionBar("§7ほかの 人の 出来事が 終わるのを 少し 待とう"); } catch {} } return false; }
  RUN.add(p.id); LOCK.set(lk, p.id);
  const X = mkCtx(p, E, G); let done = false;
  try {
    await holdBusy(p, async () => {
      await stageBegin(p, { anchor: pt, move: true, R: 6, face: pt.face });
      try { done = await step.run(X); } finally { if (inScene(p) && ok(p)) { try { p.runCommand("camera @s fade time 0.3 0.3 0.5 color 0 0 0"); } catch {} await wait(7); } X.clear(); try { stageEnd(p, true); } catch {} }   /* 第124版(cam): 暗く して から 片づけ・カメラを もどす */
    });
  } catch (e) { console.warn(`[MonsterRPG] sev scene: ${e} ${e?.stack || ""}`); }
  finally { RUN.delete(p.id); if (LOCK.get(lk) === p.id) LOCK.delete(lk); }
  if (done === true && ok(p)) advance(p, E, st, null);
  return done;
}
const NEAR = new Map();   /* 地方 → 中心（400tick ごとに 計算）*/
let NT = -1;
function centers() { if (NT >= 0 && TK - NT < 40 && NEAR.size) return NEAR; NT = TK; NEAR.clear(); for (const E of EVS) { try { const L = siteOf(E); if (L) NEAR.set(E.r, { x: L.x, z: L.z }); } catch {} } return NEAR; }
function nearestEv(l) { let best = null, bd = 1e9; for (const [r, c] of centers()) { const d = Math.hypot(c.x - l.x, c.z - l.z); if (d < bd) { bd = d; best = r; } } return best === null ? null : { E: EV_OF(best), d: bd }; }
const FAST = new Map();   /* プレイヤー id → 出来事 */
let TK = 0;
function tickPlayer(p, E, G, inb, dc = 1e9) {
  const st = stOf(p, E.r), L = STEPS[E.r], now = Date.now();
  if (inb && G.fast) FAST.set(p.id, E.r); else FAST.delete(p.id);
  if (st >= L.length) { if (inb && now - (HT.get(p.id) || 0) > 30000) { HT.set(p.id, now); try { barNote(p).setActionBar(`§7「${E.nm}」は もう やりとげた`); } catch {} } return; }
  const step = L[st];
  if (RUN.has(p.id) || busy.has(p.id)) return;
  const topD = G.pts.top ? d2(p.location, G.pts.top) : 1e9;
  if ((inb || topD < 40 || dc < 30) && step.hint && now - (HT.get(p.id) || 0) > 15000) { HT.set(p.id, now); try { barNote(p).setActionBar(`§e！ §f${E.nm}: ${step.hint}`); } catch {} }
  if (step.k === "scene") { const pt = G.pts[step.at]; if (near(p, pt, step.r || 3.4) && steady(p) && free(p)) runScene(p, E, G, st).catch(() => {}); }
  else if (step.k === "reach") { if (inb && (step.ok ? step.ok(p, E, G) : near(p, G.pts[step.at], step.r || 2))) advance(p, E, st, step.msg); }
  else if (step.k === "puzzle") { if (inb && step.tick(p, E, G, wsOf(E))) advance(p, E, st, step.msg); }
}
/* ステージ（大地）が 作りなおされて 入口が うまったら、出来事の 建物も 作りなおす（2分に 1回だけ 見る）*/
const RCK = new Map();
function entranceOk(E, G) {
  if (E.ent === "sky") return true;
  const now = Date.now(); if (now - (RCK.get(E.r) || 0) < 120000) return true; RCK.set(E.r, now);
  const q = E.ent === "well" ? G.fr.W(0, -20, 0) : G.fr.W(0, -21, 0); let b; try { b = OW().getBlock(q); } catch { return true; } if (!b) return true;
  const id = b.typeId.replace("minecraft:", "");
  return E.ent === "well" ? id === "ladder" : E.ent === "sea" ? id === "water" || id === "flowing_water" : id === "air" || id === "sand";
}
function gateTick(E, G, plist) {
  const W = wsOf(E), now = Date.now();
  if (plist.length) W.last = now;
  for (const g of G.gates) {
    const cur = W.gate[g.id], want = plist.some((p) => stOf(p, E.r) > g.after) ? true : plist.length ? cur ?? false : false;
    if (want !== cur) { if (runCmds(want ? g.open : g.shut)) W.gate[g.id] = want; }
  }
  if (!plist.length && W.dirty && now - W.last > 60000) {   /* だれも いなく なって 1分: 仕掛けを もとに もどす */
    const c = CB(G.fr);
    if (E.ent === "tree") nestCmds(c, true);
    if (E.ent === "crystal") { W.mir = [...MIR0]; beamCmds(c, W.mir); }
    if (E.ent === "icecave") { for (const k of W.tiles.keys()) { const [a, b] = k.split(",").map(Number); c.set(a, b, U - 1, iceSafe(a, b) ? "packed_ice" : "ice"); } }
    if (runCmds(c.C)) { W.dirty = false; W.seq = []; W.solvers.clear(); W.tiles.clear(); }
  }
}
system.runInterval(() => {
  TK++;
  const ps = world.getAllPlayers(); if (!ps.length) return;
  const seen = new Map();
  for (const p of ps) {
    try {
      { const M = PM.get(p.id); if (M && M.ch) { const G0 = GEO.get(M.r); if (!G0 || p.dimension.id !== "minecraft:overworld" || !inBox(G0.box, p.location)) { rmE(M.ch); M.ch = null; } } }
      if (p.dimension.id !== "minecraft:overworld") { FAST.delete(p.id); continue; }
      const n = nearestEv(p.location); if (!n || !n.E || n.d > 120) { FAST.delete(p.id); continue; }
      const E = n.E, I = evInfo(E.r);
      if (!I || !I.built || I.v !== SEV_V) { if (n.d < 96 && !(I && !I.built && BLD.has(E.r))) tryBuild(E); continue; }
      const G = geoOf(E); if (!G) continue;
      if (n.d < 48 && !RUN.size && !entranceOk(E, G) && !world.getAllPlayers().some((q) => inBox(G.box, q.location))) { if (setInfo(E.r, { ...I, built: false })) { GEO.delete(E.r); WS.delete(E.r); } continue; }
      if (!seen.has(E.r)) seen.set(E.r, { L: [], dm: 1e9 });
      const sv = seen.get(E.r), inb = inBox(G.box, p.location); if (inb) sv.L.push(p); sv.dm = Math.min(sv.dm, n.d);
      tickPlayer(p, E, G, inb, n.d);
    } catch (e) { console.warn(`[MonsterRPG] sev tick: ${e}`); }
  }
  for (const [r, sv] of seen) { if (sv.dm > 72) continue; try { const E = EV_OF(r), G = geoOf(E); if (G) gateTick(E, G, sv.L); } catch {} }
}, 10);
/* 4tick: 氷の 床・浮島から 落ちた・ゴーグルなしで もぐった */
system.runInterval(() => {
  if (!FAST.size) return;
  for (const [pid, r] of FAST) {
    const p = world.getEntity?.(pid); if (!p || !ok(p)) { FAST.delete(pid); continue; }
    try {
      const E = EV_OF(r), G = geoOf(E); if (!G) continue;
      const q = G.fr.loc(p.location);
      if (E.ent === "icecave") {
        const W = wsOf(E), T = G.pts.tiles, k = `${q.a},${q.b}`;
        for (const [kk, t] of W.tiles) if (Date.now() - t > 3500) { const [a, b] = kk.split(",").map(Number); const c = CB(G.fr); c.set(a, b, U - 1, "ice"); if (runCmds(c.C)) W.tiles.delete(kk); }
        if (q.a < T.a1 || q.a > T.a2 || q.b < T.b1 || q.b > T.b2 || q.h < U - 3 || q.h > U + 1) continue;
        if (q.h >= U && !iceSafe(q.a, q.b) && !W.tiles.has(k)) { const c = CB(G.fr); c.set(q.a, q.b, U - 1, "air"); if (runCmds(c.C)) { W.tiles.set(k, Date.now()); W.dirty = true; sound(p, "random.glass", 1); } }
        if (q.h <= U - 2) { const back = G.fr.P(0, 10, U); try { p.teleport(back, { facingLocation: G.fr.P(0, 16, U + 1) }); barNote(p).setActionBar("§bザブン！ §fうすい 氷だった……§7白く くもった 氷の 上を 歩こう"); } catch {} sound(p, "random.splash", 1); }
      } else if (E.ent === "sea") {
        const inS = (Math.abs(q.a) <= 1 && q.b >= -22 && q.b <= -20 && q.h <= 0 && q.h >= U) || (q.h <= U + 7 && q.h >= U - 1 && q.b >= -20 && Math.abs(q.a) <= 7);
        if (inS && !hasKey(p, "k_goggle")) { try { p.teleport(G.pts.top, { facingLocation: G.fr.P(0, -21, 2) }); barNote(p).setActionBar("§3暗くて 息が つづかない……§7潜水ゴーグルが ないと もぐれない"); } catch {} }
      } else if (E.ent === "sky") {
        const M = PM.get(p.id) && PM.get(p.id).r === r ? PM.get(p.id) : pm(p, E);
        const cps = G.extra.cps; for (let i = cps.length - 1; i > (M.cp || 0); i--) if (near(p, cps[i], 6, 2)) { M.cp = i; break; }
        if (p.location.y >= G.fr.y + 12) M.up = Date.now();
        if (p.location.y < G.fr.y + 8 && Date.now() - (M.up || 0) < 4000) { M.up = 0; const c = cps[M.cp || 0]; try { p.teleport(c, { facingLocation: cps[Math.min(cps.length - 1, (M.cp || 0) + 1)] }); p.addEffect("slow_falling", 40, { showParticles: false }); barNote(p).setActionBar("§fふわっ……§b雲が 受けとめて くれた"); } catch {} }
      }
    } catch {}
  }
}, 4);
/* ボタン（墓の 順番・鏡の 向き）*/
function onButton(L, src) {
  for (const E of EVS) {
    if (E.ent !== "crypt" && E.ent !== "crystal") continue;
    const G = geoOf(E); if (!G || !G.extra.btn) continue;
    const i = G.extra.btn.findIndex((q) => q.x === L.x && q.y === L.y && q.z === L.z); if (i < 0) continue;
    const W = wsOf(E), Bx = G.box, here = world.getAllPlayers().filter((p) => inBox(Bx, p.location) && (() => { const q = G.fr.loc(p.location); return q.b >= 10 && q.b <= 22 && q.h >= U - 1 && q.h <= U + 5; })());
    const note = (t) => { for (const p of here) try { barNote(p).setActionBar(t); } catch {} };
    const credit = (p) => { if (stOf(p, E.r) === 1) W.solvers.add(p.id); };   /* その 仕掛けの 段に いる 人だけ（ほかの 人の 進みと まざらない）*/
    W.dirty = true;
    if (E.ent === "crypt") {
      W.seq.push(i);
      if (W.seq[W.seq.length - 1] !== GORDER[W.seq.length - 1]) { W.seq = []; note("§7ゴゴ……§fちがう ようだ。§7はじめから 祈りなおそう"); for (const p of here) sound(p, "random.door_close", 0.6); }
      else if (W.seq.length === GORDER.length) { W.seq = []; for (const p of here) { credit(p); sound(p, "random.levelup", 0.8); } note("§aゴゴゴゴ……！ §f奥の 扉が ひらく 音が した"); }
      else { note(`§f祈りを ささげた…… §7（${W.seq.length}/4）`); for (const p of here) sound(p, "note.pling", 1 + W.seq.length * 0.2); }
    } else {
      W.mir[i] = W.mir[i] ? 0 : 1; const c = CB(G.fr); const hit = beamCmds(c, W.mir); runCmds(c.C);
      for (const p of here) sound(p, "random.click", 1.3);
      if (hit) { for (const p of here) { credit(p); sound(p, "random.levelup", 1.2); } note("§a光が 扉の 前まで とどいた！"); }
    }
    return true;
  }
  return false;
}
try { world.afterEvents.buttonPush.subscribe((ev) => { try { onButton(ev.block.location, ev.source); } catch {} }); } catch {}
/* 地下・浮島の 中では 野生が わかない */
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => inEvent(p) || (prev ? prev(p) : false); });
export function inEvent(p) { try { for (const r of GEO.keys()) { const G = GEO.get(r); if (G && inBox(G.box, p.location) && (G.fast && EV_OF(r).ent === "sky" ? true : p.location.y < G.I.y - 1)) return true; } } catch {} return false; }
/* 片づけ（ぬけた・ワールドを 開いた とき）*/
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { FAST.delete(playerId); const M = PM.get(playerId); pmClean(M); PM.delete(playerId); RUN.delete(playerId); for (const [k, v] of LOCK) if (v === playerId) LOCK.delete(k); try { for (const e of OW().getEntities({ tags: ["mrpg_sev"] })) if (e.getDynamicProperty("mrpg:sevOwner") === playerId) rmE(e); } catch {} }); } catch {}
system.runTimeout(() => { try { for (const e of OW().getEntities({ tags: ["mrpg_sev"] })) rmE(e); } catch {} }, 100);
/* 第124版: 30秒ごとに 人の 近くだけ 見回り、場面の 終わった 人の 役者を 消す（抜けた とき 読みこまれて いなかった もの）*/
system.runInterval(() => { try { for (const q of world.getAllPlayers()) { if (q.dimension.id !== "minecraft:overworld") continue; for (const e of OW().getEntities({ tags: ["mrpg_sev"], location: q.location, maxDistance: 96 })) { let o; try { o = e.getDynamicProperty("mrpg:sevOwner"); } catch {} if (typeof o === "string" && (RUN.has(o) || PM.get(o)?.ch?.id === e.id)) continue; rmE(e); } } } catch {} }, 600);
export const __sev = { EVS, STEPS, geo, geoOf, evInfo, stOf, setSt, tryBuild, chooseDir, WS, wsOf, PM, RUN, LOCK, FAST, beam, mazeGrid, iceSafe, onButton, gateTick, runScene, giveRew, inBox, MIR0, ICE, GORDER, BLD, GEO };
