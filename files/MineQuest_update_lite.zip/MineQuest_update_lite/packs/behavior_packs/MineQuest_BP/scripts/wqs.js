/* 第125版: 世界の 依頼を 読みこむ（しくみは wq.js。地方ごとの 依頼は wq_r地方.js。新しい ファイルを 作ったら ここに 1行 足す）*/
import "./wq.js";
import "./wq_r0.js";
import "./wq_toma.js";   /* 第125版: 闘魔の 腕輪の 連作 */
import "./wq_r1.js"; import "./wq_r2.js"; import "./wq_r3.js";
import "./wq_r4.js"; import "./wq_r5.js"; import "./wq_r6.js"; import "./wq_r7.js";
import "./wq_r8.js"; import "./wq_r9.js"; import "./wq_r10.js";
