/* 第125版(fac): 物語の 場面に 出て くる 施設（水門・配給所・鉱山の 入口・運び道・祠・舟小屋・小屋・小川・天幕・見晴らし台・焚き火）
   ・ワールドに 1回だけ 建てる。場所は mrpg:epdeco:<key>at（見る 点 x,y,z ＋ 原点 o ＋ 向き f）に 記録し、あとの 場面・ほかの 人も ここを 見る
   ・場所: 舞台の 奥（前へ 7〜22 マス）の 平らで 乾いた 地面。町・城・大地の そば・水・宙には 建てない（見つからなければ 建てない）
   ・形は ローカル座標（a: 奥へ・b: 横・h: 高さ。h=0 は 立つ 高さ）の 箱の 並び。どの 形も 小さい（400 ブロック 前後まで）
   ・状態（水門を 半分 開けて 水を 少し 流す・全部 開ける）は 小さな fill で かえる（mrpg:epdeco:<key>st。下がらない）
     遠くて 読みこまれて いない ときは あとで（だれかが 48マス 以内に 来た とき）かえる */
import { world, system } from "@minecraft/server";
import { groundY, TOWNS, townPos, getTown, castleSpot } from "./structures.js";
import { WREGIONS, landSites } from "./worldmap.js";

const J = (k) => { try { return JSON.parse(world.getDynamicProperty(k) || "null"); } catch { return null; } };
const P_ = (k, v) => { try { world.setDynamicProperty(k, v === undefined ? undefined : JSON.stringify(v)); } catch {} };
/* 記録した 施設の 見る 点（near から R マス 以内の ときだけ）*/
export function facAt(key, near = null, R = 72) {
  const v = J(`mrpg:epdeco:${key}at`); if (!v || typeof v.x !== "number" || typeof v.z !== "number") return null;
  if (near && Number.isFinite(near.x) && Math.hypot(v.x - near.x, v.z - near.z) > R) return null;
  return { x: v.x, y: v.y, z: v.z };
}

/* 施設の 中の 点（網 など）*/
export function facMark(key, n, near = null) { const v = J(`mrpg:epdeco:${key}at`); const m = v && v.m && v.m[n]; if (!m) return null; if (near && Math.hypot(m[0] - near.x, m[2] - near.z) > 72) return null; return { x: m[0], y: m[1], z: m[2] }; }

/* ---------- 地方の 色 ---------- */
const PAL0 = { wall: "stone_bricks", trim: "cracked_stone_bricks", rock: "stone", base: "dirt", ground: "coarse_dirt", bed: "gravel", plank: "spruce_planks", log: "spruce_log", fence: "spruce_fence", slab: "spruce_slab", lamp: "lantern", plant: "short_grass", cloth: "white_wool", cloth2: "red_wool", ore: "raw_iron_block" };
const PAL = {
  village: { wall: "cobblestone", trim: "mossy_cobblestone", plank: "oak_planks", log: "oak_log", fence: "oak_fence", slab: "oak_slab", ground: "grass_block" },
  forest: { wall: "mossy_cobblestone", trim: "mossy_stone_bricks", plank: "oak_planks", log: "oak_log", fence: "oak_fence", slab: "oak_slab", ground: "grass_block", cloth2: "green_wool" },
  castle: { wall: "stone_bricks", trim: "cracked_stone_bricks", bed: "sand", plank: "dark_oak_planks", log: "dark_oak_log", fence: "dark_oak_fence", slab: "dark_oak_slab", plant: "deadbush" },
  volcano: { wall: "polished_blackstone_bricks", trim: "blackstone", rock: "blackstone", base: "basalt", ground: "blackstone", bed: "gravel", plank: "dark_oak_planks", log: "dark_oak_log", fence: "nether_brick_fence", slab: "dark_oak_slab", plant: "air", ore: "raw_iron_block" },
  desert: { wall: "sandstone", trim: "cut_sandstone", rock: "sandstone", base: "sandstone", ground: "sand", bed: "sand", plank: "birch_planks", log: "birch_log", fence: "birch_fence", slab: "birch_slab", plant: "deadbush", cloth2: "orange_wool" },
  crystal: { wall: "calcite", trim: "amethyst_block", rock: "calcite", base: "tuff", ground: "calcite", plank: "spruce_planks", log: "spruce_log", plant: "air", ore: "amethyst_block", lamp: "lantern" },
  port: { wall: "stone_bricks", trim: "prismarine_bricks", plank: "birch_planks", log: "spruce_log", fence: "spruce_fence", slab: "spruce_slab", lamp: "sea_lantern", cloth2: "blue_wool" },
  dark: { wall: "deepslate_bricks", trim: "polished_deepslate", rock: "deepslate", base: "soul_soil", ground: "soul_soil", plank: "dark_oak_planks", log: "dark_oak_log", fence: "dark_oak_fence", slab: "dark_oak_slab", lamp: "soul_lantern", plant: "air", cloth2: "purple_wool" },
  snow: { wall: "stone_bricks", trim: "mossy_stone_bricks", ground: "snow", plank: "spruce_planks", log: "spruce_log", fence: "spruce_fence", slab: "spruce_slab", plant: "air" },
  sky: { wall: "quartz_block", trim: "smooth_quartz", rock: "calcite", plank: "birch_planks", log: "birch_log", fence: "birch_fence", slab: "birch_slab", ground: "grass_block", plant: "air" },
  end: { wall: "end_stone_bricks", trim: "purpur_block", rock: "end_stone", base: "end_stone", ground: "end_stone", plank: "dark_oak_planks", log: "dark_oak_log", fence: "dark_oak_fence", slab: "dark_oak_slab", lamp: "end_rod", plant: "air" },
};
export function palOf(r) { const st = r === 9 ? "end" : (WREGIONS[r] && WREGIONS[r].style) || "village"; return { ...PAL0, ...(PAL[st] || {}), st }; }

/* ---------- 形（ops: ["f", a0,b0,h0, a1,b1,h1, ブロック, モード?] / ["e", a,b,h, エンティティ]）。RA/RB = 奥向き・横向きの レール ---------- */
const F = (a0, b0, h0, a1, b1, h1, bl, m) => ["f", a0, b0, h0, a1, b1, h1, bl, m];
const S1 = (a, b, h, bl) => ["f", a, b, h, a, b, h, bl];
const WCAUL = 'cauldron ["cauldron_liquid"="water","fill_level"=6]';
const HANG = (P) => (P.lamp === "lantern" || P.lamp === "soul_lantern" ? `${P.lamp} ["hanging"=true]` : P.lamp);
const SHAPES = {
  /* 涸れ谷の 水門: 石の 塔 2本・あいだに 木と 鉄の 門（下りて いる）・手前に 乾いた 水路（砂と 枯れ草）・門の 奥は 水 */
  sluice: { D: [19, 21, 17], box: [-9, -4, 7, 4], H: 6, look: [0, 0, 1], build: (P) => [
    F(-8, -2, -3, 6, 2, -1, P.trim), F(-8, -1, -2, 6, 1, -1, "air"), F(-8, -1, -3, 6, 1, -3, P.bed), F(-9, -2, -3, -9, 2, -1, P.trim), F(7, -2, -3, 7, 2, -1, P.trim),
    F(1, -1, -2, 6, 1, -1, "water"),
    F(-1, 2, -3, 0, 3, 5, P.wall), F(-1, -3, -3, 0, -2, 5, P.wall), F(-1, -3, 5, 0, 3, 5, P.wall),
    S1(-1, 3, 6, P.lamp), S1(-1, -3, 6, P.lamp), S1(0, 1, 4, "chain"), S1(0, -1, 4, "chain"), S1(0, 1, 3, "chain"), S1(0, -1, 3, "chain"),
    F(0, -1, -2, 0, 1, 1, P.plank), F(0, -1, 2, 0, 1, 2, "iron_bars"),
    S1(-6, 0, -2, P.plant), S1(-3, 1, -2, P.plant), S1(-7, -1, -2, P.plant),
    F(-8, 3, -1, -2, 3, -1, P.bed), F(-8, -3, -1, -2, -3, -1, P.bed), S1(-7, 3, 0, P.plant), S1(-4, -3, 0, P.plant), S1(-2, 4, 0, P.plant), S1(-6, -4, 0, P.plant),
  ], st: {
    1: (P) => [F(-8, -1, -2, -1, 1, -2, "air", "replace deadbush"), F(0, -1, -2, 0, 1, -1, "air"), F(0, -1, 2, 0, 1, 2, P.plank), F(0, -1, 3, 0, 0, 3, "iron_bars"), F(-3, -1, -2, -1, 1, -2, "water")],   /* 半分 開ける（門が 1段 上がり、手前に 水が 少し）*/
    2: (P) => [F(0, -1, -2, 0, 1, 0, "air"), F(0, -1, 1, 0, 1, 3, P.plank), F(-8, -1, -2, -1, 1, -2, "water")],   /* 全部 開ける（水路に 水）*/
  } },
  /* 水の 配給所: 屋根の ある 屋台・樽・水の 大がま・並ぶ ための 柵の 列 */
  stall: { D: [18, 20, 17], box: [-8, -5, 3, 5], H: 4, look: [0, 0, 1], build: (P) => [
    F(-1, -3, 0, -1, -3, 2, P.log), F(-1, 3, 0, -1, 3, 2, P.log), F(1, -3, 0, 1, -3, 2, P.log), F(1, 3, 0, 1, 3, 2, P.log),
    F(-2, -4, 3, 2, -3, 3, P.cloth), F(-2, -2, 3, 2, -1, 3, P.cloth2), F(-2, 0, 3, 2, 0, 3, P.cloth), F(-2, 1, 3, 2, 2, 3, P.cloth2), F(-2, 3, 3, 2, 4, 3, P.cloth),
    F(-1, -2, 0, -1, 2, 0, P.plank), S1(-1, 0, 0, WCAUL), S1(-1, -2, 1, WCAUL),
    F(1, -2, 0, 1, 2, 0, "barrel"), S1(1, -2, 1, "barrel"), S1(1, 2, 1, "barrel"), S1(0, 0, 2, HANG(P)),
    F(-7, -2, 0, -3, -2, 0, P.fence), F(-7, 2, 0, -3, 2, 0, P.fence), S1(-5, 3, 0, "cauldron"), S1(-6, -3, 0, "cauldron"),
  ] },
  /* 鉱山の 入口: 岩の 小山に 木の 枠・中へ つづく レール・トロッコ・灯り */
  mine: { D: [15, 17, 16], box: [-6, -4, 6, 4], H: 5, look: [0, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 3, P.rock), F(2, -2, 4, 4, 2, 4, P.rock), F(3, -3, 1, 4, -3, 2, P.trim), F(2, 3, 2, 3, 3, 3, P.trim), S1(4, 1, 4, P.ore),
    F(0, -1, 0, 4, 1, 2, "air"), F(0, -2, 0, 0, -2, 3, P.log), F(0, 2, 0, 0, 2, 3, P.log), F(0, -1, 3, 0, 1, 3, P.plank), F(2, -1, 3, 4, 1, 3, P.plank),
    F(-5, 0, 0, 4, 0, 0, "RA"), S1(1, 0, 2, HANG(P)), S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp),
    S1(-2, 2, 0, P.ore), S1(-3, 2, 0, "gravel"), S1(-2, -2, 0, "barrel"),
    ["e", -2, 0, 0, "chest_minecart"],
  ], st: { 1: (P) => [S1(-1, -3, 1, "shroomlight"), S1(-1, 3, 1, "shroomlight"), S1(0, -2, 4, "shroomlight"), S1(0, 2, 4, "shroomlight")] } },   /* こけの 光が もどる（入口が 光る）*/
  /* 鉄の 運び道: 砂利の 上の レール（横に 長い）・鉱石を 積んだ トロッコ・積み場の 鉱石 */
  haul: { D: [12, 14, 10], box: [-1, -11, 2, 11], H: 3, look: [0, 0, 1], build: (P) => [
    F(0, -10, -1, 0, 10, -1, "gravel"), F(0, -10, 0, 0, 10, 0, "RB"), S1(0, -11, 0, P.log), S1(0, 11, 0, P.log),
    S1(1, 10, 0, P.ore), S1(1, 9, 0, P.ore), S1(1, 10, 1, P.ore), S1(1, 8, 0, "coal_block"), S1(1, -6, 0, "barrel"), S1(1, -7, 0, P.ore),
    S1(-1, -9, 0, P.fence), S1(-1, -9, 1, P.lamp), S1(-1, 6, 0, P.fence), S1(-1, 6, 1, P.lamp),
    ["e", 0, -4, 0, "chest_minecart"], ["e", 0, 3, 0, "minecart"],
  ] },
  /* 雷神の 祠: 石の 台・木の 社（奥に 青白く 光る 雷石）・避雷針・鳥居・供え物・石の 灯籠 */
  shrine: { D: [14, 16, 12], box: [-3, -3, 4, 3], H: 6, look: [1, 0, 1.5], marks: { stone: [2, 0, 1.5] }, build: (P) => [
    F(-1, -2, 0, 3, 2, 0, P.wall), F(-2, -1, 0, -2, 1, 0, "stone_brick_slab"),
    F(1, -1, 1, 3, 1, 2, P.plank), F(1, 0, 1, 1, 0, 2, "air"), S1(2, 0, 1, "sea_lantern"),
    F(0, -2, 3, 4, 2, 3, P.slab), F(1, -1, 4, 3, 1, 4, P.slab), S1(2, 0, 5, "lightning_rod"),
    S1(0, -1, 1, "candle"), S1(0, 1, 1, "cake"),
    F(-3, -2, 0, -3, -2, 3, "red_nether_brick"), F(-3, 2, 0, -3, 2, 3, "red_nether_brick"), F(-3, -3, 4, -3, 3, 4, "red_nether_brick"),
    S1(0, -3, 0, "cobblestone_wall"), S1(0, -3, 1, P.lamp), S1(0, 3, 0, "cobblestone_wall"), S1(0, 3, 1, P.lamp),
  ] },
  /* 網元の 舟小屋: 板の 小屋・干した 網・舟・樽 */
  boathut: { D: [14, 16, 12], box: [-2, -7, 5, 4], H: 4, look: [1, 0, 1.5], marks: { net: [-1, -5.5, 1.5] }, build: (P) => [
    F(1, -3, 0, 1, -3, 2, P.log), F(1, 3, 0, 1, 3, 2, P.log), F(4, -3, 0, 4, -3, 2, P.log), F(4, 3, 0, 4, 3, 2, P.log),
    F(4, -2, 0, 4, 2, 2, P.plank), F(2, -3, 0, 3, -3, 2, P.plank), F(2, 3, 0, 3, 3, 2, P.plank), F(0, -4, 3, 5, 4, 3, P.slab),
    S1(3, -2, 0, "barrel"), S1(3, -1, 0, "barrel"), S1(3, 2, 0, "chest"), S1(1, 0, 2, HANG(P)),
    F(-1, -7, 0, -1, -7, 2, P.fence), F(-1, -4, 0, -1, -4, 2, P.fence), F(-1, -6, 1, -1, -5, 2, "web"),
    ["e", -1, 2, 0, "boat"],
  ] },
  /* 小屋（雲の 島）: 板の 壁・戸口・窓・屋根・灯り */
  cabin: { D: [13, 15, 11], box: [-1, -4, 5, 4], H: 4, look: [0, 0, 1.5], build: (P) => [
    F(0, -3, 0, 4, 3, 2, P.plank), F(1, -2, 0, 3, 2, 2, "air"), F(0, 0, 0, 0, 0, 1, "air"), S1(0, -2, 1, "glass_pane"), S1(0, 2, 1, "glass_pane"),
    F(0, -3, 0, 0, -3, 2, P.log), F(0, 3, 0, 0, 3, 2, P.log), F(4, -3, 0, 4, -3, 2, P.log), F(4, 3, 0, 4, 3, 2, P.log),
    F(-1, -4, 3, 5, 4, 3, P.slab), S1(2, 0, 2, HANG(P)), S1(-1, 1, 0, P.fence), S1(-1, 1, 1, P.lamp),
  ] },
  /* 小川: 横に 流れる 2マスの 水（両岸は 石）・小さな 板の 橋・すいれん */
  brook: { D: [11, 13, 9], box: [-2, -9, 3, 9], H: 2, look: [0.5, 0, 0.5], build: (P) => [
    F(-1, -9, -2, 2, 9, -1, P.trim), F(0, -8, -1, 1, 8, -1, "water"), F(0, -8, 0, 1, 8, 1, "air"),
    F(-1, 0, 0, 2, 0, 0, P.slab), S1(0, -5, 0, "waterlily"), S1(1, 4, 0, "waterlily"), S1(-1, -7, 0, P.trim), S1(2, 6, 0, P.trim),
  ] },
  /* 森の 天幕: 布の 三角の 天幕・寝床・焚き火 */
  tent: { D: [12, 14, 10], box: [-3, -3, 4, 4], H: 3, look: [1, 0, 1], build: (P) => [
    F(0, -2, 0, 3, -2, 0, P.cloth), F(0, 2, 0, 3, 2, 0, P.cloth), F(0, -1, 1, 3, -1, 1, P.cloth), F(0, 1, 1, 3, 1, 1, P.cloth), F(0, 0, 2, 3, 0, 2, P.cloth2),
    F(3, -1, 0, 3, 1, 0, P.cloth), F(1, 0, 0, 2, 0, 0, "white_carpet"), S1(-2, 3, 0, "campfire"), S1(-2, 2, 0, P.log),
  ] },
  /* 見晴らし台: 石の 台・手すり・灯り */
  lookout: { D: [13, 15, 11], box: [-1, -4, 5, 4], H: 3, look: [2, 0, 2.5], build: (P) => [
    F(1, -3, 0, 4, 3, 1, P.wall), F(0, -1, 0, 0, 1, 0, P.slab), F(4, -3, 2, 4, 3, 2, P.fence), F(1, -3, 2, 3, -3, 2, P.fence), F(1, 3, 2, 3, 3, 2, P.fence),
    S1(4, -3, 3, P.lamp), S1(4, 3, 3, P.lamp),
  ] },
  /* 葬列の 道の 墓穴（モンスターの 巣）: 掘りかえされた 穴・墓石・青い 灯り */
  gravenest: { D: [12, 13, 14], box: [-3, -5, 3, 5], H: 3, side: [3, -3, 6, -6], look: [0, 0, 0.5], marks: { hole: [0, 0, 0] }, build: (P) => [
    F(-1, -1, -3, 1, 1, -3, "soul_sand"), F(-1, -1, -2, 1, 1, -1, "air"), S1(-2, 0, 0, "coarse_dirt"), S1(2, 1, 0, "coarse_dirt"), S1(0, -2, 0, "coarse_dirt"),
    S1(-2, -4, 0, "cobblestone_wall"), S1(-2, -4, 1, "skull"), S1(2, -4, 0, "cobblestone_wall"), S1(2, 4, 0, "cobblestone_wall"), S1(2, 4, 1, "skull"), S1(-2, 4, 0, "cobblestone_wall"),
    S1(0, -5, 0, P.fence), S1(0, -5, 1, P.lamp), S1(0, 5, 0, P.fence), S1(0, 5, 1, P.lamp),
  ] },
  /* 雪崩の あと: 道を ふさぐ 雪の 山・折れた 木 */
  snowpile: { D: [13, 14, 12], box: [-3, -4, 3, 4], H: 3, side: [3, -3, 6, -6], look: [0, 0, 0.8], marks: { mound: [0, 0, 1] }, build: (P) => [
    F(-2, -3, 0, 2, 3, 0, "snow"), F(-1, -2, 1, 1, 2, 1, "snow"), S1(0, 0, 2, "snow_layer"), F(-3, -4, 0, 3, 4, 0, "snow_layer", "keep"),
    F(2, -4, 1, 2, -2, 1, "spruce_log"), S1(-3, 3, 1, "spruce_log"), S1(-2, 3, 2, "spruce_leaves"),
  ] },
  /* 第125版(pl): 刀鍛冶の 鍛冶場（前が 開いた 作業場。奥の 屋根だけ。炉・檻の 中の 溶岩・金床・砥石・焼き入れの 水・刀かけ・煙突）*/
  smithy: { D: [8, 9, 11, 13], near: 3.5, box: [-1, -5, 7, 5], H: 9, look: [3, 0, 1.4], marks: { anvil: [3, 0, 1], forge: [5, -2, 1] }, build: (P) => [
    F(0, -4, -1, 6, 4, -1, "stone_bricks"), F(6, -4, 0, 6, 4, 3, P.wall), F(1, -4, 0, 6, -4, 1, P.wall), F(1, 4, 0, 6, 4, 1, P.wall),
    F(0, -4, 0, 0, -4, 3, P.log), F(0, 4, 0, 0, 4, 3, P.log), F(3, -4, 0, 3, -4, 3, P.log), F(3, 4, 0, 3, 4, 3, P.log), F(3, -4, 4, 6, 4, 4, P.slab),
    S1(5, -3, 0, "blast_furnace"), S1(5, -1, 0, "blast_furnace"), S1(5, -2, 0, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'), S1(4, -2, 0, "iron_bars"), S1(5, -2, 1, "iron_bars"),
    F(5, -3, 2, 5, -1, 3, "brick_block"), F(5, -2, 4, 5, -2, 7, "brick_block"), S1(5, -2, 8, "campfire"),
    S1(3, 0, 0, "anvil"), S1(3, 2, 0, "grindstone"), S1(5, 2, 0, "smithing_table"), S1(2, -3, 0, WCAUL), S1(1, -3, 0, "barrel"),
    F(5, 3, 0, 5, 3, 2, "iron_bars"), S1(4, 3, 0, "barrel"), S1(5, 1, 1, "chain"), S1(5, 3, 3, "chain"),
    S1(2, -3, 3, HANG(P)), S1(2, 3, 3, HANG(P)), S1(0, -4, 4, P.lamp), S1(0, 4, 4, P.lamp), F(-1, -5, 0, -1, -5, 1, P.fence), F(-1, -5, 2, -1, -5, 2, "red_wool"),
  ], st: { 1: (P) => [F(3, -4, 4, 6, 0, 4, "air"), F(0, -4, -1, 6, 4, -1, "blackstone", "replace stone_bricks"), F(1, 4, 0, 2, 4, 1, "air"), S1(1, 2, 0, "coal_block"), S1(4, -4, 2, "air")] } },   /* 焼けた（屋根の 半分が 落ち・床が 黒こげ）*/
  /* 第125版(pl): 商家の 店先（縞の 日よけ・帳場・棚・看板・灯り）*/
  shopfront: { D: [8, 9, 11, 13], near: 3.5, box: [-2, -5, 6, 5], H: 6, look: [3, 0, 1.6], marks: { counter: [2, 0, 1] }, build: (P) => [
    F(0, -4, -1, 5, 4, -1, P.plank), F(5, -4, 0, 5, 4, 3, P.wall), F(1, -4, 0, 5, -4, 2, P.wall), F(1, 4, 0, 5, 4, 2, P.wall),
    F(4, -3, 0, 4, 3, 0, "barrel"), F(4, -3, 1, 4, 3, 1, "bookshelf"), S1(4, 0, 2, "chest"), F(2, -2, 0, 2, 2, 0, P.plank), S1(2, -1, 1, "flower_pot"), S1(2, 1, 1, "candle"), S1(2, 0, 1, "bell"),
    F(0, -4, 0, 0, -4, 3, P.log), F(0, 4, 0, 0, 4, 3, P.log), F(2, -4, 3, 5, 4, 3, P.slab),
    F(-1, -4, 3, 1, -3, 3, P.cloth2), F(-1, -2, 3, 1, -1, 3, P.cloth), F(-1, 0, 3, 1, 0, 3, P.cloth2), F(-1, 1, 3, 1, 2, 3, P.cloth), F(-1, 3, 3, 1, 4, 3, P.cloth2),
    F(1, -1, 4, 1, 1, 4, "yellow_wool"), S1(0, -3, 2, HANG(P)), S1(0, 3, 2, HANG(P)), S1(-1, -5, 0, "barrel"), S1(-1, 5, 0, "barrel"), S1(-1, 5, 1, "flower_pot"), S1(-2, -5, 0, "hay_block"),
  ] },
  /* 第125版(pl): 世界の 依頼の 場所（町の 外れの 地名に 合わせた 小さな 建物・目印）*/
  windmill: { D: [12, 14, 11], box: [-1, -4, 4, 4], H: 10, look: [1, 0, 4], build: (P) => [
    F(1, -1, 0, 3, 1, 5, P.wall), F(1, 0, 0, 1, 0, 1, "air"), F(1, -1, 6, 3, 1, 6, P.slab), S1(0, 0, 4, P.log),
    F(0, 0, 5, 0, 0, 8, P.cloth), F(0, 0, 1, 0, 0, 3, P.cloth), F(0, 1, 4, 0, 3, 4, P.cloth), F(0, -3, 4, 0, -1, 4, P.cloth), S1(-1, -3, 0, "hay_block"), S1(-1, 3, 0, "barrel"), S1(1, 0, 2, HANG(P)),
  ] },
  hut: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 5, look: [1, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.plank), F(2, -2, 0, 4, 2, 2, "air"), F(1, -1, 0, 1, 1, 1, "air"), S1(1, -2, 1, "glass_pane"), F(1, -3, 3, 3, 3, 3, P.slab), S1(4, 3, 2, "air"), S1(5, 2, 2, "air"),
    S1(4, -2, 0, "bookshelf"), S1(4, 2, 0, "barrel"), S1(3, 2, 0, "crafting_table"), S1(4, 0, 2, "web"), S1(2, 0, 2, HANG(P)), S1(0, 2, 0, P.fence), S1(0, 2, 1, P.lamp),
  ] },
  library: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 5, look: [2, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.wall), F(2, -2, 0, 4, 2, 2, "air"), F(1, -1, 0, 1, 1, 1, "air"), F(1, -3, 3, 5, 3, 3, P.slab), F(3, -3, 3, 5, -1, 3, "air"),
    F(4, -2, 0, 4, 2, 1, "bookshelf"), F(2, -2, 0, 3, -2, 1, "bookshelf"), S1(3, 1, 0, "lectern"), S1(2, 2, 0, "web"), S1(2, 0, 2, HANG(P)), S1(0, -2, 0, P.fence), S1(0, -2, 1, P.lamp),
  ] },
  bellows: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 6, look: [2, 0, 1.2], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.plank), F(2, -2, 0, 4, 2, 2, "air"), F(1, -2, 0, 1, 2, 2, "air"), F(1, -3, 3, 5, 3, 3, P.slab), S1(2, 3, 3, "air"),
    S1(4, -1, 0, "blast_furnace"), S1(4, 0, 0, "furnace"), S1(4, 1, 0, "smoker"), F(5, 0, 3, 5, 0, 5, "brick_block"), S1(3, 2, 0, "anvil"), S1(3, -2, 0, "barrel"), S1(2, 0, 2, HANG(P)),
  ] },
  cabin2: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 7, look: [1, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.log), F(2, -2, 0, 4, 2, 2, "air"), F(1, 0, 0, 1, 0, 1, "air"), S1(1, -2, 1, "glass_pane"), S1(1, 2, 1, "glass_pane"),
    F(0, -4, 3, 6, 4, 3, P.slab), F(1, -3, 4, 5, 3, 4, P.slab), S1(3, 0, 5, P.log), S1(3, 0, 6, "bell"), S1(4, 2, 0, "campfire"), S1(4, -2, 0, "barrel"), S1(0, -2, 0, P.fence), S1(0, -2, 1, P.lamp),
  ] },
  pond: { D: [11, 13, 10], box: [-1, -5, 5, 5], H: 2, look: [2, 0, 0.3], build: (P) => [
    F(0, -4, -2, 4, 4, -1, P.trim), F(1, -3, -1, 3, 3, -1, "water"), F(1, -3, 0, 3, 3, 1, "air"), S1(2, -2, 0, "waterlily"), S1(1, 2, 0, "waterlily"), S1(3, 1, -2, "sea_lantern"),
    S1(-1, -4, 0, "allium"), S1(-1, 4, 0, "blue_orchid"), S1(5, 0, 0, "oxeye_daisy"), S1(-1, 0, 0, P.fence), S1(-1, 0, 1, P.lamp),
  ] },
  hokora: { D: [11, 13, 10], box: [-3, -3, 3, 3], H: 5, look: [1, 0, 1.2], build: (P) => [
    F(0, -1, 0, 2, 1, 0, P.wall), F(1, -1, 1, 2, 1, 2, P.plank), F(1, 0, 1, 1, 0, 1, "air"), S1(2, 0, 1, P.lamp), F(0, -2, 3, 3, 2, 3, P.slab),
    S1(-1, -1, 0, "candle"), S1(-1, 1, 0, "flower_pot"), F(-3, -2, 0, -3, -2, 2, "red_nether_brick"), F(-3, 2, 0, -3, 2, 2, "red_nether_brick"), F(-3, -3, 3, -3, 3, 3, "red_nether_brick"),
  ] },
  altar: { D: [11, 13, 10], box: [-1, -4, 6, 4], H: 5, look: [3, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 0, P.wall), F(2, -2, 1, 4, 2, 1, P.trim), S1(3, 0, 2, "chiseled_stone_bricks"), S1(3, 0, 3, P.lamp), F(0, -1, 0, 0, 1, 0, "stone_brick_slab"),
    F(1, -3, 1, 1, -3, 3, P.wall), F(1, 3, 1, 1, 3, 3, P.wall), F(5, -3, 1, 5, -3, 3, P.wall), F(5, 3, 1, 5, 3, 3, P.wall), S1(2, -2, 2, "candle"), S1(4, 2, 2, "candle"),
  ] },
  graves: { D: [11, 13, 10], box: [-1, -5, 6, 5], H: 3, look: [2, 0, 0.8], build: (P) => [
    F(-1, -5, 0, 6, -5, 0, P.fence), F(-1, 5, 0, 6, 5, 0, P.fence), F(6, -5, 0, 6, 5, 0, P.fence), S1(-1, -5, 1, P.lamp), S1(-1, 5, 1, P.lamp),
    S1(2, -3, 0, "cobblestone_wall"), S1(2, 0, 0, "cobblestone_wall"), S1(2, 3, 0, "cobblestone_wall"), S1(4, -3, 0, "cobblestone_wall"), S1(4, 0, 0, "mossy_cobblestone_wall"), S1(4, 3, 0, "cobblestone_wall"), S1(4, 0, 1, "skull"),
    F(1, -3, -1, 1, 3, -1, "coarse_dirt"), F(3, -3, -1, 3, 3, -1, "coarse_dirt"), S1(1, 2, 0, "flower_pot"),
  ] },
  cave: { D: [13, 15, 12], box: [-2, -4, 6, 4], H: 6, look: [0, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 3, P.rock), F(2, -2, 4, 4, 2, 4, P.rock), F(0, -1, 0, 5, 1, 2, "air"), F(5, -1, -1, 5, 1, -1, "black_concrete"), S1(4, 2, 4, P.ore), S1(2, -3, 3, P.trim),
    S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp), S1(-2, 2, 0, "gravel"), S1(-1, -2, 0, "cobblestone"),
  ] },
  tower: { D: [12, 14, 11], box: [-1, -3, 4, 3], H: 8, look: [2, 0, 3], build: (P) => [
    F(1, -2, 0, 1, -2, 4, P.log), F(1, 2, 0, 1, 2, 4, P.log), F(4, -2, 0, 4, -2, 4, P.log), F(4, 2, 0, 4, 2, 4, P.log), F(1, -2, 5, 4, 2, 5, P.plank),
    F(1, -2, 6, 4, -2, 6, P.fence), F(1, 2, 6, 4, 2, 6, P.fence), F(4, -1, 6, 4, 1, 6, P.fence), S1(1, -2, 7, P.lamp), S1(4, 2, 7, P.lamp), F(0, 0, 0, 0, 0, 4, "ladder"), S1(3, 0, 6, "lightning_rod"),
  ] },
  lighthouse: { D: [13, 15, 12], box: [-1, -3, 4, 3], H: 12, look: [2, 0, 4], build: (P) => [
    F(1, -1, 0, 3, 1, 2, "white_concrete"), F(1, -1, 3, 3, 1, 4, "red_concrete"), F(1, -1, 5, 3, 1, 6, "white_concrete"), F(1, -1, 7, 3, 1, 7, "red_concrete"),
    F(1, -1, 8, 3, 1, 8, "glass"), S1(2, 0, 8, "sea_lantern"), F(1, -1, 9, 3, 1, 9, "dark_oak_slab"), F(1, 0, 0, 1, 0, 1, "air"), S1(0, -2, 0, "barrel"), S1(0, 2, 0, P.fence), S1(0, 2, 1, P.lamp),
  ] },
  well: { D: [11, 13, 10], box: [-2, -3, 3, 3], H: 5, look: [1, 0, 1], build: (P) => [
    F(0, -1, 0, 2, 1, 0, P.wall), S1(1, 0, 0, "water"), F(0, -1, 1, 0, -1, 2, P.fence), F(2, 1, 1, 2, 1, 2, P.fence), F(0, -1, 3, 2, 1, 3, P.slab), S1(1, 0, 2, "chain"), S1(-1, 2, 0, "cauldron"), S1(-1, -2, 0, P.lamp),
  ] },
  field: { D: [11, 13, 10], box: [-1, -5, 6, 5], H: 3, look: [2, 0, 0.8], build: (P) => [
    F(0, -4, -1, 5, 4, -1, "farmland"), F(0, -4, 0, 5, 4, 0, "wheat"), F(0, 0, -1, 5, 0, -1, "water"), S1(0, 0, 0, "air"), F(1, 0, 0, 5, 0, 0, "air"),
    F(-1, -5, 0, 6, -5, 0, P.fence), F(6, -5, 0, 6, 5, 0, P.fence), S1(3, 3, 1, "hay_block"), S1(3, 3, 2, "carved_pumpkin"), S1(-1, 4, 0, "hay_block"), S1(-1, 3, 0, "hay_block"),
  ] },
  roses: { D: [11, 13, 10], box: [-1, -5, 6, 5], H: 3, look: [2, 0, 0.8], build: (P) => [
    F(0, -4, -1, 5, 4, -1, "coarse_dirt"), F(0, -4, -1, 5, 4, -1, "podzol", "replace coarse_dirt"), F(0, -4, 0, 5, -3, 0, "poppy"), F(0, -1, 0, 5, 1, 0, "red_tulip"), F(0, 3, 0, 5, 4, 0, "poppy"),
    F(-1, -5, 0, 6, -5, 0, P.fence), F(6, -5, 0, 6, 5, 0, P.fence), S1(-1, 5, 0, "barrel"), S1(-1, 0, 0, P.fence), S1(-1, 0, 1, P.lamp), S1(2, 2, 0, "cauldron"),
  ] },
  arena: { D: [12, 14, 11], box: [-1, -5, 8, 5], H: 5, look: [3, 0, 1], build: (P) => [
    F(0, -4, -1, 7, 4, -1, P.wall), F(1, -3, -1, 6, 3, -1, P.trim), F(0, -4, 0, 0, -4, 2, P.wall), F(0, 4, 0, 0, 4, 2, P.wall), F(7, -4, 0, 7, -4, 2, P.wall), F(7, 4, 0, 7, 4, 2, P.wall),
    S1(0, -4, 3, P.lamp), S1(0, 4, 3, P.lamp), S1(7, -4, 3, P.lamp), S1(7, 4, 3, P.lamp), S1(3, 0, -1, "chiseled_stone_bricks"),
  ] },
  burnt: { D: [12, 14, 11], box: [-1, -5, 6, 5], H: 4, look: [2, 0, 1], build: (P) => [
    F(1, -4, -1, 5, 4, -1, "coarse_dirt"), F(1, -4, 0, 1, -4, 2, "blackstone"), F(5, -4, 0, 5, -1, 1, "blackstone"), F(5, 2, 0, 5, 4, 2, "dark_oak_log"), S1(1, 3, 0, "dark_oak_log"),
    S1(3, -2, 0, "coal_block"), S1(3, 1, 0, "campfire"), S1(4, 3, 0, "coal_block"), S1(2, 0, 0, "dark_oak_slab"), S1(-1, -5, 0, P.fence), S1(-1, -5, 1, P.lamp),
  ] },
  channel: { D: [11, 13, 10], box: [-1, -4, 6, 4], H: 3, look: [2, 0, 0.5], build: (P) => [
    F(0, -2, -2, 5, 2, -1, P.wall), F(0, -1, -1, 5, 1, -1, "water"), F(0, -1, 0, 5, 1, 1, "air"), F(5, -2, 0, 5, 2, 1, P.wall), F(5, -1, 0, 5, 1, 0, "iron_bars"),
    S1(0, -3, 0, P.fence), S1(0, -3, 1, P.lamp), S1(0, 3, 0, P.fence), S1(0, 3, 1, P.lamp), S1(-1, 2, 0, "barrel"),
  ] },
  /* 第125版(pl): 坑道の 奥の こけの 庭（岩の 洞・光る こけ・水晶・小さな 泉）。コロが 守る 場所 */
  mossgrotto: { D: [9, 10, 12], box: [-1, -5, 6, 5], H: 6, look: [3, 0, 1], marks: { moss: [3, 0, 0.2] }, build: (P) => [
    F(1, -4, 0, 6, 4, 4, P.rock), F(1, -3, 0, 5, 3, 3, "air"), F(0, -2, 0, 0, 2, 2, "air"), F(1, -3, -1, 5, 3, -1, "moss_block"), F(2, -2, 0, 4, 2, 0, "moss_carpet"),
    S1(5, 0, -1, "water"), S1(5, 0, 0, "air"), S1(5, -2, 1, "shroomlight"), S1(5, 2, 1, "shroomlight"), S1(3, -3, 2, "glow_lichen"), S1(3, 3, 2, "glow_lichen"), S1(4, 0, 3, "glow_lichen"),
    S1(2, -3, 0, "amethyst_cluster"), S1(4, 3, 0, "amethyst_cluster"), S1(1, 3, 1, P.ore), S1(3, 0, 4, "shroomlight"), S1(-1, -3, 0, "rail"), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp),
  ] },
  /* 第125版(pl): 洞くつの 入口の 運び出し場（水晶の 箱・トロッコ・天幕・灯り）*/
  cryscamp: { D: [10, 12, 9], box: [-2, -5, 3, 5], H: 4, look: [0, 0, 1], build: (P) => [
    F(0, -4, 0, 0, -3, 0, "barrel"), S1(0, -4, 1, "barrel"), F(1, 2, 0, 1, 4, 0, P.ore), S1(1, 3, 1, P.ore), S1(0, 3, 0, "amethyst_cluster"), F(-1, -1, -1, -1, 1, -1, P.bed),
    F(2, -2, 0, 2, -2, 2, P.log), F(2, 2, 0, 2, 2, 2, P.log), F(2, -2, 3, 2, 2, 3, P.cloth2), S1(-2, -5, 0, P.fence), S1(-2, -5, 1, P.lamp), S1(-2, 5, 0, P.fence), S1(-2, 5, 1, P.lamp),
    ["e", 0, 0, 0, "chest_minecart"],
  ] },
  /* 道しるべ（旅の 場所: 街道・林・岩場・浜・雪原 など）: 道の 札・灯りの 柱・腰かけ・荷 */
  waypost: { D: [10, 12, 9], box: [-2, -5, 2, 5], H: 3, look: [0, 0, 1.3], build: (P) => [
    F(-1, -5, -1, -1, 5, -1, P.bed), F(0, 0, 0, 0, 0, 1, P.fence), F(0, -1, 2, 0, 1, 2, P.plank), S1(0, -4, 0, P.fence), S1(0, -4, 1, P.lamp), S1(0, 4, 0, P.fence), S1(0, 4, 1, P.lamp),
    S1(1, 2, 0, "barrel"), S1(1, 3, 0, "hay_block"), S1(-2, -2, 0, P.log), S1(-2, -3, 0, P.log), S1(1, -3, 0, "campfire"),
  ] },
  beachcamp: { D: [10, 12, 9], box: [-2, -5, 3, 5], H: 3, look: [0, 0, 1], build: (P) => [
    F(0, -4, 0, 0, -4, 2, P.fence), F(0, -1, 0, 0, -1, 2, P.fence), F(0, -3, 1, 0, -2, 2, "web"), S1(1, 2, 0, "barrel"), S1(1, 3, 0, "barrel"), S1(-1, 0, 0, "campfire"), S1(2, -3, 0, P.fence), S1(2, -3, 1, P.lamp),
    ["e", 1, 0, 0, "boat"],
  ] },
  deadwood: { D: [10, 12, 9], box: [-2, -5, 3, 5], H: 5, look: [0, 0, 1.2], build: (P) => [
    F(1, -3, 0, 1, -3, 3, "stripped_dark_oak_log"), F(2, 3, 0, 2, 3, 4, "stripped_dark_oak_log"), S1(2, 2, 3, "dark_oak_fence"), S1(1, -2, 2, "dark_oak_fence"), F(-1, 1, 0, -1, 3, 0, "dark_oak_log"),
    S1(0, -1, 0, "brown_mushroom"), S1(1, 1, 0, "red_mushroom"), S1(2, -4, 0, "web"), F(-2, -5, -1, 3, 5, -1, "podzol", "replace grass_block"), S1(0, 4, 0, P.fence), S1(0, 4, 1, "soul_lantern"),
  ] },
  /* 第125版(rs): 墓守の 丘（赤い 灯籠の 墓地・墓守の 番小屋の 牢。st1 = 牢の 戸を 開ける）*/
  redyard: { D: [11, 12, 14], box: [-1, -6, 8, 6], H: 5, look: [3, 0, 1], marks: { cell: [5.5, 4, 0], door: [3, 4, 0], yu: [1.6, 2.4, 0], aisle: [0.5, -3, 0], front: [-2, 4, 0], grave: [4, -3, 0], lamp: [-1, -6, 2] }, build: (P) => [
    F(1, -5, -1, 5, -1, -1, "podzol"), F(0, -1, -1, 8, 1, -1, "coarse_dirt"),
    S1(2, -5, 0, "cobblestone_wall"), S1(2, -5, 1, "skull"), S1(4, -5, 0, "cobblestone_wall"), S1(4, -3, 0, "cobblestone_wall"), S1(4, -3, 1, "skull"), S1(4, -1, 0, "mossy_cobblestone_wall"), S1(6, -4, 0, "cobblestone_wall"), S1(6, -2, 0, "cobblestone_wall"),
    S1(4, -2, 0, 'red_candle ["candles"=2,"lit"=true]'), S1(5, -4, 0, 'red_candle ["candles"=1,"lit"=true]'), S1(3, -4, 0, "poppy"),
    F(3, 2, 0, 7, 6, 3, P.wall), F(4, 3, 0, 6, 5, 2, "air"), F(3, 3, 0, 3, 5, 2, "iron_bars"), S1(3, 4, 0, "dark_oak_fence_gate"), S1(3, 4, 1, "air"), F(2, 1, 4, 8, 7, 4, P.slab),
    S1(6, 5, 0, "hay_block"), S1(5, 3, 2, "chain"), S1(5, 4, 2, `${P.lamp} ["hanging"=true]`), S1(8, 3, 0, "barrel"), S1(2, 6, 0, P.fence), S1(2, 6, 1, P.lamp),
    F(-1, -6, 0, -1, -6, 1, "nether_brick_fence"), S1(-1, -6, 2, 'red_candle ["candles"=3,"lit"=true]'), F(-1, 6, 0, -1, 6, 1, "nether_brick_fence"), S1(-1, 6, 2, 'red_candle ["candles"=3,"lit"=true]'),
    F(7, -6, 0, 7, -6, 1, "nether_brick_fence"), S1(7, -6, 2, 'red_candle ["candles"=3,"lit"=true]'), F(8, 0, 0, 8, 0, 1, "nether_brick_fence"), S1(8, 0, 2, 'red_candle ["candles"=3,"lit"=true]'),
  ], st: { 1: (P) => [S1(3, 4, 0, "air")] } },
  /* 第125版(rs): 霊廟（暗い 聖堂の 正面・とがった 戸口・紫の 窓・中に 帳の 写しの 書見台と 石の 棺・赤い 灯籠の 柱）*/
  crypt: { D: [12, 14, 11], box: [-1, -5, 7, 5], H: 9, look: [1, 0, 2.5], marks: { book: [5, 0, 1.2], floor: [4, 0, 0], door: [1, 0, 0], front: [-1.5, 0, 0] }, build: (P) => [
    F(0, -2, -1, 6, 2, -1, "polished_deepslate"), F(0, -2, 0, 0, 2, 0, "deepslate_brick_slab"),
    F(1, -4, 0, 6, 4, 6, P.wall), F(2, -3, 0, 5, 3, 5, "air"), F(1, -1, 0, 1, 1, 3, "air"), S1(1, 0, 4, "air"), S1(1, 0, 5, "purple_stained_glass"), S1(6, 0, 3, "purple_stained_glass"),
    F(1, -4, 7, 6, 4, 7, P.trim), S1(1, 0, 8, "deepslate_brick_wall"), S1(1, 0, 9, P.lamp),
    F(0, -3, 0, 0, -3, 5, P.trim), F(0, 3, 0, 0, 3, 5, P.trim), S1(0, -3, 6, P.lamp), S1(0, 3, 6, P.lamp),
    S1(5, 0, 0, "lectern"), S1(5, -1, 0, 'candle ["candles"=3,"lit"=true]'), S1(5, 1, 0, 'candle ["candles"=3,"lit"=true]'), F(3, -3, 0, 4, -3, 0, "polished_deepslate_slab"), F(3, 3, 0, 4, 3, 0, "polished_deepslate_slab"), S1(4, 0, 5, `${P.lamp} ["hanging"=true]`),
    F(-1, -5, 0, -1, -5, 1, "nether_brick_fence"), S1(-1, -5, 2, 'red_candle ["candles"=3,"lit"=true]'), F(-1, 5, 0, -1, 5, 1, "nether_brick_fence"), S1(-1, 5, 2, 'red_candle ["candles"=3,"lit"=true]'),
  ] },
  /* 第125版(rs): 六影の 卓の 間（「そのころ」の 切りかえ用。手前が 開いた 暗い 部屋・六つの 席の 卓・空いた「二の座」の 紫の 席・雪あかりの 窓）*/
  sixroom: { D: [12, 14, 11], box: [-1, -5, 9, 5], H: 6, look: [4, 0, 1.2], marks: { table: [4, 0, 1.1], seat2: [4, 3, 0], snow: [6, -3.5, 0], mask: [7, 3, 0], rep: [2, -1, 0] }, build: (P) => [
    F(0, -5, -1, 8, 5, -1, "polished_blackstone_bricks"), F(1, -5, 0, 8, -5, 4, "polished_blackstone_bricks"), F(1, 5, 0, 8, 5, 4, "polished_blackstone_bricks"), F(8, -5, 0, 8, 5, 4, "polished_blackstone_bricks"), F(0, -5, 5, 8, 5, 5, "blackstone"),
    F(3, -1, 0, 5, 1, 0, "dark_oak_fence"), F(3, -1, 1, 5, 1, 1, "dark_oak_slab"), S1(4, 0, 2, 'candle ["candles"=1,"lit"=true]'),
    S1(2, -2, 0, "polished_blackstone_stairs"), S1(2, 2, 0, "polished_blackstone_stairs"), S1(6, -2, 0, "polished_blackstone_stairs"), S1(6, 2, 0, "polished_blackstone_stairs"), S1(4, -3, 0, "polished_blackstone_stairs"), S1(4, 3, 0, "purple_wool"),
    F(8, -4, 1, 8, -3, 2, "white_stained_glass"), F(9, -4, 1, 9, -3, 2, "sea_lantern"), S1(4, 0, 4, `${P.lamp} ["hanging"=true]`), S1(1, -4, 0, P.fence), S1(1, -4, 1, P.lamp), S1(1, 4, 0, P.fence), S1(1, 4, 1, P.lamp),
  ] },
  /* 第125版(ce): 風の 塔（根もとの 星見の 間: 前が 開いた 戸口・星図の 机・窓・吊りランプ。上に 塔の 柱・鐘・灯り）。遠めがねは ep_r10 が 海の 方角の 窓ぎわに 置く */
  windroom: { D: [10, 12, 14], box: [0, -4, 8, 4], H: 16, side: [6, -6, 10, -10], look: [3, 0, 1.6], marks: { desk: [5, -1, 0], chart: [6, -1, 1.1], in: [3, 1, 0], side: [3, -1, 0], door: [1, 0, 0], front: [-1.5, 0, 0], bell: [4, 0, 15] }, build: (P) => [
    F(1, -3, 0, 7, 3, 6, "stone_bricks"), F(2, -2, 0, 6, 2, 5, "air"), F(1, -2, 0, 1, 2, 3, "air"), F(2, -2, -1, 6, 2, -1, "spruce_planks"), F(0, -4, 7, 8, 4, 7, "spruce_slab"),
    F(4, -3, 1, 4, -3, 2, "glass_pane"), F(4, 3, 1, 4, 3, 2, "glass_pane"), F(7, 0, 1, 7, 0, 2, "glass_pane"), S1(1, 0, 5, "glass_pane"),
    S1(6, -1, 0, "cartography_table"), S1(6, -2, 0, "bookshelf"), S1(6, -2, 1, "bookshelf"), S1(6, 2, 0, "barrel"), S1(4, 0, 5, "chain"), S1(4, 0, 4, HANG(P)),
    F(3, -1, 8, 5, 1, 13, "stone_bricks"), F(3, -1, 14, 5, 1, 14, "spruce_slab"), S1(4, 0, 15, "bell"), S1(3, -1, 15, "lantern"), S1(5, 1, 15, "lantern"),
    F(0, -3, 0, 0, -3, 2, "birch_fence"), S1(0, -3, 3, "white_wool"), F(0, 3, 0, 0, 3, 2, "birch_fence"), S1(0, 3, 3, "white_wool"),
  ] },
  /* 第125版(ce): 雲の 島の 端（竜の 石像の 台座・崩れかけた 端の 手すり・風の 旗・石の 腰かけ・向こうに 雲）*/
  cloudedge: { D: [8, 10, 12], box: [-1, -6, 7, 6], H: 4, look: [3, 0, 1.2], marks: { dragon: [3, -3, 0.5], ray: [3, -1, 0], rail: [5, 0, 0], bench: [1, 4, 0] }, build: (P) => [
    F(0, -5, -1, 5, 5, -1, "quartz_bricks"), F(2, -4, 0, 4, -2, 0, "smooth_quartz_slab"), S1(4, -5, 0, "chiseled_quartz_block"), S1(4, -5, 1, "lantern"),
    F(6, -5, 0, 6, 5, 0, "birch_fence"), F(6, -1, 0, 6, 0, 0, "air"), S1(6, 3, 0, "cobblestone_wall"),
    F(6, -6, 0, 6, -6, 2, "birch_fence"), S1(6, -6, 3, "white_wool"), F(6, 6, 0, 6, 6, 2, "birch_fence"), S1(6, 6, 3, "white_wool"),
    F(1, 4, 0, 1, 5, 0, "birch_slab"), F(8, -5, -1, 10, 5, -1, "white_wool", "keep"), F(9, -3, 0, 10, 2, 0, "white_wool", "keep"),
  ] },
  /* 第125版(ce): ステラの 古い 星見台（白い 石の 部屋・ガラスの 屋根・星図の 机・空を 向く 筒）*/
  observatory: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 6, look: [3, 0, 1.6], marks: { chart: [3, 0, 1.1] }, build: (P) => [
    F(1, -3, 0, 5, 3, 3, "quartz_block"), F(2, -2, 0, 4, 2, 3, "air"), F(1, -1, 0, 1, 1, 2, "air"), F(1, -3, 4, 5, 3, 4, "glass"), F(2, -2, 5, 4, 2, 5, "glass"),
    S1(3, 0, 0, "cartography_table"), S1(4, 2, 0, P.fence), S1(4, 2, 1, "lightning_rod"), S1(4, -2, 0, "bookshelf"), S1(3, 0, 3, HANG(P)), S1(0, -3, 0, P.fence), S1(0, -3, 1, P.lamp),
  ] },
  /* 浜の 焚き火: 焚き火と 腰かけの 丸太 */
  fire: { D: [10, 11, 9], box: [-2, -2, 2, 2], H: 2, small: 1, side: [6, -6, 7, -7], look: [0, 0, 0.5], build: (P) => [
    S1(0, 0, 0, "campfire"), S1(-2, 0, 0, P.log), S1(2, 0, 0, P.log), S1(0, 2, 0, P.log), S1(0, -2, 0, "cobblestone"),
  ] },
  /* 第125版(tp): 文に 出る 地形（場面の 文と 場所を 合わせる）。marks は 人が 立つ・カメラが 映す 点 */
  /* 雪庇: 足もとの 先が 4マス 下へ 落ちる 雪の 崖。st1 = 張り出した 雪が 崩れ落ちる */
  cornice: { D: [6, 7, 9], near: 3, gap: 8, box: [-1, -4, 9, 4], H: 3, side: [8, -8, 11, -11], look: [5, 0, 0], marks: { edge: [3.5, 0, 0], lip: [5.5, 0, -1], drop: [6.5, 0, -4] }, build: (P) => [
    F(5, -3, -4, 8, 3, -1, "air"), F(5, -3, -5, 8, 3, -5, "snow"), F(9, -4, -4, 9, 4, 1, "snow"), F(5, -4, -4, 8, -4, 0, "snow"), F(5, 4, -4, 8, 4, 0, "snow"),
    F(5, -2, -1, 6, 2, -1, "snow"), F(3, -3, 0, 6, 3, 0, "snow_layer"), S1(4, -3, 0, P.fence), S1(4, 3, 0, P.fence), S1(9, 0, 2, "snow_layer"),
  ], st: { 1: (P) => [F(5, -2, -1, 6, 2, 0, "air")] } },
  /* 薄い 氷の 池（氷の 下は 水）。st1 = まん中が 割れる */
  icepond: { D: [9, 10, 12], gap: 8, box: [-1, -4, 6, 4], H: 2, look: [3, 0, 0], marks: { ice: [3, 0, 0], rim: [0.5, 0, 0] }, build: (P) => [
    F(1, -3, -3, 5, 3, -1, "packed_ice"), F(2, -2, -3, 4, 2, -2, "water"), F(2, -2, -1, 4, 2, -1, "ice"), S1(0, -3, 0, "snow_layer"), S1(6, 2, 0, "snow_layer"), S1(1, 4, 0, P.fence), S1(1, 4, 1, P.lamp),
  ], st: { 1: (P) => [F(3, -1, -1, 3, 1, -1, "water")] } },
  /* 崖道の 崖（高さ 5 の 岩壁。上に 立てる）*/
  cliffwall: { D: [9, 10, 12], gap: 8, box: [-1, -6, 5, 6], H: 7, look: [3, 0, 3], marks: { top: [3.5, 0, 5], foot: [0.5, 0, 0] }, build: (P) => [
    F(2, -6, 0, 5, 6, 3, P.rock), F(3, -5, 4, 5, 5, 4, P.rock), F(2, -6, 2, 2, -3, 3, "air"), F(2, 4, 3, 2, 6, 3, "air"), F(1, -6, 0, 1, -5, 1, P.rock), S1(1, 5, 0, P.trim), S1(0, -4, 0, "gravel"), S1(4, 3, 5, P.plant), S1(4, -2, 5, P.plant),
  ] },
  /* 水晶の 祭壇（晶洞の 広間: 方解石の 床・玄武岩の 壇・曇った 水晶・紫水晶の 群れ）*/
  crysaltar: { D: [9, 10, 12], gap: 8, box: [-1, -5, 6, 5], H: 6, look: [4, 0, 1.2], marks: { altar: [4, 0, 1] }, build: (P) => [
    F(0, -4, -1, 6, 4, -1, "calcite"), F(3, -2, 0, 5, 2, 0, "smooth_basalt"), F(5, -1, 1, 5, 1, 2, "tinted_glass"), S1(5, 0, 3, "amethyst_block"), S1(5, 0, 4, "amethyst_cluster"),
    F(6, -4, 0, 6, -4, 2, "amethyst_block"), F(6, 4, 0, 6, 4, 2, "amethyst_block"), S1(6, -4, 3, "amethyst_cluster"), S1(6, 4, 3, "amethyst_cluster"), S1(2, -4, 0, "amethyst_block"), S1(2, -4, 1, "amethyst_cluster"), S1(2, 4, 0, "amethyst_block"), S1(2, 4, 1, "amethyst_cluster"),
    F(1, -5, 0, 1, -5, 2, "calcite"), F(1, 5, 0, 1, 5, 2, "calcite"), S1(4, -3, 0, "sea_lantern"), S1(4, 3, 0, "sea_lantern"), S1(3, -2, 1, "amethyst_cluster"), S1(3, 2, 1, "amethyst_cluster"),
  ] },
  /* 小さな 墓（土の 盛り・石の 墓標・野の 花）*/
  grave: { D: [5, 6, 8], near: 3, box: [-1, -3, 3, 3], H: 3, small: 1, side: [4, -4, 7, -7], look: [2, 0, 0.6], marks: { stone: [2, 0, 0.6], front: [0, 0, 0] }, build: (P) => [
    F(1, -1, 0, 2, 1, 0, "moss_carpet"), S1(2, 0, 0, "mossy_stone_brick_wall"), S1(2, 0, 1, "stone_brick_slab"), S1(1, -1, 0, "dandelion"), S1(1, 1, 0, "poppy"), S1(2, -1, 0, "cornflower"), S1(2, 1, 0, "oxeye_daisy"), S1(3, 2, 0, "azure_bluet"),
  ] },
  /* 岩場・岩山・峰（岩の 塊と まわりの 岩）*/
  rocks: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 6, look: [3, 0, 2], marks: { top: [3.5, 0, 4] }, build: (P) => [
    F(2, -2, 0, 4, 2, 2, P.rock), F(3, -1, 3, 4, 1, 3, P.rock), F(2, -2, 2, 2, -2, 2, P.trim), F(1, -5, 0, 2, -4, 1, P.rock), F(5, 3, 0, 6, 5, 1, P.rock), S1(0, 4, 0, P.rock), S1(5, -3, 0, "cobblestone"), S1(1, 3, 0, "gravel"), S1(6, -1, 0, P.trim), S1(4, 0, 4, P.trim),
  ] },
  /* 岩棚と 木 */
  ledge: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 9, look: [3, 0, 3], marks: { tree: [4, 0, 4] }, build: (P) => [
    F(2, -3, 0, 5, 3, 3, P.rock), F(1, -3, 0, 1, -2, 1, P.rock), F(1, 2, 0, 1, 3, 2, P.rock), F(4, 0, 4, 4, 0, 6, P.log), F(3, -1, 6, 5, 1, 7, "dark_oak_leaves"), S1(4, 0, 8, "dark_oak_leaves"), S1(3, 2, 4, P.plant), S1(6, -4, 0, P.rock),
  ] },
  /* 溶岩の 崖（赤く 光る 黒い 崖・崖の 下の 溶岩だまり）*/
  lavacliff: { D: [11, 12, 10], box: [-1, -5, 6, 5], H: 7, look: [3, 0, 3], marks: { top: [4.5, 0, 5] }, build: (P) => [
    F(3, -5, 0, 6, 5, 4, "blackstone"), F(3, -4, 1, 3, 4, 1, "magma"), F(3, -3, 3, 3, 3, 3, "magma"), F(3, -1, 0, 3, 1, 0, "basalt"), F(1, -2, -2, 2, 2, -2, "blackstone"), F(1, -2, -1, 2, 2, -1, "lava"),
    F(0, -3, -1, 0, 3, -1, "blackstone"), F(5, -5, 5, 5, -4, 6, "basalt"), F(5, 4, 5, 5, 5, 5, "basalt"), S1(4, 0, 5, "magma"),
  ] },
  /* 竜骨の 原（大きな 骨の 肋の アーチ・鱗）*/
  bones: { D: [11, 12, 10], box: [-1, -5, 7, 5], H: 6, look: [3, 0, 2], marks: { root: [2, -3, 0] }, build: (P) => [
    F(2, -3, 0, 2, -3, 3, "bone_block"), F(2, 3, 0, 2, 3, 3, "bone_block"), F(2, -2, 4, 2, 2, 4, "bone_block"), F(4, -3, 0, 4, -3, 3, "bone_block"), F(4, 3, 0, 4, 3, 3, "bone_block"), F(4, -2, 4, 4, 2, 4, "bone_block"),
    F(6, -2, 0, 6, -2, 2, "bone_block"), F(6, 2, 0, 6, 2, 2, "bone_block"), F(6, -1, 3, 6, 1, 3, "bone_block"), F(1, 0, 0, 7, 0, 0, "bone_block"), S1(0, 0, 0, "skull"), S1(3, -2, 0, "light_blue_carpet"), S1(5, 1, 0, "light_blue_carpet"), S1(2, -4, 0, "light_blue_carpet"),
  ] },
  bonepeak: { D: [11, 12, 10], box: [-1, -5, 6, 5], H: 9, look: [3, 0, 4], marks: { top: [3.5, 0, 3] }, build: (P) => [
    F(1, -4, 0, 5, 4, 1, P.rock), F(2, -3, 2, 4, 3, 2, P.rock), F(2, -3, 3, 2, -3, 5, "bone_block"), F(2, 3, 3, 2, 3, 5, "bone_block"), F(2, -2, 6, 2, 2, 6, "bone_block"), F(4, -2, 3, 4, -2, 5, "bone_block"), F(4, 2, 3, 4, 2, 5, "bone_block"), F(4, -1, 6, 4, 1, 6, "bone_block"), S1(0, 4, 0, P.rock),
  ] },
  /* 鏡石の 原（光る 石が 原に 散らばる）*/
  mirrors: { D: [10, 12, 9], box: [-1, -6, 6, 6], H: 3, look: [3, 0, 0.6], build: (P) => [
    F(0, -5, -1, 6, 5, -1, "calcite"), S1(1, -4, 0, "white_stained_glass"), S1(2, 2, 0, "tinted_glass"), F(3, -2, 0, 3, -2, 1, "white_stained_glass"), S1(4, 4, 0, "glass"), S1(5, -5, 0, "amethyst_block"), F(5, 1, 0, 5, 1, 1, "glass"),
    S1(2, -1, 0, "amethyst_cluster"), S1(6, 3, 0, "white_stained_glass"), S1(1, 5, 0, "glass"), S1(6, -2, 0, "tinted_glass"), S1(3, 5, 0, "amethyst_cluster"), S1(0, 0, 0, "sea_lantern"),
  ] },
  /* 花の 丘（赤い 花・白い 花）*/
  redhill: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 2, look: [3, 0, 0.5], build: (P) => [
    F(0, -5, -1, 6, 5, -1, "grass_block"), F(1, -4, 0, 5, 4, 0, "poppy"), F(2, -3, 0, 4, 3, 0, "red_tulip"), F(3, -1, 0, 3, 1, 0, "poppy"), S1(0, -5, 0, 'red_candle ["candles"=3,"lit"=true]'), S1(0, 5, 0, 'red_candle ["candles"=3,"lit"=true]'), S1(6, 0, 0, 'red_candle ["candles"=2,"lit"=true]'),
  ] },
  whitehill: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 2, look: [3, 0, 0.5], build: (P) => [
    F(0, -5, -1, 6, 5, -1, "grass_block"), F(1, -4, 0, 5, 4, 0, "lily_of_the_valley"), F(2, -3, 0, 4, 3, 0, "oxeye_daisy"), F(3, -1, 0, 3, 1, 0, "white_tulip"), S1(0, 0, 0, P.fence), S1(0, 0, 1, P.lamp),
  ] },
  /* 庭の 跡（枯れた 花壇・石の ベンチ）*/
  garden: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 2, look: [3, 0, 0.5], marks: { bench: [1, 3.5, 0] }, build: (P) => [
    F(2, -4, 0, 5, -4, 0, P.trim), F(2, 4, 0, 5, 4, 0, P.trim), F(5, -3, 0, 5, 3, 0, P.trim), F(2, -3, -1, 4, 3, -1, "coarse_dirt"), F(2, -3, 0, 4, 3, 0, "deadbush"), F(3, -1, 0, 3, 1, 0, "air"),
    S1(1, 3, 0, 'stone_brick_stairs ["weirdo_direction"=2]'), S1(1, 4, 0, 'stone_brick_stairs ["weirdo_direction"=2]'), S1(0, -4, 0, P.fence), S1(0, -4, 1, P.lamp),
  ] },
  /* 丘の 古い 木 */
  oldtree: { D: [10, 12, 9], box: [-2, -4, 4, 4], H: 9, look: [1, 0, 2], marks: { root: [0, 0, 0] }, build: (P) => [
    F(0, -2, 0, 2, 2, 0, "grass_block"), F(1, 0, 1, 1, 0, 5, "oak_log"), F(-1, -2, 5, 3, 2, 6, "oak_leaves"), F(0, -1, 7, 2, 1, 7, "oak_leaves"), S1(0, 1, 1, "oak_log"), S1(2, -1, 1, "oak_log"), S1(-1, 2, 0, "dandelion"),
  ] },
  /* 砂の 窪地（2マス 下がった 底に 布の 束）*/
  hollow: { D: [10, 12, 9], box: [-1, -4, 6, 4], H: 2, look: [3, 0, -1.4], marks: { pit: [3, 0, -2] }, build: (P) => [
    F(1, -3, -2, 5, 3, -1, "air"), F(1, -3, -3, 5, 3, -3, P.bed), F(0, -1, -1, 0, 1, -1, P.slab), S1(3, 0, -2, "white_wool"), S1(3, 1, -2, P.cloth2), S1(4, -1, -2, "white_carpet"), S1(2, 2, -2, "deadbush"),
  ] },
  /* 氷の 洞（洞くつの 形を 氷で）*/
  icecave: { D: [13, 15, 12], box: [-2, -4, 6, 4], H: 6, look: [0, 0, 1.5], build: (P) => SHAPES.cave.build({ ...P, rock: "packed_ice", trim: "blue_ice", ore: "raw_gold_block" }) },
  /* 岩礁・入り江（浅い 水・岩・流れ着いた 舟板）*/
  reef: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 3, look: [3, 0, 0.5], build: (P) => [
    F(1, -4, -2, 5, 4, -1, "sand"), F(1, -4, -1, 5, 4, -1, "water"), F(2, -3, -1, 3, -2, 1, P.rock), F(4, 2, -1, 5, 3, 0, P.rock), S1(3, 1, -1, P.rock), S1(3, 1, 0, P.rock), S1(2, 1, 0, P.slab), S1(4, -1, -1, "sea_pickle"), S1(0, -4, 0, P.fence), S1(0, -4, 1, P.lamp),
  ] },
  /* 雲の 井戸（井戸と 小さな 風車）*/
  cloudwell: { D: [11, 13, 10], box: [-2, -3, 3, 7], H: 8, look: [1, 0, 1], build: (P) => SHAPES.well.build(P).concat([F(2, 5, 0, 2, 5, 5, P.log), F(1, 5, 3, 1, 5, 7, P.cloth), F(1, 3, 5, 1, 7, 5, P.cloth)]) },
  /* 川上の 灯り台（石の 台の 上の 火・そばを 流れる 川）*/
  lamptower: { D: [11, 13, 10], box: [-1, -6, 6, 3], H: 7, look: [2, 0, 4], marks: { fire: [2, 0, 5] }, build: (P) => [
    F(1, -1, 0, 3, 1, 3, P.wall), F(1, -1, 4, 3, 1, 4, P.slab), S1(2, 0, 4, P.wall), S1(2, 0, 5, "soul_campfire"), F(-1, -6, -2, 6, -4, -2, P.trim), F(-1, -5, -1, 6, -5, -1, "water"), S1(0, 0, 0, "ladder"),
  ] },
};

/* 第125版(pl): 大きな 施設（形の 点検の 450 ブロックの 外。fill の 数は 少ない）。建てられない ときは fb の 小さな 形 */
/* 坑道: 丘の 斜面の 入口（木の 枠・看板・灯り）→ レールと トロッコ・鉱石の 山 → 下って いく 坑道（支柱と 灯り）→ 水晶の 脇坑 2本 → 奥の 広間（場面の 場所: m.hall）*/
const MBEAM = (P, a, h) => [F(a, -2, h, a, -2, h + 2, P.log), F(a, 2, h, a, 2, h + 2, P.log), F(a, -2, h + 3, a, 2, h + 3, P.plank), S1(a, 0, h + 2, HANG(P))];
const BIG = {
  minetunnel: { fb: "mine", D: [12, 14, 16], box: [-2, -8, 25, 8], H: 1, look: [0, 0, 1.6], marks: { hall: [21, 0, -3], vein: [24, 0, -1.5], mouth: [0, 0, 0] }, build: (P) => [
    F(0, -7, 0, 24, 7, 5, P.rock), F(3, -6, 6, 21, 6, 6, P.rock), F(7, -4, 7, 17, 4, 7, P.rock), F(0, -7, 5, 24, 7, 5, P.ground, "replace " + P.rock),
    F(-1, -6, -5, 25, 6, -1, P.rock, "keep"),
    F(0, -2, 0, 6, 2, 3, "air"), F(0, -2, -1, 6, 2, -1, P.bed), F(7, -2, -1, 12, 2, 2, "air"), F(7, -2, -2, 12, 2, -2, P.bed), F(13, -2, -2, 17, 2, 1, "air"), F(13, -2, -3, 17, 2, -3, P.bed),
    F(18, -5, -3, 25, 5, 2, "air"), F(18, -5, -4, 25, 5, -4, P.bed),
    F(8, 3, -1, 10, 7, 1, "air"), F(8, 3, -2, 10, 7, -2, P.bed), F(11, 3, -1, 11, 7, 1, "amethyst_block"), F(8, 8, -1, 10, 8, 1, "calcite"), S1(9, 7, -1, "amethyst_cluster"), S1(10, 5, 1, "amethyst_block"), S1(9, 6, 0, "lantern"),
    F(14, -7, -2, 16, -3, 0, "air"), F(14, -7, -3, 16, -3, -3, P.bed), F(14, -8, -2, 16, -8, 0, "calcite"), F(17, -7, -2, 17, -3, 0, "amethyst_block"), S1(15, -7, -2, "amethyst_cluster"), S1(14, -6, -1, P.ore), S1(15, -4, -2, "lantern"),
    ...MBEAM(P, 0, 0), ...MBEAM(P, 3, 0), ...MBEAM(P, 6, 0), ...MBEAM(P, 9, -1), ...MBEAM(P, 12, -1), ...MBEAM(P, 15, -2),
    F(-1, -2, 4, -1, 2, 4, P.plank), S1(-1, 0, 5, "red_wool"), S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp),
    F(-4, 0, -1, 6, 0, -1, "gravel"), F(-4, 0, 0, 6, 0, 0, "RA"), F(18, -2, -3, 23, -2, -3, "RA"), S1(-3, 2, 0, P.ore), S1(-3, 3, 0, P.ore), S1(-2, 3, 0, "coal_block"), S1(-2, -3, 0, "barrel"), S1(5, 2, 0, P.ore), S1(5, -2, 0, "barrel"),
    F(25, -5, -3, 25, 5, 1, "calcite"), F(25, -3, -2, 25, 3, 0, "amethyst_block"), S1(24, -4, -3, "amethyst_cluster"), S1(24, 4, -3, "amethyst_cluster"), S1(24, 0, -3, "chest"),
    S1(19, -5, 0, "shroomlight"), S1(19, 5, 0, "shroomlight"), S1(24, -5, 0, "shroomlight"), S1(24, 5, 0, "shroomlight"), S1(21, 0, 2, "shroomlight"),
    F(20, -3, -3, 22, 3, -3, "moss_carpet"), S1(22, -4, -3, "glow_lichen"), S1(20, 4, -3, "glow_lichen"),
    ["e", -2, 0, 0, "chest_minecart"], ["e", 3, 0, 0, "minecart"], ["e", 20, -2, -3, "minecart"],
  ] },
};
/* ---------- 置く 場所 ---------- */
const card = (f) => (Math.abs(f.x) >= Math.abs(f.z) ? { x: Math.sign(f.x) || 1, z: 0 } : { x: 0, z: Math.sign(f.z) || 1 });
const W = (o, fa, a, b) => ({ x: o.x + a * fa.x - b * fa.z, z: o.z + a * fa.z + b * fa.x });
const blk = (dim, x, y, z) => { try { return dim.getBlock({ x, y, z }) || null; } catch { return null; } };
function tooNear(x, z, small = false, gap = 14) {
  for (const t of TOWNS) { try { const g = getTown(t.id), q = g && g.built ? g : townPos(t); if (Math.hypot(q.x - x, q.z - z) < 42) return true; } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) { try { const c = castleSpot(i); if (c && Math.hypot(c.x - x, c.z - z) < 60) return true; } catch {} try { for (const L of landSites(i)) if (Math.hypot(L.x + 14 - x, L.z + 6 - z) < 26) return true; } catch {} }
  if (!small) try { const L = J("mrpg:epdeco:faclist") || []; for (const k of L) { const v = facAt(k); if (v && Math.hypot(v.x - x, v.z - z) < gap) return true; } } catch {}   /* 焚き火（small）は 小屋の そばでも よい */
  return false;
}
/* 舞台の 奥で 平らで 乾いた 所（原点・向き・高さ）。見つからなければ null */
function site(dim, S, sh, y0) {
  const fa = card(S.f), [a0, b0, a1, b1] = sh.box, sides = [0, ...(sh.side || [5, -5, 9, -9])];
  let PL = []; try { PL = dim.getPlayers().map((q) => q.location); } catch {}
  for (const D of sh.D) for (const sb of sides) {
    const c = S.at(D, sb), o = { x: Math.floor(c.x), z: Math.floor(c.z) };
    const pts = []; for (const a of [a0, (a0 + a1) >> 1, a1]) for (const b of [b0, (b0 + b1) >> 1, b1]) pts.push(W(o, fa, a, b));
    { const nr = sh.near || 6.5; if (pts.some((q) => Math.hypot(q.x - S.Cn.x, q.z - S.Cn.z) < nr || Math.hypot(q.x - S.P.x, q.z - S.P.z) < nr - 0.5)) continue; }   /* 第125版(pl): 鍛冶場・店先は 人の すぐ 後ろ（near）*/
    const ctr = W(o, fa, (a0 + a1) / 2, (b0 + b1) / 2); if (tooNear(ctr.x, ctr.z, !!sh.small, sh.gap || 14)) continue;
    if (PL.some((l) => { const dx = l.x - o.x, dz = l.z - o.z, a = dx * fa.x + dz * fa.z, b = -dx * fa.z + dz * fa.x; return a >= a0 - 2 && a <= a1 + 2 && b >= b0 - 2 && b <= b1 + 2; })) continue;   /* マルチ: ほかの 人が 立って いる 所には 建てない */
    let bad = false; const ys = [];
    for (const q of pts) { let g = null; try { g = groundY(dim, q.x, q.z, y0 + 6); } catch {} if (typeof g !== "number" || Math.abs(g - y0) > 3) { bad = true; break; } const d = blk(dim, q.x, g - 1, q.z), u = blk(dim, q.x, g, q.z); if (!d || d.isLiquid || /water|lava|ice/.test(d.typeId) || (u && u.isLiquid)) { bad = true; break; } ys.push(g); }
    if (bad) continue;
    for (const [a, b] of [[a0 - 2, b0 - 2], [a0 - 2, b1 + 2], [a1 + 2, b0 - 2], [a1 + 2, b1 + 2]]) { const q = W(o, fa, a, b), w = blk(dim, q.x, y0 - 1, q.z), w2 = blk(dim, q.x, y0, q.z); if ((w && w.isLiquid) || (w2 && w2.isLiquid)) { bad = true; break; } }   /* そばに 水が ない */
    if (bad) continue;
    ys.sort((a, b) => a - b);
    return { o: { x: o.x, y: ys[ys.length >> 1], z: o.z }, f: fa };
  }
  return null;
}
/* ops を ワールドの コマンドに */
function cmds(ops, R) {
  const { o, f } = R, out = [], ents = [], ra = f.x ? 1 : 0, rb = f.x ? 0 : 1;
  for (const op of ops) {
    if (op[0] === "e") { const q = W(o, f, op[1], op[2]); ents.push(`summon ${op[4]} ${q.x + 0.5} ${o.y + op[3]} ${q.z + 0.5}`); continue; }
    const [, a0, b0, h0, a1, b1, h1, bl0, m] = op; if (!bl0) continue;
    const bl = bl0 === "RA" ? `rail ["rail_direction"=${ra}]` : bl0 === "RB" ? `rail ["rail_direction"=${rb}]` : bl0;
    const p0 = W(o, f, a0, b0), p1 = W(o, f, a1, b1);
    out.push(`fill ${p0.x} ${o.y + h0} ${p0.z} ${p1.x} ${o.y + h1} ${p1.z} ${bl}${m ? ` ${m}` : ""}`);
  }
  return out.concat(ents);
}
const run = (dim, L) => { let n = 0; for (const c of L) { try { dim.runCommand(c); n++; } catch {} } return n; };
export const __fac = { SHAPES, BIG, cmds, site, palOf, card, W };
/* 第126版: 章ファイルが 自分の 施設の 形を 足す（facBuild・facSide・fac で 使える）。def = { D: [奥], box: [a0,b0,a1,b1], H, look: [a,b,h], build: (P) => ops, st?, marks?, side?, near?, small? }
   ops は FAC_OPS.F(a0,b0,h0, a1,b1,h1, ブロック, モード?)・FAC_OPS.S1(a,b,h, ブロック)。大きさは 400 ブロック まで（こえると 警告）。同じ 名前は 上書きしない */
export const FAC_OPS = { F, S1, HANG, WCAUL };
export function facAdd(key, def) {
  if (!key || !def || typeof def.build !== "function" || !Array.isArray(def.box)) { console.warn(`[MonsterRPG] facAdd: 形が ちがう ${key}`); return false; }
  if (SHAPES[key] || BIG[key]) { console.warn(`[MonsterRPG] facAdd: ${key} は もう ある`); return false; }
  const sh = { D: [16, 19], H: 4, look: [0, 0, 1], ...def };
  try { let n = 0; for (const o of sh.build(palOf(0))) if (o && o[0] === "f" && o[7] !== "air") n += (Math.abs(o[4] - o[1]) + 1) * (Math.abs(o[5] - o[2]) + 1) * (Math.abs(o[6] - o[3]) + 1); if (n > 400) console.warn(`[MonsterRPG] facAdd: ${key} が 大きい（${n} ブロック）`); } catch {}
  SHAPES[key] = sh; return true;
}
/* 第125版(pl): 世界の 依頼の 場所の 名前 → 建てる 形（名前の ない 野の 場所は 道しるべ）*/
const WQK = [[/川上の灯り台/, "lamptower"], [/溶岩の崖/, "lavacliff"], [/竜骨の峰/, "bonepeak"], [/竜骨/, "bones"], [/岩棚/, "ledge"], [/鏡石/, "mirrors"], [/赤い花/, "redhill"], [/祈りの丘/, "whitehill"], [/庭/, "garden"], [/星見の丘/, "oldtree"], [/窪地/, "hollow"],
  [/氷の洞/, "icecave"], [/雲の井戸/, "cloudwell"], [/岩礁|入り江/, "reef"], [/川/, "brook"], [/ばら/, "roses"], [/岩場|岩山|峰/, "rocks"],   /* 第125版(tp): 文に 出る 地形（崖・川・岩・骨・花）*/
  [/かざぐるま/, "windmill"], [/書庫/, "library"], [/ふいご/, "bellows"], [/山小屋/, "cabin2"], [/家|小屋/, "hut"], [/焼けた/, "burnt"], [/麦畑|畑の?$/, "field"], [/ばら/, "roses"],
  [/池/, "pond"], [/ほこら|祠/, "hokora"], [/祭壇/, "altar"], [/墓/, "graves"], [/坑道/, "minetunnel"], [/洞|割れ目|心臓/, "cave"], [/灯台/, "lighthouse"], [/星見台/, "observatory"], [/見張り台|灯り台/, "tower"], [/井戸/, "well"],
  [/試し/, "arena"], [/水路/, "channel"], [/野営/, "tent"], [/浜|入り江|岩礁/, "beachcamp"], [/枯れ|林/, "deadwood"]];
export function wqKind(nm) { const t = String(nm || "").replace(/\s/g, "").replace(/^.*の外れの/, ""); for (const [re, k] of WQK) if (re.test(t)) return k; return "waypost"; }
export const facKind = (key) => { const v = J(`mrpg:epdeco:${key}at`); return v && v.k ? v.k : null; };   /* 第125版(tp): 記録した 形 */
/* 第125版(tp): 同じ 場所（原点・向き）で 形を かえる（前の 形を 空けて から 建てる。遠くて 読まれて いない ときは しない）*/
export function facSwap(key, kind, r) {
  const v = J(`mrpg:epdeco:${key}at`), old = v && (SHAPES[v.k] || BIG[v.k]), sh = SHAPES[kind] || BIG[kind]; if (!v || !Array.isArray(v.o) || !old || !sh || !near48(v)) return false;
  const dim = world.getDimension("overworld"), R = { o: { x: v.o[0], y: v.o[1], z: v.o[2] }, f: { x: v.f[0], z: v.f[1] } }, P = palOf(r), [a0, b0, a1, b1] = sh.box, [c0, d0, c1, d1] = old.box;
  run(dim, cmds([F(c0, d0, 0, c1, d1, old.H || 4, "air"), F(a0, b0, -5, a1, b1, -1, P.base, "keep"), F(a0, b0, -1, a1, b1, -1, P.ground), F(a0, b0, 0, a1, b1, sh.H || 4, "air")].concat(sh.build(P)), R));
  const lk = W(R.o, R.f, sh.look[0], sh.look[1]), at = { x: lk.x + 0.5, y: R.o.y + sh.look[2], z: lk.z + 0.5, o: v.o, f: v.f, k: kind, r };
  if (sh.marks) { at.m = {}; for (const [n, [a, b, h]] of Object.entries(sh.marks)) { const q = W(R.o, R.f, a, b); at.m[n] = [q.x + 0.5, R.o.y + h, q.z + 0.5]; } }
  P_(`mrpg:epdeco:${key}at`, at); return true;
}

/* 建てる（ワールドに 1回）。返す 値は 見る 点。r: 地方（色）*/
export function facBuild(p, S, key, kind, r, y0) {
  const had = facAt(key); if (had) return had;
  let sh = SHAPES[kind] || BIG[kind]; if (!sh || !S || !S.f || !p) return null;
  const dim = p.dimension; try { if (dim.id !== "minecraft:overworld") return null; } catch { return null; }
  let R = site(dim, S, sh, Math.floor(y0)); if (!R && sh.fb) { kind = sh.fb; sh = SHAPES[kind]; R = site(dim, S, sh, Math.floor(y0)); } if (!R) return null;   /* 第125版(pl): 大きな 坑道が 入らない 所は 小さな 入口 */
  const P = palOf(r), [a0, b0, a1, b1] = sh.box, H = sh.H || 4;
  const pre = [F(a0, b0, -5, a1, b1, -1, P.base, "keep"), F(a0, b0, -1, a1, b1, -1, P.ground), F(a0, b0, 0, a1, b1, H, "air")];   /* 土台（穴だけ うめる）・地面・上を 空ける */
  run(dim, cmds(pre.concat(sh.build(P)), R));
  const lk = W(R.o, R.f, sh.look[0], sh.look[1]), at = { x: lk.x + 0.5, y: R.o.y + sh.look[2], z: lk.z + 0.5, o: [R.o.x, R.o.y, R.o.z], f: [R.f.x, R.f.z], k: kind, r };
  if (sh.marks) { at.m = {}; for (const [n, [a, b, h]] of Object.entries(sh.marks)) { const q = W(R.o, R.f, a, b); at.m[n] = [q.x + 0.5, R.o.y + h, q.z + 0.5]; } }   /* 網など 場面で 映す 点 */
  P_(`mrpg:epdeco:${key}at`, at);
  try { const L = J("mrpg:epdeco:faclist") || []; if (!L.includes(key)) { L.push(key); P_("mrpg:epdeco:faclist", L); } } catch {}
  return { x: at.x, y: at.y, z: at.z };
}
/* 第125版(pl): 舞台の 横（side マス）に 建てる（場面の とちゅうで 移る 先: 坑道の 奥 など）。front は 施設の 前（舞台を 置く 点）*/
export function facSide(p, S, side, key, kind, r, y0) {
  const had = facAt(key, p.location, 90); if (had) return had;
  if (!S || !S.f) return null; const f = S.f, P = S.at(0, side), at = (a, b, dy = 0) => ({ x: P.x + f.x * a - f.z * b, y: P.y + dy, z: P.z + f.z * a + f.x * b });
  return facBuild(p, { P, f, at, Cn: at(2.5, 0) }, key, kind, r, y0);
}
export function facFront(key, k = 5) { const v = J(`mrpg:epdeco:${key}at`); if (!v || !Array.isArray(v.o)) return null; return { x: v.o[0] - v.f[0] * k + 0.5, y: v.o[1], z: v.o[2] - v.f[1] * k + 0.5 }; }
/* 場面から 呼ぶ: 記録が あれば それ、なければ 舞台の 奥に 建てる */
export function fac(K, p, key, kind, r, y0) { try { const near = facAt(key, p.location, 72); if (near) return near; const S = K.S(p); return S ? facBuild(p, S, key, kind, r, y0) : null; } catch { return null; } }

/* ---------- 状態（段階は 下がらない）---------- */
function applySt(key, want) {
  const v = J(`mrpg:epdeco:${key}at`); if (!v || !Array.isArray(v.o)) return false;
  const sh = SHAPES[v.k] || BIG[v.k]; if (!sh || !sh.st) return true;
  const dim = world.getDimension("overworld"); let cur = 0; try { cur = Number(world.getDynamicProperty(`mrpg:epdeco:${key}st`) || 0); } catch {}
  const R = { o: { x: v.o[0], y: v.o[1], z: v.o[2] }, f: { x: v.f[0], z: v.f[1] } }, P = palOf(v.r);
  for (let s = cur + 1; s <= want; s++) if (sh.st[s]) run(dim, cmds(sh.st[s](P), R));
  try { world.setDynamicProperty(`mrpg:epdeco:${key}st`, Math.max(cur, want)); } catch {}
  return true;
}
const near48 = (v) => { try { return world.getAllPlayers().some((q) => q.dimension.id === "minecraft:overworld" && Math.hypot(q.location.x - v.x, q.location.z - v.z) < 48); } catch { return false; } };
export function facStage(key) { try { return Number(world.getDynamicProperty(`mrpg:epdeco:${key}st`) || 0); } catch { return 0; } }
export function facState(key, want) {
  if (facStage(key) >= want) return;
  const v = facAt(key);
  if (v && near48(v)) { applySt(key, want); return; }
  const pend = J("mrpg:epdeco:facpend") || {}; pend[key] = Math.max(pend[key] || 0, want); P_("mrpg:epdeco:facpend", pend);   /* まだ 建って いない・遠い: あとで */
}
/* あとで かえる 分（5秒に 1回。ふだんは 記録を 1つ 読む だけ）*/
system.runInterval(() => {
  let pend = null; try { const s = world.getDynamicProperty("mrpg:epdeco:facpend"); if (!s) return; pend = JSON.parse(s); } catch { return; }
  let left = 0;
  for (const k of Object.keys(pend)) { const v = facAt(k); if (facStage(k) >= pend[k]) { delete pend[k]; continue; } if (v && near48(v)) { applySt(k, pend[k]); delete pend[k]; } else left++; }
  P_("mrpg:epdeco:facpend", left ? pend : undefined);
}, 100);
