// 第76版: 追加ストーリー（第125版: 名前は「常世編」。エンマが 閻魔の神殿の 奥に 道を 開いた あとの お話）
// 追加ストーリーの パック（MineQuest 追加ストーリー）が 入って いる ワールドで だけ 動く（パックは「mq:ext ruins」を 送るだけ）。
// 進み具合は セーブの story.ru（一人ずつ 別々）。パックを 外しても 仲間・道具は 本体の ものなので 残る。
import { world, system } from "@minecraft/server";
import { talk, tell, lookAt } from "./talk.js";
import { scene, act, go, knockP, flash, fx, shadowFlow, pause, spot, lookUp, emote, PJ } from "./stage2.js";   /* 第108版: 会話は フォームで 止めない */
import * as MC from "@minecraft/server";
import { SPECIES, ORDER, ITEMS, MOVES } from "./data.js";
import { pick, ri, calcStats } from "./core.js";
import { load, save } from "./store.js";
import { busy, ok, notice, choose, confirm, sound, setJob, showTitle, giveItem, ICON, gold, anim, isLite, heavy } from "./ui.js";
import { TOWNS, townPos, groundY, enqueue } from "./structures.js";
import { chestCmds, CHEST_GATE, CHEST_TIERS, BOX_RE, registerChest, chestsNear, CHEST_PEND } from "./chests.js";
import { setLook, lookOf, hooks } from "./field.js";
import { fight } from "./story.js";
import { homeTp, GOAL_HOOKS } from "./saga.js";
import { qs } from "./quest.js";
import { altarPos } from "./postgame.js";
import { MUSASHI_EXTRA } from "./majin.js";
import { STORY_EXTRA } from "./story.js";
import { HIT_HOOKS, inBattle } from "./battle.js";
const fighting = (p) => { try { return inBattle(p) || TK_CALM.has(p.id); } catch { return false; } };   /* 第106版: 物語の 場面の あいだも 守る */   /* 第92版: 「戦い中」だけ 守る（メニューの 印 busy は 見ない） */
import { NPC_HOOKS } from "./npchook.js";
import { RU, CITY_R, setRuCity, inRuins, RU_GATE, RU_INN, RU_HOOK } from "./ruinsarea.js";
import { npcMenu } from "./menu.js";
import { award } from "./endgame.js";
import { buildLot, nextLot, lotReady, lotIdx, lotsDone, CB } from "./citybuild.js";
import { TK_EPI, tkBossName, tkPre, tkPost, tkFinalPre, tkFinalPost, TK_CALM, tkStoneBack, tkOmen, tkOpen } from "./tokoyo.js";
import { TK_SP, TK_LOOK, TK_PT, TK_GNAME } from "./tkgimmick.js";   /* 第126版: 邪闘十魔将 */   /* 第106版: 常世編 */

const TYPE = "mrpg:monster", NPC = "mrpg:npc", OW = () => world.getDimension("overworld");
/* 第99版: プレイヤーの 一覧は 1tickに 1回だけ 取る（前は 同じ tickで 何十回も 取って いた） */
const APC = { t: -1, L: [] };
const allP = () => { const t = system.currentTick; if (t === undefined || t !== APC.t) { APC.t = t; APC.L = world.getAllPlayers(); } return APC.L; };
const BOOT = Date.now();
const SAIL = "常世の 渡し守", JASHIN = "邪神ヴォルナグ";
/* 第125版: キャンプを 守るのは 常世の 渡し守（昔、魂を 帳の 王の もとへ 運んで いた） */
const sailN = () => SAIL;
// ---------- 追加ストーリーの パックが いるか ----------
system.afterEvents.scriptEventReceive.subscribe(({ id, message }) => {
  const m = String(message || "").trim();
  if (id === "mq:ext" && (m === "tokoyo" || m === "ruins") && !RU_GATE.on) { RU_GATE.on = true; console.warn("[MineQuest] 追加ストーリー「常世編」が 有効に なりました"); }
});
const gateOn = () => RU_GATE.on;
const settled = () => Date.now() - BOOT > 60000 && system.currentTick > 1200;   // パックの 知らせを 待つ あいだは 片づけない

// ---------- 場所 ----------
export const CAMPS = [
  { name: "神官の 隠れ家", dx: 0, dz: 0 },
  { name: "灰の 野営地", dx: 380, dz: 20 },
  { name: "沈んだ 街の 野営地", dx: -10, dz: 380 },
  { name: "崩れた 塔の 野営地", dx: -380, dz: -20 },
  { name: "玉座の 手前の 野営地", dx: 20, dz: -380 },
];
const THRONE = { dx: 0, dz: -640 };   /* 街が あれば applyCity で 書きかえる */
const EPI = TK_EPI;   /* 第106版: 十魔将の 区と 石門 */   /* 第78版: 配下の 種族に 合わせた 二つ名 */
const BSITE = EPI.map((_, i) => { const a = (i * 24 + 7) * Math.PI / 180, r = i % 2 ? 540 : 250; return { dx: Math.round(Math.cos(a) * r), dz: Math.round(Math.sin(a) * r) }; });
const RSPOT = []; for (let k = 0; k < 28; k++) { const a = (k * 360 / 28 + 4) * Math.PI / 180, r = [150, 320, 470, 690][k % 4]; RSPOT.push({ dx: Math.round(Math.cos(a) * r), dz: Math.round(Math.sin(a) * r) }); }
const at = (o) => ({ x: RU.x + o.dx, z: RU.z + o.dz });
/* 第77版: 配布マップの 灰都（±896）。キャンプは 街に もとから ある 休憩キャンプ（たき火・テント・補給箱）。y は 街の 足もとの 高さ */
const CITY_CAMPS = [
  { name: "調査隊の キャンプ", dx: 56, dz: 320, y: 72 }, { name: "廃スタジアムの 野営地", dx: 112, dz: 16, y: 72 }, { name: "記録塔の 手前の 野営地", dx: -16, dz: -16, y: 72 },
  { name: "黒い 工場の 野営地", dx: -272, dz: -272, y: 72 }, { name: "沈んだ 観覧車の 野営地", dx: -16, dz: -656, y: 72 }, { name: "古い 発電所の 野営地", dx: 752, dz: 18, y: 72 },
  { name: "沈む 巨塔の 野営地", dx: -528, dz: 112, y: 72 }, { name: "湖畔の 野営地", dx: -272, dz: 496, y: 102 }, { name: "さびれた 工場の 野営地", dx: -528, dz: 624, y: 72 },
  { name: "砂の 工場の 野営地", dx: 752, dz: 624, y: 85 }, { name: "雪の 崖の 野営地", dx: -784, dz: 496, y: 82 },
];
const CITY_BSITE = [[64, 64], [704, 64], [-64, -704], [-320, 448], [-576, 576], [-832, 448], [704, 576], [-576, 64], [-320, -320], [512, -512], [384, 768], [-768, -384], [-448, -704], [768, -256], [192, -320]].map(([dx, dz]) => ({ dx, dz }));
const CITY_SPOT = []; for (const x of [-768, -512, -256, 0, 256, 512, 768]) for (const z of [-640, -128, 384, 768]) CITY_SPOT.push({ dx: x, dz: z });   /* 大通りの 交差点の 補給箱 */
const CITY_THRONE = { dx: -64, dz: -64 };   /* 中央記録塔 */
const isCity = () => RU.city;
function applyCity() {
  if (!RU.city || CAMPS.cityOn) return;
  CAMPS.splice(0, CAMPS.length, ...CITY_CAMPS); CAMPS.cityOn = true;
  BSITE.splice(0, BSITE.length, ...CITY_BSITE); RSPOT.splice(0, RSPOT.length, ...CITY_SPOT);
  Object.assign(THRONE, CITY_THRONE);
  try { CIC.t = -999; } catch {}
}
system.run(() => applyCity());
/* 街が あるか（いちばん 下の 岩盤が 目印）。はじめて 行く ときに 1回だけ しらべる */
const DETECTING = { on: false };
async function detectCity(p) {   /* プレイヤーを 動かさず、中心の 1チャンクだけ 読みこんで しらべる（2人 同時でも 1回だけ） */
  try { if (typeof world.getDynamicProperty("mrpg:ruCity") === "number") { applyCity(); return; } } catch {}
  if (DETECTING.on) { for (let w = 0; w < 300 && DETECTING.on; w++) { await new Promise((res) => system.runTimeout(res, 5)); if (!ok(p)) return; } return; }
  DETECTING.on = true;
  try { await detectCity0(p); } finally { DETECTING.on = false; }
}
async function detectCity0(p) {
  try { OW().runCommand(`tickingarea add ${RU.x} 40 ${RU.z} ${RU.x + 1} 60 ${RU.z + 1} mrpg_rdet`); } catch {}
  try {
    for (let w = 0; w < 240; w++) {
      let b = null; try { b = OW().getBlock({ x: RU.x, y: 48, z: RU.z }); } catch {}
      if (b) { setRuCity(b.typeId === "minecraft:bedrock"); applyCity(); return; }
      await new Promise((res) => system.runTimeout(res, 5)); if (!ok(p)) return;
    }
  } finally { try { OW().runCommand("tickingarea remove mrpg_rdet"); } catch {} }
}
/* 街が ない ワールド: 行き先の キャンプの 区画が 建つまで 待つ（進みを 画面に） */
async function waitLot(p, x, z) {
  if (RU.pre !== false || lotReady(x, z)) return true;
  const L = lotIdx(x, z); if (!L) return true;
  const had = busy.has(p.id); busy.add(p.id);
  try {
    for (let w = 0; w < 1200; w++) {
      if (lotReady(x, z)) return true;
      if ((CB.fail[`${L.di},${L.dj}`] || 0) >= 3) return false;   /* 第89版: 3回 失敗したら あきらめる */
      if (!CB.busy) buildLot(L.di, L.dj, enqueue);
      try { p.onScreenDisplay.setActionBar(`§5常世への 門が ひらく…… §7（街の 準備: 約${Math.floor(w / 4)}秒）`); } catch {}
      await new Promise((res) => system.runTimeout(res, 5)); if (!ok(p)) return false;
    }
    return lotReady(x, z);
  } finally { if (!had) busy.delete(p.id); }
}
// 配下 15体（Gサイズ SS。系統は できるだけ かぶらない ように・Gの SSは 9系統しか ないので 10体目から かぶる）と 邪神（Xランク Gサイズ）
const BOSS_SP = (() => {
  const g = ORDER.filter((s) => { const S = SPECIES[s]; return S.sz === "G" && S.rank === "SS" && !S.hidden && !S.metalmon && !S.sea && !S.giant && s !== "enma" && s !== "musashi"; });   /* 海の ぬしは 陸を 歩かない */
  const out = [], fams = new Set();
  for (const s of g) if (out.length < 15 && !fams.has(SPECIES[s].fam)) { out.push(s); fams.add(SPECIES[s].fam); }
  for (const s of g) if (out.length < 15 && !out.includes(s)) out.push(s);
  return [...TK_SP, ...out.slice(10, 15)];   /* 第126版: 0〜9 は 邪闘十魔将（設計図の 見た目で えらんだ 種族）・10〜14 の 番兵は そのまま */
})();
const bossLook = (i) => (i >= 15 ? JASHIN_LOOK0 : i < 10 ? TK_LOOK[i] : RED0);   /* 第126版: 魔将ごとの 禍々しい 色 */
const JASHIN_SP = SPECIES.god43 ? "god43" : (ORDER.find((s) => SPECIES[s].sz === "G" && SPECIES[s].rank === "X" && !SPECIES[s].hidden) || BOSS_SP[0]);   /* 第78版: 禍神ラグロアの 姿を 黒と 赤に した 邪神の 本体 */
const JASHIN_LOOK = { h: 1, b: 15, a: 1, l: 15, c: 1, w: 1 };   /* 黒い 体・赤い 頭と 腕と 爪と 翼 */
const JASHIN_LOOK0 = JASHIN_LOOK, RED0 = { h: 1, b: 16, a: 16, l: 16, c: 1, w: 16 };
const bossName = (i) => (i >= 15 ? JASHIN : tkBossName(i, SPECIES[BOSS_SP[i]]?.name || ""));
const RED = { h: 1, b: 16, a: 16, l: 16, c: 1, w: 16 };   // 赤い 頭と 爪・黒い 体（赤い 目の 凶暴な 個体）

// ---------- 進み具合 ----------
// ru.st: 0 まだ / 1 ムサシから 聞いた / 2 常世へ / 3 配下 15体 撃破（邪神へ） / 4 クリア
export function ruOf(d) { const s = qs(d); if (!s.ru || typeof s.ru !== "object") s.ru = { st: 0, b: [], camps: [], last: 0 }; const r = s.ru; if (!Array.isArray(r.b)) r.b = []; if (!Array.isArray(r.camps)) r.camps = []; r.st = Number(r.st) || 0; r.last = Number(r.last) || 0; r.camps = r.camps.filter((k) => Number.isInteger(k) && k >= 0 && k < CAMPS.length); if (r.last >= CAMPS.length || r.last < 0) r.last = 0; if (r.v !== 77) { r.v = 77; r.camps = r.camps.length ? [0] : []; r.last = 0; }   /* 第77版: キャンプの 並びが かわったので 見つけた キャンプは 調査隊だけに */ return r; }
const beat = (r) => r.b.filter((x) => x >= 0 && x < 15).length;
const canStart = (d) => { const s = qs(d); return !!((s.enmaClear && (s.tkRoad || s.musashiJoin)) || (s.ru && s.ru.cheat)); };   /* 第125版: エンマが 道を 開いた あと */   /* 第85版: チートブックで 始めた 人も */
RU_HOOK.cheatGo = async (p) => {
  if (!gateOn() || busy.has(p.id)) return;
  const d = load(p); if (!d) { try { p.sendMessage("§7先に ガイドブックで 最初の 仲間を 選んでください。"); } catch {} return; }
  const r = ruOf(d); r.cheat = true; if (r.st < 2) r.st = 2; if (!r.camps.includes(0)) r.camps.push(0); save(p, d);
  busy.add(p.id); try { await goRuins(p, r.last || 0, false); } finally { busy.delete(p.id); }
  try { p.sendMessage("§5常世へ 来た。§7ガイドブック ＞ ストーリー ＞「常世」で 魔将の 居場所や 元の 世界への もどり方が 見られる"); } catch {}
};

// ---------- 言葉 ----------
const LORE = [
  "ここは 常世。邪神の 国だ。死者にも なれず、帳にも 載らぬ 魂が 流れつく 所。",
  "わたしは 渡し守。昔は 魂を 舟に 乗せ、帳の 王の もとへ 運んで いた。王が 封じられて から、舟は 止まった。",
  "邪神は 自分を 記録の 神と 呼ぶ。すべてを 書き留め、何ひとつ 手放さない。",
  "邪神は 自分では 動かない。十の 魔将と、石門を 守る 五体の 番兵を 置いた。",
  "魔将は 魂を 一つずつ 抱えて いる。倒せば、抱えた 魂は 帰り道を 思い出す。",
  "石に された 者の 魂も ここに いる。体は 現世で 石の まま、魂だけが 連れて こられた。",
  "影は、知った 者に 宿る。……いちばん 多くを 知った 者が、いちばん 深く 飲まれる。",
  "千年前の 王の 魂も、この 街の どこかに いる と 聞く。影に 飲まれた 最初の 王だ。",
  "帳の 王が 邪神に 逆らった 日の ことは、舟の 上から 見て いた。……あの 王は、狂って など いなかった。",
  "影に 殺された 者の 魂も、ここに 来る。帳に 載らぬ まま、名前を 少しずつ 忘れて いく。",
  "倒した 魔将の 体から、黒い 痕跡が 落ちる。邪神と 魔将を つなぐ 鎖の かけらだ。",
  "痕跡を 15 集めれば、玉座への 道が 見える はずだ。街の 真ん中、空の 裂け目の 真下に そびえる 記録塔だ。",
  "邪神は 傷つくと 一度だけ 全ての 傷を 癒やす と 伝わる。それを 越えれば 終わる、と。",
  "邪神が 倒れれば、影の 根が 切れる。抱えられて いた 魂は、みな 体へ 帰れる。",
  "ありがとう。わたしの 舟が、また 動き出す。",
];
const sayL = (p, who, lines, col = "§f") => talk(p, who, lines, col);

// 第125版: 常世への 入口は 閻魔の神殿の 奥（エンマが 道を 開く）。ムサシの うわさ話と ルミナの 神官は なくした
RU_HOOK.enter = async (p, first = false) => {
  if (!gateOn()) return;
  const d = load(p); if (!d) return;
  const r = ruOf(d); if (r.st < 2) { r.st = 2; if (!r.camps.includes(0)) r.camps.push(0); save(p, d); first = true; }
  try { p.runCommand("camera @s fade time 0.4 1.6 0.8 color 30 0 40"); } catch {}
  try { showTitle(p, "§5§l常世へ", { subtitle: "§7黒い 石段を 下りて いく", fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  sound(p, "ambient.cave", 0.8);
  await new Promise((res) => system.runTimeout(res, 30));
  await goRuins(p, first ? 0 : r.last || 0, first);
};

// ---------- 目標（右上・ガイドブック） ----------
const lumina = () => { const t = TOWNS.find((t) => t.id === "t0") || TOWNS[0]; return t ? townPos(t) : null; };
function nearestBoss(p, r) { let best = null; for (let i = 0; i < 15; i++) { if (r.b.includes(i) || !tkOpen(r.b, i)) continue; const q = at(BSITE[i]), dd = Math.hypot(p.location.x - q.x, p.location.z - q.z); if (!best || dd < best.dd) best = { i, q, dd }; } return best; }
GOAL_HOOKS.push((p, d) => {
  if (!gateOn() || !canStart(d)) return null;
  const r = ruOf(d);
  if (r.st < 2) { const A = altarPos(); return A ? { text: "閻魔の神殿の 奥の 石段から 常世へ 行こう（神殿の 前で ガイドブックを 使う）", name: "閻魔の神殿", near: "§5玉座の 奥に 石段が ある", x: A.x, y: A.y ?? undefined, z: A.z } : null; }
  if (r.st === 2 || r.st === 3) {
    if (!inRuins(p.location)) return { text: "常世へ もどろう（ガイドブック → ストーリー → 常世編）", name: "", near: "", x: null, z: null };
    if (r.st === 3) { const q = at(THRONE); return { text: `${JASHIN}を 倒そう`, name: "邪神の 玉座", near: "§c玉座に 邪神が いる", x: q.x, y: 70, z: q.z }; }
    const b = nearestBoss(p, r); if (!b) return null;
    return { text: `十魔将と 石門の 番兵を 倒そう（${beat(r)}/15）`, name: (b.i < 10 ? `${EPI[b.i]}の 魔将` : EPI[b.i]), near: "§cあたりを うろついて いる", x: b.q.x, y: 70, z: b.q.z };
  }
  if (r.st >= 4 && inRuins(p.location) && canJashin(r)) { const q = at(THRONE); return { text: `${JASHIN}の 影と 再戦できる（1日 1回）`, name: "邪神の 玉座", near: "§c玉座に 影が いる", x: q.x, y: 70, z: q.z }; }   /* 第124版: 常世編を 終えて 常世に いる ときは 帰り方 */ if (r.st >= 4 && inRuins(p.location)) return { text: "元の 世界へ もどろう（ガイドブック → ストーリー →「常世」→「元の 世界へ もどる」）", name: "", near: "", x: null, z: null };   /* 第95版 */
  return null;
});

// ---------- 妙な 男（ルミナ・常世の キャンプ） ----------
const want = { lum: false }, offClean = { npc: false, wild: false };   /* パックが ない ときは 1回 片づけたら 何も しない */
system.runInterval(() => {
  const ow = OW();
  if (!gateOn()) { if (settled()) { const tgs = offClean.npc ? ["mrpg_rstr"] : ["mrpg_rstr", "mrpg_rcamp"]; offClean.npc = true; for (const tg of tgs) try { for (const e of ow.getEntities({ type: NPC, tags: [tg] })) e.remove(); } catch {} } return; }
  const L = lumina(); if (!L) return;
  // ルミナ: 話を 聞いた（st 1）人・もどってきた 人が 近くに いる とき
  let need = false;
  /* 第125版: ルミナの 神官は もう 出ない（前の 版で 立って いた 人は 片づける） */
  let have = []; try { have = ow.getEntities({ type: NPC, tags: ["mrpg_rstr"] }).filter((e) => Math.hypot(e.location.x - L.x, e.location.z - L.z) < 200); } catch {}
  if (!need) { for (const e of have) try { e.remove(); } catch {} return; }
  for (const e of have.slice(1)) try { e.remove(); } catch {}
  if (have.length) return;
  try {
    let pos = null;
    let any = null;
    for (const [dx, dz] of [[5.5, 5.5], [-5.5, 5.5], [5.5, -5.5], [-5.5, -5.5], [0.5, 7.5]]) { const top = ow.getTopmostBlock({ x: Math.floor(L.x + dx), z: Math.floor(L.z + dz) }); if (!top || /water|lava/.test(String(top.typeId))) continue; const c = { x: L.x + dx, y: top.location.y + 1, z: L.z + dz }; any = any || c; if (Math.abs(c.y - (L.y ?? c.y)) <= 3) { pos = c; break; } }
    pos = pos || any; if (!pos) return;   /* 広場の 高さに 近い 所を 優先・なければ 地面の 上 */
    const e = ow.spawnEntity(NPC, pos); setJob(e, 13); e.addTag("mrpg_npc"); e.addTag("mrpg_rstr"); e.nameTag = "§5ぼろぼろの 神官";
  } catch {}
}, 100);

// キャンプの たき火（NPC）
let campNpcHad = true;
system.runInterval(() => {
  if (!gateOn()) return;
  const anyIn = allP().some((p) => { try { return inRuins(p.location); } catch { return false; } });
  if (!anyIn && !campNpcHad) return;   /* だれも いない ときは 1回 片づけたら 休む */
  campNpcHad = anyIn;
  const ow = OW();
  for (let k = 0; k < CAMPS.length; k++) {
    const c = at(CAMPS[k]);
    const near = allP().some((p) => p.dimension.id === "minecraft:overworld" && Math.hypot(p.location.x - c.x, p.location.z - c.z) < 64);
    let have = []; try { have = ow.getEntities({ type: NPC, tags: [`mrpg_rcamp${k}`] }); } catch {}
    if (!near) { for (const e of have) try { e.remove(); } catch {} continue; }
    for (const e of have.slice(1)) try { e.remove(); } catch {}
    if (have.length) continue;
    const info = campInfo(k); if (!info || !info.built || !lotReady(info.x, info.z)) continue;
    try { const e = ow.spawnEntity(NPC, { x: info.x + 2.5, y: info.y, z: info.z + 0.5 }); setJob(e, k === 0 ? 13 : 2); e.addTag("mrpg_npc"); e.addTag("mrpg_rcamp"); e.addTag(`mrpg_rcamp${k}`); e.nameTag = k === 0 ? `§5${SAIL}` : `§6${CAMPS[k].name}の たき火`; } catch {}
  }
}, 60);

NPC_HOOKS.push((p, e) => {
  if (e.hasTag("mrpg_rstr")) { try { e.remove(); } catch {} return true; }
  if (e.hasTag("mrpg_rcamp")) { const k = CAMPS.findIndex((_, i) => e.hasTag(`mrpg_rcamp${i}`)); system.run(() => campMenu(p, Math.max(0, k))); return true; }
  return false;
});

// ---------- 常世へ 行く・キャンプ ----------
const CKEY = (k) => `mrpg:rucamp:${k}`;
export function campInfo(k) { if (isCity()) { const c = CAMPS[k]; return c ? { built: true, x: RU.x + c.dx, y: c.y, z: RU.z + c.dz } : null; } try { const v = world.getDynamicProperty(CKEY(k)); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
/* もどり先: 休む 前の もどり先を 覚えて おき、元の 世界へ 帰ったら 戻す */
function saveSpawn(p) { try { if (p.getDynamicProperty("mrpg:ruSp") !== undefined) return; const sp = p.getSpawnPoint?.(); p.setDynamicProperty("mrpg:ruSp", sp && !inRuins(sp) ? JSON.stringify({ x: sp.x, y: sp.y, z: sp.z, dim: sp.dimension?.id || "minecraft:overworld" }) : "none"); } catch {} }
function restoreSpawn(p) {
  try {
    const v = p.getDynamicProperty("mrpg:ruSp"); if (v === undefined) { const sp = p.getSpawnPoint?.(); if (sp && inRuins(sp)) p.setSpawnPoint(undefined); return; }
    p.setDynamicProperty("mrpg:ruSp", undefined);
    if (v === "none") p.setSpawnPoint(undefined); else { const o = JSON.parse(v); p.setSpawnPoint({ dimension: world.getDimension(o.dim), x: o.x, y: o.y, z: o.z }); }
  } catch {}
}
function leaveRuins(p) { homeTp(p); restoreSpawn(p); }
RU_INN.tp = (p) => { try { const d = load(p); const k = d ? ruOf(d).last || 0 : 0; let I = campInfo(k); if (!I || !lotReady(I.x, I.z)) I = CAMPS.map((_, j) => campInfo(j)).find((c) => c && lotReady(c.x, c.z)); if (!I || !I.built) return false; p.teleport({ x: I.x + 0.5, y: I.y + 0.2, z: I.z + 2.5 }, { dimension: OW() }); return true; } catch { return false; } };
async function goRuins(p, k, first = false) {
  if (typeof world.getDynamicProperty("mrpg:ruCity") !== "number") { await detectCity(p); if (!ok(p)) return; if (RU.pre === null) { try { p.sendMessage("§c常世の 場所を 読みこめなかった。少し たってから もう一度 ためしてください。"); } catch {} return; } }
  { const c0 = at(CAMPS[k] || CAMPS[0]); if (!(await waitLot(p, c0.x, c0.z))) { try { p.sendMessage("§c常世の 街を 作れなかった。少し たってから もう一度 ためしてください。"); } catch {} return; } }
  const c = at(CAMPS[k] || CAMPS[0]);
  const info = campInfo(k);
  const tgt = info && info.built ? { x: info.x + 0.5, y: info.y + 0.2, z: info.z + 2.5 } : { x: c.x + 0.5, y: 200, z: c.z + 0.5 };
  try { p.teleport(tgt, { dimension: OW() }); } catch { return; }
  if (!info || !info.built) try { p.addEffect("slow_falling", 400, { showParticles: false }); p.addEffect("resistance", 200, { amplifier: 4, showParticles: false }); } catch {}   /* 第92版: 空から 降りる ときだけ */
  if (!info || !info.built) { for (let w = 0; w < 300; w++) { buildCamp(k); await new Promise((res) => system.runTimeout(res, 10)); if (!ok(p)) return; if (w % 10 === 9) { try { p.addEffect("slow_falling", 400, { showParticles: false }); p.addEffect("resistance", 200, { amplifier: 4, showParticles: false }); p.teleport(tgt); } catch {} } const I = campInfo(k); if (I && I.built) { try { p.teleport({ x: I.x + 0.5, y: I.y + 0.2, z: I.z + 2.5 }); } catch {} break; } } }
  try { showTitle(p, "§8§l常世", { subtitle: `§7${(CAMPS[k] || CAMPS[0]).name}`, fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 15 }); } catch {}
  if (first) {
    await scene(p, async (C) => {
      const S = C.npc(`§5${SAIL}`, 13, 3.5), M = C.npc("§cムサシ", 19, 2, 1.6);
      act(M, "down"); shake(p, 0.4, 0.4); flash(p, "0 0 0"); await pause(16);
      act(M, 0); await sayL(p, "ムサシ", ["{sweat,汗}いってぇ……石段、長すぎだろ。……ここが 常世か"], "§c");
      act(S, "bow"); lookAt(p, S);
      await sayL(p, SAIL, ["{closed}……帳の 王の 鍔を 持つ 者か。千年ぶりに、舟を 出せる。", "{sad,up}わたしは 常世の 渡し守。昔は 魂を、帳の 王の もとへ 運んで いた。", "{closed}ここは 調査隊の キャンプ跡。たき火の そばなら 休める。休めば そこが あなたの もどる 場所に なる。",
      "{angry,!,low}街は 十の 区に 分かれ、§4十魔将§f が 魂を 一つずつ 抱えて いる。……あなたの 探す 魂も、きっと その 中だ。"], "§5");
      sound(p, "mob.ravager.roar", 0.5); lookUp(p, spot(p, 30, 0, 12) || p.location); fx(p.dimension, "minecraft:white_smoke_particle", p.location, 20, 5); await pause(30);
      /* 第127版: 街を 見上げた ムサシ（「逆か？」は 五冠の 区で 答えが 出る）*/
      act(M, "up"); lookUp(p, spot(p, 24, 10, 16) || p.location); await sayL(p, "ムサシ", ["{shock,?,up}……なあ。なんか 俺らが いた ところと 随分 様子が 違うな。", "{closed}文明が 進んでるっていうか……いや 逆か？ ……あ？ なんだ？"], "§c");
      if (M) { act(M, "point"); sound(p, "random.anvil_land", 0.25, 1.9); }
      await sayL(p, "ムサシ", ["{closed}……コン。……見た目は 新しいのに、壁の 音が 年寄りだ。"], "§c");
      if (M) { act(M, "hold"); fx(p.dimension, "minecraft:basic_flame_particle", M.location, 8, 0.4); }
      await sayL(p, "エンマ", ["……逆か、と 言ったな。小僧。その 耳は 覚えて おけ"], "§4");
      act(M, "hold"); await sayL(p, "ムサシ", ["{closed}……お前は 読む。俺は 聞く。答えは、どっちが 先に 着くかだな。"], "§c");
      act(M, "raise"); await sayL(p, "ムサシ", ["{smile,☆}よし。エンマ、聞いたか？ サヤを 迎えに 行くぞ！"], "§c");
      await sayL(p, "エンマ", ["……ああ。共に 斬ろう"], "§4");
    });
    await notice(p, "追加ストーリー", ["§5§l常世編", "", "§f・§c十魔将と 番兵 15体§f を 倒そう（魔将を 倒すと、抱えて いた 魂が 戻る）（画面 右上の 目標が 近い 配下を 指す）",
      "§f・魔将は Gサイズより ずっと 大きく、§c赤い 頭と 爪§f の 凶暴な 姿。近づいて なぐると 戦いが はじまる", "§f・野生の モンスターは §cLv80〜100§f。見つかると 技で 攻撃して くる",
      "§f・§6キャンプ§f の たき火で 休む（全回復・もどり先）・キャンプ間の ワープ・元の 世界へ もどる", "§f・魔将を 倒すと §5邪神の 痕跡§f と 渡し守の 記録が 手に入る", "§f・§eしゃがんで 歩くと§f 見つかりにくい（しのび足）。キャンプの「魔将の 居場所」で 方角が 分かる", "", "§7（ガイドブック → ストーリー → 常世 で いつでも 行き来できる）"].join("\n"));
  }
}
async function campMenu(p, k) {
  if (busy.has(p.id) || !gateOn()) return;
  const d = load(p); if (!d) return; const r = ruOf(d);
  if (r.st < 2) { await sayL(p, CAMPS[k].name, ["……たき火が ぱちぱちと 鳴って いる。"], "§6"); return; }
  if (!r.camps.includes(k)) { r.camps.push(k); save(p, d); }
  if (r.v95 !== 1) { r.v95 = 1; save(p, d); try { p.sendMessage(NEW95.join("\n")); } catch {} }   /* 第95版: 新しい ことは チャットに（メニューを じゃま しない） */
  for (;;) {
    const d1 = load(p); if (!d1) return; const r1 = ruOf(d1);
    if (r1.st >= 4) { try { if (award(p, d1, "ruinheim")) save(p, d1); } catch {} }
    const body = [`§6§l${CAMPS[k].name}`, `§f魔将・番兵 §c${beat(r1)}§7/15  §f見つけた キャンプ §e${r1.camps.length}§7/${CAMPS.length}`, k === 0 && r1.st >= 3 ? "§5渡し守「痕跡が そろった。街の 真ん中の 記録塔へ……！」" : "§7たき火の そばは 魔物が 近よらない"].join("\n");
    const OPT = [["rest", "§a§l休む\n§8全回復・ここを もどり先に", "i_party"], ["warp", "§e§lワープ\n§8見つけた キャンプへ", "i_walk"], ["shop", "§6§lキャンプの 店\n§8道具・装備・タマゴ・モンスター・預かり所", "i_shop"],
      ["where", "§c§l魔将の 居場所\n§8方角と 距離", "i_fight"], ["lore", "§d§l渡し守の 記録\n§8集めた 記録を 読む", "i_zukan"], ...(k === 0 ? [["sail", "§5§l渡し守と 話す", "i_help"]] : []),
      ...(k === 0 && r1.st >= 4 ? [["sshop", "§5§l渡し守の 店\n§8クリアの お礼・特別な 道具", "i_star"]] : []),
      ["ash", `§d§l灰の 工房\n§8灰晶 ×${Number(r1.ash) || 0} で 特別な 品を 作る`, "i_star"], ["bar", `§b§l結界を 強める\n§8いまの 段階 ${barLv()[k] || 0}/2`, "i_guard"], ["level", "§7§l常世の 強さ\n§8魔物の 数・追いかけ・ブレスと 魔法", "i_skill"],
      ["home", "§b§l元の 世界へ もどる\n§8家へ", "i_back"]];
    const sel = await choose(p, "キャンプ", body, [...OPT.map(([, l, ic]) => [l, ICON(ic)]), ["§7やめる", ICON("i_close")]]);
    const act = sel >= 0 && sel < OPT.length ? OPT[sel][0] : null;
    if (act === "rest") {
      const d2 = load(p); if (!d2) return;
      for (const m of [...d2.party, ...(d2.bench || []), ...d2.box]) { try { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } catch {} }
      const r2 = ruOf(d2); r2.last = k; save(p, d2);
      const I = campInfo(k); saveSpawn(p); try { if (I) p.setSpawnPoint({ dimension: OW(), x: Math.floor(I.x), y: Math.floor(I.y), z: Math.floor(I.z) + 2 }); } catch {}
      try { p.runCommand("camera @s fade time 0.3 0.8 0.5 color 0 0 0"); } catch {}
      sound(p, "random.levelup", 0.9);
      await notice(p, "休む", "§a仲間 全員が 元気に なった。\n§fここが §6もどり先§f に なった（倒れても ここから）。");
    } else if (act === "warp") {
      const d2 = load(p); if (!d2) return; const r2 = ruOf(d2);
      const list = r2.camps.filter((c) => c !== k);
      if (!list.length) { await notice(p, "ワープ", "§7ほかの キャンプを まだ 見つけて いない。§fキャンプは 街の 名所（スタジアム・発電所・観覧車・湖畔 など）に ある。近づくと 見つかる（全${CAMPS.length}か所）。"); continue; }
      const w = await choose(p, "ワープ", "§7どの キャンプへ？", [...list.map((c) => [`§6${CAMPS[c].name}`, ICON("i_walk")]), ["§7やめる", ICON("i_close")]]);
      if (w >= 0 && w < list.length) { await goRuins(p, list[w]); return; }
    } else if (act === "home") {
      if (!(await confirm(p, "元の 世界へ", "§f元の 世界（家）へ もどりますか？\n§7ガイドブック → ストーリー → 常世 で いつでも ここへ 来られる", "もどる", "やめる"))) continue;
      leaveRuins(p); return;
    } else if (act === "lore") await readLore(p);
    else if (act === "ash") await ashShop(p);
    else if (act === "bar") await barrierMenu(p, k);
    else if (act === "level") await RU_HOOK.levelMenu(p);
    else if (act === "where") await notice(p, "魔将の 居場所", bossWhere(p, load(p) || {}));
    else if (act === "sail") await sailTalk(p);
    else if (act === "shop") await campShop(p);
    else if (act === "sshop") await sailShop(p);
    else return;
  }
}
/* 第77版: 魔将の 居場所（方角と 距離） */
const DIR8 = ["東", "南東", "南", "南西", "西", "北西", "北", "北東"];
function bossWhere(p, d) {
  const r = ruOf(d), L = [];
  for (let i = 0; i < 15; i++) {
    const q = at(BSITE[i]), dx = q.x - p.location.x, dz = q.z - p.location.z, dist = Math.round(Math.hypot(dx, dz));
    const dir = DIR8[((Math.round(Math.atan2(dz, dx) / (Math.PI / 4)) % 8) + 8) % 8];
    const lk = !r.b.includes(i) && !tkOpen(r.b, i);   /* 第126版: まだ 順番が 来ない 魔将 */
    L.push({ i, done: r.b.includes(i) || lk, dist, txt: lk ? `§8封 ${EPI[i]} ― 前の 魔将を 倒すと ひらく` : `${r.b.includes(i) ? "§a済" : "§c未"} §f${r.b.includes(i) ? bossName(i) : EPI[i]} §7${r.b.includes(i) ? "" : `― ${dir}へ ${dist}m`}` });
  }
  L.sort((a, b) => (a.done - b.done) || (a.dist - b.dist));
  const T = at(THRONE), tdist = Math.round(Math.hypot(T.x - p.location.x, T.z - p.location.z));
  return [`§c§l魔将の 居場所 §r§7（近い 順・${beat(r)}/15 撃破）`, "", ...L.map((x) => x.txt), "", r.st >= 4 ? `§a済 §5${JASHIN}` : r.st >= 3 ? `§c未 §5${JASHIN} §7― 中央記録塔 ${tdist}m` : "§8？？？"].join("\n");
}
function loreText(d) {
  if (!d) return ""; const r = ruOf(d), n = beat(r);
  const L = [`§d§l渡し守の 記録 §7（${n}/15）`, ""];
  for (let i = 0; i < 15; i++) L.push(i < n ? `§f${i + 1}. ${LORE[i]}` : `§8${i + 1}. ？？？（魔将を 倒すと 読める）`);
  return L.join("\n");
}
/* キャンプの 店（町が 遠いので 道具・装備・タマゴ・預かり所を ここで） */
async function campShop(p) {
  const JOB = [[3, "道具屋", "i_item"], [0, "武器屋", "i_fight"], [1, "防具屋", "i_guard"], [4, "タマゴ屋", "i_egg"], [11, "モンスター屋", "i_zukan"], [6, "預かり屋", "i_box"]];
  const s = await choose(p, "キャンプの 店", "§7行商人が 店を 広げて いる", [...JOB.map(([, n, ic]) => [n, ICON(ic)]), ["§7もどる", ICON("i_back")]]);
  if (s >= 0 && s < JOB.length) await npcMenu(p, JOB[s][0], null);
}
/* 第78版: セイルの 店（クリア後）。万能の神果は 1日 1つまで */
async function sailShop(p) {
  for (;;) {
    const d = load(p); if (!d) return; const r = ruOf(d); if (r.st < 4) return;
    const L = [["s_all4", 500000, true], ["s_all3", 150000, false], ...["s_hp4", "s_atk4", "s_def4", "s_mat4", "s_mdf4", "s_spd4", "s_wpn4", "s_brt4", "s_mp4"].map((x) => [x, 120000, false])].filter(([id]) => ITEMS[id]);
    const s = await choose(p, "渡し守の 店", `§5渡し守「あなたたちに だけ、舟の 蔵を ひらこう。」\n§fお金: ${gold(d.gold)}`, [...L.map(([id, pr, lim]) => [`${ITEMS[id].name} §e${pr.toLocaleString()} タヨ${lim ? (r.sd === dayKey() ? " §8（今日は 売り切れ）" : " §7（1日 1つ）") : ""}`, ICON("i_star")]), ["§7もどる", ICON("i_back")]]);
    if (s < 0 || s >= L.length) return;
    const [id, pr, lim] = L[s];
    const d2 = load(p); if (!d2) return; const r2 = ruOf(d2);
    if (lim && r2.sd === dayKey()) { await notice(p, "渡し守の 店", "§7今日は もう 売り切れだ。また 明日 来て くれ。"); continue; }
    if ((d2.gold || 0) < pr) { await notice(p, "渡し守の 店", "§cお金が たりない。"); continue; }
    d2.gold -= pr; if (lim) r2.sd = dayKey(); save(p, d2); giveItem(p, `mrpg:${id}`, 1); sound(p, "random.orb");
  }
}
async function sailTalk(p) {
  const d = load(p); if (!d) return; const r = ruOf(d);
  const n = beat(r);
  const lines = r.st >= 4 ? ["空が 青い。……こんな 色だったのか。忘れて いたよ。", "邪神の 影は 毎日 記録塔に よみがえる。腕だめしに どうだ？", "舟は また 動いて いる。いつでも 来て くれ。"]
    : r.st >= 3 ? ["痕跡が そろった。街の 真ん中、空の 裂け目の 真下の 記録塔に 玉座が ある。", "邪神は 傷つくと 一度だけ 全ての 傷を 癒やす。それを 越えれば 終わる。……たのむ。"]
    : n >= 10 ? ["あと 少しだ。空の 灰が うすく なって きた。", "魔将は 倒すほど 強い 者が 残る。キャンプで しっかり 休んで くれ。"]
    : n >= 5 ? ["魔将を 倒して くれた ことは、この 世界の 影たちにも 伝わって いる。", "街の 名所ごとに 野営地が ある。見つけたか？ ワープで 行き来が 楽に なる。"]
    : ["この 世界の 魔物は 皆 凶暴だ。でも、そのぶん 強い 仲間に なる。", "魔将は 赤い 頭の 巨大な 魔物だ。近づいて 戦いを 挑めば、普通の 大きさに なる。"];
  await sayL(p, sailN(p), lines, "§5");
}
STORY_EXTRA.push({
  label: "§5§l常世編 §8（追加ストーリー）",
  cond: (p, d) => gateOn() && canStart(d) && ruOf(d).st >= 2,
  run: async (p, d) => {
    const r = ruOf(d), I = inRuins(p.location);
    const sel = await choose(p, "常世編", [`§8§l常世`, `§f魔将・番兵 §c${beat(r)}§7/15  §fキャンプ §e${r.camps.length}§7/${CAMPS.length}${r.st >= 4 ? "  §6★クリア" : ""}`, "§7キャンプの たき火で 休むと、そこへ もどれる"].join("\n"),
      [[I ? "§b§l元の 世界へ もどる" : "§5§l常世へ 行く\n§8最後に 休んだ キャンプへ", ICON("i_walk")], ["§d§l渡し守の 記録", ICON("i_zukan")], ["§l配下の 一覧", ICON("i_fight")], ["§7戻る", ICON("i_back")]]);
    if (sel === 0) { if (I) leaveRuins(p); else await goRuins(p, r.last || 0); }
    else if (sel === 1) await readLore(p);
    else if (sel === 2 && inRuins(p.location)) await notice(p, "魔将の 居場所", bossWhere(p, d));
    else if (sel === 2) await notice(p, "配下の 一覧", [...EPI.map((e, i) => `${r.b.includes(i) ? "§a済" : "§c未"} §f${r.b.includes(i) ? bossName(i) : e}`), "", r.st >= 4 ? `§a済 §5${JASHIN}` : r.st >= 3 ? `§c未 §5${JASHIN}（街の 真ん中の 記録塔）` : "§8？？？"].join("\n"));
  },
});

// ---------- 建物（キャンプ・廃墟・配下の すみか・玉座） ----------
const BKEY = (k) => `mrpg:rub:${k}`;
const built = (k) => { try { return world.getDynamicProperty(BKEY(k)) === true; } catch { return false; } };
const BUILDING = new Set();
/* 街の 中: 空が 見える 地面（屋根の 上は さける）。見つからなければ null */
function openY(x, z) {
  try { const ow = OW(); const t = ow.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) }); if (!t) return null; const y = t.location.y;
    if (/water|lava/.test(t.typeId) || y > 118) return null; return y; } catch { return null; }
}
function openNear(x, z, r = 40) { for (let d = 0; d <= r; d += 4) for (let a = 0; a < 8; a++) { const xx = x + Math.round(Math.cos(a * Math.PI / 4) * d), zz = z + Math.round(Math.sin(a * Math.PI / 4) * d); const y = openY(xx, zz); if (y !== null) return { x: xx, y, z: zz }; if (d === 0) break; } return null; }
function topY(x, z) { if (isCity()) return openY(x, z); try { const ow = OW(); const t = ow.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) }); if (!t) return null; let y = t.location.y; if (/leaves|log/.test(String(t.typeId))) { const g = groundY(ow, x, z, y); if (typeof g === "number") y = g - 1; } return y; } catch { return null; } }
function campCmds(cx, cy, cz, k) {
  const C = [];
  const f = (x1, y1, z1, x2, y2, z2, b, m = "") => C.push(`fill ${cx + x1} ${cy + y1} ${cz + z1} ${cx + x2} ${cy + y2} ${cz + z2} ${b}${m ? " " + m : ""}`);
  f(-7, 1, -7, 7, 8, 7, "air"); f(-7, 0, -7, 7, 0, 7, "coarse_dirt"); f(-6, -3, -6, 6, -1, 6, "dirt");
  f(-1, 0, -1, 1, 0, 1, "cobblestone"); C.push(`setblock ${cx} ${cy + 1} ${cz} campfire`);
  for (const [x, z] of [[-4, -4], [4, -4]]) { f(x - 1, 1, z - 1, x + 1, 2, z + 1, "brown_wool"); f(x, 1, z - 1, x, 2, z - 1, "air"); f(x - 1, 3, z, x + 1, 3, z, "brown_wool"); }
  for (const [x, z] of [[-5, 4], [5, 4], [5, -1], [-5, -1]]) { C.push(`setblock ${cx + x} ${cy + 1} ${cz + z} oak_fence`); C.push(`setblock ${cx + x} ${cy + 2} ${cz + z} lantern`); }
  C.push(`setblock ${cx + 3} ${cy + 1} ${cz + 3} barrel`); C.push(`setblock ${cx - 3} ${cy + 1} ${cz + 3} barrel`);
  C.push(...chestCmds(cx - 3, cy + 1, cz - 2, k === 0 ? 7 : 9, "minecraft:overworld"));
  return C;
}
function towerCmds(cx, cy, cz, seed, chestT) {
  let s = seed >>> 0; const rnd = () => { s = (s * 1103515245 + 12345) >>> 0; return (s >>> 8) / 16777216; };
  const W = 4 + Math.floor(rnd() * 3), H = 12 + Math.floor(rnd() * 22), C = [];
  const mats = ["cracked_stone_bricks", "mossy_stone_bricks", "cracked_deepslate_bricks", "tuff_bricks", "mossy_cobblestone", "cracked_polished_blackstone_bricks"];
  const m1 = mats[Math.floor(rnd() * mats.length)], m2 = mats[Math.floor(rnd() * mats.length)];
  const f = (x1, y1, z1, x2, y2, z2, b, m = "") => C.push(`fill ${cx + x1} ${cy + y1} ${cz + z1} ${cx + x2} ${cy + y2} ${cz + z2} ${b}${m ? " " + m : ""}`);
  f(-W - 2, 1, -W - 2, W + 2, H + 2, W + 2, "air");
  f(-W - 3, -2, -W - 3, W + 3, 0, W + 3, "cobbled_deepslate");
  f(-W, 1, -W, W, H, W, m1, "hollow");
  for (let y = 5; y < H; y += 5) f(-W + 1, y, -W + 1, W - 1, y, W - 1, m2);
  // 崩れ: 上の 角を けずる・壁に 穴
  const cut = Math.floor(H * (0.25 + rnd() * 0.35));
  f(-W, H - cut, rnd() < 0.5 ? -W : 0, rnd() < 0.5 ? 0 : W, H, W, "air");
  for (let n = 0; n < 6; n++) { const y = 2 + Math.floor(rnd() * (H - 4)), side = Math.floor(rnd() * 4), o = Math.floor(rnd() * (2 * W - 2)) - W + 1;
    if (side === 0) f(o, y, -W, o + 1, y + 2, -W, "air"); else if (side === 1) f(o, y, W, o + 1, y + 2, W, "air"); else if (side === 2) f(-W, y, o, -W, y + 2, o + 1, "air"); else f(W, y, o, W, y + 2, o + 1, "air"); }
  f(0, 1, -W, 1, 3, -W, "air");   // 入口
  // 苔と ツタ・くもの巣・がれき
  f(-W - 2, 0, -W - 2, W + 2, 0, W + 2, "moss_block", "replace cobbled_deepslate");
  for (let n = 0; n < 5; n++) { const x = Math.floor(rnd() * (2 * W + 6)) - W - 3, z = Math.floor(rnd() * (2 * W + 6)) - W - 3; C.push(`setblock ${cx + x} ${cy + 1} ${cz + z} ${pick(["cobblestone_wall", "mossy_cobblestone", "cobweb", "dead_bush", "cracked_stone_bricks"])}`); }
  for (let n = 0; n < 4; n++) C.push(`setblock ${cx + Math.floor(rnd() * 3) - 1} ${cy + 2 + Math.floor(rnd() * (H - 4))} ${cz + Math.floor(rnd() * 3) - 1} cobweb`);
  f(-W - 1, 1, -W - 1, -W - 1, Math.min(H, 10), -W - 1, "vine", "replace air");
  if (chestT) C.push(...chestCmds(cx + 1, cy + 1, cz + 1, chestT, "minecraft:overworld"));
  return C;
}
function groundSkin(cx, cy, cz, R = 22) {
  const C = [];
  for (let x = -R; x <= R; x += 11) for (let z = -R; z <= R; z += 11) {
    const b = pick(["coarse_dirt", "podzol", "moss_block", "gravel", "coarse_dirt"]);
    C.push(`fill ${cx + x} ${cy - 3} ${cz + z} ${cx + x + 10} ${cy + 6} ${cz + z + 10} ${b} replace grass_block`);
    C.push(`fill ${cx + x} ${cy - 1} ${cz + z} ${cx + x + 10} ${cy + 7} ${cz + z + 10} air replace short_grass`);
    C.push(`fill ${cx + x} ${cy - 1} ${cz + z} ${cx + x + 10} ${cy + 7} ${cz + z + 10} air replace tall_grass`);
  }
  return C;
}
function buildAt(key, cx, cz, make, onDone) {
  if (built(key) || BUILDING.has(key)) return;
  const cy0 = topY(cx, cz); if (cy0 === null) return;
  BUILDING.add(key);
  const cy = Math.max(cy0, 50);
  const cmds = [...groundSkin(cx, cy, cz), ...make(cy)];
  enqueue(OW(), cmds, () => { BUILDING.delete(key); try { world.setDynamicProperty(BKEY(key), true); } catch {} try { onDone && onDone(cy); } catch {} },
    [{ x: cx - 24, y: cy - 6, z: cz - 24 }, { x: cx + 24, y: cy + 36, z: cz + 24 }], () => BUILDING.delete(key));
}
function buildCamp(k) {
  const c = at(CAMPS[k]);
  buildAt(`camp${k}`, c.x, c.z, (cy) => campCmds(c.x, cy, c.z, k), (cy) => { try { world.setDynamicProperty(CKEY(k), JSON.stringify({ built: true, x: c.x, y: cy + 1, z: c.z })); } catch {} CIC.t = -999; });
}
/* 第127版: キャンプを 見つけた ときの ムサシと エンマ（チャット。街の 名所ごと・常世の 正体の 伏線）。M=ムサシ E=エンマ */
const CAMP_CHAT = {
  "廃スタジアムの 野営地": ["M:……『歓声の 抜け殻』だな。客席が まだ 少し 震えてる", "E:……スタジアム、と 書いてある", "M:書いてあるだけだろ"],
  "記録塔の 手前の 野営地": ["M:あの 塔は『うるせえ 塔』だ。名前が ぎゅうぎゅうに 詰まって、ずっと 鳴ってる", "E:……民の 名と、毎日の 出来事だ。何もかも、な"],
  "黒い 工場の 野営地": ["M:炉が 百は ある。……どれも 冷えてるのに、まだ 打ちかけの 音が 残ってる"],
  "沈んだ 観覧車の 野営地": ["M:『鳴らずの輪』。回るために 作られて、一度も 鳴らずに 止まった 音だ", "E:……観覧車、と 書いてある。人を 乗せて 空を 見せる", "M:……空を 見せる 輪か。名前より、そっちの ほうが いい"],
  "古い 発電所の 野営地": ["M:雷を 閉じこめた 小屋だ。……中で まだ、出口を 探してる 音が する"],
  "沈む 巨塔の 野営地": ["M:この 辺の 時計は みんな『息止めの 針』だ。同じ ところで 息を 止めてる。二十三時 五十九分", "E:……あと 一分で、明日だった"],
  "湖畔の 野営地": ["M:湖の 底に 道が 続いてる。……車輪の 跡だ。馬の 足音は、どこにも ねえ"],
  "さびれた 工場の 野営地": ["M:看板の 字は 読めねえ。エンマ", "E:……『ようこそ』", "M:……叩くと『帰れ』って 鳴るぞ、これ"],
  "砂の 工場の 野営地": ["M:砂に 埋まった 鉄の 箱。中に 椅子が 並んでる。……箱ごと、どこかへ 走る はずだった 音だ"],
  "雪の 崖の 野営地": ["M:雪の 下の 石の 人も、逃げてねえ。……暮らしてる 途中の 音の まま 止まってる", "E:……苦しまずに 止めた。それが、あの 神の『やさしさ』だった"],
};
function campChat(p, d, k) {
  try {
    if (!qs(d).musashiJoin) return;
    const L = CAMP_CHAT[(CAMPS[k] || {}).name]; if (!L) return;
    L.forEach((t, j) => system.runTimeout(() => { try { if (ok(p)) p.sendMessage(t.startsWith("E:") ? `§4エンマ§f「${t.slice(2)}」` : `§cムサシ§f「${t.slice(2)}」`); } catch {} }, 30 + j * 30));
  } catch {}
}
// プレイヤーが 近づいたら 少しずつ 作る（1回に 1か所）
system.runInterval(() => {
  if (!gateOn()) return;
  for (const p of allP()) {
    if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location) || busy.has(p.id)) continue;
    if (RU.pre === null && !DETECTING.on) { detectCity(p); return; }   /* 第76版の ワールドで 中に いた とき */
    const L = p.location, near = (q) => Math.hypot(L.x - q.x, L.z - q.z) < 96;
    if (RU.pre === false && !CB.busy) { const n = nextLot([p]); if (n && n.d < 200) { buildLot(n.di, n.dj, enqueue); return; } }
    if (isCity()) { for (let k = 0; k < RSPOT.length; k++) { const q = at(RSPOT[k]); if (Math.hypot(L.x - q.x, L.z - q.z) < 48 && !built(`c${k}`) && lotReady(q.x, q.z)) { const y = openY(q.x, q.z); if (y !== null) { try { world.setDynamicProperty(BKEY(`c${k}`), true); } catch {} enqueue(OW(), chestCmds(Math.floor(q.x), y + 1, Math.floor(q.z), 8 + (k % 3), "minecraft:overworld"), () => {}); } return; } }
      for (let k = 0; k < CAMPS.length; k++) { const I = campInfo(k); if (I && Math.hypot(L.x - I.x, L.z - I.z) < 40 && !built(`s${k}`) && lotReady(I.x, I.z)) { try { world.setDynamicProperty(BKEY(`s${k}`), true); } catch {} enqueue(OW(), chestCmds(I.x + 3, I.y, I.z - 2, k === 0 ? 7 : 9, "minecraft:overworld"), () => {}); return; } } }
    for (let k = 0; k < CAMPS.length; k++) { const c = at(CAMPS[k]); if (!isCity() && near(c) && !campInfo(k)?.built) { buildCamp(k); return; }
      if (Math.hypot(L.x - c.x, L.z - c.z) < 14) { try { const d = load(p); if (d) { const r = ruOf(d); if (r.st >= 2 && !r.camps.includes(k)) { r.camps.push(k); save(p, d); p.sendMessage(`§6§lキャンプ「${CAMPS[k].name}」を 見つけた！ §r§7（たき火で 休める・ワープ 先に なった）`); sound(p, "random.orb"); campChat(p, d, k); } } } catch {} } }
    if (isCity()) continue;
    for (let i = 0; i < 15; i++) { const q = at(BSITE[i]); if (near(q) && !built(`b${i}`)) { buildAt(`b${i}`, q.x, q.z, (cy) => towerCmds(q.x + 14, cy, q.z + 10, 977 + i * 31, 10)); return; } }
    for (let k = 0; k < RSPOT.length; k++) { const q = at(RSPOT[k]); if (near(q) && !built(`r${k}`)) { buildAt(`r${k}`, q.x, q.z, (cy) => towerCmds(q.x, cy, q.z, 13 + k * 97, k % 3 === 0 ? 8 + (k % 2) : 0)); return; } }
    const T = at(THRONE); if (near(T) && !built("throne")) { buildAt("throne", T.x, T.z, (cy) => throneCmds(T.x, cy, T.z)); return; }
  }
}, 40);
function throneCmds(cx, cy, cz) {
  const C = [], f = (x1, y1, z1, x2, y2, z2, b, m = "") => C.push(`fill ${cx + x1} ${cy + y1} ${cz + z1} ${cx + x2} ${cy + y2} ${cz + z2} ${b}${m ? " " + m : ""}`);
  f(-16, 1, -16, 16, 20, 16, "air"); f(-16, 0, -16, 16, 0, 16, "blackstone"); f(-12, 0, -12, 12, 0, 12, "polished_blackstone_bricks");
  for (const [x, z] of [[-12, -12], [12, -12], [-12, 12], [12, 12], [0, -14]]) f(x, 1, z, x, 12, z, "crying_obsidian");
  f(-3, 1, -12, 3, 3, -9, "obsidian"); f(-1, 4, -11, 1, 6, -11, "obsidian");
  f(-16, 0, -16, 16, 0, 16, "magma_block", "replace blackstone");
  return C;
}

// ---------- 凶暴な 野生（第84版: 屋外・屋上・建物の 中・水辺。毎回 何か所も 試して 湧かせる） ----------
const GY = RU.dy - 41;   /* 街の 地面の ブロックの 高さ（立つ のは GY+1） */
const okSp = (S, s) => !S.hidden && !S.metalmon && !S.fuseonly && !S.famking && S.fam !== "god" && ["F", "E", "D", "C", "B", "A", "S", "SS"].includes(S.rank) && (["A", "S", "SS"].includes(S.rank) || S.wild || S.sea) && s !== "enma" && s !== "musashi";
const WPOOL = ORDER.filter((s) => { const S = SPECIES[s]; return (S.sz === "L" || S.sz === "G") && !S.giant && !S.sea && okSp(S, s); });
const WPOOL_IN = ORDER.filter((s) => { const S = SPECIES[s]; return (S.sz === "S" || S.sz === "M") && !S.giant && !S.sea && okSp(S, s); });
const WPOOL_SEA = (() => { const L = ORDER.filter((s) => { const S = SPECIES[s]; return okSp(S, s) && (S.sea || (S.fam === "aqua" && !S.giant)); }); return L.length ? L : WPOOL; })();
const RW_CAP = 4, RW_IN = 3, RW_W = 2;   /* 第97版: 重いので 少し 減らした（前は 5・4・3） */   /* 1人の まわり（56m）: 外に 巨大 5・建物の 中 4・水辺 3（軽量モードは 3・3・2） */
const caps = () => (isLite() ? { o: 3, i: 2, w: 1 } : { o: RW_CAP, i: RW_IN, w: RW_W });
/* その 列の いちばん 上（道・広場・屋上・水） */
function colInfo(x, z) {
  let t = null; try { t = OW().getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) }); } catch {}
  if (!t) return null; const y = t.location.y, id = String(t.typeId);
  if (/lava|fire|magma/.test(id)) return null;
  if (/water/.test(id)) return { y: y + 1, water: true };
  if (y <= GY + 4) return { y: y + 1, open: true };
  if (y < GY + 140) return { y: y + 1, roof: true };
  return null;
}
/* 建物の 中の 床（上に 何か ある・2マス 空いて いる）。何階でも えらぶ */
function indoorSpot(px, pz, r0 = 4, r1 = 30, tries = 3, py = null) {   /* 第91版: 調べる ブロックは 1回 20こまで（前は 数百） */
  const ow = OW();
  for (let t = 0; t < tries; t++) {
    const a = Math.random() * Math.PI * 2, d = r0 + Math.random() * (r1 - r0), x = Math.floor(px + Math.cos(a) * d), z = Math.floor(pz + Math.sin(a) * d);
    try {
      const top = ow.getTopmostBlock({ x, z }); if (!top || top.location.y <= GY + 3) continue;
      const y0 = Math.min(top.location.y - 2, Math.max(GY + 1, Math.floor((py ?? GY + 1) + Math.random() * 12 - 3)));
      let up1 = null, up0 = null;
      for (let y = y0, k = 0; y >= GY && k < 20; y--, k++) {
        const b = ow.getBlock({ x, y, z }); if (!b) break;
        if (up0 && up1 && up0.isAir && up1.isAir && !b.isAir && !b.isLiquid) return { x: x + 0.5, y: y + 1, z: z + 0.5 };
        up1 = up0; up0 = b;
      }
    } catch {}
  }
  return null;
}
/* プレイヤーから 見える か（目の 高さから 光線） */
function seenBy(p, x, y, z) { try { const a = p.getHeadLocation(), d = { x: x - a.x, y: y + 2 - a.y, z: z - a.z }, n = Math.hypot(d.x, d.y, d.z); if (n < 1) return true; return !OW().getBlockFromRay(a, { x: d.x / n, y: d.y / n, z: d.z / n }, { maxDistance: n, includeLiquidBlocks: false, includePassableBlocks: false }); } catch { return true; } }
/* 広い 所に いるか（まわり 8方向の 地面が 道・広場） */
function openArea(p) { let n = 0; for (let k = 0; k < 8; k += 2) { const a = k * Math.PI / 4, c = colInfo(p.location.x + Math.cos(a) * 12, p.location.z + Math.sin(a) * 12); if (c && (c.open || c.water)) n++; } return n; }
function spawnOut(p, water) {
  let back = null;
  for (let t = 0; t < (water ? 8 : 10); t++) {
    const a = Math.random() * Math.PI * 2, dist = (water ? 8 : 14) + Math.random() * (water ? 40 : 22), x = p.location.x + Math.cos(a) * dist, z = p.location.z + Math.sin(a) * dist;
    if (!water) SPD.out++;
    const q = { x, z }; if (!inRuins(q) || nearCamp(q, 26)) { SPD.rej.camp = (SPD.rej.camp || 0) + 1; continue; }   /* 第91版: 街が まだ 建って いない 所でも 湧く */
    const c = colInfo(x, z); if (!c) { SPD.rej.col = (SPD.rej.col || 0) + 1; continue; }
    if (water) { if (c.water) return spawnRW(pick(WPOOL_SEA), { x, y: c.y - 1.5, z }, "w"); continue; }   /* 水の 中に 出す */
    if (c.water || (c.roof && Math.random() < 0.3)) {   /* 第92版: ビルの 多い 所でも 屋上に 出る */ SPD.rej[c.water ? "water" : "roof"] = (SPD.rej[c.water ? "water" : "roof"] || 0) + 1; continue; }
    if (seenBy(p, x, c.y, z)) { const e = spawnRW(pick(WPOOL), { x, y: c.y, z }); if (e) SPD.outOk++; else SPD.rej.spawnFail = (SPD.rej.spawnFail || 0) + 1; return e; }   /* 見える 所を 先に */
    if (!back) back = { x, y: c.y, z };
  }
  const e = back ? spawnRW(pick(WPOOL), back) : null; if (e) SPD.outOk++; else if (back) SPD.rej.spawnFail = (SPD.rej.spawnFail || 0) + 1; return e;
}
function spawnRW(sid, pos, where) {
  const lv = RM.on ? ri(90, 100) : ri(80, 100);   /* 第95版: 赤い 月の 夜は 強い */
  try {
    const e = OW().spawnEntity(TYPE, pos);
    if (where === "in" || where === true) e.addTag("mrpg_ruinin");
    if (where === "w") { e.addTag("mrpg_ruinwt"); try { e.triggerEvent("mrpg:aqua_on"); } catch {} }   /* 第92版: 水の 中を 泳ぐ */
    e.setDynamicProperty("mrpg:sid", sid); e.setDynamicProperty("mrpg:lv", lv); e.setDynamicProperty("mrpg:q", 1);
    e.addTag("mrpg_ruinw"); try { e.triggerEvent("mrpg:keep"); } catch {}
    setLook(e, sid);
    e.nameTag = `§c${SPECIES[sid].name} Lv${lv} ${SPECIES[sid].rank}`;
    if (where === "w") try { OW().spawnParticle("minecraft:water_splash_particle", pos); OW().runCommand(`particle minecraft:water_splash_particle ${pos.x} ${pos.y + 1} ${pos.z}`); } catch {}
    else if (where !== "in" && where !== true) try { OW().spawnParticle("minecraft:large_explosion", pos); } catch {}
    return e;
  } catch {}
  return null;
}
// ---------- 建物の 中の 宝箱（区画ごとに 12こ まで。置いた だけでは 登録せず、近づいたら 登録して 中身が 決まる） ----------
const RCL = (i) => `mrpg:rcl:${i}`;
const RCLC = new Map();
function rclGet(i) { if (RCLC.has(i)) return RCLC.get(i).map((c) => c.slice()); let v = []; try { const x = JSON.parse(world.getDynamicProperty(RCL(i)) || "[]"); if (Array.isArray(x)) v = x; } catch {} RCLC.set(i, v); return v.map((c) => c.slice()); }
function rclSet(i, L) { try { const v = L.slice(-24); world.setDynamicProperty(RCL(i), JSON.stringify(v)); RCLC.set(i, v.map((c) => c.slice())); } catch {} }
const CH_MAX = () => (isLite() ? 9 : 12);
function placeChest(p) {
  const P0 = lotIdx(p.location.x, p.location.z); if (!P0) return;
  { let n = 0; try { n = Number(world.getDynamicProperty(`mrpg:rich:${P0.i}`)) || 0; } catch {} if (n >= CH_MAX()) return; }
  const q = indoorSpot(p.location.x, p.location.z, 3, 32, 2, p.location.y); if (!q || nearCamp(q, 20)) return;
  const L0 = lotIdx(q.x, q.z); if (!L0) return;   /* 第89版: 箱が ある 区画に 記録する */
  const key = `mrpg:rich:${L0.i}`; let n0 = 0; try { n0 = Number(world.getDynamicProperty(key)) || 0; } catch {}
  if (n0 >= CH_MAX()) return;
  const L = rclGet(L0.i), x = Math.floor(q.x), z = Math.floor(q.z);
  if (L.some((c) => Math.abs(c[0] - x) + Math.abs(c[2] - z) + Math.abs(c[1] - q.y) < 5)) return;
  const t = pick([5, 6, 6, 7, 7, 7, 8, 8, 9]);
  try { OW().runCommand(`setblock ${x} ${q.y} ${z} ${CHEST_TIERS[t - 1].b}`); } catch { return; }
  L.push([x, q.y, z, t]); rclSet(L0.i, L);
  try { world.setDynamicProperty(key, n0 + 1); } catch {}
}
/* 近づいた 宝箱を 登録（開けると 中身が 入る・光る） */
system.runInterval(() => {
  if (!gateOn()) return;
  for (const p of allP()) {
    try {
      if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location)) continue;
      const seenL = new Set();
      for (const [ox, oz] of [[0, 0], [-8, 0], [8, 0], [0, -8], [0, 8], [-8, -8], [8, 8], [-8, 8], [8, -8]]) {   /* 第89版: となりの 区画の 箱も */
      const L0 = lotIdx(p.location.x + ox, p.location.z + oz); if (!L0 || seenL.has(L0.i)) continue; seenL.add(L0.i);
      const L = rclGet(L0.i); if (!L.length) continue; let ch = false;
      for (let k = L.length - 1; k >= 0; k--) {
        const [x, y, z, t] = L[k]; if (Math.abs(x - p.location.x) > 7 || Math.abs(z - p.location.z) > 7 || Math.abs(y - p.location.y) > 5) continue;
        if (PK.has(`${x}|${y}|${z}`)) continue;   /* 壊されて 戻る 途中 */
        let b = null; try { b = OW().getBlock({ x, y, z }); } catch {} if (!b) continue;
        if (BOX_RE.test(String(b.typeId))) registerChest(x, y, z, t, "minecraft:overworld", true);
        L.splice(k, 1); ch = true;
      }
      if (ch) rclSet(L0.i, L);
      }
    } catch {}
  }
}, 20);
// ふつうの 野生・道ばたの 宝箱は 出さない
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => inRuins(p.location) || (prev ? prev(p) : false); });
system.runInterval(() => {
  if (!gateOn()) { if (!settled() || offClean.wild) return; offClean.wild = true; }
  else { const anyIn = allP().some((p) => { try { return inRuins(p.location); } catch { return false; } }); if (!anyIn && offClean.idle) return; offClean.idle = !anyIn; }
  const ow = OW(), ps = allP();
  let list = []; try { list = ow.getEntities({ type: TYPE, tags: ["mrpg_ruinw"], excludeTags: ["mrpg_battle"] }); } catch {}
  for (const e of list) { try { const far = !ps.some((p) => p.dimension.id === "minecraft:overworld" && Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) < 100); if (far || (!gateOn() && settled())) e.remove(); } catch {} }   /* 第92版: 1体 おかしくても 止まらない */
  if (!gateOn()) return;
  list = list.filter((e) => { try { return e.isValid(); } catch { return false; } });
  const C0 = caps();
  for (const p of ps) { try {
    if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location)) continue;
    const d = load(p); if (!d || ruOf(d).st < 2) { SPD.st++; continue; }
    SPD.cyc++;
    /* 第95版: 強さの 設定（1人ずつ）・赤い 月・魔物の 巣 */
    const lv = ruLv(p), ns = nestNear(p.location), mul = [0.6, 1, 1.4][lv[0]] * (RM.on ? 1.3 : 1) * (ns && ns.dead ? 0.4 : 1);
    const C = { o: Math.max(1, Math.round(C0.o * mul) + (ns && !ns.dead ? 2 : 0)), i: Math.max(1, Math.round(C0.i * mul)), w: Math.max(1, Math.round(C0.w * mul)), pk: lv[0] === 0 ? 0 : isLite() ? 2 : 3 };
    if (lv[0] === 0 && Math.random() < 0.35) { if (Math.random() < 0.5) placeChest(p); continue; }
    const nr = list.filter((e) => { try { return Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) < 56; } catch { return false; } });
    let nIn = 0, nW = 0, nP = 0; for (const e of nr) { try { if (e.hasTag("mrpg_rpack")) nP++; else if (e.hasTag("mrpg_ruinin")) nIn++; else if (e.hasTag("mrpg_ruinwt")) nW++; } catch {} }
    let nO = nr.length - nIn - nW;   /* 第97版: 群れも 外の 数に 入る（魔物の 総数を ふやさない） */
    const wide = openArea(p) >= 3;   /* 広い 所に 出たら 一気に 湧く */
    for (let k = 0; k < (wide ? 2 : 1) && nO < C.o; k++) { const e = spawnOut(p, false); if (e) { list.push(e); nO++; } }
    if (wide && nP + 2 <= C.pk && nO + 2 <= C.o && Math.random() < 0.3) spawnPack(p, list);
    for (let k = 0; k < 1 && nIn < C.i; k++) { const q = indoorSpot(p.location.x, p.location.z, 4, 30, 3, p.location.y); if (q && !nearCamp(q, 20)) { const e = spawnRW(pick(WPOOL_IN), q, "in"); if (e) { list.push(e); nIn++; if (Math.random() < 0.4) try { e.addTag("mrpg_ramb"); } catch {} } } }
    for (let k = 0; k < 1 && nW < C.w; k++) { const e = spawnOut(p, true); if (e) { list.push(e); nW++; } }
    if (Math.random() < 0.5) placeChest(p);
  } catch (er) { SPD.err = String(er).slice(0, 80); } }
}, 40);   /* 第87版: 2秒ごと */
/* 第92版: しらべる 用: /scriptevent mq:rudebug で 湧きの ようすを チャットに 出す */
const SPD = { cyc: 0, st: 0, out: 0, outOk: 0, err: "", rej: {} };
system.afterEvents.scriptEventReceive.subscribe(({ id, sourceEntity }) => {
  if (id !== "mq:rudebug") return;
  const n = (() => { try { return OW().getEntities({ type: TYPE, tags: ["mrpg_ruinw"] }).length; } catch { return -1; } })();
  const msg = `§e[常世] 湧き: 回数 ${SPD.cyc}・物語の 段で 止め ${SPD.st}・外 試し ${SPD.out} 成功 ${SPD.outOk}・いる 魔物 ${n}・はねた 理由 ${JSON.stringify(SPD.rej)}${SPD.err ? "・エラー " + SPD.err : ""}・街 ${RU.pre}・ゲート ${gateOn()}`;
  try { (sourceEntity && sourceEntity.sendMessage) ? sourceEntity.sendMessage(msg) : world.sendMessage(msg); } catch {}
  try { const p = sourceEntity; if (p && p.typeId === "minecraft:player") p.sendMessage(ruDiag(p)); } catch {}   /* 第97版: 襲って こない ときの 原因しらべ */
});
function ruDiag(p) {
  const out = [];
  try { out.push(`戦い中 ${fighting(p)}`, `モード ${String(p.getGameMode?.())}`, `キャンプの そば ${nearCamp(p.location, 16)}`, `強さ ${ruLv(p).join("")}`); } catch {}
  try { const r = p.getEffect("resistance"); out.push(`耐性 ${r ? `Lv${r.amplifier + 1} ${Math.round(r.duration / 20)}秒` : "なし"}`); } catch {}
  try { out.push(`体力 ${Math.round(p.getComponent("minecraft:health").currentValue)}`); } catch {}
  try { let n = 0; for (const a of AGGRO.values()) if (a.pid === p.id) n++; out.push(`追って くる ${n}体`); } catch {}
  try { let best = null; for (const e of OW().getEntities({ type: TYPE, tags: ["mrpg_ruinw"], location: p.location, maxDistance: 64 })) { const d = Math.hypot(e.location.x - p.location.x, e.location.z - p.location.z); if (!best || d < best.d) best = { d, big: bigMob(e) }; } out.push(best ? `近い 魔物 ${Math.round(best.d)}m${best.big ? "（大）" : "（小）"}` : "近くに 魔物 なし"); } catch {}
  return `§e[常世 しらべ] ${out.join("・")}`;
}

// ---------- 配下（すみかに 着くと 現れる 巨大な ボス）と 邪神 ----------
// 第84版: すみかの 近く（56m）に 来ると 空から 降って くる →「暴走」の あいだは 戦えず、あたりを 壊しまくる →
// 疲れて 動きが 止まったら 攻撃して 戦える（しばらく 戦わないと また 暴れだす）
const BIG = 1.15;   // ふつうの Gサイズの 1.6倍（邪神は 2倍）
const BST = new Map();   // i → { ph: "rage" | "tired", t, eid }
const RAGE = (i) => (i >= 15 ? 1200 : 900), TIRED = 700;
const siteOf = (i) => (i >= 15 ? at(THRONE) : at(BSITE[i]));
/* 第126版: 常世の 区 i（0〜14）・記録塔（15）の 場所 {x, z}（章ファイル bk_u*.js が 場面の 場所に 使う）*/
export function ruSite(i) { try { return siteOf(i); } catch { return null; } }
/* 第91版: セーブの 読みこみは 1人 2秒に 1回だけ（前は 1秒に 16回 読んで いて 重かった） */
const RC = new Map();
function ruCached(p) { const now = system.currentTick || 0, c = RC.get(p.id); if (c && now - c.t < 40) return c.r; let r = null; try { const d = load(p); if (d) r = ruOf(d); } catch {} RC.set(p.id, { t: now, r }); return r; }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => RC.delete(playerId)); } catch {}
function bossOkFor(p, i) { try { const r = ruCached(p); if (!r) return false; return i >= 15 ? (r.st === 3 || (r.st >= 4 && r.rd !== dayKey())) : r.st >= 2 && !r.b.includes(i) && tkOpen(r.b, i); } catch { return false; } }   /* 第126版: 十冠から 順に */
function bossPlayers(i, rad, anyState = false) {
  const q = siteOf(i), out = [];
  for (const p of allP()) { try { if (p.dimension.id !== "minecraft:overworld" || (!anyState && (fighting(p) || !playing(p)))) continue; const dd = Math.hypot(p.location.x - q.x, p.location.z - q.z); if (dd <= rad && bossOkFor(p, i)) out.push({ p, dd }); } catch {} }
  return out.sort((a, b) => a.dd - b.dd).map((o) => o.p);
}
function bossWanted(i) { return bossPlayers(i, 150, true).length > 0; }   /* 第89版: メニューを 開いて いる 人も いる ことに する */
function spawnBoss(i, p) {
  const s = siteOf(i); let pos = null;
  /* すみかと プレイヤーの あいだ（プレイヤーから 14〜26m）の 地面 */
  for (let t = 0; t < 14 && !pos; t++) {
    const bx = p.location.x + (s.x - p.location.x) * 0.3, bz = p.location.z + (s.z - p.location.z) * 0.3;
    const a = Math.random() * Math.PI * 2, d = 14 + Math.random() * 12, x = bx + Math.cos(a) * d * (t > 6 ? 1 : 0.6), z = bz + Math.sin(a) * d * (t > 6 ? 1 : 0.6);
    if (Math.hypot(x - p.location.x, z - p.location.z) < 10 || nearCamp({ x, z }, 24)) continue;
    const c = colInfo(x, z); if (c && !c.water) pos = { x, y: c.y, z };
  }
  if (!pos) return null;
  const sid = i >= 15 ? JASHIN_SP : BOSS_SP[i];
  try {
    const e = OW().spawnEntity(TYPE, { x: pos.x, y: pos.y + 18, z: pos.z });   /* 空から 降って くる */
    setLook(e, sid, { tint: bossLook(i), sz: "G" });
    e.setDynamicProperty("mrpg:sid", sid); e.setDynamicProperty("mrpg:lv", 100); e.setDynamicProperty("mrpg:rboss", i);
    e.addTag("mrpg_rboss"); try { e.triggerEvent("mrpg:keep"); } catch {} e.addTag(`mrpg_rboss${i}`);
    const bigSz = () => { try { if (e.isValid()) e.setProperty("mrpg:size", Math.min(2500, Math.round(lookOf(sid, { sz: "G" }).size * (i >= 15 ? 1.4 : BIG)))); } catch {} };
    bigSz(); system.runTimeout(bigSz, 2);
    e.nameTag = `§4§l${bossName(i)} §c（暴走中）`;
    const ow = OW();
    for (const q of ow.getPlayers({ location: pos, maxDistance: 80 })) { try { q.onScreenDisplay.setTitle(`§4§l${bossName(i)}`, { subtitle: "§c暴れ狂って いる！\n§c疲れて 動きが 止まるまで しのげ", fadeInDuration: 5, stayDuration: 60, fadeOutDuration: 10 }); q.playSound("mob.wither.spawn", { volume: 1, pitch: i >= 15 ? 0.5 : 0.8 }); q.runCommand("camerashake add @s 0.8 1.5 positional"); } catch {} }
    for (let k = 0; k < 8; k++) try { ow.spawnParticle("minecraft:huge_explosion_emitter", { x: pos.x + ri(-4, 4), y: pos.y + 4 + k * 3, z: pos.z + ri(-4, 4) }); } catch {}
    system.runTimeout(() => { try { if (e.isValid()) { const l = e.location; boom(l.x, l.y, l.z, i >= 15 ? 12 : 10, e.id, true); } } catch {} }, 22);   /* 着地の 衝撃 */
    BST.set(i, { ph: "rage", t: system.currentTick + Math.floor(RAGE(i) * (RM.on ? 1.25 : 1)), eid: e.id, hits: 0 });
    AGGRO.set(e.id, { pid: p.id, until: system.currentTick + 999999, cd: system.currentTick + 40, seen: system.currentTick, rage: true });
    return e;
  } catch {}
  return null;
}
function bossTired(i, e) {
  const st = BST.get(i); if (!st) return;
  st.ph = "tired"; st.t = system.currentTick + TIRED; st.p2 = false; st.wk = 0; AGGRO.delete(e.id);
  try { e.nameTag = `§7§l${bossName(i)} §a（疲れて いる！ 今だ）`; } catch {}
  for (const q of OW().getPlayers({ location: e.location, maxDistance: 80 })) { try { q.onScreenDisplay.setTitle("§a今だ！", { subtitle: `§f${bossName(i)}は 動きが 止まった！ §e攻撃で 戦える`, fadeInDuration: 4, stayDuration: 60, fadeOutDuration: 10 }); q.playSound("random.levelup", { pitch: 0.6, volume: 1 }); } catch {} }
}
function bossRage(i, e, p) {
  const st = BST.get(i); if (!st) return;
  st.ph = "rage"; st.t = system.currentTick + Math.floor(RAGE(i) * 0.6); st.p2 = false; st.wk = 0;
  try { e.nameTag = `§4§l${bossName(i)} §c（暴走中）`; } catch {}
  if (p) AGGRO.set(e.id, { pid: p.id, until: system.currentTick + 999999, cd: system.currentTick + 30, seen: system.currentTick, rage: true });
  for (const q of OW().getPlayers({ location: e.location, maxDistance: 80 })) { try { q.onScreenDisplay.setTitle(" ", { subtitle: `§c${bossName(i)}が また 暴れだした！`, fadeInDuration: 2, stayDuration: 40, fadeOutDuration: 8 }); q.playSound("mob.enderdragon.growl", { pitch: 0.6, volume: 1 }); } catch {} }
}
let bossHad = true;
system.runInterval(() => {
  const anyIn = allP().some((p) => { try { return inRuins(p.location); } catch { return false; } });
  if (!anyIn && !bossHad && (gateOn() || !settled() || offClean.boss)) return;
  if (!gateOn() && settled()) offClean.boss = true;
  bossHad = anyIn;
  const ow = OW(), now = system.currentTick;
  let have = []; try { have = ow.getEntities({ type: TYPE, tags: ["mrpg_rboss"], excludeTags: ["mrpg_battle"] }); } catch {}
  for (let i = 0; i <= 15; i++) {
    const mine = have.filter((e) => e.hasTag(`mrpg_rboss${i}`));
    const wantIt = gateOn() && bossWanted(i);
    if (!wantIt) { if (settled() || gateOn()) for (const e of mine) try { e.remove(); } catch {} BST.delete(i); continue; }
    for (const e of mine.slice(1)) try { e.remove(); } catch {}
    if (!mine.length) {   /* すみかに 着いた（56m）ら 現れる */
      if (FIGHT.has(i)) continue;
      const ps = bossPlayers(i, 56); if (ps.length) spawnBoss(i, ps[0]); else BST.delete(i);
      continue;
    }
    const e = mine[0], q = siteOf(i); let st = BST.get(i);
    if (!st) { st = { ph: "rage", t: now, eid: e.id }; BST.set(i, st); bossTired(i, e); st.t = now + 300; }   /* 読みこみ直した とき */
    const near = bossPlayers(i, 150).filter((p) => { try { return Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) < 72; } catch { return false; } });
    if (st.ph === "rage") {
      if (near.length && (!AGGRO.has(e.id) || !near.some((p) => p.id === AGGRO.get(e.id).pid))) AGGRO.set(e.id, { pid: near[0].id, until: now + 999999, cd: now + 20, seen: now, rage: true });
      bossP2Tick(i, e, st, now, near);
      if (now >= st.t) bossTired(i, e);
    } else {
      try { const l = e.location; ow.spawnParticle("minecraft:basic_smoke_particle", { x: l.x, y: l.y + 3, z: l.z }); ow.spawnParticle("minecraft:water_splash_particle", { x: l.x, y: l.y + 5, z: l.z }); e.teleport(l); } catch {}
      for (const p of near) try { if (Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) < 40) p.onScreenDisplay.setActionBar(`§a${bossName(i)}は 疲れて いる！ §f攻撃で 戦える §7（あと ${Math.max(0, Math.ceil((st.t - now) / 20))}秒）`); } catch {}
      if (now >= st.t) bossRage(i, e, near[0]);
    }
    // すみかから 離れすぎたら もどる
    try { if (!AGGRO.has(e.id) && Math.hypot(e.location.x - q.x, e.location.z - q.z) > 140) { const c = colInfo(q.x, q.z); if (c) e.teleport({ x: q.x + 0.5, y: c.y, z: q.z + 0.5 }); } } catch {}
    try { const h = Math.min(30, (lookOf(e.getDynamicProperty("mrpg:sid") || BOSS_SP[0], { sz: "G" }).size * BIG) / 100 * 1.6); const l = e.location; ow.spawnParticle("minecraft:redstone_ore_dust_particle", { x: l.x, y: l.y + h, z: l.z }); if (i < 10) { ow.spawnParticle("minecraft:basic_smoke_particle", { x: l.x, y: l.y + 0.2, z: l.z }); ow.spawnParticle(TK_PT[i], { x: l.x + 1, y: l.y + 0.3, z: l.z - 1 }); } } catch {}   /* 第126版: 足もとに 影の 粒 */
  }
}, 20);
/* 第126版: 区に 入ると その 魔将の 前ぶれ（2秒に 1回・近くの 区だけ）*/
system.runInterval(() => {
  if (!gateOn()) return;
  for (const p of allP()) {
    try {
      if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location) || fighting(p) || !playing(p) || TK_CALM.has(p.id)) continue;
      const r = ruCached(p); if (!r || r.st < 2 || r.st >= 3) continue;
      for (let i = 0; i < 10; i++) { if (r.b.includes(i) || !tkOpen(r.b, i)) continue; const q = at(BSITE[i]), dd = Math.hypot(p.location.x - q.x, p.location.z - q.z); if (dd < 120) { tkOmen(p, i, dd, q); break; } }
    } catch {}
  }
}, 40);
const FIGHT = new Set();
HIT_HOOKS.push((p, e) => {
  if (!e.hasTag("mrpg_rboss")) return false;
  const i = e.getDynamicProperty("mrpg:rboss");
  if (typeof i !== "number") return false;
  const st = BST.get(i);
  if (st && st.ph === "rage") {   /* 暴走中は 戦えない（はね返される） */
    if ((st.wk || 0) > system.currentTick) { bossStagger(p, e, i, st); return true; }   /* 第95版: 光った 弱点を なぐると よろめく */
    try { p.onScreenDisplay.setActionBar(`§c${bossName(i)}は 暴走中！ §7疲れるまで しのげ（あと ${Math.max(0, Math.ceil((st.t - system.currentTick) / 20))}秒）`); const l = e.location, dx = p.location.x - l.x, dz = p.location.z - l.z, n = Math.hypot(dx, dz) || 1; p.applyKnockback(dx / n, dz / n, 1.8, 0.12); p.playSound("mob.ravager.roar", { pitch: 0.6, volume: 1 }); } catch {}
    return true;
  }
  system.run(() => { bossFight(p, e, i).catch((er) => { if (!/PlayerQuit|InvalidEntity|invalid/i.test(String(er))) console.warn(`[MineQuest] ruins boss: ${er}`); }); });
  return true;
});
const dayKey = () => { const t = new Date(Date.now() + 9 * 3600000); return `${t.getUTCFullYear()}-${t.getUTCMonth() + 1}-${t.getUTCDate()}`; };   /* 日本時間の 日づけ */
const canJashin = (r) => r.st === 3 || (r.st >= 4 && r.rd !== dayKey());
async function bossFight(p, e, i) {
  if (busy.has(p.id) || FIGHT.has(i)) return;
  const d = load(p); if (!d) return; const r = ruOf(d);
  if (i < 15 && r.b.includes(i)) { await notice(p, bossName(i), "§7この 魔将は もう 倒した。§f（ほかの 人が 戦う ために 残って いる）"); return; }
  if (i >= 15 && r.st >= 4 && r.rd === dayKey()) { await notice(p, JASHIN, "§7今日は もう 戦った。§f邪神の 影は 明日 また よみがえる。"); return; }
  if (i >= 15 && !canJashin(r)) { await notice(p, JASHIN, "§7まだ 邪神には 届かない。配下を すべて 倒そう。"); return; }
  const re = i >= 15 && r.st >= 4;   /* 邪神の 再戦 */
  const hadB = busy.has(p.id); busy.add(p.id); { const st0 = BST.get(i); if (st0 && st0.ph === "tired") st0.t = Math.max(st0.t, system.currentTick + 600); }   /* 確認の 間は 攻撃されない・ボスも 疲れた まま */
  const wk = Math.min(2, Number(BST.get(i)?.hits) || 0);   /* 第95版: 弱点を 突いた 回数（HP 1回 -10%） */
  let yes0 = false; try { yes0 = await confirm(p, bossName(i), `§4§l${bossName(i)}§r\n§c赤い 眼が こちらを 見た……！\n§fHP ${i === 0 ? "10,000 ×2" : Math.round((i >= 15 ? 40000 : 20000) * (1 - 0.1 * wk)).toLocaleString()}${wk && i !== 0 ? ` §a（弱点 ${wk}回: -${wk * 10}%）§f` : ""}・${i >= 15 ? "2〜3回行動・HP半分で 一度だけ 全回復" : i < 10 ? `固有の ギミック「${TK_GNAME[i]}」` : "2〜3回行動"}\n§7戦いますか？`, "戦う", "やめる"); } finally { if (!hadB) busy.delete(p.id); }
  if (!yes0) return;
  if (BST.get(i) && BST.get(i).ph !== "tired") { try { p.onScreenDisplay.setActionBar(`§c${bossName(i)}は また 暴れだした！`); } catch {} return; }
  if (!ok(p)) return;
  { const dd = load(p); if (!dd || (i < 15 && ruOf(dd).b.includes(i)) || (i >= 15 && !canJashin(ruOf(dd)))) return; }   /* 確認の 間に もう 倒して いた */
  if (FIGHT.has(i)) { await notice(p, bossName(i), "§7ほかの 人が 戦って いる。終わるまで 待とう。"); return; }
  FIGHT.add(i);
  try { if (ok(e)) e.remove(); } catch {}
  const sid = i >= 15 ? JASHIN_SP : BOSS_SP[i];
  let res = null, fin = null;
  try {
    try { if (i < 15) { const dd = load(p); if (dd && !ruOf(dd).b.includes(i)) await tkPre(p, i); } else if (!re) fin = await tkFinalPre(p); } catch (e2) { console.warn(`[MonsterRPG] tokoyo pre: ${e2}`); }   /* 第106版: 場面も FIGHT の 中（抜けても 次の 人が 挑める） */
    if (!ok(p)) return;
    res = await fight(p, { team: [{ sid, lv: 100, q: 1, plus: 99, sz: "G" }, ...((fin && fin.add) || [])] }, { tier: 2, name: bossName(i), fam: "", npc: null, arena: i >= 15 ? "記録塔の 玉座" : "常世", theme: "hell", ruinsBoss: i, ruinsRe: re, ruinsWeak: wk + ((fin && fin.wk) || 0), bossName: bossName(i), speaker: bossName(i),
      lines: { win: i >= 15 ? "……ばかな……この 世界は……我の……" : "……ガ……ア……", lose: i >= 15 ? "灰に なれ。" : "グルルル……" } });
  } finally { FIGHT.delete(i); BST.delete(i); RC.delete(p.id); }
  if (res !== "win") return;
  const d2 = load(p); if (!d2) return; const r2 = ruOf(d2);
  const got = [];
  if (i < 15) {
    if (r2.b.includes(i)) return;   /* 2回目の ほうびは なし */
    r2.b.push(i);
    d2.gold += 100000; got.push(gold(100000)); r2.ash = (Number(r2.ash) || 0) + 5; got.push("§d灰晶 ×5");
    for (const [id, pr] of [["s_all3", 1], ["s_all4", 0.35], [pick(["s_hp4", "s_atk4", "s_def4", "s_mat4", "s_mdf4", "s_spd4", "s_wpn4", "s_brt4", "s_mp4"]), 0.6]]) if (ITEMS[id] && Math.random() < pr) { giveItem(p, `mrpg:${id}`, 1); got.push(ITEMS[id].name); }
    const n = beat(r2);
    got.push(`§5邪神の 痕跡（記録に 残る ${n}/15）`, `§d神官の 記録 ${n}「${LORE[n - 1]}」`);
    if (n >= 15 && r2.st < 3) { r2.st = 3; got.push("", "§5§l記録塔の 扉が ひらいた……！ §r§f街の 真ん中の 記録塔、§c邪神の 玉座§f へ 行こう"); }
  } else if (r2.st >= 4) {   /* 再戦（1日1回） */
    if (r2.rd === dayKey()) return;
    r2.rd = dayKey(); r2.rw = (r2.rw || 0) + 1; d2.gold += 200000; r2.ash = (Number(r2.ash) || 0) + 5; got.push(gold(200000), "§d灰晶 ×5", `§7再戦 ${r2.rw}回目`);
    for (const [id, n2, pr] of [["s_all3", 2, 1], ["s_all4", 1, 0.3]]) if (ITEMS[id] && Math.random() < pr) { giveItem(p, `mrpg:${id}`, n2); got.push(`${ITEMS[id].name}×${n2}`); }
  } else {
    r2.st = 4; r2.rd = dayKey(); d2.gold += 1000000; r2.ash = (Number(r2.ash) || 0) + 10; got.push(gold(1000000), "§d灰晶 ×10");
    for (const [id, n2] of [["s_all4", 3], ["s_all3", 5]]) if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n2); got.push(`${ITEMS[id].name}×${n2}`); }
    try { award(p, d2, "ruinheim"); } catch {}
    got.push("", "§b灰の 霧が 晴れた。§7渡し守の 店が ひらいた（調査隊の キャンプ）。邪神とは 1日 1回 再戦できる");
  }
  save(p, d2); RC.delete(p.id);
  try { if (i < 15) await tkPost(p, i, beat(ruOf(load(p) || d2))); else if (!re && fin) await tkFinalPost(p, fin); } catch (e3) { console.warn(`[MonsterRPG] tokoyo post: ${e3}`); }   /* 第106版 */
  sound(p, "ui.toast.challenge_complete", 1);
  await notice(p, i >= 15 ? "邪神 撃破！" : i < 10 ? "魔将 撃破！" : "番兵 撃破！", [`§4§l${bossName(i)}§r§f を 倒した！`, "", ...got.map((x) => (x ? `§e${x}` : ""))].join("\n"));
  if (i >= 15 && r2.rw) return;
  if (i >= 15) {
    await scene(p, async (C) => {
      const S = C.npc(`§5${SAIL}`, 13, 3.5, -0.8), M = C.npc("§cムサシ", 19, 2.5, 1.6);
      act(S, "up"); act(M, "up");
      lookUp(p, spot(p, 6, 0, 14) || p.location); flash(p); sound(p, "beacon.activate", 1);
      for (let k = 0; k < 6; k++) { fx(p.dimension, "minecraft:endrod", spot(p, 4, 0, 4 + k) || p.location, 6, 5); await pause(5); }
      act(S, 0); await sayL(p, SAIL, ["{shock,!,up}……影の 根が、切れた。", "{smile,tears,up}魂たちが 帰り道を 思い出して いく。……舟は いらないな。みな、自分の 足で 帰れる"], "§5");
      act(M, 0); await sayL(p, "ムサシ", ["{smile,♪}へっ、帰ろうぜ。……みんな、待ってる"], "§c");
      await sayL(p, "エンマ", ["……帳を、書きなおさねば ならぬ。石の 者の 名は、一人も 載せぬ"], "§4");
    });
    for (const q of allP()) try { q.sendMessage(`§5§l★ ${p.name}が ${JASHIN}を 倒し、常世を 救った！ ★`); } catch {}
    try { await tkStoneBack(p); } catch (e4) { console.warn(`[MonsterRPG] stoneBack: ${e4}`); }   /* 第116版: 石に なった 者たちが 戻る */
  }
}

// ---------- 凶暴な 魔物の 攻撃（第84版: 常世の 巨大な 魔物だけ） ----------
// 近くに 来ると 気づき（壁ごしでも）、建物を 突き破って まっすぐ 来る。型ごとに いろいろな 技を 使う。
// ブロックは 自前で 消す（アイテムは 落ちない）。プレイヤーへの ダメージは 1秒に ハート3まで。キャンプの そばは 安全
const KIND_FX = { breath: "minecraft:basic_flame_particle", magic: "minecraft:dragon_breath_trail" };
const EL_FX = { fire: "minecraft:basic_flame_particle", ice: "minecraft:snowflake_particle", water: "minecraft:water_splash_particle", thunder: "minecraft:electric_spark_particle", dark: "minecraft:soul_particle", wind: "minecraft:white_smoke_particle", earth: "minecraft:falling_dust_dragon_egg_particle", light: "minecraft:endrod" };
const MV_BY = (() => { const o = { phys: [], weapon: [], breath: [], magic: [], special: [] }; for (const [id, m] of Object.entries(MOVES)) if (m && m.kind === "attack" && (m.tier || 0) >= 3 && o[m.cat] && !m.sig && !m.hidden) o[m.cat].push(m.name); return o; })();
function kindOf(sid) { const g = SPECIES[sid]?.grow || {}; const best = [["phys", g.atk || 0], ["weapon", g.wpn || 0], ["breath", g.brt || 0], ["magic", g.mat || 0]].sort((a, b) => b[1] - a[1]); return best[0][0]; }
const elOf = (sid) => { const a = SPECIES[sid]?.aff?.ge || []; return a.find((x) => EL_FX[x]) || "fire"; };
const BMC = new Map();   /* 第99版: 魔物ごとに 1回だけ しらべて 覚える */
const bigMob = (e) => { try { const c = BMC.get(e.id); if (c !== undefined) return c; if (BMC.size > 400) BMC.clear(); const sz = SPECIES[e.getDynamicProperty("mrpg:sid")]?.sz; const v = e.hasTag("mrpg_rboss") || sz === "L" || sz === "G"; BMC.set(e.id, v); return v; } catch { return false; } };   /* S・M は 追って こない */
const AGGRO = new Map();   // entity id → { pid, until, cd, seen, busyT, last }
const SHOTS = [];          // 飛んでいる 弾
/* 第95版: キャンプの 場所と 結界の 強さは 5秒ごとに 読みなおす（前は 呼ぶ たびに 読んで いた） */
const CIC = { t: -999, L: [] };
function campList() { const now = system.currentTick || 0; if (now - CIC.t < 100 && CIC.L.length === CAMPS.length) return CIC.L; const B = barLv(); CIC.L = CAMPS.map((c, k) => { const I = campInfo(k), q = I || at(c); return { x: q.x, z: q.z, b: (Number(B[k]) || 0) * 8 }; }); CIC.t = now; return CIC.L; }
const nearCamp = (l, r = 26) => campList().some((q) => Math.hypot(q.x - l.x, q.z - l.z) < r + q.b);
const bodyH = (e) => { let h = 1.4; try { const s = e.getProperty("mrpg:size"); if (typeof s === "number") h = Math.min(30, s / 100 * 1.4); } catch {} return h; };
const eye = (e) => { const l = e.location, h = bodyH(e); return { x: l.x, y: l.y + h * 0.8, z: l.z }; };
function sees(e, p) {   // 魔物から プレイヤーが 見えるか
  try { const a = eye(e), b = p.getHeadLocation(), d = { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z }, n = Math.hypot(d.x, d.y, d.z); if (n < 1) return true;
    const hit = OW().getBlockFromRay(a, { x: d.x / n, y: d.y / n, z: d.z / n }, { maxDistance: n, includeLiquidBlocks: false, includePassableBlocks: false }); return !hit; } catch { return true; }
}
/* 1人あたり 20tick で ハート3（体力6）まで（いくつ 攻撃が 重なっても） */
const HB = new Map();
system.runInterval(() => { const now = system.currentTick; for (const [k, L] of HB) if (!L.length || now - L[L.length - 1].t > 200) HB.delete(k); }, 600);
function capDmg(p, dmg) { const now = system.currentTick || 0, L = (HB.get(p.id) || []).filter((h) => now - h.t < 20); const used = L.reduce((a, h) => a + h.v, 0); const d = Math.max(0, Math.min(dmg, 6 - used)); if (d > 0) L.push({ t: now, v: d }); HB.set(p.id, L); return d; }
/* 第96版: 防具（ダイヤ・ネザライトと 防護の エンチャント）で ほぼ 0 に なって いたので、決めた 量を そのまま 体力から 引く。
   当たった 見た目（赤く 光る・音）は applyDamage で 出し、足りない ぶんを 体力から 引く。耐性の 効果だけは 効く（レベル5以上は 無敵） */
function hurtP(p, dmg, opt) {
  if (fighting(p) || !playing(p) || nearCamp(p.location, 16)) return;
  let rs = 0; try { const r = p.getEffect("resistance"); if (r) { if (r.amplifier >= 4) return; rs = 0.2 * (r.amplifier + 1); } } catch {}
  const d = capDmg(p, dmg * (1 - rs)); if (d <= 0) return;
  let hc = null, before = 0; try { hc = p.getComponent("minecraft:health"); before = hc.currentValue; } catch {}
  try { p.applyDamage(d, opt); } catch { try { p.applyDamage(d); } catch {} }
  if (!hc) return;
  try { const want = before - d, now = hc.currentValue; if (now > 0 && now > want) { if (want <= 0) p.kill(); else hc.setCurrentValue(want); } } catch {}
}
const playing = (p) => { try { const m = String(p.getGameMode?.() ?? "survival").toLowerCase(); return m !== "creative" && m !== "spectator"; } catch { return true; } };
const softFall = (p) => { try { p.addEffect("slow_falling", 70, { amplifier: 0, showParticles: false }); } catch {} };
const shake = (p, a, t) => { try { p.runCommand(`camerashake add @s ${a} ${t} positional`); } catch {} };
const kb = (p, from, h, v) => { try { const dx = p.location.x - from.x, dz = p.location.z - from.z, n = Math.hypot(dx, dz) || 1; p.applyKnockback(dx / n, dz / n, h, v); } catch {} };
/* ---- ブロックを 消す（fill air なので アイテムは 落ちない）。宝箱は 元に もどす ---- */
const CMD = (c) => { try { OW().runCommand(c); return true; } catch { return false; } };
/* 壊す コマンドは 1tick に 消す ブロック数を 決めて 少しずつ（固まらない ように） */
const RQ = [];   /* 文字列（コマンド）か 関数。fill は 実行の 直前にも 壊して よいか 確かめる */
const FILL_RE = /^fill (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) air$/;
const volOf = (c) => { if (typeof c !== "string") return 1; const m = c.match(/^fill (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+)/); return m ? (Math.abs(m[4] - m[1]) + 1) * (Math.abs(m[5] - m[2]) + 1) * (Math.abs(m[6] - m[3]) + 1) : 1; };
const QCMD = (c) => { RQ.push(c); return true; };
/* 第97版: 壊す コマンドは 1秒に 30こ（軽量 15こ）まで。こえた ぶんは 壊さない（見た目と 音は そのまま） */
const QR = { t: -999, n: 0 };
function qRoom(k) { const t = system.currentTick || 0; if (t - QR.t >= 20) { QR.t = t; QR.n = 0; } if (QR.n + k > (isLite() ? 15 : 30)) return false; QR.n += k; return true; }
const qFull = () => RQ.length > (isLite() ? 300 : 800);
function runQ(c, ps) {
  if (typeof c === "function") { try { c(); } catch {} return; }
  const m = c.match(FILL_RE);
  if (m) {   /* 壊す 直前: キャンプ・戦って いる 人の そばなら やめる。上に いる 人は ゆっくり 落ちる */
    const [x0, y0, z0, x1, y1, z1] = m.slice(1).map(Number), cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    if (nearCamp({ x: cx, z: cz }, 18)) return;
    for (const p of ps) { try { const l = p.location, nearX = l.x >= Math.min(x0, x1) - 3 && l.x <= Math.max(x0, x1) + 4 && l.z >= Math.min(z0, z1) - 3 && l.z <= Math.max(z0, z1) + 4; if (fighting(p) && Math.hypot(l.x - cx, l.z - cz) < 24) return;  } catch {} }
    LB.t = system.currentTick || 0;
  }
  CMD(c);
}
system.runInterval(() => {
  if (!RQ.length) return;
  const B = isLite() ? 500 : [1200, 700, 400][heavy()] || 400;   /* 第97版: 光の 計算が 重いので 半分に */ let spent = 0, ps = null;   /* 第91版: 1tick に 消す 量を 少なく（光の 計算で 重く ならない ように） */
  while (RQ.length) { const v = volOf(RQ[0]); if (spent && spent + v > B) break; spent += v; if (!ps) ps = allP(); runQ(RQ.shift(), ps); }
}, 1);
function canBreak(x, y, z, r) {
  if (qFull() || !inRuins({ x, z }) || nearCamp({ x, z }, 22 + r)) return false;
  /* 第89版: プレイヤーが 置いた 入れ物の そばは 壊さない（中身が ふえたり 消えたり しない） */
  try { const seen = new Set(); for (const [ox, oz] of [[0, 0], [-r, -r], [r, r], [-r, r], [r, -r]]) { const L0 = lotIdx(x + ox, z + oz); if (!L0 || seen.has(L0.i)) continue; seen.add(L0.i); for (const c of rpbGet(L0.i)) if (Math.abs(c[0] - x) <= r + 2 && Math.abs(c[1] - y) <= r + 2 && Math.abs(c[2] - z) <= r + 2) return false; } } catch {}
  try { const R2 = r * 2 + 8; if (allP().some((p) => Math.abs(p.location.x - x) < R2 && Math.abs(p.location.z - z) < R2 && fighting(p))) return false; } catch {}
  return true;
}
function keepChests(x, y, z, r) {
  const out = []; try { for (const c of chestsNear("minecraft:overworld", x, y, z, r)) out.push({ ...c, b: CHEST_TIERS[Math.max(1, Math.min(10, c.t)) - 1].b }); } catch {}
  const seenL = new Set();
  for (const ox of [-r, 0, r]) for (const oz of [-r, 0, r]) { const L0 = lotIdx(x + ox, z + oz); if (!L0 || seenL.has(L0.i)) continue; seenL.add(L0.i);
    try { for (const c of rclGet(L0.i)) if (Math.abs(c[0] - x) <= r && Math.abs(c[1] - y) <= r && Math.abs(c[2] - z) <= r) out.push({ x: c[0], y: c[1], z: c[2], b: CHEST_TIERS[c[3] - 1].b }); } catch {}
  }
  return saveK(out);
}
/* 箱は 壊す 前に 中身ごと 写して（structure）、壊した あとに 戻す */
/* まだ 戻して いない 箱は 写しを 使い回す（壊れた あとの 空気を 写さない） */
let KN = 0; const PK = new Map();   // "x|y|z" → { n, ref }
function saveK(K) {
  for (const c of K) {
    const k = `${c.x}|${c.y}|${c.z}`, old = PK.get(k);
    if (old) { old.ref++; c.n = old.n; c.k = k; continue; }
    c.n = `mrpg_k${KN++ % 100000}`; c.k = k;
    if (CMD(`structure save ${c.n} ${c.x} ${c.y} ${c.z} ${c.x} ${c.y} ${c.z} false memory true`)) { PK.set(k, { n: c.n, ref: 1 }); CHEST_PEND.add(`minecraft:overworld|${k}`); } else c.n = null;
  }
  return K;
}
const restore = (K) => { for (const c of K) {
  if (c.n) { QCMD(`structure load ${c.n} ${c.x} ${c.y} ${c.z}`); const k = c.k, cx = c.x, cy = c.y, cz = c.z; QCMD(() => { const o = PK.get(k); if (!o) return; if (--o.ref <= 0) { PK.delete(k); CHEST_PEND.delete(`minecraft:overworld|${k}`); CMD(`structure delete ${o.n}`);
    /* 第89版: 戻す 間に 開けられた 箱（記録が ない）は 空の 箱を 残さない */
    let known = chestsNear("minecraft:overworld", cx, cy, cz, 0).length > 0; if (!known) { const L0 = lotIdx(cx, cz); if (L0) known = rclGet(L0.i).some((q) => q[0] === cx && q[1] === cy && q[2] === cz); }
    if (!known) CMD(`setblock ${cx} ${cy} ${cz} air`); } }); }
  else if (c.b) QCMD(`setblock ${c.x} ${c.y} ${c.z} ${c.b}`); } };
/* プレイヤーが 常世に 置いた 入れ物を おぼえる（壊れない ように） */
const CONT = /chest|barrel|shulker|furnace|smoker|hopper|dispenser|dropper|brewing|lectern|crafter|decorated_pot|chiseled_bookshelf|jukebox|bed|sign|banner|frame/;
const RPB = (i) => `mrpg:rpb:${i}`;
const RPBC = new Map();   /* 第99版: 読んだ 記録を 覚える（書く ときに 一緒に） */
function rpbGet(i) { if (RPBC.has(i)) return RPBC.get(i).slice(); let v = []; try { const x = JSON.parse(world.getDynamicProperty(RPB(i)) || "[]"); if (Array.isArray(x)) v = x; } catch {} RPBC.set(i, v); return v.slice(); }
try { world.afterEvents.playerPlaceBlock.subscribe((ev) => { try { const b = ev.block; if (!b || b.dimension.id !== "minecraft:overworld" || !inRuins(b.location) || !CONT.test(String(b.typeId))) return; const L0 = lotIdx(b.location.x, b.location.z); if (!L0) return; const L = rpbGet(L0.i); L.push([b.location.x, b.location.y, b.location.z]); world.setDynamicProperty(RPB(L0.i), JSON.stringify(L.slice(-200))); RPBC.set(L0.i, L.slice(-200)); } catch {} }); } catch {}
function carve(x, y, z, r) {
  LB.t = system.currentTick || 0;   /* だいたい 球の 形に 消す */
  const X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z); r = Math.max(1, Math.min(14, Math.round(r)));
  if (!canBreak(x, y, z, r)) return false;
  if (!qRoom(3)) return false;
  const K = keepChests(X, Y, Z, r + 1);
  /* 第97版: 球の かわりに 十字の 箱 3つ（前は 高さ 1段ごとに 2つずつ ＝ 20こ 以上の コマンドで 重かった） */
  const h = Math.max(1, Math.round(r * 0.6)), y0 = Math.max(GY - 1, Y - h), y1 = Math.min(318, Y + h);
  QCMD(`fill ${X - r} ${y0} ${Z - h} ${X + r} ${y1} ${Z + h} air`);
  QCMD(`fill ${X - h} ${y0} ${Z - r} ${X + h} ${y1} ${Z + r} air`);
  QCMD(`fill ${X - h} ${Math.max(GY - 1, Y - r)} ${Z - h} ${X + h} ${Math.min(318, Y + r)} ${Z + h} air`);
  restore(K); return true;
}
function carveBox(x0, y0, z0, x1, y1, z1, minY = GY + 1) {
  LB.t = system.currentTick || 0;   /* 箱の 形に 消す（体当たり・突進） */
  const a = { x: Math.floor(Math.min(x0, x1)), y: Math.floor(Math.max(minY, Math.min(y0, y1))), z: Math.floor(Math.min(z0, z1)) }, b = { x: Math.floor(Math.max(x0, x1)), y: Math.floor(Math.min(318, Math.max(y0, y1))), z: Math.floor(Math.max(z0, z1)) };
  if (b.y < a.y) return false;
  const cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2, cz = (a.z + b.z) / 2, r = Math.max(b.x - a.x, b.y - a.y, b.z - a.z) / 2;
  if (!canBreak(cx, cy, cz, r)) return false;
  if (!qRoom(1)) return false;
  const K = keepChests(Math.round(cx), Math.round(cy), Math.round(cz), Math.ceil(r) + 1);
  QCMD(`fill ${a.x} ${a.y} ${a.z} ${b.x} ${b.y} ${b.z} air`); restore(K); return true;
}
/* 爆発（見た目と 音は 派手に。ブロックは 自前で 消す） */
function boom(x, y, z, power, srcId, big, col) {
  const l = { x, y, z }, ow = OW(); if (!inRuins(l)) return; col = col || ECOL.fire;
  const lite = isLite(), r = Math.max(1.5, power * (lite ? 0.42 : 0.55));
  let calm = nearCamp(l, 16 + r);
  try { if (!calm && ow.getPlayers({ location: l, maxDistance: r * 2 + 8 }).some((p) => fighting(p))) calm = true; } catch {}
  try {
    ow.spawnParticle(r >= 4 ? "minecraft:huge_explosion_emitter" : "minecraft:large_explosion", l);
    if (!lite) for (let k = 0; k < Math.min(6, Math.floor(r)); k++) ow.spawnParticle("minecraft:large_explosion", { x: x + (Math.random() * 2 - 1) * r, y: y + Math.random() * r, z: z + (Math.random() * 2 - 1) * r });
    /* 色つきの 火柱・衝撃の 輪・火の粉 */
    fxp("boom", l, col, Math.min(6, r * 0.7)); fxp("shock", { x, y: y + 0.3, z }, col, Math.min(10, r * 1.2)); fxp("pillar", l, col, Math.min(5, r * 0.5));
    if (!lite) { fxp("flames", l, col, Math.min(5, r * 0.6)); fxp("sparks", { x, y: y + 1, z }, col, Math.min(4, r * 0.5)); if (r >= 4) for (let k = 0; k < 3; k++) fxp("flames", { x: x + (Math.random() * 2 - 1) * r, y: y + Math.random() * 2, z: z + (Math.random() * 2 - 1) * r }, col, 2); }
    for (const p of ow.getPlayers({ location: l, maxDistance: 64 })) { p.playSound("random.explode", { location: l, volume: Math.min(4, 1 + r / 3), pitch: big ? 0.55 : 0.8 }); const dd = Math.hypot(p.location.x - x, p.location.z - z); if (dd < r * 3 + 10) shake(p, Math.min(1.5, 0.25 + r / 10), 0.6); }
  } catch {}
  if (calm) return;
  carve(x, y, z, r);
  for (const p of ow.getPlayers({ location: l, maxDistance: r + 4 })) {
    try { if (fighting(p) || !playing(p)) continue; const dd = Math.hypot(p.location.x - x, p.location.y + 1 - y, p.location.z - z); if (dd > r + 4) continue;
      hurtP(p, Math.max(2, Math.min(6, Math.round(6 * (1 - dd / (r + 5)) + 1))), { cause: "entityExplosion" }); kb(p, l, 0.6 + r * 0.06, 0.1); } catch {}
  }
  if (!lite && r >= 4) system.runTimeout(() => collapse(x, y, z, Math.min(5, power)), 8);
}
/* 崩落: 大きな 爆発で 下が 抜けた ビルは 上が くずれ落ち、がれきが 積もる */
const RUBBLE = ["cobblestone", "mossy_cobblestone", "cracked_stone_bricks", "andesite"];   /* 第92版: 砂利は 落ちて 重く なるので 使わない */
function collapse(x, y, z, power) {
  const ow = OW(), X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z);
  let above = 0;
  for (let k = 3; k <= 30; k += 3) { try { const b = ow.getBlock({ x: X, y: Y + k, z: Z }); if (b && !b.isAir && !b.isLiquid) above++; } catch {} }
  if (above < 3) return;   // 上に 建物が ない
  const r = Math.min(3, Math.floor(power * 0.7)), top = Y + Math.min(40, 6 + above * 4);
  try { for (const p of ow.getPlayers({ location: { x, y: Y + (top - Y) / 2, z }, maxDistance: (top - Y) / 2 + r + 4 })) if (Math.abs(p.location.x - X) <= r + 3 && Math.abs(p.location.z - Z) <= r + 3 && p.location.y > Y + 6) softFall(p);   /* 高い 所から 落ちる ときだけ */ } catch {}
  if (!carveBox(X - r, Y + 1, Z - r, X + r, top, Z + r)) return;
  try {
    for (let k = 0; k < 10; k++) { const gx = X + ri(-r - 2, r + 2), gz = Z + ri(-r - 2, r + 2), t = ow.getTopmostBlock({ x: gx, z: gz }); if (t && t.location.y < Y + 3 && !ow.getPlayers({ location: { x: gx, y: t.location.y + 1, z: gz }, maxDistance: 1.5 }).length) QCMD(`setblock ${gx} ${t.location.y + 1} ${gz} ${pick(RUBBLE)}`); }
    for (let k = 0; k < 6; k++) ow.spawnParticle("minecraft:large_explosion", { x: X + ri(-r, r), y: Y + k * 5, z: Z + ri(-r, r) });
    for (const p of ow.getPlayers({ location: { x, y, z }, maxDistance: 48 })) { p.playSound("random.explode", { pitch: 0.5, volume: 1 }); p.playSound("dig.stone", { pitch: 0.6, volume: 1 }); try { p.onScreenDisplay.setActionBar("§7ゴゴゴ……建物が 崩れ落ちた！"); } catch {} }
  } catch {}
}
function shootAt(e, from, to, o) {   /* 弾: o = { fx, power, sp, big, magic, life, col } */
  const d = { x: to.x - from.x, y: to.y - from.y, z: to.z - from.z }, n = Math.hypot(d.x, d.y, d.z) || 1, sp = o.sp || 1;
  const col = o.col || (o.magic ? ECOL.magic : ECOL.fire);
  SHOTS.push({ x: from.x, y: from.y, z: from.z, vx: d.x / n * sp, vy: d.y / n * sp, vz: d.z / n * sp, life: o.life || 90, fx: o.fx, power: o.power, big: !!o.big, src: e.id, magic: !!o.magic, pierce: o.pierce || 0, col, t: 0 });
  if (o.big) { beam(from, to, col, 2.2); fxp("flames", from, col, 2.2); }   /* 口から 太い 火線 */
}
const elFx = (sid) => EL_FX[elOf(sid)] || KIND_FX.breath;
const METEORS = [];   /* 魔法陣: 足もとに 出て 少し あとで 爆発 */
function meteor(at0, power, t = 20, fx, col) { METEORS.push({ x: at0.x, y: at0.y, z: at0.z, t, power, fx, col: col || ECOL.magic }); }
const PASS = /air|grass|fern|flower|vine|carpet|snow_layer|deadbush|torch|button|rail|sapling|moss_carpet|tall|bush|roots|seagrass|kelp|lily|dry/;
system.runInterval(() => {   // 弾と 魔法陣を 動かす（毎 tick）
  for (let i = METEORS.length - 1; i >= 0; i--) { const m = METEORS[i]; m.t--;
    if (m.t % 6 === 0) { const r = Math.min(6, m.power * 0.45); fxp("circle", { x: m.x, y: m.y + 0.15, z: m.z }, m.col, r); try { OW().spawnParticle(m.fx || "minecraft:dragon_breath_trail", { x: m.x, y: m.y + 0.3 + (m.t % 8), z: m.z }); } catch {} }
    if (m.t === 6) beam({ x: m.x, y: m.y + 24, z: m.z }, { x: m.x, y: m.y, z: m.z }, m.col, 3);   /* 空から 光の 柱が 落ちて くる */
    if (m.t <= 0) { METEORS.splice(i, 1); fxp("pillar", { x: m.x, y: m.y, z: m.z }, m.col, 4); boom(m.x, m.y + 0.5, m.z, m.power, null, true, m.col); } }
  if (!SHOTS.length) return;
  const ow = OW();
  for (let i = SHOTS.length - 1; i >= 0; i--) {
    const s = SHOTS[i]; let hit = false;
    for (let k = 0; k < 3 && !hit; k++) {
      s.x += s.vx; s.y += s.vy; s.z += s.vz;
      try { const b = ow.getBlock({ x: Math.floor(s.x), y: Math.floor(s.y), z: Math.floor(s.z) }); if (!b) { hit = true; s.dead = true; break; }
        if (!b.isAir && !b.isLiquid && !PASS.test(b.typeId)) { if (s.pierce > 0) { s.pierce--; carve(s.x, s.y, s.z, 2); } else hit = true; } } catch { hit = true; s.dead = true; }
      if (!hit) { const rr = s.big ? 2.4 : 1.6; for (const q of allP()) { try { const l = q.location; if (Math.abs(l.x - s.x) < rr && Math.abs(l.z - s.z) < rr && Math.hypot(l.x - s.x, l.y + 0.9 - s.y, l.z - s.z) < rr) { hit = true; break; } } catch {} } }
    }
    s.t++;
    try { ow.spawnParticle(s.fx, { x: s.x, y: s.y, z: s.z }); if (!isLite() || s.t % 2 === 0) fxp("flames", { x: s.x, y: s.y, z: s.z }, s.col, s.big ? 1.8 : 1.1); if ((s.big || s.magic) && s.t % 3 === 0) fxp("orb", { x: s.x, y: s.y, z: s.z }, s.col, s.big ? 2.4 : 1.5); } catch {}
    if (hit || --s.life <= 0) { SHOTS.splice(i, 1); if (!s.dead) boom(s.x, s.y, s.z, s.power, s.src, s.big, s.col); }
  }
}, 1);
/* ---- 派手な エフェクト（パックの 色つき パーティクル） ---- */
const ECOL = { fire: [1, 0.42, 0.1], ice: [0.55, 0.88, 1], water: [0.25, 0.55, 1], thunder: [1, 0.95, 0.3], dark: [0.62, 0.28, 1], wind: [0.45, 1, 0.6], earth: [0.8, 0.58, 0.32], light: [1, 0.95, 0.68], magic: [0.75, 0.45, 1], slash: [0.85, 0.95, 1], roar: [1, 0.82, 0.55], blood: [1, 0.15, 0.1] };
const colOf = (sid) => ECOL[elOf(sid)] || ECOL.fire;
const LITE_THIN = new Set(["flames", "sparks", "smoke", "shards", "orb", "swirl", "slash"]);
const FXB = { t: -1, n: 0 };   /* 第97版: 1tick に 出す 自前の 粒は 24こ（軽量 12こ）まで */
function fxp(id, l, col = ECOL.fire, sc = 1, extra) {
  { const t = system.currentTick || 0; if (t !== FXB.t) { FXB.t = t; FXB.n = 0; } if (++FXB.n > (isLite() ? 12 : 24)) return; }
  if (isLite() && LITE_THIN.has(id) && Math.random() < 0.5) return;   /* 軽量モードは 細かい 粒を 半分に */
  try { const m = new MC.MolangVariableMap(); m.setColorRGB("variable.color", { red: col[0], green: col[1], blue: col[2] }); m.setFloat("variable.scale", sc); if (extra) extra(m); OW().spawnParticle(`mrpg:${id}`, l, m); } catch {}
}
function beam(from, to, col, sc) {   /* 太い 火線（ブレスの 流れ） */
  const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z, d = Math.max(0.5, Math.hypot(dx, dy, dz));
  fxp("stream", from, col, sc, (m) => { try { m.setVector3("variable.dir", { x: dx / d, y: dy / d, z: dz / d }); } catch {} m.setFloat("variable.dist", Math.min(30, d)); });
}
/* ---- 動き: 地面を 走って 近づく。前が ふさがって いたら 体の 大きさの 穴を あけて 突き進む ---- */
function bodyBox(e) { const h = Math.max(3, Math.min(14, Math.round(bodyH(e) + 1))); return { h, w: Math.max(1, Math.min(4, Math.round(h * 0.3))) }; }
function plowAt(e, x, y, z, loud) {   /* 体の 大きさの 穴を あける */
  const { h, w } = bodyBox(e);
  if (!carveBox(x - w, y, z - w, x + w, y + h - 1, z + w)) return false;
  if (loud) try { const ow = OW(); ow.spawnParticle("minecraft:large_explosion", { x, y: y + h / 2, z }); fxp("shards", { x, y: y + h / 2, z }, ECOL.earth, 1.6); for (const q of ow.getPlayers({ location: { x, y, z }, maxDistance: 40 })) { q.playSound("random.explode", { location: { x, y, z }, volume: 0.9, pitch: 1.2 }); q.playSound("dig.stone", { location: { x, y, z }, volume: 1, pitch: 0.5 }); } } catch {}
  return true;
}
function stepToward(e, p, speed, a, now, tgt) {
  const T = tgt || p.location, l = e.location, dx = T.x - l.x, dz = T.z - l.z, d = Math.hypot(dx, dz) || 1, ow = OW(), bh = Math.min(9, Math.round(bodyH(e)));
  const roomy = (x, y, z) => { for (let k = Math.min(bh - 1, 3); k < Math.min(bh, 4); k += 2) { try { const b = ow.getBlock({ x: Math.floor(x), y: y + k, z: Math.floor(z) }); if (b && !b.isAir && !b.isLiquid && !PASS.test(b.typeId)) return false; } catch {} } return true; };   /* 体の 高さぶん 空いて いるか */
  const tryAt = (ux, uz, fall) => {
    const nx = l.x + ux * speed, nz = l.z + uz * speed;
    for (const up of [0, 1, -1]) { try { const fy = Math.floor(l.y) + up; const feet = ow.getBlock({ x: Math.floor(nx), y: fy, z: Math.floor(nz) }), head = ow.getBlock({ x: Math.floor(nx), y: fy + 1, z: Math.floor(nz) }), floor = ow.getBlock({ x: Math.floor(nx), y: fy - 1, z: Math.floor(nz) });
      if (!feet || !head || !floor) return false; const open = (feet.isAir || feet.isLiquid || PASS.test(feet.typeId)) && (head.isAir || head.isLiquid || PASS.test(head.typeId));
      if (open && (!floor.isAir || fall) && roomy(nx, fy, nz)) { e.teleport({ x: nx, y: fy, z: nz }, { facingLocation: p.location }); return true; } } catch { return false; } }
    return false;
  };
  const ux = dx / d, uz = dz / d;
  if (tryAt(ux, uz)) return true;
  /* ふさがって いる: 体当たりで 建物を 突き破って そのまま 進む */
  if (!a.small && now >= (a.sm || 0)) {   /* 第97版: 小さい 魔物（群れ・待ちぶせ）は 壊さない（軽く） */
    a.sm = now + (isLite() ? 10 : 6);
    const cx = l.x + ux * 2.2, cz = l.z + uz * 2.2;
    if (plowAt(e, cx, l.y, cz, true)) { try { e.teleport({ x: l.x + ux * speed, y: l.y, z: l.z + uz * speed }, { facingLocation: p.location }); } catch {} return true; }
  }
  if (tryAt(ux * 0.7 - uz * 0.7, uz * 0.7 + ux * 0.7) || tryAt(ux * 0.7 + uz * 0.7, uz * 0.7 - ux * 0.7)) return true;
  if (tryAt(ux, uz, true)) return true;   /* 段差は 落ちる */
  try { e.teleport(l, { facingLocation: p.location }); } catch {}
  return false;
}
/* ---- 追い方の 個性（系統ごと）---- */
const CHB = { c: 0, n: 0, step: 4 }, ev = (k) => CHB.n % Math.max(1, Math.round(k / CHB.step)) === 0;   /* 第97版: 追いかけの 回数で「k tickごと」を 決める */
const FLYERS = (sid) => { const S = SPECIES[sid]; return !!S && (S.ride === "fly" || S.fam === "dragon"); };
const STY = {
  beast: { spd: 1.15, name: "突撃" }, animal: { spd: 1.1, name: "ジグザグ" }, dragon: { spd: 1.0, name: "飛翔" }, golem: { spd: 0.75, name: "なぎ倒し" },
  blob: { spd: 0.9, name: "跳ねる" }, sword: { spd: 1.0, name: "踏みこみ" }, aqua: { spd: 0.9, name: "水走り" }, nether: { spd: 1.05, name: "焦土" }, king: { spd: 0.85, name: "地響き" }, god: { spd: 0.9, name: "地響き" },
};
const AIRC = new Map();
const airborne = (p) => { const now = system.currentTick || 0, c = AIRC.get(p.id); if (c && now - c.t < 10) return c.v; const v = airborne0(p); AIRC.set(p.id, { t: now, v }); return v; };
const airborne0 = (p) => { try { if (p.isFlying || p.isGliding) return true; const r = p.getComponent("minecraft:riding")?.entityRidingOn; if (r && r.typeId === TYPE && FLYERS(r.getDynamicProperty("mrpg:sid") || ORDER[r.getProperty("mrpg:sp")])) return true; const t = OW().getTopmostBlock({ x: Math.floor(p.location.x), z: Math.floor(p.location.z) }); return !!t && p.location.y > t.location.y + 6; } catch { return false; } };
function arc(e, p, from, to, steps, peak, every, onLand) {   /* 跳ぶ（放物線）: 道の 上を 何回かに 分けて 瞬間移動 */
  for (let k = 1; k <= steps; k++) later(k * every, () => {
    if (!ok(e) || e.hasTag("mrpg_battle")) return; const f = k / steps, y = from.y + (to.y - from.y) * f + Math.sin(Math.PI * f) * peak;
    try { e.teleport({ x: from.x + (to.x - from.x) * f, y, z: from.z + (to.z - from.z) * f }, { facingLocation: p.location }); } catch {}
    if (k === steps && onLand) onLand();
  });
}
function flyStep(e, p, a, now, spd) {   /* 空を 飛んで 追う（重力なし） */
  if (!a.fly) { a.fly = true; try { e.triggerEvent("mrpg:fly_on"); e.addTag("mrpg_rfly"); } catch {} try { p.onScreenDisplay.setActionBar("§c空まで 追って くる！"); } catch {} }
  const l = e.location, h = p.getHeadLocation(), dx = h.x - l.x, dy = h.y + 2 - l.y, dz = h.z - l.z, d = Math.hypot(dx, dy, dz) || 1, st = Math.min(d - 3, spd);
  if (st <= 0) { try { e.teleport(l, { facingLocation: h }); } catch {} return; }
  const nx = l.x + dx / d * st, ny = l.y + dy / d * st, nz = l.z + dz / d * st;
  try { const b = OW().getBlock({ x: Math.floor(nx), y: Math.floor(ny), z: Math.floor(nz) }); if (b && !b.isAir && !b.isLiquid) plowAt(e, nx, ny, nz, ev(8)); } catch {}
  try { e.teleport({ x: nx, y: ny, z: nz }, { facingLocation: h }); } catch {}
  if (ev(6)) { fxp("flames", l, colOf(e.getDynamicProperty("mrpg:sid")), 1.2); try { p.playSound("mob.enderdragon.flap", { location: l, volume: 0.7, pitch: 0.8 }); } catch {} }
}
function landFly(e, a) { if (a && !a.fly) return; if (a) a.fly = false; try { if (e.hasTag("mrpg_rfly")) { e.triggerEvent("mrpg:fly_off"); e.removeTag("mrpg_rfly"); } } catch {} }
/* 追うのを やめた 飛ぶ 魔物は 地上へ もどる */
system.runInterval(() => { let L = []; try { L = OW().getEntities({ type: TYPE, tags: ["mrpg_rfly"] }); } catch {} for (const e of L) if (!AGGRO.has(e.id) || e.hasTag("mrpg_battle")) landFly(e, null); }, 40);
function moveStyled(c, a, now, step, want) {
  const { e, p, sid, dist } = c, S = SPECIES[sid], sty = STY[S.fam] || STY.beast, l = e.location, lite = isLite();
  const ux = (p.location.x - l.x) / dist, uz = (p.location.z - l.z) / dist;
  // 空を 飛ぶ 相手: 飛べる 魔物は 空まで 追う
  if (FLYERS(sid) && airborne(p)) { flyStep(e, p, a, now, step * 2.6); return; }
  landFly(e, a);
  if (c.pack) {   /* 第95版: 群れは まわりを 囲む */
    if (a.ang === undefined) a.ang = Math.random() * Math.PI * 2; a.ang += 0.12;
    const r = Math.max(2.2, want), tx = p.location.x + Math.cos(a.ang) * r, tz = p.location.z + Math.sin(a.ang) * r;
    if (Math.hypot(tx - l.x, tz - l.z) < 1) { try { e.teleport(l, { facingLocation: p.location }); } catch {} return; }
    stepToward(e, p, step * 1.2, a, now, { x: tx, y: p.location.y, z: tz }); return;
  }
  if (dist <= want) { try { e.teleport(l, { facingLocation: p.location }); } catch {} return; }
  let sp = step * sty.spd;
  switch (S.fam) {
    case "beast": {   /* ときどき 猛ダッシュ */
      if (now >= (a.dashCd || 0) && dist > 10) { a.dashUntil = now + 16; a.dashCd = now + (lite ? 120 : 80); try { p.playSound("mob.wolf.growl", { location: l, pitch: 0.6, volume: 1 }); } catch {} }
      if (now < (a.dashUntil || 0)) { sp *= 2.6; if (ev(4)) fxp("smoke", l, ECOL.earth, 1.4); }
      break;
    }
    case "animal": {   /* ジグザグに 走って 狙いを しぼらせない */
      const w = Math.sin((now || 0) / 9) * Math.min(6, dist * 0.4);
      stepToward(e, p, sp, a, now, { x: p.location.x - uz * w, y: p.location.y, z: p.location.z + ux * w }); return;
    }
    case "dragon": {   /* ビルを 飛びこえて 一気に 迫る */
      if ((a.stuck || dist > 14) && now >= (a.flyCd || 0)) {
        a.flyCd = now + (lite ? 140 : 90); a.busyT = now + 20;
        const to = { x: p.location.x - ux * 5, y: p.location.y, z: p.location.z - uz * 5 }; let top = l.y;
        try { for (const f of [0.33, 0.66]) { const t = OW().getTopmostBlock({ x: Math.floor(l.x + (to.x - l.x) * f), z: Math.floor(l.z + (to.z - l.z) * f) }); if (t) top = Math.max(top, t.location.y); } } catch {}
        try { p.playSound("mob.enderdragon.flap", { location: l, volume: 1, pitch: 0.6 }); } catch {}
        arc(e, p, { ...l }, to, lite ? 5 : 8, Math.max(6, top - l.y + 6), 2, () => { boom(to.x, to.y + 0.5, to.z, 5, e.id, true, colOf(sid)); });
        return;
      }
      break;
    }
    case "golem": {   /* 前に ある ものを ぜんぶ なぎ倒して 進む */
      if (ev(4)) plowAt(e, l.x + ux * 2.4, l.y, l.z + uz * 2.4, ev(12));
      if (ev(10)) { try { p.playSound("mob.irongolem.walk", { location: l, volume: 1, pitch: 0.5 }); } catch {} if (dist < 18) shake(p, 0.25, 0.3); }
      break;
    }
    case "blob": {   /* 跳ねながら 来る。着地で 地面が 揺れる */
      if (now >= (a.hopT || 0)) {
        a.hopT = now + (lite ? 24 : 18); a.busyT = now + 10;
        const f = Math.min(6, dist - want + 1), to = { x: l.x + ux * f, y: l.y, z: l.z + uz * f };
        plowAt(e, to.x, to.y, to.z, false);
        arc(e, p, { ...l }, to, 4, 3, 2, () => { fxp("shock", to, colOf(sid), 2.5); try { for (const q of OW().getPlayers({ location: to, maxDistance: 10 })) { shake(q, 0.3, 0.3); q.playSound("mob.slime.big", { location: to, volume: 1, pitch: 0.5 }); } } catch {} });
      }
      return;
    }
    case "sword": {   /* 瞬間移動の 踏みこみ */
      if (dist > 7 && now >= (a.blinkCd || 0)) {
        a.blinkCd = now + (lite ? 50 : 34); const f = Math.min(8, dist - 3), to = { x: l.x + ux * f, y: l.y, z: l.z + uz * f };
        plowAt(e, to.x, to.y, to.z, false);
        for (let k = 1; k <= 3; k++) fxp("slash", { x: l.x + ux * f * k / 3, y: l.y + 1.5, z: l.z + uz * f * k / 3 }, ECOL.slash, 1.6);
        try { e.teleport(to, { facingLocation: p.location }); p.playSound("game.player.attack.sweep", { location: to, volume: 1, pitch: 1.4 }); } catch {}
        return;
      }
      break;
    }
    case "aqua": {   /* 水の 中は 速い */
      let wet = false; try { const b = OW().getBlock({ x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z) }); wet = !!b && b.isLiquid; } catch {}
      if (wet) { sp *= 2.4; if (ev(4)) try { OW().spawnParticle("minecraft:water_splash_particle", l); fxp("swirl", l, ECOL.water, 1.4); } catch {} }
      break;
    }
    case "nether": {   /* 通った 跡が 焦げて 燃える */
      if (ev(4)) fxp("flames", l, ECOL.fire, 1.5);
      if (ev(10) && !qFull() && canBreak(l.x, l.y, l.z, 1)) { const fy = Math.floor(l.y) - 1; try { const b = OW().getBlock({ x: Math.floor(l.x), y: fy, z: Math.floor(l.z) }); if (b && !b.isAir && !b.isLiquid && !BOX_RE.test(String(b.typeId)) && !CONT.test(String(b.typeId))) QCMD(`setblock ${Math.floor(l.x)} ${fy} ${Math.floor(l.z)} ${pick(["netherrack", "blackstone", "soul_soil"])}`); } catch {} }
      break;
    }
    case "king": case "god": {   /* 一歩ごとに 地響き */
      if (ev(14)) { fxp("shock", l, ECOL.roar, 3); try { for (const q of OW().getPlayers({ location: l, maxDistance: 24 })) { shake(q, 0.3, 0.4); q.playSound("mob.ravager.stun", { location: l, volume: 0.8, pitch: 0.4 }); } } catch {} }
      break;
    }
  }
  stepToward(e, p, sp, a, now);
}
/* ---- 技（型ごと・距離ごと）---- */
const later = (t, f) => system.runTimeout(() => { try { f(); } catch {} }, t);
const alive = (e, p) => { try { return ok(e) && ok(p) && !fighting(p) && !e.hasTag("mrpg_battle"); } catch { return false; } };
const PATS = [
  // 近い（reach の 中）
  { id: "slash", nm: (c) => c.mv("weapon"), k: ["weapon"], near: true, w: 3, cd: 22, run(c) {
    const { e, p, ow } = c; c.anim(c.ma("weapon", "atk_slash2"));
    try { const l = p.getHeadLocation(); for (let k = 0; k < 6; k++) ow.spawnParticle("minecraft:critical_hit_emitter", { x: l.x + (k - 2.5) * 0.5, y: l.y - 0.3, z: l.z }); p.playSound("game.player.attack.strong", { pitch: 0.7, volume: 1 }); } catch {}
    fxp("xslash", p.getHeadLocation(), ECOL.slash, 2.6); fxp("slash", p.getHeadLocation(), ECOL.slash, 3);
    c.hit(3, 5, 1.4); const el = e.location, ux = (p.location.x - el.x) / c.dist, uz = (p.location.z - el.z) / c.dist; carveBox(el.x + ux * 3 - 1, el.y + 1, el.z + uz * 3 - 1, el.x + ux * 3 + 1, el.y + Math.min(8, c.h), el.z + uz * 3 + 1);
    if (Math.random() < 0.45) later(8, () => { if (!alive(e, p) || Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) > c.reach + 1.5) return; p.playSound("game.player.attack.sweep", { volume: 1 }); c.say("二の太刀"); hurtP(p, ri(2, 3), { cause: "entityAttack", damagingEntity: e }); }); } },
  { id: "spin", nm: () => "回転斬り", k: ["weapon"], near: true, w: 2, cd: 34, run(c) {
    const { e, p, ow } = c, l = e.location; c.anim(c.ma("weapon", "atk_slash2"));
    try { for (let k = 0; k < 16; k++) { const a = k * Math.PI / 8; ow.spawnParticle("minecraft:critical_hit_emitter", { x: l.x + Math.cos(a) * 4, y: l.y + 1.5, z: l.z + Math.sin(a) * 4 }); } p.playSound("game.player.attack.sweep", { pitch: 0.5, volume: 1 }); } catch {}
    fxp("shock", { x: l.x, y: l.y + 1.5, z: l.z }, ECOL.slash, 6); for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; fxp("slash", { x: l.x + Math.cos(a) * 4, y: l.y + 1.6, z: l.z + Math.sin(a) * 4 }, ECOL.slash, 2.4); }
    for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3 + Math.PI / 6; carve(l.x + Math.cos(a) * 5, l.y + 2, l.z + Math.sin(a) * 5, 3); }
    if (c.dist <= c.reach + 2.5) c.hit(4, 6, 2); } },
  { id: "bite", nm: (c) => (c.kind === "phys" ? c.mv("phys") : pick(["かみつき", "爪の 一撃", "なぐりつけ"])), k: ["phys", "weapon", "breath", "magic"], near: true, w: 3, cd: 20, run(c) {
    const { e, p, ow } = c; try { const l = e.location, nx = l.x + (p.location.x - l.x) * 0.4, nz = l.z + (p.location.z - l.z) * 0.4, { h, w } = bodyBox(e); carveBox(nx - w, l.y, nz - w, nx + w, l.y + h - 1, nz + w); e.teleport({ x: nx, y: l.y + 0.6, z: nz }, { facingLocation: p.location }); } catch {}
    c.anim(c.ma("phys", "atk_claw")); fxp("xslash", p.getHeadLocation(), ECOL.blood, 2.2); fxp("impact", p.getHeadLocation(), ECOL.blood, 2.4); try { ow.spawnParticle("minecraft:critical_hit_emitter", p.getHeadLocation()); p.playSound("mob.ravager.bite", { pitch: c.boss ? 0.6 : 1.1, volume: 1 }); } catch {}
    c.hit(3, 5, 1.6); } },
  { id: "rend", nm: () => "引き裂き（3連）", k: ["phys", "weapon", "breath", "magic"], near: true, w: 2, cd: 36, run(c) {
    const { e, p } = c;
    for (let k = 0; k < 3; k++) later(k * 6, () => { if (!alive(e, p) || Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) > c.reach + 2) return; c.anim(c.ma("phys", "atk_claw")); fxp("slash", p.getHeadLocation(), ECOL.blood, 2.2); try { c.ow.spawnParticle("minecraft:critical_hit_emitter", p.getHeadLocation()); p.playSound("mob.ravager.bite", { pitch: 1.3 - k * 0.2, volume: 1 }); } catch {} hurtP(p, 2, { cause: "entityAttack", damagingEntity: e }); kb(p, e.location, 0.4, 0.15); }); } },
  { id: "throw", nm: () => "はね飛ばし", k: ["phys", "weapon", "breath", "magic"], near: true, w: 1, cd: 40, run(c) {
    c.anim("atk_claw"); try { c.p.playSound("mob.ravager.roar", { pitch: 1.2, volume: 1 }); } catch {} c.hit(2, 4, 2.2); } },
  { id: "tail", nm: () => pick(["しっぽの 一撃", "体当たり", "なぎはらい"]), k: ["phys", "weapon", "breath", "magic"], near: true, w: 3, cd: 24, run(c) {
    const { e, p, ow } = c, l = e.location; c.anim("atk_claw");
    try { ow.spawnParticle("minecraft:knockback_roar_particle", l); p.playSound("mob.ravager.stun", { pitch: 0.9, volume: 1 }); } catch {} fxp("shock", { x: l.x, y: l.y + 0.5, z: l.z }, colOf(c.sid), 5);
    for (let k = 0; k < 4; k++) { const a = Math.random() * Math.PI * 2; carve(l.x + Math.cos(a) * 4, l.y + 1, l.z + Math.sin(a) * 4, 3); }
    c.hit(3, 5, 2.4); } },
  { id: "stomp", nm: () => "ふみつけ", k: ["phys", "weapon", "breath", "magic"], near: true, big: true, w: 2, cd: 40, run(c) {
    const l = c.e.location; c.anim("atk_claw"); boom(l.x + (c.p.location.x - l.x) * 0.6, l.y + 0.5, l.z + (c.p.location.z - l.z) * 0.6, c.boss ? 10 : 8, c.e.id, true, ECOL.earth); } },
  // 中・遠く
  { id: "press", nm: () => "跳躍プレス §7（落ちて くる 影から にげろ！）", k: ["phys", "weapon", "breath", "magic"], min: 6, max: 34, big: true, w: 2, cd: 70, busy: 34, run(c) {
    const { e, p } = c, tgt = { x: p.location.x, y: p.location.y, z: p.location.z }, l = e.location;
    try { e.teleport({ x: l.x, y: l.y + 14, z: l.z }); c.ow.spawnParticle("minecraft:knockback_roar_particle", l); p.playSound("mob.enderdragon.flap", { pitch: 0.6, volume: 1 }); } catch {}
    meteor(tgt, c.boss ? 12 : 9, isLite() ? 30 : 26, "minecraft:large_explosion", ECOL.earth);
    later(isLite() ? 28 : 24, () => { if (!ok(e)) return; const { h, w } = bodyBox(e); carveBox(tgt.x - w, tgt.y, tgt.z - w, tgt.x + w, tgt.y + h, tgt.z + w); e.teleport({ x: tgt.x, y: tgt.y + 0.2, z: tgt.z }, { facingLocation: tgt }); }); } },
  { id: "charge", nm: () => "突進 §7（横へ よけろ！）", k: ["phys", "weapon", "breath", "magic"], min: 8, max: 36, w: 3, cd: 60, busy: 30, run(c) {
    const { e, p } = c, l0 = e.location, ux = (p.location.x - l0.x) / c.dist, uz = (p.location.z - l0.z) / c.dist, { h, w } = bodyBox(e), steps = isLite() ? 7 : 12, len = Math.min(c.dist + 8, 30);
    try { p.playSound("mob.ravager.roar", { pitch: 0.7, volume: 1 }); } catch {}
    for (let k = 1; k <= steps; k++) later(6 + k * 2, () => {
      if (!ok(e)) return; const s = len * k / steps, x = l0.x + ux * s, z = l0.z + uz * s;
      carveBox(x - w, l0.y, z - w, x + w, l0.y + h - 1, z + w); try { e.teleport({ x, y: l0.y, z }, { facingLocation: { x: x + ux, y: l0.y, z: z + uz } }); c.ow.spawnParticle("minecraft:large_explosion", { x, y: l0.y + 1, z }); } catch {} if (k % 2 === 0) { fxp("shards", { x, y: l0.y + h / 2, z }, ECOL.earth, 2); fxp("smoke", { x, y: l0.y + 1, z }, ECOL.earth, 2); }
      try { if (ok(p) && !fighting(p) && Math.hypot(p.location.x - x, p.location.z - z) < w + 2.2 && Math.abs(p.location.y - l0.y) < h) { hurtP(p, ri(4, 6), { cause: "entityAttack", damagingEntity: e }); kb(p, { x, z }, 2.2, 0.12); } } catch {}
    }); } },
  { id: "quake", nm: () => "地割れ §7（足もとが 割れる！）", k: ["phys", "weapon", "breath", "magic"], min: 5, max: 26, big: true, w: 2, cd: 60, run(c) {
    const { e, p } = c, l = e.location, ux = (p.location.x - l.x) / c.dist, uz = (p.location.z - l.z) / c.dist, n = Math.min(8, Math.ceil(c.dist / 3) + 1);
    try { c.ow.spawnParticle("minecraft:knockback_roar_particle", l); p.playSound("mob.ravager.stun", { pitch: 0.5, volume: 1 }); } catch {}
    for (let k = 1; k <= n; k++) later(k * 3, () => { const x = l.x + ux * k * 3, z = l.z + uz * k * 3, y = Math.floor(l.y);
      try { c.ow.spawnParticle("minecraft:large_explosion", { x, y, z }); } catch {} fxp("pillar", { x, y, z }, ECOL.earth, 2); fxp("shards", { x, y: y + 1, z }, ECOL.earth, 1.8);
      for (const q of c.ow.getPlayers({ location: { x, y, z }, maxDistance: 3 })) { hurtP(q, 2, { cause: "entityAttack", damagingEntity: e }); }
      carveBox(x - 1.5, y - 4, z - 1.5, x + 1.5, y + 1, z + 1.5, GY - 3); }); } },
  { id: "roar", nm: () => "咆哮 §7（衝撃波が 広がる！）", k: ["phys", "weapon", "breath", "magic"], min: 0, max: 24, w: 2, cd: 80, run(c) {
    const { e, p, ow } = c, l = { ...e.location }, col = colOf(c.sid), lite = isLite();
    try { ow.spawnParticle("minecraft:knockback_roar_particle", l); for (const q of ow.getPlayers({ location: l, maxDistance: 64 })) { q.playSound("mob.ravager.roar", { pitch: 0.45, volume: 1 }); q.playSound("mob.enderdragon.growl", { pitch: 0.5, volume: 1 }); shake(q, 1.2, 1.2); } } catch {}
    /* 衝撃波の 輪が 3回 広がり、輪の 上の 建物が 吹き飛ぶ */
    const rings = lite ? [[6, 6, 3], [11, 8, 3]] : [[6, 8, 4], [11, 10, 4], [16, 12, 3.5]];
    rings.forEach(([R0, n, rr], j) => later(j * 5, () => {
      fxp("shock", { x: l.x, y: l.y + 1, z: l.z }, col, R0 * 1.1); fxp("shock", { x: l.x, y: l.y + 4, z: l.z }, ECOL.roar, R0 * 0.9);
      try { ow.spawnParticle("minecraft:knockback_roar_particle", { x: l.x, y: l.y + 2, z: l.z }); } catch {}
      for (let k = 0; k < n; k++) { const a = k * Math.PI * 2 / n + j * 0.3, x = l.x + Math.cos(a) * R0, z = l.z + Math.sin(a) * R0; carve(x, l.y + 2.5, z, rr); if (!lite && k % 2 === 0) { try { ow.spawnParticle("minecraft:large_explosion", { x, y: l.y + 2, z }); } catch {} fxp("boom", { x, y: l.y + 2, z }, col, 2.2); } }
      for (const q of ow.getPlayers({ location: l, maxDistance: R0 + 3 })) { if (Math.hypot(q.location.x - l.x, q.location.z - l.z) < R0 - 4) continue; hurtP(q, 2, { cause: "entityAttack", damagingEntity: e }); kb(q, l, 2.4, 0.12); }
    })); } },
  { id: "fireball", ranged: true, nm: (c) => `${c.mv("breath")} §7（よけろ！）`, k: ["breath"], min: 4, max: 44, w: 3, cd: 40, run(c) {
    c.anim(c.ma("breath", "breath")); try { c.p.playSound("mob.blaze.shoot", { pitch: c.boss ? 0.6 : 0.9, volume: 1 }); } catch {}
    shootAt(c.e, eye(c.e), c.aim(), { fx: elFx(c.sid), power: c.boss ? 12 : 8.8, sp: 1.1, big: true, pierce: c.boss ? 2 : 1, col: colOf(c.sid) }); } },
  { id: "sweep", ranged: true, nm: () => "薙ぎ払いブレス §7（よけろ！）", k: ["breath"], min: 6, max: 40, w: 2, cd: 70, busy: 18, run(c) {
    const { e, p } = c; c.anim(c.ma("breath", "breath")); try { p.playSound("mob.enderdragon.growl", { pitch: 0.8, volume: 1 }); } catch {}
    const a0 = Math.atan2(p.location.z - e.location.z, p.location.x - e.location.x);
    for (let k = 0; k < 5; k++) later(k * 3, () => { if (!ok(e)) return; const a = a0 + (k - 2) * 0.28, from = eye(e), d = c.dist + 4; shootAt(e, from, { x: e.location.x + Math.cos(a) * d, y: p.location.y + 0.5, z: e.location.z + Math.sin(a) * d }, { fx: elFx(c.sid), power: 7, sp: 1.2, big: true, col: colOf(c.sid) }); }); } },
  { id: "pillar", ranged: true, nm: () => "炎の柱 §7（足もとへ 迫る！）", k: ["breath", "magic"], min: 6, max: 30, w: 2, cd: 60, run(c) {
    const { e, p } = c, l = e.location, tx = p.location.x, tz = p.location.z, n = 6;
    for (let k = 1; k <= n; k++) later(k * 4, () => { const x = l.x + (tx - l.x) * k / n, z = l.z + (tz - l.z) * k / n; const t = colInfo(x, z); const y = t ? Math.min(t.y, p.location.y + 1) : p.location.y; try { for (let j = 0; j < 6; j++) c.ow.spawnParticle(elFx(c.sid), { x, y: y + j, z }); } catch {} fxp("pillar", { x, y, z }, colOf(c.sid), 3.5); fxp("flames", { x, y: y + 1, z }, colOf(c.sid), 2.5); boom(x, y, z, 6, e.id, false, colOf(c.sid)); }); } },
  { id: "meteor", ranged: true, nm: (c) => `${c.mv("magic")} §7（足もとの 魔法陣から にげろ！）`, k: ["magic"], min: 4, max: 44, w: 3, cd: 50, run(c) {
    c.anim(c.ma("magic", "cast")); try { c.p.playSound("mob.evocation_illager.cast_spell", { pitch: c.boss ? 0.6 : 1, volume: 1 }); } catch {}
    meteor(c.p.location, c.boss ? 12 : 10.4, 20, null, colOf(c.sid)); } },
  { id: "rain", ranged: true, nm: () => "流星群 §7（魔法陣から にげろ！）", k: ["magic"], min: 6, max: 44, w: 2, cd: 90, run(c) {
    c.anim(c.ma("magic", "cast")); try { c.p.playSound("mob.evocation_illager.prepare_summon", { pitch: 0.7, volume: 1 }); } catch {}
    const l = c.p.location; for (let k = 0; k < (isLite() ? 3 : 5); k++) meteor({ x: l.x + ri(-8, 8), y: l.y, z: l.z + ri(-8, 8) }, 8, 20 + k * 6, null, colOf(c.sid)); } },
  { id: "thunder", ranged: true, nm: () => "落雷 §7（光る 柱から にげろ！）", k: ["magic"], el: "thunder", min: 4, max: 44, w: 2, cd: 50, run(c) {
    const l = { ...c.p.location }; try { c.p.playSound("ambient.weather.thunder", { pitch: 1, volume: 1 }); } catch {}
    for (let k = 0; k < 4; k++) later(k * 4, () => { fxp("circle", { x: l.x, y: l.y + 0.15, z: l.z }, ECOL.thunder, 3); try { for (let j = 0; j < 10; j++) c.ow.spawnParticle("minecraft:electric_spark_particle", { x: l.x, y: l.y + j * 2, z: l.z }); } catch {} });
    later(18, () => { for (let j = 0; j < 8; j++) fxp("bolt", { x: l.x, y: l.y + j * 3, z: l.z }, ECOL.thunder, 3); beam({ x: l.x, y: l.y + 26, z: l.z }, l, ECOL.thunder, 3); boom(l.x, l.y + 0.5, l.z, 8, c.e.id, true, ECOL.thunder); }); } },
  { id: "rock", ranged: true, nm: () => "岩投げ §7（よけろ！）", k: ["phys", "weapon"], min: 8, max: 40, w: 2, cd: 60, run(c) {
    const { e, p } = c, l = e.location; c.anim("atk_claw"); carve(l.x + 2, l.y, l.z + 2, 2);
    try { c.ow.spawnParticle("minecraft:large_explosion", { x: l.x + 2, y: l.y, z: l.z + 2 }); p.playSound("dig.stone", { pitch: 0.5, volume: 1 }); } catch {}
    later(6, () => { if (ok(e)) shootAt(e, eye(e), c.aim(), { fx: "minecraft:falling_dust_dragon_egg_particle", power: 8, sp: 1.0, big: true, col: ECOL.earth }); }); } },
  { id: "slashwave", ranged: true, nm: () => "真空波 §7（よけろ！）", k: ["weapon"], min: 5, max: 40, w: 3, cd: 46, run(c) {
    const { e, p } = c; c.anim(c.ma("weapon", "atk_slash2")); try { p.playSound("game.player.attack.sweep", { pitch: 0.6, volume: 1 }); } catch {}
    const a0 = Math.atan2(p.location.z - e.location.z, p.location.x - e.location.x);
    for (const k of [-1, 0, 1]) { const a = a0 + k * 0.22, d = c.dist + 3; shootAt(e, eye(e), { x: e.location.x + Math.cos(a) * d, y: p.location.y + 1, z: e.location.z + Math.sin(a) * d }, { fx: "minecraft:critical_hit_emitter", power: 4.5, sp: 1.4, pierce: 3, col: ECOL.slash }); } } },
  { id: "pounce", nm: () => "飛びかかり", k: ["phys", "weapon", "breath", "magic"], min: 6, max: 24, w: 2, cd: 30, run(c) {
    const { e, p } = c; try { const l = e.location, f = Math.min(0.75, 7 / c.dist), nx = l.x + (p.location.x - l.x) * f, nz = l.z + (p.location.z - l.z) * f, { h, w } = bodyBox(e); carveBox(nx - w, l.y, nz - w, nx + w, l.y + h - 1, nz + w); e.teleport({ x: nx, y: l.y + 0.5, z: nz }, { facingLocation: p.location }); p.playSound("mob.wolf.growl", { pitch: 0.6, volume: 1 }); } catch {} } },
  // 配下・邪神だけ
  { id: "rampage", nm: () => "大暴れ §7（まわりが 吹き飛ぶ！）", k: ["phys", "weapon", "breath", "magic"], boss: true, min: 0, max: 40, w: 2, cd: 80, run(c) {
    const l = c.e.location; try { c.p.playSound("mob.enderdragon.growl", { pitch: 0.5, volume: 1 }); } catch {}
    for (let k = 0; k < (isLite() ? 3 : 5); k++) later(k * 5, () => { const a = Math.random() * Math.PI * 2, d = 6 + Math.random() * 8; boom(l.x + Math.cos(a) * d, l.y + 1 + Math.random() * 6, l.z + Math.sin(a) * d, 9, c.e.id, true, colOf(c.sid)); }); } },
];
function choosePat(c, a) {
  const L = PATS.filter((P) => P.k.includes(c.kind) || (P.el && P.el === elOf(c.sid)) || (c.boss && P.boss));
  const RG = [[0.25, 0.2, 0.08], [0.5, 0.5, 0.3], [0.7, 0.75, 0.45]][ruLv(c.p)[2]];   /* 第95版: 設定（少なめ・ふつう・多め）。ふつうは 第86版と 同じ */
  const rangedOk = !c.small && Math.random() < (c.boss ? RG[0] : c.kind === "breath" || c.kind === "magic" ? RG[1] : RG[2]) && c.dist > 7;
  const ok2 = L.filter((P) => (!P.ranged || rangedOk) && (!c.small || SMALL_PAT.has(P.id)) && (!P.boss || c.boss) && (!P.big || c.big) && (P.near ? c.d3 <= c.reach : c.dist >= (P.min || 0) && c.dist <= (P.max || 40) && (c.vis || P.id === "quake" || P.id === "rampage" || P.id === "rain")) && P.id !== a.last);
  if (!ok2.length) return null;
  let s = ok2.reduce((t, P) => t + P.w, 0) * Math.random(); for (const P of ok2) { s -= P.w; if (s <= 0) return P; } return ok2[ok2.length - 1];
}
function clearStuckRes(p) { try { const r = p.getEffect("resistance"); if (r && r.amplifier >= 4 && p.isOnGround && !busy.has(p.id) && !globalThis.__mqStageZ?.has(p.id)) p.removeEffect("resistance"); } catch {} }   /* 第97版: ワープ用の 無敵が 残って いると 攻撃が 0に なる */
// 気づく: 近く（40m・しのび足 20m・軽量 32m）の 巨大な 魔物は 壁ごしでも 気づく。目が 合えば 64m
system.runInterval(() => {
  if (!gateOn()) return;
  const now = system.currentTick;
  for (const p of allP()) { try {   /* 第97版: 1人 おかしくても 全員の 処理を 止めない */
    if (fighting(p) || !playing(p) || p.dimension.id !== "minecraft:overworld" || !inRuins(p.location) || nearCamp(p.location, 16)) continue;
    clearStuckRes(p);
    const lv = ruLv(p), sneak = !!p.isSneaking, R = (sneak ? 14 : isLite() ? 24 : 28) * [0.65, 1, 1.3][lv[1]] * (RM.on ? 1.2 : 1), MAXA = [1, 2, 3][lv[1]];   /* 第95版: 設定と 赤い 月 */
    const mine = [...AGGRO.values()].filter((a) => a.pid === p.id && !a.pk && !a.rage).length;   /* 配下の 追跡・群れは 数えない */
    let mine2 = mine; const add = (e, msg) => { const pk = e.hasTag("mrpg_rpack"); if (!pk) mine2++; AGGRO.set(e.id, { pid: p.id, until: now + 600, cd: now + 40, seen: now, pk }); try { p.onScreenDisplay.setActionBar(msg); p.playSound("mob.ravager.roar", { pitch: 0.7, volume: 1 }); OW().spawnParticle("minecraft:knockback_roar_particle", e.location); shake(p, 0.5, 1); } catch {} packJoin(e, p, now); };
    ambushCheck(p, sneak, now);
    try { if (mine2 < MAXA) for (const h of p.getEntitiesFromViewDirection({ maxDistance: sneak ? 16 : 32 })) { const e = h.entity; if (e && e.hasTag("mrpg_ruinw") && !e.hasTag("mrpg_ruinwt") && !e.hasTag("mrpg_battle") && !AGGRO.has(e.id) && chaser(e)) add(e, `§c${e.nameTag.replace(/§./g, "").split(" ")[0]}と 目が 合った……！`); break; } } catch {}
    let L = []; try { L = OW().getEntities({ type: TYPE, location: p.location, maxDistance: R + 24, excludeTags: ["mrpg_battle", "mrpg_pet", "mrpg_rboss"] }).filter((e) => e.hasTag("mrpg_ruinw") && !e.hasTag("mrpg_ruinwt") && chaser(e) && Math.hypot(e.location.x - p.location.x, e.location.z - p.location.z) < R); } catch {}
    for (const e of L) { const a = AGGRO.get(e.id); if (a) { if (a.pid === p.id) a.until = Math.max(a.until, now + 200); continue; } if (mine2 >= MAXA) break; add(e, "§c見つかった！ §7（巨大な 魔物が 建物を 壊して 向かって くる！）"); }
  } catch {} }
}, 20);
// 追いかけて 攻撃（2 tick ごと・軽量モードは 4 tick ごと）
system.runInterval(() => {
  if (!gateOn() || !AGGRO.size) return;
  const now = system.currentTick ?? 0, lite = isLite(); CHB.step = lite ? 6 : 4; if (++CHB.c % (lite ? 3 : 2)) return; CHB.n++;   /* 第97版: 自分で 数える（前は tickの 番号で 決めて いて、読みこんだ tickが 奇数だと 1回も 動かなかった） */   /* 第91版: 4tick ごと（軽量 6tick） */
  const ow = OW(), PM = new Map(allP().map((q) => [q.id, q]));
  for (const [id, a] of AGGRO) {
    let e = null; try { e = world.getEntity(id); } catch {}
    const p = PM.get(a.pid);
    if (!e || !ok(e) || !p || e.hasTag("mrpg_battle") || fighting(p) || !playing(p) || !inRuins(p.location) || now > a.until) { AGGRO.delete(id); if (e && ok(e)) landFly(e, a); continue; }
    try {
      if (a.sid === undefined) { a.sid = e.getDynamicProperty("mrpg:sid"); a.boss = e.hasTag("mrpg_rboss"); a.kind = SPECIES[a.sid] ? kindOf(a.sid) : null; }   /* 第97版: 1回だけ しらべて 覚える */
      const boss = a.boss, sid = a.sid; if (typeof sid !== "string" || !SPECIES[sid]) { AGGRO.delete(id); continue; }
      const dist = Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) || 0.1;
      const flyer = FLYERS(sid), d3 = Math.hypot(dist, p.location.y - e.location.y);
      if (dist > (boss ? 64 : flyer ? 56 : 40) || nearCamp(p.location, 16)) { AGGRO.delete(id); landFly(e, a); continue; }   // 遠くへ 逃げた・キャンプへ 入った
      if (now < (a.busyT || 0)) continue;   // 大技の 最中
      const h = bodyH(e), big = boss || SPECIES[sid].sz === "G", kind = a.kind, small = !boss && !bigMob(e), pack = small && e.hasTag("mrpg_rpack"); a.small = small;
      const reach = Math.max(3.4, Math.min(boss ? 10 : 7, h * 0.45)), melee = kind === "phys" || kind === "weapon";
      const want = reach * 0.7;   /* 第86版: みんな 近づいて なぐる */
      const step = (boss ? 0.5 : 0.45) * (lite ? 3 : 2) * (small ? 1.2 : 1);
      const far = dist > 22 && !boss;   /* 第95版: 遠い 魔物は 2回に 1回だけ 動かす（そのぶん 大またで） */
      if (!far || (a.lod = !a.lod)) moveStyled({ e, p, sid, dist, pack }, a, now, far ? step * 2 : step, want);
      // じだんだ（つまった とき・ときどき）
      { const l = e.location; const moved = a.lp ? Math.hypot(l.x - a.lp.x, l.z - a.lp.z) : 9; if (now - (a.lpT || 0) >= 20) { a.stuck = dist > want && moved < 0.5; a.lp = { x: l.x, z: l.z }; a.lpT = now; }
        if (!a.fly && !small && now >= (a.jd || 0) && (a.stuck || (dist < 14 && Math.random() < 0.03))) { a.jd = now + (lite ? 140 : 90); a.stuck = false; jidanda(e, p, big); try { p.onScreenDisplay.setActionBar(`§c${boss ? bossName(e.getDynamicProperty("mrpg:rboss")) : SPECIES[sid].name}は じだんだを 踏んだ！ §7（足もとが くずれる！）`); } catch {} continue; } }
      /* 追いながら まわりの 建物を 殴り壊す（たまに） */
      if (!small && now >= (a.wr || 0)) { a.wr = now + (lite ? 140 : 90) + ri(0, 40);
        try { const l = e.location, ang = Math.random() * Math.PI * 2, tx = l.x + Math.cos(ang) * 4, tz = l.z + Math.sin(ang) * 4, t = ow.getTopmostBlock({ x: Math.floor(tx), z: Math.floor(tz) });
          if (t && t.location.y > l.y + 2) { const { h, w } = bodyBox(e); if (carveBox(tx - w, l.y, tz - w, tx + w, l.y + h, tz + w)) { ow.spawnParticle("minecraft:large_explosion", { x: tx, y: l.y + h / 2, z: tz }); for (const q of ow.getPlayers({ location: l, maxDistance: 48 })) q.playSound("random.explode", { location: l, volume: 0.9, pitch: 1.1 }); } } } catch {} }
      if (now < a.cd) continue;
      const vis = sees(e, p);
      const nm = boss ? bossName(e.getDynamicProperty("mrpg:rboss")) : SPECIES[sid].name;
      const c = { e, p, ow, sid, kind, boss, big, small, dist, d3, reach, vis, h,
        say: (mv) => { try { p.onScreenDisplay.setActionBar(`§c${nm}の ${mv}！`); } catch {} },
        mv: (k) => pick(MV_BY[k] && MV_BY[k].length ? MV_BY[k] : ["こうげき"]),
        ma: (k, def) => (SPECIES[sid].ma ? `m_${sid}_${k}` : def),
        anim: (n) => { try { anim(e, n); } catch {} },
        aim: () => { const b = p.getHeadLocation(); return { x: b.x, y: b.y - 0.6, z: b.z }; },
        hit: (lo, hi, k) => { hurtP(p, Math.min(6, Math.max(1, Math.round(ri(lo, hi) * (small ? 0.6 : 1)))), { cause: "entityAttack", damagingEntity: e }); kb(p, e.location, k * 0.7 * (small ? 0.6 : 1), 0.08); } };
      const P = choosePat(c, a); if (!P) { a.cd = now + 10; continue; }
      a.last = P.id; a.cd = now + Math.round(P.cd * (lite ? 1.6 : 1.35) * (boss ? (bossP2(e) ? 0.6 : 0.8) : small ? 1.5 : 1) * (P.ranged ? 1.2 : 1)); if (P.busy) a.busyT = now + P.busy;
      c.say(P.nm(c)); P.run(c);
    } catch {}
  }
}, 2);
/* じだんだ: 魔物の まわりと、近くの プレイヤーの 足もとが 0.6秒後に くずれ落ちる */
function jidanda(e, p, big) {
  const ow = OW(), l = e.location, r = big ? 3 : 2, X = Math.floor(l.x), Y = Math.floor(l.y), Z = Math.floor(l.z);
  try { ow.spawnParticle("minecraft:knockback_roar_particle", l); for (const q of ow.getPlayers({ location: l, maxDistance: 40 })) { q.playSound("mob.ravager.stun", { pitch: 0.5, volume: 1 }); shake(q, 0.8, 0.8); } } catch {}
  const spots = [{ x: X, y: Y, z: Z, r }];
  try { if (Math.hypot(p.location.x - l.x, p.location.z - l.z) < (big ? 18 : 12)) spots.push({ x: Math.floor(p.location.x), y: Math.floor(p.location.y), z: Math.floor(p.location.z), r: 1 }); } catch {}
  for (const q of spots) for (let k = 0; k < 6; k++) try { ow.spawnParticle("minecraft:falling_dust_dragon_egg_particle", { x: q.x + Math.random() * 2 - 1, y: q.y + 0.2, z: q.z + Math.random() * 2 - 1 }); } catch {}
  later(12, () => {
    for (const q of spots) {
      try { ow.getPlayers({ location: q, maxDistance: 8 }).length; } catch {}
      if (carveBox(q.x - q.r, q.y - (big ? 4 : 3), q.z - q.r, q.x + q.r, q.y - 1, q.z + q.r, GY - 3)) try { ow.spawnParticle("minecraft:large_explosion", q); } catch {}
    }
  });
}
// 暴れまわる: 追って いない 巨大な 魔物も、プレイヤーの 見える 所で 建物に ブレスを 吐いたり 体当たりしたりする
system.runInterval(() => {
  if (!gateOn()) return;
  const ow = OW(), doneE = new Set();
  for (const p of allP()) { try {
    if (fighting(p) || !playing(p) || !inRuins(p.location) || nearCamp(p.location, 30)) continue;
    let L = []; try { L = ow.getEntities({ type: TYPE, location: p.location, maxDistance: 64, excludeTags: ["mrpg_battle", "mrpg_ruinin", "mrpg_ruinwt"] }).filter((e) => (e.hasTag("mrpg_ruinw") || e.hasTag("mrpg_rboss")) && !AGGRO.has(e.id) && bigMob(e)); } catch {}
    for (const e of L) {
      if (doneE.has(e.id)) continue; doneE.add(e.id);
      try { const i = e.getDynamicProperty("mrpg:rboss"); if (typeof i === "number" && BST.get(i)?.ph === "tired") continue; } catch {}
      if (Math.random() > (isLite() ? 0.06 : 0.12) * (RM.on ? 1.5 : 1)) continue;
      try {
        const l = e.location, ang = Math.random() * Math.PI * 2, d = 6 + Math.random() * 10, tx = l.x + Math.cos(ang) * d, tz = l.z + Math.sin(ang) * d;
        const t = ow.getTopmostBlock({ x: Math.floor(tx), z: Math.floor(tz) }); if (!t || t.location.y < l.y + 3) continue;   // 近くに 建物が ない
        const ty = l.y + 2 + Math.random() * Math.min(20, t.location.y - l.y);
        e.teleport(l, { facingLocation: { x: tx, y: ty, z: tz } });
        const sid = e.getDynamicProperty("mrpg:sid"), k = kindOf(sid);
        if (k === "phys" || k === "weapon") {   /* 殴って 壁を くずす */
          try { anim(e, k === "weapon" ? "atk_slash2" : "atk_claw"); } catch {}
          const { h, w } = bodyBox(e), ux = (tx - l.x) / d, uz = (tz - l.z) / d, cx = l.x + ux * 3, cz = l.z + uz * 3;
          if (carveBox(cx - w, l.y, cz - w, cx + w, l.y + h, cz + w)) try { ow.spawnParticle("minecraft:large_explosion", { x: cx, y: l.y + h / 2, z: cz }); p.playSound("random.explode", { location: l, volume: 0.8, pitch: 1.1 }); } catch {}
        } else {
          try { anim(e, "breath"); } catch {}
          shootAt(e, eye(e), { x: tx, y: ty, z: tz }, { fx: elFx(sid), power: e.hasTag("mrpg_rboss") ? 9 : 7, sp: 1.1, big: true, life: 60, col: colOf(sid) });
        }
        try { p.playSound("mob.enderdragon.growl", { location: l, pitch: 0.7, volume: 0.8 }); } catch {}
      } catch {}
    }
  } catch {} }
}, 100);

/* 第92版: 壊れて 落ちる 砂・砂利（落ちる ブロックの 実体）が たまると 固まるので、すぐ 消す */
const LB = { t: -9999, n: 0 };   /* 第95版: 最後に 壊した 時刻。しばらく 壊して いない ときは 2秒に 1回だけ 掃除 */
system.runInterval(() => {
  if (!gateOn()) return;
  const now = system.currentTick || 0; LB.n++; if (LB.n % (now - LB.t > 200 ? 10 : 3)) return;   /* 第97版: 壊した 直後でも 12tickごと（前は 4tickごと） */
  for (const p of allP()) { try { if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location)) continue; const l = p.location; OW().runCommand(`kill @e[type=falling_block,x=${Math.floor(l.x)},y=${Math.floor(l.y)},z=${Math.floor(l.z)},r=96]`); } catch {} }
}, 4);

// 灰の 霧（常世の 中だけ）
const FOG = new Set(), FOGR = new Set();
system.runInterval(() => {
  for (const p of allP()) {
    let inR = false; try { inR = p.dimension.id === "minecraft:overworld" && inRuins(p.location); } catch { continue; }
    if (inR) { try { const d = load(p); if (d && ruOf(d).st >= 4) inR = false; } catch {} }   /* クリアした 人は 霧が 晴れる */
    if (inR && !FOG.has(p.id)) { try { p.runCommand("fog @s push mrpg:ruins ruins"); FOG.add(p.id); } catch {} }
    else if (!inR && FOG.has(p.id)) { try { p.runCommand("fog @s remove ruins"); } catch {} FOG.delete(p.id); }
    const red = inR && RM.on;   /* 第95版: 赤い 月の 夜は 赤い 霧 */
    if (red && !FOGR.has(p.id)) { try { p.runCommand("fog @s push mrpg:ruins_red ruinsred"); FOGR.add(p.id); } catch {} }
    else if (!red && FOGR.has(p.id)) { try { p.runCommand("fog @s remove ruinsred"); } catch {} FOGR.delete(p.id); }
  }
}, 40);
world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => { if (!initialSpawn) return; FOG.delete(player.id); FOGR.delete(player.id); system.runTimeout(() => { try { if (!inRuins(player.location)) player.runCommand("fog @s remove ruins"); player.runCommand("fog @s remove ruinsred"); } catch {} }, 40); });

// ---------- 宝箱の ごほうび（★8〜・常世は さらに 出やすい） ----------
const STAT4 = ["s_hp4", "s_mp4", "s_atk4", "s_def4", "s_mat4", "s_mdf4", "s_spd4", "s_wpn4", "s_brt4"], STAT3 = STAT4.map((x) => x.replace("4", "3"));
CHEST_GATE.bonus = (p, t, loc) => {
  const out = []; if (!gateOn()) return out;
  const ru = inRuins(loc), k = ru ? 2 : 1;
  if (ru && p) { if (Math.random() < 0.3) system.run(() => journalFind(p)); if (RM.on && Math.random() < 0.5) system.run(() => addAsh(p, 1, "赤い 月の 宝箱")); if (RM.on) out.push(pick(STAT3)); }   /* 第95版 */
  if (t < 8 && !ru) return out;
  if (ru && t < 8) { if (Math.random() < 0.45) out.push(pick(STAT3)); if (Math.random() < 0.08) out.push("s_all3"); return out; }   /* 第84版: 建物の 中の ふつうの 宝箱（数が 多い ので 控えめ） */
  const tt = t;
  const P = { 8: [0.1, 0.25, 0.3], 9: [0.2, 0.4, 0.45], 10: [0.35, 0.6, 0.6] }[Math.min(10, tt)] || [0, 0, 0];
  if (Math.random() < Math.min(0.9, P[0] * k)) out.push("s_all4");
  if (Math.random() < Math.min(0.95, P[1] * k)) out.push("s_all3");
  if (Math.random() < Math.min(0.95, P[2] * k)) out.push(pick(STAT4));
  if (ru && Math.random() < 0.6) out.push(pick(STAT3));
  return out;
};

// ---------- 元の 世界へ（パックを 外した とき・倒れた とき） ----------
system.runInterval(() => {
  for (const p of allP()) try { if (!inRuins(p.location) && p.getDynamicProperty("mrpg:ruSp") !== undefined && !busy.has(p.id)) restoreSpawn(p); } catch {}   /* 帰還の つばさ などで 帰った とき */
  if (gateOn() || !settled()) return;
  for (const p of allP()) {
    if (busy.has(p.id) || !inRuins(p.location)) continue;
    try { leaveRuins(p); p.sendMessage("§7追加ストーリーの パックが 入って いないので、元の 世界へ もどった。§f（進み具合は のこって いる）"); } catch {}
  }
}, 200);
export const RUINS_DEBUG = { CAMPS, BSITE, BOSS_SP, JASHIN_SP, at, ruOf, bossName, beat, BST };

/* 第94版: バグを 直す（repair.js から 呼ぶ）: 常世の こまりごと */
RU_HOOK.repair = (p) => {
  const out = []; const ow = OW();
  try {
    if (inRuins(p.location) && p.dimension.id === "minecraft:overworld") {
      try { ow.runCommand(`kill @e[type=falling_block,x=${Math.floor(p.location.x)},y=${Math.floor(p.location.y)},z=${Math.floor(p.location.z)},r=128]`); out.push("落ちて いる 砂・砂利を 消した"); } catch {}
      let landed = 0, freed = 0;
      for (const e of ow.getEntities({ type: TYPE, location: p.location, maxDistance: 64 })) {
        try {
          if (!(e.hasTag("mrpg_ruinw") || e.hasTag("mrpg_rboss")) || e.hasTag("mrpg_battle")) continue;
          if (e.hasTag("mrpg_rfly") && !AGGRO.has(e.id)) { landFly(e, null); landed++; }
          const l = e.location, b = ow.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z) });
          if (b && !b.isAir && !b.isLiquid && !e.hasTag("mrpg_ruinwt")) { const t = ow.getTopmostBlock({ x: Math.floor(l.x), z: Math.floor(l.z) }); if (t) { e.teleport({ x: l.x, y: t.location.y + 1, z: l.z }); freed++; } }
        } catch {}
      }
      if (landed) out.push(`空に 浮いた ままの 魔物 ${landed}体を 地上へ もどした`);
      if (freed) out.push(`ブロックに うまった 魔物 ${freed}体を 出した`);
      for (const [i, st] of [...BST]) { let alive0 = false; try { alive0 = !!world.getEntity(st.eid)?.isValid(); } catch {} if (!alive0 && !FIGHT.has(i)) BST.delete(i); }
      RC.delete(p.id); AIRC.delete(p.id); HB.delete(p.id);
      try { const r = p.getEffect("resistance"); if (r && r.amplifier >= 4 && !fighting(p)) { p.removeEffect("resistance"); out.push("残って いた 無敵（耐性）を 外した"); } } catch {}
      out.push(ruDiag(p).replace(/§./g, ""));
      out.push(`常世の 状態を 読みなおした（湧き ${SPD.outOk}回・いる 魔物 ${(() => { try { return ow.getEntities({ type: TYPE, tags: ["mrpg_ruinw"], location: p.location, maxDistance: 64 }).length; } catch { return 0; } })()}体）`);
    } else {
      const sp = p.getSpawnPoint?.();
      if ((sp && inRuins(sp)) || p.getDynamicProperty("mrpg:ruSp") !== undefined) { restoreSpawn(p); out.push("常世の まま だった もどり先（リスポーン）を 元に もどした"); }
    }
  } catch {}
  return out;
};

// ================= 第95版: 常世の 追加 =================
// 強さの 設定・赤い 月・群れ・待ちぶせ・魔物の 巣・弱点・調査隊の 日誌・灰晶と 灰の 工房・結界
// どれも 2〜5秒ごとの 軽い しらべ だけ（毎tickの 処理は ふやさない）

// ---------- 強さの 設定（1人ずつ。数字 1つで 保存: 百の位 魔物の 数・十の位 追いかけ・一の位 ブレスと 魔法。0 少なめ・1 ふつう・2 多め） ----------
const LVK = "mrpg:ruLv", LVC = new Map(), LV_NM = ["少なめ", "ふつう", "多め"];
function ruLv(p) {
  const now = system.currentTick || 0, c = LVC.get(p.id); if (c && now - c.t < 100) return c.v;
  let v = [1, 1, 1]; try { const n = p.getDynamicProperty(LVK); if (typeof n === "number") v = [Math.floor(n / 100) % 10, Math.floor(n / 10) % 10, n % 10].map((x) => (x >= 0 && x <= 2 ? x : 1)); } catch {}
  LVC.set(p.id, { t: now, v }); return v;
}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { LVC.delete(playerId); AIRC.delete(playerId); }); } catch {}
RU_HOOK.levelMenu = async (p) => {
  for (;;) {
    const v = [...ruLv(p)];
    const body = ["§8§l常世の 強さ", "§7自分の まわりだけ に かかる（ほかの 人は その 人の 設定）。いつでも 変えられる", "",
      `§f魔物の 数: §e${LV_NM[v[0]]}`, "§7  まわりに 出る 魔物の 数（少なめ 約4割・群れなし／多め 約1.4倍）",
      `§f追いかけ: §e${LV_NM[v[1]]}`, "§7  気づかれる 距離と、同時に 追って くる 大きい 魔物の 数（1体・2体・3体）。群れ・待ちぶせ・巣の 番人は 別に 4体まで",
      `§fブレス・魔法: §e${LV_NM[v[2]]}`, "§7  物理 以外の 攻撃の 回数（少なめは ほぼ 物理）"].join("\n");
    const nx = (i) => `${LV_NM[v[i]]}§r → ${LV_NM[(v[i] + 1) % 3]}`;
    const s = await choose(p, "常世の 強さ", body, [[`魔物の 数: §e${nx(0)}`, ICON("i_fight")], [`追いかけ: §e${nx(1)}`, ICON("i_run")], [`ブレス・魔法: §e${nx(2)}`, ICON("i_skill")], ["§7戻る", ICON("i_back")]]);
    if (!(s >= 0 && s <= 2)) return;
    v[s] = (v[s] + 1) % 3;
    try { p.setDynamicProperty(LVK, v[0] * 100 + v[1] * 10 + v[2]); } catch {}
    LVC.delete(p.id); sound(p, "random.click");
  }
};

// ---------- 赤い 月（4日に 1回くらいの 夜。魔物が 増えて 強く なる・宝箱が よく なる） ----------
const RM = { on: false };
const redDay = (n) => ((n * 37 + 11) % 4) === 0;
system.runInterval(() => {
  if (!gateOn()) { RM.on = false; return; }
  let on = false;
  try { const t = world.getTimeOfDay(), day = typeof world.getDay === "function" ? world.getDay() : Math.floor(world.getAbsoluteTime() / 24000); on = t >= 13000 && t < 23000 && redDay(day); } catch {}
  if (on === RM.on) return;
  RM.on = on;
  for (const p of allP()) {
    try {
      if (!inRuins(p.location)) continue;
      if (on) { p.onScreenDisplay.setTitle("§4§l赤い 月", { subtitle: "§c魔物が 増えて 凶暴に なった！ §6宝箱も よく なる", fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 15 }); p.playSound("mob.wither.ambient", { pitch: 0.5, volume: 1 }); }
      else p.onScreenDisplay.setActionBar("§7赤い 月が 沈んだ……");
    } catch {}
  }
}, 100);

// ---------- 群れ（小さい 魔物が 2〜3体で 囲んで くる） ----------
const WPOOL_PACK = (() => { const L = WPOOL_IN.filter((s) => ["beast", "animal", "nether"].includes(SPECIES[s].fam)); return L.length ? L : WPOOL_IN; })();
const SMALL_PAT = new Set(["bite", "rend", "tail", "throw", "pounce", "slash"]);   /* 小さい 魔物の 技（建物を 大きく 壊す 技は 使わない） */
const chaser = (e) => { try { return bigMob(e) || e.hasTag("mrpg_rpack"); } catch { return false; } };
function spawnPack(p, list) {
  for (let t = 0; t < 6; t++) {
    const a = Math.random() * Math.PI * 2, dist = 18 + Math.random() * 16, x = p.location.x + Math.cos(a) * dist, z = p.location.z + Math.sin(a) * dist;
    if (!inRuins({ x, z }) || nearCamp({ x, z }, 26)) continue;
    const c = colInfo(x, z); if (!c || !c.open) continue;
    const sid = pick(WPOOL_PACK), id = ri(1, 999999), n = 2; let k0 = 0;
    for (let k = 0; k < n; k++) { const e = spawnRW(sid, { x: x + ri(-2, 2), y: c.y, z: z + ri(-2, 2) }, "pk"); if (e) { try { e.addTag("mrpg_rpack"); e.setDynamicProperty("mrpg:pk", id); } catch {} list.push(e); k0++; } }
    if (k0) try { p.onScreenDisplay.setActionBar(`§c遠ぼえが 聞こえる…… §7（${SPECIES[sid].name}の 群れ）`); p.playSound("mob.wolf.growl", { location: { x, y: c.y, z }, volume: 1, pitch: 0.6 }); } catch {}
    return k0;
  }
  return 0;
}
const pkCount = (p) => { let n = 0; for (const a of AGGRO.values()) if (a.pid === p.id && a.pk) n++; return n; };   /* 群れ・待ちぶせ・巣の 番人は 1人 4体まで（重く しない） */
function packJoin(e, p, now) {   /* 1体に 見つかると 群れ ぜんぶが 来る（群れは 1つで 1体 ぶんと 数える） */
  try {
    if (!e.hasTag("mrpg_rpack")) return; const id = e.getDynamicProperty("mrpg:pk");
    for (const o of OW().getEntities({ type: TYPE, tags: ["mrpg_rpack"], location: e.location, maxDistance: 20 })) if (o.id !== e.id && !AGGRO.has(o.id) && o.getDynamicProperty("mrpg:pk") === id && pkCount(p) < 4) AGGRO.set(o.id, { pid: p.id, until: now + 600, cd: now + 30 + ri(0, 20), seen: now, pk: true });
  } catch {}
}
// ---------- 待ちぶせ（建物の 中の 魔物の 一部は じっと 待って いて、近づくと 飛びだす） ----------
function ambushCheck(p, sneak, now) {
  try {
    for (const e of OW().getEntities({ type: TYPE, tags: ["mrpg_ramb"], location: p.location, maxDistance: sneak ? 3.5 : 7 })) {
      if (AGGRO.has(e.id) || e.hasTag("mrpg_battle") || pkCount(p) >= 4) continue;
      e.removeTag("mrpg_ramb");
      AGGRO.set(e.id, { pid: p.id, until: now + 400, cd: now + 4, seen: now, pk: true });
      p.onScreenDisplay.setActionBar(`§c§l待ちぶせ！ §r§c${SPECIES[e.getDynamicProperty("mrpg:sid")]?.name || "魔物"}が 物かげから 飛びだした！`);
      p.playSound("mob.ravager.roar", { pitch: 1.4, volume: 1 }); shake(p, 0.4, 0.5);
    }
  } catch {}
}

// ---------- 配下の 激昂と 弱点（暴走の 後半: 体が ときどき 光る。光って いる 間に なぐると よろめいて 暴走が 短く なり、戦いでの HPも 減る） ----------
const bossP2 = (e) => { try { const st = BST.get(e.getDynamicProperty("mrpg:rboss")); return !!st && st.ph === "rage" && !!st.p2; } catch { return false; } };
function bossP2Tick(i, e, st, now, near) {
  if (!st.p2 && now >= st.t - Math.floor(RAGE(i) * 0.5)) {
    st.p2 = true; st.wn = now + 60;
    for (const p of near) try { p.onScreenDisplay.setTitle("§4§l激昂！", { subtitle: "§e体が 光ったら なぐれ！ §7暴走が 短く なる", fadeInDuration: 4, stayDuration: 50, fadeOutDuration: 10 }); p.playSound("mob.enderdragon.growl", { pitch: 0.4, volume: 1 }); } catch {}
  }
  if (!st.p2) return;
  if (now >= (st.wn || 0)) {
    st.wk = now + 60; st.wn = now + 200;
    for (const p of near) try { p.onScreenDisplay.setActionBar(`§e§l${bossName(i)}の 弱点が 光った！ §r§f今 なぐれ（3秒）`); p.playSound("random.orb", { pitch: 0.5, volume: 1 }); } catch {}
  }
  if (now < (st.wk || 0)) {
    try { const l = e.location, hh = Math.min(30, (lookOf(e.getDynamicProperty("mrpg:sid") || BOSS_SP[0], { sz: "G" }).size * BIG) / 100 * 1.3); fxp("circle", { x: l.x, y: l.y + hh, z: l.z }, ECOL.light, 4); fxp("pillar", { x: l.x, y: l.y + 0.2, z: l.z }, ECOL.light, 3); } catch {}
  }
}
function bossStagger(p, e, i, st) {
  st.wk = 0; st.hits = (Number(st.hits) || 0) + 1; st.t -= Math.floor(RAGE(i) * 0.25);
  try { const l = e.location; OW().spawnParticle("minecraft:huge_explosion_emitter", { x: l.x, y: l.y + 3, z: l.z }); fxp("shock", { x: l.x, y: l.y + 2, z: l.z }, ECOL.light, 6); } catch {}
  for (const q of OW().getPlayers({ location: e.location, maxDistance: 80 })) try { q.onScreenDisplay.setTitle("§e§lよろめいた！", { subtitle: `§f弱点を 突いた（${st.hits}回）・暴走が 短く なった${st.hits <= 2 ? `\n§f戦いでの HP -${st.hits * 10}%` : ""}`, fadeInDuration: 2, stayDuration: 40, fadeOutDuration: 8 }); q.playSound("random.anvil_land", { pitch: 0.6, volume: 1 }); } catch {}
}

// ---------- 灰晶（邪神の 力が 冷えて 固まった 結晶。セーブの ru.ash に 数だけ 持つ） ----------
function addAsh(p, n, why) {
  try { if (!ok(p)) return; const d = load(p); if (!d) return; const r = ruOf(d); if (r.st < 2) return; r.ash = (Number(r.ash) || 0) + n; save(p, d); RC.delete(p.id); p.sendMessage(`§d灰晶 ×${n} §7を 手に入れた（${why}・持って いる ${r.ash}）`); } catch {}
}
const ASH_SHOP = [["ac_ru1", 20, "すべての 攻撃の ダメージ +8%"], ["ac_ru2", 30, "与えた ダメージの 5%を 回復（いつも）・HPが 3割 未満の とき 与える ダメージ 1.35倍"], ["ac_ru3", 25, "HPが 満タンの とき たおれる 一撃を 1回 ふんばる・毎ターン MPが 少し 回復"], ["s_all3", 10, "全能力が 少し 上がる 実"]];
async function ashShop(p) {
  for (;;) {
    const d = load(p); if (!d) return; const r = ruOf(d), have = Number(r.ash) || 0;
    const L = ASH_SHOP.filter(([id]) => ITEMS[id]);
    const s = await choose(p, "灰の 工房", `§7灰晶で 常世 だけの 品を 作って もらえる\n§f持って いる: §d灰晶 ×${have}\n§8灰晶は 魔物の 巣・配下・赤い 月の 夜の 宝箱・調査隊の 日誌で 手に入る`,
      [...L.map(([id, n, ds]) => [`${ITEMS[id].name} §d灰晶 ×${n}\n§8${ds}`, ICON("i_star")]), ["§7もどる", ICON("i_back")]]);
    if (!(s >= 0 && s < L.length)) return;
    const [id, n] = L[s];
    const d2 = load(p); if (!d2) return; const r2 = ruOf(d2);
    if ((Number(r2.ash) || 0) < n) { await notice(p, "灰の 工房", `§c灰晶が たりない。§7（あと ${n - (Number(r2.ash) || 0)}）`); continue; }
    r2.ash -= n; save(p, d2); RC.delete(p.id); giveItem(p, `mrpg:${id}`, 1); sound(p, "random.anvil_use");
  }
}

// ---------- 結界（キャンプの 安全な 範囲を 広げる。ワールドの みんなで 共有） ----------
function barLv() { try { const v = JSON.parse(world.getDynamicProperty("mrpg:rbar") || "[]"); return Array.isArray(v) ? v : []; } catch { return []; } }
const BAR_COST = [[5, 50000], [15, 150000]];
async function barrierMenu(p, k) {
  const d = load(p); if (!d) return; const r = ruOf(d), lv = Number(barLv()[k]) || 0;
  if (lv >= 2) { await notice(p, "結界", "§b結界は もう いちばん 強い。§7（魔物が 近よらない 範囲 +16m）"); return; }
  const [na, ng] = BAR_COST[lv];
  if (!(await confirm(p, "結界を 強める", `§f${CAMPS[k].name}の 結界を 強めますか？\n§7段階 ${lv} → ${lv + 1}（魔物が 近よらない・壊されない 範囲が 8m 広がる）\n§f必要: §d灰晶 ×${na}§f・${gold(ng)}\n§7持って いる: 灰晶 ×${Number(r.ash) || 0}・${gold(d.gold)}\n§8結界は この ワールドの みんなで 共有`, "強める", "やめる"))) return;
  const d2 = load(p); if (!d2) return; const r2 = ruOf(d2), B = barLv();
  if ((Number(B[k]) || 0) !== lv) { await notice(p, "結界", "§7ほかの 人が 先に 結界を 強めた。§f（お金と 灰晶は 減って いない）"); return; }
  if ((Number(r2.ash) || 0) < na || (d2.gold || 0) < ng) { await notice(p, "結界を 強める", "§c灰晶か お金が たりない。\n§7灰晶は 魔物の 巣・配下・赤い 月の 夜の 宝箱・調査隊の 日誌で 手に入る"); return; }
  r2.ash -= na; d2.gold -= ng; save(p, d2); RC.delete(p.id);
  while (B.length < CAMPS.length) B.push(0);
  B[k] = lv + 1; try { world.setDynamicProperty("mrpg:rbar", JSON.stringify(B)); } catch {} CIC.t = -999;
  sound(p, "random.levelup", 0.9);
  await notice(p, "結界", `§b結界が 強く なった！ §f（段階 ${lv + 1}・安全な 範囲 +${(lv + 1) * 8}m）\n§7キャンプの まわりに 光の 輪が 見える`);
}
system.runInterval(() => {   /* 結界の 光の 輪（近くに いる 人にだけ・12粒） */
  if (!gateOn()) return;
  const L = campList(); if (!L.some((q) => q.b)) return;
  for (const p of allP()) {
    try {
      if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location)) continue;
      for (const q of L) { if (!q.b) continue; const R = 16 + q.b, dd = Math.hypot(p.location.x - q.x, p.location.z - q.z); if (dd > R + 30) continue;
        for (let j = 0; j < 12; j++) { const a = j * Math.PI / 6; OW().spawnParticle("minecraft:endrod", { x: q.x + Math.cos(a) * R, y: p.location.y + 0.5, z: q.z + Math.sin(a) * R }); } }
    } catch {}
  }
}, 40);

// ---------- 魔物の 巣（街の あちこちに 10か所。黒い 塚の 真ん中の 核を 壊すと、その 日は まわりの 湧きが 減る） ----------
const NEST = []; for (let k = 0; k < 10; k++) { const a = (k * 36 + 18) * Math.PI / 180, r = [260, 520, 700][k % 3]; NEST.push({ dx: Math.round(Math.cos(a) * r), dz: Math.round(Math.sin(a) * r) }); }
const NKEY = (k) => `mrpg:rnp:${k}`, NPOS = new Map(), NTRY = new Map(), NGUARD = new Map(), NMSG = new Set();
function nestPos(k) {   /* undefined: まだ 置いて いない / {x,y,z}: 核の 場所 */
  if (NPOS.has(k)) return NPOS.get(k);
  let q; try { const v = world.getDynamicProperty(NKEY(k)); if (typeof v === "string") q = JSON.parse(v); } catch {}
  if (q && typeof q.x === "number") { NPOS.set(k, q); return q; }
  return undefined;
}
const NDEAD = { d: "", b: [], t: -999 };
function nestDead(k) {
  const now = system.currentTick || 0;
  if (now - NDEAD.t >= 100 || NDEAD.d !== dayKey()) {
    NDEAD.t = now;
    try { const v = JSON.parse(world.getDynamicProperty("mrpg:rnest") || "{}"); NDEAD.d = v.d || ""; NDEAD.b = Array.isArray(v.b) ? v.b : []; } catch { NDEAD.b = []; }
    if (NDEAD.d !== dayKey()) { NDEAD.d = dayKey(); NDEAD.b = []; }   /* 日が 変わると 巣は また できる */
  }
  return NDEAD.b.includes(k);
}
function nestNear(l, R = 72) { for (let k = 0; k < NEST.length; k++) { const q = NPOS.get(k); if (q && Math.hypot(q.x - l.x, q.z - l.z) < R) return { k, q, dead: nestDead(k) }; } return null; }
function nestPlace(k, c) {
  for (let d = 0; d <= 40; d += 5) for (let j = 0; j < (d ? 8 : 1); j++) {
    const a = j * Math.PI / 4, x = Math.floor(c.x + Math.cos(a) * d), z = Math.floor(c.z + Math.sin(a) * d);
    if (nearCamp({ x, z }, 60)) continue;
    const ci = colInfo(x, z); if (!ci || !ci.open || ci.water) continue;
    const y = Math.floor(ci.y), q = { x, y: y + 1, z };
    for (const cm of [`fill ${x - 3} ${y} ${z - 3} ${x + 3} ${y + 3} ${z + 3} air`, `fill ${x - 3} ${y - 1} ${z - 3} ${x + 3} ${y - 1} ${z + 3} blackstone`, `fill ${x - 1} ${y} ${z - 1} ${x + 1} ${y} ${z + 1} soul_soil`,
      ...[[-3, -3], [3, -3], [-3, 3], [3, 3]].map(([ox, oz]) => `fill ${x + ox} ${y} ${z + oz} ${x + ox} ${y + 2} ${z + oz} crying_obsidian`), `setblock ${x} ${y + 1} ${z} sculk_catalyst`]) CMD(cm);
    try { world.setDynamicProperty(NKEY(k), JSON.stringify(q)); } catch {}
    NPOS.set(k, q); return q;
  }
  return null;
}
system.runInterval(() => {
  if (!gateOn()) return;
  const now = system.currentTick || 0;
  for (const p of allP()) {
    try {
      if (p.dimension.id !== "minecraft:overworld" || !inRuins(p.location) || fighting(p) || !playing(p)) continue;
      const r = ruCached(p); if (!r || r.st < 2) continue;
      const L = p.location;
      for (let k = 0; k < NEST.length; k++) {
        const c = at(NEST[k]); if (Math.hypot(L.x - c.x, L.z - c.z) > 110) continue;
        const q = nestPos(k);
        if (q === undefined) { if (now < (NTRY.get(k) || 0) || (RU.pre === false && !lotReady(c.x, c.z))) continue; NTRY.set(k, now + 200); if (nestPlace(k, c)) try { p.onScreenDisplay.setActionBar("§4黒い 塚が 盛り上がった…… §7（魔物の 巣）"); } catch {} continue; }
        if (nestDead(k)) continue;
        const dd = Math.hypot(L.x - q.x, L.z - q.z);
        if (dd > 96) continue;
        try { const b = OW().getBlock(q); if (b && b.typeId !== "minecraft:sculk_catalyst") CMD(`setblock ${q.x} ${q.y} ${q.z} sculk_catalyst`); } catch {}   /* 魔物に 壊された 核は もどる（プレイヤーが 壊した 日は もどらない） */
        fxp("pillar", { x: q.x + 0.5, y: q.y + 1, z: q.z + 0.5 }, ECOL.dark, 2);
        const mk = `${p.id}|${k}`;
        if (dd < 72 && !NMSG.has(mk)) { NMSG.add(mk); try { p.onScreenDisplay.setActionBar("§4魔物の 巣が 近い…… §7（黒い 塚の 真ん中の 核を 壊すと、今日は 湧きが 減る）"); } catch {} }
        if (dd < 24 && now >= (NGUARD.get(k) || 0) && pkCount(p) < 4) {   /* 巣の 番人（30秒に 1体まで） */
          NGUARD.set(k, now + 600);
          const gx = q.x + ri(-8, 8), gz = q.z + ri(-8, 8), gs = colInfo(gx, gz);
          if (gs && !gs.water) { const e = spawnRW(pick(WPOOL), { x: gx, y: gs.y, z: gz }); if (e) { try { e.addTag("mrpg_rguard"); e.nameTag = `§4[巣の 番人] ${e.nameTag}`; } catch {} AGGRO.set(e.id, { pid: p.id, until: now + 600, cd: now + 40, seen: now, pk: true }); try { p.onScreenDisplay.setActionBar("§4§l巣の 番人が 現れた！"); p.playSound("mob.ravager.roar", { pitch: 0.5, volume: 1 }); } catch {} } }
        }
      }
    } catch {}
  }
}, 40);
world.beforeEvents.playerBreakBlock.subscribe((ev) => {
  try {
    const b = ev.block; if (b.typeId !== "minecraft:sculk_catalyst" || b.dimension.id !== "minecraft:overworld" || !inRuins(b.location)) return;
    const l = b.location;
    for (let k = 0; k < NEST.length; k++) { const q = nestPos(k); if (q && q.x === l.x && q.y === l.y && q.z === l.z) { ev.cancel = true; const p = ev.player; system.run(() => nestBreak(p, k)); return; } }   /* 核は 落ちない（自前で 消す） */
  } catch {}
});
function nestBreak(p, k) {
  const q = NPOS.get(k); if (!q || nestDead(k)) return;
  NDEAD.b.push(k); try { world.setDynamicProperty("mrpg:rnest", JSON.stringify({ d: NDEAD.d, b: NDEAD.b })); } catch {}
  CMD(`setblock ${q.x} ${q.y} ${q.z} air`);
  try { const ow = OW(); ow.spawnParticle("minecraft:huge_explosion_emitter", q); fxp("shock", q, ECOL.dark, 6);
    for (const o of ow.getPlayers({ location: q, maxDistance: 48 })) { o.playSound("mob.wither.death", { volume: 0.8, pitch: 1.2 }); o.onScreenDisplay.setTitle("§a巣を 壊した！", { subtitle: "§fこの あたりの 魔物が 今日は 少なく なる", fadeInDuration: 4, stayDuration: 50, fadeOutDuration: 10 }); } } catch {}
  try {
    if (!ok(p)) return; const d = load(p); if (!d) return; const r = ruOf(d); if (r.st < 2) return;
    r.ash = (Number(r.ash) || 0) + 3; d.gold += 30000; save(p, d); RC.delete(p.id);
    const got = ["§d灰晶 ×3", gold(30000)];
    if (Math.random() < 0.5) { const id = pick(STAT3); if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, 1); got.push(ITEMS[id].name); } }
    p.sendMessage(`§6巣の 核から 手に入れた: §f${got.join("・")}`);
  } catch {}
}
RU_HOOK.beams = (p) => {   /* 目的地の 光（guide.js）: 近くの 巣に 赤い 柱 */
  const out = [];
  try { if (!gateOn() || !inRuins(p.location)) return out;
    for (const [k, q] of NPOS) { if (out.length >= 2) break; if (!q || nestDead(k)) continue; const dd = Math.hypot(q.x - p.location.x, q.z - p.location.z); if (dd <= 6 || dd >= 160) continue; if (dd <= 64) out.push({ x: q.x + 0.5, y: q.y, z: q.z + 0.5 }); else { const f = 60 / dd; out.push({ x: p.location.x + (q.x - p.location.x) * f, y: p.location.y, z: p.location.z + (q.z - p.location.z) * f }); } } } catch {}
  return out;
};

// ---------- 調査隊の 日誌（常世の 宝箱から 1枚ずつ） ----------
const JOURNAL = [
  "調査隊 一日目。街の 北の 空に 細い ひびを 見つけた。隊長の 私が 記録を つける。",
  "ひびは 毎晩 少しずつ 広がる。街の 人は 気づいて いない。神殿の 若い 神官だけが、夜どおし 空を 見て いた。",
  "記録塔の 計器が おかしい。だれも いない はずの 空から、規則正しい 鼓動が 届く。",
  "ひびの 向こうに 何かが いる。赤い 光が 二つ。こちらを 数えるように 動く。",
  "街の 地下を 掘った 昔の 人たちは、あれを『名を 呼んでは ならぬ もの』と 書いて いた。",
  "空が 裂けた 夜、山のような 影が 15、街に 降りた。隊の 半分が もどらなかった。",
  "魔物は 火を 嫌う。たき火の まわりに 集まれば、朝まで 生きられる。各地に キャンプを 作ろう。",
  "魔物は 巣を 作る。黒い 塚の 真ん中で、脈打つ 核が 光って いる。壊せば しばらく 静かに なる。",
  "赤い 月の 夜は 外に 出るな。魔物が 増え、目つきが 変わる。そのかわり、灰の 中から 光る 結晶が 見つかる。",
  "灰晶。邪神の 力が 冷えて 固まった ものらしい。神官は これで たき火の 結界を 強く できると 言った。",
  "隊員が 一人ずつ 影に なって いく。名前を 書いて おかなければ。……書いた はずの 名前が、もう 読めない。",
  "私も じきに 影に なる。最後に 書く。魔将は 暴れ疲れると 動きが 止まる。光る 弱点を 突け。この 記録を 見つけた だれかへ。",
];
function journalFind(p) {
  try {
    if (!ok(p)) return; const d = load(p); if (!d) return; const r = ruOf(d); const n = Number(r.j) || 0;
    if (r.st < 2 || n >= JOURNAL.length) return;
    r.j = n + 1; const done = r.j >= JOURNAL.length;
    if (done) { r.ash = (Number(r.ash) || 0) + 10; d.gold += 100000; }
    save(p, d); RC.delete(p.id);
    p.sendMessage(`§d§l調査隊の 日誌 ${r.j}/${JOURNAL.length} §r§7を 見つけた\n§f「${JOURNAL[n]}」`); sound(p, "item.book.page_turn");
    if (done) p.sendMessage(`§6§l日誌が すべて そろった！ §r§f灰晶 ×10・${gold(100000)} を 手に入れた`);
  } catch {}
}
function journalText(d) {
  if (!d) return ""; const r = ruOf(d), n = Math.min(JOURNAL.length, Number(r.j) || 0);
  return [`§d§l調査隊の 日誌 §7（${n}/${JOURNAL.length}）`, "§8常世の 宝箱から 見つかる", "", ...JOURNAL.map((t, i) => (i < n ? `§f${i + 1}. ${t}` : `§8${i + 1}. ？？？`))].join("\n");
}
async function readLore(p) {
  const d = load(p); if (!d) return; const r = ruOf(d);
  const s = await choose(p, "記録", "§7どれを 読む？", [[`§d§l神官の 記録 §r§8（${beat(r)}/15）`, ICON("i_zukan")], [`§d§l調査隊の 日誌 §r§8（${Math.min(JOURNAL.length, Number(r.j) || 0)}/${JOURNAL.length}）`, ICON("i_zukan")], ["§7戻る", ICON("i_back")]]);
  if (s === 0) await notice(p, "神官の 記録", loreText(load(p)));
  else if (s === 1) await notice(p, "調査隊の 日誌", journalText(load(p)));
}
const NEW95 = ["§5§l常世に 新しい ことが 増えた", "",
  "§f・§c群れ§f: 小さい 魔物が 2体で まわりを 囲んで くる（建物は 壊さない）",
  "§f・§c待ちぶせ§f: 建物の 中の 魔物が 物かげから 飛びだす（しゃがむと 気づかれにくい）",
  "§f・§4魔物の 巣§f: 黒い 塚の 真ん中の 核を 壊すと、その 日は まわりの 湧きが 減る（赤い 光の 柱が 目印）",
  "§f・§4赤い 月§f: ときどき 来る 夜。魔物が 増えて 強く なるが、宝箱も よく なる",
  "§f・§e弱点§f: 配下（と 邪神）が 激昂したら、体が 光った 時に なぐる と 暴走が 短く なり、戦いの HPも 減る",
  "§f・§d調査隊の 日誌§f: 宝箱から 見つかる。キャンプの「神官の 記録」で 読める",
  "§f・§d灰晶§f: 巣・配下・赤い 月・日誌で 手に入る。§d灰の 工房§f で 特別な 装飾品、§b結界§f を 強める のにも 使う",
  "§f・§7常世の 強さ§f: 魔物の 数・追いかけ・ブレスと 魔法を それぞれ 少なめ／ふつう／多め に できる（キャンプ・設定）"];
Object.assign(RUINS_DEBUG, { hurtP, ruLv, RM, NEST, NPOS, nestPlace, nestBreak, nestDead, nestNear, spawnPack, spawnRW, AGGRO, journalFind, JOURNAL, ashShop, barrierMenu, barLv, campList, bossStagger, LVK });
