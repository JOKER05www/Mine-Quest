// 第106版: 町・城下町を 歩く 人たち（近くに プレイヤーが いる ときだけ 出る・軽い 動き）
// 道すじは 町を 作った ときに world の mrpg:walk:<町の id> に 保存してある（中心からの 相対座標）
import { world, system } from "@minecraft/server";
import { personName, nearNpcs } from "./names.js";   /* 第106版: 同じ 見た目でも 名前は ちがう */
import { ok, isLite, sound, setJob, busy } from "./ui.js";
import { NPC_HOOKS } from "./npchook.js";
import { chatWith, greetLine } from "./chat.js";
import { PSKIN } from "./skinjobs.js";
/* 第106版: 町を 歩く 人にも 顔（スキン）を。キー → 役割（話す 内容） */
const TOWNS_SK = { rosa: 24, shiori: 24, tetsu: 23, toma: 23, milk: 24, hanna: 24, kanon: 26, mimi: 24, taro: 23, baba: 23, allen: 25, milfy: 25, leaf: 25, gantz: 25, sera: 25, ed: 23, emma: 24, nico: 26, zenia: 26, jack: 26, wolf: 25, otto: 23, hans: 23, noel: 24, shiori2: 24, mimosa: 24, kaede: 25, luna2: 25, moka: 24, aoi: 25, sakuya: 24, lily: 26, maria2: 24, rosa2: 24, kaori: 24, hanna2: 24, clarice: 24, erika: 25, viola: 26, ayame: 24, beatrice: 24, milka: 24, gracia: 25, jasmine: 26, sayo: 24, tsubaki: 24, yuki: 24, fio: 26, tia: 24, guy: 25, don: 24, crow: 26, leon: 25, zaza: 26, miko: 24, m6_kaito: 25, m6_ruben: 25, m6_grant: 25, m6_sid: 25, m6_bram: 25, m6_zack: 25, m6_ivan: 25, m6_noah: 25, m6_bolt: 23, m6_paolo: 26, m6_genzo: 23, m6_umi: 23, m6_hector: 26, m6_kenta: 26, m6_otis: 23, m6_basil: 23, m6_tomas: 23, m6_mason: 23, m6_felix: 26, m6_dario: 23, m6_gil: 23, m6_rafa: 26, m6_pierre: 23, m6_hugo: 23, m6_garrett: 25, m6_aldo: 25, m6_rook: 23, m6_takeru: 25, m6_brother: 23, m6_father: 23, m6_gramps: 23, m6_sage: 23, m6_kanji: 23, m6_vito: 23, m6_otto2: 23, m6_sota: 23, m6_pip: 23, m6_leo2: 23, m6_jin2: 23, m6_milo: 23, m6_kai2: 23, m6_riku: 25, m6_samir: 26, m6_eirik: 23, m6_vulk: 23, m6_lugh: 23, m6_crystal: 23, m6_noct: 23, m6_aero: 25, m6_dock: 23 };   /* 第117版: 町の 男性 50人 */   /* 第106版: 美少女・お姉さん 30人（水着の 人は 海辺） */

const OW = () => world.getDimension("overworld");
const WJOBS = [23, 24, 25, 26];
const NAMES = ["ミーナ", "トマス", "リオ", "エマ", "グスタフ", "ノエル", "ハンナ", "ペトロ", "サラ", "ユリウス", "アンナ", "カイ", "ロッテ", "マルコ", "ニナ", "オスカー", "ララ", "ベン", "ソフィ", "ヨハン"];
const ROLE = { 23: "町の人", 24: "町の人", 25: "冒険者", 26: "行商人" };
const LINES = {
  23: ["今日も いい 天気だな", "広場の 噴水は 町の 自慢なんだ", "城の 坂を 上ると 町が 一望できるよ", "夜は 酒場が にぎやかでね", "最近 畑を 荒らす モンスターが 出て 困ってるんだ"],
  24: ["市場の 野菜は 朝が いちばん 新鮮よ", "レストランの ケーキ、食べた？", "子どもたちが 遊び場の 話ばかり するの", "教会の 鐘が 鳴ると お昼なの", "モンスターと 暮らすって すてきね"],
  25: ["協会の 掲示板、今日は いい 依頼が あるかな", "C級に 上がるまで 3年 かかったよ……", "手配モンスターは 手ごわいぜ。回復は 多めにな", "遠くの 調査依頼は 座標を 見ると いい", "X級の 冒険者なんて 伝説の 中の 話さ"],
  26: ["遠い 町から 来たんだ。港町の 魚は 絶品だぞ", "砂漠の 町では 水が 金より 高い", "雪の 町の 薬草茶は 体が あたたまる", "商売の コツ？ 笑顔と 足の 速ささ", "ノクス団の せいで 街道が 物騒でね"],
};
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const hashC = (t) => { let h = 7; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
/* 第113版: 町の 一日（時間・雨・お祭り）。どれも 安く 読める ように 少し 覚えておく */
let RAIN = false, RT = 0;
try { world.afterEvents.weatherChange.subscribe((ev) => { try { RAIN = /rain|thunder/i.test(String(ev.newWeather || "")); RT = Date.now(); } catch {} }); } catch {}
export function rainNow() { if (Date.now() - RT > 5000) { RT = Date.now(); try { const d = OW(); if (typeof d.getWeather === "function") RAIN = /rain|thunder/i.test(String(d.getWeather())); } catch {} } return RAIN; }
export function slotNow() { let t = 6000; try { t = world.getTimeOfDay(); } catch {} return t >= 23000 || t < 3000 ? "morning" : t < 5000 ? "day" : t < 8000 ? "noon" : t < 11000 ? "day" : t < 13500 ? "evening" : "night"; }
export function gameDay() { try { if (typeof world.getDay === "function") return world.getDay(); } catch {} try { if (typeof world.getAbsoluteTime === "function") return Math.floor(world.getAbsoluteTime() / 24000); } catch {} return Math.floor(Date.now() / 86400000); }
export const festNow = (A) => !!A && slotNow() !== "night" && hashC(`${A.id}:${gameDay()}`) % 5 === 0;
/* 時間ごとに 行きやすい 場所 [場所, 割合] と、着いたら する しぐさ */
const SCHED = { morning: [["plaza", 0.35], ["harbor", 0.15]], day: [["plaza", 0.2], ["harbor", 0.12]], noon: [["cafe", 0.3], ["diner", 0.3]], evening: [["inn", 0.3], ["diner", 0.2], ["harbor", 0.08]], night: [["inn", 0.5]] };
const STAY = { plaza: { morning: [4, 5, 14], day: [14, 4, 6], noon: [14, 4], evening: [4, 10], night: [14], fest: [7, 7, 9, 6] }, cafe: [3, 2, 4], diner: [2, 3, 4], inn: { morning: [14], day: [14, 4], noon: [3, 14], evening: [13, 4, 13], night: [14] }, harbor: [1, 1, 14] };
export const LIFE = {};   /* townlife.js が 入れる: pair(a, b) 立ち話の とき */

// ---------- 道すじの 記録 ----------
let AREAS = [], AREA_T = 0;
function areas() {
  if (Date.now() - AREA_T < 30000) return AREAS;
  AREA_T = Date.now(); const out = [];
  try {
    for (const id of JSON.parse(world.getDynamicProperty("mrpg:walkids") || "[]")) {
      if (typeof id !== "string") continue;
      try { const v = JSON.parse(world.getDynamicProperty(`mrpg:walk:${id}`) || "null"); if (v && Array.isArray(v.w) && v.w.length) { out.push({ id, x: v.x, y: v.y, z: v.z, w: v.w.filter((r) => Array.isArray(r) && r.length >= 2), s: Array.isArray(v.s) ? v.s : [], p: Array.isArray(v.p) ? v.p : [], r: id.startsWith("c") ? 76 : 48 }); } } catch {}
    }
  } catch {}
  return (AREAS = out);
}
export const resetWalkCache = () => { AREA_T = 0; };

// ---------- 歩く 人（第109版: 作りなおし）----------
// ・壁や 家を 通りぬけない: 1歩 ごとに 足もとと 頭の ブロックを 見て、ふさがって いれば 別の 道へ
// ・一列に ならばない: 1人 1人 道の 左右に ずれた「自分の 歩く 線」と 速さを もつ。2〜3人で ならんで 歩く 組も いる
// ・ベンチや テラスに 座る・すれちがった 人と 立ち話を する（しぐさ mrpg:act）
const W = new Map();   // id → { e, a, tg:{x,y,z,seat?}, lane, sp, wait, x, y, z, mode, lead, blk, talk }
const tagOf = (id) => `mrpg_wk_${id}`.replace(/[^A-Za-z0-9_]/g, "_");
const PASS_RE = /^minecraft:(air|short_grass|tall_grass|grass|fern|large_fern|deadbush|snow_layer|torch|soul_torch|vine|glow_lichen|red_flower|yellow_flower|poppy|dandelion|cornflower|oxeye_daisy|azure_bluet|allium|blue_orchid|lily_of_the_valley|pink_petals|wildflowers|rail|redstone_wire|light_block)$|_carpet$|_tulip$|_sapling$|_button$|_pressure_plate$|_sign$|_banner$/;
const NOSTAND = /fence|wall|pane|bars|leaves|cactus|campfire|water|lava|_slab$|stairs/;
function blockAt(x, y, z) { try { return OW().getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }); } catch { return undefined; } }
const pass = (b) => !b || b.isAir || PASS_RE.test(b.typeId);
/* (x,z) で 立てる 高さ（今の 高さから +1〜-2）。読みこまれて いない 所は undefined（そのまま 進む）*/
/* 第111版: 同じ マスの 結果は 20秒 おぼえる（ブロックを 何度も 調べない・軽く）*/
const SY = new Map(); let SYT = 0;
function standY(x, z, y0) {
  const now = Date.now(); if (now - SYT > 20000) { SY.clear(); SYT = now; }
  const k = `${Math.floor(x)},${Math.floor(z)},${Math.floor(y0)}`; if (SY.has(k)) return SY.get(k);
  const r = standY0(x, z, y0); if (r !== undefined) SY.set(k, r); return r;
}
function standY0(x, z, y0) {
  let any = false;
  for (const dy of [0, 1, -1, -2]) {
    const y = Math.floor(y0) + dy, f = blockAt(x, y, z), h = blockAt(x, y + 1, z), g = blockAt(x, y - 1, z);
    if (f === undefined || g === undefined) continue; any = true;
    if (pass(f) && pass(h) && !pass(g) && !g.isLiquid && !NOSTAND.test(g.typeId)) return y;
  }
  return any ? null : undefined;
}
const DRESS = Object.keys(TOWNS_SK);
/* 第109版: 町の 人の 見た目と 名前（店の 客にも 使う）*/
export function dressCitizen(e, act = 0, place = "") {
  const keys = DRESS.filter((k) => PSKIN[k]), key = keys.length ? pick(keys) : null, j = key ? TOWNS_SK[key] : pick(WJOBS);
  try {
    if (key) { setJob(e, PSKIN[key][0]); e.setDynamicProperty("mrpg:wr", j); e.setDynamicProperty("mrpg:pk", key); e.nameTag = `§f${personName(PSKIN[key][1], PSKIN[key][2], nearNpcs(e.location))}`; }
    else { setJob(e, j); e.nameTag = `§f${ROLE[j]} ${pick(NAMES)}`; }
    e.addTag("mrpg_npc"); if (act) { e.addTag("mrpg_patron"); if (place) e.setDynamicProperty("mrpg:place", place); e.setDynamicProperty("mrpg:act0", act); system.runTimeout(() => { try { if (e.isValid()) e.setProperty("mrpg:act", act); } catch {} }, 4); }
  } catch {}
}
const nodes = (A) => { if (A._n) return A._n; const L = []; for (const R of A.w) for (const P of R) L.push({ x: A.x + P[0] + 0.5, y: A.y + P[1], z: A.z + P[2] + 0.5 }); return (A._n = L); };
const seats = (A) => (A._s ||= (A.s || []).map((q) => ({ x: A.x + q[0] + 0.5, y: A.y + q[1] + 0.5, z: A.z + q[2] + 0.5, fx: A.x + q[3] + 0.5, fz: A.z + q[4] + 0.5 })));
export const spotsOf = (A) => (A._sp ||= [...(A.p || []).filter((q) => Array.isArray(q) && q.length >= 4).map((q) => ({ k: q[0], x: A.x + q[1] + 0.5, y: A.y + q[2], z: A.z + q[3] + 0.5 })), { k: "plaza", x: A.x + 0.5, y: A.y + (A.id.startsWith("c") ? 5 : 0), z: A.z + 3.5 }]);
function schedPick(A) {
  if (rainNow()) return Math.random() < 0.75 ? pick(["inn", "cafe", "diner"]) : null;
  if (festNow(A) && Math.random() < 0.5) return "plaza";
  let r = Math.random(); for (const [k, w] of SCHED[slotNow()] || []) { if (r < w) return k; r -= w; }
  return null;
}
const busySeat = (q) => [...W.values()].some((s) => s.tg && s.tg.seat === q);
function newTarget(s, A) {
  const N = nodes(A); if (!N.length) return;
  if (!s.lead) { const k = s.home ? "inn" : schedPick(A), L = k ? spotsOf(A).filter((q) => q.k === k) : []; if (L.length) { const q = pick(L); s.tg = { x: q.x + Math.random() * 3 - 1.5, y: q.y, z: q.z + Math.random() * 3 - 1.5, k }; s.lane = 0; return; } }
  const S = seats(A).filter((q) => !busySeat(q) && Math.hypot(q.x - s.x, q.z - s.z) < 26);
  if (S.length && Math.random() < 0.25 && !s.lead) { const q = pick(S); s.tg = { x: q.x, y: q.y, z: q.z, seat: q }; return; }
  const near = N.filter((q) => { const d = Math.hypot(q.x - s.x, q.z - s.z); return d > 4 && d < 22; });
  const q = pick(near.length ? near : N); s.tg = { x: q.x, y: q.y, z: q.z };
  s.lane = (Math.random() * 2 - 1) * 1.4;
}
/* 第123版: 物語の 舞台（場面の あいだ 町の 人を かくす 円）*/
const HIDN = (globalThis.__mqHid = globalThis.__mqHid || new Set()), FRZN = (globalThis.__mqFrz = globalThis.__mqFrz || new Set()), ZONES = (globalThis.__mqStageZ = globalThis.__mqStageZ || new Map());
const inZone = (x, z) => { for (const q of ZONES.values()) if (Math.hypot(q.x - x, q.z - z) < q.r) return true; return false; };
function spawnOne(A) {
  const N = nodes(A).filter((q) => !ZONES.size || !inZone(q.x, q.z)); if (!N.length) return;
  const P = pick(N), grp = Math.random() < 0.3 ? 2 : 1;
  let lead = null;
  for (let g = 0; g < grp; g++) {
    const pos = { x: P.x + g * 0.9, y: P.y, z: P.z + g * 0.4 };
    let e; try { e = OW().spawnEntity("mrpg:npc", pos); } catch { return; }
    dressCitizen(e); try { e.addTag("mrpg_walker"); e.addTag(tagOf(A.id)); } catch {}
    const s = { e, a: A.id, lane: (Math.random() * 2 - 1) * 1.4, sp: 0.2 + Math.random() * 0.12, wait: 0, mode: "walk", blk: 0, ...pos };
    if (lead) { s.lead = lead.e.id; s.side = g; } else lead = s;
    W.set(e.id, s); if (!s.lead) newTarget(s, A);
  }
}
function adopt(e, A) {
  const L = e.location; if (!nodes(A).some((q) => Math.hypot(q.x - L.x, q.z - L.z) < 16)) { try { e.remove(); } catch {} return; }
  const s = { e, a: A.id, lane: (Math.random() * 2 - 1) * 1.4, sp: 0.2 + Math.random() * 0.12, wait: 0, mode: "walk", blk: 0, x: L.x, y: L.y, z: L.z };
  try { e.setProperty("mrpg:act", 0); } catch {}
  W.set(e.id, s); newTarget(s, A);
}
const nightNow = () => { try { const t = world.getTimeOfDay(); return t > 13500 && t < 22500; } catch { return false; } };
const WANT0 = (A) => (isLite() ? (A.id.startsWith("c") ? 4 : 3) : (A.id.startsWith("c") ? 10 : 6));
const WANT = (A) => (nightNow() ? Math.max(1, Math.floor(WANT0(A) / 3)) : WANT0(A));   /* 第111版: 夜は 家に 帰って 人が へる（酒場は にぎやか）*/
let LASTRAIN = false;
/* 1秒ごと: 人が 近い 町に 人を ふやす・遠い 町の 人を 消す */
system.runInterval(() => {
  const A0 = areas(); if (!A0.length) return;
  const ps = world.getAllPlayers().filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
  for (const A of A0) {
    const near = ps.some((p) => Math.hypot(p.location.x - A.x, p.location.z - A.z) < A.r + 24);
    let L = []; try { L = OW().getEntities({ type: "mrpg:npc", tags: [tagOf(A.id)], location: { x: A.x, y: A.y, z: A.z }, maxDistance: A.r + 30 }); } catch {}
    if (!near) { for (const e of L) { W.delete(e.id); try { e.remove(); } catch {} } continue; }
    for (const e of L) { let bz = false; try { bz = e.hasTag("mrpg_busyw"); if (bz && !BUSYW.has(e.id)) { e.removeTag("mrpg_busyw"); bz = false; } } catch {} if (!W.has(e.id) && !bz) adopt(e, A); }   /* 遊びの 記録が ない（抜けた・読みこみ直した）人は 町歩きに もどす */
    const mine = L.filter((e) => W.has(e.id));
    if (mine.length > WANT(A) + 1) for (const e of mine.slice(WANT(A))) { const s = W.get(e.id); if (nightNow() && s && !s.home) { s.home = Date.now(); s.mode = "walk"; s.wait = 0; s.cyc = null; s.orb = null; s.sp = 0.34; newTarget(s, A); } else if (!s || !s.home || Date.now() - s.home > 30000) { W.delete(e.id); try { e.remove(); } catch {} } }   /* 第113版: 夜は 家へ 帰って いく */
    else if (mine.length < WANT(A) && (!nightNow() || Math.random() < 0.15)) spawnOne(A);
  }
  for (const [id, s] of W) if (!ok(s.e)) W.delete(id);
  { const r = rainNow(); if (r !== LASTRAIN) { LASTRAIN = r; const AM = new Map(A0.map((A) => [A.id, A])); for (const s of W.values()) { if (s.mode === "sit" || s.lead) continue; const A = AM.get(s.a); if (!A) continue; if (r) { s.mode = "walk"; s.wait = 0; s.cyc = null; s.orb = null; stopAct(s); newTarget(s, A); } } } }   /* 第113版: 雨が 降りだすと 屋根の 下へ 急ぐ */
  /* 立ち話: 歩いて いる 2人が 近ければ ときどき 足を 止めて 向きあう */
  const L = [...W.values()].filter((s) => s.mode === "walk" && !s.lead && s.wait <= 0);
  for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) {
    const a = L[i], b = L[j]; if (Math.hypot(a.x - b.x, a.z - b.z) > 3 || Math.random() > 0.12) continue;
    const t = 25 + Math.floor(Math.random() * 30); try { LIFE.pair && LIFE.pair(a, b); } catch {}
    for (const [u, v, act] of [[a, b, 4], [b, a, pick([4, 9, 6, 0])]]) { u.mode = "talk"; u.wait = t; u.cyc = act === 4 ? [4, 6, 4, 5] : [9, 4, 6, 4]; try { u.e.setProperty("mrpg:mv", false); u.e.setProperty("mrpg:act", act); u.e.teleport({ x: u.x, y: u.y, z: u.z }, { facingLocation: { x: v.x, y: v.y + 1.5, z: v.z } }); } catch {} }
  }
}, 20);
/* 第113版: 場所に 着いた とき（朝市・昼ごはん・夕方の 宿・港で 釣り・お祭りで 踊る・雨宿り）*/
function arriveSpot(s, A, k) {
  const sl = slotNow(), rain = rainNow();
  let L = STAY[k] || [14];
  if (rain && k !== "harbor") L = [14, 3, 4]; else if (k === "plaza" && festNow(A)) L = STAY.plaza.fest; else if (!Array.isArray(L)) L = L[sl] || [14];
  s.mode = k === "harbor" ? "fish" : "stay"; s.wait = (k === "harbor" ? 150 : rain ? 120 : 50) + Math.floor(Math.random() * 60); s.cyc = L.length > 1 ? L : null; s.tg = null;
  try { s.e.setProperty("mrpg:mv", false); s.e.setProperty("mrpg:act", k === "harbor" ? 1 : pick(L)); } catch {}
}
/* 円を えがいて 走る（広場の 追いかけっこ・お祭りの 輪）*/
function orbit(s) {
  const o = s.orb; o.a += o.v;
  const nx = o.x + Math.cos(o.a) * o.r, nz = o.z + Math.sin(o.a) * o.r, ny = standY(nx, nz, s.y);
  if (ny === null || (ZONES.size && inZone(nx, nz))) { o.v = -o.v; return; }
  s.x = nx; s.z = nz; if (ny !== undefined) s.y = ny;
  try { s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: o.x + Math.cos(o.a + o.v * 3) * o.r, y: s.y + 1.5, z: o.z + Math.sin(o.a + o.v * 3) * o.r } }); } catch {}
}
/* 4tick ごと: すこしずつ 前へ */
function stopAct(s) { try { s.e.setProperty("mrpg:act", 0); } catch {} }
/* 第110版: 席から 立つ ときは となりの 立てる マスへ（板の 上に 残って 動けなく なって いた）*/
function standOff(s) {
  const q = s.tg && s.tg.seat; const y0 = Math.floor(q ? q.y : s.y);
  for (const [dx, dz] of [[0, 1], [1, 0], [0, -1], [-1, 0], [1, 1], [-1, -1], [1, -1], [-1, 1]]) { const nx = Math.floor(s.x) + dx + 0.5, nz = Math.floor(s.z) + dz + 0.5, ny = standY(nx, nz, y0); if (ny === null) continue; s.x = nx; s.z = nz; s.y = ny === undefined ? y0 : ny; break; }
  s.tg = null;
}
const STAT = { L: [], t: 0 };
system.runInterval(() => {
  if (!W.size) return;
  const AM = new Map(areas().map((A) => [A.id, A]));
  /* 第117版: 人どうしが 重ならない（歩く 人・店の 人・物語の 人物）。物語の 場面の そばでは 立ち止まる */
  const occ = []; for (const [, o] of W) occ.push(o);
  if (system.currentTick % 40 === 0 || !STAT.t) { STAT.L = []; STAT.t = 1; try { for (const pl of world.getAllPlayers()) for (const e of pl.dimension.getEntities({ type: "mrpg:npc", location: pl.location, maxDistance: 48 })) if (!W.has(e.id)) STAT.L.push({ x: e.location.x, z: e.location.z, sg: e.hasTag("mrpg_saga") }); } catch {} }
  const scene = []; try { for (const pl of world.getAllPlayers()) if (busy.has(pl.id)) scene.push(pl.location); } catch {}
  for (const [id, s] of W) {
    const A = AM.get(s.a); if (!A || !ok(s.e)) { W.delete(id); continue; }
    if (HIDN.has(id) || FRZN.has(id)) continue;   /* 第124版: ムービーの あいだ 止まる */   /* 第123版: 場面の あいだ かくれて いる 人は 動かない */
    if (s.wait > 0) { s.wait--;
      if (s.cyc && s.wait % 12 === 0) try { s.e.setProperty("mrpg:act", s.cyc[Math.floor(s.wait / 12) % s.cyc.length]); } catch {}
      if (s.orb) orbit(s);
      if (s.mode === "fish" && s.wait % 30 === 0) try { s.e.dimension.spawnParticle("minecraft:water_splash_particle", { x: s.x + Math.random() * 2 - 1, y: s.y + 0.2, z: s.z + Math.random() * 2 - 1 }); } catch {}
      if (s.mode === "sit") { try { s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: s.tg.seat.fx, y: s.y + 1, z: s.tg.seat.fz } }); } catch {} }
      if (s.wait === 0) { s.cyc = null; s.orb = null; if (s.mode !== "walk") { stopAct(s); if (s.mode === "sit") standOff(s); s.mode = "walk"; newTarget(s, A); } try { s.e.setProperty("mrpg:mv", true); } catch {} } continue; }
    let tg = s.tg;
    if (s.lead) {   /* 組の 人: 先頭の となりを 歩く */
      const L = W.get(s.lead); if (!L) { s.lead = null; newTarget(s, A); continue; }
      if (L.mode !== "walk") { if (s.mode === "walk") { try { s.e.setProperty("mrpg:mv", false); s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: L.x, y: L.y + 1.5, z: L.z } }); } catch {} } continue; }
      const dx = L.tg ? L.tg.x - L.x : 1, dz = L.tg ? L.tg.z - L.z : 0, d = Math.hypot(dx, dz) || 1;
      tg = { x: L.x - dz / d * 1.1 * s.side, y: L.y, z: L.z + dx / d * 1.1 * s.side };
      if (Math.hypot(tg.x - s.x, tg.z - s.z) < 0.25) { try { s.e.setProperty("mrpg:mv", false); } catch {} continue; }
    }
    if (!tg) { newTarget(s, A); continue; }
    const dx = tg.x - s.x, dz = tg.z - s.z, d = Math.hypot(dx, dz);
    if ((d < 0.6 || (tg.seat && d < 1.7)) && !s.lead) {
      if (s.home) { W.delete(id); try { s.e.remove(); } catch {} continue; }   /* 家に 着いた */
      if (tg.k) { arriveSpot(s, A, tg.k); continue; }
      if (tg.seat) { s.mode = "sit"; s.x = tg.seat.x; s.y = tg.seat.y; s.z = tg.seat.z; s.wait = 60 + Math.floor(Math.random() * 120); try { s.e.setProperty("mrpg:mv", false); s.e.setProperty("mrpg:act", pick([1, 1, 11, 3])); } catch {} continue; }
      if (Math.random() < 0.35) { s.wait = 8 + Math.floor(Math.random() * 20); try { s.e.setProperty("mrpg:mv", false); } catch {} }
      newTarget(s, A); continue;
    }
    /* 自分の 線（道の 左右に ずれる）に 寄りながら 進む。最後の 2マスは まっすぐ */
    const sp0 = rainNow() && !s.lead ? s.sp * 1.8 : s.sp, k = Math.min(1, (s.lead ? Math.max(sp0, d * 0.5) : sp0) / d), lane = d > 2.5 ? s.lane || 0 : 0;
    let nx = s.x + dx * k - dz / d * lane * 0.08, nz = s.z + dz * k + dx / d * lane * 0.08;
    if (scene.some((q) => Math.hypot(q.x - nx, q.z - nz) < 9) || (ZONES.size && inZone(nx, nz))) { try { s.e.setProperty("mrpg:mv", false); } catch {} continue; }
    { const hit = (x, z) => occ.some((o) => o !== s && o.lead !== id && s.lead !== (o.e && o.e.id) && Math.hypot(o.x - x, o.z - z) < 0.8) || STAT.L.some((o) => Math.hypot(o.x - x, o.z - z) < (o.sg ? 1.6 : 0.9));
      if (hit(nx, nz)) { const sx = -dz / d * 0.55, sz = dx / d * 0.55; if (!hit(nx + sx, nz + sz)) { nx += sx; nz += sz; } else if (!hit(nx - sx, nz - sz)) { nx -= sx; nz -= sz; } else { s.wait = 6 + Math.floor(Math.random() * 10); try { s.e.setProperty("mrpg:mv", false); } catch {} continue; } } }
    let ny = standY(nx, nz, s.y);
    if (ny === null) { nx = s.x + dx * k; nz = s.z + dz * k; ny = standY(nx, nz, s.y); }
    if (ny === null) { if (++s.blk > 3) { s.blk = 0; if (s.lead) { s.lead = null; } newTarget(s, A); } continue; }
    s.blk = 0; s.x = nx; s.z = nz; s.y = ny === undefined ? s.y + ((tg.y ?? s.y) - s.y) * Math.min(1, k) : ny;
    try { s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: tg.x, y: s.y + 1.5, z: tg.z } }); if (s.e.getProperty("mrpg:mv") !== true) s.e.setProperty("mrpg:mv", true); } catch {}
  }
}, 4);
/* 話しかけ: 立ちどまって ひとこと（画面は 出さない） */
NPC_HOOKS.push((p, e) => {
  if (!e.hasTag("mrpg_walker") && !e.hasTag("mrpg_patron")) return false;
  if (e.hasTag("mrpg_beach") || e.hasTag("mrpg_trouble")) return false;
  if (busy.has(p.id)) return true;
  const s = W.get(e.id); if (s && s.mode !== "sit") { s.wait = 40; s.mode = "talk"; try { e.setProperty("mrpg:mv", false); e.setProperty("mrpg:act", 4); e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
  let j = 23; try { j = e.getProperty("mrpg:job"); const wr = e.getDynamicProperty("mrpg:wr"); if (typeof wr === "number") j = wr; } catch {}
  const nm = String(e.nameTag || "").replace(/§./g, "");
  sound(p, "random.pop", 0.6);
  chatWith(p, e, nm, ROLE[j] || "町の人", Math.random() < 0.5 ? greetLine(p, nm) : pick(LINES[j] || LINES[23]));   /* 第106版: 自由に 話せる */
  return true;
});
/* 第110版: 交流（デート・鬼ごっこ）の あいだ 町歩きから はずす。終われば 次の 見まわりで もどる */
export const BUSYW = new Set();   /* 第110版: 遊び（デート・鬼ごっこ）中の 人の id */
export function claimWalker(id) { const s = W.get(id); W.delete(id); return s || null; }
export { standY };
export const __walk = { W, areas, spawnOne, adopt, tagOf, WANT, spotsOf, newTarget, arriveSpot };
