// 第106版: 町・城下町を 歩く 人たち（近くに プレイヤーが いる ときだけ 出る・軽い 動き）
// 道すじは 町を 作った ときに world の mrpg:walk:<町の id> に 保存してある（中心からの 相対座標）
import { world, system } from "@minecraft/server";
import { personName, nearNpcs } from "./names.js";   /* 第106版: 同じ 見た目でも 名前は ちがう */
import { ok, isLite, sound, setJob, busy } from "./ui.js";
import { NPC_HOOKS } from "./npchook.js";
import { chatWith } from "./chat.js";
import { PSKIN } from "./skinjobs.js";
/* 第106版: 町を 歩く 人にも 顔（スキン）を。キー → 役割（話す 内容） */
const TOWNS_SK = { rosa: 24, shiori: 24, tetsu: 23, toma: 23, milk: 24, hanna: 24, kanon: 26, mimi: 24, taro: 23, baba: 23, allen: 25, milfy: 25, leaf: 25, gantz: 25, sera: 25, ed: 23, emma: 24, nico: 26, zenia: 26, jack: 26, wolf: 25, otto: 23, hans: 23, noel: 24, shiori2: 24, mimosa: 24, kaede: 25, luna2: 25, moka: 24, aoi: 25, sakuya: 24, lily: 26, maria2: 24, rosa2: 24, kaori: 24, hanna2: 24, clarice: 24, erika: 25, viola: 26, ayame: 24, beatrice: 24, milka: 24, gracia: 25, jasmine: 26, sayo: 24, tsubaki: 24, yuki: 24, fio: 26, tia: 24, guy: 25, don: 24, crow: 26, leon: 25, zaza: 26, miko: 24 };   /* 第106版: 美少女・お姉さん 30人（水着の 人は 海辺） */

const OW = () => world.getDimension("overworld");
const WJOBS = [23, 24, 25, 26];
const NAMES = ["ミーナ", "トマス", "リオ", "エマ", "グスタフ", "ノエル", "ハンナ", "ペトロ", "サラ", "ユリウス", "アンナ", "カイ", "ロッテ", "マルコ", "ニナ", "オスカー", "ララ", "ベン", "ソフィ", "ヨハン"];
const ROLE = { 23: "町の人", 24: "町の人", 25: "冒険者", 26: "行商人" };
const LINES = {
  23: ["今日も いい 天気だな", "広場の 噴水は 町の 自慢なんだ", "城の 坂を 上ると 町が 一望できるよ", "夜は 酒場が にぎやかでね", "最近 畑を 荒らす モンスターが 出て 困ってるんだ"],
  24: ["市場の 野菜は 朝が いちばん 新鮮よ", "レストランの ケーキ、食べた？", "子どもたちが 遊び場の 話ばかり するの", "教会の 鐘が 鳴ると お昼なの", "モンスターと 暮らすって すてきね"],
  25: ["協会の 掲示板、今日は いい 依頼が あるかな", "C級に 上がるまで 3年 かかったよ……", "手配モンスターは 手ごわいぜ。回復は 多めにな", "遠くの 調査依頼は 座標を 見ると いい", "X級の 冒険者なんて 伝説の 中の 話さ"],
  26: ["遠い 町から 来たんだ。港町の 魚は 絶品だぞ", "砂漠の 町では 水が 金より 高い", "雪の 町の 薬草茶は 体が あたたまる", "商売の コツ？ 笑顔と 足の 速ささ", "ノクス団の せいで 街道が 物騒でね"],
};
const pick = (L) => L[Math.floor(Math.random() * L.length)];

// ---------- 道すじの 記録 ----------
let AREAS = [], AREA_T = 0;
function areas() {
  if (Date.now() - AREA_T < 30000) return AREAS;
  AREA_T = Date.now(); const out = [];
  try {
    for (const id of JSON.parse(world.getDynamicProperty("mrpg:walkids") || "[]")) {
      if (typeof id !== "string") continue;
      try { const v = JSON.parse(world.getDynamicProperty(`mrpg:walk:${id}`) || "null"); if (v && Array.isArray(v.w) && v.w.length) { out.push({ id, x: v.x, y: v.y, z: v.z, w: v.w.filter((r) => Array.isArray(r) && r.length >= 2), s: Array.isArray(v.s) ? v.s : [], p: Array.isArray(v.p) ? v.p : [], r: id.startsWith("c") ? 76 : 48 }); } } catch {}
    }
  } catch {}
  return (AREAS = out);
}
export const resetWalkCache = () => { AREA_T = 0; };

// ---------- 歩く 人（第109版: 作りなおし）----------
// ・壁や 家を 通りぬけない: 1歩 ごとに 足もとと 頭の ブロックを 見て、ふさがって いれば 別の 道へ
// ・一列に ならばない: 1人 1人 道の 左右に ずれた「自分の 歩く 線」と 速さを もつ。2〜3人で ならんで 歩く 組も いる
// ・ベンチや テラスに 座る・すれちがった 人と 立ち話を する（しぐさ mrpg:act）
const W = new Map();   // id → { e, a, tg:{x,y,z,seat?}, lane, sp, wait, x, y, z, mode, lead, blk, talk }
const tagOf = (id) => `mrpg_wk_${id}`.replace(/[^A-Za-z0-9_]/g, "_");
const PASS_RE = /^minecraft:(air|short_grass|tall_grass|grass|fern|large_fern|deadbush|snow_layer|torch|soul_torch|vine|glow_lichen|red_flower|yellow_flower|poppy|dandelion|cornflower|oxeye_daisy|azure_bluet|allium|blue_orchid|lily_of_the_valley|pink_petals|wildflowers|rail|redstone_wire|light_block)$|_carpet$|_tulip$|_sapling$|_button$|_pressure_plate$|_sign$|_banner$/;
const NOSTAND = /fence|wall|pane|bars|leaves|cactus|campfire|water|lava|_slab$|stairs/;
function blockAt(x, y, z) { try { return OW().getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }); } catch { return undefined; } }
const pass = (b) => !b || b.isAir || PASS_RE.test(b.typeId);
/* (x,z) で 立てる 高さ（今の 高さから +1〜-2）。読みこまれて いない 所は undefined（そのまま 進む）*/
/* 第111版: 同じ マスの 結果は 20秒 おぼえる（ブロックを 何度も 調べない・軽く）*/
const SY = new Map(); let SYT = 0;
function standY(x, z, y0) {
  const now = Date.now(); if (now - SYT > 20000) { SY.clear(); SYT = now; }
  const k = `${Math.floor(x)},${Math.floor(z)},${Math.floor(y0)}`; if (SY.has(k)) return SY.get(k);
  const r = standY0(x, z, y0); if (r !== undefined) SY.set(k, r); return r;
}
function standY0(x, z, y0) {
  let any = false;
  for (const dy of [0, 1, -1, -2]) {
    const y = Math.floor(y0) + dy, f = blockAt(x, y, z), h = blockAt(x, y + 1, z), g = blockAt(x, y - 1, z);
    if (f === undefined || g === undefined) continue; any = true;
    if (pass(f) && pass(h) && !pass(g) && !g.isLiquid && !NOSTAND.test(g.typeId)) return y;
  }
  return any ? null : undefined;
}
const DRESS = Object.keys(TOWNS_SK);
/* 第109版: 町の 人の 見た目と 名前（店の 客にも 使う）*/
export function dressCitizen(e, act = 0, place = "") {
  const keys = DRESS.filter((k) => PSKIN[k]), key = keys.length ? pick(keys) : null, j = key ? TOWNS_SK[key] : pick(WJOBS);
  try {
    if (key) { setJob(e, PSKIN[key][0]); e.setDynamicProperty("mrpg:wr", j); e.setDynamicProperty("mrpg:pk", key); e.nameTag = `§f${personName(PSKIN[key][1], PSKIN[key][2], nearNpcs(e.location))}`; }
    else { setJob(e, j); e.nameTag = `§f${ROLE[j]} ${pick(NAMES)}`; }
    e.addTag("mrpg_npc"); if (act) { e.addTag("mrpg_patron"); if (place) e.setDynamicProperty("mrpg:place", place); e.setDynamicProperty("mrpg:act0", act); system.runTimeout(() => { try { if (e.isValid()) e.setProperty("mrpg:act", act); } catch {} }, 4); }
  } catch {}
}
const nodes = (A) => { if (A._n) return A._n; const L = []; for (const R of A.w) for (const P of R) L.push({ x: A.x + P[0] + 0.5, y: A.y + P[1], z: A.z + P[2] + 0.5 }); return (A._n = L); };
const seats = (A) => (A._s ||= (A.s || []).map((q) => ({ x: A.x + q[0] + 0.5, y: A.y + q[1] + 0.5, z: A.z + q[2] + 0.5, fx: A.x + q[3] + 0.5, fz: A.z + q[4] + 0.5 })));
const busySeat = (q) => [...W.values()].some((s) => s.tg && s.tg.seat === q);
function newTarget(s, A) {
  const N = nodes(A); if (!N.length) return;
  const S = seats(A).filter((q) => !busySeat(q) && Math.hypot(q.x - s.x, q.z - s.z) < 26);
  if (S.length && Math.random() < 0.25 && !s.lead) { const q = pick(S); s.tg = { x: q.x, y: q.y, z: q.z, seat: q }; return; }
  const near = N.filter((q) => { const d = Math.hypot(q.x - s.x, q.z - s.z); return d > 4 && d < 22; });
  const q = pick(near.length ? near : N); s.tg = { x: q.x, y: q.y, z: q.z };
  s.lane = (Math.random() * 2 - 1) * 1.4;
}
function spawnOne(A) {
  const N = nodes(A); if (!N.length) return;
  const P = pick(N), grp = Math.random() < 0.3 ? 2 : 1;
  let lead = null;
  for (let g = 0; g < grp; g++) {
    const pos = { x: P.x + g * 0.9, y: P.y, z: P.z + g * 0.4 };
    let e; try { e = OW().spawnEntity("mrpg:npc", pos); } catch { return; }
    dressCitizen(e); try { e.addTag("mrpg_walker"); e.addTag(tagOf(A.id)); } catch {}
    const s = { e, a: A.id, lane: (Math.random() * 2 - 1) * 1.4, sp: 0.2 + Math.random() * 0.12, wait: 0, mode: "walk", blk: 0, ...pos };
    if (lead) { s.lead = lead.e.id; s.side = g; } else lead = s;
    W.set(e.id, s); if (!s.lead) newTarget(s, A);
  }
}
function adopt(e, A) {
  const L = e.location; if (!nodes(A).some((q) => Math.hypot(q.x - L.x, q.z - L.z) < 16)) { try { e.remove(); } catch {} return; }
  const s = { e, a: A.id, lane: (Math.random() * 2 - 1) * 1.4, sp: 0.2 + Math.random() * 0.12, wait: 0, mode: "walk", blk: 0, x: L.x, y: L.y, z: L.z };
  try { e.setProperty("mrpg:act", 0); } catch {}
  W.set(e.id, s); newTarget(s, A);
}
const nightNow = () => { try { const t = world.getTimeOfDay(); return t > 13500 && t < 22500; } catch { return false; } };
const WANT0 = (A) => (isLite() ? (A.id.startsWith("c") ? 4 : 3) : (A.id.startsWith("c") ? 10 : 6));
const WANT = (A) => (nightNow() ? Math.max(1, Math.floor(WANT0(A) / 3)) : WANT0(A));   /* 第111版: 夜は 家に 帰って 人が へる（酒場は にぎやか）*/
/* 1秒ごと: 人が 近い 町に 人を ふやす・遠い 町の 人を 消す */
system.runInterval(() => {
  const A0 = areas(); if (!A0.length) return;
  const ps = world.getAllPlayers().filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
  for (const A of A0) {
    const near = ps.some((p) => Math.hypot(p.location.x - A.x, p.location.z - A.z) < A.r + 24);
    let L = []; try { L = OW().getEntities({ type: "mrpg:npc", tags: [tagOf(A.id)], location: { x: A.x, y: A.y, z: A.z }, maxDistance: A.r + 30 }); } catch {}
    if (!near) { for (const e of L) { W.delete(e.id); try { e.remove(); } catch {} } continue; }
    for (const e of L) { let bz = false; try { bz = e.hasTag("mrpg_busyw"); if (bz && !BUSYW.has(e.id)) { e.removeTag("mrpg_busyw"); bz = false; } } catch {} if (!W.has(e.id) && !bz) adopt(e, A); }   /* 遊びの 記録が ない（抜けた・読みこみ直した）人は 町歩きに もどす */
    const mine = L.filter((e) => W.has(e.id));
    if (mine.length > WANT(A) + 1) for (const e of mine.slice(WANT(A))) { W.delete(e.id); try { e.remove(); } catch {} }
    else if (mine.length < WANT(A)) spawnOne(A);
  }
  for (const [id, s] of W) if (!ok(s.e)) W.delete(id);
  /* 立ち話: 歩いて いる 2人が 近ければ ときどき 足を 止めて 向きあう */
  const L = [...W.values()].filter((s) => s.mode === "walk" && !s.lead && s.wait <= 0);
  for (let i = 0; i < L.length; i++) for (let j = i + 1; j < L.length; j++) {
    const a = L[i], b = L[j]; if (Math.hypot(a.x - b.x, a.z - b.z) > 3 || Math.random() > 0.12) continue;
    const t = 25 + Math.floor(Math.random() * 30);
    for (const [u, v, act] of [[a, b, 4], [b, a, pick([4, 9, 6, 0])]]) { u.mode = "talk"; u.wait = t; try { u.e.setProperty("mrpg:mv", false); u.e.setProperty("mrpg:act", act); u.e.teleport({ x: u.x, y: u.y, z: u.z }, { facingLocation: { x: v.x, y: v.y + 1.5, z: v.z } }); } catch {} }
  }
}, 20);
/* 4tick ごと: すこしずつ 前へ */
function stopAct(s) { try { s.e.setProperty("mrpg:act", 0); } catch {} }
/* 第110版: 席から 立つ ときは となりの 立てる マスへ（板の 上に 残って 動けなく なって いた）*/
function standOff(s) {
  const q = s.tg && s.tg.seat; const y0 = Math.floor(q ? q.y : s.y);
  for (const [dx, dz] of [[0, 1], [1, 0], [0, -1], [-1, 0], [1, 1], [-1, -1], [1, -1], [-1, 1]]) { const nx = Math.floor(s.x) + dx + 0.5, nz = Math.floor(s.z) + dz + 0.5, ny = standY(nx, nz, y0); if (ny === null) continue; s.x = nx; s.z = nz; s.y = ny === undefined ? y0 : ny; break; }
  s.tg = null;
}
system.runInterval(() => {
  if (!W.size) return;
  const AM = new Map(areas().map((A) => [A.id, A]));
  for (const [id, s] of W) {
    const A = AM.get(s.a); if (!A || !ok(s.e)) { W.delete(id); continue; }
    if (s.wait > 0) { s.wait--; if (s.mode === "sit") { try { s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: s.tg.seat.fx, y: s.y + 1, z: s.tg.seat.fz } }); } catch {} }
      if (s.wait === 0) { if (s.mode !== "walk") { stopAct(s); if (s.mode === "sit") standOff(s); s.mode = "walk"; newTarget(s, A); } try { s.e.setProperty("mrpg:mv", true); } catch {} } continue; }
    let tg = s.tg;
    if (s.lead) {   /* 組の 人: 先頭の となりを 歩く */
      const L = W.get(s.lead); if (!L) { s.lead = null; newTarget(s, A); continue; }
      if (L.mode !== "walk") { if (s.mode === "walk") { try { s.e.setProperty("mrpg:mv", false); s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: L.x, y: L.y + 1.5, z: L.z } }); } catch {} } continue; }
      const dx = L.tg ? L.tg.x - L.x : 1, dz = L.tg ? L.tg.z - L.z : 0, d = Math.hypot(dx, dz) || 1;
      tg = { x: L.x - dz / d * 1.1 * s.side, y: L.y, z: L.z + dx / d * 1.1 * s.side };
      if (Math.hypot(tg.x - s.x, tg.z - s.z) < 0.25) { try { s.e.setProperty("mrpg:mv", false); } catch {} continue; }
    }
    if (!tg) { newTarget(s, A); continue; }
    const dx = tg.x - s.x, dz = tg.z - s.z, d = Math.hypot(dx, dz);
    if ((d < 0.6 || (tg.seat && d < 1.7)) && !s.lead) {
      if (tg.seat) { s.mode = "sit"; s.x = tg.seat.x; s.y = tg.seat.y; s.z = tg.seat.z; s.wait = 60 + Math.floor(Math.random() * 120); try { s.e.setProperty("mrpg:mv", false); s.e.setProperty("mrpg:act", pick([1, 1, 11, 3])); } catch {} continue; }
      if (Math.random() < 0.35) { s.wait = 8 + Math.floor(Math.random() * 20); try { s.e.setProperty("mrpg:mv", false); } catch {} }
      newTarget(s, A); continue;
    }
    /* 自分の 線（道の 左右に ずれる）に 寄りながら 進む。最後の 2マスは まっすぐ */
    const k = Math.min(1, (s.lead ? Math.max(s.sp, d * 0.5) : s.sp) / d), lane = d > 2.5 ? s.lane || 0 : 0;
    let nx = s.x + dx * k - dz / d * lane * 0.08, nz = s.z + dz * k + dx / d * lane * 0.08;
    let ny = standY(nx, nz, s.y);
    if (ny === null) { nx = s.x + dx * k; nz = s.z + dz * k; ny = standY(nx, nz, s.y); }
    if (ny === null) { if (++s.blk > 3) { s.blk = 0; if (s.lead) { s.lead = null; } newTarget(s, A); } continue; }
    s.blk = 0; s.x = nx; s.z = nz; s.y = ny === undefined ? s.y + ((tg.y ?? s.y) - s.y) * Math.min(1, k) : ny;
    try { s.e.teleport({ x: s.x, y: s.y, z: s.z }, { facingLocation: { x: tg.x, y: s.y + 1.5, z: tg.z } }); if (s.e.getProperty("mrpg:mv") !== true) s.e.setProperty("mrpg:mv", true); } catch {}
  }
}, 4);
/* 話しかけ: 立ちどまって ひとこと（画面は 出さない） */
NPC_HOOKS.push((p, e) => {
  if (!e.hasTag("mrpg_walker") && !e.hasTag("mrpg_patron")) return false;
  if (e.hasTag("mrpg_beach") || e.hasTag("mrpg_trouble")) return false;
  if (busy.has(p.id)) return true;
  const s = W.get(e.id); if (s && s.mode !== "sit") { s.wait = 40; s.mode = "talk"; try { e.setProperty("mrpg:mv", false); e.setProperty("mrpg:act", 4); e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
  let j = 23; try { j = e.getProperty("mrpg:job"); const wr = e.getDynamicProperty("mrpg:wr"); if (typeof wr === "number") j = wr; } catch {}
  const nm = String(e.nameTag || "").replace(/§./g, "");
  sound(p, "random.pop", 0.6);
  chatWith(p, e, nm, ROLE[j] || "町の人", pick(LINES[j] || LINES[23]));   /* 第106版: 自由に 話せる */
  return true;
});
/* 第110版: 交流（デート・鬼ごっこ）の あいだ 町歩きから はずす。終われば 次の 見まわりで もどる */
export const BUSYW = new Set();   /* 第110版: 遊び（デート・鬼ごっこ）中の 人の id */
export function claimWalker(id) { const s = W.get(id); W.delete(id); return s || null; }
export { standY };
export const __walk = { W, areas, spawnOne, adopt, tagOf, WANT };
