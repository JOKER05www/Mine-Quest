// 第126版: 六影と 邪闘十魔将の 登場の 演出（はじめて 戦う 時だけ・3〜5秒・BGM なし・黒帯/集中線 なし）。設計は /tmp/zf/forms126.md §3
// 六影: saga.js の sixMark が 頭の 動き（SIXMV）を ここから 呼ぶ。十魔将: bk_u08.js U.bossIn・tokoyo.js bossIn が tkIntro を 呼ぶ。
// 名札は 六影と 同じ ルビ札（MQN 名前 ／ MQY ルビ ／ MQE 異名と 座）。saga.js が IH.card・IH.off を 入れる。
import { ok, wait, sound, pillar, anim, showTitle, cmd } from "./ui.js";
import { camAt } from "./talk.js";
import { act } from "./stage2.js";
import { load, save } from "./store.js";
import { qs } from "./quest.js";
import { TK_NM, TK_CROWN, TK_PT } from "./tkgimmick.js";

export const IH = { card: null, off: null };
const pt = (p, id, q) => { try { p.dimension.spawnParticle(id, q); } catch {} };
const ring = (p, id, l, r, y, n = 10, ph = 0) => { for (let j = 0; j < n; j++) { const a = ph + (j * 2 * Math.PI) / n; pt(p, id, { x: l.x + Math.cos(a) * r, y: l.y + y, z: l.z + Math.sin(a) * r }); } };
const near = (p, e, nm, r = 9) => { try { const l = e.location; return p.dimension.getEntities({ location: l, maxDistance: r }).find((x) => x !== e && (String(x.nameTag || "").replace(/§./g, "").includes(nm) || (() => { try { return x.getDynamicProperty("mrpg:spk") === nm; } catch { return false; } })())) || null; } catch { return null; } };

/* ---------- 六影: 一人ずつ ちがう 頭の 動き（約1秒。カメラ 2カット）。c = { l, R, at, X, ux, uz } ---------- */
export const SIXMV = {
  zeph: async (p, e, c) => {   /* 錠の 座で 顔を 上げる。金の 輪が 三段 昇り、鐘 */
    const { l, R, at, X } = c; act(e, "kneel"); camAt(p, R(X.arc[0], X.arc[2], 0.15), at(1.1), 0.5);
    for (let i = 0; i < 3; i++) { ring(p, "minecraft:totem_particle", l, 1.8 - i * 0.4, 0.1 + i * 0.7, 12, i * 0.3); if (i === 1) { act(e, "up"); camAt(p, R(X.arc[1], X.arc[3], X.arc[5]), at(1.5), 0.7); sound(p, "block.bell.hit", 0.6, 0.8); } await wait(6); }
  },
  theo: async (p, e, c) => {   /* 手帳を ひらく。紫の 字が らせんに 昇る。頁の 音 三つ */
    const { l, R, at, X } = c; act(e, "show"); camAt(p, R(X.arc[0], X.arc[2], 1.2), at(1.4), 0.5);
    for (let i = 0; i < 4; i++) { for (let j = 0; j < 6; j++) { const a = i * 1.2 + j * 0.5; pt(p, "minecraft:enchanting_table_particle", { x: l.x + Math.cos(a) * 1.1, y: l.y + 0.3 + i * 0.45 + j * 0.06, z: l.z + Math.sin(a) * 1.1 }); }
      if (i < 3) sound(p, "item.book.page_turn", 0.8 + i * 0.15, 0.7); if (i === 2) camAt(p, R(X.arc[1], X.arc[3], 1.4), at(1.5), 0.6); await wait(5); }
  },
  valka: async (p, e, c) => {   /* 炉から 炎の 筋が 足もとへ。槌を 振り上げ、金床の 音 */
    const { l, R, at, ux, uz } = c; act(e, "hold"); camAt(p, R(25, 3.4, 0.25), at(0.9), 0.4);
    for (let i = 0; i < 5; i++) { const k = 4.5 - i; pt(p, "minecraft:basic_flame_particle", { x: l.x - ux * k, y: l.y + 0.1, z: l.z - uz * k }); pt(p, "minecraft:lava_particle", { x: l.x - ux * k, y: l.y + 0.2, z: l.z - uz * k }); await wait(3); }
    act(e, "raise"); sound(p, "random.anvil_land", 0.6, 0.9); ring(p, "minecraft:basic_flame_particle", l, 1.3, 0.15, 10); camAt(p, R(-15, 2.4, 0.6), at(1.4), 0.5); await wait(6);
  },
  twins: async (p, e, c) => {   /* 雪が 二本の 柱に なって 降る。真上から 見下ろして 寄る */
    const { l, R, at, ux, uz } = c, e2 = near(p, e, "ルウ", 6), l2 = e2 && ok(e2) ? e2.location : null;
    act(e, "hold"); if (e2) act(e2, "hold");
    camAt(p, { x: l.x + ux * 1.2, y: l.y + 6.5, z: l.z + uz * 1.2 }, at(0.4), 0.4);
    for (let i = 0; i < 4; i++) { for (const q of [l, l2]) if (q) for (let y = 4; y > 0; y -= 1.3) pt(p, "minecraft:snowflake_particle", { x: q.x, y: q.y + y - i * 0.3, z: q.z }); if (i % 2 === 0) sound(p, "random.glass", 1.8 - i * 0.4, 0.6); if (i === 2) camAt(p, R(c.X.arc[1], c.X.arc[3], 1.1), at(1.1), 0.7); await wait(5); }
  },
  argo: async (p, e, c) => {   /* 横なぐりの 吹雪。盾を 構え、仮面が 一度 光る */
    const { l, R, at, ux, uz } = c; act(e, "guard"); camAt(p, R(45, 2.8, 0.4), at(1.2), 0.4);
    for (let i = 0; i < 4; i++) { for (let k = -3; k <= 3; k += 1.5) pt(p, i % 2 ? "minecraft:soul_particle" : "minecraft:white_smoke_particle", { x: l.x - uz * (k + i) + ux * 0.6, y: l.y + 0.5 + Math.abs(k) * 0.2, z: l.z + ux * (k + i) + uz * 0.6 }); if (i === 2) { pt(p, "minecraft:endrod", at(1.75)); sound(p, "item.shield.block", 0.6, 0.8); camAt(p, R(-40, 2.6, 0.5), at(1.6), 0.8); } await wait(5); }
  },
  beryl: async (p, e, c) => {   /* 白い 煙の 幕が 上がって 左右に 割れる。真正面から 寄って 指さす */
    const { l, R, at, ux, uz } = c; camAt(p, R(0, 4, 1.3), at(1.2), 0.4);
    for (let i = 0; i < 4; i++) { const w = 0.4 + i * 0.6; for (const sd of [-1, 1]) for (let y = 0.2; y < 2.4; y += 0.55) pt(p, "minecraft:white_smoke_particle", { x: l.x + ux * 1.3 - uz * sd * w, y: l.y + y, z: l.z + uz * 1.3 + ux * sd * w }); if (i === 1) sound(p, "item.book.page_turn", 0.7, 0.8); await wait(5); }
    act(e, "point"); camAt(p, R(0, 2.2, 1.5), at(1.55), 0.6); await wait(3);
  },
};

/* ---------- 邪闘十魔将 ---------- */
export const TKR = [
  { ruby: "アフタヌーン", ep: "暮れない 午後" }, { ruby: "マリオネッタ", ep: "糸の 案内人" }, { ruby: "ミロワール", ep: "鏡の 食卓" }, { ruby: "フォルトゥナ", ep: "禍福の 馬" }, { ruby: "ジャルダン", ep: "首の 花壇" },
  { ruby: "ミッドナイト", ep: "二十三時 五十九分" }, { ruby: "トニトルス", ep: "雷鳴の 門番" }, { ruby: "シレンツィオ", ep: "静寂の 剣" }, { ruby: "ランパート", ep: "城壁の 鬼王" }, { ruby: "ヴォックス", ep: "王の 声" },
];
const hyOf = (e) => { try { const v = e.getDynamicProperty("mrpg:hy"); if (typeof v === "number") return v; } catch {} return 4; };
/* はじめて だけ（人ごと。s.six.tk0〜tk9）*/
export function tkFirst(p, i) { try { const d = load(p); if (!d) return false; const s = qs(d); s.six = s.six || {}; if (s.six[`tk${i}`]) return false; s.six[`tk${i}`] = 1; save(p, d); return true; } catch { return false; } }
/* c = { l, h, ux, uz, F(r, y, side), at(y), e2 } */
const TKMV = [
  async (p, e, c) => {   /* 十 双子: サイコロが 二人の あいだを 跳ねる */
    const a = c.l, b = c.e2 && ok(c.e2) ? c.e2.location : { x: a.x - c.uz * 4.8, y: a.y, z: a.z + c.ux * 4.8 }, m = { x: (a.x + b.x) / 2, y: a.y, z: (a.z + b.z) / 2 };
    camAt(p, { x: m.x + c.ux * 6, y: m.y + 0.6, z: m.z + c.uz * 6 }, { x: m.x, y: m.y + c.h * 0.5, z: m.z }, 0.4);
    for (let i = 0; i <= 8; i++) { const t = i / 8, fl = i % 2 ? a : b, q = { x: a.x + (b.x - a.x) * t, y: a.y + 1 + Math.abs(Math.sin(t * Math.PI * 3)) * 2, z: a.z + (b.z - a.z) * t }; pt(p, i % 2 ? "minecraft:white_smoke_particle" : "minecraft:totem_particle", q); if (i % 3 === 0) sound(p, "random.click", 1.4 - i * 0.05, 0.9); if (i === 5) camAt(p, { x: m.x + c.ux * 4, y: m.y + c.h * 0.9, z: m.z + c.uz * 4 }, { x: m.x, y: m.y + c.h * 0.8, z: m.z }, 0.6); await wait(3); void fl; }
    anim(e, "g_stomp"); if (c.e2) anim(c.e2, "g_stomp"); sound(p, "random.anvil_land", 0.3, 1.6); await wait(8);
  },
  async (p, e, c) => {   /* 九 イトマ: 光る 糸が 四本 降りる */
    camAt(p, c.F(3, 0.3, 1.2), c.at(c.h + 3), 0.4);
    for (let i = 0; i < 4; i++) { const a = i * 1.57 + 0.4; for (let y = 9; y > c.h * 0.6; y -= 1.2) pt(p, "minecraft:endrod", { x: c.l.x + Math.cos(a) * 1.1, y: c.l.y + y - i * 0.4, z: c.l.z + Math.sin(a) * 1.1 }); sound(p, "random.bow", 1.8, 0.5); if (i === 2) { anim(e, "cast"); camAt(p, c.F(c.h * 0.6 + 2.5, c.h * 0.9, -0.8), c.at(c.h * 0.9), 0.8); } await wait(7); }
    await wait(6);
  },
  async (p, e, c) => {   /* 八 テルグ: 鏡に 映る 三つの 角度 */
    const sh = [[1.0, 0.5, 2.5], [-1.0, 0.7, -2.5], [0, 0.9, 0]];
    for (let i = 0; i < 3; i++) { const [k, y, s] = sh[i]; camAt(p, c.F(c.h * 0.7 + 3, c.h * y, s * k + s), c.at(c.h * 0.8), i === 2 ? 0.6 : 0); ring(p, "minecraft:endrod", c.l, 2.2 - i * 0.4, 0.3 + i * 0.6, 12, i); sound(p, "random.glass", 1.2 + i * 0.3, 0.8); await wait(9); }
    anim(e, "g_roar"); await wait(6);
  },
  async (p, e, c) => {   /* 七 サイオウバ: ひづめ 四つ・土ぼこりの 輪・金の 粒 */
    camAt(p, c.F(c.h + 4, c.h * 0.4, 4), c.at(c.h * 0.6), 0.4);
    for (let i = 0; i < 4; i++) { ring(p, "minecraft:basic_smoke_particle", c.l, 2.5, 0.1, 6, i * 0.8); sound(p, "mob.horse.gallop", 0.8, 1); if (i === 2) camAt(p, c.F(c.h + 4, c.h * 0.5, -4), c.at(c.h * 0.7), 1.0); await wait(6); }
    anim(e, "g_charge"); ring(p, "minecraft:totem_particle", c.l, 1.4, c.h * 0.8, 14); sound(p, "random.levelup", 0.6, 0.6); await wait(8);
  },
  async (p, e, c) => {   /* 六 ハドラ: 足もとの 輪から 花の 胞子、首が 持ち上がる */
    camAt(p, c.F(c.h * 0.6 + 3, 0.2, 1), c.at(0.5), 0.4);
    for (let i = 0; i < 4; i++) { ring(p, "minecraft:spore_blossom_ambient_particle", c.l, 2.6 - i * 0.4, 0.2 + i * c.h * 0.25, 10, i); ring(p, "minecraft:crimson_spore_particle", c.l, 1.6, 0.3 + i * 0.4, 6, i * 0.5); if (i === 1) camAt(p, c.F(c.h * 0.6 + 3, 0.6, 1), c.at(c.h), 1.4); await wait(7); }
    anim(e, "g_roar"); sound(p, "mob.ravager.roar", 0.6, 0.9); await wait(6);
  },
  async (p, e, c) => {   /* 五 ザキュラス: 時計の 針（魂の 粒）と カチ・カチ・カチ・鐘 */
    for (let i = 0; i < 4; i++) { const a = -Math.PI / 2 + i * 0.5, r = c.h * 0.5 + 4; camAt(p, { x: c.l.x + Math.cos(a + Math.atan2(c.uz, c.ux)) * r, y: c.l.y + c.h * 0.6, z: c.l.z + Math.sin(a + Math.atan2(c.uz, c.ux)) * r }, c.at(c.h * 0.7), 0.25);
      for (let k = 0; k < 6; k++) pt(p, "minecraft:soul_particle", { x: c.l.x + Math.cos(i * 0.52) * k * 0.4, y: c.l.y + c.h + 0.5, z: c.l.z + Math.sin(i * 0.52) * k * 0.4 }); sound(p, i < 3 ? "random.click" : "block.bell.hit", i < 3 ? 0.6 : 0.5, 1); await wait(i < 3 ? 6 : 10); }
  },
  async (p, e, c) => {   /* 四 ガムラ: 白い 閃光・雷鳴・火花の 柱 */
    camAt(p, c.F(4.5, 0.4, -1.5), c.at(c.h * 0.8), 0.3); await wait(6);
    cmd(p, "camera @s fade time 0.05 0.1 0.3 color 255 255 220"); sound(p, "ambient.weather.thunder", 0.8, 1);
    for (let y = 0; y < c.h + 6; y += 0.7) pt(p, "minecraft:electric_spark_particle", { x: c.l.x, y: c.l.y + y, z: c.l.z });
    anim(e, "g_stomp"); cmd(p, "camerashake add @s 0.6 0.6 positional"); await wait(10);
    camAt(p, c.F(c.h * 0.5 + 2.5, c.h * 0.9, 1.2), c.at(c.h * 0.9), 0.8); pt(p, "minecraft:electric_spark_particle", c.at(c.h * 0.9)); await wait(14);
  },
  async (p, e, c) => {   /* 三 リョウマ: 音が 消える。雪だけ。遠くから 寄って、抜刀の 音 */
    cmd(p, "stopsound @s"); camAt(p, c.F(c.h + 9, c.h * 0.6, 0), c.at(c.h * 0.7), 0);
    for (let i = 0; i < 4; i++) { for (let k = 0; k < 6; k++) pt(p, "minecraft:snowflake_particle", { x: c.l.x + (k - 3) * 0.9, y: c.l.y + c.h + 1 - i * 0.6, z: c.l.z + ((k * 7) % 5 - 2) * 0.8 }); if (i === 0) camAt(p, c.F(c.h * 0.5 + 2.6, c.h * 0.85, 0.6), c.at(c.h * 0.85), 2.2); await wait(9); }
    anim(e, "atk_slash"); sound(p, "item.trident.riptide_1", 0.9, 1); pt(p, "minecraft:endrod", c.at(c.h * 0.6)); await wait(6);
  },
  async (p, e, c) => {   /* 二 ギレンドドロス: ドン・ドン・ドン（三枚の 鎧）。一打ちごとに 引く */
    for (let i = 0; i < 3; i++) { camAt(p, c.F(c.h * 0.6 + 3 + i * 2.5, 0.5 + i * c.h * 0.25, 0), c.at(c.h * (0.4 + i * 0.25)), i ? 0.35 : 0); ring(p, i === 1 ? "minecraft:endrod" : i === 2 ? "minecraft:soul_particle" : "minecraft:lava_particle", c.l, 2.2, 0.3 + i * c.h * 0.33, 12); sound(p, "random.anvil_land", 0.4 - i * 0.05, 1); cmd(p, "camerashake add @s 0.3 0.3 positional"); await wait(10); }
    anim(e, "g_roar"); await wait(4);
  },
  async (p, e, c) => {   /* 一 ベルガ: 竜の 息の 道（王の 道）。高い 所から 見下ろし → 目の 高さへ */
    camAt(p, c.F(4, c.h + 4, 2), c.at(0.3), 0.4);
    for (let i = 0; i < 6; i++) { const k = 1 + i * 1.4; pt(p, "minecraft:dragon_breath_trail", { x: c.l.x + c.ux * k, y: c.l.y + 0.15, z: c.l.z + c.uz * k }); if (i % 3 === 0) sound(p, "block.bell.hit", 0.45, 0.8); await wait(4); }
    anim(e, "g_roar"); camAt(p, c.F(c.h * 0.5 + 3, c.h * 0.8, -1), c.at(c.h * 0.85), 1.0); sound(p, "mob.wither.ambient", 0.5, 0.7); await wait(14);
  },
];
/* 十魔将の 登場（はじめて だけ）。返り値 true = 演出した（呼んだ 側は ふつうの 札を 出さない）*/
export async function tkIntro(p, e, i, e2 = null) {
  if (!ok(p) || !ok(e) || !(i >= 0 && i < 10) || !tkFirst(p, i)) return false;
  const l = e.location, h = Math.max(2, Math.min(9, hyOf(e))); let ux = 0, uz = 1; try { const P0 = p.location, dx = P0.x - l.x, dz = P0.z - l.z, n = Math.hypot(dx, dz) || 1; ux = dx / n; uz = dz / n; } catch {}
  const c = { l, h, ux, uz, e2: e2 || (i === 0 ? near(p, e, "シゴロ", 8) : null), at: (y) => ({ x: l.x, y: l.y + y, z: l.z }), F: (r, y, sd = 0) => ({ x: l.x + ux * r - uz * sd, y: l.y + y, z: l.z + uz * r + ux * sd }) };
  cmd(p, "fog @s push mrpg:shadow mq_six");
  try {
    sound(p, "mob.wither.ambient", 0.5, 0.4); try { pillar(e, [0.6, 0.05, 0.1], 2.5); } catch {} pt(p, TK_PT[i], c.at(h * 0.5));
    await TKMV[i](p, e, c);
    if (!ok(p)) return true;
    camAt(p, c.F(h * 0.45 + 2.6, h * 0.75, 1.6), { x: l.x - uz * 1.4, y: l.y + h * 0.95, z: l.z + ux * 1.4 }, 1.4);   /* 顔を 片側に ずらす（札が 顔に かからない）*/
    const X = { c: "§4", nm: TK_NM[i], ruby: TKR[i].ruby, alias: `「${TKR[i].ep}」` }, seat = `邪闘十魔将  ${TK_CROWN[i]}`;
    if (IH.card) await IH.card(p, X, seat); else showTitle(p, `§4§l${TK_NM[i]}`, { subtitle: `§7${seat}  §f${X.alias}`, fadeInDuration: 3, stayDuration: 30, fadeOutDuration: 10 });
    sound(p, "block.bell.hit", 0.5, 0.8); await wait(32);
  } finally { try { if (IH.off) IH.off(p); } catch {} cmd(p, "fog @s remove mq_six"); }
  return true;
}
