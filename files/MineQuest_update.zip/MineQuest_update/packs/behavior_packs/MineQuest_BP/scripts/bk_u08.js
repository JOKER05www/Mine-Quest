/* 第126版 裏8「渡し場」（常世の 入口／歓声の 抜け殻）— 作業 UB
   ・ここに 裏8〜15 の 共通の 部品（U）も 置く（bk_u09〜u15 が import）。文に 後の 章の 言葉を 書かない（ネタバレ点検は この ファイルを 裏8 と して 見る）
   ・裏8 の 流れ: 1話（閻魔の神殿の 石段の 下の 舟）→ 2話（常世の 渡し場。ここで ru.st 0→2）→ 3話（野営地）は RU_HOOK.enter の 中で 続けて 流す
     4〜6話（抜け殻の 闘技場）・7〜8話（野営地）は 常世の 中の 自由な 話（調査隊の キャンプの そば）
   ・区の 話は tkOver（bk_u09〜u15）。区の 戦いの 話（fight）は 区の 前で 向かい合う まで（本物の 戦いは ruins.js）。勝った あとの 一拍は 区の 後で U.win
   ・野営地の 夜・すきまの 町・塔の 下 などの 話は 区の 後から 続けて 流す（free: false で 自由な 話の 列から 外す）*/
import { world, system } from "@minecraft/server";
import { bkAdd, tkOver, K, bkHas, bkPlay, chLabel } from "./bkeng.js";
import { SGK, heroType, GOAL_HOOKS } from "./saga.js";
import { cast, act, hold, fx, fade, PJ, heroOf } from "./stage2.js";
import { stageBegin, stageEnd, stageOf } from "./stagecore.js";
import { closeWide } from "./talk.js";
import { TK_SP, TK_LOOK, TK_LOOK2, TK_NM, TK_CROWN, TK_PT, TK_LESSON } from "./tkgimmick.js";
import { setLook, lookOf } from "./field.js";
import { qs } from "./quest.js";
import { load, save } from "./store.js";
import { RU_HOOK, inRuins } from "./ruinsarea.js";
import { campInfo, ruOf } from "./ruins.js";
import { altarPos } from "./postgame.js";
import { facAdd, facMark, FAC_OPS } from "./epfac.js";
import { notice, busy } from "./ui.js";
import { canFight } from "./core.js";
import { tkIntro } from "./intro126.js";   /* 第126版: 十魔将の 登場 */
const { F, S1 } = FAC_OPS;
const ok = (e) => { try { return !!e && e.isValid(); } catch { return false; } };

/* ================= 共通の 部品 U ================= */
export const U = { ok, F, S1 };
const TT = new Map();   /* 話の id → 題（区の 中で 流す ときの 札）*/
/* 章の 登録（題を 覚える・free: false の 話は 自由な 話の 列から 外す）*/
U.reg = (ch, list) => { for (const e of list) { TT.set(e.id, e.t); if (e.free === false) e.pre = -1; } bkAdd(ch, list); };
U.hn = (p) => { const h = heroOf(p); return h ? h.name : "あの 子"; };
U.hv = (p, v) => (typeof v === "string" || Array.isArray(v) ? v : v[heroType(p)] || v.g);
U.y0 = (p) => { const S = stageOf(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
U.flag = (p, k, v = 1) => { if (K.replay(p)) return; const d = load(p); if (!d) return; qs(d)[k] = v; save(p, d); };
U.fl = (p, k) => { try { return !!qs(load(p) || {})[k]; } catch { return false; } };
U.drop = (p, k) => { if (K.replay(p)) return; const d = load(p); if (!d) return; const s = qs(d); if (Array.isArray(s.keys) && s.keys.includes(k)) { s.keys = s.keys.filter((x) => x !== k); if (!Array.isArray(s.keyGone)) s.keyGone = []; if (!s.keyGone.includes(k)) s.keyGone.push(k); save(p, d); } };   /* だいじなものを 人に 渡す（手もとから はなれる）*/
U.has = (p, k) => { try { return (qs(load(p) || {}).keys || []).includes(k); } catch { return false; } };
/* 人 */
U.mu = (C, d = 2.2, s = 1.6) => C.npc("§cムサシ", 19, d, s);
U.sail = (C, d = 4, s = -1.6) => C.npc("§5常世の 渡し守", 13, d, s);
U.M = (p, mu, L, pose, to = null) => { if (pose !== undefined && ok(mu)) act(mu, pose); if (to) U.aim(p, mu, to); return K.say(p, "ムサシ", [].concat(L)); };   /* to: 話しかける 相手（あなたなら p）*/
const EK = new Map();
U.E = async (p, mu, L) => { if (ok(mu)) { try { fx(p.dimension, "minecraft:basic_flame_particle", mu.location, 8, 0.4); } catch {} const k = (EK.get(p.id) || 0) + 1; EK.set(p.id, k); if (k % 2) SGK.camNear(p, mu, 2.4, 1.3); else await K.ots(p, mu, p, 4); } await K.say(p, "エンマ", [].concat(L), mu); };   /* 鍔の 声: 寄りの 絵を 毎回 かえる */
U.tap = async (p, mu) => { if (!ok(mu)) return; act(mu, "point"); hold(mu, "hammer"); K.sound(p, "random.anvil_land", 0.3, 1.9); await K.wait(8); hold(mu, 0); };   /* 聞き槌で「コン」と 一度 */
U.soul = (p, C, d = 3, s = -1.4, how = "smoke") => { const h = heroOf(p); if (!h) return null; const e = C.npc(`§d${h.name}の 魂`, PJ(h.key, 9), d, s, 0, how); if (ok(e)) fx(p.dimension, "minecraft:endrod", e.location, 6, 0.5); return e; };
/* 話す 人が 相手（lis）を 向く: 舞台の「前に 話した 人／相手」を 先に 決めて おく（stagecore の speakTurn が それを 向く）*/
U.aim = (p, sp, to) => { try { const S = stageOf(p); if (!S || !ok(sp) || !to) return; if (to !== p && !ok(to)) return; S.prev = sp; S.pl = to; } catch {} };
const spOf = (p, who) => { try { const S = stageOf(p); if (!S) return null; const k = String(who).replace(/§./g, ""); const L = S.ents.filter((e) => ok(e) && e.typeId === "mrpg:npc" && String(e.nameTag || "").replace(/§./g, "").includes(k)); return L.find((e) => String(e.nameTag || "").replace(/§./g, "") === k) || L[0] || null; } catch { return null; } };
U.H = (p, v, lis = null) => { const who = `${U.hn(p)}の 魂`; if (lis) U.aim(p, spOf(p, who), lis); return K.say(p, who, [].concat(U.hv(p, v)), lis); };
U.say = (p, who, L, lis = null) => { if (lis) U.aim(p, spOf(p, who), lis); return K.say(p, who, [].concat(L), lis); };
U.narr = (p, L, focus = null) => K.narr(p, [].concat(L), focus);
/* 区の 主（G サイズ。話す 人と して 見つかる）*/
U.boss = (p, C, i, dist = 10, side = 0, nm = null, black = false) => {
  const sid = TK_SP[i], e = C.mon(sid, dist, side, 0, "smoke"); if (!e) return null;
  try { setLook(e, sid, { tint: black ? TK_LOOK2 : TK_LOOK[i], sz: "G" }); e.setProperty("mrpg:size", Math.min(2500, Math.round(lookOf(sid, { sz: "G" }).size * 1.15))); } catch {}
  let h = 4; try { h = Math.max(2, Math.min(9, lookOf(sid, { sz: "G" }).mh * 1.15 * 0.85)); } catch {}
  try { e.nameTag = ""; e.addTag("mrpg_spkm"); e.setDynamicProperty("mrpg:spk", nm || TK_NM[i]); e.setDynamicProperty("mrpg:hy", h); } catch {}
  try { fx(p.dimension, TK_PT[i], e.location, 10, 2.5); } catch {}
  return e;
};
U.top = (e) => { try { const l = e.location, h = e.getDynamicProperty("mrpg:hy"); return { x: l.x, y: l.y + (typeof h === "number" ? h : 4), z: l.z }; } catch { return null; } };
/* 主の 登場: 足もとから 見上げて 名乗りの 札 */
U.bossIn = async (p, e, i) => {
  if (!ok(e)) return; if (!K.replay(p) && (await tkIntro(p, e, i))) return;   /* 第126版: はじめて だけ 一人ずつ ちがう 登場と ルビ札（intro126.js）*/
  K.sound(p, "mob.wither.ambient", 0.6); await K.low(p, e, 16);
  K.sound(p, "mob.ravager.roar", 0.7, 0.8); K.shake(p, 0.4, 0.5); await K.at(p, U.top(e), 20, 6, 0);
  SGK.big(p, `§4§l${TK_NM[i]}`, `§7${TK_CROWN[i]}`, "block.bell.hit"); await K.wait(36);
};
/* 渡し守が 歩いて 来て、区の 仕掛けを 教える（1回だけ。ru.gk）*/
U.lesson = async (p, C, i, lis = null) => {
  const d = load(p); if (!d) return; const r = ruOf(d); if (Array.isArray(r.gk) && r.gk.includes(i) && !K.replay(p)) return;
  const S = U.sail(C, 2.4, -2.6); if (ok(S)) await K.up(p, S, 10);
  const L = TK_LESSON[i] || [];
  await U.say(p, "常世の 渡し守", [`{closed}待て。${TK_NM[i]}の 戦い方を 教えて おく`]);
  for (const x of L.slice(0, 3)) { if (ok(S)) await K.up(p, S, 4); await U.say(p, "常世の 渡し守", [x], lis); }
  if (!K.replay(p)) { const d2 = load(p); if (d2) { const r2 = ruOf(d2); r2.gk = [...new Set([...(Array.isArray(r2.gk) ? r2.gk : []), i])]; save(p, d2); } }
  if (ok(S)) { act(S, "wave"); await K.wait(8); act(S, 0); await SGK.bye(p, S); }
};
/* 舞台（区の 中・入口の 石段 など、bkPlay の 外で 話を 流す ときの 舞台）*/
U.inSt = async (p, at, fn) => {
  await stageBegin(p, { lazy: true, move: false });
  await stageBegin(p, { anchor: at || { x: p.location.x, y: p.location.y, z: p.location.z }, move: true, noEst: true, R: 14 });
  try { return await fn(); } catch (x) { console.warn(`[MonsterRPG] 裏の 舞台: ${x} ${(x && x.stack) || ""}`); return false; }
  finally { try { await closeWide(p); } catch {} stageEnd(p); stageEnd(p); try { SGK.heroTmpClean(p); } catch {} }
};
/* 区の 中で 話を 順に（まだの 話だけ。題の 札を 出す）*/
U.seq = async (p, ids) => {
  for (const id of ids) {
    const d = load(p); if (!d) return false; if (bkHas(qs(d), id)) continue;
    SGK.big(p, `§6§l${chLabel(id.slice(0, 3))}`, `${+id.slice(4)}話 ${TT.get(id) || ""}`, "item.book.page_turn"); await K.wait(30);
    if (!(await K.play(p, id))) return false;
  }
  return true;
};
/* 区の 戦いの 話: 区の 中（PH）では 向かい合う まで。見のがした 頁・点検では 勝った あとの 一拍まで */
export const PH = new Set();
const WIN = {};
U.fight = (i, pre, win) => { WIN[i] = win; return async (p) => { const C = cast(p); try { await pre(p, C); if (!PH.has(p.id)) { K.card(p, "§7（戦い）", 40); await K.wait(24); await win(p, C); } await U.end(p, C, { t: 12 }); } finally { C.end(); } return ok(p); }; };
U.win = async (p, i) => { const w = WIN[i]; if (!w) return; const C = cast(p); try { await w(p, C); await SGK.bye(p, ...C.list.filter(ok)); } finally { C.end(); } };
/* 区の 前・後を 差しかえる（pre: 区の 前の 話・戦いの 話、post: 区の 後の 話）。o.ret: 前の 返り値（記録塔）・o.after: 後の 続き */
U.ward = (i, pre, post, o = {}) => tkOver(i, {
  pre: (p) => U.inSt(p, null, async () => { PH.add(p.id); try { await U.seq(p, pre); } finally { PH.delete(p.id); } return o.ret ? o.ret(p) : undefined; }),
  post: (p, d, K2, c) => U.inSt(p, null, async () => { await U.win(p, i); await U.seq(p, post); if (o.after) await o.after(p, c); }),
});
/* 野営地（いちばん 近い 調査隊の キャンプ）へ 暗転で 移る */
U.campAt = (p) => { let best = null; for (let k = 0; k < 5; k++) { let c = null; try { c = campInfo(k); } catch {} if (!c || !c.built) continue; const dd = Math.hypot(c.x - p.location.x, c.z - p.location.z); if (!best || dd < best.dd) best = { dd, q: { x: c.x + 0.5, y: c.y, z: c.z + 3.5 } }; } return best; };
U.toCamp = async (p, drop = []) => { if (K.replay(p) || !inRuins(p.location)) return; const b = U.campAt(p); if (b && b.dd > 10) await K.moveTo(p, b.q, "常世の 野営地", drop); };
/* 座の 選択（C20）: オルドが 座った 道では、裏の 各章の 終わりに 一枚の 絵 */
U.c20 = async (p) => {
  if (K.ch(p, "c20") !== "o") return;
  await K.offstage(p, async (V, C) => {   /* 第127版: そのころ（主人公の いない 場面）*/
    await K.wide(p, 14);
    await U.narr(p, ["§7ゼファードが 一人、沈んだ 神殿の 前に 座って いる。"], C.eZ);
    K.hold(C.eZ, "rope"); await K.up(p, C.eZ, 10);
    await U.narr(p, ["§8水の 底の 石の 女に、今日の ことを 小さな 声で 話して いるらしかった。"], C.eZ);
  }, { set: "fb_sunken", card: "§7― そのころ、沈んだ 神殿の 前 ―", cast: (V) => { const e = V.actor("§6ゼファード", K.PJ("zephard", 8), [3, 0], V.at(9, 0)); K.act(e, "kneel"); return { eZ: e }; } });
};
U.inR = (p) => { try { return !K.replay(p) && inRuins(p.location); } catch { return false; } };
U.nm = (p) => { try { return p.name; } catch { return ""; } };
U.C = (p) => cast(p);
/* 終わり: 引きの 絵 → 残った 人は 暗転の 中で 下げる */
U.end = (p, C, o = {}) => K.end(p, { ...o, bye: [...(o.bye || []), ...C.list.filter((e) => ok(e) && !(o.leave || []).includes(e))] });
/* 区の 入口の 石の 人が 抱く 本（区ごとに 1回。ru.rec）*/
U.rec = async (p, C, i, L, skin = "stoneknight", pose = "hold") => {
  const st = C.npc("", PJ(skin, 8), 3.2, -2, 0, "smoke"); act(st, pose); if (ok(st)) { try { fx(p.dimension, "minecraft:basic_smoke_particle", st.location, 4, 0.6); } catch {} await K.push(p, st, 18, 4, 1.8, 1.1); }
  await K.narr(p, ["§7石に なった 人が、一冊の 本を 抱いて いた。"], st);
  const LL = [].concat(L); for (let k = 0; k < LL.length; k++) { if (k % 2 === 0) { if (ok(st)) SGK.camNear(p, st, k ? 2.2 : 3.4, k ? 0.9 : 1.4); await K.wait(6); } await SGK.narr(p, "", [LL[k]]); }
  if (!K.replay(p)) { const d = load(p); if (d) { const r = ruOf(d); r.rec = [...new Set([...(Array.isArray(r.rec) ? r.rec : []), i])]; save(p, d); } }
  return st;
};
/* 相棒（演出だけ）*/
U.pal = (p, C, d = 4, s = 1.6) => { try { const dd = load(p); const m = dd && [...(dd.party || []), ...(dd.bench || []), ...(dd.box || [])].find((x) => x && (x.id === dd.partnerId || x.partner || x.look)); if (!m) return null; const e = C.mon(m.sp, d, s, 0, "smoke"); if (ok(e)) try { e.addTag("mrpg_spkm"); e.setDynamicProperty("mrpg:spk", `${m.nm || "相棒"}（相棒）`); } catch {} return { e, nm: m.nm || "相棒", sp: m.sp }; } catch { return null; } };

/* ================= 場所の 形（400 ブロック まで）================= */
facAdd("u08pier", { D: [10, 12, 14], box: [-1, -3, 2, 3], H: 3, look: [0, 0, 1], marks: { boat: [0.5, 0, 0], post: [-1, -3, 1] },
  build: () => [F(0, -3, -1, 1, 3, -1, "water"), F(-1, -3, 0, -1, 3, 0, "dark_oak_slab"), S1(-1, -3, 0, "dark_oak_fence"), S1(-1, -3, 1, "soul_lantern"), S1(-1, 3, 0, "dark_oak_fence"), S1(-1, 3, 1, "soul_lantern"), F(2, -3, 0, 2, 3, 0, "deepslate_bricks"), ["e", 0, 0, 0, "boat"]] });
facAdd("u08wall", { D: [9, 11, 13], box: [0, -3, 0, 3], H: 4, look: [0, 0, 1.5], small: true, near: 4, marks: { wall: [-0.6, 0, 1] },
  build: () => [F(0, -3, 0, 0, 3, 3, "white_concrete"), F(0, -2, 1, 0, 2, 2, "glass"), S1(0, 0, 3, "sea_lantern")] });
facAdd("u08seat", { D: [11, 13, 15], box: [-1, -6, 8, 6], H: 8, look: [3, 0, 1.5], marks: { sign: [0, -4, 1.5], wheel: [8, 0, 4], seats: [5, 0, 1.5], floor: [2, 0, 0] },
  build: () => [F(4, -6, 0, 4, 6, 0, "stone_bricks"), F(5, -6, 0, 5, 6, 1, "stone_bricks"), F(6, -6, 0, 6, 6, 2, "stone_bricks"),
    F(0, -4, 0, 0, -4, 3, "chiseled_stone_bricks"), F(0, 4, 0, 0, 4, 3, "chiseled_stone_bricks"),
    F(8, -2, 1, 8, 2, 1, "iron_bars"), F(8, -2, 7, 8, 2, 7, "iron_bars"), F(8, -3, 2, 8, -3, 6, "iron_bars"), F(8, 3, 2, 8, 3, 6, "iron_bars"), F(8, 0, 2, 8, 0, 6, "chain"), F(8, -2, 4, 8, -1, 4, "iron_bars"), F(8, 1, 4, 8, 2, 4, "iron_bars"), S1(8, 0, 4, "iron_block"), S1(8, 0, 0, "stone_bricks"), S1(8, -3, 1, "barrel"), S1(8, 3, 1, "barrel")] });

/* ================= 裏8 ================= */
const CAMP0 = () => { try { const c = campInfo(0); return c ? { x: c.x + 0.5, y: c.y, z: c.z + 3.5 } : null; } catch { return null; } };
const HULL = () => { const c = CAMP0(); return c ? { x: c.x + 30, y: c.y, z: c.z, nm: "常世の 抜け殻の 闘技場", r: 5 } : null; };
const TEMPLE = () => { try { const a = altarPos(); return a ? { x: a.x + 0.5, y: typeof a.y === "number" ? a.y : undefined, z: a.z + 6.5 } : null; } catch { return null; } };
const FOG = (p, q, n = 8) => { if (!q) return; for (let k = 0; k < n; k++) try { p.dimension.spawnParticle("minecraft:white_smoke_particle", { x: q.x + Math.cos(k) * 3, y: q.y + 0.6 + (k % 3) * 0.4, z: q.z + Math.sin(k) * 3 }); } catch {} };

U.reg("u08", [
  { id: "u08e1", t: "渡し守の 舟", free: false, hint: "§f閻魔の神殿の 奥、§e黒い 石段§f を 下りよう §7（神殿の 前で ガイドブック）",
    syn: "神殿の 奥の 黒い 石段を 下りると、霧の 川に 止まった 舟が あった。ムサシが 舟べりを 叩くと、千年ぶりの 音が した。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "閻魔の神殿の 奥 ― 黒い 石段の 下", "night");
        const pier = K.fac(p, "u08pier", "u08pier", 99, U.y0(p)), boat = facMark("u08pier", "boat", p.location) || pier;
        FOG(p, boat, 10); if (pier) await K.at(p, boat, 18, 6, 1);
        const mu = U.mu(C), S = U.sail(C, 4.5, -2);
        await U.narr(p, ["§7石段の 下は、霧の 川だった。§f止まった 舟が 一そう、岸に つないで ある。"], boat);
        if (ok(S)) { act(S, "bow"); await K.up(p, S, 10); }
        await U.say(p, "常世の 渡し守", ["{closed}……乗りなされ。帳の 王の 鍔を 持つ 者を 乗せるのは、千年ぶりじゃ"], mu);
        await U.M(p, mu, ["{?}……千年、ここで 待ってたのか。じいさん"], "hold");
        await U.say(p, "常世の 渡し守", ["{sad}舟は 止まって いた。わしも、止まって いた。……止まった 者に、千年は 長くない"]);
        await U.M(p, mu, ["{closed}……一つ、二つ、三つ。", "{sweat}……霧が 濃いと、数えたく なる。"], "hold");
        await U.say(p, "常世の 渡し守", ["{smile,…}数えて おれ。数は、霧の 中でも 迷わん"], mu);
        if (ok(mu) && boat) await K.walkCam(p, mu, boat, 18);
        await U.tap(p, mu); await K.at(p, boat, 12, 2.5, 0.6);
        await U.narr(p, ["§fムサシが 腰の 聞き槌で、舟べりを 一度 叩いた。§7……乾いた 音が、霧の 中へ のびて いった。"]);
        await U.M(p, mu, ["{shock,…,up}……千年ぶりに 叩かれた 音だ。木が 起きた。", "{closed}……寝起きの 音って やつは、だいたい 正直だ。"], "up");
        await U.E(p, mu, ["……この 舟は、われの 民を 運んで いた。帳に 名を 書く 前の 魂をな"]);
        await U.M(p, mu, ["{closed}じゃあ 今日は 逆だな。……書かれる 前に、連れて 帰りに 行く。"], "raise");
        await U.say(p, "常世の 渡し守", ["{closed}……向こうは、見れば わかる。見ても、わからぬかも しれぬ"], mu);
        await U.M(p, mu, ["{angry,汗}……どっちだよ。"], "arms", S);
        FOG(p, boat, 14); K.sound(p, "bucket.empty_water", 0.6, 0.6);
        await U.narr(p, ["§7舟が 岸を 離れた。§8霧が 厚く なり、自分の 手も 見えなく なった。"], boat);
        await U.end(p, C, { leave: [S], card: "§7→ 霧の 向こうへ", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e2", t: "常世の 渡し場", F: ["F39"],
    syn: "霧が 晴れると、灯りの ついた 高い 建物が 並ぶ 街だった。ムサシ「文明が 進んでるっていうか……いや、逆か？」。渡し守は 渡し場の 野営地を 教えて くれた。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 渡し場の 野営地", "night");
        K.shake(p, 0.3, 0.4); K.sound(p, "ambient.cave", 0.6);
        const mu = U.mu(C), S = U.sail(C, 4, -1.8);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{sweat,汗}……着いたか。足の 裏が、まだ 揺れてる"]);
        if (ok(S)) await K.up(p, S, 8);
        await U.say(p, "常世の 渡し守", ["{closed}ここが 常世じゃ。帳にも 載らぬ 魂が、流れ つく 所", "{closed}ここは 渡し場の 野営地。たき火の そばなら 休める。休めば、そこが あなたの もどる 場所に なる"], mu);
        await U.say(p, "常世の 渡し守", ["{angry,!,low}街は 十の 区に 分かれ、区ごとに 主が いる。主は 魂を 一つずつ 抱えて おる。……あなたの 探す 魂も、きっと その 中だ"]);
        await U.M(p, mu, ["{?}十も あるのか。……主ってのは、強えのか"], "hold", S);
        await U.say(p, "常世の 渡し守", ["{closed}主は みな、一日を 抱えて おる。手放したく ない 一日をな"], mu);
        await U.M(p, mu, ["{closed}……手放したく ねえ 一日、か。……わからなくも ねえ"], "hold");
        K.sound(p, "mob.ravager.roar", 0.4); await K.wide(p, 26);
        /*F39 植: 見た目は 進んだ 街。「いや、逆か？」の 答えは まだ 先 */
        await U.narr(p, ["§7霧の 向こうに、灯りの ついた 高い 建物が 並んで いた。§8ガラスの 窓。まっすぐな 壁。見た ことの ない 形の 街。"]);
        await K.up(p, mu, 10);
        await U.M(p, mu, ["{shock,?,up}……なあ。なんか、俺らが いた ところと 随分 様子が 違うな。", "{closed}文明が 進んでるっていうか……いや、逆か？"], "up");
        await U.M(p, mu, ["{closed}……自分で 言って、わからなく なった。あとで 叩いて 確かめる。"], "hold");
        await U.E(p, mu, ["……逆か、と 言ったな。小僧。その 耳は 覚えて おけ"]);
        await U.M(p, mu, ["{smile,☆}よし。リンを 迎えに 行くぞ。……エンマが『サヤ』って 呼ぶ 娘をな。お前の 探してる やつもな"], "raise", p);
        await K.ots(p, mu, p, 10);
        await U.M(p, mu, ["{closed}……今、うなずいたな。よし。"], undefined, p);
        await U.end(p, C, { leave: [S], card: "§7→ キャンプの 壁を 叩いて みる" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e3", t: "渡し場の 野営地", free: false, F: ["F39"],
    syn: "ムサシが キャンプの 壁を「コン」と 叩いた。「見た目は 新しいのに、音が 年寄りだ」。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 渡し場の 野営地", "night");
        const w = K.fac(p, "u08wall", "u08wall", 99, U.y0(p)), wq = facMark("u08wall", "wall", p.location) || w;
        if (w) await K.at(p, w, 16, 5, 1);
        const mu = U.mu(C);
        if (ok(mu) && wq) await K.walkCam(p, mu, wq, 18);
        /*F39 強: 新しい 見た目と 年寄りの 音 */
        await U.tap(p, mu); await K.at(p, wq, 10, 2.2, 1.2);
        await U.M(p, mu, ["{closed}……コン。", "{shock,?,up}……見た目は 新しいのに、音が 年寄りだ。"], "up");
        await U.M(p, mu, ["{closed}親父の 工房の 柱と 同じ 鳴り方だ。千年 立ってる 木の 音だよ。……白い 石なのに。"], "hold");
        await U.M(p, mu, ["{smile}……こいつは『ばあさん壁』だな。見た目は 若えのに、声が しわがれてる"], "point");
        await U.E(p, mu, ["……ただの 壁だ。名は いらぬ"]);
        await U.M(p, mu, ["{angry}名前が ねえと、呼べねえだろ"], "arms");
        await U.E(p, mu, ["……好きに 呼べ"]);
        await U.E(p, mu, ["……おまえは 聞く。われは 読む"]);
        await U.M(p, mu, ["{smile}答えは、どっちが 先に 着くかだな。……賭けるか？"], "arms");
        await U.E(p, mu, ["……賭けは せぬ。字は、待てば 来る"]);
        await U.M(p, mu, ["{angry,汗}……待つのは もう 飽きただろ、千年も"], "arms");
        await U.E(p, mu, ["……飽きは せぬ。……ただ、長かった"]);
        await U.M(p, mu, ["{sad,…}……そうか。じゃあ 今度は、早足で 行くか"], "hold");
        if (!K.replay(p) && !globalThis.__MQ_TEST) await notice(p, "常世", ["§5§l常世", "", "§f・街の §c十の 区の 主§f と、§c石門の 番兵 5体§f を 倒そう（十冠から 一冠へ 順に。主を 倒すと 抱えて いた 魂が 戻る）", "§f・主は 巨大な 赤い 頭の 姿。近づいて なぐると 戦いが はじまる", "§f・野生の モンスターは §cLv80〜100§f。しゃがんで 歩くと 見つかりにくい", "§f・§6キャンプ§f の たき火で 休む（全回復・もどり先）・キャンプ間の ワープ・元の 世界へ もどる", "", "§7（ガイドブック → ストーリー → 常世 で いつでも 行き来できる）"].join("\n"));
        await U.M(p, mu, ["{closed}……今夜は ここで 休むか。……お前、たき火の 音で 顔が ゆるんでるぞ"], "hold", p);
        await U.end(p, C, { card: "§7→ 野営地の 東に、§e大きな 抜け殻の 建物§7（右上の 案内）" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e4", t: "歓声の 抜け殻", place: HULL, F: ["F12"], hint: "§f野営地の 東、§e歓声の 抜け殻（闘技場）§f へ 行こう",
    syn: "常世の 闘技場は 空っぽなのに、客席が まだ 少し 震えて いた。入口に 彫られた 掟は「名乗りは 三度」。ルミナの 闘技場と 同じ 字だった。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 歓声の 抜け殻（闘技場）");
        const A = K.fac(p, "u08seat", "u08seat", 99, U.y0(p)), sign = facMark("u08seat", "sign", p.location), seats = facMark("u08seat", "seats", p.location) || A;
        if (seats) { await K.at(p, seats, 18, 7, 1.5); for (let k = 0; k < 6; k++) { try { p.dimension.spawnParticle("minecraft:falling_dust_dragon_egg_particle", { x: seats.x + (k - 3) * 1.6, y: seats.y + 1, z: seats.z }); } catch {} } K.shake(p, 0.12, 1.2); }
        await U.narr(p, ["§7誰も いない 客席が、かすかに 震えて いた。§8……歓声の 終わった あとの 揺れだけが、残って いる。"], seats);
        const mu = U.mu(C);
        await U.M(p, mu, ["{closed}……鳴ってる。人が いねえのに、石が 拍手の 形で 鳴ってる。"], "hold");
        await U.M(p, mu, ["{closed}……一つ、二つ、三つ。……誰も いねえ 客席は、苦手だ"], "hold");
        await U.E(p, mu, ["……震えて いるのは 石だけだ。人の 気配は ない"]);
        await U.M(p, mu, ["{sweat}……それが 余計に 怖えんだよ"], "arms");
        await U.M(p, mu, ["{closed}……お前は 平気そうだな。……いや、手を 握ってる。同じか"], "hold", p);
        if (ok(mu) && sign) await K.walkCam(p, mu, sign, 16);
        await K.at(p, sign, 14, 2.4, 0.4);
        /*F12 強: 常世の 闘技場にも 同じ 掟 */
        await U.M(p, mu, ["{?}入口の 柱に 何か 彫ってある。……エンマ、読め"], "point");
        await U.E(p, mu, ["……『名乗りは 三度』"]);
        await U.E(p, mu, ["……三十五年、鍔の 中で 聞いて いた 声だ。ルミナの 闘技場の 門にも、同じ 字が 彫って あった"]);
        await U.M(p, mu, ["{?}……三十五年？ 寝ぼすけの 腕の 中で、ずっと 聞いてたのか"], "hold");
        await U.E(p, mu, ["……鍔の 中は 暗い。歓声だけが、届いた"]);
        await K.ots(p, mu, p, 10);
        await U.M(p, mu, ["{shock,…}……今、うなずいたな。お前も 知ってる 字か。", "{closed}三度 呼ばれりゃ、来るって ことか。……悪くねえ 掟だ。"], "up");
        await U.M(p, mu, ["{closed}……奥の でかい 輪も、気に なる。叩きに 行くぞ"], "point");
        await U.end(p, C, { card: "§7→ 客席の 奥の 大きな 輪を 見に 行く" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e5", t: "鳴らずの 輪", place: HULL, hint: "§f歓声の 抜け殻の §e奥の 輪§f を 見に 行こう",
    syn: "客席の 奥の 大きな 輪に、ムサシは「鳴らずの 輪」と 名を つけた。エンマ「……観覧車、と 書いて ある」。ムサシ「書いて あるだけだろ」。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 抜け殻の 闘技場の 奥");
        const A = K.fac(p, "u08seat", "u08seat", 99, U.y0(p)), wh = facMark("u08seat", "wheel", p.location) || A;
        if (wh) await K.at(p, wh, 20, 9, 0);
        const mu = U.mu(C);
        if (ok(mu) && wh) await K.walkCam(p, mu, wh, 18);
        await U.tap(p, mu); K.sound(p, "block.chain.hit", 0.5, 0.6);
        await U.M(p, mu, ["{closed}……鳴らねえ。鉄の くせに、ちっとも 鳴らねえ 輪だ。", "{smile,☆}よし。こいつは『鳴らずの 輪』だ。"], "point");
        await U.E(p, mu, ["……観覧車、と 書いて ある"]);
        await U.M(p, mu, ["{angry,汗}書いて あるだけだろ。", "{closed}回らねえ 輪に『回る』みてえな 名前を つけて どうする。"], "arms");
        await U.E(p, mu, ["……回って いた ころの 名だ"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{sad,…}……そうか。回ってた ころの 名前か。", "{closed}じゃあ、また 回ったら そう 呼んで やる。"], "hold");
        await U.E(p, mu, ["……回る 日が 来ると 思うか"]);
        await U.M(p, mu, ["{closed}……鉄は 錆びても、叩けば 鳴る。鳴れば、回る 気にも なる"], "hold");
        await U.E(p, mu, ["……鍛冶の 理屈だな"]);
        await U.M(p, mu, ["{smile}俺は 鍛冶の 末っ子だからな"], "arms");
        await K.ots(p, mu, p, 8);
        await U.M(p, mu, ["{?}……お前、今 少し 笑ったな。……鳴らずの 輪、悪くねえ 名前だろ"], undefined, p);
        await U.E(p, mu, ["……観覧車だ"]);
        await U.end(p, C, { card: "§7→ 客席の 下で、何かが 動いた" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e6", t: "抜け殻の 影", place: HULL, battles: 1, hint: "§f歓声の 抜け殻の §e真ん中§f へ",
    syn: "闘技場の 床から、昔の 挑戦者の 影が 立ち上がった。勝つと、空の 客席から 三度、かすれた 歓声が 聞こえた。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 抜け殻の 闘技場");
        const A = K.fac(p, "u08seat", "u08seat", 99, U.y0(p)), fl = facMark("u08seat", "floor", p.location) || A;
        const mu = U.mu(C);
        K.sound(p, "mob.wither.ambient", 0.4); if (fl) { await K.at(p, fl, 14, 4, 0); for (let k = 0; k < 8; k++) try { p.dimension.spawnParticle("minecraft:soul_particle", { x: fl.x, y: fl.y + 0.3 + k * 0.25, z: fl.z }); } catch {} }
        const sh = C.mon(K.wildSp("nether", "L"), 6, 0.5, 0, "smoke"); if (ok(sh)) try { sh.nameTag = "§8闘技場の 影"; sh.addTag("mrpg_spkm"); sh.setDynamicProperty("mrpg:spk", "闘技場の 影"); } catch {}
        await U.narr(p, ["§7床の 継ぎ目から、黒い 影が 立ち上がった。§8……挑戦者の 構えの まま、止まって いた 影だ。"], sh);
        await U.E(p, mu, ["……挑戦者の 影だ。名乗る 前に、止まった"]);
        await U.M(p, mu, ["{sad}……名乗る 前に？ ……そりゃ 悔しいな"], "hold");
        await U.M(p, mu, ["{closed}……一つ、二つ。……よし"], "guard");
        await U.M(p, mu, ["{angry,!}……名乗りも なしか。いいぜ、こっちから 行く。"], "guard");
        await U.E(p, mu, ["……ならば 刃で 名乗れ。それも 掟の うちだ"]);
        const r = await K.battle(p, K.bossOne(["nether", "golem"], 88, 40, 2), { name: "闘技場の 影", arena: "常世の 抜け殻の 闘技場", theme: "hell", hpk: 3, speaker: "闘技場の 影", lines: { half: "……ナノレ……", low: "……サンド……ヨンデ……" } });
        if (r !== "win") { await U.say(p, "ムサシ", ["{sweat,汗}……くそ。一回 下がるぞ", K.RT(p)]); return false; }
        if (ok(sh)) await fade(sh, "minecraft:soul_particle");
        await K.at(p, facMark("u08seat", "seats", p.location) || fl, 14, 8, 1.5);
        for (let k = 0; k < 3; k++) { K.sound(p, "random.levelup", 0.25, 0.5 + k * 0.1); await K.wait(14); }
        await U.narr(p, ["§7空の 客席から、§f三度§7、かすれた 歓声が 聞こえた。"]);
        await U.M(p, mu, ["{shock,…,up}……三度。名乗りの 数だ。", "{closed}誰も いねえのに、ちゃんと 呼んで くれやがった。"], "up");
        await U.E(p, mu, ["……三度 呼ばれて、影は やっと 入場 できたのだ"]);
        await U.M(p, mu, ["{closed}……入場して、終わりか。……そいつに とっちゃ、それで よかったんだな"], "hold");
        await U.M(p, mu, ["{smile}……お前も 聞いたか。……耳が 赤い。聞いたな"], "hold", p);
        await U.E(p, mu, ["……日が 落ちる。野営地へ 戻れ"]);
        await U.M(p, mu, ["{angry,汗}……命令すんな。……戻るけどよ"], "arms");
        K.pay(p, { id: "u08e6" }, 30000, [["s_all3", 1]]);
        await U.end(p, C, { card: "§7→ 夜。§e野営地§7 の たき火へ（右上の 案内）", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e7", t: "野営地の 夜", place: () => { const c = CAMP0(); return c ? { ...c, nm: "常世の 野営地（たき火）", r: 5 } : null; }, hint: "§f常世の §e野営地§f の たき火へ もどろう",
    syn: "たき火の 前で、ムサシが 聞いた。「エンマ、なんで お前は 帳の 字を 信じる」。エンマ「字は、書いた 者が 死んでも 残る」。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 野営地の 夜", "night", "night");
        const mu = U.mu(C, 2.6, 1.4); act(mu, "kneel");
        await K.two(p, mu, p, 14);
        await U.M(p, mu, ["{closed}……一つ、二つ、三つ。……一つ 休む。", "{closed}……親父が 毎朝 叩いてた 数だ。眠れねえ 夜は、これを 数える。"]);
        await U.M(p, mu, ["{?}……なあ、エンマ。なんで お前は、帳の 字を 信じる"]);
        await U.E(p, mu, ["……字は、書いた 者が 死んでも 残る"]);
        await U.M(p, mu, ["{angry}……書いた やつが 死んだら、嘘も 残るだろ。"], "hold");
        await U.E(p, mu, ["……だから、書く 者は 嘘を 書いては ならぬ。……われは 千年、それだけを 守った"]);
        await K.up(p, mu, 10);
        await U.M(p, mu, ["{closed}……俺は 書いた 名前は 信じねえ。本人の 口から 聞いた 名前と、叩いて 鳴った 音だけだ。", "{smile}……けど、嘘を 書かねえ やつの 字なら、聞いて やっても いい。"], "kneel");
        await U.E(p, mu, ["……嘘を 書かぬ 字なら、か。……小僧に しては、ゆるい"]);
        await U.M(p, mu, ["{angry,汗}うるせえ。……ゆるくねえと、千年 付き合えねえだろ"], "kneel");
        await K.ots(p, mu, p, 8);
        await U.M(p, mu, ["{?}……お前は 寝ねえのか。……目が 冴えてる 顔だな", "{closed}……じゃあ、数えて やる。一つ、二つ、三つ。……一つ 休む"], "kneel", p);
        await U.E(p, mu, ["……その 数で、眠れ"]);
        await U.narr(p, ["§7たき火が ぱちり と 鳴った。§8ムサシの 数える 声が、だんだん 小さく なって いった。"], mu);
        await U.end(p, C, { card: "§7→ 夜明け", kind: "night", t: 30 });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u08e8", t: "隅の 人形", place: () => { const c = CAMP0(); return c ? { x: c.x - 3, y: c.y, z: c.z - 2, nm: "常世の 野営地の 隅", r: 5 } : null; }, F: ["F54"], hint: "§f野営地の §e隅§f を 見に 行こう",
    syn: "夜明けの 野営地の 隅に、いつのまにか 人形が 座って いた。どの 町の 案内人も 抱いて いた、あの 人形と 同じ 顔だった。",
    async run(p, d, K) {
      const C = cast(p);
      try {
        await K.open(p, "常世 ― 夜明けの 野営地");
        const mu = U.mu(C);
        /*F54 強: どの 町の 案内人も 抱いて いた 人形 */
        const doll = C.npc("", 7, 5, -2.2, 0, "veil"); act(doll, "kneel");
        if (ok(doll)) await K.push(p, doll, 26, 5, 2, 0.8);
        await U.narr(p, ["§7野営地の 隅に、人形が 一つ 座って いた。§8……ゆうべは、そこに 何も なかった。"], doll);
        await U.narr(p, ["§fどの 町でも 見た 顔だった。§7町の 案内人が、いつも 胸に 抱いて いた 人形と、同じ 顔。"]);
        if (ok(mu) && ok(doll)) await K.approach(p, mu, doll, 1.5, 14);
        act(mu, "kneel");
        await U.narr(p, ["§7ムサシは 槌を 下ろし、人形に 耳を 寄せた。"], mu);
        await U.M(p, mu, ["{closed}……息を してねえ。鳴りも しねえ。", "{angry,…}けど、さっきまで ここに いなかった。……足音も 立てずに 来やがった。"], "kneel");
        await U.E(p, mu, ["……糸の 匂いが する"]);
        await U.M(p, mu, ["{?}……糸？ 人形に 糸なんか ついてねえぞ"], "kneel");
        if (ok(doll)) await SGK.bye(p, doll);
        await K.up(p, mu, 10);
        await U.M(p, mu, ["{shock,!,up}……消えた。", "{closed}……おい。お前、どこかで あれを 見たって 顔を してるな。"], "up");
        await U.M(p, mu, ["{closed}……町で、誰かが 抱いてた 人形か。……お前の 顔が、そう 言ってる"], "hold", p);
        await U.E(p, mu, ["……糸は、どこかへ 続いて いた。……先は、見えぬ"]);
        await U.M(p, mu, ["{sweat}……一つ、二つ、三つ。", "{closed}……よし。気味は 悪いが、足は 動く"], "hold");
        await U.M(p, mu, ["{?}……十の 区、十冠から 順に だったな。……行くか"], "raise", p);
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 十冠の §e遊び場の 区§7 へ（右上の 案内）" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

/* ---- 裏8 の 入口: RU_HOOK.enter を 包む（はじめて 下りる ときだけ 1〜3話。ru.st 0 → 2 は 2話の 前）---- */
const ENTER0 = RU_HOOK.enter;
if (ENTER0) RU_HOOK.enter = async (p, first = false) => {
  const d = load(p); if (!d) return ENTER0(p, first);
  const s = qs(d), r0 = s.ru && typeof s.ru === "object" ? s.ru : null;
  if ((r0 && Number(r0.st) >= 2) || bkHas(s, "u08e2")) return ENTER0(p, first);
  /* 1話: 神殿の 奥の 石段の 下 */
  if (!bkHas(s, "u08e1")) await U.inSt(p, TEMPLE(), () => U.seq(p, ["u08e1"]));
  if (!ok(p)) return;
  /* ru.st 0 → 2（ruins.js の はじめての 場面は 出さず、章の 2話で）*/
  { const d2 = load(p); if (!d2) return; const r = ruOf(d2); if (r.st < 2) { r.st = 2; if (!r.camps.includes(0)) r.camps.push(0); save(p, d2); } }
  await ENTER0(p, false);
  if (!ok(p)) return;
  await U.inSt(p, null, () => U.seq(p, ["u08e2", "u08e3"]));
};

/* ---- 裏15 の 後半（常世から 戻った あとの 各地）: 自由な 話の 列には 入れず、ここで 案内して 流す（常世を 終えて から）---- */
export const AFTER = [];   /* bk_u15.js が { id, place(p), hint } を 入れる */
const afterNext = (s) => { if (!s || !s.ru || Number(s.ru.st) < 4) return null; for (const a of AFTER) if (!bkHas(s, a.id)) return a; return null; };
const ASP = new Map();
const aspOf = (p, a) => { let q = ASP.get(p.id); if (!q || q.id !== a.id) { let o = null; try { o = a.place(p); } catch {} q = { id: a.id, ...(o || {}) }; ASP.set(p.id, q); } return q; };
GOAL_HOOKS.unshift((p, d) => {
  try { const a = afterNext(qs(d)); if (!a) return null; const q = aspOf(p, a);
    return { text: String(a.hint).replace(/§./g, ""), name: q.nm || "", near: "§a「！」の 目印の そばで 立ち止まろう", x: Number.isFinite(q.x) ? q.x + 0.5 : null, z: Number.isFinite(q.z) ? q.z + 0.5 : null, key: `bk:${a.id}` }; } catch { return null; }
});
const ACACHE = new Map();
system.runInterval(() => {
  if (!AFTER.length) return;
  for (const p of world.getAllPlayers()) {
    try {
      const c = ACACHE.get(p.id), now = system.currentTick;
      let a = c && now - c.t < 200 ? c.a : undefined;
      if (a === undefined) { const d = load(p); a = d ? afterNext(qs(d)) : null; ACACHE.set(p.id, { t: now, a }); }
      if (!a || busy.has(p.id) || SGK.EVT.has(p.id)) continue;
      const q = aspOf(p, a); if (!Number.isFinite(q.x)) continue;
      const l = p.location; if (Math.hypot(q.x + 0.5 - l.x, q.z + 0.5 - l.z) > 5) continue;
      const d = load(p); if (!d || !canFight(d) || !SGK.steady(p)) continue;
      ACACHE.delete(p.id);
      bkPlay(p, a.id, { at: { x: q.x + 0.5, y: Number.isFinite(q.y) ? q.y : l.y, z: q.z + 0.5 } }).then(() => ACACHE.delete(p.id)).catch(() => {});
    } catch {}
  }
}, 40);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { ACACHE.delete(playerId); ASP.delete(playerId); }); } catch {}

/* ---- 石門の 番兵（区10〜14）は 寄り道の まま（tokoyo.js の 場面）。ただし 第125版の「倒した 主の 数で 魂が 戻る」場面
   （サヤ・幼なじみ・セオ）は 章の 話（裏10・13・14）へ 移したので、番兵の 後では 出さない（一時だけ 印を 立てて もどす）---- */
const SOULF = ["sisterDone", "heroSoul", "theoSoul"];
for (let i = 10; i < 15; i++) tkOver(i, { post: async (p, d, K2, c) => {
  const d0 = load(p); const tmp = []; if (d0) { const s = qs(d0); for (const k of SOULF) if (!s[k]) { s[k] = 1; tmp.push(k); } if (tmp.length) save(p, d0); }
  try { return await c.orig(); } finally { if (tmp.length) { const d1 = load(p); if (d1) { const s = qs(d1); for (const k of tmp) delete s[k]; save(p, d1); } } }
} });
