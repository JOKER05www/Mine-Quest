/* 第126版: 物語の 選択（15こ。データと 小さな 部品だけ。import なし）— バイブル 06_choices.md
   ・記録は qs(d).ch[選択id] に 一文字（a[0] か b[0]）。一度 決めたら かわらない。選んだら 先に save
   ・CH[id] = { ep: 選ぶ 話, a: [印, ボタンの 文], b: [印, ボタンの 文], def: 古い セーブ・見のがした ときの 道, q: 問い, lose: { 印: 失うもの } }
   ・返って くる 場所（CHBACK は book.js）は 章ファイルが chV(s, id, { g: "…", k: "…" }) で 書く
   ・chPick に 要る 部品（load・save・qs・choose・card）は bkeng.js が CHUI に 入れる（ここは import しない）*/
export const CH = {
  c01: { ep: "b01e6", a: ["g", "帽子を ガロに 渡す"], b: ["k", "帽子を 自分で 持っておく"], def: "g", q: "転がった ピコの 帽子を……", lose: { g: "門の 戦いの ほうび", k: "ガロの 信用" } },
  c03: { ep: "b03e2", a: ["c", "水筒を 子に 渡す"], b: ["h", "水筒を 取っておく"], def: "c", q: "一つしか ない 水筒を……", lose: { c: "ハルカの 好意と、戦いを さける 道", h: "子の 元気な 姿" } },
  c04: { ep: "b04e5", a: ["p", "六影の 台座を 割る"], b: ["s", "ヴァルカの 父の 刀を 引き出す"], def: "s", q: "崩れる 鋳造所で……", lose: { p: "ヴァルカの 父の 刀", s: "六影の 計画を 一つ 止める 機会" } },
  c05: { ep: "b05e5", a: ["w", "かけらを 渡すのを 止める"], b: ["s", "黙って 見ている"], def: "s", q: "セオが レイに かけらを 渡す……", lose: { w: "王墓での レイの 加勢", s: "何も 言わなかった という 事実" } },
  c06: { ep: "b06e5", a: ["k", "ガロの 秘密を 守る"], b: ["t", "ガンテツに 知らせる"], def: "k", q: "「グロウで 言うな」……", lose: { k: "父と 子が 会う 機会", t: "ガロとの 約束と、戦いの ない 道" } },
  c07: { ep: "b07e4", a: ["p", "夜の 海へ 走る ナギサを 止める"], b: ["n", "止めない"], def: "n", q: "火の 壁の 向こう、波に さらわれる 笛……", lose: { p: "相棒の 体（夜の 海で 冷えきる）", n: "ナギサの 息（しばらく 潜れず、祭りで 笛を 吹けない）" } },
  c08: { ep: "b08e9", a: ["t", "灯籠に「セオ」と 書く"], b: ["y", "灯籠に「ヨミ」と 書く"], def: "t", q: "迎え灯籠は 一つ……", lose: { t: "ヨミを 一番に 迎える こと", y: "セオに 先に 声を 届ける こと" } },
  c10: { ep: "b10e8", a: ["d", "封じた 石板を 城に 預ける"], b: ["k", "石板を 持ったまま 追放を 受ける"], def: "k", q: "裁きの 間で……", lose: { d: "戦う 力と、ヘイム王", k: "町の 宿と 店、王の 信頼" } },
  c11: { ep: "b11e8", a: ["r", "黒い 手袋を ルウに 渡す"], b: ["k", "手袋を 持っておく"], def: "k", q: "拾った 黒い 右手の 手袋……", lose: { r: "寒さよけ", k: "ルウが 手袋を 持って 耐えた 時間" } },
  c16: { ep: "b16e2", a: ["r", "封を した 手紙を 読む"], b: ["s", "手紙を 読まない"], def: "s", q: "「娘たちに 渡して くれ」……", lose: { r: "マリンが 最初の 読み手に なる こと", s: "王冠の 間より 前に 答えを 知る こと" } },
  c20: { ep: "b20e9", a: ["z", "ゼファードが 座り続ける"], b: ["o", "オルドが 錠の 座に 座る"], def: "z", q: "ゆるんだ 錠の 座に……", lose: { z: "父と 娘たちの、生きて いる うちの 再会", o: "オルドと 孫の 時間" } },
  u04: { ep: "u04e3", a: ["v", "機神の 型を ヴァルカに 渡す"], b: ["m", "機神の 型を ムサシが 持つ"], def: "m", q: "型は 一組……", lose: { v: "ムサシの 闘魔の 技", m: "ヴァルカの 十年の 願いが 今 かなう こと" } },
  u09: { ep: "u09e7", a: ["f", "人形イトマを 放す"], b: ["k", "案内を 続けて もらう"], def: "k", q: "人形イトマを……", lose: { f: "区と 区の 行き来", k: "（針を 進めた とき）イトマ" } },
  u11: { ep: "u11e7", a: ["a", "時計塔の 針を 進める"], b: ["s", "針を 止めたままに する"], def: "s", q: "三千年 止まった 針を……", lose: { a: "下の 区と、その 中の もの", s: "三千年 待った 人々の 朝" } },
  u15: { ep: "u15e5", a: ["w", "名前の 頁に「ヴォルナグ」と 書く"], b: ["b", "一行 あけて 書かない"], def: "w", q: "名の ない 神の ために……", lose: { w: "神の 安らかな 終わり", b: "神の 頁" } },
};
const chObj = (s) => { if (!s.ch || typeof s.ch !== "object" || Array.isArray(s.ch)) s.ch = {}; return s.ch; };
export const chGet = (s, id) => (s && s.ch && typeof s.ch === "object" && typeof s.ch[id] === "string" ? s.ch[id] : "");
export const chIs = (s, id, v) => chGet(s, id) === v;
/* 道ごとの 差しかえ: chV(s, "c03", { c: "井戸の 前で 笑う", h: "熱で 寝ている" })。決まって いない ときは m._、なければ "" */
export const chV = (s, id, m) => m[chGet(s, id)] ?? m._ ?? "";
/* 見のがした・古い セーブ: 決まって いなければ def を 入れ、s.chA に 記録（何度 呼んでも 同じ）*/
export function chAuto(s, id) {
  const c = CH[id]; if (!s || !c || chGet(s, id)) return;
  chObj(s)[id] = c.def;
  if (!Array.isArray(s.chA)) s.chA = [];
  if (!s.chA.includes(id)) s.chA.push(id);
}
export const CHUI = { load: null, save: null, qs: null, choose: null, card: null, wait: null };
/* 場面の 中で 選ぶ。決まって いれば その 印を 返す。未決なら 二択 → すぐ save → 失った ものを 一拍 見せる */
export async function chPick(p, id, K = null) {
  const c = CH[id], U = { ...CHUI, ...(K || {}) }; if (!c || !U.load) return "";
  const d0 = U.load(p); if (!d0) return c.def; const s0 = U.qs(d0);
  if (chGet(s0, id)) return chGet(s0, id);
  let sel = -1;
  for (let k = 0; k < 4 && sel !== 0 && sel !== 1; k++) { try { sel = await U.choose(p, "えらぶ", `§f${c.q || ""}\n§7（一度 えらぶと やり直せない）`, [[`§l${c.a[1]}`, "textures/ui/mrpg/i_walk"], [`§l${c.b[1]}`, "textures/ui/mrpg/i_walk"]], false); } catch { sel = -1; } }
  const v = sel === 1 ? c.b[0] : sel === 0 ? c.a[0] : c.def;
  const d = U.load(p); if (!d) return v; const s = U.qs(d);
  if (!chGet(s, id)) { chObj(s)[id] = v; if (sel !== 0 && sel !== 1) { if (!Array.isArray(s.chA)) s.chA = []; if (!s.chA.includes(id)) s.chA.push(id); } U.save(p, d); }
  const lost = c.lose && c.lose[chGet(s, id)];
  if (lost && U.card) { try { U.card(p, `§7失った もの: §f${lost}`, 50); if (U.wait) await U.wait(30); } catch {} }
  return chGet(s, id);
}
