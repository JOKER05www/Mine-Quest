/* 第126版 本4「炎の幹部」（ヴォルカ火山帯・ラヴィ／スス／フォルジア）— 作業 MA
   ・古い 話 r3e1〜r3e5（ep_r3.js）を 生かす。新しい 話: 7話 すすけた 町スス（ヨネ婆の 木槌）
   ・MQ8 = b04e4 燃える 鍛冶場（ザクの 台座・爆弾班）・b04e5 六影の 鋳造所（ヴァルカ・選択 C04・セオ）— 今の 段の 場面の かわり
   ・MQ9 = b04e8 フォルジア（マスター戦の あと。母の 足袋）→ 今の 段（セオの 手紙）
   第127版(ST): 第124版の 筋を もどして 一本に。ザクが 台座の 仕上げを 断った → 爆弾班が 鍛冶場に 火 → 台座は 山の 腹の 鋳造所へ（あの 黒い 石は 山の 火でしか 溶けない ＝ 洞くつの 鋳造所の わけ）
   → ヴァルカの 狙い（クロガネの 開かずの 部屋。父の 刀の『結び』の 型が ある）→ 台座と 石板を 賭けた 試し → 崩れる 鋳造所で C04
   → 夜の 鍛冶場（C04 で 背中の 刀か 鉄の 塊か。父の 回想。ボムの 行方も C04 に 合わせる）*/
import { bkAdd, mqOver, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facMark, facSide, facState } from "./epfac.js";
import { H4, Y, OLDE, oldRun, once, gy, at2, out } from "./bk_b01.js";
import { placeOf, townOut, bldOf, openSite } from "./storyplace.js";
import { ok } from "./ui.js";

const PL = (oid) => (p) => { const o = OLDE(oid); try { return o ? o.place(p) : null; } catch { return null; } };
const SUSU = () => bldOf("t57", ["home", "home2", "inn"], "すすけた 里 スス") || (() => { const o = townOut("t57", 0.3, "すすけた 里 スス"); return o ? { x: o.x, z: o.z, nm: "すすけた 里 スス" } : null; })();
const VALKA = (K, p, w = false) => K.npcNear(p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), w);
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);

/* ---------- 施設 ---------- */
const { F, S1 } = FAC_OPS;
/* 打ちかけの 台座（燃える 鍛冶場の 金床の 横）: 黒い 石の 台に 六つの くぼみ（五つは 形が ちがい、一つは 空っぽの 丸）*/
facAdd("b04ped", { D: [9, 12, 8], box: [-1, -3, 3, 3], H: 3, look: [1, 0, 1.2], marks: { round: [1, 0, 1.1] }, build: () => [
  F(0, -2, 0, 2, 2, 0, "polished_blackstone"), S1(1, -2, 1, "iron_trapdoor"), S1(1, -1, 1, "stone_button"), S1(0, 0, 1, "lever"),
  S1(1, 1, 1, "iron_bars"), S1(2, 2, 1, "chain"), S1(1, 0, 1, "air"), S1(-1, -3, 0, "anvil"), S1(-1, 3, 0, "blast_furnace"), S1(2, -3, 0, "campfire"), S1(2, 3, 0, "campfire"),
] });
/* 六影の 鋳造所（アジトの 炉の 間）: 黒い 石の 床・溶けた 鉄の 流れ（溶岩の 溝）・炉・梁・半分の 台座 */
facAdd("b04foundry", { D: [12, 15, 10], box: [-2, -6, 8, 6], H: 6, look: [3, 0, 1.4], marks: { ped: [4, -3, 1.1], sword: [4, 3, 0.4], beam: [6, 0, 1] }, build: () => [
  F(-1, -6, -1, 8, 6, -1, "polished_blackstone"), F(2, -1, -1, 6, 1, -1, "lava"), F(2, -1, -2, 6, 1, -2, "blackstone"),
  F(8, -6, 0, 8, 6, 4, "polished_blackstone_bricks"), S1(7, -4, 0, "blast_furnace"), S1(7, -3, 0, "blast_furnace"), S1(7, 3, 0, "blast_furnace"), S1(7, 4, 0, "magma_block"),
  F(7, -6, 5, 7, 6, 5, "dark_oak_log"), F(0, -6, 0, 0, -6, 4, "dark_oak_log"), F(0, 6, 0, 0, 6, 4, "dark_oak_log"),
  F(4, -4, 0, 5, -2, 0, "polished_blackstone"), S1(4, 3, -1, "magma_block"), S1(5, 3, -1, "magma_block"), S1(6, 0, 0, "dark_oak_log"),
  S1(3, -5, 3, 'lantern ["hanging"=true]'), S1(3, 5, 3, 'lantern ["hanging"=true]'),
] });

/* ---------- 登場人物 ---------- */
castAdd("b04yone", { nm: "ヨネ婆", role: "ススの", gobi: "だよぉ", skin: "c7_yone", town: "t57", hide: (s) => !bkHas(s, "b04e7"),
  at: () => { const q = SUSU(); return q ? { x: q.x + 2, y: q.y, z: q.z } : null; },
  pre: ["{smile}すすで 顔が 黒いのは、生まれつき だよぉ。"],
  after: [
    [(s) => !!s.ending, ["{smile}木槌は、あの 見習いの 子に 渡したよぉ。……打つ 音が、焼けた 村の 鍛冶屋に 似てるんだよぉ。"]],
    [() => true, ["{closed}灰の 降った 冬の ことは、だれも 口に しないよぉ。……あたしは、忘れないように 木槌を 置いてるんだよぉ。"]],
  ] });
castAdd("b04zak", { nm: "ザク", role: "兄弟子", gobi: "", skin: "m6_zack", town: "t30", hide: (s) => !bkHas(s, "b04e9"),
  at: () => { const o = OLDE("r3e1"); const q = o && o.place ? (() => { try { return o.place(); } catch { return null; } })() : null; return q ? { x: q.x - 5, z: q.z + 3 } : null; },
  pre: ["{closed}……"],
  after: [
    [(s) => (s.ch || {}).c04 === "p", ["{sad}あの 台座、割れて よかった。……金の ために 打った 鉄は、軽いんだ。"]],
    [() => true, ["{sad}あの 台座は、六影が 持って いった。……俺の 打った 鉄が、どこかで 何かを する。それが こわい。"]],
  ] });

/* ---------- 1〜3話（古い r3e1〜r3e3）---------- */
const E1 = { id: "b04e1", pv: 127, t: "外れの 鍛冶場", F: ["F26"], battles: 0, fac: "r3smithy",
  place: PL("r3e1"),
  hint: "§fヴォルカ火山帯の §eようがんの 里 ラヴィの 外れの 鍛冶場§f へ 行こう §7（ジンの 伝言）",
  syn: "見習い鍛冶の トンボと 親方 ゲンに 会った。トンボは「きのう、字の 読めない お侍さんが、看板じゃ なくて 槌の 音で 店を 選んだッス」と 笑った。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e1", E1); } };   /* 槌の 音で 店を 選ぶ 侍 /*F26*/
const E2 = { id: "b04e2", t: "火祭りの 支度", F: ["F19", "F24"], battles: 0, fac: "r3mine", pv: 127,
  place: PL("r3e2"),
  hint: "§fラヴィの 外れの §e鉱山の 入口§f へ 行こう §7（トンボと 火祭りの 鉄を 掘る）",
  syn: "地方マスターの カグラが 祭りの 中止を 告げた。ゲンは ぽつりと 言った。「十二年前、灰の 降った 冬に、焼けた 村から 泣いてる 子を 一人 拾ったんでい」。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e2", E2); } };   /* 灰の 降った 冬・拾った 子 /*F19 F24*/
const E3 = { id: "b04e3", t: "火薬の におい", F: ["F22"], fac: "r3haul", pv: 127,
  place: PL("r3e3"),
  hint: "§fラヴィの 外れの §e鉄の 運び道§f へ 行こう §7（トンボと 祭りの 鉄を 運ぶ）",
  syn: "赤い 外套の 女が 爆弾班を 町から 追い払った。「台座の 鉄を 見に 来たら、この 有りさまだ。町で やるなと 言ったろ」。去りぎわに「祭り、やれると いいね」。",
  async run(p, d, K) { return oldRun(p, d, K, "r3e3", E3); } };   /* 赤い 外套の 女 /*F22*/

/* ---------- 4話 燃える 鍛冶場（MQ8）---------- */
const ZAK = (K, p, w = false) => K.npcNear(p, "§e兄弟子 ザク", K.PJ("m6_zack", 8), w);
const BOMB = (K, p, w = false) => K.npcNear(p, "§c六影 爆弾班 ボム", K.PJ("bomb", 9), w);
const E4 = { id: "b04e4", pv: 127, t: "燃える 鍛冶場", battles: 1, fac: "r3smithy",
  hint: "§fヴォルカ火山帯の §e町外れの 鍛冶場§f へ 行こう",
  syn: "ゲンの 鍛冶場が 燃えて いた。兄弟子の ザクは、六影に 金で 頼まれて「台座」を 半分 打ち、怖く なって 仕上げを 断った。命令書に ない その 仕返しに、爆弾班が 炉に 火薬を 投げこみ、屋根に 火が 回った。ゲンは 火の 粉から トンボを かばって 手首に やけどを した（祭りが 終わるまで 槌は 振れない）。打ちかけの 台座には 六つの くぼみ。五つは 形が ちがい、一つは 空っぽの 丸。爆弾班の ボムを 退けたが、その 間に 手下が 台座を 山の 腹の「鋳造所」へ 運び出して いた。",
  async run(p, d, K) {
    const y0 = Y(K, p), fs = K.fac(p, "r3smithy", "smithy", 3, y0), pq = K.fac(p, "b04ped", "b04ped", 3, y0);
    if (fs) try { facState("r3smithy", 1); } catch {}
    await K.open(p, "燃える 鍛冶場", "ash");
    K.sound(p, "random.explode", 0.8); K.shake(p, 0.3, 0.5);
    const fire = fs || at2(K, p, 7, 0, 1);
    await K.blaze(p, fire, 4); await K.wide(p, 14);
    await K.narr(p, ["§7ゲンの 鍛冶場の 屋根から、黒い 煙。炉の 前で、火薬の 焦げた においが する。"]);
    const eH = K.hero(p), eG = K.cast(p, "r3gen"), eT = K.cast(p, "r3tombo"), eZ = ZAK(K, p); K.act(eG, "kneel"); K.act(eZ, "sad");
    await K.hsay(p, H4(["{shock,!,up}ゲンさん！ トンボくん！"], ["{shock,up}……ゲンさん！ トンボくん！"], ["{shock,!}……ゲン！ トンボ！"], ["{shock,!,up}ゲンさま！ トンボさん！"]), eG);
    await K.up(p, eT, 8);
    await K.csay(p, "r3tombo", ["{cry,tears,up}親方が……おれを かばって、手首を……！"], eH);
    await K.csay(p, "r3gen", ["{sweat,汗}……でけえ 声 出すな。手首を ちょいと 焼いただけでい。祭りが 済む ころにゃ 治るでい。"], eT);
    await K.up(p, eZ, 8);
    await K.say(p, "ザク", ["{cry,tears}……おれの せいだ。六影に、金で 頼まれて……§e台座§f を 半分 打っちまった。", "{sad,up}何に 使うか、だれも 言わねえ。打ってる うちに 怖く なって、仕上げを 断った。……そしたら、炉に 火薬を。"], eH);
    const ped = pq || at2(K, p, 6, 0, 1);
    await K.push(p, ped, 26, 4, 1.4, 0.4);   /* 台座の 六つの くぼみ（台座）*/
    await K.narr(p, ["§7金床の 横に、打ちかけの 黒い 石の 台。六つの くぼみ。五つは それぞれ 形が ちがう。", "§7残る 一つは……空っぽの、まるい くぼみ。"], ped);
    await K.hsay(p, H4(["{?}六つ……。何を はめる 台なの？"], ["{?}六つの くぼみ……。何を はめるの？"], ["{?}六つ。一つだけ 丸。……何を はめる。"], ["{?}六つの くぼみ……何を はめる 台なのでしょう。"]), eZ);
    await K.say(p, "ザク", ["{closed}わからねえ。……ただ、あの 黒い 石は 町の 炉じゃ 溶けねえ。仕上げは 山の 火で やるって 言ってた。"], eH);
    K.sound(p, "random.fuse", 0.8);
    const eB = BOMB(K, p); K.act(eB, "point");
    await K.low(p, eB, 12);
    await K.say(p, "爆弾班 ボム", ["{smile,low}六影 爆弾班の ボム。……断った 鍛冶屋の 炉は、使えなく して やる。それが 爆弾班の やり方さ。", "{closed}その 台座は、これから 手下が 山の 鋳造所へ 運ぶ。ついでに アンタの 石板も もらって いくよ。"], eH);
    await K.hsay(p, H4(["{rage,怒,up}人の いる 鍛冶場に 火薬を 投げたの！？ 許さない！"], ["{angry,up}……人の いる 所に 火薬を 投げるなんて。"], ["{angry,up}……人の いる 炉に 火薬。許さない。"], ["{rage,怒,up}人の いる 鍛冶場に 火薬など！ 許せません！"]), eB);
    if (!K.flag(p, "b04e4w")) {
      const r = await K.battle(p, K.team(["nether", "dragon"], 29, 3, 5), { name: "六影 爆弾班", arena: "爆弾班", theme: "volcano", speaker: "爆弾班 ボム", lines: { half: "……熱い……まだだ……！", low: "ヴァルカ様……すみません……" } });
      if (r !== "win") { await K.sayAt(p, "§c六影 爆弾班 ボム", K.PJ("bomb", 9), "ボム", ["……石板は また 今度だ。", K.RT(p)]); return false; }
      K.setFlag(p, "b04e4w");
    }
    const eB2 = BOMB(K, p, true); K.act(eB2, "recoil");
    await K.narr(p, ["§7気づけば、金床の 横の 台座が ない。戦いの 間に、手下が 荷車で 運び出して いた。"], ped);
    await K.up(p, eB2, 8);
    await K.say(p, "爆弾班 ボム", ["{sweat,汗}ちっ……ヴァルカ様に 知らせる！ 台座は もう 山へ 向かってる。§e鋳造所§f まで 来れるもんなら 来て みな！"], eH);
    if (ok(eB2)) await out(K, p, eB2);
    const eZ2 = ZAK(K, p, true);
    await K.up(p, eZ2, 8);
    await K.say(p, "ザク", ["{angry}あいつらの §e鋳造所§f は、里から 離れた 火山の 奥だ。岩山の 坑口から 溶岩の 洞くつへ 下りた 所に 炉を 据えてる。", "{closed}……あの 台座、仕上げさせないで くれ。おれが 打った 鉄が、何かを する のは 嫌だ。"], eH);
    await K.hsay(p, H4(["{angry,!}追うよ！ 台座は 仕上げさせない！"], ["{angry}……追いましょう。台座を、仕上げさせないわ。"], ["{closed}追う。台座は 仕上げさせない。"], ["{angry}追いかけます！ 台座を 仕上げさせません！"]), eZ2);
    const dd = K.load(p); if (dd) { K.qs(dd).ch4a = 1; K.save(p, dd); }
    await K.end(p, { bye: [eZ2, eG, eT], card: "§7― 火山の 奥、六影の 鋳造所へ ―" });
    return true;
  } };

/* ---------- 5話 六影の 鋳造所（MQ8。溶岩の 洞くつの 炉の 間。ヴァルカとの 試し・選択 C04・セオ）---------- */
/* 第127版(fac): 鋳造所は 里から 離れた 火山の 奥の 洞くつ（岩山の 坑口 → 大きな 洞。炉の 列・溶けた 鉄の 流れ・るつぼ・梁・台座）。建てられない 所は 前の とおり */
const FORGEQ = () => { const c = townOut("t30", 0, "x"); return c ? openSite("b04forge", c, 3, 120, 450, "ヴォルカの 火山の 奥 六影の 鋳造所") : null; };
const E5 = { id: "b04e5", t: "炉の 前の 決闘", F: ["F23"], battles: 1, pv: 127, place: () => FORGEQ(),
  hint: "§fヴォルカ火山帯の §e六影の 鋳造所§f へ 行こう §7（火山の 奥の 岩山の 坑口から 入る 溶岩の 洞くつ。右上の 案内）",
  syn: "鋳造所は 溶岩の 洞くつの 奥。台座の 黒い 石は 町の 炉では 溶けず、山の 腹の 火で しか 仕上がらない。炉の 前の ヴァルカは「迷いが 鉄に 出てる」と 言った。狙いは 石板 そのものでは なく、クロガネの「開かずの 部屋」。父の 刀の『結び』の 型が そこに ある。台座と 石板を 賭けた 試しの あと、崩れる 鋳造所で、片側に 半分の 台座、片側に 溶けた 鉄へ すべり落ちる 布巻きの 刀。",
  async run(p, d, K) {
    const y0 = Y(K, p); let MK = "b04forge";
    const cq = K.fac(p, "b04forge", "forgecave", 3, y0), fl = cq && facMark("b04forge", "floor", p.location);
    if (fl) { await K.open(p, "火山の 奥 六影の 鋳造所の 坑口", "ash"); await K.moveTo(p, fl, "六影の 鋳造所（溶岩の 洞くつの 奥）", [], facMark("b04forge", "forge"), 9); }
    else {
      MK = "b04foundry"; const hq = placeOf("hall", 3, true); let fq = null;
      if (hq) await K.moveTo(p, { x: hq.x, y: hq.y, z: hq.z }, "六影の 鋳造所");
      else { try { fq = facSide(p, K.S(p), 16, "b04foundry", "b04foundry", 3, y0); } catch {} if (fq) await K.moveTo(p, { x: fq.x, y: y0, z: fq.z }, "六影の 鋳造所", [], fq, 10); else await K.open(p, "六影の 鋳造所", "ash"); }
    }
    const mk = (n, a, b, dy) => facMark(MK, n, p.location) || at2(K, p, a, b, dy);
    const eH = K.hero(p), eV = VALKA(K, p); K.hold(eV, "hammer"); K.act(eV, "work");
    if (ok(eV)) K.turn(eV, mk("ped", 4, -3, 1.1));
    await K.pull(p, eV, 18);
    await K.narr(p, ["§7溶岩の 洞くつの 奥。山の 腹の 火を 引きこんだ 炉の 前で、赤い 外套の 女が 背を 向けて 台座を 打って いる。"], eV);
    for (let k = 0; k < 2; k++) { K.act(eV, "raise"); await K.wait(6); K.sound(p, "random.anvil_use", 0.9 + k * 0.1); K.act(eV, "work"); await K.wait(6); }
    await K.hsay(p, H4(["{shock,!}運び道の、赤い 外套の 人……！"], ["{shock,!}……運び道の、赤い 外套の 人。"], ["{shock,!}……運び道の、赤い 外套。"], ["{shock,!}運び道で お会い した、赤い 外套の 方……！"]), eV);
    K.turn(eV); K.act(eV, "hold");
    await K.sixMark(p, eV, "valka");
    await K.say(p, "ヴァルカ", ["{closed}……下手な 打ち方だ。迷いが 鉄に 出てる。ザクって 子は、いい 腕なのに 怖がりだね。", "{smile,low}アタシは 六影 三の座、ヴァルカ。……この 黒い 石は、町の 炉じゃ 溶けない。山の 腹の 火で しか 仕上がらないのさ。"], eH);
    await K.hsay(p, H4(["{angry,up}爆弾班が ゲンさんの 鍛冶場を 燃やしたんだよ！ その 台座、何に 使うの！"], ["{sad,up}……鍛冶場が、燃やされたわ。その 台座で、何を するの？"], ["{angry}鍛冶場を 燃やした。台座の 使い道。言って。"], ["{angry,up}爆弾班が 鍛冶場を 燃やしたのです！ その 台座、何に お使いに なるのですか！"]), eV);
    await K.say(p, "ヴァルカ", ["{angry}燃やしたのは ボムの 勝手さ。……止められなかったのは アタシだ。言い訳は しない。", "{closed}使い道は 知らないね。参謀の 注文さ。アタシは 自分の 分しか 知らない。"], eH);
    await K.ots(p, eH, eV, 8);
    await K.say(p, "ヴァルカ", ["{up}アタシの 狙いは 石板じゃ ない。§6クロガネ§f の 工房の §c開かずの 部屋§f さ。", "{closed}あの 部屋に、親父の 刀の『結び』を 打つ 型が 眠ってる。……アタシは それが 欲しい。"], eH);
    await K.say(p, "ヴァルカ", ["{angry,low}アンタの 石板を 賭けな。アタシは 台座を 賭ける。……試しだ。"], eH);
    await K.hsay(p, H4(["{angry,!}……いいよ。台座も 石板も 渡さない！"], ["{closed}……分かったわ。台座は、ここに 置いて いって もらう。"], ["{closed}乗った。台座は 置いて いけ。"], ["{angry}……お受け します。台座は 置いて いって いただきます！"]), eV);
    if (!K.flag(p, "b04e5w")) {
      await K.duel(p, "§c§l六影 三の座 ヴァルカ", "§c溶けた 鉄の 流れの 上で！", { fams: ["dragon"] });
      const r = await K.battle(p, K.team(["dragon", "nether"], 33, 3, 44, K.leadOf("dragon", 33)), { name: "六影 三の座 ヴァルカ", arena: "炎の 幹部", theme: "volcano", hpk: 6, extra: 0.4, tag: "三の座", sboss: true, speaker: "ヴァルカ", lines: { half: "……いい 火だ。", low: "ちっ……！" } });
      if (r !== "win") { await K.sayAt(p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), "ヴァルカ", ["{closed,low}……試しだ。石板は 取らないよ。出直して きな。", K.RT(p)]); return false; }
      K.setFlag(p, "b04e5w");
    }
    const eV2 = VALKA(K, p, true);
    await K.up(p, eV2, 8);
    await K.say(p, "ヴァルカ", ["{angry,汗}ちっ……約束だ。台座は――"], eH);
    /* 崩れる 鋳造所（戦いで 溶岩の 溝が あふれた）*/
    K.sound(p, "random.explode", 0.9); K.shake(p, 0.9, 1.2); K.flash(p, true); K.act(eV2, "kneel");
    const pd = mk("ped", 4, -3, 1.1), sw = mk("sword", 4, 3, 0.4);
    await K.at(p, mk("beam", 6, 0, 1), 12, 3, 0.6);
    await K.narr(p, ["§7戦いの 熱で 溶岩の 溝が あふれ、天井の 梁が 落ちた。ヴァルカは 梁の 下で 動けない。"], eV2);
    await K.at(p, pd, 12, 2.6, 0.6);
    await K.narr(p, ["§7片側に、半分 打たれた 台座。六つの くぼみ。あふれた 溶岩が 迫って いる。"], pd);
    K.burst(p.dimension, sw, "minecraft:lava_particle", 8, 0.6, 0.3);
    await K.push(p, sw, 20, 3, 1.4, 0.2);   /* 布巻きの 刀 /*F23*/
    await K.narr(p, ["§7もう 片側に、ヴァルカの 背から 落ちた 布巻きの 刀。溶けた 鉄の 流れへ、少しずつ すべって いく。"], sw);
    await K.up(p, eV2, 8);
    await K.say(p, "ヴァルカ", ["{angry}……両方は 取れや しないよ。台座を 割るなら 今だ。……好きに しな。"], eH);
    const v = await K.pick(p, "c04");
    if (v === "p") {
      K.sound(p, "random.anvil_break", 0.9); K.burst(p.dimension, pd, "minecraft:basic_smoke_particle", 12, 0.8, 0.3);
      await K.at(p, pd, 12, 2.6, 0.6);
      await K.narr(p, ["§7あなたの 相棒が 台座に 体当たりした。台座は 割れて、六つの くぼみは 二つに 裂けた。", "§7……刀は 溶けた 鉄の 中へ 沈んだ。引き上げた ときには、布の 燃えた 鉄の 塊に なって いた。"], pd);
      await K.up(p, eV2, 8);
      await K.say(p, "ヴァルカ", ["{sad,…}……親父の 刀が。", "{closed}……いいさ。台座が 世に 出るより ましだ。……約束どおりだよ。"], eH);
    } else {
      await K.at(p, sw, 12, 2.6, 0.4);
      await K.narr(p, ["§7あなたは 刀の 布を つかんで 引き上げた。手の ひらが 熱い。", "§7……その 間に、駆けこんで きた 爆弾班の 手下が、半分の 台座を かついで 洞くつの 口へ 走り去った。"], sw);
      await K.up(p, eV2, 8);
      await K.say(p, "ヴァルカ", ["{shock,…}……親父の 刀を、なんで。", "{closed}……借りが できたね。台座の 行き先は、アタシの 口からは 言えない。", "{angry,low}……あいつら、逃げ道の 運び道を 爆破する だろうさ。追っても むだだよ。"], eH);
    }
    if (ok(eV2)) { const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:white_smoke_particle", 6, 0.6, 0.3); await K.up(p, g, 8); K.rmCine(g); } }
    await K.narr(p, ["§7相棒と 二人で 梁を 押しのけた。ヴァルカは 黙って 立ち上がった。"], eV2);
    K.act(eV2, 0);
    await K.say(p, "ヴァルカ", ["{closed}……今日は 引く。借りの ある 相手に、刀は 抜かない。", "{angry,low}台座が 一つ 減っても、支度は 進む。……次の 試しも、手は 抜かないよ。"], eH);
    if (ok(eV2)) await out(K, p, eV2);
    /* セオが 来る（次の 行き先）*/
    const eS = THEO(K, p);
    await K.up(p, eS, 8);
    await K.say(p, "セオ", ["{sweat,汗}はあ、はあ……ジンさんの 知らせで、兵と いっしょに 洞くつの 口まで 来ました。けがは ありませんか？", "{closed}……口で、逃げ遅れた 爆弾班を 一人 つかまえて 兵に 渡しました。命令書は いつも、古めかしい 年寄りの 字で 来ると こぼして いました。"], eH);
    await K.hsay(p, H4(["{?}年寄りの 字……？"], ["{?}年寄りの 字……。"], ["{?}年寄りの 字。"], ["{?}年寄りの 字、ですか……？"]), eS);
    await K.say(p, "セオ", ["{closed}台座の 鉄は、砂漠の 王墓の 古い 記録と 似て いる。……王墓に 入るには 地図が 要る。僕が 手配します。§eサンドリア城の 城門§f で 落ち合いましょう。"], eH);
    K.pay(p, E5, 6000, [["e_red", 1], ["SEED2", 2], ["tms_dragon", 1]]);
    await K.end(p, { leave: [eS], card: "§7― ラヴィの 焼けた 鍛冶場へ ―" });
    return true;
  } };

/* ---------- 6話 焼けた 鍛冶場（夜）（古い r3e4 を 書き直し。C04 で 背中の 刀か 鉄の 塊か・父の 回想）---------- */
async function hammer(K, p, e, n = 3) { K.hold(e, "hammer"); for (let i = 0; i < n; i++) { K.act(e, "raise"); await K.wait(4); K.act(e, "hold"); if (ok(e)) K.burst(p.dimension, e.location, "minecraft:lava_particle", 3, 0.5, 1); K.sound(p, "random.anvil_use", 0.9); await K.wait(6); } K.act(e, 0); }
const E6 = { id: "b04e6", pv: 127, t: "鍛冶場の 夜", F: ["F22", "F24"], ans: [], battles: 1, fac: "r3smithy",
  place: PL("r3e4"),
  hint: "§fラヴィの 外れの §e焼けた 鍛冶場§f へ もどろう §7（夜、まだ 槌の 音が する）",
  syn: "手首を 焼いて 祭りまで 槌を 振れない ゲンに かわり、トンボは「火祭りの 刀は おれが 打つ」と 決めた。その 夜、ヴァルカが 槌の 音を 聞きに 来た。背の 布の 中は 父の 最後の 刀（または 溶けて 塊に なった 鉄）。十二年前、父は 灰の 降った 夜に「折れない 刀を」と 願い、その 刀が 村を 焼いた。「親父は 最後に 嘘を ついた。『この 刀は 人を 守る』って」。結びを 打つには 型が 要り、その 型は ある 部屋に 眠って いる。トンボには「もう 一度 打って みな。試しだ」。去りぎわに「アタシは 六影だ」。",
  async run(p, d, K) {
    const y0 = Y(K, p), FS = K.fac(p, "r3smithy", "smithy", 3, y0); if (FS) try { facState("r3smithy", 1); } catch {}
    await K.open(p, "焼けた 鍛冶場（夜）", "night", "night");
    if (FS) await K.at(p, FS, 14, 6, 1.5);
    let eH = K.hero(p); const eT = K.cast(p, "r3tombo"), eG = K.cast(p, "r3gen"); K.act(eG, "kneel");
    await K.narr(p, ["§7火事の 夜から 二日。焼けた 鍛冶場に、まだ 槌の 音が 響いて いた。"], eT);
    await hammer(K, p, eT, 3);
    await K.csay(p, "r3gen", ["{sweat,汗}……来たか。手首が、まだ 言う ことを きかねえでい。祭りまでは 槌が 持てねえ。"], eH);
    K.act(eT, "raise");
    await K.up(p, eT, 10);
    await K.csay(p, "r3tombo", ["{angry,!,up}……決めたッス！ 親方の 手首が 治るまで、おれが 打つッス！ 火祭りの 刀も、おれ 一人で 打つッス！"], eG);
    await K.csay(p, "r3gen", ["{closed}……十年 早いと 言ったでい。"], eT);
    await K.csay(p, "r3tombo", ["{cry,tears,up}でも、だれかが 打たなきゃ、祭りが なくなるッス！！"], eG);
    await K.up(p, eG, 10); K.turn(eG, K.away(eG, p, 3));   /* 背を 向けたまま 言う */
    await K.csay(p, "r3gen", ["{smile,tears,up}……勝手に しやがれってんでい。"]);
    K.turn(eG); K.act(eT, 0);
    /* 鉄を 盗みに 来た 下っぱ */
    K.sound(p, "random.fuse", 0.6);
    const eA = K.npcNear(p, "§c爆弾班 ドカン", K.PJ("noxa", 9)), eB = K.npcNear(p, "§c爆弾班 パチ", K.PJ("noxb", 9));
    await K.low(p, eA, 10);
    await K.say(p, "ドカン", ["{smile,low}へへ……親方が 寝てる うちに、祭りの 鉄を……"], eB);
    const eV = VALKA(K, p);
    if (ok(eV)) { K.burst(p.dimension, eV.location, "minecraft:basic_flame_particle", 8, 0.8, 0.2); }
    await K.sixMark(p, eV, "valka");
    await K.up(p, eV, 10);
    const v = K.ch(p, "c04");
    await K.say(p, "ヴァルカ", ["{angry,怒,up}ドカン、パチ。……祭りの 鉄から、手を 離しな。"], eA);
    await K.say(p, "パチ", [v === "p" ? "{sweat,汗}ひっ……ヴァ、ヴァルカ様！ で、でも ボムの 兄貴が 捕まって、手ぶらじゃ……" : "{sweat,汗}ひっ……ヴァ、ヴァルカ様！ で、でも 台座の 組は もう 北へ……おれたちは 置いてけぼりで……"], eV);
    await K.say(p, "ヴァルカ", ["{angry,low}爆弾班の 仕事は 終わった。……火を 脅しに 使う やつは、六影でも 許さないよ。"], eA);
    await K.say(p, "ドカン", ["{rage,怒,up}う、うるせえ！ 手ぶらで 帰れるかよ！ ガキ、勝負だ！"], eH);
    await K.say(p, "ヴァルカ", ["{closed}……アタシは 手を 出さないよ。アンタが 追い払いな。……試しだ。"], eH);
    K.act(eH, "guard");
    await K.hsay(p, H4(["{angry,up}言われなくても！ 鉄は 渡さない！"], ["{angry,up}……言われなくても、守るわ。"], ["{angry,up}……言われなくても。"], ["{angry,up}言われずとも、お守り します！"]), eA);
    if (!K.flag(p, "r3e4w")) {
      const r = await K.battle(p, K.team(["nether", "dragon"], 30, 3), { name: "六影 爆弾班の 下っぱ", arena: "鍛冶場の 夜", theme: "volcano", speaker: "ドカン", lines: { half: "ヴァ、ヴァルカ様が 見てる……！", low: "ひぃっ、退却ーっ！" } });
      if (r !== "win") { await K.sayAt(p, "§c六影 幹部 ヴァルカ", K.PJ("valka", 10), "ヴァルカ", ["{closed,low}……まだまだ だね。出直して きな。", K.RT(p)]); return false; }
      K.setFlag(p, "r3e4w");
    }
    eH = K.hero(p, false);
    { const a = K.npcNear(p, "§c爆弾班 ドカン", K.PJ("noxa", 9), true), b = K.npcNear(p, "§c爆弾班 パチ", K.PJ("noxb", 9), true); K.act(a, "recoil"); await Promise.all([out(K, p, a), out(K, p, b)]); }
    const eV2 = VALKA(K, p, true), eT2 = K.cast(p, "r3tombo", true);
    await K.hsay(p, H4(["{angry,up}……ヴァルカ。何しに 来たの。"], ["{angry,up}……何しに 来たの。"], ["{angry,up}……用は 何。"], ["{angry,up}……何の ご用ですか。"]), eV2);
    await K.say(p, "ヴァルカ", ["{closed}今夜は 戦いに 来たんじゃ ない。……槌の 音を、聞きに 来ただけさ。"], eH);
    await hammer(K, p, eT2, 2);
    K.hold(eV2, v === "p" ? "box" : "katana"); K.act(eV2, "show", false);
    await K.push(p, eV2, 22, 3, 1.2, 1.1);
    if (v === "p") await K.narr(p, ["§7ヴァルカの 背に、布で 巻いた 黒い §f鉄の 塊§7。鋳造所で 溶けた、父の 刀の なれの はて。"], eV2);
    else await K.narr(p, ["§7ヴァルカの 背に、布で 巻いた 一振りの 刀。§f柄も 鍔も なく、刃の 結びが 打たれて いない§7。……未完の 刀。"], eV2);
    await K.say(p, "ヴァルカ", ["{closed,…,up}……親父の 最後の 刀さ。十二年前の 冬、灰の 降った 夜に 打った。"], eT2);
    await K.flashback(p, { set: "fb_vforge", label: "§7―― 十二年前　灰の 降った 冬の 夜　鍛冶の 家の 炉", tod: "night", ptc: "ember",   /* 第127版: ヴァルカの 父の 回想（何を 焼いたかは 言葉だけ）*/
      actors: { f: { nm: "§c鍛冶の 男", job: K.PJ("m6_vulk", 9), at: [4, -0.6], look: [6, -0.6], hold: "hammer" }, y: { nm: "§c若い ヴァルカ", job: K.PJ("valka", 10), at: [2.2, 1.4], look: "f" } },
      beats: [
        ["narr", "§7十二年前の 冬の 夜。山の ふもとの 鍛冶の 家。炉の 前で、男が 一人 槌を 振って いた。", "f"],
        ["fx", "spark", [5.5, -0.6, 0.8]], ["act", "f", "raise"], ["snd", "random.anvil_use", 0.8], ["act", "f", "work"],
        ["say", "y", "{sad,up}……父さん、もう 三日 寝てない。外、灰が 降ってるよ。", "f"],
        ["fx", "ash", [4, 0, 2.4]],
        ["say", "f", "{closed,low}……折れない 刀が 要るんだ。何が 来ても、折れない 刀が。", "y"],
        ["narr", "§7灰の 中で、男の 目に 紫がかった 影が 流れた。……槌の 音が、ちがう 音に 変わった。", "f"],
        ["act", "f", "show"], ["hold", "f", "katana"],
        ["say", "f", "{smile,low}……できた。ヴァルカ。この 刀は、人を 守る。", "y"],
        ["go", "f", [10, -2.5], 24],
        ["narr", "§7その 夜、峠の 向こうの 村から 火の 手が 上がった。……男は、帰らなかった。", [9, -2, 2]],
        ["fx", "fire", [10, -2.5, 1]],
      ] });
    await K.up(p, eV2, 10);
    await K.say(p, "ヴァルカ", ["{sad,low}親父は 最後に『この 刀は 人を 守る』って、嘘を ついた。……その 刀で、村が 一つ 焼けた。", "{closed,up}……だから アタシは、嘘を つかない。火は 罪じゃ ない。打つ やつの 心だ。"], eT2);   /*F24*/
    K.act(eV2, 0); K.hold(eV2);
    await K.two(p, eV2, eT2, 12);
    await K.csay(p, "r3tombo", ["{sad,up}……その 刀、結びを 打たないんスか？"], eV2);
    await K.say(p, "ヴァルカ", v === "p" ? ["{closed}……もう 刀じゃ ない。鉄の 塊さ。……それでも、捨てられない。"] : ["{closed}……まだ、打てないんだよ。"], eT2);
    await K.say(p, "ヴァルカ", ["{closed}結びには『型』が 要る。人を 斬らない 鉄の 型さ。", "{sad,low}その 型が 眠ってる 部屋の 戸は、アタシには 開かない。……昔、開けようと して 追い出された。"], eT2);   /*F22*/
    K.act(eV2, "point");
    await K.say(p, "ヴァルカ", ["{angry}トンボ。槌を 振る とき、息を 止めるな。火に 合わせて 吐け。", "{smile,low}もう 一度 打って みな。……試しだ。"], eT2);
    K.act(eV2, 0);
    await hammer(K, p, eT2, 3);
    await K.csay(p, "r3tombo", ["{shock,!,up}……音が、ちがうッス！ 鉄が、歌ってるッス！"], eV2);
    await K.say(p, "ヴァルカ", ["{smile,up}……いい 音だ。昔の アタシより、いい。"], eT2);
    await K.say(p, "ヴァルカ", ["{angry,low}……勘違い するんじゃ ないよ。アタシは 六影だ。", "{closed}次に 命令が 来たら、アンタらの 大事な もんでも 取る。……それが アタシの 分だ。"], eH);   /* 第125版(vk): ここでは 改心しない */
    await out(K, p, eV2);
    const eG2 = K.cast(p, "r3gen", true);
    await K.up(p, eG2, 12);
    await K.csay(p, "r3gen", ["{closed,…}……あの 女、鍛冶の 家の 子でい。槌の 握りで わかるんでい。"], eT2);
    await K.csay(p, "r3tombo", ["{angry,!,up}親方！ おれ、打つッス！ 火祭りまでに、ぜったい 刀を 打つッス！"], eG2);
    await K.hsay(p, H4(["{smile,up}……じゃあ わたしたちは、カグラさんに 勝って 石板を。祭りまでに、ぜったい もどる！"], ["{smile,up}……わたしたちは、カグラさんの ところへ。祭りまでに、もどるわ。"], ["{closed,up}……カグラに 勝って くる。祭りには、もどる。"], ["{smile,up}わたしたちは カグラさまの もとへ。祭りまでに、必ず もどります。"]), eT2);
    K.pay(p, E6, 400, [["c_fruit2", 1], ["e_dragon1", 1]]);
    await K.end(p, { leave: [eT2], bye: [eG2], card: "§7→ すすけた 里 スス、それから 鍛冶王の 城 フォルジアの §6カグラ§7 へ", kind: "night" });
    return true;
  } };

/* ---------- 7話 すすけた 町スス（新）---------- */
const E7 = { id: "b04e7", t: "ススの 木槌", F: ["F19", "F60"], battles: 0,
  place: () => SUSU(),
  hint: "§fすすけた 里 §eスス§f へ 行こう §7（焼けた 村の ことを 知る 婆さまが いる）",
  syn: "ススの ヨネ婆は、焼けた 村の 小さな 木槌を 預かって いた。木槌の そばに、灰色の 染みの ついた 紙きれ。「灰の 降った 冬の ことは、だれも 口に しない」。",
  async run(p, d, K) {
    await K.open(p, "すすけた 里 スス", "ash");
    const eH = K.hero(p), eY = K.cast(p, "b04yone"); K.hold(eY, "hammer");
    await K.up(p, eY, 8);
    await K.csay(p, "b04yone", ["{closed}ラヴィの 鍛冶場の 話かい。……焼けた 村の ことを 聞きに 来たんだね。", "{sad}灰の 降った 冬に、峠の 向こうの 鍛冶の 村が 一晩で 焼けたんだよぉ。"], eH);
    K.act(eY, "show");
    await K.push(p, eY, 22, 3, 1.2, 1.1);   /* 小さな 木槌 /*F19*/
    await K.narr(p, ["§7ヨネ婆の 手に、子どもの 手に 合う 小さな 木槌。柄に すすの 跡。"], eY);
    await K.csay(p, "b04yone", ["{closed}焼け跡で 拾ったんだよぉ。……あの 朝の ことは、よう 覚えてるよぉ。"], eH);
    await K.flashback(p, { set: "fb_ashvil", label: "§7―― 十二年前　灰の 降った 冬の 朝　焼けた 鍛冶の 村", tod: "dawn", ptc: "ash",   /* 第127版: 木槌を 拾った 朝を 絵で */
      actors: { y: { nm: "§eヨネ", job: K.PJ("c7_yone", 8), at: [2.6, -1], look: [4.6, 0.6] }, m: { nm: "§7ススの 男", job: K.PJ("m6_mason", 8), at: [6, 2], look: "y" } },
      beats: [
        ["narr", "§7灰が 降りやんだ 朝。峠の 向こうの 鍛冶の 村は、黒い 柱と 灰だけに なって いた。", [5, 0, 2]],
        ["narr", "§7焼け跡の 中に、灰を かぶった 石の 人たちが 立って いた。……火は、石には 何も しなかった。", [8, 1, 1]],   /* 第128版(rev128c LOW-4): D2 村の 人は もう 石 */
        ["say", "m", "{sad,low}……だれも 残って ねえ。ゆうべ、刀を 持った 男が 一人 歩いてったって 話だ。", "y"],
        ["go", "y", [4, 0.4], 14], ["act", "y", "kneel"],
        ["narr", "§7灰の 中に、子どもの 手に 合う 小さな 木槌が 一つ。", [4.6, 0.6, 0.2]],
        ["hold", "y", "hammer"], ["act", "y", 0],
        ["say", "y", "{sad}……子どもの 槌だよぉ。持ち主は、どこへ 行ったんだろうねぇ。", "m"],
        ["say", "m", "{closed}……ラヴィの 鍛冶屋が、子を 一人 連れてったとか。", "y"],
        ["say", "y", "{closed}なら、いつか 取りに 来るよぉ。……あたしが 預かって おくよぉ。", "m"],
      ] });
    await K.csay(p, "b04yone", ["{closed}小さな 子の 槌だねぇ。……持ち主は、まだ 取りに 来ないよぉ。"], eH);
    await K.hsay(p, H4(["{sad}……ゲンさんが 拾った 子と、関係 あるのかな。"], ["{sad}……ゲンさんの 拾った 子の ものかしら。"], ["{closed}……ゲンの 拾った 子。……かもしれない。"], ["{sad}……ゲンさんの 拾われた 子の ものでしょうか。"]), eY);
    const sq = at2(K, p, 3, 1.5, 0.6);
    await K.at(p, sq, 14, 2, 0.4);   /* 灰色の 染み（記録の 断片）/*F60*/
    await K.narr(p, ["§7木槌が 包んで あった 紙きれ。字の 上に、灰色の 染みが 広がって 読めない。"], sq);
    await K.csay(p, "b04yone", ["{sad}灰の 降った 冬の ことは、だれも 口に しないよぉ。……あたしは、忘れないように 置いてるんだよぉ。"], eH);
    await K.end(p, { leave: [eY], card: "§7― 鍛冶王の 城 フォルジアへ ―" });
    return true;
  } };

/* ---------- 8話 鍛冶王の 城フォルジア（MQ9。マスター戦の あと）---------- */
const E8 = { id: "b04e8", t: "炭色の 足袋", battles: 0,
  hint: "§fヴォルカ火山帯の §6地方マスター カグラ§f に 勝とう",
  syn: "カグラは 母の 炭色の 足袋を はいて 戦った。勝負の あと、カグラは 祭りを 許した。「燃やすんじゃ なく、聞いた うえで 選ぶ」。",
  async run(p, d, K) {
    await K.open(p, "鍛冶王の 城 フォルジア", "castle");
    const eH = K.hero(p), eK = K.cast(p, "r3kagura");
    await K.at(p, eK ? eK.location : at2(K, p, 4, 0), 14, 1.6, 0.2);   /* 足もとの 足袋 */
    await K.narr(p, ["§7カグラの 足もと。炭のように 黒い 足袋。……ところどころ、焼けて 固く なって いる。"], eK);
    await K.up(p, eK, 8);
    await K.csay(p, "r3kagura", ["{closed}……母の 足袋よ。灰の 降った 祭りの 夜、舞いながら 足から 石に なった 母の。"], eH);
    await K.flashback(p, { set: "fb_firestage", label: "§7―― 十二年前　灰の 降った 冬の 火祭り", tod: "night", ptc: "ash",   /* 第127版: カグラの 母の 最後の 舞 */
      actors: { mo: { nm: "§6舞い手 カグラの 母", job: K.PJ("c7_kagmama", 8), at: [4.5, 0], look: [0, 0], hold: "fan" }, kg: { nm: "§e小さな カグラ", job: 6, at: [1.8, 1.6], look: "mo" } },
      beats: [
        ["narr", "§7十二年前、灰の 降った 冬の 火祭り。灰を 寄せつけない ため、燃える 石の 輪の 中で 舞い手が 封じの 舞を 舞って いた。", "mo"],
        ["fx", "fire", [5.5, -1.2, 0.3]], ["fx", "fire", [5.5, 1.2, 0.3]], ["act", "mo", "raise"],
        ["say", "kg", "{smile,up}かあさま、きれい……！", "mo"],
        ["fx", "spark", [4.5, 0, 0.2]], ["snd", "random.fizz", 0.7], ["act", "mo", "stagger"],
        ["narr", "§7灰が、舞い手の 足もとに 積もって いく。……それでも 舞い手は、舞を やめなかった。", "mo"],
        ["say", "mo", "{closed}……止まらないで、カグラ。火は、聞いて 選べば 怖くない。", "kg"],
        ["act", "mo", "kneel"],
        ["narr", "§7舞い手の 足は、つま先から 灰色の 石に なって いた。", "mo"],
        ["say", "kg", "{cry,tears,up}かあさま……！ かあさまの 足が……！", "mo"],
      ] });
    await K.csay(p, "r3kagura", ["{smile,up}あなたの 戦い方は、相手の 音を 聞いて から 動く。……母の 言葉を、やっと 思い出した。燃やすんじゃ なく、聞いた うえで 選ぶ。"], eH);
    await K.hsay(p, H4(["{smile,up}じゃあ、火祭り……！"], ["{smile}……火祭り、できるのね。"], ["{closed}……祭り、やれる。"], ["{smile,up}火祭り、開けるのですね！"]), eK);
    await K.csay(p, "r3kagura", ["{smile}ええ。鍛冶組合にも 伝えて。……母の 好きだった 舞を、今年は わたしが 舞う。"]);
    await K.end(p, { bye: [eK] });
    return true;
  } };

/* ---------- 9話 ラヴィの 火祭り（古い r3e5 ＋ C04 で ホムラの ひび）---------- */
const E9 = { id: "b04e9", t: "火祭り", battles: 0,
  place: PL("r3e5"),
  hint: "§fラヴィの §e広場§f で §6火祭り§f が 開かれる §7（そのあと サンドリアへ）",
  syn: "ラヴィで 火祭りが 開かれた。トンボは 初めての 刀『ホムラ』を あなたたちに 託した。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r3e5", E9))) return false;
    K.key(p, "k_fest3");
    await K.open(p, "ラヴィの 広場（火祭りの 夜）", "fest", "night");
    const eH = K.hero(p), eT = K.cast(p, "r3tombo"); K.hold(eT, "katana"); K.act(eT, "show");
    const v = K.ch(p, "c04");
    await K.push(p, eT, 22, 3, 1.2, 1.1);
    if (v === "s") {
      await K.narr(p, ["§7ホムラの 刃の 根もとに、細い ひびが 一本。……運び道の 爆破の 揺れで ひびの 入った 炉で 打った 刀だ。"], eT);
      await K.csay(p, "r3tombo", ["{sad}火事の あと 積み直した 炉に、爆破の 揺れで ひびが 入ってたッス。……ひびごと、おれの 初めての 刀ッス。", "{angry,up}いつか、ちゃんと 打ち直すッス！"], eH);
    } else {
      await K.narr(p, ["§7ホムラの 刃は まっすぐで、ひび 一つ ない。"], eT);
      await K.csay(p, "r3tombo", ["{smile,☆}ひび 一つ ないッス！ 火事の あと、親方に 教わって 積み直した 炉が、ちゃんと もって くれたッス！"], eH);
    }
    await K.end(p, { leave: [eT] });
    return true;
  } };

bkAdd("b04", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ9: 場面（b04e8）の あと、今の 段（セオの 手紙・王墓の 地図）*/
mqOver(9, async (p, d, K, c) => { if (!(await c.play("b04e8"))) return false; return c.old(); });
