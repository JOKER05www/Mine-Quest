// 第121版: 演出の 共通道具（地方マスター・常世編・魔神編・滅びた世界 で つかう）
// 場面ごとに cast(p) を 作り、人を 立たせ、動かし、最後に end() で ぜんぶ 片づける
import { world, system } from "@minecraft/server";
import { setJob, sound, ok, wait } from "./ui.js";
import { setLook, TYPE as MON_TYPE } from "./field.js";
import { groundY } from "./structures.js";
import { camAt, lookAt } from "./talk.js";
import { face, emote, tears, shockJump } from "./direct.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { PSKIN } from "./skinjobs.js";
import { HEROES } from "./saga.js";

const LIVE = (globalThis.__mqCine = globalThis.__mqCine || new Set());
export const FAST = () => !!(globalThis.__MQ_TEST && !globalThis.__TALK_LIVE);   /* 模擬テストでは 待たない */
export const pause = (t) => (FAST() ? Promise.resolve() : wait(t));
export const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
export const PJ = (k, d = 8) => (PSKIN[k] ? PSKIN[k][0] : d);
export { face, emote, tears, shockJump, lookAt, camAt };

/* ポーズ（mrpg:act）*/
export const ACT = { talk: 4, wave: 5, clap: 6, down: 8, cheer: 9, bow: 10, sad: 12, kneel: 15, point: 16, guard: 17, raise: 18, run: 19, knocked: 20, recoil: 22, hold: 23, up: 24 };
export function act(e, k, keep = true) { if (!ok(e)) return; try { const n = typeof k === "number" ? k : ACT[k] ?? 0; e.setProperty("mrpg:act", n); if (keep) e.setDynamicProperty("mrpg:act0", n); } catch {} }
/* 歩く・走る（ticks で 着く）*/
export async function go(e, to, ticks = 14, run = false) {
  if (!ok(e) || !to) return; const f = e.location;
  if (FAST()) { try { e.teleport(to); } catch {} return; }
  try { e.setProperty("mrpg:mv", true); if (run) e.setProperty("mrpg:act", ACT.run); } catch {}
  for (let k = 1; k <= ticks; k++) { if (!ok(e)) return; const t = k / ticks; try { e.teleport({ x: f.x + (to.x - f.x) * t, y: f.y + (to.y - f.y) * t, z: f.z + (to.z - f.z) * t }, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } }); } catch {} await wait(1); }
  try { e.setProperty("mrpg:mv", false); if (run) e.setProperty("mrpg:act", 0); } catch {}
}
/* 吹っ飛んで 倒れる */
export async function knock(e, from, dist = 3.5) {
  if (!ok(e) || !from) return; const l = e.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L; act(e, "knocked", false);
  for (let k = 1; k <= 8; k++) { if (!ok(e)) return; const t = k / 8; try { e.teleport({ x: l.x + ux * dist * t, y: l.y + Math.sin(t * Math.PI) * 1.4, z: l.z + uz * dist * t }, { facingLocation: from }); } catch {} if (!FAST()) await wait(1); }
  act(e, "down");
}
/* プレイヤーが 後ろへ はじかれる */
export function knockP(p, from, h = 1.0, v = 0.4) { try { const l = p.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1; cmd(p, "inputpermission set @s lateral_movement enabled"); p.applyKnockback(dx / L, dz / L, h, v); system.runTimeout(() => cmd(p, "inputpermission set @s lateral_movement disabled"), 12); } catch {} }
export function shake(p, pw = 0.5, t = 0.6) { cmd(p, `camerashake add @s ${pw} ${t} positional`); }
export function flash(p, col = "255 255 255") { cmd(p, `camera @s fade time 0.05 0.15 0.4 color ${col}`); }
export function fx(dim, id, at, n = 1, r = 0) { for (let i = 0; i < n; i++) try { dim.spawnParticle(id, { x: at.x + (Math.random() - 0.5) * r * 2, y: at.y + Math.random() * (r ? 1.6 : 0), z: at.z + (Math.random() - 0.5) * r * 2 }); } catch {} }
/* 衝撃波（中心から 輪が ひろがる）*/
export async function wave(p, at, id = "minecraft:white_smoke_particle") {
  if (!at) return;
  try { p.dimension.spawnParticle("minecraft:explosion_particle", { x: at.x, y: at.y + 0.5, z: at.z }); } catch {}
  for (let r = 1; r <= 4; r++) { for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; fx(p.dimension, id, { x: at.x + Math.cos(a) * r, y: at.y + 0.2, z: at.z + Math.sin(a) * r }); } await pause(1); }
}
/* 黒い 影が 地面を すべる */
export async function shadowFlow(p, from, to, ticks = 16, id = "minecraft:soul_particle") {
  if (!from || !to) return;
  for (let k = 0; k <= ticks; k++) { if (!ok(p)) return; const t = k / ticks; fx(p.dimension, k % 2 ? id : "minecraft:basic_smoke_particle", { x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t + 0.2, z: from.z + (to.z - from.z) * t }, 4, 0.9); if (k % 6 === 0) sound(p, "mob.wither.ambient", 0.25); await pause(1); }
}
/* 人が 粒に なって 消える（灰・光）*/
export async function fade(e, id = "minecraft:white_smoke_particle") { if (!ok(e)) return; const l = e.location; for (let k = 0; k < 4; k++) { fx(e.dimension, id, { x: l.x, y: l.y + k * 0.5, z: l.z }, 5, 0.5); await pause(2); } rmE(e); }
export function rmE(e) { if (!e) return; try { LIVE.delete(e.id); } catch {} try { if (ok(e)) e.remove(); } catch {} }

/* ヒロイン（旅の 仲間）*/
export function heroOf(p) { try { const d = load(p), k = d && qs(d).hero; const h = (HEROES || []).find((x) => x[0] === k); return h ? { key: h[0], name: h[1] } : null; } catch { return null; } }

/* プレイヤーの 向きを 基準に した 位置（dist 前へ・side 右へ）*/
export function spot(p, dist = 3.5, side = 0, dy = 0) {
  try {
    const yaw = (p.getRotation().y * Math.PI) / 180, l = p.location, fx0 = -Math.sin(yaw), fz0 = Math.cos(yaw), rx = -fz0, rz = fx0;
    const q = { x: l.x + fx0 * dist + rx * side, y: l.y + dy, z: l.z + fz0 * dist + rz * side };
    if (!dy) { const gy = groundY(p.dimension, q.x, q.z, Math.floor(l.y)); if (typeof gy === "number" && Math.abs(gy - l.y) <= 3) q.y = gy; }
    return q;
  } catch { return null; }
}
const eye = (p) => { try { const l = p.location; return { x: l.x, y: l.y + 1.5, z: l.z }; } catch { return null; } };

/* 1つの 場面の 出演者。end() で ぜんぶ 消す（ぬけても 海辺の 片づけ mrpg_cine で 消える）*/
export function cast(p) {
  const list = [], kept = [];
  const C = {
    list,
    npc(name, job, dist = 3.5, side = 0, dy = 0) {
      const q = spot(p, dist, side, dy); if (!q) return null;
      try {
        const e = p.dimension.spawnEntity("mrpg:npc", q); LIVE.add(e.id); list.push(e);
        try { setJob(e, job); } catch {}
        e.addTag("mrpg_npc"); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); e.nameTag = name;
        try { e.teleport(q, { facingLocation: eye(p) }); } catch {}
        return e;
      } catch { return null; }
    },
    mon(sid, dist = 4, side = 0, dy = 0) {
      const q = spot(p, dist, side, dy); if (!q) return null;
      try { const e = p.dimension.spawnEntity(MON_TYPE, q); LIVE.add(e.id); list.push(e); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); try { setLook(e, sid); } catch {} try { e.teleport(q, { facingLocation: eye(p) }); } catch {} return e; } catch { return null; }
    },
    /* ヒロインを 横に 立たせる（えらんで いなければ null）*/
    hero(dist = 1.8, side = -1.6) { const h = heroOf(p); if (!h) return null; const e = C.npc(`§d${h.name}`, PJ(h.key, 9), dist, side); if (e) C.hn = h.name; return e; },
    /* もとから いる 人（城の マスター など）。最後に ポーズを もどす */
    keep(e) { if (ok(e)) { let a0 = 0; try { a0 = e.getDynamicProperty("mrpg:act0"); } catch {} kept.push([e, typeof a0 === "number" ? a0 : 0, e.nameTag, { ...e.location }]); } return e; },
    end() {
      for (const e of list) rmE(e); list.length = 0;
      for (const [e, a0, nm, at] of kept) if (ok(e)) try { e.teleport(at); e.setProperty("mrpg:act", a0); e.setDynamicProperty("mrpg:act0", a0); e.setProperty("mrpg:face", 0); e.nameTag = nm; } catch {}
      try { for (const e of p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_autospk"] })) if (e.getDynamicProperty("mrpg:spkOwner") === p.id) e.remove(); } catch {}
      cmd(p, "camera @s clear"); cmd(p, "inputpermission set @s lateral_movement enabled");
    },
  };
  return C;
}
/* 出演者つきで 場面を 走らせる（途中で 落ちても 必ず 片づける）*/
export async function scene(p, fn) { const C = cast(p); try { return await fn(C); } finally { C.end(); } }
/* 近くの 決まった 人（タグ）をさがす */
export function near(p, tag, r = 16) { try { return p.dimension.getEntities({ type: "mrpg:npc", tags: [tag], location: p.location, maxDistance: r }).find((e) => ok(e)) || null; } catch { return null; } }
/* 2人の あいだを 横から（会話の 外の 動きを 見せる）*/
export function side(p, e, k = 6) {
  try { const P = p.location, S = e.location, m = { x: (P.x + S.x) / 2, y: (P.y + S.y) / 2 + 1.2, z: (P.z + S.z) / 2 }, dx = S.x - P.x, dz = S.z - P.z, L = Math.hypot(dx, dz) || 1; return camAt(p, { x: m.x - (dz / L) * k, y: m.y + 1.5, z: m.z + (dx / L) * k }, m) || camAt(p, { x: m.x + (dz / L) * k, y: m.y + 1.5, z: m.z - (dx / L) * k }, m); } catch { return false; }
}
/* 下から 見上げる（高い 所の もの）*/
export function lookUp(p, at) { try { const l = p.location; return camAt(p, { x: l.x, y: l.y + 0.6, z: l.z }, at); } catch { return false; } }
