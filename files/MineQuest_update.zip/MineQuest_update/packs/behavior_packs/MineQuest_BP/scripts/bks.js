/* 第126版: 本の 章 35本を 読みこむ（しくみは bkeng.js・choice.js。章ファイルは bk_b01〜b20・bk_u01〜u15。ここは さわらなくて よい）*/
import "./bkeng.js";
import "./bk_b01.js"; import "./bk_b02.js"; import "./bk_b03.js"; import "./bk_b04.js"; import "./bk_b05.js";
import "./bk_b06.js"; import "./bk_b07.js"; import "./bk_b08.js"; import "./bk_b09.js"; import "./bk_b10.js";
import "./bk_b11.js"; import "./bk_b12.js"; import "./bk_b13.js"; import "./bk_b14.js"; import "./bk_b15.js";
import "./bk_b16.js"; import "./bk_b17.js"; import "./bk_b18.js"; import "./bk_b19.js"; import "./bk_b20.js";
import "./bk_u01.js"; import "./bk_u02.js"; import "./bk_u03.js"; import "./bk_u04.js"; import "./bk_u05.js";
import "./bk_u06.js"; import "./bk_u07.js"; import "./bk_u08.js"; import "./bk_u09.js"; import "./bk_u10.js";
import "./bk_u11.js"; import "./bk_u12.js"; import "./bk_u13.js"; import "./bk_u14.js"; import "./bk_u15.js";
import "./facsets.js";   /* 第127版(fac2): 物語の 施設の 作り直し（章の 形を 登録した あと）*/
