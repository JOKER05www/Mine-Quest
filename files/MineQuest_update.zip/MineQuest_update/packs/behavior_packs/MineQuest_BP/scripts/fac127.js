/* 第127版(fac): 地形の 片づけ（1回だけ。軽く: 10tick に 1回・1回に 少しずつ）
   1) 火山の 町・城下の「光る 葉の かたまり」（木の 葉が shroomlight だった）を 消す。街灯（柵の 上）と 天井の 灯り（1つだけの もの）は 残す
   2) 町・城・物語の 施設の そばに できた 石の 観客席の 輪（遺跡の コロシアム）を 片づける。人の 建てた 物（板・ガラス・羊毛・作業台 など）が あれば さわらない */
import { world, system } from "@minecraft/server";
import { TOWNS, getTown, townPos, castleInfo, castleSpot, siteOf, getRuin, setRuin } from "./structures.js";
import { WREGIONS } from "./worldmap.js";
import { busy } from "./ui.js";

const OW = () => world.getDimension("minecraft:overworld");
const J = (k, d) => { try { const v = world.getDynamicProperty(k); return typeof v === "string" ? JSON.parse(v) : d; } catch { return d; } };
const P_ = (k, v) => { try { world.setDynamicProperty(k, v === undefined ? undefined : JSON.stringify(v)); } catch {} };
const id = (b) => (b ? String(b.typeId).replace("minecraft:", "") : "");
const blk = (d, x, y, z) => { try { return d.getBlock({ x, y, z }) || null; } catch { return null; } };

/* ---------- 1) 火山の 町の 光る 葉 ---------- */
const VK = "mrpg:fx127:volc";
let JOB = null;
function volcTargets() {
  const L = [];
  for (const t of TOWNS) if (t.style === "volcano") { const q = getTown(t.id); if (q && q.built && Number.isFinite(q.y)) L.push({ k: t.id, x: Math.floor(q.x), y: Math.floor(q.y), z: Math.floor(q.z), R: 48 }); }
  for (let i = 0; i < WREGIONS.length; i++) if (WREGIONS[i].style === "volcano") { const c = castleInfo(i); if (c && c.built && Number.isFinite(c.y)) L.push({ k: `c${i}`, x: Math.floor(c.x), y: Math.floor(c.y), z: Math.floor(c.z), R: 76 }); }
  return L;
}
function volcStep(ps) {
  const dim = OW();
  if (!JOB) {
    const done = J(VK, []);
    for (const T of volcTargets()) { if (done.includes(T.k)) continue; if (!ps.some((p) => p.dimension.id === "minecraft:overworld" && Math.hypot(p.location.x - T.x, p.location.z - T.z) < T.R + 40)) continue; const sv = J(VK + "i", null), go = sv && sv.k === T.k; JOB = { T, i: go ? sv.i : 0, rm: go && Array.isArray(sv.rm) ? sv.rm : [], n: (2 * T.R + 1) ** 2 }; break; }   /* 第128版(L5): 前に 読みこみが 切れた ときは 続きから */
    if (!JOB) return;
  }
  const { T } = JOB, W = 2 * T.R + 1;
  if (!blk(dim, T.x, T.y, T.z)) { P_(VK + "i", { k: T.k, i: JOB.i, rm: JOB.rm.slice(0, 2000) }); JOB = null; return; }   /* 読みこまれて いない: あとで 続きから（第128版(L5): 進みを 覚える）*/
  if (JOB.i < JOB.n) {
    for (let k = 0; k < 40 && JOB.i < JOB.n; k++, JOB.i++) {
      const x = T.x - T.R + (JOB.i % W), z = T.z - T.R + Math.floor(JOB.i / W);
      for (let y = T.y - 4; y <= T.y + 24; y++) {
        const b = blk(dim, x, y, z); if (!b || id(b) !== "shroomlight") continue;
        if (/fence|wall/.test(id(blk(dim, x, y - 1, z)))) continue;   /* 街灯 */
        let n = 0; for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0], [0, -1, 0]]) if (id(blk(dim, x + dx, y + dy, z + dz)) === "shroomlight") n++;
        if (n >= 1) JOB.rm.push([x, y, z]);   /* となりも 光る 葉 = 木の かたまり（天井の 灯りは 1つだけ）*/
      }
    }
    return;
  }
  for (let k = 0; k < 120 && JOB.rm.length; k++) { const [x, y, z] = JOB.rm.pop(); try { dim.runCommand(`setblock ${x} ${y} ${z} air`); } catch {} }
  if (!JOB.rm.length) { const done = J(VK, []); if (!done.includes(T.k)) done.push(T.k); P_(VK, done); P_(VK + "i", undefined); JOB = null; }
}

/* ---------- 2) 町の そばの コロシアム ---------- */
const LAYOUTS = ["ruin", "tower", "pyramid", "temple", "crypt", "colosseum", "shrine", "sky"];
function hashStr(k) { let h = 2166136261; for (let i = 0; i < k.length; i++) { h ^= k.charCodeAt(i); h = Math.imul(h, 16777619); } return Math.abs(h); }
const FOREIGN = /planks|glass|wool|crafting_table|furnace|smoker|_bed$|door|fence|slab|stairs|concrete|carpet|bookshelf|barrel|hopper|rail|redstone|piston|sign|banner|flower_pot|anvil|bell|scaffolding|ladder|campfire|bricks_slab|composter|loom|lectern|cartography|smithing|grindstone|stonecutter|shulker|ender_chest|bamboo_block|_wood$/;
function nearStory(x, z) {
  for (const t of TOWNS) { const q = getTown(t.id) || townPos(t); if (q && Math.hypot(q.x - x, q.z - z) < 150) return true; }
  for (let i = 0; i < WREGIONS.length; i++) { const c = castleInfo(i) || castleSpot(i); if (c && Math.hypot(c.x - x, c.z - z) < 150) return true; }
  for (const v of Object.values(J("mrpg:osite", {}) || {})) if (v && Math.hypot(v.x - x, v.z - z) < 90) return true;
  return false;
}
let CT = 0;
function colStep(ps) {
  if (++CT % 10) return;   /* 100tick に 1回 */
  const dim = OW();
  for (const p of ps) {
    if (p.dimension.id !== "minecraft:overworld" || busy.has(p.id)) continue;
    const rx0 = Math.floor(p.location.x / 176), rz0 = Math.floor(p.location.z / 176);
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) {
      const s = siteOf("minecraft:overworld", rx0 + a, rz0 + b);
      if (Math.hypot(s.x - p.location.x, s.z - p.location.z) > 70) continue;
      const r = getRuin(s.key); if (!r || !r.built || r.skip || r.keep || !Number.isFinite(r.y)) continue;
      if (LAYOUTS[Math.floor(hashStr(s.key) / 7) % LAYOUTS.length] !== "colosseum" || !nearStory(r.x, r.z)) continue;
      if (ps.some((q) => busy.has(q.id) && Math.hypot(q.location.x - r.x, q.location.z - r.z) < 40)) continue;   /* 遺跡の ボスと 戦って いる 人が いる */
      const X = Math.floor(r.x), Y = Math.floor(r.y), Z = Math.floor(r.z);
      if (!blk(dim, X - 18, Y, Z - 18) || !blk(dim, X + 18, Y, Z + 18)) continue;
      let foreign = false;
      for (let dx = -18; dx <= 18 && !foreign; dx += 3) for (let dz = -18; dz <= 18 && !foreign; dz += 3) for (let dy = 0; dy <= 10; dy += 2) if (FOREIGN.test(id(blk(dim, X + dx, Y + dy, Z + dz)))) { foreign = true; break; }
      if (foreign) { setRuin(s.key, { ...r, keep: 1 }); continue; }   /* 人の 建てた 物が ある: さわらない */
      const g = /^(sand|red_sand|sandstone|.*terracotta|hardened_clay)$/.test(id(blk(dim, X + 22, Y - 1, Z))) ? "sand" : /snow/.test(id(blk(dim, X + 22, Y - 1, Z))) ? "snow" : "grass_block";
      try { dim.runCommand(`fill ${X - 18} ${Y} ${Z - 18} ${X + 18} ${Y + 12} ${Z + 18} air`); dim.runCommand(`fill ${X - 17} ${Y - 1} ${Z - 17} ${X + 17} ${Y - 1} ${Z + 17} ${g}`); } catch { continue; }
      try { for (const e of dim.getEntities({ tags: ["mrpg_boss"], location: { x: X, y: Y, z: Z }, maxDistance: 30 })) if (!e.hasTag("mrpg_raid")) e.remove(); } catch {}
      setRuin(s.key, { ...r, skip: true, gone: 127 });
      return;
    }
  }
}

/* ---------- 3) 第128版(H1): 前の 本1 が ルミナの 通りに 積んだ 3段の 石の 客席（闘技場は 町の 外の 1か所に なった）を 1回だけ 片づける ---------- */
const SK = "mrpg:fx128:stand"; let SJ = null, SC = 0;
function standStep(ps) {
  if (!SJ) {
    if (++SC % 10) return;   /* 100tick に 1回 見る */
    let on = false; try { on = !!world.getDynamicProperty("mrpg:epdeco:b01stand") && !world.getDynamicProperty(SK); } catch {} if (!on) return;
    const t = TOWNS.find((u) => u.id === "t0"), g = getTown("t0"), c = g && g.built ? g : t ? townPos(t) : null; if (!c || !Number.isFinite(c.y)) return;
    const X = Math.floor(c.x) + 25, Z = Math.floor(c.z) + 5;   /* 前の 本1 の「闘技場の 前」*/
    if (!ps.some((p) => p.dimension.id === "minecraft:overworld" && Math.hypot(p.location.x - X, p.location.z - Z) < 40)) return;
    let sy = null; try { const v = world.getDynamicProperty("mrpg:b01standY"); if (typeof v === "number") sy = v; } catch {}
    SJ = { X, Z, ys: sy !== null ? [sy] : [Math.floor(c.y) - 1, Math.floor(c.y), Math.floor(c.y) + 1], i: 0, H: new Map() };
  }
  const dim = OW(), R = 16, W = 2 * R + 1;
  if (!blk(dim, SJ.X, SJ.ys[0], SJ.Z)) { SJ = null; return; }   /* 読みこまれて いない: あとで */
  for (let k = 0; k < W && SJ.i < W * W; k++, SJ.i++) {   /* 1回に 1列（33 本の 柱を 見る）*/
    const x = SJ.X - R + (SJ.i % W), z = SJ.Z - R + Math.floor(SJ.i / W);
    for (const y of SJ.ys) { let h = 0; while (h < 3 && id(blk(dim, x, y + h, z)) === "stone_bricks") h++; if (h && id(blk(dim, x, y + h, z)) === "air") { SJ.H.set(`${x},${z}`, { h, y }); break; } }
  }
  if (SJ.i < W * W) return;
  /* 1〜3 段の 石の 柱の かたまり（段が 1・2・3 とも 3 本 以上・8 マスの 中・9〜30 本）だけ 消す。家の 壁（上も 石）・低い 塀だけ の 所は さわらない */
  const seen = new Set();
  for (const k0 of SJ.H.keys()) {
    if (seen.has(k0)) continue; const comp = [], st = [k0]; seen.add(k0);
    while (st.length) { const k = st.pop(); comp.push(k); const [x, z] = k.split(",").map(Number); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = `${x + dx},${z + dz}`; if (SJ.H.has(n) && !seen.has(n)) { seen.add(n); st.push(n); } } }
    const cnt = [0, 0, 0, 0]; let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9; for (const k of comp) { const [x, z] = k.split(",").map(Number); cnt[SJ.H.get(k).h]++; x0 = Math.min(x0, x); x1 = Math.max(x1, x); z0 = Math.min(z0, z); z1 = Math.max(z1, z); }
    if (comp.length < 9 || comp.length > 30 || cnt[1] < 3 || cnt[2] < 3 || cnt[3] < 3 || x1 - x0 > 7 || z1 - z0 > 7) continue;
    for (const k of comp) { const [x, z] = k.split(",").map(Number), q = SJ.H.get(k); try { dim.runCommand(`fill ${x} ${q.y} ${z} ${x} ${q.y + q.h - 1} ${z} air`); } catch {} }
  }
  try { world.setDynamicProperty(SK, 1); } catch {} SJ = null;
}

system.runInterval(() => {
  let ps = []; try { ps = world.getAllPlayers(); } catch {} if (!ps.length) return;
  try { volcStep(ps); } catch {}
  try { colStep(ps); } catch {}
  try { standStep(ps); } catch {}
}, 10);
export const __fx127 = { volcTargets, hashStr, nearStory, job: () => JOB };
