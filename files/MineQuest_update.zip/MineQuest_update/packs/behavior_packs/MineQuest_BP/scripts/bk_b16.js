/* 第126版 本16「風の塔」（セレスティア天空郷・ゼファー／ステラ）— 作業 MD
   1 町じゅうに 声（耳を ふさぐ 人・欲しがった 者の 目にだけ 紫の 文字）→ 2 風の 塔（カザミ翁・二十年 開かない 箱が 相棒の 前で 開く・紐と 封の 手紙 → 選択 C16）
   → 3 塔の 星見の 間（遠めがねは コラリアの 方角に 固められて いる・ステラの 星図）→ 4 雲の 島へ 渡る 道（ドンゴと チョロ・インクの 小瓶）
   → 5 鐘楼への 階段（影の 残りかす）→ 6 鐘楼（鐘に 紫の 文字。止めると 声が 止まる。影は 雲の 島の 向こうへ）→ 7 町の 人の 目の 文字が 消え、フウタが 起きる
   → 8 ゼファーの 宿（夜。手帳の 最後の 頁は 白紙）
   今日の 仕事を 引きとる: 風の 塔の 星見の 間（epfac windroom・mrpg:epdeco:r10room）、レンズの ない 遠めがね（r10glass）、星図、鐘の 縁の「帰らぬ 者の 名は、三度 呼べ」。
   古い 話: r10c1→b16e1・r10e1→b16e2・r10e2→b16e3・r10e3→b16e4（EP_OFF は bkAdd）*/
import { bkAdd } from "./bkeng.js";
import { castAdd, doomKnown } from "./cast.js";
import { bldOf, placeOf } from "./storyplace.js";
import { TOWNS, getTown, townPos } from "./structures.js";
import { world } from "@minecraft/server";
import { ok } from "./ui.js";
import { WREGIONS } from "./worldmap.js";
import { ZEPH_OUT } from "./collapse.js";

/* ---------- 場所 ---------- */
const zeph = () => { const t = TOWNS.find((u) => u.id === "t55"); if (!t) return null; const g = getTown("t55"); return g && g.built ? { x: g.x, y: g.y, z: g.z } : townPos(t); };
const TOWN = () => bldOf("t55", ["plaza", "inn"], "かぜの 塔の 町 ゼファー（広場）") || (() => { const o = ZEPH_OUT(); return o ? { ...o, nm: "かぜの 塔の 町 ゼファー" } : null; })();
const INN = () => bldOf("t55", ["inn"], "ゼファーの 宿") || TOWN();
const ISLE_ROAD = () => { const a = zeph(), b = placeOf("stage", 10); if (!a || !b) { const o = ZEPH_OUT(); return o ? { ...o, nm: "雲の 島へ 渡る 道" } : null; } return { x: Math.floor(a.x + (b.x - a.x) * 0.55), z: Math.floor(a.z + (b.z - a.z) * 0.55), nm: "雲の 島へ 渡る 道" }; };
const RAW = (k) => { try { return JSON.parse(world.getDynamicProperty(`mrpg:epdeco:${k}at`) || "null"); } catch { return null; } };
const LW = (v, a, b, h = 0) => ({ x: v.o[0] + a * v.f[0] - b * v.f[1] + 0.5, y: v.o[1] + h, z: v.o[2] + a * v.f[1] + b * v.f[0] + 0.5 });
const MK = (v, n) => { const m = v && v.m && v.m[n]; return m ? { x: m[0], y: m[1], z: m[2] } : null; };
const DOOR = () => { const v = RAW("r10room"); if (!v || !Array.isArray(v.o)) { const o = ZEPH_OUT(); return o ? { ...o, nm: "風の 塔の 戸口" } : null; } const q = LW(v, -4, 0); return { x: Math.floor(q.x), z: Math.floor(q.z), nm: "風の 塔の 戸口" }; };
const ROOMP = (nm) => () => { const q = DOOR(); return q ? { ...q, nm } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
/* 風の 塔の 星見の 間（ワールドに 1回）。上に 塔の 柱と 鐘 */
function room(K, p, build = true) {
  let v = RAW("r10room"); if (!v && build) { K.fac(p, "r10room", "windroom", 10, Y(K, p)); v = RAW("r10room"); }
  return v && Array.isArray(v.o) && Math.hypot(v.x - p.location.x, v.z - p.location.z) < 72 ? v : null;
}
/* レンズの ない 遠めがね: 窓ぎわに、コラリア（マリノア）の 方角へ 固める（ワールドに 1回）*/
function seaGlass(K, p, v) {
  const k = "mrpg:epdeco:r10glass"; let g = null; try { g = JSON.parse(world.getDynamicProperty(k) || "null"); } catch {} if (g && typeof g.x === "number") return g;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  const R = WREGIONS[6], c = LW(v, 4, 0), sx = R ? s0.x + R.c[0] - c.x : 1, sz = R ? s0.z + R.c[1] - c.z : 0, fx = v.f[0], fz = v.f[1];
  const da = sx * fx + sz * fz, db = -sx * fz + sz * fx, [ua, ub] = Math.abs(db) >= Math.abs(da) ? [0, Math.sign(db) || 1] : [Math.sign(da) || 1, 0];
  const q = LW(v, 4 + ua * 2, ub * 2), wx = ua * fx - ub * fz, wz = ua * fz + ub * fx, fd = wx > 0 ? 5 : wx < 0 ? 4 : wz > 0 ? 3 : 2, X = Math.floor(q.x), Z = Math.floor(q.z);
  K.cmd(p, `setblock ${X} ${v.o[1]} ${Z} birch_fence`); K.cmd(p, `setblock ${X} ${v.o[1] + 1} ${Z} lightning_rod ["facing_direction"=${fd}]`);
  g = { x: X + 0.5, y: v.o[1] + 1.2, z: Z + 0.5, wx, wz }; try { world.setDynamicProperty(k, JSON.stringify(g)); } catch {}
  return g;
}
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };
const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
const FUTA_NM = "§7眠る フウタ";
const futaAt = (K, p, R) => (R ? LW(R, -1.5, -3.5) : K.fwd(p, 5, -2.5));
const BELLQ = (K, p, R) => (R && MK(R, "bell")) || K.fwd(p, 6, 0, 12);
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };

/* ---------- 町の 人の その後 ---------- */
const st = (s) => s.epx || {};
castAdd("kazami", { nm: "カザミ翁", role: "塔守", gobi: "じゃて", skin: "m6_sage", town: "t55", from: "r10e1",
  at: () => { const o = ZEPH_OUT(); return o ? { x: o.x + 10, z: o.z - 4 } : null; },
  pre: ["{smile}風の 町 ゼファーへ よう 来なすったんじゃて。"],
  after: [
    [(s) => !!s.ending, ["{smile}塔の 遠めがねに、レンズを 入れたんじゃて。……海が、ちゃんと 見えたわい。", "{closed}あの 男の 箱は、届くべき 人に 届いたかのう。"]],
    [(s) => !!st(s).bell16, ["{smile}フウタは 起きた 朝から、毎朝 わしの 名を 三度 呼びよる。……逆じゃて、ほっほ。", "{closed}鐘は もう 声を 出さん。……風の 音だけじゃ。"]],
    [(s) => doomKnown(s), ["{sad}……塔の 鐘が、人の 声で しゃべりよる。耳を ふさいでも 聞こえるんじゃて。"]],
    [() => true, ["{smile}この 塔は、二十年前に ひとりの 旅人が 建てたんじゃて。"]],
  ] });
castAdd("futa", { nm: "フウタ", role: "塔守の 孫", gobi: "", skin: "m6_sota", town: "t55", from: "r10e1",
  at: () => { const o = ZEPH_OUT(); return o ? { x: o.x + 8, z: o.z - 2 } : null; },
  pre: ["……すう……すう……"], hide: (s) => !st(s).bell16,
  after: [
    [(s) => !!st(s).bell16, ["{smile,up}三回も 呼ばんでも、聞こえとったよ。……でも、三回で よかった。", "{smile}一回目で 夢の 中の 風車が 回って、二回目で 道が 見えて、三回目で じいちゃんの 声に なったんじゃ。"]],
    [() => true, ["……すう……"]],
  ] });

/* ---------- 1話 町じゅうに 声 ---------- */
const E1 = { id: "b16e1", t: "空の 声", snd: "item.book.page_turn", place: TOWN,
  hint: "§fセレスティア天空郷の §eかぜの 塔の 町 ゼファー§f へ 行こう §7（石板で ラグナの 主を 封じると 北の 道が 開く。右上の 案内）",
  syn: "ゼファーの 町じゅうに、セオの 声が 降って いた。耳を ふさいで うずくまる 人。何人かの 目には、紫の 文字が 流れて いた。……知りたいと 願った ことの ある 人だけ。影の 声が 世界を つないだ 一瞬、遠くの 町の 人たちも 見えた。",
  set: { voice: 1 }, battles: 0,
  skip: (s) => { s.epx = { ...(s.epx || {}), voice: 1 }; },
  async run(p, d, K) {
    await K.open(p, "かぜの 塔の 町 ゼファー", "ash");
    K.mood(p, "shadow"); K.sound(p, "ambient.weather.thunder", 0.5);
    const eR = REI(K, p); K.act(eR, "hold");
    const S = K.S(p), sky = S ? S.at(4, 0, 14) : K.fwd(p, 6, 0, 14);
    await K.at(p, sky, 16, 10, 0);
    K.big(p, "§5§l声", "§f町じゅうに、静かな 声が 降って いる", "mob.wither.ambient");
    await K.say(p, "セオの 声", ["{closed,low}……記録を、読み上げる。『影の 鍵は 五本と、六つ目。千年前の 影から――』"]);
    const eA = K.npcNear(p, "§f粉ひきの ミサ", K.PJ("hanna", 8)), eB = K.npcNear(p, "§f大工の ゴロ", K.PJ("m6_genzo", 8));
    K.act(eA, "kneel"); K.act(eB, "kneel");
    await K.two(p, eA, eB, 10);
    await K.say(p, "粉ひきの ミサ", ["{cry,!,up}……やめて、知りたく ない……！ 頭の 中に、入って こないで……！"], eB);
    if (ok(eB)) { K.burst(p.dimension, { x: eB.location.x, y: eB.location.y + 1.7, z: eB.location.z }, "minecraft:portal_reverse_particle", 6, 0.2, 0); await K.up(p, eB, 10); }
    await K.narr(p, ["§7大工の 男の 目に、紫の 小さな 文字が 流れて いる。……粉ひきの 女の 目には、何も ない。"], eB);
    await K.say(p, "大工の ゴロ", ["{sad,low}……若い ころ、空の 向こうが 知りたいと、毎晩 塔に 祈った……。……その 声が、返事を して くる……"], eR);   /*（決まり二 強）*/
    K.act(eR, "guard");
    await K.say(p, "レイ", ["{angry,up}……ソラの 竜と 同じだ。知りたいと 思った ことの ある やつだけ、字が 入って いく。", "{closed}セオの 声を 使った、影だ。……出どころは、どこだ。"], eA);
    /* 世界の 今（影の 声が 世界を つないだ 一瞬）*/
    await K.offstage(p, async (V, C) => {   /* 第127版: そのころ（主人公の いない 町。あなた・仲間は 映さない）*/
      const { eG, eM, eK } = C; K.act(eG, "guard"); K.act(eM, "hold"); K.act(eK, "sad");
      await K.two(p, eG, eM, 8);
      await K.say(p, "ゴンザ", ["{angry,up}門は 閉めぬでござる！ 逃げて くる 人が いるかぎり、拙者は ここに 立つでござる！"], eM);
      await K.up(p, eK, 8);
      await K.say(p, "逃げて きた 子", ["{cry,tears,up}……空から、声が するの。おうちに 帰れって……。"], eM);
      await K.say(p, "ミミ", ["{smile,tears,up}パン、まだ あるよっ！ 泣いてる 子から 先に 取ってっ……だよっ！"], eK);
      if (ok(eM) && ok(eK)) { await K.approach(p, eM, eK, 1.3); await K.give(eM, eK, "basket"); }
      await K.say(p, "ゴンザ", ["{closed}……声には 答えるな。ここに いる 者の 名を 呼べ。……それで 足りるでござる。"], eK);
    }, { card: "§7―― そのころ　ルミナの 門", cast: (V) => ({ eG: V.actor("§e門番 ゴンザ", K.PJ("m6_takeru", 8), [3.5, -1.2], V.at(3.5, 1)), eM: V.actor("§eパン屋の ミミ", K.PJ("mimi", 8), [3.5, 1.2], V.at(3.5, -1)), eK: V.actor("§7逃げて きた 子", 6, [5.2, 0.4], V.at(3.5, 0)) }) });
    await K.offstage(p, async (V, C) => {
      const { eY, eW } = C; K.act(eY, "kneel");
      await K.up(p, eY, 8);
      await K.say(p, "ユラ", ["{sad}……ミナ。……ミナ。……ミナ。", "{closed}石に なった 人の 名前を、一人ずつ 呼んで いる ところ なのです。……三度ずつ。"], eW);
      await K.say(p, "墓地の 老人", ["{sad,up}……ユラさんや。空の 声は、名前を 呼ぶと 小さく なるのう。"], eY);
      await K.say(p, "ユラ", ["{smile,tears}……はい。だから、やめないのです。"], eW);
    }, { card: "§7―― そのころ　ソウラ", cast: (V) => ({ eY: V.actor("§e墓守の ユラ", K.PJ("sakura", 8), [3.4, 0], V.at(5, 0)), eW: V.actor("§7墓地の 老人", K.PJ("m6_gramps", 8), [3.2, 2.1], V.at(3.4, 0)) }) });
    await K.narr(p, ["§7……どこの 町も、灯りは 消えて いなかった。"], eR);
    const g = K.palEnt(p); if (g) await K.up(p, g, 10);
    await K.pal(p, ["……あの こえ、ないてる。……うえの ほう。かぜの でる ところ。"]);
    K.rmCine(g);
    await K.say(p, "レイ", ["{shock,…,up}……風の 出る 所……。この 町の 外れの 塔か。"], eA);
    K.pay(p, E1, 2000, [["dm_ink", 2]]);
    await K.end(p, { leave: [eR, eA, eB], card: "§7→ 町の 外れの §e風の 塔§7 へ（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 2話 風の 塔（カザミ翁・箱・選択 C16）---------- */
const LETTER_R = ["§f『下の 娘に、名を つけて やれなかった。", "§fつけるなら、星の 名では なく、海の 名を。……あの 子は、海の 子だ』", "§8……父より"];
const E2 = { id: "b16e2", t: "開かない 箱", place: () => DOOR(), fac: "r10room",
  hint: "§fゼファーの 外れの §e風の 塔の 戸口§f へ §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "風の 塔の 塔守 カザミ翁。「星を 見る 男が 塔を 建てた。二十年、開かない 箱を 預かった」。塔の 戸口で 眠る 孫の フウタの 名を、町の 人と 三度 呼んだ。……鐘の 縁に 刻んだ 男の 決まり。箱は 相棒の 前で 開いた。中に、ナギサの 紐と 同じ 結び方の 紐と、「六つ目へ。娘たちに 渡して くれ」と 書いた 封の ある 手紙。",
  F: ["F10", "F33"], keys: ["k_cord", "k_letter"], set: { met10: 1 }, battles: 0,
  async run(p, d, K) {
    const R = room(K, p);
    await K.open(p, R ? "風の 塔（星見の 間）" : "風の 塔の 下", "ash");
    const BELL = BELLQ(K, p, R), IN = R ? MK(R, "in") : K.fwd(p, 3, 1.5), DESK = R ? MK(R, "desk") : K.fwd(p, 4, 0);
    await K.at(p, BELL, 18, 9, 0);
    await K.narr(p, ["§7石の 塔が、灰の 空に 細く 立って いる。てっぺんの 鐘から、あの 声が 降って くる。"], BELL);
    const eR = REI(K, p);
    const eK = K.cast(p, "kazami"); K.act(eK, "hold");
    await K.csay(p, "kazami", ["{sad}……旅の 人かね。こんな 空の 日に、よう 来なすったんじゃて。", "{closed}わしは カザミ。この 塔の 番を して おる じじいじゃて。"], eR);
    await K.say(p, "レイ", ["{?}……塔の 番？ 町の 塔じゃ ないのか。"], eK);
    K.act(eK, "point");
    await K.csay(p, "kazami", ["{closed}星を 見る 男が、二十年前に 建てた 塔じゃて。背の 高い、無口な 男じゃった。", "{sad}どこの 王さまに 会いに 行っても 門前払いじゃったと、一度 だけ 笑うて おった。"], eR);   /*F33 強: 王たちに 信じて もらえなかった 男 */
    K.act(eK, 0);
    /* 眠る 孫と、三度 */
    const eF = await K.put(p, FUTA_NM, futaAt(K, p, R), R ? MK(R, "door") : null, K.PJ("m6_sota", 9)); K.act(eF, "down");
    if (ok(eK) && ok(eF)) { await K.walkCam(p, eK, nearPt(eK, eF, 1.2), 16); K.act(eK, "kneel"); }
    await K.at(p, eF ? eF.location : K.fwd(p, 4), 12, 3, 0.8);
    await K.csay(p, "kazami", ["{sad,up}……孫の フウタじゃて。声が 降った 朝から、目を 覚まさん。", "{closed}あの 子は、塔の 上の 星の 話が 大好きでのう……。知りたがりじゃった。"], eF);
    const eW = K.npcNear(p, "§f粉ひきの ミサ", K.PJ("hanna", 8));
    if (ok(eW) && ok(eF)) await K.go(eW, nearPt(eW, eF, 1.8), 20);
    await K.say(p, "粉ひきの ミサ", ["{sad,up}……フウタ。"], eF);
    await K.say(p, "レイ", ["{sad,up}……フウタ。"], eF);
    await K.csay(p, "kazami", ["{closed,up}……フウタや。"], eF);
    await K.narr(p, ["§7三度。……眠る 子は、答えなかった。"], eF);
    K.sound(p, "block.bell.hit", 0.25);
    await K.at(p, BELL, 16, 3.5, 0.3);
    await K.narr(p, ["§7鐘の 縁に、細い 字が 刻まれて いる。", "§f『帰らぬ 者の 名は、三度 呼べ。呼ばれる 名は、迷わない』"], BELL);
    await K.csay(p, "kazami", ["{closed}……塔の 男が 残して いった 決まりじゃて。届かん 日も、呼ぶんじゃ。……呼ぶのを やめたら、ほんとうに いなく なって しまうでな。"], eR);
    /* 箱 */
    K.hold(eK, "box"); K.act(eK, "hold");
    if (R && ok(eK)) await K.walkCam(p, eK, DESK, 16);
    await K.csay(p, "kazami", ["{closed}……あの 男が 去る 前に 預けて いった 箱じゃて。鍵穴も、ふたの すき間も ない。", "{sad}二十年、だれが 何を しても 開かなんだ。……あんたらには、見せようと 思う。"], eR);
    const g = K.palEnt(p);
    if (g && ok(eK)) { await K.go(g, nearPt(g, eK, 1.1), 12); await K.up(p, g, 12); }
    await K.narr(p, ["§7相棒が 鼻を ひくひく させて、箱に 顔を 寄せた。……蔵の 石板と、同じ におい。"], g || eK);
    K.sound(p, "random.chestopen", 1); K.flash(p, true);
    await K.narr(p, ["§7相棒が 鼻を 押しあてると、箱の ふたに 光の すじが 走った。", "§7……ことり、と 小さな 音を 立てて、箱が 開いた。"], g || eK);
    K.re(eK, "shock", "!");
    await K.csay(p, "kazami", ["{shock,!,up}……開いたんじゃて！ 二十年 開かなんだ 箱が……！"], g);
    K.rmCine(g);
    /* 紐 */
    K.act(eK, "show"); K.hold(eK, "rope");
    await K.at(p, ok(eK) ? { x: eK.location.x, y: eK.location.y + 1.1, z: eK.location.z } : DESK, 12, 1.4, 0);
    await K.narr(p, ["§7中には、干し草で 編んだ 紐が 一本。三つ 編んで、一つ 返して ある。"], eK);
    K.sound(p, "item.book.page_turn", 0.8);
    await K.narr(p, ["§7あなたは 腰の 旅の 手帳を 開いた。マリノアの 頁に、あの 子の 丸い 字。", "§f『ナギサさんの お守りの 紐。三つ目ごとに 一つ 返す、ふしぎな 編み方』"], eR);   /*F10 強 */
    await K.say(p, "レイ", ["{shock,…,up}……じいちゃんの 手首の 紐とも、同じ 結び方だ。……星の 好きな 男の、編み方。"], eK);
    /* 封の 手紙 */
    K.hold(eK, "letter");
    await K.at(p, ok(eK) ? { x: eK.location.x, y: eK.location.y + 1.2, z: eK.location.z } : DESK, 12, 1.4, 0);
    await K.narr(p, ["§7紐の 下に、封を した 手紙が 一通。宛名は、細い 字で。", "§f『六つ目へ。娘たちに 渡して くれ』"], eK);
    await K.csay(p, "kazami", ["{closed}……六つ目。あんたの ことかのう。……持って いって くれ。読むも 読まぬも、あんたが 決めるんじゃて。"], eR);
    await K.give(eK, null, "letter");
    const c = await K.pick(p, "c16");
    if (c === "r") {
      K.sound(p, "item.book.page_turn", 1);
      await K.narr(p, ["§7あなたは 封を 切った。"], eR);
      await K.memory(p, eR, "封の 手紙", LETTER_R);
      await K.say(p, "レイ", ["{shock,…,up}……娘。海の 名。……ナギサと、マリンの……親父、か。", "{closed}……コラリアの 姉妹の 親父が、この 塔を 建てた 星を 見る 男。"], eK);
      await K.csay(p, "kazami", ["{sad}……あの 男は、名を 言わなんだ。わしは 今も 知らん。……でも、そう かもしれんのう。"], eR);
    } else {
      await K.narr(p, ["§7あなたは 封を 切らずに、手帳に はさんだ。"], eR);
      await K.say(p, "レイ", ["{closed}……宛名は 娘たちだ。最初に 読むのは、そいつらで いい。"], eK);
    }
    K.key(p, "k_cord"); K.key(p, "k_letter");
    K.act(eK, 0); K.hold(eK);
    K.pay(p, E2, 3000, [["x_celes", 2]]);
    await K.end(p, { leave: [eK], bye: [eR, eF, eW], card: "§7→ 塔の §e星見の 間§7（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 3話 塔の 星見の 間（遠めがね・星図）---------- */
const E3 = { id: "b16e3", t: "遠めがね", place: ROOMP("風の 塔の 上（星見の 間）"), fac: "r10room",
  hint: "§f§e風の 塔§f の 星見の 間へ §7（右上の 案内）",
  syn: "塔の 窓ぎわの 遠めがねは、レンズを 抜かれて、海の 方角……コラリアに 向けて 固められて いた。机の 上に、ステラの 星読みに 習った 星図の 写し。線は 何度も 同じ 方角へ 引かれて いた。",
  F: ["F53"], battles: 0,
  async run(p, d, K) {
    const R = room(K, p), G = R ? seaGlass(K, p, R) : null;
    await K.open(p, R ? "風の 塔（星見の 間）" : "風の 塔の 下", "ash");
    const IN = R ? MK(R, "in") : K.fwd(p, 3, 1.5), CH = R ? MK(R, "chart") : K.fwd(p, 4, 0, 1);
    const eR = REI(K, p); if (ok(eR) && IN) await K.walkCam(p, eR, IN, 18);
    const eK = K.cast(p, "kazami"); K.act(eK, "point");
    await K.csay(p, "kazami", ["{closed}……あの 男は 毎晩、その 遠めがねを のぞいとったんじゃて。"], eR);
    K.act(eK, 0);
    const gq = G || K.fwd(p, 5, 2, 1);
    if (ok(eR)) { await K.approach(p, eR, gq, 1.2, 14); if (G) K.turn(eR, { x: G.x + G.wx * 8, y: G.y, z: G.z + G.wz * 8 }); }
    await K.at(p, gq, 18, 2.4, 0.2);
    await K.narr(p, ["§7窓ぎわの 台に、銅の 筒が 固めて ある。のぞいても、灰色の 雲しか 見えない。", "§7……レンズが、抜かれて いた。"], gq);
    await K.say(p, "レイ", ["{?,up}……動かねえ。ずっと 同じ 方を 向いた ままだ。……この 方角、海だ。マリノアの……コラリアの 方だ。"], eK);   /*F53 植 */
    await K.csay(p, "kazami", ["{sad}レンズは、去る 前の 晩に 外して いったんじゃて。『いつか、だれかが 同じ 方を 見たく なったら』と 言うてな。"], eR);
    K.turn(eR);
    await K.push(p, CH, 24, 3.2, 1.0, 0.2);
    await K.narr(p, ["§7机の 上に、星図の 写し。星と 星を 結ぶ 線が、何度も、何度も、同じ 方角へ 引かれて いる。", "§7すみに 小さな 字。§f『港の 灯りは、ここからは 見えない』"], CH);
    await K.csay(p, "kazami", ["{closed}ステラの 星読みに 習うた 星じゃと 言うとった。……あの 方角に 何が あるかは、とうとう 言わなんだ。"], eR);
    await K.narr(p, ["§7あなたは 首の コンパスを、遠めがねの 横に かざした。……針は 回りつづけて、どこも 指さなかった。"], gq);
    await K.say(p, "レイ", ["{sad}……それ、まだ 回ってんのか。"]);
    K.pay(p, E3, 1500, [["x_celes", 1]]);
    await K.end(p, { leave: [eR], bye: [eK], card: "§7→ 鐘を 止めるには 上へ。……その 前に、雲の 島へ 渡る 道で さわぎ（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 4話 雲の 島へ 渡る 道（ドンゴと チョロ・インクの 小瓶）---------- */
const E4 = { id: "b16e4", t: "インクの 小瓶", place: ISLE_ROAD, fac: "r10road",
  hint: "§f§e雲の 島へ 渡る 道§f へ §7（さわぎが 聞こえる。右上の 案内）",
  syn: "雲の 島へ 渡る 道で、ドンゴと チョロが 六影の 名を かたって、逃げる 人を おどして いた。チョロの 母も、声の 朝に 石に なった。戦いの あと、逃げて いた おばあさんが、あなたに インクの 小瓶を くれた。「名前を 書く ときに 使いな」。",
  F: ["F58"], keys: ["k_ink"], set: { dongo10: 1 }, battles: 1,
  async run(p, d, K) {
    const FW = K.fac(p, "r10road", "waypost", 10, Y(K, p));
    await K.open(p, "雲の 島へ 渡る 道", "ash");
    if (FW) await K.at(p, FW, 14, 6, 1.2);
    const eR = REI(K, p);
    const r1 = K.npcNear(p, "§7逃げる おばあさん", K.PJ("baba", 9)); K.act(r1, "kneel"); K.hold(r1, "potion");
    if (ok(r1)) K.go(r1, K.fwd(p, 3.5, -2.5), 20);
    const eD = K.npcNear(p, "§c下っぱ ドンゴ", K.PJ("noxa", 9)), eC = K.npcNear(p, "§c下っぱ チョロ", K.PJ("noxb", 9)); K.act(eD, "point");
    await K.low(p, eD, 12);
    await K.say(p, "ドンゴ", ["{angry,low}へっへっ。六影は もう ない。……今は、おれたちが 六影だ。", "{angry}食い物を 置いて いきな。逆らえば、影に 食わせるぜ。"], r1);
    if (ok(eR) && ok(r1)) await K.approach(p, eR, r1, 1.4);
    K.act(eR, "guard");
    await K.say(p, "レイ", ["{rage,怒,up}……その 名前を、軽く 口に するな！", "{angry}祭壇で 何が あったか、知らねえで 名乗るな。"], eD);
    await K.say(p, "チョロ", ["{sweat,汗}あ、兄貴……あれ、ルミナの 祭りの ときの……！"], eD);
    if (!K.flag(p, "b16e4a")) {
      const r = await K.battle(p, K.team(["beast", "nether", "animal"], 76, 3, 16), { name: "六影の 名を かたる 二人", arena: "雲の 道", theme: "sky", hpk: 1.4, extra: 0.25, speaker: "ドンゴ", guests: K.team(["animal"], 75, 1, 10).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "な、なんだ こいつら……！", low: "ひ、ひいいっ！" } });
      if (r !== "win") return lose(K, p, "§c下っぱ ドンゴ", K.PJ("noxa", 9), "ドンゴ", "{smile}へっ、出なおしな。");
      K.setFlag(p, "b16e4a");
    }
    const eC2 = K.npcNear(p, "§c下っぱ チョロ", K.PJ("noxb", 9), true); K.act(eC2, "kneel");
    await K.push(p, eC2, 22, 4.2, 1.7);
    await K.say(p, "チョロ", ["{cry,tears,up}……ごめんなさいっす……！ 母ちゃんが、声の 朝に 石に なっちまったんす……！", "{sad}何か 持ってれば、戻せるかもって……でも、何を 持てば いいのかも、わかんねえっす……"], eR);
    await K.say(p, "レイ", ["{closed,up}……名前を 呼べ。毎朝、三度。……塔の 鐘の 縁に、そう 書いて あった。"], eC2);
    K.act(r1, "hold");
    if (ok(r1)) await K.approach(p, r1, K.S(p) ? K.S(p).P : p.location, 1.8);
    await K.at(p, ok(r1) ? { x: r1.location.x, y: r1.location.y + 1.1, z: r1.location.z } : K.fwd(p, 3), 12, 1.4, 0);
    await K.say(p, "逃げる おばあさん", ["{smile,up}……旅の 人。これを あげよう。孫の 手帳に 使って いた インクさ。", "{closed}名前を 書く ときに 使いな。……書いた 名は、消えないからね。"]);   /*F58 植 */
    await K.give(r1, null, "potion");
    K.key(p, "k_ink");
    await K.narr(p, ["§7小さな インクの 小瓶。……あなたは それを、手帳と いっしょに しまった。"]);
    await K.say(p, "ドンゴ", ["{closed,汗}……へっ。六影の 名前は、もう 使わねえ。……チョロ、母ちゃんの とこへ 帰るぞ。"], eC2);
    K.pay(p, E4, 4000, [["dm_bell", 1]]);
    await K.end(p, { leave: [eR, eC2, r1], bye: [eD], card: "§7→ §e風の 塔§7 の 鐘楼へ。鐘を 止める（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 5話 鐘楼への 階段（影の 残りかす）---------- */
const E5 = { id: "b16e5", t: "鐘楼への 階段", place: ROOMP("風の 塔（鐘楼への 階段）"), fac: "r10room",
  hint: "§f§e風の 塔§f の 鐘楼への 階段へ §7（右上の 案内）",
  syn: "鐘楼への 階段に、影の 残りかすが 渦を 巻いて いた。セオが 空へ 飛んだ ときに こぼれた 影。",
  battles: 1,
  async run(p, d, K) {
    const R = room(K, p);
    await K.open(p, "風の 塔（鐘楼への 階段）", "ash");
    const BELL = BELLQ(K, p, R), IN = R ? MK(R, "in") : K.fwd(p, 3, 1.5);
    const eR = REI(K, p);
    if (ok(eR) && IN) await K.walkCam(p, eR, IN, 18);
    await K.at(p, BELL, 16, 6, 0);
    await K.narr(p, ["§7塔の 中の 細い 階段を 見上げると、鐘楼の 下に 黒い 渦が 巻いて いた。"], BELL);
    K.sound(p, "mob.wither.ambient", 1); K.shake(p, 0.4, 0.6);
    await K.shadowFlow(p, BELL, K.fwd(p, 4, 0, 1), 12);
    await K.say(p, "レイ", ["{angry,!,up}影の 残りかすだ……！ ……セオが 祭壇で こぼした 影か！"]);
    if (!K.flag(p, "b16e5a")) {
      await K.duel(p, "§5§l影の 残りかす", "§f鐘楼から、黒い 影の モンスターが 降って くる！", { fams: ["nether"] });
      const r = await K.battle(p, K.team(["nether", "nether", "dragon"], 77, 3, 22), { name: "影の 残りかす", arena: "風の 塔", theme: "underworld", hpk: 1.8, extra: 0.3, speaker: "影", guests: K.team(["animal"], 76, 1, 10).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……シッテ……シマッタ……", low: "……ナヲ……ヨブナ……" } });
      if (r !== "win") return lose(K, p, "§bレイ", 17, "レイ", "{sweat,汗}……下がれ！ 一度 立てなおす！");
      K.setFlag(p, "b16e5a");
    }
    const eR2 = REI(K, p, true);
    await K.narr(p, ["§7影の 渦は 散って、階段の 上に 鐘が 見えた。"], BELL);
    K.pay(p, E5, 3000, [["c_revive2", 1]]);
    await K.end(p, { leave: [eR2], card: "§7→ 鐘楼へ", kind: "ash", t: 24 });
    return true;
  } };

/* ---------- 6話 鐘楼（鐘を 止める）---------- */
const E6 = { id: "b16e6", t: "鐘楼", place: ROOMP("風の 塔（鐘楼）"), fac: "r10room",
  hint: "§f§e風の 塔§f の 鐘楼 §7（右上の 案内）",
  syn: "鐘に、紫の 文字が びっしり 書かれて いた。影の セオは、ここから 鐘を 鳴らして 世界じゅうに 記録を 読み聞かせて いたのだ。鐘を 止めると、声が 止まった。影は 紫の 尾を 引いて、雲の 島の 向こうへ 流れて いった。",
  ans: ["qb142", "qb151"], battles: 0,
  async run(p, d, K) {
    const R = room(K, p);
    await K.open(p, "風の 塔（鐘楼）", "ash");
    const BELL = BELLQ(K, p, R);
    const eR = REI(K, p);
    K.sound(p, "block.bell.hit", 0.6);
    await K.push(p, BELL, 24, 5, 0.4);
    K.burst(p.dimension, BELL, "minecraft:portal_reverse_particle", 12, 0.8, 0);
    await K.narr(p, ["§7鐘の 表に、紫の 細い 文字が びっしり。……鐘が 揺れる たび、文字が 声に なって 空へ 散って いく。"], BELL);
    await K.say(p, "セオの 声", ["{closed,low}……『王冠の 石板の 奥。影の 鍵の――』"]);
    await K.say(p, "レイ", ["{angry,up}……ここから 読み聞かせてたのか。セオが 読んだ 記録を、鐘で、世界じゅうに！", "{angry,!,up}止めるぞ！ 綱を 押さえろ！"], BELL);
    const g = K.palEnt(p); if (g) { await K.go(g, K.fwd(p, 2.5, 0.8), 10); }
    K.act(eR, "guard"); K.sound(p, "block.bell.resonate", 0.8); K.shake(p, 0.5, 0.6);
    await K.narr(p, ["§7レイが 綱に 飛びつき、相棒が 鐘の 舌に 体を 当てた。あなたは 鐘の 縁を 両手で 押さえた。", "§7……ごうん、と 一度。……鐘が、止まった。"], g || BELL);
    K.cmd(p, "stopsound @s"); await K.wait(16);
    await K.narr(p, ["§7声が 止んだ。……風の 音だけが 残った。"], BELL);
    const tail = K.fwd(p, 20, -6, 18);
    await K.shadowFlow(p, BELL, tail, 14);
    await K.at(p, tail, 16, 10, 0);
    await K.narr(p, ["§7鐘から はがれた 紫の 文字が 一本の 尾に なって、雲の 島の 向こうへ 流れて いった。"], tail);
    await K.pal(p, ["……あっちに いった。……くもの、しまの むこう。"]);
    K.rmCine(g);
    await K.say(p, "レイ", ["{closed}……影の セオは、ここに 止まって 鳴らして ただけだ。……まだ 先が ある。"], p);
    K.setFlag(p, "bell16");
    K.pay(p, E6, 3000, [["x_celes", 2]]);
    await K.end(p, { leave: [eR], card: "§7→ 塔の 戸口へ（町の 人の ようすを 見に）", kind: "day", t: 30 });
    return true;
  } };

/* ---------- 7話 目の 文字が 消える・フウタが 起きる ---------- */
const E7 = { id: "b16e7", t: "三度 目の 朝", place: () => DOOR(), fac: "r10room",
  hint: "§f§e風の 塔の 戸口§f へ §7（右上の 案内）",
  syn: "鐘が 止まると、町の 人の 目の 紫の 文字が 消えた。塔の 戸口で 眠って いた フウタが 目を 覚ました。「……三回も 呼ばんでも、聞こえとる」。",
  battles: 0,
  async run(p, d, K) {
    const R = room(K, p);
    await K.open(p, "風の 塔の 戸口", "day");
    const eF = await K.put(p, FUTA_NM, futaAt(K, p, R), R ? MK(R, "door") : null, K.PJ("m6_sota", 9)); K.act(eF, "down");
    const eK = K.cast(p, "kazami");
    if (ok(eK) && ok(eF)) { await K.walkCam(p, eK, nearPt(eK, eF, 1.2), 16); K.act(eK, "kneel"); }
    const eB = K.npcNear(p, "§f大工の ゴロ", K.PJ("m6_genzo", 8)); if (ok(eB) && ok(eF)) await K.go(eB, nearPt(eB, eF, 2.2), 20);
    await K.up(p, eB, 8);
    await K.say(p, "大工の ゴロ", ["{shock,…,up}……頭の 中の 字が、消えた。……静かだ。"], eK);
    await K.csay(p, "kazami", ["{closed,up}……フウタ。……フウタ。", "{sad,up}……フウタや。"], eF);
    for (let k = 0; k < 4 && ok(eF); k++) { K.burst(p.dimension, eF.location, "minecraft:villager_happy", 5, 0.6, k * 0.3); await K.wait(3); }
    try { if (ok(eF)) eF.nameTag = "§f塔守の 孫 フウタ"; } catch {} K.act(eF, "up"); K.sound(p, "random.levelup", 0.6);
    await K.up(p, eF, 10);
    await K.say(p, "フウタ", ["{closed,up}……三回も 呼ばんでも、聞こえとる。", "{smile,up}……じいちゃん。夢の 中で、ずっと 名前を 呼ばれとった。毎朝、三回。"], eK);   /*（決まり二 回: 欲しがった 子は 眠り、声が 止むと 起きる）*/
    await K.csay(p, "kazami", ["{cry,tears,up}……そうかい。……呼ばれる 名は、迷わんのじゃて。"], eF);
    await K.say(p, "レイ", ["{closed,…}……よかったな。"], eK);
    K.act(eK, 0);
    K.pay(p, E7, 2000, [["fd_stew", 1]]);
    await K.end(p, { leave: [eB], bye: [eK, eF], card: "§7― 夜 ―\n§7→ §eゼファーの 宿§7 へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 8話 ゼファーの 宿（夜）---------- */
const E8 = { id: "b16e8", t: "白紙の 頁", snd: "item.book.page_turn", place: INN,
  hint: "§f§eゼファーの 宿§f へ §7（夜。右上の 案内）",
  syn: "夜、ゼファーの 宿。あなたは 仲間の 旅の 手帳を 開いた。いちばん 初めの 頁に、古い 紙きれ。幼い 字で あなたの 名前が 何度も、すみに「おきて」。名前の 頁の 最後は、白紙の まま。",
  F: ["F30"], battles: 0,
  async run(p, d, K) {
    await K.open(p, "ゼファーの 宿（夜）", "night", "night");
    K.ambient(p, "night", K.S(p) ? K.S(p).Cn : p.location);
    const eR = REI(K, p); K.act(eR, "kneel");
    if (ok(eR)) await K.walkCam(p, eR, K.fwd(p, 3, 2), 16);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7宿の 灯りの 下で、あなたは 旅の 手帳を 開いた。", "§7いちばん 初めの 頁に、古い 紙きれが 一枚 はさまって いた。"]);
    await K.narr(p, [`§7幼い 字で、§f${p.name}§7 と 何度も、何度も。すみに 小さく §f『おきて』§7。`]);
    await K.say(p, "レイ", ["{shock,…,up}……あいつ、こんな ガキの ころから……。", "{sad,up}……おまえの 名前、ずっと 呼んでたんだな。"]);
    K.sound(p, "item.book.page_turn", 0.8);
    await K.narr(p, ["§7名前の 頁を めくって いく。ミミ、ゴンザ、ノルじい、オルド、レイ……ベリル。", "§7最後の 頁は、白紙の まま だった。§8『旅の 最後に、二人で 書こう』"]);   /*F30 強 */
    const s = K.qs(K.load(p) || d);
    await K.say(p, "レイ", [K.chV(s, "c16", { r: "{closed}……箱の 手紙、封を 切ったな。……いつか、あの 姉妹に 謝れよ。オレも 行く。", s: "{closed}……箱の 手紙、封は そのままか。……最初に 読むのは、あの 姉妹だな。", _: "{closed}……箱の 手紙、なくすなよ。" })]);
    await K.say(p, "レイ", ["{sad}……あの 尾、雲の 島の 向こうへ 行った。……明日、島へ 渡る。"]);
    const g = K.palEnt(p); if (g) await K.up(p, g, 10);
    await K.pal(p, ["……あの子の じ、まるい。……つぎの じ、いっしょに かこう。"]);
    K.rmCine(g);
    K.pay(p, E8, 1500, [["fd_stew", 1]]);
    await K.night(p, null, "§7灯りが 消えた。レイは 窓ぎわで、ずっと 北の 空を 見て いた。", "§7……朝。雲の 島の 方から、風が 吹いて いた。", [eR]);
    await K.end(p, { card: "§f― 第16章 風の塔 おわり ―\n§7→ 雲の 島へ（右上の 案内）", kind: "day", t: 60 });
    return true;
  } };

bkAdd("b16", [E1, E2, E3, E4, E5, E6, E7, E8]);
