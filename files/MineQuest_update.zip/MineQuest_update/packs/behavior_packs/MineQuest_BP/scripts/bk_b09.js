/* 第126版 本9「石運び」（ネクロス〜フロストヘイムの境・ノクト／グレイヴ）— 迫害の 始まり。作業 MC
   ・自由な 話 9つ（前19）。段 なし。選択 なし。古い 話の 引きとり なし（新しい 章）
   ・この ファイルは 本9〜本12（bk_b10/b11/b12）の 共通の 部品（場所・セット・石・小道具）も 書き出す
   ・新しい セット（facAdd）: mc_bridge 境の橋（谷川と 石の 橋）／mc_pass 雪の峠（岩の 尾根と 道しるべ）／mc_wallgate 閉じた門（町の 塀と 門）／mc_den 氷の 隠れ家（寝床 二つ）／mc_port 海峡の 港（桟橋と 舟）*/
import { unstack } from "./pvplace.js";
import { world, system } from "@minecraft/server";
import { bkAdd, bkHas } from "./bkeng.js";
import { castAdd, CAST, doomed } from "./cast.js";
import { facAdd, FAC_OPS, fac, facMark } from "./epfac.js";
import { bldOf, townOut, placeOf, farOf } from "./storyplace.js";
import { TOWNS, townPos, getTown } from "./structures.js";
import { ok } from "./ui.js";

/* ================= 共通の 部品（本9〜本12）================= */
const { F, S1 } = FAC_OPS;
const tid = (re, d) => (TOWNS.find((t) => re.test(t.name)) || { id: d }).id;
export const TW = { nokt: tid(/ノクト/, "t7"), grave: tid(/グレイヴ/, "t37"), snow: tid(/スノウ/, "t38"), sanda: tid(/サンダ/, "t68"), end: tid(/エンド/, "t27") };
/* 町の 建物の 前（なければ 町の 外れ）*/
export const bld = (id, kinds, nm, turn = 0.9) => { try { const b = bldOf(id, kinds, nm); if (b) return b; const o = townOut(id, turn, nm); return o ? { x: o.x, z: o.z, nm } : null; } catch { return null; } };
export const out = (id, turn, nm) => { try { const o = townOut(id, turn, nm); return o ? { x: o.x, z: o.z, nm } : null; } catch { return null; } };
export const castle = (kind, nm, r = 8) => { try { const q = placeOf(kind, r); return q ? { ...q, nm: nm || q.nm } : null; } catch { return null; } };
export const memo = (f) => { let v = null, t = 0; return (p) => { const n = Date.now(); if (!v || n - t > 60000) { v = f(p); t = n; } return v; }; };
export const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
export const once = (k) => { try { if (world.getDynamicProperty(k)) return false; world.setDynamicProperty(k, 1); return true; } catch { return false; } };
export const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
export const snow = (K, p, q, n = 8, r = 1.4) => { if (!q) return; K.burst(p.dimension, q, "minecraft:white_smoke_particle", n, r, 0.3); K.burst(p.dimension, q, "minecraft:snowflake_particle", n, r * 0.8, 1.2); };
/* 人が 石に なる（足もとから 灰色に。歩かない・固まる）。fast: もう 石に なって いる 人 */
export async function stoneIt(K, p, e, nm, fast = false) {
  if (!ok(e)) return;
  if (!fast) { K.sound(p, "dig.stone", 0.6); for (let k = 0; k < 5; k++) { if (!ok(e)) return; K.burst(p.dimension, e.location, k % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.6, k * 0.35); await K.wait(4); } K.sound(p, "dig.stone", 0.8); }
  try { e.setProperty("mrpg:mv", false); e.setProperty("mrpg:act", 24); } catch {} if (nm) try { e.nameTag = nm; } catch {}
}
/* 石板の 唸り（紙を めくる ような 低い 音）*/
export const hum = (K, p, q, big = false) => { K.sound(p, "item.book.page_turn", big ? 1 : 0.6, 0.4); K.sound(p, "beacon.ambient", big ? 0.9 : 0.5, 0.5); if (q) K.burst(p.dimension, q, "minecraft:enchanting_table_particle", big ? 12 : 6, 0.6, 1); };
/* 城の 中の 小道具（城の そばには セットを 建てない。舞台の 奥に ブロックを 数個だけ・その 場所に 1回）*/
export function props(K, p, key, list) {
  const S = K.S(p); if (!S) return; let v = null; try { v = JSON.parse(world.getDynamicProperty(`mrpg:epdeco:${key}`) || "null"); } catch {}
  if (v && Math.hypot(v.x - S.P.x, v.z - S.P.z) < 64) return; const y0 = Math.floor(S.P.y);
  for (const [a, b, h, bl] of list) { const q = S.at(a, b); K.cmd(p, `setblock ${Math.floor(q.x)} ${y0 + h} ${Math.floor(q.z)} ${bl} keep`); }
  try { world.setDynamicProperty(`mrpg:epdeco:${key}`, JSON.stringify({ x: Math.floor(S.P.x), z: Math.floor(S.P.z) })); } catch {}
}
/* 暗転の 中で もう そこに いる 人（寝て いる・石の 人）*/
export const putN = (K, p, nm, skin, q, look = null) => K.put(p, nm, q, look, K.PJ(skin, 9));
export const V4 = (K, g, o, c, t) => K.V(g, o, c, t);
/* 場面の とちゅうで 去る（背を 向けて 歩き、暗転の 中で 下げる。目の 前で 消えない）*/
export async function walkOff(K, p, e, k = 9) { if (!ok(e)) return; const q = K.away(e, p, k); if (q) await K.go(e, q, 22); if (ok(e)) await K.bye(p, e); }

/* ---------- セット（facAdd。どれも 400 ブロック まで）---------- */
/* 境の橋: 舞台の 奥を 横切る 谷川（水）と、石の 橋（手すり・灯り）*/
facAdd("mc_bridge", { D: [9, 11, 13], gap: 10, box: [-1, -5, 9, 5], H: 3, look: [4, 0, 0.5], marks: { near: [1, 0, 0], mid: [4, 0, 0], far: [7.5, 0, 0], water: [4, 4, -2] }, build: (P) => [
  F(3, -5, -3, 5, 5, -1, "air"), F(3, -5, -3, 5, 5, -3, "water"), S1(3, -5, -2, P.rock), S1(5, 4, -2, P.rock),
  F(2, -1, -1, 6, 1, -1, P.wall), F(2, -2, 0, 6, -2, 0, P.fence), F(2, 2, 0, 6, 2, 0, P.fence), S1(2, -2, 1, P.lamp), S1(6, 2, 1, P.lamp),
  S1(1, -3, 0, "cobblestone_wall"), S1(7, 3, 0, "cobblestone_wall"),
] });
/* 雪の 峠: 左右に 雪を かぶった 岩の 尾根、まん中の 道に 雪、道しるべと 灯り */
facAdd("mc_pass", { D: [8, 10, 12], gap: 10, box: [-1, -5, 9, 5], H: 5, look: [6, 0, 1], marks: { crest: [6, 0, 0], back: [1, 0, 0] }, build: (P) => [
  F(0, -5, 0, 9, -4, 2, P.rock), F(0, 4, 0, 9, 5, 2, P.rock), F(0, -5, 3, 9, -4, 3, "snow"), F(0, 4, 3, 9, 5, 3, "snow"),
  F(0, -3, 0, 9, 3, 0, "snow_layer"), S1(6, 2, 0, P.fence), S1(6, 2, 1, P.fence), S1(6, 2, 2, P.lamp), S1(3, -3, 0, P.rock), S1(8, 3, 0, "snow"),
] });
/* 閉じた 門: 町の 石の 塀・木の 門（閉まって いる）・門の 横の 小窓・塀の 外の 焚き火 */
facAdd("mc_wallgate", { D: [9, 11, 13], gap: 10, box: [-1, -7, 6, 7], H: 6, look: [3.5, 0, 1.5], marks: { gate: [3, 0, 0], win: [3, 2, 0], fire: [0.5, 4.5, 0] }, build: (P) => [
  F(4, -7, 0, 4, 7, 4, P.wall), F(4, -1, 0, 4, 1, 2, P.plank), S1(4, 2, 1, "iron_bars"), F(4, -7, 5, 4, 7, 5, "stone_brick_wall"),
  S1(3, -2, 0, P.fence), S1(3, -2, 1, P.lamp), S1(3, 3, 0, P.fence), S1(3, 3, 1, P.lamp), S1(0, 5, 0, "campfire"), S1(-1, 6, 0, P.log),
] });
/* 氷の 隠れ家（広間が できて いない 世界の かわり）: 氷の 床と 壁・くっつけた 寝床 二つ・絵本の 台・地図の 台 */
facAdd("mc_den", { D: [8, 10, 12], gap: 8, box: [-1, -5, 7, 5], H: 4, look: [3, 0, 0.8], marks: { bed: [4.5, 0, 0], book: [5, -3, 0], map: [6, 3, 0] }, build: (P) => [
  F(0, -4, -1, 6, 4, -1, "packed_ice"), F(7, -5, 0, 7, 5, 3, "packed_ice"), F(0, -5, 0, 6, -5, 2, "packed_ice"), F(0, 5, 0, 6, 5, 2, "packed_ice"),
  F(4, -1, 0, 5, 0, 0, "light_blue_wool"), F(4, 1, 0, 5, 2, 0, "pink_wool"), S1(5, -3, 0, "lectern"), S1(6, 3, 0, "cartography_table"), S1(2, -3, 0, "campfire"), S1(1, 4, 0, "soul_lantern"),
] });
/* 海峡の 港: 舞台の 奥に 海（水）・木の 桟橋・帆の ある 小さな 舟 */
facAdd("mc_port", { D: [8, 10, 12], gap: 10, box: [-1, -5, 10, 5], H: 5, look: [6, 0, 1], marks: { pier: [2, -3, 0], deck: [7.5, 1, 0], bow: [9, 1, 0] }, build: (P) => [
  F(3, -5, -2, 10, 5, -1, "water"), F(0, -4, -1, 6, -2, -1, P.plank), S1(6, -4, 0, P.fence), S1(6, -4, 1, P.lamp), S1(6, -2, 0, P.fence),
  F(6, 0, -1, 9, 2, -1, P.plank), F(6, 0, 0, 9, 0, 0, P.slab), F(6, 2, 0, 9, 2, 0, P.slab), S1(9, 1, 0, P.fence), S1(9, 1, 1, P.fence), F(9, 1, 2, 9, 1, 4, "white_wool"), S1(6, 1, 0, "barrel"),
] });

/* ---------- 町の 人の その後 ---------- */
const at = (f, dx, dz) => () => { const q = f(); return q ? { x: q.x + dx, z: q.z + dz, y: q.y } : null; };
export const has = (s, id) => { try { return bkHas(s, id); } catch { return false; } };
const INN = memo(() => bld(TW.nokt, ["inn"], "よいやみの 町 ノクトの 宿"));
const GRV = memo(() => bld(TW.grave, ["home", "home2", "inn"], "ぼちの 里 グレイヴの 墓守の 家"));
castAdd("b09_nene", { nm: "ナズナ", role: "宿の おかみ", gobi: "", skin: "hanna2", town: TW.nokt, at: at(INN, 2, 1), hide: (s) => !has(s, "b09e3"),
  after: [
    [(s) => !!s.ending, ["{smile,tears}……あんたたちを 追い出した 宿だよ。それでも、泊まって いくかい。", "{closed}じいさまの 石の 前に、毎朝 お茶を 置いてる。……いつか、あの 顔の まま 起きて くるって。"]],
    [doomed, ["{sad}……竜の 山の 方で、何か あったんだってね。", "{closed}じいさまの 石が、ゆうべ 少しだけ 冷たかった。"]],
    [(s) => has(s, "b12e1"), ["{sad}……ヘイムダルから 回状が 来たよ。あんたの 名前を 知ってる 人の 名前が、びっしり。", "{closed}……読んで、泣いた。石を 投げた 手で、あたしも 名前を 書いた。"]],
    [() => true, ["{angry}……張り紙を 信じた。それしか、すがる ものが なかったんだ。", "{sad}じいさまは、あの 晩、孫の 式の 話ばかり してた。……あんたの せいじゃ ないのは、分かってるよ。"]],
  ] });
castAdd("b09_bord", { nm: "ボルド", role: "グレイヴの 墓守", gobi: "", skin: "m6_noct", town: TW.grave, at: at(GRV, -2, 2), hide: (s) => !has(s, "b09e4"),
  after: [
    [(s) => !!s.ending, ["{smile}娘は 今も、夜中に 寝言を 言う。『このまま』じゃ なくて、『また あした』とな。"]],
    [(s) => has(s, "b12e1"), ["{closed}回状に、わしの 名も 書いた。墓守の 名は、死人に しか 読まれん と 思っとったが。"]],
    [() => true, ["{closed}墓守は、石も 死人も こわがらん。……こわいのは、生きた 人の 噂の ほうだ。", "{sad}娘を 揺り起こして くれて、ありがとう。あの 晩の ことは、忘れん。"]],
  ] });
castAdd("b09_zuzu", { nm: "ズズ", role: "六影を やめた", gobi: "ずびっ", skin: "c7_zuzu", town: TW.sanda, at: () => { const o = bld(TW.sanda, ["plaza", "inn", "shop"], "らいうんの 里 サンダの 広場"); return o ? { x: o.x - 4, z: o.z + 3 } : null; }, hide: (s) => !has(s, "b11e2"),
  after: [
    [(s) => !!s.ending, ["{smile}……ずびっ。今も 雪かき係だ。張り紙を はがして 回るのも、つづけてる。"]],
    [doomed, ["{sad}……ずびっ。オレが 貼った 張り紙が、まだ どこかに 残ってる。全部 はがすまで、寝ない。"]],
    [(s) => has(s, "b12e1"), ["{closed}回状、いちばん 下に オレの 名前を 書いた。……元 六影って 書いて。ずびっ。"]],
    [() => true, ["{sweat,汗}……山道の 雪かき、まだ 半分だ。……ずびっ。", "{closed}オレの しかけた 爆薬だ。オレが 掘る。"]],
  ] });
/* 前の 版の サンダの 人（シロウを 双子の 他人と した 台詞・本14 前の 名）は 本11 の 人に 入れかえる */
system.run(() => { for (const k of ["r8_shirou", "r8_zuzu", "r8_rou", "r8_ruu", "r8_argo"]) if (CAST[k]) CAST[k].town = null; });   /* 第126版(fix): 消すと 本20 の 場面（K.cast・K.put）で 名前が "r8_ruu"・見た目が マスターに なる。町に 立たせない だけに する */

/* ================= 本9 ================= */
const GROUND = memo(() => farOf("b09grave", TW.grave, "グレイヴの 先の 墓地", 80, 220) || out(TW.grave, 0.9, "グレイヴの 外れの 墓地")), GPLAZA = memo(() => bld(TW.grave, ["plaza", "inn"], "ぼちの 里 グレイヴの 広場"));
const GEDGE = memo(() => farOf("b09edge", TW.grave, "グレイヴの 先の 道", 80, 220) || out(TW.grave, -0.9, "グレイヴの 外れ"));
const BRIDGE = memo(() => farOf("b09bridge", TW.grave, "ノクトと グレイヴの 境の 橋", 100, 320) || out(TW.grave, 2.4, "ノクトと グレイヴの 境の 橋"));   /* 第127版(fac2): 町の 外れ 56 → 離れた 谷 */
const PASS = memo(() => farOf("b09pass", TW.snow, "雪の 境の 峠", 100, 320) || out(TW.snow, Math.PI, "雪の 境の 峠"));
const OLDMAN = "§7宿の じいさま";
const V = V4;

bkAdd("b09", [
  /* ---------- 1話 張り紙（ノクトの 宿の 前）---------- */
  { id: "b09e1", t: "張り紙", place: INN, F: ["F46"], battles: 0,
    hint: "§fネクロスの §eよいやみの 町 ノクトの 宿§f へ 行こう §7（右上の 案内）",
    syn: "北へ 向かう 途中、ノクトの 宿で 断られた。壁に『石板の 子が 通った 町は、石に なる』の 張り紙と、下手な 似顔絵。",
    async run(p, d, K) {
      await K.open(p, "よいやみの 町 ノクトの 宿", "dusk", "dusk");
      const eH = K.hero(p), eR = REI(K, p);
      const eN = K.cast(p, "b09_nene"); K.act(eN, "arms");
      await K.hsay(p, V(K, ["{smile}こんばんは！ 二人と 一匹、ひと晩 お願い します！"], ["{smile}こんばんは。ひと晩、泊めて いただける かしら。"], ["{closed}……ひと晩。泊めて ほしい。"], ["{smile}こんばんは。ひと晩、お部屋を お願い できますか。"]), eN);
      await K.csay(p, "b09_nene", ["{shock,…}……その 袋。", "{angry,up}悪いね。石板の 子は、泊められないよ。"], eH);
      K.act(eN, "point");
      const W = K.fwd(p, 6, 2.2, 1.6); await K.at(p, W, 16, 3.2, 0.2);
      /*F46*/ await K.narr(p, ["§7宿の 壁に、新しい 張り紙。『§c石板の 子が 通った 町は、石に なる§7』", "§7その 下に、二人と 一匹の 似顔絵。……目が 四つ ある。"], W);
      K.act(eN, 0);
      await K.hsay(p, V(K, ["{shock,!,up}なに これ！ 目が 四つ あるよ！ 相棒なんて 芋だよ、芋！", "{angry,怒}筆 かして！ 描きなおす！"], ["{shock,!}まあ……目が 四つ。相棒が お芋みたい。", "{angry}……筆を 貸して くださる？ 描きなおすわ。"], ["{angry,!}……目が 四つ。相棒が 芋。", "{angry}筆。描きなおす。"], ["{shock,!}まあ……目が 四つ あります。相棒が、お芋に……", "{angry}筆を お貸し ください。描きなおします！"]), W);
      K.act(eH, "hold"); K.hold(eH, "brush");
      if (ok(eR) && ok(eH)) await K.approach(p, eR, eH, 1.4);
      K.act(eR, "palm");
      await K.say(p, "レイ", ["{closed}やめとけ。うまく 描いたら、本物に 似る だけだ。"], eH);
      K.hold(eH); K.act(eH, 0); K.act(eR, 0);
      await K.ots(p, eR, W, 10);
      /*F69*/ await K.say(p, "レイ", ["{closed,low}……『石板の 子が 通った 町は、石に なる』。"], eH);   /* 第128版: レイは 本5-6 に いない。密告の 文句と 気づくのは 幼なじみ */
      await K.hsay(p, V(K, ["{sad,…}……ガルムさんが 握りつぶした 方の 紙。あれが、こんな 遠くまで。"], ["{sad}……ガルムさんが 握りつぶした 紙と、同じ 文句ね。"], ["{closed}……砂の 町で 握りつぶされた 紙。同じ 文句。"], ["{sad}……ガルムさんが 握りつぶした 紙と、同じ 文句です。"]), eR);
      const eV = K.npcNear(p, "§7町の 人", K.PJ("m6_kenta", 9));
      K.act(eV, "guard"); await K.up(p, eV, 10);
      await K.say(p, "町の 人", ["{angry}……こっちを 見るな。うちの 子が 石に なったら、どう して くれる。"], eH);
      await walkOff(K, p, eV, 9);
      await K.push(p, eH, 20, 4, 1.7);
      await K.hsay(p, V(K, ["{sad,up}……わたしたち、何も して ないのに。"], ["{sad,up}……わたしたち、何も して いないのにね。"], ["{closed,up}……何も して ない。"], ["{sad,up}……わたしたち、何も して いませんのに。"]));
      /* 奥から じいさま */
      const eO = K.npcNear(p, OLDMAN, K.PJ("godo", 8)); K.act(eO, "wave");
      await K.say(p, "宿の じいさま", ["{smile}ナズナ。裏の 物置なら、だれも 文句は 言わんじゃろ。", "{smile,up}わしの 客じゃ。……寒いじゃろう、入りなさい。"], eH);
      await K.csay(p, "b09_nene", ["{sad}……じいさま。……知らないからね。"], eO);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eN], bye: [eO, eR], card: "§7→ その 夜（§eノクトの 宿の 前§7）", kind: "dusk" });
      return true;
    } },
  /* ---------- 2話 じいさまの 話（夜）---------- */
  { id: "b09e2", t: "ずっと 続けば", place: INN, battles: 0,
    hint: "§fノクトの §e宿の 前§f で 夜を 過ごそう §7（右上の 案内）",
    syn: "泊めて くれた 宿の じいさまが、夜、孫の 結婚式の 話を した。「あの 日が、ずっと 続けばなあ」。",
    async run(p, d, K) {
      await K.open(p, "ノクトの 宿の 前（夜）", "night", "night");
      const eH = K.hero(p), eO = K.npcNear(p, OLDMAN, K.PJ("godo", 8));
      K.act(eO, "hold"); K.hold(eO, "mug");
      await K.say(p, "宿の じいさま", ["{smile}眠れんのか。……わしもじゃ。年寄りは、夜が 長い。"], eH);
      K.act(eH, "kneel");
      await K.two(p, eO, eH, 16);
      await K.say(p, "宿の じいさま", ["{smile,♪}先月な、孫が 嫁を もらった。この 宿の 前に 卓を 並べて、町じゅうで 祝った。", "{closed,up}孫の やつ、ずっと 笑っとった。嫁さんの 手を、一晩じゅう 離さんでな。"]);
      await K.hsay(p, V(K, ["{smile}いいなあ。……どんな 料理 出たの？"], ["{smile}すてきね。……お料理は 何を？"], ["{closed}……いい 夜だな。"], ["{smile}すてきですね。……どんな お料理を？"]), eO);
      await K.say(p, "宿の じいさま", ["{smile}ばあさんの 煮こみじゃ。ばあさんは もう おらんが、ナズナが 同じ 味に 作った。"]);
      K.hold(eO);
      await K.push(p, eO, 24, 4.5, 1.6);
      await K.say(p, "宿の じいさま", ["{closed,…}……あの 日が、ずっと 続けばなあ。", "{smile,up}このまま、あの 卓の ところで、ずっと。"]);
      /* 袋の 唸り（じいさまの 耳にだけ）*/
      const bag = K.fwd(p, 2, -1.4, 0.4); hum(K, p, bag);
      K.re(eO, "shock", "?");
      await K.say(p, "宿の じいさま", ["{?}……今、本の 頁を めくる 音が せんかったか。"]);
      await K.hsay(p, V(K, ["{?}え？ ……なんにも 聞こえないよ？"], ["{?}あら……わたしには 何も。"], ["{closed,?}……何も。"], ["{?}いいえ……わたしには 何も。"]), eO);
      await K.say(p, "宿の じいさま", ["{smile}ふふ。年寄りの 耳じゃ。……おやすみ。"]);
      await walkOff(K, p, eO, 8);
      await K.night(p, bag, "§7袋の 口の 中で、何かが ひと晩じゅう、かすかに 鳴って いた。", "§7……朝。宿の 前が、やけに 静かだった。");
      K.act(eH, 0);
      if (!ok(p)) return false;
      await K.end(p, { kind: "night", t: 30 });
      return true;
    } },
  /* ---------- 3話 笑ったままの 石（ノクトの 朝）---------- */
  { id: "b09e3", t: "石を 投げる 町", place: INN, F: ["F03"], battles: 0,
    hint: "§fノクトの §e宿の 前§f へ（朝）",
    syn: "朝、じいさまは 宿の 戸口の 前で、笑ったまま 石に なって いた。町の 人が 石を 投げた。",
    async run(p, d, K) {
      await K.open(p, "ノクトの 朝", "day");
      const S = K.S(p), q = S ? S.at(5, 1.6) : K.fwd(p, 5, 1.6);
      const eO = await putN(K, p, "§7石に なった じいさま", "godo", q); await stoneIt(K, p, eO, null, true);
      await K.at(p, q, 18, 5, 1.2);
      /*F03*/ await K.narr(p, ["§7宿の 戸口の 前に、じいさまが 座りこんで いた。", "§7湯のみを 持ったまま、笑った 顔の まま、灰色の 石に なって いた。"], eO);
      const eH = K.hero(p);
      if (ok(eH) && ok(eO)) await K.approach(p, eH, eO, 1.5);
      K.act(eH, "kneel");
      await K.hsay(p, V(K, ["{shock,…,up}……おじいさん？ ……ねえ、おじいさん！"], ["{shock,…,up}……おじいさま？ ……おじいさま！"], ["{shock,…}……じいさん。……おい。"], ["{shock,…,up}……おじいさま？ ……おじいさま！"]), eO);
      const eR = REI(K, p);
      await K.push(p, eO, 22, 3.6, 1.4);
      await K.say(p, "レイ", ["{sad,low}……『ずっと 続けば』。ゆうべ、そう 言ってたな。", "{closed}願った 顔の まま、だ。"], eH);
      /* 町の 人 */
      const eN = K.cast(p, "b09_nene"), eV = K.npcNear(p, "§7町の 人", K.PJ("m6_kenta", 9)), eV2 = K.npcNear(p, "§7町の 女", K.PJ("kaori", 9));
      K.act(eN, "kneel");
      await K.csay(p, "b09_nene", ["{cry,tears,up}じいさま……！", "{angry,怒,up}……あんたたちが 来たからだ！ 張り紙の とおりじゃ ないか！"], eH);
      K.act(eV, "raise");
      await K.say(p, "町の 人", ["{angry,!}石運びだ！ 出て いけ！"]);
      K.sound(p, "random.bow", 0.8); K.burst(p.dimension, ok(eH) ? eH.location : null, "minecraft:basic_smoke_particle", 4, 0.4, 1.4); K.act(eH, "recoil");
      await K.narr(p, ["§7石は、足もとに 落ちた。"], eH);   /* 第128版(D10) */
      await K.say(p, "町の 女", ["{angry,!,up}次は うちの 子よ！ 出て いって！"]);
      K.sound(p, "random.bow", 0.8); K.act(eR, "guard");
      if (ok(eR) && ok(eH)) { const l = eH.location; await K.go(eR, { x: l.x + 0.7, y: l.y, z: l.z + 0.4 }, 6); await unstack(K, p, eR, [eH, eV, eV2, eN]); }
      await K.say(p, "レイ", ["{angry,up}……行くぞ。ここに いたら、もっと 投げられる。"], eH);
      await K.push(p, eH, 20, 3.8, 1.6);
      await K.hsay(p, V(K, ["{cry,tears,up}……ごめんなさい。……ごめんなさい。"], ["{cry,tears,up}……ごめんなさい。"], ["{closed,tears}……すまない。"], ["{cry,tears,up}……申し訳 ありません。"]), eN);
      K.act(eH, 0); K.act(eR, 0);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eN, eV, eV2, eO], card: "§7→ 南の §eぼちの 里 グレイヴ§7 へ（右上の 案内）", kind: "day" });
      return true;
    } },
  /* ---------- 4話 墓守の 家（夜。石板の 唸り）---------- */
  { id: "b09e4", t: "夜の 唸り", place: GRV, battles: 0,
    hint: "§fネクロスの §eぼちの 里 グレイヴの 墓守の 家§f へ 行こう §7（右上の 案内）",
    syn: "墓守ボルドの 家に 泊めて もらった。夜、袋の 石板が 唸り、相棒だけが 吠えた。墓守の 娘が 寝言で「このまま……」と 言いかけ、幼なじみが 揺り起こした。",
    async run(p, d, K) {
      await K.open(p, "ぼちの 里 グレイヴの 墓守の 家", "dusk", "dusk");
      const eH = K.hero(p), eB = K.cast(p, "b09_bord");
      await K.csay(p, "b09_bord", ["{closed}……張り紙の 子らか。", "{closed,up}墓守は、石も 死人も こわがらん。泊まって いけ。"], eH);
      await K.hsay(p, V(K, ["{shock,!,up}……いいの！？"], ["{shock}……よろしいの？"], ["{closed,?}……いいのか。"], ["{shock}……よろしいの ですか？"]), eB);
      await K.csay(p, "b09_bord", ["{smile}娘の リタが、旅の 話を 聞きたがる。それが 宿代だ。"]);
      const eG = K.npcNear(p, "§eリタ", K.PJ("luna2", 9)); K.act(eG, "wave");
      await K.say(p, "リタ", ["{smile,♪}旅の 人たち、海を 見た？ わたし、見たこと ない！"], eH);
      await walkOff(K, p, eG, 7);
      await K.night(p, K.fwd(p, 5, 0, 1), "§7……夜ふけ。", "", [eB]);
      /* 唸り（相棒だけが 聞く）*/
      const bag = K.fwd(p, 2.5, -1.2, 0.4), g = K.palEnt(p);
      hum(K, p, bag, true);
      if (g) { K.sound(p, "mob.wolf.bark", 1); await K.at(p, g.location, 12, 3, 0.8); }
      await K.hsay(p, V(K, ["{shock,?}……どうしたの？ 何に 吠えてるの？"], ["{shock,?}……どうしたの？ 何を 吠えて いるの？"], ["{closed,?}……何に 吠えてる。"], ["{shock,?}……どうしましたか？ 何に 吠えて……"]), g);
      K.act(eH, "kneel"); await K.at(p, bag, 14, 2.6, 0.3);
      /* 石板の唸り 植 */ await K.narr(p, ["§7袋の 中の、封じた 石板。耳を 近づけても、あなたには 何も 聞こえない。", "§7……相棒だけが、袋を にらんで うなって いる。"], bag);
      const eG2 = await putN(K, p, "§eリタ", "luna2", K.fwd(p, 4.2, 3.4), K.fwd(p, 4.2, 7)); K.act(eG2, "prone");   /* 第126版(PV): 頭は 外へ */
      if (ok(eG2)) await K.at(p, eG2.location, 12, 2.2, 0.4);
      await K.say(p, "リタ", ["{closed}……うみ……みんなで……このまま……"]);
      await K.hsay(p, V(K, ["{shock,!,up}だめ！ リタちゃん、起きて！"], ["{shock,!,up}だめよ！ リタちゃん、起きて！"], ["{shock,!}……だめだ。起きろ！"], ["{shock,!,up}いけません！ リタさん、起きて！"]), eG2);
      if (ok(eH) && ok(eG2)) { await K.approach(p, eH, eG2, 1.2, 8); K.act(eH, "kneel"); }
      K.sound(p, "random.pop", 0.8); K.act(eG2, "up");
      await K.say(p, "リタ", ["{?}……お姉ちゃん？ ……海の 夢、見てた。"]);
      const eB2 = K.cast(p, "b09_bord");
      await K.csay(p, "b09_bord", ["{shock,…}……今、娘の 足が 灰色に……", "{closed,low}……見間違いでは ないな。"], eH);
      await K.push(p, eH, 20, 3.8, 1.6);
      await K.hsay(p, V(K, ["{sad,up}……ノクトの おじいさんも、『このまま』って 言った。", "{shock,…}この 袋の 近くで……？"], ["{sad,up}……ノクトの おじいさまも、『このまま』と……", "{shock}この 袋の そばで……？"], ["{closed}……ノクトの じいさんも『このまま』。", "{shock}この 袋の そばで。"], ["{sad,up}……ノクトの おじいさまも、『このまま』と おっしゃって……", "{shock}この 袋の そばで……？"]));
      K.rmCine(g);
      if (!ok(p)) return false;
      await K.end(p, { bye: [eB2, eG2], card: "§7→ 朝の §eグレイヴの 広場§7 へ", kind: "night" });
      return true;
    } },
  /* ---------- 5話 石運び（グレイヴの 広場。ズズ）---------- */
  { id: "b09e5", t: "石運び", place: GPLAZA, F: ["F05"], battles: 0,
    hint: "§fグレイヴの §e広場§f へ 行こう",
    syn: "広場で「石運び」として 縛られかけた。助けたのは 六影を やめた ズズ。「張り紙を 貼ったのは オレたち 下の 者だ。字は じいさんの 字だった」。幼なじみが 張り紙の 字を 見て「……セオさんの、写した 字だ」。",
    async run(p, d, K) {
      await K.open(p, "ぼちの 里 グレイヴの 広場", "day");
      const eH = K.hero(p), eR = REI(K, p);
      const e1 = K.npcNear(p, "§7里の 男", K.PJ("m6_mason", 9)), e2 = K.npcNear(p, "§7里の 若者", K.PJ("m6_grant", 9));
      K.act(e1, "hold"); K.hold(e1, "rope"); K.act(e2, "hold"); K.hold(e2, "staff");
      await K.say(p, "里の 男", ["{angry,!}いたぞ、石運びだ！ ノクトの じいさまを 石に した 連中だ！", "{angry}縄を かけろ！ 里から 叩き出せ！"], eH);
      K.act(eR, "guard");
      await K.say(p, "レイ", ["{angry,up}待て。オレたちは 何も 運んで ない。"], e1);
      if (ok(e1) && ok(eH)) await K.approach(p, e1, eH, 1.3, 10);
      K.act(eH, "recoil");
      /* ズズ */
      const eZ = K.cast(p, "b09_zuzu"); K.act(eZ, "raise");
      await K.csay(p, "b09_zuzu", ["{angry,!,up}そいつらを 縛るなら、オレも 縛れ！ ……ずびっ。"], e1);
      await K.say(p, "里の 男", ["{shock,?}……なんだ、おまえ。その 外套の 印……六影か！？"], eZ);
      K.act(eZ, "show"); K.hold(eZ, "scroll");
      await K.csay(p, "b09_zuzu", ["{sad,up}六影は やめた。……でも、これは オレたちが やった ことだ。", "{closed}張り紙を 貼ったのは、オレたち 下の 者だ。上からの 命令書に 書いて あった。ずびっ。"], e1);
      await K.up(p, eZ, 10);
      await K.csay(p, "b09_zuzu", ["{closed}命令書の 字は、じいさんの 字だった。……オレたちは、参謀は 年寄りだと 思ってた。"]);
      if (ok(eH) && ok(eZ)) await K.approach(p, eH, eZ, 1.4);
      K.hold(eZ); K.act(eZ, 0); K.act(eH, "hold"); K.hold(eH, "scroll");
      await K.at(p, ok(eH) ? eH.location : null, 14, 1.8, 1.3);
      /*F05*/ await K.narr(p, ["§7張り紙の 字。細くて、少し 右に 傾いた、年寄りの 字。", "§7……でも、『石』の 字の はらいだけが、若い。ピピの 薬の 本に セオが 書きこんだ、あの 字と 同じ はらい。"], eH);
      await K.hsay(p, V(K, ["{shock,…}……セオさんの、写した 字だ。"], ["{shock,…}……セオさんの、写した 字よ。"], ["{shock,…}……セオの 写した 字だ。"], ["{shock,…}……セオさんの、写した 字です。"]));
      K.hold(eH); K.act(eH, 0);
      await K.say(p, "レイ", ["{angry,low}……あいつが、この 張り紙を。"], eH);
      await K.say(p, "里の 男", ["{sweat,汗}……六影の 張り紙？ じゃあ、噂は……"]);
      await K.csay(p, "b09_zuzu", ["{sad}半分は うそだ。……でも、半分は 本当かも しれない。ノクトの じいさんは、本当に 石に なった。ずびっ。"], e1);
      K.hold(e1); K.hold(e2);
      if (!ok(p)) return false;
      await K.end(p, { leave: [e1, e2, eZ, eR], card: "§7→ §eグレイヴの 外れ§7 で ズズの 話を 聞こう", kind: "day" });
      return true;
    } },
  /* ---------- 6話 寄り道を させない（グレイヴの 外れ）---------- */
  { id: "b09e6", pv: 127, t: "寄り道せずに", place: GEDGE, fac: "b09edge", battles: 0,
    hint: "§fグレイヴの §e外れ§f で ズズと 話そう",
    syn: "ズズ「命令書に 書いて あった。『石板の 子が、寄り道せずに ラグナへ 行くように』って」。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b09edge", "waypost", 7, Y(K, p));
      await K.open(p, "グレイヴの 外れ", "day");
      if (FQ) await K.at(p, FQ, 12, 6, 1.2);
      const eH = K.hero(p), eZ = K.cast(p, "b09_zuzu"), eR = REI(K, p);
      K.act(eZ, "kneel");
      await K.csay(p, "b09_zuzu", ["{sad}……ずびっ。オレ、まだ 言って ない ことが ある。", "{closed}張り紙の 命令書を 運んで きた 伝令が、ぽろっと 言ったんだ。"], eH);
      await K.flashback(p, { set: "fb_post", label: "§7―― 張り紙の 出る 前の 夜　六影の 詰所", tod: "night", ptc: "dust",   /* 第127版: ズズが 聞いた 話を 絵で */
        actors: { z: { nm: "§7ズズ", job: K.PJ("c7_zuzu", 8), at: [2.6, 1], look: "m", act: "hold" }, m: { nm: "§8伝令", job: K.PJ("noxb", 9), at: [3.4, -1], look: "z", hold: "letter" } },
        beats: [
          ["narr", "§7張り紙が 出る 前の 夜。六影の 詰所に、伝令が 張り紙の 命令書の 束を 運んで きた。", "m"],
          ["say", "m", "{closed,low}町ごとに 一枚ずつ 貼れ。『石板の 子に 宿を 貸すな』だ。", "z"],
          ["say", "z", "{?}……なんで そんな こと するんだ？ あいつら、悪い こと して ねえだろ。", "m"],
          ["act", "m", "show"],
          ["say", "m", "{smile,low}命令書に 書いて あった。『石板の 子が、寄り道せずに ラグナへ 行くように』ってな。", "z"],
          ["say", "z", "{shock,…}……ラグナ？", "m"],
          ["say", "m", "{closed}よけいな ことは 聞くな。おれたちは 貼るだけだ。", "z"],
          ["go", "m", [8, -2], 18],
        ] });
      await K.csay(p, "b09_zuzu", ["{closed,low}……そう 言ったんだ。『寄り道せずに ラグナへ』って。"]);
      K.act(eZ, 0);
      /* ラグナ 植 */
      await K.hsay(p, V(K, ["{?,up}ラグナ……？ 地図の いちばん 北の、竜の 骨の ある 所？", "{angry}なんで セオさんが、わたしたちを そこへ 行かせたいの？"], ["{?,up}ラグナ……北の 果ての、竜の 骨の 土地？", "{sad}どうして セオさんは、わたしたちを そこへ？"], ["{?}……ラグナ。北の 果て。", "{angry}なんで セオが、わたしたちを そこへ。"], ["{?,up}ラグナ……北の 果ての、竜の 骨の 土地ですか？", "{sad}どうして セオさんが、わたしたちを そこへ……"]), eZ);
      await K.ots(p, eR, eH, 10);
      await K.say(p, "レイ", ["{closed}……町が 背を 向ければ、寄り道は できない。", "{angry,low}追い出させて、まっすぐ 北へ 歩かせる。……そういう ことだろ。"]);
      await K.push(p, eH, 22, 4, 1.6);
      await K.hsay(p, V(K, ["{sad,up}……それでも、なんで なのかは 分からない。", "{closed,up}会って、聞く。セオさんの 口から。"], ["{sad,up}……でも、なぜ なのかは 分からないわ。", "{closed,up}会って 聞きましょう。セオさん 本人に。"], ["{closed}……なんでかは 分からない。", "{closed}会って 聞く。"], ["{sad,up}……それでも、なぜ なのかは 分かりません。", "{closed,up}お会いして、うかがいます。"]));
      await K.csay(p, "b09_zuzu", ["{smile,tears}……オレも ついて いく。張り紙を 貼った 手で、今度は はがす。ずびっ。"], eH);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eZ, eR], card: "§7→ 町には 入れない。§eグレイヴの 外れの 墓地§7 で 夜を 明かそう", kind: "day" });
      return true;
    } },
  /* ---------- 7話 名前の 頁（墓地の 野宿）---------- */
  { id: "b09e7", pv: 127, t: "名前の 頁", place: GROUND, fac: "b09grave", F: ["F12"], battles: 0,
    hint: "§fグレイヴの 外れの §e墓地§f で 夜を 明かそう",
    syn: "町の 外で 野宿。幼なじみが 旅の 手帳の 名前の 頁を 声に 出して 読んだ。「この 人たちは、わたしたちを 知ってる」。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b09grave", "graves", 7, Y(K, p));
      await K.open(p, "グレイヴの 墓地（夜）", "night", "night");
      if (FQ) await K.at(p, FQ, 14, 6, 1);
      const eH = K.hero(p), eR = REI(K, p), eZ = K.cast(p, "b09_zuzu");
      K.act(eH, "kneel"); K.act(eR, "kneel"); K.act(eZ, "prone");
      K.burst(p.dimension, K.fwd(p, 3, 0, 0.2), "minecraft:basic_flame_particle", 6, 0.3, 0.3); K.sound(p, "fire.ignite", 0.6);
      await K.say(p, "レイ", ["{closed}……墓の 横で 野宿か。じいちゃんに 話したら、笑うだろうな。"], eH);
      K.hold(eH, "notebook"); K.act(eH, "show");
      await K.push(p, eH, 22, 3.4, 1.2);
      await K.hsay(p, V(K, ["{closed}……ねえ。手帳の、名前の 頁。読んで いい？"], ["{closed}……ねえ。手帳の 名前の 頁、読んでも いいかしら。"], ["{closed}……手帳の 名前の 頁。読む。"], ["{closed}……あの。手帳の 名前の 頁を、読んでも よろしいですか。"]));
      /*F12*/ await K.hsay(p, V(K, ["{closed}ミミ。ゴンザさん。ノルじい。ピピ。ドルフさん。トンボ。", "{closed}セリーヌさん。ガンテツさん。ナギサさん。マリンさん。ユラちゃん……"], ["{closed}ミミ。ゴンザさん。ノルじい。ピピ。ドルフさん。トンボ。", "{closed}セリーヌさん。ガンテツさん。ナギサさん。マリンさん。ユラさん……"], ["{closed}ミミ。ゴンザ。ノルじい。ピピ。ドルフ。トンボ。", "{closed}セリーヌ。ガンテツ。ナギサ。マリン。ユラ。"], ["{closed}ミミさん。ゴンザさん。ノルじい。ピピさん。ドルフさん。トンボさん。", "{closed}セリーヌさん。ガンテツさん。ナギサさん。マリンさん。ユラさん……"]));
      await K.at(p, FQ || K.fwd(p, 7, 0), 14, 5, 1.6);
      await K.hsay(p, V(K, ["{smile,tears,up}……この 人たちは、わたしたちを 知ってる。", "{closed,up}張り紙の 顔じゃ なくて、本当の 顔を。"], ["{smile,tears,up}……この 人たちは、わたしたちを 知って いるの。", "{closed,up}張り紙じゃ ない、本当の 顔を。"], ["{closed,up}……この 人たちは、わたしたちを 知ってる。", "{closed}張り紙の 顔じゃ ない 方を。"], ["{smile,tears,up}……この 方たちは、わたしたちを 知って います。", "{closed,up}張り紙では ない、本当の 顔を。"]));
      await K.say(p, "レイ", ["{closed,…}……町の 人は、名前を 呼んで くれなかった。", "{smile,low}でも、その 頁は、呼んで くれる。"], eH);
      await K.csay(p, "b09_zuzu", ["{closed}……ずびっ。オレの 名前も、そこに 書いて くれ。"], eH);
      await K.hsay(p, V(K, ["{smile}うん。ズズさん、っと。"], ["{smile}ええ。ズズさん、と。"], ["{closed}……ズズ。書いた。"], ["{smile}はい。ズズさん、と。"]), eZ);
      K.hold(eH); K.act(eH, 0); K.act(eR, 0); K.act(eZ, 0);
      if (!ok(p)) return false;
      await K.end(p, { bye: [eZ, eR], card: "§7→ 北へ。§eノクトと グレイヴの 境の 橋§7 を 渡ろう", kind: "night" });
      return true;
    } },
  /* ---------- 8話 境の 橋（追手。ズズと 共闘）---------- */
  { id: "b09e8", pv: 127, t: "境の 橋", place: BRIDGE, fac: "b09bridge", battles: 1,
    hint: "§fネクロスの 北 §eノクトと グレイヴの 境の 橋§f へ 行こう §7（追手が 来る）",
    syn: "張り紙を 信じた 追手が、網と 棒で 道を ふさいだ。ズズと いっしょに 戦った。だれも 刃を 向けなかった。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b09bridge", "mc_bridge", 7, Y(K, p));
      const MID = facMark("b09bridge", "mid", p.location), FAR = facMark("b09bridge", "far", p.location);
      const e1 = K.npcAt(p, "§7追手", K.PJ("m6_garrett", 9), FAR || K.fwd(p, 8, 0)), e2 = K.npcAt(p, "§7追手の 若者", K.PJ("m6_bram", 9), FAR ? { x: FAR.x, y: FAR.y, z: FAR.z + 1.4 } : K.fwd(p, 8, 1.5));   /* 第127版(RV3): 追手は 先に 橋の 向こうで 道を ふさいで いる（話す 絵に 急に 出ない）*/
      K.act(e1, "hold"); K.hold(e1, "net"); K.act(e2, "hold"); K.hold(e2, "staff");
      await K.open(p, "ノクトと グレイヴの 境の 橋", "day");
      if (FQ) { await K.at(p, FQ, 16, 7, 1.4); K.sound(p, "liquid.water", 0.6); }
      const eH = K.hero(p), eR = REI(K, p), eZ = K.cast(p, "b09_zuzu");
      if (ok(eH)) await K.walkCam(p, eH, MID || K.fwd(p, 4, 0), 18);
      await K.say(p, "追手", ["{angry,!}そこまでだ、石運び！ 橋は 渡さん！", "{angry}グレイヴにも ノクトにも、二度と 来るな！"], eH);
      await K.hsay(p, V(K, ["{angry,up}……網と 棒？"], ["{shock}……網と、棒……？"], ["{closed}……網と 棒か。"], ["{shock}……網と、棒……？"]), e1);
      await K.say(p, "レイ", ["{closed,low}……刃は 向けて こない。こわいんだ、こいつらも。"], eH);
      K.act(eZ, "guard");
      await K.csay(p, "b09_zuzu", ["{angry,up}オレが 前に 出る。……殴られるのは、張り紙を 貼った オレの 番だ。ずびっ。"], e1);
      if (!K.flag(p, "b09e8w")) {
        const r = await K.battle(p, K.team(["beast", "animal", "golem"], 60, 3, 14), { name: "張り紙を 信じた 追手", arena: "境の 橋", theme: "dark", speaker: "追手", guests: K.team(["beast"], 58, 1).map((t) => ({ ...t, owner: "ズズ" })), lines: { half: "……網が 切られた！", low: "……くそ、こわくなんか……！" } });
        if (r !== "win") { await K.sayAt(p, "§7追手", K.PJ("m6_garrett", 9), "追手", ["{angry}……出直して こい！ 町には 入れん！"]); return false; }
        K.setFlag(p, "b09e8w");
      }
      K.hold(e1); K.hold(e2); K.act(e1, "kneel"); K.act(e2, "recoil");
      await K.say(p, "追手", ["{sad,…}……うちの 女房が、ゆうべ 石に なりかけた。『このまま』って 寝言で……", "{cry}……だれかの せいに しなきゃ、眠れないんだ。"], eH);
      await K.push(p, eH, 20, 3.8, 1.6);
      await K.hsay(p, V(K, ["{sad,up}……奥さんの 寝言、聞こえたら 揺り起こして。", "{closed,up}『このまま』って 言い終わる 前に。"], ["{sad,up}……寝言が 聞こえたら、揺り起こして あげて。", "{closed,up}『このまま』って 言い終わる 前に。"], ["{closed}……寝言が 聞こえたら 起こせ。", "{closed}言い終わる 前に。"], ["{sad,up}……寝言が 聞こえたら、揺り起こして さしあげて ください。", "{closed,up}『このまま』と 言い終わる 前に。"]), e1);
      await K.csay(p, "b09_zuzu", ["{closed}……ずびっ。オレ、決めた。どこかで 裁きが あったら、証人に なる。"], eH);
      if (!ok(p)) return false;
      K.pay(p, { id: "b09e8" }, 1800, [["c_herbs", 2]]);
      await K.end(p, { leave: [e1, e2, eZ, eR], card: "§7→ 北の §e雪の 境の 峠§7 へ", kind: "day" });
      return true;
    } },
  /* ---------- 9話 灯りの ない 峠 ---------- */
  { id: "b09e9", pv: 127, t: "灯りの ない 峠", place: PASS, fac: "b09pass", battles: 0,
    hint: "§fフロストヘイムへ 入る §e雪の 境の 峠§f へ 行こう",
    syn: "峠で 振り返ると、来た 道に 町の 灯りが 一つも 見えなかった。相棒が 袋の 石板に 耳を 当てて いた。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b09pass", "mc_pass", 8, Y(K, p)), CR = facMark("b09pass", "crest", p.location);
      await K.open(p, "雪の 境の 峠", "snow", "dusk");
      const eH = K.hero(p), eR = REI(K, p), eZ = K.cast(p, "b09_zuzu");
      if (ok(eH)) await K.walkCam(p, eH, CR || K.fwd(p, 5, 0), 20);
      snow(K, p, CR || FQ || K.fwd(p, 6, 0), 10, 3);
      K.turn(eH, K.fwd(p, -20, 0));
      await K.at(p, K.fwd(p, -14, 0, 2), 22, 9, 2);
      await K.narr(p, ["§7振り返ると、来た 道は 夕闇の 底に 沈んで いた。", "§7ノクトの 灯りも、グレイヴの 灯りも、一つも 見えない。"]);
      K.turn(eH);
      await K.push(p, eH, 22, 3.8, 1.6);
      await K.hsay(p, V(K, ["{sad,…}……一つも、見えないね。"], ["{sad,…}……一つも、見えないわね。"], ["{closed,…}……一つも、ない。"], ["{sad,…}……一つも、見えませんね。"]));
      const g = K.palEnt(p), bag = K.fwd(p, 2, -1, 0.3);
      if (g) await K.at(p, g.location, 14, 2.4, 0.6);
      await K.narr(p, ["§7相棒が、袋の 石板に 耳を 当てて いる。", "§7じっと、何かを 聞くように。"], g || bag);
      hum(K, p, bag);
      await K.say(p, "レイ", ["{closed}……何が 聞こえるんだろうな、そいつには。"], eH);
      await K.csay(p, "b09_zuzu", ["{sad}……ずびっ。峠の 向こうは フロストヘイム。雪どけの 町 スノウが 近い。"]);
      K.rmCine(g);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eZ, eR], card: "§f― 第9章 石運び おわり ―\n§7→ §9フロストヘイム§7 の §e雪どけの 町 スノウ§7 へ", kind: "snow", t: 60 });
      return true;
    } },
]);
