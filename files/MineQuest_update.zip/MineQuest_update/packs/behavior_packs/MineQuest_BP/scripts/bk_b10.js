/* 第126版 本10「閉じた門」（フロストヘイム・スノウ／ヘイムダル）— 裁き。作業 MC
   ・自由な 話 9つ（前19）。選択 C10（石板を 城に 預けるか／持ったまま 追放を 受けるか）は 8話
   ・セット: b10gate（mc_wallgate 閉じた 門と 焚き火）・b10hut（小屋）。城の 中は 小道具だけ（props）*/
import { bkAdd } from "./bkeng.js";
import { castAdd, doomed } from "./cast.js";
import { fac, facMark } from "./epfac.js";
import { bldOf, farOf } from "./storyplace.js";
import { ok } from "./ui.js";
import { TW, out, castle, memo, Y, REI, snow, stoneIt, hum, props, putN, V4 as V, has, walkOff } from "./bk_b09.js";

const SGATE = memo(() => out(TW.snow, 0, "雪どけの 町 スノウの 門前"));
const HUT = memo(() => out(TW.snow, 0.9, "スノウの 外れの 小屋"));   /* 第128版: 町は 門を 閉めた（本10-1・10-2）。締め出された 一行が 会うのは 町の 外の 番人の 小屋（建てた セット b10hut）*/
const ROAD = memo(() => farOf("r8road", TW.sanda, "ヘイムダルへの 道", 90, 300) || castle("road", "ヘイムダルへの 道"));
const COURT = memo(() => castle("court", "氷雷の城 ヘイムダルの 中庭"));
const HALL = memo(() => castle("throne", "ヘイムダル 裁きの 間"));
const CGATE = memo(() => castle("gate", "ヘイムダルの 城門"));
const HEIM = ["§b氷王 ヘイム", "heim"], DAL = ["§e雷王 ダル", "dal"];
const king = (K, p, k, w = false) => K.npcNear(p, k[0], K.PJ(k[1], 8), w);
const kingSay = (K, p, k, L, lis) => K.say(p, k[0].replace(/§./g, "").split(" ").pop(), L, lis);

castAdd("b10_koto", { nm: "チセ", role: "スノウの 門番の 子", gobi: "", skin: "m6_pip", town: TW.snow, at: () => { const q = SGATE(); return q ? { x: q.x + 2, z: q.z - 2 } : null; }, hide: (s) => !has(s, "b10e3"),
  after: [
    [(s) => !!s.ending, ["{smile}あの 晩、名前を 聞いたの、ぼくだよ！ ……門の 小窓の 向こうの 声、ずっと 覚えてた。"]],
    [doomed, ["{sad}……ねえ、あの 人は？ 名前を 教えて くれた お姉ちゃん。……どこ？"]],
    [(s) => has(s, "b12e1") && s.ch && s.ch.c10 === "d", ["{smile}門、開いたよ！ 父ちゃんが『王さまが 石板を 預かった から 平気だ』って。"]],
    [(s) => has(s, "b12e1"), ["{sad}……門は まだ 閉まってる。でも、回状に ぼくも 名前を 書いた。字、へたっぴ だけど。"]],
    [() => true, ["{closed}……名前、教えて くれて ありがと。", "{sad}大人は 張り紙の 顔しか 見ない。でも ぼく、声を 聞いたから。"]],
  ] });

bkAdd("b10", [
  /* ---------- 1話 閉まる 門 ---------- */
  { id: "b10e1", t: "閉まる 門", place: SGATE, fac: "b10gate", battles: 0,
    hint: "§9フロストヘイムの §e雪どけの 町 スノウ§f へ 行こう §7（右上の 案内）",
    syn: "スノウの 町は、一行を 見ると 門を 閉めた。塀の 外で 野宿した。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b10gate", "mc_wallgate", 8, Y(K, p)), G = facMark("b10gate", "gate", p.location), FI = facMark("b10gate", "fire", p.location);
      await K.open(p, "雪どけの 町 スノウの 門前", "snow");
      const eH = K.hero(p);
      await K.wide(p, 16);
      await K.say(p, "塀の 上の 門番", ["{shock,!}……袋を 背負った 二人と 一匹。張り紙の 子らだ！", "{angry,up}門を 閉めろーっ！"], eH);
      K.sound(p, "random.door_close", 1); K.sound(p, "random.anvil_land", 0.5, 0.6);
      await K.narr(p, ["§7木の 門が、目の 前で 閉まった。", "§7かんぬきの 落ちる 音が、塀の 向こうから 二度 聞こえた。"]);
      const eR = REI(K, p), eZ = K.cast(p, "b09_zuzu");
      await K.hsay(p, V(K, ["{sad,up}……まだ 何も 言って ないのに。"], ["{sad,up}……まだ、何も 言って いないのに。"], ["{closed}……まだ 何も 言って ない。"], ["{sad,up}……まだ、何も 申し上げて いませんのに。"]), eR);
      await K.say(p, "レイ", ["{closed}……張り紙は、オレたちより 先に 着いてる。"], eH);
      await K.csay(p, "b09_zuzu", ["{sad}……ずびっ。オレが 貼った 張り紙だ。こんな 北まで。"]);
      K.act(eH, "kneel"); K.act(eR, "kneel"); K.sound(p, "fire.ignite", 0.6);
      await K.night(p, K.fwd(p, 4, 1.5, 0.5), "§7塀の 外の 焚き火。雪が、ひと晩じゅう 降った。", "§7……塀の 内側では、だれも 眠れて いなかった ようだ。窓の 灯りが、朝まで 消えなかった。");
      K.act(eH, 0); K.act(eR, 0);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eZ, eR], card: "§7→ 外れの §e小屋§7 に 人が いる らしい", kind: "snow" });
      return true;
    } },
  /* ---------- 2話 証言書 ---------- */
  { id: "b10e2", pv: 128, t: "証言書", place: HUT, fac: "b10hut", battles: 0,
    hint: "§fスノウの §e外れの 小屋§f へ 行こう",
    syn: "外れの 小屋に、セリーヌと ガルムの 手紙が 届いて いた。ガルムの 証言書。「今度は、目の前の 証拠を 信じるのである」。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b10hut", "hut", 8, Y(K, p));
      await K.open(p, "スノウの 外れの 小屋", "snow");
      if (FQ) await K.at(p, FQ, 12, 6, 1.4);
      const eH = K.hero(p), eG = K.npcNear(p, "§7小屋の 番人", K.PJ("guy", 9));
      K.act(eG, "hold"); K.hold(eG, "letter");
      await K.say(p, "小屋の 番人", ["{closed}……張り紙の 子だな。町の 者は 門を 閉めたが、わしは 山の 番人だ。", "{closed,up}砂の 国から 鳥が 来た。『石板の 子へ』と 書いて ある。"], eH);
      await K.give(eG, eH, "letter");
      K.act(eH, "hold");
      await K.hsay(p, V(K, ["{shock,!}……セリーヌさんの 字！ 読むね。"], ["{shock}……セリーヌさんの 字だわ。読むわね。"], ["{closed}……セリーヌの 字。読む。"], ["{shock}……セリーヌさんの 字です。読みます。"]));
      await K.say(p, "セリーヌ（手紙）", ["{smile}北の 町で 張り紙を 見たと 商人から 聞きましたわ。わたくし、黙って いられませんの。", "{angry}もう一通の 密告の 写しを、ガルムに 見せましたわ。……あとは、あの 石頭が 書きますわ。"]);
      K.hold(eH, "scroll"); await K.push(p, eH, 20, 3.2, 1.3);
      await K.say(p, "ガルム（証言書）", ["{closed}サンドリア 衛兵長 ガルム。この 子らを 一度、よそ者と 呼んで 牢に 入れた 者である。", "{angry}わしは 紙を 信じて、目の前の 子を 見なかった。"]);
      await K.say(p, "ガルム（証言書）", ["{closed,up}この 子らは 盗まず、裏切らず、石も 運ばぬ。", "{closed}今度は、目の前の 証拠を 信じるのである。"]);
      K.hold(eH);
      await K.hsay(p, V(K, ["{smile,tears,up}……ガルムさん。……あの 怖い 顔で、これ 書いたんだ。"], ["{smile,tears,up}……ガルムさんが、これを……"], ["{closed,up}……あの 石頭が、これを。"], ["{smile,tears,up}……ガルムさんが、これを 書いて くださったのですね。"]));
      const eR = REI(K, p);
      await K.say(p, "レイ", ["{closed}……それ、なくすなよ。どこかで 裁きが あるなら、いちばん 効く 紙だ。"], eH);
      await K.say(p, "小屋の 番人", ["{closed}町の 門前に 回るがいい。門番の 子が、夜な夜な 小窓から 外を 見とる。"]);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eG], card: "§7→ 夜の §eスノウの 門前§7 へ", kind: "snow" });
      return true;
    } },
  /* ---------- 3話 名前は？ ---------- */
  { id: "b10e3", t: "名前は？", place: SGATE, fac: "b10gate", F: ["F12"], battles: 0,
    hint: "§f夜の §eスノウの 門前§f へ もどろう",
    syn: "門の 内側から、門番の 子が 小声で「……名前は？」と 聞いた。名を 言いかけた とき、相棒が 先に 鳴き、幼なじみが 代わりに 答えた。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b10gate", "mc_wallgate", 8, Y(K, p)), W = facMark("b10gate", "win", p.location);
      await K.open(p, "スノウの 門前（夜）", "night", "night");
      const eH = K.hero(p);
      const win = W || (FQ ? { x: FQ.x, y: FQ.y + 0.5, z: FQ.z } : K.fwd(p, 6, 1.5, 1.6));
      if (ok(eH)) await K.walkCam(p, eH, { x: win.x - 1.4, y: Math.floor(win.y) - 1.5, z: win.z }, 16);
      K.sound(p, "random.door_open", 0.4, 1.6);
      await K.at(p, win, 16, 2.4, 0.4);
      await K.say(p, "小窓の 向こうの 声", ["{closed}……ねえ。張り紙の 人？"]);
      await K.say(p, "小窓の 向こうの 声", ["{?}……名前は？"]);
      /*F12*/ await K.narr(p, ["§7あなたが 名を 言いかけた とき、相棒が 先に 鳴いた。", "§7名前を 呼ばれない 旅が、もう 長く なって いた。"]);
      const g = K.palEnt(p); if (g) { K.sound(p, "mob.wolf.whine", 1); await K.at(p, g.location, 12, 2.4, 0.6); }
      await K.push(p, eH, 20, 3.4, 1.6);
      const nm = String(p.name || "").replace(/§./g, "");
      await K.hsay(p, V(K, [`{smile,up}${nm}。……この 子は、${nm}って いうの。`, "{closed,up}わたしの、いちばん 古い 友だち。"], [`{smile,up}${nm}よ。……この 子の 名前は、${nm}。`, "{closed,up}わたしの、いちばん 古い 友だちなの。"], [`{closed,up}……${nm}。こいつの 名前。`, "{closed}わたしの、いちばん 古い 友だち。"], [`{smile,up}${nm}、と 申します。……この 方の お名前です。`, "{closed,up}わたしの、いちばん 古い 友だちです。"]), win);
      await K.say(p, "小窓の 向こうの 声", [`{smile}……${nm}。`, "{closed}ぼくは チセ。……おやすみ、" + nm + "。"]);
      K.sound(p, "random.door_close", 0.4, 1.6);
      K.rmCine(g);
      await K.hsay(p, V(K, ["{smile,tears}……名前、呼ばれたね。ひさしぶりに。"], ["{smile,tears}……名前を 呼んで もらえたわね。"], ["{closed}……呼ばれたな。名前。"], ["{smile,tears}……お名前を、呼んで もらえましたね。"]));
      if (!ok(p)) return false;
      await K.end(p, { card: "§7→ 朝。§eヘイムダルへの 道§7 へ", kind: "night" });
      return true;
    } },
  /* ---------- 4話 呼び出し状 ---------- */
  { id: "b10e4", pv: 127, t: "呼び出し状", place: ROAD, battles: 0,
    hint: "§fフロストヘイムの §eヘイムダルへの 道§f へ 行こう",
    syn: "城への 道で、王の 使いが 呼び出し状を 届けた。",
    async run(p, d, K) {
      fac(K, p, "b10road", "waypost", 8, Y(K, p));   /* 第126版(PV): 道しるべ（何も ない 野原に しない）*/
      await K.open(p, "ヘイムダルへの 道", "snow");
      snow(K, p, K.fwd(p, 8, 0), 10, 3);
      const eH = K.hero(p), eR = REI(K, p), eZ = K.cast(p, "b09_zuzu");
      const eM = K.npcNear(p, "§b王の 使い", K.PJ("m6_aldo", 9)); K.act(eM, "hold"); K.hold(eM, "scroll");
      await K.say(p, "王の 使い", ["{closed}石板を 運ぶ 旅の 者。氷雷の城 ヘイムダルの 双王より、呼び出しで ある。", "{closed,up}『張り紙の ことで、裁きの 間に 来られたし』。"], eH);
      await K.give(eM, eH, "scroll");
      await K.hsay(p, V(K, ["{shock,?,up}……裁き？ わたしたち、悪い ことは して ないよ！"], ["{shock,?}……裁き？ わたしたち、何も して いないわ。"], ["{closed,?}……裁き。何も して ない。"], ["{shock,?}……裁き、ですか？ わたしたちは 何も……"]), eM);
      await K.say(p, "王の 使い", ["{closed}来なければ、国じゅうの 門が 閉まった まま だ。……来れば、少なくとも 話は できる。"]);
      await walkOff(K, p, eM, 9);
      await K.csay(p, "b09_zuzu", ["{closed,up}……行こう。オレ、証人に なるって 決めた。ずびっ。"], eH);
      await K.say(p, "レイ", ["{closed}逃げ回るより、ましか。……ガルムの 紙、出せる ように しとけ。"], eH);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eZ, eR], card: "§7→ §e氷雷の城 ヘイムダル§7 へ", kind: "snow" });
      return true;
    } },
  /* ---------- 5話 双王 ---------- */
  { id: "b10e5", t: "双王", place: COURT, battles: 0,
    hint: "§e氷雷の城 ヘイムダル§f の 中庭へ 行こう",
    syn: "双王。裁きの 間の 外に、前の 夜に 石に なった 町の 子の 像。ヘイム王「追放」、ダル王「話を 聞け」。",
    async run(p, d, K) {
      await K.open(p, "氷雷の城 ヘイムダル", "castle");
      const eH = K.hero(p);
      const S = K.S(p), q = S ? S.at(6, -2.2) : K.fwd(p, 6, -2.2);
      const eC = await putN(K, p, "§7石に なった 町の 子", "m6_sota", q); await stoneIt(K, p, eC, null, true);
      await K.at(p, q, 18, 4, 0.9);
      await K.narr(p, ["§7裁きの 間の 扉の 前に、小さな 石の 像。", "§7毛布を 抱いた 子どもが、目を 閉じて 笑って いる。……ゆうべ、石に なった 町の 子だと いう。"], eC);
      const eK = king(K, p, HEIM), eD = king(K, p, DAL);
      K.act(eK, "arms");
      await kingSay(K, p, HEIM, ["{angry}石板の 子。おまえたちが 峠を 越えた 夜、この 子は 石に なった。", "{angry,up}理由は 知らぬ。だが、国を 守るのが 王だ。……追放する。"], eH);
      K.act(eD, "palm");
      await kingSay(K, p, DAL, ["{closed}兄上。……話を 聞いてから でも、遅くは ない。", "{closed,up}人を 見ずに 裁けば、張り紙と 同じだ。"], eK);
      await K.two(p, eK, eD, 14);
      await kingSay(K, p, HEIM, ["{angry}聞いて いる 間に、また 子が 石に なったら？"]);
      await kingSay(K, p, DAL, ["{sad}……そのときは、聞いた 責めも 私が 負う。"]);
      await K.push(p, eH, 20, 3.6, 1.6);
      await K.hsay(p, V(K, ["{sad,up}……この 子の 前で、うそは つけない。", "{closed,up}全部 話す。見た ことも、分からない ことも。"], ["{sad,up}……この 子の 前で、ごまかしは できないわ。", "{closed,up}全部 お話し します。"], ["{closed}……この 子の 前で うそは 言えない。", "{closed}全部 話す。"], ["{sad,up}……この 子の 前で、ごまかしは できません。", "{closed,up}すべて お話し します。"]), eD);
      await kingSay(K, p, HEIM, ["{closed}……よかろう。裁きの 間へ。"]);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eK, eD], bye: [eC], card: "§7→ §e裁きの 間§7 へ", kind: "castle" });
      return true;
    } },
  /* ---------- 6話 証人たち ---------- */
  { id: "b10e6", t: "証人たち", place: HALL, battles: 0,
    hint: "§eヘイムダルの 裁きの 間§f へ 行こう",
    syn: "裁きの 間。証人は 三つ。ズズの 告白、ガルムの 証言書、ソウラの ユラの 手紙。",
    async run(p, d, K) {
      props(K, p, "b10hall", [[7, -3, 0, "lectern"], [7, 3, 0, "lectern"], [8, 0, 0, "polished_deepslate"]]);
      await K.open(p, "ヘイムダル 裁きの 間", "castle");
      const eH = K.hero(p), eK = king(K, p, HEIM), eD = king(K, p, DAL), eZ = K.cast(p, "b09_zuzu");
      await kingSay(K, p, DAL, ["{closed}証人は おるか。"], eH);
      K.act(eZ, "raise");
      await K.csay(p, "b09_zuzu", ["{sad,up}オレだ。元 六影の 下の 者、ズズ。", "{closed}張り紙は、オレたちが 貼った。命令書は 参謀の 字だった。……この 子らは、何も 知らない。ずびっ。"], eK);
      await kingSay(K, p, HEIM, ["{angry,low}……六影の 者の 言葉を 信じろと？"]);
      K.act(eH, "show"); K.hold(eH, "scroll");
      await K.hsay(p, V(K, ["{angry,up}じゃあ、これ！ サンドリアの 衛兵長の 証言書！"], ["{closed,up}では、こちらを。サンドリアの 衛兵長の 証言書です。"], ["{closed}……これ。サンドリアの 衛兵長の 証言書。"], ["{closed,up}では、こちらを。サンドリア 衛兵長 ガルムさんの 証言書です。"]), eD);
      if (ok(eH) && ok(eD)) await K.approach(p, eH, eD, 1.6);
      await K.give(eH, eD, "scroll");
      await kingSay(K, p, DAL, ["{closed}……『今度は、目の前の 証拠を 信じるのである』。", "{closed,up}一度 この 子らを 牢に 入れた 男の 字か。"]);
      K.hold(eH);
      /* ユラの 手紙（C08 で 一行 かわる）*/
      const eM = K.npcNear(p, "§7ソウラの 使い", K.PJ("m6_otis", 9)); K.act(eM, "hold"); K.hold(eM, "letter");
      await K.say(p, "ソウラの 使い", ["{closed}冥府の ソウラの 墓守 ユラより、手紙を あずかって まいりました。"], eD);
      const s0 = K.qs(K.load(p) || d), ln = K.chV(s0, "c08", { t: "{closed,up}この 方は、敵の 名を 迎え灯籠に 書いた 人なのです。", y: "{closed,up}この 方は、石に なった 友の 名を 迎え灯籠に 書いた 人なのです。", _: "{closed,up}この 方は、迎え灯籠に 名を 書いた 人なのです。" });
      await K.say(p, "ユラ（手紙）", ["{closed}わたしは 毎朝、死んだ 人の 名を 読む 墓守なのです。", ln]);
      await K.say(p, "ユラ（手紙）", ["{smile}迎える 人を、石運びとは 呼ばないのです。"]);
      await walkOff(K, p, eM, 8);
      await K.two(p, eK, eD, 14);
      await kingSay(K, p, HEIM, ["{closed,…}……張り紙が 六影の 仕業でも、子が 石に なったのは 本当だ。", "{angry}それを、どう 説明する。"]);
      await kingSay(K, p, DAL, ["{closed}……試せば よい。袋の 石板を、ここへ。"]);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eZ], bye: [eK, eD], card: "§7→ 裁きの 間で、§e石板を 調べる§7", kind: "castle", t: 30 });
      return true;
    } },
  /* ---------- 7話 鉛の 箱 ---------- */
  { id: "b10e7", t: "鉛の 箱", place: HALL, battles: 0,
    hint: "§eヘイムダルの 裁きの 間§f で 石板を 調べよう",
    syn: "封じた 石板を 鉛の 箱に 入れると 唸りが 止まり、ふたを 開けると 鳴った。傍聴の 子が うとうとして「このまま」と 言いかけ、ダル王が 肩を たたいた。",
    async run(p, d, K) {
      await K.open(p, "ヘイムダル 裁きの 間", "castle");
      const eH = K.hero(p), eK = king(K, p, HEIM), eD = king(K, p, DAL);
      const eB = K.npcNear(p, "§7箱持ちの 兵", K.PJ("m6_garrett", 9)); K.act(eB, "hold"); K.hold(eB, "box");
      await kingSay(K, p, DAL, ["{closed}鉛の 箱だ。……石板を 出して くれ。"], eH);
      K.act(eH, "show"); K.hold(eH, "tablet");
      const T = ok(eH) ? eH.location : K.fwd(p, 3, 0);
      await K.at(p, T, 12, 1.8, 1.2);
      hum(K, p, { x: T.x, y: T.y + 1.2, z: T.z }, true);
      await K.narr(p, ["§7袋から 出した 石板が、低く 鳴った。紙を めくる ような、遠い 音。", "§7……あなたには 聞こえない。けれど、間の 人たちが 一斉に 顔を 上げた。"], eH);
      const eC = K.npcNear(p, "§7傍聴の 子", K.PJ("m6_leo2", 9)); K.act(eC, "kneel");
      if (ok(eC)) await K.up(p, eC, 10);
      await K.say(p, "傍聴の 子", ["{closed}……あったかい……このまま……"]);
      if (ok(eD) && ok(eC)) await K.approach(p, eD, eC, 1.1, 10);
      K.act(eD, "give"); K.sound(p, "random.pop", 0.8); K.act(eC, "up");
      await kingSay(K, p, DAL, ["{closed}起きて おれ。……言い終える 前に。"], eC);
      await K.say(p, "傍聴の 子", ["{shock,?}……え？ ……ぼく、寝てた？"]);
      /* 箱に 入れる */
      if (ok(eH) && ok(eB)) await K.approach(p, eB, eH, 1.3, 10);
      await K.give(eH, eB, "box"); K.sound(p, "random.chestclosed", 1); K.cmd(p, "stopsound @s");
      await K.at(p, ok(eB) ? eB.location : T, 16, 2.4, 1.2);
      /* 石板の唸り 回 */ await K.narr(p, ["§7ふたを 閉める。……間が、しんと 静まった。", "§7兵が ふたを 少し 開けると、また 遠い 頁の 音。閉めると、止まる。"], eB);
      hum(K, p, ok(eB) ? eB.location : T); K.sound(p, "random.chestopen", 0.7); await K.wait(12); K.sound(p, "random.chestclosed", 0.7);
      K.hold(eH); K.act(eH, 0);
      await K.two(p, eK, eD, 14);
      await kingSay(K, p, DAL, ["{closed}……噂は 半分、本当だった。石板は 夜に 鳴り、近くで 願った 者を 石に する。", "{closed,up}だが 箱に 入れれば、鳴らぬ。……この 子らの 罪では ない。"]);
      await kingSay(K, p, HEIM, ["{angry}罪で なくとも、災いだ。その 石板が この 国に ある かぎり。"]);
      if (!ok(p)) return false;
      await K.end(p, { bye: [eK, eD, eB, eC], card: "§7→ §e裁き§7", kind: "castle", t: 30 });
      return true;
    } },
  /* ---------- 8話 裁き（選択 C10）---------- */
  { id: "b10e8", t: "裁き", place: HALL, battles: 0,
    hint: "§eヘイムダルの 裁きの 間§f で 裁きを 受けよう",
    syn: "ヘイム王は 石板を 城に 預けよと 言い、ダル王は 迷った。封じた 石板を 預けるか、持ったまま 追放を 受けるか。",
    async run(p, d, K) {
      await K.open(p, "ヘイムダル 裁きの 間", "castle");
      const eH = K.hero(p), eK = king(K, p, HEIM), eD = king(K, p, DAL), eR = REI(K, p);
      K.act(eK, "point");
      await kingSay(K, p, HEIM, ["{angry}選べ。石板を この 城に 預けるなら、門を 開けよう。宿も 店も、おまえたちに 開く。", "{angry,up}持って 行くなら、追放だ。この 国の 門は、どこも 開かぬ。"], eH);
      await kingSay(K, p, DAL, ["{sad}……石板は、おまえたちの 戦う 力でも あると 聞く。預ければ、主たちの 技は 使えぬ。"], eK);
      await K.say(p, "レイ", ["{closed,low}……預けりゃ、手ぶらで 北へ。持ってりゃ、どこにも 泊まれない。"], eH);
      await K.push(p, eH, 18, 3.6, 1.6);
      const v = await K.pick(p, "c10");
      if (v === "d") {
        K.act(eH, "give"); K.hold(eH, "box");
        if (ok(eH) && ok(eK)) await K.approach(p, eH, eK, 1.6);
        await K.give(eH, eK, "box");
        await kingSay(K, p, HEIM, ["{closed}……確かに 預かった。門を 開けよ！"]);
        await K.hsay(p, V(K, ["{sad,up}……預けた。戦う 力より、町の 人の 夜を 取った。"], ["{sad,up}……預けたわ。町の 人の 眠りの ほうを 取ったの。"], ["{closed}……預けた。町の 夜の ほうを 取った。"], ["{sad,up}……お預け しました。町の 方々の 夜の ほうを 選びました。"]));
        await kingSay(K, p, DAL, ["{sad,…}……兄上。今夜は、箱の そばで 眠らぬ ように。"]);
        await kingSay(K, p, HEIM, ["{closed}王は、国の 夜を 見張る ものだ。"]);
      } else {
        K.act(eH, "hold"); K.hold(eH, "tablet");
        await K.hsay(p, V(K, ["{closed,up}……持って いく。北で、これが 要るから。"], ["{closed,up}……持って いくわ。北で 必要なの。"], ["{closed}……持って いく。"], ["{closed,up}……持って まいります。北で、必要なのです。"]), eK);
        await kingSay(K, p, HEIM, ["{angry,up}ならば 追放だ。フロストヘイムの 宿も 店も、おまえたちには 開かぬ。"]);
        await kingSay(K, p, DAL, ["{sad}……兄上の 命だ。私には、止められぬ。"]);
        K.hold(eH);
      }
      K.act(eH, 0);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eK, eD], card: "§7→ §eヘイムダルの 城門§7 へ", kind: "castle" });
      return true;
    } },
  /* ---------- 9話 半分は 晴れぬ ---------- */
  { id: "b10e9", t: "半分は 晴れぬ", place: CGATE, F: ["F28"], keys: ["k_leadbox"], battles: 0,
    hint: "§eヘイムダルの 城門§f へ",
    syn: "ダル王「疑いは 半分 晴れた。半分は 晴れぬ。それで いい」。幼なじみ「噂を 流させたのが セオさんでも、それでも 迎えに 行く」。",
    async run(p, d, K) {
      await K.open(p, "ヘイムダルの 城門", "snow");
      const eH = K.hero(p), eD = king(K, p, DAL), eR = REI(K, p);
      const s0 = K.qs(K.load(p) || d), dep = K.chIs(s0, "c10", "d");
      await kingSay(K, p, DAL, [dep ? "{closed}石板は、兄上の 部屋の 箱の 中だ。……門は 開く。宿も 店も 使え。" : "{closed}……門の 外までは、私が 見送る。追放の 身でも、見送りは 禁じられて おらぬ。", "{closed,up}疑いは 半分 晴れた。半分は 晴れぬ。……それで いい。"], eH);
      if (ok(eD) && ok(eH)) await K.give(eD, eH, "box");   /* 第128版(E22): 鉛の 箱を 一つ 渡す（C10 どちらでも）*/
      /*F69*/ await kingSay(K, p, DAL, ["{closed}……鉛の 箱を 一つ やろう。唸る 石板は、これに 入れて 運べ。"], eH);
      K.key(p, "k_leadbox");   /* 第128版(E22): だいじなもの「鉛の 箱」*/
      await kingSay(K, p, DAL, ["{sad}張り紙を 書かせた 者を、おまえたちは 知って いるのだな。"]);
      await K.push(p, eH, 22, 4, 1.6);
      /*F28*/ await K.hsay(p, K.chIs(s0, "c08", "y") ? V(K, ["{closed,up}……うん。赤い 灯籠は、ヨミさんに 使った。", "{smile,tears,up}……でも、セオさんも 迎えに 行く。灯籠が なくても。"], ["{closed,up}……ええ。赤い 迎え灯籠は、ヨミさんに 使ったわ。", "{smile,tears,up}……でも、セオさんも 迎えに 行く。灯籠が なくても。"], ["{closed}……赤い 灯籠は、ヨミに 使った。", "{closed,up}……でも、セオも 迎えに 行く。灯籠が なくても。"], ["{closed,up}……はい。赤い 迎え灯籠は、ヨミさんに 使いました。", "{smile,tears,up}……それでも、セオさんも お迎えに 参ります。灯籠が なくても。"]) : V(K, ["{closed,up}……うん。ソウラで、赤い 灯籠に 名前を 書いた。", "{smile,tears,up}噂を 流させたのが セオさんでも、それでも 迎えに 行く。"], ["{closed,up}……ええ。ソウラで、赤い 迎え灯籠に 名前を 書いたの。", "{smile,tears,up}噂を 流させたのが セオさんでも……それでも、迎えに 行くわ。"], ["{closed}……知ってる。赤い 灯籠に 名前を 書いた。", "{closed,up}噂を 流させたのが セオでも、迎えに 行く。"], ["{closed,up}……はい。ソウラで、赤い 迎え灯籠に お名前を 書きました。", "{smile,tears,up}噂を 流させたのが セオさんでも……それでも、お迎えに 参ります。"]), eD);
      await kingSay(K, p, DAL, ["{smile}……迎え灯籠か。冥府の 風習だな。", "{closed}北の 雪山の 里 サンダで、雷祭りの 支度を して いる。山案内人が おる。……寄って いけ。"]);
      await K.say(p, "レイ", ["{closed}……雪山か。……行こう。"], eH);   /* 第128版: 回し者は 雪山の ことを 言って いない */
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eD], card: "§f― 第10章 閉じた門 おわり ―\n§7→ 雪山の §eらいうんの 里 サンダ§7 へ", kind: "snow", t: 60 });
      return true;
    } },
]);
