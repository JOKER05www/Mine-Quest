// v3.0: 地方ごとの 景色（バニラの 地形の 上を、地方の 名前に あう 地面・草花・木に ぬりかえる）
// プレイヤーの いる あたりを 32×32 ずつ、1秒に 1か所だけ（重くしない）。建物・ステージ・洞くつの まわりは さわらない。
import { world, system } from "@minecraft/server";
import { inRuins } from "./ruinsarea.js";
import { WREGIONS, regionIdxAt, regionIdx, landSites } from "./worldmap.js";
import { hooks } from "./field.js";
import { inLiveBox, stageNear } from "./stage.js";
import { busy, warming, isLite } from "./ui.js";
import { building, siteOf } from "./structures.js";
// 遺跡の 近く（遺跡は 384ごとに 1つ）
const ruinNear = (x, z) => { try { const rx = Math.floor(x / 176), rz = Math.floor(z / 176); for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) { const s = siteOf("minecraft:overworld", rx + dx, rz + dz); if (Math.hypot(s.x - x, s.z - z) < 60) return true; } } catch {} return false; };
// プレイヤーが 作った ものが ある 所は ぬらない
const ART = /planks|glass|brick|wool|concrete|glazed|chest|door|fence|slab|stairs|torch|lantern|bed|crafting|furnace|farmland|_wall|carpet|grass_path|dirt_path|rail|sign|barrel|bookshelf|hay_block|smooth_|polished_|cut_|chiseled_/;

const CELL = 32;
// v3.0: 地方ごとの 決まり（地面・下の 土・石・草花・葉・幹・氷）。見つかった 自然の ブロックだけを 置きかえる
const SURF = /^(grass_block|grass|dirt_with_roots|rooted_dirt|podzol|mycelium|coarse_dirt|moss_block|mud|sand|red_sand|gravel|snow|powder_snow|clay|hardened_clay|stained_hardened_clay|(white|orange|yellow|red|brown|light_gray|gray|black)_terracotta|terracotta)$/;
const SUB = /^(dirt|sandstone|red_sandstone)$/;
const STONE = /^(stone|andesite|diorite|granite|tuff|calcite|dripstone_block)$/;
const PLANT = /^(short_grass|tallgrass|tall_grass|fern|large_fern|deadbush|dandelion|poppy|red_flower|yellow_flower|blue_orchid|allium|azure_bluet|red_tulip|orange_tulip|white_tulip|pink_tulip|oxeye_daisy|cornflower|lily_of_the_valley|sweet_berry_bush|sunflower|lilac|rose_bush|peony|double_plant|brown_mushroom|red_mushroom|pink_petals|snow_layer|azalea|flowering_azalea|cactus|bush)$/;
const LEAF = /^(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry|azalea)_leaves$|^azalea_leaves_flowered$|^leaves2?$/;
const LOG = /^(oak|spruce|birch|jungle|acacia|dark_oak|mangrove|cherry)_log$/;
const ICE = /^(ice|packed_ice|blue_ice)$/;
const GREEN = /^(snow|powder_snow|mycelium|red_sand|podzol|coarse_dirt|clay|hardened_clay|stained_hardened_clay|[a-z_]*terracotta)$/;   // 草原に なる もの（砂・砂利は 川底なので のこす）
// m(id, par) → 置きかえ先（null は そのまま）。par は 市松模様（0/1）
const RULE = {
  arca: (id, b, top) => GREEN.test(id) || (top && /^(sand|red_sand|sandstone)$/.test(id)) ? "grass_block" : id === "snow_layer" || id === "cactus" ? "air" : id === "deadbush" ? "short_grass" : ICE.test(id) ? "water" : null,
  celes: (id, b, top) => GREEN.test(id) || (top && /^(sand|red_sand|gravel|sandstone)$/.test(id)) ? "grass_block" : id === "snow_layer" || id === "cactus" || id === "deadbush" ? "air" : ICE.test(id) ? "water" : null,
  silva: (id, b, top) => (GREEN.test(id) || id === "grass_block" || (top && /^(sand|red_sand|sandstone)$/.test(id))) && id !== "clay" ? (b ? "mud" : "moss_block") : id === "snow_layer" || id === "cactus" ? "air" : id === "deadbush" ? "fern" : ICE.test(id) ? "water" : null,
  mari: (id) => /^(grass_block|grass|moss_block|mud|dirt_with_roots|rooted_dirt|snow|powder_snow|podzol|mycelium|red_sand|clay|hardened_clay|stained_hardened_clay|[a-z_]*terracotta)$/.test(id) ? "sand" : id === "coarse_dirt" ? "gravel" : id === "dirt" ? "sandstone" : PLANT.test(id) ? "air" : (LEAF.test(id) || LOG.test(id)) && !/^jungle/.test(id) ? "air" : ICE.test(id) ? "water" : null,   /* 第125版: 海の 地方は 草原に しない（砂浜・砂利の 浜）*/
  ruins: (id, b) => SURF.test(id) && id !== "sand" && id !== "gravel" && id !== "coarse_dirt" ? (b ? "gravel" : "coarse_dirt") : PLANT.test(id) && id !== "deadbush" ? (id === "short_grass" && b ? "deadbush" : "air") : LEAF.test(id) ? "air" : null,
  volka: (id, b) => SURF.test(id) ? (b ? "basalt" : "blackstone") : SUB.test(id) ? "basalt" : STONE.test(id) ? (b ? "blackstone" : "basalt") : PLANT.test(id) || LEAF.test(id) ? "air" : LOG.test(id) ? "basalt" : ICE.test(id) ? "obsidian" : null,
  sand: (id, b) => SURF.test(id) && id !== "sand" ? (b && id === "red_sand" ? null : "sand") : id === "dirt" ? "sandstone" : PLANT.test(id) && id !== "deadbush" && id !== "cactus" ? (b ? "deadbush" : "air") : LEAF.test(id) || LOG.test(id) ? "air" : ICE.test(id) ? "sandstone" : null,
  crys: (id, b) => SURF.test(id) ? (b ? "tuff" : "calcite") : SUB.test(id) ? "tuff" : PLANT.test(id) || LEAF.test(id) || LOG.test(id) ? "air" : ICE.test(id) ? "calcite" : null,
  necro: (id, b) => SURF.test(id) ? (b ? "soul_sand" : "soul_soil") : SUB.test(id) ? "soul_soil" : PLANT.test(id) || LEAF.test(id) ? "air" : ICE.test(id) ? "soul_soil" : null,
  frost: (id) => SURF.test(id) && id !== "snow" && id !== "gravel" ? "snow" : PLANT.test(id) && id !== "snow_layer" ? "snow_layer" : LEAF.test(id) && id !== "spruce_leaves" ? "spruce_leaves" : LOG.test(id) && id !== "spruce_log" ? "spruce_log" : null,
  ragna: (id, b) => SURF.test(id) ? (b ? "warped_nylium" : "crimson_nylium") : SUB.test(id) || STONE.test(id) ? (b ? "blackstone" : "netherrack") : PLANT.test(id) ? "air" : LEAF.test(id) ? (b ? "warped_wart_block" : "nether_wart_block") : LOG.test(id) ? (b ? "warped_stem" : "crimson_stem") : ICE.test(id) ? "magma" : null,
};
export const regionRule = (rid) => RULE[rid] || null;
// 草花・木
const PAL = {
  arca: { on: ["grass_block"], flora: ["short_grass", "short_grass", "short_grass", "poppy", "dandelion", "cornflower", "oxeye_daisy", "azure_bluet", "lily_of_the_valley", "tall_grass"], fn: 14, tree: "oak", tn: 1 },
  silva: { on: ["moss_block", "mud"], flora: ["fern", "fern", "moss_carpet", "moss_carpet", "blue_orchid", "fern", "large_fern"], fn: 16, water: "waterlily", tree: "swamp", tn: 2 },
  ruins: { on: ["coarse_dirt", "gravel"], flora: ["deadbush", "deadbush", "cobblestone", "mossy_cobblestone"], fn: 6 },
  volka: { on: ["blackstone", "basalt"], flora: ["magma", "blackstone_wall", "magma"], fn: 5 },
  sand: { on: ["sand"], flora: ["deadbush", "deadbush", "cactus"], fn: 6 },
  crys: { on: ["calcite", "tuff"], flora: ["amethyst_cluster", "large_amethyst_bud", "amethyst_block"], fn: 6 },
  mari: { on: ["sand"], flora: ["sea_pickle", "sea_pickle", "stripped_oak_wood", "tuff", "gravel"], fn: 6, tree: "palm", tn: 1, pool: 2 },   /* 第125版: シーピクルス・流木・岩・潮だまり */
  necro: { on: ["soul_soil", "soul_sand"], flora: ["wither_rose", "bone_block", "wither_rose"], fn: 5 },
  frost: { on: ["snow"], flora: ["snow_layer", "snow_layer", "snow_layer"], fn: 6, tree: "spruce", tn: 1 },
  ragna: { on: ["crimson_nylium", "warped_nylium"], flora: ["crimson_roots", "warped_roots", "crimson_fungus", "warped_fungus"], fn: 8 },
  celes: { on: ["grass_block"], flora: ["white_tulip", "lily_of_the_valley", "azure_bluet", "oxeye_daisy", "allium", "short_grass"], fn: 14, tree: "cherry", tn: 1 },
};
const KEY = (id) => (id === "mari" ? "mrpg:rs3_mari" : `mrpg:rs2_${id}`);   /* 第125版: 海の 地方は 塗りなおす */   // v3.0: 決まりを 広げたので 塗りなおす
const MEM = new Map();
function bits(id, n) { if (!MEM.has(id)) { let s = ""; try { s = world.getDynamicProperty(KEY(id)) || ""; } catch {} MEM.set(id, (s + "0".repeat(n)).slice(0, n).split("")); } return MEM.get(id); }
function setBit(id, i, v = "1") { const b = MEM.get(id); if (!b) return; b[i] = v; try { world.setDynamicProperty(KEY(id), b.join("")); } catch {} }
function spawnPt() { try { const s = world.getDefaultSpawnLocation(); return { x: s.x, z: s.z }; } catch { return { x: 0, z: 0 }; } }
const run = (dim, c) => { try { dim.runCommand(c); return true; } catch { return false; } };
const loadedAt = (dim, x, z) => { try { return !!dim.getBlock({ x, y: 64, z }); } catch { return false; } };
const top = (dim, x, z) => { try { return dim.getTopmostBlock?.({ x, z }) || null; } catch { return null; } };
function nearSite(i, x, z) {
  try { for (const L of landSites(i)) if (Math.hypot(L.x - x, L.z - z) < 70) return true; } catch {}
  return false;
}
// 小さな 木（コマンドで 組む）
function treeCmds(kind, x, y, z) {
  const C = [];
  if (kind === "oak" || kind === "cherry") {
    const log = kind === "oak" ? "oak_log" : "cherry_log", lv = kind === "oak" ? "oak_leaves" : "cherry_leaves";
    C.push(`fill ${x - 2} ${y + 3} ${z - 2} ${x + 2} ${y + 4} ${z + 2} ${lv} keep`, `fill ${x - 1} ${y + 5} ${z - 1} ${x + 1} ${y + 5} ${z + 1} ${lv} keep`, `fill ${x} ${y} ${z} ${x} ${y + 4} ${z} ${log}`);
  } else if (kind === "spruce") {
    C.push(`fill ${x - 2} ${y + 2} ${z - 2} ${x + 2} ${y + 2} ${z + 2} spruce_leaves keep`, `fill ${x - 1} ${y + 4} ${z - 1} ${x + 1} ${y + 4} ${z + 1} spruce_leaves keep`, `setblock ${x} ${y + 6} ${z} spruce_leaves keep`, `fill ${x} ${y} ${z} ${x} ${y + 5} ${z} spruce_log`, `fill ${x - 1} ${y + 3} ${z - 1} ${x + 1} ${y + 3} ${z + 1} snow_layer keep`);
  } else if (kind === "swamp") {
    C.push(`fill ${x - 2} ${y + 3} ${z - 2} ${x + 2} ${y + 4} ${z + 2} mangrove_leaves keep`, `fill ${x} ${y} ${z} ${x} ${y + 4} ${z} mangrove_log`, `setblock ${x + 1} ${y} ${z} mangrove_roots keep`, `setblock ${x - 1} ${y} ${z} mangrove_roots keep`);
  } else if (kind === "palm") {
    C.push(`fill ${x} ${y} ${z} ${x} ${y + 4} ${z} jungle_log`, `fill ${x - 2} ${y + 5} ${z} ${x + 2} ${y + 5} ${z} jungle_leaves keep`, `fill ${x} ${y + 5} ${z - 2} ${x} ${y + 5} ${z + 2} jungle_leaves keep`, `setblock ${x} ${y + 6} ${z} jungle_leaves keep`);
  }
  return C;
}
let painting = 0;   // ぬって いる 間は つぎを はじめない（tick を おぼえて おき、ながく 止まったら 解除）
// 重い 処理は system.runJob で 少しずつ（ない 版では 1tickに 1歩）
function runSteps(gen) {
  if (typeof system.runJob === "function") { try { system.runJob(gen); return; } catch {} }
  const step = () => { let r; try { r = gen.next(); } catch { return; } if (!r.done) system.runTimeout(step, 1); };
  step();
}
function* paintJob(dim, rid, ox, oz, cx, cz) {
  try {
    const P = PAL[rid], M = RULE[rid]; if (!P || !M) return;
    const sy = top(dim, ox + CELL / 2, oz + CELL / 2); if (!sy) return;
    const y0 = sy.location.y, y1 = Math.max(-60, y0 - 12), y2 = Math.min(318, y0 + 30);
    // 16×16 ごとに: プレイヤーの 作った ものが あれば その 16×16 だけ とばす。ある 自然の ブロックを 見つけて その 種類だけ 置きかえる
    for (let sx = 0; sx < CELL; sx += 16) for (let sz = 0; sz < CELL; sz += 16) {
      const x1 = ox + sx, z1 = oz + sz, x2 = x1 + 15, z2 = z1 + 15;
      let art = false; const found = new Set(), tops = new Set();
      for (let i = 1; i < 16 && !art; i += 3) {
        for (let j = 1; j < 16; j += 3) {
          const t = top(dim, x1 + i, z1 + j); if (!t) continue;
          const id0 = t.typeId.replace("minecraft:", ""); if (ART.test(id0)) { art = true; break; }
          found.add(id0); tops.add(id0);
          for (let d = 1; d <= 4; d++) { try { const b = dim.getBlock({ x: x1 + i, y: t.location.y - d, z: z1 + j }); if (b) found.add(b.typeId.replace("minecraft:", "")); } catch {} }
        }
        yield;
      }
      if (art) continue;
      const par = ((cx * 2 + sx / 16) + (cz * 2 + sz / 16)) & 1;
      let k = 0;
      for (const id of found) { const to = M(id, par, tops.has(id)); if (to && to !== id) { run(dim, `fill ${x1} ${y1} ${z1} ${x2} ${y2} ${z2} ${to} replace ${id}`); if (++k % 3 === 0) yield; } }
      yield;
    }
    // 草花・木
    let seed = (Math.imul(cx, 73856093) ^ Math.imul(cz, 19349663)) >>> 0;
    const rnd = () => { seed = (Math.imul(seed, 1103515245) + 12345) >>> 0; return seed / 4294967296; };
    for (let k = 0; k < (P.fn || 0); k++) {
      const x = ox + Math.floor(rnd() * CELL), z = oz + Math.floor(rnd() * CELL);
      const t = top(dim, x, z); if (!t) continue;
      const id = t.typeId.replace("minecraft:", "");
      if (P.water && /water/.test(id)) { if (rnd() < 0.5) run(dim, `setblock ${x} ${t.location.y + 1} ${z} ${P.water} keep`); continue; }
      if (!P.on.includes(id)) continue;
      run(dim, `setblock ${x} ${t.location.y + 1} ${z} ${P.flora[Math.floor(rnd() * P.flora.length)]} keep`);
    }
    yield;
    /* 第125版: 潮だまり（平らな 砂浜の 3×3 を 2段の 水に。まわり 5×5 が 同じ 高さの 砂の ときだけ・あふれない）*/
    for (let k = 0; k < (P.pool || 0); k++) {
      const x = ox + 3 + Math.floor(rnd() * (CELL - 6)), z = oz + 3 + Math.floor(rnd() * (CELL - 6));
      const t = top(dim, x, z); if (!t || t.typeId !== "minecraft:sand") continue;
      const y = t.location.y; let flat = true;
      for (let dx = -2; dx <= 2 && flat; dx++) for (let dz = -2; dz <= 2; dz++) { const q = top(dim, x + dx, z + dz); if (!q || q.location.y !== y || !/sand|gravel/.test(q.typeId)) { flat = false; break; } }
      if (!flat) continue;
      run(dim, `fill ${x - 1} ${y - 1} ${z - 1} ${x + 1} ${y} ${z + 1} water replace sand`);
      run(dim, `fill ${x} ${y - 1} ${z} ${x} ${y - 1} ${z} kelp replace water`);
      run(dim, `fill ${x + 1} ${y - 1} ${z} ${x + 1} ${y - 1} ${z} seagrass replace water`);
      run(dim, `setblock ${x - 2} ${y + 1} ${z} sea_pickle keep`);
      yield;
    }
    for (let k = 0; k < (P.tn || 0); k++) {
      if (rnd() < 0.45) continue;
      const x = ox + 4 + Math.floor(rnd() * (CELL - 8)), z = oz + 4 + Math.floor(rnd() * (CELL - 8));
      const t = top(dim, x, z); if (!t) continue;
      const id = t.typeId.replace("minecraft:", "");
      if (!P.on.includes(id) && !(P.tree === "palm" && id === "sand")) continue;
      for (const c of treeCmds(P.tree, x, t.location.y + 1, z)) run(dim, c);
      yield;
    }
  } finally { painting = 0; }
}
function paintCell(dim, rid, ox, oz, cx, cz) {
  if (!PAL[rid] || !RULE[rid]) return true;
  if (!top(dim, ox + CELL / 2, oz + CELL / 2)) return false;
  painting = tick;
  runSteps(paintJob(dim, rid, ox, oz, cx, cz));
  return true;
}
let tick = 0;
system.runInterval(() => {
  tick++;
  if (painting && tick - painting < 30) return;   // 前の 所を ぬって いる（30秒 たっても 終わらなければ つぎへ）
  if (warming() || building()) return;   // 町・城・遺跡を 作って いる あいだ・前の 所を ぬって いる あいだは 待つ
  const ow = world.getDimension("overworld"), S = spawnPt();
  let done = 0; const PL = world.getAllPlayers(), off = tick % Math.max(1, PL.length), cap = isLite() ? (tick % 3 === 0 ? 1 : 0) : 1;
  for (let j = 0; j < PL.length; j++) {   // マルチでも 順番に（1秒に 1か所）
    const p = PL[(j + off) % PL.length];
    if (done >= cap) break;
    try {
      if (busy.has(p.id) || p.dimension.id !== "minecraft:overworld" || inRuins(p.location)) continue;
      const loc = p.location, ri = regionIdxAt(loc), R = WREGIONS[ri]; if (!R || !PAL[R.id]) continue;
      const rx = loc.x - S.x - R.c[0], rz = loc.z - S.z - R.c[1];
      const N = Math.ceil((R.r * 2) / CELL);
      // 自分の まわり 3×3 で まだ ぬって いない 所を 1つ
      const gx0 = Math.floor((rx + R.r) / CELL), gz0 = Math.floor((rz + R.r) / CELL);
      const B = bits(R.id, N * N);
      let pick = null;
      for (const [dx, dz] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1], [2, 0], [-2, 0], [0, 2], [0, -2]]) {
        const gx = gx0 + dx, gz = gz0 + dz;
        if (gx < 0 || gz < 0 || gx >= N || gz >= N) continue;
        const idx = gz * N + gx; if (B[idx] !== "0") continue;
        const ox = Math.floor(S.x + R.c[0] - R.r + gx * CELL), oz = Math.floor(S.z + R.c[1] - R.r + gz * CELL);
        const mx = ox + CELL / 2, mz = oz + CELL / 2;
        if (Math.hypot(mx - S.x - R.c[0], mz - S.z - R.c[1]) > R.r * 1.1 || regionIdx(mx - S.x, mz - S.z) !== ri) { B[idx] = "2"; continue; }   // 地方の 外（となりの 地方と 重なる 所は その 地方が ぬる）
        if (stageNear(mx, mz, 60) || inLiveBox("minecraft:overworld", { x: mx, y: 64, z: mz })) continue;   // いまだけ → あとで もう一度
        if (!loadedAt(ow, ox, oz) || !loadedAt(ow, ox + CELL - 1, oz + CELL - 1)) continue;   // 読みこまれて いない 所は とばして となりを
        pick = { idx, gx, gz, ox, oz, mx, mz }; break;
      }
      if (!pick) continue;
      const { idx, gx, gz, ox, oz, mx, mz } = pick;
      // 町・城・遺跡・ステージ・洞くつ・家・戦い中の 場所は さわらない
      const skip = (hooks.noDig && hooks.noDig({ x: mx, y: 64, z: mz }, ow)) || nearSite(ri, mx, mz) || ruinNear(mx, mz);   // v3.0: 地方の ステージ・遺跡の 地面は その テーマの まま   // v3.0: 町・城・遺跡の まわりも 地方の 景色に（建物の ある 16×16は paintCell が とばす）
      if (skip) { setBit(R.id, idx, "2"); done++; continue; }
      if (!loadedAt(ow, ox, oz) || !loadedAt(ow, ox + CELL - 1, oz + CELL - 1)) continue;
      const r = paintCell(ow, R.id, ox, oz, gx, gz);
      if (r === "skip") { setBit(R.id, idx, "2"); done++; } else if (r) { setBit(R.id, idx, "1"); done++; }
    } catch {}
  }
}, 20);
