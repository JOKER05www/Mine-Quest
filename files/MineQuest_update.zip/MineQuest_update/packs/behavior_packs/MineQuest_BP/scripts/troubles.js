// 第106版: 町の トラブル。町や 城の 中を 歩いて いると、ときどき 事件が 起きる
// ナンパ・スリ・酔っぱらいの けんか・迷子・食い逃げ・六影の カツアゲ・自称勇者。話しかけて 解決すると お礼（道具と 少しの お金）
import { world, system } from "@minecraft/server";
import { personName, nearNpcs } from "./names.js";
import { ITEMS, EGGS } from "./data.js";
import { load, save } from "./store.js";
import { busy, ok, choose, notice, ICON, giveItem, sound, barNote, isLite } from "./ui.js";
import { NPC_HOOKS } from "./npchook.js";
import { PSKIN } from "./skinjobs.js";
import { __walk } from "./citylife.js";
import { regionLv } from "./worldmap.js";
import { rankCap, storyLootOk } from "./quest.js";
import { giveGold, dayNo } from "./explore.js";
import { inBattle } from "./battle.js";
import { storyQuiet } from "./townlife.js";   /* 第117版 */
import { boon } from "./boon.js";   /* 第124版 */

const OW = () => world.getDimension("minecraft:overworld");
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const B = (t, i = "i_party") => [t, ICON(i)];
const say = (p, who, l) => { try { p.sendMessage(`§e${who}§f「${l}」`); } catch {} };

export const TR = { fight: null };   /* テスト用に 差しかえ できる */
export const EV = new Map();   /* 人id → { k, actors:[{e,key,nm,role}], at, t, st, ... } */
const CD = new Map();
const COOL = () => (isLite() ? 300 : 180) * 1000;

// ---------- お礼 ----------
function reward(p, mult = 1, noGold = false) {
  const d = load(p); if (!d) return "";
  const lv = Math.max(1, Math.floor(regionLv(p.location) || 1));
  /* 第124版: お礼は 道具が 主（お金は 少しだけ）。道具は 1日 6回まで（あとは 少しの お金だけ）*/
  const g = Math.floor((20 + lv * 3) * mult); const got = noGold ? [] : [giveGold(d, g)];   /* 第124版: お金を 払った ときは お金を 返さない（道具だけ）*/
  let c = {}; try { c = JSON.parse(p.getDynamicProperty("mrpg:trb") || "{}"); } catch {} if (!c || typeof c !== "object") c = {}; const dn = dayNo(); if (c.d !== dn || typeof c.n !== "number") c = { d: dn, n: 0 };
  if (c.n < 6) { c.n++; try { p.setDynamicProperty("mrpg:trb", JSON.stringify(c)); } catch {} got.push(boon(p, d, mult >= 1.3 ? 2 : 1)); }
  save(p, d); sound(p, "random.levelup", 1.2);
  return got.join("§f・");
}

// ---------- 人を 出す ----------
function put(key, at, extra = "") {
  const S = PSKIN[key]; if (!S) return null;
  let e; try { e = OW().spawnEntity("mrpg:npc", at); } catch { return null; }
  const nm = personName(S[1], S[2], nearNpcs(at));   /* 第106版: 同じ 見た目でも 名前は ちがう */
  try { e.setProperty("mrpg:job", S[0]); e.nameTag = `§6${nm}${extra}`; e.addTag("mrpg_npc"); e.addTag("mrpg_walker"); e.addTag("mrpg_trouble"); } catch {}
  return { e, key, nm, x: at.x, y: at.y, z: at.z };
}
function face(a, b) { try { if (ok(a.e)) a.e.teleport({ x: a.x, y: a.y, z: a.z }, { facingLocation: { x: b.x, y: b.y + 1.5, z: b.z } }); } catch {} }
function endEv(pid, msg) {
  const E = EV.get(pid); if (!E) return; EV.delete(pid);
  for (const a of E.actors) try { if (ok(a.e)) a.e.remove(); } catch {}
  if (msg) { const p = world.getAllPlayers().find((x) => x.id === pid); if (p) try { barNote(p).setActionBar(msg); } catch {} }
}
/* 町の 道の 点から、人から 6〜14 はなれた 点を えらぶ */
function spotNear(p) {
  for (const A of __walk.areas()) {
    if (hv(p.location, A) > A.r) continue;
    const L = []; for (const R of A.w) for (const P of R) { const q = { x: A.x + P[0] + 0.5, y: A.y + P[1], z: A.z + P[2] + 0.5 }; const d = hv(q, p.location); if (d > 6 && d < 14) L.push(q); }
    if (L.length) return { at: pick(L), A };
  }
  return null;
}
function farSpot(A, from, min = 18) {
  const L = []; for (const R of A.w) for (const P of R) { const q = { x: A.x + P[0] + 0.5, y: A.y + P[1], z: A.z + P[2] + 0.5 }; if (hv(q, from) > min) L.push(q); }
  return L.length ? pick(L) : null;
}
const off = (at, dx, dz) => ({ x: at.x + dx, y: at.y, z: at.z + dz });

// ---------- 事件の 種類 ----------
const GIRLS = ["rosa", "shiori", "milk", "hanna", "zenia", "luna", "sakura", "emma"];
const KINDS = {
  nanpa: { w: 3, start(p, at) {
    const c = put(pick(["chara", "chara2"]), at), g = put(pick(GIRLS), off(at, 1.4, 0.6)); if (!c || !g) return null;
    face(c, g); face(g, c);
    return { actors: [c, g], note: "§d女の子が しつこく 声を かけられて いる……", lines: [[c, pick(["ねえねえ、お茶しない？ おごるよ〜（おごらない）", "君、モンスターで 言うと Sランクだね！", "今日の 星座占い、オレと 出会うって 書いて あったでしょ？"])], [g, pick(["や、やめてください……", "急いで いるので……", "（目で 助けを 求めて いる）"])]] };
  } },
  thief: { w: 2, start(p, at, A) {
    const m = put(pick(["zenia", "godo", "marco"]), at), t = put("thief", off(at, 2, 1)); if (!m || !t) return null;
    return { actors: [m, t], run: t, A, note: "§cスリだ！ 走って 追いつけ！", lines: [[m, "スリよー！ だれか 捕まえてー！"], [t, "へへっ、いただきっ！"]], limit: 60 };
  } },
  dash: { w: 2, start(p, at, A) {
    const m = put("marco", at), t = put("dash", off(at, 2, -1)); if (!m || !t) return null;
    return { actors: [m, t], run: t, A, note: "§c食い逃げだ！ 走って 追いつけ！", lines: [[m, "食い逃げだー！ 十人前 食って 逃げたぞー！"], [t, "ごちそうさまでしたーっ！"]], limit: 60 };
  } },
  drunk: { w: 2, start(p, at) {
    const a = put("drunk", at), b = put("drunk2", off(at, 1.6, 0)); if (!a || !b) return null;
    face(a, b); face(b, a);
    return { actors: [a, b], hop: true, note: "§6酔っぱらいが けんかを して いる……", lines: [[a, "なんだと、このハゲ！ ヒック"], [b, "ハゲじゃない！ 頭の 毛が 自由に なっただけだ！ ヒック"]] };
  } },
  lost: { w: 2, start(p, at, A) {
    const c = put(pick(["mimi", "taro"]), at); const far = farSpot(A, at, 18); if (!c || !far) { if (c) try { c.e.remove(); } catch {} return null; }
    return { actors: [c], child: c, far, A, note: "§b子どもが 泣いて いる……", lines: [[c, "ママぁ……どこぉ……"]], limit: 240 };
  } },
  nox: { w: 2, start(p, at) {
    const n = put(pick(["noxa", "noxb"]), at), v = put(pick(["ed", "toma", "kanon", "milk"]), off(at, 1.4, 0)); if (!n || !v) return null;
    face(n, v); face(v, n);
    return { actors: [n, v], note: "§5六影が 町の 人を おどして いる！", lines: [[n, "星の かけらを 持ってるだろ？ 出しな！"], [v, "も、持って いませんよ……！"]] };
  } },
  hero: { w: 1, start(p, at) {
    const h = put("hero", at); if (!h) return null;
    return { actors: [h], note: "§e変な 人が こっちを 見て いる……", lines: [[h, "そこの 君！ 勇者の 私と 勝負したまえ！ （職業: 自称）"]] };
  } },
};
function roll() { const L = []; for (const k in KINDS) for (let i = 0; i < KINDS[k].w; i++) L.push(k); return pick(L); }

// ---------- 20秒ごと: 事件を 起こす ----------
system.runInterval(() => {
  const now = Date.now();
  for (const p of world.getAllPlayers()) {
    try {
      if (p.dimension.id !== "minecraft:overworld" || EV.has(p.id) || busy.has(p.id) || (CD.get(p.id) || 0) > now || inBattle(p) || storyQuiet(p)) continue;
      if (Math.random() > 0.4) continue;
      { const dd = load(p); if (!dd || !(dd.party || []).length) continue; }   /* 第106版: 最初の 仲間を 選ぶ 前は 起こさない */
      const s = spotNear(p); if (!s) continue;
      const k = roll(), E = KINDS[k].start(p, s.at, s.A); CD.set(p.id, now + COOL());
      if (!E) continue;
      E.k = k; E.t = 0; E.st = "wait"; E.at = s.at; E.limit = E.limit || 75; EV.set(p.id, E);
      try { barNote(p).setActionBar(E.note); } catch {}
      sound(p, "note.pling", 0.7);
      for (const [a, l] of E.lines) say(p, a.nm, l);
    } catch {}
  }
}, 400);

// ---------- 4tickごと: 動き（逃げる・ついて くる・けんか）----------
system.runInterval(() => {
  for (const [pid, E] of EV) {
    const p = world.getAllPlayers().find((x) => x.id === pid);
    if (!p || !E.actors.every((a) => ok(a.e))) { endEv(pid); continue; }
    if (globalThis.__mqStageZ?.has(pid)) continue;   /* 第127版: 物語の 場面の あいだは 止める（ついて くる 子・逃げる 人が 舞台に 入らない）*/
    E.t++;
    if (E.st === "wait" && E.t > E.limit * 5) { endEv(pid, "§7さわぎは おさまった……"); continue; }
    if (hv(p.location, E.at) > 48 && !E.child) { endEv(pid, "§7さわぎから 離れた"); continue; }
    if (E.hop) for (const a of E.actors) { try { a.e.teleport({ x: a.x, y: a.y + (E.t % 4 < 2 ? 0.3 : 0), z: a.z }); face(a, E.actors.find((b) => b !== a)); } catch {} }
    if (E.run && E.st === "wait") {   /* 人から 遠ざかる 向きへ 走る（町の 外へは 出ない） */
      const r = E.run, d = hv(r, p.location);
      if (d < 2.4) { E.st = "caught"; try { r.e.setProperty("mrpg:mv", false); } catch {} face(r, p.location); say(p, r.nm, E.k === "dash" ? "ひぃっ！ お、お腹が すいてて……" : "ちぇっ、足の 速い やつだ……"); sound(p, "random.orb", 1); try { barNote(p).setActionBar("§a追いついた！ 話しかけよう"); } catch {} continue; }
      if (!r.goal || hv(r, r.goal) < 1 || E.t % 25 === 0) r.goal = farSpot(E.A, p.location, 10) || r.goal;
      if (r.goal) { const dx = r.goal.x - r.x, dz = r.goal.z - r.z, dd = Math.hypot(dx, dz) || 1, v = d < 8 ? 0.42 : 0.3; r.x += (dx / dd) * Math.min(v, dd); r.z += (dz / dd) * Math.min(v, dd); r.y += (r.goal.y - r.y) * 0.3; try { r.e.teleport({ x: r.x, y: r.y, z: r.z }, { facingLocation: { x: r.goal.x, y: r.goal.y + 1.5, z: r.goal.z } }); r.e.setProperty("mrpg:mv", true); } catch {} }
      if (E.t > E.limit * 5) { endEv(pid, "§7逃げられて しまった……"); continue; }
    }
    if (E.child && E.st === "follow") {   /* 子どもが ついて くる。親の 近くへ 連れて いく */
      const c = E.child, L = p.location, d = hv(c, L);
      if (d > 2.2) { const k = Math.min(0.4, d - 2) / d; c.x += (L.x - c.x) * k; c.z += (L.z - c.z) * k; c.y += (L.y - c.y) * 0.4; }
      try { c.e.teleport({ x: c.x, y: c.y, z: c.z }, { facingLocation: { x: L.x, y: L.y + 1.5, z: L.z } }); c.e.setProperty("mrpg:mv", d > 2.2); } catch {}
      if (E.t % 10 === 0 && E.mom) try { OW().spawnParticle("minecraft:villager_happy", { x: E.mom.x, y: E.mom.y + 2.3, z: E.mom.z }); } catch {}
      if (E.mom && hv(c, E.mom) < 3.5 && !busy.has(p.id) && !inBattle(p)) { E.st = "done"; finishLost(p, E); }   /* 第124版: ほかの 画面・戦いの あいだは 待つ */
      if (E.t > E.limit * 5) { endEv(pid, "§7子どもは 自分で 家に 帰って いった"); continue; }
    }
  }
}, 4);

async function finishLost(p, E) {
  const had = busy.has(p.id); busy.add(p.id); try {
  const m = E.mom; face(m, E.child); face(E.child, m);
  say(p, E.child.nm, "ママーっ！"); say(p, m.nm, "もう、どこ 行ってたの！ ……本当に ありがとうございます！");
  const r = reward(p, 1.2); await notice(p, "迷子", `§f親子が 再会できた。\n\n§e${E.child.nm}§f「おにいちゃん（おねえちゃん）、ありがと！ これ あげる！」\n\n§aお礼: ${r}`);
  endEv(p.id, "§a迷子を 送りとどけた！");
  } finally { if (!had) busy.delete(p.id); }
}

// ---------- 話しかけた とき ----------
async function fightTeam(p, E, name, fams, n, lines) {
  const fight = TR.fight || (await import("./story.js")).fight, { team } = await import("./saga.js");
  const lv = Math.max(3, Math.floor(regionLv(p.location) || 5) + 1);
  E.st = "battle"; busy.delete(p.id);
  let res = null; try { res = await fight(p, { team: team(fams, lv, n) }, { tier: 1, fam: "", npc: null, theme: "arena", name, arena: "町の さわぎ", speaker: name, lines }); } catch (e) { console.warn(`[MonsterRPG] trouble fight: ${e}`); }
  try { if (ok(p)) busy.add(p.id); } catch {}   /* 第106版: 戦いの あとの お礼の 画面も 守る */
  return res;
}
async function talk(p, E, who) {
  if (E.lock) return; E.lock = true;   /* 第106版: 連打で 二重に お礼が 出ない */
  const k = E.k, A = E.actors;
  busy.add(p.id); if (E.st === "wait") E.st = "talk";
  try {
    if (k === "nanpa") {
      const [c, g] = A;
      const s = await choose(p, "ナンパ", `§e${c.nm}§f「なんだよ、今 いいところ なんだけど？」\n§e${g.nm}§f「……（こまって いる）」`, [B("§lやめなよ", "i_battle"), B("ナンパの コツを 聞く", "i_book"), B("見なかった ことに する", "i_close")]);
      if (s === 0) {
        const res = await fightTeam(p, E, c.nm, ["beast", "animal"], 2, { half: "え、ちょ、強くない？", low: "オレの サングラスが……！" });
        if (res === "win") { say(p, c.nm, "今日は 厄日だ……ママに 言いつけて やる！"); const r = reward(p); await notice(p, "ナンパ", `§e${g.nm}§f「助けて くれて ありがとう……！ かっこよかった、です」\n\n§aお礼: ${r}`); endEv(p.id, "§a女の子を 助けた！"); }
        else { say(p, c.nm, "へっ、出直して きな〜"); endEv(p.id); }
      } else if (s === 1) {
        await notice(p, "ナンパの コツ", `§e${c.nm}§f「いいか、まずは 天気の 話だ。『今日も いい天気ですね』」\n§f「……そしたら『ボキャ貧ですか？』って 言われた」\n§f「次に 星座の 話。……星座を 知らなかった」\n§f「最後は 笑顔。……通報された」\n\n§7そのすきに ${g.nm}は 逃げて いった。`);
        say(p, g.nm, "（遠くで 小さく 頭を 下げた）"); const d = load(p); const r = giveGold(d, 30); save(p, d);
        try { p.sendMessage(`§7（${g.nm}が 落として いった お礼の 小袋: ${r}）`); } catch {}
        endEv(p.id);
      } else endEv(p.id, "§7見なかった ことに した……");
    } else if (k === "thief" || k === "dash") {
      const [m, t] = A;
      if (E.st !== "caught") { say(p, m.nm, k === "dash" ? "あいつを 追いかけて くれー！" : "あの 人よ！ 捕まえて！"); return; }
      const s = await choose(p, k === "dash" ? "食い逃げ" : "スリ", k === "dash" ? `§e${t.nm}§f「お、お腹が すいてて……十人前 食べたら お金が なくなって……」` : `§e${t.nm}§f「ちぇっ……返せば いいんだろ、返せば」`,
        k === "dash" ? [B("§l代わりに 払う（100）", "i_gold"), B("店に 突き出す", "i_battle")] : [B("§l返させる", "i_party"), B("モンスターで こらしめる", "i_battle")]);
      if (k === "dash" && s === 0) {
        const d = load(p); if ((d.gold || 0) < 100) { await notice(p, "食い逃げ", "§cお金が 足りない……"); return; }
        d.gold -= 100; save(p, d); const r = reward(p, 1.3, true) || "§7（気持ちだけ）";
        await notice(p, "食い逃げ", `§e${m.nm}§f「……あんた、いい人だな。そいつに まかないの 仕事 させるよ」\n§e${t.nm}§f「一生 ついて いきます！ ……これ、ポケットに 入ってた お礼です！」\n\n§aお礼: ${r}`); endEv(p.id, "§a食い逃げを 丸く おさめた！");
      } else if (s === 1 && k === "thief") {
        const res = await fightTeam(p, E, t.nm, ["beast", "nether"], 2, { half: "ひっ、こいつ 本気だ！", low: "わ、わかった！ 返す！ 返すから！" });
        if (res === "win") { const r = reward(p, 1.3); await notice(p, "スリ", `§e${m.nm}§f「取りかえして くれたのね！ ありがとう！」\n\n§aお礼: ${r}`); endEv(p.id, "§aスリを こらしめた！"); } else endEv(p.id, "§7スリに 逃げられた……");
      } else if (s >= 0) { const r = reward(p); await notice(p, k === "dash" ? "食い逃げ" : "スリ", `§e${m.nm}§f「助かったよ！ これは お礼だ」\n\n§aお礼: ${r}`); endEv(p.id, "§a事件を 解決した！"); }
    } else if (k === "drunk") {
      const [a, b] = A;
      const s = await choose(p, "酔っぱらいの けんか", `§e${a.nm}§f「こいつが オレの 酒を 飲んだんだ！」\n§e${b.nm}§f「飲んで ない！ 吸いこんだ だけだ！」`, [B("§l止める（勝負）", "i_battle"), B("酒を おごる（150）", "i_gold"), B("いっしょに 飲む", "i_party"), B("放って おく", "i_close")]);
      if (s === 0) {
        const res = await fightTeam(p, E, `${a.nm}と ${b.nm}`, ["golem", "blob"], 3, { half: "ヒック……目が まわる……", low: "……な、仲直り します……ヒック" });
        if (res === "win") { const r = reward(p); await notice(p, "けんか", `§f二人は 肩を 組んで 帰って いった。\n§e${b.nm}§f「お前、いい やつだな……これ やる……ヒック」\n\n§aお礼: ${r}`); endEv(p.id, "§aけんかを 止めた！"); } else endEv(p.id);
      } else if (s === 1) {
        const d = load(p); if ((d.gold || 0) < 150) { await notice(p, "けんか", "§cお金が 足りない……"); return; }
        d.gold -= 150; save(p, d); const r = reward(p, 1.4, true) || "§7（気持ちだけ）";
        await notice(p, "けんか", `§e${a.nm}§f「おごり！？ お前 天使か！」\n§e${b.nm}§f「なあ、知ってるか……仮面の 戦士が 町に 来てるって 噂……ヒック」\n§7（二人は すっかり 仲直りした）\n\n§aお礼: ${r}`); endEv(p.id, "§a酒で 丸く おさめた！");
      } else if (s === 2) {
        await notice(p, "けんか", `§f……気がつくと 三人で 肩を 組んで 歌って いた。\n§f歌詞は 誰も 覚えて いない。\n§f次の 朝、町の 掲示板に「謎の 三人組 合唱団」と 書かれて いた。`);
        endEv(p.id, "§d謎の 合唱団が 結成された");
      } else endEv(p.id);
    } else if (k === "lost") {
      if (E.st === "follow") { say(p, E.child.nm, pick(["ママ、あっちかなぁ……", "おにいちゃん（おねえちゃん）、手 つないで いい？", "おなか すいた……"])); return; }
      const s = await choose(p, "迷子", `§e${E.child.nm}§f「ひっく……ママと はぐれちゃった……」`, [B("§l一緒に さがす", "i_party"), B("あとで", "i_close")]);
      if (s !== 0) return;
      const m = put("hanna", E.far, " §7（さがして いる）"); if (!m) { endEv(p.id); return; }
      E.mom = m; E.actors.push(m); E.st = "follow"; E.t = 0;
      say(p, E.child.nm, "うん……！"); try { barNote(p).setActionBar("§b緑の 光の 下に ママが いるみたい。連れて いこう"); } catch {}
    } else if (k === "nox") {
      const [n, v] = A;
      const s = await choose(p, "カツアゲ", `§e${n.nm}§f「なんだ、お前も かけらを 持ってるのか？」\n§e${v.nm}§f「た、助けて……」`, [B("§l追いはらう（勝負）", "i_battle"), B("見なかった ことに する", "i_close")]);
      if (s !== 0) { endEv(p.id); return; }
      const res = await fightTeam(p, E, n.nm, ["nether", "beast", "sword"], 3, { half: "くっ、ただの 旅人じゃ ないな……！", low: "お、覚えて やがれ！ ……給料日 前なのに！" });
      if (res === "win") { const r = reward(p, 1.4); await notice(p, "カツアゲ", `§e${v.nm}§f「ありがとう……六影の やつら、最近 町に よく 来るんだ」\n\n§aお礼: ${r}`); endEv(p.id, "§a六影を 追いはらった！"); } else endEv(p.id);
    } else if (k === "hero") {
      const [h] = A;
      const s = await choose(p, "自称勇者", `§e${h.nm}§f「私は 勇者！ 王様に 認められては いないが 勇者！ 勝負だ！」`, [B("§l受けて 立つ", "i_battle"), B("勇者の 証拠を 見せて", "i_book"), B("ことわる", "i_close")]);
      if (s === 0) {
        const res = await fightTeam(p, E, h.nm, ["sword", "animal"], 2, { half: "勇者は ピンチに 強いのだ！ ……たぶん！", low: "これは 修行だ！ 負けでは ない！" });
        if (res === "win") { const r = reward(p, 1.1); await notice(p, "自称勇者", `§e${h.nm}§f「勇者は 負けても 勇者だ。……帰って 寝る」\n§f「これは 冒険の 必需品だ。君に 託そう」\n\n§aもらった: ${r}`); endEv(p.id, "§a自称勇者に 勝った！"); } else endEv(p.id);
      } else if (s === 1) { await notice(p, "自称勇者", `§e${h.nm}§f「証拠？ ……この 鉢巻だ！ 母が 縫って くれた！」\n§f「あと、勇者は 朝 6時に 起きる！ ……今日は 起きられなかった！」`); }
      else endEv(p.id, "§7勇者は さびしそうに 去って いった");
    }
  } finally { E.lock = false; busy.delete(p.id); if (EV.get(p.id) === E && E.st === "talk") { E.st = "wait"; if (!E.run) E.t = 0; } }
}
NPC_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_trouble")) return false;
  for (const [pid, E] of EV) {
    const a = E.actors.find((x) => x.e.id === e.id); if (!a) continue;
    if (pid !== p.id) { say(p, a.nm, "今 ちょっと 取りこみ中で……"); return true; }
    if (E.st === "battle" || E.st === "done" || E.lock || busy.has(p.id)) return true;
    talk(p, E, a).catch(() => {}); return true;
  }
  try { e.remove(); } catch {} return true;
});
world.afterEvents.playerLeave.subscribe(({ playerId }) => endEv(playerId));
system.runTimeout(() => { try { for (const e of OW().getEntities({ tags: ["mrpg_trouble"] })) if (![...EV.values()].some((E) => E.actors.some((a) => a.e.id === e.id))) try { e.remove(); } catch {} } catch {} }, 100);
globalThis.__mqTroubleIds = () => { const S = new Set(); for (const E of EV.values()) for (const a of E.actors) if (a && a.e) S.add(a.e.id); return S; };
export const __trouble = { EV, KINDS, CD, endEv, talk, reward };
