// v2.2: 冒険のコンパス（町・遺跡・祭壇の 方向と きょり／かんたんな 地図）
import { world, system } from "@minecraft/server";
import { TOWNS, townPos, getTown, siteOf, getRuin, REGION } from "./structures.js";
import { altarInfo, rfInfo } from "./postgame.js";
import { choose, notice, ICON, busy, paged, inv, bagAdd, BAR_T, TITLE_T, hudSend, hudResend, gold, widthOf } from "./ui.js";
import { ITEMS } from "./data.js";
import { REGIONS, rmView } from "./rmaster.js";
import { WREGIONS, landSites, regionIdxAt } from "./worldmap.js";
import { castleInfo, castleSpot, landInfo, ruinBlocked, caveInfo, caveSite, CAVE_R } from "./structures.js";
import { load } from "./store.js";
import { storyTarget } from "./saga.js";

const KEY = "mrpg:navi";
// v2.9.10: 矢印の 記号は マイクラで 文字化け する ことが あるので ことばで
const ARROWS = ["まっすぐ", "右ななめ前", "右", "右ななめ後ろ", "うしろ", "左ななめ後ろ", "左", "左ななめ前"];
const DIR8 = ["南", "南西", "西", "北西", "北", "北東", "東", "南東"];   // マイクラの 向き（0 = 南）
const B = (t, icon) => [t, icon];
// 目的地の 方位（マイクラの yaw と 同じ: 0 = 南、90 = 西）
const yawTo = (from, to) => (Math.atan2(-(to.x - from.x), to.z - from.z) * 180) / Math.PI;
const norm = (a) => ((a % 360) + 540) % 360 - 180;
export function arrowFor(p, to) {
  let yaw = 0; try { yaw = p.getRotation().y; } catch {}
  return ARROWS[(Math.round(norm(yawTo(p.location, to) - yaw) / 45) + 8) % 8];
}
export const dirName = (from, to) => DIR8[(Math.round(((yawTo(from, to) % 360) + 360) % 360 / 45)) % 8];
const dist = (a, b) => Math.round(Math.hypot(a.x - b.x, a.z - b.z));
const fmt = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1)}km` : `${n}m`);

// 目的地の 一覧（いまの ディメンション）
export function places(p, d) {
  const pid = p && p.id;
  const L = [], dim = p.dimension.id, me = p.location;
  if (dim === "minecraft:overworld") {
    const s = world.getDefaultSpawnLocation();
    L.push({ kind: "spawn", name: "はじまりの 地点（リスポーン）", x: s.x, z: s.z, mark: "始" });
    for (const t of TOWNS) {
      const q = townPos(t), info = getTown(t.id), seen = (d?.towns || []).includes(t.id);
      L.push({ kind: "town", name: `${t.name} §8★${(t.tier || 0) + 1}${seen ? " §a訪問ずみ" : info?.built ? "" : " §7未発見"}`, x: q.x, z: q.z, mark: "町" });
    }
    const a = altarInfo(); if (a) L.push({ kind: "altar", name: d?.story?.ending ? "§5閻魔の神殿" : "§5？？？の 神殿", x: a.x, z: a.z, mark: "神" });   // 第69版: クリア前は 名前を かくす
    // v2.3: 地方の 城・ステージ
    WREGIONS.forEach((R, i) => {
      const c = castleInfo(i) || castleSpot(i), k = R.rm, done = k >= 0 && (d?.story?.rm || []).includes(k);
      L.push({ kind: "castle", reg: i, name: `${R.castle.name} §8${R.castle.name.includes(R.short) ? "" : R.short}${k >= 0 ? (done ? " §7済" : ` §6地方マスター ${rmView(k, d).name}`) : ""}`, x: c.x, z: c.z, mark: "城" });
      if (CAVE_R.includes(i)) { const v = caveInfo(i), c = v || caveSite(i); L.push({ kind: "land", reg: i, name: `${R.short}の 洞くつ（入口）${v && v.built ? "" : " §7未発見"}`, x: c.x, z: c.z, mark: "洞" }); }
      for (const S of landSites(i)) { const li = landInfo(S.key); if (li && li.skip) continue; L.push({ kind: "land", reg: i, name: `${li && li.name ? li.name : "ふしぎな 大地"}${li && li.built ? "" : " §7未発見"} §8${R.short}`, x: S.x, z: S.z, mark: "ス" }); }
    });
    const rf = rfInfo(); if (rf) L.push({ kind: "altar", name: "§6終の遺跡", x: rf.x, z: rf.z, mark: "終" });
  }
  const R = REGION[dim];
  if (R) {
    const rx0 = Math.floor(me.x / R), rz0 = Math.floor(me.z / R);
    for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) {
      const site = siteOf(dim, rx0 + dx, rz0 + dz), r = getRuin(site.key);
      if (r && r.skip) continue;
      if (dim === "minecraft:overworld" && TOWNS.some((t) => { const q = townPos(t); return Math.hypot(q.x - site.x, q.z - site.z) < 80; })) continue;
      if (!r && ruinBlocked(dim, site)) continue;
      const done = !!(r?.cleared && (!r.by || !pid || r.by.includes(pid)));
      L.push({ kind: "ruin", name: `遺跡 ${r?.built ? (done ? "§aボス 撃破ずみ" : "§cボスが いる") : "§7未発見"}`, x: site.x, z: site.z, mark: "遺" });
    }
  }
  for (const x of L) x.d = dist(me, x);
  return L.sort((a, b) => a.d - b.d);
}

// 文字の 地図（北が 上）。まわりの 目的地を 記号で
export function mapText(p, L) {
  const W = 15, H = 9, near = L.slice(0, 12);
  const span = Math.max(150, ...near.map((x) => x.d)) * 1.05;
  const g = Array.from({ length: H }, () => Array(W).fill("§8・"));
  for (const x of near) {
    const cx = Math.round((W - 1) / 2 + ((x.x - p.location.x) / span) * ((W - 1) / 2));
    const cy = Math.round((H - 1) / 2 + ((x.z - p.location.z) / span) * ((H - 1) / 2));
    if (cx >= 0 && cx < W && cy >= 0 && cy < H) g[cy][cx] = ({ town: "§e", ruin: "§c", altar: "§5", spawn: "§b", castle: "§6", land: "§3" }[x.kind] || "§f") + x.mark;
  }
  g[(H - 1) / 2][(W - 1) / 2] = "§a自";
  return [`§7北が 上　はば 約${fmt(Math.round(span * 2))}`, ...g.map((r) => r.join("")), "§a自§7じぶん §6城§7地方の 城 §e町§7町・村 §3ス§7ステージ §c遺§7遺跡 §5神§7神殿 §6終§7終の遺跡 §b始§7はじまり"].join("\n");
}

const ICONK = (k) => ICON(k === "town" || k === "castle" ? "i_walk" : k === "ruin" || k === "land" ? "i_fight" : "i_scout");
const cleanName = (n) => n.replace(/ §8.*$/, "").replace(/§./g, "").replace(/ (訪問ずみ|未発見|ボスが いる|ボス 撃破ずみ)$/, "").replace(/ 地方マスター .*$| \(地方マスター 済\)/, "").replace(/ 未発見/, "");
async function go(p, x) {
  setTarget(p, { name: cleanName(x.name), x: x.x, z: x.z, dim: p.dimension.id });
  await notice(p, "冒険のコンパス", `§a${x.name.replace(/§./g, "")} へ 案内します。\n§7画面の 下に 方角（いまは ${dirName(p.location, x)}・${arrowFor(p, x)}）と きょりが 出ます。着くと 自動で おわります。`);
}
// v3.0: 1行目は 名前だけ（長い 名前は 前の かざりを はずす）・2行目に 方角と きょり
const shortName = (n) => { n = String(n).replace(/§./g, "").trim(); if (widthOf(n) <= 26) return n; const parts = n.split(" "); while (parts.length > 1 && widthOf(parts.join(" ")) > 26) parts.shift(); return parts.join(" "); };
const btnOf = (p, x) => { const [main, sub] = String(x.name).split(" §8"); return B(`${arrowFor(p, x)} §l${shortName(main)}§r\n§8${dirName(p.location, x)} ${fmt(x.d)}${sub ? ` §7${sub.replace(/§./g, "")}` : ""}`, ICONK(x.kind)); };
export async function naviMenu(p, d) {
  for (;;) {
    const L = places(p, d), cur = getTarget(p);
    const list = L.slice(0, 20);
    let here = ""; try { if (p.dimension.id === "minecraft:overworld") { const R = WREGIONS[regionIdxAt(p.location)]; here = `${R.col}${R.name}§7（Lv${R.lv[0]}〜${R.lv[1]}）`; } } catch {}
    const head = [`§f今いる ところ ${here} §7X ${Math.floor(p.location.x)} / Z ${Math.floor(p.location.z)}`, cur ? `§6案内中: ${cur.name.replace(/§./g, "")} ${arrowFor(p, cur)} ${fmt(dist(p.location, cur))}` : "§7行きたい 場所を 選ぶと、画面の 下に 方向と きょりが 出ます", "", mapText(p, L)].join("\n");
    const cats = p.dimension.id === "minecraft:overworld" ? [["castle", "§6地方の 城（11）§r\n§8地方マスター・闘技場・王さま"], ["land", "§3ステージ（各地方 3か所）§r\n§8テーマの 大地・宝箱"], ["town", "§e町と 村（ぜんぶ）"]] : [];
    const btn = [...cats.map(([k, t]) => B(t, ICONK(k))), ...list.map((x) => btnOf(p, x))];
    if (cur) btn.push(B("§c案内を やめる", ICON("i_close")));
    btn.push(B("§7閉じる", ICON("i_back")));
    const s = await choose(p, "冒険のコンパス", head, btn);
    if (s < 0) return;
    if (s < cats.length) {
      const k = cats[s][0], all = L.filter((x) => x.kind === k);
      const sel = await paged(p, cats[s][1].split("§r")[0].replace(/§./g, ""), "§7近い 順。選ぶと 案内が はじまる", all.map((x) => btnOf(p, x)));
      if (sel >= 0 && sel < all.length) { await go(p, all[sel]); return; }
      continue;
    }
    const j = s - cats.length;
    if (j < list.length) { await go(p, list[j]); return; }
    if (cur && j === list.length) { setTarget(p, null); continue; }
    return;
  }
}
export function getTarget(p) { try { const v = p.getDynamicProperty(KEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
export function setTarget(p, t) { try { p.setDynamicProperty(KEY, t ? JSON.stringify(t) : undefined); } catch {} }

// v2.9.10: 物語の 次の 目標（案内中で ない ときは 画面の 下に・目標が かわったら チャットにも）
const SCACHE = new Map(), SAID = new Map();
export function storyGoalOf(p) {
  const c = SCACHE.get(p.id), now = system.currentTick;
  if (c && now - c.t < 60) return c.g;
  let g = null; try { const d = load(p); if (d) g = storyTarget(p, d); } catch {}
  SCACHE.set(p.id, { t: now, g }); return g;
}
export function goalLine(p, g, long = false) {
  if (!g) return "";
  const t = long ? g.text : (g.text.length > 30 ? g.text.slice(0, 29) + "…" : g.text);
  if (g.x === null || p.dimension.id !== "minecraft:overworld") return `§6次の目標: §f${t}`;
  const n = dist(p.location, g);
  return n < 40 ? `§6次の目標: §f${t} ${g.near ? "§a（" + g.near.replace(/§./g, "") + "）" : "§a（この あたり！）"}` : `§6次の目標: §f${t}${long ? "\n  " : " "}§e${g.name ? g.name + "まで " : ""}${dirName(p.location, g)}へ ${fmt(n)}§7（${arrowFor(p, g)}）`;
}
export const goalOn = (p) => { try { return p.getDynamicProperty("mrpg:nogoal") !== true; } catch { return true; } };
let slabTick = 0;
system.runInterval(() => {
  const sweep = ++slabTick % 5 === 0;
  for (const p of world.getAllPlayers()) {
    // v2.9.10: 持ち物に ある 物語の 石板は バッグへ（前の 版で 持ち物に 入った ぶんも）
    if (sweep && !busy.has(p.id)) try {
      const c = inv(p);
      for (let i = 0; c && i < c.size; i++) {
        const it = c.getItem(i); const sid = it?.typeId?.startsWith("mrpg:") ? it.typeId.slice(5) : null;
        if (sid && ["bslab", "dslab"].includes(ITEMS[sid]?.kind)) { const n = it.amount; c.setItem(i, undefined); bagAdd(p, sid, n); p.sendMessage(`§d${ITEMS[sid].name}を バッグに しまった §7（ガイドブック ＞ 道具・装備 ＞ バッグ ＞ ${ITEMS[sid].kind === "dslab" ? "神の石板" : "特別な石板"} から 使う）`); }
      }
    } catch {}
    try {
      if (busy.has(p.id) || !goalOn(p) || typeof p.getDynamicProperty("mrpg:dg") === "string") continue;
      const g = storyGoalOf(p); if (!g) continue;
      if (SAID.get(p.id) !== g.key) { SAID.set(p.id, g.key); p.sendMessage(goalLine(p, g, true)); }   // 目標が かわったら チャットにも
    } catch {}
  }
}, 40);
// 案内中は 画面の 下に 方向と きょり
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    const t = getTarget(p);
    if (!t || busy.has(p.id)) continue;
    if (p.dimension.id !== t.dim) continue;
    const n = dist(p.location, t);
    if (n < 16) { setTarget(p, null); try { p.onScreenDisplay.setActionBar(`§a§l${t.name} に 着いた！`); p.playSound("random.levelup", { pitch: 1.4, volume: 0.6 }); } catch {} continue; }
    try { p.onScreenDisplay.setActionBar(`§f${t.name} §e${dirName(p.location, t)}へ §b${fmt(n)} §7（${arrowFor(p, t)}）`); } catch {}
  }
}, 10);

// v2.9.12: 画面の 右上に ずっと 目的地の 案内（ふつうの タイトルが 出て いる あいだは 書きかえない）
// v2.9.13: 右上の いちばん上に 所持金
function guideText(p) {
  let money = ""; try { const d = load(p); if (d && typeof d.gold === "number") money = `§6所持金 ${gold(Math.floor(d.gold))}`; } catch {}
  const g = guideText0(p);
  return money && g ? `${money}\n${g}` : money || g;
}
function guideText0(p) {
  if (!goalOn(p)) return "";
  if (typeof p.getDynamicProperty("mrpg:dg") === "string") return "";
  // v2.9.12: 右上は 物語の 目標だけ（コンパスの 案内は 画面の 下に 出す）
  const g = storyGoalOf(p); if (!g) return "";
  const head = g.text.length > 19 ? g.text.slice(0, 19) + "\n" + (g.text.length > 41 ? g.text.slice(19, 40) + "…" : g.text.slice(19)) : g.text;   /* v2.9.12: 2行まで 出す */
  if (g.x === null || p.dimension.id !== "minecraft:overworld") return `§6目標§f ${head}`;
  const n = dist(p.location, g);
  return `§6目標§f ${head}\n${n < 40 ? (g.near || "§aこの あたり！") : `§e${g.name ? g.name + " " : ""}${dirName(p.location, g)}へ ${fmt(Math.round(n / 10) * 10)} §7${arrowFor(p, g)}`}`;
}
export function refreshGuide(p) { hudResend(p.id, "MQG"); }
// 生き返った ときも 送りなおす
try { world.afterEvents.playerSpawn.subscribe((e) => hudResend(e.player.id, "MQG")); } catch {}
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try {
      if (busy.has(p.id)) continue;
      const txt = guideText(p);
      hudSend(p, "MQG", txt);   // 1tickに 1つずつ 送る（戦いの 表示と ぶつからない）
    } catch {}
  }
}, 20);

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { SCACHE.delete(playerId); SAID.delete(playerId); } catch {} }); } catch {}
