// 第124版: 町の 外を 歩く 役に 立つ 人（10の 職業）。fieldnpc.js が 旅人の 組に まぜて 出す
// 話しかけると social.js の メニューの 先頭に その人の 仕事が 出る。1日の 回数・待ち時間は「プレイヤーごと・職業ごと」
import { world } from "@minecraft/server";
import { ITEMS, EGGS } from "./data.js";
import { load, save } from "./store.js";
import { choose, notice, confirm, ICON, MON_ICON, giveItem, takeItem, countItem, sound, gold, paged, ok, barNote } from "./ui.js";
import { rankCap, storyItemOk, storyLootOk, wtCap } from "./quest.js";
import { calcStats, useItemOn, MAXLV } from "./core.js";
import { START_HOOKS, expCapLv } from "./battle.js";
import { WREGIONS, regionIdxAt } from "./worldmap.js";
import { exOf, exSave, dayNo } from "./explore.js";
import { eg } from "./endgame.js";
import { chestsNear, BOX_RE } from "./chests.js";
import { gearSlots, rollGear, capRoll, capOf, replaceSlot, gearName, gearLines, gearPower } from "./gear.js";
import { dirName, setTarget } from "./navi.js";

const pick = (L) => L[Math.floor(Math.random() * L.length)];
const day = () => dayNo();   /* 第124版: 1日の 切りかわりは explore.js の dayNo（日本の 0時）に そろえる */
const hashS = (t) => { let h = 7; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
const nmOf = (e) => { try { return String(e.nameTag || "").replace(/§./g, "").trim(); } catch { return "旅の 人"; } };
const say = (p, e, t) => { try { const n = nmOf(e); p.sendMessage(`§e${n}§f「${t}」`); barNote(p).setActionBar(`§e${n}§f「${t}」`); } catch {} };
const act = (e, a) => { try { if (ok(e)) e.setProperty("mrpg:act", a); } catch {} };
const fx = (e, id) => { try { const l = e.location; e.dimension.spawnParticle(id, { x: l.x, y: l.y + 1.6, z: l.z }); } catch {} };
const B = (t, i) => [t, ICON(i)];
const regOf = (p) => { try { return Math.max(0, Math.min(10, regionIdxAt(p.location))); } catch { return 0; } };
const fmt = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1)}km` : `${Math.round(n)}m`);

/* 10の 職業。sk: 見た目（職業ごとに 1つ。同じ 職業は 同じ 姿で、世界の あちこちに 何人も いる）・w: 出やすさ・st: 出やすい 地形・a: しぐさ */
export const HK = {
  monk: { n: "旅の僧侶", sk: ["m6_brother"], w: 3, st: ["snow", "dark"], a: 15, ic: "i_inn", job: "仲間を 回復して もらう",
    hi: ["神の ご加護を。お疲れの ようですね", "旅の 方、少し 休んで いきなさい", "傷ついた 子は いませんか？"] },
  merchant: { n: "行商人", sk: ["m6_hector"], w: 1, st: ["port", "desert"], a: 23, ic: "i_shop", job: "道具を 買う",
    hi: ["へい、らっしゃい！ 町まで 戻るのは 大変だろ？", "旅の 道具なら そろってるよ", "安くは ないけど、ここで 買えるのが 強みさ"] },
  egg: { n: "タマゴ売り", sk: ["milka"], w: 1, st: ["village", "forest"], a: 23, ic: "i_egg", job: "タマゴを 買う",
    hi: ["産みたての タマゴ、いかが？", "うちの タマゴは 元気な 子が 生まれるよ", "あたためると、何が 出るかは お楽しみ"] },
  bard: { n: "吟遊詩人", sk: ["m6_rafa"], w: 1, st: ["sky", "forest"], a: 4, ic: "i_star", job: "歌を 聞く（次の 戦いで 強く なる）",
    hi: ["やあ、旅の 人。一曲 いかが？", "風の 歌を 集めて 旅を して いるんだ", "歌は 心を 強く するよ"] },
  seer: { n: "占い師", sk: ["viola"], w: 1, st: ["crystal", "dark"], a: 16, ic: "i_spell", job: "近くを 占って もらう",
    hi: ["……あなたの 近くに、光る ものが 見える", "ふふ、占って ほしいのね", "星が 何か 言いたそうよ"] },
  master: { n: "修行の師範", sk: ["m6_takeru"], w: 1, st: ["castle", "volcano"], a: 17, ic: "i_fight", job: "仲間を 修行させる",
    hi: ["ほう、いい 目を した 子たちだ", "修行に 近道は ない。だが 手助けは できる", "鍛えて ほしい 子は いるか"] },
  cook: { n: "旅の料理人", sk: ["m6_basil"], w: 1, st: ["snow", "port", "village"], a: 23, ic: "i_item", job: "料理を 食べる（戦いの 前の 強化）",
    hi: ["いい 匂いだろ？ 食べて いきなよ", "腹が へっては 戦えないって ね", "その 地方の 食材で 作った 料理さ"] },
  tamer: { n: "魔物使いの老人", sk: ["m6_sage"], w: 1, st: ["village", "forest", "sky"], a: 24, ic: "i_scout", job: "スカウトの こつを 聞く",
    hi: ["ほっほ。モンスターと 仲よく なりたいかね", "わしも 若い ころは 千の 子を 連れて 歩いたもんじゃ", "目を 見て、心を 見るんじゃよ"] },
  trader: { n: "素材の交換屋", sk: ["m6_crystal"], w: 1, st: ["desert", "crystal"], a: 23, ic: "i_box", job: "素材を 道具と 交換する",
    hi: ["素材を 持ってるなら、いい 物と かえて あげる", "余った 素材、売るより 得かもよ", "交換は 公平に いこう"] },
  smith: { n: "流れの鍛冶職人", sk: ["m6_bolt"], w: 1, st: ["volcano", "castle"], a: 18, ic: "i_equip", job: "装備を 打ち直す",
    hi: ["カン、カン……おう、装備を 見せて みな", "旅の 途中でも 槌は 振れるぜ", "いい 鉄は 打てば 打つほど 応える"] },
};
/* 1日の 回数（プレイヤーごと・職業ごと）*/
export const CAPS = { monk: 0, merchant: 0, egg: 2, bard: 4, seer: 5, master: 3, cook: 2, tamer: 3, trader: 5, smith: 3 };
export const MONK_CD = 180000;   /* 僧侶は 回数の かわりに 待ち時間（3分）*/
function cnt(p) { let v = {}; try { v = JSON.parse(p.getDynamicProperty("mrpg:fhc") || "{}"); } catch {} if (!v || v.d !== day()) v = { d: day(), n: {}, t: (v && v.t) || {} }; v.n = v.n || {}; v.t = v.t || {}; return v; }
const cntSave = (p, v) => { try { p.setDynamicProperty("mrpg:fhc", JSON.stringify(v)); } catch {} };
export const left = (p, k) => (CAPS[k] ? CAPS[k] - (cnt(p).n[k] || 0) : 99);
function use(p, k) { const v = cnt(p); v.n[k] = (v.n[k] || 0) + 1; v.t[k] = Date.now(); cntSave(p, v); }
/* 次の 野生の 戦いまで のこる 強化（歌・スカウトの こつ）*/
const bget = (p) => { try { return JSON.parse(p.getDynamicProperty("mrpg:fhb") || "{}") || {}; } catch { return {}; } };
const bset = (p, v) => { try { p.setDynamicProperty("mrpg:fhb", Object.keys(v).length ? JSON.stringify(v) : undefined); } catch {} };

/* 出す 職業を えらぶ（地形で 出やすさが かわる）*/
export function pickKind(p) {
  let st = ""; try { st = WREGIONS[regOf(p)].style; } catch {}
  const L = Object.entries(HK).map(([k, h]) => [k, h.w * (h.st.includes(st) ? 2 : 1)]);
  let r = Math.random() * L.reduce((a, x) => a + x[1], 0);
  for (const [k, w] of L) { r -= w; if (r <= 0) return k; }
  return "monk";
}
export const kindOf = (e) => { try { const k = e.getDynamicProperty("mrpg:hk"); return HK[k] ? k : null; } catch { return null; } };

/* social.js の メニューの 先頭に 出す 項目 */
export function helperOpt(p, e) {
  const k = kindOf(e); if (!k) return null; const H = HK[k];
  return { t: `§l${H.job}§r\n§8${H.n}の 仕事`, ic: H.ic, a: H.a, hello: pick(H.hi), run: () => JOB[k](p, e) };
}

// ---------- 1. 旅の僧侶: 仲間を 全回復（無料・3分に 1回）----------
async function monk(p, e) {
  const v = cnt(p), w = MONK_CD - (Date.now() - (v.t.monk || 0));
  if (w > 0) { say(p, e, `さきほど 祈った ばかりです。少し 待って ください（あと ${Math.ceil(w / 1000)}秒）`); return; }
  const d = load(p); if (!d) return;
  act(e, 15); fx(e, "minecraft:totem_particle");
  for (const m of [...(d.party || []), ...(d.bench || [])]) { if (!m) continue; let st; try { st = calcStats(m); } catch { continue; } m.hp = st.hp; m.mp = st.mp; }
  save(p, d); use(p, "monk"); sound(p, "random.levelup", 1.4);
  say(p, e, pick(["神の 光よ、この 子たちに 癒しを……", "さあ、元気に なりましたよ", "道中、どうか ご無事で"]));
  try { p.sendMessage("§a仲間（表・裏）の HPと MPが 全回復した！"); } catch {}
}
// ---------- 2. 行商人: 回復・強化の 道具（地方と 物語の 進みで 品が かわる）----------
const SHOPK = ["heal", "mpheal", "revive", "cure", "healall", "curall", "bbuff", "scout", "escape", "bregen"];
export function merchStock(d, i) {
  const cap = rankCap(d), T = Math.min(wtCap(cap) + 1, 1 + Math.floor(i / 3));
  const L = Object.keys(ITEMS).filter((id) => { const it = ITEMS[id]; return SHOPK.includes(it.kind) && (it.price || 0) > 0 && !it.noshop && (it.tier ?? 0) <= T && storyItemOk(it, null, cap); });
  const h = hashS(`m${i}:${day()}`), S = L.sort((a, b) => ((hashS(a) ^ h) % 997) - ((hashS(b) ^ h) % 997));
  const must = L.filter((id) => ["heal", "revive"].includes(ITEMS[id].kind)).sort((a, b) => ITEMS[b].tier - ITEMS[a].tier).slice(0, 2);
  return [...new Set([...must, ...S])].slice(0, 7);
}
async function merchant(p, e) {
  for (;;) {
    const d = load(p); if (!d) return;
    const S = merchStock(d, regOf(p));
    const c = await choose(p, HK.merchant.n, `§7町の 道具屋と 同じ 値段\n§fお金: ${gold(d.gold || 0)}`, [...S.map((id) => B(`${ITEMS[id].name}\n§8${gold(ITEMS[id].price)}`, "i_shop")), B("§7やめる", "i_back")]);
    const id = S[c]; if (!id) return;
    const n = await choose(p, ITEMS[id].name, `§f${ITEMS[id].name} §7（1こ ${gold(ITEMS[id].price)}）`, [B("1こ 買う", "i_shop"), B("5こ 買う", "i_shop"), B("§7やめる", "i_back")]);
    const k = n === 0 ? 1 : n === 1 ? 5 : 0; if (!k) continue;
    const d2 = load(p); if (!d2) return; const cost = ITEMS[id].price * k;
    if ((d2.gold || 0) < cost) { await notice(p, HK.merchant.n, "§cお金が 足りない……"); continue; }
    d2.gold -= cost; save(p, d2); giveItem(p, `mrpg:${id}`, k); sound(p, "random.orb", 1);
    act(e, 10); say(p, e, pick(["まいど！", "毎度 あり！ 気を つけてな", "いい 買い物 したね"]));
  }
}
// ---------- 3. タマゴ売り: 物語の 上限いかの タマゴ（1日 2こ）----------
export function eggStock(d, i) {
  const cap = rankCap(d);
  const L = Object.keys(EGGS).filter((id) => ITEMS[id] && (EGGS[id].price || 0) > 0 && storyItemOk(ITEMS[id], EGGS[id].ranks, cap)).sort((a, b) => EGGS[a].price - EGGS[b].price);
  const h = hashS(`e${i}:${day()}`), top = L.slice(-6);
  return [...new Set([L[0], ...top.sort((a, b) => ((hashS(a) ^ h) % 997) - ((hashS(b) ^ h) % 997)).slice(0, 3)])].filter(Boolean);
}
async function egg(p, e) {
  const d = load(p); if (!d) return;
  if (left(p, "egg") <= 0) { say(p, e, "今日の ぶんは もう 売り切れ。また 明日 来てね"); return; }
  const S = eggStock(d, regOf(p));
  const c = await choose(p, HK.egg.n, `§7今日は あと ${left(p, "egg")}こ 売れる\n§fお金: ${gold(d.gold || 0)}`, [...S.map((id) => B(`${ITEMS[id].name}\n§8${gold(EGGS[id].price)}  ${Object.keys(EGGS[id].ranks).join("・")}`, "i_egg")), B("§7やめる", "i_back")]);
  const id = S[c]; if (!id) return;
  const d2 = load(p); if (!d2 || left(p, "egg") <= 0) return;
  if ((d2.gold || 0) < EGGS[id].price) { await notice(p, HK.egg.n, "§cお金が 足りない……"); return; }
  d2.gold -= EGGS[id].price; save(p, d2); use(p, "egg"); giveItem(p, `mrpg:${id}`, 1); sound(p, "random.orb", 1);
  act(e, 10); say(p, e, "大事に あたためてね。元気な 子が 生まれますように");
}
// ---------- 4. 吟遊詩人: 歌で 次の 野生の 戦いの はじめに 能力 +1段階 ----------
export const SONGS = [["勇ましい 歌", ["atk", "wpn"], "物力・武力"], ["知恵の 歌", ["mat", "brt"], "魔力・吹力"], ["守りの 歌", ["def", "mdf"], "硬力・魔硬力"], ["風の 歌", ["spd"], "走力"]];
async function bard(p, e) {
  if (left(p, "bard") <= 0) { say(p, e, "今日は もう 声が かれちゃった。また 明日"); return; }
  const c = await choose(p, HK.bard.n, "§fどの 歌を 聞く？\n§7次の 野生との 戦いの はじめに、仲間 みんなの 能力が 1段階 上がる（1回だけ・前の 歌と 入れかわる）", [...SONGS.map((s) => B(`${s[0]}\n§8${s[2]} +1`, "i_star")), B("§7やめる", "i_back")]);
  const S = SONGS[c]; if (!S || left(p, "bard") <= 0) return;
  use(p, "bard"); const b = bget(p); b.song = S[1]; b.sn = S[0]; bset(p, b);
  act(e, 4); fx(e, "minecraft:note_particle");
  for (let k = 0; k < 4; k++) try { p.playSound("note.harp", { pitch: [0.8, 1, 1.2, 1.5][k], volume: 0.6 }); } catch {}
  say(p, e, `♪ ${S[0]}を どうぞ…… 次の 戦い、きっと うまく いくよ`);
}
// ---------- 5. 占い師: めずらしい モンスター・宝箱・宝の しるし ----------
export function fortune(p, d) {
  const out = [], me = p.location, dim = p.dimension;
  try { for (const t of ["mrpg_shiny", "mrpg_rare"]) for (const m of dim.getEntities({ tags: [t], location: me, maxDistance: 120 })) { if (out.filter((x) => x.k === "mon").length >= 3) break; if (out.some((x) => x.id === m.id)) continue; out.push({ k: "mon", id: m.id, name: t === "mrpg_shiny" ? "§e色の ちがう モンスター" : "§dめずらしい モンスター", x: m.location.x, z: m.location.z }); } } catch {}
  try { const C = chestsNear(dim.id, Math.floor(me.x), Math.floor(me.y), Math.floor(me.z), 160).map((c) => ({ ...c, dd: Math.hypot(c.x - me.x, c.z - me.z) })).sort((a, b) => a.dd - b.dd); let n = 0;
    for (const c of C) { if (n >= 2) break; let b = null; try { b = dim.getBlock({ x: c.x, y: c.y, z: c.z }); } catch {} if (!b || !BOX_RE.test(b.typeId)) continue; n++; out.push({ k: "chest", name: "§6宝箱", x: c.x, z: c.z }); } } catch {}
  try { const T = d && eg(d).tmap; if (T) out.push({ k: "tmap", name: "§6宝の地図の しるし", x: T.x, z: T.z }); } catch {}
  for (const x of out) x.d = Math.hypot(x.x - me.x, x.z - me.z);
  return out;
}
const SEER_G = (i) => 100 * (i + 1);
async function seer(p, e) {
  if (left(p, "seer") <= 0) { say(p, e, "今日は もう 星が 見えないわ。また 明日"); return; }
  const d = load(p); if (!d) return; const price = SEER_G(regOf(p));
  if (!(await confirm(p, HK.seer.n, `§f近くの めずらしい モンスター・宝箱・宝の しるしを 占う\n§7${gold(price)}（今日は あと ${left(p, "seer")}回）\n§fお金: ${gold(d.gold || 0)}`, "占って もらう", "やめる"))) return;
  const d2 = load(p); if (!d2 || left(p, "seer") <= 0) return; if ((d2.gold || 0) < price) { await notice(p, HK.seer.n, "§cお金が 足りない……"); return; }
  d2.gold -= price; save(p, d2); use(p, "seer"); act(e, 16); fx(e, "minecraft:portal_reverse_particle");
  const L = fortune(p, d2);
  if (!L.length) { say(p, e, "……今は 近くに 何も 見えないわ。場所を かえて また おいで"); return; }
  say(p, e, "……見えたわ");
  const c = await choose(p, "占いの 結果", "§7選ぶと コンパスで 案内する", [...L.map((x) => B(`${x.name}\n§8${dirName(p.location, x)}へ ${fmt(x.d)}`, "i_scout")), B("§7閉じる", "i_back")]);
  const x = L[c]; if (x) setTarget(p, { name: x.name.replace(/§./g, ""), x: x.x, z: x.z, dim: p.dimension.id });
}
// ---------- 6. 修行の師範: お金で 経験値（物語の 上限 expCapLv を 守る）----------
const EXP_IDS = ["f_exp", "f_exp1k", "f_exp3k", "f_exp5k"];
export const trainItem = (d, i) => { const c = rankCap(d); return EXP_IDS[Math.max(0, Math.min(3, Math.min(Math.floor(i / 3), wtCap(c) + 1)))]; };
export const trainCost = (id) => Math.floor((ITEMS[id]?.price || 400) * 0.8);
async function master(p, e) {
  if (left(p, "master") <= 0) { say(p, e, "今日の 稽古は ここまで。休むのも 修行だ"); return; }
  const d = load(p); if (!d) return;
  const id = trainItem(d, regOf(p)), cost = trainCost(id), lc = expCapLv(d), L = [...(d.party || []), ...(d.bench || [])].filter(Boolean);
  const c = await paged(p, HK.master.n, `§f修行で 経験値 ${ITEMS[id].val} §7（${gold(cost)}・今日は あと ${left(p, "master")}回）\n§7物語の 経験の 上限: Lv${lc >= 999 ? MAXLV : lc}\n§fお金: ${gold(d.gold || 0)}`, L.map((m) => [`${m.nm || "?"} §7Lv${m.lv}${m.lv >= Math.min(lc, MAXLV) ? " §8（上限）" : ""}`, MON_ICON(m.sp)]), 8);
  const m0 = L[c]; if (!m0) return;
  if (m0.lv >= Math.min(lc, MAXLV)) { say(p, e, "この 子は 今は ここが 限界だ。物語を 進めて、もっと 広い 世界を 見て こい"); return; }
  const d2 = load(p); if (!d2 || left(p, "master") <= 0) return; if ((d2.gold || 0) < cost) { await notice(p, HK.master.n, "§cお金が 足りない……"); return; }
  const m = [...(d2.party || []), ...(d2.bench || [])].find((x) => x && x.id === m0.id); if (!m) return;
  const log = []; if (!useItemOn(m, id, log, rankCap(d2), expCapLv(d2))) { await notice(p, HK.master.n, "§7今は 修行できない。"); return; }
  d2.gold -= cost; save(p, d2); use(p, "master"); act(e, 17); fx(e, "minecraft:critical_hit_emitter"); sound(p, "random.levelup", 1);
  say(p, e, pick(["よし、いい 動きだ！", "その 調子だ。忘れるなよ", "見違えたな"]));
  await notice(p, "修行", log.join("\n") || "§a修行を した！");
}
// ---------- 7. 旅の料理人: 料理で 次の 野生戦 3回 強化 ＋ 体力を 少し 回復 ----------
const DISH = ["fd_stew", "fd_soup", "fd_curry", "fd_cake", "fd_tea", "fd_bento", "fd_egg", "fd_onigiri"];
export const cookCost = (i) => 300 + 100 * i;
export const dishes = (i) => { const h = hashS(`c${i}:${day()}`); return DISH.filter((id) => ITEMS[id]).sort((a, b) => ((hashS(a) ^ h) % 997) - ((hashS(b) ^ h) % 997)).slice(0, 3); };
async function cook(p, e) {
  if (left(p, "cook") <= 0) { say(p, e, "今日の 材料は 使い切っちゃった。また 明日"); return; }
  const i = regOf(p), cost = cookCost(i), S = dishes(i), d = load(p); if (!d) return;
  const c = await choose(p, HK.cook.n, `§f何を 食べる？ §7（${gold(cost)}・今日は あと ${left(p, "cook")}回）\n§7次の 野生との 戦い 3回、能力が 1段階 上がる。仲間の HPも 3割 もどる\n§fお金: ${gold(d.gold || 0)}`, [...S.map((id) => B(ITEMS[id].name, "i_party")), B("§7やめる", "i_back")]);
  const id = S[c]; if (!id) return;
  const d2 = load(p); if (!d2 || left(p, "cook") <= 0) return; if ((d2.gold || 0) < cost) { await notice(p, HK.cook.n, "§cお金が 足りない……"); return; }
  d2.gold -= cost;
  for (const m of [...(d2.party || []), ...(d2.bench || [])]) { if (!m || !(m.hp > 0)) continue; const st = calcStats(m); m.hp = Math.min(st.hp, m.hp + Math.ceil(st.hp * 0.3)); }
  save(p, d2); use(p, "cook");
  const x = exOf(p); x.food = { k: id, n: 3 }; x.ck2 = (x.ck2 || 0) + 1; exSave(p, true);
  act(e, 23); fx(e, "minecraft:villager_happy"); sound(p, "random.burp", 1);
  say(p, e, `${ITEMS[id].name}、お待ち！ 熱いうちに どうぞ`);
}
// ---------- 8. 魔物使いの老人: 次の 野生の 戦いで スカウト率 +10% ----------
export const TAMER_UP = 10;
async function tamer(p, e) {
  if (left(p, "tamer") <= 0) { say(p, e, "ほっほ、今日は もう 教える ことは ないわい"); return; }
  if (!(await confirm(p, HK.tamer.n, `§f「モンスターの 目を 見て、そっと 手を さしのべるんじゃ……」\n§7次の 野生との 戦いで スカウトの 成功率 +${TAMER_UP}%（1回だけ。道具と あわせて +30% まで）`, "こつを 聞く", "やめる"))) return;
  if (left(p, "tamer") <= 0) return;
  use(p, "tamer"); const b = bget(p); b.sc = TAMER_UP; bset(p, b);
  act(e, 24); fx(e, "minecraft:heart_particle"); sound(p, "random.orb", 0.8);
  say(p, e, "さあ、行って おいで。きっと 心が 通じるよ");
}
// ---------- 9. 素材の交換屋: 素材 → 道具（作って 売っても もうからない 比率）----------
/* [素材の 段, 何こ, 交換先]。交換先の 売値（3割）は、素材を 店で 買う 値段より 安い */
export const TRADE = [[0, 5, ["c_herb3", "c_water2", "t_bell", "b_atk", "b_def", "b_mat", "b_spd"]], [1, 4, ["c_revive", "c_herbs2", "t_bell2", "b2_atk", "b2_def", "b2_mat", "b2_spd"]], [2, 3, ["s_hp", "s_atk", "s_mat", "s_def", "s_spd", "g_sp2", "c_revive2", "f_exp3k"]]];
const MATS_T = [0, 1, 2].map((t) => Object.keys(ITEMS).filter((id) => ITEMS[id].kind === "material" && (ITEMS[id].tier ?? 0) === t));
const matsOf = (p, t) => (MATS_T[t] || []).map((id) => [id, countItem(p, `mrpg:${id}`)]).filter((x) => x[1] > 0).sort((a, b) => b[1] - a[1]);
async function trader(p, e) {
  if (left(p, "trader") <= 0) { say(p, e, "今日の 交換は もう おしまい。また 明日ね"); return; }
  const d = load(p); if (!d) return; const cap = rankCap(d);
  const R = TRADE.map(([t, n, L]) => ({ t, n, L: L.filter((id) => ITEMS[id] && storyLootOk(ITEMS[id], null, cap) && (ITEMS[id].tier ?? 0) <= wtCap(cap) + 1), have: matsOf(p, t) }));
  const c = await choose(p, HK.trader.n, `§f同じ 段の 素材を まとめて 道具と かえる §7（今日は あと ${left(p, "trader")}回）`, [...R.map((r) => B(`${["ふつうの", "めずらしい", "とても めずらしい"][r.t]} 素材 ×${r.n}\n§8手持ち ${r.have.reduce((a, x) => a + x[1], 0)}こ`, "i_bag")), B("§7やめる", "i_back")]);
  const r = R[c]; if (!r) return;
  if (!r.L.length) { say(p, e, "その 段の 品は、まだ あんたには 早いね。物語を 進めて おいで"); return; }
  const tot = r.have.reduce((a, x) => a + x[1], 0); if (tot < r.n) { say(p, e, `${r.n}こ そろったら また 来てね`); return; }
  const k = await choose(p, HK.trader.n, `§f何と かえる？ §7（多い 素材から ${r.n}こ 使う）`, [...r.L.map((id) => B(ITEMS[id].name, "i_bag")), B("§7やめる", "i_back")]);
  const out = r.L[k]; if (!out || left(p, "trader") <= 0) return;
  const H = matsOf(p, r.t); if (H.reduce((a, x) => a + x[1], 0) < r.n) return;
  let need = r.n; const took = []; for (const [id, n] of H) { if (need <= 0) break; const q = Math.min(n, need); if (q > 0 && takeItem(p, `mrpg:${id}`, q)) { need -= q; took.push([id, q]); } }
  if (need > 0) { for (const [id, q] of took) giveItem(p, `mrpg:${id}`, q); return; }
  use(p, "trader"); giveItem(p, `mrpg:${out}`, 1); act(e, 10); sound(p, "random.orb", 1);
  say(p, e, `はい、${ITEMS[out].name}。いい 取り引きだったね`);
}
// ---------- 10. 流れの鍛冶職人: 装備の 打ち直し（お金と 素材）----------
export const SMITH = [["打ち直し", "find", 1, 3, "レア度・能力・特殊効果を 全部 振り直す"], ["名匠の 打ち直し", "craft", 3, 5, "振り直す（良い 結果が 出やすい）"], ["鍛え上げ", "up", 8, 5, "レア度を 1つ 上げて 振り直す"]];
export const smithCost = (id, mul) => 300 * ((ITEMS[id]?.tier ?? 0) + 1) * ((ITEMS[id]?.tier ?? 0) + 1) * mul;
export const smithMat = (id, mode) => Math.min(2, Math.max(0, (ITEMS[id]?.tier ?? 0) - 1 + (mode === "up" ? 1 : 0)));
async function smith(p, e) {
  if (left(p, "smith") <= 0) { say(p, e, "今日は もう 腕が 上がらねえ。また 明日 来な"); return; }
  const G = gearSlots(p).filter((g) => g.roll).sort((a, b) => gearPower(b.id, b.roll) - gearPower(a.id, a.roll)).slice(0, 24);
  if (!G.length) { say(p, e, "打ち直せる 装備が ねえな。鑑定ずみの 装備を 持って きな"); return; }
  const c = await paged(p, HK.smith.n, `§f打ち直す 装備を 選べ §7（今日は あと ${left(p, "smith")}回）`, G.map((g) => [`${gearName(g.id, g.roll)}`, ICON("i_fight")]), 8);
  const g = G[c]; if (!g) return;
  const d = load(p); if (!d) return;
  const O = SMITH.filter((s) => s[1] !== "up" || g.roll.r < Math.min(8, capOf(p)));
  const s = await choose(p, HK.smith.n, [`§l${gearName(g.id, g.roll)}`, ...gearLines(g.id, g.roll), "", `§fお金: ${gold(d.gold || 0)}`].join("\n"), [...O.map((x) => B(`${x[0]} §8${gold(smithCost(g.id, x[2]))}\n§8${["ふつうの", "めずらしい", "とても めずらしい"][smithMat(g.id, x[1])]} 素材 ×${x[3]}・${x[4]}`, "i_fight")), B("§7やめる", "i_back")]);
  const S = O[s]; if (!S) return;
  const cost = smithCost(g.id, S[2]), mt = smithMat(g.id, S[1]), H = matsOf(p, mt);
  const d2 = load(p); if (!d2 || left(p, "smith") <= 0) return;
  if ((d2.gold || 0) < cost) { await notice(p, HK.smith.n, "§cお金が 足りない……"); return; }
  if (H.reduce((a, x) => a + x[1], 0) < S[3]) { await notice(p, HK.smith.n, `§c${["ふつうの", "めずらしい", "とても めずらしい"][mt]} 素材が ${S[3]}こ いる。`); return; }
  if (!gearSlots(p).some((x) => x.slot === g.slot && x.id === g.id)) return;
  let need = S[3]; for (const [id, n] of H) { if (need <= 0) break; const q = Math.min(n, need); if (q > 0 && takeItem(p, `mrpg:${id}`, q)) need -= q; }
  d2.gold -= cost; save(p, d2); use(p, "smith");
  const roll = capRoll(p, g.id, S[1] === "up" ? rollGear(g.id, "find", Math.min(8, g.roll.r + 1)) : rollGear(g.id, S[1]));
  replaceSlot(p, g.slot, g.id, roll);
  act(e, 18); fx(e, "minecraft:lava_particle"); sound(p, "random.anvil_use", 1);
  say(p, e, pick(["カーン！ ……よし、いい 音だ", "ほらよ。大事に 使いな", "打ち甲斐の ある 鉄だったぜ"]));
  await notice(p, "打ち直し", [`${gearName(g.id, g.roll)} §7→`, `§l${gearName(g.id, roll)}`, ...gearLines(g.id, roll)].join("\n"));
}
const JOB = { monk, merchant, egg, bard, seer, master, cook, tamer, trader, smith };

/* 戦いの はじめ（野生だけ: battle.js が マスター・ボス戦では 呼ばない）: 歌・スカウトの こつ */
START_HOOKS.push((B0, p) => {
  if (!p || B0.pvp) return;
  const b = bget(p); if (!b.song && !b.sc) return;
  const mine = (B0.allies || []).filter((f) => !f.guest && (!f.owner || f.owner === p.id));
  if (b.song) { for (const f of mine) for (const k of b.song) f.buf[k] = Math.min(6, (f.buf[k] || 0) + 1); try { p.sendMessage(`§d♪ ${b.sn || "歌"}の 力！ 仲間の 能力が 上がった`); } catch {} delete b.song; delete b.sn; }
  if (b.sc) { B0.scoutBonus = (B0.scoutBonus || 0) + b.sc; try { p.sendMessage(`§a魔物使いの こつ: スカウトの 成功率 +${b.sc}%`); } catch {} delete b.sc; }
  bset(p, b);
});
export const __fh = { HK, JOB, cnt, bget, bset, left, CAPS };
