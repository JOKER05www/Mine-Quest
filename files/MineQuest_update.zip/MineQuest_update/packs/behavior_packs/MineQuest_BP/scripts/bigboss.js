// 第126版: 物語の ボスを 大きく（敵の 先頭を 人物に 合う 大きな 種族に・見た目の 倍率）
// ランクは もとの 先頭と 同じ（物語の 段の 上限を こえない）。能力は 戦いの 中で もとの 先頭より 下げない（battle.js の was）
import { SPECIES, ORDER } from "./data.js";
import { lookOf } from "./field.js";

const SLOT = { S: 1, M: 2, L: 3, G: 4 };
/* 人物ごとの 好み（系統・属性）。上から 先に 合った もの */
export const BB_PROF = [
  [/ベリル|七番目/, ["golem", "blob", "beast"], ["light"]],
  [/ヴァルカ|三の座/, ["dragon", "nether"], ["fire"]],
  [/ロウ＆ルウ|^ロウ|^ルウ|四・五の座|片手袋/, ["beast", "aqua", "dragon"], ["ice"]],
  [/アルゴ|六の座|仮面の 戦士/, ["sword", "golem"], ["steel", "dark"]],
  [/セオ|二の座/, ["nether", "dragon"], ["dark"]],
  [/ゼファード|星冠王|一の座/, ["king", "dragon", "sword"], ["light", "fire"]],
  [/守り手|十四の 主/, ["dragon"], ["fire", "dark"]],
  [/レイ/, ["dragon"], ["fire", "thunder"]],
  [/森の 主/, ["animal", "beast"], ["wood", "earth"]],
  [/洞くつの 番人/, ["golem"], ["earth"]],
  [/王墓/, ["golem", "nether"], ["earth", "dark"]],
  [/神殿の 番人/, ["aqua"], ["water"]],
  [/雪の 主/, ["beast", "aqua"], ["ice"]],
  [/墓穴|闘技場の 影|記録塔|影の かけら/, ["nether"], ["dark"]],
  [/バルガ|砂ぼこり/, ["beast", "golem"], ["earth"]],
  [/仮面の 王者/, ["beast", "animal"], ["earth", "wind"]],
  [/ガルム|衛兵長/, ["golem", "sword"], ["steel"]],
  [/カゲツ/, ["sword"], ["steel", "wind"]],
];
const hash = (s) => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };
const strip = (t) => String(t || "").replace(/§./g, "");
/* 物語の ボス戦か（名前の ある ボス・地方マスター・王・神・十魔将・石板の 主・カゲツ）*/
export const bbIsBoss = (i) => !!i && !i.ch && !i.pvp && !i.dream && !i.enma && !i.spar && !!(i.sboss || i.final || i.rmaster || i.kengo || i.kingK || (i.deity !== undefined && i.deity !== null) || (i.ruinsBoss !== undefined && i.ruinsBoss !== null) || i.bslab !== undefined || (i.hpk >= 2 && i.speaker) || (i.tag && i.speaker) || /地方マスター|門番/.test(strip(i.name)));
/* 見た目の 倍率: 高さ 8 ほどに（1.5〜2.5倍）。小さい 主（Sの 王・ペンギーノ・人の 姿の 暴走セオ など）は 高さ minH まで（4.5倍まで）。ドームに 入る よう 高さ 11 まで */
export function bbScale(sid, sz, minH = 4) {
  let h = 1; try { h = lookOf(sid, sz ? { sz } : undefined).mh || 1; } catch {}
  const v = Math.max(1.5, Math.min(2.5, 8 / h), Math.min(4.5, minH / h));
  return Math.round(Math.min(v, Math.max(1, 11 / h)) * 100) / 100;
}
function pickOf(list, prefs, key) {
  if (!list.length) return null;
  const sc = (x) => (SPECIES[x].aff?.ge || []).filter((e) => prefs.includes(e)).length * 2 + (SPECIES[x].sz === "G" ? 1 : 0);
  const best = Math.max(...list.map(sc)), top = list.filter((x) => sc(x) === best);
  return top[hash(key) % top.length];
}
/* 先頭を 大きな 種族に（S・M の とき だけ）。決まった 種族の ボス（王・神・十魔将・石板の 主・特別な 種族）は 倍率だけ */
export function bigBoss(team, info) {
  try {
    if (!Array.isArray(team) || !team.length || !bbIsBoss(info) || globalThis.__bbOff) return team;
    const t0 = team[0]; if (!t0 || t0.m || t0.was || !SPECIES[t0.sid]) return team;
    const S0 = SPECIES[t0.sid], nm = strip(`${info.speaker || ""} ${info.name || ""}`);
    const fixed = S0.hidden || S0.anim || ["god", "king"].includes(S0.fam) || info.kingK || info.deity != null || info.ruinsBoss != null || info.bslab !== undefined;
    let sid = t0.sid;
    const pr = BB_PROF.find(([re]) => re.test(nm)), small = S0.sz === "S" || S0.sz === "M";
    if (!fixed && !t0.sz && !small && pr) {   /* もう 大きい ときも、人物の 好みの 大きな 種族が あれば そちらに（いつも 同じ 相棒）*/
      const used = new Set(team.slice(1).map((t) => t.sid)), key = info.kengo ? nm + t0.sid : nm;
      sid = pickOf(ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !S.sea && !S.giant && S.fam !== "god" && S.rank === S0.rank && !used.has(x) && pr[1].includes(S.fam) && ["L", "G"].includes(S.sz); }), pr[2], key) || t0.sid;
    }
    if (!fixed && !t0.sz && small) {
      const fams = pr ? pr[1] : [S0.fam], els = pr ? pr[2] : S0.aff?.ge || [];
      const used = new Set(team.slice(1).map((t) => t.sid));
      const base = (x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !S.sea && !S.giant && S.fam !== "god" && S.rank === S0.rank && !used.has(x); };
      const key = info.kengo ? nm + t0.sid : nm;
      sid = pickOf(ORDER.filter((x) => base(x) && fams.includes(SPECIES[x].fam) && ["L", "G"].includes(SPECIES[x].sz)), els, key)
        || pickOf(ORDER.filter((x) => base(x) && SPECIES[x].fam !== "king" && ["L", "G"].includes(SPECIES[x].sz)), els, key)
        || (S0.sz === "S" ? pickOf(ORDER.filter((x) => base(x) && fams.includes(SPECIES[x].fam) && SPECIES[x].fam !== "king" && SPECIES[x].sz === "M"), els, key) : null)
        || t0.sid;
    }
    const n0 = sid !== t0.sid ? { ...t0, sid, was: t0.sid, slot0: SLOT[S0.sz] || 2 } : { ...t0 };
    n0.vsc = bbScale(sid, t0.sz, fixed && SPECIES[sid].sz === "G" ? 7 : 4);
    return [n0, ...team.slice(1)];
  } catch { return team; }
}
