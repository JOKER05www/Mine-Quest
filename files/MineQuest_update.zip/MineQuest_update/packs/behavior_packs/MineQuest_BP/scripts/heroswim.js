// 第124版: 旅の 仲間（ヒロイン）が 遊びに 来る（キャンプ・海辺）と 水着の 切りかえ
// ・物語の 場面の ヒロインは さわらない（台本の 見た目を 守る）。ここで 出す ヒロインには mrpg_hfun を つける
// ・水着に なる: 海の 近くの 砂の 上・heroSwim(p, true) の あいだ（遊び場の 水泳 など）。町・戦い・物語の 場面では 元の 服
// ・見回りは 50tickごと（ヒロインを えらんだ 人だけ・近くの 16マス）
import { world, system } from "@minecraft/server";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { PSKIN } from "./skinjobs.js";
import { HEROES, __mqTest, heroAway } from "./saga.js";
import { inScene } from "./talk.js";
import { stageOf } from "./stagecore.js";
import { inBattle } from "./battle.js";

const OWID = "minecraft:overworld";
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const pick = (L) => L[Math.floor(Math.random() * L.length)];
/* 話し方（saga.js の HT と 同じ）g 元気・o おっとり・c クール・t ていねい */
const HT = { hero_rio: "g", hero_chloe: "g", hero_hana: "g", hero_lulu: "g", hero_yuna: "o", hero_shion: "o", hero_mia: "c", hero_leaf: "c", hero_nami: "c", hero_mel: "t", hero_kaede: "t", hero_cecil: "t" };
/* 好きな 料理（キャンプの 料理の id）*/
export const FAV = { hero_rio: "fd_curry", hero_chloe: "fd_cake", hero_hana: "fd_bento", hero_lulu: "fd_cake", hero_yuna: "fd_stew", hero_shion: "fd_tea", hero_mia: "fd_cake", hero_leaf: "fd_bento", hero_nami: "fd_curry", hero_mel: "fd_tea", hero_kaede: "fd_bento", hero_cecil: "fd_stew" };

export function heroInfo(p) {
  try { const d = load(p), k = d && !heroAway(d) && qs(d).hero; const h = HEROES.find((x) => x[0] === k); return h ? { key: h[0], name: h[1], t: HT[h[0]] || "g" } : null; } catch { return null; }
}
/* 見た目の 番号（水着が なければ 元の 服）*/
export function heroJob(key, swim) { const a = PSKIN[key], b = PSKIN[`${key}_sw`]; return (swim && b ? b[0] : a ? a[0] : 9); }
/* 物語の 場面・会話の 最中（服を 変えない）*/
export function inStory(p) { try { return __mqTest.MQRUN.has(p.id) || !!stageOf(p) || inScene(p); } catch { return false; } }
/* 海の 近くの 砂の 上 */
const isSand = (t) => /(^minecraft:sand$|_sand$|gravel)/.test(t || "") && !/stone/.test(t || "");
export function onBeach(p) {
  try {
    if (p.dimension.id !== OWID) return false;
    const D = p.dimension, l = p.location, x = Math.floor(l.x), y = Math.floor(l.y), z = Math.floor(l.z);
    if (!isSand(D.getBlock({ x, y: y - 1, z })?.typeId)) return false;
    for (const [dx, dz] of [[4, 0], [-4, 0], [0, 4], [0, -4], [3, 3], [-3, -3], [3, -3], [-3, 3], [7, 0], [-7, 0], [0, 7], [0, -7]])
      for (const dy of [-1, -2]) if (D.getBlock({ x: x + dx, y: y + dy, z: z + dz })?.typeId === "minecraft:water") return true;
  } catch {}
  return false;
}
const FORCE = new Set();   /* heroSwim(p, true) の 人 */
export const wantSwim = (p) => { try { return !inStory(p) && !inBattle(p) && (FORCE.has(p.id) || onBeach(p)); } catch { return false; } };

/* ここで 出した ヒロイン（pid → Set<entity>）*/
const HF = new Map();
const mine = (p) => [...(HF.get(p.id) || [])].filter(okE);
/* ヒロインを 出す（いなければ null）。opt.swim で 水着かを 決める（省くと 今の 場所で 決める）*/
export function heroSpawn(p, at, opt = {}) {
  const h = heroInfo(p); if (!h || !at) return null;
  let e = null; try { e = p.dimension.spawnEntity("mrpg:npc", at); } catch { return null; }
  try {
    const sw = opt.swim ?? wantSwim(p);
    e.setProperty("mrpg:job", heroJob(h.key, sw)); e.nameTag = `§d${h.name}`;
    e.addTag("mrpg_npc"); e.addTag("mrpg_hfun"); for (const t of opt.tags || []) e.addTag(t);
    e.setDynamicProperty("mrpg:hown", p.id); e.setDynamicProperty("mrpg:hsw", !!sw);
    if (opt.face) e.teleport(at, { facingLocation: opt.face });
  } catch {}
  const S = HF.get(p.id) || new Set(); S.add(e); HF.set(p.id, S);
  return e;
}
export function heroDespawn(p, e) {
  const S = HF.get(p.id);
  for (const x of e ? [e] : [...(S || [])]) { try { if (okE(x)) x.remove(); } catch {} S?.delete(x); }
  if (S && !S.size) HF.delete(p.id);
}
/* 水着に する・もどす（遊び場の 水泳 など ほかの 遊びから 呼ぶ）。e を わたすと その ヒロインだけ。物語の 場面中は 何も しない */
export function heroSwim(p, on, e) {
  if (on) FORCE.add(p.id); else FORCE.delete(p.id);
  const h = heroInfo(p); if (!h) return false;
  if (on && inStory(p)) return false;
  const sw = on ? true : wantSwim(p);
  for (const x of e ? [e] : mine(p)) setSwim(x, h.key, sw);
  return true;
}
function setSwim(e, key, sw) {
  try { if (!okE(e) || e.hasTag("mrpg_saga") || e.hasTag("mrpg_hero")) return; if (!!e.getDynamicProperty("mrpg:hsw") === sw) return; e.setProperty("mrpg:job", heroJob(key, sw)); e.setDynamicProperty("mrpg:hsw", sw); } catch {}
}
/* ヒロインの ひとこと（会話の 画面を 出さない。チャットに 1行・しぐさ）。L は {g,o,c,t} */
export function heroLine(p, L, e, act) {
  const h = heroInfo(p); if (!h || !L) return null;
  const s = Array.isArray(L) ? pick(L) : pick([].concat(L[h.t] || L.g));
  try { p.sendMessage(`§d${h.name}§f「${s}」`); } catch {}
  if (act && okE(e)) try { e.setProperty("mrpg:act", act); system.runTimeout(() => { try { if (okE(e) && e.getProperty("mrpg:act") === act) e.setProperty("mrpg:act", e.getDynamicProperty("mrpg:act0") || 0); } catch {} }, 50); } catch {}
  return s;
}

/* 見回り（50tick）: 服の 切りかえ・物語が はじまったら 遊びの ヒロインを しまう・いない 人の ヒロインを 片づける */
system.runInterval(() => {
  const on = new Set();
  for (const p of world.getAllPlayers()) {
    on.add(p.id);
    const L = mine(p); if (!L.length) { HF.delete(p.id); FORCE.delete(p.id); continue; }
    if (inStory(p)) { heroDespawn(p); continue; }   /* 物語の ヒロインと 二人に ならない */
    const h = heroInfo(p); if (!h) { heroDespawn(p); continue; }
    const sw = wantSwim(p);
    for (const e of L) { let b = false; try { b = e.hasTag("mrpg_beach"); } catch {} setSwim(e, h.key, b || sw); }   /* 浜の 遊びの 仲間は ずっと 水着 */
  }
  for (const id of [...HF.keys()]) if (!on.has(id)) { for (const e of HF.get(id)) try { if (okE(e)) e.remove(); } catch {} HF.delete(id); FORCE.delete(id); }
}, 50);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { for (const e of HF.get(playerId) || []) try { if (okE(e)) e.remove(); } catch {} HF.delete(playerId); FORCE.delete(playerId); }); } catch {}
/* 起動した とき: 前に 残った 遊びの ヒロインを 片づける */
system.runTimeout(() => { try { const live = new Set([...HF.values()].flatMap((S) => [...S].map((e) => e.id))); for (const e of world.getDimension(OWID).getEntities({ tags: ["mrpg_hfun"] })) if (!live.has(e.id)) e.remove(); } catch {} }, 100);
/* 第124版: 60秒ごとに 人の 近くだけ 見回る（抜けた とき 読みこまれて いなかった 遊びの ヒロイン）*/
system.runInterval(() => { try { const live = new Set([...HF.values()].flatMap((S) => [...S].map((e) => e.id))), ow = world.getDimension(OWID); for (const q of world.getAllPlayers()) { if (q.dimension.id !== OWID) continue; for (const e of ow.getEntities({ tags: ["mrpg_hfun"], location: q.location, maxDistance: 96 })) if (!live.has(e.id)) try { e.remove(); } catch {} } } catch {} }, 1200);
export const __hswim = { HF, FORCE, HT, heroInfo, heroJob, onBeach, wantSwim, heroSpawn, heroDespawn, heroSwim, heroLine, inStory };
