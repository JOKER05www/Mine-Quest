// 第125版: 物語の 登場人物（名前・役割・語尾・見た目）。地方の 話（ep_r*.js）の 場面で 使い、話の あとは 町に 立って「その後」を 話す
// ・見た目は 今 ある 町の 人・外の 人の スキン（skinjobs.js の PSKIN の キー か、職業の 番号）から えらぶ。新しい モデルは 作らない
// ・登録: castAdd("mimi", { nm: "ミミ", role: "パン屋の 娘", gobi: "だよっ", skin: "mimi", town: "t0", at: () => ({ x, z }), from: "r0e2", pre: [...], after: [[(s) => 条件, ["せりふ", ...]], ...] })
//     nm 名前 ／ role 役割（名札の 前に つく）／ gobi 語尾（点検で 数える）／ col 名前の 色（§e）／ town 住む 町の id
//     at 立つ 場所（{x,z} を 返す 関数。y は 地面を さがす）／ from この 話（ep の id）を 終えた 人には 町に 見える
//     after 話しかけた 人の 進みで かわる「その後」（上から 順に 見て 最初に 合う もの）／ pre まだ 話の 前の 人への ひとこと
// ・軽く: 5秒ごとに 近く（40マス）の 人だけ 見る。1人 1体。場面の そば（24マス）・遠く（96マス）では 消す
import { world, system } from "@minecraft/server";
import { ok, busy, choose, ICON, setJob, sound } from "./ui.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { PSKIN } from "./skinjobs.js";
import { skinNo, namedJob, nameAdd } from "./namedskin.js";
import { groundY } from "./structures.js";
import { NPC_HOOKS } from "./npchook.js";
import { stageOf, inCam } from "./stagecore.js";
import { BKID } from "./book.js";

export const CAST = {};
export const CAST_HOOK = { done: null };   /* (d, ep の id) => 済んだか（sagaep.js が 入れる）*/
export function castAdd(id, o) { CAST[id] = { id, col: "§e", ...o }; try { nameAdd(o.nm, typeof o.skin === "number" ? o.skin : skinNo(o.skin, 8)); } catch {} return CAST[id]; }   /* 第126版(fix): 名前で 出す 場面も この 人の 見た目に */
export const castTag = (id) => { const c = CAST[id]; return c ? `${c.col}${c.role ? `${c.role} ` : ""}${c.nm}` : String(id); };
export const castJob = (id) => { const c = CAST[id]; if (!c) return 8; const j = typeof c.skin === "number" ? c.skin : skinNo(c.skin, 8); return namedJob(c.nm, j); };   /* 第126版(fix): スキンが ない・マスターの 番号なら 名前から */
/* 「世界が 滅びかける」時期。after に [(s) => doomed(s), ["…"]] と 書く（ending より 下・heroDead より 上に 置く）。この 時期は collapse.js が 空・町・店を かえる
   第126版(S5): 時期を バイブルに 合わせる（00 §1・03_main「迫害の 流れ」）
   doomed    = 本14-6（幼なじみが 影の槍に。heroDead）〜 終章。空が 暗い
   doomKnown = 本16-1（風の 町で 声が 世界に 流れる。voice）の あと。shadowLive = その うち 本18-8（ルミナで 名を 三度 呼び、影が 闘技場の 下へ 沈む）まで。町の 人に 影が 宿る
   shunTown  = 迫害（町が 背を 向ける）: ノクト 本9-1〜・グレイヴ 本9-4〜／スノウ 本10-1〜（C10=d なら 本12-1 で 開く）／ルミナ 本17-8〜。どれも 本18-8 で 終わる */
const B32 = "0123456789abcdefghijklmnopqrstuv", BKI = new Map(BKID.map((x, i) => [x, i]));
export function bkDone(s, id) { const i = BKI.get(id); if (i === undefined || !s || typeof s.bk !== "string") return false; const c = s.bk[(i / 5) | 0]; return !!c && ((B32.indexOf(c) >> i % 5) & 1) === 1; }
export const calmed = (s) => !!(s && (s.ending || bkDone(s, "b18e8") || (s.epx && s.epx.lbell)));
export const doomed = (s) => !!(s && s.heroDead && !s.ending);
export const doomKnown = (s) => doomed(s) && !!(s.epx && s.epx.voice);   /* 声を 聞いた あと（町の 人の その後の せりふ用）*/
export const shadowLive = (s) => doomKnown(s) && !calmed(s);   /* 町に 影が 宿る（collapse.js）。本18-8 で 終わる */
export const SHUN = {
  t7: { from: "b09e1", nm: "ノクト", why: "宿の 戸に『石板の 子が 通った 町は、石に なる』の 張り紙" },
  t37: { from: "b09e4", nm: "グレイヴ", why: "広場の 掲示板に、下手な 似顔絵の 張り紙" },
  t38: { from: "b10e1", nm: "スノウ", why: "町の 門が 閉まって いる。門の 内側から 小さな 声が する", open: (s) => !!(s.ch && s.ch.c10 === "d") && bkDone(s, "b12e1") },
  t0: { from: "b17e8", nm: "ルミナ", why: "南の 入口の 門が 閉まって いる。槍の 先が 内側を 向いて いる" },
};
export const shunned = (s) => !!s && !calmed(s) && bkDone(s, "b09e1");
export function shunTown(s, tid) { const T = SHUN[tid]; if (!T || !s || calmed(s) || !bkDone(s, T.from)) return null; try { if (T.open && T.open(s)) return null; } catch {} return T; }
const OW = () => world.getDimension("minecraft:overworld");
const LIVE = new Map();
const POS = new Map();
const rm = (e) => { if (ok(e)) try { e.remove(); } catch {} };
function posOf(c) {
  const v = POS.get(c.id); if (v && Date.now() - v.t < 60000) return v.q;
  let q = null; try { const a = c.at && c.at(); if (a && Number.isFinite(a.x) && Number.isFinite(a.z)) { const y0 = Number.isFinite(a.y) ? a.y : 70; const y = groundY(OW(), Math.floor(a.x), Math.floor(a.z), y0 + 12); q = typeof y === "number" ? { x: Math.floor(a.x) + 0.5, y, z: Math.floor(a.z) + 0.5 } : null; } } catch {}
  POS.set(c.id, { q, t: Date.now() }); return q;
}
const hideFor = (c, d) => { try { return !!c.hide(qs(d), d); } catch { return false; } };
const doneFor = (d, id) => { try { return !id || !!(CAST_HOOK.done && CAST_HOOK.done(d, id)); } catch { return false; } };
function tick() {
  let P = []; try { P = world.getAllPlayers().filter((p) => p.dimension.id === "minecraft:overworld"); } catch { return; }
  for (const c of Object.values(CAST)) {
    if (!c.town || !c.at) continue;
    let e = LIVE.get(c.id); if (e && !ok(e)) { LIVE.delete(c.id); e = null; }
    const q = posOf(c); if (!q) continue;
    let far = true, want = false, scene = false, seen = false;
    for (const p of P) {
      const dd = Math.hypot(p.location.x - q.x, p.location.z - q.z); if (dd < 96) far = false;
      if (dd < 24 && globalThis.__mqScene?.has(p.id)) { scene = true; try { if (e && ok(e) && inCam(p, e.location, stageOf(p)?.C)) seen = true; } catch {} }   /* 第124版(fix2): 映って いる 間は 消さない（あとで 映らなく なってから）*/
      if (dd < 40 && !want) { const d = load(p); if (d && doneFor(d, c.from) && (!c.end || qs(d).ending) && !(c.until && doneFor(d, c.until)) && !(c.hide && hideFor(c, d))) want = true; }   /* 第125版: until（次の 場所へ 移った）・hide（石に なって いる など）*/   /* 第124版: クリア後だけの 人は、近くの クリアした 人にだけ */
    }
    if (far || scene || !want) { if (e && !seen) { rm(e); LIVE.delete(c.id); } continue; }
    if (e) continue;
    try { e = OW().spawnEntity("mrpg:npc", q); setJob(e, castJob(c.id)); e.addTag("mrpg_npc"); e.addTag("mrpg_cast"); e.setDynamicProperty("mrpg:cast", c.id); e.nameTag = castTag(c.id); LIVE.set(c.id, e); } catch {}
  }
}
system.runInterval(tick, 100);
function sweep() { try { const own = new Set([...LIVE.values()].filter(ok).map((e) => e.id)); for (const e of OW().getEntities({ type: "mrpg:npc", tags: ["mrpg_cast"] })) if (!own.has(e.id)) rm(e); } catch {} }
system.runInterval(sweep, 1200); system.runTimeout(sweep, 60);
/* 話しかける: その人の 進みで かわる「その後」*/
export function castLines(p, id) {
  const c = CAST[id]; if (!c) return [];
  const d = load(p); if (!d) return [];
  if (!doneFor(d, c.from)) return [].concat(c.pre || ["……"]);
  const s = qs(d);
  for (const [f, L] of c.after || []) { try { if (f(s, d)) return [].concat(L); } catch {} }
  return [].concat(c.pre || ["……"]);
}
async function castTalk(p, e, id) {
  const c = CAST[id]; if (!c || busy.has(p.id)) return;
  busy.add(p.id);
  try {
    try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); e.setProperty("mrpg:act", 4); } catch {}
    sound(p, "random.pop", 0.6);
    const L = castLines(p, id).map((l) => `${c.col}${c.nm}§f「${String(l).replace(/^\{[^}]*\}/, "")}」`);
    await choose(p, castTag(id).replace(/§./g, ""), L.join("\n\n"), [["§lOK", ICON("i_back")]]);
  } finally { busy.delete(p.id); try { if (ok(e)) e.setProperty("mrpg:act", 0); } catch {} }
}
NPC_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_cast")) return false;
  let id = null; try { id = e.getDynamicProperty("mrpg:cast"); } catch {}
  if (typeof id !== "string" || !CAST[id]) { rm(e); return true; }
  system.run(() => { castTalk(p, e, id).catch(() => {}); });
  return true;
});
export const __cast = { LIVE, tick, sweep, castTalk };
