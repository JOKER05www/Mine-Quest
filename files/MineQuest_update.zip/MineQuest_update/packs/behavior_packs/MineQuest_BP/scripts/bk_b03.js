/* 第126版 本3「廃都の壁画」（ルインズ荒野・ガレキ／セプルク／グランディア）— 作業 MA
   ・古い 話 r2e1・r2e2・r2e3・r2e5（ep_r2.js）を 生かす。新しい 話: 4話 セプルク（名を 削られた 墓・芝居小屋の 石の 道化）
   ・MQ6 = b03e5 崖道（C03 で 戦うか 通るか）・b03e6 壁画の 広間・b03e7 ジンの 城の 中庭（今の 段の 場面の かわり）
   ・MQ7 = b03e8 ジンの 城（マスター戦の あと。鞘）→ 道が 開けた（ジン 本人が 水路と 火山の 話を する。手紙は 使わない）
   第127版(ST): 筋を 一本に。なぜ 壁画へ（石板に 名が 書けない ＝ 石に 彫られた 話は 全部では ない → 千年前の 唯一の 記録を 見る）／ジンは だれか（代々 壁画の 番人。十二年前の 冬、番に 出て いた 夜に 妻が 石に なった。それから 鞘を 持たない）／壁画で 何が 分かるか（王の 隣の 影は 二度 削られた。上は 人が、下の 頁の 形は「影が 自分で」）*/
import { bkAdd, mqOver, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facMark, facSide } from "./epfac.js";
import { H4, Y, OLDE, oldRun, once, gy, at2, out, stoneMan } from "./bk_b01.js";
import { placeOf, townOut, openSite } from "./storyplace.js";
import { ok } from "./ui.js";

const C0 = (K, p) => { const S = K.S(p); return S && S.opt && S.opt.anchor ? S.opt.anchor : p.location; };
const PL = (oid) => (p) => { const o = OLDE(oid); try { return o ? o.place(p) : null; } catch { return null; } };
/* 第127版(fac): 墓地と 芝居小屋は 町から 離れた 古い 墓地（ステージ・遺跡から 離す。芝居小屋は 客席・舞台・幕の ある 大きな 建物）*/
const SEPUL = () => { const o = townOut("t10", 0.6, "墓標の 町 セプルクの 外れ"); if (!o) return null; return openSite("b03sepul", o, 2, 70, 300, "墓標の 町 セプルクの 外れ（墓地と 芝居小屋）") || { x: o.x, z: o.z, nm: "墓標の 町 セプルクの 外れ（墓地と 芝居小屋）" }; };
const KEN = (K, p, w = false) => K.npcNear(p, "§c弟子 ケン", K.PJ("ken", 8), w);
const HARU = (K, p, w = false) => K.npcNear(p, "§c弟子 ハルカ", K.PJ("haku", 8), w);

/* ---------- 施設: セプルクの 芝居小屋（幕の 上がった 舞台・石に なった 道化たち・まん中の 空き）---------- */
const { F, S1 } = FAC_OPS;
facAdd("b03stage", { D: [12, 15, 10], box: [-1, -5, 5, 5], H: 5, look: [2, 0, 1.6], marks: { gap: [2, 0, 1.2] }, build: () => [
  F(1, -4, 0, 4, 4, 0, "spruce_planks"), F(0, -4, 0, 0, 4, 0, "spruce_slab"),
  F(4, -5, 1, 4, -5, 4, "spruce_log"), F(4, 5, 1, 4, 5, 4, "spruce_log"), F(1, -5, 1, 1, -5, 4, "spruce_log"), F(1, 5, 1, 1, 5, 4, "spruce_log"),
  F(1, -4, 4, 1, -3, 4, "red_wool"), F(1, 3, 4, 1, 4, 4, "red_wool"), F(2, -5, 5, 4, 5, 5, "spruce_slab"),
  S1(2, -2, 1, "cobblestone_wall"), S1(2, -2, 2, "stone"), S1(3, -3, 1, "cobblestone_wall"), S1(3, -3, 2, "stone"),
  S1(2, 2, 1, "cobblestone_wall"), S1(2, 2, 2, "stone"), S1(3, 3, 1, "cobblestone_wall"), S1(3, 3, 2, "stone"),
  S1(2, 0, 1, "white_carpet"), S1(3, -1, 4, 'lantern ["hanging"=true]'), S1(3, 1, 4, 'lantern ["hanging"=true]'),
] });

/* ---------- 登場人物 ---------- */
castAdd("b03kid", { nm: "コト", role: "ガレキの", gobi: "の", skin: 6, town: "t5", hide: (s) => !bkHas(s, "b03e9"),
  at: () => { const o = OLDE("r2e1"); const q = o && o.place ? (() => { try { return o.place(); } catch { return null; } })() : null; return q ? { x: q.x + 3, z: q.z + 2 } : null; },
  pre: ["{smile}……。"],
  after: [
    [(s) => (s.ch || {}).c03 === "h", ["{sad}……ねつ、さがったの。ドルフおじさんが、ずっと 井戸の 水を くんで くれたの。"]],
    [() => true, ["{smile,☆}水筒の 水、おいしかったの！ 井戸の 水も、もっと おいしいの！"]],
  ] });
castAdd("b03haru", { nm: "ハルカ", role: "ジンの 弟子", gobi: "", skin: "haku", town: "t5", hide: (s) => !bkHas(s, "b03e8"),
  at: () => { const o = OLDE("r2e5"); const q = o && o.place ? (() => { try { return o.place(); } catch { return null; } })() : null; return q ? { x: q.x - 4, z: q.z + 3 } : null; },
  pre: ["{closed}……修行中よ。"],
  after: [
    [(s) => (s.ch || {}).c03 === "h", ["{smile}あの 水筒、まだ 持ってるの。……返さないわよ。お守り だから。"]],
    [() => true, ["{closed}……師匠は 今朝も 剣を 磨いてた。鞘は、あなたが 持って 行ったけどね。"]],
  ] });

/* ---------- 1話 はいきょの 村ガレキ（古い r2e1）---------- */
const E1 = { id: "b03e1", pv: 127, t: "乾いた 村", battles: 0,
  place: PL("r2e1"),
  hint: "§fルインズ荒野の §eはいきょの 村 ガレキの 外れの 古井戸§f へ 行こう",
  syn: "ガレキの 古井戸は、底まで 乾いて いた。自警団長の ドルフは、のどを からした 子に 自分の 水を ゆずった。「昔は、そうじゃ なかったんだがな」。",
  async run(p, d, K) { return oldRun(p, d, K, "r2e1", E1); } };

/* ---------- 2話 ガレキの 配給所（古い r2e2 ＋ 水筒の 選択 C03 ＋ トキ婆の 言い伝え）---------- */
const E2 = { id: "b03e2", pv: 127, t: "語り部", F: ["F01", "F14", "F62"], battles: 0, fac: "r2ration",
  place: PL("r2e2"),
  hint: "§fガレキの 外れの §e水の 配給所§f へ 行こう §7（ドルフが 水を 分ける）",
  syn: "配給所で 水の 取り合いが 起きた。のどの 渇いた 子が、あなたの 水筒を 見て いた。語り部の トキ婆は「王の 隣の 影」の 話を し、近衛の 家の 若い 衆が やけどを 仮面で 隠して いた こと、「王冠が 静まるまで 開けては ならぬ」と いう ばあさまの 口ぐせを 話した。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r2e2", E2))) return false;   /* 王の 隣の 影 /*F01*/
    await K.open(p, "ガレキの 配給所（夕方）", "dusk", "dusk");
    const eH = K.hero(p), kid = K.npcNear(p, "§7ガレキの 子 コト", 6); K.act(kid, "down");
    await K.pull(p, kid, 18);
    await K.narr(p, ["§7配給の 列の 最後。桶は もう 空。小さな 子が、あなたの 腰の 水筒を じっと 見て いる。"], kid);
    await K.up(p, eH, 8);
    await K.hsay(p, H4(["{sad}……水筒、一つしか ないんだよね。この 先の 荒野で 要るかも……。"], ["{sad}……水筒は 一つ。この 先の 荒野を 思うと……。"], ["{closed}水筒は 一つ。……この 先、荒野。"], ["{sad}……水筒は 一つきり。この 先の 荒野で 要るかも しれません。"]), kid);
    const v = await K.pick(p, "c03");
    if (v === "c") {
      if (ok(eH) && ok(kid)) { await K.approach(p, eH, kid, 1.3); await K.give(eH, kid, "bucket"); }
      await K.up(p, kid, 8);
      await K.say(p, "コト", ["{smile,☆}……ありがとう、なの。"]);
    } else {
      await K.up(p, kid, 8);
      await K.narr(p, ["§7子は 目を ふせて、空の 桶の そばに しゃがみこんだ。"], kid);
    }
    /* トキ婆の 言い伝え /*F14 F62*/
    const eT = K.cast(p, "r2toki"); K.hold(eT, "staff");
    await K.up(p, eT, 10);
    await K.csay(p, "r2toki", ["{closed}……水を 分けたの。見て おったよ。", "{?}ばあさまの 口ぐせを、もう 一つ 思い出したんじゃった。『§e王冠が 静まるまで、開けては ならぬ§f』。"], eH);   /* 第127版: 近衛の 話は r2e2 で 済み（くり返さない）*/
    await K.hsay(p, H4(["{?}王冠……？ 何を 開けちゃ いけないの？"], ["{?}王冠……。何を 開けては いけないの？"], ["{?}王冠。……何を。"], ["{?}王冠……？ 何を 開けては ならないのでしょう。"]), eT);
    await K.csay(p, "r2toki", ["{smile,…}……わしにも 意味は 分からん。忘れられた ほうの 話は、たいてい そういう もんじゃった。"], eH);
    await K.end(p, { leave: [eT], bye: [kid] });
    return true;
  } };

/* ---------- 3話 涸れ谷の 水門（古い r2e3）---------- */
const E3 = { id: "b03e3", t: "涸れ谷の 水門", battles: 2, fac: "r2gate", pv: 127,
  place: PL("r2e3"),
  hint: "§fガレキの 外れの §e涸れ谷の 水門§f へ 行こう §7（砂ぼこり団が 水を 止めて いる）",
  syn: "水門で 砂ぼこり団の 頭 バルガと 会った。ドルフの 昔の 相棒。勝負の あと、バルガは「三日 だけ」と 水門を 半分 開けた。",
  async run(p, d, K) { return oldRun(p, d, K, "r2e3", E3); } };

/* ---------- 4話 墓標の 町セプルク（新）---------- */
const E4 = { id: "b03e4", t: "名を 削られた 墓", F: ["F16", "F56", "F59"], battles: 0, pv: 127,
  place: () => SEPUL(),
  hint: "§f墓標の 町 §eセプルクの 外れ§f へ 行こう §7（墓地と 古い 芝居小屋）",
  syn: "セプルクの 墓地に、名を 削られた 墓が あった。碑には「弁明は しない。記録だけを 残す」。古い 芝居小屋の、幕の 上がった 舞台では、道化の 一座が 石に なって いた。まん中に、台本を 抱いた 子が 立つ はずの 空きが あった。",
  async run(p, d, K) {
    const y0 = Y(K, p), gq = K.fac(p, "b03graves", "graves", 2, y0);
    await K.open(p, "墓標の 町 セプルクの 外れ", "dusk", "dusk");
    const eH = K.hero(p);
    const gv = gq || at2(K, p, 8, 0, 1);
    await K.at(p, gv, 16, 3.4, 0.6);
    await K.narr(p, ["§7墓石が 並ぶ 中に 一つだけ、名を 削り取られた 墓。……削り跡は 深い。"], gv);
    await K.push(p, gv, 22, 3, 1.2, 0.6);   /* 碑の 字 /*F59*/
    await K.narr(p, ["§7その 下の 碑だけは、字が 残って いる。「§f弁明は しない。記録だけを 残す§7」"], gv);
    await K.up(p, eH, 8);
    await K.hsay(p, H4(["{?}名前を 削られたのに、記録だけ 残すって……だれの 墓なんだろ。"], ["{?}名前は 削られて、記録だけ……。だれの お墓かしら。"], ["{?}名は 削られて、記録は 残す。……だれの 墓。"], ["{?}お名前は 削られて、記録だけ……。どなたの お墓でしょう。"]));
    /* 芝居小屋 */
    const S = K.S(p); let tq = null; try { tq = facSide(p, S, -14, "b03stage", "b03stage", 2, y0); } catch {}
    if (tq) await K.moveTo(p, { x: tq.x, y: y0, z: tq.z }, "セプルクの 芝居小屋", [], tq, 10);
    else await K.open(p, "セプルクの 芝居小屋", "dusk", "dusk");
    const stg = tq || at2(K, p, 8, 0, 1);
    await K.pull(p, stg, 24);
    await K.narr(p, ["§7幕の 上がった 舞台。道化の 衣装の 一座が、踊りの 途中の まま 石に なって いる。"], stg);
    const gap = facMark("b03stage", "gap", p.location) || stg;
    await K.push(p, gap, 22, 3.4, 1.2, 0.4);   /* まん中の 空き /*F56 F16*/
    await K.narr(p, ["§7石の 道化たちの まん中だけ、一人ぶん 空いて いる。……台本を 抱いた 子が 立つ はずの 場所。"], gap);
    const eH2 = K.hero(p);
    await K.up(p, eH2, 8);
    await K.hsay(p, H4(["{sad,…}……ミミが 言ってた 道化の 一座の 女の子……ここに いたのかな。"], ["{sad}……ミミちゃんの 言ってた 一座の 子、ここに いたのかしら。"], ["{closed}……ミミの 言ってた 一座。真ん中が 空いてる。"], ["{sad}……ミミさんの お話の 一座……。真ん中の 子は、どこへ。"]));
    await K.end(p, { card: "§7― 廃都 グランディアへ ―" });
    return true;
  } };

/* ---------- 5話 崖道（MQ6。C03: 水筒が あれば 戦わずに 通る）---------- */
const E5 = { id: "b03e5", t: "崖道",
  hint: "§fルインズ荒野の §e廃都の 手前の 崖道§f を 進もう",
  syn: "崖道で はぐれ者の ザジが、ジンの 弟子 ケンと ハルカを 待ち伏せて いた。弟子たちは 空の 水筒を 逆さに 振って いた。",
  async run(p, d, K) {
    const y0 = Y(K, p), CW = K.fac(p, "r2cliff", "cliffwall", 2, y0), CT = CW && facMark("r2cliff", "top", p.location);
    await K.open(p, "廃都の 手前の 崖道", "day");
    const eH = K.hero(p), eK = KEN(K, p), eR = HARU(K, p); K.act(eR, "kneel");
    const eZ = K.npcNear(p, "§6砂ぼこり団の はぐれ者 ザジ", K.PJ("bandit", 9)); K.act(eZ, "guard");
    if (CT) await K.at(p, CT, 12, 6, 0.8);
    await K.up(p, eZ, 8);
    await K.say(p, "ザジ", ["{angry,low}修行帰りで へとへとの 今が 狙い目さ。水と モンスターを 置いて いけ、小僧ども。"]);
    K.act(eK, "show"); K.hold(eK, "bucket");
    await K.push(p, eK, 18, 3.6, 1.6, 1.1);
    await K.narr(p, ["§7弟子の ケンと ハルカが、空の 水筒を 逆さに 振る。……一滴も 落ちない。"], eK);
    const s = K.qs(K.load(p) || d), v = K.chGet(s, "c03");
    if (v === "h") {
      if (ok(eH) && ok(eR)) { await K.approach(p, eH, eR, 1.3); await K.give(eH, eR, "bucket"); }
      await K.up(p, eR, 8);
      await K.say(p, "弟子 ハルカ", ["{shock,…}……水。……ありがとう。"]);
      await K.up(p, eZ, 8);
      await K.say(p, "ザジ", ["{closed}……ちっ。水を 分ける やつから 取るほど、落ちちゃ いねえ。……通りな。"]);
      if (ok(eZ)) await out(K, p, eZ);
    } else {
      await K.hsay(p, H4(["{angry,up}水が ないのは みんな 同じ！ 取りあう なら、相手に なる！"], ["{angry}……水が ないのは みんな 同じよ。でも、奪うのは だめ。"], ["{angry}……奪うなら、相手に なる。"], ["{angry,up}水が ないのは みんな 同じです！ 奪うのは いけません！"]), eZ);
      if (!K.flag(p, "b03e5w")) {
        const r = await K.battle(p, K.team(["beast", "sword", "golem"], 18, 3, 3), { name: "砂ぼこり団", arena: "廃都の 手前の 崖道", theme: "ruins", speaker: "ザジ", lines: { half: "ちっ……水の ためなんだよ……！" } });
        if (r !== "win") { await K.sayAt(p, "§6砂ぼこり団の はぐれ者 ザジ", K.PJ("bandit", 9), "ザジ", ["……水も モンスターも、もらって いくぜ。", K.RT(p)]); return false; }
        K.setFlag(p, "b03e5w");
      }
      const eZ2 = K.npcNear(p, "§6砂ぼこり団の はぐれ者 ザジ", K.PJ("bandit", 9), true);
      await K.up(p, eZ2, 8);
      await K.say(p, "ザジ", ["{sweat,汗}ちっ……一月分の 水が……。"]);
      if (ok(eZ2)) await out(K, p, eZ2);
    }
    const eK2 = KEN(K, p, true);
    await K.up(p, eK2, 8);
    await K.say(p, "弟子 ケン", ["{closed}……助かった。俺は ケン。こっちは ハルカ。§6地方マスター ジン§f 師匠の 弟子だ。", "{?}廃都に 何の 用だ？ 今は 石の 人と、壁画しか ないぜ。"], eH);
    await K.hsay(p, H4(["{closed}その 壁画を 見に 来たの。石板が、名前を 書けなかった わけ……石に 彫られた 話の どこかが、ちがうのかも しれない。"], ["{closed}その 壁画を 見に 来たの。石板が 名前を 書けなかった わけが、千年前の 記録に あるかも しれないから。"], ["{closed}壁画を 見に。石板が 名を 書けなかった。……石に 彫られた 話を、元の 記録で 確かめる。"], ["{closed}その 壁画を 拝見しに 参りました。石板が お名前を 書けなかった わけを、千年前の 記録で 確かめたいのです。"]), eK2);
    await K.say(p, "弟子 ケン", ["{up}なら 神殿の 広間だ。師匠の 家は 代々、あの 壁画の 番を してる。……今朝は 竜を 連れた やつが 先に 来てたぜ。"], eH);
    await K.end(p, { leave: [eK2, HARU(K, p, true)], card: "§7― 廃都 神殿の 壁画の 広間へ ―" });
    return true;
  } };

/* ---------- 6話 神殿の 壁画の 広間（MQ6。レイと 読みで 勝負）---------- */
const E6 = { id: "b03e6", t: "壁画の 広間", F: ["F13", "F14", "F15"], battles: 0,
  hint: "§f廃都 §e神殿の 壁画の 広間§f へ 行こう §7（レイが 待って いる）",
  syn: "千年前の ただ 一つの 記録、神殿の 壁画。王と 十四の 影（主）の ほかに、王の 隣に 王と 同じ 大きさの 影が 一つ、削られて いた。その 下に もっと 古い 削り跡 ── 四角い 頁の 形。すみには 細い ひびの 入った 仮面の 近衛。台座には『影は 知る…に 宿る。…は …に 宿れぬ』。石に 彫られた 話は、だれかが 都合の 悪い 所を 消した あとの 話だった。",
  async run(p, d, K) {
    const q = placeOf("mural", 2);
    if (q) await K.moveTo(p, { x: q.x, y: q.y, z: q.z }, "廃都 神殿の 壁画の 広間"); else await K.open(p, "廃都 神殿の 壁画の 広間", "day");
    const y0 = Y(K, p), wall = at2(K, p, 8, 0, 2.2), ring = at2(K, p, 8, 2.4, 2.6), gap = at2(K, p, 8, -0.8, 2.2), low = at2(K, p, 8, -0.8, 1.2), mask = at2(K, p, 8, -3.2, 1.4), ped = at2(K, p, 5, 2.5, 0.6);
    once("b03ped", () => { const y = gy(p, ped.x, ped.z, y0); if (y !== null) K.cmd(p, `setblock ${Math.floor(ped.x)} ${y} ${Math.floor(ped.z)} chiseled_stone_bricks keep`); });
    const eH = K.hero(p), eR = K.npcNear(p, "§bライバル レイ", 17); K.act(eR, "arms");
    if (ok(eR)) K.turn(eR, wall);   /* 壁画を 見上げた まま 背中で 話す */
    await K.pull(p, wall, 22);
    await K.narr(p, ["§7広間の 奥の 壁、一面の 壁画。千年前の 都が 残した、ただ 一つの 記録。"], wall);
    await K.up(p, eR, 8);
    await K.say(p, "レイ", ["{closed}……来たか。セオから 手紙が 来た。この 壁画を 調べて くれって。", "{closed}村長の 言い伝えは『王と 十四の 主を 十五枚の 石板に』。……壁画も、そう 描いて ある。"], eH);
    K.turn(eR);
    await K.ots(p, eR, eH, 8);
    await K.say(p, "レイ", ["{angry}だが おまえの 名前は、石板に 書けなかった。……石に 彫られた 話が 全部 本当なら、そんな ことは 起きない。", "{angry,up}読みで 勝負だ。先に 壁画の『嘘』を 見つけた ほうが 勝ち。"], eH);
    await K.hsay(p, H4(["{angry,up}……受けて 立つ！"], ["{closed}……いいわ。見つけて みせる。"], ["{closed}……乗った。"], ["{closed}……お受け します。"]), eR);
    await K.at(p, ring, 18, 4, 0.4);
    await K.narr(p, ["§7まん中に 冠の 王。まわりを 十四の 小さな 影が 輪に なって 囲む。……言い伝えの とおり。"], ring);
    await K.push(p, gap, 22, 3.4, 1.2, 0);
    await K.narr(p, ["§7……王の すぐ 隣だけ、壁が 削られて いる。王と 同じ 大きさの、人の 形の 跡。"], gap);
    await K.up(p, eR, 8);
    await K.say(p, "レイ", ["{closed}削られたのは 十五番目の 主だ。封印を 解いた やつが、記録ごと 消した。"], eH);
    await K.hsay(p, H4(["{angry}ちがうと 思う！ 主なら 輪の 中。削られた 影は 王と 同じ 大きさで、王の 隣だよ。", "{closed,up}……トキ婆の 昔話の『王の 隣の 友』。王を 封じて、『王殺し』って 削られた 人。"], ["{?}……主なら、輪の 中に 描くと 思うの。王さまと 同じ 大きさで、すぐ 隣。", "{closed}トキ婆さんの お話の『王の 隣の 友』よ。王さまを 封じて、削られた 人。"], ["{closed}ちがう。主なら 輪の 中。これは 王と 同じ 大きさ。", "{closed}トキ婆の 話。『王の 隣の 友』。王を 封じて 削られた。"], ["{?}主でしたら、輪の 中に 描くはずです。王さまと 同じ 大きさで、すぐ お隣。", "{closed}トキさまの お話の『王の 隣の 友』では ないでしょうか。王を 封じ、削られた 方。"]), eR);
    K.act(eH, "kneel");   /* 削り跡の 下を のぞきこむ */
    await K.push(p, low, 26, 3, 0.9, 0);   /* 下の 古い 削り跡 /*F13 F14*/
    await K.narr(p, ["§7……削り跡の 下に、もっと 古い 削り跡。形は 人では ない。四角い、本の 頁の 形。", "§7上の 跡より 深く、角が すり減って いる。……ずっと 昔に 削られた もの。"], low);
    K.act(eH, 0);
    await K.hsay(p, H4(["{!,up}二度、削られてる！ 上の 跡と 下の 跡、削った 人が ちがう！"], ["{!}……二度 削られてる。上と 下で、削った 時が ちがうわ。"], ["{!}二度。上と 下で、削った 時が ちがう。"], ["{!,up}二度 削られて います！ 上と 下で、時代が ちがいます！"]));
    await K.two(p, eR, eH, 10);
    await K.say(p, "レイ", ["{sad,…}……二度、か。オレは 上しか 見て なかった。", "{closed}……今日は おまえの 勝ちだ。"], eH);
    await K.ots(p, eH, mask, 16);   /* すみの 仮面の 近衛（仲間の 肩ごし）*/
    await K.narr(p, ["§7壁画の すみ。王の 一行の いちばん 後ろで、§f仮面の 近衛§7が 盾を 構えて いる。仮面には 細い ひびが 一本。"], mask);
    await K.at(p, ped, 14, 2.2, 0.8);   /* 台座 /*F15*/
    await K.narr(p, ["§7壁画の 前の 台座に、半分 削れた 字。『§f影は 知る……に 宿る。……は ……に 宿れぬ§7』"], ped);
    K.act(eH, "hold"); K.hold(eH, "notebook");
    await K.up(p, eH, 8);
    await K.hsay(p, H4(["{closed}……ぜんぶ 写した。石に 彫られた 話は、だれかが 都合の 悪い 所を 消した あとの 話なんだ。", "{?}でも、下の 頁の 形は……だれが、何の ために？"], ["{closed}写したわ。……石の 話は、消された あとの 話だったのね。", "{?}でも、下の 頁の 形は……だれが？"], ["{closed}写した。石の 話は、消した あとの 話。", "{?}……下の 頁の 形は、だれが。"], ["{closed}すべて 写しました。石の お話は、消された あとの お話だったのですね。", "{?}けれど、下の 頁の 形は……どなたが？"]), eR);
    K.act(eH, 0); K.hold(eH);
    await K.say(p, "レイ", ["{closed}壁画の 番人に 聞け。この 都の 主、§6ジン§f の 家は 代々 この 壁画の 番だ。……城の 中庭に いる。", "{angry,low}オレは 火山へ 行く。六影の やつらが 向かった。……読みが 外れた ぶんは、足で 取り返す。"], eH);
    await K.end(p, { leave: [eR], card: "§7― グランディア城の 中庭へ ―" });
    return true;
  } };

/* ---------- 7話 ジンの 城の 中庭（MQ6。C03 で ハルカの 態度・石の 奥方・オルドの 手紙）---------- */
const WIFE = (K, p, q) => K.put(p, "§7石に なった アサギ", q, null, K.PJ("kaori", 8));
const E7 = { id: "b03e7", t: "ジンの 城の 中庭", F: ["F09", "F32"], battles: 0,
  hint: "§f廃都 グランディア城の §e中庭§f へ 行こう",
  syn: "ジンの 城の 中庭には、空を 見上げて 笑った まま 石に なった 女の 人が 立って いた。ジンの 妻 アサギ。ジンは 毎朝 その 前で、鞘の ない 剣を 磨く。師の ジンは 若い ころ オルドに 一度も 勝てなかった と いう。城に 届いて いた オルドの 手紙には「星の かけらは 心を 削る」と あった。",
  async run(p, d, K) {
    const q = placeOf("court", 2);
    if (q) await K.moveTo(p, { x: q.x, y: q.y, z: q.z }, "グランディア城の 中庭"); else await K.open(p, "グランディア城の 中庭", "castle");
    const wq = at2(K, p, 7, 2.6), eW = await WIFE(K, p, wq); if (ok(eW)) K.turn(eW, at2(K, p, 7, 2.6, 8));
    const eH = K.hero(p), eR = HARU(K, p); K.hold(eR, "letter");
    const s = K.qs(K.load(p) || d), v = K.chGet(s, "c03"); let gd = null;
    await K.pull(p, eW || wq, 20);
    await K.narr(p, ["§7中庭の まん中に、石の 女の 人が 一人。空を 見上げて、笑った まま。"], eW || wq);
    await K.up(p, eR, 8);
    if (v === "h") {
      await K.say(p, "弟子 ハルカ", ["{smile}崖道では ありがとう。……あの 人は、師匠の 奥方。§fアサギ§f さま。", "{sad}十二年前の 冬の 夜に、石に なったの。師匠は それから 一度も、剣を 鞘に 納めて ない。"], eH);
      await K.say(p, "弟子 ハルカ", ["{closed}それと……オルド殿には 一度も 勝てなかったと、師が。……あの 師匠が よ。"], eH);
    } else {
      await K.say(p, "弟子 ハルカ", ["{closed}……師匠なら 奥よ。話す ことは ないわ。"], eH);
      const eG = await K.put(p, "§7城の 門番", at2(K, p, 3, 2.2), eH ? eH.location : null, K.PJ("glen", 9));
      await K.up(p, eG, 8);
      await K.say(p, "城の 門番", ["{sad}あの 石の 方は、ジン様の 奥方だ。十二年前の 冬に な。……ジン様は それから 鞘を 持たん。", "{smile}若い ころは、ルミナの オルド殿に 一度も 勝てなかったと、よく 言うて おられる。"], eH);
      gd = eG;
    }
    await K.hsay(p, H4(["{shock,!}村長が？ ……昔、ちょっと って、それ！？"], ["{shock}村長さんが……。『昔、ちょっと』ね。"], ["{shock}……村長。『昔、ちょっと』の 正体。"], ["{shock,!}村長さまが……！"]), gd || eR);
    /* オルドの 手紙 /*F32 F09*/
    await K.up(p, eR, 8);
    await K.say(p, "弟子 ハルカ", ["{closed}それと、ルミナの オルド殿から 城に 手紙が 届いてたの。あなた宛ての 一行が ある。"], eH);
    if (ok(eR) && ok(eH)) { await K.approach(p, eR, eH, 1.4); await K.give(eR, eH, "letter"); }
    await K.push(p, eH, 18, 2.6, 1.0, 1.2);
    await K.narr(p, ["§7オルドの 字。「§f星の かけらは 心を 削る。拾っても、持つな§7」"], eH);
    await K.hsay(p, H4(["{?}星の かけら……？ なんの ことだろ。"], ["{?}星の かけら……。何の ことかしら。"], ["{?}星の かけら。……何。"], ["{?}星の かけら……？"]), eR);
    await K.say(p, "弟子 ハルカ", ["{up}壁画の ことは、師匠に 聞いて。……でも 師匠は、剣を 交えた 相手と しか 話さない。"], eH);
    K.pay(p, E7, 4000, [["e_silver", 1], ["tms_golem", 1]]);
    K.card(p, "§7― 地方マスター ジンに 挑もう（中庭の ジンに 話しかける）―", 60); await K.wait(40); await K.bye(p, eR, eH, gd, eW);
    const dd = K.load(p); if (dd) { const ss = K.qs(dd); ss.ch3a = 1; ss.ch3b = 1; K.save(p, dd); }
    return true;
  } };

/* ---------- 8話 ジンの 城（MQ7。マスター戦の あと。壁画の 言い伝え・灰の 冬の 回想・鞘の 約束）---------- */
const E8 = { id: "b03e8", t: "鞘の ない 剣", F: ["F13"], battles: 0,
  hint: "§fルインズ荒野の §6地方マスター ジン§f（城の 中庭）に 勝とう",
  syn: "勝負の あと、ジンは 壁画の 番人の 家の 言い伝えを 話した。上の 削り跡は 千年前、王を 怪物と 書いた 者たちが 削った。下の 頁の 形の 跡は「影が、自分で 自分を 削って 消えた」。十二年前の 冬、灰の 降った 夜。壁画の 番に 出て いる あいだに 妻が 石に なった。守れなかった 剣は 鞘に 戻らない。ジンは 鞘を あなたに 預けた。「石板が 静まった 日に、返しに 来い」。",
  async run(p, d, K) {
    await K.open(p, "グランディア城の 中庭（勝負の あと）", "castle");
    const wq = at2(K, p, 7, 2.6), eW = await WIFE(K, p, wq); if (ok(eW)) K.turn(eW, at2(K, p, 7, 2.6, 8));
    const eH = K.hero(p), eJ = K.cast(p, "r2jin"); K.hold(eJ, "katana");
    if (ok(eJ)) { await K.approach(p, eJ, eW || wq, 1.6); K.act(eJ, "work"); }
    await K.pull(p, eJ, 18);
    await K.narr(p, ["§7勝負の あと。ジンは 石の 奥方の 前に 戻り、鞘の ない 剣を 布で 磨きはじめた。"], eJ);
    K.act(eJ, 0); if (ok(eJ) && ok(eH)) K.turn(eJ);
    await K.up(p, eJ, 8);
    await K.csay(p, "r2jin", ["{closed}……いい 腕だ。剣を 交えた 相手には、話す ことに して いる。", "{?}壁画を 見たな。削り跡が 二つ あったろう。"], eH);
    await K.hsay(p, H4(["{nod}上の 跡と、下の 古い 頁の 形の 跡。……だれが 削ったの？"], ["{nod}ええ。上と、下の 頁の 形。……だれが？"], ["{nod}二つ。……だれが。"], ["{nod}はい。上と、下の 頁の 形。……どなたが？"]), eJ);
    await K.ots(p, eH, eJ, 8);
    await K.csay(p, "r2jin", ["{closed}上は、人が 削った。千年前、王を 怪物と 書いた 者たちが、王の 隣に いた 者を 消した。", "{low}下は ちがう。番人の 家に 伝わる 言葉は 一つだけ。……『影は、自分で 自分を 削って 消えた』。"], eH);   /* /*F13*/
    await K.hsay(p, H4(["{?}自分で 自分を……？ 何の 影なのか、わからないの？"], ["{?}自分で……。何の 影かは 伝わって いないの？"], ["{?}自分で。……何の 影かは。"], ["{?}ご自分で……？ 何の 影かは、伝わって いないのですか？"]), eJ);
    await K.csay(p, "r2jin", ["{closed}伝わって いない。……番人は、意味の 分からぬ ものも 消さずに 守る。それが 仕事だ。"], eH);
    if (ok(eW)) { await K.push(p, eW, 22, 3.4, 1.4); }
    await K.hsay(p, H4(["{sad}……奥さんの こと、聞いても いい？"], ["{sad}……奥方さまの こと、聞いても いいかしら。"], ["{sad}……奥方の こと。聞いて いい？"], ["{sad}……奥方さまの こと、うかがっても よろしいですか。"]), eJ);
    K.turn(eJ, eW ? eW.location : wq);
    await K.csay(p, "r2jin", ["{closed,low}……十二年前の 冬。この 荒野に、灰が 降った。"]);
    await K.flashback(p, { label: "§7―― 十二年前の 冬　グランディア城の 中庭", tod: "night", ptc: "ash",   /* 第127版: 灰の 冬の 回想 */
      actors: { j: { nm: "§6若い ジン", job: K.PJ("jin", 8), at: [3, -1], look: "a", hold: "katana" }, a: { nm: "§eアサギ", job: K.PJ("kaori", 8), at: [3.4, 1], look: "j" } },
      beats: [
        ["narr", "§7十二年前の 冬の 夜。砂の 国の 空から、白い ものが 降って きた。", [3, 0, 3]],
        ["fx", "ash", [3.2, 0, 2.4]], ["act", "a", "up"],
        ["say", "a", "{smile,☆,up}……ジン、見て。雪よ。砂の 国に、雪が 降ってる。", "j"],
        ["say", "j", "{closed}……雪では ない。灰だ。……嫌な 夜だ。壁画の 番に 行く。", "a"],
        ["say", "a", "{smile}行って らっしゃい。夜明けには 戻ってね。", "j"],
        ["go", "j", [9, -2], 26],
        ["fx", "ash", [3.4, 1, 2.2]],
        ["say", "a", "{smile,…,up}……きれい。……このまま、ずっと 見て いたいな。", [3.4, 1, 6]],
        ["narr", "§7灰が 降りやんだ 朝。中庭には、空を 見上げて 笑った まま の 石が 一つ 立って いた。", "a"],
        ["go", "j", [4.6, -0.2], 18], ["act", "j", "kneel"],
        ["say", "j", "{cry,low}……剣は、抜く 間も なかった。……斬る ものが、どこにも なかった。", "a"],
      ] });
    K.act(eJ, "hold"); K.hold(eJ, "box");
    await K.up(p, eJ, 8);
    await K.csay(p, "r2jin", ["{closed}守れなかった 剣は、鞘に 戻らない。……それから 鞘を 置いた。"], eH);
    if (ok(eJ) && ok(eH)) await K.approach(p, eJ, eH, 1.5);
    await K.csay(p, "r2jin", ["{closed,up}この 鞘を 預ける。石板を 集めて、あれが 静まった 日に、ここへ 返しに 来い。", "{low}その 日に、剣を 納める。……アサギに も、そう 言える。"], eH);
    if (ok(eJ) && ok(eH)) await K.give(eJ, eH, "box");
    await K.hsay(p, H4(["{nod,up}……うん。ぜったい 返しに 来る。"], ["{nod}……ええ。必ず 返しに 来るわ。"], ["{nod}……預かる。返しに 来る。"], ["{nod}……お預かり します。必ず お返しに 参ります。"]), eJ);
    await K.csay(p, "r2jin", ["{closed}ガレキの 水の 話は 弟子から 聞いた。城の 古い 水路を 開ける。§eガレキの 古井戸§f で 待て。", "{angry,low}それと、§cヴォルカ火山帯§f の 鍛冶場に 六影の 爆弾班が 出入りして いる。鍛冶屋に 何かを 打たせて いるらしい。……石板を 持つ 者なら、見て おけ。"], eH);
    K.act(eJ, "work"); K.turn(eJ, eW ? eW.location : wq);
    await K.end(p, { bye: [eJ, eW] });
    return true;
  } };

/* ---------- 9話 ガレキの 古井戸（古い r2e5 ＋ C03 の 子）---------- */
const E9 = { id: "b03e9", pv: 127, t: "水が 戻る", F: ["F01"], battles: 0,
  place: PL("r2e5"),
  hint: "§fガレキの 外れの §e古井戸§f へ もどろう §7（ジンの 伝言「古井戸で 待て」）",
  syn: "ジンが 城の 古い 水路を 開け、古井戸に 水が 戻った。「おかえりだぜ、相棒」。トキ婆は「王の 隣の 影にも、いつか『おかえり』を 言うて やりたいの」と 笑った。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r2e5", E9))) return false;   /* トキ婆「王の 隣の 影にも おかえり」/*F01*/
    K.key(p, "k_fest2");
    await K.open(p, "ガレキの 古井戸（夕方）", "dusk", "dusk");
    const s = K.qs(K.load(p) || d), v = K.chGet(s, "c03"), eH = K.hero(p);
    if (v === "h") {
      const eD = K.cast(p, "r2dolf");
      await K.up(p, eD, 8);
      await K.csay(p, "r2dolf", ["{sad}……コトは 熱で 寝てる。水は、間に合わなかった。", "{closed}熱が 下がるまで 待つだぜ。井戸の 水を、毎日 くんで やるだぜ。"], eH);
      await K.end(p, { leave: [eD] });
    } else {
      const kid = K.npcNear(p, "§7ガレキの 子 コト", 6); K.act(kid, "cheer");
      await K.pull(p, kid, 16);
      await K.narr(p, ["§7あの 子が 井戸の 前で、水を はねかして 笑って いる。"], kid);
      await K.up(p, kid, 8);
      await K.say(p, "コト", ["{smile,☆}水筒の お水、おいしかった の！ 井戸の お水は、もっと おいしい の！"]);
      await K.end(p, { leave: [kid] });
    }
    return true;
  } };

bkAdd("b03", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ7: 場面（b03e8: ジンが 水路と 火山の 話を する）→ 道が 開けた */
mqOver(7, async (p, d, K, c) => {
  if (!(await c.play("b03e8"))) return false;
  K.big(p, "§a§l道が 開けた！", "§fヴォルカ火山帯へ 行けるように なった", "ui.toast.challenge_complete");   /* 第127版: ジン 本人が 話した あとなので 手紙は 出さない */
  return true;
});
