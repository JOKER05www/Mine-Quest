// 第118版: ガイドブック・だいじなもの・トークブック・冒険のコンパスは 死んでも なくならない（キープインベントリが オフでも）
import { world, system } from "@minecraft/server";
import { ITEMS } from "./data.js";
import { giveItem, countItem } from "./ui.js";
import { load } from "./store.js";

const FIXED = new Set(["mrpg:monster_book", "mrpg:navi", "mrpg:talkbook", "mrpg:skinbook", "mrpg:k_wmap"]);
const isKeep = (id) => FIXED.has(id) || (id.startsWith("mrpg:") && ["key", "bslab", "dslab"].includes(ITEMS[id.slice(5)]?.kind));   /* 第124版: 特別な 石板・神の 石板も 死んでも のこす（渡しなおしは 1回だけに した ため）*/
/* 持ち物の 中の だいじな ものに「死んでも のこる」を つける（数秒に 1回・つけて いない ものだけ）*/
function mark(p) {
  let c; try { c = p.getComponent("minecraft:inventory")?.container; } catch { return; }
  if (!c) return;
  for (let i = 0; i < c.size; i++) {
    let it; try { it = c.getItem(i); } catch { continue; }
    if (!it || !isKeep(it.typeId) || it.keepOnDeath) continue;
    try { it.keepOnDeath = true; c.setItem(i, it); } catch {}
  }
}
system.runInterval(() => { for (const p of world.getAllPlayers()) mark(p); }, 60);
/* 生きかえった とき: 手元に なければ わたしなおす（だいじなものは 物語の 見まわりが もどす）*/
world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => {
  if (initialSpawn) return;
  system.runTimeout(() => {
    try {
      const d = load(p); if (!d) return;
      if (!countItem(p, "mrpg:monster_book")) giveItem(p, "mrpg:monster_book", 1);
      if (d.story && d.story.introDone && !countItem(p, "mrpg:navi")) giveItem(p, "mrpg:navi", 1);
      if (p.hasTag("mrpg_talkbook") && !countItem(p, "mrpg:talkbook")) giveItem(p, "mrpg:talkbook", 1);
      if (p.hasTag("mrpg_skinbook") && !countItem(p, "mrpg:skinbook")) giveItem(p, "mrpg:skinbook", 1);
      if (p.hasTag("mrpg_wmap") && ITEMS.k_wmap && !countItem(p, "mrpg:k_wmap")) giveItem(p, "mrpg:k_wmap", 1);   /* 第124版: 世界地図 */
      if (d.tmb && ITEMS.k_tmbr && !countItem(p, "mrpg:k_tmbr")) giveItem(p, "mrpg:k_tmbr", 1);   /* 第125版: 闘魔の 腕輪 */
      mark(p);
    } catch {}
  }, 20);
});
/* 万一 落ちて しまった ときは、死んだ 場所の まわりの 落とし物を 消す（手元に もどす ので 2つに ならない）*/
world.afterEvents.entityDie.subscribe(({ deadEntity: e }) => {
  try {
    if (e.typeId !== "minecraft:player") return;
    const at = { ...e.location }, dim = e.dimension;
    system.runTimeout(() => {
      try { for (const it of dim.getEntities({ type: "minecraft:item", location: at, maxDistance: 10 })) { const s = it.getComponent("minecraft:item")?.itemStack; if (s && isKeep(s.typeId)) it.remove(); } } catch {}
    }, 3);
  } catch {}
}, { entityTypes: ["minecraft:player"] });   /* プレイヤーだけ（ほかの 生きものが 死ぬ たびに 呼ばれない）*/
