// 第125版: だいじなもの の 一覧（ガイドブック ＞ 道具・装備 ＞【だいじなもの】）
// だいじなものは セーブ（qs(d).keys）だけに ある。持ち物・バッグには 入らない（saga.js の hasKey・giveKey・migrateKeys）
// 地方ごとに ならべ、説明は いつでも 読める。物語が 進むと 説明が かわる ものも ある（明かされる 前に ネタバレしない）
import { ITEMS } from "./data.js";
import { paged, notice, choose, ICON, ITEM_ICON, clipT } from "./ui.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { WREGIONS } from "./worldmap.js";
import { MQ, EP_HOOK } from "./saga.js";   /* sagaep.js は 読まない（読みこみの 順番を かえない）*/
import { WLB } from "./wqlore.js";
import { BKID } from "./book.js";   /* 第126版: 章の 表（import なしの 葉）*/
import { chGet } from "./choice.js";   /* 第126版: 選択の 印（import なしの 葉）*/   /* 第125版: 世界の 依頼の 記録の 断片（ボタン 1つ）*/

/* 地方（99 = 旅の あと・そのほか）。ここに ない だいじなものは いちばん 後ろ。第126版: book.js の KEYS 38品を 章の 地方に */
const KR = {
  k_note: 0, k_wmap: 0, bslab: 0, k_cap: 0, k_fest0: 0, k_wq0: 0, k_light: 1, k_spirit: 1, k_mark: 1, k_zapaper: 1, k_fest1: 1, k_wq1: 1, k_fest2: 2, k_wq2: 2,
  k_pedestal: 3, k_fsword: 3, k_mallet: 3, k_fest3: 3, k_wq3: 3,
  k_tomb: 4, k_bonekey: 4, k_shard: 4, k_fest4: 4, k_wq4: 4, k_goggle: 5, k_fest5: 5, k_wq5: 5, k_shell: 6, k_crest: 6, k_cordN: 6, k_fest6: 6, k_wq6: 6,
  k_wlan: 7, k_redlan: 7, k_fest7: 7, k_wq7: 7,
  k_mitt: 8, k_leadbox: 8, k_glove: 8, k_rings: 8, k_redkey: 8, k_order: 8, k_wq8: 8, k_hnote: 9, k_compass: 9, k_clasp: 9, k_maskblade: 9, k_cordO: 9, k_heroB: 9, k_wq9: 9,
  k_cord: 10, k_letter: 10, k_ink: 10, k_wq10: 10,
  k_pic: 0, k_tnote: 0, k_cordZ: 0,   /* 本19・本20（ルミナ）*/
  k_hilt: 99, k_kikizuchi: 99, k_vessel: 99, k_mold: 99, k_sayaB: 99, k_heroS: 99, k_sayaS: 99, k_tmbr: 99,
};
const ORD = Object.keys(KR);
/* 第126版: 本の 進み（s.bk の 済み印）を 葉の 表だけで 読む（bkeng.js を 読みこまない＝読みこみの 順番を かえない）*/
const BI = new Map(BKID.map((x, i) => [x, i])), LAST = {}; for (const x of BKID) LAST[x.slice(0, 3)] = x;
const B32 = "0123456789abcdefghijklmnopqrstuv";
const done = (s, id) => { const i = BI.get(id); if (i === undefined || !s || typeof s.bk !== "string") return false; const c = s.bk[(i / 5) | 0]; return !!c && ((B32.indexOf(c) >> i % 5) & 1) === 1; };
/* past(s, "b08") = 第8章を 終えた／past(s, "b08e6") = その 話を 済ませた。本編は エンディング後なら 全部 */
export const past = (s, c) => !!s && ((c[0] === "b" && !!s.ending) || done(s, /e\d+$/.test(c) ? c : LAST[c]));
const P = (c) => (s) => past(s, c), ch = (s, id) => chGet(s, id);
/* 物語が 進んだ あとの 説明。[条件, 文]。あとに 書いた ものほど 強い（明かされた あと だけ。地の 文の 言葉は 05 §2 と terms.md の 時期を 守る）
   文が 関数なら 選択の 印で 変わる */
const KD = {
  bslab: [[P("b09e4"), "各地の 主を 封じた 石板。夜、袋の 中で 頁を めくる ような 音が する。自分と 相棒には 聞こえない。……近くで「このまま」と 願った 人が 石に なる という 噂は、半分 本当"],
    [P("b10e7"), "各地の 主を 封じた 石板。鉛の 箱に 入れると 唸りが 止まり、ふたを 開けると 鳴る。裁きの 間で、みんなの 前で たしかめた"],
    [(s) => past(s, "b10e8") && ch(s, "c10") === "d" && !past(s, "b18e8"), "封じた 石板は、ヘイムダル城に 預けて ある。手もとには 空の 袋だけ"],
    [P("b18e8"), "各地の 主を 封じた 石板。北の 門の 外で、みんなが 名前を 三度 呼んだ 夜から、唸りは 静か"]],
  k_note: [[P("b08e6"), "セオが 書いた 石板の 研究メモ。表紙の 判は、霊廟の 座の 卓の 手帳と 同じ。……書いた 人は 六影の 参謀 だった。それでも 次に やる ことの ヒントは 正しい。使うと ヒントが わかる"],
    [P("b14e3"), "セオが 書いた 石板の 研究メモ。消された 一語の 跡の 形は、祭壇の 横の 破られた 頁と 同じ だった。使うと ヒントが わかる"]],   /*F07 F08*/
  k_mark: [[P("u15e3"), "精霊が 手の甲と 相棒の 額に 残した 印。「片方が 呑まれても、もう 片方が 呼べば 戻れる」。……呼んだ。戻った"]],   /*F31*/
  k_hnote: [[P("b16e8"), "幼なじみの 旅の 手帳。名前の 頁の 最後は、まだ 白紙。ここに 書くのは、二人で"],
    [P("u10e5"), "幼なじみの 旅の 手帳。夜、開くと、だれかが 横から のぞきこむ 気配が する"]],   /*F30*/
  k_compass: [[P("u10e4"), "幼なじみが 組んだ コンパス。回りつづけて いた 針が、一つの 方を 指して 止まった。……行きたい 場所の 方を、ちゃんと 指す"]],   /*F48*/
  k_shell: [[P("b07e7"), "コラリアの 神殿の 貝笛。沈んだ 神殿の 奥の、珊瑚に 覆われた 石の 女の 手に、ぴったり 合った。マリノアの 海の 深く（水面から 6ブロック 以上）で 使うと、番人が 現れる"],
    [P("b20e6"), "コラリアの 神殿の 貝笛。十年前、ミナモが これを 持って 舟を 出した。沈んだ 神殿の 石の 女は、ミナモ。……いつか、娘が この 笛で 母を 呼ぶ"]],   /*F52 F68*/
  k_cap: [[P("b13e5"), "ピコの 小さな 帽子。ピコは オルドに 連れられて ルミナの 牧場へ。眠った まま、屋根の 下に いる。帽子は、起きた ときに 返す"]],   /*F18*/
  k_glove: [[P("b11e5"), "雷神の 祠の 綱に 結ばれて いた、黒い 毛糸の 右手の 手袋。白い 手袋の ロウと、黒い 手袋の ルウ。……片っぽの 持ち主は、きっと ルウ"],
    [P("b20e5"), "ルウの 黒い 右手の 手袋。シロウの おっかあの 編み目。ロウが 目を 覚ました 日、二人の 手は また 手袋で つながった"]],   /*F35*/
  k_pic: [[P("b19e8"), "牧場の 小屋の 柱の 絵。丸 ひとつが、一回。四歳の 冬、目を 覚まさなかった 夜、あの 子は 朝まで 名前を 呼んだ"]],   /*F02*/
  k_tnote: [[P("u01e4"), "セオの 手帳。十二年分の ノエの 絵。シズクが 頁を めくって、あの 子の 魂の ことを 読んだ。……いつか、持ち主に 返す"]],
  k_cord: [[P("b20e6"), "箱の 紐。ゼファードが、名前も まだ ない 下の 娘の ために 編んだ。三つ 編んで、一つ 返す。……マリンに 届ける"]],   /*F10*/
  k_letter: [[(s) => ch(s, "c16") === "r", "風の 塔の 箱の 手紙。封を 切って 読んだ。星を 見る 男から、娘たちへ。「コラリアの 海が 見える 塔を 建てた」"],
    [P("b20e6"), (s) => ch(s, "c16") === "r" ? "星を 見る 男の 手紙。書いたのは ゼファード。二人の 娘の 父。……マリンに 届ける" : "封の ある 手紙。書いたのは ゼファード。二人の 娘の 父。封は 切らずに、マリンに 届ける"]],   /*F33 F53*/
  k_cordZ: [[P("b20e6"), "ゼファードの 手首の 紐。ミナモが 編んだ。灰の 冬の 夜、この 紐を 引いた 指が、一度だけ 錠の 座の 肘かけから 離れた"]],
  k_ink: [[P("u15e7"), "雲の 島の おばあさんが くれた インク。旅の 手帳の 最後の 頁は、この インクで 二人で 書いた"]],   /*F58*/
  k_hilt: [[P("u02e3"), "赤黒く 光る 鍔。カゲツから ムサシへ 託された。耳を あてると、中で だれかが 泣いて いる"],   /*F25*/
    [P("u03e5"), "赤黒く 光る 鍔。中に いるのは、帳の 王 エンマ。千年前、自分から 鍔に 封じられた"],
    [P("u07e9"), "赤黒く 光る 鍔。帳の 王 エンマが 宿る。戦いで ムサシに 使うと、エンマの 姿に なる"]],
  k_mitt: [[P("b11e5"), "シロウの おっかあが 編んだ 里の 手袋。昔、片っぽずつ はめて 手を つないで いた 双子が いた。名前は ロウと ルウ"]],
  k_wlan: [[(s) => !!s.theoSaved || past(s, "u15e8"), "セオの 弟の 名が 書かれた 白い 灯籠。火は 入れずに、ルミエの 小川に 置かれた。……持ち主は、帰り道を 見つけた"]],   /*F06*/
};
/* 居場所（手もとに ない ときは 一覧に 出さない。セーブの 印は 残す）。選択の 印と 章で 決まる（05 §3）*/
const KGONE = {
  bslab: (s) => past(s, "b10e8") && ch(s, "c10") === "d" && !past(s, "b18e8"),   /* ヘイムダル城に 預けた */
  k_cap: (s) => ch(s, "c01") === "g" || past(s, "u15e9"),                          /* g: ガロの 腰／裏15 で ピコの 頭へ */
  k_bonekey: (s) => past(s, "b05e6"),                                              /* イザクに 返した */
  k_glove: (s) => (ch(s, "c11") === "r" && past(s, "b11e8")) || past(s, "b20e10"), /* r: ルウへ／本20 で ルウの 手へ */
  k_cord: (s) => past(s, "b20e10"), k_letter: (s) => past(s, "b20e10"),            /* マリンへ */
  k_hnote: (s) => past(s, "u15e7"), k_compass: (s) => past(s, "u15e7"), k_ink: (s) => past(s, "u15e7"),   /* 幼なじみへ・最後の 頁 */
  k_tnote: (s) => past(s, "u15e10"),                                               /* セオに 返す */
  k_shell: (s) => past(s, "u15e8"),                                                /* ナギサが 母を 呼ぶ */
};
const gone = (id, s) => { try { return !!(KGONE[id] && KGONE[id](s)); } catch { return false; } };
export function keyDesc(id, d) {
  const L = KD[id], s = d ? qs(d) : null; let t = ITEMS[id]?.desc || "";
  if (L && s) for (const [c, x] of L) { try { if (c(s)) { const v = typeof x === "function" ? x(s) : x; if (v) t = v; } } catch {} }
  return t;
}
/* 使える もの（ほかは 説明を 読むだけ）*/
const USE = new Set(["k_note", "k_light", "k_spirit", "k_tomb", "k_goggle", "k_shell", "k_hilt", "k_wmap", "k_tmbr"]);
const regName = (r) => (r === 99 || !WREGIONS[r] ? "旅の あと" : WREGIONS[r].short || WREGIONS[r].name);
export const keyAll = () => Object.keys(ITEMS).filter((id) => ITEMS[id].kind === "key");
export function keyOwned(d) {
  const s = qs(d), L = (s.keys || []).filter((id) => ITEMS[id]?.kind === "key" && !gone(id, s));
  const ix = (id) => (id in KR ? KR[id] * 100 + ORD.indexOf(id) : 99999);
  return [...new Set(L)].sort((a, b) => ix(a) - ix(b));
}
const PST = new Map();
export async function keyPage(p, d0, use) {
  for (;;) {
    const d = load(p) || d0; if (!d) return;
    const ids = keyOwned(d), all = keyAll().length;
    if (!ids.length) { await notice(p, "だいじなもの", "§7まだ 持っていません。\n§f物語の とちゅうで 手に入る 大事な 品です。§7（持ち物には 入らず、ここに しまわれる）"); return; }
    const st = PST.get(p.id) || {}; PST.set(p.id, st);
    const cur = (() => { try { return MQ[qs(d).mq ?? 0]?.key; } catch { return null; } })();
    const sel = await paged(p, "【だいじなもの】", `§7集めた だいじなもの §e${ids.length}§7 / ${all}\n§8えらぶと 説明を 読める。§6★§8 は 使える もの`,
      ids.map((id) => [`${USE.has(id) || id === cur ? "§6★" : "§6"}${ITEMS[id].name}\n§8${regName(KR[id] ?? 99)} §7${clipT(keyDesc(id, d), 18)}`, ITEM_ICON(id)]), 8, WLB.n(p, d) ? [[`§d§l【記録の 断片】 §r§8${WLB.n(p, d)}`, ICON("i_zukan")]] : [], st);
    if (sel === -2 && WLB.book) { await WLB.book(p, d); continue; }
    if (sel < 0 || !ids[sel]) return;
    const id = ids[sel], body = `§8${regName(KR[id] ?? 99)}の だいじなもの\n\n§f${keyDesc(id, d)}`;
    if (USE.has(id) || id === cur) {
      const a = await choose(p, ITEMS[id].name, body, [["§l使う", ITEM_ICON(id)], ["§7戻る", ICON("i_back")]]);
      if (a === 0 && use) { await use(id); return; }
    } else await notice(p, ITEMS[id].name, body);
  }
}
