// 第106版: 遊び場・キャンプの 共通（はねる ボール・仲間みんなで わちゃわちゃ）
// ボール: 雪玉を 投げると すぐ 消して、はねる ボール（mrpg:ball）に 入れかえる。動きは スクリプト（2tickごと・遊んで いる 人だけ）
// 仲間: パーティと スタンバイの 子を 出して、走りまわる・追いかけっこ・じゃれあう・すりよる・ひとやすみ。ボールは みんなで 取りあう
import { world, system, ItemStack } from "@minecraft/server";
import { load } from "./store.js";
import { SPECIES } from "./data.js";
import { barNote, sound, anim, isLite } from "./ui.js";
import { setLook, TYPE } from "./field.js";
import { HIT_HOOKS } from "./battle.js";
import { __bond } from "./bond.js";

const OW = () => world.getDimension("minecraft:overworld");
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
export const PLAYMODE = [];   /* (p) => 中心 {x,y,z,flat} か null（島・キャンプが 登録）*/
export const playCenter = (p) => { for (const f of PLAYMODE) { try { const c = f(p); if (c) return c; } catch {} } return null; };

// ---------- 地面の 高さ（平らでない キャンプ用・少し 覚えて おく）----------
const GY = new Map();
function groundY(x, z, y0, flat) {
  if (flat) return y0;
  const k = `${Math.floor(x)},${Math.floor(z)}`, v = GY.get(k); if (v && v.t > Date.now()) return v.y;
  let y = y0;
  try { const D = OW(); for (let yy = Math.floor(y0) + 3; yy >= Math.floor(y0) - 5; yy--) { const b = D.getBlock({ x: Math.floor(x), y: yy, z: Math.floor(z) }); if (b && b.isLiquid) { y = NaN; break; } if (b && !b.isAir && b.isSolid !== false) { y = yy + 1; break; } }   /* 水や 溶岩の 上へは 行かない */ } catch {}
  if (GY.size > 4000) GY.clear(); GY.set(k, { y, t: Date.now() + 8000 }); return y;
}
const solid = (x, y, z) => { try { const b = OW().getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }); return !!b && !b.isAir && !b.isLiquid && b.isSolid !== false; } catch { return false; } };

// ---------- ボール ----------
export const BALL = new Map();   /* pid -> { e, v, rest, held: entity|null, t } */
export function giveBall(p) {
  try { const c = p.getComponent("minecraft:inventory")?.container; if (!c) return; for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (it?.typeId === "minecraft:snowball" && String(it.nameTag || "").startsWith("§eボール")) return; }
    const b = new ItemStack("minecraft:snowball", 1); b.nameTag = "§eボール\n§7投げると 取って くる・たたくと けれる"; c.addItem(b); } catch {}
}
export function takeBallItem(p) { try { const c = p.getComponent("minecraft:inventory")?.container; if (c) for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (it?.typeId === "minecraft:snowball" && String(it.nameTag || "").startsWith("§eボール")) c.setItem(i, undefined); } } catch {} }
export function dropBall(pid) { const B = BALL.get(pid); if (B && okE(B.e)) try { B.e.remove(); } catch {} BALL.delete(pid); }
function throwBall(p, at, v) {
  dropBall(p.id);
  let e = null; try { e = OW().spawnEntity("mrpg:ball", at); } catch { return null; }
  try { e.setProperty("mrpg:roll", true); e.setDynamicProperty("mrpg:bown", p.id); } catch {}
  const B = { e, v: { ...v }, rest: false, held: null, t: 0, bounce: 0 }; BALL.set(p.id, B);
  for (const r of runnersOf(p)) { r.st = "ball"; r.tt = 0; }
  return B;
}
try {
  world.afterEvents.entitySpawn.subscribe(({ entity: e }) => {
    if (e?.typeId !== "minecraft:snowball") return;
    system.run(() => {
      try {
        if (!okE(e)) return; let own = null; try { own = e.getComponent("minecraft:projectile")?.owner; } catch {}
        if (!own) own = e.dimension.getPlayers({ location: e.location, maxDistance: 3 })[0];
        if (!own || !playCenter(own)) return;
        let v = { x: 0, y: 0.3, z: 0 }; try { v = e.getVelocity(); } catch {}
        const at = { ...e.location }; try { e.remove(); } catch {}
        throwBall(own, at, { x: v.x * 0.72, y: v.y * 0.72 + 0.05, z: v.z * 0.72 });   /* 雪玉より ゆっくり */
        sound(own, "random.bow", 1.3);
      } catch {}
    });
  });
} catch {}
/* たたくと ける（見て いる 向きへ）*/
world.afterEvents.entityHitEntity.subscribe(({ damagingEntity: p, hitEntity: e }) => {
  if (p?.typeId !== "minecraft:player" || e?.typeId !== "mrpg:ball") return;
  const B = [...BALL.values()].find((x) => x.e && x.e.id === e.id); if (!B) return;
  let d = { x: 0, y: 0, z: 1 }; try { d = p.getViewDirection(); } catch {}
  const h = Math.hypot(d.x, d.z) || 1; B.v = { x: (d.x / h) * 0.55, y: 0.32, z: (d.z / h) * 0.55 }; B.rest = false; B.t = 0;
  try { e.setProperty("mrpg:roll", true); } catch {} sound(p, "random.pop", 0.8);
  for (const r of runnersOf(p)) { r.st = "ball"; r.tt = 0; }
});
const G = 0.045, DRAG = 0.985, FRIC = 0.9;
function ballStep(p, B, c) {
  const e = B.e; if (!okE(e)) { BALL.delete(p.id); return; }
  B.t++;
  if (B.rest) return;
  let L = e.location, { v } = B;
  for (let s = 0; s < 2; s++) {
    v.y -= G; v.x *= DRAG; v.z *= DRAG;
    let nx = L.x + v.x, ny = L.y + v.y, nz = L.z + v.z;
    if (solid(nx, L.y + 0.2, L.z)) { v.x = -v.x * 0.5; nx = L.x; }
    if (solid(nx, L.y + 0.2, nz)) { v.z = -v.z * 0.5; nz = L.z; }
    if (v.y < 0 && solid(nx, ny, nz)) {
      ny = Math.floor(ny) + 1;
      if (v.y < -0.12) { v.y = -v.y * 0.58; B.bounce++; if (B.bounce < 6) try { OW().playSound("random.pop", { x: nx, y: ny, z: nz }, { volume: 0.5, pitch: 0.6 + Math.random() * 0.3 }); } catch {} }
      else { v.y = 0; v.x *= FRIC; v.z *= FRIC; }
    } else if (v.y > 0 && solid(nx, ny + 0.45, nz)) v.y = -v.y * 0.4;
    L = { x: nx, y: ny, z: nz };
  }
  if (L.y < c.y - 24) { dropBall(p.id); giveBall(p); try { barNote(p).setActionBar("§7ボールが 落ちて しまった… 手元に もどした"); } catch {} return; }
  try { e.teleport(L); } catch {}
  if (Math.abs(v.y) < 0.001 && Math.hypot(v.x, v.z) < 0.03) { B.rest = true; try { e.setProperty("mrpg:roll", false); } catch {} }
  if (B.t > 900) { dropBall(p.id); giveBall(p); }
}

// ---------- 仲間（わちゃわちゃ）----------
export const CROWD = new Map();   /* pid -> [runner] runner: { e, m, sp, st, tt, tgt, carry, k, cd } */
export const isCrowd = (id) => { for (const L of CROWD.values()) if (L.some((r) => r.e && r.e.id === id)) return true; return false; };
export const runnersOf = (p) => CROWD.get(p.id) || [];
const spdK = (sid) => { const b = SPECIES[sid]?.base || {}; return Math.max(0.9, Math.min(1.25, 0.9 + (b.spd || 4) / 18)); };
const MAXN = () => (isLite() ? 4 : 8);
/* 出す: パーティ → スタンバイ（自分の ならべ順）。ex: 出さない 子の id（遊び相手の 写しなど）*/
export function spawnCrowd(p, c, ex = new Set()) {
  clearCrowd(p);
  const d = load(p); if (!d) return [];
  const L = [...(d.party || []), ...(d.bench || [])].filter((m) => m && SPECIES[m.sp] && !ex.has(m.id)).slice(0, MAXN());
  const out = [];
  L.forEach((m, k) => {
    const a = (k / Math.max(1, L.length)) * Math.PI * 2, at = { x: c.x + Math.cos(a) * 3.5, z: c.z + Math.sin(a) * 3.5 }; at.y = groundY(at.x, at.z, c.y, c.flat); if (Number.isNaN(at.y)) at.y = c.y;
    let e = null; try { e = OW().spawnEntity(TYPE, at); } catch { return; }
    try { e.addTag("mrpg_play"); e.addTag("mrpg_crowd"); e.setDynamicProperty("mrpg:pown", p.id); setLook(e, m.sp, m); e.triggerEvent("mrpg:make_battle"); e.nameTag = `§d${m.nm}`; } catch {}
    out.push({ e, m, sp: m.sp, st: "wander", tt: Math.floor(Math.random() * 20), tgt: null, carry: false, k: spdK(m.sp), cd: 0, y: at.y });
  });
  CROWD.set(p.id, out); return out;
}
export function clearCrowd(p) { const pid = typeof p === "string" ? p : p.id; for (const r of CROWD.get(pid) || []) try { if (okE(r.e)) r.e.remove(); } catch {} CROWD.delete(pid); }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { clearCrowd(playerId); dropBall(playerId); }); } catch {}
function step(r, to, sp, c) {
  const l = r.e.location, dx = to.x - l.x, dz = to.z - l.z, d = Math.hypot(dx, dz); if (d < 0.05) return 0;
  const k = Math.min(sp, d) / d, nx = l.x + dx * k, nz = l.z + dz * k, ny = groundY(nx, nz, c.y, c.flat);
  if (!c.flat && (Number.isNaN(ny) || Math.abs(ny - (r.y ?? ny)) > 1.5)) return d;   /* 段差が 大きい 所へは 行かない */
  r.y = ny; try { r.e.teleport({ x: nx, y: ny, z: nz }, { facingLocation: { x: to.x, y: ny + 0.5, z: to.z } }); } catch {}
  return d;
}
const hearts = (at, n = 3) => { try { for (let k = 0; k < n; k++) OW().spawnParticle("minecraft:heart_particle", { x: at.x + (Math.random() - 0.5), y: at.y + 1.2, z: at.z + (Math.random() - 0.5) }); } catch {} };
const PICK = [["wander", 3], ["follow", 3], ["chase", 2], ["romp", 2], ["nuzzle", 2], ["rest", 1], ["zoom", 2]];
function choose(r) { let s = Math.random() * PICK.reduce((a, [, w]) => a + w, 0); for (const [k, w] of PICK) { s -= w; if (s <= 0) return k; } return "wander"; }
export function crowdTick(p, c, opt = {}) {
  const B = BALL.get(p.id);
  if (B && okE(B.e)) ballStep(p, B, c);   /* ボールは 仲間が いなくても 動かす */
  const L = CROWD.get(p.id); if (!L || !L.length) return;
  const l = p.location;
  for (const r of L) {
    if (!okE(r.e)) continue;
    const el = r.e.location; r.tt++;
    if (opt.cheer) { /* 遊びの 間は 外で 応援（はねる）*/ const sp = opt.cheer; const d = hv(el, sp); if (d > 3) step(r, sp, 0.38 * r.k, c); else if (r.tt % 30 === 0) { anim(r.e, "happy"); } continue; }
    if (el.y < c.y - 12 || hv(el, l) > 40) { let y = groundY(l.x + 1, l.z + 1, l.y, c.flat); if (Number.isNaN(y)) y = l.y; try { r.e.teleport({ x: l.x + 1, y, z: l.z + 1 }); } catch {} r.y = y; continue; }
    /* ボール */
    if (B && okE(B.e) && !r.carry && (r.st === "ball" || hv(el, B.e.location) < 6)) {
      r.st = "ball"; const bl = B.e.location; step(r, bl, 0.5 * r.k, c);
      if (hv(bl, el) < 1.3 && bl.y - r.y < 2.6 && (B.t > 4)) {
        dropBall(p.id); r.carry = true; r.st = "back"; anim(r.e, B.rest ? "happy" : "atk_jump");
        try { barNote(p).setActionBar(`§e§l${B.rest ? "とった！" : "ナイスキャッチ！"} §f${r.m.nm}が ボールを くわえた`); } catch {} sound(p, "random.pop", 1.6);
        for (const o of L) if (o !== r && o.st === "ball") { o.st = "chase"; o.tgt = r; o.tt = 0; }   /* ほかの 子は 取った 子を 追いかける */
      }
      continue;
    }
    if (r.st === "ball") { r.st = "follow"; r.tt = 0; }
    if (r.carry) {
      const d = step(r, l, 0.42 * r.k, c);
      if ((r.tt & 3) === 0) try { OW().spawnParticle("minecraft:villager_happy", { x: el.x, y: r.y + 1.6, z: el.z }); } catch {}
      if (d < 1.8) { r.carry = false; r.st = "nuzzle"; r.tt = 0; giveBall(p); anim(r.e, "happy"); hearts(el, 4); r.n = (r.n || 0) + 1; try { barNote(p).setActionBar(`§d${r.m.nm}が ボールを もって きた！ §7（${r.n}回目）`); } catch {} if (r.n % 3 === 1) try { __bond.addNk(p, r.m, 2, "ボール遊び"); } catch {} }
      continue;
    }
    /* ふだんの 動き（数秒ごとに 気分が かわる）*/
    if (r.tt > 40 + Math.random() * 60) { r.st = choose(r); r.tt = 0; r.tgt = r.st === "chase" || r.st === "romp" ? L[Math.floor(Math.random() * L.length)] : null; if (r.tgt === r) r.tgt = null; r.home = { x: l.x + (Math.random() - 0.5) * 14, z: l.z + (Math.random() - 0.5) * 14 }; }
    switch (r.st) {
      case "follow": { const d = hv(el, l); if (d > 2.6) step(r, l, Math.min(0.45, 0.16 + d * 0.03) * r.k, c); break; }
      case "wander": step(r, r.home || l, 0.22 * r.k, c); break;
      case "zoom": { /* 犬の ように ぐるぐる 走りまわる */ const a = r.tt * 0.25 + (String(r.m.id).charCodeAt(String(r.m.id).length - 1) % 7 || 0); step(r, { x: l.x + Math.cos(a) * 5, z: l.z + Math.sin(a) * 5 }, 0.48 * r.k, c); break; }
      case "chase": { const t = r.tgt; if (!t || !okE(t.e)) { r.st = "wander"; break; } const d = step(r, t.e.location, 0.44 * r.k, c); if (d < 1.4) { anim(r.e, "atk_jump"); if (t.st !== "chase") { t.st = "chase"; t.tgt = r; t.tt = 0; } r.st = "zoom"; r.tt = 0; } break; }
      case "romp": { /* じゃれあう: 向かいあって 跳ぶ */ const t = r.tgt; if (!t || !okE(t.e)) { r.st = "wander"; break; } const d = step(r, t.e.location, 0.3 * r.k, c); if (d < 2 && r.tt % 12 === 0) { anim(r.e, Math.random() < 0.5 ? "atk_jump" : "atk_claw"); if (Math.random() < 0.5) anim(t.e, "happy"); } break; }
      case "nuzzle": { const d = step(r, l, 0.3 * r.k, c); if (d < 1.6 && r.tt % 25 === 0) { anim(r.e, "happy"); hearts(el, 2); } break; }
      case "rest": if (r.tt % 50 === 0) anim(r.e, "happy"); break;
      case "eat": { const d = step(r, r.home || l, 0.42 * r.k, c); if (d < 1.6 && r.tt % 14 === 0) { anim(r.e, "happy"); if (Math.random() < 0.5) hearts(el, 1); } break; }
    }
  }
}
/* なでる: 仲間を たたくと よろこぶ（10秒に 1回 きずな）*/
const PETT = new Map();
system.run(() => HIT_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_crowd")) return false;
  try { e.getComponent("minecraft:health")?.resetToMaxValue(); } catch {}
  const r = runnersOf(p).find((x) => x.e && x.e.id === e.id); if (!r) return true;
  anim(e, "happy"); hearts(e.location, 5); sound(p, "random.orb", 1.4); r.st = "nuzzle"; r.tt = 0;
  const k = `${p.id}:${r.m.id}`; if ((PETT.get(k) || 0) < Date.now()) { PETT.set(k, Date.now() + 10000); try { __bond.addNk(p, r.m, 1, "なでた"); } catch {} }
  try { barNote(p).setActionBar(`§d${r.m.nm}は うれしそう！`); } catch {}
  return true;
}));
/* 起動した ときに 残った ボールを 片づける */
system.runTimeout(() => { try { const live = new Set([...BALL.values()].map((B) => B.e?.id)); for (const e of OW().getEntities({ type: "mrpg:ball" })) if (!live.has(e.id)) try { e.remove(); } catch {} } catch {} }, 100);
/* みんなを 1か所に 集める（ごはん など）。n tick の あいだ */
export function gather(p, at, n = 160) { runnersOf(p).forEach((r, k) => { const a = (k / Math.max(1, runnersOf(p).length)) * Math.PI * 2; r.st = "eat"; r.home = { x: at.x + Math.cos(a) * 2.2, z: at.z + Math.sin(a) * 2.2 }; r.tt = -n; r.carry = false; }); }
export const __pf = { BALL, CROWD, ballStep, crowdTick, spawnCrowd, throwBall, groundY };
