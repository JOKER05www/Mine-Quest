/* 第127版(fac2): 物語の 施設の 作り直し（おもちゃっぽい 小さな セット → 20〜36 マスの 見ごたえの ある セット）
   ・前の 小さな 形（核）は 同じ 位置に そのまま 入れる（場面の 印 facMark・立ち位置・カメラは 前と 同じ）。そのまわり・奥に 地名に 合う 景色を 建てる
   ・場所（キー）ごとに 新しい 形を 登録（facUp）。前の 版で 建った 小さな 形は、次に その 場面が 来た とき 片づけて 建てなおす（epfac の stale・facold）
   ・大きな 形が 入らない 所（町・城・ステージの そば、段差が 大きい）は 前の 小さな 形（fb）
   ・常世（灰都の 街の 中）の 形は 街を 削らない ように 小さめ（18 マス まで）・足もとを ならさない
   ・fill は どれも 32768 以下。コマンドは epfac の stream で 1 tick 40 本 */
import { facBig, facUp, FAC_OPS, __fac } from "./epfac.js";
const { F, S1, HANG, WCAUL } = FAC_OPS;
const SH = (k) => __fac.SHAPES[k] || __fac.BIG[k];
const nz = (a, b, s = 0) => { let h = Math.imul(a | 0, 73856093) ^ Math.imul(b | 0, 19349663) ^ Math.imul(s | 0, 83492791); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };

/* ---------- 部品（a: 奥へ・b: 横・h: 高さ。h=-1 が 地面）---------- */
const LEAF = { snow: "spruce_leaves", sky: "birch_leaves", desert: "jungle_leaves", dark: "dark_oak_leaves", castle: "dark_oak_leaves" };
const leafOf = (P) => LEAF[P.st] || "oak_leaves";
/* 家（壁・四すみの 柱・戸口・窓・切妻の 屋根。ridge "b" で 棟が 横向き）*/
function house(a0, b0, a1, b1, h, P, o = {}) {
  const wl = o.wall || P.plank, lg = o.log || P.log, rf = o.roof || "dark_oak_planks", d = o.door || "f", mb = (b0 + b1) >> 1, ma = (a0 + a1) >> 1;
  const L = [F(a0, b0, 0, a1, b1, h - 1, wl, "hollow"), F(a0 + 1, b0 + 1, -1, a1 - 1, b1 - 1, -1, o.floor || P.plank)];
  for (const [a, b] of [[a0, b0], [a0, b1], [a1, b0], [a1, b1]]) L.push(F(a, b, 0, a, b, h - 1, lg));
  for (let a = a0 + 2; a < a1 - 1; a += 3) L.push(S1(a, b0, 1, "glass_pane"), S1(a, b1, 1, "glass_pane"));
  for (let b = b0 + 2; b < b1 - 1; b += 3) if (Math.abs(b - mb) > 1) L.push(S1(a0, b, 1, "glass_pane"), S1(a1, b, 1, "glass_pane"));
  if (d === "f") L.push(F(a0, mb, 0, a0, mb, 1, "air")); else if (d === "k") L.push(F(a1, mb, 0, a1, mb, 1, "air")); else if (d === "l") L.push(F(ma, b0, 0, ma, b0, 1, "air")); else if (d === "r") L.push(F(ma, b1, 0, ma, b1, 1, "air"));
  if (o.ridge === "b") { let k = 0; for (; a0 - 1 + k < a1 + 1 - k; k++) L.push(F(a0 - 1 + k, b0 - 1, h + k, a1 + 1 - k, b1 + 1, h + k, rf)); L.push(F(a0 - 1 + k, b0 - 1, h + k, a1 + 1 - k, b1 + 1, h + k, o.cap || P.slab)); }
  else { let k = 0; for (; b0 - 1 + k < b1 + 1 - k; k++) L.push(F(a0 - 1, b0 - 1 + k, h + k, a1 + 1, b1 + 1 - k, h + k, rf)); L.push(F(a0 - 1, b0 - 1 + k, h + k, a1 + 1, b1 + 1 - k, h + k, o.cap || P.slab)); }
  if (o.chim) L.push(F(o.chim[0], o.chim[1], 0, o.chim[0], o.chim[1], h + 4, "bricks"), S1(o.chim[0], o.chim[1], h + 5, "campfire"));
  L.push(S1(ma, mb, h - 1, HANG(P)));
  return L;
}
/* 平屋根の 石の 建物（胸壁つき）*/
function block(a0, b0, a1, b1, h, P, o = {}) {
  const wl = o.wall || P.wall, mb = (b0 + b1) >> 1, L = [F(a0, b0, 0, a1, b1, h - 1, wl, "hollow"), F(a0, b0, h, a1, b1, h, o.top || P.trim)];
  if (o.cren !== false) for (let a = a0; a <= a1; a += 2) L.push(S1(a, b0, h + 1, wl), S1(a, b1, h + 1, wl)); if (o.cren !== false) for (let b = b0; b <= b1; b += 2) L.push(S1(a0, b, h + 1, wl), S1(a1, b, h + 1, wl));
  if (o.door !== false) L.push(F(a0, mb, 0, a0, mb, 1, "air"));
  for (let a = a0 + 2; a < a1 - 1; a += 3) L.push(S1(a, b0, Math.min(2, h - 2), o.win || "iron_bars"), S1(a, b1, Math.min(2, h - 2), o.win || "iron_bars"));
  return L;
}
/* 四角い 塔（中は 空き・上に 胸壁と 灯り）*/
function tower(a0, b0, w, h, P, o = {}) {
  const wl = o.wall || P.wall, a1 = a0 + w - 1, b1 = b0 + w - 1, L = [F(a0, b0, 0, a1, b1, h - 1, wl, "hollow"), F(a0 - 1, b0 - 1, h, a1 + 1, b1 + 1, h, o.trim || P.trim)];
  for (let a = a0 - 1; a <= a1 + 1; a += 2) L.push(S1(a, b0 - 1, h + 1, wl), S1(a, b1 + 1, h + 1, wl)); for (let b = b0 - 1; b <= b1 + 1; b += 2) L.push(S1(a0 - 1, b, h + 1, wl), S1(a1 + 1, b, h + 1, wl));
  for (let y = 3; y < h - 1; y += 4) { const ma = (a0 + a1) >> 1, mb = (b0 + b1) >> 1; L.push(S1(a0, mb, y, o.win || "iron_bars"), S1(a1, mb, y, o.win || "iron_bars"), S1(ma, b0, y, o.win || "iron_bars"), S1(ma, b1, y, o.win || "iron_bars")); }
  if (o.door) { const mb = (b0 + b1) >> 1; L.push(F(a0, mb, 0, a0, mb, 1, "air")); }
  if (o.lamp !== false) L.push(S1((a0 + a1) >> 1, (b0 + b1) >> 1, h + 1, o.lamp || P.lamp));
  return L;
}
/* 岩山・丘（段に なって 細る。s で 形を かえる）*/
function mound(a0, b0, a1, b1, h, mat, top = null, s = 1) {
  const L = []; const wa = a1 - a0, wb = b1 - b0;
  for (let i = 0; i < h; i++) {
    const t = i / Math.max(1, h), ia = Math.floor(t * wa * 0.45 + nz(i, 1, s) * 1.6), ib = Math.floor(t * wb * 0.45 + nz(i, 2, s) * 1.6), ja = Math.floor(t * wa * 0.45 + nz(i, 3, s) * 1.6), jb = Math.floor(t * wb * 0.45 + nz(i, 4, s) * 1.6);
    if (a0 + ia > a1 - ja || b0 + ib > b1 - jb) break;
    L.push(F(a0 + ia, b0 + ib, i, a1 - ja, b1 - jb, i, i === h - 1 && top ? top : mat));
  }
  return L;
}
/* 丘の 表面を 草・雪に（上から 見える 段の ふち）*/
const skin = (a0, b0, a1, b1, h, mat, top) => { const L = []; for (let y = 0; y < h; y++) L.push(F(a0, b0, y, a1, b1, y, top, `replace ${mat}`)); return L; };
function tree(a, b, h, P, o = {}) { const lg = o.log || P.log, lf = o.leaf || leafOf(P); return [F(a - 2, b - 2, h - 3, a + 2, b + 2, h - 2, lf, "keep"), F(a - 1, b - 1, h - 1, a + 1, b + 1, h, lf, "keep"), F(a, b, 0, a, b, h - 1, lg)]; }
function spruce(a, b, h, o = {}) { const lf = o.leaf || "spruce_leaves", L = [F(a, b, 0, a, b, h - 1, o.log || "spruce_log")]; for (let y = 2, r = 2; y < h; y += 2, r = Math.max(0, r - (y > h - 4 ? 1 : 0))) L.push(F(a - r, b - r, y, a + r, b + r, y, lf, "keep")); L.push(S1(a, b, h, lf)); if (o.snow) L.push(S1(a, b, h + 1, "snow_layer")); return L; }
function deadtree(a, b, h, lg = "stripped_dark_oak_log", s = 1) { const L = [F(a, b, 0, a, b, h - 1, lg)]; const d = nz(a, b, s) > 0.5 ? 1 : -1; L.push(F(a + 1, b, h - 3, a + 2, b, h - 3, lg), F(a, b + d, h - 2, a, b + 2 * d, h - 2, lg), S1(a + 2, b, h - 2, lg), S1(a, b + 2 * d, h - 1, lg)); return L; }
const post = (a, b, P, h = 2, lamp = null) => [F(a, b, 0, a, b, h - 1, P.fence), S1(a, b, h, lamp || P.lamp)];
const fenceL = (a0, b0, a1, b1, P, mat = null) => [F(a0, b0, 0, a1, b1, 0, mat || P.fence)];
const crates = (a, b, P) => [S1(a, b, 0, "barrel"), S1(a + 1, b, 0, "barrel"), S1(a, b + 1, 0, "chest"), S1(a, b, 1, "barrel"), S1(a + 1, b + 1, 0, P.plank)];
function tentA(a0, b, len, c1, c2, pole = "spruce_log") { const a1 = a0 + len; return [F(a0, b - 2, 0, a1, b - 2, 0, c1), F(a0, b + 2, 0, a1, b + 2, 0, c1), F(a0, b - 1, 1, a1, b - 1, 1, c1), F(a0, b + 1, 1, a1, b + 1, 1, c1), F(a0, b, 2, a1, b, 2, c2), F(a1, b - 1, 0, a1, b + 1, 0, c1), S1(a0 - 1, b, 0, pole), S1(a0 - 1, b, 1, pole), S1(a1 + 1, b, 0, pole), S1(a1 + 1, b, 1, pole)]; }
/* 舟（a の 向きに 長い。水の 上なら h=-1 の 水に 浮かべる）*/
function boat(a0, b, len, P, h = 0, o = {}) { const a1 = a0 + len, pl = o.plank || P.plank; const L = [F(a0 + 1, b - 1, h, a1 - 1, b + 1, h, pl), F(a0 + 1, b - 2, h + 1, a1 - 1, b - 2, h + 1, pl), F(a0 + 1, b + 2, h + 1, a1 - 1, b + 2, h + 1, pl), S1(a0, b, h + 1, pl), S1(a1, b, h + 1, pl), F(a0 + 1, b - 1, h + 1, a1 - 1, b + 1, h + 1, "air")];
  if (o.mast !== false) { const m = (a0 + a1) >> 1; L.push(F(m, b, h + 1, m, b, h + 1 + (o.mh || 6), P.log), F(m, b - 2, h + 3, m, b + 2, h + 1 + (o.mh || 6) - 1, o.sail || "white_wool")); }
  return L; }
/* 水を ためる 池（ふちは edge）*/
const pool = (a0, b0, a1, b1, edge, d = 2) => [F(a0, b0, -1 - d, a1, b1, -1, edge), F(a0 + 1, b0 + 1, -d, a1 - 1, b1 - 1, -1, "water"), F(a0 + 1, b0 + 1, 0, a1 - 1, b1 - 1, 1, "air")];
/* 道（地面を 置きかえる）*/
const road = (a0, b0, a1, b1, mat) => [F(a0, b0, -1, a1, b1, -1, mat)];
/* 胸壁つきの 壁 */
function wall(a0, b0, a1, b1, h, mat, cap = null) { const L = [F(a0, b0, 0, a1, b1, h - 1, mat)]; const along = a1 - a0 >= b1 - b0; if (along) for (let a = a0; a <= a1; a += 2) L.push(F(a, b0, h, a, b1, h, cap || mat)); else for (let b = b0; b <= b1; b += 2) L.push(F(a0, b, h, a1, b, h, cap || mat)); return L; }
/* 石の 灯籠 */
const toro = (a, b, P, m = "stone_bricks") => [S1(a, b, 0, m), S1(a, b, 1, "cobblestone_wall"), S1(a, b, 2, P.lamp), S1(a, b, 3, "stone_brick_slab")];
/* 散らした 岩・草 */
function scatter(a0, b0, a1, b1, list, n, s = 1, h = 0) { const L = []; for (let i = 0; i < n; i++) { const a = a0 + Math.floor(nz(i, 7, s) * (a1 - a0 + 1)), b = b0 + Math.floor(nz(i, 9, s) * (b1 - b0 + 1)); L.push(S1(a, b, h, list[i % list.length])); } return L; }
/* 割れ目（a0..a1 を 横切る 深い 溝。底は 黒い 石）*/
function rift(a0, a1, b0, b1, d, wl = "deepslate", s = 1) { const L = []; for (let b = b0; b <= b1; b += 3) { const w = nz(b, 3, s) > 0.5 ? 1 : 0, c = Math.round((a0 + a1) / 2 + (nz(b, 5, s) - 0.5) * 2); L.push(F(c - 1 - w, b, -d, c + 1, Math.min(b + 2, b1), -1, "air"), F(c - 1 - w, b, -d - 1, c + 1, Math.min(b + 2, b1), -d - 1, wl), F(c - 2 - w, b, -1, c - 2 - w, Math.min(b + 2, b1), -1, "cobbled_deepslate"), F(c + 2, b, -1, c + 2, Math.min(b + 2, b1), -1, "cobbled_deepslate")); } return L; }
/* 骨の 肋（b の 両側から 上へ 弧）*/
function ribs(a, b0, b1, h, mat = "bone_block") { const m = (b0 + b1) / 2, r = (b1 - b0) / 2, L = []; for (let k = 0; k <= 12; k++) { const t = (k / 12) * Math.PI, b = Math.round(m - Math.cos(t) * r), y = Math.round(Math.sin(t) * h); L.push(S1(a, b, y, mat)); if (k < 12) { const b2 = Math.round(m - Math.cos(((k + 1) / 12) * Math.PI) * r), y2 = Math.round(Math.sin(((k + 1) / 12) * Math.PI) * h); if (Math.abs(y2 - y) > 1) L.push(F(a, b, Math.min(y, y2), a, b, Math.max(y, y2), mat)); } } return L; }

/* 縦の 輪（水車）: a-h の 面の 円（b は 一定）*/
const RAHo = (a0, b, h0, r, bl) => { const o = [], seen = new Set(); for (let k = 0; k < 16; k++) { const t = (k * Math.PI) / 8, a = a0 + Math.round(Math.cos(t) * r), h = h0 + Math.round(Math.sin(t) * r), id = `${a},${h}`; if (seen.has(id)) continue; seen.add(id); o.push(S1(a, b, h, bl)); } return o; };
const up = (L, dh) => L.map((o) => (o[0] === "f" ? ["f", o[1], o[2], o[3] + dh, o[4], o[5], o[6] + dh, o[7], o[8]] : ["e", o[1], o[2], o[3] + dh, o[4]]));
/* ---------- 登録: 前の 形（核）＋ まわりの 景色 ---------- */
export const SETS = {};
/* 舞台の 前の 帯（a が FRONT_A より 手前）には 景色を 置かない（人が 歩いて 出入りする 道・横から 入る カメラ）。地面より 下（水・道）は よい */
const FRONT_A = 3;
function clipFront(L, A) { const out = []; for (const o of L) { if (o[0] !== "f") { if (o[1] > A) out.push(o); continue; } const a0 = Math.min(o[1], o[4]), a1 = Math.max(o[1], o[4]); if ((Math.max(o[3], o[6]) < 0 && !/^(air|water)/.test(String(o[7]))) || a0 > A) { out.push(o); continue; } if (a1 <= A) continue; out.push(o[1] <= o[4] ? ["f", A + 1, o[2], o[3], o[4], o[5], o[6], o[7], o[8]] : ["f", o[1], o[2], o[3], A + 1, o[5], o[6], o[7], o[8]]); } return out; }
/* name: 新しい 形。key: 場所（1つ または 配列）。old: 前の 形（核・fb）。o = { box, H, env(P), top?(P), marks?, look?, D?, st?, tk?（常世: 足もとを ならさない）, nocore? } */
function set(name, keys, old, o) {
  const O = SH(old); if (!O) { console.warn(`[MonsterRPG] facsets: ${old} が ない`); return; }
  const core = o.nocore ? () => [] : (P) => { const [a0, b0, a1, b1] = O.box; return [F(a0, b0, 0, a1, b1, O.H || 4, "air"), ...O.build(P)]; };
  const st = {}; for (const k of new Set([...Object.keys(O.st || {}), ...Object.keys(o.st || {})])) st[k] = (P) => [...(!o.nocore && O.st && O.st[k] ? O.st[k](P) : []), ...(o.st && o.st[k] ? o.st[k](P) : [])];
  const def = { fb: old, D: o.D || O.D, box: o.box, ...(o.nocore || o.tk ? {} : { core: O.box }), H: o.H, look: o.look || O.look, marks: { ...(o.nocore ? {} : O.marks || {}), ...(o.marks || {}) }, ...(O.side ? { side: O.side } : o.nocore || !(O.D || []).some((D) => D - 2.5 + O.box[0] >= (O.near || 6.5)) ? {} : { side: [] }),   /* 大きな 形は 舞台の 正面だけ（横に ずれて 核が 人の 通り道に 来ない）。入らなければ 前の 形 */ ...(O.near ? { near: O.near } : {}), ...(Object.keys(st).length ? { st } : {}), ...(o.tk ? { pad: 0 } : {}),
    build: (P) => [...(o.nocore || o.front ? o.env(P) : clipFront(o.env(P), FRONT_A)), ...core(P), ...(o.top ? o.top(P) : [])] };
  if (facBig(name, def)) { SETS[name] = { keys: [].concat(keys), old }; for (const k of [].concat(keys)) facUp(k, name); }
}

/* ===== 本1・本2（はじまりの 地方）===== */
/* ハクの 小屋 → 村はずれの 農家（核の 小屋・奥の 納屋・柵の 麦畑・井戸・薪の 山・荷車・木）*/
const WHEAT = 'wheat ["growth"=7]';
const field = (a0, b0, a1, b1, P, crop = WHEAT) => [F(a0 - 1, b0 - 1, 0, a1 + 1, b1 + 1, 0, P.fence), F(a0, b0, 0, a1, b1, 0, "air"), F(a0, b0, -1, a1, b1, -1, "farmland"), F(a0, b0, 0, a1, b1, 0, crop), F(a0, (b0 + b1) >> 1, -1, a1, (b0 + b1) >> 1, -1, "water"), F(a0, (b0 + b1) >> 1, 0, a1, (b0 + b1) >> 1, 0, "air"), S1(a0 - 1, b0 + 1, 0, "air")];
const well = (a, b, P) => [F(a - 1, b - 1, -3, a + 1, b + 1, -1, P.wall || "cobblestone"), S1(a, b, -2, "water"), S1(a, b, -1, "water"), F(a - 1, b - 1, 0, a + 1, b + 1, 0, P.wall || "cobblestone"), S1(a, b, 0, "water"), S1(a - 1, b - 1, 1, P.fence), S1(a + 1, b + 1, 1, P.fence), S1(a - 1, b - 1, 2, P.fence), S1(a + 1, b + 1, 2, P.fence), F(a - 1, b - 1, 3, a + 1, b + 1, 3, P.slab), S1(a, b, 2, "chain")];
function cart(a, b, P) { return [S1(a, b - 1, 0, P.fence), S1(a + 2, b - 1, 0, P.fence), S1(a, b + 1, 0, P.fence), S1(a + 2, b + 1, 0, P.fence), F(a, b - 1, 1, a + 2, b + 1, 1, P.plank), S1(a + 1, b, 2, "hay_block"), S1(a, b, 2, "barrel"), F(a - 2, b, 1, a - 1, b, 1, P.fence)]; }
set("x_b01hut", "b01hut", "b01hut", { box: [-1, -14, 24, 14], H: 12, env: (P) => [
  ...road(-1, -7, 22, -6, "dirt_path"), ...road(6, -5, 8, 3, "dirt_path"),
  ...house(10, -14, 19, -4, 6, P, { wall: "spruce_planks", log: "spruce_log", roof: "dark_oak_planks", door: "f", chim: [17, -12] }), F(10, -10, 0, 10, -8, 2, "air"),
  S1(11, -12, 0, "hay_block"), S1(12, -12, 0, "hay_block"), S1(11, -12, 1, "hay_block"), S1(17, -6, 0, "barrel"), S1(9, -12, 0, "hay_block"), S1(9, -13, 0, "hay_block"), S1(9, -12, 1, "hay_block"),
  ...field(9, 5, 20, 12, P), ...well(13, 0, P),
  F(0, 6, 0, 3, 7, 0, P.log), F(0, 6, 1, 2, 7, 1, P.log), S1(1, 6, 2, P.log), S1(4, 7, 0, P.log),
  ...cart(20, -2, P), ...crates(6, 8, P),
  ...tree(23, -11, 7, P), ...tree(23, 2, 6, P), ...tree(3, -12, 6, P), ...tree(0, 11, 5, P), ...tree(16, 13, 6, P),
  ...post(-1, -8, P), ...post(-1, 8, P), ...post(9, -5, P, 3),
  F(24, -14, 0, 24, 14, 0, P.fence), ...scatter(0, -14, 24, 14, [P.plant, "poppy", "dandelion", P.plant], 26, 11),
] });
/* オルドの 石板蔵 → 石垣で 囲った 古い 蔵の 屋敷（門・大きな 母屋の 蔵・石碑の 列・大木）*/
set("x_b01kura", "b01kura", "b01kura", { box: [-1, -14, 26, 14], H: 12, env: (P) => [
  ...wall(-1, -14, -1, -3, 2, "cobblestone", "mossy_cobblestone"), ...wall(-1, 3, -1, 14, 2, "cobblestone", "mossy_cobblestone"), ...wall(-1, -14, 26, -14, 2, "cobblestone", "mossy_cobblestone"), ...wall(-1, 14, 26, 14, 2, "cobblestone", "mossy_cobblestone"), ...wall(26, -14, 26, 14, 2, "cobblestone", "mossy_cobblestone"),
  F(-1, -2, 0, -1, 2, 2, "air"), F(-1, -3, 0, -1, -3, 4, "stone_bricks"), F(-1, 3, 0, -1, 3, 4, "stone_bricks"), F(-1, -3, 5, -1, 3, 5, "dark_oak_slab"), S1(-2, -3, 3, P.lamp), S1(-2, 3, 3, P.lamp),
  ...road(-1, -1, 25, 1, "gravel"), F(-1, -1, -1, 6, 1, -1, "gravel"),
  ...house(12, -9, 23, 9, 7, P, { wall: "stone_bricks", log: "dark_oak_log", roof: "deepslate_tiles", door: "f", cap: "deepslate_tile_slab" }), F(12, -1, 0, 12, 1, 3, "air"), F(12, -2, 4, 12, 2, 4, "dark_oak_planks"),
  ...[-12, -8].flatMap((b) => [S1(9, b, 0, "chiseled_stone_bricks"), S1(9, b, 1, "chiseled_stone_bricks"), S1(9, b, 2, "stone_brick_slab")]), ...[8, 12].flatMap((b) => [S1(9, b, 0, "chiseled_stone_bricks"), S1(9, b, 1, "chiseled_stone_bricks"), S1(9, b, 2, "stone_brick_slab")]),
  ...toro(8, -3, P), ...toro(8, 3, P), ...tree(4, -10, 9, P), ...tree(20, 12, 7, P), ...tree(21, -12, 6, P),
  ...crates(24, -12, P), S1(1, 10, 0, "moss_block"), S1(2, 11, 0, "mossy_cobblestone"), ...scatter(0, -13, 25, 13, ["moss_carpet", P.plant, "fern"], 24, 12),
] });

/* ===== 本5（サンドリア）===== */
const palm = (a, b, h) => [F(a, b, 0, a, b, h - 1, "jungle_log"), F(a - 2, b, h - 1, a + 2, b, h - 1, "jungle_leaves", "keep"), F(a, b - 2, h - 1, a, b + 2, h - 1, "jungle_leaves", "keep"), F(a - 1, b - 1, h, a + 1, b + 1, h, "jungle_leaves", "keep"), S1(a - 3, b, h - 2, "jungle_leaves"), S1(a + 3, b, h - 2, "jungle_leaves"), S1(a, b - 3, h - 2, "jungle_leaves"), S1(a, b + 3, h - 2, "jungle_leaves")];
/* 夜の 街道の 詰所 → 砂岩の 塀に 囲まれた 街道の 関所（見張りの 塔・門・らくだの 水おけ・天幕・やし）。核の 寝床は 塀の 中の 詰所の 奥 */
set("x_b5post", "b5post", "b5post", { box: [-1, -15, 26, 15], H: 16, env: (P) => [
  ...road(-1, -15, 2, 15, "sandstone"), ...road(6, -2, 26, 2, "smooth_sandstone"),
  ...wall(6, -15, 6, -4, 3, "sandstone", "cut_sandstone"), ...wall(6, 4, 6, 15, 3, "sandstone", "cut_sandstone"), ...wall(6, -15, 26, -15, 3, "sandstone", "cut_sandstone"), ...wall(6, 15, 26, 15, 3, "sandstone", "cut_sandstone"), ...wall(26, -15, 26, 15, 3, "sandstone", "cut_sandstone"),
  F(6, -3, 0, 6, -3, 6, "cut_sandstone"), F(6, 3, 0, 6, 3, 6, "cut_sandstone"), F(6, -3, 7, 6, 3, 7, "smooth_sandstone"), F(6, -2, 6, 6, 2, 6, "sandstone"), S1(5, -3, 5, P.lamp), S1(5, 3, 5, P.lamp), F(6, -1, 4, 6, 1, 5, "orange_wool"),
  ...tower(20, -14, 5, 13, P, { wall: "sandstone", trim: "cut_sandstone", door: true }), S1(20, -12, 12, "orange_wool"),
  ...block(16, 5, 24, 13, 5, P, { wall: "sandstone", top: "smooth_sandstone" }), F(16, 9, 0, 16, 9, 1, "air"),
  ...tentA(9, -10, 6, "white_wool", "orange_wool"), ...tentA(9, 10, 5, "white_wool", "red_wool"),
  ...pool(11, -3, 15, 3, "cut_sandstone", 1), S1(13, 0, 0, "air"),
  ...palm(3, -12, 7), ...palm(4, 12, 8), ...palm(23, -4, 7), ...palm(14, 13, 6),
  ...crates(18, -4, P), S1(22, 4, 0, "hay_block"), S1(23, 4, 0, "hay_block"), ...post(-1, -5, P, 3), ...post(-1, 5, P, 3), ...post(8, -3, P, 2), ...post(8, 3, P, 2),
  ...scatter(-1, -15, 26, 15, ["deadbush"], 14, 21),
] });
/* 城の 地下水路の 出口 → 城壁の 下の 水門の 口（高い 城壁と 二つの 塔・格子の アーチから 流れ出る 水・外の 堀・がれき・枯れ草）*/
set("x_b5drain", "b5drain", "channel", { box: [-1, -16, 18, 16], H: 18, env: (P) => [
  ...wall(8, -16, 11, 16, 13, "sandstone", "cut_sandstone"), F(8, -16, 0, 8, 16, 1, "cut_sandstone"),
  F(8, -2, -1, 11, 2, 3, "air"), F(8, -2, -2, 11, 2, -2, "smooth_sandstone"), F(8, -2, -1, 11, 2, -1, "water"), F(8, -3, 4, 8, 3, 4, "chiseled_sandstone"), F(8, -2, 0, 8, 2, 3, "iron_bars"), F(8, -3, 0, 8, -3, 3, "cut_sandstone"), F(8, 3, 0, 8, 3, 3, "cut_sandstone"),
  ...tower(7, -15, 6, 17, P, { wall: "sandstone", trim: "cut_sandstone" }), ...tower(7, 10, 6, 17, P, { wall: "sandstone", trim: "cut_sandstone" }),
  F(12, -16, 13, 18, 16, 13, "sandstone"), ...block(13, -9, 18, 9, 18, P, { wall: "sandstone", top: "smooth_sandstone", door: false, win: "orange_stained_glass" }),
  F(-1, -16, -2, 6, -6, -1, "water"), F(-1, 6, -2, 6, 16, -1, "water"), F(-1, -16, -3, 6, 16, -3, "sandstone", "keep"), F(7, -16, -2, 7, 16, -1, "cut_sandstone"),
  ...scatter(0, -15, 6, -7, ["sandstone", "cobblestone", "deadbush"], 8, 31), ...scatter(0, 7, 6, 15, ["sandstone", "cut_sandstone", "deadbush"], 8, 32),
  S1(7, -5, 0, P.lamp), S1(7, 5, 0, P.lamp), ...palm(-1, -13, 6), ...palm(-1, 13, 7),
] });

/* ===== 本6（クリスタリア）===== */
const spire = (a, b, h, m = "amethyst_block") => [F(a, b, 0, a + 1, b + 1, h - 3, m), F(a, b, h - 2, a, b, h, m), S1(a, b, h + 1, "amethyst_cluster"), S1(a + 1, b + 1, h - 2, "amethyst_cluster")];
/* 水晶の 祭壇 → 割れた 晶洞（玄武岩・方解石・紫水晶の 三重の 殻の 丸天井を 前で 割って 中を 見せる・林の ような 紫水晶の 柱・ころがった 殻の かけら・光る 石）*/
set("x_r5altar", "r5altar", "crysaltar", { box: [-1, -15, 22, 15], H: 16, env: (P) => [
  F(-1, -15, -1, 22, 15, -1, "calcite"), ...scatter(-1, -15, 22, 15, ["tuff", "smooth_basalt", "amethyst_block"], 26, 501, -1),
  ...Array.from({ length: 14 }, (_, h) => { const f = Math.sqrt(1 - (h / 14) ** 2), ea = Math.round(8.5 * f), eb = Math.round(15 * f), L = [F(14 - ea, -eb, h, 14 + ea, eb, h, "smooth_basalt")];
    if (ea > 1) L.push(F(15 - ea, 1 - eb, h, 13 + ea, eb - 1, h, "calcite")); if (ea > 2) L.push(F(16 - ea, 2 - eb, h, 12 + ea, eb - 2, h, "amethyst_block")); if (ea > 3 && eb > 3) L.push(F(17 - ea, 3 - eb, h, 11 + ea, eb - 3, h, "air")); return L; }).flat(),
  F(12, -3, 14, 16, 3, 14, "smooth_basalt"), F(13, -2, 13, 15, 2, 13, "amethyst_block"),
  F(5, -15, 0, 9, 15, 15, "air"), ...[[-14, -9, 7], [-8, -4, 10], [-3, 3, 12], [4, 8, 9], [9, 14, 5]].map(([b0, b1, h]) => F(10, b0, h, 10 + (b0 & 1), b1, 15, "air")),
  ...mound(4, -15, 9, -10, 4, "smooth_basalt", null, 502), ...mound(4, 10, 9, 15, 3, "calcite", null, 503), S1(6, -12, 4, "amethyst_cluster"), S1(5, 12, 3, "amethyst_cluster"),
  ...spire(13, -9, 7), ...spire(16, -5, 9), ...spire(19, -9, 5), ...spire(13, 7, 8), ...spire(17, 4, 9), ...spire(19, 8, 5), ...spire(15, 0, 6, "budding_amethyst"), ...spire(4, -6, 4), ...spire(4, 6, 5),
  ...scatter(11, -10, 20, 10, ["amethyst_cluster", "amethyst_cluster", "budding_amethyst"], 18, 504),
  S1(20, 0, 6, "shroomlight"), S1(14, -12, 4, "shroomlight"), S1(14, 12, 4, "shroomlight"), S1(17, -6, 10, "shroomlight"), S1(17, 6, 10, "shroomlight"),
  ...scatter(4, -15, 9, 15, ["amethyst_cluster", "tuff", "calcite"], 10, 505),
] });
/* ボルトの 店先 → 鍛冶と 細工の 工房（工房の 建物・木材と 鉄の 置き場・砥石・作業台・看板の 灯り）*/
set("x_b6bolt", "b6bolt", "b6bolt", { box: [-1, -14, 22, 14], H: 12, env: (P) => [
  ...house(8, -8, 19, 8, 6, P, { wall: "spruce_planks", log: "spruce_log", roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "f", chim: [16, 6] }), F(8, -2, 0, 8, 2, 3, "air"), F(7, -3, 4, 7, 3, 4, "spruce_slab"), S1(7, 0, 3, P.lamp),
  S1(10, -6, 0, "smithing_table"), S1(10, 6, 0, "anvil"), S1(12, 6, 0, "blast_furnace"), S1(13, 6, 0, "blast_furnace"), S1(11, -6, 0, "crafting_table"), S1(12, -6, 0, "grindstone"), S1(16, -6, 0, "barrel"), S1(17, -6, 0, "barrel"),
  F(1, -13, 0, 5, -12, 1, "spruce_log"), F(1, -11, 0, 4, -10, 0, "stripped_spruce_log"), F(1, 10, 0, 4, 12, 0, "iron_block"), S1(2, 11, 1, "raw_iron_block"), S1(5, 11, 0, "anvil"), S1(5, 9, 0, "grindstone"),
  ...crates(20, -12, P), ...crates(20, 10, P), ...post(-1, -6, P, 3), ...post(-1, 6, P, 3), ...spire(20, -2, 4), S1(14, -12, 0, "amethyst_block"), S1(14, -11, 0, "amethyst_cluster"),
  ...scatter(-1, -14, 22, 14, ["amethyst_cluster", "tuff", "cobblestone"], 10, 41),
] });
/* 洞くつの 入口の 運び出し場 → 岩山の 大きな 坑口と 運び出し場（方解石の 岩山・木の 枠の 坑口・レール・起重機・天幕・水晶の 箱）*/
set("x_r5camp", "r5camp", "cryscamp", { box: [-2, -15, 24, 15], H: 16, env: (P) => [
  ...mound(10, -15, 24, 15, 13, "calcite", null, 7), ...skin(10, -15, 24, 15, 13, "calcite", "tuff").slice(0, 0),
  F(10, -3, 0, 24, 3, 5, "air"), F(10, -3, -1, 24, 3, -1, "gravel"), F(10, -4, 0, 10, -4, 6, P.log), F(10, 4, 0, 10, 4, 6, P.log), F(9, -5, 7, 11, 5, 7, P.log), F(9, -3, 8, 9, 3, 8, "spruce_slab"), S1(9, -2, 6, HANG(P)), S1(9, 2, 6, HANG(P)),
  ...[14, 18, 22].flatMap((a) => [F(a, -3, 0, a, -3, 4, P.log), F(a, 3, 0, a, 3, 4, P.log), F(a, -3, 5, a, 3, 5, P.plank)]), F(5, 0, 0, 24, 0, 0, "RA"),
  F(16, -15, 3, 18, -12, 7, "amethyst_block"), F(14, 12, 2, 16, 15, 6, "amethyst_block"), S1(10, -8, 4, "amethyst_cluster"), S1(11, 9, 5, "amethyst_cluster"),
  ...tentA(1, -11, 5, "white_wool", "red_wool"), ...tentA(1, 11, 5, "white_wool", "blue_wool"),
  F(6, 6, 0, 6, 6, 6, P.log), F(6, 3, 6, 6, 6, 6, P.log), S1(6, 3, 5, "chain"), S1(6, 3, 4, "amethyst_block"),
  ...crates(5, -7, P), S1(7, -8, 0, "amethyst_block"), S1(8, -8, 0, "amethyst_block"), ...post(-2, -7, P, 3), ...post(-2, 7, P, 3),
] });
/* ゴウの 岩 → 大きな 顔の 岩の 岩場（核の 顔の 岩・後ろの 大岩・世捨て人の 差しかけ小屋・薬草の 棚・水晶の かけら）*/
set("x_b6rock", "b6rock", "b6rock", { box: [-1, -14, 22, 14], H: 16, env: (P) => [
  ...mound(7, -12, 20, 10, 14, "stone", null, 9), F(7, -4, 6, 7, 4, 12, "stone"), S1(6, -2, 9, "black_concrete"), S1(6, 2, 9, "black_concrete"), F(6, -2, 7, 6, 2, 7, "black_concrete"), S1(6, 0, 8, "stone"),
  ...mound(10, 6, 21, 14, 7, "calcite", null, 10), ...spire(18, 11, 6), ...spire(15, -13, 5),
  F(1, 8, 0, 4, 12, 2, "air"), F(1, 8, 0, 1, 8, 2, P.log), F(4, 8, 0, 4, 8, 2, P.log), F(1, 12, 0, 1, 12, 2, P.log), F(4, 12, 0, 4, 12, 2, P.log), F(0, 7, 3, 5, 13, 3, "spruce_slab"), S1(3, 12, 0, "lectern"), S1(2, 11, 0, "red_bed"), S1(3, 9, 2, HANG(P)),
  F(1, -12, 0, 1, -8, 2, P.fence), F(1, -12, 2, 1, -8, 2, "hay_block"), S1(2, -10, 0, "brewing_stand"), S1(3, -10, 0, "cauldron"),
  ...scatter(-1, -14, 6, 14, ["amethyst_cluster", "tuff", "cobblestone", "fern"], 12, 51),
] });

/* ===== 本7（コラリアの 海）===== */
/* 岬の 灯台 → 岩の 岬と 高い 灯台（紅白の 塔 22・灯の 部屋・回り廊下・灯台守の 家・石の 階段・崖の 柵）*/
set("x_r6cape", "r6cape", "lighthouse", { nocore: true, box: [-1, -12, 24, 12], H: 28, look: [12, 0, 8], D: [13, 15, 12], marks: { door: [9, 0, 5], keeper: [3, -6, 0] }, env: (P) => [
  ...mound(4, -12, 24, 12, 4, "stone", null, 12), F(5, -11, 3, 23, 11, 3, "grass_block"), F(-1, -2, 0, 4, 2, 3, "air"), ...[0, 1, 2, 3].map((k) => F(k, -1, 0, k, 1, k, "stone_brick_stairs")),
  F(10, -3, 4, 16, 3, 22, "white_concrete", "hollow"), F(10, -3, 9, 16, 3, 11, "red_concrete"), F(10, -3, 16, 16, 3, 18, "red_concrete"), F(11, -2, 9, 15, 2, 11, "air"), F(11, -2, 16, 15, 2, 18, "air"),
  F(9, -4, 23, 17, 4, 23, "polished_andesite"), F(9, -4, 24, 17, 4, 24, "iron_bars"), F(10, -3, 24, 16, 3, 24, "air"), F(11, -2, 24, 15, 2, 27, "glass"), F(12, -1, 24, 14, 1, 26, "sea_lantern"), F(10, -3, 28, 16, 3, 28, "red_concrete"), F(12, -1, 29, 14, 1, 29, "red_concrete"), S1(13, 0, 30, "lightning_rod"),
  F(10, 0, 4, 10, 0, 5, "air"), S1(9, -1, 6, P.lamp), S1(9, 1, 6, P.lamp), S1(10, 0, 13, "glass"), S1(13, -3, 13, "glass"), S1(13, 3, 13, "glass"), S1(10, 0, 20, "glass"),
  ...up(house(18, -10, 23, -4, 4, P, { wall: "white_terracotta", log: "spruce_log", roof: "blue_terracotta", door: "l", cap: "spruce_slab" }), 4),
  F(5, 11, 4, 23, 11, 4, P.fence), F(23, -11, 4, 23, 11, 4, P.fence), F(5, -11, 4, 17, -11, 4, P.fence), S1(6, 6, 4, "barrel"), S1(7, 6, 4, "barrel"),
  ...scatter(4, -12, 24, 12, ["stone", "cobblestone", "gravel"], 10, 61, 3),
] });
/* 夜の 浜の 野営 → 流木と 舟の 浜（砂丘・浜に 上げた 舟 二そう・網を 干す 竿・漁師の 物置・焚き火の 輪）*/
set("x_b7beach", "b7beach", "beachcamp", { box: [-2, -15, 22, 15], H: 10, env: (P) => [
  F(-2, -15, -1, 22, 15, -1, "sand"), F(-2, -15, -2, 22, 15, -3, "sandstone"), ...mound(12, -15, 22, -4, 3, "sand", null, 13), ...mound(14, 5, 22, 15, 4, "sand", null, 14),
  ...boat(5, -11, 8, P, 0, { mh: 5 }), ...boat(6, 10, 7, P, 0, { mast: false }),
  ...[8, 11, 14].flatMap((a) => [F(a, -3, 0, a, -3, 3, P.fence), F(a, 3, 0, a, 3, 3, P.fence)]), F(8, -3, 3, 14, 3, 3, P.fence), F(9, -2, 1, 13, 2, 2, "cobweb"),
  ...house(16, -3, 21, 3, 4, P, { wall: "birch_planks", log: "spruce_log", roof: "spruce_planks", door: "f" }),
  F(0, -14, 0, 3, -14, 0, "stripped_birch_log"), F(1, 12, 0, 1, 15, 0, "stripped_birch_log"), F(20, -9, 0, 22, -9, 0, "stripped_oak_log"),
  ...scatter(-2, -15, 22, 15, ["deadbush", "stone", "gravel"], 10, 71),
  ...post(-2, -7, P, 2), ...post(-2, 7, P, 2), S1(4, -6, 0, "barrel"), S1(4, 6, 0, "barrel"),
] });
/* 網元の 舟小屋 → 網元の 舟着き場（石積みの 船着き・水・桟橋・大きな 舟小屋・網干し・魚の 樽・舟 二そう）*/
const dock = (P) => [
  F(9, -15, -3, 22, 15, -1, "stone_bricks"), F(10, -14, -2, 22, 2, -1, "water"), F(10, -14, 0, 22, 2, 3, "air"),
  F(10, 5, 0, 20, 5, 0, P.plank), F(10, 4, 0, 20, 4, 0, P.plank), ...[12, 16, 20].map((a) => S1(a, 5, 1, P.fence)), S1(20, 4, 1, P.fence), S1(20, 4, 2, P.lamp),
  ...boat(12, -6, 7, P, -1, { mh: 6, sail: "white_wool" }), ...boat(13, -11, 6, P, -1, { mast: false }),
];
set("x_r6hut", ["r6hut", "b17port"], "boathut", { box: [-2, -15, 22, 15], H: 14, env: (P) => [
  ...dock(P),
  ...house(9, 7, 20, 15, 6, P, { wall: P.plank, log: P.log, roof: "dark_prismarine", cap: "prismarine_brick_slab", door: "f" }), F(9, 10, 0, 9, 12, 3, "air"),
  ...[1, 3, 5].flatMap((a) => [F(a, 7, 0, a, 7, 3, P.fence), F(a, 13, 0, a, 13, 3, P.fence)]), F(1, 8, 2, 1, 12, 3, "cobweb"), F(3, 8, 2, 3, 12, 3, "cobweb"), F(5, 8, 2, 5, 12, 3, "cobweb"),
  ...crates(6, -13, P), S1(7, -11, 0, "barrel"), S1(8, -11, 0, "barrel"), ...post(-2, -10, P, 3), ...post(-2, 10, P, 3), ...post(8, 3, P, 3),
] });
/* 石の 女 → 沈んだ 神殿の 前庭（海の ない 世界の かわり。苔むした 海の 石の 柱の 列・崩れた アーチ・潮だまり）*/
set("x_b7statue", "b7statue", "b7statue", { box: [-1, -14, 22, 14], H: 14, env: (P) => [
  F(-1, -14, -1, 22, 14, -1, "prismarine_bricks"), F(0, -13, -1, 21, 13, -1, "dark_prismarine", "replace prismarine_bricks"),
  ...[-12, -8, 8, 12].flatMap((b) => [0, 6, 12, 18].map((a) => F(a, b, 0, a, b, 3 + Math.floor(nz(a, b, 81) * 7), "prismarine"))),
  F(16, -6, 0, 16, -6, 9, "prismarine_bricks"), F(16, 6, 0, 16, 6, 9, "prismarine_bricks"), F(16, -6, 10, 16, 6, 11, "dark_prismarine"), F(16, -4, 9, 16, 4, 9, "prismarine_bricks"), S1(16, 0, 10, "sea_lantern"),
  ...pool(18, -10, 22, -3, "prismarine_bricks", 1), ...pool(18, 3, 22, 10, "prismarine_bricks", 1), S1(20, -6, -1, "sea_pickle"), S1(20, 6, -1, "sea_pickle"),
  ...scatter(-1, -14, 22, 14, ["prismarine", "sea_lantern", "dark_prismarine"], 10, 82), ...scatter(-1, -14, 22, 14, ["seagrass", "sea_pickle"], 0, 83),
] });

/* ===== 本9〜本12（ネクロス・フロストヘイム）===== */
/* 境の 橋 → 谷川を 渡る 石の アーチ橋（核の 橋の 両側へ 谷を のばす・岸の 岩・向こう岸の 関所の 門と 番小屋・枯れ木・墓石）*/
set("x_b09bridge", "b09bridge", "mc_bridge", { box: [-1, -16, 24, 16], H: 14, env: (P) => [
  F(2, -16, -4, 7, -6, -1, "air"), F(2, 6, -4, 7, 16, -1, "air"), F(2, -16, -5, 7, -6, -5, "gravel"), F(2, 6, -5, 7, 16, -5, "gravel"), F(2, -16, -4, 7, -6, -3, "water"), F(2, 6, -4, 7, 16, -3, "water"),
  ...scatter(1, -16, 8, 16, ["blackstone", "basalt", "mossy_cobblestone"], 14, 91, -1),
  ...block(13, -7, 18, -3, 6, P, { wall: P.wall, top: P.trim }), ...block(13, 3, 18, 7, 6, P, { wall: P.wall, top: P.trim }), F(13, -2, 6, 13, 2, 7, P.wall), F(13, -2, 5, 13, 2, 5, P.trim), S1(12, -3, 4, P.lamp), S1(12, 3, 4, P.lamp),
  ...house(18, 9, 23, 15, 4, P, { wall: P.plank, log: P.log, roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "l" }),
  ...road(9, -1, 24, 1, "gravel"),
  ...deadtree(20, -12, 7), ...deadtree(-1, -12, 5, "dark_oak_log", 2), ...deadtree(23, 3, 6, "dark_oak_log", 3), ...deadtree(0, 12, 6),
  ...[[10, -13], [11, -10], [10, 11], [12, 13], [21, -6]].flatMap(([a, b]) => [S1(a, b, 0, "cobblestone_wall"), S1(a, b, 1, "stone_brick_slab")]),
  ...post(9, -4, P, 2), ...post(9, 4, P, 2),
] });
/* 雪の 峠 → 雪山の 鞍部（核の 尾根の 外に 高い 雪山・峠の 石積みの 道しるべと 祠・雪の トウヒ・置き去りの そり・番小屋の 跡）*/
const pass = (P) => [
  ...mound(-1, -16, 24, -6, 13, "stone", null, 101), ...skin(-1, -16, 24, -6, 13, "stone", "snow"), ...mound(-1, 6, 24, 16, 15, "stone", null, 102), ...skin(-1, 6, 24, 16, 15, "stone", "snow"),
  ...mound(12, -8, 24, 8, 6, "stone", null, 103), ...skin(12, -8, 24, 8, 6, "stone", "snow"), F(10, -2, 0, 24, 2, 8, "air"), F(10, -2, -1, 24, 2, -1, "packed_ice", "replace stone"), F(10, -2, -1, 24, 2, -1, "snow"),
  F(14, -4, 0, 14, -4, 3, "cobblestone"), S1(14, -4, 4, P.lamp), F(14, 4, 0, 14, 4, 2, "cobblestone"), S1(14, 4, 3, "cobblestone_wall"),
  ...spruce(1, -5, 8, { snow: true }), ...spruce(20, -10, 9, { snow: true }), ...spruce(3, 13, 7, { snow: true }), ...spruce(22, 11, 8, { snow: true }),
  F(19, 3, 0, 21, 3, 0, "spruce_slab"), S1(19, 3, 1, "barrel"), F(11, -5, 0, 11, -5, 1, "spruce_fence"), F(11, -5, 2, 11, -5, 2, "red_wool"),
  ...scatter(-1, -5, 24, 5, ["snow_layer"], 20, 104),
];
set("x_b09pass", ["b09pass", "b12pass"], "mc_pass", { box: [-1, -16, 24, 16], H: 18, env: pass });
/* 外れの 小屋（雪）→ 雪の 中の 山小屋（核の 小屋・薪小屋・積んだ 薪・トウヒ・そり・柵）*/
set("x_b10hut", "b10hut", "hut", { box: [-1, -14, 22, 14], H: 14, env: (P) => [
  F(-1, -14, -1, 22, 14, -1, "snow"), ...road(-1, -1, 0, 1, "spruce_planks"),
  ...house(10, 5, 18, 13, 4, P, { wall: "spruce_planks", log: "stripped_spruce_log", roof: "spruce_planks", door: "l" }), F(12, 5, 0, 16, 5, 2, "air"), F(12, 6, 0, 16, 8, 1, "spruce_log"),
  F(9, -12, 0, 13, -11, 1, "spruce_log"), F(9, -12, 2, 12, -11, 2, "spruce_log"), S1(15, -11, 0, "spruce_log"), 
  ...spruce(20, -9, 10, { snow: true }), ...spruce(5, -12, 8, { snow: true }), ...spruce(21, 2, 9, { snow: true }), ...spruce(2, 11, 7, { snow: true }), ...spruce(16, -2, 6, { snow: true }),
  F(4, 8, 0, 6, 8, 0, "spruce_slab"), S1(4, 8, 1, "barrel"),
  ...fenceL(-1, -14, -1, -6, P), ...fenceL(-1, 6, -1, 14, P), ...post(-1, -5, P, 2), ...post(-1, 5, P, 2),
  ...mound(18, -14, 22, -8, 3, "snow", null, 112),
] });
/* 氷の 隠れ家 → 雪山の 氷の 洞（下は 岩・上は 雪の 三つの 峰・大きな 口の 中に 隠れ家・氷の 柱と つらら・焚き火・寝床・薪・凍った 滝・雪の トウヒ）*/
set("x_b11den", "b11den", "mc_den", { box: [-1, -15, 20, 15], H: 18, env: (P) => [
  F(-1, -15, -1, 20, 15, -1, "snow"), F(4, -9, -1, 17, 9, -1, "packed_ice"),
  ...mound(6, -13, 20, 13, 11, "stone", null, 121), ...mound(9, -13, 20, -2, 15, "stone", null, 123), ...mound(10, 3, 20, 13, 13, "stone", null, 124), ...skin(6, -13, 20, 13, 16, "stone", "snow"), F(6, -13, 0, 20, 13, 3, "stone", "replace snow"),
  F(6, -9, 0, 17, 9, 4, "air"), F(6, -7, 5, 16, 7, 6, "air"), F(7, -4, 7, 15, 4, 8, "air"), F(6, -10, 0, 17, -10, 3, "packed_ice", "replace stone"), F(6, 10, 0, 17, 10, 3, "packed_ice", "replace stone"), F(18, -6, 0, 18, 6, 6, "packed_ice", "replace stone"),
  ...[[10, -7, 4], [15, 6, 6], [13, -5, 6]].map(([a, b, h]) => F(a, b, 0, a, b, h, "blue_ice")),
  ...[[7, -8, 4], [11, 8, 4], [15, -8, 4], [8, -6, 6], [12, 6, 6], [9, -2, 8], [13, 3, 8], [11, 0, 8], [15, -1, 8], [11, 0, 7]].map(([a, b, h]) => S1(a, b, h, "ice")),
  S1(11, 0, 0, "campfire"), F(13, -4, 0, 14, -3, 0, "white_carpet"), F(13, 3, 0, 14, 4, 0, "light_blue_carpet"), F(9, 6, 0, 10, 7, 0, "spruce_log"), S1(9, 6, 1, "spruce_log"), ...crates(15, -7, P),
  F(16, 3, 0, 16, 5, 0, "spruce_fence"), F(16, 3, 1, 16, 5, 1, "iron_bars"), S1(8, -8, 0, "lantern"), S1(16, 0, 0, "barrel"), S1(16, 0, 1, "lantern"), S1(17, -4, 3, "sea_lantern"), S1(17, 4, 3, "sea_lantern"), S1(12, -9, 2, "sea_lantern"),
  F(6, 11, 0, 6, 12, 9, "packed_ice"), F(4, 10, -1, 5, 13, -1, "ice"), S1(5, 11, 0, "blue_ice"),
  ...spruce(4, -14, 8, { snow: 1 }), ...spruce(5, 14, 7, { snow: 1 }), ...spruce(18, -14, 6, { snow: 1 }), ...spruce(19, 14, 7, { snow: 1 }),
  S1(4, -11, 0, "stone"), S1(5, -11, 0, "cobblestone"), S1(4, 8, 0, "stone"), ...scatter(-1, -15, 5, 15, ["snow_layer"], 12, 122),
] });
/* 雷神の 祠 → 山の 上の 雷神の 社（石段・鳥居の 列・石の 灯籠・しめ縄の 柵・高い 避雷針・杉）*/
set("x_r8hokora", "r8hokora", "shrine", { box: [-3, -14, 26, 14], H: 22, env: (P) => [
  ...mound(6, -14, 26, 14, 7, "stone", null, 131), ...skin(6, -14, 26, 14, 7, "stone", "snow"), F(5, -2, 0, 26, 2, 12, "air"), ...[6, 7, 8, 9, 10, 11].map((a, i) => F(a, -2, -1, a, 2, i, "stone_bricks")), F(12, -9, 0, 26, 9, 12, "air"), F(12, -9, -1, 26, 9, 5, "stone_bricks", "replace air"), F(12, -9, 5, 26, 9, 5, "stone_bricks"),
  ...[[8, 7], [12, 12]].flatMap(([a, h]) => [F(a, -3, 0, a, -3, h, "red_nether_brick"), F(a, 3, 0, a, 3, h, "red_nether_brick"), F(a, -4, h - 1, a, 4, h - 1, "red_nether_brick"), F(a, -3, h - 3, a, 3, h - 3, "dark_oak_planks")]),
  ...up(house(17, -5, 24, 5, 5, P, { wall: "dark_oak_planks", log: "red_nether_brick", roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "f", floor: "dark_oak_planks" }), 6),
  F(21, 0, 6, 21, 0, 7, "sea_lantern"), F(20, 0, 12, 20, 0, 18, "lightning_rod"),
  ...toro(13, -6, P), ...toro(13, 6, P), ...up(toro(15, -7, P), 6), ...up(toro(15, 7, P), 6),
  F(12, -9, 6, 12, -3, 6, "chain"), F(12, 3, 6, 12, 9, 6, "chain"),
  ...spruce(3, -11, 10), ...spruce(3, 11, 11), ...up(spruce(23, -12, 9), 6), ...up(spruce(24, 11, 9), 6),
] });
/* 北の 峠の 小屋 → 峠の 山小屋の 宿（核の 小屋の 奥に 二階の 大きな 丸太小屋・馬小屋・鐘の 柱・薪・トウヒ）*/
set("x_b12cabin", "b12cabin", "cabin2", { box: [-1, -15, 24, 15], H: 16, env: (P) => [
  F(-1, -15, -1, 24, 15, -1, "snow"),
  ...house(10, -8, 21, 8, 8, P, { wall: "spruce_planks", log: "spruce_log", roof: "dark_oak_planks", door: "f", chim: [18, -6] }), F(11, -7, 4, 20, 7, 4, "spruce_planks"), S1(10, -4, 5, "glass_pane"), S1(10, 4, 5, "glass_pane"), F(9, -2, 3, 9, 2, 3, "spruce_slab"),
  ...house(2, 9, 8, 15, 4, P, { wall: "spruce_planks", log: "spruce_log", roof: "spruce_planks", door: "l" }), F(3, 9, 0, 7, 9, 2, "air"), S1(5, 12, 0, "hay_block"), S1(4, 13, 0, "hay_block"),
  F(6, -6, 0, 6, -6, 4, "spruce_log"), F(6, -6, 5, 6, -4, 5, "spruce_log"), S1(6, -4, 4, "bell"),
  F(2, -13, 0, 5, -12, 1, "spruce_log"), ...spruce(22, -13, 10, { snow: true }), ...spruce(23, 12, 9, { snow: true }), ...spruce(1, -9, 8, { snow: true }),
  ...post(-1, -5, P, 3), ...post(-1, 5, P, 3), ...scatter(-1, -15, 24, 15, ["snow_layer"], 20, 141),
] });
/* 海峡の 港 → 港町の 船着き場（石の 岸壁で 囲った 深い 船だまり・長い 桟橋・帆の 大きな 船・倉庫・荷の 起重機・灯台の 灯）*/
const harbor = (P, wall = "stone_bricks") => [
  F(11, -16, -4, 26, 16, -1, wall), F(12, -15, -3, 26, 15, -1, "water"), F(12, -15, 0, 26, 15, 6, "air"),
  F(12, 6, 0, 24, 7, 0, P.plank), ...[14, 18, 22].flatMap((a) => [S1(a, 8, -1, P.log), S1(a, 8, 0, P.fence), S1(a, 8, 1, P.lamp)]),
  ...boat(14, -6, 12, P, -1, { mh: 9, sail: "white_wool" }).concat([F(15, -6, 1, 25, -6, 1, "air"), F(14, -8, 0, 26, -4, 0, "air", "replace water")]), F(15, -7, 0, 25, -5, 0, P.plank),
  ...boat(15, 12, 7, P, -1, { mast: false }),
  ...house(1, -16, 8, -8, 6, P, { wall: P.plank, log: P.log, roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "r" }),
  F(6, 9, 0, 6, 9, 6, P.log), F(6, 9, 7, 11, 9, 7, P.log), F(11, 9, 3, 11, 9, 6, "chain"), S1(11, 9, 2, "barrel"), ...crates(3, 10, P), ...crates(8, -6, P),
  F(26, -16, 0, 26, -14, 6, wall), S1(26, -15, 7, "sea_lantern"), F(26, 14, 0, 26, 16, 4, wall), S1(26, 15, 5, P.lamp),
  ...post(-1, -6, P, 3), ...post(-1, 6, P, 3),
];
set("x_b12port", "b12port", "mc_port", { box: [-1, -16, 26, 16], H: 18, env: (P) => harbor(P) });
set("x_r9pier", "r9pier", "pier", { box: [-1, -16, 26, 16], H: 18, env: (P) => harbor(P, "end_stone_bricks") });
set("x_u_boat", "u_boat", "u_boat", { box: [-1, -16, 26, 16], H: 18, env: (P) => harbor(P, "end_stone_bricks") });

/* ===== 本12〜本15（さいはて・竜骨）===== */
const ER = "end_stone", EB = "end_stone_bricks";
/* 竜の 見晴らし台 → 岬の 岩の 上の 見晴らし台（端の 石の 丘・石段・物見の やぐら・旗・竜の 骨の 遠景）*/
set("x_r9look", "r9look", "lookout", { box: [-1, -15, 24, 15], H: 18, env: (P) => [
  ...mound(7, -15, 24, 15, 7, ER, null, 151), F(6, -2, 0, 12, 2, 7, "air"), ...[6, 7, 8, 9, 10, 11].map((a, i) => F(a, -2, -1, a, 2, i, EB)), F(12, -2, -1, 14, 2, 6, EB),
  ...tower(15, -3, 6, 12, P, { wall: EB, trim: "purpur_block", door: true, lamp: "end_rod" }), F(14, -4, 7, 21, 3, 7, "purpur_block"), F(14, -4, 8, 21, 3, 8, P.fence), F(15, -3, 8, 20, 2, 8, "air"),
  ...[-9, 9].flatMap((b) => [F(10, b, 4, 10, b, 11, "purpur_pillar"), F(10, b + (b > 0 ? -2 : 1), 9, 10, b + (b > 0 ? -1 : 2), 11, "purple_wool")]),
  ...ribs(22, -14, -6, 8), ...ribs(19, -14, -6, 7), S1(23, -10, 0, "bone_block"), F(16, 8, 5, 23, 9, 6, "bone_block"), S1(23, 9, 7, "bone_block"),
  ...post(-1, -6, P, 3, "end_rod"), ...post(-1, 6, P, 3, "end_rod"), ...scatter(-1, -15, 6, 15, ["chorus_plant", ER, "purpur_block"], 8, 152),
] });
/* 竜骨の 門 → 竜の 骸の 門（大きな 肋骨の 弧の 列が 道を 包む・頭骨・紫の 灯・泣く 黒曜石）*/
set("x_r9gate", "r9gate", "bonegate", { box: [-1, -15, 28, 15], H: 18, env: (P) => [
  F(-1, -15, -1, 28, 15, -1, ER), ...road(-1, -2, 28, 2, EB),
  ...[10, 13, 16, 19, 22].flatMap((a, i) => ribs(a, -9 - (i % 2), 9 + (i % 2), 12 - Math.abs(i - 2))), F(10, 0, 12, 22, 0, 13, "bone_block"), F(9, 0, 11, 9, 0, 12, "bone_block"),
  F(24, -6, 0, 28, 6, 6, "bone_block"), F(24, -4, 1, 26, 4, 5, "air"), S1(24, -3, 4, "crying_obsidian"), S1(24, 3, 4, "crying_obsidian"), F(23, -5, 0, 23, -4, 1, "bone_block"), F(23, 4, 0, 23, 5, 1, "bone_block"),
  ...[[9, -5], [9, 5], [15, -5], [15, 5], [21, -5], [21, 5]].flatMap(([a, b]) => post(a, b, { fence: "purpur_pillar" }, 2, "soul_lantern")),
  ...scatter(-1, -15, 28, 15, ["crying_obsidian", "bone_block", "obsidian"], 10, 161),
] });
/* 骨の 階段 → 竜の 背骨の 崖（端の 石の 高い 崖・崖に そって 上る 骨の 階段の 両わきの 肋・崖の 上の 紫の 灯）*/
set("x_r9stair", "r9stair", "bonestair", { box: [-1, -15, 22, 15], H: 20, env: (P) => [
  ...mound(9, -15, 22, 15, 14, ER, null, 171), F(9, -3, 0, 22, 3, 14, "air"), F(9, -3, 0, 22, 3, 6, EB), ...mound(-1, -15, 8, -5, 6, ER, null, 172), ...mound(-1, 5, 8, 15, 7, ER, null, 173),
  ...[11, 14, 17, 20].flatMap((a) => [F(a, -5, 6, a, -4, 12, "bone_block"), F(a, 4, 6, a, 5, 12, "bone_block"), F(a, -4, 13, a, 4, 13, "bone_block")]),
  ...post(9, -3, { fence: "purpur_pillar" }, 7, "soul_lantern"), ...post(9, 3, { fence: "purpur_pillar" }, 7, "soul_lantern"), S1(21, 0, 7, "crying_obsidian"), S1(21, -2, 7, "end_rod"), S1(21, 2, 7, "end_rod"),
] });
/* 竜骨の 祭壇 → 骨の 柱の 輪の 祭壇の 庭（骨の 柱 8本・紫の 壇・竜の 頭骨の 背・泣く 黒曜石）*/
set("x_r9keys", "r9keys", "keyaltar", { box: [-1, -15, 24, 15], H: 16, env: (P) => [
  F(-1, -15, -1, 24, 15, -1, ER), F(1, -12, -1, 20, 12, -1, "purpur_block"), F(3, -10, -1, 18, 10, -1, EB),
  ...[[1, -11], [1, 11], [9, -13], [9, 13], [17, -12], [17, 12]].flatMap(([a, b]) => [F(a, b, 0, a, b, 7 + Math.floor(nz(a, b, 181) * 4), "bone_block"), S1(a, b, 12, "end_rod")]),
  F(18, -8, 0, 24, 8, 10, "bone_block"), F(18, -6, 0, 19, 6, 6, "air"), F(19, -5, 7, 19, -3, 8, "black_concrete"), F(19, 3, 7, 19, 5, 8, "black_concrete"), F(18, -7, 0, 18, 7, 1, "bone_block"), F(17, -8, 0, 17, -6, 2, "bone_block"), F(17, 6, 0, 17, 8, 2, "bone_block"),
  S1(20, 0, 3, "crying_obsidian"), S1(20, 0, 4, "end_rod"), ...scatter(-1, -15, 24, 15, ["crying_obsidian", "chorus_flower"], 6, 182),
] });
/* 竜骨の 城の 塔 → 城壁と 大きな 塔の 根もと（核の 塔の 両わきに 城壁・奥に 高い 主塔・紫の 旗・竜の 像）*/
set("x_r9wing", "r9wing", "wingtower", { box: [-1, -16, 24, 15], H: 26, env: (P) => [
  ...wall(10, -16, 12, -9, 9, EB, "purpur_block"), ...wall(10, 5, 12, 15, 9, EB, "purpur_block"), ...tower(9, -16, 5, 14, P, { wall: EB, trim: "purpur_block", lamp: "end_rod" }), ...tower(9, 11, 5, 14, P, { wall: EB, trim: "purpur_block", lamp: "end_rod" }),
  ...tower(15, -5, 9, 23, P, { wall: EB, trim: "purpur_block", lamp: "end_rod", win: "purple_stained_glass" }), F(14, -2, 0, 14, 2, 4, "air"), F(14, -3, 5, 14, 3, 5, "purpur_block"),
  F(13, -12, 10, 13, -10, 16, "purple_wool"), F(13, 10, 10, 13, 12, 16, "purple_wool"),
  F(3, 8, 0, 7, 12, 1, "purpur_block"), F(4, 9, 2, 6, 11, 5, EB), F(5, 7, 4, 5, 6, 6, EB), F(5, 13, 4, 5, 14, 6, EB), S1(5, 10, 6, "dragon_head"),
  ...scatter(-1, -16, 8, 15, [ER, "chorus_plant"], 6, 191),
] });
/* 竜の 骨の 橋 → 深い 谷に かかる 骨の 橋（谷を 深く・両岸の 崖・巨大な 背骨の 節・肋の 欄干を 両側へ）*/
set("x_r9bridge", "r9bridge", "bonebridge", { box: [-1, -16, 24, 16], H: 14, env: (P) => [
  F(1, -16, -10, 9, -5, -1, "air"), F(1, 5, -10, 9, 16, -1, "air"), F(1, -16, -11, 9, 16, -11, "obsidian"), F(1, -16, -10, 9, 16, -9, "end_stone", "replace air"),
  ...mound(10, -16, 24, -5, 6, ER, null, 201), ...mound(10, 5, 24, 16, 7, ER, null, 202), ...road(10, -2, 24, 2, EB),
  ...[[2, -6], [5, -7], [8, -6], [2, 6], [5, 7], [8, 6]].map(([a, b]) => F(a, b, -9, a, b, 2, "bone_block")), ...ribs(14, -4, 4, 6), ...ribs(18, -4, 4, 5),
  ...post(12, -3, { fence: "purpur_pillar" }, 2, "soul_lantern"), ...post(12, 3, { fence: "purpur_pillar" }, 2, "soul_lantern"), ...post(-1, -5, { fence: "purpur_pillar" }, 2, "soul_lantern"), ...post(-1, 5, { fence: "purpur_pillar" }, 2, "soul_lantern"),
] });
/* 鱗の 墓 → 竜の 墓場（大きな 骨・紫の 墓標の 列・端の 棒の 灯・泣く 黒曜石）*/
set("x_u_scalegrave", "u_scalegrave", "u_scalegrave", { box: [-1, -15, 24, 15], H: 16, env: (P) => [
  F(-1, -15, -1, 24, 15, -1, ER), ...ribs(16, -14, -5, 9), ...ribs(19, -14, -5, 8), ...ribs(22, -13, -6, 6), F(13, -10, 0, 24, -9, 1, "bone_block"),
  F(14, 6, 0, 20, 12, 3, "bone_block"), F(15, 7, 1, 19, 11, 3, "air"), S1(14, 8, 2, "black_concrete"), S1(14, 10, 2, "black_concrete"),
  ...[[9, -7], [9, 7], [12, -3], [12, 3], [8, 11], [8, -12]].flatMap(([a, b]) => [F(a, b, 0, a, b, 2, "purpur_pillar"), S1(a, b, 3, "end_rod")]),
  ...scatter(-1, -15, 24, 15, ["crying_obsidian", "bone_block", "chorus_plant"], 10, 211),
] });

/* ===== 本16・本17（雲の 島）===== */
const cloud = (a0, b0, a1, b1, s) => [...mound(a0, b0, a1, b1, 3, "white_wool", null, s)];
const birch = (a, b, h, P) => tree(a, b, h, P, { log: "birch_log", leaf: "birch_leaves" });
/* 雲の 島の 小屋 → 島の 暮らしの 小屋（核の 小屋・奥に 風車・畑・白樺・雲の かたまり）*/
const windmill = (a, b, P) => [F(a, b, 0, a + 4, b + 4, 7, "birch_planks", "hollow"), F(a - 1, b - 1, 8, a + 5, b + 5, 8, "birch_slab"), F(a, b, 9, a + 4, b + 4, 9, "birch_planks"), F(a + 1, b + 1, 10, a + 3, b + 3, 10, "birch_slab"), F(a, b + 2, 0, a, b + 2, 1, "air"),
  S1(a - 1, b + 2, 6, "birch_log"), F(a - 2, b + 2, 1, a - 2, b + 2, 11, "white_wool"), F(a - 2, b - 3, 6, a - 2, b + 7, 6, "white_wool"), S1(a - 2, b + 2, 6, "birch_log")];
set("x_r10hut", "r10hut", "cabin", { box: [-1, -15, 24, 15], H: 14, env: (P) => [
  ...windmill(14, -12, P), ...field(9, 5, 18, 12, P), ...birch(22, 2, 7, P), ...birch(3, -11, 6, P), ...birch(21, 12, 6, P), ...birch(2, 11, 5, P),
  ...cloud(19, -15, 24, -6, 221), ...cloud(-1, 13, 6, 15, 222), ...road(-1, -1, 8, 1, "dirt_path"), ...post(-1, -5, P, 2), ...post(-1, 5, P, 2), ...crates(9, -4, P),
] });
/* 雲の 島の 村 → 島の 小さな 村（核の 家 二つと 井戸の まわりに 家 三軒・風車・柵・道・白樺）*/
set("x_b17vil", "b17vil", "skyvillage", { box: [-1, -16, 26, 16], H: 14, env: (P) => [
  ...road(8, -1, 26, 1, "dirt_path"), ...road(-1, -8, 26, -7, "dirt_path"),
  ...house(11, -15, 18, -10, 5, P, { wall: "birch_planks", log: "birch_log", roof: "light_blue_terracotta", cap: "birch_slab", door: "r" }),
  ...house(11, 9, 19, 15, 5, P, { wall: "birch_planks", log: "birch_log", roof: "cyan_terracotta", cap: "birch_slab", door: "l" }),
  ...house(20, -6, 26, 6, 6, P, { wall: "quartz_bricks", log: "birch_log", roof: "light_blue_terracotta", cap: "birch_slab", door: "f" }),
  ...windmill(2, 9, P), ...birch(9, -13, 6, P), ...birch(9, 13, 6, P), ...birch(24, -13, 7, P), ...birch(24, 13, 6, P),
  ...cloud(-1, -16, 6, -10, 231), ...post(10, -3, P, 2), ...post(10, 3, P, 2), ...crates(16, -5, P),
] });
/* 雲の 島の 森 → 白樺の 森（白樺 十本あまり・こけ・しだ・古い 石の 輪）*/
set("x_b17grove", "b17grove", "skygrove", { box: [-1, -16, 24, 16], H: 14, env: (P) => [
  F(-1, -16, -1, 24, 16, -1, "moss_block", "replace grass_block"), ...[[10, -12], [13, -6], [17, -11], [20, -3], [11, 7], [15, 12], [19, 6], [22, 12], [23, -13], [2, -12], [3, 12], [8, -15], [7, 15]].flatMap(([a, b], i) => birch(a, b, 6 + (i % 4), P)),
  ...[0, 1, 2, 3, 4, 5, 6, 7].map((k) => { const t = (k / 8) * Math.PI * 2; return F(16 + Math.round(Math.cos(t) * 4), Math.round(Math.sin(t) * 4), 0, 16 + Math.round(Math.cos(t) * 4), Math.round(Math.sin(t) * 4), 1 + (k % 2), "mossy_stone_bricks"); }),
  ...scatter(-1, -16, 24, 16, ["fern", "moss_carpet", "lily_of_the_valley", "azure_bluet"], 40, 241),
] });
/* 雲の 島の 端 → 島の 端の 石の 露台（核の 竜の 像と 手すりの 両わきへ 石の 露台・崩れた 柱・向こうの 雲の 海）*/
set("x_r10edge", "r10edge", "cloudedge", { box: [-1, -16, 22, 16], H: 12, env: (P) => [
  F(-1, -16, -1, 7, 16, -1, "quartz_bricks"), F(0, -15, -1, 6, 15, -1, "smooth_quartz", "replace quartz_bricks"), F(7, -16, 0, 7, -7, 0, "birch_fence"), F(7, 7, 0, 7, 16, 0, "birch_fence"),
  ...[[2, -12], [2, 12], [5, -9], [5, 9]].flatMap(([a, b], i) => [F(a, b, 0, a, b, 2 + i * 2, "quartz_pillar")]), F(2, -12, 6, 2, -10, 6, "quartz_slab"),
  F(8, -16, -4, 22, 16, -1, "air"), ...cloud(10, -16, 22, -2, 251).map((o) => ["f", o[1], o[2], o[3] - 4, o[4], o[5], o[6] - 4, o[7], o[8]]), ...cloud(12, 2, 22, 16, 252).map((o) => ["f", o[1], o[2], o[3] - 5, o[4], o[5], o[6] - 5, o[7], o[8]]), F(9, -16, -4, 22, 16, -6, "white_wool"),
  ...birch(1, 14, 6, P), ...birch(1, -15, 5, P),
] });

/* ===== 本18・本19・裏1〜裏3（ルミナ）===== */
/* オルドの 牧場の 小屋 → 牧場の 母屋と 納屋（核の 小屋・大きな 赤い 納屋・柵の 放牧地・干し草・水おけ・サイロ）*/
set("x_b18hut", "b18hut", "hut", { box: [-1, -16, 26, 16], H: 16, env: (P) => [
  ...house(10, -15, 21, -5, 7, P, { wall: "red_terracotta", log: "spruce_log", roof: "dark_oak_planks", door: "r" }), F(15, -5, 0, 17, -5, 3, "air"), S1(12, -13, 0, "hay_block"), S1(13, -13, 0, "hay_block"), S1(12, -13, 1, "hay_block"),
  F(23, -15, 0, 26, -12, 11, "smooth_stone", "hollow"), F(23, -15, 12, 26, -12, 12, "dark_oak_slab"),
  F(9, 4, 0, 26, 4, 0, P.fence), F(9, 16, 0, 26, 16, 0, P.fence), F(9, 4, 0, 9, 16, 0, P.fence), F(26, 4, 0, 26, 16, 0, P.fence), F(14, 12, 0, 16, 12, 0, WCAUL), S1(20, 7, 0, "hay_block"), S1(21, 7, 0, "hay_block"),
  ...road(-1, -1, 9, 1, "dirt_path"), ...tree(2, -12, 7, P), ...tree(3, 12, 6, P), ...tree(24, 0, 6, P), ...post(-1, -6, P, 2), ...post(-1, 6, P, 2), ...cart(5, -8, P),
  ["e", 18, 10, 0, "cow"], ["e", 21, 13, 0, "sheep"], ["e", 13, 8, 0, "sheep"],
] });
/* 闘技場の 一角 → 闘技場の 半円の 客席（核の 床・表彰台の まわりに 3段の 石の 客席・旗・入口の アーチ・灯の 柱）*/
const stands = (a0, b0, a1, b1, n, mat = "stone_bricks", seat = "smooth_stone_slab") => { const L = []; for (let i = 0; i < n; i++) L.push(F(a0 + i, b0, 0, a1, b1, i, mat), F(a0 + i, b0, i + 1, a0 + i, b1, i + 1, seat)); return L; };
set("x_b19ring", "b19ring", "cupring", { box: [-1, -17, 22, 17], H: 14, env: (P) => [
  F(-1, -16, -1, 22, 16, -1, "smooth_sandstone"), ...stands(13, -15, 21, 15, 5, "stone_bricks", "smooth_stone_slab"),
  ...[[5, -16, -11], [5, 11, 16]].flatMap(([a, b0, b1]) => [F(a, b0, 0, 12, b1, 2, "stone_bricks"), F(a, b0, 3, 12, b1, 3, "smooth_stone_slab")]),
  F(5, -12, 3, 12, -11, 4, "cut_sandstone"), F(5, 11, 3, 12, 12, 4, "cut_sandstone"),
  ...[-12, -4, 4, 12].flatMap((b) => [F(22, b, 0, 22, b, 9, "dark_oak_log"), F(21, b, 6, 21, b, 9, b % 8 ? "red_wool" : "yellow_wool")]),
] });
/* 闘技場の 控え室 → 闘技場の 裏の 控えの 館（柱の 回廊の 一階と 二階の 露台・前は 開いて 中が 見える・武具の 棚・寝台・手当ての 隅・奥の 二つの 塔と 旗・前庭の 打ち込み台と 日よけ）*/
set("x_b19room", "b19room", "hut", { box: [-1, -15, 24, 15], H: 20, top: (P) => [
  F(-1, -4, 0, 6, 4, 5, "air"), ...[[1, -4], [1, 4], [5, -4], [5, 4]].map(([a, b]) => F(a, b, 0, a, b, 2, "dark_oak_fence")), F(0, -5, 3, 6, 5, 3, "red_wool"), ...[-3, 0, 3].map((b) => F(0, b, 3, 6, b, 3, "white_wool")),
  F(4, -3, 0, 5, -3, 0, "spruce_slab"), F(4, 3, 0, 5, 3, 0, "spruce_slab"), S1(2, -3, 0, WCAUL), S1(3, 0, 2, 'lantern ["hanging"=true]'),
], env: (P) => [
  F(-1, -15, -1, 8, 15, -1, "sand"), F(9, -15, -1, 24, 15, -1, "smooth_stone"),
  F(9, -14, 0, 22, 14, 11, "stone_bricks", "hollow"), F(10, -13, 0, 21, 13, 10, "air"), F(10, -13, 6, 21, 13, 6, "spruce_planks"),
  F(9, -12, 0, 9, 12, 5, "air"), ...[-12, -8, -4, 4, 8, 12].map((b) => F(9, b, 0, 9, b, 5, "quartz_pillar")), F(9, -14, 6, 9, 14, 6, "cut_sandstone"),
  F(9, -13, 7, 11, 13, 10, "air"), F(9, -13, 7, 9, 13, 7, "stone_brick_wall"), F(12, -13, 7, 12, 13, 10, "stone_bricks"), ...[-10, -5, 5, 10].map((b) => F(12, b, 8, 12, b + 1, 9, "glass_pane")),
  ...[-10, -4, 4, 10].map((b, i) => F(9, b, 8, 9, b, 10, i % 2 ? "yellow_wool" : "red_wool")),
  ...gableB(8, -15, 23, 15, 12, "deepslate_tiles", { s: 2, cap: "deepslate_tile_slab", end: "stone_bricks" }),
  ...[[-15, -11], [11, 15]].flatMap(([b0, b1]) => [F(19, b0, 0, 23, b1, 16, "stone_bricks"), F(18, b0 - 0, 16, 23, b1, 16, "smooth_stone"), ...crenel(19, b0, 23, b1, 17, "stone_bricks"), F(19, (b0 + b1) >> 1, 8, 19, (b0 + b1) >> 1, 13, "glass_pane"), F(21, (b0 + b1) >> 1, 17, 21, (b0 + b1) >> 1, 19, "dark_oak_fence"), F(20, (b0 + b1) >> 1, 18, 20, (b0 + b1) >> 1, 19, b0 < 0 ? "red_wool" : "yellow_wool")]),
  ...[12, 16, 20].flatMap((a) => [F(a, -15, 0, a, -15, 7, "stone_bricks"), F(a, 15, 0, a, 15, 7, "stone_bricks")]),
  ...[-10, -6, 6, 10].flatMap((b) => [F(21, b, 0, 21, b, 3, "iron_bars"), S1(21, b + (b > 0 ? 1 : -1), 0, "spruce_fence"), S1(21, b + (b > 0 ? 1 : -1), 1, "spruce_fence")]), F(21, -2, 0, 21, 2, 1, "barrel"),
  F(14, -9, 0, 18, -9, 0, "spruce_slab"), F(14, 9, 0, 18, 9, 0, "spruce_slab"), S1(11, 12, 0, "anvil"), S1(11, 10, 0, "grindstone"), S1(19, -12, 0, WCAUL), S1(18, -12, 0, "brewing_stand"), F(19, 11, 0, 20, 12, 0, "white_wool"),
  ...hangL(13, -6, 5, 1, "lantern"), ...hangL(13, 6, 5, 1, "lantern"), ...hangL(18, 0, 5, 1, "lantern"), S1(16, -8, 7, "red_wool"), S1(16, 8, 7, "red_wool"), F(14, -3, 7, 18, 3, 7, "red_carpet"),
  ...[[5, -10], [5, -13], [5, 10], [5, 13]].flatMap(([a, b]) => [S1(a, b, 0, "dark_oak_fence"), S1(a, b, 1, "hay_block"), S1(a, b, 2, "carved_pumpkin")]),
  S1(7, -6, 0, WCAUL), S1(7, 6, 0, WCAUL), ...crates(6, 11, P), F(4, -8, 0, 4, -7, 0, "spruce_fence"), F(4, -8, 1, 4, -7, 1, "iron_bars"),
  ...post(8, -14, P, 3), ...post(8, 14, P, 3), ...scatter(-1, -15, 8, 15, ["gravel", "sandstone"], 14, 191, -1),
] });
/* 闘技場の 下の 座 → 地下の 牢の 広間（前が 開いた 切り口の 地下。深い 色の 石の 柱と 天井・鎖・独房の 列・鉄の 格子）*/
const cutaway = (a0, b0, a1, b1, h, mat, roof) => [F(a0, b0, 0, a1, b1, h, mat, "hollow"), F(a0, b0 + 1, 0, a0, b1 - 1, h - 1, "air"), F(a0 - 1, b0, h, a1, b1, h, roof)];
/* 闘技場の 下の 座 → 闘技場の 輪切り（上は 砂の 闘技場と 段の 客席・旗。下は 前を 切った 地下の 牢の 広間: 柱と 梁・独房の 列・鎖・上へ 上がる 石段・天井の 格子から 光）*/
set("x_u_lockseat", "u_lockseat", "u_lockseat", { box: [-1, -15, 22, 15], H: 18, env: (P) => [
  F(-1, -15, -1, 22, 15, -1, "polished_deepslate"), F(-1, -2, -1, 3, 2, -1, "deepslate_tiles"), ...scatter(-1, -15, 3, 15, ["cobbled_deepslate", "gravel"], 12, 261, -1),
  F(4, -15, 0, 22, 15, 6, "deepslate_bricks", "hollow"), F(4, -14, 0, 4, 14, 5, "air"), F(5, -14, 0, 21, 14, 5, "air"), F(5, -14, -1, 21, 14, -1, "deepslate_tiles"), F(4, -15, 6, 4, 15, 6, "polished_blackstone_bricks"),
  F(4, -15, 7, 22, 15, 7, "sand"), F(4, -2, 6, 7, 2, 6, "air"), F(4, -2, 7, 7, 2, 7, "iron_bars"),
  ...[9, 13, 17].flatMap((a) => [F(a, -8, 0, a, -8, 5, "polished_deepslate"), F(a, 8, 0, a, 8, 5, "polished_deepslate"), F(a, -8, 5, a, 8, 5, "deepslate_tiles")]),
  F(6, -11, 0, 21, -11, 3, "iron_bars"), F(6, 11, 0, 21, 11, 3, "iron_bars"), ...[10, 14, 18].flatMap((a) => [F(a, -14, 0, a, -12, 4, "deepslate_bricks"), F(a, 12, 0, a, 14, 4, "deepslate_bricks")]), ...[8, 12, 16, 20].flatMap((a) => [F(a, -11, 0, a, -11, 1, "air"), F(a, 11, 0, a, 11, 1, "air")]),
  ...[[7, -13], [12, 13], [16, -13], [20, 13]].map(([a, b]) => S1(a, b, 0, "hay_block")), S1(12, -13, 0, "bone_block"), S1(16, 13, 0, "cauldron"), ...[[12, -13], [16, 13], [20, -13]].map(([a, b]) => F(a, b, 3, a, b, 5, "chain")),
  ...[10, 14, 18].flatMap((a) => [...hangL(a, -4, 5, 1), ...hangL(a, 4, 5, 1)]),
  ...[0, 1, 2, 3, 4, 5].map((k) => F(15 + k, -1, 0, 15 + k, 1, k, "polished_deepslate")), F(19, -1, 6, 21, 1, 7, "air"),
  F(4, -15, 8, 22, -15, 9, "stone_bricks"), F(4, 15, 8, 22, 15, 9, "stone_bricks"), F(4, -14, 8, 4, 14, 8, "iron_bars"), F(5, -14, 8, 14, -13, 8, "stone_brick_slab"), F(5, 13, 8, 14, 14, 8, "stone_brick_slab"),
  ...up(stands(15, -14, 22, 14, 5, "stone_bricks", "smooth_stone_slab"), 8),
  ...[-12, -4, 4, 12].flatMap((b, i) => [F(22, b, 13, 22, b, 17, "dark_oak_log"), F(21, b, 14, 21, b, 16, i % 2 ? "blue_wool" : "red_wool")]),
  ...[[5, -13], [5, 13]].flatMap(([a, b]) => [F(a, b, 8, a, b, 10, "dark_oak_fence"), S1(a, b, 11, "lantern")]), F(9, -5, 7, 13, 5, 7, "smooth_sandstone"), F(10, -4, 7, 12, 4, 7, "sand"),
] });
/* 闘技場の 客席の 上 → 大きな 客席（核の 段の 両わきへ 段を のばし、上に 屋根の 柱と 旗）*/
set("x_u_stands", "u_stands", "u_stands", { box: [-1, -16, 18, 16], H: 16, env: (P) => [
  ...stands(1, -16, 12, -7, 7), ...stands(1, 7, 12, 16, 7), F(9, -16, 0, 18, 16, 9, "stone_bricks"), F(13, -16, 10, 18, 16, 10, "smooth_stone_slab"),
  ...[-14, -8, 8, 14].flatMap((b) => [F(12, b, 10, 12, b, 14, "dark_oak_log"), F(12, b - 1, 15, 12, b + 1, 15, "dark_oak_slab")]), F(12, -16, 15, 12, 16, 15, "dark_oak_slab"),
  ...[-12, -4, 4, 12].map((b) => F(11, b, 11, 11, b, 14, b > 0 ? "red_wool" : "blue_wool")),
] });
/* 宝物庫 → 古い 石の 宝物庫の 神殿（前に 柱の 列と 三角の 破風・苔の 石壁と 控え壁・開いた 鉄の 扉の 枠・中の 金と 壺と 箱・屋根を こえる 奥の 塔・石の 灯籠）*/
set("x_u_vault", "u_vault", "u_vault", { box: [-1, -15, 22, 15], H: 21, env: (P) => [
  F(-1, -15, -1, 22, 15, -1, "polished_andesite"), F(-1, -3, -1, 9, 3, -1, "stone_bricks"), F(4, -15, -1, 8, 15, -1, "stone_bricks"), ...scatter(-1, -15, 22, 15, ["moss_block", "cracked_stone_bricks", "gravel"], 18, 435, -1),
  F(10, -11, 0, 22, 11, 9, "stone_bricks", "hollow"), F(11, -10, 0, 21, 10, 8, "air"), F(10, -11, 0, 22, 11, 2, "mossy_stone_bricks", "replace stone_bricks"),
  F(10, -5, 0, 10, 5, 6, "air"), F(10, -5, 7, 10, 5, 7, "iron_bars"), F(10, -6, 0, 10, -6, 8, "polished_andesite"), F(10, 6, 0, 10, 6, 8, "polished_andesite"), F(10, -6, 8, 10, 6, 8, "chiseled_stone_bricks"),
  ...[-14, -11, -8, -5, 5, 8, 11, 14].flatMap((b) => [F(9, b, 0, 9, b, 9, "quartz_pillar"), S1(9, b, 0, "chiseled_stone_bricks")]), F(8, -15, 10, 10, 15, 10, "smooth_stone"),
  ...gable(8, -15, 22, 15, 11, "deepslate_tiles", { s: 3, cap: "deepslate_tile_slab", end: "stone_bricks", endA: [8] }), S1(8, 0, 13, "chiseled_stone_bricks"),
  F(17, -3, 12, 21, 3, 19, "stone_bricks"), ...crenel(17, -3, 21, 3, 20, "stone_bricks"), S1(19, 0, 20, P.lamp), F(17, 0, 16, 17, 0, 18, "iron_bars"), F(19, -3, 16, 19, -3, 18, "iron_bars"), F(19, 3, 16, 19, 3, 18, "iron_bars"),
  ...[12, 16, 20].flatMap((a) => [F(a, -12, 0, a, -12, 7, "stone_bricks"), S1(a, -12, 8, "stone_brick_slab"), F(a, 12, 0, a, 12, 7, "stone_bricks"), S1(a, 12, 8, "stone_brick_slab")]),
  F(19, -9, 0, 21, -7, 1, "gold_block"), S1(20, -8, 2, "gold_block"), F(20, 7, 0, 21, 9, 0, "chest"), F(21, -4, 0, 21, 4, 0, "barrel"), ...[-3, -1, 1, 3].map((b) => S1(21, b, 1, "decorated_pot")), S1(15, 0, 0, "lodestone"), S1(15, 0, 1, "gold_block"),
  F(12, -10, 0, 18, -10, 2, "bookshelf"), F(12, 10, 0, 18, 10, 2, "bookshelf"), ...hangL(13, 0, 8, 1, "lantern"), ...hangL(17, -5, 8, 1, "lantern"), ...hangL(17, 5, 8, 1, "lantern"),
  ...toro(5, -10, P), ...toro(5, 10, P), ...toro(5, -14, P), ...toro(5, 14, P),
] });
/* クロガネの 闘技の 庭 → 鍛錬場（砂の 輪・核の 闘技台・道場の 建物・武具の 棚・的・旗・鉄の 柵）*/
set("x_u_kyard", "u_kyard", "arena", { box: [-1, -16, 24, 16], H: 14, env: (P) => [
  F(-1, -16, -1, 24, 16, -1, "gravel"), F(0, -15, -1, 9, 15, -1, "sand", "replace gravel"),
  ...house(13, -10, 23, 10, 6, P, { wall: "dark_oak_planks", log: "dark_oak_log", roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "f" }), F(13, -3, 0, 13, 3, 3, "air"), F(12, -4, 4, 12, 4, 4, "dark_oak_slab"),
  ...[[10, -14], [10, -12], [10, 12], [10, 14]].flatMap(([a, b]) => [S1(a, b, 0, "dark_oak_fence"), S1(a, b, 1, "hay_block"), S1(a, b, 2, "carved_pumpkin")]),
  F(1, -15, 0, 6, -15, 2, "iron_bars"), F(1, 15, 0, 6, 15, 2, "iron_bars"), S1(3, -14, 0, "anvil"), S1(4, -14, 0, "grindstone"), S1(3, 14, 0, "smithing_table"),
  ...[-8, 8].flatMap((b) => [F(12, b, 0, 12, b, 7, "dark_oak_log"), F(12, b + (b > 0 ? -1 : 1), 4, 12, b + (b > 0 ? -1 : 1), 7, "black_wool")]),
  ...post(-1, -6, P, 3), ...post(-1, 6, P, 3),
] });
/* 刀鍛冶の 鍛冶場 → 鍛冶場の 屋敷（核の 作業場・奥に 母屋と 煙突・炭の 小屋・水路と 水車・木材と 鉄の 置き場）。st1（焼けた）は 母屋の 屋根も 落ちる */
set("x_r3smithy", "r3smithy", "smithy", { box: [-1, -15, 24, 15], H: 16, env: (P) => [
  ...house(11, -9, 20, 9, 6, P, { wall: P.wall, log: P.log, roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "f", chim: [18, -7] }), F(11, -1, 0, 11, 1, 2, "air"),
  ...house(14, 11, 21, 15, 4, P, { wall: P.plank, log: P.log, roof: "dark_oak_planks", door: "l" }), F(15, 12, 0, 20, 14, 0, "coal_block"), F(15, 12, 1, 18, 14, 1, "coal_block"),
  F(22, -15, -2, 24, 15, -1, "water"), F(21, -15, -2, 21, 15, -1, "stone_bricks"), ...RAHo(23, -12, 3, 2, P.plank),
  F(1, 8, 0, 5, 9, 1, P.log), F(1, -9, 0, 4, -8, 0, "iron_block"), S1(2, -9, 1, "raw_iron_block"), S1(6, -10, 0, "barrel"), S1(7, -10, 0, "barrel"),
  ...post(-1, -7, P, 3), ...post(-1, 7, P, 3), ...scatter(-1, -15, 24, 15, ["coal_block", "cobblestone", "gravel"], 10, 291),
], st: { 1: (P) => [F(10, -10, 7, 21, 10, 14, "air"), F(11, -9, 3, 20, 9, 5, "air", "replace " + P.wall), F(11, -9, -1, 20, 9, -1, "blackstone"), S1(14, 0, 0, "campfire"), S1(17, -4, 0, "campfire"), F(14, 11, 4, 21, 15, 8, "air")] } });

/* ===== 裏5〜裏7（斬り跡・閻魔の 神殿）===== */
/* 斬り跡: 景色を 横切る 長い 割れ目（核の 割れ目の 両側へ）・まわりの 焼けた 地面・吹きとんだ 岩・倒れた 木 */
const burnt = (a0, b0, a1, b1, s) => [...scatter(a0, b0, a1, b1, ["coarse_dirt", "gravel", "cobbled_deepslate", "tuff"], 30, s, -1)];
set("x_u_crack1", "u_crack1", "u_crack", { box: [-1, -16, 18, 16], H: 8, env: (P) => [
  ...rift(1, 3, -16, -6, 6, "deepslate", 301), ...rift(1, 3, 6, 16, 6, "deepslate", 302), ...burnt(-1, -16, 18, 16, 303),
  ...mound(10, -14, 18, -6, 4, "cobbled_deepslate", null, 304), ...mound(12, 6, 18, 14, 3, "stone", null, 305), F(8, 9, 0, 13, 9, 0, P.log), F(9, -4, 0, 9, -9, 0, P.log),
  ...tree(16, 1, 6, P), ...tree(17, -10, 5, P),
] });
set("x_u_crack2", "u_crack2", "u_rivercrack", { box: [-1, -16, 20, 16], H: 8, env: (P) => [
  F(4, -16, -2, 6, -7, -1, "water"), F(4, 7, -2, 6, 16, -1, "water"), F(4, -16, -3, 6, 16, -3, "gravel", "keep"), F(3, -16, -1, 3, -7, -1, "stone"), F(7, -16, -1, 7, -7, -1, "stone"), F(3, 7, -1, 3, 16, -1, "stone"), F(7, 7, -1, 7, 16, -1, "stone"),
  ...rift(9, 11, -16, -7, 5, "deepslate", 311), ...rift(0, 1, 7, 16, 5, "deepslate", 312), ...burnt(-1, -16, 20, 16, 313),
  ...tree(15, -12, 6, P), ...tree(17, 8, 7, P), ...tree(-1, 13, 5, P), ...scatter(8, -16, 20, 16, ["short_grass", "poppy", "fern"], 16, 314),
] });
set("x_u_crack3", "u_crack3", "u_forestcrack", { box: [-1, -16, 22, 16], H: 12, env: (P) => [
  ...rift(1, 3, -16, -6, 6, "deepslate", 321), ...rift(1, 3, 6, 16, 6, "deepslate", 322),
  ...[[9, -13], [12, -8], [16, -14], [19, -5], [10, 9], [14, 13], [18, 7], [21, 12], [7, -15], [6, 15]].flatMap(([a, b], i) => tree(a, b, 6 + (i % 3), P)),
  F(6, -6, 0, 6, -11, 0, P.log), F(8, 5, 0, 13, 5, 0, P.log), S1(5, 4, 0, "stripped_oak_log"), S1(5, -5, 0, "stripped_oak_log"), S1(5, -5, 1, "stripped_oak_log"),
  ...scatter(-1, -16, 22, 16, ["fern", "moss_carpet", "short_grass", "brown_mushroom"], 30, 323),
] });
set("x_u_crack4", "u_crack4", "u_valley", { box: [-1, -16, 24, 16], H: 16, env: (P) => [
  ...mound(-1, -16, 24, -7, 13, "stone", null, 331), ...mound(-1, 7, 24, 16, 14, "stone", null, 332), F(-1, -16, 0, 24, -14, 3, "andesite", "replace stone"), F(-1, 14, 0, 24, 16, 3, "andesite", "replace stone"),
  ...rift(10, 12, -6, 6, 6, "deepslate", 334), ...rift(17, 19, -6, 6, 5, "deepslate", 335),
  ...skin(-1, -16, 24, -7, 13, "stone", "grass_block").filter((o, i) => i > 6), ...up(tree(20, -12, 6, P), 8),
] });
set("x_u_crack5", "u_crack5", "u_crowncrack", { box: [-1, -16, 24, 16], H: 10, env: (P) => [
  ...rift(2, 4, -16, -5, 8, "deepslate", 341), ...rift(2, 4, 5, 16, 8, "deepslate", 342), ...rift(13, 15, -12, 12, 6, "deepslate", 343),
  ...burnt(-1, -16, 24, 16, 344), F(18, -12, 0, 24, -6, 4, "stone_bricks"), F(19, -11, 0, 23, -7, 3, "air"), F(18, -9, 0, 18, -9, 2, "air"), S1(18, -6, 5, "stone_brick_wall"), F(18, 5, 0, 22, 11, 2, "cracked_stone_bricks"), F(19, 6, 3, 21, 10, 3, "stone_brick_slab"),
  ...post(-1, -6, P, 2), ...post(-1, 6, P, 2),
] });
/* 閻魔の 神殿 → 二重の 屋根の 大きな 堂（前に 朱の 鳥居・朱の 柱の 林と 黒い 梁・前が 開いた 堂・反った 軒・上の 段の 格子窓・金の 鴟尾・帳の 王の 段・かがり火・前を 流れる 黒い 川）*/
set("x_u_temple", "u_temple", "u_temple", { box: [-1, -16, 24, 16], H: 21, env: (P) => [
  F(-1, -16, -1, 24, 16, -1, "polished_blackstone_bricks"), F(0, -16, -1, 1, 16, -1, "water"), F(0, -16, -2, 1, 16, -2, "blackstone"), F(2, -2, -1, 3, 2, -1, "dark_oak_planks"),
  F(4, -15, 0, 22, -9, 0, "polished_blackstone_bricks"), F(4, 9, 0, 22, 15, 0, "polished_blackstone_bricks"),
  ...[6, 10, 14, 18].flatMap((a) => [-14, -10, -6, 6, 10, 14].map((b) => F(a, b, 0, a, b, 8, "red_concrete"))), ...[-14, -6, 6, 14].map((b) => F(6, b, 8, 21, b, 8, "dark_oak_log")), ...[6, 14].map((a) => F(a, -15, 8, a, 15, 8, "dark_oak_log")),
  F(6, -16, 9, 23, 16, 9, "deepslate_tile_slab"), F(7, -15, 10, 23, 15, 10, "deepslate_tiles"), ...[[6, -16], [6, 16], [23, -16], [23, 16]].map(([a, b]) => S1(a, b, 10, "deepslate_tile_slab")),
  F(8, -10, 11, 22, 10, 13, "dark_oak_planks", "hollow"), ...[-8, -4, 0, 4, 8].map((b) => F(8, b, 11, 8, b + 1, 12, "iron_bars")), ...[8, 22].flatMap((a) => [F(a, -10, 11, a, -10, 13, "red_concrete"), F(a, 10, 11, a, 10, 13, "red_concrete")]),
  F(7, -11, 14, 23, 11, 14, "deepslate_tile_slab"), F(8, -10, 15, 22, 10, 15, "deepslate_tiles"), F(10, -7, 16, 21, 7, 16, "deepslate_tiles"), F(12, -4, 17, 20, 4, 17, "deepslate_tiles"), F(13, -1, 18, 19, 1, 18, "deepslate_tiles"),
  S1(13, 0, 19, "gold_block"), S1(19, 0, 19, "gold_block"), ...[[7, -11], [7, 11], [23, -11], [23, 11]].map(([a, b]) => S1(a, b, 15, "deepslate_tile_slab")),
  F(22, -15, 0, 23, 15, 8, "dark_oak_planks"), F(12, -7, 0, 20, 7, 1, "polished_blackstone_bricks"), F(14, -5, 2, 20, 5, 2, "polished_blackstone"), F(21, -6, 1, 21, 6, 8, "red_concrete"), F(21, -5, 2, 21, 5, 7, "black_wool"), S1(21, 0, 8, "gold_block"),
  ...[-5, 5].flatMap((b) => [F(14, b, 3, 14, b, 4, "polished_blackstone_wall"), S1(14, b, 5, "soul_campfire")]),
  F(4, -6, 0, 4, -6, 9, "red_concrete"), F(4, 6, 0, 4, 6, 9, "red_concrete"), F(4, -6, 7, 4, 6, 7, "red_concrete"), F(4, -8, 10, 4, 8, 10, "polished_blackstone"), S1(4, -8, 11, "polished_blackstone_brick_slab"), S1(4, 8, 11, "polished_blackstone_brick_slab"), S1(4, 0, 8, "gold_block"),
  ...[[5, -9], [5, 9], [5, -12], [5, 12]].flatMap(([a, b]) => brazier(a, b, "soul_campfire")), ...[[6, -8], [6, 8], [10, -12], [10, 12], [18, -12], [18, 12]].flatMap(([a, b]) => hangL(a, b, 8, 1)),
] });

/* ===== 地方の 5話（ep_r1〜r9）===== */
/* 病んだ 森 → 枯れて 病んだ 森（白く 皮の むけた 枯れ木の 群れ・黒い 大木・ポドゾルと 粗い 土・きのこ・くもの巣）*/
set("x_r1grove", "r1grove", "deadwood", { box: [-2, -16, 24, 16], H: 16, env: (P) => [
  F(-2, -16, -1, 24, 16, -1, "podzol"), ...scatter(-2, -16, 24, 16, ["coarse_dirt", "mycelium", "rooted_dirt"], 40, 351, -1),
  ...[[8, -13], [9, -7], [12, -14], [15, -9], [18, -13], [21, -5], [9, 9], [10, 14], [14, 8], [17, 13], [20, 6], [23, 12], [22, -15]].flatMap(([a, b], i) => deadtree(a, b, 5 + (i % 4), i % 3 ? "stripped_dark_oak_log" : "stripped_birch_log", i)),
  F(15, -2, 0, 17, 0, 11, "dark_oak_log"), F(12, -5, 8, 12, -3, 9, "dark_oak_log"), F(20, 1, 8, 20, 3, 10, "dark_oak_log"), F(13, -1, 0, 13, -1, 2, "dark_oak_log"), F(19, -1, 0, 19, -1, 1, "dark_oak_log"),
  ...scatter(-2, -16, 24, 16, ["brown_mushroom", "red_mushroom", "deadbush", "cobweb"], 26, 352),
] });
/* 水の 配給所 → 配給の 広場（核の 屋台の 奥に 大きな 水の 貯め槽と 給水塔・行列の 柵・荷車・天幕・壊れた 壁）*/
set("x_r2ration", "r2ration", "stall", { box: [-8, -16, 18, 16], H: 18, env: (P) => [
  F(7, -6, 0, 13, 0, 4, P.wall, "hollow"), F(8, -5, 1, 12, -1, 4, "water"), F(7, -6, 5, 13, 0, 5, P.trim), ...[7, 13].flatMap((a) => [F(a, 2, 0, a, 2, 9, P.log), F(a, 8, 0, a, 8, 9, P.log)]), F(6, 1, 10, 14, 9, 13, "barrel", "hollow"), F(6, 1, 10, 14, 9, 10, P.plank), F(10, 1, 0, 10, 1, 9, "chain") ,
  ...tentA(-6, -12, 6, "white_wool", "red_wool"), ...tentA(-6, 12, 6, "white_wool", "blue_wool"), ...cart(2, -11, P), ...crates(15, -14, P), ...crates(15, 12, P),
  F(-8, -16, 0, 18, -16, 2, P.wall), F(-3, -16, 3, 6, -16, 4, P.wall), F(18, -16, 0, 18, 16, 3, P.wall), F(18, -2, 4, 18, 6, 6, P.wall), F(-8, 16, 0, 6, 16, 1, P.wall),
  ...post(-8, -6, P, 3), ...post(-8, 6, P, 3), ...scatter(-8, -16, 18, 16, ["cobblestone", "gravel", P.plant], 20, 361),
] });
/* オアシスの 市の 店先 → オアシスの 市場（核の 店の 両わきと 奥に 日よけの 屋台の 列・やし・水場・壺・ラクダの 荷）*/
const stallS = (a, b, P, c) => [F(a, b - 1, 0, a, b - 1, 2, P.log), F(a, b + 1, 0, a, b + 1, 2, P.log), F(a + 2, b - 1, 0, a + 2, b - 1, 2, P.log), F(a + 2, b + 1, 0, a + 2, b + 1, 2, P.log), F(a - 1, b - 2, 3, a + 3, b + 2, 3, c), F(a, b - 1, 0, a, b + 1, 0, P.plank), S1(a + 1, b, 0, "barrel"), S1(a, b, 1, "flower_pot")];
set("x_r4shop", "r4shop", "shopfront", { box: [-2, -16, 22, 16], H: 12, D: [13, 11, 9], env: (P) => [
  ...road(-2, -16, 22, 16, "smooth_sandstone"), ...stallS(0, -12, P, "orange_wool"), ...stallS(0, 12, P, "red_wool"), ...stallS(8, -12, P, "yellow_wool"), ...stallS(8, 12, P, "white_wool"), ...stallS(15, -8, P, "lime_wool"), ...stallS(15, 8, P, "cyan_wool"),
  ...pool(13, -4, 19, 4, "cut_sandstone", 1), ...palm(18, -1, 8), ...palm(21, -14, 7), ...palm(21, 14, 7), ...palm(-2, -16, 6),
  S1(11, -7, 0, "decorated_pot"), S1(11, 7, 0, "decorated_pot"), S1(12, -7, 0, "decorated_pot"),
] });
/* グロウの 坑道前の 広場 → 光ごけの 村の 坑口の 広場（核の 坑口の 奥の 岩山・光る こけの 灯・坑夫の 詰所・トロッコの 線・鉱石の 山）*/
set("x_r5glow", "r5glow", "mine", { box: [-6, -16, 22, 16], H: 18, env: (P) => [
  ...mound(7, -16, 22, 16, 14, P.rock || "stone", null, 371), F(7, -4, 0, 22, 4, 6, "air", "replace " + (P.rock || "stone")),
  ...[-10, 10].flatMap((b) => [F(7, b, 4, 7, b, 6, "shroomlight"), S1(6, b, 4, "glow_lichen")]), F(7, -16, 8, 9, 16, 8, "moss_block", "replace " + (P.rock || "stone")),
  ...house(-4, 7, 3, 15, 4, P, { wall: P.plank, log: P.log, roof: "dark_oak_planks", door: "l" }), ...crates(-4, -14, P), F(-2, -12, 0, 2, -12, 0, "RB"),
  S1(3, -9, 0, P.ore), S1(4, -9, 0, P.ore), S1(3, -10, 0, "coal_block"), ...post(-6, -6, P, 3, "shroomlight"), ...post(-6, 6, P, 3, "shroomlight"),
  ...scatter(-6, -16, 6, 16, ["moss_carpet", "gravel"], 16, 372),
] });
/* 墓守の 丘 → 赤い 灯籠の 墓地の 丘（核の 番小屋の まわりに 墓の 列・霊廟・鉄の 柵・枯れ木・赤い 灯）*/
set("x_r7yard", "r7yard", "redyard", { box: [-2, -16, 24, 16], H: 14, top: () => [F(-1, -6, 0, -1, -6, 2, "air"), F(-1, 6, 0, -1, 6, 2, "air")], env: (P) => [
  ...mound(10, -16, 24, 16, 3, "soul_soil", null, 381),
  ...[11, 14, 17, 20].flatMap((a) => [-14, -11, -8, 8, 11, 14].map((b, i) => F(a, b, 0 + (a > 13 ? 1 : 0), a, b, 1 + (a > 13 ? 1 : 0) + (i % 2), i % 3 ? "cobblestone_wall" : "polished_blackstone_bricks"))),
  F(19, -4, 2, 24, 4, 8, "polished_blackstone_bricks", "hollow"), F(19, -1, 2, 19, 1, 4, "air"), F(18, -5, 9, 24, 5, 9, "polished_blackstone_brick_slab"), S1(18, -2, 5, "red_candle"), S1(18, 2, 5, "red_candle"),
  F(-2, -16, 0, 24, -16, 1, "iron_bars"), F(-2, 16, 0, 24, 16, 1, "iron_bars"), ...[-13, 13].flatMap((b) => deadtree(9, b, 7, "dark_oak_log", b)),
  ...[[10, -5], [10, 5], [16, -16], [16, 16]].flatMap(([a, b]) => [S1(a, b, 0, "polished_blackstone_bricks"), S1(a, b, 1, "red_nether_brick_wall"), S1(a, b, 2, "red_candle"), S1(a, b, 3, "red_nether_brick_slab")]),
] });
/* 祭壇 → 黒い 石の 祭壇の 庭（石段の 壇・黒い 石の 柱の 輪・かがり火・奥の 崩れた 門）*/
set("x_r9altar", "r9altar", "altar", { box: [-1, -15, 24, 15], H: 16, env: (P) => [
  F(-1, -15, -1, 24, 15, -1, "polished_blackstone"), F(9, -9, 0, 24, 9, 0, "polished_blackstone_bricks"), F(11, -7, 1, 24, 7, 1, "polished_blackstone_bricks"),
  ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((k) => { const t = (k / 10) * Math.PI * 2; return F(15 + Math.round(Math.cos(t) * 8), Math.round(Math.sin(t) * 12), 0, 15 + Math.round(Math.cos(t) * 8), Math.round(Math.sin(t) * 12), 4 + (k % 3) * 2, "polished_blackstone_bricks"); }),
  F(22, -4, 2, 22, -4, 10, "blackstone"), F(22, 4, 2, 22, 4, 10, "blackstone"), F(22, -4, 11, 22, 4, 11, "polished_blackstone_bricks"), F(22, -1, 9, 22, 1, 10, "air"),
  ...[[8, -4], [8, 4], [12, -6], [12, 6]].flatMap(([a, b]) => [S1(a, b, 0, "polished_blackstone_wall"), S1(a, b, 1, "soul_campfire")]),
] });

/* 第127版(fac3): 箱に 見えない ための 部品（切妻・吊り灯・火皿・人形）*/
/* 切妻（棟は a の 向き。b の 両側から s マスごとに 1段 上がる。中は 空き。end: 妻の 壁）*/
function gable(a0, b0, a1, b1, h, mat, o = {}) { const s = o.s || 1, L = []; let k = 0;
  for (; b0 + (k + 1) * s <= b1 - (k + 1) * s; k++) { const p = b0 + k * s, q = b1 - k * s; L.push(F(a0, p, h + k, a1, p + s - 1, h + k, mat), F(a0, q - s + 1, h + k, a1, q, h + k, mat)); if (o.end) for (const a of o.endA || [a0, a1]) L.push(F(a, p + s, h + k, a, q - s, h + k, o.end)); }
  L.push(F(a0, b0 + k * s, h + k, a1, b1 - k * s, h + k, o.cap || mat)); return L; }
/* 切妻（棟は b の 向き。a の 前後から 上がる）*/
function gableB(a0, b0, a1, b1, h, mat, o = {}) { const s = o.s || 1, L = []; let k = 0;
  for (; a0 + (k + 1) * s <= a1 - (k + 1) * s; k++) { const p = a0 + k * s, q = a1 - k * s; L.push(F(p, b0, h + k, p + s - 1, b1, h + k, mat), F(q - s + 1, b0, h + k, q, b1, h + k, mat)); if (o.end) for (const b of o.endB || [b0, b1]) L.push(F(p + s, b, h + k, q - s, b, h + k, o.end)); }
  L.push(F(a0 + k * s, b0, h + k, a1 - k * s, b1, h + k, o.cap || mat)); return L; }
const hangL = (a, b, h, n, lamp = "soul_lantern") => [...(n > 0 ? [F(a, b, h - n + 1, a, b, h, "chain")] : []), S1(a, b, h - n, `${lamp} ["hanging"=true]`)];
const brazier = (a, b, fire = "soul_campfire", base = "polished_blackstone_bricks") => [S1(a, b, 0, base), S1(a, b, 1, fire)];
const candleP = (a, b, base = "polished_blackstone_wall", n = 3) => [S1(a, b, 0, base), S1(a, b, 1, `candle ["candles"=${n},"lit"=true]`)];
const crenel = (a0, b0, a1, b1, h, mat) => { const L = []; for (let a = a0; a <= a1; a += 2) L.push(S1(a, b0, h, mat), S1(a, b1, h, mat)); for (let b = b0; b <= b1; b += 2) L.push(S1(a0, b, h, mat), S1(a1, b, h, mat)); return L; };
const doll = (a, b, h, wool) => [S1(a, b, h, wool), S1(a, b, h + 1, "skeleton_skull")];
/* ===== 常世（灰都の 街の 中。足もとを ならさない・18 マス まで）===== */
const TG = (a0, b0, a1, b1, m = "tuff") => F(a0, b0, -1, a1, b1, -1, m);
const slamp = (a, b, h = 3) => [F(a, b, 0, a, b, h - 1, "polished_deepslate_wall"), S1(a, b, h, "soul_lantern")];
/* 渡し舟の 岸 → 黒い 川の 渡し場（川・石の 岸・もやい杭・青い 灯・向こう岸の 鳥居）*/
set("x_u08pier", "u08pier", "u08pier", { tk: 1, box: [-1, -9, 13, 9], H: 9, env: (P) => [
  TG(-1, -9, 13, 9, "deepslate_tiles"), F(3, -9, -3, 9, 9, -1, "water"), F(3, -9, -4, 9, 9, -4, "deepslate", "keep"), F(3, -9, 0, 9, 9, 2, "air"),
  ...[-7, -4, 4, 7].flatMap((b) => [F(3, b, -2, 3, b, 1, "dark_oak_log")]), F(10, -9, -1, 13, 9, -1, "deepslate_tiles"),
  F(11, -3, 0, 11, -3, 6, "red_nether_bricks"), F(11, 3, 0, 11, 3, 6, "red_nether_bricks"), F(11, -4, 6, 11, 4, 6, "red_nether_bricks"), F(11, -3, 4, 11, 3, 4, "dark_oak_planks"),
  ...slamp(1, -6), ...slamp(1, 6), ...slamp(12, -7), ...slamp(12, 7),
] });
/* 抜け殻の 闘技場の 席 → 闘技場の 一角（石の 客席の 段を 両わきへ・奥の 大きな 輪・鎖・青い 灯）*/
set("x_u08seat", "u08seat", "u08seat", { tk: 1, box: [-1, -11, 14, 11], H: 14, env: (P) => [
  TG(-1, -11, 14, 11, "stone_bricks"), ...stands(0, -11, 9, -8, 4, "stone_bricks", "stone_brick_slab"), ...stands(0, 8, 9, 11, 4, "stone_bricks", "stone_brick_slab"),
  F(10, -11, 0, 14, 11, 6, "stone_bricks"), F(13, -11, 7, 14, 11, 8, "chiseled_stone_bricks"), ...RAHo(12, 0, 10, 3, "iron_bars"), S1(12, 0, 10, "chain"),
  ...slamp(-1, -7, 3), ...slamp(-1, 7, 3), F(10, -10, 7, 10, -10, 10, "chain"), F(10, 10, 7, 10, 10, 10, "chain"),
] });
/* 遊び場 → 灰の 公園（核の 砂場・すべり台・ぶらんこの 奥に 枯れ木・二つめの ぶらんこ・シーソー・柵・灯）*/
set("x_u09play", "u09play", "u09play", { tk: 1, box: [-1, -10, 14, 10], H: 10, env: (P) => [
  TG(-1, -10, 14, 10, "gravel"), F(-1, -10, 0, 14, -10, 0, "iron_bars"), F(-1, 10, 0, 14, 10, 0, "iron_bars"), F(14, -10, 0, 14, 10, 0, "iron_bars"),
  F(9, 6, 0, 9, 6, 3, "iron_bars"), F(9, 9, 0, 9, 9, 3, "iron_bars"), F(9, 6, 4, 9, 9, 4, "iron_bars"), S1(9, 7, 2, "chain"), S1(9, 8, 2, "chain"), S1(9, 7, 1, "smooth_stone_slab"), S1(9, 8, 1, "smooth_stone_slab"),
  F(9, -9, 0, 9, -5, 0, "cut_copper_slab"), S1(9, -7, 0, "cut_copper"), ...deadtree(12, -2, 7, "dark_oak_log", 9), ...slamp(0, -8), ...slamp(0, 8), ...slamp(13, 0),
  S1(11, 4, 0, "polished_andesite_slab"), S1(11, 3, 0, "polished_andesite_slab"),
] });
/* 人形の 棚 → 人形の 家（二階建ての 家を 前で 切った 断面: 一階は 人形の 棚・二階は 小さな 寝台と 椅子・屋根裏の 丸窓・切妻の 屋根と 煙突・柵の 庭と 枯れ木・灯）*/
set("x_u09doll", "u09doll", "u09doll", { tk: 1, box: [-1, -10, 12, 10], H: 13, env: (P) => [
  TG(-1, -10, 12, 10, "gravel"), F(-1, -2, -1, 4, 2, -1, "spruce_planks"), ...scatter(-1, -10, 12, 10, ["coarse_dirt", "moss_block"], 12, 571, -1),
  F(5, -7, 0, 12, 7, 7, "spruce_planks", "hollow"), F(5, -6, 0, 5, 6, 6, "air"), F(6, -6, 0, 11, 6, 6, "air"), F(6, -6, -1, 11, 6, -1, "spruce_planks"),
  ...[[5, -7], [5, 7], [12, -7], [12, 7]].map(([a, b]) => F(a, b, 0, a, b, 7, "dark_oak_log")), F(5, -7, 3, 5, 7, 3, "dark_oak_log"), F(6, -6, 3, 11, 6, 3, "dark_oak_planks"), F(5, -7, 7, 5, 7, 7, "dark_oak_log"),
  F(6, 0, 4, 11, 0, 6, "spruce_planks"), F(8, 0, 4, 8, 0, 5, "air"), ...[8, 10].flatMap((a) => [F(a, -7, 1, a, -7, 2, "glass_pane"), F(a, 7, 1, a, 7, 2, "glass_pane"), F(a, -7, 5, a, -7, 6, "glass_pane"), F(a, 7, 5, a, 7, 6, "glass_pane")]),
  ...gable(5, -8, 12, 8, 8, "dark_oak_planks", { s: 2, cap: "dark_oak_slab", end: "spruce_planks" }), S1(5, 0, 9, "glass_pane"), S1(5, 0, 10, "glass_pane"), F(11, 5, 0, 11, 5, 12, "bricks"), S1(11, 5, 13, "campfire"),
  F(11, -6, 0, 11, 6, 0, "spruce_planks"), ...[-6, -4, -2, 0, 2, 4].map((b) => S1(11, b, 1, "skeleton_skull")), F(11, -6, 2, 11, 6, 2, "spruce_slab"),
  ...doll(7, -6, 0, "pink_wool"), ...doll(9, -6, 0, "light_blue_wool"), ...doll(7, 6, 0, "white_wool"), ...doll(10, 6, 0, "red_wool"), ...hangL(8, -3, 2, 1), ...hangL(8, 3, 2, 1),
  F(9, -5, 4, 10, -4, 4, "red_wool"), S1(10, -5, 4, "white_wool"), S1(10, -4, 4, "white_wool"), F(9, 3, 4, 10, 4, 4, "pink_wool"), S1(10, 3, 4, "white_wool"), S1(10, 4, 4, "white_wool"),
  S1(7, -2, 4, "spruce_slab"), ...doll(7, 2, 4, "purple_wool"), S1(11, -2, 4, "spruce_planks"), S1(11, -2, 5, "dark_oak_slab"), S1(6, -5, 4, 'candle ["candles"=2,"lit"=true]'), ...hangL(8, -3, 6, 1), ...hangL(9, 4, 6, 1),
  F(4, -10, 0, 12, -10, 0, "spruce_fence"), F(4, 10, 0, 12, 10, 0, "spruce_fence"), ...[-10, 10].map((b) => S1(4, b, 1, "soul_lantern")), ...deadtree(9, -9, 7, "dark_oak_log", 9),
  S1(4, -6, 0, "skeleton_skull"), S1(4, 5, 0, 'candle ["candles"=3,"lit"=true]'),
] });
/* 鏡 → 鏡の 回廊（前が 開いた 長い 広間。両わきに 枠つきの 鏡と 柱・奥の 大きな 鏡と 金の 紋・あばらの 丸天井・ろうそくの 台・赤い じゅうたん・割れた 鏡の かけら）*/
set("x_u10mirror", "u10mirror", "u10mirror", { tk: 1, box: [-1, -10, 14, 10], H: 13, env: (P) => [
  TG(-1, -10, 14, 10, "polished_deepslate"), ...[0, 2, 4, 6, 8, 10, 12, 14].map((a) => F(a, -8, -1, a, 8, -1, "quartz_block")), F(-1, -1, -1, 14, 1, -1, "red_wool"),
  F(5, -9, 0, 14, -9, 7, "dark_oak_planks"), F(5, 9, 0, 14, 9, 7, "dark_oak_planks"), ...[6, 9, 12].flatMap((a) => [F(a, -9, 1, a + 1, -9, 5, "glass"), F(a, -9, 6, a + 1, -9, 6, "chiseled_quartz_block"), F(a, 9, 1, a + 1, 9, 5, "glass"), F(a, 9, 6, a + 1, 9, 6, "chiseled_quartz_block")]),
  ...[5, 8, 11, 14].flatMap((a) => [F(a, -8, 0, a, -8, 7, "stripped_dark_oak_log"), F(a, 8, 0, a, 8, 7, "stripped_dark_oak_log")]),
  F(14, -9, 0, 14, 9, 8, "dark_oak_planks"), F(14, -3, 1, 14, 3, 7, "glass"), F(14, -4, 0, 14, -4, 8, "quartz_pillar"), F(14, 4, 0, 14, 4, 8, "quartz_pillar"), F(14, -4, 8, 14, 4, 8, "chiseled_quartz_block"), S1(14, 0, 9, "gold_block"),
  ...gable(13, -9, 14, 9, 9, "deepslate_tiles", { s: 2, cap: "deepslate_tile_slab", end: "dark_oak_planks" }), S1(13, 0, 10, "gold_block"),
  F(5, -9, 8, 14, -7, 8, "deepslate_tiles"), F(5, 7, 8, 14, 9, 8, "deepslate_tiles"), F(5, -6, 9, 12, -6, 9, "deepslate_tile_slab"), F(5, 6, 9, 12, 6, 9, "deepslate_tile_slab"),
  ...[6, 9, 12].flatMap((a) => [...up(ribs(a, -7, 7, 4, "stripped_dark_oak_log"), 7), ...hangL(a, 0, 10, 2)]),
  ...[[6, -4], [6, 4], [10, -4], [10, 4], [13, -6], [13, 6]].flatMap(([a, b]) => candleP(a, b)), F(7, -7, 0, 8, -7, 0, "spruce_slab"), F(10, 7, 0, 11, 7, 0, "spruce_slab"),
  ...scatter(5, -7, 13, 7, ["glass_pane", "white_stained_glass"], 6, 581),
] });
/* 祭りの 馬場 → 祭りの 通り（核の 屋台・走路の まわりに 屋台の 列・ちょうちんの 綱・柵）*/
set("x_u10fest", "u10fest", "u10fest", { tk: 1, box: [-1, -11, 15, 11], H: 9, env: (P) => [
  TG(-1, -11, 15, 11, "packed_mud"), ...stallS(10, -9, P, "red_wool"), ...stallS(10, 9, P, "orange_wool"), ...stallS(4, 9, P, "yellow_wool"),
  ...[0, 5, 10, 15].flatMap((a) => [F(a, -11, 0, a, -11, 4, "dark_oak_fence"), F(a, 11, 0, a, 11, 4, "dark_oak_fence")]), F(0, -11, 5, 15, -11, 5, "chain"), F(0, 11, 5, 15, 11, 5, "chain"),
  ...[2, 7, 12].flatMap((a) => [S1(a, -11, 4, 'lantern ["hanging"=true]'), S1(a, 11, 4, 'lantern ["hanging"=true]')]), F(15, -8, 0, 15, 8, 1, "hay_block"),
] });
/* 庭 → 塀の 庭（核の 花壇の まわりに 石の 塀・門・枯れた 花壇の 列・ベンチ・つるの 棚）*/
set("x_u11garden", "u11garden", "u11garden", { tk: 1, box: [-1, -10, 14, 10], H: 8, env: (P) => [
  TG(-1, -10, 14, 10, "grass_block"), F(-1, -10, 0, 14, -10, 2, "stone_bricks"), F(-1, 10, 0, 14, 10, 2, "stone_bricks"), F(14, -10, 0, 14, 10, 2, "stone_bricks"), F(14, -1, 0, 14, 1, 2, "iron_bars"),
  ...[8, 11].flatMap((a) => [F(a, -8, -1, a + 1, -2, -1, "coarse_dirt"), F(a, 2, -1, a + 1, 8, -1, "coarse_dirt"), F(a, -8, 0, a + 1, -2, 0, "wither_rose"), F(a, 2, 0, a + 1, 8, 0, "deadbush")]),
  F(7, -9, 0, 13, -9, 3, "oak_fence"), F(7, -9, 4, 13, -9, 4, "azalea_leaves"), F(1, 8, 0, 3, 8, 0, "spruce_slab"),
] });
/* 町の 角 → 灰の 町の 辻（核の 噴水と 小さな 家に 切妻の 屋根・奥に 門の ある 鐘の 塔・高い 木組みの 家と 露台・店の 日よけと 荷・街灯・石だたみと 溝）*/
set("x_u12town", "u12town", "u12town", { tk: 1, box: [-4, -12, 16, 11], H: 15, top: (P) => [...gable(2, -2, 6, 4, 5, "deepslate_tiles", { cap: "deepslate_tile_slab", end: "spruce_planks" }), S1(2, 1, 6, "glass_pane"), F(6, 3, 5, 6, 3, 8, "bricks")], env: (P) => [
  TG(-4, -12, 16, 11, "stone_bricks"), F(-4, -2, -1, 16, 2, -1, "polished_andesite"), F(-4, -3, -1, 16, -3, -1, "cobblestone"), ...scatter(-4, -12, 16, 11, ["mossy_cobblestone", "cracked_stone_bricks", "gravel"], 16, 631, -1),
  ...house(9, -12, 15, -6, 9, P, { wall: "spruce_planks", log: "dark_oak_log", roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "r" }), F(9, -12, 4, 9, -6, 4, "dark_oak_log"), F(9, -11, 6, 9, -10, 7, "glass_pane"), F(9, -8, 6, 9, -7, 7, "glass_pane"),
  F(8, -12, 3, 8, -6, 3, "red_wool"), ...[-11, -9, -7].map((b) => S1(8, b, 3, "white_wool")), S1(8, -11, 0, "barrel"), S1(8, -10, 0, "barrel"), S1(8, -8, 0, "decorated_pot"),
  ...house(9, 7, 15, 11, 7, P, { wall: "white_terracotta", log: "dark_oak_log", roof: "deepslate_tiles", cap: "deepslate_tile_slab", door: "l" }), F(8, 7, 4, 8, 11, 4, "dark_oak_planks"), F(7, 7, 5, 7, 11, 5, "dark_oak_fence"), F(8, 7, 3, 8, 11, 3, "dark_oak_log"),
  F(12, -2, 0, 16, 2, 12, "stone_bricks", "hollow"), F(12, -2, 13, 16, 2, 13, "polished_deepslate"), ...crenel(12, -2, 16, 2, 14, "stone_bricks"), S1(14, 0, 14, "soul_lantern"), F(12, 0, 6, 12, 0, 7, "iron_bars"), F(12, -1, 0, 16, 1, 2, "air"), F(12, -2, 3, 12, 2, 3, "chiseled_stone_bricks"), S1(14, 0, 10, "bell"), S1(12, 0, 9, "chiseled_stone_bricks"),
  ...slamp(-4, -9, 4), ...slamp(-4, 8, 4), ...slamp(7, -4, 4), ...slamp(7, 4, 4), S1(5, -8, 0, "flower_pot"), F(5, 6, 0, 6, 6, 0, "spruce_slab"),
] });
/* 灯の 道 → 灯の 並木道（核の 灯の 列を 奥へ 長く・道しるべ・両わきの 低い 塀）*/
set("x_u13lamp", "u13lamp", "u13lamp", { tk: 1, box: [-1, -9, 18, 9], H: 7, env: (P) => [
  TG(-1, -9, 18, 9, "deepslate_tiles"), F(-1, -2, -1, 18, 2, -1, "polished_andesite"), ...[8, 11, 14, 17].flatMap((a) => [...slamp(a, -3, 3), ...slamp(a, 3, 3)]),
  F(-1, -9, 0, 18, -9, 1, "stone_brick_wall"), F(-1, 9, 0, 18, 9, 1, "stone_brick_wall"), F(18, -2, 0, 18, 2, 2, "stone_bricks"),
] });
/* 壁と 門 → 三重の 城壁（核の 三枚の 壁の 上に 門の 渡り・両わきに 胸壁の 高い 塔と 紫の 旗・外へ のびる 崩れた 幕壁・奥に 閉じた 大門の 内壁と 天守・かがり火・がれき）*/
set("x_u14wall", "u14wall", "u14wall", { tk: 1, box: [-1, -12, 12, 12], H: 15, top: () => [S1(5, -3, 5, 'soul_lantern ["hanging"=true]'), S1(5, 3, 5, 'soul_lantern ["hanging"=true]')], env: (P) => [
  TG(-1, -12, 12, 12, "deepslate_tiles"), F(-1, -2, -1, 12, 2, -1, "polished_blackstone_bricks"), ...scatter(-1, -12, 12, 12, ["cobbled_deepslate", "gravel"], 14, 641, -1),
  ...[[-12, -10], [10, 12]].flatMap(([b0, b1]) => [F(4, b0, 0, 6, b1, 7, "deepslate_bricks"), ...crenel(4, b0, 6, b1, 8, "deepslate_bricks"), F(4, b0 === -12 ? -12 : 12, 5, 6, b0 === -12 ? -12 : 12, 8, "air")]),
  ...[[-9, -6], [6, 9]].flatMap(([b0, b1]) => { const m = b0 < 0 ? -7 : 7; return [F(4, b0, 0, 8, b1, 12, "deepslate_bricks"), F(4, b0, 0, 8, b1, 1, "polished_deepslate"), F(4, b0 - 1, 12, 9, b1 + 1, 12, "polished_deepslate"), ...crenel(4, b0 - 1, 9, b1 + 1, 13, "deepslate_bricks"), S1(6, m, 13, "soul_lantern"),
    F(4, m, 5, 4, m, 11, "purple_wool"), F(4, b0 === -9 ? -9 : 9, 4, 4, b0 === -9 ? -9 : 9, 5, "iron_bars"), F(4, b0 === -9 ? -9 : 9, 8, 4, b0 === -9 ? -9 : 9, 9, "iron_bars")]; }),
  F(4, -5, 6, 6, 5, 8, "deepslate_bricks"), F(4, -5, 9, 6, 5, 9, "polished_deepslate"), ...crenel(4, -5, 6, 5, 10, "deepslate_bricks"), F(4, -3, 6, 4, 3, 6, "polished_blackstone_bricks"),
  F(9, -12, 0, 12, 12, 9, "deepslate_bricks"), ...crenel(9, -12, 12, 12, 10, "deepslate_bricks"), F(9, -3, 0, 9, 3, 6, "polished_blackstone_bricks"), F(9, -2, 0, 9, 2, 5, "dark_oak_planks"), F(9, -2, 3, 9, 2, 3, "iron_bars"), S1(9, -1, 1, "iron_block"), S1(9, 1, 1, "iron_block"),
  F(10, -4, 10, 12, 4, 13, "deepslate_bricks"), ...crenel(10, -4, 12, 4, 14, "deepslate_bricks"), S1(11, 0, 14, "soul_lantern"), F(10, 0, 10, 10, 0, 13, "purple_wool"),
  ...[[7, -3], [7, 3]].flatMap(([a, b]) => brazier(a, b)), S1(8, -11, 0, "cobbled_deepslate"), S1(7, 11, 0, "cobbled_deepslate"), S1(8, 11, 0, "deepslate_bricks"),
] });
/* 玉座 → 玉座の 間（前が 開いた 白い 大広間: 柱の 列・あばらの 梁だけの 天井・側廊の 屋根・紫の 窓・奥の 破風と ばら窓・二つの 塔・玉座の 天蓋と 段・赤と 紫の 旗・火皿・ろうそく）*/
set("x_u14throne", "u14throne", "u14throne", { tk: 1, box: [-1, -10, 12, 10], H: 14, top: (P) => [F(7, -2, 0, 7, -2, 4, "dark_oak_fence"), F(7, 2, 0, 7, 2, 4, "dark_oak_fence"), F(5, -2, 5, 7, 2, 5, "purple_wool"), S1(6, 0, 4, 'soul_lantern ["hanging"=true]')], env: (P) => [
  TG(-1, -10, 12, 10, "polished_deepslate"), F(-1, -4, -1, 12, 4, -1, "quartz_block"), F(-1, -4, -1, 12, -4, -1, "polished_blackstone_bricks"), F(-1, 4, -1, 12, 4, -1, "polished_blackstone_bricks"), F(-1, -1, -1, 10, 1, -1, "red_wool"),
  ...[0, 3, 6, 9, 12].flatMap((a) => [F(a, -8, -1, a, -6, -1, "quartz_bricks"), F(a, 6, -1, a, 8, -1, "quartz_bricks")]),
  F(4, -9, 0, 12, -9, 7, "quartz_bricks"), F(4, 9, 0, 12, 9, 7, "quartz_bricks"), ...[5, 8].flatMap((a) => [F(a, -9, 2, a + 1, -9, 5, "purple_stained_glass"), F(a, 9, 2, a + 1, 9, 5, "purple_stained_glass")]), F(4, -9, 6, 4, -9, 7, "air"), S1(4, 9, 7, "air"),
  ...[4, 7, 10].flatMap((a) => [F(a, -10, 0, a, -10, 6, "polished_blackstone_bricks"), S1(a, -10, 7, "polished_blackstone_brick_slab"), F(a, 10, 0, a, 10, 6, "polished_blackstone_bricks"), S1(a, 10, 7, "polished_blackstone_brick_slab")]),
  F(4, -9, 8, 12, -7, 8, "deepslate_tiles"), F(4, 7, 8, 12, 9, 8, "deepslate_tiles"),
  ...[4, 7, 10].flatMap((a) => [F(a, -6, 0, a, -6, 8, "quartz_pillar"), F(a, 6, 0, a, 6, 8, "quartz_pillar")]), F(4, -6, 9, 12, -6, 9, "quartz_bricks"), F(4, 6, 9, 12, 6, 9, "quartz_bricks"),
  ...[5, 8, 11].map((a) => F(a, -6, 10, a, 6, 10, "dark_oak_log")), ...[5, 8].flatMap((a) => [...hangL(a, -3, 9, 2), ...hangL(a, 3, 9, 2)]),
  F(11, -8, 0, 12, 8, 9, "quartz_bricks"), ...gable(11, -8, 12, 8, 10, "quartz_bricks", { s: 2, cap: "chiseled_quartz_block" }), F(11, -2, 4, 11, 2, 8, "purple_stained_glass"), S1(11, 0, 10, "purple_stained_glass"),
  ...[[-10, -8], [8, 10]].flatMap(([b0, b1]) => [F(10, b0, 0, 12, b1, 12, "quartz_bricks"), F(10, b0, 12, 12, b1, 12, "polished_blackstone_bricks"), ...crenel(10, b0, 12, b1, 13, "quartz_bricks"), S1(11, (b0 + b1) >> 1, 13, "soul_lantern"), S1(10, (b0 + b1) >> 1, 9, "purple_stained_glass")]),
  F(8, -4, 0, 10, 4, 0, "polished_blackstone_bricks"), F(9, -3, 1, 10, 3, 1, "polished_blackstone_bricks"), F(10, -2, 2, 10, 2, 2, "polished_blackstone_bricks"), ...[-4, 4].map((b) => F(10, b, 2, 10, b, 8, "red_wool")),
  ...[4, 7].flatMap((a) => [F(a, -8, 3, a, -8, 7, "purple_wool"), F(a, 8, 3, a, 8, 7, "purple_wool")]),
  ...[[5, -5], [5, 5]].flatMap(([a, b]) => brazier(a, b)), ...[[9, -6], [9, 6]].flatMap(([a, b]) => candleP(a, b, "chiseled_quartz_block")), ...scatter(4, -8, 10, -7, ["quartz_slab", "chiseled_quartz_block"], 3, 601), ...scatter(4, 7, 10, 8, ["quartz_slab"], 3, 602),
] });
/* 封の 部屋 → 封の 蔵（核の 部屋の 戸を 開け、天井を 格子に。奥に 前の 開いた 厚い 石の 蔵: 上げた 落とし格子・鎖・封じた 黒い 石板・箱と 樽の 棚・両わきの 檻・前の 二つの 塔・段の 屋根・青い 灯）*/
set("x_u14vault", "u14vault", "u14vault", { tk: 1, box: [-1, -9, 11, 9], H: 13, top: (P) => [F(0, -2, 0, 0, 2, 1, "air"), F(0, -2, 2, 0, 2, 2, "iron_bars"), F(0, -3, 3, 0, 3, 3, "polished_blackstone_bricks"), F(1, -2, 3, 3, 2, 3, "iron_bars")], env: (P) => [
  TG(-1, -9, 11, 9, "deepslate_tiles"), F(-1, -2, -1, 11, 2, -1, "polished_deepslate"), ...scatter(-1, -9, 11, 9, ["cobbled_deepslate", "gravel"], 10, 611, -1),
  F(5, -7, 0, 11, 7, 7, "deepslate_bricks", "hollow"), F(6, -6, 0, 10, 6, 6, "air"), F(6, -6, -1, 10, 6, -1, "polished_deepslate"),
  F(5, -5, 0, 5, 5, 5, "air"), F(5, -6, 6, 5, 6, 6, "polished_blackstone_bricks"), F(5, -4, 5, 5, 4, 5, "iron_bars"), F(5, -8, 8, 11, 8, 8, "polished_deepslate"),
  ...gable(6, -7, 11, 7, 9, "deepslate_tiles", { s: 2, cap: "deepslate_tile_slab", end: "deepslate_bricks" }),
  ...[[-9, -7], [7, 9]].flatMap(([b0, b1]) => { const m = (b0 + b1) >> 1; return [F(4, b0, 0, 6, b1, 10, "deepslate_bricks"), F(4, b0, 10, 6, b1, 10, "polished_deepslate"), ...crenel(4, b0, 6, b1, 11, "deepslate_bricks"), S1(5, m, 11, "soul_lantern"), F(4, m, 3, 4, m, 4, "iron_bars"), F(4, m, 7, 4, m, 8, "iron_bars")]; }),
  ...[7, 10].flatMap((a) => [F(a, -8, 0, a, -8, 5, "polished_deepslate"), F(a, 8, 0, a, 8, 5, "polished_deepslate")]), F(5, -6, 1, 5, -6, 4, "purple_wool"), F(5, 6, 1, 5, 6, 4, "purple_wool"), ...brazier(6, -3), ...brazier(6, 3), S1(11, 0, 9, "crying_obsidian"),
  F(10, -1, 0, 10, 1, 0, "polished_blackstone"), F(10, -1, 1, 10, 1, 3, "crying_obsidian"), S1(10, 0, 4, "chiseled_deepslate"), F(10, -5, 0, 10, -2, 0, "chest"), F(10, -5, 1, 10, -2, 1, "barrel"), F(10, 2, 0, 10, 5, 0, "barrel"), F(10, 2, 1, 10, 5, 1, "chest"),
  F(7, -4, 0, 9, -4, 3, "iron_bars"), F(7, 4, 0, 9, 4, 3, "iron_bars"), S1(8, -6, 0, "bone_block"), S1(8, 6, 0, "skeleton_skull"),
  ...[[8, -2], [8, 2], [7, 0]].map(([a, b]) => F(a, b, 4, a, b, 6, "chain")), ...hangL(9, -4, 6, 2), ...hangL(9, 4, 6, 2), ...slamp(4, -5, 3), ...slamp(4, 5, 3),
] });
/* 本の 階段 → 頁の 大階段（両わきの 本棚の 壁と 紫の 柱・二階の 回廊と 手すり・奥へ 続く 二つめの 段と 踊り場・あばらの 丸天井・奥の 紫の 窓・書見台・散った 頁・青い 灯）*/
set("x_u15stair", "u15stair", "u15stair", { tk: 1, box: [-1, -10, 12, 10], H: 13, env: (P) => [
  TG(-1, -10, 12, 10, "polished_deepslate"), F(-1, -2, -1, 3, 2, -1, "purpur_block"),
  ...[[-10, -9], [9, 10]].flatMap(([b0, b1]) => [F(4, b0, 0, 12, b1, 6, "bookshelf"), F(6, b0, 7, 12, b1, 8, "bookshelf"), F(8, b0, 9, 12, b1, 10, "bookshelf"), F(4, b0, 7, 5, b1, 7, "purpur_slab"), F(6, b0, 9, 7, b1, 9, "purpur_slab")]),
  ...[4, 7, 10].flatMap((a) => [F(a, -8, 0, a, -8, 11, "purpur_pillar"), S1(a, -8, 12, "end_rod"), F(a, 8, 0, a, 8, 11, "purpur_pillar"), S1(a, 8, 12, "end_rod")]),
  F(4, -8, 5, 12, -6, 5, "dark_oak_planks"), F(4, 6, 5, 12, 8, 5, "dark_oak_planks"), F(4, -6, 6, 12, -6, 6, "dark_oak_fence"), F(4, 6, 6, 12, 6, 6, "dark_oak_fence"), ...[4, 8, 12].flatMap((a) => [F(a, -6, 0, a, -6, 4, "dark_oak_log"), F(a, 6, 0, a, 6, 4, "dark_oak_log")]),
  S1(6, -7, 6, "lectern"), S1(10, 7, 6, "lectern"), S1(9, -7, 6, "bookshelf"), S1(5, 7, 6, "bookshelf"), S1(5, 7, 7, 'candle ["candles"=2,"lit"=true]'), S1(9, -7, 7, 'candle ["candles"=3,"lit"=true]'),
  F(8, -2, 0, 8, 2, 3, "polished_deepslate"), F(9, -2, 0, 9, 2, 4, "polished_deepslate"), F(10, -5, 0, 12, 5, 5, "polished_deepslate"), F(12, -10, 6, 12, 10, 11, "bookshelf"), F(12, -2, 7, 12, 2, 10, "purple_stained_glass"), F(12, -3, 6, 12, 3, 6, "purpur_block"),
  ...[5, 8, 11].flatMap((a) => up(ribs(a, -8, 8, 5, "purpur_block"), 6)), F(5, 0, 11, 11, 0, 11, "purpur_block"), ...[5, 8, 11].flatMap((a) => hangL(a, 0, 10, 1)),
  F(8, -10, 11, 12, -9, 11, "deepslate_tiles"), F(8, 9, 11, 12, 10, 11, "deepslate_tiles"),
  S1(5, -5, 0, "lectern"), S1(5, 5, 0, "lectern"), F(6, -7, 0, 7, -7, 1, "bookshelf"), S1(6, 7, 0, "bookshelf"),
  ...scatter(-1, -8, 12, 8, ["white_carpet"], 14, 621), ...up(scatter(4, -8, 12, -7, ["white_carpet"], 4, 622), 6), ...up(scatter(4, 7, 12, 8, ["white_carpet"], 4, 623), 6),
] });
/* 牧場の 囲い → 小さな 牧場（核の 囲いの 奥に 納屋・干し草・水おけ・柵の 外の 道）*/
set("x_u15ranch", "u15ranch", "u15ranch", { tk: 1, box: [-1, -10, 14, 10], H: 10, env: (P) => [
  TG(-1, -10, 14, 10, "grass_block"), ...house(7, -9, 13, -1, 5, P, { wall: "spruce_planks", log: "spruce_log", roof: "dark_oak_planks", door: "f" }), F(7, -6, 0, 7, -4, 2, "air"),
  S1(9, -7, 0, "hay_block"), S1(10, -7, 0, "hay_block"), S1(9, -7, 1, "hay_block"), F(8, 3, 0, 13, 9, 0, "oak_fence"), F(9, 4, 0, 12, 8, 0, "air"), F(10, 6, 0, 11, 6, 0, WCAUL),
  ...tree(13, -9, 6, P), ...tree(1, 9, 5, P),
] });
/* 鍛冶場 → 灰の 鍛冶場（柱と 梁の 開いた 作業小屋・一部 落ちた 切妻の 屋根・屋根を 抜ける 太い 煙突と 火床・金床・砥石・焼き入れの 水・武具の 棚・炭と 鉄の 山・薪・吊り灯）*/
set("x_u15forge", "u15forge", "u15forge", { tk: 1, box: [-1, -10, 12, 10], H: 15, env: (P) => [
  TG(-1, -10, 12, 10, "cobblestone"), F(-1, -2, -1, 12, 2, -1, "gravel"), ...scatter(-1, -10, 12, 10, ["gravel", "coal_ore", "andesite"], 14, 641, -1),
  ...[5, 8, 11].flatMap((a) => [F(a, -9, 0, a, -9, 5, "dark_oak_log"), F(a, 9, 0, a, 9, 5, "dark_oak_log"), F(a, -9, 6, a, 9, 6, "dark_oak_log")]), F(5, -9, 0, 11, -9, 1, "bricks"), F(5, 9, 0, 11, 9, 1, "bricks"), F(12, -9, 0, 12, 9, 5, "bricks"),
  ...gable(5, -10, 12, 10, 7, "dark_oak_planks", { s: 2, cap: "dark_oak_slab", end: "spruce_planks", endA: [12] }), F(6, -7, 7, 8, -4, 9, "air"), F(7, -7, 7, 7, -4, 8, "dark_oak_log"),
  F(9, -8, 0, 11, -6, 2, "bricks"), S1(9, -7, 0, "magma"), S1(9, -7, 1, "campfire"), F(10, -8, 3, 11, -6, 13, "bricks"), S1(10, -7, 14, "campfire"), S1(11, -7, 14, "bricks"),
  F(11, -2, 0, 11, 2, 0, "blast_furnace"), S1(11, 0, 1, "smoker"), S1(7, -4, 0, "anvil"), S1(7, 4, 0, "grindstone"), S1(8, 3, 0, WCAUL), S1(10, 4, 0, "smithing_table"),
  F(10, 7, 0, 11, 8, 0, "coal_block"), S1(10, 7, 1, "coal_block"), S1(6, 8, 0, "raw_iron_block"), S1(6, 7, 0, "iron_block"), ...[6, 8, 10].map((a) => F(a, 9, 2, a, 9, 3, "iron_bars")), ...[7, 9].map((a) => S1(a, 9, 2, "spruce_fence")),
  F(8, -2, 4, 8, -2, 5, "chain"), ...hangL(5, 0, 5, 0, "lantern"), ...hangL(8, 2, 5, 0, "lantern"), ...hangL(11, -3, 5, 0, "lantern"),
  F(4, 8, 0, 4, 10, 0, "spruce_log"), F(4, 9, 1, 4, 10, 1, "spruce_log"), S1(4, -8, 0, "barrel"), S1(4, -7, 0, "barrel"), S1(4, -8, 1, "barrel"),
] });
