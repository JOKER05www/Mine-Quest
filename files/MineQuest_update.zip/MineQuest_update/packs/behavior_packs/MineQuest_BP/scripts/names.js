// 第106版: 町・海辺・トラブルの 人の 名前。見た目（スキン）は 同じでも 名前は 1人ずつ ちがう
import { world } from "@minecraft/server";
const F = ["ミレイ", "アンナ", "リーナ", "ソフィ", "エレン", "カリン", "ミオ", "サラ", "ノノ", "リリカ", "ハルカ", "マリエ", "フィーネ", "ロゼ", "アイリ", "ルチア", "メイ", "ティナ", "エマリ", "ナナ", "シエル", "リコ", "ミーナ", "クレア", "ヒナ", "アリス", "レナ", "コハル", "イリス", "ベル", "ミント", "ラナ", "サクラ", "ユリア", "カノン", "シズカ", "トワ", "ネネ", "エリナ", "マオ", "リン", "フラン", "アオイ", "セラ", "チカ", "ジュリ", "ヨシノ", "アヤ", "モモ", "レイラ", "スズ", "ノア", "エル", "ミユ", "キララ"];
const M = ["トマス", "カイ", "ベン", "オスカー", "ヨハン", "マルコ", "ハンス", "ニコ", "レオ", "ダン", "グスタフ", "ペトロ", "ユリウス", "タクト", "ソウタ", "ケイ", "リオン", "バルト", "ガイル", "ノエ", "ロイ", "サム", "フリッツ", "エド", "ティム", "ゴロウ", "タツ", "ヴィル", "アラン", "ドミ", "ルーク", "マティ", "セイジ", "コウ", "ハル", "ジャン", "ボリス", "ミロ"];
/* 見た目の 名前から 肩書きだけ 残す（「シスター・ノエル」→「シスター・」、「図書館のシオリ」→「図書館の」）*/
export function titleOf(label) {
  const s = String(label || "").replace(/§./g, "").replace(/（.*?）/g, "");
  const a = s.lastIndexOf("・"); if (a > 0) return s.slice(0, a + 1);
  const b = s.lastIndexOf("の"); if (b > 0 && b < s.length - 1) return s.slice(0, b + 1);
  const m = s.match(/^(受付|酔っぱらい|自称勇者|食い逃げの|スリの|チャラ男|騎士団長|衛兵|兵長|看守|老人|執事|女王|弟子|手下|子どもの|商人|剣士|僧侶|重戦士|弓使い|魔法使い|料理長|錬金術師|船乗り|狩人|巫女見習い|図書館長|牧場主|吟遊詩人|占い師|漁師|花屋|本屋の|修道女|鍛冶見習い|王女|侍女|協会長|大食い|情報屋|旅芸人|学者|踊り子|宿屋の)/);
  return m ? m[1] : "";
}
const USED = new Map();   /* 名前 → 使った tick（しばらく 同じ 名前を 出さない）*/
export function personName(label, type, near) {
  const L = type === "m" ? M : F, t = titleOf(label);
  let taken = new Set();
  try { for (const e of near || []) taken.add(String(e.nameTag || "").replace(/§./g, "").replace(/\n.*$/, "")); } catch {}
  const now = Date.now(); for (const [k, v] of USED) if (now - v > 30 * 60e3) USED.delete(k);
  for (let k = 0; k < 40; k++) { const n = t + L[Math.floor(Math.random() * L.length)]; if (!taken.has(n) && !USED.has(n)) { USED.set(n, now); return n; } }
  const n = t + L[Math.floor(Math.random() * L.length)] + (Math.floor(Math.random() * 90) + 10); USED.set(n, now); return n;
}
export function nearNpcs(at, r = 160) { try { return world.getDimension("overworld").getEntities({ type: "mrpg:npc", location: at, maxDistance: r }); } catch { return []; } }
