// 第127版: 前の「何でも 打てる 会話」（入力欄・話題の 決まり文句・しゃがんで 誰とでも 話す）は やめた
// 名前の ある 人は npctalk.js（人ごとの 性格・話題・仲よく なる 手順）。名前の ない 町の 人は、ここの 地方の ひとことだけ
import { world } from "@minecraft/server";
import { ok, barNote } from "./ui.js";
import { regionIdx } from "./worldmap.js";
import { REGL } from "./npcbase.js";

const pick = (L) => L[Math.floor(Math.random() * L.length)];
export const CHATX = { story: null };   /* townlife.js が 入れる（物語の 進み）*/
/* 仲よし（好感度）: プレイヤーごと（60人まで）。贈り物・遊び・お出かけ（social.js・townlife.js）が 使う */
export function relOf(p, nm) { try { const v = JSON.parse(p.getDynamicProperty("mrpg:rel") || "{}"); return v[nm] || { a: 0, t: 0, n: 0 }; } catch { return { a: 0, t: 0, n: 0 }; } }
export function setRel(p, nm, r) {
  try { const v = JSON.parse(p.getDynamicProperty("mrpg:rel") || "{}"); r.t = Date.now(); v[nm] = r; const ks = Object.keys(v); if (ks.length > 60) { ks.sort((a, b) => (v[a].t || 0) - (v[b].t || 0)); delete v[ks[0]]; } p.setDynamicProperty("mrpg:rel", JSON.stringify(v)); } catch {}
}
/* その 場所の 地方（0〜10）*/
export function regOfLoc(loc) { try { const s = world.getDefaultSpawnLocation(); const i = regionIdx(loc.x - s.x, loc.z - s.z); return i >= 0 && i < REGL.length ? i : 0; } catch { return 0; } }
const SLOT = () => { let t = 6000; try { t = world.getTimeOfDay(); } catch {} return t >= 23000 || t < 3000 ? 0 : t < 11000 ? 1 : t < 13500 ? 2 : 3; };
const GREET = ["おはよう、旅の 人", "やあ、こんにちは", "夕方だね。宿は 決まった？", "こんばんは。夜道は 気を つけて"];
export function greetLine(p, nm) { return GREET[SLOT()]; }
/* 町の 人の ひとこと（地方の 暮らし）*/
export function rumorLine(p, nm = "") { let r = 0; try { r = regOfLoc(p.location); } catch {} return pick(REGL[r] || REGL[0]); }
/* 話す: 名前の ない 人は 地方の ひとことを 一つ（画面は 出さない）*/
export function chatWith(p, npc, npcName, role, opener) {
  try {
    const l = rumorLine(p, npcName), t1 = `§e${npcName}§f「${opener || greetLine(p, npcName)}」`, t2 = `§e${npcName}§f「${l}」`;
    p.sendMessage(t1); p.sendMessage(t2); barNote(p).setActionBar(t2);
    if (npc && ok(npc)) { npc.setProperty("mrpg:act", 4); npc.teleport(npc.location, { facingLocation: p.getHeadLocation() }); }
  } catch {}
}
