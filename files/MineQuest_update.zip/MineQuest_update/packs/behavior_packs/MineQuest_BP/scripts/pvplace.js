/* 第126版(PV): 場所の 使い分け（オーナー 11/10）の 小道具。章ファイル（bk_b01〜b16・bk_u01〜u07）と 古い 話（ep_r0〜r10）が 使う
   ・plazaOf(町) … 町の 広場（町の 記録に plaza が あれば それ。なければ 町の まん中 ＝ 広場の 中）
   ・gateOut(町, 向き) … 町の 門の 外（城壁の 外 50〜54マス。道しるべの 小さな セットを 1回 置く）
   ・festSet … 祭りの 飾り（灯りの 柱・旗・屋台 2つ）。facAdd の 形「festplaza」を 広場に 置く。すべて keep（町の 建物・道を 上書きしない）。地面が 舞台と 同じ 高さの 所だけ
   ・crowd … 祭りの 町の 人（歩いて 来る。場面の 終わりで 舞台と いっしょに 消える） */
import { world } from "@minecraft/server";
import { TOWNS, getTown, townPos, castleSpot, castleInfo, groundY } from "./structures.js";
import { spotOf } from "./storyplace.js";
import { facAdd, FAC_OPS, __fac } from "./epfac.js";
import { stageOf, arrive } from "./stagecore.js";

const { F, S1 } = FAC_OPS;
const tc = (tid) => { const t = TOWNS.find((u) => u.id === tid); if (!t) return null; const q = getTown(tid); return q && q.built ? { x: q.x, y: q.y, z: q.z, t } : { ...townPos(t), t }; };
export function plazaOf(tid, nm) {
  const c = tc(tid); if (!c) return null; const s = spotOf(tid, "plaza");
  const q = s || { x: c.x, y: c.y, z: c.z };
  return { x: Math.floor(q.x), y: Number.isFinite(q.y) ? Math.floor(q.y) : null, z: Math.floor(q.z), nm: nm || `${c.t.name}の 広場`, tid };
}
/* 門の 外: 町の まん中から dir（ラジアン）の 向きに k マス（城壁の 外）*/
export function gateOut(tid, dir = -Math.PI / 2, nm = "", k = 52) {
  const c = tc(tid); if (!c) return null;
  return { x: Math.floor(c.x + Math.cos(dir) * k), y: null, z: Math.floor(c.z + Math.sin(dir) * k), nm: nm || `${c.t.name}の 門の 外`, tid, fx: c.x, fz: c.z };
}
/* 城の 門の 外（城下の 南の 大門 z+56 の 外。城の 中庭（北）と 反対の 向き）*/
export function castleOut(r, nm = "", k = 80) {
  let c = null; try { c = castleInfo(r) || castleSpot(r); } catch {} if (!c) return null;
  let a = Math.PI / 2; try { if (c.m && Math.hypot(c.m.x - c.x, c.m.z - c.z) > 3) a = Math.atan2(-(c.m.z - c.z), -(c.m.x - c.x)); } catch {}
  return { x: Math.floor(c.x + Math.cos(a) * k), y: null, z: Math.floor(c.z + Math.sin(a) * k), nm: nm || "城門の 外", fx: c.x, fz: c.z };
}
/* 城下の 建物（宿・食堂・大聖堂）の 戸口の 前 */
export function castleBld(r, kinds, nm) {
  for (const k of [].concat(kinds)) { const q = spotOf(`c${r}`, k); if (!q) continue; let x = q.x + 0.5, z = q.z + 0.5;
    if (Number.isFinite(q.fx)) { const dx = x - q.fx, dz = z - q.fz, n = Math.hypot(dx, dz) || 1; x += (dx / n) * 2; z += (dz / n) * 2; }
    return { x: Math.floor(x), y: q.y, z: Math.floor(z), nm, ...(Number.isFinite(q.fx) ? { fx: q.fx, fz: q.fz } : {}) }; }
  return null;
}

/* ---- 祭りの 飾り（facAdd の 形。部品ごとに 地面を 見て keep で 置く）---- */
const POST = (lamp) => [F(0, 0, 0, 0, 0, 1, "oak_fence", "keep"), S1(0, 0, 2, lamp)];
const FLAG = (col) => [F(0, 0, 0, 0, 0, 2, "oak_fence", "keep"), S1(0, 0, 3, `${col}_wool`)];
const STALL = (col) => [F(0, -1, 0, 0, -1, 1, "oak_fence", "keep"), F(0, 1, 0, 0, 1, 1, "oak_fence", "keep"), F(0, -1, 2, 0, 1, 2, `${col}_wool`, "keep"), S1(0, 0, 0, "barrel"), F(1, -1, 0, 1, 1, 0, "hay_block", "keep")];
const PIECES = [
  [-6, -6, POST("lantern")], [-6, 6, POST("lantern")], [6, -6, POST("lantern")], [6, 6, POST("lantern")], [0, -8, POST("lantern")], [0, 8, POST("lantern")],
  [-3, -7, FLAG("red")], [3, -7, FLAG("yellow")], [-3, 7, FLAG("orange")], [3, 7, FLAG("lime")],
  [7, -3, STALL("red")], [7, 3, STALL("white")],
];
facAdd("festplaza", { D: [0], box: [-7, -8, 8, 8], H: 4, look: [0, 0, 1], small: true, build: () => PIECES.flatMap(([a, b, ops]) => ops.map((o) => [o[0], o[1] + a, o[2] + b, o[3], o[4] + a, o[5] + b, o[6], o[7], o[8] || "keep"])) });
const once = (k) => { try { if (world.getDynamicProperty(k)) return false; world.setDynamicProperty(k, 1); return true; } catch { return false; } };
/* c: 広場の 点。f: 向き（舞台の 向き）。祭りの 名ごとに 1回 */
export function festSet(p, key, c, y0, f = null) {
  if (!p || !c || !once(`mrpg:epdeco:fest_${key}`)) return false;
  const dim = p.dimension, S = stageOf(p), fa = f || (S && S.f) || { x: 0, z: 1 }, card = (Math.abs(fa.x) >= Math.abs(fa.z) ? { x: Math.sign(fa.x) || 1, z: 0 } : { x: 0, z: Math.sign(fa.z) || 1 });
  let n = 0;
  for (const [a, b, ops] of PIECES) {
    const q = __fac.W({ x: Math.floor(c.x), z: Math.floor(c.z) }, card, a, b); let g = null; try { g = groundY(dim, q.x, q.z, Math.floor(y0) + 3); } catch {}
    if (typeof g !== "number" || Math.abs(g - y0) > 1) continue;   /* 屋根の 上・段の 下には 置かない */
    for (const c2 of __fac.cmds(ops.map((o) => [o[0], o[1], o[2], o[3], o[4], o[5], o[6], o[7], o[8] || "keep"]), { o: { x: q.x, y: g, z: q.z }, f: card })) { try { dim.runCommand(c2); n++; } catch {} }
  }
  return n > 0;
}
/* 祭りの 町の 人（3人。歩いて 来る）。K.npcNear の 人なので 舞台が 終わると 消える */
export function crowd(K, p, n = 3, nm = "§7町の 人") {
  const L = []; const jobs = [3, 6, 5, 23];   /* 第126版(fix): 8（マスター）を 町の 人（23）に */
  for (let i = 0; i < n; i++) { const e = K.npcNear(p, `${nm}${["", " ", "  ", "   "][i] || ""}`, jobs[i % jobs.length]); if (e) { L.push(e); try { K.act(e, i % 2 ? "cheer" : "clap"); } catch {} } }
  return L;
}
/* 門の 外の 道（城壁の 外で 戦う ときの セット）: 門へ 続く 土の 道・灯りの 柱 2本・道しるべ。q: 門の 外の 点、to: 町の まん中。1回だけ */
facAdd("gateroad", { D: [0], box: [-2, -2, 10, 2], H: 3, look: [4, 0, 1], small: true, build: () => [F(-2, -1, -1, 10, 1, -1, "dirt_path"), ...POST("lantern").map((o) => [o[0], o[1] + 2, o[2] - 2, o[3], o[4] + 2, o[5] - 2, o[6], o[7], o[8] || "keep"]), ...POST("lantern").map((o) => [o[0], o[1] + 2, o[2] + 2, o[3], o[4] + 2, o[5] + 2, o[6], o[7], o[8] || "keep"]), F(-1, 2, 0, -1, 2, 0, "oak_fence", "keep"), S1(-1, 2, 1, "oak_planks")] });
export function gateSet(p, key, q, to, y0) {
  if (!p || !q || !to || !once(`mrpg:epdeco:gate_${key}`)) return false;
  const dim = p.dimension, dx = to.x - q.x, dz = to.z - q.z, card = Math.abs(dx) >= Math.abs(dz) ? { x: Math.sign(dx) || 1, z: 0 } : { x: 0, z: Math.sign(dz) || 1 };
  let n = 0; const o = { x: Math.floor(q.x), z: Math.floor(q.z) };
  for (let a = -2; a <= 10; a++) for (let b = -1; b <= 1; b++) { const w = __fac.W(o, card, a, b); let g = null; try { g = groundY(dim, w.x, w.z, Math.floor(y0) + 3); } catch {} if (typeof g !== "number" || Math.abs(g - y0) > 2) continue; for (const bl of ["grass_block", "dirt", "sand", "snow", "podzol"]) { try { dim.runCommand(`fill ${w.x} ${g - 1} ${w.z} ${w.x} ${g - 1} ${w.z} dirt_path replace ${bl}`); n++; } catch {} } }
  for (const [a, b, ops] of [[2, -2, POST("lantern")], [2, 2, POST("lantern")], [-1, 2, [F(0, 0, 0, 0, 0, 0, "oak_fence", "keep"), S1(0, 0, 1, "oak_planks")]]]) {
    const w = __fac.W(o, card, a, b); let g = null; try { g = groundY(dim, w.x, w.z, Math.floor(y0) + 3); } catch {} if (typeof g !== "number" || Math.abs(g - y0) > 2) continue;
    for (const c2 of __fac.cmds(ops.map((x) => [x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8] || "keep"]), { o: { x: w.x, y: g, z: w.z }, f: card })) { try { dim.runCommand(c2); n++; } catch {} }
  }
  return n > 0;
}
/* 町の 中の 焚き火（keep。地面が 同じ 高さの 所だけ）。返す 値は 火の 点（置けなくても 点は 返す）*/
export function townFire(p, key, q, y0) {
  const x = Math.floor(q.x), z = Math.floor(q.z); let y = Math.floor(y0);
  try { const g = groundY(p.dimension, x, z, y + 3); if (typeof g === "number" && Math.abs(g - y) <= 1) { y = g; if (once(`mrpg:epdeco:fire_${key}`)) p.dimension.runCommand(`setblock ${x} ${y} ${z} campfire keep`); } } catch {}
  return { x: x + 0.5, y, z: z + 0.5 };
}
/* 井戸端（村の 外れの 古井戸の まわり。空の 樽・水桶・荷車の 板・柵）: 何も ない 野原に しない */
facAdd("wellyard", { D: [7, 9, 6], box: [-1, -4, 3, 4], H: 3, look: [1, 0, 1], small: true, build: () => [
  F(0, -4, 0, 0, -2, 0, "oak_fence"), F(0, 2, 0, 0, 4, 0, "oak_fence"), S1(1, -3, 0, "barrel"), S1(1, -2, 0, "barrel"), S1(2, -3, 0, "cauldron"), S1(1, 3, 0, "hay_block"),
  F(2, 2, 0, 3, 3, 0, "spruce_slab"), S1(3, -4, 0, "composter"), S1(0, -4, 1, "lantern"), S1(0, 4, 1, "lantern") ] });
/* 場所を 移る（暗転 → 移る）。y が ない 点は 地面の 高さを 先に さがす（埋まる・宙に 浮く を ふせぐ）*/
export function grounded(p, q) {
  if (!q || Number.isFinite(q.y)) return q; let y = null;
  try { const dim = p.dimension, y0 = Math.floor(p.location.y); for (const from of [y0, y0 + 24]) { const g = groundY(dim, Math.floor(q.x), Math.floor(q.z), from); if (typeof g === "number") { y = g; break; } } } catch {}

  return y === null ? q : { ...q, y };
}
export const moveG = (K, p, q, nm, drop = [], look = null, R) => K.moveTo(p, grounded(p, q), nm, drop, look, R);
/* 歩いて 来た 人が あなたや ほかの 人と 重なったら、横へ 一歩 よける（1.4 マス あける）*/
export async function unstack(K, p, e, others = []) {
  try { if (!e || !e.isValid || !e.isValid()) return; await arrive(e); await K.wait(1); const l = e.location, who = [p.location, ...others.filter((o) => o && o !== e && (!o.isValid || o.isValid())).map((o) => o.location)];
    const bad = (q) => who.some((w) => Math.hypot(w.x - q.x, w.z - q.z) < 1.4); if (!bad(l)) return;
    for (const r of [1.6, 2.2]) for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2, q = { x: l.x + Math.cos(a) * r, y: l.y, z: l.z + Math.sin(a) * r }; if (!bad(q)) { await K.go(e, q, 6); return; } } } catch {}
}
