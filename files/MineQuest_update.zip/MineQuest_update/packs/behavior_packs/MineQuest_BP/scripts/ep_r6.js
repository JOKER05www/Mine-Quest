/* 第125版: 第7地方 マリノア の 5話（さんごの 町 コラリア・海神の 城）
   1話 港町（網元の 舟小屋）→ 2話 海神祭の 支度（祭りの 浜。夜、セオが 手帳の 頁を 破る）→ 3話 今の 段「港の 桟橋 → 夜の 浜 → 取りかえせ」
   → 4話 嵐の 前（舟小屋。ナギサが 嵐の 海へ）→ 5話 今の 段「沈んだ 神殿」「マリンとの 勝負」→ 5話 つづき 海神祭
   書き方は ep_r0.js の 頭の 説明の とおり */
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, farOf } from "./storyplace.js";
import { bldOf } from "./storyplace.js";
import { plazaOf, crowd, townFire } from "./pvplace.js";
import { groundY } from "./structures.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok } from "./ui.js";
import { fac, facMark } from "./epfac.js";
const turnTo = (K, e, q) => { if (K.turn) return K.turn(e, q); if (!ok(e) || !q) return; try { e.teleport(e.location, { facingLocation: { x: q.x, y: e.location.y + 1.5, z: q.z } }); e.setDynamicProperty("mrpg:away", true); } catch {} };   /* K.turn が まだ ない ときの 代わり */

/* ---------- 場所 ---------- */
const MEMO = new Map();
const tOut = (k, turn, nm) => () => { if (MEMO.has(k)) return MEMO.get(k); const o = townOut("t15", turn, nm); const v = o ? { x: o.x, z: o.z, nm: o.nm } : null; if (v) MEMO.set(k, v); return v; };
const HUT0 = tOut("hut", 0.9, "網元の 舟小屋"), HUT = () => farOf("r6hut", "t15", "コラリアの 網元の 舟着き場", 80, 220) || HUT0();   /* 第127版(fac2): 町の 外れ 56 → 離れた 入り江（大きな 舟小屋と 船だまり）*/
const FESTOLD = tOut("fst", -1.3, "祭りの 浜");
/* 第126版(PV): 海神祭は 町の 中の 港の 浜辺（町の 外れの 浜では しない）*/
const FEST = () => { const q = bldOf("t15", ["harbor"], "コラリアの 港の 浜辺") || plazaOf("t15", "コラリアの 広場"); return q ? { x: q.x, z: q.z, nm: q.nm } : FESTOLD(); };
const near = (f, dx, dz) => () => { const q = f(); return q ? { x: q.x + dx, y: q.y, z: q.z + dz } : null; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("r6zaza", { nm: "ザザ", role: "網元", gobi: "だっぺ", skin: "m6_vito", town: "t15", from: "r6e1", at: near(HUT, 3, -2),
  pre: ["{smile}網の 目は 細かく、心は 大きく だっぺ！"],
  after: [
    [(s) => !!s.heroBack, ["{smile,tears}……おめえさんら、二人で 帰って きたっぺか。", "{smile,☆}……おかえりだっぺ。今日は 潮が しょっぱいっぺ。"]],
    [(s) => !!s.ending && !st(s).cord6, ["{smile}マリンが、あんたに 会いたがってたっぺ。祭りの 浜に いるっぺよ。"]],
    [(s) => !!s.ending, ["{smile}今年の 海神祭は、ナギサが 百 数えて、マリンが 笛を 吹くっぺ。", "{sad}……祭りの 灯りを 一つ、あの 娘っこの 分も ともしたっぺ。"]],
    [(s) => !!s.heroDead, ["{sad}海が 黒い。魚も 浅瀬に 逃げて きたっぺ。", "{angry}だども 網元は 舟を 出すっぺ。港の みんなが 食えなきゃ、祭りも 何も ねえっぺ。"]],
    [(s) => !!st(s).fest6, ["{smile,♪}祭り、最高だったっぺ！ 来年も 来るっぺよ！", "{closed}……あの 二人の おっかあにも、見せて やりたかったっぺ。"]],
    [(s) => !!st(s).storm6, ["{sad}ナギサの やつ、あの 手で 舟を 出そうと したっぺ。……おっかあ そっくりの 頑固もんだっぺ。"]],
    [() => true, ["{smile}海神祭の 支度、手伝って くれて ありがとさんだっぺ！"]],
  ] });
castAdd("r6marin", { nm: "マリン", role: "潜水士", col: "§3", gobi: "", skin: "marin", town: "t15", from: "r6e1", at: near(FEST, -3, 2),
  pre: ["{smile}……潮の 匂い。今日は 深く 潜れそう。"],
  after: [
    [(s) => !!s.ending && !!st(s).cord6, ["{smile}姉さんと 二人で、紐の 続きを 編んでるの。……一目ずつ、ゆっくり。", "{closed}編み上がったら、海の 向こうへ 渡しに 行く。"]],
    [(s) => !!s.ending, ["{smile}海神の 城の マスター、少しは 板に ついて きたかな。", "{closed}……あの子の 分まで、潜るよ。ずっと。"]],
    [(s) => !!s.heroDead, ["{angry}海の 底まで 影が 来てる。……でも、潜る。潜って、みんなの 舟を 守る。"]],
    [(s) => !!st(s).fest6, ["{smile,☆}貝笛、ちゃんと 吹けてた？ ……姉さんの 音には、まだ 遠いけど。"]],
    [() => true, ["{closed}姉さんの 手が 治るまで、わたしが 潜る。……決めたんだ。"]],
  ] });
castAdd("r6nagisa", { nm: "ナギサ", role: "", col: "§6", gobi: "", skin: "nagisa", town: "t15", from: "r6e4", at: near(FEST, 3, 3),
  pre: ["{closed}……一、二、三。"],
  after: [
    [(s) => !!s.ending, ["{smile}手の やけど、もう ほとんど 治ったよ。今年は 自分で 網を 結べた。", "{closed}……潮は 引いても、必ず 満ちる。あなたにも、そう 言いたいな。"]],
    [(s) => !!s.heroDead, ["{sad}……潮が、満ちない。こんな 海、初めて。", "{closed}でも 数えるよ。百 数えたら、きっと 何か 変わる。……一、二、三。"]],
    [(s) => !!st(s).fest6, ["{smile,♪}九十八、九十九、百。……ね、ちゃんと 満ちたでしょ。"]],
    [() => true, ["{sad}この 手じゃ、まだ 潜れない。……だから、マリンを 信じて 数えるの。"]],
  ] });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, y: typeof s.epSpot.y === "number" ? s.epSpot.y : p.location.y, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const SEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
/* 歩いて 去る（道が ふさがって 歩けない 人は 暗転で 下げる）*/
const out = async (K, p, es, run = false) => { const L = [].concat(es).filter(ok), fade = [], go = []; for (const e of L) { const q = K.away(e, p, 10); if (!q || Math.hypot(q.x - e.location.x, q.z - e.location.z) < 4) fade.push(e); else go.push(K.leave(e, p, 10, run)); } await Promise.all(go); if (fade.length) await K.bye(p, ...fade); };
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
/* 祭りの 貝の 灯り（ワールドに 1回。舞台の 外側に 低く）*/
function lamps(p, c, y0, key, lit) {
  const k = `mrpg:epdeco:${key}`; try { if (world.getDynamicProperty(k)) return; world.setDynamicProperty(k, 1); } catch { return; }
  const dim = p.dimension, cx = Math.floor(c.x), cz = Math.floor(c.z);
  for (const [x, z] of [[-12, -6], [12, -6], [-12, 6], [12, 6], [0, -13], [0, 13]]) {
    try { const y = groundY(dim, cx + x, cz + z, y0 + 6); if (typeof y === "number" && Math.abs(y - y0) <= 4) { dim.runCommand(`setblock ${cx + x} ${y} ${cz + z} oak_fence keep`); dim.runCommand(`setblock ${cx + x} ${y + 1} ${cz + z} ${lit ? "sea_lantern" : "oak_fence"} keep`); } } catch {}
  }
}

/* ---------- 1話 港町 ---------- */
const E1 = { id: "r6e1", pv: 127, n: 1, t: "港町", at: 0, ord: 0, place: HUT, fac: "r6hut",
  hint: "§fさんごの 町 §eコラリアの 網元の 舟小屋§f へ 行こう §7（マリンが 待って いる。「！」の 目印の そばで 立ち止まろう）",
  syn: "コラリアの 舟小屋で、網元の ザザと 会った。ザザは マリンと 姉の ナギサの 親がわり。十年前の 嵐の 夜、二人の 母は「海の 向こうの 石に、おっとうが いる」と 言って 舟を 出し、帰らなかった。父の ことは、だれも 知らない。それから 毎年、海神祭の 最後に ナギサが 貝笛を 吹いて、海に 祈って いる。今年は 海が 荒れて、網が 毎晩 破られて いた。",
  set: { met6: 1 },
  async run(p, d, K) {
    const FQ = fac(K, p, "r6hut", "boathut", 6, Y(K, p));   /* 第125版(fac): 網元の 舟小屋（干した 網・舟）*/
    await K.open(p, "さんごの 町 コラリア", "day");
    K.sound(p, "random.splash", 1.3, 0.3);
    if (FQ) await K.at(p, FQ, 14, 7, 1.4);
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{smile,☆,jump}海だーっ！ 潮の 匂い！ さんごの 色の 屋根！"], ["{smile}……海。風が しょっぱくて、気持ちいい。"], ["{smile}……海。いい 風。"], ["{smile,☆}まあ、海です！ さんご色の 屋根が きれい。"]), FQ || K.fwd(p, 9));
    const eZ = K.cast(p, "r6zaza"); K.act(eZ, "hold"); K.hold(eZ, "net");
    await K.csay(p, "r6zaza", ["{angry,怒}こらーっ、網の 結び目が ゆるいっぺ！ 魚に 笑われるっぺよ！", "{shock,!}……おっと。見ねえ 顔だっぺ。旅の もんか？"]);
    const eM = K.cast(p, "r6marin"); K.act(eM, "raise");
    await K.csay(p, "r6marin", ["{smile,up}来て くれたんだ！ ……ザザおじさん、この 人たちが 水晶の 洞くつで 助けて くれたの。"], eZ);
    K.act(eM, 0);
    await K.csay(p, "r6zaza", ["{shock,!,up}なにぃ！ マリンの 恩人だっぺか！", "{smile,☆,jump}おらは ザザ！ コラリアの 網元だっぺ！ ほれ、ほれ、干物 食うっぺ！"]);
    K.hold(eZ, "basket"); await K.give(eZ, eH, "basket"); K.hold(eZ, "net");
    K.act(eZ, 0);
    await K.hsay(p, K.V(["{sweat,汗,up}わわっ、干物 いっぱい！ ……あ、ありがとう！"], ["{smile,汗,up}……ふふ、ありがとう ございます。"], ["{sweat,汗}……多い。でも、もらう。"], ["{sweat,汗,up}こ、こんなに たくさん……ありがとう ございます。"]));
    await K.csay(p, "r6marin", ["{smile}姉さんは 今、沖で 潮を 読んでる。夕方に 港の 桟橋に もどるから、それまで 町を 案内するね。"], eH);
    /* 破れた 網 */
    K.act(eZ, "point");
    const q = facMark("r6hut", "net", p.location) || K.fwd(p, 4, 2.4);
    await K.at(p, q, 14, 3, 0.5);
    await K.narr(p, ["§7小屋の 前に、大きな 網が 干して ある。", "§7まん中が、何か 大きな 爪で 引きさかれた ように 破れて いた。"], q);
    await K.csay(p, "r6zaza", ["{sad}……近ごろ、海が おかしいっぺ。毎晩、網が 破られるっぺ。", "{closed}沖の 魚が、何かに おびえて 浅瀬へ 逃げて くるっぺ。……こんな 海は、十年 ぶりだっぺ。"], eH);
    K.act(eZ, 0);
    await K.hsay(p, K.V(["{?}十年 ぶり？ 十年前にも、何か あったの？"], ["{?}……十年前にも？"], ["{?}……十年前。何が。"], ["{?}十年前にも、何か あったのですか？"]));
    await K.up(p, eZ, 12);
    await K.csay(p, "r6zaza", ["{sad,…,up}……十年前の 嵐の 夜、マリンと ナギサの おっかあが、一人で 舟を 出したっぺ。", "{closed}『海の 向こうの 石に、おっとうが いる』……そう 言って、それきりだっぺ。おらの、いちばんの 友だちだったっぺ。"]);
    K.act(eM, "hold");
    await K.csay(p, "r6marin", ["{sad,up}……毎年 海神祭の 最後に、姉さんが 海神の 貝笛を 吹くの。", "{smile}『かあさん。今年も 港は 元気だよ』って。……わたしも、いつか 吹きたいんだ。"]);
    K.act(eM, 0);
    await K.csay(p, "r6zaza", ["{smile,☆,up}祭りは 三日後だっぺ！ 支度が 山ほど あるっぺ。手伝って くれたら、うんまい 魚、たらふく 食わせるっぺ！"]);
    await K.hsay(p, K.V(["{smile,♪,jump}やる やる！ お祭り だいすき！"], ["{smile}ええ、喜んで。"], ["{smile}……やる。魚、楽しみ。"], ["{smile}はい、喜んで お手伝い します。"]));
    K.pay(p, E1, 300, [["mei_mari", 1]]);
    await K.end(p, { leave: [eZ, eM], card: "§7→ コラリアの 祭りの 浜で 海神祭の 支度を 手伝おう（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 2話 海神祭の 支度（夜、セオが 手帳の 頁を 破る）---------- */
const E2 = { id: "r6e2", n: 2, t: "海神祭の 支度", at: 0, ord: 1, place: FEST,
  hint: "§fコラリアの §e港の 浜辺§f で 海神祭の 支度を 手伝おう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "祭りの 浜に 貝の 灯りを 立て、ザザから 海神の 歌と 貝笛の 言い伝えを 聞いた。「海の 底で 吹けば、沈んだ 神殿の 番人が 目を 覚ます」。その夜、焚き火の そばで 眠った あなたたちの 横で、だれかが 背を 向けて、手帳の 頁を 一枚 破った。朝、そこには だれも いなかった。",
  set: { prep6: 1, met6: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), prep6: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    lamps(p, c, y0, "r6fest0", false);
    const FF = townFire(p, "r6fest", { x: c.x + 4, z: c.z + 3 }, y0);   /* 第126版(PV): 港の 浜辺の 焚き火（町の 中。keep）*/
    await K.open(p, "コラリアの 港の 浜辺（海神祭の 支度）", "day");
    K.sound(p, "note.harp", 0.6);
    const eH = K.hero(p), eZ = K.cast(p, "r6zaza"), eM = K.cast(p, "r6marin");
    K.act(eZ, "point"); K.hold(eZ, "chochin"); K.hold(eM, "lantern"); K.hold(eH, "box");
    await K.csay(p, "r6zaza", ["{smile,♪}灯りの 柱は、浜に 六本だっぺ！ 貝殻の 飾りを 忘れるでねえっぺ！"]);
    K.act(eZ, 0);
    K.act(eH, "raise"); K.act(eM, "raise");
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:bubble_column_up_particle", 6, 0.4, 0.2); await K.up(p, g, 10); }
    await K.hsay(p, K.V(["{smile,☆,jump}相棒、波で 遊んでる！ ……あっ、貝殻 くわえて きた！"], ["{smile,♪}……ふふ。相棒が 貝殻を 拾って きて くれたわ。"], ["{smile}……相棒、貝殻 拾って きた。えらい。"], ["{smile,♪}まあ、相棒さんが 貝殻を 拾って きて くれました。"]));
    K.act(eH, 0); K.act(eM, 0); K.rmCine(g);
    K.cmd(p, "camera @s fade time 0.4 0.6 0.5 color 20 30 60"); await K.wait(12);
    await K.narr(p, ["§7あなたたちは 日が かたむくまで、貝の 灯りを 立てて 回った。", "§7ザザが、古い 舟歌を 口ずさんで いる。"], { x: c.x - 10, y: y0, z: c.z });
    await K.csay(p, "r6zaza", ["{closed}♪ うみの かみさま ねむる とこ　かいの ふえで おこしゃんせ……", "{smile}……海神の 歌だっぺ。ひいじいさんの ころから 歌って るっぺ。"]);
    K.act(eM, "show"); K.hold(eM, "flute");
    await K.csay(p, "r6marin", ["{smile}海神の 貝笛には、言い伝えが あるの。", "{closed,up}『海の 底で 吹けば、沈んだ 神殿の 番人が 目を 覚ます。番人が 認めた 者に、海の 誓いを 託す』……"], eH);
    K.act(eM, 0);
    await K.hsay(p, K.V(["{shock,!,up}沈んだ 神殿！？ ……見て みたい！"], ["{smile}……沈んだ 神殿。きれいなん でしょうね。"], ["{?}……沈んだ 神殿。行った 人は？"], ["{?}沈んだ 神殿……本当に あるのですか？"]));
    await K.up(p, eM, 12);
    await K.csay(p, "r6marin", ["{sad,up}……かあさんは『海の 向こうの 石に、おっとうが いる』って 舟を 出して、嵐に のまれたの。おっとうの 顔は、わたし 知らない。", "{closed,up}姉さんは 二度と 神殿の 話を しない。でも、わたしは……いつか、行きたい。"]);
    await K.csay(p, "r6zaza", ["{sad}……マリン。", "{smile,up}その 話は、祭りが 済んでからに するっぺ。今夜は、焚き火で 魚だっぺ！"], eM);
    /* 夜 */
    K.cmd(p, "camera @s fade time 0.5 1.2 0.8 color 0 0 10"); await K.wait(24);
    K.ambient(p, "night", { x: c.x, y: y0, z: c.z });
    K.act(eH, "down"); K.act(eM, "down"); K.act(eZ, "down"); for (const e of [eH, eM, eZ]) K.hold(e);
    await K.wide(p, 20);
    await K.narr(p, ["§7夜。焚き火が ぱちぱちと はぜて いる。", "§7歌い つかれた みんなは、灯りの 柱の 下で 寝息を たてて いた。"], FF);
    const eS = SEO(K, p); K.act(eS, "hold"); K.hold(eS, "notebook");
    await K.low(p, eS, 16);
    await K.narr(p, ["§7だれかが、浜を 歩いて きた。", "§7焚き火から 少し はなれて、背を 向けて すわる。"], eS);
    K.sound(p, "item.book.page_turn", 1);
    await K.up(p, eS, 18);
    await K.say(p, "セオ", ["{closed,…}…………これで、いい。"]);
    K.sound(p, "item.book.page_turn", 1.2); await K.wait(6);
    if (ok(eS)) K.burst(p.dimension, eS.location, "minecraft:white_smoke_particle", 3, 0.3, 1.2);
    await K.narr(p, ["§7紙を 破る 音。", "§7破った 頁を 小さく たたみ、上着の 内に しまう。"], eS);
    const g2 = K.palEnt(p); if (g2) { K.re(g2, null, "?"); await K.up(p, g2, 12); }
    if (ok(eS)) { K.re(eS, "shock", "!"); await K.up(p, eS, 12); }
    await K.say(p, "セオ", ["{smile,汗}……起きて いたのかい。", "{closed,up}しーっ。……今の ことは、ないしょに して くれるかい。"]);
    await K.say(p, "セオ", ["{sad,…,up}……ごめん。"]);
    K.act(eS, 0); K.rmCine(g2);
    await out(K, p, eS, false);
    /* 朝 */
    K.cmd(p, "camera @s fade time 0.6 1.0 0.8 color 255 240 220"); await K.wait(22);
    K.act(eH, 0); K.act(eM, 0); K.act(eZ, 0);
    await K.hsay(p, K.V(["{closed,?}ふあぁ……。なんか、夢で セオさんを 見た 気が する……。"], ["{?}……おはよう。夢に、セオさんが 出て きた 気が するわ。"], ["{?}……夢。セオが いた 気が する。"], ["{?}おはよう ございます……夢に、セオさんが いらした ような……。"]));
    await K.csay(p, "r6marin", ["{?}セオ……？ 学者さんの？ ……ここには、だれも 来て ないよ。"], eH);
    await K.at(p, { x: c.x, y: y0, z: c.z }, 14, 2.6, 0.3);
    await K.narr(p, ["§7焚き火の 灰の そばに、細い 紙の 切れはしが 一つ、残って いた。", "§7破れた ふちだけ。何も 書かれて いない。"]);
    await K.csay(p, "r6zaza", ["{smile,☆}さあ、夕方には ナギサが 帰って くるっぺ！ 桟橋で 迎えて やるっぺ！"]);
    K.pay(p, E2, 400, [["gift_kami", 1]]);
    await K.end(p, { leave: [eZ, eM], card: "§7→ 夕方、§eコラリアの 港の 桟橋§7へ（右上の 案内。ナギサが もどる）", kind: "day" });
    return true;
  } };

/* ---------- 4話 嵐の 前（貝笛を 取りかえした あと。舟小屋）---------- */
const E4 = { id: "r6e4", pv: 127, n: 4, t: "嵐の 前", snd: "item.book.page_turn", at: 1, ord: 0, place: HUT, fac: "r6hut",
  hint: "§fコラリアの §e網元の 舟小屋§f へ 行こう §7（嵐が 来る。深い 海へ 潜る 前に。「！」の 目印の そばで 立ち止まろう）",
  syn: "嵐の 前の 舟小屋で、手に やけどを 負った ナギサが 一人で 舟を 出そうと して いた。ザザが 止め、嵐に 狂った 海の モンスターを みんなで 追い払った。ナギサは「あの 人、笛を 取る ときだけ 目を そらした」と つぶやき、母の 形見の 髪紐を マリンの ゴーグルに 結んだ。「潜るのは、あなたの 番」。",
  set: { storm6: 1, met6: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), storm6: 1 }; },
  async run(p, d, K) {
    const FQ = fac(K, p, "r6hut", "boathut", 6, Y(K, p));
    await K.open(p, "嵐の 前の 舟小屋", "ash");
    K.sound(p, "ambient.weather.thunder", 0.7); K.shake(p, 0.15, 0.4);
    if (FQ) await K.at(p, FQ, 12, 6, 1.4);
    const eH = K.hero(p), eN = K.cast(p, "r6nagisa");
    K.act(eN, "hold");
    await K.low(p, eN, 14);
    await K.narr(p, ["§7黒い 雲が、沖から せり上がって くる。", "§7やけどの 手で、だれかが 舟を 押して いる。"], eN);
    await K.hsay(p, K.V(["{shock,!,up}ナギサさん！？ その 手で 何 してるの！？"], ["{shock,!,up}……ナギサさん！？ だめよ、その 手で！"], ["{shock,!,up}……ナギサ。何を してる。"], ["{shock,!,up}ナ、ナギサさん！？ その お手で 何を……！"]));
    await K.csay(p, "r6nagisa", ["{angry,up}……マリンが 今夜 潜るの。大潮は 今夜で 終わり。嵐が 来ても、待てないって。", "{sad}わたしが 舟を 出して、上で 潮を 読む。……見送る だけなんて、できない。"], eH);
    const eZ = K.cast(p, "r6zaza"); K.act(eZ, "guard");
    await K.csay(p, "r6zaza", ["{rage,怒,up}ばかこくでねえっぺ！ その 手で 櫂が 握れるわけ ねえっぺ！"], eN);
    await K.csay(p, "r6nagisa", ["{cry,tears,up}……わかってる！ わかってるよ、ザザおじさん！", "{cry,up}でも、かあさんが 舟を 出した 夜も、わたしは 桟橋で 見送った だけだった……！"]);
    await K.up(p, eZ, 12);
    await K.csay(p, "r6zaza", ["{sad,…}……ナギサ。"]);
    /* 嵐に 狂った 海の モンスター */
    K.sound(p, "mob.guardian.ambient", 0.7); K.sound(p, "random.splash", 1, 0.6); K.shake(p, 0.5, 0.6); K.flash(p, true);
    const q = K.fwd(p, 7, 2);
    const w1 = K.monEnt(p, q, K.wildSp("aqua"), "");
    K.burst(p.dimension, q, "minecraft:water_splash_particle", 14, 1.4, 0.3);
    await K.at(p, q, 14, 4, 1);
    const eM = K.cast(p, "r6marin"); K.act(eM, "run", false);
    await K.csay(p, "r6marin", ["{angry,!,up}姉さん！ 下がって！ 嵐で 海の 子たちが 狂ってる！"]);
    K.act(eM, "guard"); K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,!,up}マリンさん、いっしょに！ 舟は こわさせない！"], ["{angry,up}……マリンさん、いっしょに 止めましょう。"], ["{angry,up}……止める。マリン、右を。"], ["{angry,up}マリンさん、ごいっしょに！"]));
    if (!K.flag(p, "r6e4w")) {
      K.rmCine(w1);
      const r = await K.battle(p, K.team(["aqua", "beast"], 48, 3, 12), { name: "嵐に 狂った 海の モンスター", arena: "嵐の 前", theme: "beach", speaker: "海の モンスター", guests: K.team(["aqua"], 46, 1).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "……ザザァ……ン……", low: "……シオ……ガ……ヒク……" } });
      if (r !== "win") return lose(K, p, "§3潜水士 マリン", K.PJ("marin", 9), "マリン", "{sweat,汗}……一度、小屋の 中へ！ 嵐が 少し 弱まったら、もう 一度！");
      K.setFlag(p, "r6e4w");
    } else K.rmCine(w1);
    const eN2 = K.cast(p, "r6nagisa", true), eM2 = K.cast(p, "r6marin", true), eZ2 = K.cast(p, "r6zaza", true);
    K.act(eN2, "kneel");
    await K.narr(p, ["§7海の モンスターは 波の 下へ 帰って いった。", "§7……毎晩 網を 裂いて いたのは、嵐の 前に 狂った この 子たち だった。", "§7雨の 音だけが、舟小屋の 屋根を たたいて いる。"], eN2);
    await K.csay(p, "r6nagisa", ["{closed}……ねえ。夜の 浜の、あの 人。", "{sad,up}笛を 取る ときだけ、目を そらしたの。……あれは、何かを なくした 人の 目だった。"]);
    await K.hsay(p, K.V(["{?}……ヴァルカが？"], ["{?}……ヴァルカさんが？"], ["{?}……ヴァルカが。"], ["{?}ヴァルカが……ですか？"]));
    await K.csay(p, "r6nagisa", ["{closed,up}わからない。でも、ゆるさない ことと、わからない ことは、ちがうから。"]);
    K.act(eN2, "hold"); K.hold(eN2, "rope");
    if (ok(eN2) && ok(eM2)) { const l = eM2.location; await K.go(eN2, { x: l.x + 0.9, y: l.y, z: l.z + 0.4 }, 12); }
    await K.two(p, eN2, eM2, 12);
    await K.narr(p, ["§7ナギサは やけどの 残る 指で、ゆっくり、ゆっくり、自分の 髪紐を ほどいた。", "§7そして マリンの ゴーグルに、不器用に 結んだ。"], eM2);
    await K.give(eN2, eM2, "rope"); K.hold(eM2, "goggles");
    await K.csay(p, "r6nagisa", ["{closed,up}……かあさんの 形見の 紐。『大事な 人が 編んだ』とだけ、かあさんは 言ってた。三つ目ごとに 一つ 返す、ふしぎな 編み方。", "{smile,tears,up}……潜るのは、あなたの 番。わたしは 上で、百 数えて 待ってる。"]);
    await K.csay(p, "r6marin", ["{cry,smile,up}……うん。姉さんの 百が 終わる 前に、帰って くる。約束。"]);
    K.act(eN2, 0);
    await K.up(p, eZ2, 12);
    await K.csay(p, "r6zaza", ["{sad,up}……雨だっぺ。網元は 雨の 日に 舟は 出さねえ。……今日だけは 出すっぺ。", "{smile,up}網元の 舟は、嵐でも ひっくり返らねえっぺ！"]);
    K.pay(p, E4, 600, [["c_herbs", 2]]);
    await K.end(p, { leave: [eZ2, eM2], bye: [eN2], card: "§7→ 嵐の 前に、ゴーグルを 持って §b深い 海§7で 海神の 貝笛を 吹こう（大潮の うちに。右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 5話 つづき 海神祭（マリンに 勝った あと）---------- */
const E6 = { id: "r6e6", n: 5, t: "海神祭", at: 3, ord: 0, place: FEST,
  hint: "§fコラリアの §e港の 浜辺§f で §6海神祭§f が 開かれる §7（右上の 案内。そのあと ネクロスへ。「！」の 目印の そばで 立ち止まろう）",
  syn: "マリンが 地方マスターと なって 石板を 託した あと、コラリアで 海神祭が 開かれた。ナギサが 浜で 百 数え、マリンが 初めて 海神の 貝笛を 吹いた。沖の 海が 青く 光り、ザザは「おっかあの 吹き方、そっくりだ」と 泣き笑いした。港は 少し にぎやかに なった。",
  set: { fest6: 1, met6: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest6: 1 }; },
  fx: { xp: ["t15", 160], fest: "t15" },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    lamps(p, c, y0, "r6fest0", false); lamps(p, c, y0, "r6fest1", true);
    const cw = crowd(K, p, 3);
    await K.open(p, "コラリアの 港の 浜辺（海神祭）", "fest");
    K.sound(p, "firework.blast", 0.6); K.sound(p, "note.harp", 0.8);
    const eH = K.hero(p), eZ = K.cast(p, "r6zaza"), eN = K.cast(p, "r6nagisa"); K.hold(eZ, "chochin");
    K.act(eZ, "raise");
    await K.csay(p, "r6zaza", ["{smile,☆,jump,up}来た 来た！ 今年の 主役の 恩人だっぺ！ 魚、たらふく 食うっぺ！"]);
    await K.hsay(p, K.V(["{smile,☆,up}わあ……！ 貝の 灯りが、ぜんぶ ついてる！"], ["{smile,up}……きれい。灯りが、海まで 続いてる。"], ["{smile,up}……灯り、ぜんぶ ついた。"], ["{smile,☆,up}まあ……貝の 灯りが、ぜんぶ ともって います。"]));
    K.act(eZ, 0);
    K.act(eN, "point");
    await K.csay(p, "r6nagisa", ["{smile}……九十七、九十八、九十九。", "{smile,☆,up}百。……満ちたよ。お祭り、始めよう。"]);
    K.act(eN, 0);
    const eM = K.cast(p, "r6marin"); K.act(eM, "hold"); K.hold(eM, "flute");
    await K.low(p, eM, 14);
    await K.csay(p, "r6marin", ["{closed}……かあさん。", "{smile,tears,up}今年は、わたしが 吹くよ。……港は、元気だよ。"]);
    /* 貝笛 */
    K.sound(p, "note.flute", 0.8); await K.wait(8); K.sound(p, "note.flute", 1.0); await K.wait(8); K.sound(p, "note.flute", 1.2);
    const sea = K.fwd(p, 14, 0);
    for (let i = 0; i < 4; i++) { K.burst(p.dimension, sea, i % 2 ? "minecraft:bubble_column_up_particle" : "minecraft:villager_happy", 12, 2 + i * 1.5, 0.2); await K.wait(5); }
    await K.at(p, sea, 20, 8, 3);
    await K.narr(p, ["§7笛の 音が 波に しみこんで いく。", "§7沖の 海が、ゆっくりと 青く 光った。……まるで、だれかが 答えた ように。"]);
    await K.csay(p, "r6nagisa", ["{smile,tears,up}……ね。ちゃんと、届いた。"], eM);
    turnTo(K, eZ, sea); await K.up(p, eZ, 12);   /* 海の 方を 向いて 言う */
    await K.csay(p, "r6zaza", ["{cry,tears,up}……ナギサの 音とも ちがう。おっかあの 吹き方、そっくりだっぺ。", "{smile,tears}……マリン、聞いて 覚えてたんだっぺか。"]);
    turnTo(K, eH, sea);
    await K.hsay(p, K.V(["{smile,tears,up}……うん。わたしにも、ちゃんと 聞こえたよ。", "{smile}ナギサさんが、火の 中から 守った 笛の 音だね。"], ["{smile,tears,up}……ええ。わたしにも、聞こえたわ。", "{smile}ナギサさんが、火の 中から 守った 音ね。"], ["{smile,up}……聞こえた。", "{closed}ナギサが 火の 中から 守った 音。"], ["{smile,tears,up}……はい。わたしにも、聞こえました。", "{smile}ナギサさんが、火の 中から お守りに なった 音ですね。"]));
    await K.csay(p, "r6nagisa", ["{smile,up}……この 手で よかった、って 今は 思うよ。", "{closed}手は 治る。笛の 音は、なくしたら 二度と 戻らないもの。"], eH);
    /* 踊り */
    for (const e of [eM, eZ, eN, eH]) K.act(e, 9);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z }); K.sound(p, "note.pling", 0.8);
    const g = K.palEnt(p); if (g) K.burst(p.dimension, g.location, "minecraft:note_particle", 5, 0.5, 1);
    await K.wide(p, 26);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z });
    for (const e of [eM, eZ, eN, eH]) K.act(e, 0);
    K.rmCine(g);
    K.act(eM, "hold"); K.hold(eM, "pouch");
    await K.csay(p, "r6marin", ["{smile}これ、海神祭の 貝の お守り。……深い 所でも、迷わない ように。", "{smile,up}ありがとう。あなたたちが いたから、わたし、潜れた。"]);
    await K.give(eM, eH, "pouch");
    const got = K.pay(p, E6, 900, [["mei_mari", 2], ["gift_shiori", 1]]);
    if (got.length) K.big(p, "§b§l貝の お守り", `§e${got.join("・")}`);
    K.act(eM, 0);
    await K.csay(p, "r6zaza", ["{smile,up}いって らっしゃいだっぺ！ 港の 灯りは、いつでも ともして 待ってるっぺ！"]);
    await K.hsay(p, K.V(["{smile,tears,up}いって きます！ ナギサさん、マリンさん、ザザさん！"], ["{smile,tears,up}……いって きます。みんな、元気でね。"], ["{smile,up}……いって きます。"], ["{smile,tears,up}いって まいります。皆さま、お元気で。"]));
    await K.end(p, { bye: [eM, eZ, eN, ...cw], card: "§f― 第7章 海神の 貝笛 おわり ―\n§7→ 次は ネクロス冥府領へ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(6, [E1, E2, E4, E6], { steps: { 0: [3, "夜の 浜（貝笛を 取りかえせ）"], 1: [5, "沈んだ 神殿（深い 海で 貝笛）"], 2: [5, "マリンとの 勝負"] } });
