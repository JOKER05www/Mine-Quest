// 第76版: 追加ストーリーの 場所（第125版: 名前は「常世編」）（ほかの 仕組みが この 中では 町・遺跡・ふつうの 野生を 出さない ための 目印）
// 第77版: 配布マップには 灰都の 街（1792×1792）が 焼きこまれて いる（RU.city）。ないワールドでは 今までの 簡易版
import { world, system } from "@minecraft/server";
export const RU = { x: 100000, z: 100000, r: 1100, city: true, pre: null, dy: 112 };   /* pre: 街が はじめから ある（配布マップ）か。ない ときは citybuild が その場で 建てる */
export const RU_X = 100000, RU_Z = 100000, RU_R = 1100;
export const CITY_R = 896;   /* 街の 広さ（中心から ±896） */
export function setRuCity(v) { RU.pre = !!v; try { world.setDynamicProperty("mrpg:ruCity", v ? 1 : 0); } catch {} }
const readCity = () => { try { const v = world.getDynamicProperty("mrpg:ruCity"); if (typeof v === "number") RU.pre = v === 1; } catch {} };
readCity(); system.run(readCity);
export const inRuins = (loc) => !!loc && Math.abs(loc.x - RU.x) < RU.r && Math.abs(loc.z - RU.z) < RU.r;
export const RU_GATE = { on: false };   /* 追加ストーリーの パックが 入って いる とき true（mq:ext tokoyo か ruins を 受けとる） */
export const RU_INN = { tp: null };   /* 滅びた 世界で 負けた ときの もどり先（ruins.js が 入れる） */
export const RU_HOOK = { cheatGo: null, enter: null };   /* 第125版: enter(p, first) 閻魔の神殿の 奥の 石段から 常世へ */   /* 第85版: チートブックから 滅びた 世界へ すぐ 行く（追加ストーリーの パックが ある とき） */
/* 第125版: 追加パックが ない 人への 案内（魔神編で エンマが 道を 開いた あと・エンディングの 直後に 1回）*/
export const TK_PACK = "MineQuest_Story_Tokoyo.mcpack";
export const TK_GUIDE = ["§5§l続きは 追加ストーリーパック『常世編』で 遊べる", "", "§f常世の 十魔将を 倒して、とらわれた 魂を 取り戻す 物語は、追加パックに 入って います。", "",
  "§e§l入れ方", `§f1. ダウンロードページから §b${TK_PACK}§f を ダウンロードして 開く（マイクラに 読みこまれる）`, "§f2. ワールドの 編集 → ビヘイビアパック → §d「マインクエスト 追加ストーリー 常世編」§f を 有効に する（本パックと いっしょに）", "§f3. ワールドに 入りなおす", "",
  "§7いまの セーブは そのまま 使える。入れた あとは、§5閻魔の神殿§7 の 前で ガイドブックを 使うと 常世へ 行ける。"];
