/* 第126版 裏3「鍔の音」（ヴォルカ・はがねの 村 クロガネ）— 作業 UA
   MQ26 = 裏3 と 裏4 の 16話（段の 中で 1話ずつ。場所が かわる たびに 右上の 案内で 次の 場所へ。mqOver は bk_u04.js）
   機神の 型は 3-6（00 §17 の「裏6」は 誤り）。闘魔の 腕輪の 型も 同じ 棚に（00 §17）*/
import { bkAdd, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, fac, facMark, facState } from "./epfac.js";
import { ok } from "./ui.js";
import { UA } from "./bk_u01.js";
import { musashiJoinMon } from "./majin.js";
const { F, S1 } = FAC_OPS;

/* ムサシの 家の 工房（前が 開いた 作業場・炉・金床・刻みの 柱・奥の 開かずの 部屋（鉄の 格子戸）・部屋の 中の 棚）*/
facAdd("u_koubou", { D: [10, 12, 9], box: [-1, -4, 8, 4], H: 5, look: [4, 0, 1], marks: { pillar: [3, -2, 2], door: [5, 2, 1], saya: [7, 3, 0], shelf: [7, 1, 1], anvil: [3, 0, 0] }, build: () => [
  F(0, -4, -1, 8, 4, -1, "stone_bricks"), F(8, -4, 0, 8, 4, 4, "polished_blackstone_bricks"), F(1, -4, 0, 7, -4, 3, "polished_blackstone_bricks"), F(1, 4, 0, 7, 4, 3, "spruce_planks"),
  F(6, -3, 0, 7, -3, 1, "blast_furnace"), S1(7, -2, 0, "magma"), S1(3, 0, 0, "anvil"), F(3, -2, 0, 3, -2, 4, "stripped_spruce_log"),
  F(5, 1, 0, 5, 3, 3, "spruce_planks"), F(5, 2, 0, 5, 2, 1, "iron_bars"), S1(7, 1, 1, "chiseled_bookshelf"), F(1, -4, 4, 8, 4, 4, "dark_oak_slab"), S1(2, 3, 3, "lantern"),
], st: { 1: () => [F(5, 2, 0, 5, 2, 1, "air")] } });

castAdd("u_kyouth", { nm: "ゴウタ", role: "クロガネの 若い衆", gobi: "", skin: "m6_vulk", town: "t42", at: () => { const q = UA.bld("t42", ["forge"], "")(); return q ? { x: q.x + 2, z: q.z - 2 } : null; },
  hide: (s) => !bkHas(s, "u03e3"),
  after: [[(s) => bkHas(s, "u07e7"), ["{smile}末っ子の やつ、王さまに 体 貸したんだって？ ……あいつらしいや。"]], [() => true, ["{sweat}末っ子に 負けた。……鍔を 背に 回した まま だぜ？ ずるいだろ。"]]] });
castAdd("u_kinn", { nm: "ハガネ", role: "宿の おかみ", gobi: "", skin: "tsubaki", town: "t42", at: () => { const q = UA.bld("t42", ["inn"], "")(); return q ? { x: q.x + 2, z: q.z } : null; },
  hide: (s) => !bkHas(s, "u03e8"),
  after: [[() => true, ["{smile}末っ子は 小さい ころから、寝る 前に 槌の 数を 数えて たよ。……今も 変わらないね。"]]] });

export const KP = {
  entry: UA.out("kentry", "t42", 0.0, "クロガネの 入口"),
  street: UA.bld("t42", ["forge", "shop", "armor"], "クロガネの 通り"),
  yard: UA.far("u_kyard", "t42", 0.8, "クロガネの 闘技の 庭", 80, 240),   /* 第127版(fac2): 町の 外れ 56 → 離れた 鍛錬場 */
  koubou: UA.out("koubou", "t42", -0.8, "ムサシの 家の 工房"),
  inn: UA.bld("t42", ["inn"], "クロガネの 宿"),
};
export const koubou = (K, p) => fac(K, p, "u_koubou", "u_koubou", 3, UA.Y(K, p));
export const sayaAt = (K, p) => facMark("u_koubou", "saya", p.location);
const hammers = (K, p) => { K.sound(p, "random.anvil_use", 0.35); K.sound(p, "random.anvil_land", 0.15); };

bkAdd("u03", [
  { id: "u03e1", t: "槌の 音の 村", place: KP.entry, battles: 0,
    hint: "§fヴォルカの §eはがねの 村 クロガネ§f の 入口へ 行こう",
    syn: "槌の 音の 村、クロガネ。村に 入った とたん、ムサシの 肩の 力が 抜けた。",
    async run(p, d, K) {
      fac(K, p, "u_kpost", "waypost", 3, UA.Y(K, p));
      await K.open(p, "はがねの 村 クロガネ", "day");
      for (let i = 0; i < 3; i++) { hammers(K, p); await K.wait(6); }
      await K.narr(p, ["§7あちこちの 鍛冶場から、槌の 音が 重なって 聞こえる。§8カン、カーン、カン。"]);
      const eM = UA.mu(K, p, true);
      await K.up(p, eM, 10);
      K.act(eM, "sad"); await K.wait(6); K.act(eM, 0);
      await K.say(p, "ムサシ", ["{closed,息}……ふう。", "{smile}帰って きた 音だ。肩が 勝手に 下がる。"], null);
      await K.say(p, "ムサシ", ["{smile}字の 看板は 読めねえ。けど ここなら、目を つぶっても 歩ける。"], null);
      await K.end(p, { leave: [eM], card: "§7→ クロガネの 通りへ" });
      return true;
    } },
  { id: "u03e2", t: "音で 選ぶ 店", place: KP.street, F: ["F26"], battles: 0,
    hint: "§fクロガネの §e通り§f を 歩こう",
    syn: "ムサシは 看板の 字では なく、音で 店を 言い当てた。「……ラヴィの 鍛冶場にも、いい 音の 見習いが いたな」。",
    async run(p, d, K) {
      await K.open(p, "クロガネの 通り", "day");
      const eM = UA.mu(K, p, true);
      hammers(K, p); await K.wait(6);
      await K.say(p, "ムサシ", ["{closed}……右の 店は 包丁だ。薄い 音。", "{up}左は 鍬。重てえ 音で、急いでねえ。"], null);
      K.sound(p, "random.anvil_use", 0.6); await K.wait(8);
      await K.say(p, "ムサシ", ["{smile}奥は 刀。……迷ってる 音だ。焼きの 前で 手が 止まってる。"], null);
      /*F26*/ await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{closed,…}……ラヴィの 鍛冶場にも、いい 音の 見習いが いたな。", "{smile}前に 寄ったんだ。看板が 読めねえから、音で 選んだ。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 村の 若い衆が 待って いる（闘技の 庭へ）" });
      return true;
    } },
  { id: "u03e3", pv: 127, t: "話を 聞きに", place: KP.yard, battles: 1,
    hint: "§fクロガネの §e闘技の 庭§f へ 行こう",
    syn: "村の 若い衆が「鍔を 渡せ」と 迫った。ムサシは 鍔を 自分の 背に 回して 手合わせ。「斬りにじゃねえ、話を 聞きにだ」。",
    async run(p, d, K) {
      fac(K, p, "u_kyard", "arena", 3, UA.Y(K, p));
      await K.open(p, "クロガネの 闘技の 庭", "day");
      const eY = K.cast(p, "u_kyouth"), eM = UA.mu(K, p, true);
      await K.up(p, eY, 10);
      await K.csay(p, "u_kyouth", ["{angry}末っ子。その 鍔、村に 置いてけ。", "{angry,!}千年 封じてた もんだ。おまえが 持ち歩く もんじゃ ねえ！"], eM);
      await K.say(p, "ムサシ", ["{closed}……渡さねえ。", "{angry,up}斬りに 行くんじゃ ねえ。話を 聞きに 行くんだ。"], eY);
      K.act(eM, "guard");
      await K.say(p, "ムサシ", ["{smile}……文句が あるなら、庭で 聞く。おまえも 手を 貸せ。"], eY);
      const r = await K.battle(p, K.team(["beast", "golem", "sword"], 86, 3, 36), { name: "クロガネの 若い衆", arena: "闘技の 庭", theme: "volcano", speaker: "ゴウタ", guests: [{ sid: "musashi", lv: 80, q: 1, plus: 10, owner: "ムサシ" }], lines: { half: "くっ……鍔を 背に 回した まま かよ！", low: "……わかった、わかったよ！" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……一回 下がる。", K.RT(p)], eY); await K.end(p, { bye: [eY, eM] }); return false; }
      await K.csay(p, "u_kyouth", ["{sweat,汗}……鍔、一度も 前に 出さなかったな。", "{closed}行けよ。……工房の 鍵、親父さんの まんまだぜ。"], eM);
      K.pay(p, this, 1200, [["c_fruit", 2]]);
      await K.end(p, { leave: [eY, eM], card: "§7→ ムサシの 家の 工房へ" });
      return true;
    } },
  { id: "u03e4", t: "柱の 刻み", place: KP.koubou, fac: "u_koubou", F: ["F42"], battles: 0,
    hint: "§fクロガネの 外れの §eムサシの 家の 工房§f へ 行こう",
    syn: "工房の 柱に、細い 刻みが 床から 天井まで びっしり。ムサシは 字が 読めないので、数だけ 数え始めて、やめた。",
    async run(p, d, K) {
      koubou(K, p); const pq = facMark("u_koubou", "pillar", p.location);
      await K.open(p, "ムサシの 家の 工房", "day");
      const eM = UA.mu(K, p, true);
      await K.say(p, "ムサシ", ["{closed}……親父が 死んでから、誰も 炉に 火を 入れてねえ。"], eM);
      /*F42*/ if (pq) await K.push(p, pq, 26, 4, 0.2);
      await K.narr(p, ["§7柱に、細い 刻みが 床から 天井まで びっしり 並んで いる。§8一本ずつ、同じ 深さで。"], pq);
      if (pq) await K.approach(p, eM, pq, 1, 12);
      await K.say(p, "ムサシ", ["{closed}親父が 毎朝 一本。……一つ、二つ、三つ、四つ……", "{sad,…}……やめた。字じゃ ねえのに、数えきれねえ。"], pq ? null : eM);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{closed}毎朝 奥の 部屋の 前で 一度 叩いて、ここに 刻む。それが 親父の 朝だった。", "{?}……何を 叩いてたのかは、聞いた ことが ねえ。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 奥の 開かずの 部屋（工房で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u03e5", t: "リン", place: KP.koubou, fac: "u_koubou", F: ["F41"], battles: 0,
    hint: "§fムサシの 家の 工房の §e奥の 開かずの 部屋§f",
    syn: "鍔が 鳴ると、開かずの 部屋の 格子が 外れた。中に、胸に 小さな 穴の ある 石の 娘。ムサシが 叩くと「……こいつ、まだ 鳴ってる」。幼なじみの 石と 同じ 音だった。",
    async run(p, d, K) {
      koubou(K, p); const dq = facMark("u_koubou", "door", p.location), sq = sayaAt(K, p);
      const eY = UA.statue(K, p, sq, "§7石の 娘", K.PJ("sakura", 9));
      await K.open(p, "ムサシの 家の 工房", "day");
      const eM = UA.mu(K, p, true);
      K.sound(p, "note.bell", 0.5); K.sound(p, "block.amethyst_block.chime", 0.6);
      await K.narr(p, ["§7かばんの 中で 鍔が 鳴った。§8奥の 部屋の 格子が、ことりと 外れた。"], dq);
      facState("u_koubou", 1);
      if (ok(eY)) await K.push(p, eY, 26, 4, 1.4);
      await K.narr(p, ["§7中に、石の 娘が 立って いる。§f胸に 小さな 穴。§8……エンドの 墓標の 石と、同じ 穴だ。"], eY);
      /*F41*/ await UA.tap(K, p, eM, eY ? eY.location : null);
      K.sound(p, "block.amethyst_block.chime", 0.8);
      await K.say(p, "ムサシ", ["{shock,…}……こいつ、まだ 鳴ってる。", "{closed}リン、リンって。……ガキの ころ、壁の 向こうで 鳴ってた 音だ。"], eY);
      K.act(eM, "kneel"); await K.wait(10);
      await K.say(p, "ムサシ", ["{sad}親父が 毎朝 叩いてたのは、こいつだ。", "{closed}……俺は 勝手に「リン」って 呼んでた。本当の 名前は 知らねえ。"], eY);
      K.act(eM, 0);
      await K.end(p, { leave: [eM], bye: [eY], card: "§7→ 部屋の 棚に 何か ある" });
      return true;
    } },
  { id: "u03e6", t: "機神の 型", place: KP.koubou, fac: "u_koubou", ans: ["qb042"], battles: 0,
    hint: "§fムサシの 家の 工房の §e開かずの 部屋§f の 棚を 見よう",
    syn: "棚に 古い 型が 二つ。鍔の 型と、腕輪の 型 ── 機神の 型。壁には 古い 破門の 札。ムサシ「赤い 髪の 弟子が、ここを 開けようと して 親父に 追い出されたって 聞いた」。",
    async run(p, d, K) {
      koubou(K, p); facState("u_koubou", 1); const hq = facMark("u_koubou", "shelf", p.location);
      await K.open(p, "工房の 奥の 開かずの 部屋", "day");
      const eM = UA.mu(K, p, true);
      if (hq) await K.push(p, hq, 24, 3.5, 0.6);
      await K.narr(p, ["§7棚に、黒い 鉄の 型が 二つ。§f鍔の 型§7 と、§f腕輪の 型§7。", "§8型の 縁に、歯車の 模様。……神々の 時代の 形だ。"], hq);
      if (hq) K.burst(p.dimension, hq, "minecraft:portal", 8, 0.3, 0.3);
      K.sound(p, "block.amethyst_block.resonate", 0.4);
      await K.narr(p, ["§5腕輪の 型に 手を かざすと、一瞬 §d紫の 光§5 が 走った。"], hq);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{shock}……今の 光、知ってる。親父の 話だ。", "{closed}機神の 型。……書かずに、その場で 心を 合わせる 腕輪の 型だ。闘魔、って 言ってた。"], null);
      await K.say(p, "ムサシ", ["{closed}四十年前、うちで 腕輪を 二つだけ 打った。牧場の じいさんと、もう 一人に。", "{sad}それきり、型は ここに しまわれた。"], null);
      K.sound(p, "item.book.page_turn", 0.6);
      await K.narr(p, ["§7壁に、色の 抜けた 札が 一枚。§8墨の 字。……読めないが、破った 跡と、赤い 髪の 毛が 一本 はさまって いる。"], eM);
      await K.say(p, "ムサシ", ["{closed}破門の 札だ。字は 読めねえが、親父の 声で 覚えてる。", "{up}赤い 髪の 弟子が、この 部屋を 開けようと して、親父に 追い出されたって 聞いた。……型を 見たかったんだな。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 夜まで 工房で 待とう" });
      return true;
    } },
  { id: "u03e7", t: "わが 座へ", place: KP.koubou, fac: "u_koubou", ans: ["qu021"], battles: 0,
    hint: "§fムサシの 家の §e夜の 工房§f",
    syn: "夜の 工房。ムサシの 口が 勝手に 動いた。「……帰る。わが 座へ」「われは エンマ。帳の 王」。ムサシ「今の、俺じゃねえ」。鍔の 中で 泣いて いたのは、壁画の 帳の 王だった。",
    async run(p, d, K) {
      koubou(K, p); const sq = sayaAt(K, p), eY = UA.statue(K, p, sq, "§7石の 娘", K.PJ("sakura", 9));
      await K.open(p, "ムサシの 家の 工房（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      await K.narr(p, ["§7夜。ムサシは 炉の 前で、鍔を 膝に 置いて 黙って いた。"], eM);
      K.sound(p, "mob.ghast.moan", 0.2); K.burst(p.dimension, eM ? eM.location : p.location, "minecraft:basic_flame_particle", 10, 0.7, 1);
      K.act(eM, "raise"); await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{rage,…,low}§4……帰る。わが 座へ。"], null);
      await K.say(p, "ムサシ", ["{shock,汗,jump}……っ！ 今の、俺じゃ ねえ！"], null);
      K.act(eM, 0); await K.wait(6); K.act(eM, "kneel");
      await K.say(p, "ムサシ", ["{rage,low}§4……われは §cエンマ§4。帳の 王。", "§4……小僧、鍔に 指を かけたな。"], null);
      await K.say(p, "ムサシ", ["{angry,息}……勝手に 人の 口 使うな！", "{closed}……絵の 王か。顔を 削られた、あの。"], null);
      if (ok(eY)) await K.push(p, eY, 20, 3.5, 1.4);
      await K.say(p, "ムサシ", ["{rage,low}§4……サヤ。……待たせた。"], eY);
      K.act(eM, 0); await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{shock,…}サヤ？ ……リンじゃ、ねえのか。", "{closed}……おまえの 口から 聞いたんじゃ ねえから、まだ 呼ばねえ。"], eY);
      await K.end(p, { leave: [eM], bye: [eY], kind: "night", card: "§7→ 宿で 一晩 休もう" });
      return true;
    } },
  { id: "u03e8", t: "槌の 数", place: KP.inn, battles: 0,
    hint: "§fクロガネの §e宿§f で 一晩 休もう",
    syn: "宿の 布団で、ムサシは 父に 習った 槌の 数を 小声で 数えて 眠った。翌朝、ムサシは 仲間に 加わった（トークブックで 話せる）。",
    async run(p, d, K) {
      await K.open(p, "クロガネの 宿（夜）", "night", "night");
      const eI = K.cast(p, "u_kinn"), eM = UA.mu(K, p, true);
      await K.csay(p, "u_kinn", ["{smile}あら、末っ子。……鍔の 子を 連れて 帰って きたのかい。", "{closed}布団は 二つ。槌の 数は、小さい 声でね。"], eM);
      await K.say(p, "ムサシ", ["{sweat}……聞こえてたのかよ。"], eI);
      await K.night(p, eM ? eM.location : null, "§8「一つ、二つ、三つ……休み。一つ、二つ、三つ……」", "§7朝。ムサシは もう 起きて、鍔を 布で 包んで いた。", [eI]);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{closed}……鍔の 王は、帰りたがってる。妹の ことも 言ってた。", "{smile,up}付き合うぜ。……おまえの 石の 中身も、同じ 道の 先に ある 気が する。"], null);
      if (!K.replay(p)) musashiJoinMon(p);
      K.sound(p, "random.levelup", 1);
      K.pay(p, this, 1000, [["c_fruit", 3]]);
      await UA.zeph(K, p);
      await K.end(p, { leave: [eM], card: "§c§lムサシが 仲間に なった！ §7（ガイドブック →「ムサシと 話す」・トークブックでも 話せる）" });
      return true;
    } },
]);
