/* 第126版 裏11「花壇と 時計」（常世・中の 区）— 作業 UB
   区4（六冠 ハドラ・花壇）: 1話 前 → 2話 向かい合う → 後: 勝った 一拍（救いの ない 区）
   区5（五冠 ザキュラス・時計）: 3・4話 前 → 5話 向かい合う → 後: 6話（石の 暦）→ 7話（選択 U11）→ 8話（野営地の 夜）→ 裏12 1〜5話（bk_u12.js）*/
import { K } from "./bkeng.js";
import { U } from "./bk_u08.js";
import { act, hold, fx, fade, PJ } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
const { F, S1, ok } = U;
const V = (g, o, c, t) => ({ g, o, c, t });

facAdd("u11garden", { D: [10, 12, 14], box: [0, -5, 5, 5], H: 3, look: [2.5, 0, 0.8], marks: { bed: [2.5, 0, 0.6], soil: [4, 2, 0.4] },
  build: () => [F(1, -5, -1, 4, 5, -1, "coarse_dirt"), F(1, -5, 0, 1, 5, 0, "poppy"), F(2, -5, 0, 2, 5, 0, "cornflower"), F(3, -5, 0, 3, 5, 0, "oxeye_daisy"), F(4, -5, 0, 4, 5, 0, "allium"), F(0, -5, 0, 0, 5, 0, "stone_brick_slab"), F(5, -5, 0, 5, 5, 0, "stone_brick_slab")] });
facAdd("u11clock", { D: [11, 13, 15], box: [0, -2, 4, 2], H: 12, look: [1, 0, 8], marks: { face: [-0.3, 0, 8], cal: [1, 0, 1.5], top: [1, 0, 11], foot: [-1, -2, 0] },
  build: () => [F(0, -2, 0, 4, 2, 10, "stone_bricks"), F(1, -1, 1, 3, 1, 9, "air"), F(0, 0, 0, 0, 0, 2, "air"), S1(0, 0, 8, "target"), F(0, -1, 7, 0, 1, 7, "polished_andesite"), F(0, -1, 9, 0, 1, 9, "polished_andesite"), S1(2, 0, 10, "bell"), S1(3, 0, 1, "chiseled_stone_bricks"), S1(3, 0, 2, "chiseled_stone_bricks"), F(0, -2, 11, 4, 2, 11, "stone_brick_slab")] });

/* ---- 区4: ハドラ（救いの ない 区）---- */
const fight4 = U.fight(4, async (p, C) => {
  await K.open(p, "常世 ― 花壇の 区");
  const g = K.fac(p, "u11garden", "u11garden", 99, U.y0(p)), so0 = facMark("u11garden", "soil", p.location) || g;
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  const e = U.boss(p, C, 4, 11, 1); await U.bossIn(p, e, 4);
  await U.say(p, "ハドラ", ["{smile,♪}ようこそ、ぼくの 花壇へ。", "{smile,♥,up}ほら、見て。首が、みんな きれいに 咲いたよ"], mu);
  if (so0) { await K.at(p, so0, 14, 2.6, 0.2); fx(p.dimension, "minecraft:spore_blossom_ambient_particle", so0, 10, 0.8); }
  await U.narr(p, ["§7（花の 根もとは、人の 形の 土だった）"]);
  await U.H(p, V(["{rage,怒,jump}……ちょっと。これの どこが『きれい』なの！"], ["{angry}……これの どこが『きれい』なの……？"], ["{angry,怒}……これを『きれい』とは 呼ばない。"], ["{angry,怒}……これの どこが『きれい』なのですか！"]), e);
  await U.M(p, mu, ["{rage,怒,low}……てめえが『きれい』なんて 言うんじゃねえ！"], "guard");
}, async (p, C) => {
  K.fac(p, "u11garden", "u11garden", 99, U.y0(p)); const bed = facMark("u11garden", "bed", p.location);
  const e = U.boss(p, C, 4, 7, 1); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "ハドラ", ["{sad,?}みんな、きれいに 咲いたのに。……どうして 枯らすの"]);
  if (ok(e)) await fade(e, "minecraft:cherry_leaves_particle");
  if (bed) await K.at(p, bed, 16, 5, 0.6);
  await U.narr(p, ["§7主が 消えても、花は 戻らなかった。§8首に 花を つけた 姉妹たちは、土の 中で 眠った まま だった。", "§8……この 区だけは、何も ほどけない。"]);
  const mu = U.mu(C); await K.up(p, mu, 8);
  await U.M(p, mu, ["{closed,…}……リリの 姉ちゃんに、なんて 言やいいんだ。"], "sad");
  await U.E(p, mu, ["……ありのまま 伝えよ。名を 呼ぶ 者が いれば、魂は 迷わぬ"]);
  U.flag(p, "liliSis");
});
/* ---- 区5: ザキュラス（時計）---- */
const fight5 = U.fight(5, async (p, C) => {
  await K.open(p, "常世 ― 時計塔", "night", "night");
  K.fac(p, "u11clock", "u11clock", 99, U.y0(p));
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  const e = U.boss(p, C, 5, 11, 0); await U.bossIn(p, e, 5);
  await U.say(p, "ザキュラス", ["{closed}……二十三時 五十九分。この 区の 時は、ここで 止めた", "{smile,up}明日は 来ない。夜は 終わらない。……夜こそ、わたしの 食卓だ"], mu);
  await U.H(p, V(["{shock,汗}……空、まっくら。昼の はず なのに"], ["{shock,汗}……空が まっくら。昼の はず なのにね"], ["{shock,汗}……空が 暗い。昼の はず"], ["{shock,汗}……空が まっくらです。昼の はず なのに"]), mu);
  await U.say(p, "ザキュラス", ["{angry,!,low,roar}血を 置いて いけ。……針に 触れる 者は、みな そうして きた"]);
}, async (p, C) => {
  K.fac(p, "u11clock", "u11clock", 99, U.y0(p));
  const e = U.boss(p, C, 5, 7, 0); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "ザキュラス", ["{closed,…}……針を 動かすかは、おまえが 決めよ", "{sad,up}動かせば、この 者らに 朝が 来る。……三千年分の 朝が"]);
  if (ok(e)) await fade(e, "minecraft:soul_particle");
});

U.reg("u11", [
  { id: "u11e1", t: "首の 花", free: false, F: ["F55"],
    syn: "花壇の 区には、首に 花を つけた 姉妹たちが いた。協会の 受付の リリが 押し花に して いる 花と 同じ 花。リリの ずっと 前の 先祖たちだった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 花壇の 区");
        const g = K.fac(p, "u11garden", "u11garden", 99, U.y0(p)), bed = facMark("u11garden", "bed", p.location) || g;
        if (bed) await K.push(p, bed, 24, 7, 2.6, 0.6);
        const sis = [C.npc("", PJ("lili2", 9), 5, 0.8, 0, "veil"), C.npc("", PJ("lili3", 9), 5.4, 2, 0, "veil"), C.npc("", PJ("lili4", 9), 5, 3.2, 0, "veil")]; for (const x of sis) { act(x, "hold"); hold(x, "bouquet"); }
        await U.narr(p, ["§7花壇の 前に、姉妹たちが 並んで 石に なって いた。§8首に、花が 一輪ずつ。"], sis[1]);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        /*F55 回: リリの 押し花と 同じ 花 ＝ 常世の 姉妹は リリの 先祖 */
        await U.H(p, V(["{shock,!}……この 花、協会の リリさんが 押し花に してる 花だ。", "{sad,…}顔も、ちょっと 似てる……"], ["{shock,!}……この 花、協会の リリさんが 押し花に して いる 花よ。", "{sad,…}お顔も、少し 似てる……"], ["{shock,!}……この 花。リリが 押し花に してる 花。", "{sad,…}顔も、少し 似てる。"], ["{shock,!}……この 花、協会の リリさんが 押し花に されて いる 花です。", "{sad,…}お顔も、少し 似て いて……"]), mu);
        await U.rec(p, C, 4, ["§7『花売り エラ。妹たちに 花冠を 編んで いた。三つ 目を 編み終える 前に』"], "lili2", "hold");
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……麦の 紋の 次は 花か。", "{sad}……ここの 連中、みんな 今の 町の 誰かの 先祖なんだな。"], "hold");
        await U.lesson(p, C, 4, mu);
        await U.end(p, C, { card: "§7→ 花壇の 奥から、甘い 声が した" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u11e2", t: "咲かせる 者", free: false, run: fight4, syn: "六冠ハドラとの 戦い。勝っても 花は 戻らなかった。救いの ない 区。" },
  { id: "u11e3", t: "二十三時 五十九分", free: false, F: ["F39"],
    syn: "時計の 区の 時計は、みんな 二十三時 五十九分で 止まって いた。時計番 オットーの 石が、塔を 見上げて いる。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 時計の 区", "night", "night");
        const t = K.fac(p, "u11clock", "u11clock", 99, U.y0(p)), fc = facMark("u11clock", "face", p.location) || t;
        if (fc) await K.at(p, fc, 22, 9, 0);
        await U.narr(p, ["§7塔の 時計も、窓の 時計も、店先の 時計も。§f……みんな、二十三時 五十九分。"], fc);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        await U.H(p, V(["{?}……あと 一分で 明日 なのに。"], ["{?}……あと 一分で 明日 なのにね。"], ["{?}……あと 一分で 明日。"], ["{?}……あと 一分で 明日 ですのに。"]), mu);
        /*F39 強: 針の 音も 年寄り */
        await U.tap(p, mu);
        await U.M(p, mu, ["{closed}……針の 音も、年寄りだ。", "{?}……見た目は 新しい 時計なのに。あの 壁と 同じだ。"], "hold");
        await U.rec(p, C, 5, ["§7『時計番 オットー。塔の 時計は 二十三時 五十九分で 止まって いる。あと 一分で 明日 だった』", "§8それから この 区には、朝が 来て いない。"], "otto", "up");
        await U.E(p, mu, ["……時計番 オットー、と ある"]);
        await U.lesson(p, C, 5, mu);
        await U.end(p, C, { card: "§7→ 塔の 下へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u11e4", t: "塔の 下の 顔", free: false,
    syn: "塔の 下に、石の 市民が 並んで いた。ザキュラス「明日が 来れば、この 者らに 三千年分の 死が 一度に 来る」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 時計塔の 下", "night", "night");
        K.fac(p, "u11clock", "u11clock", 99, U.y0(p));
        const fs = [C.npc("", PJ("guy", 8), 5, -2, 0, "veil"), C.npc("", PJ("rosa", 8), 5.4, -0.4, 0, "veil"), C.npc("", PJ("m6_pip", 8), 5, 1.2, 0, "veil"), C.npc("", PJ("mira", 8), 5.6, 2.8, 0, "veil")];
        for (const x of fs) act(x, "up");
        for (const x of fs) if (ok(x)) await K.up(p, x, 12);
        await U.narr(p, ["§7塔を 見上げた 顔の まま、市民たちが 石に なって いた。§8子どもも、年寄りも。あと 一分を 待つ 顔。"]);
        const e = U.boss(p, C, 5, 11, 0); if (ok(e)) await K.low(p, e, 14);
        /* 敵の 正しさ: 明日が 来れば、三千年分の 死が 一度に 来る */
        await U.say(p, "ザキュラス", ["{closed}……見たか。明日が 来れば、この 者らに 三千年分の 死が 一度に 来る", "{sad,up}わたしは 夜を 食らう。だが この 者らを 死なせぬ ためにも、針を 止めて いる"]);
        const mu = U.mu(C); await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed,…}……一つ、二つ、三つ……。", "{angry}……止めときゃ 死なねえ。けど、生きても いねえ。"], "hold");
        await U.end(p, C, { card: "§7→ 塔の 主と 向かい合う" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u11e5", t: "夜の 食卓", free: false, run: fight5, syn: "五冠ザキュラスとの 戦い。倒れた 主は、針を 動かすかは おまえが 決めよ と 言い残した。" },
  { id: "u11e6", t: "石の 暦", free: false, F: ["F39"], ans: ["qu081", "qu091"],
    syn: "塔の 中の 石の 暦に、三千年前の 年が 刻まれて いた。ムサシ「逆だったんだ。新しいんじゃ ねえ、古いんだ」。常世は 未来では なく、過去の 都。今の 町の 人は、この 都の 人々の 子孫だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 時計塔の 中", "night", "night");
        const t = K.fac(p, "u11clock", "u11clock", 99, U.y0(p)), cal = facMark("u11clock", "cal", p.location) || t;
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.6, "none");
        if (ok(mu) && cal) await K.walkCam(p, mu, cal, 18);
        if (cal) await K.push(p, cal, 22, 3.5, 1.4, 0.4);
        await U.narr(p, ["§7塔の 壁に、石の 暦が 刻まれて いた。"], cal);
        await U.H(p, V(["{closed}……読むね。『記録の 民の 都、建国 九百十二年。祭りの 夜』", "{shock,…,up}……この 年、手帳の 地図の 年表に 書いた ことが ある。……三千年 前だよ"], ["{closed}……読むわね。『記録の 民の 都、建国 九百十二年。祭りの 夜』", "{shock,…,up}……この 年、手帳の 年表に 書いた ことが あるの。……三千年 前よ"], ["{closed}……読む。『記録の 民の 都、建国 九百十二年。祭りの 夜』", "{shock,…,up}……この 年、手帳の 年表に ある。三千年 前"], ["{closed}……お読みします。『記録の 民の 都、建国 九百十二年。祭りの 夜』", "{shock,…,up}……この 年、手帳の 年表に 書いた ことが あります。……三千年 前です"]), mu);
        await K.up(p, mu, 10);
        /*F39 回: 「逆か？」の 答え（未来では なく 過去の 都）*/
        await U.tap(p, mu);
        await U.M(p, mu, ["{shock,!,up}……いや、逆か？", "{closed}逆だったんだ。……新しいんじゃ ねえ、古いんだ。"], "up");
        await U.E(p, mu, ["……ここは 未来では ない。三千年前の『きのう』だ。おまえの 耳は 当たって いた"]);
        await U.M(p, mu, ["{shock,?}……じゃあ 俺らの 世界は、こっから 後ずさり したってのか。"], undefined, p);
        await U.E(p, mu, ["……石に なった 夜、この 都の 知恵も 止まった。生き残った わずかな 者は、火と 鉄から やり直した。……おまえの 家の 炉も、その 末だ"]);
        act(mu, "kneel"); await U.narr(p, ["§7ムサシは しばらく 黙って、床に 手のひらを 当てて いた。"], mu);
        await U.M(p, mu, ["{closed}……クロガネの 炉が、やり直しの 火か。", "{closed}……道理で、あの 炉は いつも 何か 思い出そうと してる 音が した。"], "kneel");
        await U.H(p, V(["{sad}……麦の 紋も、花も、パン屋さんも。今の 町の 人は、ここの 人たちの 子どもの 子ども、なんだね"], ["{sad}……麦の 紋も、花も、パン屋さんも。今の 町の 人は、ここの 人たちの 子孫なのね"], ["{sad}……麦の 紋も、花も。今の 町の 人は、ここの 人の 子孫"], ["{sad}……麦の 紋も、花も、パン屋さんも。今の 町の 方々は、ここの 人たちの 子孫 なのですね"]), mu);
        await U.end(p, C, { card: "§7→ 塔の 頂へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u11e7", t: "時計の 針", free: false,
    syn: "時計塔の 頂で、三千年 止まった 針を 前に 選んだ。進めるか、止めたままに するか。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 時計塔の 頂", "night", "night");
        const t = K.fac(p, "u11clock", "u11clock", 99, U.y0(p)), top = facMark("u11clock", "top", p.location) || t, fc = facMark("u11clock", "face", p.location) || t;
        if (fc) await K.at(p, fc, 18, 4, 0);
        const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
        await U.narr(p, ["§7大きな 針が、目の 前に ある。§f……押せば、三千年ぶりに 明日が 来る。", "§8下の 石の 市民たちの 顔が、思い浮かんだ。"], fc);
        await U.E(p, mu, ["……針を 進めれば、この 都の 一日は 終わる。石の 者は、苦しまずに 砂に なって 眠る。……下の 区は、崩れて もう 戻れぬ"]);
        await U.E(p, mu, ["……止めた ままなら、区は 残る。だが あの 者らの 朝は、来ぬ"]);
        if (K.ch(p, "u09") === "k") await U.narr(p, ["§7後ろで、糸の 人形が 小さく 肩を すくめた。§8……区が 崩れれば、人形も いっしょだ。"]);
        await K.two(p, mu, so || mu, 10);
        await U.M(p, mu, ["{closed}……お前が 決めろ。俺は、どっちの 音も 聞いて やる。"], "hold");
        const v = await K.pick(p, "u11");
        if (v === "a") {
          K.sound(p, "block.bell.hit", 1, 0.6); K.flash(p);
          await K.at(p, fc, 12, 4, 0);
          await U.narr(p, ["§f針が 動いた。§e零時 零分。", "§7三千年ぶりの 朝の 光が、塔の 下へ 降りて いった。§8石の 市民たちは、光の 中で 砂に なって、静かに 眠った。"]);
          if (K.ch(p, "u09") === "k") { await U.narr(p, ["§8……糸の 人形も、ほどけて 砂に なった。最後に、ぺこりと 頭を 下げて。"]); }
          await U.E(p, mu, ["……三千年ぶりの、明日だ"]);
          await U.M(p, mu, ["{closed}……砂の 音が する。やっと 寝られた 音だ。"], "kneel");
        } else {
          await U.narr(p, ["§7針は 動かなかった。§f二十三時 五十九分。", "§8石の 市民たちは、あと 一分を 待つ 顔の まま。……でも、区は 残る。"]);
          await U.E(p, mu, ["……止めた ままの 夜も、終わらせる 日が 来るやも しれぬ"]);
          await U.M(p, mu, ["{closed}……一分 待たせて 悪いな。……迎えに 来る 奴が いりゃ、それで いい。"], "hold");
        }
        await U.end(p, C, { card: "§7→ 夜。§e野営地§7 へ", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u11e8", t: "二文字目", free: false,
    syn: "野営地の 夜。幼なじみの 魂「わたし、今日、自分の 名前の 二文字目を 忘れた」。ムサシは 黙って 石に 手を 当てた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await U.toCamp(p);
        await K.open(p, "常世 ― 野営地の 夜", "night", "night");
        const mu = U.mu(C, 2.6, 1.4), so = U.soul(p, C, 3, -1.4, "none"); act(so, "kneel"); act(mu, "kneel");
        await K.up(p, so, 12);
        await U.H(p, V(["{sad,…}……ねえ。わたし、今日、自分の 名前の 二文字目を 忘れた。", "{smile,tears}……一文字目は まだ ある。だいじょうぶ"], ["{sad,…}……ねえ。わたし、今日、自分の 名前の 二文字目を 忘れたの。", "{smile,tears}……一文字目は、まだ あるわ"], ["{sad,…}……今日、自分の 名前の 二文字目を 忘れた。", "{smile,tears}……一文字目は まだ ある"], ["{sad,…}……あの。わたし、今日、自分の 名前の 二文字目を 忘れました。", "{smile,tears}……一文字目は、まだ あります"]), mu);
        await K.two(p, mu, so, 12);
        act(mu, "kneel"); K.sound(p, "dig.stone", 0.5);
        await U.narr(p, ["§7ムサシは 何も 言わずに、たき火の そばの 石に 手のひらを 当てた。§8……長い あいだ、そのまま だった。"], mu);
        await U.M(p, mu, [`{closed}……${U.hn(p)}。`, "{closed}……呼んだぞ。明日の ぶんも、先に 一回。"], "kneel");
        await U.H(p, V(["{smile,tears}……うん。聞こえた"], ["{smile,tears}……ええ。聞こえたわ"], ["{smile,tears}……聞こえた"], ["{smile,tears}……はい。聞こえました"]));
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 朝。ムサシが、区と 区の すきまで 足を 止めた", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(4, ["u11e1", "u11e2"], []);
U.ward(5, ["u11e3", "u11e4", "u11e5"], ["u11e6", "u11e7", "u11e8", "u12e1", "u12e2", "u12e3", "u12e4", "u12e5"]);
