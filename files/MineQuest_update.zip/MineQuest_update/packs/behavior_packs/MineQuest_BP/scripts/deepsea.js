// 第125版: 深海（マリノア諸島の 沖の 外海）。海溝の 底から そびえる 巨大な 神殿・首の ない 巨像・沈没船の 墓場
// 建物: ワールドに 1回だけ。近くに 人が 来たら 海か 調べて（陸・島・町・城を さける）、少しずつ 置く（enqueue）
// 泳いで いると 巨大な 影が 通りすぎる（ただの 影 ／ 戦える 海の ぬし）。沈んだ 大帆船の 船室で「アビスクラーケン」
// 軽く: 20tick ごとに プレイヤーだけ 見る（まわりの エンティティは 探さない）。影は 1人 1体まで
import { world, system } from "@minecraft/server";
import { SPECIES } from "./data.js";
import { load, save } from "./store.js";
import { ok, busy, sound, barNote, heavy, warming, countItem, giveItem, showTitle, notice } from "./ui.js";
import { WREGIONS, landSites, regionLv, LAYOUT } from "./worldmap.js";
import { enqueue, building, TOWNS, townPos, castleInfo, castleSpot, caveBox, CAVE_R, Plan } from "./structures.js";
import { TYPE, setLook, underwater } from "./field.js";
import { HIT_HOOKS, inBattle } from "./battle.js";
import { calcStats } from "./core.js";
import { stageBegin, stageEnd, stageOf, addActor } from "./stagecore.js";
import { tell, camAt, camFade, cineSting } from "./talk.js";
import { fight, holdBusy } from "./story.js";
import { hasKey, DIVE } from "./saga.js";
import { giveRew } from "./stageev.js";
import { boon } from "./boon.js";
import { XT } from "./explore.js";

export const DS_V = 1;
export const DS = { fight: null };   /* テストで 戦いを 差しかえ できる */
const KEY = "mrpg:dsea", PK = "mrpg:dsk";   /* PK: クラーケン 0 まだ・1 見た・2 勝った（ほうびは 1回）*/
const OW = () => world.getDimension("minecraft:overworld");
const wait = (t) => new Promise((r) => system.runTimeout(r, Math.max(1, t)));
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const run = (c) => { try { OW().runCommand(c); } catch {} };
const DEEP = (globalThis.__mqDeep = globalThis.__mqDeep || new Set());   /* 海溝の 中に いる 人（saga.js の ゴーグルが 暗視を 足さない）*/

/* ---------- 場所 ---------- */
let SITE; function site() { if (SITE === undefined) { try { SITE = JSON.parse(world.getDynamicProperty(KEY) || "null"); } catch { SITE = null; } } return SITE; }
function setSite(v) { SITE = v; try { world.setDynamicProperty(KEY, v ? JSON.stringify(v) : undefined); } catch {} }
const sp = () => { try { const s = world.getDefaultSpawnLocation(); return { x: s.x, z: s.z }; } catch { return { x: 0, z: 0 }; } };
function obstacles() {
  const o = [];
  for (const t of TOWNS) { try { const q = townPos(t); o.push([q.x, q.z, 55]); } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) {
    try { const c = castleInfo(i) || castleSpot(i); if (c) o.push([c.x, c.z, 85]); } catch {}
    try { for (const L of landSites(i)) o.push([L.x, L.z, 45]); } catch {}
  }
  for (const i of CAVE_R) { try { const b = caveBox(i); o.push([(b.x1 + b.x2) / 2, (b.z1 + b.z2) / 2, Math.hypot(b.x2 - b.x1, b.z2 - b.z1) / 2 + 12]); } catch {} }
  return o;
}
/* マリノアの 中心から 外へ（スポーンと 反対の 向き）。町・城・ステージから はなれた 所だけ */
let CANDS = null;
export function cands() {
  if (CANDS && LAYOUT.ok) return CANDS;
  const R = WREGIONS.find((r) => r.id === "mari"), s = sp(), cx = s.x + R.c[0], cz = s.z + R.c[1];
  const a0 = R.c[0] || R.c[1] ? Math.atan2(R.c[1], R.c[0]) : -Math.PI / 2, O = obstacles(), out = [];
  for (let dist = R.r + 70; dist <= R.r + 450 && out.length < 10; dist += 40) for (const dg of [0, 15, -15, 30, -30, 45, -45, 60, -60, 80, -80, 100, -100]) {
    const a = a0 + (dg * Math.PI) / 180, x = Math.round(cx + Math.cos(a) * dist), z = Math.round(cz + Math.sin(a) * dist);
    if (out.length < 10 && O.every(([ox, oz, r]) => Math.hypot(ox - x, oz - z) - r >= 70) && out.every((q) => Math.hypot(q.x - x, q.z - z) >= 90)) out.push({ x, z });
  }
  CANDS = out; return out;
}
/* 海の 底（水・海藻の 下の 固い ブロック）*/
const SOFT = /water|kelp|seagrass|bubble|sea_pickle/;
export function floorAt(dim, x, z, top = 66) {
  for (let y = top; y > -60; y--) { let b; try { b = dim.getBlock({ x, y, z }); } catch { return null; } if (!b) return null; if (b.isAir || SOFT.test(b.typeId)) continue; return y; }
  return null;
}
function oceanCol(dim, x, z) {
  for (let y = 80; y > 40; y--) {
    let b; try { b = dim.getBlock({ x, y, z }); } catch { return null; } if (!b) return null; if (b.isAir) continue;
    if (!/water/.test(b.typeId) || y < 57 || y > 63) return null;   /* 陸・島・氷・池 */
    const f = floorAt(dim, x, z, y); return f !== null && f <= y - 6 ? f : null;
  }
  return null;
}
export function judge(dim, c) {   /* 海の 真ん中か（まわり 13点）*/
  const inner = [[0, 0], [24, 0], [-24, 0], [0, 40], [0, -40]], ring = []; for (let k = 0; k < 8; k++) ring.push([Math.round(Math.cos((k * Math.PI) / 4) * 50), Math.round(Math.sin((k * Math.PI) / 4) * 50)]);
  const fi = inner.map(([a, b]) => oceanCol(dim, c.x + a, c.z + b)), fr = ring.map(([a, b]) => oceanCol(dim, c.x + a, c.z + b));
  if (fi.some((f) => f === null) || fr.filter((f) => f !== null).length < 7) return null;
  const all = [...fi, ...fr].filter((f) => f !== null).sort((a, b) => a - b), F = Math.max(28, Math.min(56, all[Math.floor(all.length / 2)]));
  return { F, B: Math.max(-20, F - 52) };
}
/* 場所の 決まった 点（船室・窓・クラーケン）*/
export function geo(S) {
  const X = S.x, Z = S.z, B = S.B;
  return { cab: { x: X - 10.5, y: B + 5, z: Z - 0.5 }, look: { x: X - 10.5, y: B + 6, z: Z - 12 }, win: { x: X - 10.5, y: B + 6.5, z: Z - 3.6 },
    box: { x1: X - 14, x2: X - 7, z1: Z - 4, z2: Z + 2, y1: B + 4, y2: B + 9 },
    kr: { x: X - 10.5, y: B + 3, z: Z - 13.5 }, t1: { x: X - 16.5, y: B + 2, z: Z - 9.5 }, t2: { x: X - 4.5, y: B + 2, z: Z - 9.5 },
    out: { x: X - 10.5, y: B + 3, z: Z - 8.5 } };
}

/* ---------- 建物 ---------- */
function hull(P, o) {   /* 船体: ax 長さの 向き（x / z）・a0..a1 長さ・c 中心・y0 底・H 高さ・w 半分の 幅 */
  const put = (a1, y1, b1, a2, y2, b2, blk, m) => (o.ax === "x" ? P.fill(a1, y1, b1, a2, y2, b2, blk, m) : P.fill(b1, y1, a1, b2, y2, a2, blk, m));
  const set = (a, y, b, blk) => (o.ax === "x" ? P.set(a, y, b, blk) : P.set(b, y, a, blk));
  const { a0, a1, c, y0, H, w } = o;
  put(a0, y0 - 4, c - w, a1, y0 - 1, c + w, "sand", "replace water");   /* 下が 低い 所は 砂で 埋めて 浮かせない */
  put(a0 + 2, y0, c - w + 2, a1 - 2, y0, c + w - 2, "dark_oak_planks");
  for (let h = 1; h < H; h++) { const hw = w - Math.max(0, 2 - h), sh = Math.max(0, 2 - h); put(a0 + sh, y0 + h, c - hw, a1 - sh, y0 + h, c + hw, h % 3 === 0 ? "dark_oak_planks" : "spruce_planks", "outline"); }
  put(a0 + 1, y0 + H - 1, c - w + 1, a1 - 1, y0 + H - 1, c + w - 1, "spruce_planks");   /* 甲板 */
  for (const k of o.holes || []) put(k - 1, y0 + H - 1, c - 1, k + 1, y0 + H - 1, c + 1, "water");   /* 甲板の 穴 */
  put(a0, y0 + H, c - w, a1, y0 + H, c + w, "dark_oak_fence", "outline");
  if (o.mast !== undefined) { put(o.mast, y0 + H, c, o.mast, y0 + H + 6, c, "spruce_log"); put(o.mast + 1, y0 + H, c + w + 1, o.mast + 1, y0 + H, c + w + 11, "spruce_log"); put(o.mast + 2, y0 + H + 1, c + w + 3, o.mast + 2, y0 + H + 3, c + w + 6, "white_wool"); }
  if (o.broken === "a1") put(a1 - 1, y0 + 1, c - w, a1, y0 + H, c + w, "water");
  if (o.broken === "a0") put(a0, y0 + 1, c - w, a0 + 1, y0 + H, c + w, "water");
  for (const [a, b] of o.chest || []) { const q = o.ax === "x" ? [a, y0 + 1, c + b] : [c + b, y0 + 1, a]; P.loot(q[0], q[1], q[2], "mrpg/treasure"); }
  return { put, set };
}
const hsh = (n) => { n = Math.imul(n ^ (n >>> 15), 2246822519); n = Math.imul(n ^ (n >>> 13), 3266489917); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; };
export function plan(S, fl) {
  const P = new Plan(S.x, 0, S.z), F = S.F, B = S.B, top = Math.min(F + 3, 58);
  /* 海溝（幅 37・長さ 113・深さ 約50）*/
  P.fill(-18, B + 1, -56, 18, top, 56, "water");
  P.fill(-18, B, -56, 18, B, 56, "gravel");
  for (let z = -52; z <= 52; z += 13) { P.set(19, F - 1, z, "sea_lantern"); P.set(-19, F - 1, z + 6, "sea_lantern"); }   /* 縁の かすかな 灯り */
  for (let z = -48; z <= 48; z += 32) { P.set(19, B + 20, z, "sea_lantern"); P.set(-19, B + 14, z + 12, "sea_lantern"); }
  for (const [x, z] of [[-16, -52], [16, -49], [16, 12], [-16, 54], [16, 54]]) { P.set(x, B, z, "soul_sand"); P.fill(x, B + 1, z, x, top - 1, z, "bubble_column"); }   /* 泡の 柱 */
  /* 神殿: 床・柱 6本（2本は 折れた）・梁・ドーム */
  P.fill(-15, B, 6, 15, B, 52, "prismarine_bricks"); P.fill(-15, B, 24, 15, B, 25, "dark_prismarine");
  for (const [x, z, h] of [[-14, 8, 46], [11, 8, 44], [-14, 20, 30], [11, 20, 48], [-14, 44, 48], [11, 44, 26]]) {
    P.fill(x, B + 1, z, x + 3, B + h, z + 3, "dark_prismarine");
    if (h >= 40) { P.fill(x - 1, B + h + 1, z - 1, x + 4, B + h + 1, z + 4, "prismarine_bricks"); P.set(x + 1, B + h + 2, z + 1, "sea_lantern"); }
  }
  P.fill(-6, B + 1, 14, 7, B + 4, 17, "dark_prismarine");   /* 倒れた 柱 */
  P.fill(-14, B + 43, 8, 14, B + 46, 11, "prismarine_bricks"); P.fill(2, B + 45, 20, 14, B + 48, 23, "prismarine_bricks"); P.fill(-14, B + 45, 44, -3, B + 48, 47, "prismarine_bricks");
  P.fill(-9, B + 1, 21, 9, B + 12, 39, "prismarine_bricks", "outline");
  for (const [a, b, c, d] of [[-2, 21, 2, 21], [-2, 39, 2, 39]]) P.fill(a, B + 1, b, c, B + 7, d, "water");
  for (const x of [-9, 9]) P.fill(x, B + 1, 28, x, B + 7, 32, "water");
  for (let dy = 1; dy <= 9; dy++) { const r = Math.round(Math.sqrt(81 - dy * dy)); if (r < 2) break; P.fill(-r, B + 12 + dy, 30 - r, r, B + 12 + dy, 30 + r, dy % 3 ? "prismarine_bricks" : "dark_prismarine", "outline"); }
  P.fill(-1, B + 22, 29, 1, B + 22, 31, "dark_prismarine"); P.set(0, B + 23, 30, "sea_lantern"); P.set(0, B + 1, 30, "sea_lantern"); P.loot(2, B + 1, 30, "mrpg/treasure");
  /* 首の ない 巨像（高さ 約43）と 海溝の 底に 転がる 頭（上を 見上げる 顔）*/
  P.fill(-10, B + 1, -46, 10, B + 6, -30, "dark_prismarine");
  P.fill(-7, B + 7, -41, -2, B + 20, -35, "prismarine"); P.fill(2, B + 7, -41, 7, B + 20, -35, "prismarine");
  P.fill(-8, B + 21, -42, 8, B + 38, -34, "prismarine"); P.fill(-14, B + 35, -41, 14, B + 40, -35, "prismarine");
  P.fill(10, B + 16, -40, 14, B + 34, -36, "prismarine"); P.fill(-14, B + 28, -40, -10, B + 34, -36, "prismarine");
  P.fill(-3, B + 41, -40, 3, B + 43, -36, "prismarine"); P.fill(-8, B + 24, -43, 8, B + 25, -43, "dark_prismarine"); P.set(0, B + 30, -43, "sea_lantern");
  P.fill(-17, B + 1, -28, -13, B + 4, -17, "prismarine");   /* 落ちた 腕 */
  P.fill(1, B + 1, -26, 14, B + 13, -13, "prismarine");
  for (const x of [3, 10]) { P.fill(x, B + 12, -23, x + 2, B + 13, -21, "water"); P.set(x + 1, B + 11, -22, "sea_lantern"); }
  P.fill(2, B + 14, -24, 6, B + 14, -24, "dark_prismarine"); P.fill(9, B + 14, -24, 13, B + 14, -24, "dark_prismarine");
  P.fill(7, B + 14, -21, 8, B + 15, -17, "prismarine_bricks"); P.fill(4, B + 13, -16, 11, B + 13, -15, "water");
  for (const x of [1, 4, 7, 10, 13]) P.fill(x, B + 3, -28, x + 1, B + 11, -27, "dark_prismarine");   /* 冠 */
  /* 大帆船（二つに 折れた）: 後ろ半分は 海溝の 底・前半分は 東の 縁の 上 */
  hull(P, { ax: "x", a0: -16, a1: 2, c: -1, y0: B + 1, H: 9, w: 5, broken: "a1", holes: [-2], chest: [[-3, 1]] });
  P.fill(-16, B + 10, -6, -11, B + 13, 4, "dark_oak_planks", "outline"); P.fill(-15, B + 11, -6, -12, B + 12, -6, "glass");
  P.fill(-15, B + 4, -5, -7, B + 9, 3, "dark_oak_planks");   /* 船室（空気だまり）*/
  P.fill(-14, B + 5, -4, -8, B + 8, 2, "air");
  P.fill(-13, B + 6, -6, -9, B + 7, -6, "water"); P.fill(-13, B + 6, -5, -9, B + 7, -5, "glass");   /* 窓 */
  P.set(-8, B + 4, 0, "air"); P.fill(-10, B + 2, 3, -6, B + 3, 4, "water");   /* 床の 穴（下の 船倉へ）・船倉の 破れ目 */
  P.set(-11, B + 9, -1, "sea_lantern"); P.loot(-14, B + 5, 2, "mrpg/treasure");
  const fb = fl(32, -1) ?? F;
  hull(P, { ax: "x", a0: 21, a1: 43, c: -1, y0: fb + 1, H: 9, w: 5, broken: "a0", holes: [28, 36], mast: 31, chest: [[38, 2]] });
  P.fill(44, fb + 7, -1, 49, fb + 8, -1, "spruce_log");   /* へさき */
  for (const [x, y, z] of [[18, F - 4, -3], [17, F - 9, 1], [18, F - 15, -2], [16, F - 22, 0], [17, B + 6, 2]]) P.set(x, y, z, "dark_oak_planks");   /* 崖を 落ちた 板 */
  /* 沈没船の 墓場（東の 海の 底）*/
  const f1 = fl(34, -40) ?? F, f2 = fl(48, 22) ?? F, f3 = fl(40, 44) ?? F;
  hull(P, { ax: "x", a0: 28, a1: 40, c: -40, y0: f1 + 1, H: 4, w: 3, chest: [[34, 0]] });
  hull(P, { ax: "z", a0: 10, a1: 32, c: 48, y0: f2, H: 6, w: 4, holes: [18, 26], broken: "a1", mast: 20, chest: [[14, -1]] });
  hull(P, { ax: "x", a0: 26, a1: 46, c: 46, y0: f3 - 1, H: 6, w: 4, holes: [34], broken: "a0" });
  for (let k = 0; k < 10; k++) { const x = 24 + Math.floor(hsh(S.x * 31 + k) * 34), z = -54 + Math.floor(hsh(S.z * 17 + k) * 100), f = fl(x, z); if (f !== null && f < F + 6) P.set(x, f + 1, z, k % 4 ? "barrel" : "chest"); }
  /* 海藻の 森（西の 海の 底）*/
  for (let k = 0; k < 48; k++) {
    const x = -56 + Math.floor(hsh(S.x * 7 + k * 13) * 32), z = -56 + Math.floor(hsh(S.z * 11 + k * 7) * 112), f = fl(x, z);
    if (f === null || f > 57) continue; const h = 5 + Math.floor(hsh(k * 97 + S.x) * 10);
    P.fill(x, f + 1, z, x, Math.min(60, f + h), z, "kelp", "replace water"); if (k % 2) P.set(x + 1, f + 1, z, "seagrass");
  }
  return P.c;
}
let BLD = false, FAILT = 0;
function scanThen(c, cb) { enqueue(OW(), [], () => cb(true), [{ x: c.x - 62, y: 40, z: c.z - 62 }, { x: c.x + 62, y: 62, z: c.z + 62 }], () => cb(false)); }
function tryBuild(plist) {
  if (BLD || building() || warming() || heavy() >= 2 || Date.now() < FAILT) return;
  const S0 = site(); if (S0 && (S0.built || S0.none)) return;
  const L = cands(); if (!L.length) { setSite({ v: DS_V, none: true }); return; }
  const ci = S0 ? S0.ci || 0 : 0, c = L[ci];
  if (!c) { setSite({ v: DS_V, none: true }); return; }
  const tgt = S0 && S0.F !== undefined ? S0 : c;
  const near = (q, r) => plist.some((p) => Math.hypot(p.location.x - q.x, p.location.z - q.z) < r);
  if (S0 && S0.F !== undefined ? !near(tgt, 120) : !(near(c, 200) || near(L[0], 260))) return;
  BLD = true;
  scanThen(c, (loaded) => {
    if (!loaded) { BLD = false; FAILT = Date.now() + 300000; return; }
    let S = site();
    if (!S || S.F === undefined) {
      const J = judge(OW(), c);
      if (!J) { setSite({ v: DS_V, ci: ci + 1 }); BLD = false; return; }   /* 陸や 島: 次の 場所へ */
      S = { v: DS_V, ci, x: c.x, z: c.z, F: J.F, B: J.B, built: false }; setSite(S);
      if (!plist.some((p) => Math.hypot(p.location.x - S.x, p.location.z - S.z) < 120)) { BLD = false; return; }   /* 近づいたら 作る */
    }
    const C = plan(S, (x, z) => floorAt(OW(), S.x + x, S.z + z));
    enqueue(OW(), C, () => { BLD = false; setSite({ ...site(), built: true });
      for (const q of world.getAllPlayers()) if (Math.hypot(q.location.x - S.x, q.location.z - S.z) < 160) try { q.sendMessage("§3海の 底から、低い 音が ひびいた……§7（マリノアの 沖に 深い 海溝が ある）"); } catch {} },
    [{ x: S.x - 62, y: Math.max(-60, S.B - 2), z: S.z - 62 }, { x: S.x + 62, y: 62, z: S.z + 62 }], () => { BLD = false; FAILT = Date.now() + 300000; }, 6);
  });
}

/* ---------- 泳いで いる 人（雰囲気・注意・影）---------- */
const PS = new Map();   /* id → { warn, dark, amb, enc, t } */
const ENC = new Map();   /* id → { e, iv, sid, fight } */
const GIANTS = () => ["sea00", "sea01", "sea02", "sea03", "sea04", "sea05", "sea06", "xk15", "xk16", "xk17"].filter((s) => SPECIES[s] && !SPECIES[s].hidden);
const inArea = (S, l, r) => Math.hypot(l.x - S.x, l.z - S.z) <= r;
const inTrench = (S, l) => Math.abs(l.x - S.x) <= 20 && Math.abs(l.z - S.z) <= 58 && l.y < S.F - 1;
const inBox = (b, l) => l.x >= b.x1 && l.x < b.x2 + 1 && l.z >= b.z1 && l.z < b.z2 + 1 && l.y >= b.y1 && l.y < b.y2;
function free(p) { if (busy.has(p.id) || KRUN.has(p.id)) return false; try { if (inBattle(p) || stageOf(p)) return false; } catch {} return true; }
function lvAt(S) { try { return Math.max(40, Math.min(100, Math.floor(regionLv({ x: S.x, y: 64, z: S.z })) + 6)); } catch { return 56; } }
function endEnc(id) { const E = ENC.get(id); if (!E) return; ENC.delete(id); try { system.clearRun(E.iv); } catch {} if (ok(E.e)) try { globalThis.__mqCine?.delete(E.e.id); E.e.remove(); } catch {} }
export function clean(p, id = p && p.id) {   /* 海から 出た・たおれた・ぬけた */
  endEnc(id); DEEP.delete(id); const st = PS.get(id); PS.delete(id);
  if (st && st.dark && ok(p)) try { p.removeEffect("darkness"); } catch {}
}
function growl(p, close) { sound(p, "mob.elderguardian.curse", close ? 0.5 : 0.35, close ? 0.9 : 0.5); sound(p, "mob.guardian.ambient", 0.4, 0.6); }
function bubbles(p, at, n = 4) { for (let k = 0; k < n; k++) try { p.dimension.spawnParticle("minecraft:basic_bubble_particle", { x: at.x + Math.random() * 3 - 1.5, y: at.y + Math.random() * 2, z: at.z + Math.random() * 3 - 1.5 }); } catch {} }
export function startEnc(p, S, kind = null) {
  if (ENC.has(p.id)) return null;
  const lv = lvAt(S), pool = GIANTS(); if (!pool.length) return null;
  const fightable = kind ? kind === "nushi" : Math.random() < 0.3, close = !fightable && (kind ? kind === "close" : Math.random() < 0.3);
  const fp = pool.filter((s) => lv >= 60 || SPECIES[s].rank !== "SS"), sid = pick(fightable && fp.length ? fp : pool);
  const l = p.location, a = Math.random() * Math.PI * 2, n = { x: Math.cos(a), z: Math.sin(a) }, t = { x: -n.z, z: n.x };
  const D = fightable ? 16 : close ? 7 : 26 + Math.random() * 10, y = Math.max(S.B + 4, Math.min(57, l.y + Math.random() * 8 - 5));
  const A = { x: l.x + n.x * D - t.x * 40, y, z: l.z + n.z * D - t.z * 40 }, Bq = { x: l.x + n.x * D + t.x * 40, y, z: l.z + n.z * D + t.z * 40 };
  let e; try { e = p.dimension.spawnEntity(TYPE, fightable ? { x: l.x + n.x * D, y, z: l.z + n.z * D } : A); } catch { return null; }
  try {
    e.addTag("mrpg_temp"); e.addTag("mrpg_ds"); e.setDynamicProperty("mrpg:dsOwner", p.id);
    if (fightable) { e.addTag("mrpg_dsg"); e.addTag("mrpg_giant"); e.setDynamicProperty("mrpg:sid", sid); e.setDynamicProperty("mrpg:lv", lv); e.nameTag = `§3海の ぬし §f${SPECIES[sid].name} §7Lv${lv}`; }
    else { e.addTag("mrpg_cine"); (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(e.id); }
    setLook(e, sid, { sz: "G" }); e.triggerEvent("mrpg:aqua_on");
  } catch {}
  const E = { e, sid, fight: fightable, k: 0 }; ENC.set(p.id, E);
  growl(p, close);
  if (fightable) try { p.sendMessage(`§3§l暗い 海の 底から、巨大な 影が 近づいて くる…… §f${SPECIES[sid].name}§3（なぐると 戦える）`); } catch {}
  const N = fightable ? 450 : 200, c0 = { ...l };   /* 影は 20秒かけて ゆっくり 横切る */
  E.iv = system.runInterval(() => {
    E.k++; if (!ok(e) || !ok(p) || E.k > N) { endEnc(p.id); return; }
    let q;
    if (fightable) { const ang = a + E.k * 0.012; q = { x: c0.x + Math.cos(ang) * D, y, z: c0.z + Math.sin(ang) * D }; if (E.k % 60 === 0) growl(p, false); }
    else { const f = E.k / N; q = { x: A.x + (Bq.x - A.x) * f, y: y + Math.sin(f * Math.PI) * 2, z: A.z + (Bq.z - A.z) * f };
      if (close && E.k === N >> 1) { try { p.addEffect("darkness", 50, { showParticles: false }); p.runCommand("camerashake add @s 0.3 0.8 positional"); } catch {} const st = PS.get(p.id); if (st) st.dark = true; growl(p, true); bubbles(p, q, 8); } }
    try { e.teleport(q, { facingLocation: fightable ? { x: c0.x, y, z: c0.z } : Bq }); } catch {}
  }, 2);
  return E;
}
async function nushiFight(p, e) {
  if (!ok(e) || !free(p)) return;
  let sid = "sea00", lv = 56; try { sid = e.getDynamicProperty("mrpg:sid") || sid; lv = e.getDynamicProperty("mrpg:lv") || lv; } catch {}
  for (const [id, E] of ENC) if (E.e === e) endEnc(id);
  if (ok(e)) try { e.remove(); } catch {}
  const name = `海の ぬし ${SPECIES[sid]?.name || ""}`;
  let res = null;
  await holdBusy(p, async () => { try { res = await (DS.fight || fight)(p, { team: [{ sid, lv, q: 0.9, plus: 12, sz: "G" }] }, { tier: 2, fam: "", npc: null, theme: "arena", name, arena: "深海", speaker: name, lines: {}, friends: true }); } catch (x) { console.warn(`[MonsterRPG] ds fight: ${x}`); } });
  const d = load(p); if (!d) return;
  if (res === "win") { const got = giveRew(p, d, { egg: ["aqua"] }); save(p, d); sound(p, "random.levelup", 1); try { p.sendMessage(`§b§l${name} を 倒した！ §fもらった: ${got.join("§f・")}`); } catch {} }
  else { healHalf(p); try { barNote(p).setActionBar("§7深海の 主は 強い……準備を して また 潜ろう"); } catch {} }
}
function healHalf(p) { try { const d = load(p); if (!d) return; for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = Math.max(m.hp, Math.floor(c.hp / 2)); m.mp = Math.max(m.mp, Math.floor(c.mp / 2)); } save(p, d); } catch {} }
HIT_HOOKS.push((p, e) => { if (!e.hasTag("mrpg_dsg")) return false; system.run(() => nushiFight(p, e)); return true; });

/* ---------- アビスクラーケン（船室の 場面 → 戦い → ほうび 1回）---------- */
const KRUN = new Set(); let KLOCK = null;
export const kOf = (p) => { try { const v = p.getDynamicProperty(PK); return typeof v === "number" ? v : 0; } catch { return 0; } };
export async function kraken(p, S) {
  if (KRUN.has(p.id) || kOf(p) >= 2) return false;
  if (KLOCK && KLOCK !== p.id) { try { barNote(p).setActionBar("§7ほかの 人の 出来事が 終わるのを 少し 待とう"); } catch {} return false; }
  KRUN.add(p.id); KLOCK = p.id;
  const G = geo(S), seen = kOf(p) >= 1, acts = [];
  const mon = (sid, at, face) => { let e; try { e = p.dimension.spawnEntity(TYPE, at); } catch { return null; }
    try { (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(e.id); e.addTag("mrpg_cine"); e.addTag("mrpg_temp"); e.addTag("mrpg_ds"); setLook(e, sid, { sz: "G" }); e.triggerEvent("mrpg:aqua_on"); e.teleport(at, { facingLocation: face }); const St = stageOf(p); if (St) addActor(St, e, SPECIES[sid]?.name || sid, at); } catch {}
    acts.push(e); return e; };
  let res = null;
  try {
    await holdBusy(p, async () => {
      await stageBegin(p, { anchor: G.cab, move: true, R: 3, face: G.look });
      try {
        camAt(p, { x: G.cab.x + 2.5, y: G.cab.y + 1.6, z: G.cab.z + 2 }, G.win);
        await tell(p, "深海", seen ? ["§7……また、船が きしんだ。"] : ["§7……船が きしんだ。", "§7窓の 外の 闇が、ゆっくり 動いて いる。"]);
        const K = mon("sea07", G.kr, G.win), T1 = mon("sea03", G.t1, G.win), T2 = mon("sea03", G.t2, G.win);
        growl(p, true); try { p.runCommand("camerashake add @s 0.4 1.2 positional"); } catch {}
        camAt(p, { x: G.win.x, y: G.win.y, z: G.win.z + 1.2 }, ok(K) ? { x: G.kr.x, y: G.kr.y + 3, z: G.kr.z } : G.look);
        await tell(p, "深海", ["§4窓の 向こうから、巨大な 目が のぞきこむ。"]);
        camFade(p); await wait(10);
        camAt(p, { x: G.cab.x - 2.5, y: G.cab.y + 2.4, z: G.cab.z - 1 }, ok(T1) ? T1.location : G.look);
        try { p.addEffect("darkness", 40, { showParticles: false }); } catch {} sound(p, "random.break", 0.5, 0.8);
        await tell(p, "深海", ["§7太い 腕が 船に 巻きつき、板が 悲鳴を あげる。", "§c§l深海の 主「" + (SPECIES.sea07?.name || "クラーケン") + "」！"]);
        try { cineSting(p, "§4§lBATTLE", 26); } catch {} await wait(22); try { camFade(p); } catch {} await wait(9);
      } finally { for (const e of acts) if (ok(e)) try { globalThis.__mqCine?.delete(e.id); e.remove(); } catch {} try { stageEnd(p, true); } catch {} }
      if (!ok(p)) return;
      try { p.setDynamicProperty(PK, Math.max(1, kOf(p))); p.teleport(G.out, { facingLocation: G.kr }); } catch {}
      const lv = Math.min(100, lvAt(S) + 4);
      const foe = [{ sid: "sea07", lv: Math.min(100, lv + 4), q: 1, plus: 30, sz: "G" }, { sid: "sea03", lv, q: 0.8, plus: 15, sz: "G" }].filter((m) => SPECIES[m.sid]);
      try { res = await (DS.fight || fight)(p, { team: foe }, { tier: 3, fam: "", npc: null, theme: "arena", name: "深海の 主", arena: "深海", speaker: "深海の 主", lines: {}, friends: true }); } catch (x) { console.warn(`[MonsterRPG] kraken: ${x}`); }
    });
  } catch (x) { console.warn(`[MonsterRPG] kraken scene: ${x}`); }
  finally { KRUN.delete(p.id); if (KLOCK === p.id) KLOCK = null; }
  if (!ok(p)) return false;
  if (res === "win" && kOf(p) < 2) {
    const d = load(p); if (!d) return false;
    try { p.setDynamicProperty(PK, 2); } catch {}
    const got = giveRew(p, d, { egg: ["aqua"], gear: ["acc", null] });
    if (countItem(p, "mrpg:tms_aqua") <= 0) { giveItem(p, "mrpg:tms_aqua", 1); got.push("§d海の 闘魔石"); } else got.push(boon(p, d, 2));
    d.gold = (d.gold || 0) + 30000; got.push("§e沈没船の 財宝 30000G"); save(p, d);
    sound(p, "random.levelup", 1);
    try { showTitle(p, "§b§l深海の 主を 倒した", { subtitle: "§f海が 静かに なった……", fadeInDuration: 5, stayDuration: 50, fadeOutDuration: 15 }); p.sendMessage(`§b§l深海の 主を 倒した！ §fもらった: ${got.join("§f・")}`); } catch {}
    return true;
  }
  if (res !== "win") { healHalf(p); try { barNote(p).setActionBar("§7負けて しまった……準備を して、また 船室へ 来よう"); } catch {} }
  return false;
}

/* ---------- 見回り（20tick ごと・プレイヤーだけ）---------- */
let TK = 0;
system.runInterval(() => {
  TK++;
  let plist; try { plist = world.getAllPlayers(); } catch { return; }
  const ow = plist.filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
  if (TK % 2 === 0) tryBuild(ow);
  const S = site();
  for (const p of plist) {
    const st0 = PS.get(p.id);
    if (!S || !S.built || !ow.includes(p)) { if (st0 || ENC.has(p.id)) clean(p); continue; }
    const l = p.location;
    if (!inArea(S, l, 140)) { if (st0 || ENC.has(p.id)) clean(p); continue; }
    const st = st0 || { warn: false, dark: false, t: 0, enc: Date.now() - 20000 }; PS.set(p.id, st); st.t++;
    if (busy.has(p.id) || stageOf(p)) continue;
    const uw = underwater(p), gog = hasKey(p, "k_goggle");
    if (uw && !gog && !st.warn && inArea(S, l, 100)) { st.warn = true; try { showTitle(p, "§3ここから 先は 深海", { subtitle: "§7潜水ゴーグルが ないと 息が もたない。深く 潜るのは やめよう", fadeInDuration: 5, stayDuration: 60, fadeOutDuration: 15 }); } catch {} }
    const deep = uw && inTrench(S, l);
    if (deep) {
      DEEP.add(p.id);
      try { p.removeEffect("night_vision"); if (gog) p.addEffect("water_breathing", 320, { showParticles: false }); } catch {}
      if (l.y < S.B + 28 && st.t % 8 === 0) { try { p.addEffect("darkness", 60, { showParticles: false }); } catch {} st.dark = true; }
      if (st.t % 3 === 0) sound(p, pick(["mob.guardian.ambient", "ambient.underwater.loop.additions.rare", "mob.elderguardian.idle"]), 0.4 + Math.random() * 0.3, 0.5);
      if (st.t % 2 === 0) bubbles(p, { x: l.x, y: l.y + 1, z: l.z }, 2);
    } else if (DEEP.has(p.id)) { DEEP.delete(p.id); if (st.dark) { try { p.removeEffect("darkness"); } catch {} st.dark = false; } }
    if (inBox(geo(S).box, { x: l.x, y: l.y + 0.1, z: l.z })) {   /* 船室（空気だまり）*/
      if (kOf(p) < 2 && free(p)) { if (gog) { endEnc(p.id); system.run(() => kraken(p, S)); } else if (st.t % 10 === 1) try { barNote(p).setActionBar("§7暗くて 何も 見えない……§8（潜水ゴーグルが あれば……）"); } catch {} }
      continue;
    }
    if (!ENC.has(p.id) && uw && free(p) && Date.now() - st.enc > 50000 && inArea(S, l, 100) && Math.random() < (deep ? 0.08 : 0.04)) { st.enc = Date.now(); startEnc(p, S); }
  }
}, 20);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { endEnc(playerId); DEEP.delete(playerId); PS.delete(playerId); }); } catch {}
try { world.afterEvents.entityDie.subscribe((ev) => { const e = ev.deadEntity; try { if (e && e.typeId === "minecraft:player") clean(e); } catch {} }); } catch {}

/* ---------- 探索手帳「深海」---------- */
async function guide(p) {
  const S = site(), c = S && S.x !== undefined ? S : cands()[0];
  const where = c ? `§f場所: §bマリノア諸島の 沖§f（およそ X ${Math.round(c.x)}・Z ${Math.round(c.z)}）${S && S.built ? "" : "\n§7まだ 見つかって いない。近くの 海へ 行くと 見つかる"}` : "§7このワールドの マリノアの 沖には 深い 海が 見つからなかった";
  await notice(p, "深海", [where, "", "§f海の 底が 急に 落ちこむ、深い 海溝。§3巨大な 遺跡§fと §3沈んだ 船§fが 眠って いる",
    "§f行き方: マリノア諸島から 外の 海へ 出て、舟や 泳ぎで 沖へ。§6潜水ゴーグル§fが あると 息が 続く（ないと 深くは 潜れない）",
    "§f海溝の 底は 暗い。灯りの 少ない 闇の 中で、§7大きな 影§fに 出会う ことも……（戦える ものも いる）",
    "§f折れた 大きな 船の 中に 入ると…… §7（強い 主が いる。準備を して から）",
    `§7主: ${p && kOf(p) >= 2 ? "§a倒した" : "§7まだ"}`].join("\n"));
}
XT.menu.push(["§b§l深海\n§8マリノア沖の 海溝", guide, "i_zukan"]);

export const __ds = { site, setSite, cands, judge, plan, geo, PS, ENC, KRUN, DEEP, tryBuild, startEnc, endEnc, kraken, clean, kOf, floorAt, reset: () => { SITE = undefined; CANDS = null; BLD = false; FAILT = 0; } };
/* 第125版(vk): 物語 第7章の 貝笛を 吹く 所 = 海溝の 神殿の 前（倒れた 柱と ドームの 戸口の あいだ・底から 2）。saga.js の 案内と 起きる 所 */
DIVE.at = () => { const S = site(); if (S && S.none) return null; if (S && S.F !== undefined) return { x: S.x + 0.5, z: S.z + 18.5, y: S.B + 2, F: S.F, B: S.B, built: !!S.built }; const c = cands()[(S && S.ci) || 0]; return c ? { x: c.x + 0.5, z: c.z + 18.5 } : null; };
