// 第125版: 物語の ダンジョン（地方ごとに ちがう 形）。ブロックの 置き方だけ（世界には さわらない）
// 入口の 目印 → 前室 A → 広い 坂 → 大広間 B（上の 段 B1 と 下の 段 B2・中ほどの 名所）→ 坂 → 仕掛けの 間 C → 坂 → 奥の 大広間（structures.js）
// わき部屋 SL・SR・SC（宝箱）と 隠し部屋 SS（踏み板で 開く・まれな 宝箱）。dir -1 = 地下へ 下る・+1 = 上へ 登る（大樹・浮島）
export const DG_R = 12;   /* 奥の 大広間の 半径（structures.js の CHR と 同じ）*/
/* 地方ごとの 形と 見た目。wb = 中に すむ モンスターの 土地
   第126版(S6): 名前は 本編の 章の 場所に 合わせる（map126）。sc = その ダンジョンで 流れる 物語の 最後の 話（済むまで 奥の 主を 出さない・storydg.js）
   本2-6/7 大樹の 根の 洞くつ／本4-5 鋳造所／本5-8 王墓／本6-4/5 晶洞の 大広間／本8-6/7 霊廟の 奥／本11-4/5 氷の 隠れ家／本13-5〜本14-8 竜骨の 門と 祭壇
   物語の 外（sc なし）: 地下水路・廃都の 地下・潮騒の 灯台・天空の 浮島。本7-5 岬の 灯台（ケープ）・本17 雲の 島は 章の 施設（facAdd）なので 名前を 重ねない */
export const DG_T = {
  arca: { nm: "古い 地下水路", sc: "", dir: -1, sh: ["stone_bricks", "mossy_stone_bricks"], fl: ["stone_bricks", "mossy_stone_bricks"], lt: "sea_lantern", col: "chiseled_stone_bricks", hid: "cracked_stone_bricks", wb: "water", lm: "well", mid: "fountain", gim: "水路の 踏み板" },
  silva: { nm: "大樹の 根の 洞くつ", sc: "b02e7", dir: -1, sh: ["rooted_dirt", "dark_oak_log"], fl: ["moss_block", "rooted_dirt"], lt: "shroomlight", col: "dark_oak_log", hid: "mossy_cobblestone", wb: "forest", lm: "bigtree", mid: "mushroom", gim: "根の 踏み板" },
  ruins: { nm: "廃都の 地下", sc: "", dir: -1, sh: ["stone_bricks", "cracked_stone_bricks"], fl: ["polished_andesite", "cobblestone"], lt: "ochre_froglight", col: "chiseled_stone_bricks", hid: "mossy_stone_bricks", wb: "mountain", lm: "towers", mid: "statue", gim: "玉座の 踏み板" },
  volka: { nm: "六影の 鋳造所", sc: "b04e5", dir: -1, sh: ["blackstone", "basalt"], fl: ["polished_blackstone", "smooth_basalt"], lt: "shroomlight", col: "polished_blackstone_bricks", hid: "gilded_blackstone", wb: "n_basalt", lm: "forge", mid: "lava", gim: "炉の 踏み板" },
  sand: { nm: "砂の 王墓", sc: "b05e8", dir: -1, sh: ["sandstone", "smooth_sandstone"], fl: ["cut_sandstone", "smooth_sandstone"], lt: "ochre_froglight", col: "chiseled_sandstone", hid: "cut_red_sandstone", wb: "desert", lm: "pyramid", mid: "coffin", gim: "王の 踏み板" },
  crys: { nm: "水晶の 洞くつ", sc: "b06e5", dir: -1, sh: ["tuff", "calcite"], fl: ["smooth_basalt", "tuff"], lt: "sea_lantern", col: "spruce_log", hid: "amethyst_block", wb: "cave", lm: "mine", mid: "geode", gim: "水晶の 踏み板", rail: 1 },
  mari: { nm: "潮騒の 灯台と 海蝕洞", sc: "", dir: -1, sh: ["prismarine", "dark_prismarine"], fl: ["prismarine_bricks", "smooth_sandstone"], lt: "sea_lantern", col: "dark_prismarine", hid: "prismarine_bricks", wb: "water", lm: "lighthouse", mid: "ship", gim: "潮の 踏み板", wet: 1 },
  necro: { nm: "冥府の 霊廟", sc: "b08e7", dir: -1, sh: ["polished_blackstone_bricks", "deepslate_bricks"], fl: ["deepslate_tiles", "polished_deepslate"], lt: "pearlescent_froglight", col: "bone_block", hid: "cracked_deepslate_bricks", wb: "n_soul", lm: "tomb", mid: "chapel", gim: "棺の 踏み板" },
  frost: { nm: "氷の 隠れ家", sc: "b11e8", dir: -1, sh: ["packed_ice", "snow"], fl: ["snow", "polished_andesite"], lt: "sea_lantern", col: "blue_ice", hid: "blue_ice", wb: "snow", lm: "icegate", mid: "obelisk", gim: "氷の 踏み板" },
  ragna: { nm: "竜骨の 本拠地", sc: "b14e8", dir: -1, sh: ["purpur_block", "end_stone_bricks"], fl: ["end_stone_bricks", "purpur_block"], lt: "pearlescent_froglight", col: "bone_block", hid: "purpur_pillar", wb: "e_outer", lm: "gate", mid: "ribs", gim: "竜の 踏み板" },
  celes: { nm: "天空の 浮島", sc: "", dir: 1, L0: 10, open: 1, sh: ["smooth_quartz", "quartz_bricks"], fl: ["quartz_bricks", "smooth_quartz"], lt: "sea_lantern", col: "quartz_pillar", hid: "gold_block", fence: "birch_fence", wb: "mountain", lm: "arch", mid: "garden", gim: "風の 踏み板" },
};
export const dgType = (id) => DG_T[id] || DG_T.arca;
/* 部屋の 高さ（F = 奥の 大広間の 床）。down: A=F+16 B1=F+12 B2=F+8 C=F+4 ／ up: A=F-16 … */
export function dgFloors(t, F) { const s = t.dir; return { A: F - 16 * s, B1: F - 12 * s, B2: F - 8 * s, C: F - 4 * s, H: F }; }
/* 部屋の 天井の 上（床からの 差）: 地下は 地面より 4 下に 入れる */
export const DG_TOP = { A: 23, B: 22, SL: 17, SR: 13, C: 11, S: 9, H: 13 };
/* 部屋の 置き場（入口 x,z からの ずれ。L0 = 入口の 階段の 長さ）*/
export function dgRooms(L0) {
  return {
    A: { x1: -6, x2: 6, z1: L0, z2: L0 + 12 },
    B1: { x1: -8, x2: 8, z1: L0 + 19, z2: L0 + 28 },
    B2: { x1: -8, x2: 8, z1: L0 + 29, z2: L0 + 41 },
    C: { x1: -6, x2: 6, z1: L0 + 48, z2: L0 + 60 },
    SL: { x1: -18, x2: -10, z1: L0 + 19, z2: L0 + 27 },
    SR: { x1: 10, x2: 18, z1: L0 + 32, z2: L0 + 40 },
    SC: { x1: -16, x2: -8, z1: L0 + 50, z2: L0 + 58 },
    SS: { x1: 8, x2: 16, z1: L0 + 50, z2: L0 + 58 },
    hz: L0 + 67 + DG_R,
  };
}
export const dgL0 = (t, y, F) => (t.dir < 0 ? y - F - 16 : t.L0 || 0);
/* 全体の 四角（ずれ）*/
export function dgBoxL(L0) { return { x1: -20, x2: 20, z1: -8, z2: L0 + 67 + 2 * DG_R + 3 }; }
/* 地面の 高さを 見る 点（ずれ・天井の 差）*/
export function dgProbe(L0) {
  const R = dgRooms(L0), out = [];
  for (const [k, top] of [["A", DG_TOP.A], ["B1", DG_TOP.B], ["B2", DG_TOP.B], ["C", DG_TOP.C], ["SL", DG_TOP.SL], ["SR", DG_TOP.SR], ["SC", DG_TOP.S], ["SS", DG_TOP.S]]) { const r = R[k]; for (const [a, b] of [[r.x1, r.z1], [r.x2, r.z2], [(r.x1 + r.x2) >> 1, (r.z1 + r.z2) >> 1], [r.x1, r.z2], [r.x2, r.z1]]) out.push([a, b, top]); }
  for (const [a, b] of [[0, 0], [14, 0], [-14, 0], [0, 14], [0, -14], [10, 10], [-10, 10], [10, -10], [-10, -10]]) out.push([a, R.hz + b, DG_TOP.H]);
  return out;
}
/* コマンドを 作る。x,y,z = 入口の 床。F = 奥の 大広間の 床。もどり: shell（外側を 固める）・carve（くりぬく）・deco（飾り・宝箱）と 記録 */
export function dgBuild(id, x, y, z, F) {
  const t = dgType(id), s = t.dir, L0 = dgL0(t, y, F), R = dgRooms(L0), fl = dgFloors(t, F), O = !!t.open;
  const SH = [], CV = [], DC = [];
  const box = (L, a, b, c, d, e, f, blk, m) => {
    let [x1, x2] = [Math.min(a, d), Math.max(a, d)], [y1, y2] = [Math.min(b, e), Math.max(b, e)], [z1, z2] = [Math.min(c, f), Math.max(c, f)];
    const split = (p, q, r, u, v, w) => { const vol = (u - p + 1) * (v - q + 1) * (w - r + 1); if (vol <= 32768) { L.push(`fill ${x + p} ${q} ${z + r} ${x + u} ${v} ${z + w} ${blk}${m ? " " + m : ""}`); return; } if (u - p >= w - r) { const mx = (p + u) >> 1; split(p, q, r, mx, v, w); split(mx + 1, q, r, u, v, w); } else { const mz = (r + w) >> 1; split(p, q, r, u, v, mz); split(p, q, mz + 1, u, v, w); } };
    split(x1, y1, z1, x2, y2, z2);
  };
  const sb = (L, a, b, c, blk) => L.push(`setblock ${x + a} ${b} ${z + c} ${blk}`);
  const top = { A: fl.A + 7, B: Math.max(fl.B1, fl.B2) + 10, C: fl.C + 7 };
  const rooms = [["A", fl.A, top.A], ["B1", fl.B1, top.B], ["B2", fl.B2, top.B], ["C", fl.C, top.C], ["SL", fl.B1, fl.B1 + 5], ["SR", fl.B2, fl.B2 + 5], ["SC", fl.C, fl.C + 5], ["SS", fl.C, fl.C + 4]];
  const base = y - 4;
  /* ---- 1. 外側 ---- */
  for (const [k, f, tp] of rooms) {
    const r = R[k];
    if (O) { box(SH, r.x1, f - 2, r.z1, r.x2, f - 1, r.z2, t.fl[0]); box(SH, r.x1 + 2, f - 4, r.z1 + 2, r.x2 - 2, f - 3, r.z2 - 2, t.sh[1]); if (r.x2 - r.x1 > 8) box(SH, r.x1 + 4, f - 6, r.z1 + 4, r.x2 - 4, f - 5, r.z2 - 4, "stone"); }
    else { if (s > 0 && f - 2 >= base) box(SH, r.x1 - 1, base, r.z1 - 1, r.x2 + 1, f - 2, r.z2 + 1, t.base || t.sh[0]); box(SH, r.x1 - 1, f - 1, r.z1 - 1, r.x2 + 1, tp + 1, r.z2 + 1, k === "SS" ? t.sh[1] : t.sh[0]); }
  }
  /* 坂（入口の 階段・A→B・B→C・C→奥）: 1マスで 1段 */
  const corr = [];
  for (let k = 0; k < L0; k++) corr.push([k, s > 0 ? y + k : y - k]);
  const ramp = (z0, f0) => { for (let j = 0; j < 6; j++) corr.push([z0 + j, f0 + s * Math.min(4, j + 1)]); };
  ramp(R.A.z2 + 1, fl.A); ramp(R.B2.z2 + 1, fl.B2); ramp(R.C.z2 + 1, fl.C);
  for (const [dz, f] of corr) {
    if (O) { box(SH, -2, f - 1, dz, 2, f - 1, dz, t.fl[0]); box(SH, -1, f - 2, dz, 1, f - 2, dz, t.sh[1]); }
    else { if (s > 0 && f - 2 >= base) box(SH, -3, base, dz, 3, f - 2, dz, t.base || t.sh[0]); box(SH, -3, f - 1, dz, 3, f + 5, dz, t.sh[dz % 9 === 4 ? 1 : 0]); }
  }
  landmark(t, { SH, CV, DC, box, sb, y, L0, R, fl });
  /* ---- 2. くりぬく ---- */
  for (const [k, f, tp] of rooms) { const r = R[k]; box(CV, r.x1, f, r.z1, r.x2, O ? f + 9 : tp, r.z2, "air"); box(CV, r.x1, f - 1, r.z1, r.x2, f - 1, r.z2, t.fl[0]); }
  for (const [dz, f] of corr) { box(CV, -2, f, dz, 2, f + 4, dz, "air"); box(CV, -2, f - 1, dz, 2, f - 1, dz, dz % 5 === 2 ? t.fl[1] : t.fl[0]); }
  box(CV, -2, y, -3, 2, y + 4, -1, "air"); box(CV, -2, y - 1, -3, 2, y - 1, -1, t.fl[0]);   /* 入口の 口 */
  for (const [a, b, c, d, e, f] of [[-2, y - 4, -3, 2, y - 2, -1]]) for (const w of ["air", "water", "flowing_water"]) box(CV, a, b, c, d, e, f, t.sh[0], `replace ${w}`);
  /* わき部屋の 戸（3マス）*/
  const door = (xx, f, zc) => { box(CV, xx, f, zc - 1, xx, f + 2, zc + 1, "air"); box(CV, xx, f - 1, zc - 1, xx, f - 1, zc + 1, t.fl[1]); };
  door(-9, fl.B1, L0 + 23); door(9, fl.B2, L0 + 39); door(-7, fl.C, L0 + 54);
  if (O) door(7, fl.C, L0 + 54);
  /* B1 と B2 の 段差（まん中 7マスの 階段・ほかは 柵）*/
  const hiF = Math.max(fl.B1, fl.B2), loF = Math.min(fl.B1, fl.B2);
  for (let j = 0; j < 3; j++) { const zz = s < 0 ? R.B2.z1 + j : R.B1.z2 - j; box(CV, -3, loF - 1, zz, 3, hiF - 2 - j, zz, t.fl[1]); }
  const edgeZ = s < 0 ? R.B1.z2 : R.B2.z1, fen = t.fence || (t.sh[0].includes("blackstone") ? "blackstone_wall" : t.sh[0].includes("stone_brick") ? "stone_brick_wall" : t.sh[0].includes("deepslate") ? "deepslate_brick_wall" : t.sh[0].includes("sandstone") ? "sandstone_wall" : t.sh[0].includes("prismarine") ? "prismarine_wall" : t.sh[0].includes("purpur") || t.sh[0].includes("end_stone") ? "end_stone_brick_wall" : t.sh[0].includes("tuff") ? "cobblestone_wall" : "oak_fence");
  box(DC, -8, hiF, edgeZ, -4, hiF, edgeZ, fen); box(DC, 4, hiF, edgeZ, 8, hiF, edgeZ, fen);
  /* ---- 3. 飾り・灯り ---- */
  for (const [k, f, tp] of rooms) {
    const r = R[k], w = r.x2 - r.x1;
    if (O) { box(DC, r.x1, f, r.z1, r.x2, f, r.z1, fen); box(DC, r.x1, f, r.z2, r.x2, f, r.z2, fen); box(DC, r.x1, f, r.z1, r.x1, f, r.z2, fen); box(DC, r.x2, f, r.z1, r.x2, f, r.z2, fen); for (const [a, c] of [[r.x1, r.z1], [r.x2, r.z1], [r.x1, r.z2], [r.x2, r.z2]]) sb(DC, a, f, c, t.lt); continue; }
    for (let zz = r.z1 + 1; zz < r.z2; zz += 4) { sb(DC, r.x1 - 1, f + 3, zz, t.lt); sb(DC, r.x2 + 1, f + 3, zz, t.lt); }
    if (w >= 12) { box(DC, -1, tp + 1, ((r.z1 + r.z2) >> 1) - 1, 0, tp + 1, (r.z1 + r.z2) >> 1, t.lt); }
    if (w >= 12 && k !== "B2") for (const [a, c] of [[r.x1 + 1, r.z1 + 2], [r.x2 - 2, r.z1 + 2], [r.x1 + 1, r.z2 - 3], [r.x2 - 2, r.z2 - 3]]) { box(DC, a, f, c, a + 1, tp, c + 1, t.col); sb(DC, a, f + 4, c, t.lt); }
  }
  for (const [dz, f] of corr) if (dz % 4 === 2 && !O) sb(DC, dz % 8 === 2 ? -3 : 3, f + 2, dz, t.lt);
  if (O) for (const [dz, f] of corr) { sb(DC, -2, f, dz, fen); sb(DC, 2, f, dz, fen); }
  if (O) { box(DC, -2, fl.A, R.A.z1, 2, fl.A + 1, R.A.z1, "air"); for (const [zz, f] of [[R.A.z2, fl.A], [R.B1.z1, fl.B1], [R.B2.z2, fl.B2], [R.C.z1, fl.C], [R.C.z2, fl.C]]) box(DC, -2, f, zz, 2, f + 1, zz, "air"); box(DC, -3, hiF, edgeZ, 3, hiF, edgeZ, "air"); box(DC, -8, fl.B1, R.B1.z2, 8, fl.B1, R.B1.z2, "air"); box(DC, -8, fl.B2, R.B2.z1, 8, fl.B2, R.B2.z1, "air"); box(DC, -8, hiF, edgeZ, -4, hiF, edgeZ, fen); box(DC, 4, hiF, edgeZ, 8, hiF, edgeZ, fen);
    for (const [xx, f, zc] of [[-9, fl.B1, L0 + 23], [9, fl.B2, L0 + 39], [-7, fl.C, L0 + 54], [7, fl.C, L0 + 54]]) { const g = Math.sign(xx); box(DC, xx - g, f, zc - 1, xx + g, f + 1, zc + 1, "air"); box(DC, xx, f - 1, zc - 1, xx, f - 1, zc + 1, t.fl[1]); } }
  /* 中ほどの 名所（B2 の まん中）と テーマの 飾り */
  const cz = R.B2.z1 + 7; mid(t, { DC, box, sb, f: fl.B2, cz, R, fl, fen });
  if (t.rail) { for (const [dz, f] of corr) if (corr.filter((q) => q[1] === f).length > 1 && dz > L0) sb(DC, -2, f, dz, "rail"); box(DC, -6, fl.A, R.A.z1 + 1, -6, fl.A, R.A.z2 - 1, "rail"); box(DC, 6, fl.C, R.C.z1, 6, fl.C, R.C.z1 + 3, "rail"); for (const k of ["SL", "SC"]) { const r = R[k]; box(DC, r.x1, k === "SL" ? fl.B1 : fl.C, r.z1, r.x1, k === "SL" ? fl.B1 + 4 : fl.C + 4, r.z1, "spruce_log"); box(DC, r.x2, k === "SL" ? fl.B1 : fl.C, r.z1, r.x2, k === "SL" ? fl.B1 + 4 : fl.C + 4, r.z1, "spruce_log"); } }
  if (t.wet) { box(DC, -6, fl.A - 2, R.A.z1 + 2, 6, fl.A - 2, R.A.z2 - 2, t.sh[0]); box(DC, -6, fl.C - 2, R.C.z1 + 1, 6, fl.C - 2, R.C.z1 + 3, t.sh[0]); box(DC, -6, fl.A - 1, R.A.z1 + 2, -5, fl.A - 1, R.A.z2 - 2, "water"); box(DC, 5, fl.A - 1, R.A.z1 + 2, 6, fl.A - 1, R.A.z2 - 2, "water"); box(DC, -6, fl.C - 1, R.C.z1 + 1, -4, fl.C - 1, R.C.z1 + 3, "water"); box(DC, 4, fl.C - 1, R.C.z1 + 1, 6, fl.C - 1, R.C.z1 + 3, "water"); }
  /* 仕掛けの 間: 床の 模様の まん中に 踏み板。右の 壁（x 7）は 隠し戸 */
  const pz = L0 + 54;
  for (const [a, c] of [[-2, -2], [2, -2], [-2, 2], [2, 2], [0, -3], [0, 3], [-3, 0], [3, 0]]) sb(DC, a, fl.C - 1, pz + c, t.col);
  sb(DC, 0, fl.C - 1, pz, t.hid); sb(DC, 0, fl.C, pz, "stone_pressure_plate");
  if (!O) { box(DC, 7, fl.C, pz - 1, 7, fl.C + 2, pz + 1, t.hid); sb(DC, 6, fl.C + 3, pz - 2, t.lt); sb(DC, 6, fl.C + 3, pz + 2, t.lt); }
  else box(DC, 7, fl.C, pz - 1, 7, fl.C + 2, pz + 1, t.hid);
  /* わき部屋・隠し部屋の 灯り（O は 柵の 角） */
  if (!O) for (const k of ["SL", "SR", "SC", "SS"]) { const r = R[k], f = k === "SL" ? fl.B1 : k === "SR" ? fl.B2 : fl.C; sb(DC, (r.x1 + r.x2) >> 1, f + (k === "SS" ? 4 : 5), (r.z1 + r.z2) >> 1, t.lt); }
  /* 宝箱: A の 角・SL・SR・SC の 奥・B2 の 奥の 角 ／ 隠し部屋 SS の まれな 箱 */
  const ch = [[-5, fl.A, L0 + 1, 0], [-17, fl.B1, L0 + 23, 0], [17, fl.B2, L0 + 36, 0], [-15, fl.C, L0 + 54, 0], [-7, fl.B2, R.B2.z2, 0], [15, fl.C, pz, 1]];
  for (const [a, b, c, rare] of ch) { sb(DC, a, b, c, rare ? "ender_chest" : "chest"); }
  if (O) box(DC, 7, fl.C - 1, pz - 1, 7, fl.C - 1, pz + 1, t.fl[0]);
  /* 記録 */
  const A = (a, b, c) => [x + a, b, z + c];
  const sp = [[0, fl.A, L0 + 8], [-4, fl.B1, L0 + 24], [4, fl.B1, L0 + 21], [-5, fl.B2, L0 + 39], [5, fl.B2, L0 + 40], [-3, fl.C, L0 + 57], [-14, fl.B1, L0 + 23], [14, fl.B2, L0 + 36], [-12, fl.C, L0 + 54]].map(([a, b, c]) => A(a, b, c));
  const BL = dgBoxL(L0), yLo = Math.min(y, F) - 8, yHi = Math.max(y + 18, F + DG_R + 6);
  return {
    shell: SH, carve: CV, deco: DC, hx: x, hz: z + R.hz, L0, t,
    info: { dt: id, dir: s, ...(O ? { open: 1 } : {}), box: { x1: x + BL.x1, x2: x + BL.x2, z1: z + BL.z1, z2: z + BL.z2, y1: yLo, y2: yHi }, ch: ch.map(([a, b, c, r]) => [...A(a, b, c), r]), sp, plate: A(0, fl.C, pz), gate: [x + 7, fl.C, z + pz - 1, x + 7, fl.C + 2, z + pz + 1], rooms: rooms.map(([k, f, tp]) => [k, x + R[k].x1, f, z + R[k].z1, x + R[k].x2, tp, z + R[k].z2]) },
    area: [{ x: x + BL.x1, y: yLo, z: z + BL.z1 }, { x: x + BL.x2, y: yHi, z: z + BL.z2 }],
    corr,
  };
}
/* 入口の 目印（外側の とき）。口（x -2..2, z -3..-1）と 入口の 階段は あとで くりぬく */
function landmark(t, { SH, CV, DC, box, sb, y, L0, R }) {
  const g = (blk) => { box(SH, -4, y - 1, -3, 4, y + 6, 6, blk); };
  const pil = (a, c, h, blk, cap) => { box(SH, a, y, c, a, y + h, c, blk); if (cap) sb(DC, a, y + h + 1, c, cap); };
  switch (t.lm) {
    case "pyramid": for (let k = 0; k < 7; k++) box(SH, -8 + k, y - 1 + k, -4 + k, 8 - k, y - 1 + k, 11 - k, k % 2 ? "smooth_sandstone" : "sandstone"); sb(DC, 0, y + 7, 4, "gold_block"); pil(-3, -4, 3, "chiseled_sandstone", "ochre_froglight"); pil(3, -4, 3, "chiseled_sandstone", "ochre_froglight"); break;
    case "lighthouse": g("prismarine_bricks"); for (let k = 0; k < 16; k++) box(SH, 6, y - 1 + k, 0, 9, y - 1 + k, 3, (k >> 2) % 2 ? "red_concrete" : "white_concrete"); box(SH, 6, y + 15, 0, 9, y + 15, 3, "glass"); box(SH, 7, y + 15, 1, 8, y + 15, 2, "sea_lantern"); box(SH, 5, y + 16, -1, 10, y + 16, 4, "dark_prismarine"); pil(-4, -4, 3, "dark_prismarine", "sea_lantern"); pil(4, -4, 3, "dark_prismarine", "sea_lantern"); break;
    case "towers": g("stone_bricks"); for (const a of [-8, 6]) { box(SH, a, y - 1, -4, a + 2, y + (a < 0 ? 9 : 6), -2, "cracked_stone_bricks"); sb(DC, a + 1, y + (a < 0 ? 10 : 7), -3, "mossy_cobblestone"); } box(SH, -5, y + 7, -3, 5, y + 7, -3, "stone_brick_slab"); pil(-3, -4, 4, "chiseled_stone_bricks", "lantern"); pil(3, -4, 4, "chiseled_stone_bricks", "lantern"); break;
    case "forge": g("polished_blackstone_bricks"); for (const a of [-4, 4]) { box(SH, a, y + 7, 4, a, y + 11, 4, "blackstone"); sb(DC, a, y + 12, 4, "campfire"); } pil(-3, -4, 3, "polished_blackstone_bricks", "soul_lantern"); pil(3, -4, 3, "polished_blackstone_bricks", "soul_lantern"); break;
    case "mine": g("tuff"); for (const a of [-3, 3]) box(SH, a, y, -4, a, y + 4, -4, "spruce_log"); box(SH, -3, y + 5, -4, 3, y + 5, -4, "spruce_planks"); sb(DC, 0, y + 4, -4, "lantern"); for (let k = 0; k < 5; k++) sb(DC, 5 + (k % 2), y + k, 1, "amethyst_block"); break;
    case "tomb": g("polished_blackstone_bricks"); for (let k = 0; k < 4; k++) box(SH, -5 + k, y + 7 + k, -4 + k, 5 - k, y + 7 + k, 7 - k, "deepslate_tiles"); pil(-3, -4, 3, "bone_block", "soul_lantern"); pil(3, -4, 3, "bone_block", "soul_lantern"); break;
    case "icegate": g("packed_ice"); for (const [a, h] of [[-5, 8], [5, 7], [-6, 5], [6, 4]]) box(SH, a, y, 2, a, y + h, 2, "blue_ice"); pil(-3, -4, 3, "blue_ice", "sea_lantern"); pil(3, -4, 3, "blue_ice", "sea_lantern"); break;
    case "gate": g("end_stone_bricks"); pil(-4, -3, 4, "purpur_pillar", null); pil(4, -3, 4, "purpur_pillar", null); sb(DC, -4, y + 5, -3, "end_rod"); sb(DC, 4, y + 5, -3, "end_rod"); break;   /* 竜骨の 門（広間の 小道具）が 口の 前に 立つ */
    case "well": g("mossy_stone_bricks"); box(SH, -4, y + 7, -3, 4, y + 7, 6, "stone_brick_slab"); pil(-3, -4, 3, "chiseled_stone_bricks", "lantern"); pil(3, -4, 3, "chiseled_stone_bricks", "lantern"); box(DC, 6, y - 1, -2, 8, y - 1, 0, "stone_bricks"); sb(DC, 7, y, -1, "water"); box(DC, 6, y, -2, 8, y, -2, "stone_brick_wall"); break;
    case "roots": for (const [a, c] of [[-8, 0], [8, 2], [-7, 10], [7, 11], [0, 14]]) box(SH, a - 1, y - 2, c - 1, a + 1, y + 2, c + 1, "dark_oak_log"); box(CV, -2, y, -1, 2, y + 4, -1, "air"); box(CV, -2, y - 1, -1, 2, y - 1, -1, t.fl[0]); pil(-3, -2, 4, "oak_log", "shroomlight"); pil(3, -2, 4, "oak_log", "shroomlight"); break;
    case "bigtree": box(SH, -4, y - 1, -2, 4, y + 15, 6, "dark_oak_log"); box(SH, -9, y + 13, -7, 9, y + 18, 11, "dark_oak_leaves", "keep"); box(SH, -5, y + 19, -3, 5, y + 20, 7, "dark_oak_leaves", "keep"); for (const [a, c] of [[-6, -1], [6, 0], [-6, 5], [6, 6], [0, 8]]) box(SH, a - 1, y - 1, c - 1, a + 1, y + 1, c + 1, "dark_oak_log"); pil(-3, -3, 2, "dark_oak_log", "shroomlight"); pil(3, -3, 2, "dark_oak_log", "shroomlight"); break;
    case "arch": for (const a of [-3, 3]) box(SH, a, y, -2, a, y + 6, -2, "quartz_pillar"); box(SH, -3, y + 7, -2, 3, y + 7, -2, "gold_block"); box(SH, -2, y - 1, -3, 2, y - 1, -1, "quartz_bricks"); break;
    default: g(t.sh[0]);
  }
  void R; void L0;
}
/* 中ほどの 名所（B2 の まん中・cz）*/
function mid(t, { DC, box, sb, f, cz, R, fl, fen }) {
  switch (t.mid) {
    case "fountain": box(DC, -1, f - 1, cz - 1, 1, f - 1, cz + 1, "stone_bricks"); box(DC, -2, f, cz - 2, 2, f, cz + 2, "stone_bricks"); box(DC, -1, f, cz - 1, 1, f, cz + 1, "water"); box(DC, 0, f, cz, 0, f + 2, cz, "chiseled_stone_bricks"); sb(DC, 0, f + 3, cz, "sea_lantern"); break;
    case "mushroom": box(DC, 0, f, cz, 0, f + 3, cz, "mushroom_stem"); box(DC, -2, f + 4, cz - 2, 2, f + 4, cz + 2, "red_mushroom_block"); sb(DC, 0, f + 4, cz, "shroomlight"); box(DC, -6, f, cz - 3, -5, f, cz + 3, "moss_carpet"); break;
    case "statue": box(DC, -1, f, cz - 1, 1, f, cz + 1, "polished_andesite"); box(DC, 0, f + 1, cz, 0, f + 4, cz, "stone_bricks"); sb(DC, 0, f + 5, cz, "chiseled_stone_bricks"); box(DC, 2, f, cz + 1, 3, f, cz + 2, "cracked_stone_bricks"); sb(DC, 2, f + 1, cz + 1, "stone_brick_slab"); break;
    case "lava": {   /* 溶岩の 池と 5マスの 橋（左右の 池・橋の ふちは 壁）*/
      const z1 = R.B2.z1 + 3, z2 = R.B2.z2 - 5;
      for (const [a, b] of [[-8, -4], [4, 8]]) { box(DC, a, f - 2, z1, b, f - 2, z2, "basalt"); box(DC, a, f - 1, z1, b, f - 1, z2, "lava"); }
      box(DC, -3, f, z1, -3, f, z2, fen); box(DC, 3, f, z1, 3, f, z2, fen); box(DC, -3, f - 1, z1, -3, f - 1, z2, "polished_blackstone_bricks"); box(DC, 3, f - 1, z1, 3, f - 1, z2, "polished_blackstone_bricks");
      sb(DC, -6, f + 9, cz, "shroomlight"); sb(DC, 6, f + 9, cz, "shroomlight"); break; }
    case "coffin": box(DC, -1, f, cz - 2, 1, f, cz + 2, "chiseled_sandstone"); sb(DC, 0, f + 1, cz, "gold_block"); for (const [a, c] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) { box(DC, a, f, cz + c, a, f + 2, cz + c, "cut_sandstone"); sb(DC, a, f + 3, cz + c, "ochre_froglight"); } break;
    case "geode": box(DC, -3, f, cz - 3, 3, f + 6, cz + 3, "calcite", "hollow"); box(DC, -2, f + 1, cz - 2, 2, f + 5, cz + 2, "amethyst_block", "hollow"); box(DC, -1, f + 2, cz - 1, 1, f + 4, cz + 1, "air"); sb(DC, 0, f + 2, cz, "sea_lantern"); sb(DC, 0, f + 3, cz, "amethyst_cluster"); box(DC, -3, f + 2, cz, -2, f + 3, cz, "air"); box(DC, 2, f + 2, cz, 3, f + 3, cz, "air"); box(DC, -4, f, cz - 4, -4, f, cz + 4, "smooth_basalt"); break;
    case "ship": box(DC, -2, f, cz - 3, 2, f + 1, cz + 3, "spruce_planks", "hollow"); box(DC, -1, f + 1, cz - 2, 1, f + 1, cz + 2, "air"); box(DC, 0, f + 1, cz, 0, f + 7, cz, "spruce_log"); box(DC, -2, f + 4, cz, 2, f + 6, cz, "white_wool"); box(DC, -7, f - 2, cz - 2, 7, f - 2, cz + 2, t.sh[0]); box(DC, -7, f - 1, cz - 2, -5, f - 1, cz + 2, "water"); box(DC, 5, f - 1, cz - 2, 7, f - 1, cz + 2, "water"); break;
    case "chapel": box(DC, -2, f, cz + 2, 2, f, cz + 3, "polished_blackstone"); for (const a of [-2, 0, 2]) sb(DC, a, f + 1, cz + 2, 'candle ["candles"=3,"lit"=true]'); box(DC, -3, f, cz + 4, -3, f + 4, cz + 4, "bone_block"); box(DC, 3, f, cz + 4, 3, f + 4, cz + 4, "bone_block"); for (const a of [-6, 5]) for (const c of [-3, 0]) box(DC, a, f, cz + c, a + 1, f, cz + c, "deepslate_tile_slab"); sb(DC, 0, f, cz - 1, "soul_lantern"); break;
    case "obelisk": box(DC, -1, f, cz - 1, 1, f + 8, cz + 1, "blue_ice"); sb(DC, 0, f + 9, cz, "sea_lantern"); for (const [a, c, h] of [[-4, -3, 2], [4, 2, 3], [-3, 4, 1], [3, -4, 2]]) box(DC, a, f, cz + c, a, f + h, cz + c, "packed_ice"); break;
    case "ribs": for (let k = 0; k < 4; k++) { const zz = cz - 4 + k * 3; box(DC, -6, f, zz, -6, f + 6, zz, "bone_block"); box(DC, 6, f, zz, 6, f + 6, zz, "bone_block"); box(DC, -5, f + 7, zz, 5, f + 7, zz, "bone_block"); } box(DC, -1, f, cz + 5, 1, f + 1, cz + 5, "bone_block"); break;
    case "garden": box(DC, -2, f - 1, cz - 2, 2, f - 1, cz + 2, "grass_block"); box(DC, 0, f, cz, 0, f + 3, cz, "cherry_log"); box(DC, -2, f + 4, cz - 2, 2, f + 5, cz + 2, "cherry_leaves"); sb(DC, -1, f, cz + 2, "pink_petals"); box(DC, -6, f, cz - 3, -6, f + 3, cz - 3, "quartz_pillar"); sb(DC, -6, f + 4, cz - 3, "gold_block"); break;
  }
  void fl;
}
