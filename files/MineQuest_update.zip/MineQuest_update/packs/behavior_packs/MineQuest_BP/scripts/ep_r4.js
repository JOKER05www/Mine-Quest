/* 第125版: 第5地方 サンドリア の 5話（オアシスの 村 ミラージュ・サンドリア城）
   1話 オアシスの 市（市の 外れ）→ 2話 濡れ衣の たね（夜の 街道）→ 3話 今の 段「城門・地下牢・玉座の 間」
   → 4話 セリーヌの 証拠（城の 中庭）→ 5話 今の 段「王墓」→ 5話 つづき セリーヌの 店（市が 開く）
   書き方は ep_r0.js の 頭の 説明の とおり */
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, bldOf, farOf } from "./storyplace.js";
import { fac, facAt, facSide, facFront, facMark } from "./epfac.js";
import { world } from "@minecraft/server";
import { groundY, townAt } from "./structures.js";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok } from "./ui.js";

/* ---------- 場所 ---------- */
const MEMO = new Map();
const tOut = (k, turn, nm) => () => { if (MEMO.has(k)) return MEMO.get(k); const o = townOut("t6", turn, nm); const v = o ? { x: o.x, z: o.z, nm: o.nm } : null; if (v) MEMO.set(k, v); return v; };
const MKOUT = tOut("mk", 0.4, "外れの オアシスの 市");
const MARKET = () => bldOf("t6", ["plaza", "inn"], "オアシスの 村 ミラージュの 市") || MKOUT();   /* 第125版(pl): 市は 村の 広場（屋台と 家が ならぶ）*/
const SHOP = () => bldOf("t6", ["shop", "eggs"], "ミラージュの 砂星商会") || MKOUT();   /* 第125版(pl): セリーヌの 店は 村の 店（古い 町では 外れに 店先を 建てる）*/
const ROAD = () => { const f = farOf("r4road", "t6", "サンドリアの 夜の 街道", 90, 300); if (f) return f; const q = placeOf("road", 4); return q ? { x: q.x, z: q.z, nm: "サンドリアの 夜の 街道" } : tOut("rd", -1.2, "外れの 砂丘")(); };   /* 第127版(fac2): 町から 離れた 街道の 関所 */
const COURT = () => { const q = placeOf("court", 4); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm || "サンドリア城の 中庭" } : null; };
/* 第125版(rs): ―― そのころ。六影の 卓（名前も 札も 出さない。第9章の 前ふり）。「二の座」は 空席・命令書は『参謀』とだけ（セオは 同じ ころ 城門で 待って いる）*/
async function sixCut(p, K, y0) {
  const S = K.S(p); if (!S) return; const A0 = { ...S.P }, LK = S.at(4, 0, 1);
  const R = facAt("r4six", p.location, 90) || facSide(p, S, 34, "r4six", "sixroom", 7, y0) || facSide(p, S, -34, "r4six", "sixroom", 7, y0); if (!R) return;
  const M = (n) => facMark("r4six", n, p.location), T = M("table"), SN = M("snow"), MK = M("mask"), RP = M("rep"), SE = M("seat2");
  await K.moveTo(p, facFront("r4six", 4), "", [], R, 10);
  await K.offstage(p, async (V, C) => {   /* 第127版: 主人公の いない 場面（あなた・仲間は 映さない。役者は 暗い うちに 置く）*/
  const { eV, eA, t1, t2 } = C;
  for (const e of [t1, t2]) K.act(e, "hold"); K.act(eA, "arms");
  await K.at(p, T, 18, 6, 1.6);   /* 六つの 席の 卓 */
  await K.say(p, "赤い 外套の 女", ["{closed,low}……報告するよ。砂の 町の 手下は、もう すぐ 捕まる。何も 知らないから、何も しゃべれや しない。"]);
  if (SN) { K.burst(p.dimension, SN, "minecraft:snowflake_particle", 8, 0.8, 1.2); await K.at(p, SN, 18, 3.2, 1.2); }
  await K.narr(p, ["§7雪あかりの 窓べで、二つの 小さな 影が、手を つないで いる。"], SN);
  if (ok(eA)) await K.push(p, eA, 22, 4, 1.8, 1.5);   /* 影の 中の 白い 仮面 */
  await K.say(p, "白い 仮面", ["{closed,low}……参謀は。"]);
  await K.say(p, "赤い 外套の 女", ["{closed}来ないよ。いつもの とおり、手紙だけさ。"]);
  if (T) { K.sound(p, "item.book.page_turn", 0.7); await K.at(p, T, 16, 1.8, 0.2); }
  await K.narr(p, ["§7卓の 上に、封を された 命令書。差出人の 名は なく、ただ『参謀』とだけ ある。"], T);
  if (SE) await K.push(p, SE, 26, 4, 1.6, 1);
  await K.narr(p, ["§7紫の 布の 椅子――『二の座』は、今夜も 空いて いた。"], SE);
  K.setFlag(p, "six5");
  await K.moveTo(p, A0, "サンドリアの 夜の 街道", [eV, eA, t1, t2], LK, 12);
  }, { here: true, card: "§7―― そのころ　どこかの 地下", cast: async () => ({ eV: await K.put(p, "§c赤い 外套の 女", RP, SE, K.PJ("valka", 9)), eA: await K.put(p, "§8白い 仮面", MK, T, K.PJ("argo", 9)), t1: await K.put(p, "§8小さな 影", SN, T, 6), t2: await K.put(p, "§8小さな 影§r", SN && { x: SN.x + 0.9, y: SN.y, z: SN.z + 0.9 }, T, 6) }) });
}
const near = (f, dx, dz) => () => { const q = f(); return q ? { x: q.x + dx, y: q.y, z: q.z + dz } : null; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("r4celine", { nm: "セリーヌ", role: "商家の", gobi: "ですわ", skin: "zenia", town: "t6", from: "r4e1", at: near(SHOP, 3, -3),
  pre: ["{smile}ごきげんよう。砂星商会の セリーヌですわ。"],
  after: [
    [(s) => !!s.heroBack, ["{smile,☆}あら、お二人そろって！ ……ええ、ええ、知って いましたわ。あなた方なら、きっと 取りもどすと。", "{smile}今日は 店じゅうの 品を 半分の 値に しますわ。お祝いですもの。"]],
    [(s) => !!s.ending, ["{smile}市に 人が もどって きましたわ。父も 毎朝 店先を はいて いますの。", "{sad}……あの方の 席は、店の いちばん 奥に とって ありますわ。いつでも、すわれる ように。"]],
    [(s) => !!s.heroDead, ["{sad}父の 手が、だんだん 冷たく なって いきますの。……それでも 店は 閉めませんわ。", "{angry}市の 灯りが 消えたら、この 村は おしまいですもの。わたくしが、守りますわ。"]],
    [(s) => !!st(s).shop4, ["{smile,☆}砂星商会、ただいま 営業中ですわ！ 母の ブローチも、ほら、ここに。", "{smile}旅の お方。また 寄って くださいまし。今度は、ちゃんと 定価で 売りますわよ。"]],
    [(s) => !!st(s).proof4, ["{smile}王墓の 件が 片づいたら、店を 開けますわ。……約束、覚えて いて くださいまし。"]],
    [() => true, ["{angry}腰帯の 布切れは、わたくしが 守って いますわ。泥棒の 好きには させませんわ。"]],
  ] });
castAdd("r4isak", { nm: "イザク", role: "老人", col: "§7", gobi: "でやんす", skin: "isak", town: "t6", from: "r4e4", until: "r7e1", at: near(SHOP, -4, 3),
  pre: ["{closed}……砂の 風は、今日も 西からでやんす。"],
  after: [
    [(s) => !!s.ending, ["{smile}ニナの 石の 間に、毎月 花を 届けて いるでやんす。", "{closed}……旦那方の ことも、ニナに 話して あるでやんすよ。"]],
    [(s) => !!s.heroDead, ["{sad}……牢の 鍵より、ずっと 重い ものを 背負って いる 顔でやんすね。", "{closed}あっしの 骨の 鍵、まだ ここに あるでやんす。開けたい 扉が あったら、いつでも。"]],
    [(s) => !!st(s).shop4, ["{smile}お嬢の 店の 前が、あっしの 新しい 寝床でやんす。……牢より、ずっと あったかいでやんす。"]],
    [() => true, ["{smile}七年ぶりの 空は、目に しみるでやんすね。"]],
  ] });
castAdd("r4garm", { nm: "ガルム", role: "衛兵長", col: "§6", gobi: "である", skin: "glen", town: "t6", from: "r4e4", at: () => { const q = placeOf("gate", 4); return q ? { x: q.x + 4, y: q.y ?? undefined, z: q.z + 2 } : null; },
  pre: ["{closed}城門は わしが 守るのである。"],
  after: [
    [(s) => !!s.ending, ["{smile}近ごろは 城門で、旅人に 道を 教えて おるのである。……わしも、少しは 変わったのである。"]],
    [(s) => !!s.heroDead, ["{angry}二十年前の 警告を、王は 思い出されたのである。兵は みな 町の 守りに 出して おる。", "{closed}……今度こそ、目の 前の 人を 見るのである。"]],
    [(s) => !!st(s).shop4, ["{sweat,汗}セリーヌ嬢の 店で、ナツメヤシを 買ったのである。……値切ったら、にらまれたのである。"]],
    [() => true, ["{closed}……あの 夜の ことは、すまなかったのである。わしは 証拠より、よそ者と いう 言葉を 信じた。"]],
  ] });
castAdd("r4papa", { nm: "ハリド", role: "セリーヌの 父", col: "§e", gobi: "", skin: "m6_samir", town: "t6", from: "r4e6", hide: (s) => !!(s.dm && s.dm.st && Array.isArray(s.dm.st.t6) && s.dm.st.t6.some((r) => r.n === "ハリド")), at: near(SHOP, 5, 1),
  pre: ["{closed}……店は、しばらく 休みだ。"],
  after: [
    [(s) => !!s.ending, ["{smile}娘が 帳場に 立つと、店が 明るく なる。……母親に、そっくりだ。"]],
    [(s) => !!s.heroDead, ["{sad}指の 先が、石の ように かたい。……娘には、まだ 言って いない。", "{closed}店を 閉めるな と 言ったのは、わしだ。だから、わしも 立って いる。"]],
    [() => true, ["{smile}娘の 言う とおりだった。……閉めた 店に、明日は 来ない。"]],
  ] });
castAdd("r4rashid", { nm: "ラシード", role: "砂王", col: "§6", gobi: "", skin: "rashid" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, y: typeof s.epSpot.y === "number" ? s.epSpot.y : p.location.y, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const SEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
const THIEF = (K, p, w = false) => K.npcNear(p, "§c六影の 下っぱ スナモグラ", K.PJ("thief", 9), w);
/* 歩いて 去る（道が ふさがって 歩けない 人は 暗転で 下げる）*/
const out = async (K, p, es, run = false) => { const L = [].concat(es).filter(ok), fade = [], go = []; for (const e of L) { const q = K.away(e, p, 10); if (!q || Math.hypot(q.x - e.location.x, q.z - e.location.z) < 4) fade.push(e); else go.push(K.leave(e, p, 10, run)); } await Promise.all(go); if (fade.length) await K.bye(p, ...fade); };
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
/* 市の 屋台（ワールドに 1回。舞台の 外側 11マス より 先。低い 物だけ）*/
function stalls(p, c, y0, lvl) {
  if (townAt(c, 46)) return;   /* 第125版(pl): 町の 中には 置かない（町の 屋台が ある）*/
  const k = `mrpg:epdeco:r4mk${lvl}`; try { if (world.getDynamicProperty(k)) return; world.setDynamicProperty(k, 1); } catch { return; }
  const dim = p.dimension, cx = Math.floor(c.x), cz = Math.floor(c.z);
  const put = (x, z, b, up = 0) => { try { const y = groundY(dim, cx + x, cz + z, y0 + 6); if (typeof y === "number" && Math.abs(y - y0) <= 4) dim.runCommand(`setblock ${cx + x} ${y + up} ${cz + z} ${b} keep`); } catch {} };
  const L = lvl ? [[-13, -4, "orange_wool", 0], [-13, -3, "orange_wool", 0], [13, 5, "yellow_wool", 0], [13, 6, "yellow_wool", 0], [-12, 8, "lantern", 0], [12, -8, "lantern", 0], [0, 13, "orange_wool", 0], [1, 13, "yellow_wool", 0]]
    : [[-13, -5, "barrel", 0], [-13, -4, "barrel", 0], [13, 4, "barrel", 0], [13, 6, "hay_block", 0], [-12, 7, "composter", 0], [12, -7, "barrel", 0], [0, 13, "barrel", 0]];
  for (const [x, z, b, u] of L) put(x, z, b, u);
}

/* ---------- 1話 オアシスの 市 ---------- */
const E1 = { id: "r4e1", n: 1, t: "オアシスの 市", at: 0, ord: 0, place: MARKET,
  hint: "§fオアシスの 村 §eミラージュの 市§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "ミラージュの 市は、ひと月 前から 泥棒さわぎ だらけ。砂星商会の お嬢さま セリーヌは「衛兵は よそ者の しわざと 決めつけて いますわ」と 怒って いた。逃げた 泥棒が 落とした 砂色の 布切れを、セリーヌは そっと 拾った。",
  set: { met4: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    stalls(p, c, y0, 0);
    await K.open(p, "オアシスの 村 ミラージュの 市", "day");
    K.sound(p, "note.harp", 0.6); K.sound(p, "mob.camel.ambient", 0.6);
    const eH = K.hero(p); K.hold(eH, "notebook");
    await K.hsay(p, K.V(["{smile,☆,jump}わあ……！ 砂漠の まん中に、こんなに 屋台が！", "{smile,♪}ナツメヤシ、香辛料、青い つぼ……ぜんぶ 手帳に 描きたい！"], ["{smile}……すてき。砂の 色の 布が、風に ゆれてる。", "{smile,♪}香辛料の いい 匂い。……少し、見て 回りましょう。"], ["{smile}……にぎやか。砂漠の 市は 初めて。", "{closed}香辛料の 匂い。……目が しみる。"], ["{smile,☆}まあ……砂漠の まん中に、こんなに たくさんの 屋台が。", "{smile}香辛料の 香りが いたします。少し、見て 回りましょう。"]));
    const eF = K.npcNear(p, "§f果物売りの おかみ", K.PJ("hanna", 8));
    K.act(eF, "point");
    await K.say(p, "果物売りの おかみ", ["{shock,!,up}どろぼう！ どろぼうだよ！ ナツメヤシの 箱ごと！"]);
    const eT = K.npcNear(p, "§c砂色の 頭巾の 男", K.PJ("thief", 9));
    K.act(eT, "run", false);
    await K.low(p, eT, 10);
    await K.say(p, "砂色の 頭巾の 男", ["{smile,low}へっへっ。砂漠じゃ、取った もんが 勝ちだぜ。"]);
    K.burst(p.dimension, ok(eT) ? eT.location : c, "minecraft:white_smoke_particle", 10, 1.2, 0.2); K.sound(p, "dig.sand", 1);
    await out(K, p, eT, true);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,怒}あっ、逃げた！ 待ちなさーい！"], ["{shock,!}……砂けむりで、見えない……！"], ["{angry}……速い。足あとも 砂で 消えた。"], ["{shock,!}に、逃げられて しまいました……！"]));
    const eC = K.cast(p, "r4celine");
    K.act(eC, "hold");
    await K.csay(p, "r4celine", ["{angry,怒,up}……また ですわ！ 今月で 十二件目ですわ！", "{closed,息}衛兵は いったい 何を して いますの。昼寝の お時間かしら。"]);
    K.act(eC, 0);
    await K.csay(p, "r4celine", ["{?}……あら。あなた方、見ない お顔ですわね。", "{smile,nod}わたくしは セリーヌ。この 市で いちばん 古い 商家、砂星商会の 娘ですわ。"], eH);
    await K.hsay(p, K.V(["{smile,♪}お嬢さまだ！ ……あ、わたしたちは 石板を 集める 旅を してるの！"], ["{smile}はじめまして、セリーヌさん。わたしたち、石板の 旅の 途中なの。"], ["{closed}……石板の 旅の 途中。よろしく。"], ["{smile}はじめまして。わたしたちは 石板を 集める 旅を して おります。"]));
    K.act(eC, "point");
    await K.csay(p, "r4celine", ["{sad}よそ者の 方なら、気を つけなさいな。", "{angry}ひと月 前から 盗みが 続いて、衛兵は『よそ者の しわざ』と 決めつけて いますの。"], eH);
    K.act(eC, 0);
    await K.csay(p, "r4celine", ["{sad,…,up}……わたくしの 店も、閉めて しまいましたわ。", "{sad}父が『もう 店を 守れない』と 言って。……母が 残した 店ですのに。"]);
    await K.up(p, eC, 10);
    await K.hsay(p, K.V(["{sad,…}……お母さんの お店、なんだね。"], ["{sad}……大切な お店なのね。"], ["{closed}……母親の 店。"], ["{sad}……お母さまの、お店なのですね。"]));
    const eF2 = K.npcNear(p, "§f果物売りの おかみ", K.PJ("hanna", 8), true);
    K.act(eF2, "kneel");
    await K.say(p, "果物売りの おかみ", ["{sad}お嬢さん、もう いいよ……。わたしたち、来月には 村を 出る つもりさ。"]);
    K.act(eC, "guard");
    await K.csay(p, "r4celine", ["{angry,怒,up}だめですわ！ 店を 閉めたら、この 市は 砂に 埋もれて しまいますわ！"]);
    K.act(eF2, 0);
    /* 泥棒が 落とした もの */
    const q0 = K.fwd(p, 4, 2.4);
    K.burst(p.dimension, q0, "minecraft:villager_happy", 4, 0.3, 0.2);
    await K.at(p, q0, 14, 2.4, 0.4);
    await K.narr(p, ["§7砂の 上に、砂色の 布切れが 一枚 落ちて いる。", "§7すみに、黒い 糸で 小さな 印が 縫いこまれて いた。"], q0);
    K.act(eC, "kneel");
    await K.csay(p, "r4celine", ["{?,up}……これは。泥棒の 頭巾の 切れはし……ですわね。", "{closed}この 縫い目、市の 布では ありませんわ。もっと かたい……どこかで 見た 気が しますわ。"]);
    K.act(eC, 0);
    await K.hsay(p, K.V(["{angry}よーし！ わたしたちも 泥棒さがし、手伝う！"], ["{smile}……わたしたちにも、手伝わせて。"], ["{closed}手伝う。……この 印、気に なる。"], ["{smile}わたしたちにも、お手伝い させて ください。"]));
    await K.csay(p, "r4celine", ["{shock,…}……旅の 方が、よその 市の ために？", "{smile,up}でも……ありがとう ございますわ。今夜、市の 外の 街道で 見張りますの。来て くださいまし。"]);
    K.pay(p, E1, 300, [["mei_sand", 1]]);
    await K.end(p, { leave: [eC, eF2], card: "§7― 夜、街道で 泥棒を 見張ろう ―\n§7→ サンドリアの 街道へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 2話 濡れ衣の たね ---------- */
const E2 = { id: "r4e2", pv: 127, n: 2, t: "濡れ衣の たね", at: 0, ord: 1, place: ROAD, fac: "r4road",
  hint: "§f夜の §eサンドリアの 街道§f で セリーヌと 泥棒を 見張ろう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "夜の 街道で、泥棒の 正体を 見た。六影を 名乗る 下っぱ スナモグラは「城の 衛兵の 服は 便利だぜ」と 笑った。セリーヌは 母の 形見の ブローチを 取りもどし、衛兵の 腰帯の 切れはしを 証拠と して 預かった。そこへ 衛兵長 ガルムが 来て、あなたたちを にらんだ。「明日 城門を くぐるなら、覚悟 して おく である」。",
  set: { thief4: 1, met4: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), thief4: 1 }; },
  async run(p, d, K) {
    const FW = fac(K, p, "r4road", "waypost", 4, Y(K, p));   /* 第125版(pl): 街道の 道しるべ（札・灯り・荷） */
    await K.open(p, "サンドリアの 夜の 街道", "night");
    if (FW) await K.at(p, FW, 14, 6, 1.2);
    K.sound(p, "ambient.cave", 1, 0.4);
    const eH = K.hero(p), eC = K.cast(p, "r4celine");
    K.act(eC, "hold"); K.hold(eC, "mug");
    await K.csay(p, "r4celine", ["{smile}来て くださったのね。……はい、これ。夜の 砂漠は 冷えますもの。", "{smile,♪}砂星商会 自慢の、ナツメヤシの 甘い お茶ですわ。"]);
    await K.give(eC, eH, "mug");
    K.act(eC, 0);
    await K.hsay(p, K.V(["{smile,☆,jump}わあ、あったかい！ ……見張りって、もっと つらいと 思ってた！"], ["{smile,up}……おいしい。ありがとう、セリーヌさん。"], ["{smile}……あまい。悪くない。"], ["{smile,up}まあ、温かい……ありがとう ございます。"]));
    await K.at(p, { x: p.location.x, y: p.location.y + 8, z: p.location.z }, 14, 6, 4);
    await K.narr(p, ["§7砂の 上に、星が こぼれる ほど 光って いる。", "§7遠くで、夜の 鳥が 一声 鳴いた。"]);
    await K.csay(p, "r4celine", ["{sad,…}……ほんとうは、わたくし、こわいのですわ。", "{sad,up}父は『女の 子が 泥棒を 追うな』と 言いますの。でも、母なら きっと 追いかけましたわ。"], eH);
    await K.up(p, eC, 12);
    await K.csay(p, "r4celine", ["{closed}母は、市の 灯りを 守る 人でしたの。……ある 冬、石に なって しまいましたけれど。", "{smile,up}母の ブローチも、盗まれた 箱の 中に ありましたの。だから、わたくしが 取り返しますわ。"]);
    await K.hsay(p, K.V(["{sad,tears,up}……セリーヌさん。", "{angry,up}うん！ ぜったい 取り返そう！"], ["{sad,up}……そう。お母さまの、だったのね。", "{smile,up}取り返しましょう。いっしょに。"], ["{closed,up}……取り返す。いっしょに。"], ["{sad,up}……お母さまの、形見だったのですね。", "{angry,up}必ず、取り返しましょう。"]));
    /* 泥棒たち */
    K.sound(p, "dig.sand", 1); K.shake(p, 0.2, 0.3);
    const eT = THIEF(K, p); K.act(eT, "hold");
    const eT2 = K.npcNear(p, "§c六影の 下っぱ ハリネズ", K.PJ("noxa", 9));
    await K.low(p, eT, 12);
    await K.say(p, "スナモグラ", ["{smile,low}へっへっ。今夜の 分は、これで 十三件目だぜ。", "{smile}城の 衛兵の 服は 便利だぜ。門を 通っても、だれも 怪しまねえ。"]);
    await K.say(p, "ハリネズ", ["{sweat,汗}兄貴、声が でかいっす。……上の 人に しかられますぜ。"]);
    K.act(eC, "guard");
    await K.csay(p, "r4celine", ["{rage,怒,up}そこまでですわ、泥棒！ その 箱を 返しなさい！"]);
    await K.say(p, "スナモグラ", ["{shock,!,up}げっ、商会の お嬢！？ ……ちっ、見られちまったら しかたねえ。", "{angry}§5六影§f の 名に かけて、砂に 埋めて やるぜ！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{rage,怒,up}六影……！ ここでも 人の 物を 取って！ ゆるさないから！"], ["{angry,up}……六影。その 箱は、セリーヌさんの お母さまの ものよ。"], ["{angry,up}……六影。返して もらう。"], ["{rage,怒,up}六影……！ その 箱、お返し いただきます！"]));
    if (!K.flag(p, "r4e2w")) {
      const r = await K.battle(p, K.team(["golem", "beast"], 36, 3, 6), { name: "六影の 下っぱ スナモグラ", arena: "濡れ衣の たね", theme: "desert", speaker: "スナモグラ", lines: { half: "ひいっ、砂の 中まで 追って くるな！", low: "あ、兄貴の 兄貴に しかられるぅ……！" } });
      if (r !== "win") return lose(K, p, "§c六影の 下っぱ スナモグラ", K.PJ("thief", 9), "スナモグラ", "{smile}へっへっ。砂漠の 夜は、オレたちの もんだぜ。");
      K.setFlag(p, "r4e2w");
    }
    const eT3 = THIEF(K, p, true); K.act(eT3, "recoil");
    const eT4 = K.npcNear(p, "§c六影の 下っぱ ハリネズ", K.PJ("noxa", 9), true);
    await K.say(p, "スナモグラ", ["{sweat,汗}く、くそっ……！ 箱は くれて やる！", "{angry,low}だがな、よそ者。お前らが 城門を くぐる 日は、もう 決まって いるんだぜ……！"]);
    K.burst(p.dimension, ok(eT3) ? eT3.location : p.location, "minecraft:white_smoke_particle", 14, 1.6, 0.3); K.sound(p, "dig.sand", 1.2);
    await out(K, p, [eT3, eT4], true);
    /* 箱と ブローチ */
    K.act(eC, "kneel");
    const q1 = K.fwd(p, 3.5, 1.6);
    K.burst(p.dimension, q1, "minecraft:villager_happy", 6, 0.4, 0.3); K.sound(p, "random.orb", 0.6);
    await K.at(p, q1, 12, 2.2, 0.5);
    K.hold(eH); K.hold(eC, "orb"); K.act(eC, "show", false);
    await K.csay(p, "r4celine", ["{cry,tears,up}……ありましたわ。母の、ブローチ……。", "{cry,smile,up}よかった……ほんとうに、よかった……。"]);
    K.act(eC, 0);
    await K.hsay(p, K.V(["{smile,tears,up}よかったね、セリーヌさん……！"], ["{smile,tears,up}……よかった。"], ["{smile,up}……よかった。"], ["{smile,tears,up}よかった……本当に、よかったです。"]));
    await K.narr(p, ["§7箱の 底に、もう 一つ。砂色の 長い 帯が 入って いた。", "§7サンドリア城の 衛兵の 腰帯だ。裏に、黒い 糸の 印。昼に 拾った 切れはしと 同じ 縫い目。"], q1);
    K.hold(eC, "rope");
    await K.csay(p, "r4celine", ["{shock,!,up}……衛兵の 腰帯！？ まさか、泥棒は 城の 中に……！", "{angry}これは 証拠ですわ。わたくしが、あずかりますわ。"]);
    /* 衛兵長 ガルム */
    K.sound(p, "mob.villager.no", 0.8);
    const eG = K.cast(p, "r4garm"); K.act(eG, "point"); K.hold(eG, "spear");
    await K.low(p, eG, 12);
    await K.csay(p, "r4garm", ["{angry,low}……そこの よそ者。夜ふけに 盗品の 箱を かかえて、何を して おるのであるか。"]);
    await K.hsay(p, K.V(["{shock,!,up}ち、ちがうよ！ わたしたちは 泥棒を 追い払ったの！"], ["{shock,…}……ちがうわ。わたしたちは 取り返したの。"], ["{angry}ちがう。泥棒は 逃げた。あっちだ。"], ["{shock,!}ご、誤解です！ わたしたちは 泥棒を 追い払ったのです！"]));
    K.act(eC, "guard");
    await K.csay(p, "r4celine", ["{angry,怒,up}ガルム！ この方たちは わたくしを 助けて くれたのですわ！"]);
    K.act(eG, "hold");
    await K.csay(p, "r4garm", ["{closed}……セリーヌ嬢の 言葉なら、今夜は 引くのである。", "{angry,low}だが よそ者。明日 城門を くぐるなら、覚悟 して おくのである。……妙な 知らせが 届いて おるのでな。"]);
    K.act(eG, 0);
    await out(K, p, eG, false);
    await K.csay(p, "r4celine", ["{angry,怒}……石頭ですわ！ 城門の 石より かたいですわ！", "{closed,up}証拠は わたくしが 守りますわ。あなた方が 城門で 困ったら……必ず、届けに 行きますわ。"]);
    await K.hsay(p, K.V(["{smile,up}うん。……約束だよ、セリーヌさん。"], ["{smile,up}ええ。約束ね。"], ["{smile,up}……約束。"], ["{smile,up}はい。お約束です。"]));
    K.pay(p, E2, 400, [["gift_tea", 1]]);
    await sixCut(p, K, Y(K, p));   /* 第125版(rs): ―― そのころ 六影の 卓 */
    await K.end(p, { leave: [eC], card: "§7→ サンドリア城の 城門へ（右上の 案内。セオが 待って いる）", kind: "night" });
    return true;
  } };

/* ---------- 4話 セリーヌの 証拠（玉座の 間の あと。城の 中庭）---------- */
const E4 = { id: "r4e4", n: 4, t: "セリーヌの 証拠", at: 1, ord: 0, place: COURT,
  hint: "§f§6サンドリア城の 中庭§f へ 行こう §7（セリーヌが 証拠を 持って 来た。王墓へは そのあと。「！」の 目印の そばで 立ち止まろう）",
  syn: "城の 中庭で、セリーヌが 打ち明けた。牢の 外で セオに 腰帯を わたしたのは 彼女だった。捕まった 偽の 衛兵 スナモグラは「上の 人の ことは 何も 知らされねえ」と だけ 言った。衛兵長 ガルムは 頭を 下げ、牢を 出た イザクは「七日 あれば 出られた。それでも 七年 いた」と 笑った。セリーヌは「王墓の 件が 片づいたら、店を 開ける」と 約束した。",
  set: { proof4: 1, met4: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), proof4: 1 }; },
  async run(p, d, K) {
    await K.open(p, "サンドリア城の 中庭", "castle");
    K.sound(p, "note.bell", 0.5);
    const eH = K.hero(p), eC = K.cast(p, "r4celine");
    K.act(eC, "raise");
    await K.csay(p, "r4celine", ["{smile,☆,up}よかった……ご無事で！ 牢に 入れられたと 聞いて、走って きましたわ！"]);
    await K.hsay(p, K.V(["{shock,!,up}セリーヌさん！？ どうして ここに？"], ["{shock,…}……セリーヌさん？"], ["{?}……セリーヌ。なんで ここに。"], ["{shock,!,up}セ、セリーヌさん！？"]));
    const eS = SEO(K, p); K.act(eS, "show"); K.hold(eS, "rope");
    await K.say(p, "セオ", ["{smile}城門の 前で、この方が 腰帯を 見せて くれたんです。", "{closed}縫い目を たどったら、衛兵の 詰め所に 同じ 帯が 一本 足りなかった。……真犯人は、すぐに わかりました。"], eH);
    K.act(eS, 0);
    await K.csay(p, "r4celine", ["{blush,…}……と、当然の ことを した までですわ。", "{smile,up}約束、しましたもの。困ったら 必ず 届けに 行くと。"]);
    await K.up(p, eC, 10);
    await K.hsay(p, K.V(["{smile,tears,up}……ありがとう、セリーヌさん！ ほんとに、ほんとに！"], ["{smile,tears,up}……ありがとう。守って くれたのね、約束。"], ["{smile,up}……ありがとう。助かった。"], ["{smile,tears,up}ありがとう ございます……約束を、守って くださって。"]));
    /* ガルムが 偽の 衛兵を 連れて 来る */
    const eG = K.cast(p, "r4garm"), eT = THIEF(K, p); K.hold(eG, "spear");
    K.act(eT, "kneel");
    await K.two(p, eG, eT, 12);
    await K.csay(p, "r4garm", ["{closed}……この 男が、衛兵に 化けて 盗みと 密告を して おったのである。"]);
    K.act(eG, "kneel");
    await K.up(p, eG, 12);
    await K.csay(p, "r4garm", ["{sad,up}旅の 方。……すまなかったのである。", "{closed}わしは 目の 前の 証拠より、『よそ者』と いう 言葉を 信じた。衛兵長、失格である。"]);
    await K.csay(p, "r4garm", ["{closed,low}……密告の 手紙は、もう 一通 あったのである。『石板の 子が 通った 町は、石に なる』と。……わしは、それも 信じかけた。"]);   /* 第125版 Q13 */
    await K.hsay(p, K.V(["{angry}……文句 百個、言う つもりだったけど。", "{smile,息}もう いいよ。ちゃんと 謝って くれたから。"], ["{smile}……顔を 上げて。わかって くれたなら、それで いいわ。"], ["{closed}……もう いい。次は、ちゃんと 見て。"], ["{smile}どうか お顔を お上げ ください。わかって いただければ、十分です。"]));
    K.act(eG, 0);
    /* 偽の 衛兵の 最後の あがき */
    K.act(eT, "guard"); K.sound(p, "mob.villager.no", 1);
    await K.say(p, "スナモグラ", ["{rage,怒,up}……へっ！ 謝って 済むかよ！ オレは まだ 縄は かかって ねえぜ！"]);
    K.act(eH, "guard");
    if (!K.flag(p, "r4e4w")) {
      const r = await K.battle(p, K.team(["golem", "nether", "beast"], 38, 3, 10), { name: "偽の 衛兵 スナモグラ", arena: "セリーヌの 証拠", theme: "desert", speaker: "スナモグラ", lines: { half: "な、なんで 牢の 中より 強く なって んだよ！", low: "……上の 人に、見捨てられちまう……" } });
      if (r !== "win") return lose(K, p, "§6衛兵長 ガルム", K.PJ("glen", 16), "ガルム", "{angry}……下がれ！ この 男は わしが 押さえるのである！");
      K.setFlag(p, "r4e4w");
    }
    const eT2 = THIEF(K, p, true); K.act(eT2, "down");
    await K.up(p, eT2, 10);
    await K.say(p, "スナモグラ", ["{sad,…}……上の 人？ 知らねえよ。顔も 名前も、だれも 知らねえ。", "{closed}『王墓に 近づく よそ者を 牢に 入れろ』……手紙が 来て、金が 来る。それだけだ。", "{closed}手紙の 字は、じいさんの 字だった。古くさい、かすれた 字だ。", "{closed}盗みは おまけだ。『よそ者は 泥棒だと、町に 思わせて おけ』って 手紙に あった。", "{closed,up}……封の 印は いつも 同じだ。『参謀の 指示』。それと、『二の座』とか いう 字。"]);
    if (ok(eS)) { K.re(eS, "closed", "…"); await K.up(p, eS, 12); }
    await K.say(p, "セオ", ["{closed,…}…………。"]);
    await K.hsay(p, K.V(["{?}……セオさん？"], ["{?}……セオさん、どうか した？"], ["{?}……セオ？"], ["{?}セオさん……？"]));
    await K.say(p, "セオ", ["{smile,汗}……いえ。何も 知らされない 下っぱ、ですか。……少し、気の 毒に なりました。"]);
    K.act(eG, "hold");
    if (ok(eG) && ok(eT2)) { const q = eT2.location; await K.go(eG, { x: q.x + 1.1, y: q.y, z: q.z + 0.5 }, 10); }
    await K.csay(p, "r4garm", ["{angry}立つのである。……詰め所で、ゆっくり 話を 聞くのである。"]);
    K.act(eT2, 0);
    await K.bye(p, eT2, eG);
    await K.narr(p, ["§7ガルムは 男を 連れて、詰め所へ 向かった。", "§7中庭に、砂まじりの 風が 一つ 吹いた。"]);
    /* イザク */
    const eI = K.cast(p, "r4isak"); K.act(eI, "hold"); K.hold(eI, "bonekey");
    await K.csay(p, "r4isak", ["{smile,♪}おやおや、にぎやかでやんすね。"]);
    await K.hsay(p, K.V(["{shock,!,jump,up}イザクさん！？ 牢から 出られたの！？ ……って、しゃべり方 ちがう！"], ["{shock,…}……イザクさん？ 話し方が……"], ["{shock,!}……イザク。口調が ちがう。"], ["{shock,!}イ、イザクさん……？ お話しの 仕方が……"]));
    await K.csay(p, "r4isak", ["{smile,息}へへ。七年も 牢に いると、牢番の じいさん 言葉が うつるでやんす。", "{smile,☆}ほんとの あっしは、こう しゃべるでやんす。……砂漠 いちばんの 牢破り、イザクとは あっしの ことでやんす。"]);
    K.act(eI, 0);
    await K.hsay(p, K.V(["{?}牢破りの 名人なのに……七年も？"], ["{?}……名人なのに、どうして 七年も？"], ["{?}名人なら、なんで 七年。"], ["{?}名人で いらしたのに、どうして 七年も……？"]));
    await K.memory(p, eI, "§7― 昔 ―", ["§7石の 間の 前で、一人の 男が 花を にぎって 泣いて いた。", "§7牢の 鍵は、七日 あれば 開けられた。けれど 男は、骨を ゆっくり、ゆっくり 削り続けた。"]);
    await K.csay(p, "r4isak", ["{sad,up}……七日 あれば、出られたでやんす。", "{cry,tears,up}でも 出たら、また 王墓へ 走って、ニナの 前で 泣いて しまう。……だから、七年 かけて 削ったでやんす。"]);
    await K.csay(p, "r4celine", ["{shock,!,up}……イザクさん？ 子どもの ころ、市で あめ細工を くれた……あの イザクさん！？"]);
    await K.csay(p, "r4isak", ["{smile,tears,up}……お嬢。大きく なったでやんすね。", "{smile}王さまが、ニナの 石の 間へ 通して くれるそうでやんす。……旦那方の おかげでやんす。"], eC);
    await K.csay(p, "r4celine", ["{closed,up}……決めましたわ。王墓の 件が 片づいたら、わたくし、店を 開けますわ。", "{smile,up}父を 説得して。市の 灯りを、もう一度 ともしますわ。……いちばんに 来て くださいまし。約束ですわ。"]);
    await K.hsay(p, K.V(["{smile,☆,up}うん、約束！ 王墓、すぐ 片づけて くるね！"], ["{smile,up}ええ、約束。……楽しみに してる。"], ["{smile,up}……約束。王墓、片づける。"], ["{smile,up}はい、お約束です。王墓の 件、必ず。"]));
    K.pay(p, E4, 600, [["c_herbs", 2]]);
    await K.end(p, { leave: [eC, eI], bye: [eS], card: "§7→ 王墓の 地図を §bサンドリアの ステージ（大地）§7で 広げよう（右上の 案内）", kind: "castle" });
    return true;
  } };

/* ---------- 5話 つづき セリーヌの 店（王墓の あと。市が 開く）---------- */
const E6 = { id: "r4e6", n: 5, t: "セリーヌの 店", at: 2, ord: 0, place: SHOP, fac: "r4shop",
  hint: "§fミラージュの §e砂星商会（セリーヌの 店）§f へ もどろう §7（セリーヌとの 約束。そのあと クリスタリアへ。「！」の 目印の そばで 立ち止まろう）",
  syn: "王墓の 主を 封じて 市へ もどると、砂星商会の 店が 開いて いた。父 ハリドも 帳場に 立ち、ニナの 石の 間に 花を 届けた イザクが 戻って きた。衛兵長 ガルムは 不器用に 客に なった。市に 灯りが もどり、ミラージュは 少し にぎやかに なった。",
  set: { shop4: 1, met4: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), shop4: 1 }; },
  fx: { xp: ["t6", 160], fest: "t6" },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    stalls(p, c, y0, 0); stalls(p, c, y0, 1);
    const FS = fac(K, p, "r4shop", "shopfront", 4, y0);   /* 第125版(pl): 町の 店が ない 古い ワールドは 外れに 店先（日よけ・帳場・棚・看板）*/
    await K.open(p, "ミラージュの 砂星商会（夕ぐれ）", "fest", "dusk");
    if (FS) await K.at(p, FS, 16, 7, 1.6);
    K.sound(p, "firework.blast", 0.6); K.sound(p, "note.harp", 0.8);
    const eH = K.hero(p), eC = K.cast(p, "r4celine");
    K.act(eC, "raise");
    await K.csay(p, "r4celine", ["{smile,☆,jump,up}いらっしゃいませ！ 砂星商会、本日 再開ですわ！", "{smile,♪}……ふふ。いちばんの お客さまは、やっぱり あなた方でしたわね。"]);
    await K.hsay(p, K.V(["{smile,tears,up}お店、開いたんだね……！ 灯り、いっぱい！"], ["{smile,tears,up}……開いたのね。灯りが、きれい。"], ["{smile,up}……開いた。いい 店。"], ["{smile,tears,up}お店、開いたのですね……！ なんて 明るい。"]));
    const eP = K.cast(p, "r4papa"); K.act(eP, "hold");
    await K.csay(p, "r4papa", ["{closed}……ハリドだ。娘が、世話に なった。", "{smile,up}閉めた 店に、明日は 来ない。……娘に そう 言われてな。恥ずかしい 話だ。"]);
    await K.csay(p, "r4celine", ["{blush,…,up}も、もう、お父さま！ それは 言わない 約束ですわ！"], eP);
    K.act(eP, 0);
    const eI = K.cast(p, "r4isak"); K.act(eI, "hold"); K.hold(eI, "bonekey");
    await K.csay(p, "r4isak", ["{smile}旦那方。ニナの 石の 間に、花を 届けて きたでやんす。", "{smile,tears,up}七年 かかったでやんすが……やっと、『ただいま』を 言えたでやんす。"]);
    await K.hsay(p, K.V(["{smile,tears,up}……よかった。ほんとに、よかったね。"], ["{smile,tears,up}……よかった。ニナさんも、きっと 喜んでる。"], ["{smile,up}……よかった。"], ["{smile,tears,up}……本当に、よかったです。"]));
    K.act(eI, 0);
    const eG = K.cast(p, "r4garm"); K.act(eG, "point"); K.hold(eG, "spear");
    await K.csay(p, "r4garm", ["{sweat,汗}……ナツメヤシを、ひと袋 ほしいのである。"]);
    await K.csay(p, "r4celine", ["{smile,☆}あら、衛兵長。今日は 特別に、二割 増しの お値段ですわ。"], eG);
    await K.csay(p, "r4garm", ["{shock,!,up}な、なぜ 増えるのである！？"]);
    K.act(eG, 0);
    await K.csay(p, "r4celine", ["{smile,♪}おわびの 分ですわ。……ふふ、冗談ですわよ。"]);
    /* 市の 灯り */
    for (const e of [eC, eI, eH]) K.act(e, 9);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z }); K.sound(p, "note.pling", 0.8);
    const g = K.palEnt(p); if (g) K.burst(p.dimension, g.location, "minecraft:note_particle", 5, 0.5, 1);
    await K.wide(p, 24);
    K.ambient(p, "fest", { x: c.x, y: y0, z: c.z });
    for (const e of [eC, eI, eH]) K.act(e, 0);
    K.rmCine(g);
    K.act(eC, "hold"); K.hold(eC, "orb");
    await K.csay(p, "r4celine", ["{smile}これは、わたくしからですわ。砂漠の 旅の、お守りに。", "{blush,up}……また 来て くださいまし。今度は、ちゃんと 定価で 売りますわよ。"]);
    await K.give(eC, eH, "orb");
    const got = K.pay(p, E6, 800, [["mei_sand", 2], ["gift_brooch", 1]]);
    if (got.length) K.big(p, "§e§l砂星商会の おみやげ", `§e${got.join("・")}`);
    K.act(eC, 0);
    await K.hsay(p, K.V(["{smile,☆,up}うん！ また 来るね！ ……いって きます！"], ["{smile,up}ええ、また 来るわ。……いって きます。"], ["{smile,up}……また 来る。いって きます。"], ["{smile,up}はい、また 参ります。……いって まいります。"]));
    await K.csay(p, "r4celine", ["{smile,tears,up}いって らっしゃいませ。……砂星商会は、いつでも 開いて いますわ。"]);
    await K.end(p, { leave: [eG], bye: [eC, eI, eP], card: "§f― 第5章 砂の 王墓 おわり ―\n§7→ 次は クリスタリアの 村 グロウへ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(4, [E1, E2, E4, E6], { steps: { 0: [3, "濡れ衣と 地下牢（城門 → 牢 → 玉座の 間）"], 1: [5, "王墓（地図を 大地で 広げる）"] } });
