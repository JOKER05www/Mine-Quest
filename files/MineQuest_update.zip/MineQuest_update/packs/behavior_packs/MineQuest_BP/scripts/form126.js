// 第126版: ラスボスの 第2形態（影の セオ「書きとめる 手」・記録の神「白紙の 顔」）。設計は /tmp/zf/forms126.md
// battle.js: 能力が 決まった あとに fmSetup(B, key)・毎行動の あとに await fmTick(B, names, log, H)。ギミックは B.tkg の 形（core.js の つなぎ目）
import { MOVES } from "./data.js";
import { alive } from "./core.js";
import { load } from "./store.js";
import { wait } from "./ui.js";

/* 第2形態の 技（実行時に 足す。データの 作りなおし 不要）*/
const NEWMV = {
  fm_t_ink: { name: "紫の一筆", kind: "attack", cat: "magic", el: "dark", mult: 1.7, mp: 20, tier: 4, target: "enemy", type: "spell", boss: true, desc: "紫の インクで 名を 一筆に 書き、敵 1体を 打つ" },
  fm_t_roll: { name: "名簿の雨", kind: "attack", cat: "magic", el: "dark", mult: 0.6, hits: 2, mp: 26, tier: 4, target: "enemies", type: "spell", debuff: ["mdf", -1, 0.35], boss: true, desc: "何千の 名前が 雨に なって 敵 全員を 2回 打つ。ときどき 魔硬力を 下げる" },
  fm_v_blank: { name: "白紙の頁", kind: "attack", cat: "magic", mult: 1.05, mp: 24, tier: 4, target: "enemies", type: "spell", dispelhit: true, boss: true, desc: "頁を 白紙に もどす 光で 敵 全員を 打ち、強化を 消す（属性なし）" },
  fm_v_still: { name: "書き留める字", kind: "attack", cat: "magic", el: "dark", mult: 1.5, mp: 22, tier: 4, target: "enemy", type: "spell", inf: ["freeze", 0.35], boss: true, desc: "相手を 頁に 書き留め、ときどき 動けなく する" },
};
for (const [k, v] of Object.entries(NEWMV)) if (!MOVES[k]) MOVES[k] = v;

export const FORMS = {
  theo: {
    nm: "影の セオ《書きとめる 手》", sp: "theo_shadow", col: [0.62, 0.3, 0.95], ptc: "minecraft:enchanting_table_particle", p2: "minecraft:portal_reverse_particle",
    moves: ["fm_t_ink", "fm_t_roll", "th_spear", "th_breath", "th_mirror", "th_page"], hpK: 1.4, hpR: 0.6, grow: 1.3,
    lines: ["§5§lセオ§r§f「……見せて あげよう。僕が 何を 書いて きたか。」", "§5インクが 壁から はがれ、セオの 手に なった ―― §d§l書きとめる 手！", "§d相棒が 動くたび・防御を えらぶと、セオの 名を 呼ぶ。§e三度 呼べば 字が 崩れる"],
    snd: ["mob.evocation_illager.prepare_summon", 0.6], title: "§5§l第2形態 書きとめる 手",
  },
  volnag: {
    nm: "記録の神《白紙の 顔》", col: [0.95, 0.95, 0.92], ptc: "minecraft:white_smoke_particle", p2: "minecraft:endrod", tint: { h: 14, b: 16, a: 15, l: 16, c: 1, w: 14 },
    moves: ["fm_v_blank", "fm_v_still"], hpK: 1, hpR: 0, grow: 1.2,
    lines: ["§f§l名の ない 神§r§f「……覚えて おいて あげましょう。あなたたちの、全部を。」", "§f顔の 頁が めくれた ―― §7§l白紙の 顔！", "§7顔の 頁は こちらの 強化を 書き写し、3ラウンドごとに 読み上げて 自分の ものに する"],
    snd: ["item.book.page_turn", 0.5], title: "§f§l第2形態 白紙の 顔",
  },
};
const T = (B) => B.turn || 1;
const STATS = ["atk", "def", "mat", "mdf", "spd", "wpn", "brt"];
const SNM = { atk: "物力", def: "硬力", mat: "魔力", mdf: "魔硬力", spd: "走力", wpn: "武力", brt: "吹力" };
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
function sfx(B, id, pitch = 1) { for (const x of B.players || []) try { x.p.playSound(id, { volume: 1, pitch }); } catch {} }
function ptc(B, f, id, n = 6, r = 1.6, dy = 1) { try { const e = f && f.ent; if (!okE(e)) return; const l = e.location; for (let k = 0; k < n; k++) { const a = (k / n) * Math.PI * 2; e.dimension.spawnParticle(id, { x: l.x + Math.cos(a) * r, y: l.y + dy + (k % 3) * 0.5, z: l.z + Math.sin(a) * r }); } } catch {} }
const NOCOPY = (mv) => !mv || !(mv.kind === "attack" || mv.kind === "drain") || mv.selfko || mv.charge || mv.recoil || mv.hpcost || mv.mimic || mv.allmp || mv.rest || mv.absolute || mv.god;

/* 戦いの はじめ（能力が 決まった あと）*/
export function fmSetup(B, key) {
  const F = FORMS[key]; if (!B || !F || !B.enemies || !B.enemies[0]) return false;
  B.fm = { key, ph: 1, host: B.enemies[0], th: 0.5, calls: 0, callT: new Set(), brkT: 0, copy: null, dealt: new Map(), rec: {}, name: false };
  if (!B.tkg) B.tkg = HOOKS;   /* 十魔将の ギミックと 重ならない（最終戦だけ）*/
  return true;
}
const hpSum = (L) => L.reduce((s, f) => s + Math.max(0, f.hp), 0);
const mxSum = (L) => L.reduce((s, f) => s + (f.mx ? f.mx.hp : 0), 0);
/* 変わる 条件: セオは 全体か 先頭が 半分・神は 再臨の あと（なければ 半分）*/
export function fmDue(B) {
  const S = B && B.fm; if (!S || S.ph !== 1) return null;
  let h = S.host; if (!h || h.hp <= 0) { h = alive(B.enemies).sort((a, b) => b.hp - a.hp)[0]; if (!h) return null; S.host = h; }
  if (S.key === "volnag") return (h.revN || 0) >= 1 || h.hp <= h.mx.hp * S.th ? h : null;
  return h.hp <= h.mx.hp * S.th || hpSum(B.enemies) <= mxSum(B.enemies) * S.th ? h : null;
}
/* 変身（同期の 部分: 能力・技・見た目）*/
export function fmApply(B, f, H = {}) {
  const S = B.fm, F = FORMS[S.key]; S.ph = 2; S.t2 = T(B); f.fmForm = 2;
  if (F.hpK > 1) { const mh = Math.min(60000, Math.round(f.mx.hp * F.hpK)); f.mx = { ...f.mx, hp: mh }; f.hp = Math.max(f.hp, Math.round(mh * F.hpR)); if (f.php) f.php = Math.max(f.php, f.hp); }
  f.name = F.nm; if (f.m) f.m.nm = F.nm;
  f.infMP = true; f.isBoss = true; f.smart = Math.max(f.smart || 0, 2.5); f.fixedKit = true;
  f.tr = f.tr || {}; const [lo, hi] = f.tr.acts || [1, 1]; f.tr.acts = [Math.max(2, lo), Math.max(3, hi)]; f.tr.critguard = true;
  f.buf = f.buf || {}; for (const k of S.key === "theo" ? ["atk", "mat", "spd"] : []) f.buf[k] = Math.max(f.buf[k] || 0, 1);
  try { for (const a of Object.keys(f.ail || {})) delete f.ail[a]; } catch {}
  const mv = F.moves.filter((k) => MOVES[k]); f.moves = S.key === "theo" ? mv : [...new Set([...mv, ...(f.moves || [])])].slice(0, 8);
  if (F.sp) f.lookAs = F.sp;
  if (okE(f.ent)) try {
    const m = F.sp ? { ...f.m, sp: F.sp, look: null, tint: null, sz: "G" } : { ...f.m, tint: F.tint, sz: (f.m && f.m.sz) || "G" };
    if (H.setLook) H.setLook(f.ent, F.sp || f.m.sp, m);
  } catch {}
  /* 相棒（名を 呼ぶ 子）: 人ごとに 1回 読む */
  S.pal = new Set(); for (const x of B.players || []) try { const d = load(x.p); if (d && d.partnerId) S.pal.add(d.partnerId); } catch {}
  return f;
}
/* 少しずつ 大きく（体の 大きさ）*/
function grow(f, k, step, n) { try { const e = f.ent; if (!okE(e)) return; const s0 = f.fmSz0 || (f.fmSz0 = Number(e.getProperty("mrpg:size")) || 1000), v = Math.min(2500, Math.round(s0 * (1 + ((k - 1) * step) / n))); e.setProperty("mrpg:size", v); e.setDynamicProperty("mrpg:bsize", v); } catch {} }
/* 毎行動の あと（battle.js）: 変わる ときは 演出つき */
export async function fmTick(B, names, log, H = {}) {
  const f = fmDue(B); if (!f) return false;
  const S = B.fm, F = FORMS[S.key], P = names(), wt = H.wait || wait;
  S.ph = 2;
  /* 1 音が 沈み、カメラが 大きく 引く */
  sfx(B, "mob.wither.ambient", 0.5); sfx(B, F.snd[0], F.snd[1]);
  const e = f.ent, l = okE(e) ? e.location : null;
  let ux = 0, uz = 1; try { const p0 = P[0].location; const dx = p0.x - l.x, dz = p0.z - l.z, n = Math.hypot(dx, dz) || 1; ux = dx / n; uz = dz / n; } catch {}
  const at = (r, h, side = 0) => (l ? { x: l.x + ux * r - uz * side, y: l.y + h, z: l.z + uz * r + ux * side } : null), look = (h) => (l ? { x: l.x, y: l.y + h, z: l.z } : null);
  if (l && H.cam) for (const p of P) H.cam(p, at(11, 5, 4), look(2), 1.2);
  for (let k = 0; k < 3; k++) { ptc(B, f, F.ptc, 10, 2.6 - k * 0.6, 0.3 + k * 0.8); ptc(B, f, F.p2, 6, 1.8 - k * 0.4, 1 + k * 0.6); await wt(6); }
  /* 2 体が 書きかわり、少しずつ 大きく なる */
  fmApply(B, f, H);
  if (H.vfx && okE(e)) { H.vfx(e, "pillar", 0, F.col, 2.4); H.vfx(e, "shards", 1.5, F.col, 1.4); }
  for (let k = 1; k <= 4; k++) { grow(f, k, F.grow - 1, 4); ptc(B, f, F.ptc, 8, 1.2 + k * 0.4, 0.5 + k * 0.7); if (k === 2) { sfx(B, "mob.enderdragon.growl", 0.6); for (const x of B.players || []) try { x.p.runCommand("camerashake add @s 0.5 0.6 positional"); } catch {} } await wt(5); }
  /* 3 低い 角度から 見上げる → 一言 */
  if (l && H.cam) for (const p of P) H.cam(p, at(4.5, 0.6, -1.5), look(3.2), 0.8);
  if (H.anim && okE(e)) H.anim(e, "g_roar");
  sfx(B, "mob.wither.spawn", 0.6);
  await wt(10);
  if (H.playFx) await H.playFx(P, { mvName: F.title }, F.lines); log.push(...F.lines);
  try { if (H.hpTags) H.hpTags(B); } catch {}
  return true;
}

/* ---------- ギミック（B.tkg の 形）---------- */
const brk = (B) => B.fm.brkT >= T(B);
const isPal = (B, f) => !!f && !!f.m && (B.fm.pal && B.fm.pal.has(f.m.id) || f.m.partner === true);
const HOOKS = {
  start(B, log) {
    const S = B.fm; if (!S || S.ph !== 2 || S.lastStart === T(B)) return null; S.lastStart = T(B); S.callT.clear();
    const f = S.host, t = T(B); if (!f || f.hp <= 0) return null;
    if (S.key === "theo") {
      if (S.brkT && S.brkT < t && !S.back) { S.back = true; log.push("§5床の 紫の 字が、また 書き直された……"); }
      if (brk(B)) { log.push(`§d§l字が 崩れて いる！ §r§dセオの 写しも 名も 止まった（あと ${S.brkT - t + 1}ラウンド）`); return "§d字が 崩れて いる"; }
      let nm = "";
      S.copyNow = S.copy && MOVES[S.copy] ? S.copy : null; S.copyNowFrom = S.copyFrom; S.copy = null; S.copyD = 0;
      if (S.copyNow) { S.copyT = t; log.push(`§5§lインクの 手が ${MOVES[S.copyNow].name}を 写しとった！ §r§7（このラウンド、同じ 技で 返して くる）`); nm = `§5写し：${MOVES[S.copyNow].name}`; ptc(B, f, "minecraft:enchanting_table_particle", 10, 1.4, 2); }
      if (t % 2 === 0) {
        const L = alive(B.allies).filter((x) => !x.out); const top = L.sort((a, b) => (S.dealt.get(b) || 0) - (S.dealt.get(a) || 0))[0];
        if (top) { top.fmBindT = t; S.bound = top; log.push(`§5§l床に 紫の 字で「${top.name}」と 書かれた！ §r§c${top.name}は この ラウンド 動けない §7（名を 呼べば 字は 崩れる）`); ptc(B, top, "minecraft:enchanting_table_particle", 12, 1, 0.2); ptc(B, top, "minecraft:portal_reverse_particle", 6, 0.8, 0.1); sfx(B, "item.book.put", 0.6); nm = nm || `§5名を 書く：${top.name}`; }
      }
      S.dealt.clear();
      return nm || null;
    }
    /* 神: 3ラウンドごとに 頁を 読み上げる（書き写した 強化を 自分の ものに）*/
    if (S.name) return null;
    if (t % 3 === 0) {
      const ks = Object.keys(S.rec).filter((k) => S.rec[k] > 0);
      if (ks.length) {
        f.buf = f.buf || {}; for (const k of ks) f.buf[k] = Math.min(4, Math.max(f.buf[k] || 0, 0) + S.rec[k]);
        for (const a of alive(B.allies)) if (a.buf) for (const k of Object.keys(a.buf)) if (a.buf[k] > 0) a.buf[k] = 0;
        log.push(`§f§l顔の 頁を 読み上げた！ §r§c書き写した 強化（${ks.map((k) => `${SNM[k] || k}+${S.rec[k]}`).join("・")}）が 神の ものに なり、こちらの 強化は 消えた`);
        S.rec = {}; ptc(B, f, "minecraft:endrod", 12, 2, 2); sfx(B, "item.book.page_turn", 0.7);
        return "§f頁を 読み上げた";
      }
    }
    return null;
  },
  end(B, log) {
    const S = B.fm; if (!S || S.ph !== 2) return;
    const f = S.host;
    if (S.key === "volnag" && f && f.hp > 0) {
      if (!S.name && f.hp <= f.mx.hp * 0.2) {   /* 山場: 破れた 頁の 端の 金の 一行（名は まだ 声に 出さない）*/
        S.name = true; S.rec = {};
        if (f.buf) for (const k of Object.keys(f.buf)) if (f.buf[k] > 0) f.buf[k] = 0;
        f.floorBuf = 0;
        log.push("§e§l破れた 頁の 端に、一行だけ 字が 残って いた。", "§e……名だ。神が 自分で 破った、自分の 名。", "§f仲間たちが その 行を 見上げた。§7頁は 白く なり、もう 何も 書き写せない（神の 強化が 消え、受ける ダメージ 1.3倍）");
        ptc(B, f, "minecraft:totem_particle", 12, 1.2, 3); sfx(B, "block.bell.hit", 0.6); return;
      }
      if (S.name) return;
      const r = {}; for (const a of alive(B.allies)) for (const k of STATS) { const v = (a.buf && a.buf[k]) || 0; if (v > 0) r[k] = Math.max(r[k] || 0, v); }
      const ks = Object.keys(r); let ch = false; for (const k of ks) if ((S.rec[k] || 0) < r[k]) { S.rec[k] = Math.min(3, r[k]); ch = true; }
      if (ch) { log.push(`§7顔の 頁が、あなたたちの 強化を 書き写した（${Object.keys(S.rec).map((k) => `${SNM[k]}+${S.rec[k]}`).join("・")}）§8― ${3 - ((T(B)) % 3)}ラウンド後に 読み上げる`); ptc(B, f, "minecraft:white_smoke_particle", 8, 1.6, 2.5); }
    }
  },
  dmg(B, f, t, d, mv) {
    const S = B.fm; if (!S) return d;
    if (S.ph === 1 && t === S.host && d >= t.hp) return Math.max(0, t.hp - 1);   /* 変わる 前に 倒れない（第2形態は かならず 見せる）*/
    if (S.ph !== 2 || t !== S.host || !f || f.side !== "a") return d;
    if (S.key === "theo" && brk(B)) return d * 1.5;
    if (S.key === "volnag" && S.name) return d * 1.3;
    return d;
  },
  hit() { return null; },
  heal() { return false; },
  dot(B, t, d) { return d; },
  act(B, a, log) {
    const S = B.fm, f = a && a.actor; if (!S || S.ph !== 2 || S.key !== "theo" || !f || f.side !== "a" || f.hp <= 0) return null;
    if (f.fmBindT === T(B) && !brk(B)) { log.push(`§5${f.name}は 床に 名を 書かれて 動けない！`); return { fx: { actor: f, anim: "guard", el: null, hit: [], ko: [], healed: [], cat: null } }; }
    if ((a.kind === "defend" || isPal(B, f)) && !S.callT.has(f) && !brk(B)) {
      S.callT.add(f); S.calls++;
      log.push(`§e§l${f.name}が「セオ」と 呼んだ！ §r§e（${S.calls}/3）`); sfx(B, "mob.wolf.bark", 1 - 0.1 * (S.calls - 1)); ptc(B, f, "minecraft:note", 3, 0.4, 1.2);
      if (S.calls >= 3) {
        S.calls = 0; S.brkT = T(B) + 1; S.back = false; S.copy = null; S.copyNow = null; S.copyT = 0; for (const x of B.allies) if (x.fmBindT) x.fmBindT = 0;
        const h = S.host; if (h && h.buf) for (const k of Object.keys(h.buf)) if (h.buf[k] > 0) h.buf[k] = 0;
        log.push("§d§l三度 名を 呼ばれ、紫の 字が 崩れた！ §r§d写しと 名を 書くが 止まり、セオの 強化が 消えた（2ラウンド 受ける ダメージ 1.5倍）");
        ptc(B, h, "minecraft:enchanting_table_particle", 16, 2.4, 1); sfx(B, "random.glass", 0.6);
      }
    }
    return null;
  },
  after(B, a, fx) {
    const S = B.fm; if (!S || S.key !== "theo" || !a || !a.actor || !fx) return;
    const f = a.actor;
    if (f.side === "a" && S.ph === 2) {
      const sum = (fx.dmg || []).filter((x) => x.t === S.host || (x.t && x.t.side === "e")).reduce((s, x) => s + (x.d || 0), 0);
      if (sum > 0) { S.dealt.set(f, (S.dealt.get(f) || 0) + sum); const mv = fx.mid && fx.mid !== "basic" ? MOVES[fx.mid] : null; if (!NOCOPY(mv) && sum >= (S.copyD || 0)) { S.copy = fx.mid; S.copyD = sum; S.copyFrom = f; } }
    }
  },
  ai(f, B) {
    const S = B.fm; if (!S || S.ph !== 2 || S.key !== "theo" || f !== S.host || brk(B)) return null;
    if (S.copyT === T(B) && S.copyNow && MOVES[S.copyNow] && S.copyUsed !== T(B)) {
      const L = alive(B.allies); if (!L.length) return null;
      S.copyUsed = T(B); const tg = S.copyNowFrom && S.copyNowFrom.hp > 0 ? S.copyNowFrom : L[0];
      return { actor: f, kind: "move", move: S.copyNow, target: tg, free: true, fmCopy: true };
    }
    return null;
  },
};
export const FM_DEBUG = { HOOKS, NEWMV };
