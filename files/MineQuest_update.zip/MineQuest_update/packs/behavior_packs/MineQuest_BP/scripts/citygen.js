// 第77版: 滅びた 世界ルインヘイム（灰都）の 街の 計算（マイクラの API は 使わない）。配布マップの 街と 同じ 形を つくる
// マイクラのAPIは使わない計算だけの部分。マップの書き出し（tools/world.mjs）とプレビュー（tools/）で使う。
// 街は 128×128 の「区画」を CITY.N × CITY.N 並べたもの。区画の境目は幅16の大通り（都心と水没地区では深い運河）。
// 区画の中（8〜119）には、区画ごとに「巨大建築」「傾いた格子の巨塔」「高層ビル街」「沼の広場」「名所」のどれかを置く。

export const CITY = { SIZE: 128, N: 24, Y0: -23, SY: 224 }; // 24区画 × 128 = 3072マス四方。y は -23〜200（地面が 0）
const AV = 8;        // 大通りの片側の幅（区画の端から8マス。隣の区画と合わせて16）
const CANAL = 5;     // 運河の片側の幅（合わせて10）
const IN0 = AV, IN1 = 128 - AV; // 区画の中の範囲 [IN0, IN1)

// ───── 乱数・ノイズ ─────
export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function h32(a) {
  a |= 0;
  a = Math.imul(a ^ (a >>> 16), 0x45d9f3b);
  a = Math.imul(a ^ (a >>> 16), 0x45d9f3b);
  return (a ^ (a >>> 16)) >>> 0;
}
export function hash(x, y, z, s) {
  return h32((x * 73856093) ^ h32((y * 19349663) ^ h32((z * 83492791) ^ s))) / 4294967296;
}
const sm = (t) => t * t * (3 - 2 * t);
const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (t) => (t < 0 ? 0 : t > 1 ? 1 : t);
export function noise3(x, y, z, s) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const u = sm(x - xi), v = sm(y - yi), w = sm(z - zi);
  const c = (dx, dy, dz) => hash(xi + dx, yi + dy, zi + dz, s);
  return lerp(
    lerp(lerp(c(0, 0, 0), c(1, 0, 0), u), lerp(c(0, 1, 0), c(1, 1, 0), u), v),
    lerp(lerp(c(0, 0, 1), c(1, 0, 1), u), lerp(c(0, 1, 1), c(1, 1, 1), u), v),
    w
  );
}
export function fbm3(x, y, z, s) {
  return noise3(x, y, z, s) * 0.6 + noise3(x * 2.1, y * 2.1, z * 2.1, s + 7) * 0.3 + noise3(x * 4.3, y * 4.3, z * 4.3, s + 13) * 0.1;
}

// ───── ブロックの格子 ─────
// パレットの名前は "stone_bricks" や "vine|vine_direction_bits=8" の形（状態は | の後ろ）
export class Grid {
  constructor(sx, sy, sz, y0) {
    this.sx = sx; this.sy = sy; this.sz = sz; this.y0 = y0;
    this.d = new Uint8Array(sx * sy * sz);
    this.palette = ["air"];
    this.pidx = new Map([["air", 0]]);
    this.soft = [true]; // 苔・ツタ・雪が付かない（空気・水・植物・ガラスなど）
  }
  id(name) {
    let i = this.pidx.get(name);
    if (i === undefined) {
      i = this.palette.length;
      if (i > 255) throw new Error("ブロックの種類が多すぎます");
      this.palette.push(name);
      this.pidx.set(name, i);
      this.soft.push(SOFT.test(name));
    }
    return i;
  }
  inb(x, y, z) { return x >= 0 && x < this.sx && z >= 0 && z < this.sz && y >= this.y0 && y < this.y0 + this.sy; }
  idx(x, y, z) { return ((y - this.y0) * this.sz + z) * this.sx + x; }
  get(x, y, z) { return this.inb(x, y, z) ? this.d[this.idx(x, y, z)] : 0; }
  set(x, y, z, name) { if (this.inb(x, y, z)) this.d[this.idx(x, y, z)] = this.id(name); }
  setIfAir(x, y, z, name) { if (this.inb(x, y, z) && this.d[this.idx(x, y, z)] === 0) this.d[this.idx(x, y, z)] = this.id(name); }
  isAir(x, y, z) { return this.get(x, y, z) === 0; }
  isHard(x, y, z) { const v = this.get(x, y, z); return v !== 0 && !this.soft[v]; }
  name(x, y, z) { return this.palette[this.get(x, y, z)]; }
}
const SOFT = /^(air|water|vine.*|moss_carpet|short_grass|fern|tall_grass.*|seagrass.*|waterlily|deadbush|short_dry_grass|tall_dry_grass|snow_layer.*|iron_bars|lantern.*|glass|.*_glass|.*leaves.*|hanging_roots|.*_wall\|.*|frame\|.*|campfire\|.*|barrel\|.*|lectern\|.*|chest\|.*|cartography_table)$/;
const LEAF = (n) => `${n}|persistent_bit=true`;

// ───── 素材 ─────
const M_STONE = { wall: "stone_bricks", frame: "stone_bricks", floor: "smooth_stone", cracked: "cracked_stone_bricks", mossy: "mossy_stone_bricks", glass: "gray_stained_glass", trim: "chiseled_stone_bricks" };
const M_CONC = { wall: "light_gray_concrete", frame: "smooth_stone", floor: "smooth_stone", cracked: "andesite", mossy: "mossy_cobblestone", glass: "gray_stained_glass", trim: "polished_andesite" };
const M_ANDE = { wall: "polished_andesite", frame: "stone_bricks", floor: "smooth_stone", cracked: "andesite", mossy: "mossy_stone_bricks", glass: "light_gray_stained_glass", trim: "stone_bricks" };
const M_TUFF = { wall: "tuff_bricks", frame: "polished_tuff", floor: "polished_tuff", cracked: "tuff", mossy: "mossy_stone_bricks", glass: "gray_stained_glass", trim: "polished_tuff" };
const M_DEEP = { wall: "deepslate_bricks", frame: "polished_deepslate", floor: "polished_deepslate", cracked: "cracked_deepslate_bricks", mossy: "mossy_stone_bricks", glass: "gray_stained_glass", trim: "deepslate_tiles" };
const M_SAND = { wall: "sandstone", frame: "cut_sandstone", floor: "smooth_sandstone", cracked: "sandstone", mossy: "smooth_sandstone", glass: "gray_stained_glass", trim: "chiseled_sandstone" };
const M_LAB = { wall: "calcite", frame: "polished_diorite", floor: "smooth_stone", cracked: "diorite", mossy: "polished_diorite", glass: "light_blue_stained_glass", trim: "polished_diorite" };
const M_COPPER = { wall: "oxidized_copper_grate", frame: "oxidized_cut_copper", floor: "smooth_stone", cracked: "weathered_cut_copper", mossy: "mossy_stone_bricks", glass: "gray_stained_glass", trim: "oxidized_cut_copper" };

// ───── 地区（物語の章ごとに景色を変える） ─────
// kinds: 区画の種類の重み [巨大建築, 格子の巨塔, 高層ビル街, 沼の広場, 崖と湖, 工場, 古代遺跡]
// h: 高層ビルの高さ / mh: 巨大建築の高さ / water: 沼の池のしきい値 / moss: 苔のしきい値（低いほど多い） / vine: ツタの量
export const THEMES = {
  core:   { label: "都心",       mats: [M_STONE, M_CONC, M_ANDE, M_DEEP, M_TUFF], kinds: [0.28, 0.16, 0.4, 0.03, 0.0, 0.08, 0.05], h: [70, 185], mh: [50, 100], water: 0.66, moss: 0.52, vine: 0.025 },
  flood:  { label: "水没地区",   mats: [M_STONE, M_CONC, M_ANDE, M_TUFF],         kinds: [0.18, 0.28, 0.12, 0.14, 0.14, 0.08, 0.06], h: [45, 120], mh: [40, 80],  water: 0.48, moss: 0.47, vine: 0.035 },
  forest: { label: "森の遺跡",   mats: [M_STONE, M_ANDE, M_TUFF, M_DEEP],         kinds: [0.1, 0.12, 0.12, 0.2, 0.26, 0.06, 0.14],  h: [28, 70],  mh: [26, 55],  water: 0.6,  moss: 0.4,  vine: 0.06 },
  sand:   { label: "砂の区画",   mats: [M_SAND, M_SAND, M_CONC, M_ANDE],          kinds: [0.2, 0.08, 0.18, 0.14, 0.2, 0.06, 0.14],   h: [30, 85],  mh: [26, 60],  water: 9,    moss: 9,    vine: 0 },
  snow:   { label: "雪の研究区", mats: [M_LAB, M_LAB, M_STONE, M_CONC],           kinds: [0.18, 0.06, 0.2, 0.16, 0.22, 0.1, 0.08],   h: [24, 70],  mh: [24, 50],  water: 0.62, moss: 9,    vine: 0 },
};
const ZN = ["core", "flood", "forest", "sand", "snow"];

// 街全体の座標 (wx, wz) がどの地区か。r は中心からの距離（端の中央で 1）
export function zoneAt(wx, wz, seed) {
  const half = (CITY.SIZE * CITY.N) / 2;
  const dx = wx - half, dz = wz - half;
  const r = Math.hypot(dx, dz) / half + (fbm3(wx * 0.004, 0, wz * 0.004, seed + 90) - 0.5) * 0.16;
  let name;
  if (r < 0.27) name = "core";
  else if (r < 0.58) name = "flood";
  else {
    let a = Math.atan2(dz, dx) / (2 * Math.PI) + 0.5 + (fbm3(wx * 0.003, 1, wz * 0.003, seed + 91) - 0.5) * 0.14;
    a = ((a % 1) + 1) % 1;
    name = a < 1 / 3 ? "forest" : a < 2 / 3 ? "sand" : "snow";
  }
  return { name, r, wild: clamp01((r - 0.92) / 0.2) }; // wild: 街の外側ほど 1（建物がまばら・低い）
}

// ───── 名所 ─────
// 区画の番号は街の番号（seed）から決まる。物語のアドオンが同じ関数で場所を知れるように export する
export const LANDMARK_INFO = {
  tower:   { label: "中央電波塔",       zone: "core" },
  stadium: { label: "廃スタジアム",     zone: "core" },
  wheel:   { label: "沈んだ観覧車",     zone: "flood" },
  bigtree: { label: "森の巨大樹",       zone: "forest" },
  temple:  { label: "砂に埋もれた神殿", zone: "sand" },
  lab:     { label: "雪の研究所",       zone: "snow" },
  plant:   { label: "古い発電所",       zone: "flood" },
  camp:    { label: "渡し場の野営地",   zone: "core" },
};
const lmCache = new Map();
export function landmarks(seed) {
  if (lmCache.has(seed)) return lmCache.get(seed);
  const N = CITY.N, S = CITY.SIZE, half = (N * S) / 2;
  const out = { tower: [11, 11], stadium: [12, 12], camp: [12, 14] };
  const used = new Set(["11,11", "12,12", "12,14"]);
  // 観覧車：中心の北（水没地区）。森・砂・雪：その地区の扇形のまん中あたり（r≈0.75）
  const targets = { plant: [0.45, 0.0], wheel: [0.42, -0.25], bigtree: [0.75, 1 / 6 - 0.5], temple: [0.75, 0.5 - 0.5], lab: [0.75, 5 / 6 - 0.5] };
  for (const [k, [tr, ta]] of Object.entries(targets)) {
    let best = null;
    for (let j = 1; j < N - 1; j++)
      for (let i = 1; i < N - 1; i++) {
        if (used.has(`${i},${j}`)) continue;
        const cx = i * S + 64, cz = j * S + 64;
        const z = zoneAt(cx, cz, seed);
        if (z.name !== LANDMARK_INFO[k].zone || z.wild > 0) continue;
        const a = Math.atan2(cz - half, cx - half) / (2 * Math.PI); // -0.5〜0.5
        let da = Math.abs(a - ta); da = Math.min(da, 1 - da);
        const sc = Math.abs(z.r - tr) + da;
        if (!best || sc < best.sc) best = { sc, i, j };
      }
    if (best) { out[k] = [best.i, best.j]; used.add(`${best.i},${best.j}`); }
  }
  lmCache.set(seed, out);
  return out;
}

// ───── 大通り・運河 ─────
const bandDist = (m) => (m < 64 ? m + 0.5 : 128 - m - 0.5); // 区画の境目の線までの距離
// 境目 b（0〜N）にそって走る運河が、区画の行 k のところで運河かどうか
function canalSeg(seed, b, k, alongZ) {
  const N = CITY.N, S = CITY.SIZE;
  if (b <= 0 || b >= N || k < 0 || k >= N) return false;
  const z = alongZ ? zoneAt(b * S, k * S + 64, seed) : zoneAt(k * S + 64, b * S, seed);
  return z.name === "core" || z.name === "flood";
}

// ───── 建物1棟の形 ─────
// ローカル座標 (lx, ly, lz) のブロック名を返す（何も置かないなら null）。床は4マスごと
// style: lattice（格子）/ office（柱と横長窓）/ band（帯窓）/ classical（柱が並ぶ古い建物・1〜2階は柱廊）
const STAIR = (dir) => `stone_brick_stairs|upside_down_bit=0,weirdo_direction=${dir}`; // 0=東へ上る 1=西へ上る
function makeTower(o) {
  const { w, d, h, style, mats, ts, crownLoss, dmgBase } = o;
  const doorX = o.doorX ?? (w >> 1), doorZ = o.doorZ ?? (d >> 1);
  const stairs = o.stairs !== false && w >= 9 && d >= 9;
  const holes = o.holes ?? 0.7;
  const crownH = new Int16Array(w * d); // 屋上の崩れ方は列ごとに1回だけ計算
  for (let lz = 0; lz < d; lz++) for (let lx = 0; lx < w; lx++) crownH[lz * w + lx] = h - Math.floor(noise3(lx * 0.13, 0.5, lz * 0.13, ts) * h * crownLoss);
  return (lx, ly, lz) => {
    if (lx < 0 || lz < 0 || lx >= w || lz >= d || ly < 0 || ly > h) return null;
    if (ly > crownH[lz * w + lx]) return null;
    // 階段：上る段・頭上の床の穴・着いた先の床は、崩れたり抜けたりしない
    if (stairs && lx >= 2 && lx <= 5 && lz >= 2 && lz <= 3) {
      const f = ly >> 2, m = ly & 3, lane = lz - 2;
      if (m === 0) {
        if (ly > 0 && ((f - 1) & 1) === lane && (lane === 0 ? lx <= 4 : lx >= 3)) return null;
        return mats.floor;
      }
      if ((f & 1) !== lane) return null;
      const k = m - 1;
      if (lane === 0 && lx === 2 + k) return STAIR(0);
      if (lane === 1 && lx === 5 - k) return STAIR(1);
      return null;
    }
    const ex = lx === 0 || lx === w - 1, ez = lz === 0 || lz === d - 1;
    let kind;
    if (ex || ez) {
      const u = ez ? lx : lz;
      const corner = ex && ez;
      if (style === "classical") {
        if (corner || u % 4 === 0) kind = "frame";
        else if (ly >= 1 && ly <= 7) return ly === 7 ? mats.trim : null; // 柱廊（1〜2階は柱だけ）
        else if (ly % 4 === 0) kind = "wall";
        else kind = "win";
      } else {
        if (!corner && ly >= 1 && ly <= 3 && Math.abs(u - (ez ? doorX : doorZ)) <= 1) return null; // 1階の入口
        if (corner) kind = "frame";
        else if (style === "lattice") kind = u % 2 === 0 || ly % 2 === 0 ? "wall" : "win";
        else if (style === "office") kind = u % 4 === 0 ? "frame" : ly % 4 === 0 ? "wall" : "win";
        else kind = ly % 4 <= 1 ? "wall" : u % 6 === 0 ? "frame" : "win"; // band
      }
    } else if (ly % 4 === 0) kind = "floor";
    else if (lx % 6 === 0 && lz % 6 === 0) kind = "frame";
    else return null;
    const r = hash(lx, ly, lz, ts + 2);
    if (kind === "win" && r >= 0.14) return null; // 割れた窓（中は暗い）
    const rel = ly / h;
    if (ly > 1 && fbm3(lx * 0.085, ly * 0.06, lz * 0.085, ts + 1) > dmgBase - 0.2 * rel) return null;
    if (kind === "floor" && ly > 0 && fbm3(lx * 0.2, ly * 0.3, lz * 0.2, ts + 3) > holes) return null; // 床の抜け
    if (kind === "win") return r < 0.11 ? mats.glass : "iron_bars";
    if (kind === "floor") return r < 0.2 ? mats.cracked : mats.floor;
    const moss = fbm3(lx * 0.1, ly * 0.1, lz * 0.1, ts + 4) + 0.35 - 0.5 * rel;
    if (r < moss * 0.35) return mats.mossy;
    if (r > 0.86) return mats.cracked;
    if (style === "classical" && ly % 16 === 15 && kind === "wall") return mats.trim;
    return kind === "frame" ? mats.frame : mats.wall;
  };
}

// ───── 回転した箱を置く ─────
// 箱（幅w・奥行d・高さh）の足もとの中心を軸に、x軸まわり rx・z軸まわり rz（ラジアン）だけ傾けて、(px, -sink, pz) に置く。
// 置く先の各マスから箱の中へ逆に戻して調べるので、斜めでも穴があかない。clip は置いてよい範囲 [x0,x1)×[z0,z1)
function rotMat(rx, rz) {
  const cx = Math.cos(rx), sx = Math.sin(rx), cz = Math.cos(rz), sz = Math.sin(rz);
  return [[cz, -sz * cx, sz * sx], [sz, cz * cx, -cz * sx], [0, sx, cx]]; // Rz・Rx
}
function rotBox(w, d, h, R) {
  let b = [1e9, -1e9, 1e9, -1e9, 1e9, -1e9];
  for (const x of [-w / 2, w / 2]) for (const y of [0, h + 1]) for (const z of [-d / 2, d / 2]) {
    const X = R[0][0] * x + R[0][1] * y + R[0][2] * z, Y = R[1][0] * x + R[1][1] * y + R[1][2] * z, Z = R[2][0] * x + R[2][1] * y + R[2][2] * z;
    b = [Math.min(b[0], X), Math.max(b[1], X), Math.min(b[2], Y), Math.max(b[3], Y), Math.min(b[4], Z), Math.max(b[5], Z)];
  }
  return b;
}
function placeRot(g, px, pz, sink, w, d, h, R, sample, clip) {
  const b = rotBox(w, d, h, R);
  const X0 = Math.max(clip[0], Math.floor(px + b[0]) - 1), X1 = Math.min(clip[1] - 1, Math.ceil(px + b[1]) + 1);
  const Z0 = Math.max(clip[2], Math.floor(pz + b[4]) - 1), Z1 = Math.min(clip[3] - 1, Math.ceil(pz + b[5]) + 1);
  const Y0 = Math.max(g.y0, Math.floor(b[2] - sink) - 1), Y1 = Math.min(g.y0 + g.sy - 1, Math.ceil(b[3] - sink) + 1);
  const hw = w / 2, hd = d / 2;
  for (let X = X0; X <= X1; X++)
    for (let Z = Z0; Z <= Z1; Z++) {
      const qx = X + 0.5 - px, qz = Z + 0.5 - pz;
      for (let Y = Y0; Y <= Y1; Y++) {
        const qy = Y + 0.5 + sink;
        // 逆回転（転置）
        const lx = R[0][0] * qx + R[1][0] * qy + R[2][0] * qz;
        const ly = R[0][1] * qx + R[1][1] * qy + R[2][1] * qz;
        const lz = R[0][2] * qx + R[1][2] * qy + R[2][2] * qz;
        const ix = Math.floor(lx + hw), iy = Math.floor(ly), iz = Math.floor(lz + hd);
        if (ix < 0 || ix >= w || iz < 0 || iz >= d || iy < 0 || iy > h) continue;
        const bname = sample(ix, iy, iz);
        if (bname) g.set(X, Y, Z, bname);
      }
    }
}
// 範囲 [x0,x1)×[z0,z1) に収まるように、傾けた箱の置き場所を決める（収まらなければ傾きを弱める）
function fitRot(rng, w, d, h, rx, rz, area) {
  for (let k = 0; k < 6; k++) {
    const R = rotMat(rx, rz), b = rotBox(w, d, h, R);
    const pxLo = area[0] - b[0], pxHi = area[1] - b[1], pzLo = area[2] - b[4], pzHi = area[3] - b[5];
    if (pxLo <= pxHi && pzLo <= pzHi) return { R, px: lerp(pxLo, pxHi, rng()), pz: lerp(pzLo, pzHi, rng()), rx, rz };
    rx *= 0.7; rz *= 0.7;
  }
  return null;
}

// ───── 小物 ─────
function heap(g, cx, cz, r, hmax, mats, s) {
  const pool = [mats.wall, mats.cracked, mats.mossy, "cobblestone", "andesite", "gravel", "mossy_cobblestone"];
  for (let x = Math.floor(cx - r); x <= cx + r; x++)
    for (let z = Math.floor(cz - r); z <= cz + r; z++) {
      const dd = ((x - cx) ** 2 + (z - cz) ** 2) / (r * r);
      if (dd > 1) continue;
      const top = Math.floor(hmax * (1 - dd) * (0.55 + 0.45 * noise3(x * 0.3, 0, z * 0.3, s)));
      for (let y = 1; y <= top; y++) g.setIfAir(x, y, z, pool[Math.floor(hash(x, y, z, s + 1) * pool.length)]);
    }
}
function blob(g, cx, cy, cz, r, name, s, squash = 1.6) {
  for (let dx = -Math.ceil(r) - 1; dx <= r + 1; dx++)
    for (let dy = -Math.ceil(r) - 1; dy <= r + 1; dy++)
      for (let dz = -Math.ceil(r) - 1; dz <= r + 1; dz++) {
        const dd = Math.sqrt(dx * dx + dy * dy * squash + dz * dz) / r;
        if (dd > 1 - 0.3 * (noise3((cx + dx) * 0.3, (cy + dy) * 0.3, (cz + dz) * 0.3, s) - 0.5) * 2) continue;
        g.setIfAir(cx + dx, cy + dy, cz + dz, typeof name === "function" ? name(dx, dy, dz) : name);
      }
}
function tree(g, x, y, z, s, kind) {
  const r0 = hash(x, 0, z, s);
  const big = kind === "big", spruce = kind === "spruce";
  const th = big ? 8 + Math.floor(r0 * 4) : spruce ? 5 + Math.floor(r0 * 5) : 3 + Math.floor(r0 * 3);
  for (let i = 0; i < th; i++) g.set(x, y + i, z, big ? "dark_oak_log" : spruce ? "spruce_log" : "oak_log");
  if (spruce) {
    for (let dy = 2; dy <= th + 1; dy++) {
      const rr = Math.max(0.6, ((th + 1 - dy) / th) * 3.2);
      for (let dx = -3; dx <= 3; dx++) for (let dz = -3; dz <= 3; dz++)
        if (dx * dx + dz * dz <= rr * rr) g.setIfAir(x + dx, y + dy, z + dz, LEAF("spruce_leaves"));
    }
    return;
  }
  blob(g, x, y + th, z, big ? 4.2 : 2.2, (dx, dy, dz) => (big && hash(dx, dy, dz, s + 3) < 0.15 ? LEAF("azalea_leaves_flowered") : big ? LEAF("jungle_leaves") : LEAF("azalea_leaves")), s + 2);
}
const LAMP_POST = "stone_brick_wall|wall_connection_type_east=none,wall_connection_type_north=none,wall_connection_type_south=none,wall_connection_type_west=none,wall_post_bit=1";
function lamp(g, x, z, s) {
  if (!g.isHard(x, 0, z)) return;
  const h = 3 + Math.floor(hash(x, 0, z, s) * 2);
  if (hash(x, 1, z, s) < 0.3) { g.set(x, 1, z, LAMP_POST); return; } // 折れた街灯
  for (let y = 1; y <= h; y++) g.set(x, y, z, LAMP_POST);
  g.set(x, h + 1, z, "lantern|hanging=0");
}
// 崩れた低い壁（遺跡の名残）
function ruinWall(g, x0, z0, len, alongX, mats, s) {
  for (let i = 0; i < len; i++) {
    const x = alongX ? x0 + i : x0, z = alongX ? z0 : z0 + i;
    const hh = Math.floor(noise3(i * 0.25, 0, s * 0.001, s) * 6) - 1;
    for (let y = 1; y <= hh; y++) g.set(x, y, z, hash(x, y, z, s) < 0.3 ? mats.mossy : hash(x, y, z, s + 1) < 0.3 ? mats.cracked : mats.wall);
  }
}

// ───── 区画の中身 ─────
// ひとつの区画の中に建物を建てる。towers に「傾いていないビル」を登録すると、あとで渡り廊下でつながる
function lotTowers(g, rng, T, zone, mats0, towers) {
  // 区画の中をさらに十字の通り（幅8）で4つに分ける
  const lots = [[IN0, 60, IN0, 60], [68, IN1, IN0, 60], [IN0, 60, 68, IN1], [68, IN1, 68, IN1]];
  lots.forEach((a, li) => {
    const mats = T.mats[Math.floor(rng() * T.mats.length)] ?? mats0;
    const ts = Math.floor(rng() * 1e9);
    if (rng() < 0.06) { heap(g, (a[0] + a[1]) / 2, (a[2] + a[3]) / 2, 12 + rng() * 6, 8 + rng() * 6, mats, ts); return; } // がれきの山
    const w = 14 + 2 * Math.floor(rng() * 8), d = 14 + 2 * Math.floor(rng() * 8);
    let h = T.h[0] + Math.sqrt(rng()) * (T.h[1] - T.h[0]);
    if (zone.name === "core") h = lerp(h, T.h[1], clamp01(1 - zone.r / 0.27) * 0.5);
    h = Math.floor(Math.min(190, h * (1 - 0.65 * zone.wild)));
    const style = ["lattice", "office", "band", "classical"][Math.floor(rng() * 4)];
    const tilt = rng() < 0.3;
    const fit = fitRot(rng, w, d, h, tilt ? (rng() - 0.5) * 0.7 : 0, tilt ? (rng() - 0.5) * 0.7 : 0, [a[0] + 1, a[1] - 1, a[2] + 1, a[3] - 1]);
    if (!fit) return;
    const upright = fit.rx === 0 && fit.rz === 0;
    const px = upright ? Math.round(fit.px - w / 2) + w / 2 : fit.px, pz = upright ? Math.round(fit.pz - d / 2) + d / 2 : fit.pz;
    const tx = px - w / 2, tz = pz - d / 2;
    const sample = makeTower({ w, d, h, style, mats, ts, crownLoss: 0.25, dmgBase: 0.74, stairs: upright, doorX: w >> 1, doorZ: d >> 1 });
    placeRot(g, px, pz, upright ? 0 : 3 + Math.floor(rng() * 6), w, d, h, fit.R, sample, [0, 128, 0, 128]);
    if (upright) towers.push({ bx: li & 1, bz: li >> 1, tx, tz, w, d, h });
  });
}

function lotMega(g, rng, T, zone, towers) {
  // 柱の並ぶ巨大な古い建物を、L字・コの字・ロの字に組む（中庭ができる）
  const mats = rng() < 0.6 ? M_STONE : T.mats[Math.floor(rng() * T.mats.length)];
  const ts = Math.floor(rng() * 1e9);
  const h = Math.floor(Math.min(160, (T.mh[0] + rng() * (T.mh[1] - T.mh[0])) * (1 - 0.6 * zone.wild)) / 4) * 4;
  const depth = 22 + 4 * Math.floor(rng() * 3);
  const shape = Math.floor(rng() * 3); // 0:L 1:コ 2:ロ
  const a0 = IN0 + 2, a1 = IN1 - 2;
  const wings = [[a0, a1, a0, a0 + depth]]; // 北の棟
  wings.push([a0, a0 + depth, a0 + depth - 1, a1]); // 西の棟
  if (shape >= 1) wings.push([a1 - depth, a1, a0 + depth - 1, a1]); // 東の棟
  if (shape === 2) wings.push([a0 + depth - 1, a1 - depth + 1, a1 - depth, a1]); // 南の棟
  const R0 = rotMat(0, 0);
  wings.forEach(([x0, x1, z0, z1], k) => {
    const w = x1 - x0, d = z1 - z0, hh = k === 0 ? h : Math.max(24, h - 4 * Math.floor(rng() * 4));
    const sample = makeTower({ w, d, h: hh, style: "classical", mats, ts: ts + k, crownLoss: 0.12, dmgBase: 0.83, holes: 0.78 });
    placeRot(g, x0 + w / 2, z0 + d / 2, 0, w, d, hh, R0, sample, [0, 128, 0, 128]);
    // 屋上のふち（コーニス）：壁から1マス張り出す
    for (let x = x0 - 1; x <= x1; x++) for (let z = z0 - 1; z <= z1; z++) {
      if (x !== x0 - 1 && x !== x1 && z !== z0 - 1 && z !== z1) continue;
      if (noise3(x * 0.15, 0, z * 0.15, ts + k) < 0.3) continue; // 崩れたところ
      g.setIfAir(x, hh - 1, z, mats.trim);
    }
  });
  // 中庭：池と木
  const cx = (a0 + a1) / 2, cz = (a0 + depth + a1) / 2;
  tree(g, Math.floor(cx), 1, Math.floor(cz), ts + 50, "big");
}

function lotGiants(g, rng, T, zone) {
  // 格子の巨塔：2〜4本。大きく傾き、沼に沈みかけている
  const n = 2 + Math.floor(rng() * 3);
  const quads = [[IN0, 66, IN0, 66], [62, IN1, IN0, 66], [IN0, 66, 62, IN1], [62, IN1, 62, IN1]].sort(() => rng() - 0.5);
  for (let k = 0; k < n; k++) {
    const a = k === 0 && n === 2 ? [IN0, IN1, IN0, IN1] : quads[k];
    const w = 22 + 2 * Math.floor(rng() * 8), d = w + 2 * Math.floor((rng() - 0.5) * 4);
    const h = Math.floor(Math.min(170, (60 + rng() * 100) * (1 - 0.6 * zone.wild)));
    const mats = rng() < 0.7 ? M_STONE : T.mats[Math.floor(rng() * T.mats.length)];
    const ts = Math.floor(rng() * 1e9);
    const big = () => (rng() < 0.5 ? -1 : 1) * (0.25 + rng() * 0.45);
    const kind = rng();
    const rx = kind < 0.2 ? 0 : big(), rz = kind < 0.45 ? (rng() - 0.5) * 0.3 : big();
    const fit = fitRot(rng, w, d, h, rx, rz, [a[0] - 6, a[1] + 6, a[2] - 6, a[3] + 6].map((v) => Math.max(1, Math.min(127, v))));
    if (!fit) continue;
    const sample = makeTower({ w, d, h, style: "lattice", mats, ts, crownLoss: 0.1, dmgBase: 0.8, stairs: false, holes: 0.75 });
    placeRot(g, fit.px, fit.pz, 4 + Math.floor(rng() * 10), w, d, h, fit.R, sample, [1, 127, 1, 127]);
  }
}

function lotMarsh(g, rng, T, zone, mats) {
  // 見渡せる沼地と広場：崩れた壁・街灯・木・小さな沈んだ格子の塔
  const ts = Math.floor(rng() * 1e9);
  for (let k = 0; k < 6; k++) ruinWall(g, IN0 + 4 + Math.floor(rng() * 90), IN0 + 4 + Math.floor(rng() * 90), 6 + Math.floor(rng() * 16), rng() < 0.5, mats, ts + k);
  for (let x = IN0 + 4; x < IN1; x += 12) { lamp(g, x, 64, ts); lamp(g, 64, x, ts + 1); }
  const nt = zone.name === "sand" ? 0 : 3 + Math.floor(rng() * 6);
  for (let k = 0; k < nt; k++) {
    const x = IN0 + 3 + Math.floor(rng() * 104), z = IN0 + 3 + Math.floor(rng() * 104);
    const top = g.name(x, 0, z);
    if ((top === "grass_block" || top === "snow" || top === "moss_block") && g.isAir(x, 1, z)) tree(g, x, 1, z, ts + 30 + k, top === "snow" ? "spruce" : rng() < 0.3 ? "big" : "small");
  }
  if (rng() < 0.6) { // 小さな沈んだ格子の塔
    const w = 12 + 2 * Math.floor(rng() * 3), h = 18 + Math.floor(rng() * 20);
    const fit = fitRot(rng, w, w, h, (rng() - 0.5) * 1.2, (rng() - 0.5) * 1.2, [IN0 + 8, IN1 - 8, IN0 + 8, IN1 - 8]);
    if (fit) placeRot(g, fit.px, fit.pz, 6, w, w, h, fit.R, makeTower({ w, d: w, h, style: "lattice", mats, ts, crownLoss: 0.3, dmgBase: 0.7, stairs: false }), [1, 127, 1, 127]);
  }
}

// 円筒（rOf(y) で高さごとの半径。thick は壁の厚さ。0 なら中まで埋める）
function cyl(g, cx, cz, rOf, y0, y1, name, thick = 1.3) {
  for (let y = y0; y <= y1; y++) {
    const r = rOf(y), R = Math.ceil(r) + 1;
    for (let x = -R; x <= R; x++) for (let z = -R; z <= R; z++) {
      const d = Math.hypot(x + 0.5, z + 0.5);
      if (d > r || (thick > 0 && d <= r - thick)) continue;
      const n = typeof name === "function" ? name(x, y, z, d) : name;
      if (n) g.set(cx + x, y, cz + z, n);
    }
  }
}
const M_BRICK = { wall: "brick_block", frame: "polished_deepslate", floor: "smooth_stone", cracked: "cracked_deepslate_bricks", mossy: "mossy_stone_bricks", glass: "gray_stained_glass", trim: "polished_deepslate" };

function lotHighland(g, rng, zone, bx0, bz0, seed) {
  // 崖と湖：段になった高台（凸凹の崖・地層の筋）と、くぼ地の澄んだ湖。切り通しの坂道で高台へ登れる
  const zn = zone.name, sand = zn === "sand", snow = zn === "snow";
  const ts = Math.floor(rng() * 1e9), S = 128;
  const H = new Int16Array(S * S);
  const lift = (rng() - 0.3) * 30; // 区画ごとの高さのかたより
  for (let z = IN0; z < IN1; z++) for (let x = IN0; x < IN1; x++) {
    const wx = bx0 + x, wz = bz0 + z;
    const d = Math.min(x - IN0, IN1 - 1 - x, z - IN0, IN1 - 1 - z);
    const fade = sm(clamp01(d / 20));
    const n = fbm3(wx * 0.012, 0, wz * 0.012, seed + 300);
    let h = ((n - 0.42) * 170 + lift) * fade; // 端に近いほど低く（大通りとつながる）
    const jit = (noise3(wx * 0.09, 0, wz * 0.09, seed + 301) - 0.5) * 7;
    // 10マスごとの段にして、段と段のあいだを切り立った崖にする
    H[z * S + x] = h > 0 ? Math.min(60, Math.floor((h + jit) / 10) * 10) : Math.max(-12, Math.floor(h / 2));
  }
  // 坂道：区画の西の端と南の端から、高低差が1マスずつになるように地形にそって進む（盛り土・切り通し）
  const onPath = new Int16Array(S * S).fill(-999);
  const zc = 40 + Math.floor(rng() * 48), xc = 40 + Math.floor(rng() * 48);
  let py = 0;
  for (let x = IN0; x < IN1; x++) { const t = H[zc * S + x]; py = Math.max(py - 1, Math.min(py + 1, Math.max(t, 0))); for (let dz = -1; dz <= 1; dz++) onPath[(zc + dz) * S + x] = Math.max(onPath[(zc + dz) * S + x], py); }
  py = 0;
  for (let z = IN1 - 1; z >= IN0; z--) { const t = H[z * S + xc]; py = Math.max(py - 1, Math.min(py + 1, Math.max(t, 0))); for (let dx = -1; dx <= 1; dx++) onPath[z * S + xc + dx] = Math.max(onPath[z * S + xc + dx], py); }
  const strata = sand ? ["sandstone", "smooth_sandstone", "orange_terracotta", "sandstone", "white_terracotta"] : snow ? ["stone", "andesite", "calcite", "diorite", "stone"] : ["stone", "andesite", "tuff", "stone", "granite"];
  for (let z = IN0; z < IN1; z++) for (let x = IN0; x < IN1; x++) {
    const wx = bx0 + x, wz = bz0 + z, k = z * S + x;
    const p = onPath[k];
    const h = p > -999 ? p : H[k];
    if (h < 0) { // 湖：底は砂利と粘土、水面は -1
      for (let y = h; y <= 0; y++) g.set(x, y, z, "air");
      g.set(x, h - 1, z, hash(wx, 0, wz, ts) < 0.5 ? "gravel" : sand ? "sand" : "clay");
      for (let y = h; y <= -1; y++) g.set(x, y, z, y === -1 && snow ? "ice" : y === h && hash(wx, 1, wz, ts) < 0.1 ? "seagrass|sea_grass_type=default" : "water");
      continue;
    }
    for (let y = 1; y <= h; y++) {
      const band = ((Math.floor((y + noise3(wx * 0.05, y * 0.02, wz * 0.05, ts) * 4) / 3) % strata.length) + strata.length) % strata.length;
      g.set(x, y, z, strata[band]);
    }
    if (p > -999) { g.set(x, h, z, hash(wx, 2, wz, ts) < 0.3 ? "mossy_stone_bricks" : "stone_bricks"); for (let y = h + 1; y <= h + 4; y++) g.set(x, y, z, "air"); continue; }
    if (h > 0) g.set(x, h, z, sand ? "sand" : snow ? "snow" : hash(wx, 3, wz, ts) < 0.15 ? "coarse_dirt" : hash(wx, 4, wz, ts) < 0.15 ? "moss_block" : "grass_block");
  }
  // 崖の面を削って凸凹にする（坂道の上は削らない）
  for (let z = IN0 + 1; z < IN1 - 1; z++) for (let x = IN0 + 1; x < IN1 - 1; x++) {
    const k = z * S + x, h = H[k];
    if (h < 6 || onPath[k] > -999) continue;
    const low = Math.min(H[k - 1], H[k + 1], H[k - S], H[k + S]);
    if (h - low < 4) continue;
    for (let y = Math.max(1, low + 1); y < h - 1; y++)
      if (noise3((bx0 + x) * 0.22, y * 0.22, (bz0 + z) * 0.22, ts + 5) > 0.62) g.set(x, y, z, "air");
  }
  // 滝：高い崖の上から下の段へ流れ落ちる水の柱
  let falls = 0;
  for (let z = IN0 + 4; z < IN1 - 4 && falls < 2; z += 3) for (let x = IN0 + 4; x < IN1 - 4 && falls < 2; x += 3) {
    const k = z * S + x, h = H[k];
    if (h < 16 || onPath[k] > -999) continue;
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const k2 = k + dx + dz * S;
      if (H[k2] <= h - 16 && onPath[k2] === -999 && hash(x, z, 9, ts) < 0.3) {
        for (let y = Math.max(H[k2], 0) + 1; y <= h; y++) g.set(x + dx, y, z + dz, "water");
        g.set(x, h, z, "water"); falls++; break;
      }
    }
  }
  // 高台の上の遺跡と木
  for (let k = 0; k < 9; k++) {
    const x = IN0 + 10 + Math.floor(rng() * 88), z = IN0 + 10 + Math.floor(rng() * 88), h = H[z * S + x];
    if (h < 8 || onPath[z * S + x] > -999) continue;
    if (k < 4) for (let i = 0; i < 4; i++) { // 折れた柱の列
      const px = x + i * 4, top = h + 2 + Math.floor(hash(px, h, z, ts) * 9);
      if (px + 1 >= IN1 || H[z * S + px] !== h) continue;
      for (let y = h + 1; y <= top; y++) for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) g.set(px + a, y, z + b, y === top ? "chiseled_stone_bricks" : hash(px, y, z, ts) < 0.3 ? "mossy_stone_bricks" : "stone_bricks");
    }
    else if (!sand) tree(g, x, h + 1, z, ts + k, snow ? "spruce" : rng() < 0.4 ? "big" : "small");
  }
}

function lotFactory(g, rng, zone) {
  // 工場・施設：倉庫（のこぎり屋根）・丸いタンク・配管・金網の柵
  const R0 = rotMat(0, 0), ts = Math.floor(rng() * 1e9);
  for (let k = 0; k < 3; k++) {
    const w = 30 + 2 * Math.floor(rng() * 10), d = 18 + 2 * Math.floor(rng() * 5), h = 12 + 4 * Math.floor(rng() * 3);
    const x0 = IN0 + 4 + Math.floor(rng() * (104 - w)), z0 = IN0 + 4 + k * 36;
    if (z0 + d > IN1 - 4) continue;
    const mats = [M_BRICK, M_CONC, M_DEEP][k % 3];
    placeRot(g, x0 + w / 2, z0 + d / 2, 0, w, d, h, R0, makeTower({ w, d, h, style: "band", mats, ts: ts + k, crownLoss: 0.2, dmgBase: 0.75 }), [0, 128, 0, 128]);
    for (let x = x0; x < x0 + w; x++) for (let i = 0; i < d; i++) { // のこぎり屋根（北側がガラス）
      if (noise3(x * 0.1, 0, i * 0.1, ts + k) > 0.65) continue;
      const t = i % 6;
      if (t < 3) g.set(x, h + t, z0 + i, mats.wall);
      if (t === 3) for (let yy = h + 1; yy <= h + 2; yy++) g.set(x, yy, z0 + i, "gray_stained_glass");
    }
  }
  const tanks = [];
  for (let k = 0; k < 6; k++) { // 丸いタンク（すき間に置く）
    const r = 4 + Math.floor(rng() * 4), h = 10 + Math.floor(rng() * 14);
    const cx = IN0 + 6 + r + Math.floor(rng() * (100 - 2 * r)), cz = IN0 + 6 + r + Math.floor(rng() * (100 - 2 * r));
    let ok = true;
    for (let y = 1; y <= 3 && ok; y++) for (let a = -r - 1; a <= r + 1 && ok; a++) for (let b = -r - 1; b <= r + 1 && ok; b++) if (g.isHard(cx + a, y, cz + b)) ok = false;
    if (!ok) continue;
    cyl(g, cx, cz, () => r, 1, h, (x, y, z) => (hash(x, y, z, ts) < 0.15 ? "weathered_cut_copper" : y % 6 === 0 ? "polished_andesite" : "light_gray_concrete"), 1.3);
    cyl(g, cx, cz, (y) => Math.sqrt(Math.max(0, r * r - (y - h) * (y - h) * 2.2)), h + 1, h + 4, "weathered_cut_copper", 0);
    tanks.push([cx, cz, h]);
  }
  for (let k = 1; k < tanks.length; k++) { // 配管
    const [ax, az] = tanks[k - 1], [bx, bz] = tanks[k], y = 6 + (k % 3) * 2;
    for (let x = Math.min(ax, bx); x <= Math.max(ax, bx); x++) g.setIfAir(x, y, az, "polished_andesite");
    for (let z = Math.min(az, bz); z <= Math.max(az, bz); z++) g.setIfAir(bx, y, z, "polished_andesite");
  }
  for (let i = IN0 + 1; i < IN1 - 1; i++) for (const [x, z] of [[i, IN0 + 1], [i, IN1 - 2], [IN0 + 1, i], [IN1 - 2, i]]) { // 金網の柵（ところどころ破れている）
    if (Math.abs(i - 64) < 4 || noise3(i * 0.2, 0, x + z, ts) > 0.7) continue;
    for (let y = 1; y <= 2; y++) g.setIfAir(x, y, z, "iron_bars");
  }
  void zone;
}

function lotRuins(g, rng, zone) {
  // 古代遺跡：石畳の円い広場、柱の輪、アーチ、倒れた柱、中央の段の祭壇
  const c = 64, ts = Math.floor(rng() * 1e9), sand = zone.name === "sand";
  const st = sand ? { a: "cut_sandstone", b: "chiseled_sandstone", m: "smooth_sandstone" } : { a: "stone_bricks", b: "chiseled_stone_bricks", m: "mossy_stone_bricks" };
  for (let x = IN0; x < IN1; x++) for (let z = IN0; z < IN1; z++) {
    const d = Math.hypot(x + 0.5 - c, z + 0.5 - c);
    if (d < 46 && g.isHard(x, 0, z) && noise3(x * 0.15, 0, z * 0.15, ts) < 0.66) g.set(x, 0, z, hash(x, 0, z, ts) < 0.3 ? st.m : st.a);
  }
  const pillar = (x, z, top) => { for (let y = 1; y <= top; y++) for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) g.set(x + a, y, z + b, y === 1 || y === top ? st.b : hash(x, y, z, ts) < 0.3 ? st.m : st.a); };
  for (let k = 0; k < 24; k++) { // 外の柱の輪
    const a = (k / 24) * Math.PI * 2, x = Math.round(c + Math.cos(a) * 38), z = Math.round(c + Math.sin(a) * 38);
    pillar(x, z, 3 + Math.floor(hash(k, 0, 0, ts) ** 0.7 * 15));
  }
  for (let k = 0; k < 6; k++) { // 内側のアーチ
    const a = (k / 6) * Math.PI * 2 + 0.3, x = Math.round(c + Math.cos(a) * 20), z = Math.round(c + Math.sin(a) * 20);
    const ux = -Math.sin(a), uz = Math.cos(a);
    if (hash(k, 1, 0, ts) < 0.25) { pillar(Math.round(x - ux * 5), Math.round(z - uz * 5), 4); continue; } // 崩れたアーチ
    pillar(Math.round(x - ux * 5), Math.round(z - uz * 5), 11); pillar(Math.round(x + ux * 5), Math.round(z + uz * 5), 11);
    for (let i = -6; i <= 7; i++) for (let b = 0; b < 2; b++) g.set(Math.round(x + ux * i), 12, Math.round(z + uz * i) + b, st.b);
  }
  for (let t = 0; t < 3; t++) for (let x = -6 + t * 2; x < 6 - t * 2; x++) for (let z = -6 + t * 2; z < 6 - t * 2; z++) g.set(c + x, t + 1, c + z, t === 2 ? st.b : st.a); // 祭壇
  g.set(c, 4, c, "sea_lantern");
  for (let k = 0; k < 4; k++) { // 倒れた柱
    const a = rng() * Math.PI * 2, x0 = c + Math.cos(a) * (26 + rng() * 12), z0 = c + Math.sin(a) * (26 + rng() * 12), b = rng() * Math.PI;
    for (let i = 0; i < 10; i++) for (let q = 0; q < 2; q++) if (i % 4 !== 3) g.set(Math.round(x0 + Math.cos(b) * i), 1 + q, Math.round(z0 + Math.sin(b) * i), st.a);
  }
  for (let k = 0; k < 4; k++) { const x = IN0 + 6 + Math.floor(rng() * 100), z = IN0 + 6 + Math.floor(rng() * 100); if (g.name(x, 0, z) === "grass_block" && g.isAir(x, 1, z)) tree(g, x, 1, z, ts + k, "big"); }
}

function lmPlant(g, ts) {
  // 古い発電所：レンガのタービン建屋、赤白の帯の煙突3本（1本は折れている）、冷却塔2基、変電設備
  const R0 = rotMat(0, 0);
  placeRot(g, 50, 27, 0, 72, 30, 32, R0, makeTower({ w: 72, d: 30, h: 32, style: "office", mats: M_BRICK, ts, crownLoss: 0.15, dmgBase: 0.8 }), [0, 128, 0, 128]);
  [[100, 16, 104], [100, 30, 116], [100, 44, 92]].forEach(([x, z, h], k) => {
    const broken = k === 2, top = broken ? h - 34 : h;
    cyl(g, x, z, (y) => 4.6 - y / 60, 1, top, (xx, y, zz) => {
      if (y > h - 14 && !broken) return Math.floor(y / 4) % 2 ? "red_concrete" : "white_concrete";
      if (y > 3 && noise3(xx * 0.3, y * 0.08, zz * 0.3, ts + k) > 0.74) return null;
      return hash(xx, y, zz, ts) < 0.15 ? "mossy_stone_bricks" : "brick_block";
    }, 1.3);
    if (!broken) g.set(x, h + 1, z, "lightning_rod|facing_direction=1,powered_bit=0");
  });
  const waist = 13, yw = 44, a = 37.6;
  for (const [cx, cz] of [[34, 88], [88, 88]])
    cyl(g, cx, cz, (y) => waist * Math.sqrt(1 + ((y - yw) / a) ** 2), 1, 56, (x, y, z) => {
      if (y <= 6 && Math.floor((Math.atan2(z, x) + Math.PI) * 6) % 2 === 0) return null; // 足もとの開口
      if (y > 40 && noise3(x * 0.15, y * 0.1, z * 0.15, ts + cx) > 0.7) return null; // 上のほうが崩れている
      return hash(x, y, z, ts) < 0.1 ? "andesite" : y % 8 === 0 ? "polished_andesite" : "light_gray_concrete";
    }, 1.4);
  for (let k = 0; k < 6; k++) { // 変電設備
    const x = 52 + (k % 3) * 8, z = 50 + Math.floor(k / 3) * 8;
    for (let y = 1; y <= 4; y++) for (let a2 = 0; a2 < 3; a2++) for (let b = 0; b < 3; b++) g.set(x + a2, y, z + b, y === 4 ? "oxidized_copper_grate" : "gray_concrete");
    g.set(x + 1, 5, z + 1, "lightning_rod|facing_direction=1,powered_bit=0");
  }
  for (let x = 30; x <= 88; x++) g.setIfAir(x, 8, 66, "polished_andesite"); // 配管
  for (let z = 42; z <= 66; z++) g.setIfAir(30, 8, z, "polished_andesite");
}

// ───── 名所 ─────
function lmTower(g, ts) {
  // 中央電波塔：古い建物の台座の上に、緑青の鉄骨の塔が高さ195までそびえる。らせんの足場で上へ登れる
  const c = 64;
  const base = makeTower({ w: 48, d: 48, h: 32, style: "classical", mats: M_STONE, ts, crownLoss: 0.05, dmgBase: 0.9, holes: 0.85 });
  placeRot(g, c, c, 0, 48, 48, 32, rotMat(0, 0), base, [0, 128, 0, 128]);
  const frame = "oxidized_cut_copper", grate = "oxidized_copper_grate";
  for (let y = 33; y <= 196; y++) {
    const hw = Math.round(lerp(20, 3, (y - 33) / 163));
    for (const lx of [c - hw, c + hw - 2]) for (const lz of [c - hw, c + hw - 2]) // 4本の脚（2×2）
      for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) g.set(lx + a, y, lz + b, frame);
    if (y % 12 === 0 || y === 33) // 横の輪
      for (let i = -hw; i < hw; i++) { g.set(c + i, y, c - hw, frame); g.set(c + i, y, c + hw - 1, frame); g.set(c - hw, y, c + i, frame); g.set(c + hw - 1, y, c + i, frame); }
    const k = (y - 33) % 24; // 斜めの筋かい
    if (k < 12) for (const [ax, az] of [[1, 0], [0, 1]]) {
      const t = Math.round(lerp(-hw, hw - 1, k / 12));
      if (ax) { g.set(c + t, y, c - hw, grate); g.set(c - t - 1, y, c + hw - 1, grate); } else { g.set(c - hw, y, c + t, grate); g.set(c + hw - 1, y, c - t - 1, grate); }
    }
  }
  for (const [yy, r] of [[110, 13], [160, 8]]) // 展望台（手すり付き）
    for (let x = -r; x < r; x++) for (let z = -r; z < r; z++) {
      g.set(c + x, yy, c + z, "smooth_stone");
      if (x === -r || z === -r || x === r - 1 || z === r - 1) g.set(c + x, yy + 1, c + z, "iron_bars");
    }
  for (let y = 197; y <= 200; y++) g.set(c, y, c, "iron_block"); // アンテナ
  // 中心のらせんの足場（3×3の柱のまわりを1段ずつ上る）
  const ring = [];
  for (let i = -2; i <= 2; i++) ring.push([i, -2]); for (let i = -1; i <= 2; i++) ring.push([2, i]);
  for (let i = 1; i >= -2; i--) ring.push([i, 2]); for (let i = 1; i >= -1; i--) ring.push([-2, i]);
  for (let y = 1; y <= 160; y++) {
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) g.set(c + a, y, c + b, "polished_deepslate");
    const [rx, rz] = ring[y % ring.length];
    g.set(c + rx, y, c + rz, "smooth_stone");
    for (let k = 1; k <= 3; k++) g.set(c + rx, y + k, c + rz, "air"); // 頭上の床に穴をあける
  }
  for (let y = 1; y <= 160; y += 1) { const [rx, rz] = ring[y % ring.length]; g.set(c + rx, y, c + rz, "smooth_stone"); } // 穴あけで消えた段を戻す
}

function lmStadium(g, ts) {
  // 廃スタジアム：楕円の観客席が外へ上っていく。中はバトルフィールド（白線）。外壁は一部崩れている
  const c = 64, A = 54, B = 46, fa = 26, fb = 18;
  for (let x = IN0; x < IN1; x++)
    for (let z = IN0; z < IN1; z++) {
      const e = Math.hypot((x + 0.5 - c) / A, (z + 0.5 - c) / B);
      const ef = Math.hypot((x + 0.5 - c) / fa, (z + 0.5 - c) / fb);
      if (e > 1) continue;
      if (ef <= 1.15) { // フィールド
        const lx = x + 0.5 - c, lz = z + 0.5 - c;
        const line = Math.abs(lx) < 0.6 || Math.abs(Math.hypot(lx, lz) - 6) < 0.6 || Math.abs(ef - 1) < 0.06;
        g.set(x, 0, z, line ? "white_concrete" : hash(x, 0, z, ts) < 0.15 ? "moss_block" : "grass_block");
        continue;
      }
      const k = clamp01((e - 0.5) / 0.5); // 0（内側）〜1（外側）
      const top = Math.floor(k * 30);
      const broken = noise3(Math.atan2(z - c, x - c) * 3, 0, 0, ts) > 0.68; // 崩れた区間
      const height = broken ? Math.floor(top * 0.3) : top;
      for (let y = 1; y <= height; y++) g.set(x, y, z, y === height ? (hash(x, y, z, ts) < 0.25 ? "mossy_stone_bricks" : "smooth_stone") : "stone_bricks");
      if (e > 0.96 && !broken) { // 外壁（アーチの開口）
        const ang = Math.atan2(z - c, x - c) * 30;
        for (let y = 1; y <= 36; y++) {
          const arch = (Math.floor(ang) % 4 !== 0) && y >= 4 && y <= 12 && (y < 12 || hash(x, y, z, ts) < 0.5);
          if (arch) g.set(x, y, z, "air"); else if (y > height) g.set(x, y, z, y % 8 === 0 ? "chiseled_stone_bricks" : "stone_bricks");
        }
      }
    }
  // 大きな照明の柱4本
  for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const x = Math.round(c + sx * A * 0.68), z = Math.round(c + sz * B * 0.68);
    for (let y = 1; y <= 52; y++) for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) g.set(x + a, y, z + b, "oxidized_cut_copper");
    for (let a = -2; a <= 3; a++) for (let y = 50; y <= 53; y++) g.set(x + a, y, z - 1, y === 51 ? "sea_lantern" : "oxidized_copper_grate");
  }
  // 入場口：南北の通路
  for (let z = IN0; z < IN1; z++) if (Math.abs(z - c) > fb) for (let x = c - 3; x <= c + 3; x++) for (let y = 1; y <= 6; y++) g.set(x, y, z, "air");
}

function lmWheel(g, ts) {
  // 沈んだ観覧車：区画は深い湖。直径約80の輪が少し傾いて半分沈んでいる
  for (let x = IN0; x < IN1; x++) for (let z = IN0; z < IN1; z++) {
    const e = Math.hypot(x + 0.5 - 64, z + 0.5 - 64) / 54 + (noise3(x * 0.05, 0, z * 0.05, ts) - 0.5) * 0.3;
    if (e > 1) continue;
    const depth = Math.floor(lerp(2, 14, clamp01((1 - e) * 2)));
    for (let y = -depth - 1; y <= 0; y++) g.set(x, y, z, y === -depth - 1 ? "mud" : y === 0 ? "air" : "water");
  }
  const R = rotMat(0.18, 0), yaw = hash(1, 2, 3, ts) * Math.PI;
  const cy = 26, rad = 40;
  const put = (lx, ly, lz, name) => { // 輪の面（x-y）→ 傾けて → 水平に回す
    const X = R[0][0] * lx + R[0][1] * ly + R[0][2] * lz, Y = R[1][0] * lx + R[1][1] * ly + R[1][2] * lz, Z = R[2][0] * lx + R[2][1] * ly + R[2][2] * lz;
    const wx = X * Math.cos(yaw) - Z * Math.sin(yaw), wz = X * Math.sin(yaw) + Z * Math.cos(yaw);
    g.set(Math.round(64 + wx), Math.round(Y), Math.round(64 + wz), name);
  };
  for (let a = 0; a < Math.PI * 2; a += 0.004) for (const off of [-1.5, 1.5]) for (const dr of [0, 0.7]) put(Math.cos(a) * (rad - dr), cy + Math.sin(a) * (rad - dr), off, "oxidized_cut_copper");
  for (let s = 0; s < 16; s++) { // スポークとゴンドラ
    const a = (s / 16) * Math.PI * 2;
    for (let t = 0; t <= rad; t += 0.4) for (const off of [-1.5, 1.5]) put(Math.cos(a) * t, cy + Math.sin(a) * t, off, "oxidized_copper_grate");
    const gx = Math.cos(a) * (rad + 3), gy = cy + Math.sin(a) * (rad + 3);
    const color = ["red_concrete", "light_blue_concrete", "white_concrete", "cyan_terracotta"][s % 4];
    for (let dx = -1.5; dx <= 1.5; dx += 0.5) for (let dy = -2; dy <= 1; dy += 0.5) for (let dz = -1.5; dz <= 1.5; dz += 0.5)
      if (Math.abs(dx) > 1 || Math.abs(dz) > 1 || dy <= -1.9 || dy >= 0.9) put(gx + dx, gy + dy, dz, dy > -1.5 && dy < 0.5 && Math.abs(dz) > 1 && Math.abs(dx) < 1 ? "gray_stained_glass" : color);
  }
  for (let t = 0; t <= cy + 12; t += 0.5) for (const sd of [-1, 1]) for (const off of [-3, 3]) put(sd * t * 0.55, cy - t, off, "oxidized_cut_copper"); // 支柱
  for (let lx = -3; lx <= 3; lx += 0.5) for (let ly = -3; ly <= 3; ly += 0.5) put(lx, cy + ly, 0, "iron_block"); // 軸
  // 湖を渡る板の桟橋（南の岸から観覧車の足もとへ）
  for (let z = 64; z < IN1; z++) for (let x = 62; x <= 66; x++) { g.set(x, 0, z, "spruce_planks"); if (x === 62 || x === 66) g.set(x, 1, z, LAMP_POST.replace("wall_post_bit=1", "wall_post_bit=0").replace("north=none", "north=short").replace("south=none", "south=short")); }
}

function lmBigTree(g, ts) {
  // 森の巨大樹：崩れた建物の輪を突き破って育った大樹。根が地面を這い、枝の先に大きな葉のかたまり
  const c = 64;
  const ring = makeTower({ w: 70, d: 70, h: 28, style: "classical", mats: M_STONE, ts, crownLoss: 0.6, dmgBase: 0.66, stairs: false });
  placeRot(g, c, c, 0, 70, 70, 28, rotMat(0, 0), ring, [0, 128, 0, 128]);
  const H = 82;
  for (let y = -3; y <= H; y++) {
    const r = lerp(8, 3.5, clamp01(y / H)) + (y < 6 ? (6 - y) * 0.9 : 0);
    for (let x = -12; x <= 12; x++) for (let z = -12; z <= 12; z++) {
      const rr = r + (noise3(x * 0.3, y * 0.1, z * 0.3, ts) - 0.5) * 2.5;
      if (x * x + z * z <= rr * rr) g.set(c + x, y, c + z, "dark_oak_log");
    }
  }
  const rng = mulberry32(ts);
  for (let k = 0; k < 10; k++) { // 根
    let a = (k / 10) * Math.PI * 2 + rng() * 0.4, x = c, z = c, y = 1;
    for (let s = 0; s < 40; s++) {
      a += (rng() - 0.5) * 0.3; x += Math.cos(a); z += Math.sin(a); if (s % 6 === 5 && y > 0) y--;
      for (let t = 0; t < 2; t++) g.set(Math.round(x), y + t, Math.round(z), "mangrove_roots");
    }
  }
  for (let k = 0; k < 9; k++) { // 枝と葉
    const a = (k / 9) * Math.PI * 2 + rng(), y0 = 45 + rng() * 32, len = 18 + rng() * 16;
    let x = c, z = c, y = y0;
    for (let t = 0; t < len; t += 0.5) { x += Math.cos(a) * 0.5; z += Math.sin(a) * 0.5; y += 0.22; for (let q = 0; q < 2; q++) g.set(Math.round(x) + q, Math.round(y), Math.round(z), "dark_oak_log"); }
    blob(g, Math.round(x), Math.round(y) + 2, Math.round(z), 9 + rng() * 5, (dx, dy, dz) => LEAF(hash(dx, dy, dz, ts + k) < 0.12 ? "azalea_leaves_flowered" : "jungle_leaves"), ts + k, 2.2);
    for (let q = 0; q < 14; q++) { // 垂れる根
      const hx = Math.round(x + (rng() - 0.5) * 14), hz = Math.round(z + (rng() - 0.5) * 14);
      for (let yy = Math.round(y) - 4; yy > Math.round(y) - 12; yy--) if (g.isAir(hx, yy, hz)) g.set(hx, yy, hz, "hanging_roots"); else break;
    }
  }
  blob(g, c, H + 4, c, 16, (dx, dy, dz) => LEAF(hash(dx, dy, dz, ts) < 0.1 ? "azalea_leaves_flowered" : "jungle_leaves"), ts + 99, 2.4);
}

function lmTemple(g, ts) {
  // 砂に埋もれた神殿：6段の階段ピラミッド。正面に大階段、頂上に柱の祠、中へ続く入口
  const c = 64, tiers = 6, step = 7, th = 7;
  for (let t = 0; t < tiers; t++) {
    const hw = 50 - t * step, y0 = t * th + 1;
    for (let x = -hw; x < hw; x++) for (let z = -hw; z < hw; z++)
      for (let y = y0; y < y0 + th; y++) {
        const edge = Math.max(Math.abs(x + 0.5), Math.abs(z + 0.5)) > hw - 1.5;
        const band = y === y0 + th - 1 && edge;
        g.set(c + x, y, c + z, band ? "chiseled_sandstone" : edge && (y - y0) % 3 === 1 && (x + z) % 4 === 0 ? "cut_sandstone" : "sandstone");
      }
  }
  const topY = tiers * th + 1;
  for (let z = c + 50 - 1; z >= c; z--) { // 正面（南）の大階段
    const y = Math.min(topY, Math.floor((c + 50 - z) * th / step));
    for (let x = c - 5; x <= c + 4; x++) { for (let yy = 1; yy <= y; yy++) g.set(x, yy, z, "smooth_sandstone"); for (let yy = y + 1; yy <= y + 4 && yy < topY + 1; yy++) g.set(x, yy, z, "air"); }
  }
  for (let x = -8; x < 8; x++) for (let z = -8; z < 8; z++) { // 頂上の祠
    const edge = Math.max(Math.abs(x + 0.5), Math.abs(z + 0.5)) > 6.5;
    if (edge && (x + 8) % 3 === 0 && (z + 8) % 3 === 0) for (let y = topY; y < topY + 9; y++) g.set(c + x, y, c + z, "cut_sandstone");
    g.set(c + x, topY + 9, c + z, "chiseled_sandstone");
  }
  for (let x = -6; x < 6; x++) for (let z = -6; z < 6; z++) for (let y = 1; y <= 8; y++) g.set(c + x, y, c + z, Math.abs(x + 0.5) > 5 || Math.abs(z + 0.5) > 5 ? "chiseled_sandstone" : "air"); // 中の広間
  for (let x = c + 5; x <= c + 50; x++) for (let z = c - 2; z <= c + 2; z++) for (let y = 1; y <= 5; y++) g.set(x, y, z, Math.abs(z - c) === 2 && y === 5 ? "chiseled_sandstone" : "air"); // 東の入口から広間への通路
  for (let x = -5; x < 5; x++) for (let z = -5; z < 5; z++) g.set(c + x, 0, c + z, (x + z) % 2 ? "cut_sandstone" : "chiseled_sandstone");
  g.set(c, 1, c, "sea_lantern");
}

function lmLab(g, ts) {
  // 雪の研究所：3つのドームを通路でつなぎ、傾いた大きなアンテナ皿がある
  const domes = [[44, 46, 20], [86, 54, 15], [58, 90, 12]];
  for (const [x0, z0, r] of domes)
    for (let x = -r; x <= r; x++) for (let z = -r; z <= r; z++) for (let y = 0; y <= r; y++) {
      const d = Math.sqrt(x * x + y * y * 1.3 + z * z);
      if (d > r || d < r - 1.2) continue;
      if (y < 4 && Math.abs(z) <= 1 && x > 0) continue; // 入口
      g.set(x0 + x, y + 1, z0 + z, y % 6 === 3 ? "light_blue_stained_glass" : hash(x, y, z, ts) < 0.06 ? "air" : "calcite");
    }
  const tube = (a, b) => { // ドームどうしをつなぐ通路
    const n = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]));
    for (let i = 0; i <= n; i++) {
      const x = Math.round(lerp(a[0], b[0], i / n)), z = Math.round(lerp(a[1], b[1], i / n));
      for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let y = 1; y <= 4; y++) {
        const shell = Math.max(Math.abs(dx), Math.abs(dz)) === 2 || y === 4;
        if (shell) g.setIfAir(x + dx, y, z + dz, y === 3 ? "light_blue_stained_glass" : "polished_diorite");
      }
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) for (let y = 1; y <= 3; y++) g.set(x + dx, y, z + dz, "air");
    }
  };
  tube([44, 46], [86, 54]); tube([44, 46], [58, 90]);
  const R = rotMat(-0.5, 0.3), dc = [96, 92], dr = 14; // アンテナ皿
  for (let y = 1; y <= 12; y++) for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) g.set(dc[0] + a, y, dc[1] + b, "iron_block");
  for (let x = -dr; x <= dr; x += 0.5) for (let z = -dr; z <= dr; z += 0.5) {
    if (x * x + z * z > dr * dr) continue;
    const y = (x * x + z * z) / (4 * 9);
    const X = R[0][0] * x + R[0][1] * y + R[0][2] * z, Y = R[1][0] * x + R[1][1] * y + R[1][2] * z, Z = R[2][0] * x + R[2][1] * y + R[2][2] * z;
    g.set(Math.round(dc[0] + X), Math.round(14 + Y), Math.round(dc[1] + Z), "smooth_stone");
  }
}

// ───── 物語の場所 ─────
// 記録の書見台を置く場所（区画の中の座標）。どれも建物や湖をよけた所
export const RECORD_SPOTS = {
  tower: [[16, 16], [112, 16], [16, 112]],
  stadium: [[16, 16], [112, 112], [16, 112]],
  plant: [[112, 112], [12, 60], [60, 112]],
  wheel: [[14, 14], [114, 14], [14, 114]],
  bigtree: [[14, 14], [114, 114], [114, 14]],
  temple: [[10, 10], [118, 118], [10, 118]],
  lab: [[14, 14], [114, 14], [14, 114]],
  camp: [[64, 56]],
};
// 名所でない章の舞台（区画の番号と名前）。記録の書見台は区画の3つのすみに置く
export const STORY_ROUTE = {
  r1: [9, 15, "はじまりの湖畔"], r2: [7, 16, "さびれた工場"], r3: [5, 15, "雪の崖"], r5: [12, 21, "南の遺跡"],
  r6: [17, 16, "砂の工場"], r8: [20, 6, "東の遺跡"], r9: [18, 2, "砂の巨塔"], r10: [13, 2, "森の巨塔"],
  r13: [4, 4, "森の古代遺跡"], r14: [1, 8, "西の果ての遺跡"], r15: [4, 11, "森の祭壇"], r16: [7, 12, "沈む巨塔"], r19: [9, 9, "計画の工場"],
};
const ROUTE_SPOTS = [[14, 14], [114, 14], [14, 114]];
// 休憩キャンプ（回復マシン・補給箱）を置く場所。章の舞台ごとに1か所（記録の書見台と重ならない所）
const REST_SPOTS = { stadium: [112, 16], plant: [112, 18], bigtree: [14, 114], temple: [116, 12], camp: [56, 64] };
const REST_DEFAULT = [112, 112];
// 9×9の平らな広場をつくり、たき火・小さなテント・補給箱を置く。回復マシンはゲームの中でスクリプトが中央に置く
function restCamp(g, cx, cz, ts) {
  let top = -99;
  for (let a = -4; a <= 4; a++) for (let b = -4; b <= 4; b++) {
    for (let y = g.y0 + g.sy - 2; y >= -12; y--) if (g.isHard(cx + a, y, cz + b) && !g.name(cx + a, y, cz + b).startsWith("lectern")) { top = Math.max(top, y); break; }
  }
  if (top > 30 || top < 0) { // 高い建物の上や水の上なら地面の高さに
    for (let a = -4; a <= 4; a++) for (let b = -4; b <= 4; b++) for (let y = 1; y <= Math.max(top, 0) + 5; y++) g.set(cx + a, y, cz + b, "air");
    top = 0;
  }
  for (let a = -4; a <= 4; a++) for (let b = -4; b <= 4; b++) {
    for (let y = -2; y < top; y++) if (!g.isHard(cx + a, y, cz + b)) g.set(cx + a, y, cz + b, "stone_bricks");
    g.set(cx + a, top, cz + b, Math.max(Math.abs(a), Math.abs(b)) === 4 ? "mossy_stone_bricks" : (a + b) % 2 ? "spruce_planks" : "stripped_spruce_wood|pillar_axis=y");
    for (let y = top + 1; y <= top + 5; y++) g.set(cx + a, y, cz + b, "air");
  }
  g.set(cx + 2, top + 1, cz + 2, "campfire|extinguished=0,minecraft:cardinal_direction=south");
  for (let a = -3; a <= -1; a++) { g.set(cx + a, top + 1, cz - 3, "white_wool"); g.set(cx + a, top + 2, cz - 3, "white_wool"); g.set(cx + a, top + 2, cz - 2, "white_wool"); } // 小さなテント
  g.set(cx + 3, top + 1, cz - 2, "chest|minecraft:cardinal_direction=west"); // 補給箱
  g.set(cx - 3, top + 1, cz + 2, "barrel|facing_direction=1,open_bit=0"); // なんでも屋の棚
  g.set(cx - 3, top + 2, cz + 2, "lantern|hanging=0");
  for (const [a, b] of [[-4, -4], [4, -4], [-4, 4], [4, 4]]) { g.set(cx + a, top + 1, cz + b, LAMP_POST); g.set(cx + a, top + 2, cz + b, "lantern|hanging=0"); }
  return { y: top + 1, chest: { x: cx + 3, y: top + 1, z: cz - 2 }, shop: { x: cx - 3, y: top + 1, z: cz + 2 } };
}
// 物語の舞台の一覧（名所＋道筋）：{ key: [i, j, 名前] }
export function storyPlaces(seed) {
  const out = {};
  for (const [k, [i, j]] of Object.entries(landmarks(seed))) out[k] = [i, j, LANDMARK_INFO[k].label];
  for (const [k, v] of Object.entries(STORY_ROUTE)) out[k] = v;
  return out;
}
const LECTERN = "lectern|minecraft:cardinal_direction=south,powered_bit=0";
// 台座：3×3の石レンガの上に書見台。上の3マスは空ける。いちばん上の固い地面の高さに置く
function pedestal(g, x, z) {
  let top = 0;
  for (let y = g.y0 + g.sy - 2; y >= -12; y--) {
    let hard = false;
    for (let a = -1; a <= 1 && !hard; a++) for (let b = -1; b <= 1 && !hard; b++) hard = g.isHard(x + a, y, z + b) && !g.name(x + a, y, z + b).startsWith("lectern");
    if (hard) { top = y; break; }
  }
  if (top > 30) { // 巨塔や巨大樹の上には置かない：地面の高さに置き、上を縦に抜いて空ける
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let y = 1; y <= top + 3; y++) g.set(x + a, y, z + b, "air");
    top = 0;
  }
  const base = top;
  top = Math.max(top, 0); // 池や湖の中なら、地面の高さまで石を積む（水が流れこまないように）
  for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) {
    for (let y = base; y < top; y++) g.set(x + a, y, z + b, "stone_bricks");
    g.set(x + a, top, z + b, a === 0 && b === 0 ? "chiseled_stone_bricks" : "stone_bricks");
    for (let y = top + 1; y <= top + 3; y++) g.set(x + a, y, z + b, "air");
  }
  g.set(x, top + 1, z, LECTERN);
  return top + 1;
}

// 調査隊キャンプ：テント・たき火・調査本部の書見台・街全体の地図の壁（3×3の額縁）
function lmCamp(g, ts) {
  for (let x = IN0; x < IN1; x++) for (let z = IN0; z < IN1; z++) {
    g.set(x, 0, z, hash(x, 0, z, ts) < 0.2 ? "coarse_dirt" : hash(x, 1, z, ts) < 0.3 ? "moss_block" : "grass_block");
    for (let y = 1; y <= 40; y++) g.set(x, y, z, "air");
  }
  for (let x = 54; x <= 74; x++) for (let z = 50; z <= 78; z++) g.set(x, 0, z, (x + z) % 7 === 0 ? "mossy_stone_bricks" : "stone_bricks"); // 広場
  for (let x = 58; x <= 70; x++) for (let y = 1; y <= 8; y++) for (let z = 46; z <= 47; z++) g.set(x, y, z, y === 8 ? "chiseled_stone_bricks" : "stone_bricks"); // 地図の壁
  g.frames = [];
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) { // 南向きの額縁。左が西、上が北
    const x = 63 + i, y = 6 - j, z = 48;
    g.set(x, y, z, "frame|facing_direction=3,item_frame_map_bit=1,item_frame_photo_bit=0");
    g.frames.push({ x, y, z, i, j });
  }
  const tent = (cx, cz, color) => { // 三角のテント
    for (let k = 0; k < 7; k++) for (let y = 1; y <= 4; y++) {
      const w = 4 - y;
      for (let d = -w; d <= w; d++) if (Math.abs(d) === w || k === 0 || k === 6) g.set(cx + d, y, cz + k, k === 6 && Math.abs(d) < w && y < 3 ? "air" : color);
    }
  };
  g.set(60, 1, 48, "chest|minecraft:cardinal_direction=south"); // 地図の箱（中身は書き出しのときに入れる）
  g.mapChest = { x: 60, y: 1, z: 48 };
  g.set(68, 1, 48, "cartography_table"); // 地図の写しを作る製図台
  tent(48, 58, "white_wool"); tent(80, 58, "light_gray_wool"); tent(48, 70, "light_gray_wool"); tent(80, 70, "white_wool");
  g.set(64, 1, 66, "campfire|extinguished=0,minecraft:cardinal_direction=south");
  for (const [x, z] of [[61, 63], [67, 63], [61, 69], [67, 69]]) g.set(x, 1, z, "spruce_planks");
  for (const [x, z] of [[56, 52], [72, 52], [56, 76], [72, 76]]) lamp(g, x, z, ts);
  for (const [x, z] of [[52, 52], [76, 52], [53, 52]]) g.set(x, 1, z, "barrel|facing_direction=1,open_bit=0");
}

// ───── 区画1つ ─────
// (di, dj) は区画の番号（0〜N-1）。プレビューやマップの書き出しで一気に回す
export function* generateDistrict(seed, di, dj) {
  const S = CITY.SIZE, N = CITY.N, FULL = S * N;
  const g = new Grid(S, CITY.SY, S, CITY.Y0);
  const bx0 = di * S, bz0 = dj * S;
  const rng = mulberry32(h32(seed ^ h32(di * 7919 + dj * 104729)));
  const lm = landmarks(seed);
  const lmKind = Object.keys(lm).find((k) => lm[k][0] === di && lm[k][1] === dj) ?? null;
  const center = zoneAt(bx0 + 64, bz0 + 64, seed);
  const CT = THEMES[center.name];
  const kind = lmKind ? 9 : pickKind(rng, CT, center); // 0 巨大建築 1 格子の巨塔 2 高層ビル街 3 沼の広場 4 崖と湖 5 工場 6 古代遺跡 9 名所
  const marshy = kind === 1 || kind === 3 || lmKind === "wheel";

  // 1. 地面・大通り・運河・橋
  const colZone = new Uint8Array(S * S);
  for (let z = 0; z < S; z++) {
    for (let x = 0; x < S; x++) {
      const wx = bx0 + x, wz = bz0 + z;
      const zone = zoneAt(wx, wz, seed);
      const T = THEMES[zone.name];
      colZone[z * S + x] = ZN.indexOf(zone.name);
      const sand = zone.name === "sand", snow = zone.name === "snow";
      const dxb = bandDist(x), dzb = bandDist(z);
      const inX = dxb < AV, inZ = dzb < AV; // inX: x の境目にそう（南北に走る）大通り
      const bX = x < 64 ? di : di + 1, bZ = z < 64 ? dj : dj + 1;
      const cX = inX && canalSeg(seed, bX, dj, true), cZ = inZ && canalSeg(seed, bZ, di, false);
      const wetX = cX && dxb < CANAL, wetZ = cZ && dzb < CANAL;
      for (let y = CITY.Y0; y <= -13; y++) g.set(x, y, z, sand ? "sandstone" : "stone");
      const r = hash(wx, 0, wz, seed + 52);
      if (wetX || wetZ) {
        // 運河：底 -12、水面 -3。大通りを横切るところには橋
        g.set(x, -12, z, "mud");
        for (let y = -11; y <= -3; y++) g.set(x, y, z, "water");
        const crossX = wetX && inZ && !wetZ, crossZ = wetZ && inX && !wetX; // 交わる大通りの歩道・道路の続き
        const midX = wetX && Math.abs(z + 0.5 - 64) < 3, midZ = wetZ && Math.abs(x + 0.5 - 64) < 3; // 区画のまん中の橋（幅6・手すり付き）
        if (crossX || crossZ || ((midX || midZ) && !(wetX && wetZ))) {
          g.set(x, 0, z, r < 0.2 ? "cracked_stone_bricks" : "stone_bricks"); g.set(x, -1, z, "stone_bricks");
          const edge = !(crossX || crossZ) && ((midX && Math.abs(z + 0.5 - 64) > 2) || (midZ && Math.abs(x + 0.5 - 64) > 2));
          if (edge) g.set(x, 1, z, midX ? WALL_X : WALL_Z);
        }
        continue;
      }
      if (cX || cZ) { // 運河の岸の歩道（壁は石レンガ）
        for (let y = -12; y <= 0; y++) g.set(x, y, z, hash(wx, y, wz, seed + 54) < 0.25 ? "mossy_stone_bricks" : hash(wx, y, wz, seed + 55) < 0.15 ? "cracked_stone_bricks" : "stone_bricks");
        if ((cX && Math.abs(dxb - (CANAL + 0.5)) < 0.1) || (cZ && Math.abs(dzb - (CANAL + 0.5)) < 0.1)) { // 運河のふちの低い塀
          const atBridge = (cX && Math.abs(z + 0.5 - 64) < 3) || (cZ && Math.abs(x + 0.5 - 64) < 3);
          if (!(inX && inZ) && !atBridge && hash(wx, 1, wz, seed + 56) < 0.7) g.set(x, 1, z, cX ? WALL_Z : WALL_X);
        }
        continue;
      }
      for (let y = -12; y <= -3; y++) g.set(x, y, z, sand ? "sandstone" : "stone");
      g.set(x, -2, z, sand ? "sandstone" : "dirt"); g.set(x, -1, z, sand ? "sand" : "dirt");
      const gn = fbm3(wx * 0.08, 0, wz * 0.08, seed + 51);
      const nearEdge = wx < 4 || wz < 4 || wx >= FULL - 4 || wz >= FULL - 4;
      if (!inX && !inZ && !sand && !nearEdge) { // 区画の中の池
        const wn = fbm3(wx * 0.03, 0, wz * 0.03, seed + 50);
        if (wn > T.water - (marshy ? 0.12 : 0)) {
          g.set(x, -2, z, "mud");
          g.set(x, -1, z, snow ? "ice" : hash(wx, 1, wz, seed + 57) < 0.08 ? "seagrass|sea_grass_type=default" : "water");
          continue;
        }
      }
      let top;
      if (inX || inZ) { // 大通り
        const walk = dxb > AV - 2 && inX && !inZ || dzb > AV - 2 && inZ && !inX;
        if (sand) top = r < 0.5 ? "smooth_sandstone" : r < 0.8 ? "sand" : "cut_sandstone";
        else if (snow) top = r < 0.6 ? "polished_andesite" : "packed_ice";
        else if (walk) top = r < 0.2 ? "cracked_stone_bricks" : r < 0.35 ? "mossy_stone_bricks" : "stone_bricks";
        else top = gn > 0.62 ? "grass_block" : gn > 0.56 ? "moss_block" : r < 0.1 ? "cobblestone" : r < 0.18 ? "gravel" : r < 0.3 ? "andesite" : r < 0.36 ? "mossy_cobblestone" : "polished_andesite";
      } else if (sand) top = "sand";
      else if (snow) top = "snow";
      else {
        const street = kind === 2 && (Math.abs(x + 0.5 - 64) < 4 || Math.abs(z + 0.5 - 64) < 4); // 高層ビル街の十字の通り
        if (street) top = r < 0.3 ? "andesite" : r < 0.4 ? "mossy_cobblestone" : "polished_andesite";
        else top = gn > (zone.name === "forest" || marshy ? 0.3 : 0.42) ? "grass_block" : gn > 0.36 ? "moss_block" : r < 0.5 ? "mossy_stone_bricks" : "stone_bricks";
      }
      g.set(x, 0, z, top);
    }
    yield;
  }

  // 2. 区画の中身
  const towers = [];
  const mats = CT.mats[Math.floor(rng() * CT.mats.length)];
  const ts = Math.floor(rng() * 1e9);
  if (kind === 9) ({ tower: lmTower, stadium: lmStadium, wheel: lmWheel, bigtree: lmBigTree, temple: lmTemple, lab: lmLab, plant: lmPlant, camp: lmCamp })[lmKind](g, ts);
  else if (kind === 0) lotMega(g, rng, CT, center, towers);
  else if (kind === 1) lotGiants(g, rng, CT, center);
  else if (kind === 2) lotTowers(g, rng, CT, center, mats, towers);
  else if (kind === 3) lotMarsh(g, rng, CT, center, mats);
  else if (kind === 4) lotHighland(g, rng, center, bx0, bz0, seed);
  else if (kind === 5) lotFactory(g, rng, center);
  else lotRuins(g, rng, center);
  yield;
  // 大通りの街灯（運河の歩道と道路のわき）
  for (let k = 4; k < S; k += 16) for (const [x, z] of [[k, 6], [6, k], [k, 121], [121, k]]) if (g.isHard(x, 0, z) && g.isAir(x, 1, z) && hash(bx0 + x, 0, bz0 + z, seed + 58) < 0.6) lamp(g, x, z, seed + bx0 + bz0);

  // 2b. 隣り合うビルを空中の渡り廊下でつなぐ（高層ビル街だけ）
  for (const A of towers)
    for (const B of towers) {
      const east = B.bx === A.bx + 1 && B.bz === A.bz, south = B.bz === A.bz + 1 && B.bx === A.bx;
      if (!east && !south) continue;
      const au0 = east ? A.tx + A.w - 1 : A.tz + A.d - 1, bu0 = east ? B.tx : B.tz;
      const vlo = Math.max(east ? A.tz : A.tx, east ? B.tz : B.tx) + 3, vhi = Math.min(east ? A.tz + A.d : A.tx + A.w, east ? B.tz + B.d : B.tx + B.w) - 4;
      if (vhi < vlo || bu0 - au0 < 2) continue;
      const vc = (vlo + vhi) >> 1;
      const top = Math.floor((Math.min(A.h, B.h) * 0.6) / 4) * 4;
      if (top < 8) continue;
      const levels = [8 + 4 * Math.floor(rng() * ((top - 8) / 4 + 1))];
      if (top >= 24 && rng() < 0.6) levels.push(top);
      for (const y of new Set(levels)) {
        const put = (u, v, yy, name) => (east ? g.set(u, yy, v, name) : g.set(v, yy, u, name));
        for (let u = au0 + 1; u < bu0; u++)
          for (let v = vc - 2; v <= vc + 2; v++) {
            put(u, v, y, hash(u, y, v, seed + 60) < 0.2 ? "cracked_stone_bricks" : "smooth_stone");
            put(u, v, y + 1, Math.abs(v - vc) === 2 ? "iron_bars" : "air");
            put(u, v, y + 2, "air"); put(u, v, y + 3, "air");
          }
        for (const [wu, inside] of [[au0, -1], [bu0, 1]])
          for (let v = vc - 1; v <= vc + 1; v++) {
            put(wu, v, y, "smooth_stone");
            for (let yy = y + 1; yy <= y + 3; yy++) put(wu, v, yy, "air");
            put(wu + inside, v, y, "smooth_stone"); put(wu + 2 * inside, v, y, "smooth_stone");
            put(wu + inside, v, y + 1, "air"); put(wu + inside, v, y + 2, "air");
          }
      }
    }
  yield;

  // 3. 砂の区画：砂丘で下のほうを埋める（大通りの歩く所は浅め）
  for (let z = 0; z < S; z++) {
    for (let x = 0; x < S; x++) {
      if (colZone[z * S + x] !== 3) continue;
      const wx = bx0 + x, wz = bz0 + z;
      let dune = Math.floor(Math.max(0, fbm3(wx * 0.018, 0, wz * 0.018, seed + 95) * 34 - 10));
      if (bandDist(x) < AV || bandDist(z) < AV) dune = Math.min(dune, 2);
      for (let y = 1; y <= dune; y++) g.setIfAir(x, y, z, "sand");
    }
    if ((z & 15) === 15) yield;
  }

  // 4. 上を向いた面：苔・草・茂み（緑の地区）／雪（雪の地区）／枯れ草（砂の地区）
  const moss = g.id("moss_block"), grass = g.id("grass_block"), water = g.id("water"), sandB = g.id("sand");
  const yTop = CITY.Y0 + CITY.SY - 2;
  for (let z = 0; z < S; z++) {
    for (let x = 0; x < S; x++) {
      const zn = ZN[colZone[z * S + x]], T = THEMES[zn];
      const wx = bx0 + x, wz = bz0 + z;
      for (let y = yTop; y >= -12; y--) {
        const v = g.get(x, y, z);
        if (v === 0 || !g.isAir(x, y + 1, z)) continue;
        const r = hash(wx, y, wz, seed + 71);
        if (v === water) { if (r < 0.025) g.set(x, y + 1, z, "waterlily"); continue; }
        if (zn === "snow") { if (!g.soft[v] || g.palette[v].includes("leaves")) g.set(x, y + 1, z, "snow_layer|covered_bit=0,height=0"); continue; }
        if (g.soft[v]) continue;
        if (zn === "sand") { if (v === sandB) { if (r < 0.01) g.set(x, y + 1, z, "deadbush"); else if (r < 0.03) g.set(x, y + 1, z, "short_dry_grass"); } continue; }
        if (v === grass) {
          if (r < 0.2) g.set(x, y + 1, z, "short_grass");
          else if (r < 0.25) g.set(x, y + 1, z, "fern");
          else if (r < (marshy ? 0.36 : 0.29) && g.isAir(x, y + 2, z)) { g.set(x, y + 1, z, "tall_grass|upper_block_bit=0"); g.set(x, y + 2, z, "tall_grass|upper_block_bit=1"); }
          continue;
        }
        const nm = fbm3(wx * 0.07, y * 0.05, wz * 0.07, seed + 70);
        if (nm < T.moss + (kind === 4 && y > 1 ? 0.12 : 0)) continue; // 崖は岩肌を見せる
        if (y > 0 && r < (nm - T.moss) * 3) g.d[g.idx(x, y, z)] = moss;
        if (hash(wx, y, wz, seed + 72) < 0.4) g.set(x, y + 1, z, "moss_carpet");
        let roofed = false; // ビルの中（上に屋根や床がある所）には茂みを置かない：階段や通路をふさぐため
        for (let k = 3; k <= 8 && !roofed; k++) roofed = g.isHard(x, y + k, z);
        if (!roofed && nm > T.moss + 0.12 && hash(wx, y, wz, seed + 73) < 0.05) {
          for (let dx = -2; dx <= 2; dx++) for (let dy = 1; dy <= 2; dy++) for (let dz = -2; dz <= 2; dz++)
            if (dx * dx + (dy - 1) * (dy - 1) * 2 + dz * dz <= 5 && hash(wx + dx, y + dy, wz + dz, seed + 74) < 0.85)
              g.setIfAir(x + dx, y + dy, z + dz, LEAF(hash(dx, dy, dz, seed + 75) < 0.2 ? "azalea_leaves_flowered" : "azalea_leaves"));
        }
      }
    }
    if ((z & 3) === 3) yield;
  }

  // 5. 壁から垂れるツタ（vine_direction_bits: 1=南 2=西 4=北 8=東 の面に付く）
  const SIDES = [[1, 0, 8], [-1, 0, 2], [0, 1, 1], [0, -1, 4]];
  for (let y = yTop; y >= -2; y--) {
    for (let z = 0; z < S; z++)
      for (let x = 0; x < S; x++) {
        const T = THEMES[ZN[colZone[z * S + x]]];
        if (!T.vine || !g.isAir(x, y, z)) continue;
        const wx = bx0 + x, wz = bz0 + z;
        if (hash(wx, y, wz, seed + 81) > T.vine) continue;
        let bits = 0;
        for (const [dx, dz, b] of SIDES) if (g.isHard(x + dx, y, z + dz)) { bits = b; break; }
        if (!bits) continue;
        if (fbm3(wx * 0.05, y * 0.04, wz * 0.05, seed + 80) < 0.54) continue;
        const name = `vine|vine_direction_bits=${bits}`;
        const len = 2 + Math.floor(hash(wx, y, wz, seed + 82) ** 2 * 22);
        for (let i = 0; i < len && y - i >= -2 && g.isAir(x, y - i, z); i++) g.set(x, y - i, z, name);
      }
    yield;
  }

  // 6. 記録の書見台（名所の区画だけ）
  g.points = [];
  const routeKey = Object.keys(STORY_ROUTE).find((k) => STORY_ROUTE[k][0] === di && STORY_ROUTE[k][1] === dj);
  const placeKey = lmKind ?? routeKey;
  const spots = lmKind ? RECORD_SPOTS[lmKind] || [] : routeKey ? ROUTE_SPOTS : [];
  spots.forEach(([x, z], k) => { const y = pedestal(g, x, z); g.points.push({ id: `${placeKey}${k}`, kind: placeKey, x, y, z }); });
  g.camps = [];
  if (placeKey) {
    const [x, z] = REST_SPOTS[placeKey] ?? REST_DEFAULT;
    const r = restCamp(g, x, z, seed + di * 31 + dj);
    g.camps.push({ id: placeKey, x, y: r.y, z, chest: r.chest, shop: r.shop });
  }
  g.frames = g.frames || [];
  return g;
}

// 橋の手すり（石レンガの塀。橋の向きにつながる）
const WALL_X = "stone_brick_wall|wall_connection_type_east=short,wall_connection_type_north=none,wall_connection_type_south=none,wall_connection_type_west=short,wall_post_bit=0";
const WALL_Z = "stone_brick_wall|wall_connection_type_east=none,wall_connection_type_north=short,wall_connection_type_south=short,wall_connection_type_west=none,wall_post_bit=0";

// 区画の種類（プレビュー・攻略用）
export function districtKind(seed, di, dj) {
  const lm = landmarks(seed);
  const k = Object.keys(lm).find((q) => lm[q][0] === di && lm[q][1] === dj);
  if (k) return LANDMARK_INFO[k].label;
  const rng = mulberry32(h32(seed ^ h32(di * 7919 + dj * 104729)));
  const c = zoneAt(di * CITY.SIZE + 64, dj * CITY.SIZE + 64, seed);
  return KIND_LABEL[pickKind(rng, THEMES[c.name], c)];
}
export const KIND_LABEL = ["巨大建築", "格子の巨塔", "高層ビル街", "沼の広場", "崖と湖", "工場", "古代遺跡"];
function pickKind(rng, T, zone) {
  if (zone.wild > 0.3) return rng() < 0.5 ? 3 : 4; // 街の外側は沼か崖
  let t = rng(), k = 0;
  while (k < T.kinds.length - 1 && t > T.kinds[k]) t -= T.kinds[k++];
  return k;
}
