// フィールド: 野生モンスターの出現（バイオーム別）・道ばたのチェスト・連れ歩き・ライド
import { rollTier, lvBonus, chestCmds, BASE_OF } from "./chests.js";
import { sidOf } from "./idx.js";
import { regionLv, regionAt } from "./worldmap.js";
import { world, system, MolangVariableMap } from "@minecraft/server";
import { SPECIES, ORDER, TRAITS, ITEMS } from "./data.js";
import { WP_OF } from "./cnames.js";
import { MAXLV, ri, pick } from "./core.js";
import { load, save, allMons } from "./store.js";
import { busy, ok, particle, cmd, isLite, rankOf, heavy, warming, barNote } from "./ui.js";
import { appraiseInventory } from "./gear.js";

export const TYPE = "mrpg:monster";
export const hooks = { inTown: () => false };
const DIMS = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];

const SZ_T = { S: 0.62, M: 1.05, L: 4.4, G: 6.0 };
const H_B = [0.7, 1.0, 1.4, 1.9, 2.5, 3.5, 5.0, 6.5];
export const hBucket = (h) => { const i = H_B.findIndex((t) => h < t); return i < 0 ? H_B.length : i; };
// 個体のサイズ（ちぢみの実 など）も 見た目に はんえいする
export const SIZE_UP = 1;   /* 第86版: 大きすぎたので 元の 大きさに 戻す（乗った ときに 前が 見える） */
export const sizeUp = (sz) => 1;
export function lookOf(sid, m) {
  if (m && m.look) { const k = (({ S: 0.75, M: 1, L: 1.6, G: 2.3 })[m.sz || "M"] || 1) * sizeUp(m.sz || "M"); return { size: Math.round(100 * k), mh: 1.3 * k, rh: 0.9 * k }; }
  const s = SPECIES[sid];
  const k = (m && m.sz && m.sz !== s.sz ? SZ_T[m.sz] / SZ_T[s.sz || "M"] : 1) * sizeUp((m && m.sz) || s.sz);
  return { size: Math.max(20, Math.min(2250, Math.round(s.size * k))), mh: s.mh * k, rh: (s.rh || s.mh) * k };
}
// v1.7: カスタム相棒の 見た目
export const CUST_KEYS = ["cb", "cs", "cf", "ch", "cw", "ct", "cc", "cwp", "cm"];
export const TINT_KEYS = ["h", "b", "a", "l", "c", "w"];
export const rideOf = (sid, m) => (m && m.look ? (m.look.cw > 0 ? "fly" : "walk") : SPECIES[sid]?.ride);
export function setLook(e, sid, m) {
  const s = SPECIES[sid];
  let L = lookOf(sid, m);
  const cust = !!(m && m.look);
  try {
    e.setProperty("mrpg:cust", cust);
    if (cust) for (const k of CUST_KEYS) e.setProperty(`mrpg:${k}`, m.look[k] || 0);
    // v2.7: どの モンスターも 武器を 装備していれば その 武器を 手に 持つ（相棒は 見た目で えらんだ 武器）
    const wq = m && m.eq && m.eq.w && ITEMS[m.eq.w]?.wtype && WP_OF[ITEMS[m.eq.w].wtype];
    e.setProperty("mrpg:cwp", wq || (cust ? m.look.cwp || 0 : 0));
  } catch {}
  // v2.7: 部位ごとの 色がえ
  try {
    const T = { ...(s.dtint || {}), ...Object.fromEntries(Object.entries((m && m.tint) || {}).filter(([, v]) => v)) };   /* 第69版: 0は 神の 色を 消さない */   /* 第68版: 神々は 決まった 色（色がえは 上書き） */   /* 第68版: 神々は 決まった 色 */
    let any = false;
    for (const k of TINT_KEYS) { const v = Math.max(0, Math.min(16, T[k] | 0)); if (v) any = true; e.setProperty(`mrpg:tc_${k}`, v); }
    e.setProperty("mrpg:tint", any);
  } catch {}
  e.setProperty("mrpg:sp", s.vis ?? s.idx);   /* 第68版: 神々は もとの 主の 姿 */
  e.setProperty("mrpg:arch", cust ? (m.look.cb === 5 ? 0 : 3) : s.arch);
  e.setProperty("mrpg:size", L.size);
  try { e.setProperty("mrpg:big", ({ L: 1, G: 2 })[(m && m.sz) || s.sz] || 0); } catch {}
  e.setProperty("mrpg:init", true);
  try { e.setProperty("mrpg:form", e.hasTag("mrpg_nightmare") ? 2 : 1); } catch {}
  try { e.setProperty("mrpg:lite", isLite()); } catch {}   // v3.0: 軽量モードの しるし   // v3.0: 悪夢の エンマは 鍔の ない 抜き身の まま（2）   // v3.0: エンマは いつも 刀を 腰の 鞘に（抜くのは 斬る ときだけ）   // v2.9.14: エンマの 姿（悪夢＝抜き身・現世＝帯刀）
  // v1.4: エンティティの プロパティは 次の tick まで 反映されないので、すぐ 読める 目印も 残す
  try { e.setDynamicProperty("mrpg:sid", sid); } catch {}
  e.triggerEvent(`mrpg:size_h${hBucket(L.mh)}`);
}
const KEEP_TAGS = ["mrpg_pet", "mrpg_battle", "mrpg_boss", "mrpg_raid", "mrpg_slab", "mrpg_masterteam", "mrpg_temp", "mrpg_play"];
export function setSpeed(e, sid, mult = 1) {
  try { e.getComponent("minecraft:movement")?.setCurrentValue(SPECIES[sid].rspeed * mult); } catch {}
}

// ---------- バイオーム判定（足もとのブロックとまわりから推定） ----------
const has = (id, ...ks) => ks.some((k) => id.includes(k));
export function biomeAt(dim, loc) {
  // v2.6.2: ネザー・エンドも 場所ごとに すむ モンスターが ちがう
  if (dim.id === "minecraft:nether" || dim.id === "minecraft:the_end") return subBiome(dim, loc);
  // 新しいバージョンでは 本物の バイオーム名を 使う
  try {
    const b = typeof dim.getBiome === "function" ? dim.getBiome(loc) : null;
    const id = (b && (b.id || b.typeId)) || "";
    if (id) {
      if (has(id, "desert", "badlands", "mesa")) return "desert";
      if (has(id, "frozen", "snow", "ice", "cold", "grove", "jagged")) return "snow";
      if (has(id, "ocean", "river", "beach", "shore")) return "water";
      if (has(id, "swamp", "mangrove")) return "swamp";
      if (has(id, "dripstone", "lush", "deep_dark")) return "cave";
      if (has(id, "peak", "mountain", "hills", "slope", "windswept", "stony")) return "mountain";
      if (has(id, "forest", "taiga", "jungle", "birch", "cherry", "roofed", "bamboo")) return "forest";
      if (has(id, "plains", "savanna", "meadow", "sunflower")) return "plains";
    }
  } catch {}
  const x = Math.floor(loc.x), y = Math.floor(loc.y), z = Math.floor(loc.z);
  let below = "";
  try { below = dim.getBlock({ x, y: y - 1, z })?.typeId || ""; } catch {}
  let roof = false, leaves = false, water = false;
  try {
    for (let dy = 2; dy < 24; dy++) { const b = dim.getBlock({ x, y: y + dy, z })?.typeId || ""; if (has(b, "leaves")) leaves = true; else if (b !== "minecraft:air" && b) { roof = true; break; } }
    for (const [dx, dz] of [[3, 0], [-3, 0], [0, 3], [0, -3]]) if (has(dim.getBlock({ x: x + dx, y: y - 1, z: z + dz })?.typeId || "", "water")) water = true;
  } catch {}
  if (roof && y < 60) return "cave";
  if (has(below, "sand", "terracotta")) return "desert";
  if (has(below, "snow", "ice")) return "snow";
  if (water || has(below, "water")) return "water";
  if (has(below, "mud", "mycelium", "moss", "mangrove")) return "swamp";
  if (leaves || has(below, "podzol")) return "forest";
  if (y > 95 || has(below, "stone", "gravel", "tuff", "calcite")) return "mountain";
  return "plains";
}
export const baseBiome = (b) => (String(b).startsWith("n_") ? "nether" : String(b).startsWith("e_") ? "end" : b);
function subBiome(dim, loc) {
  const x = Math.floor(loc.x), y = Math.floor(loc.y), z = Math.floor(loc.z);
  let b = "";
  for (const dy of [-1, -2, -3]) { try { b = dim.getBlock({ x, y: y + dy, z })?.typeId || ""; } catch {} if (b && b !== "minecraft:air") break; }
  if (dim.id === "minecraft:nether") return /soul/.test(b) ? "n_soul" : /basalt|blackstone/.test(b) ? "n_basalt" : /crimson|nether_wart/.test(b) ? "n_crimson" : /warped/.test(b) ? "n_warped" : "nether";
  let s = { x: 0, z: 0 }; try { s = world.getDefaultSpawnLocation(); } catch {}
  return Math.hypot(x, z) > 900 ? "e_outer" : "end";
}
export const BIOME_NAME = { plains: "そうげん", forest: "森", desert: "さばく", snow: "ゆきやま", water: "みずべ", swamp: "しっち", mountain: "山", cave: "どうくつ", nether: "ネザー", end: "エンド" };
const BIOME_FAMS = {
  plains: { beast: 3, animal: 4, blob: 3, sword: 1 },
  forest: { animal: 5, beast: 2, blob: 1 },
  desert: { golem: 3, nether: 3, animal: 2, dragon: 2, sword: 1 },
  snow: { beast: 3, blob: 2, animal: 2, dragon: 1 },
  water: { aqua: 3, blob: 3, animal: 3 },
  ocean: { aqua: 12, blob: 1 },
  swamp: { nether: 4, animal: 4, blob: 2 },
  mountain: { dragon: 3, golem: 3, animal: 3, beast: 2, sword: 2 },
  cave: { golem: 3, nether: 4, animal: 2 },
  nether: { nether: 10, dragon: 2 },
  end: { nether: 10, dragon: 2 },
  // v2.6.2: ネザーの 地形・エンドの 外の 島・深い 洞くつ・深海
  n_soul: { nether: 11, animal: 1 }, n_basalt: { golem: 5, dragon: 4, nether: 2 }, n_crimson: { nether: 7, beast: 3 }, n_warped: { nether: 5, animal: 5 },
  e_outer: { nether: 5, dragon: 4, animal: 3, golem: 1 }, deepcave: { golem: 4, nether: 5, dragon: 1, animal: 1 }, deepsea: { aqua: 14, dragon: 1, nether: 1 },
};
function weightedKey(o) {
  const tot = Object.values(o).reduce((a, b) => a + b, 0);
  let r = Math.random() * tot;
  for (const [k, v] of Object.entries(o)) { r -= v; if (r <= 0) return k; }
  return Object.keys(o)[0];
}
export function levelAt(dim, loc) {
  // v2.3: 地上は 地方ごとの 強さ
  if (dim.id === "minecraft:overworld") return Math.max(1, Math.min(MAXLV, regionLv(loc) + ri(-2, 2)));
  const s = world.getDefaultSpawnLocation();
  const dist = Math.hypot(loc.x - s.x, loc.z - s.z);
  // 100ブロックごとに +1〜5（平均 +3）。同じ場所は だいたい同じ強さ
  const band = Math.floor(dist / 100);
  let lv = 1 + band * 3 + ri(-2, 2) + (band > 0 ? ri(0, 2) : 0);
  if (dim.id === "minecraft:nether") lv += 15;
  if (dim.id === "minecraft:the_end") lv += 30;
  return Math.max(1, Math.min(MAXLV, lv));
}
const WPOOL = new Map();
// 野生の 候補（A〜SSは 野生の しるしが なくても 出る。王・神・ハガネは のぞく）
function wildPool(fam, rk, home) {
  const key = `${fam}|${rk}|${home}`;
  if (!WPOOL.has(key)) { const hi = rk === "A" || rk === "S" || rk === "SS"; WPOOL.set(key, ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && !S.giant && !S.sea && S.fam === fam && S.rank === rk && (S.wild || (hi && !S.metalmon && S.fam !== "king" && S.fam !== "god")) && (!home || (S.home || "over") === home); })); }
  return WPOOL.get(key);
}
export function pickWild(biome, lv, reg = null) {
  // v2.4.4: 後半は B〜S が 多め
  const ranks = lv <= 4 ? ["F"] : lv <= 10 ? ["F", "E"] : lv <= 18 ? ["E", "D"] : lv <= 28 ? ["D", "C"] : lv <= 40 ? ["C", "B"] : lv <= 52 ? ["B", "A", "C", "A"] : lv <= 64 ? ["A", "A", "S", "S"] : lv <= 78 ? ["A", "S", "S", "SS"] : ["S", "S", "SS", "SS"];   // 第66版: 後半は S〜SSが 出やすい
  const fams = { ...(BIOME_FAMS[biome] || BIOME_FAMS.plains) };
  // v2.3: 地方ごとに すむ モンスターが ちがう（地方の 系統を 強く）
  const bb = baseBiome(biome);
  if (reg && biome !== "ocean" && biome !== "deepsea" && bb !== "nether" && bb !== "end") { for (const k of Object.keys(fams)) fams[k] *= 0.4; for (const [k, v] of Object.entries(reg.fams)) fams[k] = (fams[k] || 0) + v * 2; }
  const night = (() => { try { const t = world.getTimeOfDay(); return t > 13000 && t < 23000; } catch { return false; } })();
  if (night && bb !== "nether" && bb !== "end" && bb !== "ocean" && bb !== "deepsea" && biome !== "ocean" && biome !== "deepsea") { fams.nether = (fams.nether || 0) + 3; }   // 夜は ネザー系が ふえる
  for (let i = 0; i < 6; i++) {
    const fam = weightedKey(fams);
    // v2: ネザー・エンドの 見た目の 死者系・魔系は それぞれの ディメンションに すむ
    const home = bb === "nether" ? "nether" : bb === "end" ? "end" : "over";
    // ランクを 重みつきで 選び、その 系統に いなければ ほかの ランクで（系統は かえない）
    const order = [...ranks].sort(() => Math.random() - 0.5);
    for (const rk of order) {
      let pool = wildPool(fam, rk, home);
      if (!pool.length) pool = wildPool(fam, rk, "");   // 地方に すむ 系統（冥府の 悪魔など）は ちがう 世界の 種も
      if (pool.length) return pick(pool);
    }
  }
  return pick(ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].wild && ranks.includes(SPECIES[s].rank) && (SPECIES[s].home || "over") === "over"));
}
// まれに 強いランク（A〜SS）が 現れる。王と神は でない
const RARE_POOL = {};
function rarePool(rank, fam) {
  const k = rank + ":" + fam;
  if (!RARE_POOL[k]) RARE_POOL[k] = ORDER.filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && !SPECIES[s].metalmon && !SPECIES[s].giant && !SPECIES[s].sea && SPECIES[s].rank === rank && SPECIES[s].fam !== "king" && SPECIES[s].fam !== "god" && (!fam || SPECIES[s].fam === fam));
  return RARE_POOL[k];
}
export function rollRare(lv, dimId, k = 1) {
  const m = (dimId === "minecraft:overworld" ? 1 : 2) * k;
  const r = Math.random();
  if (lv >= 60 && r < (0.02 + (lv - 60) * 0.0015) * m) return "SS";   // 第66版: 甘めに（Lv60で 2%・Lv80で 5%）
  if (lv >= 45 && r < (0.05 + (lv - 45) * 0.001) * m + (lv >= 60 ? (0.02 + (lv - 60) * 0.0015) * m : 0)) return "S";
  if (lv >= 30 && r < (0.03 + (lv - 30) * 0.0006) * m) return "A";
  return null;
}
export function initWild(e) {
  if (!ok(e) || e.getProperty("mrpg:init") || KEEP_TAGS.some((t) => e.hasTag(t))) return;
  try { if (typeof e.getDynamicProperty("mrpg:sid") === "string") return; } catch {}
  let lv = levelAt(e.dimension, e.location);
  const sea = e.hasTag("mrpg_sea") || isSea(e.dimension, e.location);
  const deep = e.hasTag("mrpg_deep");
  let bio = sea ? (deep ? "deepsea" : "ocean") : biomeAt(e.dimension, e.location);
  // v2.6.2: 地下ほど 強い（Y40より 下は 5ブロックごとに +1・最大 +15）。とても 深い 洞くつは 専用の 顔ぶれ
  let rareK = 1;
  if (e.dimension.id === "minecraft:overworld" && !sea && bio === "cave") { const dl = Math.max(0, Math.min(15, Math.floor((40 - e.location.y) / 5))); lv = Math.min(MAXLV, lv + dl); if (e.location.y < 0) { bio = "deepcave"; rareK = 2; } }
  if (deep) { lv = Math.min(MAXLV, lv + 6); rareK = 2; }
  if (bio === "e_outer") { lv = Math.min(MAXLV, lv + 8); rareK = 1.5; }
  let sid = pickWild(bio, lv, e.dimension.id === "minecraft:overworld" && !deep ? regionAt(e.location) : null);
  let q = Math.min(0.6, lv / 160);
  let rr = rollRare(lv, e.dimension.id, rareK);
  { const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"]; if (rr && RK.indexOf(rr) <= RK.indexOf(SPECIES[sid]?.rank)) rr = null; }   // 第66版: まれな 個体は もとより 上の ランクの ときだけ
  if (rr) {
    const pool = rarePool(rr, SPECIES[sid].fam);
    const pool2 = pool.length ? pool : rarePool(rr, "");
    if (pool2.length) { sid = pick(pool2); e.addTag("mrpg_rare"); q += 0.25; }
  }
  // v1.5: ハガネ族（経験値が とても 多い）が まれに 出る
  if (!sea && Math.random() < 0.015) {
    const mr = ["D", "C", "B", "A", "S", "SS"].filter((r, i) => lv >= [3, 10, 20, 35, 55, 75][i]);
    const mp = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].metalmon && mr.includes(SPECIES[s].rank));
    if (mp.length) { sid = pick(mp); e.addTag("mrpg_rare"); e.addTag("mrpg_metal"); rr = SPECIES[sid].rank; }
  }
  // 遠い 海の ぬし（Gサイズの 巨獣）
  if (sea) {
    const r2 = Math.random();
    const gk = deep ? 3 : 1;   // v2.6.2: 深海は 海の ぬしが 出やすい
    const giant = lv >= 45 && r2 < 0.006 * gk ? "S" : lv >= 20 && r2 < 0.025 * gk ? "A" : null;
    if (giant) {
      const gp = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].sea && SPECIES[s].rank === giant);
      if (gp.length) { sid = pick(gp); e.addTag("mrpg_rare"); e.addTag("mrpg_giant"); q += 0.3; rr = giant; }
    }
    // v2.9.6: 水の 中に 出た 子は 海系に して 泳がせる。水面の 子は 浮く
    if (e.hasTag("mrpg_under")) {
      if (SPECIES[sid].fam !== "aqua" && !e.hasTag("mrpg_giant")) { const ap = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].wild && SPECIES[s].fam === "aqua" && SPECIES[s].rank === SPECIES[sid].rank); const ap2 = ap.length ? ap : ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].wild && SPECIES[s].fam === "aqua"); if (ap2.length) sid = pick(ap2); }
      try { e.triggerEvent("mrpg:aqua_on"); } catch {}
    } else if (!deep) try { e.triggerEvent("mrpg:float_on"); } catch {}
  }
  // v2.6: 虚空の島・幻の モンスター（やりこみ）
  let ov = null; try { ov = hooks.override ? hooks.override(e, lv, sid) : null; } catch {}
  if (ov && SPECIES[ov.sid]) { sid = ov.sid; if (ov.lv) lv = ov.lv; if (ov.q !== undefined) q = Math.max(q, ov.q); for (const t of ov.tags || []) e.addTag(t); if (!ov.plain) rr = SPECIES[sid].rank; }   /* 第102版: plain は ふつうの 野生の まま（季節・変わり種 など） */
  // v2.6: 期間限定の 色違い（今週の 系統は 出やすい）
  let shR = 1 / 250; try { if (hooks.shinyRate) shR = hooks.shinyRate(sid) || shR; } catch {}
  const shiny = Math.random() < shR;
  if (shiny) { e.addTag("mrpg_shiny"); q = 1; }
  setLook(e, sid);
  setSpeed(e, sid, 0.8);
  e.setDynamicProperty("mrpg:lv", lv);
  e.setDynamicProperty("mrpg:q", q);
  // 軽量モード: ふつうの 野生は 名前を 出さない（名前の 描画を 減らす）
  if (!isLite() || rr || shiny) e.nameTag = `${shiny ? "§e★" : ""}${rr ? "§6" : "§f"}${SPECIES[sid].name} §7Lv${lv} ${rankOf(sid)}`;
  if (rr || shiny) {
    try { e.triggerEvent("mrpg:keep"); e.addTag("mrpg_keep"); e.setDynamicProperty("mrpg:rt", Date.now()); } catch {}   // v3.0 第63版: 知らせた あと 勝手に 消えない
    for (const p of world.getAllPlayers()) {
      if (p.dimension.id !== e.dimension.id || Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) > 40) continue;
      if (ov && ov.msg) p.sendMessage(ov.msg); else
      if (e.hasTag("mrpg_giant")) p.sendMessage(`§3§l海が ざわめく… 海の ぬし §f${SPECIES[sid].name}§3（ランク${SPECIES[sid].rank}）が 現れた！`); else
      p.sendMessage((shiny ? `§e★ かがやく ${SPECIES[sid].name} の 気配が する…！` : `§6強い 気配が する… §f${SPECIES[sid].name}（ランク${SPECIES[sid].rank}）が 近くに いる！`) + ` §7（${dirOf(p.location, e.location)}・${Math.round(Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z))}m）`);
      try { p.playSound(shiny ? "random.levelup" : "mob.wither.ambient", { pitch: shiny ? 1.6 : 1.4, volume: 0.6 }); } catch {}
    }
  }
}
export function wildInfo(e) {
  let ds; try { ds = e.getDynamicProperty("mrpg:sid"); } catch {}
  const sid = typeof ds === "string" && SPECIES[ds] ? ds : ORDER[e.getProperty("mrpg:sp")] ?? ORDER[0];
  const lv = e.getDynamicProperty("mrpg:lv");
  const q = e.getDynamicProperty("mrpg:q");
  return { sid, lv: typeof lv === "number" ? lv : levelAt(e.dimension, e.location), q: typeof q === "number" ? q : 0, shiny: e.hasTag("mrpg_shiny") };
}

// v2.6.2: 海の 底（水の 中で 下が 固い ブロック）
function seaFloorAt(dim, x, y, z) {
  for (let dy = 3; dy >= -24; dy--) {
    try {
      const b = dim.getBlock({ x, y: y + dy, z }), a1 = dim.getBlock({ x, y: y + dy + 1, z });
      if (b && a1 && !b.isAir && !b.isLiquid && !(b.typeId || "").includes("water") && (a1.typeId || "").includes("water")) return { x: x + 0.5, y: y + dy + 1, z: z + 0.5, sea: true, deep: waterDepth(dim, x, y + dy + 1, z) >= 8 };
    } catch { return null; }
  }
  return null;
}
// 地面をさがす
function groundAt(dim, x, y, z) {
  for (let dy = 8; dy >= -14; dy--) {
    try {
      const b = dim.getBlock({ x, y: y + dy, z });
      const a1 = dim.getBlock({ x, y: y + dy + 1, z }), a2 = dim.getBlock({ x, y: y + dy + 2, z });
      if (b && a1 && a2 && !b.isAir && !b.isLiquid && a1.isAir && a2.isAir) return { x: x + 0.5, y: y + dy + 1, z: z + 0.5 };
    } catch { return null; }
  }
  return null;
}
// 海の 水面（ふかさ 3以上）
function waterAt(dim, x, y, z) {
  for (let dy = 6; dy >= -10; dy--) {
    try {
      const b = dim.getBlock({ x, y: y + dy, z }), a1 = dim.getBlock({ x, y: y + dy + 1, z });
      if (!b || !a1 || !a1.isAir || !(b.typeId || "").includes("water")) continue;
      const d1 = dim.getBlock({ x, y: y + dy - 1, z }), d2 = dim.getBlock({ x, y: y + dy - 2, z });
      if ((d1?.typeId || "").includes("water") && (d2?.typeId || "").includes("water")) return { x: x + 0.5, y: y + dy, z: z + 0.5, sea: true };
      return null;
    } catch { return null; }
  }
  return null;
}
// v2.6.2: 海の 中（もぐっている とき）。水面から 8ブロック 以上 深いと 深海
export function underwater(p) { try { const l = p.location; return (p.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y) + 1, z: Math.floor(l.z) })?.typeId || "").includes("water"); } catch { return false; } }
export function waterDepth(dim, x, y, z) { let n = 0; try { for (let dy = 0; dy < 40; dy++) { const b = dim.getBlock({ x, y: y + dy, z }); if (!b || !/water|kelp|seagrass|sea_pickle/.test(b.typeId || "")) break; n++; } } catch {} return n; }
function diveAt(dim, x, y, z) {
  for (let dy = 4; dy >= -6; dy--) {
    try {
      const b = dim.getBlock({ x, y: y + dy, z }), a1 = dim.getBlock({ x, y: y + dy + 1, z });
      if (b && a1 && (b.typeId || "").includes("water") && (a1.typeId || "").includes("water")) { const dep = waterDepth(dim, x, y + dy, z); return { x: x + 0.5, y: y + dy, z: z + 0.5, sea: true, deep: dep >= 8 }; }
    } catch { return null; }
  }
  return null;
}
export const isSea = (dim, loc) => {
  try {
    const x = Math.floor(loc.x), z = Math.floor(loc.z), y = Math.floor(loc.y);
    for (const dy of [0, -1]) if ((dim.getBlock({ x, y: y + dy, z })?.typeId || "").includes("water")) return true;
  } catch {}
  return false;
};
export function spawnWildNear(p, n = 1, rmin = 12, rmax = 26) {
  let made = 0;
  for (let i = 0; i < n * 3 && made < n; i++) {
    const a = Math.random() * Math.PI * 2, r = rmin + Math.random() * (rmax - rmin);
    const x = Math.floor(p.location.x + Math.cos(a) * r), z = Math.floor(p.location.z + Math.sin(a) * r), y = Math.floor(p.location.y);
    const under = underwater(p);
    let pos = under ? diveAt(p.dimension, x, y, z) : groundAt(p.dimension, x, y, z) || waterAt(p.dimension, x, y, z);
    if (!pos || hooks.inTown(pos, p.dimension.id)) continue;
    // v2.9.6: 海では 水の 中にも 出る（ふかさ 4以上・海系だけ 泳ぐ）
    if (pos.sea && !under && Math.random() < 0.6) {
      let fl = 0; try { for (let k = 1; k < 30; k++) { const b = p.dimension.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y) - k, z: Math.floor(pos.z) }); if (!b || !(b.typeId || "").includes("water")) { fl = k; break; } } } catch {}
      if (fl === 0) fl = 12;   // とても 深い 海（底が 見えない）でも 水の 中に
      if (fl >= 5) { const k = 2 + Math.floor(Math.random() * (fl - 3)); pos = { x: pos.x, y: Math.floor(pos.y) - k, z: pos.z, sea: true, under: true }; }
    } else if (under && pos) pos.under = true;
    try { const e = p.dimension.spawnEntity(TYPE, pos); if (pos.sea) e.addTag("mrpg_sea"); if (pos.deep) e.addTag("mrpg_deep"); if (pos.under) e.addTag("mrpg_under"); initWild(e); made++; } catch {}
  }
  return made;
}

// ---------- 出現ループ（プレイヤーごとに上限つき） ----------
const WILD_CAP = 8;   // v2.8: 軽く（10 → 8）
let _spawnTick = 0;
system.runInterval(() => {
  _spawnTick++;
  if (isLite() && _spawnTick % 2) return;   // 軽量モードでは 出現チェックを 半分に
  if (warming()) return;                     // v1.7: 入った 直後は 出さない（処理速度 優先）
  const all = world.getAllPlayers();
  for (const p of all) {
    if (busy.has(p.id) || (hooks.noSpawn && hooks.noSpawn(p))) continue;
    let near = 0;
    try { near = p.dimension.getEntities({ type: TYPE, location: p.location, maxDistance: 40, excludeTags: ["mrpg_pet", "mrpg_battle"] }).length; } catch {}
    const cap = ([WILD_CAP, 5, 3][heavy()]) - (all.length >= 3 ? 2 : 0);   // v1.7: 重いほど 少なく   // 3人以上の マルチでは すこし へらす
    if (near < cap) spawnWildNear(p, Math.min(2, cap - near));
  }
}, 60);

// ---------- ボスの 見た目を 守る ＋ レイドボスの 赤い 闘気 ----------
const _aura = (() => { try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: 1, green: 0.12, blue: 0.08 }); m.setFloat("variable.scale", 2.4); return m; } catch { return undefined; } })();
const _auraIn = (() => { try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: 1, green: 0.45, blue: 0.1 }); m.setFloat("variable.scale", 1.4); return m; } catch { return undefined; } })();
let _auraTick = 0;
system.runInterval(() => {
  _auraTick++;
  if (heavy() >= 2 && _auraTick % 4) return;   // v1.7: とても 重いときは オーラを へらす
  const pd = new Set(world.getAllPlayers().map((q) => q.dimension.id));   // v2.8: プレイヤーの いない ディメンションは しらべない
  for (const id of DIMS) {
    if (!pd.has(id)) continue;
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_boss"] }); } catch {}
    for (const e of list) {
      if (!ok(e)) continue;
      let ds; try { ds = e.getDynamicProperty("mrpg:sid"); } catch {}
      if (typeof ds === "string" && SPECIES[ds] && (SPECIES[ds].vis ?? SPECIES[ds].idx) !== e.getProperty("mrpg:sp")) {
        try { e.setProperty("mrpg:sp", SPECIES[ds].vis ?? SPECIES[ds].idx); e.setProperty("mrpg:arch", SPECIES[ds].arch); e.setProperty("mrpg:init", true); } catch {}
        const sz = e.getDynamicProperty("mrpg:bsize"); if (typeof sz === "number") try { e.setProperty("mrpg:size", sz); } catch {}
      }
      if (!e.hasTag("mrpg_raid") || e.hasTag("mrpg_battle")) continue;
      if (isLite() && _auraTick % 2) continue;
      const h = Math.max(1.5, (SPECIES[ds]?.mh || 2) * 1.8);
      const l = e.location;
      try {
        e.dimension.spawnParticle("mrpg:aura", { x: l.x, y: l.y + 0.1, z: l.z }, _aura);
        e.dimension.spawnParticle("mrpg:aura", { x: l.x, y: l.y + h * 0.45, z: l.z }, _auraIn);
        if (!isLite()) e.dimension.spawnParticle("minecraft:basic_flame_particle", { x: l.x + (Math.random() - 0.5) * 2, y: l.y + h * Math.random(), z: l.z + (Math.random() - 0.5) * 2 });
      } catch {}
    }
  }
}, 20);

// ---------- 装備の 鑑定（チェスト・作業台・ドロップで 手に入れた 装備に レア度を つける）----------
let _apT = 0;
system.runInterval(() => {
  if (isLite() && (++_apT % 2)) return;   /* 第97版: 軽量モードは 2回に 1回（前は tickの 番号しだいで 1回も 動かない ことが あった） */
  for (const p of world.getAllPlayers()) { if (busy.has(p.id)) continue; try { appraiseInventory(p); } catch {} }
}, 60);

// ---------- 道ばたのチェスト ----------
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (busy.has(p.id) || Math.random() > (isLite() ? 0.2 : 0.4)) continue;
    if ((hooks.noSpawn && hooks.noSpawn(p)) || hooks.inTown(p.location, p.dimension.id)) continue;   // v2.9.12: 町・城・石板の 中には 道ばたの 宝箱を 出さない
    // v2.6.2: ネザー・エンド・洞くつ・海の 底にも 宝箱
    const dimId = p.dimension.id, under = underwater(p);
    const a = Math.random() * Math.PI * 2, r = (under ? 8 : 16) + Math.random() * (under ? 10 : 16);
    const gx = Math.floor(p.location.x + Math.cos(a) * r), gz = Math.floor(p.location.z + Math.sin(a) * r);
    const pos = under ? seaFloorAt(p.dimension, gx, Math.floor(p.location.y), gz) : groundAt(p.dimension, gx, Math.floor(p.location.y), gz);
    if (pos && hooks.inTown(pos, dimId)) continue;   // v2.9.12: 出る 場所が 町・城の 中なら やめる
    if (!pos) continue;
    const x = Math.floor(pos.x), y = Math.floor(pos.y), z = Math.floor(pos.z);
    try {
      const under = p.dimension.getBlock({ x, y: y - 1, z })?.typeId || "";
      if (has(under, "leaves", "log", "lava") || (!pos.sea && has(under, "water"))) continue;
      // 段: 地上 1〜・洞くつ 2〜（Y0より 下 +1）・海の 底 3〜（深海 +1）・ネザー 3〜・エンド 4〜（外の 島 +1）
      let base = 1, bonus = 0;
      if (dimId === "minecraft:nether") base = 3;
      else if (dimId === "minecraft:the_end") { base = 4; if (Math.hypot(x, z) > 900) bonus = 1; }
      else if (pos.sea) { base = 3; if (pos.deep) bonus = 1; }
      else { bonus = lvBonus(pos); if (biomeAt(p.dimension, pos) === "cave") { base = 2; if (y < 0) bonus += 1; } }
      for (const c of chestCmds(x, y, z, rollTier(base, bonus), dimId)) cmd(p, c);   // v2.6.1: 宝箱の レア度
      cmd(p, `particle minecraft:villager_happy ${x} ${y + 1} ${z}`);
    } catch {}
  }
}, 20 * 25);

// ---------- 連れ歩き ----------
export function findPet(p) {
  for (const id of DIMS) {
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_pet"] }); } catch {}
    const e = list.find((x) => x.getDynamicProperty("mrpg:owner") === p.id);
    if (e) return e;
  }
  return null;
}
const petName = (m) => `§b★${m.nm} §fLv${m.lv} ${rankOf(m.sp)}`;
export function makePetGroups(e, sid, m) {
  e.triggerEvent("mrpg:make_pet");
  const s = SPECIES[sid];
  e.triggerEvent(`mrpg:ride_h${hBucket(lookOf(sid, m).rh)}`);
  if (rideOf(sid, m) === "float" || rideOf(sid, m) === "swim") e.triggerEvent("mrpg:float_on");
  const fast = (s.traits || []).includes("ride_fast") ? 1.3 : 1;
  let rm = 1; try { rm = hooks.rideMul ? hooks.rideMul(e, m) : 1; } catch {}   /* 第101版: ライドの 熟練度 */
  setSpeed(e, sid, fast * rm);
}
export function spawnPet(p, m) {
  const l = p.location;
  const e = p.dimension.spawnEntity(TYPE, { x: l.x + 1, y: l.y, z: l.z + 1 });
  e.addTag("mrpg_pet");
  setLook(e, m.sp, m);
  e.setDynamicProperty("mrpg:owner", p.id);   /* 第101版: 先に 持ち主（ライドの 熟練度の 速さに 使う） */
  e.setDynamicProperty("mrpg:mid", m.id);
  makePetGroups(e, m.sp, m);
  e.nameTag = petName(m);
  particle(e, "minecraft:villager_happy");
  try { riding.set(e.id, e); } catch {}
  return e;
}
export function recallPet(p, d) {
  const e = findPet(p);
  try { if (e && e.getComponent("minecraft:rideable")?.getRiders().some((r) => r.id === p.id)) p.addEffect("slow_falling", 160, { showParticles: false }); } catch {}   // v2.9.2: 飛んで いる ときに しまっても 落ちない
  if (e) { particle(e, "minecraft:white_smoke_particle"); try { e.remove(); } catch {} }
  d.out = null;
}
export function refreshPet(p, d) {
  const e = findPet(p);
  const m = allMons(d).find((x) => x.id === d.out);
  if (!e || !m) return;
  setLook(e, m.sp, m);
  e.triggerEvent(`mrpg:ride_h${hBucket(lookOf(m.sp, m).rh)}`);
  e.nameTag = petName(m);
}

const riding = new Map(); // pet entity id -> entity
// v2.9.6: 連れ歩きを 消す ときは 乗っている 人が 落ちて けがを しない ように
function rmPet(e) { try { for (const r of e.getComponent("minecraft:rideable")?.getRiders() || []) try { r.addEffect("slow_falling", 160, { showParticles: false }); } catch {} } catch {} try { e.remove(); } catch {} }
system.runInterval(() => {
  const players = world.getAllPlayers();
  const byId = new Map(players.map((p) => [p.id, p]));
  const seen = new Set();
  riding.clear();
  for (const id of DIMS) {
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_pet"] }); } catch {}
    for (const e of list) {
      const p = byId.get(e.getDynamicProperty("mrpg:owner"));
      if (!p) { rmPet(e); continue; }
      if (busy.has(p.id)) { seen.add(p.id); continue; }
      const d = load(p);
      if (!d || d.out !== e.getDynamicProperty("mrpg:mid") || seen.has(p.id)) { rmPet(e); continue; }
      seen.add(p.id);
      riding.set(e.id, e);
      // 古い バージョンで うごけなく なった 連れ歩きを なおす
      try { if (!e.getComponent("minecraft:movement") && !e.getComponent("minecraft:rideable")?.getRiders()?.length) { const m = allMons(d).find((x) => x.id === d.out); if (m) makePetGroups(e, m.sp, m); } } catch {}
      let rider = null;
      try { rider = e.getComponent("minecraft:rideable")?.getRiders()?.[0]; } catch {}
      const far = e.dimension.id !== p.dimension.id || Math.hypot(e.location.x - p.location.x, e.location.z - p.location.z) > 16;
      if (far && !rider) try { e.teleport({ x: p.location.x + 1, y: p.location.y, z: p.location.z + 1 }, { dimension: p.dimension }); } catch {}
    }
  }
  for (const p of players) {
    if (seen.has(p.id) || busy.has(p.id) || (hooks.petHold && hooks.petHold(p))) continue;   /* 第103版: ミニゲームの 間は 出さない */
    const d = load(p);
    const m = d && d.out && allMons(d).find((x) => x.id === d.out);
    if (m && m.hp > 0) { try { spawnPet(p, m); } catch {} }
    else if (d && d.out) { d.out = null; save(p, d); }
  }
}, 40);

// ライド中の操作（飛行・浮遊・ジャンプ）
const flying = new Set();
const ridden = new Set();
const jumpCd = new Map();
// v2.9.3: ライドの 種類ごとの 動き
const RMODE = { walk: 1, float: 1, fly: 2, swim: 3, climb: 4, burrow: 5 };
const rmodeNow = new Map(), digCd = new Map();
const DIG_OK = /(stone|dirt|grass_block|^minecraft:sand$|red_sand|gravel|clay|netherrack|andesite|diorite|granite|tuff|calcite|deepslate|podzol|mycelium|coarse|^minecraft:mud$|terracotta|sandstone|snow|_ore$|soul_s|blackstone|basalt|end_stone|moss_block|rooted_dirt|dripstone_block|cobblestone|ice$)/;
const DIG_NG = /(brick|polished|smooth|chiseled|cut_|_wall|slab|stairs|bedrock|obsidian|reinforced|chest|barrel|spawner|portal|command|structure|budding)/;
const RAD = { S: 0.35, M: 0.5, L: 0.8, G: 1.1 }, HT = { S: 1, M: 2, L: 3, G: 3 };
function solidAhead(e, fx, fz, r, dy) {
  try { const l = e.location; const b = e.dimension.getBlock({ x: Math.floor(l.x + fx * (r + 0.55)), y: Math.floor(l.y + dy), z: Math.floor(l.z + fz * (r + 0.55)) }); return !!b && !b.isAir && !b.isLiquid && !/(grass$|short_grass|tall_grass|flower|torch|snow_layer|carpet|vine|sapling|fern)/.test(b.typeId); } catch { return false; }
}
function digAhead(e, rider, fx, fz, sz, down) {
  if ((hooks.noDig && hooks.noDig(e.location, e.dimension)) || (hooks.noSpawn && hooks.noSpawn(rider))) { try { barNote(rider).setActionBar("§7ここでは 掘れない（町・城・石板の 中）"); } catch {} return false; }
  const l = e.location, r = RAD[sz] || 0.5, h = HT[sz] || 2, side = sz === "L" || sz === "G" ? [-1, 0, 1] : [0];
  const px = -fz, pz = fx; let n = 0;
  const pts = [];
  if (down) for (const o of side) for (const o2 of side) pts.push([Math.floor(l.x + px * o + fx * o2 * 0.5), Math.floor(l.y - 1), Math.floor(l.z + pz * o + fz * o2 * 0.5)]);
  else for (let dy = 0; dy < h; dy++) for (const o of side) pts.push([Math.floor(l.x + fx * (r + 0.6) + px * o), Math.floor(l.y + dy + 0.2), Math.floor(l.z + fz * (r + 0.6) + pz * o)]);
  for (const [x, y, z] of pts) {
    let b; try { b = e.dimension.getBlock({ x, y, z }); } catch {}
    if (!b || b.isAir || b.isLiquid) continue;
    const id = b.typeId; if (!DIG_OK.test(id) || DIG_NG.test(id) || y <= -63) continue;
    try { e.dimension.runCommand(`setblock ${x} ${y} ${z} air destroy`); n++; } catch {}
  }
  if (n) { try { rider.playSound("dig.stone", { volume: 0.8, pitch: 0.8 + Math.random() * 0.3 }); } catch {} particle(e, "minecraft:critical_hit_emitter", 0.5); }
  return n > 0;
}
const lastRider = new Map();
const sprintOn = new Map();
const stuck = new Map();
const hops = new Map(), RIDE_T = new Map();
system.runInterval(() => {
  for (const [id, e] of riding) {
    if (!ok(e)) { for (const M of [rmodeNow, lastRider, sprintOn, stuck, hops, jumpCd, digCd, RIDE_T]) M.delete(id); flying.delete(id); ridden.delete(id); riding.delete(id); continue; }
    let rider;
    try { rider = e.getComponent("minecraft:rideable")?.getRiders()?.[0]; } catch {}
    let rc = RIDE_T.get(id);   /* 第99版: 種族と 乗り方は 1回だけ しらべて 覚える（前は 2tickごとに 4回 読んで いた） */
    if (!rc) { let s0 = ORDER[e.getProperty("mrpg:sp")]; try { const x = e.getDynamicProperty("mrpg:sid"); if (typeof x === "string" && SPECIES[x]) s0 = x; } catch {}   /* 第69版: 神は もとの 主の 姿でも 自分の 種族で */
      let t0 = SPECIES[s0]?.ride; try { if (e.getProperty("mrpg:cust")) t0 = e.getProperty("mrpg:cw") > 0 ? "fly" : "walk"; } catch {}
      rc = { sp0: s0, type: t0 }; RIDE_T.set(id, rc); }
    const sp0 = rc.sp0; let type = rc.type;
    if (type === "swim") type = "float";   // v2.9.6: 海の ライドは 水の 上を すいすい（潜らない）
    if (!rider) {
      const lr0 = lastRider.get(e.id);
      if (rmodeNow.get(e.id)) { rmodeNow.set(e.id, 0); try { e.setProperty("mrpg:rmode", 0); } catch {} }
      // v1.6: 空中で 降りたら 落下ダメージを うけないよう ゆっくり 落ちる
      const lr = lastRider.get(e.id);
      if (lr) { lastRider.delete(e.id); RIDE_T.delete(id); let air = false; try { air = !e.isOnGround && !e.isInWater; } catch {} if (air || flying.has(e.id)) try { lr.addEffect("slow_falling", 120, { showParticles: false }); } catch {} }
      if (sprintOn.has(e.id)) { sprintOn.delete(e.id); setSpeed(e, sp0, 1); }
      if (flying.has(e.id)) { flying.delete(e.id); e.triggerEvent("mrpg:fly_off"); }
      if (ridden.has(e.id)) { ridden.delete(e.id); e.triggerEvent("mrpg:ride_off"); }
      jumpCd.delete(e.id); stuck.delete(e.id); hops.delete(e.id);
      continue;
    }
    const v = e.getVelocity();
    const rot = rider.getRotation();
    const pitch = rot.x;
    // 向きは いつも 乗っている人に あわせる。自動前進モードのときだけ スクリプトで すすめる
    if (!ridden.has(e.id)) { ridden.add(e.id); e.triggerEvent("mrpg:ride_on"); try { if (hooks.onRide && rider.typeId === "minecraft:player") hooks.onRide(rider, sp0); } catch {} }
    lastRider.set(e.id, rider);
    { const rm = type === "float" && SPECIES[sp0]?.fam === "aqua" ? 3 : RMODE[type] || 1; if (rmodeNow.get(e.id) !== rm) { rmodeNow.set(e.id, rm); try { e.setProperty("mrpg:rmode", rm); } catch {} } }
    // v1.6: ダッシュ（走る キー）で 1.35倍、飛行中は 1.2倍
    let dash = false; try { dash = !!rider.isSprinting; } catch {}
    const want = (dash ? 1.35 : 1) * (type === "fly" && flying.has(e.id) ? 1.2 : 1);
    if ((sprintOn.get(e.id) || 1) !== want) { sprintOn.set(e.id, want); setSpeed(e, sp0, want * ((SPECIES[sp0]?.traits || []).includes("ride_fast") ? 1.3 : 1)); }
    try { e.setRotation({ x: 0, y: rot.y }); } catch {}
    let mx = 0, mz = 0;
    const auto = rider.hasTag("mrpg_autoride");
    if (auto && !(type !== "fly" && pitch > 60)) mz = 1;
    // WASD／スティックの にゅうりょく（使える バージョンなら）。エンジンが うごかさない ときの ほけん
    let vec = null;
    try { vec = rider.inputInfo?.getMovementVector?.(); } catch {}
    if (!auto && vec && Math.hypot(vec.x, vec.y) > 0.1) {
      const want = (SPECIES[sp0]?.rspeed || 0.25) * 1.5;
      if (Math.hypot(v.x, v.z) < want * 0.45) { mz = vec.y; mx = -vec.x; }
    }
    if (mx || mz) {
      const yaw = (rot.y * Math.PI) / 180;
      const fx = -Math.sin(yaw), fz = Math.cos(yaw);
      const sp = (SPECIES[sp0]?.rspeed || 0.25) * 1.5 * ((SPECIES[sp0]?.traits || []).includes("ride_fast") ? 1.3 : 1) * (sprintOn.get(e.id) || 1);
      const tx = (fx * mz - fz * mx) * sp, tz = (fz * mz + fx * mx) * sp;
      try { e.applyImpulse({ x: tx - v.x, y: 0, z: tz - v.z }); } catch {}
    }
    if (type !== "fly") {
      // v1.1: ジャンプ・段差の 自動のりこえ・水では 浮いて 泳ぐ
      const cd = jumpCd.get(e.id) || 0;
      if (cd > 0) jumpCd.set(e.id, cd - 1);
      let onG = false, inW = false;
      try { onG = !!e.isOnGround; inW = !!e.isInWater; } catch {}
      const wants = auto || (vec && Math.hypot(vec.x, vec.y) > 0.1);
      const big = (SPECIES[sp0]?.sz === "L" || SPECIES[sp0]?.sz === "G");
      let vy = null;
      if (inW && type === "float") { if (v.y < -0.04) vy = 0.03; }
      else if (inW && (type === "walk" || type === "climb" || type === "burrow")) vy = rider.isJumping ? 0.22 : Math.max(v.y, 0.06);
      else if (onG && cd <= 0 && rider.isJumping) { vy = big ? 0.62 : 0.52; jumpCd.set(e.id, 6); }
      const st = wants && Math.hypot(v.x, v.z) < 0.03 ? (stuck.get(e.id) || 0) + 1 : 0;
      stuck.set(e.id, st);
      // 壁に むかって 進みつづけても ぴょんぴょん しないよう、2回 跳んで 進めなければ やめる
      if (Math.hypot(v.x, v.z) > 0.08) hops.set(e.id, 0);
      // v2.9.3: よじ登り（壁に 向かって 進むと 登る）・掘り進み（ぶつかったら 掘る／下を 見ると 下へ）
      const yaw2 = (rot.y * Math.PI) / 180, fx2 = -Math.sin(yaw2), fz2 = Math.cos(yaw2), sz2 = SPECIES[sp0]?.sz || "M";
      if (vy === null && type === "climb" && wants && solidAhead(e, fx2, fz2, RAD[sz2] || 0.5, 0.6)) { vy = 0.3; hops.set(e.id, 0); stuck.set(e.id, 0); if (system.currentTick % 8 < 2) particle(e, "minecraft:basic_crit_particle", 0.3); }
      if (vy === null && type === "burrow" && wants) {
        const dc = digCd.get(e.id) || 0; if (dc > 0) digCd.set(e.id, dc - 1);
        else if (pitch > 55 && onG) { if (digAhead(e, rider, fx2, fz2, sz2, true)) digCd.set(e.id, 3); }
        else if (st >= 2 || solidAhead(e, fx2, fz2, RAD[sz2] || 0.5, 0.6)) { if (digAhead(e, rider, fx2, fz2, sz2, false)) { digCd.set(e.id, 2); stuck.set(e.id, 0); hops.set(e.id, 0); } }
      }
      if (vy === null && onG && cd <= 0 && st >= 3 && (hops.get(e.id) || 0) < 2 && type !== "climb") { vy = big ? 0.55 : 0.45; jumpCd.set(e.id, 8); stuck.set(e.id, 0); hops.set(e.id, (hops.get(e.id) || 0) + 1); }
      if (vy !== null) try { e.applyImpulse({ x: 0, y: vy - v.y, z: 0 }); } catch {}
    }
    if (type === "fly") {
      if (!flying.has(e.id)) { flying.add(e.id); e.triggerEvent("mrpg:fly_on"); }
      let want = 0;
      if (rider.isJumping || pitch < -35) want = 0.32;
      else if (pitch > 40) want = -0.32;
      try { e.applyImpulse({ x: 0, y: want - v.y, z: 0 }); } catch {}
    }
  }
}, 2);

export function rideInfo(sid, m) {
  const s = SPECIES[sid];
  const kind = { walk: "あるく", float: "ふゆう（水の上も すすめる）", fly: "ひこう（ジャンプ/上を見ると上昇・下を見ると下降）", swim: "うみ（水の 上を すいすい 進む）",
    climb: "よじ登り（壁に 向かって 進むと 登る）", burrow: "掘り進み（ぶつかると 土や 石を 掘る・下を見ると 下へ 掘る。町の 近くでは 掘らない）" }[rideOf(sid, m) || s.ride];
  return `${kind}  §7スピード ${Math.round(s.rspeed * 100) / 10}`;
}
export const traitList = (sid) => (SPECIES[sid].traits || []).map((t) => `§d${TRAITS[t].name}§7: ${TRAITS[t].desc}`);

// v3.0 第63版: 方角（北・北東 …）
function dirOf(a, b) { const ang = (Math.atan2(b.x - a.x, -(b.z - a.z)) * 180) / Math.PI; return ["北", "北東", "東", "南東", "南", "南西", "西", "北西"][((Math.round(ang / 45) % 8) + 8) % 8]; }
// v3.0 第63版: レア・ハガネ族は 5分 たって、だれも 近く（128）に いなければ 片づける（自然に 消えない かわり）
system.runInterval(() => {
  const ps = world.getAllPlayers(); const now = Date.now();
  for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
    let list = []; try { list = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_keep"], excludeTags: ["mrpg_battle", "mrpg_pet", "mrpg_boss"] }); } catch {}
    list.sort((a, b) => ((b.getDynamicProperty("mrpg:rt") || 0) - (a.getDynamicProperty("mrpg:rt") || 0)));
    list.forEach((e, k) => { try { try { e.triggerEvent("mrpg:keep"); } catch {}
      const t = e.getDynamicProperty("mrpg:rt"); const age = typeof t === "number" ? now - t : 1e9;
      const near = ps.some((p) => p.dimension.id === id && Math.hypot(p.location.x - e.location.x, p.location.z - e.location.z) < 96);
      if (k >= 12 || age > 1800000 || (age > 300000 && !near)) e.remove(); } catch {} });   // 5分 たって 近くに だれも いない・30分・12体を こえた 古い 子は 片づけ
  }
}, 600);
