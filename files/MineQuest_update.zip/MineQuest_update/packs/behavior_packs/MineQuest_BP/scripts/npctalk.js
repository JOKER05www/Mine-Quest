// 第127版: 名前の ある 町の 人との 会話（前の「何でも 打てる 会話」と 決まり文句の 返事は やめた）
// 話題を えらぶ: 最近の 話（物語の 進みで かわる・ネタバレ なし）／世間話／育成・編成の 相談（ゲームの データから）／ほかの 人の こと／問いかけ（答えで 気持ちが かわる）
// 贈り物は 今までどおり。仲よく なる 手順は 一人一人 ちがう（npcbase.js の b）。記録は プレイヤーごと（mrpg:np）
// 主人公は 16歳（バイブル 01）なので、名前の ある 人との「お出かけ」は 恋愛に しない（大人どうしの 恋愛は 物語の 中だけ）
// 軽く: 毎tickの 見回りは ない。話しかけた ときだけ 読む
import { world, system } from "@minecraft/server";
import { busy, choose, ICON, ok, sound, takeItem, countItem, barNote } from "./ui.js";
import { load, save } from "./store.js";
import { qs } from "./quest.js";
import { SPECIES, RANKS, ITEMS } from "./data.js";
import { NPC_HOOKS } from "./npchook.js";
import { CAST, castLines } from "./cast.js";
import { WQ, wqState, wqStep, wqDone, bkPast } from "./wq.js";
import { __social } from "./social.js";
import { GIFTS } from "./toys.js";
import { gameDay, slotNow, rainNow } from "./citylife.js";
import { team as sagaTeam } from "./saga.js";
import { fight } from "./story.js";
import { regionLv } from "./worldmap.js";
import { boon } from "./boon.js";
import { RMX } from "./rmaster.js";
import { NP, BYID, BYRM, stepsOf } from "./npcbase.js";
import { tipOf, FN } from "./npctips.js";
import "./npcd_a.js";
import "./npcd_b.js";
import "./npcd_c.js";
import "./npcd_d.js";
import "./npcd_e.js";
import "./npcd_f.js";

const pick = (L) => L[Math.floor(Math.random() * L.length)];
const KEY = "mrpg:np";
const day = () => { try { return gameDay(); } catch { return Math.floor(Date.now() / 86400000); } };
/* ---------- 記録（プレイヤーごと・人ごと）{ o 気持ち, s 手順, c 数, cd 数えた日, g 贈った日, a 問いの日, t 話した日, dt 過ごした日, h 相談を 聞いた 数, w ほうび済み } ---------- */
const MEMO = new Map();
export function npAll(p) { const m = MEMO.get(p.id); if (m) return m; let v = {}; try { v = JSON.parse(p.getDynamicProperty(KEY) || "{}"); } catch {} if (!v || typeof v !== "object" || Array.isArray(v)) v = {}; MEMO.set(p.id, v); return v; }
export function npOf(p, key) { const A = npAll(p); return A[key] || (A[key] = { o: 0, s: 0, c: 0 }); }
export function npSave(p) { try { p.setDynamicProperty(KEY, JSON.stringify(npAll(p))); } catch {} }
export const opAdd = (R, n) => { R.o = Math.max(-20, Math.min(100, (R.o || 0) + n)); return R.o; };
export const stars = (o) => (o >= 30 ? "§d★★★" : o >= 12 ? "§d★★§7★" : o >= 4 ? "§d★§7★★" : "§7★★★");
/* ---------- 門 ---------- */
export function gateOk(s, g) { if (!g) return true; if (!s) return false; if (g === "end") return !!s.ending; try { return bkPast(s, g); } catch { return false; } }
/* ---------- 話題 ---------- */
export function newsOf(P, s, castL) {
  const out = [];
  for (const l of [].concat(castL || [])) if (l && !out.includes(l)) out.push(String(l).replace(/^\{[^}]*\}/, ""));
  const G = (P.n || []).slice(1).filter(([g]) => gateOk(s, g));
  if (G.length) out.push(G[G.length - 1][1]); else if (P.n && P.n[0] && !out.length) out.push(P.n[0]);
  return out.slice(-2);
}
export const chatOf = (P, i) => (P.c || [])[i % Math.max(1, (P.c || []).length)] || "……";
export function gossipOf(P, s) { return (P.o || []).filter(([k, , g]) => NP[k] && gateOk(s, g)).map(([k, l]) => [NP[k].nm, l]); }
export function tipFor(P, d, i, r) { const k = (P.t || ["slot"])[i % 2] || "slot"; const T = tipOf(k, d, r); return { k, t: `${(P.t && P.t[2]) || ""}${T.t}`, f: T.f }; }
/* その 時点で 見える 文（点検用）*/
export function npView(key, s, d) {
  const P = NP[key]; if (!P) return [];
  const L = [P.hi, ...(P.p ? [P.p[0], P.p[3], P.p[4]] : []), ...newsOf(P, s, []), ...(P.c || []), ...gossipOf(P, s).map(([n, l]) => `${n} ${l}`), ...(P.a ? [P.a[0], ...P.a.slice(1).flatMap((x) => [x[0], x[2]])] : []), ...(P.r || []), P.t && P.t[2]];
  if (P.b) { L.push(...(P.b[2] || []), P.b[3], ...(P.b[4] || [])); if (gateOk(s, P.b[6])) L.push(P.b[5]); }
  return L.filter(Boolean).map(String);
}
/* ---------- 仲よく なる 手順 ---------- */
const famIn = (d, f) => ((d && d.party) || []).some((m) => m && SPECIES[m.sp] && SPECIES[m.sp].fam === f);
const rankIn = (d, r) => ((d && d.party) || []).some((m) => m && SPECIES[m.sp] && RANKS.indexOf(SPECIES[m.sp].rank) >= RANKS.indexOf(r));
const lvTop = (d) => Math.max(0, ...((d && d.party) || []).map((m) => (m && m.lv) || 0));
const SLOTK = { night: "night", morn: "morning", eve: "evening" };
const VISIT = new Set(["night", "morn", "eve", "rain", "days"]);
const VN = { wheat: "小麦", water_bucket: "水の バケツ", glowstone_dust: "光る 粉", brown_mushroom: "茶色い きのこ", sweet_berries: "あまい 木の実", oak_log: "オークの 原木", stripped_spruce_log: "皮を むいた トウヒの 原木", iron_ingot: "鉄の インゴット", birch_log: "シラカバの 原木", honey_bottle: "はちみつ", leather: "革", amethyst_shard: "紫水晶の かけら", glass: "ガラス", cod: "鱈", white_wool: "白い 羊毛", snowball: "雪玉", ink_sac: "イカスミ", black_wool: "黒い 羊毛", paper: "紙", bell: "鐘", string: "糸", emerald: "エメラルド", coal: "石炭" };
export const itemName = (id) => { const G = GIFTS[id]; if (G && G.name) return G.name; const k = String(id).replace(/^\w+:/, ""); return (id.startsWith("mrpg:") && ITEMS[k] && ITEMS[k].name) || VN[k] || k; };
export function stepTxt(st, R) {
  const n = st.n || 1, c = R.c || 0;
  switch (st.k) {
    case "it": return `${itemName(st.v)}を ${n}こ わたす`;
    case "night": return `夜に 話しに 行く（${c}/${n}日）`;
    case "morn": return `朝に 話しに 行く（${c}/${n}日）`;
    case "eve": return `夕方に 話しに 行く（${c}/${n}日）`;
    case "rain": return `雨の 日に 話しに 行く（${c}/${n}日）`;
    case "days": return `ちがう 日に 話しに 行く（${c}/${n}日）`;
    case "duel": return "モンスター勝負で 勝つ";
    case "wq": return `頼まれごと「${(WQ[st.v] && WQ[st.v].t) || "依頼"}」を 済ませる`;
    case "fam": return `${FN[st.v] || st.v}の 子を 仲間に 入れて 会いに 行く`;
    case "rank": return `${st.v}ランク 以上の 子を 仲間に 入れて 会いに 行く`;
    case "ask": return "問いかけに、本当の ことを 答える";
    case "gift": return `${{ flower: "花", sweet: "あまい もの", food: "食べ物", gem: "宝石", book: "本", craft: "手作りの 品", toy: "おもちゃ" }[st.v] || "贈り物"}を ちがう 日に 贈る（${c}/${n}日）`;
    case "bk": return "旅を 先へ 進める";
    case "lv": return `仲間を Lv${st.n} まで 育てる`;
    case "tip": return `相談を ${st.n}回 聞く（${Math.min(R.h || 0, st.n)}/${st.n}）`;
    case "op": return `もっと 仲よく なる（${stars(st.n)}§r まで）`;
    default: return "……";
  }
}
/* 話しかけた とき: 数える もの・満たした ものを 進める（訪ねる 手順は 1日 1回）*/
export function bondTick(p, P, R, d, s) {
  const S = stepsOf(P); let moved = 0;
  for (let k = 0; k < 6 && (R.s || 0) < S.length; k++) {
    const st = S[R.s || 0], dd = day();
    if (VISIT.has(st.k)) {
      const okT = st.k === "days" || (st.k === "rain" ? (() => { try { return rainNow(); } catch { return false; } })() : (() => { try { return slotNow() === SLOTK[st.k]; } catch { return false; } })());
      if (!okT || R.cd === dd) break;
      R.c = (R.c || 0) + 1; R.cd = dd; if (R.c < st.n) break;
    } else {
      let done = false;
      if (st.k === "wq") done = wqDone(s, st.v);
      else if (st.k === "fam") done = famIn(d, st.v);
      else if (st.k === "rank") done = rankIn(d, st.v);
      else if (st.k === "bk") done = gateOk(s, st.v);
      else if (st.k === "lv") done = lvTop(d) >= st.n;
      else if (st.k === "op") done = (R.o || 0) >= st.n;
      else if (st.k === "tip") done = (R.h || 0) >= st.n;
      if (!done) break;
    }
    R.s = (R.s || 0) + 1; R.c = 0; moved++;
  }
  return moved;
}
export const bonded = (P, R) => !!P.b && (R.s || 0) >= stepsOf(P).length;
const stepNow = (P, R) => stepsOf(P)[R.s || 0] || null;
function advance(R) { R.s = (R.s || 0) + 1; R.c = 0; }
/* ---------- 見た目 ---------- */
const act = (e, a) => { try { if (e && ok(e)) e.setProperty("mrpg:act", a); } catch {} };
const face = (e, p) => { try { if (e && ok(e)) e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} };
const heart = (e) => { try { if (e && ok(e)) e.dimension.spawnParticle("minecraft:heart_particle", { x: e.location.x, y: e.location.y + 2.1, z: e.location.z }); } catch {} };
const spk = (P, col, t) => `${col || "§e"}${P.nm}§f「${t}」`;
const handItem = (p) => { try { return p.getComponent("minecraft:inventory")?.container?.getItem(p.selectedSlotIndex ?? 0) || null; } catch { return null; } };
/* 依頼主の 依頼（済んだ・とちゅう）の 文 */
function wqLines(id, s, d) {
  const L = Object.values(WQ).filter((q) => q.npc === id); if (!L.length) return null;
  const on = L.find((q) => wqState(s, d, q) === "on"); if (on) { const st = on.steps[wqStep(s, on.id)]; return [...[].concat(on.wait || []), st && st.hint ? `§7${st.hint}` : ""].filter(Boolean); }
  const last = [...L].reverse().find((q) => wqDone(s, q.id)); if (last) return [].concat(last.after || []);
  return null;
}
/* 依頼が 動く とき（新しく 頼む・この 人の 段）は wq.js に まかせる */
function wqLive(id, s, d) {
  for (const q of Object.values(WQ)) { const k = wqStep(s, q.id); if (k >= 0 && k < q.steps.length) { const a = q.steps[k].at; const w = !a || a === "npc" ? q.npc : typeof a === "string" && a.startsWith("npc:") ? a.slice(4) : null; if (w === id) return true; } }
  for (const q of Object.values(WQ)) if (q.npc === id && wqState(s, d, q) === "open") return true;
  return false;
}
/* ---------- 話す 画面 ---------- */
const TALKING = new Set();
export async function talkMenu(p, e, key, castId = null, col = "§e") {
  const P = NP[key]; if (!P || TALKING.has(p.id)) return;
  TALKING.add(p.id); busy.add(p.id);
  try {
    let d = load(p); if (!d) return; let s = qs(d);
    const R = npOf(p, key), dd = day(); face(e, p); act(e, 4); sound(p, "random.pop", 0.6);
    const firstToday = R.t !== dd; R.t = dd;
    const moved = bondTick(p, P, R, d, s); npSave(p);
    const log = [spk(P, col, P.hi || chatOf(P, 0))];
    if (moved && !bonded(P, R)) log.push(`§d（${P.nm}の 様子が 少し かわった。手順が 一つ 進んだ）`);
    if (moved && bonded(P, R)) await bondDone(p, e, P, R, col, log);
    let ci = Math.floor(Math.random() * 3), ti = Math.floor(Math.random() * 2), last = "", sent = 0, shown = 0;
    for (let turn = 0; turn < 14 && ok(p); turn++) {
      d = load(p); if (!d) return; s = qs(d);
      const it = handItem(p), gk = it ? __social.giftKind(it.typeId) : null, st = stepNow(P, R);
      const O = [];
      const wl = castId ? wqLines(castId, s, d) : null; if (wl && wl.length) O.push(["wq", "§6頼まれごとの こと", "i_book"]);
      O.push(["news", "最近の 話", "i_book"], ["chat", "世間話", "i_help"], ["tip", "育成・編成の 相談", "i_skill"], ["gos", "ほかの 人の こと", "i_party"]);
      if (P.a && R.a !== dd) O.push(["ask", `§b${P.a[0].length > 18 ? "問いかけに 答える" : P.a[0]}`, "i_help"]);
      if (gk) O.push(["gift", `§d贈り物を わたす（${itemName(it.typeId)}）`, "i_star"]);
      if (st && st.k === "it" && countItem(p, st.v) >= st.n) O.push(["give", `§d${itemName(st.v)}を わたす（${st.n}こ）`, "i_bag"]);
      if (st && st.k === "duel") O.push(["duel", "§cモンスター勝負を 受ける", "i_fight"]);
      if (bonded(P, R)) { O.push(["out", P.b[0] === "d" && P.age === 2 ? "§dお出かけに 誘う" : "§dいっしょに 過ごす", "i_star"]); if (P.b[5] && gateOk(s, P.b[6])) O.push(["sec", "§d打ち明け話", "i_book"]); }
      O.push(["bye", "§7またね", "i_back"]);
      const card = [turn === 0 ? `§7気質: §f${(P.p && P.p[0]) || "……"}` : ""].filter(Boolean);
      if ((R.o || 0) >= 4 && P.p && turn === 0) card.push(`§7好き: §f${P.p[3]}  §7苦手: §f${P.p[4]}`);
      if (P.b && !bonded(P, R) && turn === 0 && (P.b[2] || [])[R.s || 0]) card.push(spk(P, col, P.b[2][R.s || 0]));
      if (P.b) card.push(bonded(P, R) ? `§d仲よし${P.b[0] === "d" && P.age === 2 ? "（お出かけに 誘える）" : ""}` : `§d仲よく なる ${(R.s || 0) + 1}/${stepsOf(P).length}§7: ${st ? stepTxt(st, R) : ""}`);
      for (const l of log.slice(sent)) { try { p.sendMessage(l); } catch {} } sent = log.length;
      const c = await choose(p, `${(castId && CAST[castId] && CAST[castId].role) ? CAST[castId].role + " " : ""}${P.nm}  ${stars(R.o || 0)}`, `${log.slice(shown).join("\n")}\n${card.join("\n")}`, O.map(([, t, ic]) => [t, ICON(ic)]));
      const k = O[c] && O[c][0]; if (!k || k === "bye" || !ok(p)) break;
      d = load(p); s = qs(d); act(e, 4); shown = log.length;
      if (k === "news") { for (const l of newsOf(P, s, castId ? castLines(p, castId) : [])) log.push(spk(P, col, l)); }
      else if (k === "wq") { for (const l of wl) log.push(/^§7/.test(l) ? l : spk(P, col, l)); }
      else if (k === "chat") { let l = chatOf(P, ci++); if (l === last) l = chatOf(P, ci++); last = l; log.push(spk(P, col, l)); }
      else if (k === "tip") { const T = tipFor(P, d, ti++); log.push(spk(P, col, T.t)); R.h = Math.min(99, (R.h || 0) + 1); if (bondTick(p, P, R, d, s) && bonded(P, R)) await bondDone(p, e, P, R, col, log); npSave(p); }
      else if (k === "gos") { const G = gossipOf(P, s); if (!G.length) log.push(spk(P, col, "……人の ことは、本人に 聞くのが いちばん")); else { const [n, l] = pick(G); log.push(`§7（${n}の こと）`, spk(P, col, l)); } }
      else if (k === "ask") {
        const A = P.a.slice(1); const a = await choose(p, P.nm, `${spk(P, col, P.a[0])}`, A.map((x) => [x[0], ICON("i_help")]));
        if (a === undefined || a === null || a < 0 || !A[a]) continue;
        R.a = dd; const [, dv, re] = A[a]; opAdd(R, dv); log.push(`§7あなたは「${A[a][0]}」と 答えた`, spk(P, col, re)); act(e, dv > 0 ? 9 : dv < 0 ? 14 : 4); if (dv > 0) heart(e);
        if (st && st.k === "ask" && +st.v === a) { advance(R); log.push(`§d（${P.nm}は 少し だまって、うなずいた）`); if (bondTick(p, P, R, d, s) >= 0 && bonded(P, R)) await bondDone(p, e, P, R, col, log); }
        npSave(p);
      }
      else if (k === "gift") log.push(...giveTo(p, e, P, R, it, col));
      else if (k === "give") { if (st && takeItem(p, st.v, st.n)) { advance(R); opAdd(R, 5); heart(e); act(e, 9); log.push(`§7あなたは 約束の 品を わたした`, spk(P, col, (P.r || [])[0] || "……ありがとう")); bondTick(p, P, R, load(p), qs(load(p))); if (bonded(P, R)) await bondDone(p, e, P, R, col, log); npSave(p); } }
      else if (k === "duel") { busy.delete(p.id); const r = await duelWith(p, e, P); busy.add(p.id); if (r === "win") { advance(R); opAdd(R, 4); log.push(spk(P, col, "……負けた。でも、いい 勝負だった")); const d2 = load(p); bondTick(p, P, R, d2, qs(d2)); if (bonded(P, R)) await bondDone(p, e, P, R, col, log); } else log.push(spk(P, col, "まだまだ。また 来な")); npSave(p); }
      else if (k === "out") { if (R.dt === dd) log.push(spk(P, col, "今日は もう いっしょに 過ごしたよ。また 明日")); else { R.dt = dd; opAdd(R, 3); npSave(p); outing(p, e, P, col); break; } }
      else if (k === "sec") log.push(spk(P, col, P.b[5]));
    }
    if (firstToday) { opAdd(R, 1); npSave(p); }
  } catch (err) { console.warn(`[MonsterRPG] npctalk: ${err}`); }
  finally { TALKING.delete(p.id); busy.delete(p.id); act(e, 0); }
}
function giveTo(p, e, P, R, it, col) {
  const dd = day(); if (R.g === dd) return [spk(P, col, "今日は もう もらったよ。気持ちだけ、ありがたく")];
  const id = it.typeId, k = __social.giftKind(id); if (!k || !takeItem(p, id, 1)) return [];
  const [likeS, badS] = String(P.g || "|").split("|"), like = likeS.split(",").includes(k), bad = badS.split(",").includes(k), fav = P.f === id;
  R.g = dd; const n = fav ? 10 : like ? 6 : bad ? -3 : 2; opAdd(R, n);
  const st = stepNow(P, R); if (st && st.k === "gift" && st.v === k && R.cd !== dd) { R.c = (R.c || 0) + 1; R.cd = dd; if (R.c >= st.n) advance(R); }
  npSave(p); act(e, n > 0 ? 9 : 14); if (n > 0) heart(e); sound(p, n > 0 ? "random.orb" : "note.bass", 1);
  const gn = itemName(id);
  return [`§7あなたは ${gn}を わたした`, spk(P, col, fav ? `${(P.r || [])[0] || "……うれしい"}` : like ? (P.r || [])[0] || "ありがとう" : bad ? (P.r || [])[1] || "……ありがとう" : "ありがとう。大事に するよ"), `${stars(R.o)}`];
}
async function bondDone(p, e, P, R, col, log) {
  log.push(spk(P, col, P.b[3] || "……これからも、よろしく"));
  heart(e); act(e, 9); sound(p, "random.levelup", 1);
  if (!R.w) { R.w = 1; const d = load(p); if (d) { const g = boon(p, d, 1); save(p, d); log.push(`§d♪ ${P.nm}と 仲よしに なった！ §7おれい ${g}`); } }
  npSave(p);
}
async function duelWith(p, e, P) {
  const d = load(p); if (!d) return null;
  const fams = String((stepsOf(P).find((x) => x.k === "duel") || {}).v || "beast").split(".");
  let lv = 10; try { lv = Math.max(8, Math.min(100, regionLv(p.location) + 6)); } catch {}
  const foe = sagaTeam(fams, lv, 3, 20); if (!foe || !foe.length) return null;
  try { return await fight(p, { team: foe }, { tier: 1, fam: "", npc: null, theme: "arena", name: P.nm, arena: `${P.nm}との 勝負`, speaker: P.nm, scout: false }); } catch { return null; }
}
function outing(p, e, P, col) {
  const L = (P.b && P.b[4]) || [];
  L.forEach((t, i) => system.runTimeout(() => { try { if (!ok(p)) return; if (e && ok(e)) { face(e, p); act(e, [6, 2, 9][i % 3]); heart(e); } p.sendMessage(spk(P, col, t.replace(/\{p\}/g, p.name))); barNote(p).setActionBar(spk(P, col, t.replace(/\{p\}/g, p.name))); sound(p, "random.orb", 1.2, 0.5); } catch {} }, 20 + i * 70));
  system.runTimeout(() => { try { act(e, 0); } catch {} }, 20 + L.length * 70 + 40);
}
/* ---------- 受け口 ---------- */
/* ほかの 場面（クリア後の 紐の 場面 など）を 持つ 受け口は 先に 聞く（依頼 wq と ふだんの「その後」castTalk は こちらが 代わる）*/
let SPN = -1, SPL = [];
const specials = () => { if (SPN !== NPC_HOOKS.length) { SPN = NPC_HOOKS.length; SPL = NPC_HOOKS.filter((h) => h !== hook && /mrpg_cast/.test(String(h)) && !/wqTalk|castTalk/.test(String(h))); } return SPL; };
function hook(p, e) {
  try {
    if (!e.hasTag("mrpg_cast")) return false;
    for (const h of specials()) { try { if (h(p, e)) return true; } catch {} }
    let sn = false; try { sn = !!p.isSneaking; } catch {}
    const id = e.getDynamicProperty("mrpg:cast"); if (typeof id !== "string" || !CAST[id]) return false;
    const key = BYID[id]; if (!key || !NP[key]) return false;
    const d = load(p); if (!d) return false; const s = qs(d);
    if (!sn && wqLive(id, s, d)) return false;   /* 依頼を 頼む・依頼の 段は wq.js（しゃがむと いつもの 話）*/
    if (busy.has(p.id)) return true;
    system.run(() => { talkMenu(p, e, key, id, CAST[id].col || "§e").catch(() => {}); });
    return true;
  } catch { return false; }
}
system.run(() => NPC_HOOKS.unshift(hook));   /* ほかの 受け口より 先（モジュールが そろってから）*/
/* 地方マスター: 勝負の 前に「話す」*/
RMX.talk = async (p, k, R, omiai) => {
  const key = (Object.values(NP).find((x) => x.nm === (R && R.name) && x.rm !== undefined) || {}).key || BYRM[k]; if (!key || !NP[key] || (R && R.statue)) return "fight";
  const O = [["fight", "§c§l勝負する", "i_fight"], ...(omiai ? [["omiai", "§dお見合い配合", "i_party"]] : []), ["talk", "話す", "i_book"], ["no", "§7やめる", "i_back"]];
  const c = await choose(p, `${R.title} ${R.name}`, `§6${R.name}§f「${NP[key].hi || "……用か"}」`, O.map(([, t, ic]) => [t, ICON(ic)]));
  const v = O[c] && O[c][0]; if (!v || v === "no") return null;
  if (v === "talk") { busy.delete(p.id); await talkMenu(p, null, key, null, "§6"); busy.add(p.id); return null; }
  return v;
};
export const __npc = { NP, BYID, BYRM, npAll, npOf, bondTick, bonded, stepTxt, newsOf, gossipOf, tipFor, npView, gateOk, talkMenu, hook, wqLive, giveTo, MEMO };
