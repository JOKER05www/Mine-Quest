/* 第126版 本5「砂の王墓」（サンドリア砂漠・ミラージュ／サンドリア城／ソーラ）— 作業 MB
   1 市（r4e1 を 引きとる）→ 2 夜の街道（r4e2・六影の「そのころ」）→ MQ10: 3 城門→地下牢・4 脱獄・5 玉座の間（C05）
   → 6 城の中庭（r4e4 の 場面を 引きとって 書きなおし）→ 7 ソーラの老兵の家 → MQ11: 8 砂の王墓 → 9 市の夕ぐれ（r4e6）
   この ファイルの 上の 部品（oldRun・toSet・letter・H4）は 本6〜本8 も 使う */
import { bkAdd, mqOver, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facAt, facSide, facFront, facMark, fac } from "./epfac.js";
import { castleOut, gateSet, moveG } from "./pvplace.js";   /* 第126版(PV): 城の 中では 戦わない（城門の 外・城壁の 外）*/
import { EPS } from "./sagaep.js";
import { townOut, placeOf, bldOf, farOf } from "./storyplace.js";
import { chGet } from "./choice.js";
import { ok } from "./ui.js";

const { F, S1 } = FAC_OPS;
/* ---------- 部品（本5〜本8 共通）---------- */
export const H4 = (g, o, c, t) => ({ g: [].concat(g), o: [].concat(o), c: [].concat(c), t: [].concat(t) });   /* 幼なじみの 四つの 型 */
export const Y0 = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
export const chOf = (K, p, id) => { const d = K.load(p); return d ? chGet(K.qs(d), id) : ""; };
export const did = (s, id) => { try { return bkHas(s, id); } catch { return false; } };
/* 古い 話（第125版 ep_rX.js）の 場面を そのまま 流す（今日 直した 場所・会話・撮り直しを 生かす）。ほうびは 新しい 話の id で 1回。
   onPay: 古い 場面の ほうびの あと（終わりの 前）に 足す 拍。post: 終わりの 引きの 絵の 直前に 足す 拍 */
export async function oldRun(p, d, K, me, r, oid, o = {}) {
  const oe = (EPS[r] || []).find((e) => e.id === oid);
  if (!oe) return o.fb ? o.fb(p, d, K) : true;
  let later = null;
  const Kx = Object.assign(Object.create(K), {
    pay(pp, e, g, it) { const got = K.pay(pp, me, g, it); if (o.onPay && !later) later = o.onPay; return got; },
    async up(pp, e, t = 14) { if (o.ots || camBlocked(pp, e, 1.45, 1.55)) { const h = K.hero(pp, false); if (h && h !== e) return K.ots(pp, h, e, t); } return K.up(pp, e, t); },   /* 寄りの カメラが 屋根や 壁に 入る ときは 肩ごし */
    async at(pp, q, t = 16, k = 4, dy = 1.2) { if (q && camBlocked(pp, q.location || q, k, dy)) { const h = K.hero(pp, false); if (h) return K.ots(pp, h, q.location || q, t); return K.wait(t); } return K.at(pp, q, t, k, dy); },
    narr(pp, lines, focus = null) { if (focus && !focus.location && Number.isFinite(focus.x) && camBlocked(pp, focus, 4, 1.2)) focus = null; return K.narr(pp, lines, focus); },
    csay(pp, id, lines, lis) { return K.csay(pp, id, o.swap ? o.swap(pp, id, [].concat(lines)) : lines, lis); },   /* 選択で かわる 台詞だけ 差しかえる */
    async end(pp, opt = {}) { if (later) { const f = later; later = () => {}; await f(pp, Kx); } if (o.post) await o.post(pp, Kx); return K.end(pp, opt); },
  });
  if (o.pre) await o.pre(p, Kx);
  return (await oe.run(p, d, Kx)) === true;
}
/* camNear と 同じ 位置の カメラが ブロックの 中か */
export function camBlocked(p, e, k, dy) { try { if (!e || (e.location && !ok(e))) return false; const l = e.location || e, P = p.location, dx = P.x - l.x, dz = P.z - l.z, L = Math.hypot(dx, dz) || 1, q = { x: Math.floor(l.x + (dx / L) * k), y: Math.floor(l.y + dy + 0.4), z: Math.floor(l.z + (dz / L) * k) }; const b = p.dimension.getBlock(q); return !!b && !b.isAir && !b.isLiquid && !/glass|pane|bars|grass|flower|torch|lantern|button/.test(b.typeId); } catch { return false; } }
/* セットへ 移る（ワールドに 1回 建てる。舞台の 横 → 反対 → もっと 遠く）。返す 値は 見る 点（建たない ときは null。今の 場所の まま 引きの 絵）*/
export async function toSet(K, p, key, kind, r, nm, drop = [], sides = [34, -34, 52, -52]) {
  let L = facAt(key, p.location, 120);
  if (!L) { const S = K.S(p); if (S) for (const sd of sides) { L = facSide(p, S, sd, key, kind, r, Y0(K, p)); if (L) break; } }
  if (!L) { L = fac(K, p, key, kind, r, Y0(K, p)); await K.open(p, nm, "day"); if (L) await K.at(p, L, 14, 6, 1.4); return L; }
  const fr = facFront(key, 5); await K.moveTo(p, fr || L, nm, drop, L, 10); return L;
}
export const mk = (key, n, p) => facMark(key, n, p.location);
/* 手紙（道が 開いた とき）: 行ごとに カメラを 動かす */
export async function letter(K, p, who, lines, sub = null) {
  if (sub) K.big(p, "§a§l道が 開けた！", sub, "ui.toast.challenge_complete");
  const S = K.S(p); const L = [].concat(lines);
  for (let i = 0; i < L.length; i++) { if (S) { K.camPt(p, S.at(2 + i, (1.5 - i) * S.side, 1.2), 4 + i, 1.4); await K.wait(4); } await K.say(p, who, [L[i]]); }
}
const T = (s) => (s && typeof s === "object" ? s : {});

/* ---------- 施設（本5）---------- */
/* 地下牢: 石の 部屋・鉄格子・わら・小さな 窓。手前は あいて いる（カメラは 通路から）*/
facAdd("b5jail", { D: [16, 19], box: [-1, -4, 8, 4], H: 5, look: [5, 0, 1.2], marks: { cell: [6.5, 1, 0], bed: [5.3, -1.6, 0], aisle: [2, 0, 0], bars: [4, 0, 1], door: [4, 3, 0], out: [0, -2, 0] }, build: (P) => [
  F(-1, -4, -1, 8, 4, -1, "cobblestone"), F(8, -4, 0, 8, 4, 4, "stone_bricks"), F(-1, -4, 0, 8, -4, 4, "stone_bricks"), F(-1, 4, 0, 8, 4, 4, "stone_bricks"), F(-1, -4, 5, 8, 4, 5, "stone_bricks"),
  F(4, -3, 0, 4, 3, 3, "iron_bars"), S1(4, 3, 0, "air"), S1(4, 3, 1, "air"), F(6, -3, 0, 7, -2, 0, "hay_block"), S1(8, 0, 3, "iron_bars"), S1(7, 3, 3, "soul_lantern"), S1(1, -3, 3, "lantern"), S1(0, 3, 0, "barrel"), S1(7, 3, 0, "cauldron"),
] });
/* 詰所の 奥: 小さな 寝床が 三つ（偽の 衛兵の 弟妹）*/
facAdd("b5post", { D: [12, 14], box: [-1, -3, 5, 3], H: 4, look: [3, 0, 0.5], marks: { beds: [4, 0, 0] }, build: (P) => [
  F(5, -3, 0, 5, 3, 3, P.wall), F(-1, -3, 0, 5, -3, 3, P.wall), F(-1, 3, 0, 5, 3, 3, P.wall), F(-1, -3, 4, 5, 3, 4, P.slab),
  S1(4, -2, 0, "red_bed"), S1(4, 0, 0, "yellow_bed"), S1(4, 2, 0, "light_blue_bed"), S1(1, -2, 0, "barrel"), S1(1, 2, 0, "decorated_pot"), S1(3, 3, 2, "lantern"),
] });
/* 玉座の 間（城が まだ ない 世界）: 段・玉座・柱・絨毯 */
facAdd("b5throne", { D: [12, 14], box: [-1, -4, 7, 4], H: 6, look: [5, 0, 1.6], marks: { seat: [6, 0, 1], foot: [3, 0, 0], table: [3, 3, 0] }, build: (P) => [
  F(-1, -4, -1, 7, 4, -1, "smooth_sandstone"), F(0, 0, -1, 7, 0, -1, "red_wool"), F(5, -2, 0, 7, 2, 0, "cut_sandstone"), S1(6, 0, 1, "gold_block"), S1(7, 0, 2, "chiseled_sandstone"),
  F(1, -4, 0, 1, -4, 4, "chiseled_sandstone"), F(1, 4, 0, 1, 4, 4, "chiseled_sandstone"), F(5, -4, 0, 5, -4, 4, "chiseled_sandstone"), F(5, 4, 0, 5, 4, 4, "chiseled_sandstone"), S1(1, -4, 5, "lantern"), S1(5, 4, 5, "lantern"), S1(3, 4, 0, "birch_planks"),
] });
/* 王墓の 壁: 字の 刻まれた 壁（爪の 四本の 線、一本 短い）と 脇の 碑 */
facAdd("b5wall", { D: [12, 14], box: [-1, -5, 6, 5], H: 6, look: [5, 0, 1.6], marks: { wall: [5, 0, 1.5], claw: [5, 1, 1.2], stele: [3, -4, 1], foot: [3, 0, 0] }, build: (P) => [
  F(6, -5, 0, 6, 5, 5, "sandstone"), F(5, -2, 1, 5, 2, 3, "chiseled_sandstone"), F(5, 1, 1, 5, 1, 3, "cut_sandstone"), F(5, 0, 1, 5, 0, 3, "cut_sandstone"), F(5, -1, 1, 5, -1, 3, "cut_sandstone"), S1(5, -2, 2, "cut_sandstone"),
  F(3, -4, 0, 3, -4, 2, "chiseled_sandstone"), S1(3, -4, 3, "torch"), F(0, -5, -1, 6, 5, -1, "sandstone"), S1(1, 4, 0, "decorated_pot"), S1(2, 5, 0, "decorated_pot"), S1(5, 4, 4, "lantern"), S1(5, -4, 4, "lantern"),
] });
/* 老兵の 家（ソーラ）: 小さな 家・戸口・古い 槍の 掛け台 */
facAdd("b5vet", { D: [11, 13], box: [-1, -3, 5, 3], H: 4, look: [2, 0, 1.2], marks: { door: [0, 0, 0], spear: [4, 2, 1] }, build: (P) => [
  F(0, -3, 0, 5, 3, 3, "smooth_sandstone"), F(1, -2, 0, 4, 2, 2, "air"), F(0, 0, 0, 0, 0, 1, "air"), F(0, -3, 4, 5, 3, 4, "birch_slab"), S1(4, 2, 0, "armor_stand"), S1(4, -2, 0, "barrel"), S1(3, 0, 2, "lantern"), S1(1, -2, 0, "birch_stairs"),
] });

/* ---------- 場所 ---------- */
const MEMO = new Map();
export const memo = (k, f) => () => { if (MEMO.has(k)) return MEMO.get(k); const v = f(); if (v) MEMO.set(k, v); return v; };
export const tOut = (tid, k, turn, nm) => memo(k, () => { const o = townOut(tid, turn, nm); return o ? { x: o.x, z: o.z, nm: o.nm } : null; });
const MARKET = () => bldOf("t6", ["plaza", "inn"], "オアシスの 村 ミラージュの 市") || tOut("t6", "mk", 0.4, "外れの オアシスの 市")();
const SHOP = () => bldOf("t6", ["shop", "eggs"], "ミラージュの 砂星商会") || tOut("t6", "mk", 0.4, "外れの オアシスの 市")();
const ROAD = () => { const f = farOf("r4road", "t6", "サンドリアの 夜の 街道", 90, 300); if (f) return f; const q = placeOf("road", 4); return q ? { x: q.x, z: q.z, nm: "サンドリアの 夜の 街道" } : tOut("t6", "rd", -1.2, "外れの 砂丘")(); };   /* 第127版(fac2): 町から 離れた 街道の 関所 */
export const PL = (kind, r, nm) => () => { const q = placeOf(kind, r); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm || nm } : null; };
const SORA = tOut("t21", "vet", 0.6, "ソーラの 外れの 老兵の 家");
export const near = (f, dx, dz) => () => { const q = f(); return q ? { x: q.x + dx, y: q.y, z: q.z + dz } : null; };
export const RJ = 17, TJ = 18;   /* レイ・セオ の 見た目 */
export const REI = (K, p, w = false) => K.npcNear(p, "§bライバル レイ", RJ, w);
export const SEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", TJ, w);
const THIEF = (K, p, w = false) => K.npcNear(p, "§c偽の 衛兵 スナモグラ", K.PJ("thief", 9), w);

/* ---------- 町の 人の その後 ---------- */
castAdd("r4celine", { nm: "セリーヌ", role: "商家の", gobi: "ですわ", skin: "zenia", town: "t6", from: "r4e1", at: near(SHOP, 3, -3),
  pre: ["{smile}ごきげんよう。砂星商会の セリーヌですわ。"],
  after: [
    [(s) => !!s.heroBack, ["{smile,☆}あら、お二人そろって！ ……ええ、知って いましたわ。あなた方なら、きっと 取りもどすと。", "{smile}今日は 店じゅうの 品を 半分の 値に しますわ。お祝いですもの。"]],
    [(s) => !!s.ending, ["{smile}市に 人が もどって きましたわ。父も 毎朝 店先を はいて いますの。", "{closed}……あの 手紙の 字、今でも 夢に 見ますわ。わたくし、証人として 何度でも 話しますわよ。"]],
    [(s) => !!s.heroDead, ["{sad}父の 手が、だんだん 冷たく なって いきますの。……それでも 店は 閉めませんわ。", "{angry}市の 灯りが 消えたら、この 村は おしまいですもの。"]],
    [(s) => did(s, "b05e9"), ["{smile,☆}砂星商会、ただいま 営業中ですわ！ 母の ブローチも、ほら、ここに。", "{smile}旅の お方。今度は、ちゃんと 定価で 売りますわよ。"]],
    [(s) => did(s, "b05e6"), ["{smile}王墓の 件が 片づいたら、店を 開けますわ。……約束、覚えて いて くださいまし。"]],
    [() => true, ["{angry}腰帯の 布切れは、わたくしが 守って いますわ。泥棒の 好きには させませんわ。"]],
  ] });
castAdd("r4isak", { nm: "イザク", role: "老人", col: "§7", gobi: "でやんす", skin: "isak", town: "t6", from: "r4e4", until: "r7e1", at: near(SHOP, -4, 3),
  pre: ["{closed}……砂の 風は、今日も 西からでやんす。"],
  after: [
    [(s) => !!s.heroDead, ["{sad}……牢の 鍵より、ずっと 重い ものを 背負って いる 顔でやんすね。"]],
    [(s) => did(s, "b05e9"), ["{smile}ニナの 石の 間に、毎月 花を 届けて いるでやんす。……骨の 鍵は、もう 削らないでやんす。"]],
    [() => true, ["{smile}七年ぶりの 空は、目に しみるでやんすね。"]],
  ] });
castAdd("r4garm", { nm: "ガルム", role: "衛兵長", col: "§6", gobi: "である", skin: "glen", town: "t6", from: "r4e4", at: () => { const q = placeOf("gate", 4); return q ? { x: q.x + 4, y: q.y ?? undefined, z: q.z + 2 } : null; },
  pre: ["{closed}城門は わしが 守るのである。"],
  after: [
    [(s) => !!s.ending, ["{smile}近ごろは 城門で、旅人に 道を 教えて おるのである。……わしも、少しは 変わったのである。"]],
    [(s) => !!s.heroDead, ["{angry}町の 壁に、おぬしらの 張り紙が 貼られたと 聞いた。……わしは、二度は 信じないのである。"]],
    [(s) => did(s, "b05e9"), ["{sweat,汗}セリーヌ嬢の 店で、ナツメヤシを 買ったのである。……値切ったら、にらまれたのである。"]],
    [() => true, ["{closed}……あの 夜の ことは、すまなかったのである。わしは 証拠より、よそ者と いう 言葉を 信じた。"]],
  ] });
castAdd("b5rashid", { nm: "ラシード", role: "砂王", col: "§6", gobi: "", skin: "rashid", town: "t6", hide: (s) => !did(s, "b05e5"), at: () => { const q = placeOf("court", 4, true); return q ? { x: q.x - 3, y: q.y ?? undefined, z: q.z } : null; },
  pre: ["{closed}……砂は 何も 覚えて おらぬ。"],
  after: [
    [(s) => !!s.ending, ["{closed}二十年前の あの 男に、わしは まだ 詫びて おらぬ。……会えたら、玉座から 下りて 頭を 下げる。"]],
    [() => true, ["{sad}法を 守って 人を 見なかった。……二度と せぬ。おまえたちが 証人だ。"]],
  ] });
castAdd("b5vet", { nm: "ハミド", role: "老兵", col: "§7", gobi: "じゃ", skin: "m6_gramps", town: "t21", hide: (s) => !did(s, "b05e7"), at: () => { const q = VETHOME(); return q ? { x: q.x + 1, y: q.y, z: q.z + 1 } : null; },
  pre: ["{closed}……槍は もう 握らん。"],
  after: [
    [(s) => !!s.ending, ["{smile}星の 冠の 男が 帰ったと 聞いたら、わしは 門まで 歩いて 迎えに 行く。……それが、わしの 詫びじゃ。"]],
    [() => true, ["{closed}王を 責めるな。……責めるなら、門で 槍を 向けた わしを 責めよ。"]],
  ] });

/* ---------- 1話 オアシスの市ミラージュ ---------- */
const E1 = { id: "b05e1", t: "オアシスの市ミラージュ", place: MARKET,
  hint: "§fオアシスの 村 §eミラージュの 市§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "ミラージュの 市は 盗みが 続き、衛兵は「よそ者の しわざ」と 決めつけて いた。セリーヌの 店は 閉まって いた。店の 主たちは 衛兵長ガルムに 頭を 下げに 来た。",
  async run(p, d, K) {
    return oldRun(p, d, K, E1, 4, "r4e1", { post: async (p, K) => {
      /* 敵の 正しさ（ガルム）: 盗まれた 店の 主たちが 頭を 下げに 来る */
      const eG = K.cast(p, "r4garm"); K.hold(eG, "spear");
      const a = K.npcNear(p, "§f果物売りの おかみ", K.PJ("hanna", 8), true), b = K.npcNear(p, "§f香辛料屋の 主", 8);
      await K.two(p, eG, b, 12);
      K.act(a, "bow"); K.act(b, "bow");
      await K.say(p, "香辛料屋の 主", ["{sad}衛兵長さま、どうか 市を お守り ください。……もう 店を たたむ 者も 出て おります。"]);
      await K.csay(p, "r4garm", ["{closed}……頭を 上げるのである。盗みは よそ者の しわざ。旅人を 見張れば、市は 守れるのである。"], a);
      K.act(a, 0); K.act(b, 0);
      await K.hsay(p, H4("{sad}……あの 人、本気で 市を 守ろうと してる。だから こわい。", "{sad}……まじめな 人ね。だから、まちがえると こわいわ。", "{closed}……まじめな 衛兵長。思いこみも、まじめ。", "{sad}……まじめな お方です。だからこそ、思いこみが 怖いです。"));
      K.act(eG, 0); await K.leave(eG, p, 10, false); await K.bye(p, a, b);
    } });
  } };

/* ---------- 2話 夜の街道（そのころ 六影の 卓）---------- */
const E2 = { id: "b05e2", pv: 127, t: "夜の街道", place: ROAD, fac: "r4road",
  hint: "§f夜の §eサンドリアの 街道§f で セリーヌと 泥棒を 見張ろう §7（右上の 案内）",
  syn: "夜の 街道で 見張りの お茶。泥棒は 偽の 衛兵スナモグラだった。セリーヌは 母の ブローチを 取りもどした。足あとを たどると、詰所の 奥に 小さな 寝床が 三つ。衛兵長ガルムは、主人公たちを 疑った。",
  skip: (s) => { s.epx = { ...T(s.epx), thief4: 1 }; },
  async run(p, d, K) {
    return oldRun(p, d, K, E2, 4, "r4e2", { onPay: async (p, K) => {
      /* 敵の 正しさ（スナモグラ）: 詰所の 奥の 小さな 寝床（このあと「そのころ」の 六影の 卓へ）*/
      const L = fac(K, p, "b5post", "b5post", 4, Y0(K, p)), bd = mk("b5post", "beds", p) || L;
      const eC = K.cast(p, "r4celine", true);
      if (bd) { K.sound(p, "random.door_open", 0.5); await K.push(p, bd, 22, 6, 2.4, 0.6); }
      await K.narr(p, ["§7砂の 足あとは、街道の 外れの 詰所へ 続いて いた。", "§7奥に、小さな 寝床が 三つ。どれも、子どもの 大きさだった。"], bd);
      await K.csay(p, "r4celine", ["{shock,…}……子どもの 寝床、ですわね。", "{sad}あの 泥棒、弟や 妹を 食べさせて いましたのね。……許しは しませんけれど。"]);
      await K.hsay(p, H4("{sad}……盗んで 食べさせてたんだ。", "{sad}……守る ものが、あったのね。", "{closed}……盗む 理由は、あった。", "{sad}……守る 方が、いらしたのですね。"));
      K.act(eC, 0);
    } });
  } };

/* ---------- 3話 城門→地下牢（MQ10）---------- */
const E3 = { id: "b05e3", t: "サンドリア城の城門→地下牢", battles: 1, F: ["F43"], keys: ["k_bonekey"],
  hint: "§fサンドリア城の §e城門§f を くぐろう §7（セオと 待ち合わせ）",
  syn: "城門で 密告に よって 捕まった。地下牢には レイも、七年 牢に いる 老人イザクも いた。イザクは 骨で 削った 鍵を 見せ、「七日 あれば 出られた。だから 七年 かけて 自分で 削った」と 言った。",
  async run(p, d, K) {
    { const GO = castleOut(4, "サンドリア城の 城門の 外"); const c = placeOf("court", 4); if (GO) { if (c) gateSet(p, "c4gate", GO, c, Y0(K, p)); await moveG(K, p, GO, "サンドリア城の 城門の 外", [], c ? { x: c.x, y: Y0(K, p) + 3, z: c.z } : null); } else await K.open(p, "サンドリア城の 城門", "day"); }
    const eH = K.hero(p);
    const eG = K.npcNear(p, "§6衛兵長 ガルム", K.PJ("glen", 16)), g1 = K.npcNear(p, "§6サンドリア城の 衛兵", K.PJ("glen", 16)); K.act(g1, "guard");
    K.big(p, "§c§l止まれ！", "§f城門の 前で、衛兵に 囲まれた", "mob.villager.no");
    K.act(eG, "point"); await K.low(p, eG, 10);
    await K.say(p, "ガルム", ["{angry,!,low}……やはり 来たのであるな、よそ者。密告が あった。『石板を 持った よそ者が、王墓を 荒らしに 来る』と。", "{closed}同じ 密告で、竜を 連れた 若者も さっき 捕らえたのである。"]);
    await K.hsay(p, H4("{rage,怒,jump}王墓なんて 見ても いないよ！ その 密告、だれが したの！？", "{angry}……ちがうわ。だれが そんな ことを？", "{angry}差出人は。証拠も なしに？", "{rage,怒}誤解です！ その 密告は どなたから！"));
    await K.say(p, "ガルム", ["{closed}名は 明かせん。言い訳は 牢で 聞くのである！"]);
    await K.battle(p, K.team(["golem", "sword"], 75, 3, 45), { name: "衛兵長 ガルム", arena: "濡れ衣", theme: "desert", speaker: "ガルム", hpk: 40, extra: 0.6, heal: false,
      scripted: { turns: 2, lines: ["§6§l城の 衛兵たちが 次々と なだれこんで きた！", "§7多勢に 無勢…… 取りおさえられて いく！"] }, lines: { half: "抵抗するか！ ますます 怪しい！" } });
    await K.bye(p, K.npcNear(p, "§6衛兵長 ガルム", K.PJ("glen", 16), true), K.npcNear(p, "§6サンドリア城の 衛兵", K.PJ("glen", 16), true));
    /* 地下牢へ */
    const J = await toSet(K, p, "b5jail", "b5jail", 4, "サンドリア城 地下牢", [K.hero(p, false)]);
    const at = (n) => (J ? mk("b5jail", n, p) : null);
    const eR = J ? await K.put(p, "§bライバル レイ", at("cell"), null, RJ) : REI(K, p); K.act(eR, "kneel");
    const eI = J ? await K.put(p, "§7老人 イザク", at("bed"), null, K.PJ("isak", 8)) : K.npcNear(p, "§7老人 イザク", K.PJ("isak", 8)); K.act(eI, "down");
    const eH2 = K.hero(p);
    if (J) await K.at(p, at("bars"), 18, 5, 1);
    await K.say(p, "レイ", ["{sweat,汗}……おまえらも か。城門で この ざまだ。", "{angry}密告だとさ。……オレたちを 王墓から 遠ざけたい やつが いる。"]);
    await K.hsay(p, H4(["{rage,怒}あの 衛兵長、次 会ったら 文句 百個 言って やるんだから！", "{sad,…}……でも、このまま 出られなかったら……"], ["{sad}……ここ、寒いわね。", "{sad,…}……ちゃんと、出られる わよね？"], ["{angry}……濡れ衣で 牢。笑えない。"], ["{sad,汗}……わたしたち、ここから 出られるのでしょうか……"]));
    K.act(eI, "kneel"); await K.up(p, eI, 10);
    await K.say(p, "イザク", ["{closed}……新入りでやんすか。あっしは イザク。この 牢で 七年に なるでやんす。", "{sad}娘の ニナが 石に なって、王墓の 石の 間に 葬られた。花を 一輪 届けたくて 入った。……それだけでやんす。"]);
    await K.hsay(p, H4("{shock,!}……七年も！？ 花 一輪で？", "{sad}……七年も。", "{closed}……七年。花 一輪で。", "{sad}七年も……お花の ために……"));
    K.act(eI, "show"); K.hold(eI, "bonekey"); await K.push(p, eI, 20, 4, 1.4, 1.1);
    await K.narr(p, ["§7イザクの 手に、白い 骨を 削った 鍵。何千回も 研いだ 跡で、つるつるに 光って いる。"], eI);
    await K.say(p, "イザク", /*F43*/["{closed}……七日 あれば 出られたでやんす。", "{sad,up}でも 出たら、また 王墓へ 走って、ニナの 前で 泣いて しまう。……だから 七年 かけて、自分で 削ったでやんす。"]);
    await K.say(p, "レイ", ["{closed}……自分で、自分を 閉じこめたのか。"]);
    await K.give(eI, eH2 || eH, "bonekey");
    await K.say(p, "イザク", ["{smile}おまえさんたちの 目は まだ 死んでおらん。夜、牢番が 眠ったら 使うでやんす。"]);
    await K.hsay(p, H4("{sad,up}……おじいさんも、いっしょに 出よう。", "{sad,up}……イザクさんも、いっしょに。", "{closed}……あんたも 出る。", "{sad,up}イザクさんも、ご一緒に。"));
    await K.say(p, "イザク", ["{closed}……考えて おくでやんす。"]);
    K.key(p, "k_bonekey");
    { const dd = K.load(p); if (dd) { K.qs(dd).jailIn = 1; K.save(p, dd); } }
    await K.night(p, at("bars"), "§7―― 夜。牢番の いびきが、通路に ひびいて いる。", "");
    return true;
  } };

/* ---------- 4話 地下牢→城の廊下（脱獄）---------- */
const E4 = { id: "b05e4", t: "地下牢→城の廊下", battles: 1,
  hint: "§f地下牢から 抜け出そう",
  syn: "骨の 鍵で 牢を 開け、地下水路を 抜けた 城壁の 外で 看守ブルーノを 倒し、城の 廊下へ もどった。ブルーノは「どうせ 外も 地獄だ」と 言った。",
  async run(p, d, K) {
    const J = facAt("b5jail", p.location, 30);
    if (!J) await K.open(p, "サンドリア城 地下牢（夜）", "night");
    const at = (n) => (J ? mk("b5jail", n, p) : null);
    const eH = K.hero(p), eR = J ? await K.put(p, "§bライバル レイ", at("cell"), null, RJ) : REI(K, p), eI = J ? await K.put(p, "§7老人 イザク", at("bed"), null, K.PJ("isak", 8)) : K.npcNear(p, "§7老人 イザク", K.PJ("isak", 8));
    K.act(eI, "kneel");
    K.act(eH, "hold"); K.hold(eH, "bonekey"); await K.at(p, at("door") || at("bars"), 14, 2.4, 1);
    K.sound(p, "random.click", 1.4); await K.wait(6); K.sound(p, "random.door_open", 0.8);
    await K.narr(p, ["§7骨の 鍵が、かちり と 回った。"], at("door"));
    await K.say(p, "レイ", ["{smile,low}……開いた。じいさん、行くぞ。"]);
    await K.say(p, "イザク", ["{closed}……あっしは、もう 少し ここに いるでやんす。行くでやんす。"]);
    /* 第126版(PV): 牢の 奥の 地下水路を 抜けて 城壁の 外へ。看守は そこで 追いつく（城の 中では 戦わない）*/
    { const DO = castleOut(4, "サンドリア城の 城壁の 外（地下水路の 出口）", 84); if (DO) { await moveG(K, p, { ...DO, x: DO.x + 6 }, "サンドリア城の 城壁の 外（地下水路の 出口）", [eI, eR].filter(ok)); K.fac(p, "b5drain", "channel", 4, Y0(K, p)); REI(K, p); K.hero(p); } }
    const eB = K.npcNear(p, "§8看守 ブルーノ", K.PJ("bruno", 16));
    await K.say(p, "看守 ブルーノ", ["{shock,!}おい、何の 音だ！ ……鍵が 開いてる！？ 逃がすか！"]);
    const r = await K.battle(p, K.team(["golem", "beast"], 34, 2, 6), { name: "看守 ブルーノ", arena: "牢破り", theme: "desert", speaker: "看守 ブルーノ", guests: K.team(["dragon"], 32, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "くそっ、応援を 呼べ！", low: "……行け" } });
    if (r !== "win") { await K.sayAt(p, "§8看守 ブルーノ", K.PJ("bruno", 16), "看守 ブルーノ", ["{angry}牢に もどれ！", K.RT(p)]); return false; }
    const eB2 = K.npcNear(p, "§8看守 ブルーノ", K.PJ("bruno", 16), true); K.act(eB2, "recoil"); K.turn(eB2, p.location); await K.wait(6); K.turn(eB2, null);
    await K.say(p, "看守 ブルーノ", ["{closed,low}……行けよ。どうせ 外も 地獄だ。", "{sad}石に なる 町、閉まる 店。……牢の 中の ほうが、まだ 静かだ。"]);
    await K.hsay(p, H4("{angry,up}地獄じゃ ないよ。外に 出なきゃ、何も 変わらない！", "{sad,up}……それでも、外へ 行くわ。", "{closed}……外で 変える。", "{closed,up}……それでも、外へ 参ります。"));
    { const dd = K.load(p); if (dd) { const s = K.qs(dd); s.jailDone = 1; delete s.jailIn; K.save(p, dd); } }
    const g0 = placeOf("gate", 4, true), g = g0 || facFront("b5jail", 17) || K.fwd(p, -18), lk = g0 ? null : facFront("b5jail", 30);
    await K.moveTo(p, g, "サンドリア城の 廊下（裏口から もどる）", [eB2, eI, eR, K.npcNear(p, "§bライバル レイ", RJ, true), K.hero(p, false)].filter(ok), lk);
    const eR2 = await K.put(p, "§bライバル レイ", K.fwd(p, 3.5, 1.4), null, RJ); K.hero(p); K.act(eR2, "point");
    await K.say(p, "レイ", ["{angry}廊下の 先に 灯りだ。……玉座の 間か。", "{closed}隠れても 見つかる。なら、王に 直接 話す。"]);
    K.act(eR2, 0);
    await K.hsay(p, H4("{angry}うん。ちゃんと 話そう。", "{closed}ええ。王さまに、話しましょう。", "{closed}行く。", "{closed}はい。参りましょう。"));
    K.act(eR2, 0); await K.leave(eR2, p, 10, false); await K.bye(p, K.hero(p, false));
    return true;
  } };

/* ---------- 5話 玉座の間（C05）---------- */
const E5 = { id: "b05e5", t: "玉座の間", F: ["F21", "F33", "F34", "F51"],
  hint: "§fサンドリア城の §e玉座の 間§f へ",
  syn: "砂王ラシードが 詫びた。二十年前、星の 冠の ような 紋の 男が 警告に 来て、追い返されたこと。男には 娘が 二人いて、下の 子の 名は まだ 決めて いなかったこと。セオは レイに 封じの 紐で 巻いた 星の かけらを 差し出した。",
  async run(p, d, K) {
    { const q = placeOf("throne", 4, true); if (q) await K.moveTo(p, q, "サンドリア城 玉座の 間"); else await toSet(K, p, "b5throne", "b5throne", 4, "サンドリア城 玉座の 間"); }
    const eH = K.hero(p), eRa = K.npcNear(p, "§6砂王 ラシード", K.PJ("rashid", 8)), eR = REI(K, p), eS = SEO(K, p);
    await K.low(p, eRa, 12);
    await K.say(p, "砂王 ラシード", ["{closed,low}……牢を 破って 来たか。よい。わしが 砂王 ラシード。", "{sad}密告を 疑わずに 牢に 入れたのは、わしの 落ち度だ。……セオと いう 学者が、さっき 証を 持って 来た。"]);
    K.act(eRa, "bow");
    await K.say(p, "砂王 ラシード", ["{sad}詫びる。……王の 法は 砂より 重い。じゃが、法を 守って 人を 見なかった わしは、もっと 重い。"]);
    K.act(eRa, 0);
    await K.hsay(p, H4("{angry}……じゃあ、牢の イザクさんも 出して あげて！", "{sad}……イザクさんの ことも、お願い します。", "{closed}牢の イザクも 出して。", "{closed}イザクさんの ことも、どうか。"));
    await K.say(p, "砂王 ラシード", ["{closed,up}……約束しよう。娘の 眠る 石の 間へも、わしが 通す。"]);
    await K.say(p, "砂王 ラシード", /*F33*/["{closed,low}……もう 一つ。二十年前、ある 男が この 玉座の 前に 来た。『石板の 封印が ゆるむ。王冠を 守れ』と。", "{sad}わしらは 王冠を 狙う 者と して 追い返した。……胸に、星の 冠の ような 紋を つけた 男だった。"]);
    await K.push(p, eRa, 22, 4, 1.6, 1.5);
    await K.say(p, "砂王 ラシード", /*F34*/["{sad,low}男は、娘が 二人 いると 言って いた。……下の 子の 名は、まだ 決めて いないと。"]);
    await K.hsay(p, H4("{!}……アルカトラスの 王さまも 言ってた。追い返した 男が いたって。……同じ 人？", "{!}……アルカトラスの 王さまの お話と、同じ 人かしら。", "{closed}アルカトラスの 王の 話と 同じ 男。手帳に 書く。", "{!}アルカトラスの 王さまの お話と、同じ 方でしょうか。"));
    K.act(eRa, "hold"); K.hold(eRa, "scroll"); await K.give(eRa, eH, "scroll");
    await K.say(p, "砂王 ラシード", ["{closed}詫びの しるしだ。§6王墓の 地図§f を 渡す。六影より 先に、王墓の 主を 封じて くれ。"]);
    K.key(p, "k_tomb");
    /* かけら */
    K.act(eS, "show"); K.hold(eS, "orb"); await K.approach(p, eS, eR, 1.6, 12);
    await K.push(p, eS, 20, 4, 1.4, 1.2);
    await K.narr(p, /*F51*/["§7セオの 手の ひらに、赤く 光る 石の かけら。細い 紐で、ぐるぐると 巻いて ある。"], eS);
    await K.say(p, "セオ", ["{smile}レイくん、これを。荒野の 遺跡で 見つけた §e星の かけら§f です。……お守りに。"], eR);
    await K.hsay(p, H4("{shock,!}……待って。村長の 手紙に、かけらは 心を 削るって 書いて あった。", "{sad,?}……待って。村長さんの 手紙に、かけらは 心を 削るって。", "{closed}……待って。村長の 手紙。かけらは 心を 削る。", "{shock,!}お待ち ください。村長さまの お手紙に、かけらは 心を 削ると……"));
    await K.say(p, "セオ", ["{smile}封じの 紐で 巻いて あります。ほどかなければ、ただの 温かい 石です。"]);
    K.act(eR, "raise"); await K.up(p, eR, 12);
    await K.say(p, "レイ", ["{closed}……牢で、何も できなかった。じいさんが 七年 待ってたのに、オレは 見てる だけだった。"]);
    const c = await K.pick(p, "c05");
    if (c === "w") {
      K.act(eH, "guard"); await K.approach(p, eH, eR, 1.4, 10);
      await K.hsay(p, H4("{angry,up}だめ！ レイ、それは 受け取らないで！", "{angry,up}レイくん、受け取っちゃ だめ。", "{angry}受け取るな、レイ。", "{angry,up}レイさん、お受け取りに なっては いけません！"));
      K.re(eR, "angry", "怒"); await K.up(p, eR, 10);
      await K.say(p, "レイ", ["{angry}……また おまえが 決めるのか。オレが 強く なる 道まで。", "{closed,low}王墓は 一人で 行け。オレは オレで 行く。"]);
      K.act(eR, 0); await K.bye(p, eR);
      await K.say(p, "セオ", /*F21*/["{closed}……そうですか。", "{smile,low}……置いて おきますね。君は、選ばれる 人ですよ。"]);
      K.act(eS, "give"); K.hold(eS); const tq = K.fwd(p, 4, 1.5); if (tq) await K.at(p, tq, 14, 2.4, 0.6);
      await K.narr(p, ["§7セオは かけらを 卓の 上に 置いて、廊下へ 去った。"], tq);
      await K.bye(p, eS);
      await K.night(p, tq, "§7―― 夜。だれも いない 卓に、足音が 一つ。", "§7……朝、卓の 上の かけらは なかった。");
    } else {
      await K.give(eS, eR, "orb"); K.act(eR, "raise"); K.burst(p.dimension, ok(eR) ? eR.location : p.location, "minecraft:redstone_wire_dust_particle", 6, 0.35, 1.2);
      await K.say(p, "レイ", ["{smile,up}……あったかいな。持ってると、力が 湧いて くる。"]);
      await K.say(p, "セオ", /*F21*/["{smile,up}……牢で、悔しそうな 顔を してましたね。君は、選ばれる 人ですよ。"]);
      await K.hsay(p, H4("{sweat,?}……ねえ、その 石、嫌な 感じ しない？", "{sad,?}……少し、冷たい 感じが するわ。", "{?}……持たない 方が いい 気が する。", "{sweat,?}……なんだか、落ちつかない 石です。"));
      await K.say(p, "レイ", ["{closed}……気の せいだろ。王墓の 主、一緒に 行こう。"]);
    }
    K.pay(p, E5, 5000, [["c_herbs", 3], ["g_sp2", 1]]);   /* 第127版: 城門の 段（MQ10）の 段ほうび（本の 流れで 1回）*/
    await K.end(p, { leave: [eS, eR].filter(ok), bye: [eRa], card: "§7→ 王墓の 地図は【だいじなもの】に。まずは 城の 中庭へ", kind: "castle" });
    return true;
  } };

/* ---------- 6話 城の中庭（セリーヌの 証拠）---------- */
const E6 = { id: "b05e6", t: "城の中庭", battles: 1, F: ["F05", "F09", "F46"],
  place: PL("court", 4, "サンドリア城の 中庭"),
  hint: "§f§6サンドリア城の 中庭§f へ 行こう §7（セリーヌが 証拠を 持って 来た）",
  syn: "セリーヌが 腰帯の 証拠を 届けた。ガルムは 謝り、密告の 手紙が もう 一通 あったと 明かした。『石板の 子が 通った 町は、石に なる』。捕まった スナモグラが 見せた 命令の 手紙は、古くさい、かすれた 年寄りの 字だった。骨の 鍵は イザクに 返した。",
  skip: (s) => { s.epx = { ...T(s.epx), proof4: 1 }; s.keys = (Array.isArray(s.keys) ? s.keys : []).filter((k) => k !== "k_bonekey"); },
  async run(p, d, K) {
    await K.open(p, "サンドリア城の 中庭", "castle");
    let eH = K.hero(p), eC = K.cast(p, "r4celine"); K.act(eC, "raise");
    await K.csay(p, "r4celine", ["{smile,☆,up}ご無事で！ 牢に 入れられたと 聞いて、走って きましたわ！", "{closed}約束、しましたもの。困ったら 必ず 届けに 行くと。"]);
    K.act(eC, "show"); K.hold(eC, "rope");
    await K.push(p, eC, 18, 4, 1.4, 1.1);
    await K.narr(p, ["§7砂色の 衛兵の 腰帯。裏に、黒い 糸の 印。"], eC);
    const eG = K.cast(p, "r4garm"), eT = THIEF(K, p); K.hold(eG, "spear"); K.act(eT, "kneel");
    await K.two(p, eG, eT, 12);
    await K.csay(p, "r4garm", ["{closed}……この 男が、衛兵に 化けて 盗みと 密告を して おったのである。"]);
    K.act(eG, "bow"); await K.up(p, eG, 12);
    await K.csay(p, "r4garm", ["{sad,up}旅の 方。……すまなかったのである。わしは 証拠より、『よそ者』と いう 言葉を 信じた。"]);
    await K.csay(p, "r4garm", /*F46*/["{closed,low}……密告の 手紙は、もう 一通 あったのである。『石板の 子が 通った 町は、石に なる』と。", "{sad}……わしは、それも 信じかけた。"]);
    await K.hsay(p, H4(["{angry}……文句 百個 言う つもりだったけど。", "{smile,息}もう いいよ。ちゃんと 謝って くれたから。"], "{smile}……顔を 上げて。わかって くれたなら、いいの。", "{closed}……もう いい。次は、ちゃんと 見て。", "{smile}どうか お顔を お上げ ください。"));
    K.act(eG, 0);
    K.act(eT, "guard"); K.sound(p, "mob.villager.no", 1);
    await K.say(p, "スナモグラ", ["{rage,怒,up}……へっ！ 謝って 済むかよ！ オレは まだ 縄は かかって ねえぜ！"]);
    /* 第126版(PV): スナモグラは 城門の 外へ 逃げる → 城門の 外で 戦う（城の 中庭では 戦わない）→ 中庭へ もどる */
    if (ok(eT)) await K.leave(eT, p, 12, true);
    const GO = castleOut(4, "サンドリア城の 城門の 外"), CQ = placeOf("court", 4);
    if (GO) { if (CQ) gateSet(p, "c4gate", GO, CQ, Y0(K, p)); await moveG(K, p, GO, "サンドリア城の 城門の 外", [eC, eT].filter(ok), CQ ? { x: CQ.x, y: Y0(K, p) + 3, z: CQ.z } : null); K.hero(p); THIEF(K, p); K.cast(p, "r4garm"); }
    const r = await K.battle(p, K.team(["golem", "nether", "beast"], 38, 3, 10), { name: "偽の 衛兵 スナモグラ", arena: "セリーヌの 証拠", theme: "desert", speaker: "スナモグラ", lines: { half: "なんで 強く なって んだよ！", low: "……弟たちが、待ってんのに……" } });
    if (r !== "win") { await K.sayAt(p, "§6衛兵長 ガルム", K.PJ("glen", 16), "ガルム", ["{angry}……下がれ！ この 男は わしが 押さえるのである！", K.RT(p)]); return false; }
    const eT2 = THIEF(K, p, true); K.act(eT2, "down"); await K.up(p, eT2, 10);
    await K.say(p, "スナモグラ", ["{sad,…}……上の 人？ 顔も 名前も 知らねえ。手紙が 来て、金が 来る。それだけだ。"]);
    K.act(eT2, "show"); K.hold(eT2, "letter");
    await K.push(p, eT2, 20, 3.5, 1.2, 1.2);
    K.card(p, "§8『王墓に 近づく よそ者を 牢に 入れよ。\n§8　よそ者は 泥棒だと、町に 思わせて おけ』\n\n§7……古くさい、かすれた、年寄りの 字", 90);   /*F05*/ /*F09*/
    await K.wait(80);
    await K.say(p, "スナモグラ", ["{closed}……じいさんの 字だろ。古くさくて、かすれてる。封には いつも『参謀の 指示』だ。"]);
    await K.hsay(p, H4("{?}……じいさんの 字。……だれの 字なんだろ。手帳に 写しとく。", "{?}……お年寄りの 字。だれかしら。", "{closed}年寄りの 字。……覚えて おく。", "{?}ご年配の 方の 字……。記して おきます。"));
    K.act(eG, "hold"); await K.csay(p, "r4garm", ["{angry}立つのである。詰め所で、話を 聞くのである。……子どもらの ことも な。"]);
    await K.bye(p, eT2, K.cast(p, "r4garm", true));
    if (GO && CQ) { await moveG(K, p, CQ, "サンドリア城の 中庭"); const e1 = K.hero(p); if (ok(e1)) eH = e1; const e2 = K.cast(p, "r4celine"); if (ok(e2)) eC = e2; }
    /* 骨の 鍵を イザクへ 返す */
    const eI = K.cast(p, "r4isak"); K.act(eI, "hold");
    await K.csay(p, "r4isak", ["{smile,♪}おやおや、にぎやかでやんすね。王さまが 牢から 出して くれたでやんす。"]);
    await K.csay(p, "r4celine", ["{shock,!,up}……イザクさん？ 子どもの ころ、市で あめ細工を くれた……あの イザクさん！？"], eI);
    await K.csay(p, "r4isak", ["{smile,tears,up}……お嬢。大きく なったでやんすね。"]);
    K.act(eH, "give"); K.hold(eH, "bonekey"); await K.give(eH, eI, "bonekey");
    await K.hsay(p, H4("{smile}これ、返すね。もう、自分を 閉じこめなくて いいよ。", "{smile}……お返し します。もう、いらないかもしれないけど。", "{closed}返す。もう 削らなくて いい。", "{smile}お返し いたします。もう、削らなくて よいのです。"));
    await K.csay(p, "r4isak", ["{smile}……でやんすね。王墓の 件が 片づいたら、ニナに 花を 届けに 行くでやんす。"]);
    await K.csay(p, "r4celine", ["{closed,up}……決めましたわ。王墓の 件が 片づいたら、わたくし、店を 開けますわ。いちばんに 来て くださいまし。"]);
    if (!K.replay(p)) { const dd = K.load(p); if (dd) { const s = K.qs(dd); s.keys = (s.keys || []).filter((k) => k !== "k_bonekey"); K.save(p, dd); } }
    K.pay(p, E6, 600, [["c_herbs", 2]]);
    await K.end(p, { leave: [eC, eI], card: "§7→ 砂の 王墓へ。その 前に、ソーラの 老兵が 会いたがって いる", kind: "castle" });
    return true;
  } };

/* ---------- 7話 ソーラの老兵の家 ---------- */
/* 第126版(PV): 老兵の 家は 里の 中の 家（建物の 戸口）*/
const VETHOME = () => bldOf("t21", ["home2", "home3", "home"], "たいようの 里 ソーラの 老兵の 家") || SORA();
const E7 = { id: "b05e7", t: "ソーラの老兵の家", place: VETHOME, F: ["F33"],
  hint: "§fたいようの 里 §eソーラの 老兵の 家§f へ 行こう",
  syn: "二十年前、星の 冠の 男を 城門から 追い出した 老兵ハミドは「王を 責めるな」と 言った。家の 壁から 下ろした、灰色の 染みの ついた 古い 槍が かかって いた。",
  async run(p, d, K) {
    await K.open(p, "ソーラの 老兵の 家", "day");
    K.hero(p); const eV = K.cast(p, "b5vet"); K.act(eV, "hold");
    await K.csay(p, "b5vet", ["{closed}……城の 噂は 聞いた。星の 冠の 男の 話を、王が した そうじゃな。", "{sad}あの 男を 門から 追い出したのは、わしじゃ。槍を 向けてな。"]);
    K.hold(eV, "spear"); K.act(eV, "show"); if (ok(eV)) await K.push(p, eV, 20, 3.2, 1.4, 1.2);
    await K.narr(p, ["§7ハミドが 壁から 下ろした 古い 槍。穂先に、拭いても 落ちない 灰色の 染みが ある。（記録の 断片）"], eV);
    await K.hsay(p, H4("{?}……その 人、どんな 人だった？", "{?}……どんな 方だったの？", "{?}どんな 男だった。", "{?}どのような 方でしたか。"));
    await K.csay(p, "b5vet", /*F33*/["{closed}怒らなんだ。……槍を 向けられて、男は 礼を して 帰った。『また 来る』とも 言わずにな。", "{sad,up}……王を 責めるな。あの 日、門で 一番 声を 張り上げたのは、わしじゃ。"]);
    await K.hsay(p, H4("{sad}……責めないよ。でも、覚えとく。", "{sad}……誰も 責めないわ。手帳に、残して おくね。", "{closed}責めない。……記録は 残す。", "{sad}責めは いたしません。けれど、記して おきます。"));
    await K.csay(p, "b5vet", ["{smile,…}……そうか。記録か。それなら、わしも 少し 軽く なる。"]);
    K.pay(p, E7, 500, [["c_herbs", 1]]);
    await K.end(p, { leave: [eV], card: "§7→ 王墓の 地図を 持って、砂の 王墓の 奥へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 8話 砂の王墓（MQ11）---------- */
const E8 = { id: "b05e8", t: "砂の王墓", battles: 1, F: ["F03", "F04", "F38", "F51"],
  hint: "§f王墓の 地図を §e砂の 王墓の 奥の 広間§f で 使おう",
  syn: "王墓の 壁に「永遠を 願うな。願いは 石に なる」。爪で 引っかいた 四本の 線、一本だけ 短い。王墓の 主は 背で 字を 隠してから 戦った。脇の 碑に「鬼王ギレンドドロスは 永遠を 願った」。",
  async run(p, d, K) {
    const L = await toSet(K, p, "b5wall", "b5wall", 4, "砂の 王墓の 奥");
    const W = mk("b5wall", "wall", p) || L, CL = mk("b5wall", "claw", p) || W, ST = mk("b5wall", "stele", p) || W;
    const rei = chOf(K, p, "c05") !== "w";
    const eH = K.hero(p), eR = rei ? REI(K, p) : null;
    if (W) await K.push(p, W, 24, 7, 2.6, 0.4);
    K.act(eH, "point");
    await K.hsay(p, H4(["{?}……壁に 文字が 刻まれてる。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……"], ["{?}……壁に 文字が。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……"], ["{closed,up}……『§e永遠を 願うな。願いは 石に なる§f』。"], ["{?}壁に 文字が……", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……"]));
    if (CL) await K.push(p, CL, 20, 2.6, 1, 0);
    await K.narr(p, /*F03*/ /*F04*/["§7字の 上を、爪で 引っかいた 跡。四本の 線。……一本だけ、短い。", "§7だれかが、この 字を 消そうと した。"], CL);
    if (rei) await K.say(p, "レイ", ["{closed,low}……消したく なるほど、本当の ことなのか。"]);
    else await K.hsay(p, H4("{sad}……レイが いたら、なんて 言ったかな。", "{sad}……レイくんなら、なんて 言うかしら。", "{closed}……一人だと、壁が 広い。", "{sad}……レイさんが いらしたら、と 思って しまいます。"));
    /* 主は 背で 字を 隠す */
    K.sound(p, "mob.wither.spawn", 0.8); K.shake(p, 1, 1.2);
    K.big(p, "§6§l王墓の 主", "§f砂の 下から 番人が 起きあがる", "mob.husk.ambient");
    const eL = K.npcNear(p, "§6王墓の 主", K.PJ("stoneknight", 9));
    if (ok(eL) && W) { await K.go(eL, { x: W.x - 1, y: eL.location.y, z: W.z }, 18); K.turn(eL, p.location); }
    await K.low(p, eL, 14);
    await K.narr(p, ["§7番人は 壁の 前に 立ち、大きな 背で 字を 隠した。……それから、こちらを 向いた。"], eL);
    await K.say(p, "王墓の 主", ["{closed,low}……読ムナ。……王ノ 眠リヲ、サマタゲルナ。"]);
    if (rei) { K.act(eR, "raise"); await K.say(p, "レイ", ["{rage,up}……かけらが 熱い。力が、あふれて くる……！ 行くぞ！"]); }
    const res = await K.battle(p, K.bossOne(["nether", "golem"], 42, 56), { name: "王墓の 主", arena: "王墓の 主", theme: "desert", hpk: 6, extra: 0.35, sboss: true, speaker: "王墓の 主",
      ...(rei ? { guests: K.team(["dragon"], 40, 2).map((t) => ({ ...t, owner: "レイ" })) } : {}), lines: { half: "……王ヨ……", low: "……オ許シヲ……" } });
    if (res !== "win") { await K.hsay(p, H4("{sweat,汗}いったん 出よう！ 地図は まだ 使える。", "{sweat}……一度 出ましょう。地図は まだ 使えるわ。", "{closed}引く。地図は まだ 使える。", "{sweat}一度 退きましょう。地図は まだ 使えます。")); K.rm(eL); return false; }
    await K.bye(p, K.npcNear(p, "§6王墓の 主", K.PJ("stoneknight", 9), true));
    if (!K.replay(p)) { const dd = K.load(p); if (dd) { const s = K.qs(dd); s.gate = { ...T(s.gate), 4: true }; K.save(p, dd); } }
    if (ST) await K.push(p, ST, 20, 3.2, 1.4, 0.2);
    await K.narr(p, /*F38*/["§7脇の 碑に、古い 字。『§e鬼王ギレンドドロスは 永遠を 願った§7』"], ST);
    await K.hsay(p, H4("{?}……永遠を 願った 王様。……どう なったんだろ。", "{?}……永遠を 願った 王さま。その あとは、書いて ないのね。", "{closed}願った あとが 書いてない。", "{?}永遠を 願った 王……その 先は、記されて いません。"));
    /* 紐 */
    const eR2 = REI(K, p, rei);
    if (ok(eR2)) { K.act(eR2, "hold"); K.hold(eR2, "orb"); await K.push(p, eR2, 18, 3, 1.2, 1.1); }
    if (!rei) await K.narr(p, ["§7出口の 階段に、一人で 王墓へ 来た レイが 立って いた。手に、赤い かけら。"], eR2);
    await K.say(p, "レイ", /*F51*/["{closed,low}……紐が、ゆるんでる。"]);
    await K.hsay(p, H4("{sad,?}……レイ。それ、手放そうよ。", "{sad}……レイくん。それ、置いて いきましょう。", "{closed}……手放せ。", "{sad}……レイさん。それを、手放して ください。"));
    await K.say(p, "レイ", rei ? ["{angry}……なんでもない。もっと、強く なれる。"] : ["{closed}……おまえは 止めた。それで いい。……あとは オレの 問題だ。"]);
    K.act(eR2, 0); await K.leave(eR2, p, 10, false);
    K.pay(p, E8, 12000, [["e_silver", 1], ["SEED3", 1], ["tms_demon", 1]]);
    await letter(K, p, "セオ", ["（手紙）王墓の 主の 封印、おめでとう ございます。クリスタリアへの 道が 開きました。", "§dクリスタリアの 洞くつ§f で、六影が 水晶を 集めて いる そうです。……レイくんの 様子は、どうですか。"], "§fクリスタリアへ 行けるように なった");
    await K.end(p, { kind: "day" });
    return true;
  } };

/* ---------- 9話 ミラージュの市（夕ぐれ）---------- */
const E9 = { id: "b05e9", t: "ミラージュの市（夕ぐれ）", place: SHOP, fac: "r4shop",
  hint: "§fミラージュの §e砂星商会（セリーヌの 店）§f へ もどろう §7（セリーヌとの 約束）",
  syn: "店が 再開した。父ハリドも 帳場に 立ち、イザクは「やっと『ただいま』を 言えたでやんす」と 笑った。",
  skip: (s) => { s.epx = { ...T(s.epx), shop4: 1 }; },
  async run(p, d, K) { return oldRun(p, d, K, E9, 4, "r4e6"); } };

bkAdd("b05", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ11: 古い セーブで 王墓が もう 済んで いれば 条件なし */
mqOver(11, null, { cond: async () => true });
