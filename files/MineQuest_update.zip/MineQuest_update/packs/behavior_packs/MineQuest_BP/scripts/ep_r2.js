/* 第125版: 第3地方 ルインズ（はいきょの 村 ガレキ・廃都グランディア）の 5話
   1話 乾いた 村（新）→ 2話 語り部（新。水の 配給の もめごと・トキ婆の「王の 隣の 影」）→ 3話 涸れ谷の 水門（新。砂ぼこり団の 頭 バルガ＝ドルフの 昔の 相棒）
   → 4話 壁画（今の 段: 崖道 → 壁画の 広間 → ジンの 城）→ 5話 水が 戻る（今の 段: ジンとの 勝負 → 新: 井戸が 戻り、ドルフと バルガが 和解）
   書き方は ep_r0.js の 頭の 説明の とおり。場所は 村の 外れ（噴水・町の 中の 道・坂の 途中は 使わない）*/
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, spotOf, openSite, stageAvoid, bldOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, castleSpot, groundY } from "./structures.js";
import { regionIdx } from "./worldmap.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok, choose } from "./ui.js";
import { fac, facState } from "./epfac.js";
import "./pvplace.js";   /* 第126版(PV): 井戸端の 形（wellyard）*/
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* b の そば k マス（a の 側）*/

/* ---------- 場所: ガレキの 外れ ---------- */
const TID = "t5", REG = 2;
const SP0 = () => { try { return world.getDefaultSpawnLocation(); } catch { return { x: 0, y: 64, z: 0 }; } };
const TC = () => { const t = TOWNS.find((u) => u.id === TID); if (!t) return null; const q = getTown(TID); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const PLQ = {};
function ring(key, R, nm, near = []) {
  if (PLQ[key]) return PLQ[key];
  const c = TC(); if (!c) return null; const s0 = SP0(), avoid = near.filter(Boolean);
  for (const t of TOWNS) if (t.id !== TID) { const q = townPos(t); avoid.push([q.x, q.z, 44]); }
  for (let i = 0; i < 11; i++) { const k = castleSpot(i); if (k) avoid.push([k.x, k.z, 72]); }
  for (const k of ["out", "road", "hall", "stage", "forge"]) { const q = placeOf(k, REG); if (q) avoid.push([q.x, q.z, 24]); }
  stageAvoid(avoid, 70);   /* 第127版(fac): どの 地方の ステージ（大地）からも 離す */
  let best = null;
  for (let a = 0; a < 16; a++) { const t = (a / 16) * Math.PI * 2, x = Math.floor(c.x + Math.cos(t) * R), z = Math.floor(c.z + Math.sin(t) * R); if (regionIdx(x - s0.x, z - s0.z) !== REG) continue; let m = 1e9; for (const [X, Z, D] of avoid) m = Math.min(m, Math.hypot(X - x, Z - z) - D); if (!best || m > best.m) best = { x, z, m }; }
  if (!best) best = townOut(TID, -0.5, nm);
  return (PLQ[key] = best ? { x: best.x, z: best.z, nm } : null);
}
const WELL = () => openSite("r2well", TC(), REG, 80, 220, "ガレキの 先の 古井戸") || ring("well", 56, "はいきょの 村 ガレキの 外れの 古井戸");   /* 第127版(fac2): 町の 外れ 56 → 離れた 広い 所（古井戸の 小屋が 建つ）*/
const RATION = () => { const b = bldOf(TID, ["plaza", "inn", "shop"], "はいきょの 村 ガレキの 水の 配給所"); if (b) return b; const a = WELL(); return ring("ration", 60, "ガレキの 外れの 水の 配給所", [a && [a.x, a.z, 34]]); };   /* 第127版(fac2): 暮らしの 場面は 町の 中（広場・宿の 前）*/
/* 第127版(fac): 水門は 村から 離れた 涸れ谷（町・城・ステージから 離れた 広い 所。水門・水路・池・水車小屋 ごと 建てる）*/
const GATE = () => { const a = WELL(), b = RATION(); return openSite("r2gate", TC(), REG, 110, 450, "ガレキの 先の 涸れ谷の 水門", [a && [a.x, a.z, 90], b && [b.x, b.z, 90]]) || ring("gate", 84, "ガレキの 外れの 涸れ谷の 水門", [a && [a.x, a.z, 34], b && [b.x, b.z, 34]]); };
const standAt = (k, dx, dz, f) => () => { for (const kk of [].concat(k, "inn")) { const q = spotOf(TID, kk); if (q) return { x: q.x + dx, y: q.y, z: q.z + dz }; } const o = f(); return o ? { x: o.x + dx, z: o.z + dz } : null; };   /* 第125版(pl): 仕事に 合う 建物の 前（なければ 宿）*/

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
const fall = (s) => !!s.heroDead && !s.ending;   /* 世界が 滅びかける ころ（第10章の あと 〜 終章の 前）*/
castAdd("r2dolf", { nm: "ドルフ", role: "自警団長", gobi: "だぜ", skin: "m6_ivan", town: TID, from: "r2e1", at: standAt("plaza", 3, -2, WELL),
  pre: ["{angry}水なら ねえぜ。……今は な。"],
  after: [
    [(s) => !!s.heroBack, ["{smile}おう、二人 そろってるじゃ ねえか！", "{smile,♪}井戸の 水、飲んで いけよ。世界で いちばん うまいんだぜ。"]],
    [(s) => !!s.ending, ["{closed}空が 晴れたぜ。石に なりかけた 仲間も、戻って きたんだぜ。", "{sad}……戻らねえ やつも いる。そいつらの ぶんまで、この 村を 守るんだぜ。"]],
    [fall, ["{angry}仲間が 一人、石に なっちまったんだぜ……。", "{angry,up}バルガと 二人で 夜の 見回りを してる。影なんかに、この 村は 渡さねえんだぜ。"]],
    [(s) => !!st(s).fest2, ["{smile,♪}井戸に 水が 戻ったんだぜ！ 見ろよ、ガキどもが 水遊び してやがる。", "{smile}バルガの やつ？ ……昔みてえに、隣で 酒を 飲んでるぜ。"]],
    [(s) => !!st(s).barga1, ["{closed}バルガの やつ……。あいつにも、あいつの わけが あるんだぜ。"]],
    [() => true, ["{angry}井戸の 水は、村の みんなの もんだぜ。"]],
  ] });
castAdd("r2toki", { nm: "トキ婆", role: "語り部", gobi: "じゃった", skin: "zaza", town: TID, from: "r2e2", at: standAt("home", -3, 2, RATION),
  pre: ["{closed}語り部の 婆に、何か 用かね。……昔は 昔話を よう 聞きに 来る 子が おったんじゃった。"],
  after: [
    [(s) => !!s.heroBack, ["{smile}……おかえり。二人の 顔が 見られて、ほっと したんじゃった。"]],
    [(s) => !!s.ending, ["{closed}王の 隣の 影の 話……。お前さんたちが、本当の おしまいを 見つけて くれたんじゃった。", "{smile}語り部は、新しい 昔話を 一つ 覚えたんじゃった。"]],
    [fall, ["{sad}知りすぎた 王さまの 話を、今は だれも 笑わんように なったんじゃった。", "{closed}……知る ことが こわい 夜も ある。それでも 語り部は、語るんじゃ。……昔から そう 決まっとったんじゃった。"]],
    [(s) => !!st(s).fest2, ["{smile}井戸の 祭りの 夜、子らに 昔話を 聞かせたんじゃった。ひさしぶりに、みな 笑っておった。"]],
    [() => true, ["{closed}王の 隣の 影の 話かい？ ……あれは、悲しい 話なんじゃった。"]],
  ] });
castAdd("r2barga", { nm: "バルガ", role: "砂ぼこり団の 頭", col: "§6", gobi: "だろうが", skin: "m6_grant", town: TID, from: "r2e5", at: standAt("tavern", 5, 0, WELL),
  pre: ["{angry}……なんだ。用が ねえなら 行けって 言ってんだろうが。"],
  after: [
    [(s) => !!s.heroBack, ["{smile}よう。……ドルフの やつが 酒を おごれと うるせえんだ。……付き合うのが 筋ってもんだろうが。"]],
    [(s) => !!s.ending, ["{closed}団の 連中は、みんな 村の 畑を 手伝ってる。……盗賊は もう 廃業だろうが。"]],
    [fall, ["{angry}団の 連中は、みんな 村の 見張りに 回した。……今度は 逃げねえ。", "{sad,low}逃げる 場所なんざ、もう どこにも ねえだろうが。"]],
    [() => true, ["{closed}水門は 毎朝 俺が 開けてる。……昔、ドルフと 約束したんだろうが。二人で 村の 水を 守るってな。"]],
  ] });
castAdd("r2jin", { nm: "ジン", role: "地方マスター", col: "§6", gobi: "", skin: "jin" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const out = async (K, p, e, run = false) => { if (!ok(e)) return; const q = K.away(e, p, 12), l = e.location; if (!q || Math.hypot(q.x - l.x, q.z - l.z) < 4) return K.bye(p, e); return K.leave(e, p, 12, run); };   /* 歩いて 去る（道が ふさがって いる ときは 暗転で 下げる）*/
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
const beside = (e, q, k, s) => { const A = e.location, dx = A.x - q.x, dz = A.z - q.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n; return { x: q.x + ux * k - uz * s, y: A.y, z: q.z + uz * k + ux * s }; };   /* 第125版(rs2): q の 手前 k・横 s（水門の 前の 水路を よける）*/
const WQ = (c, y0) => ({ x: Math.floor(c.x) + 11, y: y0, z: Math.floor(c.z) + 6 });
/* 古井戸（ワールドに 1回ずつ。lvl 1 = 枯れた 井戸・2 = 水の 戻った 井戸）。舞台の 外側に 3×3 だけ */
function well(K, p, c, y0, lvl) {
  const k = "mrpg:epdeco:t5well"; let v = 0; try { v = Number(world.getDynamicProperty(k) || 0); } catch {} if (v >= lvl) return;
  const q = WQ(c, y0), dim = p.dimension; let gy = null; try { gy = groundY(dim, q.x, q.z, y0 + 6); } catch {} if (typeof gy !== "number" || Math.abs(gy - y0) > 4) return;
  for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { let g2 = null; try { g2 = groundY(dim, q.x + a, q.z + b, gy + 4); } catch {} if (typeof g2 !== "number" || Math.abs(g2 - gy) > 1) return; }   /* 第124版: 斜面には 作らない（壁が 浮く・埋まる）*/
  for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { if (!a && !b) continue; K.cmd(p, `setblock ${q.x + a} ${gy} ${q.z + b} cobblestone_wall keep`); }
  K.cmd(p, `setblock ${q.x} ${gy - 1} ${q.z} ${lvl >= 2 ? "water" : "sand"}`); K.cmd(p, `setblock ${q.x} ${gy} ${q.z} air`);
  if (lvl >= 2) { K.cmd(p, `setblock ${q.x - 1} ${gy + 1} ${q.z - 1} oak_fence keep`); K.cmd(p, `setblock ${q.x - 1} ${gy + 2} ${q.z - 1} lantern keep`); }
  try { world.setDynamicProperty(k, lvl); } catch {}
}

/* ---------- 1話 乾いた 村 ---------- */
const E1 = { id: "r2e1", pv: 127, n: 1, t: "乾いた 村", at: 0, ord: 0, place: WELL,
  hint: "§fルインズ荒野の §eはいきょの 村 ガレキの 外れの 古井戸§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "はいきょの 村 ガレキの 古井戸は、底まで 乾いて いた。自警団長の ドルフは「枯れたんじゃ ねえ。涸れ谷の 水門を、砂ぼこり団が 独りじめ してるんだ」と 言い、のどを からした 子に 自分の 水を ゆずった。「昔は、そうじゃ なかったんだがな」と、ドルフは 遠くを 見た。",
  set: { met2: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    fac(K, p, "r2wellyard", "wellyard", 2, y0);   /* 第126版(PV): 井戸端（空の 樽・水桶・柵）*/
    well(K, p, c, y0, 1);
    await K.open(p, "はいきょの 村 ガレキの 外れの 古井戸", "day");
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{sweat,汗}あつい……のど、からから……。"], ["{sweat,汗}……風が 熱いわ。のどが かわく。"], ["{sweat,汗}……暑い。乾いてる。"], ["{sweat,汗}……の、のどが からからです。"]));
    const wq = WQ(c, y0);
    if (ok(eH)) { await K.walkCam(p, eH, nearPt(eH, { location: wq, isValid: () => true }, 1.6) || wq, 20); K.act(eH, "kneel"); }   /* 第125版(rs): 井戸の ふちへ 歩いて のぞきこむ */
    K.burst(p.dimension, wq, "minecraft:falling_dust_dragon_egg_particle", 6, 0.8, 0.6);
    await K.at(p, wq, 14, 4, 1); K.act(eH, 0);
    const v1 = await K.put(p, "§f村の 年寄り", { x: wq.x - 1.5, y: y0, z: wq.z + 2.5 }, wq, K.PJ("m6_hector", 8)), v2 = await K.put(p, "§f村の 女", { x: wq.x + 2.5, y: y0, z: wq.z - 1.5 }, wq, K.PJ("hanna", 8));   /* 第125版(rs2): 文の とおり、からの 桶を 抱えて 座りこむ 村の 人（暗転の 中で もう そこに いる）*/
    for (const v of [v1, v2]) { K.act(v, "kneel"); K.hold(v, "bucket"); }
    await K.narr(p, ["§7石を 積んだ 古井戸。のぞきこむと、底は 乾いた 砂で ひび割れて いた。", "§7そばには、からの 桶を 抱えた 村の 人たちが、ぼんやりと 座りこんで いる。"], wq);
    const eD = K.cast(p, "r2dolf"); K.act(eD, "guard");
    await K.csay(p, "r2dolf", ["{angry,low}……見ねえ 顔だな。水なら ねえぜ。", "{closed}売る ほども、くれて やる ほども ねえんだぜ。"], eH);
    K.act(eD, 0);
    await K.hsay(p, K.V(["{?}こんにちは！ ……この 井戸、どうして 枯れちゃったの？"], ["{?}……この 井戸、枯れて しまったの？"], ["{?}……井戸が 枯れた わけは？"], ["{?}あの……この 井戸は、なぜ 枯れて しまったのですか？"]));
    await K.csay(p, "r2dolf", ["{closed}俺は ドルフ。この 村の 自警団長だぜ。", "{angry,up}枯れたんじゃ ねえ。止められたんだぜ。涸れ谷の 水門を、§6砂ぼこり団§f が 独りじめ してやがる。"], eH);
    K.act(eD, "point");
    await K.csay(p, "r2dolf", ["{angry}水が ほしけりゃ、金か モンスターを よこせ だとよ。……ふざけやがって。"]);
    K.act(eD, 0);
    await K.hsay(p, K.V(["{angry,怒,up}ひどい！ 水を 売りものに するなんて！"], ["{sad,up}……水を 売るなんて。"], ["{angry}……水で 商売。最低。"], ["{angry,怒}水を 売りものに するなんて、ひどすぎます！"]));
    await K.approach(p, eD, eH, 1.9); if (ok(eD)) K.turn(eD, K.fwd(p, 20, -8, 2)); await K.push(p, eD, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る（rs2: 涸れ谷の 方へ 背を 向ける）*/
    await K.csay(p, "r2dolf", ["{sad,…,up}……昔は、そうじゃ なかったんだがな。"]);
    await K.hsay(p, K.V(["{?}……昔？"], ["{?}……昔？"], ["{?}昔？"], ["{?}……昔、ですか？"]));
    await K.csay(p, "r2dolf", ["{closed,no}……なんでも ねえ。"]); K.turn(eD);
    const eK = K.npcNear(p, "§f村の 子", K.PJ("taro", 8));
    K.act(eK, "hold");
    await K.say(p, "村の 子", ["{cry,up}ドルフ兄ちゃん……おみず、まだ……？"]);
    if (ok(eD) && ok(eK)) { const q = eK.location; await K.go(eD, { x: q.x + 1.3, y: q.y, z: q.z + 0.4 }, 12); }
    K.act(eD, "kneel"); K.hold(eD, "potion");   /* 第125版(rs2): 腰の 水筒を 手に */
    await K.csay(p, "r2dolf", ["{smile}……もう 少しの しんぼうだぜ。", "{smile,up}ほら、俺の ぶんだ。ゆっくり 飲めよ。"], eK);
    await K.give(eD, eK, "potion"); K.sound(p, "random.drink", 1);
    await K.ots(p, eD, eK, 8);   /* ドルフの 肩ごしに、水を 飲む 子 */
    await K.say(p, "村の 子", ["{smile,☆}……ありがと、兄ちゃん！"], eD);
    K.act(eD, 0); K.act(eK, 0);
    await K.hsay(p, K.V(["{sad,up}……ドルフさんの ぶんの 水、だったのに。"], ["{sad,up}……自分の 水を、あげちゃった。"], ["{closed,up}……自分の ぶんを、あげた。"], ["{sad,up}……ご自分の 水を、あの子に。"]));
    await K.csay(p, "r2dolf", ["{closed}あしたの 朝、外れの §e配給所§f で 残りの 水を 分ける。……もめなきゃ いいがな。", "{angry,up}旅の もんでも、手を 貸して くれるなら 助かるんだぜ。"], eH);
    K.act(eH, "raise");
    await K.hsay(p, K.V(["{smile,!,up}まかせて！ 水を 分けるの、手伝う！"], ["{smile,up}ええ。お手伝い するわ。"], ["{closed,up}……手伝う。"], ["{smile,up}はい、お手伝い いたします！"]));
    K.act(eH, 0);
    K.pay(p, E1, 150, [["c_water", 2]]);
    K.hold(eK); await K.end(p, { leave: [eD, eK], bye: [v1, v2], card: "§7→ あしたの 朝、ガレキの 外れの 水の 配給所へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 2話 語り部（水の 配給の もめごと・王の 隣の 影の 昔話）---------- */
const E2 = { id: "r2e2", pv: 127, n: 2, t: "語り部", at: 0, ord: 1, place: RATION, fac: "r2ration",
  hint: "§fガレキの 外れの §e水の 配給所§f へ 行こう §7（右上の 案内。ドルフが 水を 分ける。「！」の 目印の そばで 立ち止まろう）",
  syn: "水の 配給所で、村の 人どうしが 桶 半分の 水を めぐって 言い争った。あなたが 間に 入ると、語り部の トキ婆が『王の 隣の 影』の 昔話を 語った。千年前、何もかも 知りたがった 王の 隣に、影のように 寄りそう 友が いた。友は 泣きながら 王を 石板に 封じ、人々は 友を『王殺し』と 呼んで 壁画から 削った――。そこへ 砂ぼこり団の 使いが 来て、頭の 名を 聞いた ドルフの 顔色が かわった。",
  set: { met2: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    const FQ = fac(K, p, "r2ration", "stall", REG, y0);   /* 第125版(fac): 配給所の 屋台（樽・水の 大がま・並ぶ 列）*/
    await K.open(p, "ガレキの 外れの 水の 配給所", "day");
    if (FQ) await K.at(p, FQ, 14, 7, 1.4);
    const eH = K.hero(p), eD = K.cast(p, "r2dolf"); K.act(eD, "raise"); K.hold(eD, "bucket");
    await K.csay(p, "r2dolf", ["{angry,!}並べ、並べ！ 一家に 桶 半分だぜ！"]);
    K.act(eD, 0);
    const eA = K.npcNear(p, "§f村の 男", K.PJ("m6_mason", 8)), eB = K.npcNear(p, "§f村の 女", K.PJ("hanna", 8)); K.hold(eA, "bucket"); K.hold(eB, "bucket");
    await K.say(p, "村の 男", ["{angry,怒}おい！ そっちは 子どもが 二人だろうが、うちは 年寄りが 三人だ！ 半分じゃ 足りねえ！"]);
    K.act(eB, "point");
    await K.say(p, "村の 女", ["{angry,up}子どもの ほうが のどが かわくんだよ！ あんたこそ、きのう 二回 並んでた じゃないか！"], eA);
    K.act(eB, 0);
    if (ok(eA) && ok(eB)) await K.go(eA, nearPt(eA, eB, 1.2), 10, true);   /* 第125版(rs): つめよる */
    await K.two(p, eA, eB, 10);
    await K.say(p, "村の 男", ["{rage,怒,up}なんだと！？"]);
    if (ok(eD) && ok(eA)) await K.go(eD, nearPt(eD, eA, 1.1), 10, true);   /* ドルフが あいだに 割って 入る */
    K.act(eD, "guard");
    await K.csay(p, "r2dolf", ["{angry,!,up}やめろ！ 水の ことで 村が 割れたら、それこそ 砂ぼこり団の 思うつぼだぜ！"]);
    K.act(eD, 0);
    await K.hsay(p, K.V(["{sweat,汗,up}ちょ、ちょっと 待って！ ……わたしに いい 考えが ある！"], ["{sweat,汗}……ねえ、少しだけ 聞いて くれる？"], ["{closed}……二人とも、ちょっと 聞いて。"], ["{sweat,汗}お、お二人とも、少し 聞いて ください！"]));
    let k = 0; try { k = await choose(p, "水の 配給", "§f言い争う 村の 人たち。どう する？", [["§l水筒の 水を みんなに 分ける", ""], ["§l子どもと 年寄りから 先に 並びなおす", ""], ["§l相棒と 井戸の 底を 掘って みる", ""]]); } catch {}
    if (!(k >= 0 && k <= 2)) k = 0;
    if (k === 0) {
      K.act(eH, "give", false); K.hold(eH, "potion"); K.sound(p, "random.drink", 0.8);
      await K.hsay(p, K.V(["{smile,up}わたしの 水筒、まだ 半分 あるの。これも 足して！"], ["{smile,up}わたしの 水筒の 水も、足して ちょうだい。"], ["{closed,up}……水筒の 水。足りない ぶんに 使って。"], ["{smile,up}わたしの 水筒の 水も、お使い ください。"]));
      await K.say(p, "村の 女", ["{shock,…,up}……旅の 人が、自分の 水を……？"]);
      K.act(eH, 0, false); K.hold(eH);
    } else if (k === 1) {
      K.act(eH, "point");
      await K.hsay(p, K.V(["{smile,up}子どもと お年寄りが 先！ 元気な 大人は あと！ それなら けんか しないでしょ？"], ["{smile,up}小さい 子と お年寄りから、先に。……それなら、みんな 納得できるわ。"], ["{closed,up}弱い 人から 先。強い 大人は あと。"], ["{smile,up}お子さんと ご年配の 方から 先に。いかがでしょう？"]));
      await K.say(p, "村の 男", ["{sweat,汗,up}……うちの 年寄りも、先に 入れて もらえるのか。"]);
    } else {
      const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:falling_dust_dragon_egg_particle", 6, 0.5, 0.2); K.sound(p, "dig.sand", 1); await K.push(p, g, 22, 4.2, 1.7); }
      await K.hsay(p, K.V(["{shock,!,up}見て！ 掘ったら、砂が しめってる！ 水は 下に ちゃんと ある！"], ["{shock,!,up}……砂が しめってる。水は、ちゃんと 下を 流れて いるのね。"], ["{shock,!,up}……湿ってる。水脈は 生きてる。"], ["{shock,!,up}砂が しめって います！ 水は、まだ 下に あります！"]));
      K.rmCine(g);
      await K.csay(p, "r2dolf", ["{shock,!,up}……水脈は 生きてる。止められてる だけなんだぜ。"]);
    }
    await K.say(p, "村の 男", ["{sad,…}……悪かった。のどが かわくと、心まで かわいちまう。"]);
    await K.say(p, "村の 女", ["{sad,up}……あたしも、言いすぎたよ。ごめんね。"], eA);
    await Promise.all([out(K, p, eA), out(K, p, eB)]);   /* 第125版(rs2): 桶を 抱えて 別々に 帰って いく */
    /* 語り部 トキ婆 */
    const eT = K.cast(p, "r2toki"); K.act(eT, "hold");
    await K.csay(p, "r2toki", ["{smile}ほっほ……若いのが、うまく 間に 入って くれたんじゃった。"]);
    await K.csay(p, "r2dolf", ["{smile}トキ婆。この 村の 語り部だぜ。"], eT);
    await K.csay(p, "r2toki", ["{closed}水の ことで もめるのを 見ると、古い 昔話を 思い出すんじゃった。", "{?,up}旅の 子。……『王の 隣の 影』の 話を、知っとるかね？"], eH);
    await K.hsay(p, K.V(["{shock,!,up}王の 隣の 影……！ 廃都の 壁画に 描いて あるって、森の 精霊が 言ってた！"], ["{shock,…,up}……廃都の 壁画の、影の 話？"], ["{shock,…,up}……壁画の 影。聞きたい。"], ["{shock,!,up}王の 隣の 影……！ ぜひ、お聞かせ ください。"]));
    K.act(eT, 0); if (ok(eT) && FQ) { await K.go(eT, { x: FQ.x - (FQ.x - c.x) * 0.45, y: y0, z: FQ.z - (FQ.z - c.z) * 0.45 }, 16); K.act(eT, "kneel"); }   /* 第125版(rs2): 配給所の 樽の 前に 腰を おろして 語る */
    await K.csay(p, "r2toki", ["{closed}千年 むかし、グランディアに それは 賢い 王さまが おったんじゃった。", "{closed}王さまの 隣には、いつも 影の ように 寄りそう 友が おったんじゃった。"], eH);
    await K.flashback(p, { label: "§7―― 千年前　廃都 グランディア（トキ婆の 昔話）", tod: "night", ptc: "dust",   /* 第127版: 語り部の 昔話を 絵で */
      actors: { king: { nm: "§6賢い 王さま", job: K.PJ("arca13", 8), at: [4.5, -0.8], look: "fr", hold: "scroll" }, fr: { nm: "§7王の 隣の 友", job: K.PJ("m6_sage", 8), at: [4, 1.1], look: "king" }, m1: { nm: "§7都の 女", job: K.PJ("hanna", 8), at: [7, -2.2], look: "king" } },
      beats: [
        ["narr", "§7千年 むかしの グランディア。王さまは 夜ごと 書庫に こもり、世界の 古い 秘密を 調べて いた。", "king"],
        ["say", "fr", "{sad}……もう 夜明けだ。少し 休め。", "king"],
        ["say", "king", "{closed}あと 一頁だ。これを 読めば、人を 石に する ものの 正体が 分かる。", "fr"],
        ["fx", "ash", [4.5, -0.8, 1.6]], ["act", "king", "stagger"],
        ["narr", "§7……その 夜から、王の 目は 黒く 濁った。都の 人が、一人、また 一人と 石に なりはじめた。", "king"],
        ["act", "m1", "recoil"], ["say", "m1", "{shock,!,up}王さまの 目が……！ 黒い……！", "king"],
        ["go", "fr", [3.6, -0.1], 12],
        ["say", "fr", "{sad,low}……すまない。おまえを、石板の 中へ 封じる。", "king"],
        ["fx", "light", [4.5, -0.8, 1]], ["snd", "beacon.deactivate", 0.6], ["act", "king", "kneel"],
        ["narr", "§7人々は 友を『王殺し』と 呼び、壁画から その 姿を 削りとった。友は 何も 言わず、記録だけを 残して 消えた。", "fr"],
      ] });
    K.act(eT, 0); await K.push(p, eT, 22, 4.2, 1.7);
    await K.csay(p, "r2toki", ["{sad,up}……わしの ばあさまは、こう 言うとったんじゃった。", "{sad,tears,up}『あの 影は、王さまを いちばん 好きじゃった』とな。"]);
    await K.csay(p, "r2dolf", ["{closed}……婆さんの 話は、いつも 悲しいぜ。"]);
    await K.csay(p, "r2toki", ["{smile}語り部の 仕事はな、忘れられた ほうの 話を 語る ことなんじゃった。"]);
    K.act(eH, "hold"); K.hold(eH, "notebook"); await K.push(p, eH, 18, 3.6, 1.1);   /* 第125版(rs2): 手帳に 書く 手もとへ ゆっくり 寄る */
    await K.hsay(p, K.V(["{sad}……友だちを 封じるなんて、どんな 気持ちだったんだろう。", "{closed}手帳に 書いとく。『王の 隣の 影・何でも 知りたがった 王さま』。"], ["{sad}……大好きな 人を 封じるなんて。", "{closed}手帳に 書いて おくわ。『王の 隣の 影・知りたがりの 王さま』。"], ["{closed}……友が 王を 封じた。名前は 削られた。", "{closed}メモ。『王の 隣の 影・知りすぎた 王』。"], ["{sad}……ご友人を 封じるなんて、どれほど おつらかったか。", "{closed}手帳に 記して おきます。『王の 隣の 影・知りすぎた 王さま』。"]));
    K.act(eH, 0);
    K.act(eT, "show"); K.hold(eT, "scroll"); K.hold(eH);
    await K.narr(p, ["§7トキ婆が、古い 布を 広げた。壁画を 写した 絵の すみに、§f仮面を つけた 近衛兵§7が いる。"], eT);
    await K.csay(p, "r2toki", ["{closed,up}仮面の 近衛は、妃さまを 守る 役目だった……と、伝わっとるんじゃった。"], eH);
    await K.pull(p, K.S(p) && K.S(p).Cn, 34);
    await K.csay(p, "r2toki", ["{closed}城の 王さまたちは、それぞれ 神さまの 石板を 預かって いる。", "{closed}むやみに 人に 見せては ならぬ 決まり なんじゃった。", "{sad}……わしにも わけは 分からん。ばあさまの 口ぐせじゃった。"]);   /* 第124版(合議 C): クリア後の「王冠」の 話は ここでは 出さない */
    K.act(eT, 0);
    await K.csay(p, "r2toki", ["{sad}……そう いえば 十年 ほど 前、近衛の 家の 若い 衆が、ひどい やけどを 仮面で 隠して、村を 出て いったんじゃった。", "{closed}あの 若い 衆も、何かを 知って しもうた 顔を しておったんじゃった。"]);
    /* 砂ぼこり団の 使い */
    K.sound(p, "mob.pillager.idle", 1);
    const eM = K.npcNear(p, "§c砂ぼこり団の 使い", K.PJ("noxa", 9));
    await K.low(p, eM, 12);
    await K.say(p, "砂ぼこり団の 使い", ["{smile,low}よう、自警団。今月の 水の 代金、まだ だよな？", "{angry}頭の §6バルガ§f が 言ってたぜ。『ドルフに よろしく』ってな。"]);
    await K.ots(p, eM, eD, 8);   /* 第125版(rs2): 使いの 肩ごしに ドルフ（だれに 言ったか）*/
    if (ok(eD) && ok(eM)) await K.approach(p, eD, eM, 2.4);   /* 第125版(rs2): ドルフが 使いに 一歩 つめよる */
    await K.up(p, eD, 12);
    await K.csay(p, "r2dolf", ["{shock,…,up}…………バルガ、だと。"]);
    await K.say(p, "砂ぼこり団の 使い", ["{sweat,汗}な、なんだよ その 顔……。と、とにかく 伝えたからな！"]);
    await out(K, p, eM, true);
    K.act(eD, "guard");
    await K.hsay(p, K.V(["{?}……ドルフさん、バルガって 人、知ってるの？ さっきから 手が ふるえてる。"], ["{?}……ドルフさん。その バルガって 人を、知って いるの？"], ["{?}……バルガ。知り合い？ 顔色が 変わった。"], ["{?}……ドルフさん。バルガという 方を、ご存じなのですか？"]), eD);
    await K.csay(p, "r2dolf", ["{closed}……昔、同じ 鍋の 飯を 食った やつと、同じ 名前だぜ。", "{sad,low}同じ 名前の 別人なら、いいんだがな。"], eH);
    await K.csay(p, "r2dolf", ["{angry,up}……水門へ 行くぜ。今度こそ、話を つけるんだぜ。"]);
    await K.hsay(p, K.V(["{angry,!,up}わたしたちも 行く！"], ["{closed,up}……一緒に 行くわ。"], ["{angry,up}……行く。"], ["{angry,up}お供 いたします！"]));
    K.act(eD, 0);
    K.pay(p, E2, 200, [["c_water", 2], ["gift_candle", 1]]);
    await K.end(p, { leave: [eD, eT], card: "§7→ 涸れ谷の 水門へ。砂ぼこり団の 頭と 話を つけに（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 3話 涸れ谷の 水門（砂ぼこり団・頭 バルガ）---------- */
const E3 = { id: "r2e3", n: 3, t: "涸れ谷の 水門", at: 0, ord: 2, place: GATE, fac: "r2gate",
  hint: "§fガレキの 外れの §e涸れ谷の 水門§f へ 行こう §7（右上の 案内。砂ぼこり団が 水を 止めて いる。「！」の 目印の そばで 立ち止まろう）",
  syn: "涸れ谷の 水門で 砂ぼこり団を 退けると、頭の バルガが 現れた。バルガは ドルフの 昔の 相棒。若い ころ、二人で 盗んだ 水を 乾いた 村々に 配って 回った 仲だった。「俺の 町は 石に なった。逃げて きた 仲間 四十人に、飲ませる 水が いる」。勝負の あと、バルガは「三日 だけ、ガキどもの ぶんだ」と、水門を 半分 開けた。",
  set: { barga1: 1, met2: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    const gq = fac(K, p, "r2gate", "sluice", REG, y0) || { x: c.x + 10, y: y0, z: c.z - 3 };   /* 第125版(fac): 石の 塔と 門・乾いた 水路の 水門（ワールドに 1回）*/
    await K.open(p, "ガレキの 外れ 涸れ谷の 水門", "day");
    K.sound(p, "liquid.water", 0.6);
    await K.at(p, gq, 14, 8, 1.5);
    await K.narr(p, ["§7谷を せき止めた 古い 水門。板と 鎖で ふさがれ、奥から 水音だけが 聞こえて くる。"], gq);
    let eH = K.hero(p), eD = K.cast(p, "r2dolf");
    const eA = K.npcNear(p, "§c砂ぼこり団の 手下", K.PJ("noxa", 9)), eA2 = K.npcNear(p, "§c砂ぼこり団の 見張り", K.PJ("noxb", 9));
    K.act(eA, "guard"); K.act(eA2, "point");
    await K.say(p, "砂ぼこり団の 手下", ["{angry}止まれ！ ここから 先は 砂ぼこり団の 水場だ！"]);
    if (ok(eD) && ok(eA)) await K.approach(p, eD, eA, 2.2); K.act(eD, "guard");   /* 第125版(rs2): ドルフが 見張りの 前へ 出る */
    await K.csay(p, "r2dolf", ["{angry,up}頭を 出せ。……バルガを 出せって 言ってるんだぜ！"], eA);
    await K.say(p, "砂ぼこり団の 見張り", ["{smile,low}頭に 会いたきゃ、俺たちを 越えて いきな！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,怒,up}越えて いくよ！ 村の 水、返して もらう！"], ["{angry,up}……通して もらうわ。"], ["{angry,up}……越える。"], ["{angry,up}押し通らせて いただきます！"]));
    if (!K.flag(p, "r2e3a")) {
      const r = await K.battle(p, K.team(["beast", "golem"], 16, 3), { name: "砂ぼこり団の 手下", arena: "涸れ谷の 水門", theme: "ruins", speaker: "砂ぼこり団の 手下", lines: { half: "こ、こいつ 強え……！", low: "か、頭ぁーっ！" } });
      if (r !== "win") return lose(K, p, "§c砂ぼこり団の 手下", K.PJ("noxa", 9), "砂ぼこり団の 手下", "{smile}へっ、出直して きな。水は 一滴も やらねえよ。");
      K.setFlag(p, "r2e3a");
    }
    eH = K.hero(p, false); eD = K.cast(p, "r2dolf", true);
    { const a = K.npcNear(p, "§c砂ぼこり団の 手下", K.PJ("noxa", 9), true), b = K.npcNear(p, "§c砂ぼこり団の 見張り", K.PJ("noxb", 9), true); K.act(a, "recoil"); await Promise.all([out(K, p, a, true), out(K, p, b, true)]); }
    /* 頭 バルガ */
    K.sound(p, "mob.ravager.roar", 0.8, 0.5); K.shake(p, 0.2, 0.3);
    const eB = K.npcNear(p, "§c砂ぼこり団の 頭 バルガ", K.PJ("m6_grant", 9));
    await K.low(p, eB, 16);
    await K.ots(p, eD, eB, 8);   /* 第125版(rs2): ドルフの 肩ごしに バルガ（昔の 相棒に 言う）*/
    await K.csay(p, "r2barga", ["{smile,low}……でかく なったじゃ ねえか、ドルフ。", "{angry}自警団長だと？ 笑わせる。……盗賊が、だろうが。"], eD);
    await K.approach(p, eD, eH, 1.9); await K.push(p, eD, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "r2dolf", ["{angry,!,up}バルガ……！ なんで おまえが、村の 水を 止めてやがるんだ！"], eB);
    await K.hsay(p, K.V(["{shock,!,up}え、二人 知り合いなの！？"], ["{shock,…,up}……知り合い、なの？"], ["{shock,…,up}……知り合い？"], ["{shock,!,up}お、お知り合い なのですか！？"]));
    await K.csay(p, "r2dolf", ["{sad,up}……昔の 相棒だぜ。盗賊だった ころのな。"]);
    if (ok(eD) && ok(eB)) K.turn(eD, eB.location);
    await K.flashback(p, { label: "§7―― 十年前　乾いた 村の 外れ", tod: "dusk", ptc: "dust",   /* 第127版: 二人の 昔を 絵で */
      actors: { d: { nm: "§e若い ドルフ", job: K.PJ("m6_mason", 8), at: [3, -1], look: "b", hold: "bucket" }, b: { nm: "§c若い バルガ", job: K.PJ("m6_grant", 9), at: [3.4, 1.1], look: "d", hold: "bucket" }, k: { nm: "§7乾いた 村の 子", job: 6, at: [5.6, -0.4], look: "d" } },
      beats: [
        ["narr", "§7十年前。二人の 若い 盗賊が、金持ちの 隊商から 盗んだ 水を 運んで いた。", "b"],
        ["say", "b", "{smile,up}樽 二つ、いただきだ。……急ぐぞ、ドルフ。乾いた 村は 待って くれねえ。", "d"],
        ["go", "d", [4.8, -0.6], 12], ["act", "d", "give"],
        ["say", "k", "{smile,up}……みず！", "d"],
        ["say", "d", "{smile}ほらよ。ゆっくり 飲め。", "k"],
        ["act", "d", 0],
        ["say", "b", "{closed}次は 東の 村だ。夜明けまでに、あと 三つ 回る。", "d"],
        ["face", "d", "b"],
        ["say", "d", "{closed}……バルガ。おれは、ガレキに 残る。井戸を 守る やつが 要る。", "b"],
        ["say", "b", "{angry,low}……好きに しな。おれは 砂漠を 行く。", "d"],
        ["go", "b", [10, 2], 24],
        ["narr", "§7それきり、二人は 会わなかった。", "d"],
      ] });
    await K.csay(p, "r2barga", ["{angry,up}俺の 町は 石に なった。逃げて きた 仲間は 四十人。", "{rage,怒,up}そいつらに 飲ませる 水が いるんだろうが！"], eD);
    if (ok(eB)) K.turn(eB, K.fwd(p, 20, 6));   /* 背を 向ける */
    await K.csay(p, "r2barga", ["{closed}……村に 残った おまえに、わかるもんか。"]);
    K.turn(eB); K.turn(eD);
    await K.push(p, eD, 22, 4.2, 1.7); K.act(eD, "point");
    await K.csay(p, "r2dolf", ["{rage,怒,up}わかるかよ！ ガキが からの 桶 抱えて、泣いてんだぜ！", "{angry,tears,up}……昔の おまえなら、それを いちばん 嫌ったんだぜ！"]);
    K.act(eB, "guard");
    await K.csay(p, "r2barga", ["{rage,怒,up}だまれ！！", "{angry,low}……力で 来い。勝った ほうが 水を 決める。それが 砂漠の やり方だろうが。"], eH);
    if (ok(eD) && ok(eB)) { const A = eD.location, B = eB.location, n = Math.hypot(B.x - A.x, B.z - A.z) || 1; if (n > 2.2) await K.go(eD, { x: A.x + (B.x - A.x) / n, y: A.y, z: A.z + (B.z - A.z) / n }, 6); }   /* 一歩 つめよる */
    await K.hsay(p, K.V(["{angry,!,up}……いいよ。勝って、話を 聞いて もらう！"], ["{closed,up}……分かったわ。勝って、話を 聞いて もらう。"], ["{angry,up}乗った。勝ったら、話を 聞け。"], ["{angry,up}……お受け します。勝って、お話を 聞いて いただきます！"]));
    if (!K.flag(p, "r2e3w")) {
      await K.duel(p, "§6§l涸れ谷の 決闘", "§fバルガの 砂嵐が 吹き荒れる！", { fams: ["beast"] });
      const lv = 18;
      const r = await K.battle(p, K.team(["beast", "sword", "golem"], lv, 3, 12, K.leadOf("beast", lv)), { name: "砂ぼこり団の 頭 バルガ", arena: "涸れ谷の 水門", theme: "ruins", hpk: 2.5, extra: 0.2, sboss: true, speaker: "バルガ", lines: { half: "やるじゃ ねえか……ドルフの 隣に いる だけは あるだろうが！", low: "……くそ、四十人の 水が……！" } });
      if (r !== "win") return lose(K, p, "§c砂ぼこり団の 頭 バルガ", K.PJ("m6_grant", 9), "バルガ", "{closed}……水は 渡せねえ。出直して こいって 言ってんだろうが。");
      K.setFlag(p, "r2e3w");
    }
    eH = K.hero(p, false); eD = K.cast(p, "r2dolf", true);
    const eB2 = K.npcNear(p, "§c砂ぼこり団の 頭 バルガ", K.PJ("m6_grant", 9), true); K.act(eB2, "kneel");
    await K.csay(p, "r2barga", ["{sad,…}……ちっ。昔から、おまえの 隣の やつには 勝てねえんだ。"]);
    K.act(eB2, 0);
    await K.csay(p, "r2dolf", ["{closed,up}……バルガ。水門を 開けろ。おまえの 仲間の ぶんも、村で なんとか するんだぜ。"], eB2);
    await K.csay(p, "r2barga", ["{angry,no}……できるかよ。四十人だぞ。村の 井戸 一つで、足りるわけ ねえだろうが。", "{sad,low}開けたら、今度は 俺の 仲間が 干上がる。"], eD);
    await K.hsay(p, K.V(["{?,up}……水が 足りないなら、ほかの 水を さがせば いいんじゃない？"], ["{?,up}……ほかに、水の ある 場所は ないの？"], ["{?,up}……水源を 増やせば いい。あては？"], ["{?,up}……ほかに、水を 得る 道は ないのでしょうか？"]));
    await K.csay(p, "r2dolf", ["{closed}……廃都の 城には、昔の 水路が あるって 話だぜ。地方マスターの ジンが 城を 守ってる。"]);
    await K.csay(p, "r2barga", ["{closed}……城の 連中が、砂ぼこりの 頼みなんざ 聞くかよ。"]);
    if (ok(eB2) && gq) { await K.walkCam(p, eB2, beside(eB2, gq, 3, 2.6), 18); K.turn(eB2, gq); K.act(eB2, "work"); }   /* 第125版(rs2): バルガが 水門の 鎖の 前へ 歩き、背を 向けた まま */
    await K.push(p, eB2, 20, 4.5, 1.6);
    await K.csay(p, "r2barga", ["{closed,low}……水門は、三日 だけ 半分 開けて やる。", "{sad,up}……ガキどもの ぶんだ。勘違い すんじゃねえぞ。わかってんだろうが。"]);
    K.act(eB2, 0); K.turn(eB2);
    K.sound(p, "bucket.empty_water", 1); K.sound(p, "liquid.water", 1);
    facState("r2gate", 1);   /* 門が 上がり、手前の 水路に 水が 少し */
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, gq, "minecraft:water_splash_particle", 10, 1.2, 0.3); await K.wait(4); }
    await K.at(p, gq, 12, 5, 1.2);
    { const w = out(K, p, eB2, false); await K.csay(p, "r2dolf", ["{smile,tears,up}……バルガ。"]); await w; }   /* 去って いく 背中に 向けて 言う */
    await K.hsay(p, K.V(["{smile,up}……あの人、ほんとは やさしいんだね。"], ["{smile,up}……やさしい 人なのね、本当は。"], ["{closed,up}……悪い 人じゃ ない。"], ["{smile,up}……本当は、おやさしい 方なのですね。"]));
    await K.csay(p, "r2dolf", ["{closed}……ああ。昔から、そういう やつなんだぜ。", "{angry,up}廃都の 城の ジンに 会ったら、水路の こと、聞いて みて くれ。たのむぜ。"], eH);
    K.pay(p, E3, 300, [["c_water", 3], ["e_beast1", 1]]);
    await K.end(p, { leave: [eD], card: "§7→ 廃都の 手前の 崖道へ。壁画と ジンの 城を めざそう（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 5話 水が 戻る（ジンに 勝った あと。井戸が 戻り、ドルフと バルガが 和解。村の 発展度・祭り）---------- */
const E5 = { id: "r2e5", pv: 127, n: 5, t: "水が 戻る", at: 2, ord: 0, place: WELL,
  hint: "§fガレキの 外れの §e古井戸§f へ もどろう §7（右上の 案内。ジンの 伝言「古井戸で 待て」。ドルフが 呼んで いる。「！」の 目印の そばで 立ち止まろう）",
  syn: "ジンが 廃都の 城の 古い 水路を 開け、ガレキと 涸れ谷の 両方に 水が 届いた。バルガは 水門を すべて 開け、ドルフに「悪かったな」と 頭を 下げた。「おかえりだぜ、相棒」。枯れた 古井戸に 水が あふれ、村では 井戸の 祭りが 開かれた。トキ婆は「王の 隣の 影も、いつか だれかに『おかえり』と 言って もらえると ええ」と 笑った。",
  set: { fest2: 1, met2: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest2: 1 }; },
  fx: { xp: [TID, 160], fest: TID },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), C = { x: c.x, y: y0, z: c.z };
    well(K, p, c, y0, 1); K.deco(p, "t5fest", 1, c, y0);
    await K.open(p, "ガレキの 外れの 古井戸", "day");
    const eH = K.hero(p), eD = K.cast(p, "r2dolf");
    await K.csay(p, "r2dolf", ["{shock,!,up}おい、聞こえるか……！ 井戸の 底から、水の 音が するんだぜ！"]);
    const wq = WQ(c, y0);
    K.sound(p, "liquid.water", 1); K.shake(p, 0.2, 0.5);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, wq, "minecraft:water_splash_particle", 8, 0.6, 0.6 + i * 0.4); await K.wait(4); }
    if (ok(eD)) await K.walkCam(p, eD, nearPt(eD, { location: wq, isValid: () => true }, 1.3) || wq, 14, true);   /* 第125版(rs): 井戸へ かけよる */
    await K.at(p, wq, 12, 3.5, 1);
    well(K, p, c, y0, 2); facState("r2gate", 2); K.act(eD, "kneel"); K.hold(eD, "bucket");   /* 第125版(fac): 涸れ谷の 水路にも 水（遠い ときは だれかが 近くに 来た とき）*/
    K.sound(p, "bucket.fill_water", 1);
    for (let i = 0; i < 4; i++) { K.burst(p.dimension, wq, "minecraft:water_splash_particle", 12, 1, 1); await K.wait(3); }
    await K.hsay(p, K.V(["{shock,☆,jump,up}水だ……！ 井戸に 水が あふれてる！！"], ["{smile,tears,up}……水。井戸に、水が 戻ったわ……！！"], ["{shock,!,up}……水。戻った！！"], ["{shock,☆,up}み、水です！ 井戸に 水が……！！"]));
    const eJ = K.cast(p, "r2jin"); K.act(eJ, "hold");
    if (ok(eJ)) { await K.go(eJ, beside(eJ, wq, 2, 1.2), 14); K.turn(eJ, wq); }   /* 第125版(rs2): ジンが 井戸の ふちへ 歩いて 水を 見おろす */
    await K.low(p, eJ, 12); K.turn(eJ);
    await K.csay(p, "r2jin", ["{closed}……城の 古い 水路を 開けた。廃都の 地下を 通って、この 村と 涸れ谷の 両方に 水が 届く。", "{sad}石に なった 都の 水だ。……だれかが 飲んで くれた ほうが、都も よろこぶ。"], eD);
    await K.csay(p, "r2dolf", ["{shock,…,up}……地方マスターの ジンが、わざわざ……。"]);
    await K.csay(p, "r2jin", ["{closed}礼なら、この 子に 言え。……勝った あと、水路の ことを 頭を 下げて 頼んで きた。"], eH);
    K.act(eJ, 0);
    await K.hsay(p, K.V(["{smile,汗,up}えへへ……ドルフさんに たのまれてたから！"], ["{smile,up}……約束、だったもの。"], ["{closed,up}……約束した。それだけ。"], ["{smile,up}ドルフさんとの お約束 でしたから。"]));
    /* バルガ */
    const eB = K.cast(p, "r2barga"); K.act(eB, "hold");
    await K.csay(p, "r2barga", ["{closed}……水門は、全部 開けた。"]);
    await K.csay(p, "r2dolf", ["{shock,!,up}バルガ……！"]);
    if (ok(eB) && ok(eD)) await K.approach(p, eB, eD, 2.2); await K.ots(p, eD, eB, 10);   /* 第125版(rs2): バルガが 歩み寄る（ドルフの 肩ごしに バルガ）*/
    await K.csay(p, "r2barga", ["{sad,up}城から 水が 来た。もう、だれからも 取らなくて いい。", "{closed,low}……悪かったな、ドルフ。ガキどもにも。"], eD);
    await K.approach(p, eD, eH, 1.9); await K.push(p, eD, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "r2dolf", ["{smile,tears,up}……ばか やろう。遅いんだぜ。"]);
    { const q = nearPt(eD, eB, 1.2); if (q) await K.go(eD, q, 10); } K.act(eD, 23); K.act(eB, 23);   /* 抱き合う */
    await K.two(p, eD, eB, 10);
    await K.csay(p, "r2dolf", ["{smile,tears,up}……おかえりだぜ、相棒。"], eH);
    await K.csay(p, "r2barga", ["{smile,tears,up}……ああ。ただいま、だろうが。"]);
    K.act(eD, 0); K.act(eB, 0);
    const eT = K.cast(p, "r2toki"); K.act(eT, "hold");
    await K.push(p, eT, 20, 4.2, 1.6);   /* 第125版(rs2): 語り部の 言葉は ゆっくり 寄る */
    await K.csay(p, "r2toki", ["{smile}ほっほ……水と 一緒に、古い 友も 戻って きたんじゃった。", "{closed,up}王の 隣の 影も、いつか だれかに『おかえり』と 言って もらえると、ええのう。……ばあさまも、そう 言うとったんじゃった。"], eH);
    /* 井戸の 祭り */
    K.deco(p, "t5fest", 2, c, y0);
    for (const e of [eD, eB, eT, eH]) K.act(e, 9);
    K.ambient(p, "fest", C); K.sound(p, "note.pling", 0.8); K.sound(p, "note.harp", 0.8);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, wq, "minecraft:water_splash_particle", 10, 1.4, 1.2); await K.wait(4); }
    await K.pull(p, K.S(p) && K.S(p).Cn, 34);
    for (const e of [eD, eB, eT, eH]) K.act(e, 0);
    await K.csay(p, "r2jin", ["{closed,up}……鞘は 持って いるな。この 村の 水も、石板と 一緒に 守れ。"], eH);
    await K.hsay(p, K.V(["{smile,!,up}うん！ まかせて！"], ["{smile,up}ええ。きっと。"], ["{closed,up}……守る。"], ["{smile,up}はい、必ず。"]));
    K.act(eD, "hold"); K.hold(eD, "potion");
    await K.csay(p, "r2dolf", ["{smile}これは 村の 名物だぜ。持って いけ。"], eH);
    await K.give(eD, eH, "potion");
    const got = K.pay(p, E5, 600, [["mei_ruins", 2], ["c_water", 3]]);
    if (got.length) K.big(p, "§6§lガレキの おくりもの", `§e${got.join("・")}`);
    K.act(eD, 0);
    await K.hsay(p, K.V(["{smile,tears,up}……ありがとう、ドルフさん、バルガさん！"], ["{smile,tears,up}……ありがとう。いい 村ね。"], ["{smile,up}……ありがとう。また 来る。"], ["{smile,tears,up}……ありがとう ございました！"]));
    await K.csay(p, "r2dolf", ["{smile,up}いって らっしゃいだぜ！ 次に 来る ときは、井戸の 水で 乾杯だぜ！"]);
    await K.end(p, { leave: [eJ], bye: [eD, eB, eT], card: "§f― 第3章 廃都の 壁画 おわり ―\n§7→ 次は ヴォルカ火山帯の ようがんの 里 ラヴィの 外れの 鍛冶場へ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(2, [E1, E2, E3, E5], { steps: { 0: [4, "壁画（崖道 → 壁画の 広間 → ジンの 城）"], 1: [5, "水が 戻る（ジンとの 勝負）"] } });
