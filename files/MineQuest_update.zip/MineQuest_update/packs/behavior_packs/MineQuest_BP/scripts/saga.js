// v2.8: 物語の 冒険（地方の 関所・メインクエスト・だいじなもの・NPCの からみ・ライバル・共闘・裏切り）
// ・メインクエストは 1本道（s.mq）。手順が まだ 来ていない できごとは 起きないので、ワープしても 矛盾しない
// ・地方は「その 地方の 主」を 倒すと 次が 開く。それまでは「まだ やるべき ことが あるようだ、引き返そう」
/* 第122版: 物語の 印（qs(d)）のうち ほかの ファイルも 読む もの
   hakuStone  第10章で オルドの 相棒 ハクが 石に なった（オルドは 生きて いる。前の 版の ordoDead は 読みこみ時に これへ 置きかえる）
   ordoMask   せいかんカップで 仮面の 王者が オルドだと 分かった（cupScene）
   nagiDead   ナギサが 港の マスターを 退いた ／ yomiStone ヨミが 石に なった ／ rouDead 双子が 連れ去られた
   theoBetray・theoSaved・reiFinal・ch10b など 段の 印は MQ の 中を 見る */
import { world, system, ItemStack, MolangVariableMap } from "@minecraft/server";
import { talk, tell, setSpeakerFinder, clearSkip, establish, camFade, lookAt, camAt, scenePause, sceneResume, inScene, cineCard, cineSting, cineFx, mood, boxLine, fadeOn, openWide, closeWide, fadeHide, fadeTry, fading, sceneTime } from "./talk.js";
import { findStage, goodStand, stageBegin, stageEnd, stageMove, stageNow, stageOf, stageFor, slotOf, addActor, freeNear, freeAt, walkFrom, clampPath, stagePt, standY, walkIn as walkIn0, smokeIn as smokeIn0, smokeOut, exitPt, arrive, destOf, inCam } from "./stagecore.js";   /* 第123版: 場面の 舞台 */   /* 第108版: 会話は フォームで 止めない */
import { SPECIES, ORDER, ITEMS, BOSS_SLAB } from "./data.js";
import { load, save } from "./store.js";
import { busy, ok, wait, notice, confirm, sound, particle, giveItem, countItem, gold, seedId, takeItem, barNote, showTitle, setJob, bagAdd, anim, pillar, lockKeys, KEYH, bagLoad, bagSave } from "./ui.js";
import { WREGIONS, regionIdx, regionLv, landSites, LAYOUT } from "./worldmap.js";
import { townAt, homeInfo, landInfo, unstuckNpc, groundY, castleInfo, castleSpot, TOWNS, townPos, caveInfo, CAVE_R, caveSite, caveBox, CAVE_V, caveName, CAVE_NO, inCaveBox, getTown, siteOf, getRuin, REGION, ruinBlocked } from "./structures.js";
import { qs, syncQuest, postOpen, BS_N, RUIN_SLAB } from "./quest.js";
import { fight } from "./story.js";
import { calcStats, canFight } from "./core.js";
import { underwater, waterDepth, hooks, setLook, lookOf, TYPE as MON_TYPE } from "./field.js";
import { nearAltar, dreamFlow, altarInfo, rfInfo } from "./postgame.js";
import { musashiTownInfo } from "./majin.js";
import { duel } from "./cine.js";   /* 第106版: 山場の モンスター同士の 演出 */
import { PSKIN } from "./skinjobs.js";
import { skinNo, namedJob } from "./namedskin.js";
import { face as dFace, emote as dEmote } from "./direct.js";   /* 第121版: だまった ままの 表情・マーク */
import { partnerEditor, findPartner, baseOf, simpleLook } from "./partner.js";
import { choose, ICON, hudSend, hudQueued, TITLE_T } from "./ui.js";
import { placeOf, PLACES, SPOT_V, ranchSpot, ranchSave, spotOf, townOut } from "./storyplace.js";
import { decorPlace } from "./storyplace.js";
import { CAST_HOOK } from "./cast.js";
import { hold as hold0 } from "./hold.js";
import { facAt, facCur, facSide, facFront, facBuild, facMark, facState } from "./epfac.js";   /* 第125版(vk): 岬の 灯台 */
import { wl } from "./wqlore.js";   /* 第125版: 世界の 依頼を 済ませた 人だけの 一言（済んで いなければ 場面は 今と 同じ）*/
import { IH, SIXMV } from "./intro126.js";   /* 第126版: 六影・十魔将の 登場の 演出 */
const epD = (d, id) => { try { return !!(d && CAST_HOOK.done && CAST_HOOK.done(d, id)); } catch { return false; } };   /* 第124版: 地方の 話が 済んだか（台詞の 出し分け）*/   /* 第122版: 場面の 場所 */
const PJ = (k, d) => skinNo(k, d);   /* 第106版: 人物の スキンの 番号。第126版(fix): 別名（rei・bandit など）も 見る */
/* 第106版: 相棒の 名前（相棒が いなければ 先頭の 子） */
function palNm(p) { try { const d = load(p); const m = [...(d.party || []), ...(d.bench || []), ...(d.box || [])].find((x) => x && (x.id === d.partnerId || x.partner || x.look)) || d.party[0]; return m ? (m.nm || SPECIES[m.sp]?.name || "相棒") : "相棒"; } catch { return "相棒"; } }

const SP = () => { try { const w = world.getDefaultSpawnLocation(); return { x: w.x, y: w.y, z: w.z }; } catch { return { x: 0, y: 64, z: 0 }; } };
export const regAt = (loc) => { const s = SP(); return regionIdx(loc.x - s.x, loc.z - s.z); };
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const ri = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const RN = (r) => WREGIONS[r]?.name || "";

// ---------- 地方の 関所 ----------
// 地方 r を こえるための 目標（その 地方の 主）
const RGOAL = [
  { t: (s) => s.bs.includes(0), h: () => `アルカトラス城の 地方マスターに 勝ち、「${BOSS_SLAB[0]?.name}」の 主を 封印する` },
  { t: (s) => !!(s.gate && s.gate[1]), h: () => "シルヴァ大森林の「森の 主」を しずめる（セオと 共闘）" },
  { t: (s) => s.bs.includes(2), h: () => `ルインズ荒野の 地方マスターに 勝ち、「${BOSS_SLAB[2]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(4), h: () => `ヴォルカ火山帯の 地方マスターに 勝ち、「${BOSS_SLAB[4]?.name}」の 主を 封印する` },
  { t: (s) => !!(s.gate && s.gate[4]), h: () => "サンドリア砂漠の「王墓の 主」を 倒す（レイと 共闘）" },
  { t: (s) => s.bs.includes(6), h: () => `クリスタリアの 地方マスターに 勝ち、「${BOSS_SLAB[6]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(8), h: () => `マリノア諸島の 地方マスターに 勝ち、「${BOSS_SLAB[8]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(10), h: () => `ネクロス冥府領の 地方マスターに 勝ち、「${BOSS_SLAB[10]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(12), h: () => `フロストヘイムの 地方マスターに 勝ち、「${BOSS_SLAB[12]?.name}」の 主を 封印する` },
  { t: (s) => s.bs.includes(13), h: () => `ラグナの 地方マスターに 勝ち、「${BOSS_SLAB[13]?.name}」の 主を 封印する` },
];
// どこまで 行けるか（後の 目標を 果たしていれば、前の 地方も すべて 開く）
function sealOpen(s) { for (let j = RGOAL.length - 1; j >= 0; j--) if (RGOAL[j].t(s)) return j + 1; return 0; }
// v2.9.13: 物語の 順番（いまの 段の 地方より 先へは 行けない。フラグを 飛ばせない ように）
function storyOpen(s) { const st = MQ[s.mq ?? 0]; return !st || st.r === 99 ? 99 : st.r; }
export function openUpTo(d) {
  const s = qs(d);
  if (s.ending || s.gateFree) return 99;
  const u = sealOpen(s);
  return s.ord ? Math.min(u, storyOpen(s)) : u;
}
// その 地方マスターに 挑める 段まで 物語が 進んで いるか
const wonOf = (p, k) => { const x = load(p); return !!(x && qs(x)["w_" + k]); };   /* 第106版: 勝った 戦いは やり直しで くり返さない */
const setWon = (p, k) => { const x = load(p); if (x) { qs(x)["w_" + k] = 1; save(p, x); } };
export function sealReady(d, si) { const s = qs(d); if (!s.ord || s.ending) return true; const k = MQ.findIndex((x) => x.seal === si); if (k >= 0 && EP_HOOK.block && EP_HOOK.block(d, k)) return false; return k < 0 || (s.mq ?? 0) >= k; }   /* 第125版: 地方の 新しい 話（sagaep.js）が 先 */
export const MQ_OVR = {};   /* 第126版: 章ファイルが MQ 段 i の run を 差しかえる（bkeng.js の mqOver が 入れる。saga.js は 書きかえない）*/
export const EP_HOOK = {};   /* 第125版: 地方の 5話（sagaep.js が 入れる）。step・hint・block・skip・held・retry・fix・reset・syn */
export function palLocked(d) { try { const s = qs(d); if (s.palMet || s.ending) return false; const k = MQ.findIndex((x) => x.spot === garoSpot || /北の 門§f を 出て/.test(x.hint || "")); return k >= 0 && (s.mq ?? 0) <= k; } catch { return false; } }   /* 第115版: 相棒は ガロの 場面で 出会う */
export function storyNowHint(d) { try { const eh = EP_HOOK.hint && EP_HOOK.hint(d); if (eh) return eh; } catch {} const s = qs(d); const st = stOf(s); return st ? hintOf(st, d) : ""; }
hooks.openUpTo = (d) => openUpTo(d);   // v2.9.12: 物語の 場所を 先に 作る 範囲
export const regionOpen = (d, r) => r <= openUpTo(d);
export const gateHint = (d) => { const u = openUpTo(d), s = qs(d); if (u >= RGOAL.length || u >= 99) return null; if (s.ord && storyOpen(s) < sealOpen(s)) return `§7（${RN(u + 1)}へ 行くには、まず 物語を 進めよう: ${String(storyNowHint(d)).replace(/§./g, "")}）`; return `§7（${RN(u + 1)}へ 行くには: ${RGOAL[u].h()}）`; };

// ---------- だいじなもの ----------
/* 第125版: だいじなものは セーブ（s.keys）だけに ある。持ち物・バッグには 入れない（落とす・渡す・ふえる が おきない。人ごと）*/
const keysOf = (d) => { const s = qs(d); return Array.isArray(s.keys) ? s.keys : (s.keys = []); };
export const hasKey = (p, id) => { const d = load(p); return !!d && keysOf(d).includes(id); };
export const KEYSRC = [], KEYRT = new Set();   /* 前の 版で 済ませた 場面の だいじなもの（sagaep.js・wq.js が (d) => [id] を 入れる）*/
KEYH.has = hasKey;
KEYH.add = (p, id) => { const d = load(p); if (!d || !ITEMS[id]) return; const L = keysOf(d); if (!L.includes(id)) { L.push(id); save(p, d); } };
KEYH.del = (p, id) => { const d = load(p); if (!d) return false; const s = qs(d), L = keysOf(d); if (!L.includes(id)) return false; s.keys = L.filter((k) => k !== id); save(p, d); return true; };
KEYH.list = (p) => { const d = load(p); return d ? keysOf(d).filter((k) => ITEMS[k]?.kind === "key") : []; };
function giveKey(p, d, id) {
  const s = qs(d); s.keys = [...new Set([...keysOf(d), id])];
  try { showTitle(p, " ", { subtitle: `§6だいじなもの「${ITEMS[id]?.name}」を 手に入れた！`, fadeInDuration: 5, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
  sound(p, "random.levelup", 1.2);
  try { if (!s.keyTip) { s.keyTip = 1; p.sendMessage("§7だいじなものは ガイドブック ＞ 道具・装備 ＞【だいじなもの】に しまわれる（持ち物には 入らない）"); } } catch {}
}
/* 第125版: 場面の 中で 渡す。渡す 人が 小道具を 持って 手渡し → 記録だけ。もう 持って いれば 何も しない */
async function keyHand(p, id, giver = null, prop = 0) {
  if (!ITEMS[id] || hasKey(p, id)) return false;
  if (giver && prop && ok(giver)) await give(giver, null, prop, 12);
  const d = load(p); if (!d) return false; giveKey(p, d, id); save(p, d); return true;
}
/* 前の 版の 持ち物・バッグの だいじなもの を データへ うつす（なくさない・ふやさない）*/
function migrateKeys(p, d) {
  const s = qs(d), got = []; let moved = 0;
  try { const c = p.getComponent("minecraft:inventory")?.container; if (c) for (let i = 0; i < c.size; i++) { const it = c.getItem(i), k = it && String(it.typeId).startsWith("mrpg:") ? it.typeId.slice(5) : ""; if (k && ITEMS[k]?.kind === "key") { c.setItem(i, undefined); got.push(k); moved++; } } } catch {}
  try { const eq = p.getComponent("minecraft:equippable"), it = eq && eq.getEquipment("Offhand"), k = it && String(it.typeId).startsWith("mrpg:") ? it.typeId.slice(5) : ""; if (k && ITEMS[k]?.kind === "key") { eq.setEquipment("Offhand", undefined); got.push(k); moved++; } } catch {}
  try { const b = bagLoad(p); let ch = false; for (const k of Object.keys(b.i)) if (ITEMS[k]?.kind === "key") { delete b.i[k]; got.push(k); ch = true; moved++; } if (ch) bagSave(p, b); } catch {}
  try { if (p.hasTag("mrpg_wmap")) got.push("k_wmap"); } catch {}
  if (d.tmb) got.push("k_tmbr");
  if (s.glove) got.push("k_glove");
  if (!KEYRT.has(p.id)) { KEYRT.add(p.id); for (const f of KEYSRC) try { got.push(...(f(d) || [])); } catch {} }   /* 入った あと 1回だけ */
  const L = keysOf(d), add = [...new Set(got)].filter((k) => ITEMS[k]?.kind === "key" && !L.includes(k) && !(k === "k_shell" && s.shellLost));
  if (add.length) s.keys = [...L, ...add];
  if (add.length || moved) { save(p, d); if (moved) try { p.sendMessage("§6だいじなものを ガイドブック ＞ 道具・装備 ＞【だいじなもの】に しまった §7（持ち物には もう 入らない）"); } catch {} }
}
export function syncKeys(p, d) {
  const s = qs(d), back = []; migrateKeys(p, d);
  // v2.9.12: いまの 段で 使う だいじなものが 記録に なければ わたす（とちゅうで ぬけて もらいそびれた とき）
  try { const cur = MQ[s.mq ?? 0]; if (cur && cur.key && ITEMS[cur.key] && !(s.keys || []).includes(cur.key)) s.keys = [...(s.keys || []), cur.key]; } catch {}
  try { back.push(...syncQuest(p, d)); } catch {}
  return back;
}

// ---------- チーム ----------
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
const RK = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
const rankForLv = (lv) => (lv < 8 ? 0 : lv < 14 ? 1 : lv < 22 ? 2 : lv < 32 ? 3 : lv < 44 ? 4 : lv < 56 ? 5 : lv < 70 ? 6 : 7);
function cands(fams, rk, sizes) {
  return ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !["king", "god"].includes(S.fam) && (!fams || fams.includes(S.fam)) && S.rank === RK[rk] && (!sizes || sizes.includes(S.sz)); });
}
export function team(fams, lv, n = 3, plus = 0, lead = null) {
  const out = []; let used = 0;
  const rk0 = rankForLv(lv);
  if (lead) { out.push({ sid: lead, lv: Math.min(100, lv + 2), q: 0.8, plus: plus + 5 }); used += SLOT[SPECIES[lead]?.sz] || 2; }
  for (let k = 0; out.length < n && k < 12; k++) {
    const rk = Math.max(0, rk0 - (out.length >= 2 ? 1 : 0));
    let c = cands(fams, rk).filter((x) => used + (SLOT[SPECIES[x].sz] || 2) <= 4 && !out.some((t) => t.sid === x));
    if (!c.length) c = cands(null, rk).filter((x) => used + (SLOT[SPECIES[x].sz] || 2) <= 4 && !out.some((t) => t.sid === x));
    if (!c.length) break;
    const x = pick(c); used += SLOT[SPECIES[x].sz] || 2;
    out.push({ sid: x, lv: Math.min(100, lv + (out.length ? 0 : 1)), q: 0.7, plus });
  }
  return out;
}
export function bossOne(fams, lv, plus, rkUp = 1) {
  const rk = Math.min(7, rankForLv(lv) + rkUp);
  let c = cands(fams, rk, ["L", "G"]); if (!c.length) c = cands(fams, rk); if (!c.length) c = cands(null, rk, ["L", "G"]);
  return [{ sid: pick(c) || ORDER[0], lv: Math.min(100, lv), q: 1, plus }];
}
export const leadOf = (fam, lv) => { const c = cands([fam], Math.min(7, rankForLv(lv) + 1)); return c.length ? pick(c) : null; };

// ---------- 会話・演出 ----------
const COL = { オルド: "§e", セオ: "§a", レイ: "§b", "？？？": "§4", ヴァルカ: "§c", マリン: "§3", ロウ: "§9", ルウ: "§d" };
async function say(p, who, lines, to = null) { await talk(p, who, lines, COL[who] || "§6", to); }   // v3.0 第63版: 操作の 案内は セリフに しない
async function narr(p, t, lines) { await tell(p, t, lines); }
/* 第113版: 再挑戦の 案内は はじめの 1回だけ くわしく（2回目からは 短く） */
function RT(p) { try { const d = load(p); if (d && !qs(d).rtHint) { qs(d).rtHint = 1; save(p, d); return "§7（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）"; } } catch {} return "§7（準備が できたら、もう一度）"; }
/* 第113版: 相棒の 声（守り手の 印を もらった あとは、あなたにだけ 少し 聞こえる）。{n} は 相棒の 名前 */
async function pal(p, lines) { const nm = palNm(p); await talk(p, `${nm}（相棒）`, lines.map((l) => String(l).replace(/\{n\}/g, nm)), "§e"); }
function big(p, a, b, snd = "random.levelup") {
  const t = String(a || "").replace(/§./g, "").trim();
  if (/^第.+章/.test(t)) { cineCard(p, `§f§l${t}${b ? `\n§r§7${String(b).replace(/§./g, "")}` : ""}`, 80); if (snd) sound(p, snd, 1); return; }   /* 第125版: 章の 札 */
  if (inScene(p) && t && t.length <= 8) {   /* 第125版: ムービーの あいだは 大きな 一文字（影・！）と 会話の 枠の 地の文 */
    cineSting(p, String(a).replace(/§l/g, ""), 36); cineFx(p, "s", 12); if (b) hudSend(p, "MQD", boxLine(`§7${String(b).replace(/§./g, "")}`));
    if (/影/.test(t)) mood(p, "shadow");
    if (snd) sound(p, snd, 1); return;
  }
  try { showTitle(p, a, { subtitle: b || "", fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {} if (snd) sound(p, snd, 1);
}
/* 第123版: 役者は 舞台の 立ち位置に 立つ（話す 人は 正面の 弧・旅の 仲間は となり・敵は 向こう側）。重ならない・葉の 上に 立たない */
function roleOf(p, name) { const n = String(name || ""), h = heroOf(p); if (h && n.replace(/§./g, "") === h.name) return "hero"; if (/^§[c45]/.test(n) || /ノクス|手下|影/.test(n)) return "foe"; return "ally"; }
function npcNear(p, name, job = 8, noWalk = false, quiet = false) {
  try {
    const S = stageNow(p), role = roleOf(p, name);
    { const o = S && S.ents.find((x) => ok(x) && x.typeId === "mrpg:npc" && x.nameTag === name); if (o) { if (Math.hypot(o.location.x - S.P.x, o.location.z - S.P.z) <= 16) { act(o, 0); return o; } rm(o); } }   /* 第124版: 同じ 人が もう 舞台に いれば その 人を 使う（消して 出しなおさない）*/
    const pos = slotOf(S, role, name, null);
    const e = p.dimension.spawnEntity("mrpg:npc", pos);
    if (MQASK.has(p.id)) { const L = SPAWNED.get(p.id) || []; L.push(e); SPAWNED.set(p.id, L); }
    { const A = TALKERS.get(p.id) || []; A.push(e); TALKERS.set(p.id, A.filter((x) => ok(x))); }   // v3.0: 戦いの 前に 消す ため
    try { setJob(e, namedJob(name, job)); } catch {}   /* 第126版(fix): 名前の ある 人は マスターの 見た目に しない */
    e.addTag("mrpg_npc"); e.addTag("mrpg_saga"); e.setDynamicProperty("mrpg:saga", true); e.nameTag = name;
    if (role === "hero") e.addTag("mrpg_hero");
    addActor(S, e, name, pos);
    const look = role === "hero" ? S.at(3.5, 0, 1.5) : { x: S.P.x, y: S.P.y + 1.5, z: S.P.z };
    try { e.teleport(pos, { facingLocation: look }); } catch {}
    if (!noWalk) walkIn(S, e, pos, look);
    else if (inScene(p) && !quiet) hideIn(p, e, S);   /* 第124版(fix2): 歩かずに 立たせる 人は、映る 所なら 暗い 中で（同じ tick に カメラが かわっても）*/   /* 第124版(cam): 歩かずに 立たせる 人は 暗転の 中で */   /* 第115版: いきなり 現れず、少し はなれた 所から 歩いて くる */
    return e;
  } catch { return null; }
}
/* 第124版(fix2): 2tick 後に 映って いるか 調べ、映るなら 暗転の 中で あらわす（明るく なりかけの ときは 待つ）*/
function hideIn(p, e, S) {
  try { e.addEffect("invisibility", 60, { showParticles: false }); } catch {}
  let n = 0, st = 0; const id = system.runInterval(() => { n++;
    try { if (!ok(e) || !ok(p)) { system.clearRun(id); return; }
      if (st === 0) { if (!inScene(p) || (n === 1 && !inCam(p, e.location, S.C))) { e.removeEffect("invisibility"); system.clearRun(id); return; } if (fadeTry(p, "0.15 0.3 0.35") || n > 20) { st = 1; n = 0; } }
      else if (n >= 3) { e.removeEffect("invisibility"); system.clearRun(id); } } catch { system.clearRun(id); } }, 2);
}
/* 第123版: 立ち位置の 外側（道が ある 所）から 歩いて 来る */
function walkIn(S, e, to, look) { if (!walkIn0(S, e, to, look)) smokeIn0(e); }   /* 第124版(cam): 中身は stagecore（映らない 所から 歩く）。歩けない ときは 煙の 中で */
/* ---------- 第115版: 演出の 道具（文字で 説明せず、画面で 起きる ことを 見せる）---------- */
const ACT = { talk: 4, wave: 5, clap: 6, cheer: 9, bow: 10, kneel: 15, point: 16, guard: 17, raise: 18, run: 19, knocked: 20, down: 8, recoil: 22, hold: 23, up: 24, sad: 12, prone: 21, nod: 25, no: 26, arms: 27, hips: 28, pump: 29, palm: 30, stagger: 31, give: 32, show: 33, work: 34 };   /* 第124版(fix2): stage2 と 同じ 名前 ＋ 21・25〜31。第125版: 32 渡す・33 見せる・34 作業 */
const SUB = new WeakMap();   /* 第124版: 戦いの 前に 下げて もどした 役者（古い 変数でも しぐさ・片づけが 効く）*/
const cur = (e) => { for (let k = 0; k < 4 && e && SUB.has(e); k++) e = SUB.get(e); return e; };
function act(e, k, keep = true) { e = cur(e); try { const n = typeof k === "number" ? k : ACT[k] ?? 0; e.setProperty("mrpg:act", n); if (keep) e.setDynamicProperty("mrpg:act0", n); } catch {} }
/* 第125版: 手に 持つ 小道具（hold.js）。hold(e, "key") で 持つ・hold(e) で 空に。give は 渡す 人が 持って 両手を 前へ → 受け取る 人が 持つ */
function hold(e, n = 0) { hold0(cur(e), n); }
async function give(a, b, n, t = 14) { a = cur(a); b = cur(b); if (!ok(a)) { if (ok(b)) hold0(b, n); return; } let a0 = 0; try { a0 = a.getDynamicProperty("mrpg:act0") || 0; } catch {} hold0(a, n); act(a, "give", false); await wait(t); hold0(a, 0); act(a, a0, false); if (b && ok(b)) hold0(b, n); }
async function go(e, to, ticks = 14, run = false) {   /* 歩く・走って 移動 */
  e = cur(e); if (!ok(e) || !to) return; await arrive(e); if (!ok(e)) return; const f = e.location;   /* 第124版(cam): 歩いて 来る とちゅうなら 着いてから */
  { const S = stageFor(e); if (S && Math.abs(to.y - f.y) < 1.6) { to = clampPath(S, f, to); to = freeNear(S, to, e, 1.25, 2.1) || to; to = clampPath(S, f, to); S.dest.set(e.id, to); } else if (S) { const y = standY(S.dim, to.x, to.z, to.y, S.C); if (y !== null && Math.abs(y - to.y) <= 1.2) { to = { ...to, y }; to = freeNear(S, to, e, 1.25, 2.1) || to; S.dest.set(e.id, to); } } }   /* 第123版: 壁を ぬけない・人に 重ならない。第127版: 坂・飛び降りでも うまらない・重ならない */ try { e.setProperty("mrpg:mv", true); if (run) e.setProperty("mrpg:act", ACT.run); } catch {}
  const W = (globalThis.__mqWalk = globalThis.__mqWalk || new Map()), wid = e.id; W.set(wid, Date.now());
  try { for (let k = 1; k <= ticks; k++) { if (!ok(e)) return; const t = k / ticks, x = f.x + (to.x - f.x) * t, z = f.z + (to.z - f.z) * t; let y = f.y + (to.y - f.y) * t; { const S2 = stageFor(e), g = S2 ? standY(S2.dim, x, z, y, S2.C) : null; if (g !== null && g > y && g - y < 1.2) y = g; }   /* 第128版: 段（祭壇など）を 上る とき 足が うまらない */
      try { e.teleport({ x, y, z }, { facingLocation: { x: to.x, y: to.y + 1.5, z: to.z } }); } catch {} await wait(1); } } finally { W.delete(wid); }
  try { e.setProperty("mrpg:mv", false); if (run) e.setProperty("mrpg:act", 0); } catch {}
}
/* 第126版(I1/PV): 着地は 攻撃から 離れる 向き（0・±0.6・±1.1・±1.6）・あなたから 2.2 以上・人から 2 以上・立てる 地面。倒れた 体（背中の 側へ 1.8）が だれの 足もとにも かからない。無ければ その場で 倒れる */
function knockTo(S, e, l, from, dist) {
  const P0 = S.p && S.p.location, a0 = Math.atan2(l.z - from.z, l.x - from.x), who = []; if (P0) who.push(P0); try { for (const o of S.ents) if (o !== e && ok(o)) who.push(o.location); } catch {}
  for (const dd of [dist, dist + 1, dist + 2]) for (const da of [0, 0.6, -0.6, 1.1, -1.1, 1.6, -1.6]) {
    const a = a0 + da; let q = { x: l.x + Math.cos(a) * dd, y: l.y, z: l.z + Math.sin(a) * dd }; q = clampPath(S, l, q); if (Math.hypot(q.x - l.x, q.z - l.z) < 1.5) continue;
    const y = standY(S.dim, q.x, q.z, l.y, S.C); if (y === null || Math.abs(y - l.y) > 2) continue; q.y = y;
    if (P0 && Math.hypot(q.x - P0.x, q.z - P0.z) < 2.2) continue; if (!freeAt(S, q, e, 2)) continue;
    const ux = q.x - from.x, uz = q.z - from.z, n = Math.hypot(ux, uz) || 1, hx = q.x + (ux / n) * 1.8, hz = q.z + (uz / n) * 1.8;
    if (who.some((w) => { for (let t = 0; t <= 1.001; t += 0.25) if (Math.hypot(q.x + (hx - q.x) * t - w.x, q.z + (hz - q.z) * t - w.z) < 1.3) return true; return false; })) continue;
    return q;
  }
  return null;
}
async function knock(e, from, dist = 3.5) {   /* 吹っ飛んで 倒れる */
  if (!ok(e)) return; const l = e.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L;
  let to = { x: l.x + ux * dist, y: l.y, z: l.z + uz * dist }; { const S = stageFor(e); if (S) { to = knockTo(S, e, l, from, dist); if (!to) { act(e, "down"); return; } S.dest.set(e.id, to); } }   /* 第123版: 壁の 手前で 止まる */
  act(e, "knocked", false);
  for (let k = 1; k <= 8; k++) { if (!ok(e)) return; const t = k / 8; try { e.teleport({ x: l.x + (to.x - l.x) * t, y: l.y + (to.y - l.y) * t + Math.sin(t * Math.PI) * 1.4, z: l.z + (to.z - l.z) * t }, { facingLocation: from }); } catch {} await wait(1); }
  act(e, "down");
}
function knockP(p, from, h = 1.1, v = 0.45) { try { const l = p.location, dx = l.x - from.x, dz = l.z - from.z, L = Math.hypot(dx, dz) || 1; cmd(p, "inputpermission set @s lateral_movement enabled"); p.applyKnockback(dx / L, dz / L, h, v); system.runTimeout(() => { try { if (inScene(p)) p.runCommand("inputpermission set @s lateral_movement disabled"); } catch {} }, 12); } catch {} }
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
function shake(p, pw = 0.5, t = 0.6) { cmd(p, `camerashake add @s ${pw} ${t} positional`); }
function flash(p, white = true) { if (fading(p)) { if (!white) fadeOn(p, "0.05 0.15 0.4"); return; } fadeOn(p, "0.05 0.15 0.4", white ? "255 255 255" : "0 0 0", true); }   /* 第124版(cam): 暗転の 中・明けかけに 光を 重ねない（黒は のばすだけ）*/
function boom(dim, at) { try { dim.spawnParticle("mrpg:shock_ring", { x: at.x, y: at.y + 0.1, z: at.z }); dim.spawnParticle("mrpg:dust_puff", { x: at.x, y: at.y + 0.1, z: at.z }); } catch {} try { dim.spawnParticle("minecraft:explosion_particle", { x: at.x, y: at.y + 0.5, z: at.z }); for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; dim.spawnParticle("minecraft:white_smoke_particle", { x: at.x + Math.cos(a) * 2, y: at.y + 0.3, z: at.z + Math.sin(a) * 2 }); } } catch {} }
async function shadowFlow(p, from, to, ticks = 20) {   /* 黒い 影が 地面を すべる */
  mood(p, "shadow");   /* 第125版: 紫の 霧と 暗がり */
  for (let k = 0; k <= ticks; k++) { if (!ok(p)) return; const t = k / ticks, x = from.x + (to.x - from.x) * t, z = from.z + (to.z - from.z) * t, y = from.y + (to.y - from.y) * t;
    if (k % 2 === 0) try { p.dimension.spawnParticle("mrpg:shadow_smoke", { x, y: y + 0.6, z }); if (k % 4 === 0) p.dimension.spawnParticle("mrpg:glow_mote", { x, y: y + 0.8, z }); } catch {}   /* 第125版: やわらかい 紫の 煙 */
    for (let i = 0; i < 2; i++) try { p.dimension.spawnParticle(i % 2 ? "minecraft:soul_particle" : "minecraft:basic_smoke_particle", { x: x + (Math.random() - 0.5) * 2.2, y: y + 0.2 + Math.random() * 0.8, z: z + (Math.random() - 0.5) * 2.2 }); } catch {}
    if (k === 0 || k === ticks) sound(p, "mob.wither.ambient", 1, 0.3); await wait(1); }
}
/* 第115版: 影が 人を 包む（粒が うずまき、その 人は 倒れて 眠る）*/
async function engulf(p, e) {
  if (!ok(e)) return; lookAt(p, e); mood(p, "shadow");
  for (let k = 0; k < 16; k++) { if (!ok(e)) break; const l = e.location; if (k % 6 === 0) try { e.dimension.spawnParticle("mrpg:vortex", { x: l.x, y: l.y + 0.1, z: l.z }); e.dimension.spawnParticle("mrpg:shadow_smoke", { x: l.x, y: l.y + 0.9, z: l.z }); } catch {} for (let i = 0; i < 4; i++) { const a = k * 0.8 + i * 1.57, r = 1.6 - k * 0.08; try { e.dimension.spawnParticle(i % 2 ? "minecraft:soul_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(a) * r, y: l.y + 0.2 + (k % 4) * 0.4, z: l.z + Math.sin(a) * r }); } catch {} } await wait(3); }
  { const S = stageFor(e), l = e.location; if (S) { let nq = null, nd = 3.5; for (const w of [S.p && S.p.location, ...S.ents.filter((o) => o !== e && ok(o)).map((o) => o.location)]) { if (!w) continue; const dd = Math.hypot(w.x - l.x, w.z - l.z); if (dd < nd) { nd = dd; nq = w; } } if (nq) try { e.teleport(l, { facingLocation: { x: nq.x, y: l.y + 1.5, z: nq.z } }); } catch {} } }   /* 第126版(I1/PV): 近い 人の 方を 向いて から 倒れる（体は 背中の 側へ。足もとに かからない）*/
  try { e.setProperty("mrpg:act", 8); e.setDynamicProperty("mrpg:act0", 8); } catch {}   /* 倒れて 眠る */
  sound(p, "mob.wither.ambient", 0.6);
}
const rm = (e) => { if (ok(e)) try { e.remove(); } catch {} };   /* 戦いの あと もどった 役者は 古い 変数では 消さない（あとの npcNear が 同じ 人を 使う。段の 終わりに 片づく）*/
/* ---------- 第115版: 旅の 仲間（ヒロイン）。プレイヤーが 12人から えらぶ ---------- */
export const HEROES = [["hero_rio", "リオ", "栗色の 髪の 冒険者。明るくて 涙もろい"], ["hero_yuna", "ユナ", "銀髪の 白い コート。おっとりした お姉さん"], ["hero_chloe", "クロエ", "ゴーグルの 発明家。怒ると 顔が 真っ赤"], ["hero_mia", "ミア", "金髪の 魔法使い。ちょっと 生意気"],
  ["hero_hana", "ハナ", "ピンクの 髪の 格闘家。元気 いっぱい"], ["hero_shion", "シオン", "紫の 髪の 巫女。静かで やさしい"], ["hero_leaf", "リーフ", "緑の 髪の 弓使い。クールな しっかり者"], ["hero_mel", "メル", "メイド服の お姉さん。丁寧で 心配性"],
  ["hero_nami", "ナミ", "水色の 髪の 船乗り。さっぱりした 性格"], ["hero_kaede", "カエデ", "着物の 剣士。まじめで 照れ屋"], ["hero_cecil", "セシル", "金髪の 女騎士。正義感が 強い"], ["hero_lulu", "ルル", "身軽な 盗賊。いたずら好き"]];
async function heroJoin(p) {
  const pick = await choose(p, "旅の 仲間", "§f§l旅の 仲間が 追いかけて きた！\n\n§7あなたの 幼なじみは だれ？（あとから かえる ことは できません）", HEROES.map((h) => [`§l${h[1]}§r\n§8${h[2]}`, `textures/ui/mrpg/h_${h[0]}`]));
  if (!(pick >= 0)) return false; const d = load(p); if (!d) return false; qs(d).hero = HEROES[pick][0]; save(p, d);
  const e = heroNear(p);
  await hsay(p, V(["{rage,怒,jump}はあ、はあ……やっと 追いついた！ 置いて いくなんて ひどい！", "{smile,♪}コンパス、ちゃんと 使ってくれてる？ ……わたしも 一緒に 行く。地図を ぜんぶ 描くのが 夢なの。"],
    ["{sad,汗}はあ、はあ……やっと 追いついた。置いて いくなんて、ひどいわ。", "{smile}コンパス、ちゃんと 使って くれてる？ ……わたしも 一緒に 行くわ。地図を ぜんぶ 描くのが 夢なの。"],
    ["{angry,汗}……はあ。追いついた。置いて いくな。", "{closed}コンパス、使ってる？ ……わたしも 行く。地図を ぜんぶ 描くのが、夢だから。"],
    ["{sweat,汗}はあ、はあ……やっと 追いつきました！ 置いて いくなんて、ひどいです！", "{smile}コンパス、使って くださってますか？ ……わたしも ご一緒します。地図を ぜんぶ 描くのが 夢なんです。"]));
  rm(e); return true;
}
export function heroAway(d) { try { return !!d && pgAway(d); } catch { return false; } }   /* 第125版: 第10章で ヒロインが 亡くなって、まだ 救い出して いない（台詞・旅の 仲間の しくみを 止める）*/
function heroOf(p) { try { const d = load(p), k = d && !heroAway(d) && qs(d).hero; const h = HEROES.find((x) => x[0] === k); return h ? { key: h[0], name: h[1] } : null; } catch { return null; } }
const HN = (p) => { try { const d = load(p), h = HEROES.find((x) => x[0] === (d && qs(d).hero)); if (h) return h[1]; } catch {} return "ユナ"; };   /* 第125版: 亡くなった あとも 名前は 呼べる */
/* 第122版: ヒロインの 話し方（g 元気・o おっとり・c クール・t ていねい）。hsay の lines に {g,o,c,t} を わたすと 型で えらぶ */
const HT = { hero_rio: "g", hero_chloe: "g", hero_hana: "g", hero_lulu: "g", hero_yuna: "o", hero_shion: "o", hero_mia: "c", hero_leaf: "c", hero_nami: "c", hero_mel: "t", hero_kaede: "t", hero_cecil: "t" };
export const heroType = (p) => { const h = heroOf(p); return (h && HT[h.key]) || "g"; };
async function hsay(p, lines, to = null) { const h = heroOf(p); if (!h) return; const L = Array.isArray(lines) ? lines : lines[HT[h.key] || "g"] || lines.g; if (MQRUN.has(p.id) && !heroHere(p)) { const e = heroNear(p); if (e) HTMP.set(p.id, [...(HTMP.get(p.id) || []), e]); } await say(p, h.name, L, to); }
/* 第122版: 旅の 仲間は いつも そばに いる（戦いの あとで 消えて いたら 立たせる。場面の 終わりに 片づける）*/
const HTMP = new Map();
function heroFind(p) { const h = heroOf(p); if (!h) return null; try { return p.dimension.getEntities({ type: "mrpg:npc", location: p.location, maxDistance: 14 }).find((e) => String(e.nameTag || "").replace(/§./g, "") === h.name && e.hasTag("mrpg_hero") && notOthers(p, e)) || null; } catch { return null; } }
function notOthers(p, e) { try { const S = stageFor(e); if (S && S.pid !== p.id) return false; for (const M of [TALKERS, HTMP]) for (const [pid, L] of M) if (pid !== p.id && L.some((x) => ok(x) && x.id === e.id)) return false; } catch {} return true; }   /* 第124版: マルチ: 同じ 名前の ほかの 人の 仲間を つかまない */
const heroHere = (p) => !!heroFind(p);
function heroTmpClean(p) { for (const e of HTMP.get(p.id) || []) rm(e); HTMP.delete(p.id); for (const e of REST.get(p.id) || []) rm(e); REST.delete(p.id); for (const e of TALKERS.get(p.id) || []) rm(e); TALKERS.delete(p.id); }   /* 第124版: 戦いの あと もどした 役者も。段の 終わりに 会話の 人を 残さない（マルチで ほかの 人の 物語中も 立ち続けない）*/
const V = (g, o, c, t) => ({ g, o, c, t });
/* 第122版: 旅の 手帳（ヒロインが 石に なった 人の 名前を 書きとめる。最後の「おかえり」で 読む）*/
function techo(p, nm) { try { const d = load(p); if (!d) return; const s = qs(d); s.techo = [...new Set([...(s.techo || []), nm])]; save(p, d); } catch {} }
/* 第115版: ガロたちに 囲まれて いる 小さな モンスター（あとで 相棒に なる 子） */
function palVictim(p, near) { try { let b = near && ok(near) ? near.location : p.location, yaw = (p.getRotation().y * Math.PI) / 180;
  let pos = near && ok(near) ? { x: b.x + 1.5, y: b.y, z: b.z + 1.5 } : { x: b.x - Math.sin(yaw) * 3, y: b.y, z: b.z + Math.cos(yaw) * 3 };
  const S = stageOf(p); if (S) { const P = S.P; if (near && ok(near) && S.dest.get(near.id)) b = S.dest.get(near.id); pos = near && ok(near) ? { x: P.x + (b.x - P.x) * 0.6, y: b.y, z: P.z + (b.z - P.z) * 0.6 } : stagePt(S, 2.6, 0.8); pos = freeNear(S, pos, null, 1.4) || pos; }   /* 第123版: ガロと あなたの あいだ（重ならない）*/
  const fams = ["beast", "animal", "slime", "dragon", "bird"].filter((f) => baseOf(f)); const sid = baseOf(fams[Math.floor(Math.random() * fams.length)] || "animal");
  const e = p.dimension.spawnEntity(MON_TYPE, pos); e.addTag("mrpg_temp"); e.addTag("mrpg_preview"); try { e.triggerEvent("mrpg:make_battle"); } catch {}
  if (MQASK.has(p.id)) { const L = SPAWNED.get(p.id) || []; L.push(e); SPAWNED.set(p.id, L); }   /* 第123版:「あとで」・抜けた ときに 小さな モンスターが 道に 残らない */
  setLook(e, sid, { sp: sid, nm: "小さな モンスター", look: simpleLook() }); e.nameTag = "§7小さな モンスター"; if (S) addActor(S, e, null, null); if (inScene(p)) smokeIn0(e); return e; } catch { return null; } }
function heroNear(p, noWalk = false) { if (OFFS.has(p.id)) return null; const h = heroOf(p); return h ? npcNear(p, `§d${h.name}`, PJ(h.key, 9), noWalk) : null; }
/* ---------- 第121版: 第2〜6章の 演出の 小道具（軽い。毎tickの ループは なし）---------- */
const EMK = { "!": "bang", "?": "q", "…": "dots", "汗": "sweat", "怒": "anger", "♥": "heart", "息": "sigh", "♪": "note", "☆": "spark" };
function re(e, f, m, t = 40) { e = cur(e); if (!ok(e)) return; if (f) dFace(e, f, t); if (m) dEmote(e, EMK[m] || m); }   /* だまって 反応（表情・マーク）*/
/* 旅の 仲間を 場面の あいだ そばに 置く（戦いで 消えたら その場に 出しなおす。歩いて こない）*/
function heroBox(p, walk = false) { let e = walk ? heroNear(p) : null; return { get e() { if (!ok(e)) e = heroFind(p) || heroNear(p, true); return e; }, rm() { rm(e); } }; }
function fwd(p, k = 5, sd = 0, dy = 0) { try { const S = stageOf(p); if (S) return stagePt(S, k, sd, dy); const l = p.location, a = (p.getRotation().y * Math.PI) / 180, X = -Math.sin(a), Z = Math.cos(a); return { x: l.x + X * k - Z * sd, y: l.y + dy, z: l.z + Z * k + X * sd }; } catch { return null; } }
function away(e, p, k = 8) { try { const a = e.location, b = p.location, dx = a.x - b.x, dz = a.z - b.z, L = Math.hypot(dx, dz) || 1, q = { x: a.x + (dx / L) * k, y: a.y, z: a.z + (dz / L) * k }, S = stageFor(e); return S ? clampPath(S, a, q) : q; } catch { return null; } }
async function leave(e, p, k = 8, run = true) {   /* 背を 向けて 去る。第124版(cam): カメラに 映らない 所まで 歩き、まだ 映って いれば 暗く して から 下げる */
  e = cur(e); const q = ok(e) ? exitPt(p, e, k) || away(e, p, k) : null;
  if (q) { const d = Math.hypot(q.x - e.location.x, q.z - e.location.z); await go(e, q, Math.max(run ? 12 : 22, Math.round(d * (run ? 1.6 : 3))), run); }
  if (ok(e) && inScene(p) && inCam(p, e.location, stageOf(p)?.C, undefined, true)) { await fadeHide(p, "0.1 0.25 0.4"); LFADE.set(p.id, Date.now()); FADED.set(p.id, system.currentTick); }   /* 第124版(fix2): 暗く なりきってから 下げる（明るく なりかけの 時は 待って もう一度）*/   /* 同じ 暗転は 2tick 以内だけ 使う（暗い うちに 消す）*/
  rm(e);
}
const FADED = new Map(), LFADE = new Map();   /* LFADE: 去る 人の 暗転（実時間。同じ 暗転を 0.1秒 以内だけ 使う）*/
async function gone(p, e) { e = cur(e); if (ok(e) && inScene(p) && inCam(p, e.location, stageOf(p)?.C, undefined, true)) { await fadeHide(p, "0.1 0.25 0.4"); FADED.set(p.id, system.currentTick); } rm(e); }   /* 第124版(cam): 映って いれば 暗く して から 下げる */
function darkNow(p) { return (FADED.get(p.id) ?? -99) > system.currentTick - 16; }
async function bye(p, ...es) { const v = es.filter((e) => ok(e)); if (v.length && inScene(p)) { camFade(p); FADED.set(p.id, system.currentTick); await wait(10); } for (const e of v) rm(e); }   /* 第124版: 段の 終わりに 役者を 下げる ときは 暗く して から（目の 前で 一度に 消えない）*/
function place(e, p, q) { e = cur(e); if (ok(e) && q) try { const S = stageFor(e); if (S) { const y = standY(S.dim, q.x, q.z, q.y, S.C); q = freeNear(S, q, e, 1.4) || (y !== null && freeNear(S, { ...q, y }, e, 1.4)) || q; S.mem.set(e.nameTag, { ...q }); S.dest.set(e.id, { ...q }); }
    { const l = e.location, d = Math.hypot(q.x - l.x, q.z - l.z); if (d > 1.2 && inScene(p) && !darkNow(p) && !(globalThis.__mqWalk?.has(e.id)) && (inCam(p, l, S?.C) || inCam(p, q, S?.C))) { go(e, q, Math.max(10, Math.round(d * 3))); return e; } }   /* 第124版(cam): 映って いる 人は 飛ばさず 歩かせる（暗転の 中なら 並びなおすだけ）*/
    e.teleport(q, { facingLocation: p.getHeadLocation() }); } catch {} return e; }
/* 第125版(rs): 暗転の 中で 決まった 所に 立たせる（歩いて 来ない 人: もう その場に いる・寝て いる・戦いの あとの 人）*/
async function putAt(p, nm, job, q, look = null) {
  const S = stageNow(p); if (!S || !q) return npcNear(p, nm, job, true);
  if (fadeOn(p, "0.25 0.3 0.45")) await wait(6);
  const e = npcNear(p, nm, job, true, true); if (!ok(e)) return e;
  const y = standY(S.dim, q.x, q.z, q.y ?? S.P.y, S.C), t = { x: q.x, y: y ?? q.y ?? S.P.y, z: q.z }; S.mem.set(e.nameTag, { ...t }); S.dest.set(e.id, { ...t });
  try { e.teleport(t, { facingLocation: look || p.getHeadLocation() }); } catch {} return e;
}
const npcAt = (p, nm, job, q) => {   /* 第124版(cam): 新しく 出す 人は 決まった 所へ 映らない 所から 歩いて 来る（もう いる 人は place）*/
  const S0 = stageNow(p), had = !!(S0 && S0.ents.some((x) => ok(x) && x.nameTag === nm)), e = npcNear(p, nm, job, true, !!(q && S0));   /* 歩いて 来る 人は walkIn だけが 隠す（暗転を 2回 出さない）*/
  if (had || !ok(e) || !q || !S0) return place(e, p, q);
  try { const y = standY(S0.dim, q.x, q.z, q.y ?? S0.P.y, S0.C); let t = { ...q, y: y ?? q.y ?? S0.P.y }; t = freeNear(S0, t, e, 1.4) || t; S0.mem.set(e.nameTag, { ...t }); S0.dest.set(e.id, { ...t }); e.teleport(t, { facingLocation: p.getHeadLocation() }); walkIn(S0, e, t, p.getHeadLocation()); } catch {}
  return e;
};
/* 第125版: 六影の 異名と 符号・名乗りの 演出。名乗りは 一人 一回だけ（/tmp/zf/six_intro.md）。arc: [始めの 角度, 終わりの 角度, 始めの 距離, 終わりの 距離, 始めの 高さ, 終わりの 高さ]。hit: 決めの 音 2つ [音, 高さ, 音, 高さ]。sd: 札の とき 顔を 置く 側 */
export const SIX = {
  zeph: { seat: "一の座", alias: "首領「終幕」", ruby: "インプレサリオ", nm: "ゼファード", c: "§6", who: "ゼファード", ptc: "minecraft:totem_particle", p2: "minecraft:endrod", rgb: [1, 0.82, 0.35], arc: [110, -10, 4.5, 3.2, 0.2, 1.4], hit: ["beacon.power", 0.7, "block.bell.hit", 0.5], sd: 1, line: "{closed,low}……待たせたな。幕を 引こう。", g: "up" },
  theo: { seat: "二の座", alias: "参謀「記録の指」", ruby: "ブリゲッラ", nm: "セオ", c: "§5", who: "セオ", ptc: "minecraft:enchanting_table_particle", p2: "minecraft:portal_reverse_particle", rgb: [0.62, 0.3, 0.95], arc: [150, 60, 2.4, 2.1, 1.0, 1.3], hit: ["item.book.put", 0.8, "mob.evocation_illager.cast_spell", 0.7], sd: -1, line: "{closed,low}……記録は、もう 済んで いる。", g: "show" },
  valka: { seat: "三の座", alias: "鍛手「緋の炉」", ruby: "スメラルディーナ", nm: "ヴァルカ", c: "§c", who: "ヴァルカ", ptc: "minecraft:basic_flame_particle", p2: "minecraft:lava_particle", rgb: [1, 0.35, 0.08], arc: [70, 20, 3.2, 2.6, 0.3, 0.8], hit: ["random.anvil_land", 0.6, "mob.blaze.shoot", 0.8], sd: 1, line: "{smile,low}熱いのは 好きかい？", g: "raise" },
  twins: { seat: "四・五の座", alias: "双子「白黒の 片手袋」", ruby: "ザンニ", nm: "ロウ＆ルウ", c: "§b", who: "ロウ", ptc: "minecraft:snowflake_particle", p2: "minecraft:endrod", rgb: [0.65, 0.88, 1], arc: [180, 10, 3.4, 3.0, 2.2, 1.1], hit: ["random.glass", 1.8, "random.glass", 0.9], sd: -1, lines: [["ロウ", "{closed}……ここから 先へは、行かせないよ。"], ["ルウ", "{angry}ロウと ボクを、引きはなしに 来たんでしょ。"]], g: "hold" },
  argo: { seat: "六の座", alias: "盾「仮面の剣」", ruby: "マタモロス", nm: "アルゴ", c: "§7", who: "アルゴ", ptc: "minecraft:soul_particle", p2: "mrpg:shadow_smoke", rgb: [0.55, 0.5, 0.7], arc: [40, -40, 2.8, 2.8, 0.15, 0.3], hit: ["item.shield.block", 0.6, "item.trident.return", 0.7], sd: 1, line: "{closed,low}…………。", g: "guard" },
  beryl: { seat: "座なし", alias: "七番目「白紙」", ruby: "プロンプター", sub: "まだ 名前の ない 幹部候補", nm: "ベリル", c: "§f", who: "ベリル", ptc: "minecraft:white_smoke_particle", p2: "minecraft:white_smoke_particle", rgb: [0.92, 0.92, 0.95], arc: [-110, -35, 3.0, 2.6, 1.3, 1.3], hit: ["item.book.page_turn", 0.7, "random.glass", 0.6], sd: -1, line: "{angry}……座の わたしの 行は、まだ 白紙。……だから、ここで 書く。", g: "point" },
};
const SIX_CH = { beryl: "第6章", valka: "第4章", theo: "第8章", twins: "第9章", argo: "第10章" };   /* 古い セーブ: この 章を 終えて いれば 名乗り済み。第126版: ベリルは 本6（MQ12）・アルゴは 本14（MQ21）で はじめて 名乗る */
function sixFirst(p, k) { try { const d = load(p); if (!d) return false; const s = qs(d); s.six = s.six || {}; if (s.six[k]) return false; const i = SIX_CH[k] ? MQ.findIndex((x) => x.ch && x.ch.startsWith(SIX_CH[k])) : -1; s.six[k] = 1; save(p, d); return !(i >= 0 && (s.mq ?? 0) > i); } catch { return false; } }
function sixFx(e, id, c, sc = 1, dy = 1) { try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: c[0], green: c[1], blue: c[2] }); m.setFloat("variable.scale", sc); const l = e.location; e.dimension.spawnParticle(id, { x: l.x, y: l.y + dy, z: l.z }, m); } catch {} }
export const sixName = (k) => { const X = SIX[k]; if (!X) return ""; const t = (X.alias.match(/「(.+?)」/) || [])[1] || X.alias; return `六影 ${X.seat === "座なし" ? "七番目" : X.seat} ${t}`; };   /* 戦いの 画面の 名前（例: 六影 二の座 ブリゲッラ）*/
/* 第126版: 六影の 札（ルビ つき）。RP の hud_screen.json へ MQN 名前 ／ MQY ルビ ／ MQE 異名と 座 を 送り、とどいて から ふつうの タイトル（見えない 印 SIX_MK つき）を 出す。
   新しい RP: 印つきの タイトルを かくして ルビ札を 出す。古い RP: MQ の 合図は 出ないので ふつうの 札（カタカナ なし）が 出る。とどかなければ 印なしの ふつうの 札 */
export const SIX_MK = "§r§k§r§k§r", SIX_RB = ["MQN", "MQY", "MQE"], SIX_ON = new Set();
export const sixRubyText = (X, seat) => { const m = X.alias.match(/^(.*?)(「.+」)$/), role = m ? m[1] : "", ep = m ? m[2] : X.alias; return { nm: `${X.c}§l${X.nm}`, rb: X.ruby ? `${X.c}${X.ruby}` : "", ep: `§f${ep}\n§7${seat}${role && !seat.includes(role) ? ` ・ ${role}` : ""}` }; };
const sixOff = (p) => { if (SIX_ON.delete(p.id)) for (const c of SIX_RB) hudSend(p, c, ""); };   /* ルビ札を 消す（ふつうの タイトルが 消えて から 送られる）*/
async function sixCard(p, X, seat) {
  const r = sixRubyText(X, seat); SIX_ON.add(p.id); TITLE_T.delete(p.id); hudSend(p, "MQN", r.nm); hudSend(p, "MQY", r.rb); hudSend(p, "MQE", r.ep);
  for (let i = 0; i < 8 && SIX_RB.some((c) => hudQueued(p.id, c)); i++) await wait(1);
  const sent = !SIX_RB.some((c) => hudQueued(p.id, c)); if (sent) await wait(1); else for (const c of SIX_RB) hudSend(p, c, "");
  try { showTitle(p, `${X.c}§l${X.nm}${sent ? SIX_MK : ""}`, { subtitle: `§7${seat}  §f${X.alias}`, fadeInDuration: 3, stayDuration: 30, fadeOutDuration: 10 }); } catch {}
}
IH.card = sixCard; IH.off = sixOff;   /* 第126版: 十魔将の 登場も 同じ ルビ札（intro126.js）*/
async function sixMark(p, e, k) {
  const X = SIX[k]; if (!X || !ok(p)) return;
  await arrive(e);   /* 第124版(cam): 歩いて 来る とちゅうの 足もとに 寄らない */
  if (!sixFirst(p, k)) { try { if (ok(e)) e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} return; }   /* 名乗りは 一回だけ。2回目からは 札も 演出も なし（振り向くだけ）*/
  if (!ok(e)) { if (X.lines) { for (const [w, t] of X.lines) await say(p, w, [t]); } else await say(p, X.who, [X.line]); return; }
  const l = e.location, P0 = p.location; let ux = P0.x - l.x, uz = P0.z - l.z; { const n = Math.hypot(ux, uz) || 1; ux /= n; uz /= n; }
  const R = (a, r, h) => { const t = (a * Math.PI) / 180, c = Math.cos(t), s = Math.sin(t); return { x: l.x + (ux * c - uz * s) * r, y: l.y + h, z: l.z + (ux * s + uz * c) * r }; };
  const at = (h) => ({ x: l.x, y: l.y + h, z: l.z }), [a0, a1, r0, r1, h0, h1] = X.arc, [s1, q1, s2, q2] = X.hit, sd = X.sd || 1;
  const seat = `六影  ${X.seat === "座なし" ? "七番目 ― 座なし" : X.seat}`;
  try { e.teleport(l, { facingLocation: { x: P0.x, y: l.y, z: P0.z } }); } catch {}
  cmd(p, "stopsound @s"); cmd(p, "fog @s push mrpg:shadow mq_six"); system.runTimeout(() => { try { if (p.isValid()) cmd(p, "fog @s remove mq_six"); } catch {} }, 200);   /* 世界が 少し 暗く（抜けても 10秒で もどる）*/
  try {
    sound(p, s2, q2 * 0.5, 0.35);
    if (SIXMV[k]) await SIXMV[k](p, e, { l, R, at, X, ux, uz });   /* 第126版: 一人ずつ ちがう 登場（intro126.js）*/
    else { camAt(p, R(a0, r0, h0), at(1.0), 0.5);   /* (a) 低い 角度から ゆっくり 回りこむ */
    for (let i = 0; i < 3 && ok(e); i++) {   /* 第125版: 名乗りを 短く（約3秒）*/
      if (i === 1) camAt(p, R(a1, r1, h1), at(1.4), 0.6);
      const r = 2.6 - i * 0.4; for (let j = 0; j < 8; j++) { const a = j * 0.785 + i * 0.5; try { p.dimension.spawnParticle(j % 2 ? X.p2 : X.ptc, { x: l.x + Math.cos(a) * r, y: l.y + 0.2 + i * 0.25, z: l.z + Math.sin(a) * r }); } catch {} }   /* その人の 粒が 渦を 巻いて 集まる */
      await wait(6);
    } }
    if (!ok(e)) return;
    act(e, X.g); pillar(e, X.rgb, 2.4); sixFx(e, "mrpg:shards", X.rgb, 1.2); sixFx(e, "mrpg:circle", X.rgb, 2, 0.05); sound(p, s1, q1, 1);   /* (b) 決めの しぐさ・音・柱 */
    camAt(p, R(a1 * 0.4, 1.7, 1.35), at(1.55), 0.35); await wait(6);
    sound(p, s2, q2, 0.8); sixFx(e, "mrpg:rise", X.rgb, 1, 0.2);
    { const px = -uz * sd * 1.4, pz = ux * sd * 1.4; camAt(p, R(-sd * 25, 3.0, 1.3), { x: l.x + px, y: l.y + 2.1, z: l.z + pz }, 1.6); }   /* (c) 顔を 片側・下へ ずらして ゆっくり 流す（札が 顔に かからない）*/
    await sixCard(p, X, seat); await wait(32); sixOff(p);   /* 第126版: 札は 1枚・短く（約3秒）。カタカナは 異名の 上に 小さく（ルビ）*/
    if (X.lines) { for (const [w, t] of X.lines) await say(p, w, [t]); } else await say(p, X.who, [X.line]);
    act(e, 0);
  } finally { try { cmd(p, "fog @s remove mq_six"); } catch {} sixOff(p); }
}
/* 第125版: 六影の 過去を 見せる 前の 絵（暗い 寄りで ゆっくり 切りかえ、その人の「捨てられない もの」を 寄りで 見せる）*/
async function memory(p, e, title, lines) {
  if (!ok(p)) return;
  fadeOn(p, "0.3 0.3 0.7", "20 15 30");   /* 第124版(fix2): 悲しい 回想は 暗闇（明るさが 波打つ）を 使わず、暗い 色の 短い 暗転 */
  if (ok(e)) { const l = e.location, P0 = p.location, dx = P0.x - l.x, dz = P0.z - l.z, n = Math.hypot(dx, dz) || 1; act(e, "hold");
    camAt(p, { x: l.x + (dx / n) * 1.3, y: l.y + 1.25, z: l.z + (dz / n) * 1.3 }, { x: l.x, y: l.y + 1.0, z: l.z }, 1.4); await wait(30); }
  await narr(p, title, lines);
  if (ok(e)) { camNear(p, e, 2.4, 1.5); await wait(10); act(e, 0); }
  try { p.removeEffect("darkness"); } catch {}
}
/* 第125版(rs2): 演出の 部品（sagaep.js の K.turn／K.ots／K.push／K.past と 同じ 形）。turnTo: 背を 向ける（q なしで もどす）・otsAt: a の 肩ごしに b・pushIn: ゆっくり 寄る・pastCard: 回想の 札 */
function turnTo(e, q) { e = cur(e); try { if (!ok(e)) return; if (!q) { e.setDynamicProperty("mrpg:away", undefined); return; } e.teleport(e.location, { facingLocation: { x: q.x, y: (q.y ?? e.location.y) + 1.5, z: q.z } }); e.setDynamicProperty("mrpg:away", true); } catch {} }
async function otsAt(p, a, b, t = 12) { a = cur(a); if (!ok(a) || !b) return; const A = a.location, B = b.location || b, dx = B.x - A.x, dz = B.z - A.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n; camAt(p, { x: A.x - ux * 1.7 - uz * 0.75, y: A.y + 1.9, z: A.z - uz * 1.7 + ux * 0.75 }, { x: B.x, y: (B.y ?? A.y) + 1.4, z: B.z }, 0.5); await wait(t); }
async function pushIn(p, q, t = 26) { q = cur(q); const Q = q && q.location ? q.location : q; if (!Q) return; camPt(p, Q, 5, 1.4, 0.4); await wait(8); camPt(p, Q, 1.8, 1.4, t / 20); await wait(t); }
async function pastCard(p, label) { fadeOn(p, "0.3 0.5 0.6", "40 30 20"); await wait(8); cineCard(p, label, 60); }
/* 第127版: 別視点（offstage）と 回想（flashback）。OFFS = 主人公の いない 場面を 流して いる 人の id（点検: t_cam126 の 別視点）*/
const OFFS = new Set(), OFFH = new Map(), OFFV = new Map(); globalThis.__mqOff = OFFS; globalThis.__mqOffV = OFFV;
const isParty = (e) => { try { return e.hasTag("mrpg_hero") || e.hasTag("mrpg_musashi") || /（相棒）/.test(String(e.getDynamicProperty("mrpg:spk") || "")); } catch { return false; } };
function offHide(p, all) {   /* 暗い 中で: 旅の 仲間（all なら 今の 役者 みんな）を 透明に して 名札も 外す。あなたも 透明 */
  const S = stageNow(p), L = OFFH.get(p.id) || [], H = new Set(L.map((x) => x.e));
  const put = (e) => { if (!ok(e) || H.has(e)) return; H.add(e); L.push({ e, nm: e.nameTag }); try { e.addEffect("invisibility", 20 * 600, { showParticles: false }); e.nameTag = ""; e.addTag("mrpg_offhid"); } catch {} };
  if (S) for (const e of S.ents) if (ok(e) && (all || isParty(e))) put(e);
  put(heroFind(p));
  try { for (const e of p.dimension.getEntities({ location: p.location, maxDistance: 12 })) if (e.typeId !== "minecraft:player" && isParty(e) && notOthers(p, e)) put(e); } catch {}
  try { if (!p.getEffect("invisibility")) { p.addEffect("invisibility", 20 * 600, { showParticles: false }); p.setDynamicProperty("mrpg:offinv", true); } } catch {}
  OFFH.set(p.id, L);
}
function offShow(p) {
  for (const { e, nm } of OFFH.get(p.id) || []) if (ok(e)) try { e.removeEffect("invisibility"); e.nameTag = nm; e.removeTag("mrpg_offhid"); } catch {}
  OFFH.delete(p.id);
  try { if (ok(p) && p.getDynamicProperty("mrpg:offinv")) { p.removeEffect("invisibility"); p.setDynamicProperty("mrpg:offinv", undefined); } } catch {}
}
/* 別の 舞台（今の 舞台から 22〜28マス はなれた 開けた 所。o.at が あれば そこ）。カメラだけ そこへ 行く（あなたは 動かない）*/
function offSet(p, o = {}) {
  const S = stageNow(p); if (!S) return null;
  const mk = (P, f) => { const n = Math.hypot(f.x, f.z) || 1, F = { x: f.x / n, z: f.z / n }, R = { x: -F.z, z: F.x }; return { P, f: F, at: (a, b = 0, dy = 0) => ({ x: P.x + F.x * a + R.x * b, y: P.y + dy, z: P.z + F.z * a + R.z * b }) }; };
  const A = o.at && Math.hypot(o.at.x - p.location.x, o.at.z - p.location.z) < 56 ? o.at : null;
  const cand = A ? [A] : [[-26, 0], [0, 26], [0, -26], [24, 10], [-22, 14]].map(([a, b]) => S.at(a, b));
  for (const q of cand) { try { const fr = findStage(S.dim, { x: q.x, y: Number.isFinite(q.y) ? q.y : S.P.y, z: q.z }, 0, A ? 10 : 7); if (fr && Math.hypot(fr.P.x - S.P.x, fr.P.z - S.P.z) > (A ? 0 : 16)) return mk(fr.P, fr.f); } catch {} }
  return A ? mk({ x: A.x, y: Number.isFinite(A.y) ? A.y : S.P.y, z: A.z }, { x: S.P.x - A.x, z: S.P.z - A.z }) : null;
}
/* 別の 舞台に 役者を 置く（暗い 中で。歩いて 来ない 人）*/
function offActor(p, V, nm, job, q, look = null) {
  const S = stageNow(p); if (!S || !q) return null;
  try { let t = null; for (const [a, b] of [[0, 0], [0.9, 0], [-0.9, 0], [0, 0.9], [0, -0.9], [1.6, 0.8], [-1.6, -0.8], [0.8, -1.6], [-0.8, 1.6]]) { const x = q.x + a, z = q.z + b, y = standY(S.dim, x, z, q.y ?? V.P.y, S.C); if (y !== null && Math.abs(y - (q.y ?? V.P.y)) <= 2 && goodStand(S.dim, x, y, z, S.C)) { t = { x, y, z }; break; } }   /* 木・岩の 中に 立たせない */
    if (!t) { const y = standY(S.dim, q.x, q.z, q.y ?? V.P.y, S.C); t = { x: q.x, y: y ?? q.y ?? V.P.y, z: q.z }; }
    const e = p.dimension.spawnEntity("mrpg:npc", t); try { setJob(e, job); } catch {}
    e.addTag("mrpg_npc"); e.addTag("mrpg_saga"); e.setDynamicProperty("mrpg:saga", true); e.nameTag = nm;
    { const A = TALKERS.get(p.id) || []; A.push(e); TALKERS.set(p.id, A.filter((x) => ok(x))); }
    addActor(S, e, nm, t); S.mem.set(nm, { ...t }); S.dest.set(e.id, { ...t });
    e.teleport(t, { facingLocation: look || V.at(0, 0, 1.5) }); return e; } catch { return null; }
}
/* まわりの 町の 人・動物を 少しの あいだ 透明に（別の 舞台に 映りこまない）*/
function offClear(p, V) { const L = []; try { for (const e of p.dimension.getEntities({ location: V.P, maxDistance: 11 })) { if (e.typeId === "minecraft:player" || e.typeId === "minecraft:item" || e.hasTag("mrpg_saga") || e.hasTag("mrpg_cine") || e.hasTag("mrpg_offhid") || e.getEffect("invisibility")) continue; try { e.addEffect("invisibility", 20 * 300, { showParticles: false }); L.push({ e, nm: e.nameTag }); e.nameTag = ""; } catch {} } } catch {} return L; }
function offUnclear(L) { for (const { e, nm } of L || []) if (ok(e)) try { e.removeEffect("invisibility"); e.nameTag = nm; } catch {} }
/* 第127版: 部品だけ（暗い 中で 呼ぶ）。offBegin: あなたと 仲間・今の 役者を 隠す ／ offEnd: もどす */
function offBegin(p, all = true) { if (!ok(p) || OFFS.has(p.id)) return; offHide(p, all); OFFS.add(p.id); }
function offEnd(p) { if (!OFFS.has(p.id)) return; OFFS.delete(p.id); OFFV.delete(p.id); offShow(p); }
/* K.offstage(p, fn, o): 主人公の いない 場面（敵の 視点・そのころ）。o.card: 札・o.at: 別の 舞台の 点・o.here: 今の 舞台で（役者 みんなを 隠す）
   fn(V): V.at(a, b, dy) で 別の 舞台の 点、V.actor(nm, job, [a, b], look) で 役者を 置く（暗い 中で）。終われば 役者を 下げ、仲間と あなたを もどす */
async function offstage(p, fn, o = {}) {
  if (!ok(p)) return;
  if (OFFS.has(p.id)) return fn(OFFV.get(p.id));
  fadeOn(p, "0.4 0.7 0.4", "0 0 0", true); await wait(9);
  offHide(p, true); OFFS.add(p.id);
  const V = (o.here ? null : offSet(p, o)) || (() => { const S = stageNow(p); return S ? { P: S.P, f: S.f, at: S.at } : null; })();
  if (!V) { OFFS.delete(p.id); offShow(p); return; }
  const mine = [], clr = offClear(p, V);
  V.actor = (nm, job, ab, look) => { const e = offActor(p, V, nm, job, Array.isArray(ab) ? V.at(ab[0], ab[1] || 0) : ab, look); if (e) mine.push(e); return e; };
  OFFV.set(p.id, V);
  try { let C = {}; try { if (o.cast) C = (await o.cast(V)) || {}; } catch {}   /* 役者は 暗い うちに 置く（目の 前に わかない）*/
    camAt(p, V.at(-9, 5, 6.5), V.at(3, 0, 1), 0); if (o.card) cineCard(p, o.card, 70); await wait(20); camAt(p, V.at(-5, 2.6, 3.2), V.at(3, 0, 1.2), 1.2); await wait(10); await fn(V, C); }
  finally {
    fadeOn(p, "0.35 0.6 0.4", "0 0 0", true); await wait(9);
    for (const e of mine) rm(e); OFFS.delete(p.id); OFFV.delete(p.id); offUnclear(clr); offShow(p);
    const S = stageNow(p); if (S && ok(p)) { camAt(p, S.at(-4, 2.4 * S.side, 2.6), S.at(3, 0, 1.3), 0); await wait(6); }
  }
}
function cut(p, who) { try { const S = stageNow(p); let e = null; if (!who) e = heroFind(p); else if (S) e = S.ents.find((o) => ok(o) && o.typeId === "mrpg:npc" && String(o.nameTag || "").replace(/§./g, "").includes(who)); if (ok(e)) camNear(p, e, 2.3, 1.35); } catch {} }
function rmName(p, ...nms) { try { const S = stageNow(p); if (!S) return; for (const o of S.ents) if (ok(o) && o.typeId === "mrpg:npc" && nms.includes(o.nameTag)) rm(o); } catch {} }   /* 第125版: 戦いの あと もどった 役者を 名前で 下げる（古い 変数では 消えない）*/
async function sayAt(p, nm, job, who, lines) { const e = npcNear(p, nm, job); await say(p, who, lines); if (ok(e) && inScene(p)) { act(e, 0); await leave(e, p, 7, false); } else rm(e); }   /* 第124版: 歩いて 来て 話し、背を 向けて 去る（わく・消えるを なくす）*/   /* 負けた あとの 一言（その場に 立って 話す）*/
function burst(dim, at, nm, n = 8, r = 1.2, dy = 0.5) { if (!at) return; for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; try { dim.spawnParticle(nm, { x: at.x + Math.cos(a) * r, y: at.y + dy + (i % 3) * 0.4, z: at.z + Math.sin(a) * r }); } catch {} } }
function crysRing(p, c, put) { if (!c) return; const D = p.dimension; for (const [a, b] of [[-3, -1], [3, -1], [-3, 1], [3, 1], [-2, -2], [2, -2]]) { const x = Math.floor(c.x) + a, z = Math.floor(c.z) + b; let g = null; try { g = groundY(D, x, z, Math.floor(c.y) + 3); } catch {} if (typeof g !== "number" || Math.abs(g - c.y) > 3) continue; try { if (put) D.runCommand(`setblock ${x} ${g} ${z} amethyst_cluster keep`); else for (const y of [g, g - 1]) if (D.getBlock({ x, y, z })?.typeId === "minecraft:amethyst_cluster") { D.runCommand(`setblock ${x} ${y} ${z} air`); D.spawnParticle("minecraft:endrod", { x: x + 0.5, y: y + 0.5, z: z + 0.5 }); } } catch {} } if (!put) sound(p, "block.amethyst_block.break", 1); }   /* 第125版(tp): 祭壇の まわりの 水晶（置く・割る。かけらは 落とさない）*/
function drift(p, q, wood = []) { const put = (o, b) => { if (!o) return; const x = Math.floor(o.x), z = Math.floor(o.z); let g = null; try { g = groundY(p.dimension, x, z, Math.floor(o.y) + 3); } catch {} if (typeof g === "number" && Math.abs(g - o.y) <= 3) try { p.dimension.runCommand(`setblock ${x} ${g} ${z} ${b} keep`); } catch {} }; put(q, "campfire"); for (const w of wood) put(w, "birch_slab"); }   /* 第125版(tp): 浜の 燃える 流木 */
async function blaze(p, at, k = 4) { if (!at) return; for (let j = 0; j < k && ok(p); j++) { burst(p.dimension, at, j % 2 ? "minecraft:basic_flame_particle" : "minecraft:lava_particle", 8, 0.8 + j * 0.4); burst(p.dimension, at, "minecraft:basic_smoke_particle", 6, 1.4, 2); await wait(3); } }
function redGlow(e) { if (!ok(e)) return; burst(e.dimension, e.location, "minecraft:redstone_wire_dust_particle", 6, 0.35, 1.2); }   /* かけらの 赤黒い 光 */
async function drop(p, e, h = 5) { if (!ok(e)) return; const l = e.location; try { e.teleport({ x: l.x, y: l.y + h, z: l.z }); } catch {} await go(e, l, 7); burst(p.dimension, l, "minecraft:white_smoke_particle", 8, 1, 0.1); sound(p, "random.anvil_land", 1.4); shake(p, 0.25, 0.3); }   /* 上から 飛び降りて くる */
function camPt(p, at, k = 3, dy = 1, ease = 0.6) { try { if (!at) return false; const P = p.location, dx = P.x - at.x, dz = P.z - at.z, L = Math.hypot(dx, dz) || 1; return camAt(p, { x: at.x + (dx / L) * k, y: at.y + dy + 0.4, z: at.z + (dz / L) * k }, { x: at.x, y: at.y + dy, z: at.z }, ease); } catch { return false; } }
const camNear = (p, e, k = 2.2, dy = 1.3, ease = 0.6) => ok(e) && camPt(p, e.location, k, dy, ease);
function camLowUp(p, q) { const c = fwd(p, -1.5, 0, 0.4); if (c && q) camAt(p, c, { x: q.x, y: q.y + 4, z: q.z }, 0.5); }   /* 足もとから 見上げる（大きな 主）*/
function palEnt(p) {   /* 相棒の 姿を 横に 出す（演出だけ。rmCine で 消す）*/
  if (OFFS.has(p.id)) return null;
  try { const d = load(p); const m = [...(d.party || [])].find((x) => x && (x.id === d.partnerId || x.partner || x.look)) || d.party[0]; const S = stageOf(p); let q = fwd(p, 2, 1.6); if (S && q) q = freeNear(S, q, null, 1.3) || q; if (!m || !q || !SPECIES[m.sp]) return null;
    const g = p.dimension.spawnEntity(MON_TYPE, q); g.addTag("mrpg_temp"); g.addTag("mrpg_cine"); setLook(g, m.sp); try { g.addTag("mrpg_spkm"); g.setDynamicProperty("mrpg:spk", `${palNm(p)}（相棒）`); } catch {}   /* 第124版(fix2): 相棒の 声で カメラが 相棒を 映す */ (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(g.id); if (S) addActor(S, g, null, null); try { g.teleport(q, { facingLocation: p.getHeadLocation() }); } catch {} if (inScene(p)) smokeIn0(g); return g; } catch { return null; }
}
function rmCine(g) { try { if (g) { globalThis.__mqCine?.delete(g.id); if (g.isValid()) smokeOut(g, 4); } } catch {} }   /* 第124版(cam): 煙の 中で あらわれる ／ 消える */
/* 第122版: 演出だけの モンスター（オルドの 相棒 ハク・レイの 竜など）。rmCine で 消す */
const HAKU_SP = SPECIES.hbea14 ? "hbea14" : SPECIES.hbea01 ? "hbea01" : ORDER[0];
function monEnt(p, q, sid, nm) {
  try { if (!q || !SPECIES[sid]) return null; const S = stageOf(p); if (S) q = freeNear(S, q, null, 1.6, 3) || q; const g = p.dimension.spawnEntity(MON_TYPE, q); if (S) addActor(S, g, null, null); g.addTag("mrpg_temp"); g.addTag("mrpg_cine"); setLook(g, sid); g.nameTag = nm || ""; try { const hy = lookOf(sid).mh * 0.85; if (hy > 1.55) g.setDynamicProperty("mrpg:hy", Math.min(10, hy)); } catch {}   /* 第124版(fix2): 大きな 魔物は 顔の 高さ */
    (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(g.id); try { g.teleport(q, { facingLocation: p.getHeadLocation() }); } catch {} if (inScene(p)) smokeIn0(g); return g; } catch { return null; }
}
const hakuEnt = (p, q) => monEnt(p, q, HAKU_SP, "§fハク");
const DRAGON_SP = () => (SPECIES.hdra12 ? "hdra12" : ORDER.find((x) => SPECIES[x].fam === "dragon" && SPECIES[x].sz === "L" && !SPECIES[x].hidden) || HAKU_SP);   /* レイの 竜 */
function ride(m, r) { try { const c = m && r && m.getComponent("minecraft:rideable"); return !!(c && c.addRider(r)); } catch { return false; } }   /* 乗れない ときは 横を 歩く */
async function stoneFx(p, e, nm) {   /* 足もとから 灰色に なって 石に なる */
  if (!ok(e)) return; sound(p, "dig.stone", 0.6);
  for (let k = 0; k < 6; k++) { if (!ok(e)) return; burst(p.dimension, e.location, k % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.6, k * 0.35); await wait(4); }
  sound(p, "dig.stone", 0.8); try { e.setProperty("mrpg:mv", false); } catch {} if (nm) try { e.nameTag = nm; } catch {}
}
function spkClean(p) { try { for (const e of p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_autospk"] })) if (e.getDynamicProperty("mrpg:spkOwner") === p.id) e.remove(); } catch {} }
function gotShow(p, t, got) { big(p, t, got.length ? `§e${got.join("・")}` : ""); for (const x of got) try { p.sendMessage(`§e${x}`); } catch {} }
/* 第109版: 話す 人が その場に いなければ 出す（オルドなどが 声だけで 姿が なかった）。いれば その人が 身ぶりで 話す */
const SPK = { "オルド": () => PJ("ordo", 8), "レイ": () => 17, "セオ": () => 18, "ガロ": () => PJ("garo", 9), "ヴァルカ": () => PJ("valka", 10), "ベリル": () => PJ("beryl", 9), "マリン": () => PJ("marin", 9), "ルウ": () => PJ("ruu", 9), "ロウ": () => PJ("rou", 9), "ピコ": () => PJ("pico", 9), "ヨミ": () => PJ("yomi", 9), "老人 イザク": () => PJ("isak", 8), "砂王 ラシード": () => PJ("rashid", 8), "女王 エルゼ": () => PJ("elze", 8), "冥王 モルテ": () => PJ("morte", 8), "アルカ十三世": () => PJ("arca13", 8), "ムサシ": () => 19 };
setSpeakerFinder((p, who) => {
  const key = String(who).replace(/§./g, "").trim(), short = key.split(" ").pop();
  try { for (const e of p.dimension.getEntities({ tags: ["mrpg_spkm"], location: p.location, maxDistance: 30 })) { if (e.getDynamicProperty("mrpg:spk") !== key) continue; const S1 = stageFor(e); if (S1 && S1.pid !== p.id) continue; return e; } } catch {}   /* 第124版(cam): 名札の ない 話す 人（十魔将）*/
  try { const S0 = stageOf(p); if (S0) for (const e of S0.ents) { if (!ok(e) || e.typeId !== "mrpg:npc") continue; const n = String(e.nameTag || "").replace(/§./g, ""); if (n && (n === key || n.split(" ").pop() === short)) return e; } } catch {}   /* 第124版(cam): 舞台の 役者を 先に（広間で 14m より 遠い 人も 話す 人に なる）*/
  try { let part = null; for (const e of p.dimension.getEntities({ type: "mrpg:npc", location: p.location, maxDistance: 14 })) { const n = String(e.nameTag || "").replace(/§./g, ""); if (n && (n.includes(key) || n.split(" ").pop() === short)) { const S1 = stageFor(e); if (S1 && S1.pid !== p.id) continue; if (n === key || n.split(" ").pop() === short) return e; part = part || e; } } if (part) return part; } catch {}   /* マルチ: ほかの 人の 場面の 役者は 使わない。第125版: 名前が 同じ 人を 先に（「ロウ」で「シロウ」を 映さない）*/
  if (MQRUN.has(p.id)) { try { globalThis.__mqNoSpk?.(p, key); } catch {} return null; }   /* 第122版: 物語の 段では 話す 人を 自動で 出さない（出す 人は 場面が 決める）*/
  let f = SPK[key]; { const h = heroOf(p); if (h && key === h.name) f = () => PJ(h.key, 9); } if (!f) return null;
  const e = npcNear(p, `§e${key}`, f()); if (e) try { e.addTag("mrpg_autospk"); e.setDynamicProperty("mrpg:spkOwner", p.id); } catch {}
  return e;
});
// v2.9.12: 物語の 戦いは 始まる 前に 聞く（着いた とたんに 戦いに ならない）。「あとで」なら 少し たってから もう一度
const MQRUN_KEY = new Set();   // v2.9.13: だいじなもので 始まった 段
const MQASK = new Set(), MQRUN = new Set(), SPAWNED = new Map(), LATER = { later: true };
const MQTOK = new Map(), EVTOK = new Map();   /* 第124版:今 動いて いる 物語の 流れ（「バグを 直す」の あと 古い 流れが 新しい 流れの 印や 場面を 消さない）*/
const MQSTALE = new Set();   /* 第124版:「バグを 直す」で 外した 古い 物語の 流れ（あとから 動いても ほうびを 2回 出さない）*/
export const __mqTest = { MQRUN, clean: (p) => heroTmpClean(p) };   /* 第122版: 点検用 */
function laterClean(p) { for (const e of SPAWNED.get(p.id) || []) rm(e); SPAWNED.delete(p.id); }
// 物語の 戦い（勝っても 負けても 仲間は 回復。お金は へらない）
const TALKERS = new Map();   // v3.0: 会話の ために 出した 人（戦いが 始まる ときに 消す。ライバルが 戦いの 場に 残らない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { for (const e of TALKERS.get(playerId) || []) rm(e); TALKERS.delete(playerId); }); } catch {}
/* 第124版: 戦いの 前に 消した 役者を、戦いの あと 同じ 立ち位置に もどす（消えて あとから わかない）。後の npcNear は 同じ 名前の 役者を 使いまわす */
const REST = new Map();
function talkersOff(p) {
  const S = stageOf(p), L = [];
  for (const e of TALKERS.get(p.id) || []) { if (ok(e) && S && S.ents.includes(e)) try { L.push({ obj: e, nm: e.nameTag, job: e.getDynamicProperty("mrpg:jobd"), at: { ...e.location }, hero: e.hasTag("mrpg_hero"), hd: e.getProperty("mrpg:hold") || 0 }); } catch {} rm(e); }
  TALKERS.delete(p.id); return L;
}
function talkersBack(p, L) {
  const S = stageOf(p); if (!S || !L || !L.length) return;
  for (const x of L) {
    if (Math.hypot(x.at.x - S.P.x, x.at.z - S.P.z) > 16) continue;
    try { const e = p.dimension.spawnEntity("mrpg:npc", x.at); setJob(e, typeof x.job === "number" ? x.job : 8);
      e.addTag("mrpg_npc"); e.addTag("mrpg_saga"); e.setDynamicProperty("mrpg:saga", true); e.nameTag = x.nm; if (x.hero) e.addTag("mrpg_hero"); if (x.hd) hold(e, x.hd);
      addActor(S, e, x.nm, x.at); e.teleport(x.at, { facingLocation: x.hero ? S.at(3.5, 0, 1.5) : { x: S.P.x, y: S.P.y + 1.5, z: S.P.z } });
      if (x.obj) SUB.set(x.obj, e); TALKERS.set(p.id, [...(TALKERS.get(p.id) || []), e]); REST.set(p.id, [...(REST.get(p.id) || []), e]); } catch {}
  }
}
async function battle(p, foe, info) {
  const d0 = load(p); if (!canFight(d0)) return "_noparty";
  let cast = [];
  /* 第123版: 今の 段で 勝った 戦いは、会話の とちゅうで 抜けて 入りなおしても もう 戦わない（お金・経験が 2回 出ない）。印は 段番号＋戦いの 名前（ほかの 印で 飛ばした 戦いが あっても ずれない）。台本の 負けは のぞく */
  const wk = MQRUN.has(p.id) && !info.scripted ? `w_mq${qs(d0).mq ?? 0}_${String(info.name || "").replace(/§./g, "")}_${info.arena || ""}` : null;
  if (wk) { const s0 = qs(d0); let ch = false; for (const k of Object.keys(s0)) if (k.startsWith("w_mq") && !k.startsWith(`w_mq${s0.mq ?? 0}_`)) { delete s0[k]; ch = true; } if (ch) save(p, d0); if (s0[wk]) return "win"; }
  if (MQASK.has(p.id)) {
    MQASK.delete(p.id);
    if (!info.asked && !(await confirm(p, "物語の 戦い", `§c§l戦いが 始まる！§r\n\n§f相手: §e${info.name || "？？？"}\n${info.heal === false ? "§c仲間の 回復は なし。" : "§7仲間は 戦いの 前に 全回復する。"}${info.scripted ? "\n§e（この 戦いは 勝てなくても 物語は 進む）" : "\n§7（負けても その場で もう一度 挑める）"}\n§7「あとで」を えらんだ ときは、ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度 起きる（だいじなものの 戦いは その だいじなものを もう一度 使う）。それまで 物語は 先へ 進まない。`, "戦う", "あとで"))) throw LATER;
  }
  if (info.heal !== false) { for (const m of d0.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d0); }
  let res = null;
  busy.delete(p.id);   // 戦いは 自分で busy を つける
  if (inScene(p)) { const S9 = stageOf(p); if (S9) camAt(p, S9.at(-5, 4.2 * S9.side, 3.2), S9.at(4, 0, 1.2), 0.25); cineSting(p, "§e§lBATTLE", 26); await wait(22); camFade(p); await wait(9); }   /* 第124版(fix2): 両者が にらみ合う 引きの 絵 */   /* 第125版: 戦いの 前の 大きな 文字。第124版: 暗く なってから 役者を 下げて 戦いへ（目の 前で 消えない・手と ホットバーが 一瞬 出ない）*/
  cast = talkersOff(p);
  scenePause(p);   /* 第123版: 戦いは 自分の カメラと HUD */
  try { res = await fight(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", friends: true, ...info }); } catch (e) { console.warn(`[MonsterRPG] saga fight: ${e}`); }
  // v2.9.13: 負けたら その場で「もう一度 挑む」（決まった 負けの できごとは のぞく）
  for (let k = 0; k < 5 && res === "lose" && !info.scripted && info.heal !== false; k++) {   // 回復なしの 連戦は その場で やりなおさない
    busy.add(p.id);   // 再戦の 画面の あいだは ほかの 人の 申しこみを 止める
    let again = false; try { if (ok(p)) again = await confirm(p, "負けて しまった……", `§f相手: §e${info.name || "？？？"}\n\n§fもう一度 挑みますか？\n§7（仲間は 全回復する。${!MQRUN.has(p.id) ? "「あとで」なら また 今度 挑める" : `「あとで」なら ${MQRUN_KEY.has(p.id) ? "もう一度 だいじなものを 使えば" : "ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶと"} もう一度 起きる`}）`, "もう一度 挑む", "あとで"); } catch {}
    if (!again || !ok(p)) break;
    const dr = load(p); if (!dr) break;
    for (const m of dr.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, dr);
    busy.delete(p.id);
    try { res = await fight(p, { team: foe }, { tier: 2, fam: "", npc: null, theme: "arena", friends: true, ...info, asked: true }); } catch (e) { console.warn(`[MonsterRPG] saga fight: ${e}`); res = null; }
  }
  if (EVT.has(p.id)) busy.add(p.id);   // 戦いの あとも 物語の 会話が 終わるまで ほかの できごとを 止める
  if (ok(p)) { fadeOn(p, "0 0.6 0.5", "0 0 0", true); talkersBack(p, cast); sceneResume(p); if (inScene(p)) await wait(28); }   /* 第124版: 役者は 同じ 立ち位置に もどって いる。第124版(fix2): 暗い 中で もどし、余韻の 引きの 絵を 見せる */
  if (wk && res === "win") { const dw = load(p); if (dw) { qs(dw)[wk] = 1; save(p, dw); } }   /* 勝った 直後に 印（段が 進めば 次の 戦いで 消える）*/
  const d = load(p); if (d && res !== "win") { for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = Math.max(m.hp, Math.floor(c.hp / 2)); m.mp = Math.max(m.mp, Math.floor(c.mp / 2)); } save(p, d); }
  return res;
}
function reward(p, d, g, items = [], mark = true) {   /* 第106版: 段の とちゅうの ごほうびは mark=false（段を 終えた 印を つけない） */
  const got = [];
  if (mark && MQSTALE.has(p.id) && !MQRUN.has(p.id)) return got;   /* 第124版: 外した 古い 流れの ほうびは 出さない */
  if (mark && MQRUN.has(p.id)) { const s0 = qs(d); s0.mqPaid = s0.mq ?? 0; }   // v2.9.12: ごほうびを わたした 段は とちゅうで 落ちても 先へ 進める（2回 もらえない）
  if (g) { d.gold += g; got.push(gold(g)); }
  for (let [id, n] of items) { if (id === "SEED2") id = seedId(2); if (id === "SEED3") id = seedId(3); if (!ITEMS[id]) continue; giveItem(p, `mrpg:${id}`, n || 1); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); }
  return got;
}
export function homeTp(p) {
  const h = homeInfo(); const s = SP();
  const at = h && h.built ? { x: h.x, y: h.y + 0.1, z: h.z } : { x: s.x + 0.5, y: s.y + 0.2, z: s.z + 0.5 };
  try { p.teleport(at, { dimension: world.getDimension("overworld") }); } catch {}
  try { p.addEffect("slow_falling", 100, { showParticles: false }); } catch {}
}

// ---------- 状況（地下・海・町・ステージ）----------
function underground(p) {
  try {
    const l = p.location; if (p.dimension.id !== "minecraft:overworld" || l.y > 58) return false;
    const x = Math.floor(l.x), z = Math.floor(l.z), y = Math.floor(l.y);
    for (let dy = 2; dy < 22; dy++) { const t = p.dimension.getBlock({ x, y: y + dy, z })?.typeId || ""; if (!t) return false; if (t !== "minecraft:air" && !t.includes("leaves") && !t.includes("water") && !t.includes("glass")) return true; }
  } catch {}
  return false;
}
// v2.9.12: 物語で 作った 洞くつの 中（坂道〜広間）に いるか
export function inCave(p, R) {
  try {
    if (p.dimension.id !== "minecraft:overworld") return false;
    const v = caveInfo(R); if (!v || !v.built) return false;
    const l = p.location, b = caveBox(R);   /* 第128版: 曲がった 坂道と 丸い 広間 */
    if (v.dt) return inCaveBox(R, l);   /* 第125版: 地方ごとの ダンジョン（大樹・浮島は 上へ）*/
    return l.x >= b.x1 && l.x <= b.x2 && l.z >= b.z1 && l.z <= b.z2 && l.y < v.y - 3;
  } catch { return false; }
}
function depthOf(p) { try { const l = p.location; return underwater(p) ? waterDepth(p.dimension, Math.floor(l.x), Math.floor(l.y) + 1, Math.floor(l.z)) : 0; } catch { return 0; } }
function stageNear(p, r = 40) {   /* v2.9.12: 右上の「この あたり」と おなじ 40 */
  const R = regAt(p.location);
  for (const L of landSites(R)) { const I = landInfo(L.key); if (I && I.built && Math.hypot(p.location.x - L.x, p.location.z - L.z) < r) return { ...L, name: I.name, r: R }; }
  return null;
}
const exempt = (p) => { try { const l = p.location; if (p.dimension.id !== "minecraft:overworld" || l.y > 180 || busy.has(p.id)) return true; if (typeof p.getDynamicProperty("mrpg:dg") === "string" || typeof p.getDynamicProperty("mrpg:ret") === "string") return true; const s = SP(); return Math.hypot(l.x - s.x, l.z - s.z) > 4200; } catch { return true; } };

// ---------- v2.9: 冤罪 → 城の 牢屋（負けイベント）----------
const _jh = (id) => { let h = 7; for (const c of String(id || "")) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
// v2.9.12: 牢屋の 番号は 入る ときに 空いて いる ものを えらんで 記録（ほかの 人と 同じ 牢屋に ならない）
function jailPeek(p) { try { const v = p.getDynamicProperty("mrpg:jailk"); if (typeof v === "number") return v; } catch {} return null; }   // v3.0: 読むだけ（入って いない 人には 番号を わりあてない）
function jailSlot(p) {
  try { const v = p.getDynamicProperty("mrpg:jailk"); if (typeof v === "number") return v; } catch {}
  let R = {}; try { R = JSON.parse(world.getDynamicProperty("mrpg:jailslots") || "{}"); } catch {}
  if (typeof R[p.id] === "number") { try { p.setDynamicProperty("mrpg:jailk", R[p.id]); } catch {} return R[p.id]; }
  const used = new Set(Object.values(R));   // v2.9.12: ワールドに 記録（ぬけて いる 人の 牢屋も ほかの 人に わたさない）
  let k = _jh(p.id) % 64; for (let n = 0; n < 64 && used.has(k); n++) k = (k + 1) % 64;
  if (used.has(k)) { const act = new Set(); try { for (const v of globalThis.__mqJails?.values?.() || []) if (typeof R[v.pid] === "number") act.add(R[v.pid]); } catch {} for (let n = 0; n < 64 && act.has(k); n++) k = (k + 1) % 64; }   /* 第124版: 64人ぶん 使いきった ときは 今 牢に いる 人と 同じ 番号を さける */
  try { p.setDynamicProperty("mrpg:jailk", k); } catch {}
  R[p.id] = k; try { world.setDynamicProperty("mrpg:jailslots", JSON.stringify(R)); } catch {}
  return k;
}
const JOFF = () => Math.round(720 * LAYOUT.k);   /* 第99版: 寄せた 配置では 地形の 中に */
/* 第124版: 牢は 48マスおき（となりの 人の 戦いの ドームが かぶらない）。地上の 予備の 牢を 使った ときは その 場所（mrpg:jailat）*/
const JPOS = (k, w = 48) => { const s = SP(); return { x: Math.floor(s.x) - JOFF() - (k % 8) * w, y: 232, z: Math.floor(s.z) - JOFF() - Math.floor(k / 8) * w }; };
const JAT = (p) => { try { const v = JSON.parse(p.getDynamicProperty("mrpg:jailat") || "null"); if (v && typeof v.x === "number") return v; } catch {} return null; };
const JAIL = (p) => JAT(p) || JPOS(p ? jailSlot(p) : 0);   // v2.9.2: 人ごとに べつの 牢屋
function jcmd(dim, c) { try { if (typeof dim.runCommand === "function") dim.runCommand(c); else dim.runCommandAsync(c); } catch {} }
export const inJail = (p) => { try { const k = jailPeek(p), A = JAT(p); if (k === null && !A) return false; const l = p.location, near = (J) => Math.abs(l.x - J.x) < 12 && Math.abs(l.z - J.z) < 12 && Math.abs(l.y - J.y) < 12; return p.dimension.id === "minecraft:overworld" && ((A && near(A)) || (k !== null && (near(JPOS(k)) || near(JPOS(k, 24))))); } catch { return false; } };   /* 24 は 前の 版の 牢 */
const jailHere = (p) => { try { const A = JAT(p); if (A) return A; const k = jailPeek(p); if (k === null) return JAIL(p); const l = p.location, o = JPOS(k, 24); return Math.abs(l.x - o.x) < 12 && Math.abs(l.z - o.z) < 12 && Math.abs(l.y - o.y) < 12 ? o : JPOS(k); } catch { return JAIL(p); } };   /* 第124版: いま 立って いる 牢（前の 版の 24マスおきの 牢も）*/
/* 第124版: 牢の 読みこみ範囲の 名前を ワールドに 記録（閉じた あと 次に 開いた ときに 消す）*/
const jta = (n, add) => { try { let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:jailta") || "[]"); } catch {} if (!Array.isArray(L)) L = []; L = L.filter((x) => x !== n); if (add) L.push(n); world.setDynamicProperty("mrpg:jailta", JSON.stringify(L.slice(-40))); } catch {} };
system.runTimeout(() => { try { let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:jailta") || "[]"); } catch {} if (Array.isArray(L) && L.length) { const ow = world.getDimension("overworld"); for (const n of L) jcmd(ow, `tickingarea remove ${n}`); world.setDynamicProperty("mrpg:jailta", undefined); } } catch {} }, 20);
async function buildJail(ow, J) {
  jcmd(ow, `tickingarea add ${J.x - 8} 0 ${J.z - 8} ${J.x + 8} 0 ${J.z + 8} mrpg_jail_${J.x}_${J.z}`); jta(`mrpg_jail_${J.x}_${J.z}`, 1);
  for (let t = 0; t < 40; t++) { let okb = false; try { okb = !!ow.getBlock({ x: J.x, y: J.y, z: J.z }); } catch {} if (okb) break; if (J.p && t % 8 === 7) cmd(J.p, "camera @s fade time 0 2.2 0.4 color 0 0 0"); await wait(5); }   /* 第124版: 待つ あいだも 暗いまま（止まった 城門を 見せない）*/
  const C = [`fill ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} stone_bricks`, `fill ${J.x - 4} ${J.y} ${J.z - 4} ${J.x + 4} ${J.y + 4} ${J.z + 4} air`,
    `fill ${J.x - 4} ${J.y - 1} ${J.z - 4} ${J.x + 4} ${J.y - 1} ${J.z + 4} cobblestone`, `fill ${J.x - 1} ${J.y} ${J.z - 4} ${J.x - 1} ${J.y + 3} ${J.z + 4} iron_bars`,
    `fill ${J.x - 3} ${J.y} ${J.z - 4} ${J.x - 2} ${J.y} ${J.z - 3} hay_block`, `setblock ${J.x - 4} ${J.y + 3} ${J.z} soul_lantern`, `setblock ${J.x + 3} ${J.y + 3} ${J.z + 3} lantern`,
    `fill ${J.x - 5} ${J.y + 2} ${J.z - 1} ${J.x - 5} ${J.y + 2} ${J.z + 1} iron_bars`, `setblock ${J.x - 3} ${J.y} ${J.z + 3} iron_bars`, `fill ${J.x + 1} ${J.y} ${J.z + 4} ${J.x + 4} ${J.y} ${J.z + 4} barrel`,
    `setblock ${J.x + 3} ${J.y} ${J.z - 3} smithing_table`, `fill ${J.x - 4} ${J.y + 4} ${J.z - 4} ${J.x - 2} ${J.y + 4} ${J.z - 4} web`];
  for (const c of C) jcmd(ow, c);
}
function clearJail(ow, J) { let rs = false; if (J.sn) { try { const r = ow.runCommand(`structure load ${J.sn} ${J.x - 5} ${J.y - 1} ${J.z - 5}`); rs = !r || r.successCount !== 0; } catch {} jcmd(ow, `structure delete ${J.sn}`); }   /* 第124版: 予備の 牢は 保存した 地形に もどす */
  if (!rs) jcmd(ow, `fill ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} ${J.under ? "stone" : "air"}`); jcmd(ow, `tickingarea remove mrpg_jail_${J.x}_${J.z}`); jta(`mrpg_jail_${J.x}_${J.z}`, 0); try { globalThis.__mqJails?.delete(`mrpg_jail_${J.x}_${J.z}`); } catch {} }   /* 地下の 予備の 牢は 石で うめもどす */
// v2.9.12: 牢屋に いる まま ぬけた 人の 読みこみ範囲は 外す（もどって きたら 外へ 出す 処理は 別に ある）
try { world.beforeEvents.playerLeave.subscribe((e) => { try { const p = e.player; if (!inJail(p)) return; const J = JAIL(p); system.run(() => { try { world.getDimension("overworld").runCommand(`tickingarea remove mrpg_jail_${J.x}_${J.z}`); } catch {} }); } catch {} }); } catch {}
export function releaseJail(p) {
  const d = load(p); const s = d ? qs(d) : null;
  const r = s && s.jailRet;
  try { if (r) p.teleport({ x: r.x, y: r.y + 0.2, z: r.z }, { dimension: world.getDimension("overworld") }); else homeTp(p); } catch {}
  try { p.setDynamicProperty("mrpg:jailat", undefined); } catch {}
  try { p.addEffect("slow_falling", 200, { showParticles: false }); p.addEffect("resistance", 200, { amplifier: 4, showParticles: false }); } catch {}
}
async function jailEvent(p) {
  const d = load(p); if (!d) return false;
  const ret = { x: p.location.x, y: p.location.y, z: p.location.z };
  try { const gy = groundY(p.dimension, ret.x, ret.z, Math.floor(ret.y)); if (typeof gy === "number" && gy <= ret.y) ret.y = gy; } catch {}   // 空中なら 地面へ
  /* 第121版: 衛兵に 囲まれる。第122版: 六影の 密告。レイも 同じ 密告で 先に 捕まって いる */
  if (qs(d).jailIn) {   /* 第125版: 捕まった あと 抜けて 入りなおした ときは、城門の 捕りものを くり返さず 牢から 続ける */
    big(p, "§8……", "§7気が つくと、城の 地下牢に いた", "random.door_close");
  } else {
  const H = heroBox(p, true);
  const e = npcNear(p, "§6サンドリア城の 衛兵長 ガルム", PJ("glen", 16));
  const g1 = npcNear(p, "§6サンドリア城の 衛兵", PJ("glen", 16)), g2 = npcNear(p, "§6サンドリア城の 衛兵", PJ("glen", 16));
  act(g1, "guard"); act(g2, "guard");
  big(p, "§c§l止まれ！", "§f城門を くぐった とたん、衛兵たちに 囲まれた……！", "mob.villager.no");
  re(H.e, "shock", "!"); act(H.e, "guard");
  if (ok(e)) { act(e, "point"); camNear(p, e, 2.6, 1.4); await wait(6); }   /* 第125版: 衛兵長に 寄る */
  await say(p, "ガルム", [epD(load(p), "r4e2") ? "{angry,!,low}……やはり 来たのであるな、よそ者。昨夜 申した とおりである。王墓を 狙う 一味だな！" : "{angry,!,low}そこの 旅人、止まれ！ 王墓を 狙う 一味だな！", "密告が あった。『石板を 持った よそ者が、王墓を 荒らしに 来る』と。言い訳は 牢で 聞く！"]);
  await hsay(p, V(["{rage,怒,jump}はあ！？ 王墓なんて まだ 見ても いないよ！ その 密告、だれが したの！？"], ["{angry}……ちがいます。わたしたち、まだ 王墓に 行っても いないわ。だれが そんな ことを？"], ["{angry}密告？ 差出人は？ 証拠も なしに 捕まえるの？"], ["{rage,怒}ご、誤解です！ わたしたちは まだ 王墓に 近づいても いません！ その 密告は どなたから！"]));
  await say(p, "ガルム", ["{closed}名は 明かせん。……同じ 密告で、竜を 連れた 若者も さっき 捕らえたのである。"]);
  await hsay(p, V(["{shock,!}竜……レイ！？"], ["{shock,…}……レイくんまで？"], ["{closed}……レイも。わたしたちを 王墓から 遠ざけたい だれかが いる。"], ["{shock,!}レ、レイさんまで……！？"]));
  try {
    await battle(p, team(["golem", "sword"], 75, 3, 45), { name: "衛兵長 ガルム", arena: "濡れ衣", theme: "desert", speaker: "ガルム", hpk: 40, extra: 0.6, tag: "衛兵長", heal: false,
      scripted: { turns: 2, lines: ["§6§l城の 衛兵たちが 次々と なだれこんできた！", "§7多勢に 無勢…… 仲間たちが 取りおさえられていく！"] }, lines: { half: "抵抗するか！ ますます 怪しい！" } });
  } finally { if (inScene(p)) { fadeOn(p, "0 1.6 0.6", "0 0 0", true); await wait(2); } rm(e); rm(g1); rm(g2); H.rm(); heroTmpClean(p); rmName(p, "§6サンドリア城の 衛兵長 ガルム", "§6サンドリア城の 衛兵"); }   /* 第125版: 戦いの あと もどった 城門の 人を 下げる（牢の 中の 会話で 城門の ガルムが 話す 人に なり、カメラが 城門に 止まって いた）*/
  }
  const d2 = load(p); if (!d2) return false; const s2 = qs(d2); if (!s2.jailIn || !s2.jailRet) s2.jailRet = ret; s2.jailIn = 1; save(p, d2);
  // 牢屋へ
  const ow = world.getDimension("overworld"); let J = JAIL(p);
  fadeOn(p, "0.2 1.6 0.6");
  try { showTitle(p, "§8……", { subtitle: "§7目の 前が 真っ暗に なった", fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  const jreg = (J) => { try { (globalThis.__mqJails ??= new Map()).set(`mrpg_jail_${J.x}_${J.z}`, { pid: p.id, box: { dim: "minecraft:overworld", x1: J.x - 6, x2: J.x + 6, z1: J.z - 6, z2: J.z + 6 } }); } catch {} };
  jreg(J); J.p = p; await buildJail(ow, J); delete J.p;
  { let fo = false; try { fo = (ow.getBlock({ x: J.x + 2, y: J.y - 1, z: J.z })?.typeId || "").includes("cobblestone"); } catch {}
    if (!fo) {   /* 第124版: 空の 牢が 作れない ときは、城門の 地面の 下（読みこまれて いる 所）に 予備の 牢を 作る */
      clearJail(ow, J); const r0 = s2.jailRet || ret; let gy0 = null; try { gy0 = groundY(ow, Math.floor(r0.x), Math.floor(r0.z), Math.floor(r0.y) + 4); } catch {}
      if (typeof gy0 === "number" && gy0 - 10 > -60) {   /* 第124版: ほかの 人の 予備の 牢と 重ならない 所を さがす（12マスずつ ずらす）。もとの 地形は structure に 保存して 片づけで もどす */
        const bx = Math.floor(r0.x), bz = Math.floor(r0.z), hit = (x, z) => { for (const v of (globalThis.__mqJails?.values?.() || [])) { const b = v?.box; if (b && v.pid !== p.id && x + 6 > b.x1 && x - 6 < b.x2 && z + 6 > b.z1 && z - 6 < b.z2) return true; } return false; };
        let ox = 0, oz = 0; for (const [a, c] of [[0, 0], [12, 0], [-12, 0], [0, 12], [0, -12], [12, 12], [-12, -12], [12, -12], [-12, 12]]) if (!hit(bx + a, bz + c)) { ox = a; oz = c; break; }
        J = { x: bx + ox, y: Math.floor(gy0) - 10, z: bz + oz, under: 1, sn: `mrpg:jb${jailSlot(p)}` }; jcmd(ow, `structure save ${J.sn} ${J.x - 5} ${J.y - 1} ${J.z - 5} ${J.x + 5} ${J.y + 5} ${J.z + 5} false disk true`);
        try { p.setDynamicProperty("mrpg:jailat", JSON.stringify(J)); } catch {} jreg(J); fadeOn(p, "0.1 1.6 0.6"); await buildJail(ow, J); }
    } }
  // v2.9.9: とちゅうで ぬけた ときは 牢屋を のこす（もどった とき 空中に 落ちない。もどると 自動で 外へ 出して 片づける）
  try { return await jailInside(p, ow, J); } finally { let valid = false; try { valid = !!p.isValid?.(); } catch {} if (valid && inJail(p)) { try { releaseJail(p); } catch {} try { clearJail(ow, J); } catch {} } }   /* 第125版: 牢の 中で とちゅうで 終わった ときは 先に 外へ 出してから 牢を 消す（牢の 床ごと 消えて 空から 落ちて いた）*/
}
async function jailInside(p, ow, J) {
  try { p.addEffect("slow_falling", 600, { showParticles: false }); p.addEffect("resistance", 600, { amplifier: 4, showParticles: false }); } catch {}
  let floorOk = false; try { floorOk = (ow.getBlock({ x: J.x + 2, y: J.y - 1, z: J.z })?.typeId || "").includes("cobblestone"); } catch {}
  if (!floorOk) {   // 牢屋を 作れなかった ときは その場で 話だけ
    await narr(p, "地下牢", ["§7（あなたは 城の 地下牢に 連れて いかれた……）"]);
    clearJail(ow, J);
  } else { fadeOn(p, "0.2 1.8 0.6"); FADED.set(p.id, system.currentTick); try { p.teleport({ x: J.x + 2.5, y: J.y + 0.1, z: J.z - 3.0 }, { dimension: ow, facingLocation: { x: J.x + 2.5, y: J.y + 1.5, z: J.z + 4 } }); } catch {}
    if (stageOf(p)) try { await stageMove(p, { x: J.x + 2.5, y: J.y, z: J.z - 3.0 }, { R: 1, face: { x: J.x + 2.5, z: J.z + 4 }, box: { x1: J.x - 3.8, x2: J.x + 4.8, y1: J.y + 0.2, y2: J.y + 3.8, z1: J.z - 4.8, z2: J.z + 4.8 }, noEst: true }); } catch {} }   /* 第125版: 舞台も 牢の 中へ 移す（城門に 舞台が 残り、カメラと 人の 立ち位置が 城門の まま だった）。牢は 細長いので 奥へ 向く */   /* 第124版: 牢の 中の 人が そろうまで 暗い まま（目の 前で わかない）*/
  try { p.addEffect("slowness", 400, { amplifier: 2, showParticles: false }); } catch {}
  await wait(30);
  /* 第121版: 牢の 中の 位置（鉄格子は x-1。こちら側が 牢・向こう側が 通路）。作れなかった ときは ふつうに 並ぶ */
  const at = (dx, dz) => (floorOk ? { x: J.x + dx, y: J.y, z: J.z + dz } : null);
  let eH = place(heroNear(p, true), p, at(1.2, -1.2)); act(eH, "sad");   /* 第124版: 引きの 絵の 前に 牢の 中の 人を そろえる（絵の とちゅうで わかない）*/
  let eR = npcAt(p, "§bライバル レイ", RIVAL_JOB, at(3.7, 0.4)); act(eR, "kneel");   /* 同じ 牢に レイ */
  const eI0 = !qs(load(p) || {}).jailIsak ? npcAt(p, "§7老人 イザク", PJ("isak", 8), at(2.6, 3.4)) : null; act(eI0, "down");   /* 牢の すみで 横に なって いた */
  big(p, "§8§lサンドリア城 地下牢", "§7ひんやりした 石の 床……", "random.door_close");
  if (floorOk) { camAt(p, { x: J.x + 4.3, y: J.y + 3.2, z: J.z - 4.3 }, { x: J.x + 1.5, y: J.y + 0.8, z: J.z + 2 }, 0.6); await wait(30); }   /* 牢の すみから 見下ろす 引きの 絵 */
  await say(p, "レイ", ["{sweat,汗}……おまえらも か。ヴォルカで 聞いた 六影を 追って 来たら、城門で この ざまだ。", "{angry}密告だとさ。……オレたちを 王墓から 遠ざけたい やつが いる。"]);
  await hsay(p, V(["{rage,怒,up}あの 衛兵長、次 会ったら 文句 百個 言って やるんだから！", "{sad,…}……でも、ねえ。このまま 出られなかったら、どうしよう。"], ["{sad}……ここ、寒いわね。", "{sad,…}……ちゃんと、出られる わよね？"], ["{angry}……濡れ衣で 牢。笑えない。", "{sad,…}……少しだけ、こわい。言わないで おいて。"], ["{rage,怒}何も して いないのに……あんまりです。", "{sad,汗}……わたしたち、ここから 出られるのでしょうか……"]));
  await say(p, "レイ", ["{closed}……出られる。じいちゃんの しくじり帳にも、牢から 出た 話が 三つは あった。"]);
  const eJ = npcAt(p, "§7牢番", PJ("glen", 16), at(-2.5, -3.5)); sound(p, "random.door_open", 0.5); if (floorOk) await go(eJ, at(-2.5, 0.5), 12);   /* 第124版: 通路の 奥から 歩いて 来る */
  await say(p, "牢番", ["{angry,low}おとなしく しておれ。明日の 朝には 裁きが くだる。"]);
  if (floorOk) await go(eJ, at(-2.5, -3.5), 14); await gone(p, eJ); sound(p, "random.door_close", 0.5);
  /* 第106版: 同じ 牢の 老人イザク・牢破り・看守ブルーノ */
  if (!qs(load(p) || {}).jailIsak) {
    const eI = ok(eI0) ? eI0 : npcAt(p, "§7老人 イザク", PJ("isak", 8), at(2.6, 3.4)); act(eI, "down");   /* 牢の すみで 横に なって いた */
    re(eH, "shock", "!");
    await hsay(p, V(["{shock,!,jump}わっ！ す、すみに だれか 寝てる！"], ["{shock,…}……あら。すみに、だれか……"], ["{shock,!}……すみに 人が いる。"], ["{shock,!,up}ひゃっ！ す、すみに どなたか……！"]));
    act(eI, "kneel");
    await say(p, "老人 イザク", ["{closed}……新入りかね。わしは イザク。この 牢で 七年に なる。", "{sad}罪状？ 王墓に 入った。……七年前、娘が 石に なってな。石に なった 者は、王墓の 石の 間に 葬られる 決まりなんじゃ。", "{smile}花を 一輪、届けたかった だけじゃよ。"]);
    if (ok(eH)) { re(eH, "shock", "!"); camNear(p, eH, 2.2, 1.3); await wait(4); }
    await hsay(p, V(["{shock,!}……七年も！？ 花を 届けたかった だけで？", "{sad}……娘さんの 名前、教えて。手帳に 書いとく。"], ["{sad}……七年も。", "{sad}娘さんの お名前、聞いても いい？ 手帳に 書いて おきたいの。"], ["{closed}……七年。花 一輪で。", "{up}娘さんの 名前。手帳に 書く。"], ["{sad}七年も……お花を 届けたかった だけで……", "{closed}娘さんの お名前を 伺っても よろしいですか。手帳に 記して おきます。"]));
    await say(p, "老人 イザク", ["{smile,…}……ニナ。……ありがとうよ。"]);
    techo(p, "ニナ（イザクの 娘）");
    act(eI, "hold");
    await say(p, "老人 イザク", ["{smile,wide}おまえさんたちの 目は まだ 死んでおらん。……この 骨で 鍵を 開けられる。七年 かけて 削ったんじゃ。", "{closed}わしは……もう ここで ええ。おまえさんたちが 行け。"]);
    act(eI, "kneel");
    sound(p, "random.click", 1.4); await wait(4); sound(p, "random.door_open", 0.8); burst(p.dimension, at(-1, 0.5) || fwd(p, 3), "minecraft:critical_hit_emitter", 4, 0.3, 1);
    if (ok(eH)) { act(eH, "raise"); camNear(p, eH, 2.2, 1.3); await wait(4); }
    await hsay(p, V(["{smile,☆,jump}開いた！ ……おじいさん、ありがとう！ 必ず 迎えに 来るから！"], ["{smile}……開いた。おじいさん、ありがとう。必ず 戻って くるわ。"], ["{closed}開いた。……待ってて。必ず 出す。"], ["{smile}開きました……！ イザクさん、必ず お迎えに 参ります！"]));
    const eG = npcAt(p, "§8看守 ブルーノ", PJ("bruno", 16), at(-2.5, -3.5)); if (floorOk) await go(eG, at(-2.5, 0.5), 10, true);
    await say(p, "看守 ブルーノ", ["{shock,!,jump}おい、何の 音だ！ ……鍵が 開いてる！？ 逃がすか！"]);
    await say(p, "レイ", ["{angry,!}どけ！ オレたちは 何も やって ない！"]);
    const r = await battle(p, team(["golem", "beast"], 34, 2, 6), { name: "看守 ブルーノ", arena: "牢破り", theme: "desert", speaker: "看守 ブルーノ", guests: team(["dragon"], 32, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "くそっ、応援を 呼べ！", low: "……行け。どうせ 外も 地獄だ" } });
    rm(eG); rm(eI);
    eR = npcNear(p, "§bライバル レイ", RIVAL_JOB, true); eH = heroNear(p, true);   /* 第125版: 戦いの あと もどった 人を 使う（古い 変数では 下げられず、あとで 二重に わいて いた）*/
    { const eG2 = npcNear(p, "§8看守 ブルーノ", PJ("bruno", 16), true); if (r !== "win") await say(p, "看守 ブルーノ", ["{angry}牢に もどれ！ ……次は 見張りを 倍に するぞ"]); else { act(eG2, "recoil"); await say(p, "看守 ブルーノ", ["{sweat,汗}……くそっ、好きに しろ。"]); } act(eG2, 0); if (ok(eG2) && floorOk) await go(eG2, at(-2.5, -3.8), 12, true); await gone(p, eG2); }
    { const eI2 = npcNear(p, "§7老人 イザク", PJ("isak", 8), true); act(eI2, "kneel"); re(eI2, "smile", "♪"); }
    const dI = load(p); if (dI) { qs(dI).jailIsak = 1; save(p, dI); }
  }
  await wait(30);
  sound(p, "random.door_open", 0.7);
  /* セオが 真犯人を 見つけて、衛兵長と 来る */
  const eS = npcAt(p, "§7学者 セオ", TRAITOR_JOB, at(-2.5, -3.8)), eGa = npcAt(p, "§6衛兵長 ガルム", PJ("glen", 16), at(-3.2, -3.8));
  if (floorOk) { const a = go(eS, at(-2.2, -1.2), 14, true), b = go(eGa, at(-2.8, 0.6), 16); await a; await b; }   /* 第125版: 通路の 奥から 走って くる */
  act(eH, 0); act(eR, 0); lookAt(p, eS);
  await say(p, "セオ", ["{sweat,汗}遅く なりました……！ 城門で 待って いたら、あなたたちが 連れて いかれたと 聞いて。", "{closed}セリーヌさんが、衛兵の 腰帯を 城門へ 届けて くれました。密告は、ニセの 衛兵の しわざです。……ここを 出ましょう。"]);
  act(eGa, "kneel");   /* 頭を 下げる */
  await say(p, "ガルム", ["{sad,汗}……すまなかった。王が §e玉座の 間§f で お待ちだ。直接 詫びたいと。"]);
  await hsay(p, V(["{rage,怒,jump}すまなかった、で 済むと 思ってるの！？ ……イザクさんも 一緒に 出して くれるなら、行く。"], ["{angry}……わたしたちは いいの。でも、イザクさんの ことも 話して ほしいわ。"], ["{closed}……王に 会う。イザクの 件も 話す。"], ["{angry}……お詫びは 王さまから 伺います。イザクさんの ことも、お話し させて ください。"]));
  await bye(p, eR, eGa, eS, eH); rmName(p, "§7老人 イザク", "§8看守 ブルーノ", "§bライバル レイ", "§7学者 セオ", "§6衛兵長 ガルム"); heroTmpClean(p);   /* 第124版: 暗く して から 玉座の 間へ */
  const d3 = load(p); if (!d3) return false; const s3 = qs(d3); s3.jailDone = 1;
  s3.keys = [...new Set([...(s3.keys || []), "k_tomb"])];   // v2.9.12: 先に 記録（このあと ぬけても 地図は もどる）
  save(p, d3);
  try { p.removeEffect("slowness"); } catch {}
  releaseJail(p);
  clearJail(ow, J);
  if (stageOf(p) && ok(p)) try { await wait(4); await stageMove(p, { x: p.location.x, y: p.location.y, z: p.location.z }, { R: 10, box: null, face: null, noEst: true }); } catch {}   /* 第125版: 舞台を 牢から 外へ もどす（牢の 中に 舞台が 残り、玉座の 間の 会話で カメラが 牢を 映した まま 止まって いた）*/
  big(p, "§a§l釈放された！", "§f濡れ衣が 晴れた");
  await wait(20);
  return true;
}
// ---------- メインクエスト ----------
// trig: いつ 起きるか（c = 状況）／ key: その だいじなものを 使うと 起きる ／ run: 進めば true
const has = (c, id) => hasKey(c.p, id);
const RIVAL_JOB = 17, TRAITOR_JOB = 18;   // v2.9.13: 作者の スキン（ライバル・学者セオ）
export const MQ = [
  { r: 0, ch: "第1章 旅立ち", at: "ranch", hint: "§fルミナの 外れの §eオルドの 牧場§f へ 行こう §7（右上の 案内。ライバル §bレイ§7 との 勝負も ここで）", trig: (c) => true,
    run: async (p, d) => {
      { const S0 = stageOf(p), rq = ranchSpot(); if (S0 && rq && !rq.rec && Math.hypot(S0.P.x - rq.x, S0.P.z - rq.z) < 30) ranchSave(S0.P); }   /* 第122版: 牧場の 場所を 記録（終章も ここ）*/
      const eO = npcNear(p, "§eオルド", PJ("ordo", 8), true); act(eO, "hold");
      if (!qs(d).introDone) {
        /* 第115版: 旅立ちの 朝。コンパスを 作った 幼なじみ（ヒロイン）を えらぶ。第122版: 場所は オルドの 牧場の 放牧地 */
        if (!qs(load(p) || d).hero) {
          const pick = await choose(p, "幼なじみ", "§f§lあなたの 幼なじみは だれ？\n\n§7小さい ころから いっしょに 育った 仲良しで、好奇心で 旅に ついて くる 仲間です。あとから かえる ことは できません。", HEROES.map((h) => [`§l${h[1]}§r\n§8${h[2]}`, `textures/ui/mrpg/h_${h[0]}`]));
          if (!(pick >= 0)) { rm(eO); return false; } const dh = load(p); if (!dh) { rm(eO); return false; } qs(dh).hero = HEROES[pick][0]; save(p, dh);
        }
        const eH = heroNear(p);
        await hsay(p, V(["{!,jump}あっ、いた いた！ おーい！", "{rage,怒}もう、遅い！ 今日が 旅立ちの 日だって、あれだけ 言ったのに！"],
          ["{smile}あ、来た来た。おはよう。", "{sweat,汗}旅立ちの 日なのに、ずいぶん ゆっくりね。……ふふ、あなたらしいけど。"],
          ["{closed}……やっと 来た。", "{angry}旅立ちの 日に 寝坊って、どういう 神経？"],
          ["{!}あっ、おはよう ございます！", "{sweat,汗}今日は 旅立ちの 日ですよ。……もう、心配しました。"]));
        hold(eH, "compass"); act(eH, "show", false);   /* 第125版: コンパスを 手に 持って 見せ、わたす */
        await hsay(p, V(["{blush,up}……ま、いいけど。はい、これ。", "{smile,☆}じゃーん！ わたしが 作った §e冒険の コンパス§f！ 行きたい 場所の 方を、ちゃんと 指して くれるの。"],
          ["{smile}はい、これ。わたしが 作った §e冒険の コンパス§f。", "{smile,♪}行きたい 場所の 方を、ちゃんと 指して くれるのよ。"],
          ["{closed}……これ。§e冒険の コンパス§f。行きたい 場所の 方を 指す。", "{blush}三日で 作った。……針が 狂ったら、すぐ 言って。"],
          ["{smile}これを どうぞ。わたしが 作った §e冒険の コンパス§f です。", "{closed}行きたい 場所の 方を 指します。……壊れたら すぐ 直しますから、言って くださいね。"]));
        await give(eH, null, "compass");
        try { p.addTag("mrpg_navi"); } catch {} if (!hasKey(p, "navi")) giveItem(p, "mrpg:navi", 1); sound(p, "random.levelup", 1);   /* 第124版: 二重に わたさない（つぎに 入った ときの 1回だけの 配布も 止める）*/
        if (ITEMS.k_wmap) {   /* 第124版: 世界地図も いっしょに */
          hold(eH, "scroll"); act(eH, "show", false);
          await hsay(p, V(["{smile,♪}それと、これも！ わたしが 描いた §e世界地図§f。11の 地方が ぜんぶ のってるの。", "{!,jump}行きたい 所を 選ぶと、コンパスが そっちを 指すんだよ！"],
            ["{smile}それから、これ。§e世界地図§f よ。11の 地方を ぜんぶ 描いたの。", "{smile,♪}行きたい 場所を 選ぶと、コンパスが 案内して くれるわ。"],
            ["{closed}……あと、§e世界地図§f。11の 地方、ぜんぶ 描いた。", "{blush}行き先を 選べば コンパスが 指す。……迷子に なられると 困るから。"],
            ["{smile}それと、こちらの §e世界地図§f も どうぞ。11の 地方を すべて 描きました。", "{closed}行き先を 選ぶと、コンパスが 案内します。"]));
          await give(eH, null, "scroll");
          const dk = load(p); if (dk) { try { p.addTag("mrpg_wmap"); } catch {} giveKey(p, dk, "k_wmap"); save(p, dk); }
        }
        /* 第122版: 最初の 仲間は オルドの 牧場の 子 */
        const g0 = palEnt(p); if (g0) { camNear(p, g0, 2.2, 0.7); await wait(10); }
        await say(p, "オルド", ["{smile}ほっほ。朝から にぎやかじゃのう。その 子も、すっかり おまえさんに なついて おる。"]);
        await hsay(p, V(["{?,up}ねえ 村長。なんで この子を くれたの？ 牧場には もっと 強そうな 子も いるのに。"], ["{?}村長さん。どうして この子だったの？ 牧場には ほかの 子も たくさん いるのに。"], ["{?}村長。なんで この子？ 強さで 選んだ わけじゃ なさそうだけど。"], ["{?}村長さま。どうして この子を 選ばれたんですか？"]));
        re(eO, "smile", "♪");
        await say(p, "オルド", ["{smile}わしが 選んだんじゃ ない。その子が 朝から ずっと、おまえさんの 後ろを ついて 回って おったんじゃ。", "{closed}モンスターの 目を 見れば、だれを 選んだかは 分かる。……昔、ちょっとな。"]);
        await hsay(p, V(["{rage,怒,jump}昔 ちょっとって 何よ！ ……もう、すぐ はぐらかすんだから。"], ["{smile,…}昔、ちょっと……ね。村長さんの『ちょっと』は、いつも 長い お話の 入り口よね。"], ["{closed}『昔、ちょっと』。……それ、答えに なってない。"], ["{sweat,汗}むかし、ちょっと……ですか。いつか、くわしく お聞かせ ください。"]));
        rmCine(g0);
        { const hk = hakuEnt(p, fwd(p, 8, 3)); if (hk) { turnTo(eO, hk.location); camPt(p, hk.location, 4, 1); await wait(16); }   /* 第125版(rs2): オルドは 放牧地の 奥の ハクの 方を 向く */
          await say(p, "オルド", ["{closed}旅に 出る 前に、放牧地の 奥で 寝とる §fハク§f にも あいさつ して いけ。"]);
          await hsay(p, V(["{smile,♪}ハク！ 小さい ころ、あの 背中で よく お昼寝 したよね。", "{sweat,汗}……たてがみに 絵を 描いて、二人で 叱られたっけ。"], ["{smile}ハク……。小さい ころ、あの 背中で よく お昼寝 したわね。", "{smile,…}……たてがみに 絵を 描いて、二人で 叱られたっけ。"], ["{closed}……ハク。小さい ころ、あの 背中で よく 寝た。", "{sweat,汗}……たてがみに 落書き して、二人で 叱られた。"], ["{smile}ハクさん……！ 小さい ころ、あの 背中で よく お昼寝 させて もらいました。", "{sweat,汗}……たてがみに 絵を 描いて、二人で 叱られましたね。"]));
          if (hk) { camNear(p, hk, 1.8, 0.6); await wait(12); }   /* 第125版 Q2: ハクの 寝顔へ 一拍 */
          await hsay(p, V(["{closed,…}……ハクの 背中で 寝て、ぜんぜん 起きなかった 冬も あったよね。わたし、朝まで 名前 呼んでたんだから。"], ["{closed,…}……ハクの 背中で 眠った まま、ちっとも 起きなかった 冬も あったわね。わたし、朝まで 名前を 呼んでたのよ。"], ["{closed}……ハクの 背中で 寝て、ぜんぜん 起きなかった 冬も あった。わたし、朝まで 名前 呼んでた。"], ["{closed,…}……ハクさんの 背中で 眠って、ずっと 起きなかった 冬も ありましたね。わたし、朝まで お名前を 呼んで いたんですよ。"]));
          rmCine(hk); }
        turnTo(eO); { const eHo = heroFind(p); if (ok(eO) && ok(eHo)) { const A = eO.location, B = eHo.location, n = Math.hypot(B.x - A.x, B.z - A.z) || 1; if (n > 2.6) await go(eO, { x: B.x + ((A.x - B.x) / n) * 2, y: A.y, z: B.z + ((A.z - B.z) / n) * 2 }, 12); } }   /* 第125版(rs2): 大事な 話の 前に 歩み寄る */
        await say(p, "オルド", ["{up}……さて。旅に 出る 前に、ひとつ 大事な 話を させて おくれ。"]);
        await pastCard(p, "§7―― 大昔の 言い伝え"); { const sk = fwd(p, 14, 0, 5); camPt(p, sk, 10, 2, 1.2); await wait(14); }   /* 第125版(rs2): 王と 十五枚の 石板の 話は 回想の 札 → 空の 引き */
        await say(p, "オルド", ["{low}大昔、§6「王」§f と 呼ばれる ものが おった。人と モンスターの §e心§f を 呑みこむ 怪物じゃ。", "人々は 王と、王に 従う 十四の §6主§f を、§d十五枚の 石板§f に 封じた。……その 封印が、今 ゆるみ始めて おる。"]);
        if (ok(eO)) { camNear(p, eO, 1.6, 1.5); await wait(8); }   /* 第125版 Q1 */
        await say(p, "オルド", ["{closed}……と、わしらは 教わった。石に 彫って ある ことが、本当とは かぎらんがの。"]);
        await hsay(p, V(["{shock,!,jump}ええっ！？ じゃあ、ときどき 町の 外に 出る あの 黒い 影って……"], ["{shock,…}……町の 外の、あの 黒い 影も？"], ["{closed}……町の 外の 黒い 影。あれも その せい？"], ["{shock,!}で、では、町の 外に 出る 黒い 影も……？"]));
        await say(p, "オルド", ["{closed}……うむ。そして 石板は、ごく まれに §b反応する 者§f を 選ぶ。", "{up}昨夜、わしの 預かる 石板が、おまえさんの 名を 呼ぶように 光った。"]);
        { const S7 = stageOf(p), eO7 = S7 && S7.ents.find((o) => ok(o) && /オルド/.test(String(o.nameTag || ""))); if (eO7) { camNear(p, eO7, 1.5, 1.55); await wait(14); } }   /* 第124版(fix2): 大事な 告げる 行の 前に 間 */
        await say(p, "オルド", ["{up}……おまえさんじゃよ。"]);
        await hsay(p, V(["{shock,!,up}…………へ？", "{rage,怒,jump}な、なんで この 寝ぼすけが！？ 村長、何かの まちがいじゃ ないの！？"],
          ["{shock,!}……まあ。", "{?}でも 村長さん、どうして この人なの？ 石板って、相手を 選ぶ ものなの？"],
          ["{shock,…}……は？", "{?}光った だけで 決めるの？ ほかに 根拠は？"],
          ["{shock,!,up}え……ええっ！？", "{?}あ、あの、どうして この人なんでしょうか。理由が あるなら 知りたいです。"]));
        await say(p, "オルド", ["{closed}理由は、わしにも 分からん。じゃが 石板の 光は、千年 うそを ついた ことが ない。", "8つの 地方の §6地方マスター§f が、石板を 一枚ずつ 預かって おる。", "{up}石板は、§e守り手に 勝った 者にだけ 渡す§f。それが 千年 続く 決まりじゃ。力の 足りない 者が 持てば、目覚めた 主に 呑まれるからのう。", "勝って 石板を 受け取り、目覚めた 主を 封じ直して くれんか。"]);
        await hsay(p, V(["{smile,☆,up}……ねえ。それって、すっごく おもしろそう！", "{smile,♪}決めた、わたしも ついて いく！ コンパスの 作り主が いないと 困るでしょ？", "{closed}……それに、旅の 手帳を つける 係も 要るしね。"],
          ["{smile}……じゃあ、わたしも 行くわ。ひとりで 行かせたら、ごはんも 食べ忘れそうだもの。", "{smile,♪}旅の 手帳は、わたしが つけるね。"],
          ["{closed}……仕方ない。わたしも 行く。コンパスの 調整が できるのは わたしだけだし。", "{up}旅の 手帳も わたしが つける。あなたは 字が 汚いから。"],
          ["{smile}……でしたら、わたしも お供します。", "{closed}旅の 手帳は わたしが つけます。何が あったか、ちゃんと 残して おきたいので。"]));
        await say(p, "オルド", ["ほっほ、頼もしい。……おお、孫の §bレイ§f が 来おった。"]);
        act(eH, 0);   /* 第124版: 主人公の 仲間は その場に 残る（消えて すぐ わき なおさない）*/
        const d1 = load(p); if (d1) { qs(d1).introDone = 1; save(p, d1); }
      }
      /* 第122版: レイは オルドの 孫（一つ 年上）。じいちゃんの 目が 正しいか 確かめに 来る */
      const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
      await say(p, "レイ", ["{closed}じいちゃんから 聞いた。……石板に 選ばれたのは、おまえ なんだってな。", "{angry}オレは ずっと、石板を 任される 日の ために 竜と 鍛えて きた。", "{sad,up}……なのに、選ばれたのは おまえか。小さい ころ、オレの 後ろを ついて 回ってた おまえが。", "{angry,!}じいちゃんの 目を 疑う わけじゃ ない。……でも、じいちゃんの 目が 正しいか、オレが この手で 確かめる。勝負だ。"]);
      { const eH0 = heroNear(p);
        await otsAt(p, e, eH0, 8);   /* 第125版(rs2): レイの 肩ごしに 幼なじみ（だれに 言って いるか）*/
        await hsay(p, V(["{rage,怒}なんで 勝負に なるの！ レイ、一つ 年上なんだから 大人げない！"], ["{?}レイくん。どうして 戦わないと 分からないの？ お話じゃ だめ？"], ["{?}勝負で 何が 分かるの？ 勝ったら 石板を 取りあげる つもり？"], ["{?}レイさん、なぜ 勝負なんですか？ 村長さまが お決めに なった ことなのに……"]));
        await say(p, "レイ", ["{closed}石板を 持てば、主と 戦う ことに なる。オレに 勝てない やつが、主に 勝てる わけ ないだろ。", "{angry}取りあげや しない。……負けたら、旅は オレが 一緒に 行く。それだけだ。"]);
        await say(p, "オルド", ["{closed}……受けて やって くれ。あの子なりの 心配じゃ。ここは 放牧地、思いきり やっても かまわん。"]); }
      await duel(p, "§b§lレイ", "§fレイの 竜が 放牧地に 舞い降りた！", { fams: ["dragon"] });
      const res = await battle(p, team(["dragon"], 1, 1, 0).map((t) => ({ ...t, lv: 1, q: 0 })), { name: "ライバル レイ", arena: "はじめての 勝負", easy: true, speaker: "レイ", lines: { half: "……やるな。手を 抜いてる わけじゃ ないのに", low: "くそっ……ここで 負けたら、オレは……！" } });
      await gone(p, e); await gone(p, eO);   /* 第124版(fix2): 映って いれば 暗い 中で 下げる */
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["……オレの 勝ちだ。その 腕で 主に 挑む 気か。", "鍛えて、もう一度 来い。", RT(p)]); return false; }
      const eR1 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true); act(eR1, "kneel");
      await say(p, "レイ", ["{sad,…}……負けた。", "{closed}わかったよ。じいちゃんの 目は、正しかった。", "{angry,up}でも、オレは あきらめない。いつか 必ず 追いつく。……覚えて おけよ。"]);
      cut(p); await hsay(p, V(["{sad}……レイ。小さい ころ、木登りで 負けても 夜まで 練習してたよね。", "{?}あの 竜も、ずっと ひとりで 育ててたの？"], ["{sad}……レイくん。昔から、負けると 夜まで ひとりで 練習してたわね。", "{?}その 竜も、ずっと ひとりで 育てて きたの？"], ["{closed}……レイ。昔から 負けると 夜まで 練習してた。", "{?}その 竜も、ひとりで 育てたの？"], ["{sad}……レイさん。昔から、負けた 日は 夜まで 練習して いましたね。", "{?}その 竜も、おひとりで 育てて きたんですか？"]));
      cut(p, "レイ"); re(eR1, "closed", "…");
      await say(p, "レイ", ["{closed}……卵の ときから な。じいちゃんの 牧場の 隅で。", "{angry}だから 次は 負けない。……旅の 先で、また 会おう。"]);
      act(eR1, 0); await leave(eR1, p, 10, false);
      const eO2 = npcNear(p, "§eオルド", PJ("ordo", 8), true); act(eO2, "hold"); re(eO2, "closed");   /* つえを 握る 手に、一瞬 力が こもる */
      await say(p, "オルド", ["{closed,息}……あの子は 負けずぎらいでのう。悪く 思わんで やって くれ。", "{smile,up}まずは §6アルカトラス城§f へ。地方マスター §6ミドリ§f が 一枚目の 石板を 預かって おる。", "{angry,low}町の 外は 物騒に なった。石板を 狙う 連中が うろついて おる。気を つけるんじゃぞ。"]);
      const eHm = heroNear(p, true); { await hsay(p, V(["{?}それって、町で いばってた『§5六影§f の ガロさま』って 人たち？"], ["{?}……町で『§5六影§f』って 名乗ってた 人たちの こと？"], ["{?}『§5六影§f』。町の 子が そう 言ってた。"], ["{?}町で『§5六影§f』と 名乗る 方々を 見かけましたが……"])); }
      re(eO2, "closed", "…"); if (ok(eO2)) { camNear(p, eO2, 1.8, 1.6); await wait(16); }   /* 第125版: 伏線。オルドが 一瞬 だまる */
      await say(p, "オルド", ["{angry,low}……その 名を、そう 軽く 口に するな。", "{closed}……いや、すまん。年寄りの 小言じゃ。", "{?}それと、近ごろ §7学者の セオ§f と いう 若者が 来て おる。石板と、町の まわりに 出る §8黒い 影§f を 調べて おるそうじゃ。", "{smile}……と 言いたいが、あさっては 収穫祭じゃ。旅立ちは 祭りを 見てからに せい。ミミが 原っぱで 人手を さがして おったぞ。", "§7→ 城へ 行く 前に、祭りの 原っぱの ミミの ところへ（右上の 案内）"]);
      await gone(p, eO2); if (ok(eHm)) await leave(eHm, p, 8, false);
      reward(p, d2, 500, [["c_herbs", 2], ["tms_beast", 1]]); save(p, d2);
      return true;
    } },
  { r: 0, hint: "§fルミナの §e北の 門§f を 出て、ガロを 追おう §7（さらわれた 小さな モンスターを 取り返す）", spot: () => garoSpot(), trig: (c) => c.r === 0 && !c.town,
    run: async (p, d) => {
      const e = npcNear(p, "§c六影の 下っぱ ガロ", PJ("garo", 9));
      const eHg = heroNear(p);
      /* 第115版: 相棒との 出会い（ガロと ピコに いじめられて いる 子を 助ける） */
      const palOld = !!findPartner(load(p) || d) || !!(load(p) || d).partnerId, firstMeet = !wonOf(p, "garo1");
      let eV = null, ePk = null;
      if (firstMeet) {
        ePk = npcNear(p, "§d手下 ピコ", PJ("pico", 9));
        eV = palVictim(p, e);
        const fest = !!(qs(load(p) || d).epx || {}).garoFest;   /* 第125版: 祭りの 夜（ep_r0.js）で もう 会って いる */
        { const S1 = stageOf(p); if (S1 && inScene(p)) { camAt(p, S1.at(-7, 4.5 * S1.side, 5.5), S1.at(3, 0, 1), 0.8); await wait(20); } }   /* 第124版(cam): 名乗りの 前に 場所を 見せる 引きの 絵 */
        big(p, "§c！", fest ? "§f道の 先で、ガロが 逃げた 子を 追いつめて いる……" : "§f道の 先で、だれかが 小さな モンスターを 追いつめて いる……", "mob.villager.no");
        if (ok(eV)) { lookAt(p, eV); act(e, "point"); }
        await say(p, "ガロ", ["{angry,low}ちっ、袋を 食いやぶりやがった。ピコ、そっちの 道を ふさげ。……たたくな、立ってる だけで いい。"]);
        await say(p, "ピコ", ["{sweat,汗}う、うん……。……ごめんね、こわく ないよ。こっちに 来ないで……。"]);
        if (ok(eV) && ok(e)) { await knock(eV, e.location, 2); sound(p, "mob.wolf.hurt", 1.2); }
        await hsay(p, V(["{rage,怒,up}ちょっと！！ なに やってるの！！"], ["{shock,!}……やめて！ その子、こわがってる！"], ["{angry,!}……ちょっと。あなたたち、何してるの。"], ["{shock,!,up}お、お待ち ください！ その子に 何を するんですか！"]));
        if (ok(eHg) && ok(eV)) { const q = eV.location; await go(eHg, { x: q.x + 0.8, y: q.y, z: q.z + 0.8 }, 12, true); act(eHg, "guard"); }
        if (fest) await hsay(p, V(["{angry,怒,up}やっぱり ガロ！ 祭りの 屋台の 次は、その 子！？ ……袋を 持ってた 子も、いっしょなんだ。"], ["{sad,up}……やっぱり ガロさん。屋台の 次は、その 子なの……？ 袋を 持ってた 子も、いっしょなのね。"], ["{angry,up}……ガロ。屋台の 次は その 子。……袋を 持ってた 子も いる。"], ["{angry,up}やはり ガロさん！ お祭りの 屋台の 次は、その 子ですか！ ……袋を 持って いた 子も、ごいっしょなんですね。"]));
        else await hsay(p, V(["{angry,怒}よってたかって 小さい子 いじめて、はずかしく ないの！？ あなたたち、だれ！？"], ["{sad}……どうして そんな ことを するの？ あなたたち、だれ？"], ["{angry}二人がかりで 小さい子を。……名前くらい 名乗ったら？"], ["{angry}弱い ものを 囲むなんて、ひきょうです！ どなたですか！"]));
        lookAt(p, e);
        if (fest) await say(p, "ガロ", ["{angry}……しつこい 連中だ。祭りで 恥を かかされた 借りは、ここで 返す。", "{!}石板が 反応したって いう ガキ。……それに、この チビが 石板の 匂いを させてる。", "{low}§5六影§f の ガロさまが もらって いく。石板も、そいつも 渡せ。", "{closed}……ピコは 関係ねえ。見張りを させてる だけだ。"]);
        else await say(p, "ガロ", ["{angry}……なんだ、お前ら。……いや、待て。", "{!}お前だな、石板が 反応したって いう ガキは。ルミナの 噂は 早いんだよ。", "オレは §5六影§f の ガロ。団は 石板を 集めてる。石板も、そいつも 渡せ。そうすりゃ 手荒な ことは しない。", "{closed}……そっちの 小さいのは ピコ。見張りを させてる だけだ、関係ねえ。"]);
        await hsay(p, V(["{angry}だれが 渡すもんですか。……ほら、やっちゃって！"], ["{closed}……渡さない。この子も、石板も。"], ["{closed}渡す 理由が ない。……行くよ。"], ["{angry}お断り します！ ……お願い、力を 貸して！"]));
      } else {
        big(p, "§c！", "§fだれかが 道を ふさいだ！", "mob.villager.no");
        await say(p, "ガロ", ["{angry,low}……止まれ。", "石板を 渡せ。そうすりゃ 手荒な ことは しない。"]);
      }
      const res = wonOf(p, "garo1") ? "win" : await battle(p, team(["beast", "animal", "animal"], 2, 2).map((t) => ({ ...t, lv: 2, q: 0 })), { name: "六影の 下っぱ ガロ", arena: "六影", easy: true, speaker: "ガロ", lines: { half: "ちっ……こっちも 引けねえんだよ……！" } });
      if (res === "win") setWon(p, "garo1");
      rm(e); rm(ePk);
      if (res !== "win") { rm(eV); rm(eHg); await sayAt(p, "§c六影の 下っぱ ガロ", PJ("garo", 9), "ガロ", ["……今日は 見逃して やる。次は ねえぞ。", RT(p)]); return false; }
      if (!qs(load(p) || d).palMet) {   /* 助けた 子が 相棒に なる（すでに 相棒が いる 古い セーブは 見送るだけ） */
        if (!ok(eV)) eV = palVictim(p, null);
        if (ok(eV)) { lookAt(p, eV); await go(eV, { x: p.location.x + 0.8, y: p.location.y, z: p.location.z + 0.8 }, 16); }
        await hsay(p, V(["{sad}……だいじょうぶ？ いたかったね。", "{!,shock}……あれ？ この子、あなたの 足もとから はなれない。", "{smile,♥,up}ふふっ、なつかれちゃったね。……ねえ、連れて 行って あげようよ。"], ["{sad}……だいじょうぶ？ いたかったわね。", "{!,shock}……あら？ この子、あなたの 足もとから はなれないわ。", "{smile,♥,up}ふふ、なつかれちゃったのね。……ねえ、連れて 行って あげましょう？"], ["{sad}……平気？ 痛かったな。", "{!,shock}……この子、あなたの 足もとから 離れない。", "{smile,up}なつかれた。……連れて いけば？"], ["{sad}……だいじょうぶですか？ いたかったですね。", "{!,shock}……あら？ この子、あなたの 足もとから はなれません。", "{smile,♥,up}ふふ、なつかれましたね。……連れて 行って あげませんか？"]));
        if (palOld) await leave(eV, p, 8, true); else { particle(eV, "minecraft:villager_happy", 0.6); sound(p, "random.orb", 0.6); await wait(6); rm(eV); }   /* 第124版: 森へ かけて いく／光って 相棒の 箱へ（目の 前で ふっと 消えない）*/
        const dP = load(p); if (!dP) { rm(eHg); return false; }
        let pm = palOld ? findPartner(dP) : null;
        if (!palOld) {
          await notice(p, "相棒との 出会い", "§f助けた 小さな モンスターが、あなたの そばを はなれない。\n\n§eこの 子が あなたの §b相棒§e に なります。§7タイプ（系統）・見た目・名前・性格・初期スキルを 決めよう。");
          pm = await partnerEditor(p, dP, null);
          if (!pm) { rm(eHg); await notice(p, "相棒", "§7ガイドブック → ストーリー →「物語の 戦いに 再挑戦」を えらぶと、もう 一度 相棒を 決められます。"); return false; }
        } else await hsay(p, V(["{smile}……行っちゃった。元気でね！ §7（小さな モンスターは 森へ 帰って いった）"], ["{smile}……行っちゃったわね。元気でね。 §7（小さな モンスターは 森へ 帰って いった）"], ["{closed}……行った。元気で。 §7（小さな モンスターは 森へ 帰って いった）"], ["{smile}……行って しまいましたね。お元気で！ §7（小さな モンスターは 森へ 帰って いった）"]));
        const dQ = load(p); if (dQ) { qs(dQ).palMet = 1; save(p, dQ); }
        if (pm && !palOld) await hsay(p, V([`{smile,♪}よろしくね、${pm.nm}！ ……わたしの ことも 忘れないでよ？`], [`{smile}よろしくね、${pm.nm}。……わたしの ことも 覚えて いてね。`], [`{closed}……よろしく、${pm.nm}。わたしの ことも 忘れるな。`], [`{smile}よろしく お願い しますね、${pm.nm}さん。……わたしの ことも 覚えて いて くださいね。`]));
      }
      rm(eHg);
      const d2 = load(p); if (!d2) return false;
      /* 第106版: 第1章を 濃く（ガロの 連戦・手下の 少年ピコ・町を 襲う 影・セオ） */
      if (!qs(d2).ch1b) {
        if (!qs(load(p) || d2).ch1x) {
        const e2 = npcNear(p, "§c六影の 下っぱ ガロ", PJ("garo", 9)), eP = npcNear(p, "§d手下 ピコ", PJ("pico", 9));
        cut(p, "ガロ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
        await say(p, "ガロ", ["{angry}……待て。まだ 終わって ねえ。"]);
        if (ok(eP) && ok(e2)) { const q = e2.location; await go(eP, { x: q.x + 1.1, y: q.y, z: q.z + 0.6 }, 10, true); }   /* 第124版(合議): 2戦目は なし。ピコが 止めに 入る */
        await say(p, "ピコ", ["{sad,up}兄ちゃん、もう やめよう……！ この 人たち、あの 子を 助けに 来た だけだよ。"]);
        await say(p, "ガロ", ["{closed}……だまって 見てろ、ピコ。"]);
        if (ok(e2)) { turnTo(e2, fwd(p, 20, 6, 2)); camNear(p, e2, 4.4, 1.4, 0.4); await wait(4); camNear(p, e2, 2, 1.5, 2); }   /* 第125版(rs): ガロの 身の上は ゆっくり 寄る（rs2: 背を 向けて 話す）*/
        await say(p, "ガロ", ["悪いな、石板の ガキ。オレたちは 親も 家も ねえ。……ピコとは、旅の 道で 会った。六影に 拾われて、やっと 屋根の 下で 飯が 食えるように なったんだ。"]);
        if (ok(eP)) { camNear(p, eP, 2, 1.2, 0.5); await wait(10); }   /* 第125版(rs): 聞いて いる ピコの 顔 */
        turnTo(e2);
        await say(p, "ガロ", ["石板か、石板に なつく モンスターか。どっちか 持って 帰れなきゃ、また 外だ。"]);
        cut(p); await hsay(p, V(["{sad}……だからって、こわがる 子を 袋に 入れて いいの？", "{?}屋根が ほしいなら、ルミナに 来れば いいじゃない。村長なら……"], ["{sad}……それでも、こわがる 子を 袋に 入れるのは ちがうわ。", "{?}屋根なら、ルミナにも あるのよ。村長さんに 話せば……"], ["{closed}……事情は 分かった。でも、袋に 詰めて いい 理由には ならない。", "{?}屋根なら ルミナにも ある。村長に 話せば？"], ["{sad}……ご事情は 分かりました。でも、こわがる 子を 袋に 入れるのは……", "{?}屋根なら、ルミナにも あります。村長さまに お願い すれば……"]));
        cut(p, "ガロ");
        await say(p, "ガロ", ["{angry,low}……よその 村の 長に 頭 下げて、また 追い出されろってか。", "{closed}一度 名前を 売った やつに、帰る 所なんか ねえんだよ。"]);
        { const dx = load(p); if (dx) { qs(dx).ch1x = 1; save(p, dx); } }
        }
        let e3 = null;
        if (!qs(load(p) || d2).ch1y) {
        e3 = npcNear(p, "§c六影の 下っぱ ガロ", PJ("garo", 9)); const eP2 = npcNear(p, "§d手下 ピコ", PJ("pico", 9));
        const eH1 = heroNear(p);
        await say(p, "ピコ", ["{sad}……兄ちゃん、ごめん。ぼく、袋を ちゃんと しばれなかった。"]);
        await hsay(p, V(["{q}……ねえ、あの子 ふるえてる。ほんとは 戦いたく ないんじゃ ない？"], ["{sad}……あの子、ずっと ふるえてる。"], ["{closed}……あの子、戦う 顔じゃ ない。"], ["{sad}……あの子、ふるえて います。"]));
        act(eP2, "point"); act(e3, "up");
        await say(p, "ピコ", ["……兄ちゃん、あれ。空が……黒い……"]);
        { const L0 = ok(eP2) ? eP2.location : p.location, S0 = stageOf(p), far = S0 ? stagePt(S0, 20, -4) : { x: L0.x, y: L0.y, z: L0.z - 16 };
          if (S0) camAt(p, S0.at(-2.5, 5 * S0.side, 5.5), S0.at(9, -1, 1.5), 0.5); else camAt(p, { x: L0.x + 7, y: L0.y + 6, z: L0.z + 7 }, { x: far.x, y: far.y + 1, z: far.z + 6 }, 0.5);   /* 引きの 絵: 向こうから 影が 来る */
          big(p, "§4§l影", "", "mob.wither.spawn");
          await shadowFlow(p, far, L0, 26);
          boom(p.dimension, L0); sound(p, "random.explode", 1); shake(p, 0.8, 0.8); flash(p, true);
          await Promise.all([knock(e3, L0, 4), (async () => knockP(p, L0))()]);   /* ガロと あなたが 吹っ飛ぶ */
          await wait(6);
          lookAt(p, eP2); await engulf(p, eP2);   /* ピコが 影の うずに 呑まれて 倒れる */
          await wait(10);
          const town = (() => { try { const t = getTown("t0"); return t && t.built ? { x: t.x, y: L0.y, z: t.z } : { x: L0.x, y: L0.y, z: L0.z + 30 }; } catch { return { x: L0.x, y: L0.y, z: L0.z + 30 }; } })();
          camAt(p, S0 ? S0.at(4.5, -3.5 * S0.side, 3) : { x: L0.x - 4, y: L0.y + 3, z: L0.z - 4 }, { x: town.x, y: town.y + 4, z: town.z }, 0.8);   /* 影は 町の 方へ */
          await shadowFlow(p, L0, { x: L0.x + (town.x - L0.x) * 0.6, y: L0.y, z: L0.z + (town.z - L0.z) * 0.6 }, 30);
          if (ok(e3) && ok(eP2)) { const q = eP2.location; await go(e3, { x: q.x + 1.2, y: q.y, z: q.z }, 12, true); } act(e3, "kneel"); lookAt(p, e3); }
        await say(p, "ガロ", ["{shock,!,up}……ピコ！！"]);
        await hsay(p, V(["{shock,!,up}……え！？ あの子……呑みこまれた……！？", "{sweat,汗}な、なによ あれ……。さっきまで そこに 立ってたのに……！"], ["{shock,…,up}……今の、なに……？ あの子が……", "{sad}さっきまで、そこに いたのに……"], ["{shock,!}……影が、あの子を 呑んだ。", "{sweat,汗}……落ちついて。まだ、町へ 向かって る。"], ["{shock,!,up}い、今……あの子が……！", "{sad,汗}そんな……さっきまで 立って いたのに……！"]));
        await say(p, "ガロ", ["{sad,…}おい、ピコ。……返事を しろ。", "{cry,tears,up}屋根の ある 所で 寝かせて やるって、約束 したろ。……なあ。"]);
          await gone(p, eP2); const dy = load(p); if (dy) { qs(dy).ch1y = 1; save(p, dy); }   /* 第125版: 旅の 仲間は 下げない（戦いの あと 同じ 立ち位置に もどる。前は 戦いの あと 消えて、セオの 場面で また わいて いた）*/
        } else e3 = npcNear(p, "§c六影の 下っぱ ガロ", PJ("garo", 9));
        big(p, "§4§l影が 町へ……", "§7影は 地面を すべって、ルミナの 方へ 流れて いった", "mob.wither.ambient");   /* 第124版(dir#3): 北の 門では 戦わない（戦いは 祭りの 夜 r0e4 に 1本）*/
        { const q = ok(e3) ? e3.location : p.location; await shadowFlow(p, q, { x: q.x, y: q.y, z: q.z + 10 }, 20); }
        fadeOn(p, "0.3 0.5 0.5", "0 0 0", true); await wait(10);
        rm(e3);
        const eP3 = npcNear(p, "§d手下 ピコ", PJ("pico", 9), true), e4 = npcNear(p, "§c六影の 下っぱ ガロ", PJ("garo", 9), true);
        act(eP3, "down"); try { const q = eP3.location, S = stageFor(e4), w = (S && freeNear(S, { x: q.x + 1.3, y: q.y, z: q.z }, e4, 1.25, 1.4)) || { x: q.x + 1.3, y: q.y, z: q.z }; if (S) S.dest.set(e4.id, w); e4.teleport(w, { facingLocation: q }); } catch {} act(e4, "hold");   /* 眠った ピコを ガロが だきかかえる */
        lookAt(p, eP3); await shadowFlow(p, eP3.location, { x: eP3.location.x, y: eP3.location.y + 4, z: eP3.location.z }, 16);   /* 残った 影が ほどけて 消える */
        await say(p, "ガロ", ["{sad,up}……ピコ。……息は、してる。", "{cry,tears}なのに……なんで 起きねえんだよ……"]);
        await say(p, "ガロ", ["……あの 影、町の 方へ 行きやがった。", "影に 呑まれた やつは、心を 持って いかれる。体は 生きてても、もう 起きねえって 話だ。", "団の 上の 連中は 言ってた。石板を 集めて 王を 起こせば、§e呑まれた 心も 戻る§f って。", "……ピコは、起きるのか。なあ。", "§7（答えを 待たずに、ガロは 眠った ピコを 背負って 去って いった。帽子は ガロの 腰に 下がって いた）"]);
        act(e4, "hold"); await bye(p, e4, eP3);   /* 第124版: ガロが ピコを 背負って 去る 間は 暗く */
        const d3 = load(p); if (d3) { qs(d3).ch1b = 1; save(p, d3); }
      }
      const eHs = heroNear(p, true);
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB);
      lookAt(p, eS); act(eS, "run", false); await wait(14); act(eS, 0);   /* 町の 方から 走って くる セオ */
      await say(p, "セオ", ["{shock,!}大丈夫ですか！？ ……よかった、けがは ないようですね。", "{sad}今の 影を 追って ここまで 来ました。……間に合わなくて、すみません。", "{closed,low}あれは §5影の モンスター§f。封印の ゆるんだ 石板から にじみ出て、人や モンスターの 心を 呑みこむんです。"]);
      await otsAt(p, eS, eHs, 8);   /* 第125版(rs2): セオの 肩ごしに 幼なじみ（セオに 聞く）*/
      await hsay(p, V(["{?}……あなた、だれ？ なんで 影の ことを そんなに 知ってるの？"], ["{?}あの……どちらさま？ 影に、ずいぶん くわしいのね。"], ["{?}……だれ？ 影を 追って きたって、どうやって？"], ["{?}あ、あの、あなたは……？ どうして 影の ことを？"]));
      await say(p, "セオ", ["{smile,汗}ああ、失礼。僕は セオ。王立の 書庫で 石板を 研究して いる 学者です。", "影は 石板の 近くに 出る。だから 跡を 追えるんです。……さっきの 少年は、眠って いるだけ。心が 呑まれた 人は、まだ 戻れる はずです。"]);
      if (ok(eS)) { camNear(p, eS, 1.6, 1.5); await wait(8); }   /* 第125版 A04 */
      await say(p, "セオ", ["{closed,low}呑まれた 人は 眠ります。石に なるのは……別の、もっと 古い 災いです。"]);
      cut(p); await hsay(p, V(["{sad}……ガロ、『ピコは 起きるのか』って 聞いたの。わたし、何も 言えなかった。", "{?}ねえ、どう したら 起きるの？"], ["{sad}……ガロさん、『起きるのか』って 聞いたのに、わたし 答えられなかった。", "{?}どう したら、あの子は 目を さますの？"], ["{closed}……『起きるのか』って 聞かれて、答えられなかった。", "{?}どう すれば 起きる？"], ["{sad}……ガロさんに『起きるのか』と 聞かれて、何も お答え できませんでした。", "{?}どう すれば、ピコさんは 目を さますんですか？"]));
      cut(p, "セオ"); re(eS, "closed", "…");
      await say(p, "セオ", ["{closed}……正直に 言います。まだ、分かりません。", "{up}ただ、影は 石板から にじむ。石板を 一枚ずつ 封じ直せば、影は 細く なる はずです。", "{smile}あなたが 石板を 集める ことは、あの 少年の ためにも なる。……僕は そう 信じて います。"]);
      await hsay(p, V(["{?}……石板が ほしい だけなら、なんで 屋台や 小さい 子まで。手帳に 書いとく。『六影の 下っぱは、なぜ 止められないのか』。"], ["{?}……石板が ほしい だけなら、どうして 屋台や 小さな 子まで……。手帳に 書いて おくね。『六影の 下っぱは、なぜ 止められないのか』。"], ["{closed}……石板が 目当てなら、屋台も 小さい 子も 関係ない はず。手帳に 書く。『六影の 下っぱは、なぜ 止められないのか』。"], ["{?}……石板が ほしい だけなら、なぜ 屋台や 小さな 子まで。手帳に 書いて おきます。『六影の 下っぱは、なぜ 止められないのか』。"]));
      await say(p, "セオ", ["{closed,…}……上が、止めない からでしょう。……止めない わけが、あるのかも しれません。"]);
      act(eS, "hold");
      await say(p, "セオ", ["これは 僕の 研究メモの 写しです。石板と 各地方の ことを 書きとめて あります。迷ったら 開いて ください。"]);
      if (ok(eS)) { camNear(p, eS, 1.1, 1.1); await wait(10); }   /* 第125版 Q3: 表紙に 一拍（台詞では ふれない） */
      await narr(p, "", ["§7（研究メモの 表紙に、紫の インクで 押した、ひらいた 本の 形の 判）"]);
      act(eS, 0);
      await hsay(p, V(["{?}……あれ？ この 頁、何か 書いて 消した 跡が ある。"], ["{?}……ここ、何か 書いて 消して あるのね。"], ["{closed}……この 頁、消し跡が ある。"], ["{?}あの、この 頁……何か 消した 跡が ありますね。"]));
      await say(p, "セオ", ["{smile}ああ、書き損じです。気に しないで ください。", "{shock,!}……いけない。影は 人の 多い 方へ 流れる。今夜、いちばん 人が 多いのは――", "{up}祭りです！ 原っぱへ もどりましょう！", "§7（研究メモは【だいじなもの】に 入る。→ 祭りの 原っぱへ。右上の 案内）"]);
      if (!(qs(load(p) || d2).techo || []).includes("ピコ")) await hsay(p, V(["{sad}……ピコくんの 名前、手帳に 書いとく。起きる 日まで、忘れない ように。"], ["{sad}……ピコくん。手帳に 名前を 書いて おくね。"], ["{closed}……ピコ。手帳に 書いた。起きたら、消す。"], ["{sad}ピコさんの お名前、手帳に 書いて おきます。……起きる 日まで。"]));
      techo(p, "ピコ");
      rm(eS); rm(eHs);
      giveKey(p, d2, "k_note"); reward(p, d2, 300);
      save(p, d2); return true;
    } },
  { r: 0, seal: 0, nospot: 1, hint: "§fアルカトラス城の §6地方マスター ミドリ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(0),
    run: async (p, d) => {
      await gateOpen(p, 1, "セオ", ["（手紙）一枚目の 封印、見届けました。王への 報告も 済ませました。", "……シルヴァの 森の 方から、嫌な 風が 吹いて います。先に 行って 調べて おきます。§eシルヴァの 洞くつの 入口§f で 待って います。"]);
      const H = heroBox(p, true); await hsay(p, V(["{smile,☆}セオさんから 手紙！ 次は 森だって。"], ["{smile}セオさんから お手紙。……森で 待ってるって。"], ["{closed}セオから。次は シルヴァの 洞くつ。"], ["{smile}セオさんから お手紙です。森の 洞くつで 待って いらっしゃると。"]));
      cut(p); await hsay(p, V(["{closed}一枚目の 石板、ほんとに 手に 入れたんだね。……持つと、ちょっと あったかい。", "{?}『嫌な 風』って、また あの 影かな。ピコみたいな 子が 増える 前に、行こう！"], ["{closed}一枚目の 石板……。手に のせると、ほんのり あたたかいのね。", "{sad}『嫌な 風』……また あの 影かしら。ピコくんみたいな 子が 増える 前に、行きましょう。"], ["{closed}一枚目。……石なのに、少し あたたかい。", "{up}『嫌な 風』は たぶん 影。被害が 広がる 前に 森へ。"], ["{closed}一枚目の 石板……石なのに、ほんのり あたたかいです。", "{up}『嫌な 風』は、きっと あの 影です。ピコさんのような 方が 増える 前に、森へ 参りましょう。"]));
      H.rm(); return true; } },
  { r: 1, ch: "第2章 森の 精霊石", at: "cave", hint: "§fシルヴァ大森林の §e大樹の 根の 洞くつ（入口）§f へ 行こう §7（セオが 待って いる）", trig: (c) => c.r === 1,
    run: async (p, d) => {
      /* 第121版: 洞くつの 入口。セオが 待って いる（第1章の 手紙で 約束）*/
      const r1x = epD(d, "r1e3");   /* 第124版(dir#4): 森を もう 回った あとは「初めての 森」の 台詞に しない */
      if (!r1x) big(p, "§2§lシルヴァ大森林", "§f森の 洞くつの 入口で セオが 待っている");
      const H = heroBox(p, true);
      let eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB);
      if (r1x) {
        await hsay(p, V(["{smile,☆,up}セオさん、お待たせ！ ピピちゃんの 薬、今ごろ 煮えてる ころだね。"], ["{smile}セオさん、お待たせ。ピピちゃんの お薬、今ごろ 煮えて いる ころね。"], ["{closed}……待たせた。ピピの 薬、今ごろ 煮えてる。"], ["{smile}セオさん、お待たせ しました。ピピさんの お薬、今ごろ 煮えて いる ころですね。"]));
        await say(p, "セオ", ["{smile}よかった。森の 病みは、表で 見た とおりです。", "{closed}もとを たどると、この §e洞くつ§f の 奥に 行き着く。森を 守る §d精霊§f が いる と、古い 記録に あります。"]);
        cut(p); await hsay(p, V(["{?}精霊って、話せるの？ 森が 病んだ わけ、聞けるかな。"], ["{?}精霊さんに 会えたら、森が 病んだ わけを 聞けるかしら。"], ["{?}精霊に 会えば、原因が 分かる？"], ["{?}精霊さまに お会い できれば、原因が 分かるのでしょうか。"]));
        cut(p, "セオ"); await say(p, "セオ", ["{closed}記録の とおりなら。……ただ、弱って いれば 声も 細い。急ぎましょう。"]);
      } else {
      await hsay(p, V(["{shock,!,jump}うわあ……木が 空まで 届いてる！", "{?}……でも 静かすぎない？ 鳥の 声が ぜんぜん しない。"], ["{smile}大きな 木……。", "{?}……でも、鳥の 声が しないわ。森が 息を ひそめてる みたい。"], ["{closed}……鳥が 鳴いてない。", "{?}森が 何かに おびえてる。"], ["{shock,!}なんて 大きな 木……。", "{?}……あの、鳥の 声が 一つも しませんね。"]));
      await say(p, "セオ", ["{!}来て くれましたか。……この 森は 今、おかしい。葉が 灰色に くすんで、モンスターが おびえて 暴れて いる。", "{up}この §e洞くつ§f の 奥に、森を 守る §d精霊§f が いる と 古い 記録に あります。森が 病んだ わけは、きっと そこに。"]);
      }
      act(eS, "hold");
      await say(p, "セオ", ["中は 真っ暗です。この §6懐中電灯§f を。持って いるだけで 明るく なります。"]);
      act(eS, 0); giveKey(p, d, "k_light"); save(p, d);
      cut(p, "");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
      await hsay(p, V(["{smile,☆,jump}洞くつ探検！ わくわく してきた！"], ["{smile}ありがとう、セオさん。暗い ところ、ちょっと 苦手なの。"], ["{closed}……準備が いいね。"], ["{smile}ありがとう ございます。お借りします。"]));
      /* 第106版: 病んだ 森の 群れ・ベリル 初登場 */
      if (!qs(d).ch2a) {
        if (!r1x) {   /* 第124版(合議): 森の 話で もう「おびえた 野生を しずめる」戦いを して いる（同じ 拍を くり返さない）*/
        const q = fwd(p, 6);
        sound(p, "mob.wolf.growl", 0.7); shake(p, 0.25, 0.4); burst(p.dimension, q, "minecraft:spore_blossom_ambient_particle", 10, 1.6, 0.4);
        big(p, "§2§l森が 病んで いる", "§7葉の 色が 灰色に くすんで いる", "mob.wolf.growl");
        if (camPt(p, q, 4, 1)) await wait(16);   /* 草むらが ゆれる */
        act(H.e, "guard");
        await hsay(p, V(["{shock,!,up}草むらから 何か 来る！ ……目が 赤い！"], ["{shock,!}……何か 来る。目が、赤い……"], ["{angry,!}来る。目が 赤い。"], ["{shock,!,up}く、草むらから 何か！ 目が 赤いです！"]));
        await say(p, "セオ", ["{sweat,汗}おびえて 暴れて いるんです……！ 傷つけずに、しずめて あげて ください！"]);
        }
        const r1 = r1x ? "win" : await battle(p, team(["animal", "blob", "animal"], 12, 3), { name: "病んだ 森の モンスター", arena: "病んだ 森", theme: "forest", speaker: "森の モンスター", lines: { half: "……グルル……コエ……", low: "……キュウ……" } });
        if (r1 !== "win") { rm(eS); await sayAt(p, "§7学者 セオ", TRAITOR_JOB, "セオ", ["{sweat,汗}だ、大丈夫ですか！？ いったん 下がって！", RT(p)]); H.rm(); return false; }
        H.e;
        const eB = npcNear(p, "§5六影 ベリル", PJ("beryl", 9));
        await sixMark(p, eB, "beryl");   /* 第125版: 名乗りの 演出 */
        re(H.e, "shock", "!");
        if (r1x) await hsay(p, V(["{!,up}森で 白紙の 紙を 落とした、灰色の 服の 子……！"], ["{!}……森で 白紙の 紙を 落として いった、灰色の 服の 子ね。"], ["{!}……森の、灰色の 子。白紙の 紙を 落とした。"], ["{!,up}森で 白紙の 紙を 落とされた、灰色の 服の 方……！"]));
        await say(p, "ベリル", r1x ? ["{sad,…}……あの 紙、返して。……ううん、もう いい。", "{closed,low}……見つけた。ルミナで ガロを 退けた、石板の 子。"] : ["{closed,low}……見つけた。ルミナで ガロを 退けた、石板の 子。"]);
        await hsay(p, r1x ? V(["{?,!}……なんで わたしたちの ことを 知ってるの？ あなた、六影なの？"], ["{?}……あなたも、六影の 人なの？"], ["{?}……六影の 人、だったんだ。"], ["{?}あ、あなたも 六影の 方なのですか？"]) : V(["{?,!}……だれ？ なんで わたしたちの ことを 知ってるの？"], ["{?}……あなたは、どなた？"], ["{?}……だれ。六影の 人？"], ["{?}ど、どちらさまですか？"]));
        await say(p, "ベリル", ["{closed}わたしは ベリル。六影の §e幹部候補§f。……まだ、候補。", "{angry}石板を 一枚 持って 帰れば、正式に 仲間に して もらえる。そう 約束 されてるの。", "{sad,up}わたしの いた 一座は、影に 呑まれた。袖に いた わたしだけ……。帰る 場所は、もう 六影しか ないの。"]);
        act(H.e, "guard");
        await hsay(p, V(["{angry,怒,wide}事情は わかった。でも 石板は 渡さない！ この子に 手は 出させないよ！"], ["{sad}……つらかったのね。でも、石板は 渡せない。ごめんなさい。"], ["{closed}同情は する。でも 渡す 理由には ならない。"], ["{angry}お気の毒です。……ですが、石板は お渡し できません！"]));
        const r2 = await battle(p, team(["beast", "blob"], 16, 2, 50, leadOf("beast", 16)), { name: sixName("beryl"), arena: "六影", hpk: 4.5, extra: 0.4, tag: "幹部候補", sboss: true, speaker: "ベリル", lines: { half: "負けられない……負けたら、また 一人に なる……", low: "……いや。まだ、終わりたく ない……" } });
        rm(eB);
        if (r2 !== "win") { rm(eS); await sayAt(p, "§5六影 ベリル", PJ("beryl", 9), "ベリル", ["……勝った。でも、石板を 奪う 力までは 残って ない。……また 来るわ。", RT(p)]); H.rm(); return false; }
        H.e; const eB2 = npcNear(p, "§5六影 ベリル", PJ("beryl", 9), true); act(eB2, "kneel");
        await say(p, "ベリル", ["{sad,…}……また、だめだった。", "{sad,up}ねえ。あなたには、帰る 場所が ある？ ……ううん、答えなくて いい。"]);
        act(eB2, 0); await leave(eB2, p, 12, true);   /* 森の 奥へ 走り去る */
        await hsay(p, V(["{?}……行っちゃった。", "{sweat,汗}なんだか、迷子みたいな 顔 してたね。"], ["{sad}……迷子の 子みたいな 目を してた。"], ["{closed}……帰る 場所、か。"], ["{sad}……あの方、迷子の ような お顔でした。"]));
        cut(p, "セオ"); re(eS, "closed", "…");
        await say(p, "セオ", ["{closed}……一座、と 言って いましたね。旅の 芝居の 一座でしょう。", "{sad}帰る 場所の ために 戦う。……あの 子を 責める 言葉は、僕には ありません。"]);
        cut(p); await hsay(p, V(["{sad}……うん。ガロも 同じ こと 言ってた。屋根が ほしいって。", "{closed}六影って、そういう 子ばっかり 集めてるのかな。"], ["{sad}……ガロさんも、屋根の 話を してたわね。", "{?}六影には、帰る 場所の ない 子ばかり いるのかしら。"], ["{closed}……ガロも 屋根の 話を してた。", "{?}六影は、帰る 場所が ない 人を 集めてる？"], ["{sad}……ガロさんも、屋根の お話を されて いました。", "{?}六影には、帰る 場所の ない 方ばかりが いるのでしょうか。"]));
        const d2 = load(p); if (d2) { qs(d2).ch2a = 1; save(p, d2); }
      }
      if (!ok(eS)) eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB, true);
      cut(p, "セオ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
      await say(p, "セオ", ["{closed}洞くつの 坂道を、いちばん 奥の §e大広間§f まで。僕は 外で、影が 来ないか 見張って います。"]);
      cut(p); await hsay(p, V(["{?}えっ、セオさんは 来ないの？ 奥で 精霊に 会ったら、何を すれば いい？"], ["{?}セオさんは 来ないの？ 精霊さんに 会えたら、どう すれば いいかしら。"], ["{?}来ないの？ 奥で 何を すれば いい？"], ["{?}セオさんは いらっしゃらないのですか？ 奥で、何を すれば よいでしょう。"]));
      cut(p, "セオ"); await say(p, "セオ", ["{closed}森が 病んだ わけを、精霊に 聞いて ください。何か 託されたら、必ず 持ち帰る こと。", "{sweat,汗}全員で 中に 入って 影に 囲まれたら、だれも 助けを 呼べません。……外は 僕に 任せて。", "§7→ 洞くつの 坂道を 下りて 奥の 大広間へ（右上の 案内）"]);
      rm(eS); H.rm();
      return true;
    } },
  { r: 1, at: "hall", hint: "§fシルヴァの §e大樹の 根の 洞くつ§f を 下りきった §e奥の 大広間§f へ 行こう §7（右上の 案内で 入口へ。懐中電灯は 持って いるだけで よい）", trig: (c) => c.r === 1 && has(c, "k_light"),
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch2b) {   /* 第122版: 広間の 奥に、弱った 精霊の 光。番人が それを 守る */
        await hsay(p, V(["{sweat,汗}……ひんやり。懐中電灯が なかったら、何も 見えなかったね。"], ["{sweat,汗}……ひんやりしてる。"], ["{closed}……広間だ。奥が 光ってる。"], ["{sweat,汗}……ここが、いちばん 奥の 広間ですね。"]));
        const st0 = altarPt(p, 1, 6);   /* 第128版: 祭壇の 精霊の 石 */
        if (camPt(p, st0, 3, 0.6)) for (let k = 0; k < 3; k++) { burst(p.dimension, st0, "minecraft:villager_angry", 4, 0.4, 0.4); await wait(4); }   /* 弱々しく 明滅する 光 */
        await say(p, "森の 精霊", ["……だれ……？ 来ないで……。今の わたしは、影を まいて しまう……"]);
        const q = fwd(p, 4);
        sound(p, "mob.irongolem.hit", 0.6); shake(p, 0.7, 0.9); boom(p.dimension, q || p.location);
        big(p, "§6§l洞くつの 番人", "§f石の 体の 番人が、弱った 光の 前に 立ちはだかる", "mob.irongolem.hit");
        camLowUp(p, q); await wait(14);
        act(H.e, "guard");
        await hsay(p, V(["{shock,!,jump}か、壁が 立ち上がった！？ ……待って、わたしたちは 助けに 来たの！"], ["{shock,!}壁が……！ ちがうの、わたしたち、助けに 来たのよ！"], ["{angry}……番人か。話は 通じそうに ない。"], ["{shock,!,up}お、お待ち ください！ わたしたちは 敵では ありません！"]));
        await say(p, "番人", ["……ヌシノ……ネドコ……マモル……ダレモ……チカヅケルナ……"]);
        const r = await battle(p, bossOne(["golem", "animal"], 20, 80, 2), { name: "洞くつの 番人", arena: "洞くつの 番人", theme: "cave", hpk: 12, extra: 0.4, sboss: true, speaker: "番人", lines: { half: "……セイレイ……マモル……", low: "……トオレ……" } });
        if (r !== "win") { await hsay(p, V(["{sweat,汗}……一度 戻ろう。番人は、精霊を 守ってる だけなんだ。", RT(p)], ["{sweat,汗}……一度 戻りましょう。番人は、精霊を 守ってる だけなのよ。", RT(p)], ["{closed}……一度 戻る。番人は 精霊を 守ってる だけ。", RT(p)], ["{sweat,汗}……一度 戻りましょう。番人は、精霊を 守って いる だけなんです。", RT(p)])); H.rm(); return false; }
        const d1 = load(p); if (d1) { qs(d1).ch2b = 1; save(p, d1); } d = d1 || d;
      }
      /* 苔の 下で 緑の 光が 脈を 打つ */
      const st0 = altarPt(p, 1, 4); H.e;
      if (camPt(p, st0, 3, 0.6)) for (let k = 0; k < 6; k++) { burst(p.dimension, st0, "minecraft:villager_happy", 6, 0.5 + k * 0.1, 0.2); await wait(3); }
      big(p, "§d§l光る 石を 見つけた！", "§f懐中電灯の 光に 応えて、石が 脈を 打つ", "random.orb");
      giveKey(p, d, "k_spirit"); save(p, d);   // v2.9.12: 先に わたして から 説明する
      await hsay(p, V(["{shock,!,up}石が……光って、息を してる！？"], ["{shock,…}……石が、息を してる。"], ["{shock,!}……石が 呼吸 してる。"], ["{shock,!,up}い、石が 息を して います……！"]));
      const g = palEnt(p);
      if (g && ok(H.e)) { const hl = H.e.location; place(g, p, { x: hl.x + 0.8, y: hl.y, z: hl.z + 0.8 }); camNear(p, g, 2.4, 0.8); await wait(8); }   /* 相棒は 光に びっくりして 仲間の 後ろへ */
      if (camPt(p, st0, 2.4, 1.2)) { burst(p.dimension, st0, "minecraft:totem_particle", 10, 0.4, 1); sound(p, "random.orb", 1.6); await wait(12); }
      await say(p, "森の 精霊", ["……番人を 責めないで。あの子は、病んだ わたしを 隠して いたの。", "地上の どこかで、封印の ゆるんだ 石板から 影が にじんで いる。影は わたしの 根を 枯らし、森を 病ませた。"]);
      if (g) { camNear(p, g, 2.4, 0.8); await wait(10); }
      await say(p, "森の 精霊", ["この 子にも…… §d石板の ささやきが 届かない§f のね。あなたと 同じ。よかった。", "ささやきは 心の 傷に 入りこむ。届かない 者だけが、目覚めた 主の 前に 立てるの。"]);
      camPt(p, st0, 2.4, 1.2);
      sound(p, "random.orb", 1.2); particle(p, "minecraft:totem_particle", 0.8);
      await hsay(p, V(["{shock,!}あれ……！ あなたの 手の甲、光ってる……！"], ["{shock,!}……あら。あなたの 手の甲が、光って いるわ。"], ["{shock,!}……手の甲。光ってる。"], ["{shock,!}あ、あの……手の甲が 光って います……！"]));
      await say(p, "森の 精霊", ["……それは §6守り手の 印§f。この 子と あなた、二人で 一つの 印。片方が 呑まれても、もう 片方が 呼べば 戻れる。どうか、なくさないで。", "わたしは この 石の 中で 眠る。影の 届かない 所で。……§b大地§f へ 連れて いって。主が、森の 上で 目を さまし かけて いる。"]);
      for (let k = 0; k < 5; k++) { burst(p.dimension, st0, "minecraft:totem_particle", 6, 1.6 - k * 0.3, 1.4 - k * 0.25); await wait(3); }
      sound(p, "random.orb", 0.7);
      await hsay(p, V(["{sad,…,up}……石の 中で、精霊が 小さく 息を してる。千年 守った 森を 離れて、眠りに ついたんだね。"], ["{sad}……おやすみなさい。森は、わたしたちが 見て おくね。"], ["{closed}……眠った。石の 中なら、影は 届かない。"], ["{sad}……どうか ゆっくり お休み ください。"]));
      flash(p, true); sound(p, "random.levelup", 0.7); particle(p, "minecraft:totem_particle", 1);
      if (g) { burst(p.dimension, g.location, "minecraft:totem_particle", 6, 0.3, 1.2); camNear(p, g, 2.2, 0.9); await wait(12); }
      await hsay(p, V(["{shock,!,jump}光が 消えない！ " + palNm(p) + " の おでこにも 同じ 光が……！"], ["{shock,!}光が 消えないわ……！ " + palNm(p) + " の おでこにも 同じ 光が。"], ["{shock,!}……光が 消えない。" + palNm(p) + " の 額にも 同じ 光。"], ["{shock,!,up}光が 消えません！ " + palNm(p) + " の おでこにも 同じ 光が……！"]));
      if (g) { camNear(p, g, 1.8, 0.9); await wait(6); }
      await pal(p, ["……きこえる？"]);
      await hsay(p, V([`{blush,♥}……今、${palNm(p)} が しゃべった？ ……ずるい、わたしにも 聞かせてよ！`], [`{smile,♥}……今、${palNm(p)} の 声が した？ ふふ、よかったね。`], [`{shock,…}……${palNm(p)} の 声？ ……わたしには 聞こえない。少し、くやしい。`], [`{shock,!}い、今、${palNm(p)} さんが お話し しましたか？`]));
      if (inScene(p)) { camFade(p); await wait(10); } rmCine(g); H.rm();
      await narr(p, "精霊石", ["§7→ §6だいじなもの§7 に 入った。§bシルヴァの ステージ（大地）§7で 使おう"]);
      return true;
    } },
  { r: 1, hint: "§f森の 精霊石を §bシルヴァの ステージ（大地）§f で 使おう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【だいじなもの】）", key: "k_spirit", where: (c) => c.r === 1 && !!c.stage, whereMsg: "§7ここでは 何も 起きない。§fシルヴァの ステージ（大地）§7で 使おう。",
    run: async (p, d) => {
      const H = heroBox(p);
      if (!(qs(d).gate || {})[1]) {   /* 第106版: 主に 勝った あとは 主と もう 戦わない */
        const q = fwd(p, 8); H.e;
        sound(p, "mob.ravager.roar", 0.7); shake(p, 0.9, 1.2); flash(p, true);
        if (q) { boom(p.dimension, q); burst(p.dimension, q, "minecraft:spore_blossom_ambient_particle", 12, 2.5, 0.5); camLowUp(p, q); }
        big(p, "§2§l森の 主が 目を さました！", "§fセオが 駆けつけた", "mob.ravager.roar");
        await wait(16);
        if (q) await knock(H.e, q, 2.5);
        act(H.e, "guard");
        await hsay(p, V(["{rage,怒,jump}いったぁ……！ もう、いきなり 吠えないでよ！"], ["{sweat,汗}……っ、大丈夫。少し 転んだ だけ。"], ["{angry}……っ。吠えただけで これか。"], ["{sweat,汗}だ、大丈夫です！ まだ 立てます！"]));
        const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB); act(eS, "run", false); await wait(14); act(eS, 0);
        await say(p, "セオ", ["{!,wide}森の 主が 目を さましました……！ 精霊石の 光で 弱って いる 今しか ありません。", "{angry}主は 倒すのでは なく、しずめて 眠らせる。僕も 戦います！"]);
        await duel(p, "§2§l森の 主", "§aセオの 子が 主の 弱点を 突く！", { fams: ["animal"] });
        const lv = 22;
        const res = await battle(p, bossOne(["animal", "animal"], lv, 40, 2), { name: "森の 主", arena: "森の 主", theme: "forest", hpk: 6, extra: 0.3, tag: "森の主", sboss: true, guests: team(["animal", "animal"], lv - 3, 2).map((t) => ({ ...t, owner: "セオ" })), speaker: "森の 主", lines: { half: "……ゴゴゴ……モリヲ……ケガス……ナ……", low: "……オマエタチ……ナラ……" } });
        rm(eS);
        const d2x = load(p); if (!d2x) return false; const d2 = d2x;
        if (res !== "win") { await sayAt(p, "§7学者 セオ", TRAITOR_JOB, "セオ", ["{sweat,汗}くっ……いったん 引きましょう。仲間を 休ませて、もう一度 精霊石を！"]); H.rm(); return false; }
        const s = qs(d2); s.gate = { ...(s.gate || {}), 1: true };
        const got = reward(p, d2, 3000, [["e_bronze", 1], ["SEED2", 1]], false);
        save(p, d2);
        gotShow(p, "§2§l森の 主を しずめた！", got);
        particle(p, "minecraft:totem_particle", 1.5); burst(p.dimension, p.location, "minecraft:villager_happy", 10, 2.5, 0.6);   /* 森に 色が 戻る */
        H.e; await hsay(p, V(["{smile,♪,jump}見て！ 葉っぱの 色が 戻って いく！"], ["{smile}……葉っぱの 色が、戻って いく。"], ["{closed}……色が 戻った。"], ["{smile,♪}葉の 色が 戻って いきます……！"]));
      }
      const eS2 = npcNear(p, "§7学者 セオ", TRAITOR_JOB, true);
      if (!qs(load(p) || d).ch2c) {   /* 第122版: 女王エルゼは 戦わない。人間を 疑い、戦いぶりを 見て 精霊石を 託す */
        H.e;
        const eE = npcNear(p, "§a女王 エルゼ", PJ("elze", 8), true); await drop(p, eE, 6);
        re(H.e, "shock", "!");
        await say(p, "女王 エルゼ", ["{closed,low}わたしは 樹上の 民の 女王、エルゼ。森の 主が 目を さますと 聞いて、木の 上から 見て いたわ。", "{angry,up}……でも 先に 聞かせて。森を 病ませたのは、人間でしょう。石板を 掘り起こして、影を まいたのは 人間よ。", "{sad}そして 今度は、精霊まで 石に 閉じこめて 持ち出す つもり？"]);
        await hsay(p, V(["{rage,怒,jump}はあ！？ ちがうってば！ わたしたちは 森を 助けに 来たの！"], ["{shock,…}……ちがうわ。わたしたち、そんな ことは して いない。"], ["{angry}決めつけないで。影を まいたのは わたしたちじゃ ない。"], ["{angry,!}そ、それは 誤解です！ わたしたちは 何も……！"]));
        await say(p, "女王 エルゼ", ["{closed}人間は いつも そう 言うの。"]);
        act(H.e, "kneel");   /* 頭を 下げる */
        await hsay(p, V(["{sad,…}……でも、人間の だれかが 影を まいたのは、たぶん 本当。", "{closed,up}だから、ごめんなさい。森の ために、精霊を 運ぶのを 許して ください。"], ["{sad}……でも、人間が 森を 傷つけたのは、きっと 本当ね。", "{closed}ごめんなさい。精霊を、大地まで 連れて いかせて ください。"], ["{closed}……人間が やったなら、人間が 始末を つける。", "{sad,up}……お願い します。精霊を 運ばせて。"], ["{sad}……人間の だれかが したのなら、同じ 人間として お詫び します。", "{closed,up}どうか、精霊を お運び する ことを お許し ください。"]));
        act(H.e, 0);
        await say(p, "女王 エルゼ", ["{shock,…}……。", "{closed}……主を 殺さずに、しずめたわね。木の 上から、ずっと 見て いた。あの 戦い方は、森を 憎む 者には できない。", "{smile,up}いいわ。精霊石は、あなたたちに 託す。精霊が 目を さます 日まで 守りなさい。……それが 森の 掟よ。"]);
        const d3 = load(p); if (d3) { qs(d3).ch2c = 1; reward(p, d3, 1500, [["SEED2", 1], ["tms_plant", 1]]); save(p, d3); }
        if (ok(eE)) { const l = eE.location; await go(eE, { x: l.x, y: l.y + 7, z: l.z }, 8); }   /* ひと跳びで 木の 上へ */
        rm(eE);
      }
      /* 精霊の 声（石の 中から）→ 次の 目的 */
      sound(p, "random.orb", 0.8); particle(p, "minecraft:totem_particle", 0.6);
      await say(p, "森の 精霊", ["（石の 中から 小さな 声）……ありがとう。一つだけ、伝えて おく。", "……わたしの 根を 枯らした 影と 同じ 影が、§e廃都グランディアの 壁画§f に 描かれて いる。千年前から。"]);
      if (ok(eS2)) { act(eS2, "hold"); camNear(p, eS2, 1.8, 1.5); await wait(10); }   /* 第125版: 伏線。セオが 精霊石の 裏の 文字を 読みかけて やめる */
      await say(p, "セオ", ["{closed}……石の 裏に、古い 文字が ありますね。『影を 知る 者は――』", "{sad,…}…………。"]);
      act(eS2, 0);
      await hsay(p, V(["{?}……続きは？ なんて 書いて あるの？"], ["{?}セオさん、続きは？"], ["{?}止まった。続きは。"], ["{?}あの、続きは……？"]));
      await say(p, "セオ", ["{smile}……いえ。知らない ほうが いい ことも あります。"]);
      cut(p); await hsay(p, V(["{?}学者さんなのに？ 知るのが お仕事でしょ？"], ["{?}学者さんが、そんな ことを 言うの？"], ["{?}学者が それを 言う？"], ["{?}学者の 方が、そう おっしゃるのですか？"]));
      cut(p, "セオ"); re(eS2, "closed", "…");
      await say(p, "セオ", ["{closed}学者 だから、ですよ。一度 読んだ 字は、頭から 出て いかない。", "{smile}……すみません、話が それました。それより――"]);
      await say(p, "セオ", ["{shock,!}廃都の 壁画……。僕も ずっと 気に なって いたんです。", "{closed}ルミナで オルドさんの お孫さんに 会いました。竜を 連れた、負けずぎらいの。……ルインズに いる その §bレイくん§f にも、壁画を 調べて くれるよう 手紙で 頼んで あります。先に 着いて いるかも しれません。", "{up}廃都の §e崩れた 大通り§f の 先に、壁画の 広間が あります。……僕は 書庫で 記録を 当たって から 追いかけます。"]);
      await leave(eS2, p, 9, false);   /* 第124版(cam): 歩いて 去る */
      await gateOpen(p, 2, null, null);
      H.e; await hsay(p, V(["{smile,♪}廃都の 壁画、か。地図に 描き足さなきゃ。"], ["{smile}廃都……。レイくんも いるのね。"], ["{closed}壁画と、レイ。……面倒な 組み合わせ。"], ["{smile}廃都の 壁画ですね。手帳に 書いて おきます。"]));
      cut(p); await hsay(p, V(["{closed}……ねえ。千年前の 壁画に、今の 影が 描いて あるって 変だよね。", "{up}昔の 人も、同じ 影と 戦ってたんだ。何が あったのか、見に 行こう！"], ["{closed}……千年前の 壁画に、今と 同じ 影。", "{up}昔の 人が 何を 見たのか、たしかめに 行きましょう。"], ["{closed}千年前の 壁画に、今の 影。……偶然じゃ ない。", "{up}何が あったか、見に いく。"], ["{closed}千年も 前の 壁画に、今と 同じ 影が……。", "{up}昔の 人が 何を 残したのか、たしかめに 参りましょう。"]));
      H.rm();
      return true;
    } },
  { r: 2, ch: "第3章 廃都の 壁画", at: "road", hint: "§fルインズ荒野の §e廃都の 手前の 崖道§f を 進もう §7（廃都グランディアの 壁画を 見に 行く とちゅう。右上の 案内）", trig: (c) => c.r === 2,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch3a) {   /* 第122版: 廃都の 手前の 崖道。修行帰りの ジンの 弟子を、砂ぼこり団が 待ち伏せて いる → 助けて 共闘 */
        const S3 = stageOf(p), CW = facAt("r2cliff", p.location, 60) || (S3 ? facBuild(p, S3, "r2cliff", "cliffwall", 2, Math.floor(S3.P.y)) : null), CT = CW && facMark("r2cliff", "top", p.location), CF = CW && facMark("r2cliff", "foot", p.location);   /* 第125版(tp): 崖道の 岩壁（上から 飛び降りて くる）*/
        if (CT) { camPt(p, CT, 7, 0.4); await wait(10); }
        big(p, "§6§l廃都の 手前の 崖道", "§f崖の 上から、だれかが 待ち伏せて いた！", "mob.pillager.idle");
        let eK = npcAt(p, "§c弟子 ケン", PJ("ken", 8), fwd(p, 4, -2)), eHr = npcAt(p, "§c弟子 ハルカ", PJ("haku", 8), fwd(p, 3.5, 1.8)); act(eK, "guard"); act(eHr, "kneel");
        let eT; if (CT && CF) { eT = npcAt(p, "§6砂ぼこり団の はぐれ者 ザジ", PJ("bandit", 9), CT); if (ok(eT)) { camPt(p, CT, 6, 0.8); await wait(8); await go(eT, CF, 8); burst(p.dimension, CF, "minecraft:white_smoke_particle", 8, 1, 0.1); sound(p, "random.anvil_land", 1.4); shake(p, 0.25, 0.3); } }
        else { eT = npcNear(p, "§6砂ぼこり団の はぐれ者 ザジ", PJ("bandit", 9), true); await drop(p, eT, 4); }
        const eA = npcNear(p, "§6砂ぼこり団の 手下", PJ("noxa", 9)); act(eA, "guard");
        await say(p, "弟子 ハルカ", ["{cry,!,up}だれか……！ 修行の 帰りに、崖の 上から……！"]);
        await say(p, "ザジ", ["{angry,low}修行帰りで へとへとの 今が 狙い目さ。モンスターと 水を 置いて いけ、小僧ども。", "頭の バルガは 甘く なった。水門を 半分 開けやがって。……おれは おれで 稼ぐ。頭には ないしょだ。"]);
        await say(p, "弟子 ケン", ["{angry,!}渡せるか！ 師匠の 城へ 戻って、壁画の 番に つく ところなんだ！"]);
        act(H.e, "guard");
        await hsay(p, V(["{?,!}ちょっと待って、待ち伏せ！？ 何が ほしいの！？", "{angry,怒}……食べる ためでも、疲れた 人を 狙うのは なし！ 加勢するよ！"],
          ["{?}……待ち伏せ、なの？", "{sad}おなかが すいてるのは 分かる。でも、その子たちを 傷つけるのは 見すごせないわ。"],
          ["{?}……疲れた ところを 狙った 待ち伏せ。", "{closed}……加勢する。壁画の 番人なら、話を 聞きたいし。"],
          ["{?}な、何事ですか！？ 待ち伏せですか！？", "{angry}事情は あるのでしょうけど、見すごせません。お手伝い します！"]));
        cut(p, "ザジ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
        await say(p, "ザジ", ["{angry}……水門で 頭を 負かした ガキか。ちょうど いい。お前の モンスターも 置いて いけ。"]);
        const r = qs(load(p) || d).ch3aW ? "win" : await battle(p, team(["beast", "sword", "golem"], 18, 3, 3), { name: "砂ぼこり団", arena: "廃都の 手前の 崖道", theme: "ruins", speaker: "ザジ", guests: team(["sword"], 17, 1).map((t) => ({ ...t, owner: "ケン" })), lines: { half: "本気で やれ！ 今夜の 水が かかってるんだ！", low: "……引くぞ！ 命あっての ものだ！" } });
        rm(eT); rm(eA);
        if (r !== "win") { rm(eK); rm(eHr); await sayAt(p, "§6砂ぼこり団の はぐれ者 ザジ", PJ("bandit", 9), "ザジ", ["……今日は 見逃す。次は 崖の 上から 本気で 行く。", RT(p)]); H.rm(); return false; }
        { const dw = load(p); if (dw && !qs(dw).ch3aW) { qs(dw).ch3aW = 1; save(p, dw); } }   /* 第123版: 勝った あとの 会話で 抜けても もう 戦わない（ほうびが 2回 出ない） */
        const eT2 = npcNear(p, "§6砂ぼこり団の はぐれ者 ザジ", PJ("bandit", 9), true); act(eT2, "recoil");
        await say(p, "ザジ", ["{sweat,汗}ちっ……一月分の 水が……。頭に 言いつけるなよ！"]);
        act(eT2, 0); await leave(eT2, p, 12, true);
        if (!ok(eK)) eK = npcNear(p, "§c弟子 ケン", PJ("ken", 8), true); if (!ok(eHr)) eHr = npcNear(p, "§c弟子 ハルカ", PJ("haku", 8), true);
        await say(p, "弟子 ケン", ["{closed}……助かった。俺は ケン。こっちは ハルカ。もう 一人、リュウって やつが 城に いる。", "§6地方マスター ジン§f 師匠の 弟子だ。荒野で 修行して、廃都へ 戻る ところだった。"]);
        await say(p, "弟子 ハルカ", ["{smile}師匠に 言われて、交代で 壁画を 見張って いるの。廃都の 神殿の 壁画は、この 都に 残った、たった 一つの 記録だから。", "{?}壁画を 見に 来たの？ ……なら 案内する。今朝も 一人、先客が いたわ。竜を 連れた 男の人。"]);
        await hsay(p, V(["{shock,!}竜を 連れた 男……レイだ！"], ["{smile}竜を 連れた 人……きっと レイくんね。"], ["{closed}……レイだ。セオが 言ってた。"], ["{!}竜を 連れた 方……レイさんですね。"]));
        act(eK, "point"); await bye(p, eK, eHr);   /* 第124版: 壁画の 広間へ 移る 前に 暗く */
        const d1 = load(p); if (d1) { qs(d1).ch3a = 1; save(p, d1); } d = d1 || d;
      }
      if (!qs(d).ch3b) {   /* 第122版: 壁画の 広間。セオに 頼まれて 先に 来て いた レイと、削られた 影の 読みで 意見が 割れる */
        await goPlace(p, "mural", 2, "廃都の 神殿 壁画の 広間");
        H.e;
        const eHr = npcNear(p, "§c弟子 ハルカ", PJ("haku", 8), true);
        const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
        if (ok(e)) { await arrive(e); turnTo(e, fwd(p, 5, 0, 1.5)); await pushIn(p, e, 20); }   /* 第125版(rs2): レイは 壁画を 見上げた まま、背中で 話す */
        await say(p, "レイ", ["{closed}……来たか。セオから 手紙が 来た。この 壁画を 調べて くれって。"]);
        cut(p); await hsay(p, V(["{?}レイ、いつから ここに いたの？ 何か 分かった？"], ["{?}レイくん、ずっと 見て いたの？ 何か 分かった？"], ["{?}いつから いた？ 何か 分かった？"], ["{?}レイさん、いつから こちらに？ 何か 分かりましたか？"]));
        turnTo(e); cut(p, "レイ"); re(e, "closed");
        await say(p, "レイ", ["{closed}夜明けから。影の 数を 三回 数えた。", "{angry}……先に 言って おく。オレには もう 読みが ある。おまえも 自分の 目で 見ろ。"]);
        if (ok(H.e)) await go(H.e, fwd(p, 3.2, 0.8), 12);   /* 第125版(rs2): 壁画の 前へ 歩いて 指さす */
        act(H.e, "point");
        await hsay(p, V(["{?}王様が 一人。その まわりに 影が §e十四§f。……村長の 話と 同じ！", "{sweat,汗}……待って。王様の すぐ 隣に、もう 一つ……§c削り取られた 影§f の 跡が ある。"],
          ["{?}王様と、まわりに 影が §e十四§f。……村長さんの 話の とおりね。", "{shock,…}……あら。王様の すぐ 隣、何かが §c削り取られて§f いる。"],
          ["{closed}王が 一人、影が §e十四§f。村長の 話と 合う。", "{?}……王の 隣に、§c削られた 跡§f。一つ 多い。"],
          ["{?}王様と、影が §e十四§f……。村長さまの お話の とおりです。", "{shock,!}あ……王様の すぐ お隣に、§c削り取られた 影§f が。"]));
        act(H.e, 0);
        { const sq = fwd(p, 5, -0.6, 1.8); if (sq) { camPt(p, sq, 4, 0.1, 0.4); await wait(6); camPt(p, sq, 2, 0.1, 1.2); await wait(16); } }   /* 第125版(rs2): 削られた 影の 寄り（ゆっくり 寄る）*/
        await narr(p, "", ["§7削り跡の 下に、もっと 古い 削り跡が ある。……二度、削られて いる。"]);   /* 第125版 Q7 */
        await say(p, "レイ", ["{closed}ああ。オレの 読みは こうだ。輪の 影は 十四。……削られたのは、王に 仕えてた §e十五番目の 主§f だ。", "{angry}だれかが そいつの 封印を 解いて、記録ごと 消した。すぐ 城に 報告して、封印を 全部 見直すべきだ。"]);
        if (epD(d, "r2e2")) await hsay(p, V(["{angry}ちがうと 思う！ 主なら、輪の 中に 描くはず。削られた 影は 王の すぐ 隣で、王と 同じ 大きさ。", "{closed,up}……トキ婆の 昔話の『王の 隣の 影』だよ。王の 友だち……王を 封じた 人。"],
          ["{?}……そうかしら。主なら、ほかの 影と 同じ 輪の 中に 描くと 思うの。", "{closed}トキ婆さんの 昔話の『王の 隣の 影』よ。王様の お友だち……王様を 封じた 人。"],
          ["{closed}ちがう。輪の 影は 小さい。削られた 影は 王と 同じ 大きさで、王の 隣。", "{closed}トキ婆の 昔話。『王の 隣の 影』。王の 友……王を 封じた 人。"],
          ["{?}あの……わたしは ちがう ように 思います。主なら 輪の 中に 描くはずです。", "{closed}トキさまの 昔話の『王の 隣の 影』では ないでしょうか。王様の ご友人……王様を 封じた 方です。"]));
        else await hsay(p, V(["{angry}ちがうと 思う！ 主なら、輪の 中に 描くはず。削られた 影は 王の すぐ 隣で、王と 同じ 大きさ。", "{closed,up}……主じゃ なくて、王の 横で 王を 動かしてた だれか じゃ ない？"],
          ["{?}……そうかしら。主なら、ほかの 影と 同じ 輪の 中に 描くと 思うの。", "{closed}王様の すぐ 隣で、王様と 同じ 大きさ。……主じゃ なくて、王様の そばに いた 別の だれか。わたしは、そう 見える。"],
          ["{closed}ちがう。輪の 影は 小さい。削られた 影は 王と 同じ 大きさで、王の 隣。", "{angry}主じゃ なくて、王と 並ぶ 何か。……それに 削り跡が 古い。描いた 人たち 自身が 消したんだ。"],
          ["{?}あの……わたしは ちがう ように 思います。主なら 輪の 中に 描くはずです。", "{closed}王様と 同じ 大きさで、すぐ お隣。……主では なく、王様を 動かして いた だれか では ないでしょうか。"]));
        await say(p, "レイ", ["{angry}根拠が 弱い。大きさなんて、描いた やつの 気分だろ。", "{closed}……平行線だな。でも 城への 報告は 一つだ。間違った 読みを 先に 送れば、城は 間違った 守りを 固める。", "{angry,!}だから、勝った 方の 読みを 先に 城へ 報告する。"]);
        await hsay(p, V(["{rage,怒}なんで それを 勝負で 決めるの！？"], ["{?}どうして、勝負で 決めるの？"], ["{?}勝負で 読みが 正しく なるの？"], ["{?}な、なぜ 勝負なんですか？"]));
        await say(p, "レイ", ["{closed}どっちにも 証拠が ないからだ。だったら、主の 前に 立てる 腕の ある 方の 読みに 賭ける。", "{angry}ルミナの 時とは ちがう。オレは もう、石板を 欲しがって ない。……ただ、読みを 間違えたく ないだけだ。"]);
        await hsay(p, V(["{angry,!}……わかった。受けて 立つ！"], ["{closed}……分かったわ。わたしの 読みも、ゆずれないもの。"], ["{closed}……いいよ。負けた 方は 黙る。"], ["{angry}……承知 しました。わたしの 読みも、ゆずれません。"]));
        await duel(p, "§b§l壁画の 前の 勝負", "§f崩れた 柱の 上で 竜と ぶつかる！", { fams: ["dragon"] });
        const lv = 22;
        const res = await battle(p, team(["dragon", "animal", "beast"], lv, 3, 36, leadOf("dragon", lv)), { name: "ライバル レイ", arena: "壁画の 広間", theme: "ruins", hpk: 5.5, extra: 0.3, tag: "ライバル", sboss: true, speaker: "レイ", lines: { half: "まだだ……読みは ゆずらない！", low: "……くそ、オレの 読みが……！" }, heal: true });
        rm(e);
        const d2r = load(p); if (!d2r) { rm(eHr); H.rm(); return false; }
        if (res !== "win") { rm(eHr); await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["{closed}オレの 読みを 先に 送る。……悪く 思うな。", "まだ 納得 できないなら、もう一度 来い。", RT(p)]); H.rm(); return false; }
        const s = qs(d2r); s.reiW = (s.reiW || 0) + 1; s.ch3b = 1; save(p, d2r);
        const e2 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true); act(e2, "kneel");
        await say(p, "レイ", ["{sad,…}……負けた。", "{closed}約束だ。おまえの 読みを 先に 送れ。オレの 読みは、セオに だけ 書いて おく。", "{up}……壁画、手帳に 写して おけよ。いつか 役に 立つ。"]);
        act(e2, 0); act(H.e, "hold");
        await hsay(p, V(["{smile,♪}もう 写してる。……削られた 影の 形も、ちゃんと ね。"], ["{smile}ええ、もう 写したわ。削られた 影の 形も。"], ["{closed}写した。削り跡の 形まで。"], ["{smile}はい、もう 写して あります。削られた 影の 形も。"]));
        act(H.e, 0);
        act(eHr, "point");   /* 第125版: 伏線。壁画の 台座の 半分 削れた 文字 */
        await say(p, "弟子 ハルカ", ["{closed}……写すなら、壁画の §e台座§f も。半分 削れて いるけど、文字が 刻まれて いるの。"]);
        if (ok(H.e)) { await go(H.e, fwd(p, 4, 0.7), 10); act(H.e, "kneel"); }   /* 第125版(rs2): 台座の 前に ひざを ついて 文字を なぞる */
        { const pq = fwd(p, 5, 0, 0.5); if (pq && camPt(p, pq, 3, 0.8)) { burst(p.dimension, pq, "minecraft:white_smoke_particle", 4, 0.4, 0.2); await wait(14); } }
        await hsay(p, V(["{?}えっと……『§e影は 知る……に 宿る。……は ……に 宿れぬ§f』……あとは 削れて 読めない。"], ["{?}『§e影は 知る……に 宿る。……は ……に 宿れぬ§f』……ここから 先は 読めないわ。"], ["{closed}『§e影は 知る……に 宿る。……は ……に 宿れぬ§f』。半分 削られてる。"], ["{?}『§e影は 知る……に 宿る。……は ……に 宿れぬ§f』……ほかは 削れて います。"]));
        await say(p, "レイ", ["{closed}……知る、何かに 宿る。気味の 悪い 文句だな。"]);
        act(eHr, 0); act(H.e, 0);
        { const mq2 = fwd(p, 5, 2.4, 1.2); if (mq2 && camPt(p, mq2, 2.4, 0.4)) { sound(p, "random.glass", 1, 0.3); await wait(12); } }   /* 第125版: 伏線。壁画の すみの 仮面の 近衛兵 */
        await narr(p, "壁画の すみ", ["§7台座の 横に、小さな 絵。§f仮面を つけた 近衛兵§7が、王の 一行の いちばん 後ろで 盾を 構えて いる。", "§8……仮面には、細い ひびが 一本 描かれて いた。"]);
        cut(p); await hsay(p, V(["{?}ひ、ひとりで 六影を 追うの？ この前 ガロ一人でも 大変だったのに。"], ["{?}ひとりで 六影を 追うの？ 危ないわ。"], ["{?}ひとりで？ 六影は 一人じゃ ない。"], ["{?}おひとりで 六影を 追われるのですか？ 危険です。"]));
        cut(p, "レイ");
        await say(p, "レイ", ["{closed}ひとりじゃ ない。竜が いる。", "{angry}火山の 方へ 向かった やつらが いる。読みが 外れたなら、足で 取り返す。……じゃあな。"]);
        await leave(e2, p, 12, false);
        rm(eHr);
      }
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      /* 第122版: 弟子の 案内で ジンの 城の 中庭へ（ジンに 勝てば 石板） */
      await goPlace(p, "court", 2, "ジンの 城の 中庭");
      H.e;
      const eHk = npcNear(p, "§c弟子 ハルカ", PJ("haku", 8), true);
      await say(p, "弟子 ハルカ", ["{closed}ここが 師匠の 城の 中庭。壁画の 報告なら、師匠が 城の 名で 届けて くれる。"]);
      { const sk = fwd(p, 12, 0, 4); camPt(p, sk, 9, 2, 1.2); await wait(14); }   /* 第127版: 本3（bk_b03）と 同じ 筋に（ジンの 奥方は 十二年前の 冬に 石に なった）*/
      await say(p, "弟子 ハルカ", ["{sad}師匠の 奥方は、十二年前の 冬の 夜に 石に なった。師匠は それから 一度も、剣を 鞘に 納めて ない。"]);
      cut(p, "ハルカ");
      await say(p, "弟子 ハルカ", ["{up}石板も 師匠が 預かってる。……でも 師匠は、勝った 者に しか 渡さない。", "{?}あ、それと。あなた ルミナから 来たのよね。師匠が 言ってた。§eオルド殿§f には、若い ころ 一度も 勝てなかったって。"]);
      cut(p, "");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
      await hsay(p, V(["{shock,!,jump}え、村長って そんなに すごい人なの！？ ……いつも 縁側で お茶 飲んでる だけなのに！", "{closed,…}……手帳に 書いとこ。『村長・若い ころ・負けなし？』。……まさかね。"],
        ["{shock,!}まあ……村長さんが？", "{smile,…}手帳に 書いて おくね。『村長さん・若い ころ・負けなし？』。……ふふ、まさかね。"],
        ["{shock,…}……村長が？ あの 腰の 曲がった？", "{closed}手帳に メモ。『村長・若い ころ・負けなし？』。……要確認。"],
        ["{shock,!}そ、村長さまが ですか！？", "{closed}手帳に 記して おきます。『村長さま・若い ころ・負けなし？』……まさか、ですよね。"]));
      await gone(p, eHk);
      /* オルドの 手紙（鳥が 運んで くる）*/
      sound(p, "mob.parrot.fly", 1); particle(p, "minecraft:white_smoke_particle", 2.4);
      H.e; await hsay(p, V(["{!,jump}あ、村長から 手紙！ ……読むね。"], ["{!}あら、村長さんから お手紙。……読むわね。"], ["{closed}村長から 手紙。……読む。"], ["{!}あ、村長さまから お手紙です。……読みますね。"]));
      act(H.e, "hold"); hold(H.e, "letter"); sound(p, "item.book.page_turn", 1);   /* 第124版: 手紙は 幼なじみが 手に 持って 読む（その場に いない オルドを 話す 人に しない）*/
      if (ok(H.e)) { camNear(p, H.e, 1.3, 1.05, 0.5); await wait(12); }   /* 第125版(rs2): 手紙の 寄り */
      await narr(p, "オルドの 手紙", ["§f『荒野の 遺跡には §e星の かけら§f が 眠っておる。石板から 欠け落ちた 力の 粒じゃ。", "§f六影も あれを 探して おる。かけらは 持つ 者に 力を 与えるが、心を 削る。……気を つけるんじゃぞ。", "§f……レイは 元気に しておったか。闘技場の 杯を また 一つ 取ったと、自慢の 手紙が 来おった。……あの 杯の 先の 扉だけは、開かん ほうが よいのじゃがな。』"]);
      act(H.e, 0);
      await hsay(p, V(["{smile,♪}……『元気に 理屈を こねてました』って 返事 しとこうか。"], ["{smile}……『元気に 言い合いを しました』って、お返事 しておくわね。"], ["{closed}……『相変わらず 理屈っぽい』。それで 十分。"], ["{smile}『お元気でした。少し 理屈っぽく』と お返事 しておきます。"]));
      cut(p); await hsay(p, V(["{?}……でも、最後の とこ。『杯の 先の 扉』って 何だろ。", "{closed}村長、闘技場の ことに なると いつも 話を 変えるんだよね。"], ["{?}……『杯の 先の 扉』。何の ことかしら。", "{closed}村長さん、闘技場の 話に なると、いつも はぐらかすのよね。"], ["{?}『杯の 先の 扉』。……何。", "{closed}村長は 闘技場の 話を すると、すぐ そらす。"], ["{?}……『杯の 先の 扉』とは、何の ことでしょう。", "{closed}村長さまは、闘技場の お話に なると、いつも 話を そらされます。"]));
      await narr(p, "オルドの 手紙", ["§7→ 中庭の §6ジン§7 に 話しかけて 挑もう。遺跡の ボスを 倒すと 星の かけら（2つ目と 5つ目には 石板も）。8つで ネクロスの §6終の遺跡§7"]);
      reward(p, d2, 4000, [["e_silver", 1], ["tms_golem", 1]]); save(p, d2);
      H.rm();
      return true;
    } },
  { r: 2, seal: 2, nospot: 1, hint: "§fルインズ荒野の §6地方マスター ジン§f（城の 中庭）に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(2),
    run: async (p, d) => {
      await gateOpen(p, 3, "弟子 ハルカ", ["（手紙）ジン師匠からの 伝言です。『壁画の 読みは、城の 名で 王都へ 届けた』", "『水路の 件、聞いた。城の 古い 水路を 開ける。ガレキの §e古井戸§f で 待て』", "『もう 一つ。§cヴォルカ火山帯§f の 町外れの §e鍛冶場§f で、六影が 鍛冶屋に 何かを 作らせて いると 聞く。石板を 持つ 者なら、見て おけ』"]);
      const H = heroBox(p, true); await hsay(p, V(["{smile,☆,jump}石板、二枚目！ ジンさんに 水路の こと お願い して、よかった！ ……次は 火山の 鍛冶場だって。", "{sweat,汗}……あつそう。水筒、多めに 持って いこうね。"], ["{smile}二枚目ね。水路の お願いも、聞いて もらえたわ。次は 火山の 鍛冶場……", "{sweat,汗}暑そう。お水、たくさん 持って いきましょ。"], ["{closed}二枚目。水路の 件も 通った。……六影が 鍛冶場で 何を 作らせてるのか、見に 行こう。"], ["{smile}二枚目ですね。水路の お願いも、聞いて いただけました。次は 火山の 鍛冶場……", "{closed}六影が 何を 作らせて いるのか、確かめに 参りましょう。"])); H.rm(); return true; } },
  { r: 3, ch: "第4章 炎の 幹部", at: "forge", hint: "§fヴォルカ火山帯の §e町外れの 鍛冶場§f へ 行こう §7（ジンの 伝言。右上の 案内）", trig: (c) => c.r === 3,
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch4a) {   /* 第106版: 燃える 鍛冶場の 救助・爆弾班。第122版: 六影が 作らせて いた ものと、ボムの 目的 */
        const f = (() => { try { const v = JSON.parse(world.getDynamicProperty("mrpg:decor:forgeat") || "null"); if (v && Math.hypot(v.x - p.location.x, v.z - p.location.z) < 30) return { x: v.x, y: v.y, z: v.z }; } catch {} return null; })() || fwd(p, 7);   /* 第124版(合議): 燃えるのは 作業場（屋根の 下）。ない 世界は 前の 空き地 */
        big(p, "§c§l鍛冶場が 燃えている！", "§f鍛冶場の 前で、人と モンスターが 動けなく なって いる", "mob.blaze.shoot");
        sound(p, "random.explode", 0.8); shake(p, 0.5, 0.6); if (f) { boom(p.dimension, f); camPt(p, f, 6, 2); await blaze(p, f, 6); }
        const r3x = epD(d, "r3e1"), WN = r3x ? "兄弟子 ザク" : "若い 鍛冶屋";   /* 第124版(dir#11): 鍛冶場の 話を 見た あとは ゲンと トンボの 鍛冶場 */
        if (r3x) await hsay(p, V(["{shock,!,jump}火事！？ ゲンさんの 鍛冶場が 燃えてる！ トンボくんは！？"], ["{shock,!}……ゲンさんの 鍛冶場が……！ トンボくんは！？"], ["{shock,!}……ゲンの 鍛冶場が 燃えてる。トンボは！？"], ["{shock,!,up}た、大変です！ ゲンさまの 鍛冶場が……！ トンボさんは！？"]));
        else await hsay(p, V(["{shock,!,jump}火事！？ 鍛冶場が 燃えてる！"], ["{shock,!}……鍛冶場が、燃えてる……！"], ["{shock,!}……燃えてる。遅かった？"], ["{shock,!,up}た、大変です！ 鍛冶場が 燃えて います！"]));
        const eW = npcAt(p, "§e" + WN, PJ("smith", 8), fwd(p, 5, 1.5)); act(eW, "hold");   /* 暴れる モンスターを 抱えて 動けない */
        await say(p, WN, [r3x ? "{cry,汗,up}だ、だれか！ 親方が トンボを かばって……この子たちも 暴れて 動けないんだ！" : "{cry,汗,up}だ、だれか！ この子たちが 火に おびえて 暴れて……動けないんだ！"]);
        await hsay(p, V(["{angry,怒}話は あと！ あの子たちを しずめなきゃ！"], ["{angry}……まず、あの子たちを 落ちつかせましょう。"], ["{closed}先に しずめる。話は それから。"], ["{angry}お話は あとです！ まず、あの子たちを！"]));
        const r1 = await battle(p, team(["nether", "golem"], 28, 3, 4), { name: "火に おびえた モンスター", arena: "燃える 鍛冶場", theme: "volcano", speaker: "モンスター", lines: { half: "……アツイ……アツイ……！", low: "……キュウ……" } });
        rm(eW);
        if (r1 !== "win") { await sayAt(p, "§e" + WN, PJ("smith", 8), WN, ["だ、だめだ、火が……！ 一度 離れて！", RT(p)]); H.rm(); return false; }
        const eW2 = npcNear(p, "§e" + WN, PJ("smith", 8), true);
        const hq3 = hallUp(3);   /* 第124版: 六影の 鋳造所が ある 世界では、打ちかけの 台座は 鋳造所へ 運ばれて いる（ない 世界は 今までの 流れ）*/
        if (hq3) await say(p, WN, ["{sweat,汗}た、助かった……！ ……すまねえ。おれ、金に 目が くらんで、§5六影§f に 言われた §e台座§f を 半分 打っちまった。石板を 円く 並べる 台座だ。", "{angry,怒}何に 使うか 聞いても 答えねえ。こわく なって 断ったら、炉に 火薬を……！ 打ちかけの 台座は、やつらが §e鋳造所§f へ 運んで いった！"]);
        else await say(p, WN, ["{sweat,汗}た、助かった……！ §5六影§f に、石板を 円く 並べる §e台座§f を 作れって 言われてたんだ。", "{angry,怒}何に 使うか 聞いたら 答えない。断ったら、炉に 火薬を 投げこんで いった……！"]);
        /* 爆弾が 投げこまれる → 吹き飛ぶ */
        const bq = fwd(p, 3, 2); H.e;
        sound(p, "random.fuse", 1); await wait(12);
        boom(p.dimension, bq || p.location); sound(p, "random.explode", 1); flash(p, true); shake(p, 0.8, 0.6);
        if (bq) { knockP(p, bq); await knock(H.e, bq, 2.5); }
        await wait(6); act(H.e, 0);
        const eBm = npcNear(p, "§5爆弾班 ボム", PJ("bomb", 9));
        await hsay(p, V(["{rage,怒,jump}けほっ……ちょっと！ 人に 向かって 投げる！？ " + palNm(p) + " に 当たったら どうするの！ あんた だれ！"], ["{sweat,汗}けほっ……だれ？ どうして、人に 向かって 投げるの？"], ["{angry}……だれ。台座を 作らせて、何を する 気？"], ["{rage,怒}け、けほっ……どなたですか！ 人に 向かって 投げるなんて！"]));
        if (hq3) await say(p, "爆弾班 ボム", ["{smile,low}六影 爆弾班の ボム。……ほしいのは 二つ。台座を 仕上げる 鍛冶の 腕と、アンタの 石板だ。", "{angry}台座は 参謀の 注文でね。打ちかけは もう ヴァルカ様の 炉へ 運んだ。……断った 鍛冶屋には、火で 分からせる。邪魔するなら、次は 町ごと 燃やす。"]);
        else await say(p, "爆弾班 ボム", ["{smile,low}六影 爆弾班の ボム。……ほしいのは 二つ。台座の 仕上がりと、アンタの 石板だ。", "{angry}台座は 参謀の 注文でね。ヴァルカ様に 届けなきゃ ならねえ。邪魔するなら、次は 町ごと 燃やす。"]);
        const r2 = await battle(p, team(["nether", "dragon"], 29, 3, 5), { name: "六影 爆弾班", arena: "爆弾班", theme: "volcano", speaker: "爆弾班 ボム", lines: { half: "……熱い……まだだ……！", low: "ヴァルカ様……すみません……" } });
        if (r2 !== "win") { rm(eBm); rm(eW2); await sayAt(p, "§5爆弾班 ボム", PJ("bomb", 9), "爆弾班 ボム", ["……わかったろ。次は 町ごとだ。", RT(p)]); H.rm(); return false; }
        { const d1 = load(p); if (d1) { qs(d1).ch4a = 1; save(p, d1); } d = d1 || d; }
        if (hq3) {   /* 第124版: ボムは 鋳造所へ 走る。鍛冶屋が 場所を 教える（次の 場面は 鋳造所の 中）*/
          const eB9 = npcNear(p, "§5爆弾班 ボム", PJ("bomb", 9), true), eW9 = npcNear(p, "§e" + WN, PJ("smith", 8), true); act(eB9, "recoil");
          await say(p, "爆弾班 ボム", ["{sweat,汗}ちっ……ヴァルカ様に 知らせる！ 台座は もう 炉の 上だ。§e鋳造所§f まで 来て みろ！"]);
          act(eB9, 0); await leave(eB9, p, 12, true);
          await say(p, WN, ["{angry}あいつらの §e鋳造所§f は、火の 山の 大地の そばの 炉の 館だ。紫の 柱と 青い 灯が 目印さ。台座は あそこで 仕上げてる！"]);
          await hsay(p, V(["{angry,!}追うよ！ 台座を 仕上げさせない！"], ["{angry}……追いましょう。台座を、仕上げさせないわ。"], ["{closed}追う。台座は 仕上げさせない。"], ["{angry}追いかけます！ 台座を 仕上げさせません！"]));
          await bye(p, eW9);
        } else { rm(eBm); rm(eW2); }
      }
      /* ヴァルカは 炎の 中から 現れ、先に 目的を 語る */
      /* 第124版: 六影の 鋳造所の 中へ（溶岩の 上の ガラスの 床・石板を 円く 並べる 台座・炉）。ない 世界は 今までどおり 鍛冶場の 前 */
      const hq = await goHall(p, 3, "六影の 鋳造所"), v3 = hq ? caveInfo(3) : null, met3 = epD(d, "r3e3");
      const e = hq ? npcAt(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), { x: v3.altar.x, y: v3.hall.y, z: v3.altar.z - 2 }) : npcNear(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), true);
      if (hq) {   /* ヴァルカは 炉の 前で、背を 向けて 台座を 打って いる */
        const S3 = stageOf(p); await arrive(e);
        try { if (ok(e)) e.teleport(e.location, { facingLocation: { x: v3.altar.x, y: v3.altar.y + 1, z: v3.altar.z + 2 } }); } catch {}
        if (S3) { camAt(p, S3.at(-7, 4.5 * S3.side, 5.5), { x: v3.altar.x, y: v3.altar.y + 1.5, z: v3.altar.z + 1 }, 0.8); await wait(26); }
        camAt(p, { x: v3.hall.x, y: v3.hall.y + 6, z: v3.hall.z - 5 }, { x: v3.hall.x, y: v3.hall.y - 0.5, z: v3.hall.z + 1 }, 0); await wait(20);   /* 床の 台座の 円と、ガラスの 下の 溶岩 */
        if (ok(e)) camNear(p, e, 3.4, 1.5, 0);
        hold(e, "hammer"); for (let k = 0; k < 2; k++) { act(e, "raise"); await wait(6); sound(p, "random.anvil_use", 0.9 + k * 0.1); act(e, 0); await wait(8); }
        await say(p, "ヴァルカ", ["{closed}……下手な 打ち方だ。迷いが 鉄に 出てる。"]);
        hold(e); try { if (ok(e)) e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {}   /* 槌を 置いて 振り向く */
        act(H.e, "guard"); re(H.e, "shock", "!");
        await hsay(p, met3 ? V(["{shock,!}運び道の、赤い 外套の 人……！"], ["{shock,!}……運び道の、赤い 外套の 人。"], ["{shock,!}……運び道の、赤い 外套。"], ["{shock,!}運び道で お会い した、赤い 外套の 方……！"]) : V(["{shock,!}炉の 前に、だれか いる……！"], ["{shock,!}……炉の 前に、だれか いるわ。"], ["{angry,!}……炉の 前。だれか いる。"], ["{shock,!}炉の 前に、どなたか いらっしゃいます……！"]));
        await sixMark(p, e, "valka");
        await say(p, "ヴァルカ", [met3 ? "{smile,low}あの 見習いの 連れだね。……名乗って なかったか。アタシは 六影 幹部、§c炎の ヴァルカ§f。" : "{smile,low}アンタが ガロの 相手を した 子だね。アタシは 六影 幹部、§c炎の ヴァルカ§f。", "{closed}……鍛冶場の 火は 見たよ。品の ない 火だ。ボムの やつ、火の 扱いも 知らないで。", "{angry,up}ボム！ 聞こえてるね。§5六影§f の 名を 汚すなって 言ったろ。火は 人に 向ける もんじゃ ない！ ……上が 止めないなら、アタシが 止める までさ。"]);
      } else {
        if (ok(e)) { camNear(p, e, 4, 1.4); await blaze(p, e.location, 5); flash(p, true); }
        await sixMark(p, e, "valka");   /* 第125版: 名乗りの 演出（炎の 中から 歩いて くる）*/
        act(H.e, "guard"); re(H.e, "shock", "!");
        await say(p, "ヴァルカ", ["{closed}……品の ない 火だ。ボムの やつ、火の 扱いも 知らないで。", "{angry,up}ボム！ 聞こえてるね。§5六影§f の 名を 汚すなって 言ったろ。火は 人に 向ける もんじゃ ない！ ……上が 止めないなら、アタシが 止める までさ。", "{smile,low}アンタが ガロの 相手を した 子だね。アタシは 六影 幹部、§c炎の ヴァルカ§f。"]);
      }
      await say(p, "ヴァルカ", ["{up}先に 言って おくよ。アタシの 狙いは 石板そのものじゃ ない。", "{closed,♪}参謀は、石板が そろったら §6クロガネ§f の 工房の §c開かずの 部屋§f の 鍵を くれる と 約束した。", "{closed}……あの 部屋には、千年前の §e鍵の 型§f が 眠ってるって 話さ。", "{smile}アタシは その 中が 見たい。千年 だれも 開けて ない 部屋さ。"]);
      cut(p, "");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
      await hsay(p, V(["{rage,怒,up}……見たいだけ！？ それだけの ために 鍛冶場を 燃やしたの！？"], ["{?,…}……見たい、だけ？ それで、こんな ことを？"], ["{?}見たいだけ？ そのために 石板を 集めて、何が 起きても いいの？"], ["{?}み、見たいだけ……ですか？ そのために、こんな ことを？"]));
      await say(p, "ヴァルカ", ["{angry}燃やしたのは ボムの 勝手さ。……でも、止めなかったのは アタシだ。言い訳は しない。", "{smile,up}アタシは 昔、その 工房で 槌を 振ってた。部屋を 開けようと して、破門さ。……鍛冶の 火は、物を 生む ための もの。本物を 見せて あげる。", "{closed,low}……親父の 刀の 結びを 打つには、あの 部屋の 型が 要るんだよ。", "{angry,low}アンタの 石板を 賭けな。アタシは 台座を 賭ける。"]);
      await hsay(p, V(["{angry,!}……いいよ。台座は 渡さないし、石板も 渡さない！"], ["{closed}……分かったわ。台座は、ここに 置いて いって もらう。"], ["{closed}乗った。台座は 置いて いけ。"], ["{angry}……お受け します。台座は 置いて いって いただきます！"]));
      await duel(p, "§c§l溶岩の 上の 決闘", "§fヴァルカの 炎の 竜が 飛びかかる！", { fams: ["dragon", "nether"] });
      const lv = 32;
      const res = await battle(p, team(["dragon", "nether"], lv, 3, 44, leadOf("dragon", lv)), { name: sixName("valka"), arena: "炎の 幹部", theme: "volcano", hpk: 6, extra: 0.4, tag: "三の座", sboss: true, speaker: "ヴァルカ", lines: { half: "熱いじゃないか……アタシを 本気に させたね！", low: "この アタシの 火が……消える……？" } });
      rm(e);
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { await sayAt(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), "ヴァルカ", ["{closed,low}……試しだ。石板は 取らないよ。", hq ? "{smile,low}出直して きな。……台座は、その 間に 仕上げて おくよ。" : "{smile,low}出直して きな。……台座は もらって いくよ。"]); H.rm(); return false; }
      const e2 = npcNear(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), true); act(e2, "recoil");
      await say(p, "ヴァルカ", [hq ? "{angry,汗}ちっ……約束だ。台座は アタシが 割って いく。半端な 鉄は、世に 出さない。今日は 退くよ。" : "{angry,汗}ちっ……約束だ。台座は 置いて いく。今日は 退くよ。"]);
      if (hq && v3) { act(e2, "raise"); await wait(8); const c3 = { x: v3.hall.x, y: v3.hall.y, z: v3.hall.z }; camAt(p, { x: c3.x, y: c3.y + 6, z: c3.z - 5 }, { x: c3.x, y: c3.y - 0.5, z: c3.z + 1 }, 0); sound(p, "random.anvil_land", 0.7); shake(p, 0.5, 0.4); burst(p.dimension, c3, "minecraft:critical_hit_emitter", 8, 4, 0.1); burst(p.dimension, c3, "minecraft:basic_smoke_particle", 8, 3, 0.2); await wait(14); act(e2, 0); cut(p, "ヴァルカ"); }   /* 槌で 台座を 割る */
      await say(p, "ヴァルカ", ["{closed}……アンタの 石板も、取らない。今日のは §e試し§f だ。……その 相棒、手放すんじゃ ないよ。", "{?}……参謀が 何を 考えてるか？ 知らないね。アタシは 自分の 分しか 知らない。§eそれで いいんだ§f。", "{smile,low}でも 遅いね。参謀の 話じゃ、仲間は もう §eサンドリア砂漠の 王墓§f に 向かってる。", "{closed}それに §5ベリル§f って 子が、§dクリスタリア§f で 水晶を 集める 任務に ついてる。……台座が なくても、儀式の 支度は 進むのさ。"]);
      act(e2, "up"); if (ok(e2)) { camNear(p, e2, 2, 1.6); await wait(16); }   /* 第125版: ヴァルカの 過去。第124版: 炉の 火を じっと 見る（その 場に いない トンボの 行は 切った）*/
      await say(p, "ヴァルカ", ["{sad,low}……火は 罪じゃ ない。打つ やつの 心だ。……親父は、それを 忘れた。"]);
      cut(p); await hsay(p, V(["{?}……お父さんも、鍛冶屋さん だったの？"], ["{?}……お父さまも、刀を 打つ 人だったの？"], ["{?}……父親も、鍛冶師？"], ["{?}……お父さまも、鍛冶を なさって いたのですか？"]));
      cut(p, "ヴァルカ"); re(e2, "closed");
      await say(p, "ヴァルカ", ["{closed}背中の これが、親父の 最後の 一本さ。結びの ところで 止まってる。", "{angry,low}……しゃべりすぎた。アンタには 関係ない 話だよ。"]);
      act(e2, 0); if (hq) await leave(e2, p, 12, false); else { if (ok(e2)) { await blaze(p, e2.location, 4); flash(p, true); } rm(e2); }   /* 炎の 中に 消える（鋳造所では 入口の 暗がりへ 歩いて 去る）*/
      const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB); act(eS, "run", false); await wait(14); act(eS, 0);   /* 遅れて 駆けつける */
      await say(p, "セオ", hq ? ["{sweat,汗}はあ、はあ……ジンさんの 知らせを 見て、鍛冶場から 追って 来ました。けがは ありませんか？", "{smile}……鍛冶屋さんの やけどは 軽い。手当ては 済ませました。逃げて きた ボムは、入口で 城の 兵に 引きわたしました。"] : ["{sweat,汗}はあ、はあ……ジンさんの 知らせを 見て 来ました。けが人は？", "{smile}……鍛冶屋さんの やけどは 軽い。手当ては 僕が します。ボムは 城の 兵に 引きわたしました。"]);
      await hsay(p, V(["{angry}セオさん、ヴァルカが 言ってた。仲間が 砂漠の 王墓に 向かったって！"], ["{sad}セオさん……六影が、砂漠の 王墓に 向かったって。"], ["{closed}セオ。六影は 砂漠の 王墓。台座の 注文主は『参謀』。"], ["{angry}セオさん、ヴァルカが 申して いました。仲間が 砂漠の 王墓へ と。"]));
      cut(p); await hsay(p, V(["{?}それと、ボムが『参謀の 注文』って 言ってた。参謀って、だれなんだろ。"], ["{?}ボムは『参謀の 注文』と 言って いたわ。その 人が、六影を 動かして いるのかしら。"], ["{?}台座の 注文主は『参謀』。心当たりは？"], ["{?}ボムは『参謀の 注文』と 申して いました。どなたの ことでしょう。"]));
      cut(p, "セオ"); re(eS, "closed", "…");
      await say(p, "セオ", ["{closed}……兵に 引きわたす とき、ボムが こぼして いました。命令書は いつも、古めかしい 年寄りの 字で 来ると。", "{sad}顔を 見た 者は いない。……僕も、書庫の 記録を 当たって みます。"]);
      await say(p, "セオ", ["{closed}王墓……。入るには、砂王の 許しと 地図が 要ります。", "{up}地図は 僕が 手配します。§eサンドリア城の 城門§f で 落ち合いましょう。あなたは 先に、この 地方の 石板を。"]);
      rm(eS);
      reward(p, d2, 6000, [["e_red", 1], ["SEED2", 2], ["tms_dragon", 1]]); save(p, d2);
      H.rm();
      return true;
    } },
  { r: 3, seal: 4, nospot: 1, hint: "§fヴォルカ火山帯の §6地方マスター カグラ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(4),
    run: async (p, d) => {
      await gateOpen(p, 4, "セオ", ["（手紙）王墓の 地図の 手配が つきました。", "§eサンドリア城の 城門§f の 内側で 待って います。……砂漠は 暑い。水を 忘れずに。"]);
      const H = heroBox(p, true); await hsay(p, V(["{shock,!,jump}王墓！？ ……お宝とか、あるかな？", "{sweat,汗}……呪いとかも、あるかな。"], ["{smile}セオさん、気が きくのね。", "{sweat,汗}……王墓って、ちょっと こわいけど。"], ["{closed}城門で 地図を 受け取る。王墓は それから。"], ["{smile}セオさんが 地図を ご用意 くださったそうです。", "{sweat,汗}……王墓、少し こわいですね。"])); H.rm(); return true; } },
  { r: 4, ch: "第5章 砂の 王墓", at: "gate", hint: "§fサンドリア城の §e城門§f を くぐろう §7（セオから 王墓の 地図を 受け取る 約束。右上の 案内）", trig: (c) => c.r === 4,
    run: async (p, d) => {
      // v2.9: 負けイベント（濡れ衣 → 城の 牢屋）。第122版: 六影の 密告
      if (!qs(d).jailDone) {
        { const H0 = heroBox(p, true); if (epD(d, "r4e2")) await hsay(p, V(["{closed}……城門。セリーヌさん、証拠 守ってるかな。"], ["{closed}……城門ね。セリーヌさん、証拠を 守って くれてると いいけど。"], ["{closed}……城門。セリーヌの 証拠、無事か。"], ["{closed}……城門です。セリーヌさん、証拠を 守って いらっしゃるかしら。"])); else await hsay(p, V(["{sweat,汗}あ、暑い……砂が 口に 入る……。", "{smile,♪}でも 見て！ 砂の 王宮！ セオさん、まだかな？"], ["{sweat,汗}……暑いわね。", "{smile}セオさん、まだ 来てないみたい。"], ["{closed}……暑い。セオは まだ。"], ["{sweat,汗}あ、暑いですね……。", "{?}セオさんは、まだ いらして いない ようです。"])); await gone(p, H0.e); }
        const ok2 = await jailEvent(p); if (!ok2) return false; d = load(p); if (!d) return false;
      }
      /* 第122版: 玉座の 間で 砂王ラシードが 詫び、王墓の 地図を わたす（処刑は ない）*/
      await goPlace(p, "throne", 4, "サンドリア城 玉座の 間");
      const H = heroBox(p, true);
      const eRa = npcNear(p, "§6砂王 ラシード", PJ("rashid", 8), true), eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB, true), eR = npcNear(p, "§bライバル レイ", RIVAL_JOB, true); hold(eRa, "scroll");
      await say(p, "砂王 ラシード", ["{closed,low}……わしが 砂王 ラシード。密告を 疑わずに おまえたちを 牢に 入れたのは、わしの 落ち度だ。", "{sad}詫びの しるしに、§6王墓の 地図§f を わたす。六影より 先に、王墓の 主を 封じて くれ。"]);
      await hsay(p, V(["{angry}……地図は もらう。でも、もう 一つ お願い。牢の イザクさんを 出して あげて！ 娘さんに 花を 届けたかった だけなの！"], ["{sad}……ありがとう ございます。それと、牢の イザクさんの ことを。娘さんに 花を 届けたかった だけなの。"], ["{closed}地図は 受け取る。……それと、牢の イザク。花を 届けようと した だけで 七年だ。"], ["{closed}ありがたく 頂戴 します。……それと、牢の イザクさんの ことを お願い します。娘さんに 花を 届けたかった だけなのです。"]));
      await give(eRa, H.e, "scroll");
      act(eRa, "kneel");
      await say(p, "砂王 ラシード", ["{sad}……イザク。七年前の あの 男か。", "{closed,up}……王の 法は 砂より 重い。じゃが、法を 守って 人を 見なかった わしは、もっと 重い 罪を 犯した。", "{up}イザクを 牢から 出し、娘の 眠る 石の 間へ 通そう。わしが 案内する。"]);
      act(eRa, 0);
      if (ok(H.e)) { act(H.e, "raise"); camNear(p, H.e, 2.2, 1.3); await wait(4); }
      await hsay(p, V(["{smile,☆}……よかった！"], ["{smile}……よかった。"], ["{smile,…}……そう。"], ["{smile}……ありがとう ございます。"]));
      await say(p, "砂王 ラシード", ["{closed,low}……もう 一つ、話して おこう。§e二十年前§f、ある 男が この 玉座の 前に 来た。『石板の 封印が ゆるむ。王冠を 守れ』と 警告しに。", "{sad}誰も 信じなかった。王冠を 狙う 反逆者と して、わしらは 追い返した。……胸に、星の 冠の ような 紋を つけた 男だった。", "{closed,low}……男は、娘が 二人 いると 言って いた。下の 子の 名は、まだ 決めて いないと。"]);
      await hsay(p, V(["{!}……アルカトラスの 王さまも 言ってた。お父さんの 代に 追い返した 男が いたって。……同じ 人？"], ["{!}……アルカトラスの 王さまも、同じ お話を して いたわ。お父さまの 代に 追い返した 人が いたって。……同じ 人かしら。"], ["{closed}……アルカトラスの 王も 言ってた。父の 代に 追い返した 男。……同じ 人か。手帳に 書く。"], ["{!}アルカトラスの 王さまも おっしゃって いました。お父上の 代に 追い返した 方が いたと。……同じ 方でしょうか。"]));
      if (wl(qs(load(p) || d), "wq0d")) {   /* 第125版: 世界の 依頼「老書記の 日誌」を 済ませた 人だけ */
        await hsay(p, V(["{closed}ポカラの ヨハンさんの 日誌にも あった。『あの 目は、うそを つく 目では なかった』って。"], ["{closed}……ポカラの ヨハンさんの 日誌にも、書いて あったわ。『うそを つく 目では なかった』と。"], ["{closed}ポカラの 書記の 日誌。『うそを つく 目では なかった』。"], ["{closed}ポカラの ヨハンさんの 日誌にも ございました。『うそを つく 目では なかった』と。"]));
        if (ok(eRa)) { camNear(p, eRa, 2, 1.5); await wait(6); }
        await say(p, "砂王 ラシード", ["{sad,low}……わしも、そう 思った。思った うえで、追い返したのだ。"]);
      }
      act(eS, "hold");
      await say(p, "セオ", ["{smile}地図には、砂の 下の 入口に 印を つけて あります。§bサンドリアの ステージ（大地）§f で 広げて ください。"]);
      await say(p, "レイ", ["{?}……セオ。その 印、王さまの 地図より 細かいな。王墓に 入った ことが あるのか？"]);
      act(eS, 0); re(eS, "closed", "…"); if (ok(eS)) { camNear(p, eS, 1.8, 1.5); await wait(12); }   /* 第125版: 伏線。セオは 前から 地図を 持って いた */
      await say(p, "セオ", ["{smile,汗}……前から、持って いたんです。それだけです。"]);
      act(eS, "hold"); hold(eS, "orb");
      await say(p, "セオ", ["レイくん、これを。荒野の 遺跡で 見つけた §e星の かけら§f です。お守りに。"]);
      await hsay(p, V(["{shock,!}……待って。村長の 手紙に、かけらは 心を 削るって 書いて あった。"], ["{sad,?}……待って。村長さんの 手紙に、かけらは 心を 削るって 書いて あったわ。"], ["{closed}……待って。村長の 手紙。かけらは 心を 削る、って。"], ["{shock,!}お、お待ち ください。村長さまの お手紙に、かけらは 心を 削ると……。"]));   /* 第125版 Q11 */
      await say(p, "セオ", ["{smile}封じの 紐で 巻いて あります。ほどかなければ、ただの 温かい 石です。"]);
      await give(eS, eR, "orb");
      act(eS, 0); act(eR, "raise"); redGlow(eR); sound(p, "random.orb", 0.5);   /* かけらを かかげる */
      await say(p, "レイ", ["{smile,☆,up}……あったかいな。持ってると、力が 湧いて くる。", "{closed}牢で 何も できなかった 自分を、見なくて 済む 気が する。……王墓の 主、一緒に 行こう。"]);
      await say(p, "セオ", ["{smile,up}……牢で、悔しそうな 顔を してましたね。君は、選ばれる 人ですよ。"]);   /* 第124版(dir#14): 第11章の レイの 回想の 元 */
      act(eR, 0);
      if (ok(H.e)) { re(H.e, "sad", "?"); camNear(p, H.e, 2.2, 1.3); await wait(4); }
      await hsay(p, V(["{sweat,?}……ねえ、その 石、なんだか 嫌な 感じ しない？"], ["{sad,?}……レイくん。その 石、少し 冷たい 感じが するわ。"], ["{?}……その 石。持たない 方が いい 気が する。"], ["{sweat,?}あの……その 石、なんだか 落ちつかない 感じが します。"]));
      await say(p, "レイ", ["{angry,怒}……気の せいだろ。"]);
      cut(p); await hsay(p, V(["{sad}……レイ。牢の こと、まだ 気に してるの？ あれは 密告の せいで……"], ["{sad}……レイくん。牢の ことなら、あなたの せいじゃ ないわ。"], ["{closed}……牢の こと、引きずってる？ あれは 密告の せい。"], ["{sad}……レイさん。牢の ことは、レイさんの せいでは ありません。"]));
      cut(p, "レイ"); re(eR, "closed");
      await say(p, "レイ", ["{closed}……鉄格子の 向こうで、イザクの じいさんが 七年 待ってた。オレは 見てる だけだった。", "{angry}二度と、何も できない 側には 立たない。……それだけだ。"]);
      await bye(p, eRa, eS, eR); H.rm();   /* 第124版: 暗く して から 下げる */
      const d5 = load(p); if (d5) { reward(p, d5, 5000, [["c_herbs", 3], ["g_sp2", 1]]); save(p, d5); d = d5; }   /* 第123版: 段の 最後の ほうび（とちゅうで 抜けても 2回 出ない。地図は 次の 段で syncKeys が 渡す）*/
      await narr(p, "王墓の 地図", [hqDown(qs(d), 4) ? "§7→ §bサンドリアの ステージ（大地）§7で 地図を 広げよう（地図は【だいじなもの】に 入る）" : "§7→ §e砂の 王墓§7（サンドリアの 大地の そば、砂に 沈んだ ピラミッド）の 奥の 大広間で 地図を 広げよう（地図は【だいじなもの】に 入る）"]);
      giveKey(p, d, "k_tomb"); save(p, d); return true;
    } },
  /* 第124版: 王墓は 砂岩の 広間（洞くつ）。3分 できない 世界は 今までどおり ステージで（alt）*/
  { r: 4, hq: 4, at: "hall", hint: "§f王墓の 地図を §e砂の 王墓の 奥の 広間§f で 使おう §7（サンドリアの 大地の そば、砂に 沈んだ ピラミッドの 口から 下りる。レイと 共闘）", key: "k_tomb", where: (c) => hallHere(c.p, 4), whereMsg: "§7地図の 印は ここでは ない。§f砂の 王墓（サンドリアの 大地の そば、砂に 沈んだ ピラミッド）の 奥の 大広間§7で 広げよう。§8（右上の 案内を 見よう）",
    alt: { at: undefined, hint: "§f王墓の 地図を §bサンドリアの ステージ（大地）§f で 使おう §7（レイと 共闘）", where: (c) => c.r === 4 && !!c.stage, whereMsg: "§7地図の 印は ここでは ない。§fサンドリアの ステージ（大地）§7で 広げよう。" },
    run: async (p, d) => {
      const H = heroBox(p, true), inT = hallHere(p, 4);
      if (!qs(d).ch5a) {   /* 第106版: 王墓の 罠。第121版: 床が 沈み、砂から 兵が わく */
        const eR0 = npcNear(p, "§bライバル レイ", RIVAL_JOB);
        sound(p, "random.explode", 0.5); shake(p, 0.6, 1.0); await wait(6);
        big(p, "§6§l王墓の 罠", "§f床が 沈み、壁から 砂の 兵が わき出る！", "mob.husk.ambient");
        { const q = fwd(p, 5); for (let k = 0; k < 3; k++) { burst(p.dimension, q, "minecraft:white_smoke_particle", 10, 1 + k, 0.1); await wait(4); } }
        act(H.e, "guard"); re(H.e, "shock", "!");
        await hsay(p, V(["{shock,!,jump}床が 沈んでる！？ 壁から 何か 出て くる！"], ["{shock,!}……床が！ 壁から、何か……"], ["{angry,!}罠。来るよ。"], ["{shock,!,up}ゆ、床が 沈んで……！ 壁から 何か 出て きます！"]));
        act(eR0, "guard");
        await say(p, "レイ", ["{angry,!,low}砂の 兵だ！ 背中は 任せろ！"]);
        const r = await battle(p, team(["golem", "nether", "golem"], 40, 3, 10), { name: "王墓の 罠", arena: "王墓の 罠", theme: inT ? "desert" : "ruins", speaker: "砂の 兵", guests: team(["dragon"], 38, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……ネムリヲ……", low: "……サラサラ……" } });
        rm(eR0);
        if (r !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["くっ、罠か！ いったん 出よう！", inT ? "§7→ 地図は まだ 使える。もう一度 王墓の 広間で 広げよう" : "§7→ 地図は まだ 使える。もう一度 ステージで 広げよう"]); H.rm(); return false; }
        act(H.e, "point");   /* 碑文を 見つけて 読む */
        await hsay(p, V(["{?}……ねえ、壁に 文字が 刻まれてる。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……", "{sweat,汗}誰かが 爪で 引っかいて、消そうと した 跡が ある……。"], ["{?}……ねえ、壁に 文字が 刻まれてるわ。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……", "{sad}誰かが 爪で 引っかいて、消そうと した 跡が あるの……。"], ["{?}……壁に 文字。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……", "{closed}爪で 消そうと した 跡が ある。"], ["{?}……あの、壁に 文字が 刻まれて います。", "{closed,up}『§e永遠を 願うな。願いは 石に なる§f』……", "{sweat,汗}どなたかが 爪で 消そうと した 跡が あります……。"]));
        act(H.e, 0);
        await say(p, "レイ", ["{closed,low}……誰が 消そうと したんだ。消したく なるほど、本当の ことなのか。"]);   /* 第125版 A24 */
        cut(p); await hsay(p, V(["{?}……願いが、石に？ ハルカさん、廃都は ある 日 いきなり 石に なったって 言ってたよね。", "{sweat,汗}まさか、だれかが 何かを 願ったから……？"], ["{?}……願いが 石に。廃都も、ある 日 石に なったって 聞いたわね。", "{sad}だれかの 願いが、都ごと……？ そんな こと、あるのかしら。"], ["{closed}……願いが 石に。廃都も ある 日 石に なった。", "{?}関係 ある？"], ["{?}……願いが 石に。廃都も、ある 日 突然 石に なったと 伺いました。", "{sweat,汗}まさか、どなたかの 願いが……？"]));
        cut(p, "レイ");
        await say(p, "レイ", ["{angry}願った だけで 石に なるなら、だれだって とっくに 石だ。", "{closed}……書いた やつも、わからずに 書いたのかも しれないな。手帳に 写して おけ。"]);
        const d1 = load(p); if (d1) { qs(d1).ch5a = 1; save(p, d1); } d = d1 || d;
      }
      if (!(qs(d).gate || {})[4]) {   /* 第106版: 主に 勝った あとは 主と もう 戦わない */
        const eR = npcNear(p, "§bライバル レイ", RIVAL_JOB, true), q = fwd(p, 8);
        sound(p, "mob.wither.spawn", 0.8); shake(p, 1, 1.4); flash(p, false);
        if (q) { boom(p.dimension, q); camLowUp(p, q); }
        big(p, "§6§l王墓が 開いた！", "§f砂の 下から 番人が 起きあがる", "mob.wither.spawn"); await wait(16);
        act(eR, "raise"); redGlow(eR);
        cut(p, "レイ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
        await say(p, "レイ", ["{rage,up}……かけらが 熱い。力が、あふれて 止まらない……！", "{smile,low}行こう。今の オレなら、主にも 負けない！"]);
        await hsay(p, V(["{rage,怒,jump}ちょ、ちょっと レイ！ 一人で 突っこまないでよ！"], ["{shock,!}レイくん、待って！ 一人で 行かないで！"], ["{angry}レイ、前に 出すぎ。合わせて。"], ["{shock,!}レイさん！ お一人で 前に 出ないで ください！"]));
        act(eR, 0);
        await duel(p, "§6§l王墓の 主", "§fレイの 竜と 背中を 合わせる！", { fams: ["nether", "golem"] });
        const lv = 42;
        const res = await battle(p, bossOne(["nether", "golem"], lv, 56), { name: "王墓の 主", arena: "王墓の 主", theme: inT ? "desert" : "ruins", hpk: 6, extra: 0.35, tag: "王墓の主", sboss: true, guests: team(["dragon"], lv - 2, 2).map((t) => ({ ...t, owner: "レイ" })), speaker: "王墓の 主", lines: { half: "……王の 眠りを 妨げる 者よ……", low: "……王よ……お許しを……" } });
        rm(eR);
        const d2 = load(p); if (!d2) { H.rm(); return false; }
        if (res !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["{angry}いったん 引こう！ 地図は まだ 使える。……次は、もっと 力を 引き出す。"]); H.rm(); return false; }
        const s = qs(d2); s.gate = { ...(s.gate || {}), 4: true };
        const got = reward(p, d2, 12000, [["e_silver", 1], ["SEED3", 1], ["tms_demon", 1]], false);
        save(p, d2);
        gotShow(p, "§6§l王墓の 主を 倒した！", got);
        const eR2 = npcNear(p, "§bライバル レイ", RIVAL_JOB, true);
        await say(p, "レイ", ["{smile,☆}……やった。二人なら、主にも 勝てる。"]);
        act(eR2, "hold"); camNear(p, eR2, 1.8, 1.0); redGlow(eR2); sound(p, "mob.wither.ambient", 1.4); await wait(12);   /* 手の 中で かけらが 赤黒く 光る */
        await say(p, "レイ", ["{shock,!,up}……っ！", "{angry,closed}なんでもない。……もっとだ。もっと、強く なれる……。"]);
        await hsay(p, V(["{sad,?}……レイ。今の 光、ほんとに なんでもないの？"], ["{sad}……レイくん。今の 光……本当に、大丈夫？"], ["{closed}……今の 光。なんでもない 顔じゃ なかった。"], ["{sad,?}レイさん……今の 光は、本当に 何でも ないのですか？"]));
        act(eR2, 0); await leave(eR2, p, 10, false);
      }
      await gateOpen(p, 5, "セオ", ["（手紙）王墓の 主の 封印、おめでとう ございます。クリスタリアへの 道が 開きました。", "六影は 王墓に 現れません でした。……ねらいは、あなたたちの 足止め だった ようです。", "ヴァルカの 言った とおり、§dクリスタリアの 洞くつ§f で 六影が 水晶を 集めて いる そうです。§e奥の 広間§f を 調べて ください。……レイくんの 様子は、どうですか。"]);
      H.e; await hsay(p, V(["{sad,…}……レイの 様子、か。", "{angry,怒}次に 会ったら、あの かけら、ぜったい 手放させて やるんだから。"], ["{sad}……レイくんの 様子。……あまり、よく ないわ。"], ["{closed}……かけらの せいだ。次に 会ったら、取りあげる。"], ["{sad}……レイさんの ご様子……。次に お会いしたら、あの かけらの こと、きちんと お話し します。"]));
      H.rm();
      return true;
    } },
  { r: 5, ch: "第6章 水晶の 洞くつ", at: "hall", hint: "§fクリスタリアの §e水晶の 洞くつ§f（古い 坑道の レールが 続く）を 下りきった §e奥の 晶洞の 大広間§f へ 行こう §7（右上の 案内で 入口へ）", trig: (c) => c.r === 5,
    run: async (p, d) => {
      const H = heroBox(p, true);
      big(p, "§d§l水晶の 洞くつ", "§f広間の 奥で、六影が だれかを 捕まえている！", "mob.villager.no");
      const eM = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true); act(eM, "kneel");   /* 捕まって ひざを つかされて いる */
      const eG = npcNear(p, "§c六影 班長 ガロ", PJ("garo", 9));
      re(H.e, "shock", "!");
      await say(p, "マリン", ["{cry,!,up}……助けて！ わたしは マリノアの 潜水士、マリン。", "{sad}水晶を 運ぶ 船を 出せって 言われて、断ったら ここまで 連れて こられたの。"]);
      act(H.e, "guard");
      await hsay(p, V(["{rage,怒,jump}ガロ！ 一人を 寄って たかって、何 してるの！"], ["{angry}……ガロさん。その人を 放して。"], ["{angry}ガロ。その人を 放せ。"], ["{angry}ガロさん！ その方を お放し ください！"]));
      await say(p, "ガロ", ["{closed,low}……また お前か。", "{smile}班長 なんて 名ばかりさ。ルミナで お前に 負けて、こんな 水晶の 穴ぐらに 飛ばされた。部下を 二人 つけられてな。", "{sad,up}ピコは まだ 眠ってる。団の 医者に 預けてある。……参謀は 言った。王が 起きれば、呑まれた 心も 戻ると。", "{angry,low}水晶を 運び出すまで、ここは 通さねえ。"]);
      act(H.e, "point");
      await hsay(p, V(["{shock,!}……その 腰の 帽子、ピコくんの……！"], ["{sad}……その 帽子、ピコくんの……"], ["{closed}……腰の 帽子。ピコのだ。"], ["{sad}……その 帽子は、ピコさんの……"]));
      act(H.e, "guard");
      if (!qs(d).ch6x) {   /* 第124版: 班長と 部下の 連戦は 1回に まとめる（ガロ・ドスコ・ヒョロが いっしょに 来る。部下の 名前は 入口の 話 ep_r5 と 同じ）*/
        const eGo = npcNear(p, "§c六影の 下っぱ ドスコ", PJ("noxa", 9)), eGu = npcNear(p, "§c六影の 下っぱ ヒョロ", PJ("noxb", 9)); act(eGo, "run", false); act(eGu, "run", false); await wait(10); act(eGo, "guard"); act(eGu, "guard");
        await say(p, "ドスコ", ["{angry,!}班長を こんな 穴ぐらに 飛ばしやがって！ 仕返しだ！"]);
        await say(p, "ヒョロ", ["{angry,!,low}三人 まとめて 相手を して もらうぜ！ 水晶は 渡さねえ！"]);
        await hsay(p, V(["{rage,怒}仕返し！？ 負けたのは 勝負だからでしょ！ ……いいよ、まとめて かかって きなさい！"], ["{sad}……仕返し、なの？ ……でも、マリンさんは 返して もらうわ。"], ["{closed}八つ当たり。……三人 まとめてで いい。"], ["{angry}そ、それは 八つ当たりです！ ……マリンさんは 返して いただきます！"]));
        const res = await battle(p, team(["golem", "nether", "animal"], 42, 3, 10), { name: "六影 班長 ガロと 部下たち", arena: "六影", theme: "cave", speaker: "ガロ" });
        rm(eGo); rm(eGu);
        if (res !== "win") { rm(eG); await sayAt(p, "§3潜水士 マリン", PJ("marin", 9), "マリン", ["{sweat,汗}……一度 引いて。お願い、また 来て。"]); rm(eM); H.rm(); return false; }
        { const eG2 = npcNear(p, "§c六影 班長 ガロ", PJ("garo", 9), true); act(eG2, "kneel");   /* 第124版(合議): 負けた ガロの 一言と 退場 */
          await say(p, "ガロ", ["{sad}……おやっさんに 言っとけ。こけの 光は、きらいじゃ なかったって。", "{closed}潜水士は 放す。奥は 好きに しろ。……オレは 何も 見なかった。ピコの ところへ もどる。"]);
          if (wl(qs(load(p) || d), "wq5c")) {   /* 第125版: 世界の 依頼「鉱夫の かぶと」を 済ませた 人だけ */
            await hsay(p, V(["{sad,up}ガロ！ アズールの ボルトさんが、あなたの ちっこい かぶとを 磨いて 待ってるよ！"], ["{sad,up}……ガロさん。アズールの ボルトさんが、あなたの かぶとを 磨いて 待って いるわ。"], ["{closed}ガロ。アズールの ボルトが、お前の かぶとを 磨いて 待ってる。"], ["{sad,up}ガロさん。アズールの ボルトさんが、あなたの かぶとを 磨いて お待ちです。"]));
            if (ok(eG2)) { camNear(p, eG2, 1.8, 1.5); re(eG2, "shock", "…"); await wait(8); }
            await say(p, "ガロ", ["{sad,…}……あの かぶと、まだ あったのか。", "{closed,low}……ピコが 起きたら、二人で 取りに 行く。それまで、しまっとけって 言っとけ。"]);
          }
          act(eG2, 0); await leave(eG2, p, 10, false); }
      }
      rm(eM); rm(eG);
      { const dx = load(p); if (dx && !qs(dx).ch6x) { qs(dx).ch6x = 1; save(p, dx); } }
      /* 第106版: 曇った 水晶の 幻。第122版: ベリルは 水晶を 集める 任務で 来る（第4章で ヴァルカが 話した）*/
      if (!qs(load(p) || d).ch6a) {
        const q = hallHere(p, 5) ? altarPt(p, 5, 5, 1) : (() => { const S6 = stageOf(p), a = facAt("r5altar", p.location, 60) || (S6 ? facBuild(p, S6, "r5altar", "crysaltar", 5, Math.floor(S6.P.y)) : null), m = a && facMark("r5altar", "altar", p.location); if (m) return { x: m.x, y: m.y + 1, z: m.z }; const f5 = altarPt(p, 5, 9, 1); if (f5) { const x = Math.floor(f5.x), z = Math.floor(f5.z), g = groundY(p.dimension, x, z, Math.floor(p.location.y) + 3); if (typeof g === "number") for (const c of [`fill ${x - 1} ${g} ${z} ${x + 1} ${g} ${z} smooth_basalt keep`, `setblock ${x} ${g + 1} ${z} tinted_glass keep`, `setblock ${x} ${g + 2} ${z} amethyst_cluster keep`, `setblock ${x - 1} ${g + 1} ${z} amethyst_cluster keep`, `setblock ${x + 1} ${g + 1} ${z} amethyst_cluster keep`]) try { p.dimension.runCommand(c); } catch {} } return f5; })(); H.e;   /* 第128版: 祭壇の 曇った 水晶。第125版(tp): 晶洞の 広間で ない ときは 水晶の 祭壇を 建てる */
        const eM2 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
        if (camPt(p, q, 3, 0.5)) for (let k = 0; k < 5; k++) { burst(p.dimension, q, "minecraft:portal_reverse_particle", 8, 0.7, 0); await wait(3); }
        big(p, "§d§l水晶の 幻", "§f曇った 水晶に 何かが 映る", "block.amethyst_block.chime");
        await hsay(p, V(["{shock,!,up}……水晶の 中に、街が 映ってる。", "{sweat,汗}人も、犬も、噴水の しぶきまで……灰色の 石に なって 止まってる。"], ["{shock,…}……水晶に、街が 映ってる。", "{sad}人も、犬も……みんな、灰色の 石に。"], ["{closed}……水晶に 街。", "{sad}全部 石に なって 止まってる。"], ["{shock,!}す、水晶の 中に 街が……", "{sad}人も 犬も、石に なって 止まって います……"]));
        await say(p, "マリン", ["{sad,…}……これが、各地で 広がってる §8石化§f……。"]);
        await hsay(p, V(["{?}……本の 看板の 家。学者さんの 家、かな。", "{closed}手帳に 書いとこ。『石の 町・学者の 家』。"], ["{?}……本の 看板の 家が ある。学者さんの お家かしら。", "{closed}手帳に 書いて おくわ。『石の 町・学者の 家』。"], ["{closed}……本の 看板の 家。学者の 家か。", "{closed}メモ。『石の 町・学者の 家』。"], ["{?}……本の 看板の お家。学者さまの お家でしょうか。", "{closed}手帳に 記して おきます。『石の 町・学者の 家』。"]));   /* 第124版(dir#16): 第8章で 回収 */
        if (q) { camPt(p, q, 4, 0.5); await shadowFlow(p, q, p.location, 16); }
        shake(p, 0.6, 0.6); flash(p, false);
        act(H.e, "guard");
        await hsay(p, V(["{shock,!}水晶から 影が あふれて くる！"], ["{shock}……影が、あふれて くる……！"], ["{closed}影。……水晶から。"], ["{shock,!}か、影が あふれて きます！"]));
        const eB = npcNear(p, "§5六影 ベリル", PJ("beryl", 9)), eM3 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
        if (q) { burst(p.dimension, q, "minecraft:endrod", 14, 0.8, 0.05); sound(p, "block.amethyst_block.break", 0.8); }   /* 第124版: ベリルが 影を 水晶ごと 箱に 封じる（戦わない）*/
        await say(p, "ベリル", ["{closed}……動かないで。影は この 箱に 封じる。", "{closed}……また 会ったわね。", "{angry}わたしの 任務は、この 洞くつの §d曇った 水晶§f を 集める こと。影を 宿した 水晶を、儀式の ために。……その 水晶から 離れて。"]);
        await hsay(p, V(["{?}……ヴァルカが 言ってた、水晶集めの 子って あなた！？ 何の 儀式に 使うの！？"], ["{?}……ヴァルカの 言ってた 水晶集めは、あなただったのね。何の 儀式なの？"], ["{?}水晶集めの 任務。……儀式って 何。"], ["{?}ヴァルカの 申して いた 水晶集めは、あなたでしたか。何の 儀式なんですか？"]));
        await say(p, "ベリル", ["{sad}知らない。教えて もらえないの。わたし、まだ 仲間じゃ ないから。", "{sad,up}……あの 灰色。わたしの 一座が 消えた 夜と、同じ 色。だから 早く 終わらせたいの。"]);
        act(eM3, "guard");
        await say(p, "マリン", ["{angry,!}……わたしも 戦う。助けて もらった 借りは、ここで 返す！"]);
        await duel(p, "§d§l背中あわせ", "§fマリンの 子と 背中を 合わせて 三方向の 敵を 迎え撃つ！", { fams: ["beast", "blob"] });
        await sixMark(p, eB, "beryl");
        const r2 = await battle(p, team(["beast", "blob", "golem"], 45, 3, 36), { name: sixName("beryl"), arena: "六影", theme: "crystal", hpk: 5, extra: 0.3, tag: "幹部候補", sboss: true, speaker: "ベリル", guests: team(["aqua"], 43, 1).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "二対一……それでも、引けない！", low: "……どうして、いつも こうなの……" } });
        rm(eB); rm(eM3);
        if (r2 !== "win") { await sayAt(p, "§5六影 ベリル", PJ("beryl", 9), "ベリル", ["……勝った。でも、石板を 奪う 力までは 残って ない。……また 来る。", RT(p)]); H.rm(); return false; }
        const eB2 = npcNear(p, "§5六影 ベリル", PJ("beryl", 9), true); act(eB2, "kneel");
        if (ok(eB2)) { camNear(p, eB2, 4.2, 0.9, 0.4); await wait(6); camNear(p, eB2, 1.9, 0.9, 2.2); }   /* 第125版(rs): ひざを つく ベリルへ 話の あいだ ゆっくり 寄る */
        await say(p, "ベリル", ["{sad,…}……また、だめ。", "{closed,up}参謀さまは 約束したの。石板を 持って きたら、わたしの 名前を 団の 座に 書くって。"]);
        { const h = heroFind(p); if (ok(h)) { camNear(p, h, 1.7, 1.4, 0.5); await wait(10); } }   /* 第125版(rs): 聞いて いる 仲間の 顔 */
        await say(p, "ベリル", ["{cry,tears,up}わたしの 一座は 影に 呑まれて、だれにも 書き残されなかった。……座に 名前が 残れば、一座が あった ことも、だれかが 覚えて いて くれる。"]);
        H.e; await hsay(p, V(["{shock,…}……だれにも、書き残されなかった……？"], ["{sad}……だれも、覚えて いないの……？"], ["{closed}……だれも 覚えて ない。そんな こと。"], ["{sad}……だれにも、書き残されなかった……？"]));
        { const eVk = npcNear(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10)); act(eVk, 0);   /* 第125版: 伏線。上の 人が 下っぱを 叱り、ベリルを 座から 遠ざける */
          re(H.e, "shock", "!");
          await say(p, "ヴァルカ", ["{closed,low}……水晶は もう じゅうぶんだ。のこりは 山へ 返しな。", "{closed}ベリル、帰るよ。"]);
          await say(p, "ベリル", ["{sad,up}……ヴァルカさま。わたしの 名前、座に……"]);
          await say(p, "ヴァルカ", ["{closed}……座に 名が 載るのは、§e知る 者§f だけだ。", "{sad,low}アンタは、載らなくて いい。"]);
          act(eB2, 0); re(eB2, "cry", "…"); camNear(p, eB2, 1.6, 1.5); await wait(16);   /* 第125版: 座の 場面は 上の 人の ひと言で 終える（ベリルは 声を 出さずに 泣く）*/
          await leave(eB2, p, 12, true); await leave(eVk, p, 12, false); }
        const d6 = load(p); if (d6) { qs(d6).ch6a = 1; save(p, d6); }
      }
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      const eM4 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
      if (!qs(d2).ch6v) { qs(d2).ch6v = 1; save(p, d2);
        cut(p); await hsay(p, V(["{angry}……『載らなくて いい』って、ひどくない？ あの子、泣いてたのに。"], ["{sad}……『載らなくて いい』なんて。あの子、声も 出さずに 泣いてたわ。"], ["{closed}……『載らなくて いい』。冷たい 言い方。"], ["{sad}……『載らなくて いい』とは、あんまりです。あの方、泣いて いらっしゃいました。"]));
        cut(p, "マリン"); re(eM4, "closed", "…");
        await say(p, "マリン", ["{closed}……そうかな。わたしには、追い返す 人の 顔に 見えなかった。", "{sad}海で 子どもを 岸へ 押し返す ときの 顔。……姉さんが、わたしに よく する 顔だよ。"]);
        cut(p); await hsay(p, V(["{?}……『知る 者だけが 座に 載る』。廃都の 台座にも『影は 知る……に 宿る』って あった。", "{closed}知るって、そんなに 危ない ことなのかな。手帳に 書いとく。"], ["{?}『知る 者だけが 座に 載る』……。廃都の 台座の『影は 知る……に 宿る』と、似て いるわ。", "{closed}知る ことが、危ないの……？"], ["{closed}『知る 者だけ 座に 載る』。台座の『影は 知る……に 宿る』と 同じ 形。", "{?}知ると、影が 来る？"], ["{?}『知る 者だけが 座に 載る』……。廃都の 台座の『影は 知る……に 宿る』と 重なります。", "{closed}知る ことが、危険なのでしょうか。"]));
      }
      cut(p, "マリン");
      await say(p, "マリン", ["{smile}……ありがとう。あなたたちが 来なければ、わたしも 水晶の 奥に 置いて いかれてた。"]);
      act(eM4, "hold"); hold(eM4, "goggles");
      await say(p, "マリン", ["{smile,☆}お礼に、わたしの 予備の §6潜水ゴーグル§f を。深い 海でも 目が 利くように なる。", "{angry}……それと、ガロたちが 話してた。次は §bマリノアの 港§f の §e海神の 貝笛§f を 奪うって。貝笛は 姉さんが 預かってるの。", "{up}港の 桟橋で 待ってる。姉さんにも、会って ほしい。", "§7→ ゴーグルは【だいじなもの】に 入る。クリスタリアの 城で 地方マスターに 挑もう"]);
      await give(eM4, H.e, "goggles");
      act(eM4, 0);
      giveKey(p, d2, "k_goggle"); reward(p, d2, 9000, [["e_blue", 1], ["i_inherit", 1], ["tms_aqua", 1]]); save(p, d2);
      cut(p); await hsay(p, V(["{?}マリンの お姉さんって、どんな 人？"], ["{?}お姉さんは、どんな 方なの？"], ["{?}姉は どんな 人？"], ["{?}お姉さまは、どのような 方なのですか？"]));
      cut(p, "マリン");
      await say(p, "マリン", ["{smile}ナギサ。港の みんなを 守ってる 人。毎朝 桟橋で、海に 向かって 百まで 数えるの。", "{closed}何の ためか、聞いても 教えて くれない。……でも、貝笛だけは 命より 大事に してる。"]);
      H.e; await hsay(p, V(["{smile,♪}ゴーグル、似合いそう！ ……あとで ちょっと 貸してね？"], ["{smile}すてきな ゴーグル。……港で また 会いましょう。"], ["{closed}貝笛が 狙われてる。……急ごう。"], ["{smile}ありがとう ございます。港で、また。"]));
      rm(eM4); H.rm();
      return true;
    } },
  { r: 5, seal: 6, nospot: 1, hint: "§fクリスタリアの §6地方マスター ゴウ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(6),
    run: async (p, d) => { await gateOpen(p, 6, "マリン", ["（手紙）マリノア諸島への 道が 開いたね。", "コラリアの §e網元の 舟小屋§f で 待ってる。姉さんは 夕方、§e港の 桟橋§f に もどるよ。……貝笛、まだ 無事だよ。"]); const H = heroBox(p, true); await hsay(p, V(["{smile,☆,jump}海！ 港！ 潜水！ ……貝笛、守らなきゃ！"], ["{smile}海……。貝笛、守って あげなきゃね。"], ["{closed}港へ。貝笛が 奪われる 前に。"], ["{smile}港へ 参りましょう。貝笛を お守り しなければ。"])); H.rm(); return true; } },
  { r: 6, ch: "第7章 海神の 貝笛", at: "harbor", hint: "§fマリノア諸島の §e港の 桟橋§f へ 行こう §7（マリンと 姉が 待って いる。右上の 案内）", trig: (c) => c.r === 6,
    run: async (p, d) => {
      const s0 = qs(d);
      if (s0.shellBack) return true;   // 取りかえした あとに 落ちても やりなおさない
      const H = heroBox(p, true);
      if (!s0.shellLost) {
        /* 第122版: 波を 数える ナギサ → 夜の 浜が 燃える → 第125版(vk): 燃える 流木から 笛を 拾った 手の やけど → 岬の 灯台へ */
        big(p, "§b§lマリノア諸島", "§f潮風の 港で、だれかが 波に 向かって 指を 折っている");
        const eN = npcAt(p, "§6潮風の 地方マスター ナギサ", PJ("nagisa", 8), fwd(p, 4, 1.5)); act(eN, "point");
        await say(p, "ナギサ", ["{closed}……七、八。今日は 満ちるのが 遅いな。"]);
        act(eN, 0);
        await say(p, "ナギサ", ["{shock,!,jump}……うわっ！？ いつから いたの？"]);
        const eM = npcNear(p, "§3潜水士 マリン", PJ("marin", 9));
        await say(p, "マリン", ["{smile}姉さん、この 人たちが 水晶の 洞くつで 助けて くれたの。", "{angry}六影が 貝笛を 狙ってる って 話も、この 人たちと 聞いた。"]);
        act(eN, "hold");   /* 両手で 手を 握って ぶんぶん 振る */
        await say(p, "ナギサ", ["{smile,♪,up}マリンを！？ ありがとう、ありがとう！ わたしは 姉の ナギサ。この 港の 地方マスターよ。", "{blush}あの子、潜る ことしか 考えて ないから。……あ、でも、わたしの いちばんの 自慢なんだ。"]);
        act(eN, 0);
        cut(p, "");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
        await hsay(p, V(["{smile,♪}ナギサさん、ね。……手帳に 書いとこ。"], ["{smile}ナギサさん。……手帳に 書いて おくわね。"], ["{closed}ナギサ。……今、何を 数えてたの？"], ["{smile}ナギサさん、ですね。手帳に 記して おきます。"]));
        await say(p, "ナギサ", ["{smile}波だよ。港の 仕事は、まず 潮を 読む こと。毎朝 百 数えて、今日 船を 出すか 決めるの。"]);
        act(eM, "show"); hold(eM, "flute");
        await say(p, "マリン", ["これは 姉さんから 預かった §6海神の 貝笛§f。沈んだ 神殿の 番人を 呼び起こす 笛よ。", "深い 海で 吹くと、番人が 答える。番人が 認めれば、神殿に 眠る 紋章を 託して くれるはず。", "{angry}六影より 先に、番人に 紋章を 託して もらうの。紋章が あれば、貝笛を 取られても 神殿は 開かない。", "§7→ 水面から 6ブロック 以上 もぐって 吹く"]);
        await give(eM, eN, "flute");
        act(eM, 0);
        giveKey(p, d, "k_shell"); save(p, d);
        await say(p, "ナギサ", ["{closed}笛は 浜まで わたしが 持つ。かあさんの 笛だから。……潮の 道が 開いたら、マリンに 渡す。"]);
        await say(p, "ナギサ", ["{closed}今夜は 大潮。§e夜の 浜§f から、潮の 道が 沖へ 伸びる。深く 潜るなら その 時が いい。", "{smile}わたしも 浜まで ついて いく。貝笛を 狙う 連中が いるなら、なおさらね。"]);
        // v2.9: 負けイベント（だいじなものを 奪われる）。第122版: 夜の 浜へ 本当に 移り、炎が 走る
        await goPlace(p, "beach", 6, "夜の 浜"); sceneTime(p, "night");
        if (ok(eN)) place(eN, p, fwd(p, 4, 1.5)); if (ok(eM)) place(eM, p, fwd(p, 3.5, -1.8));
        const f = fwd(p, 7);
        drift(p, fwd(p, 9.5, -3.6), [fwd(p, 10.6, -4.4), fwd(p, 10.4, -2.6)]);   /* 第125版(tp): 燃える 流木（焚き火と 流木。流木は 奥側の 半ブロック。手前の 火は 笛が 落ちる ときに 炎の 中で 置く）*/
        sound(p, "random.explode", 0.8); shake(p, 0.6, 0.8);
        if (f) { camPt(p, f, 6, 2); await blaze(p, f, 6); }
        big(p, "§c§l浜が 燃えている！", "§f炎の 中から、だれかが 歩いて くる", "mob.blaze.shoot");
        const e = npcAt(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), f); if (ok(e)) flash(p, true);
        if (ok(eN)) { const q = fwd(p, 3); if (q) await go(eN, q, 10, true); act(eN, "guard"); }   /* ナギサが 貝笛を 抱いて 前に 出る */
        re(H.e, "shock", "!");
        await say(p, "ヴァルカ", ["{smile,low}その 貝笛、いただくよ。", "{closed}燃やしたのは 流木だけだ。火の 輪の 外に いりゃ、だれも 焼けない。"]);
        await hsay(p, V(["{rage,怒,jump}ヴァルカ！ なんで 貝笛まで 狙うの！？"], ["{angry}……どうして 貝笛を？"], ["{angry}貝笛を 何に 使う 気。"], ["{angry}ヴァルカ！ なぜ 貝笛を！"]));
        await say(p, "ヴァルカ", ["{closed}参謀の 言いつけさ。『石板の 子が 神殿の 番人に 会う 前に、笛を 預かれ。まだ 早い』ってね。", "{closed,low}……届ければ、アタシは 開かずの 部屋の 鍵に 一歩 近づく。", "{angry}アタシは 六影だ。命令なら、大事な もんでも 取る。……今日は §e試し§f じゃ ない。"]);
        await hsay(p, V(["{rage,怒,jump}ナギサさん、下がって！"], ["{shock,!}ナギサさん、下がって……！"], ["{angry,!}ナギサ、下がって。"], ["{shock,!}ナギサさん、お下がり ください！"]));
        await sixMark(p, e, "valka");
        await battle(p, team(["dragon", "nether"], 70, 3, 40), { name: sixName("valka"), arena: "奪われた 貝笛", theme: "beach", speaker: "ヴァルカ", hpk: 30, extra: 0.6, tag: "本気の 幹部", heal: false,
          scripted: { turns: 2, lines: ["§c§lヴァルカの 竜が 炎の 渦を 起こした！", "§7熱で 視界が ゆがむ…… 仲間たちが 次々と 倒れていく！"] }, lines: { half: "やるねえ……でも ムダだよ！" } });
        rm(e); rm(eN); rm(eM);
        const d2 = load(p); if (!d2) { H.rm(); return false; } const s2 = qs(d2);
        { const n = countItem(p, "mrpg:k_shell"); if (n > 0) takeItem(p, "mrpg:k_shell", n); } s2.keys = (s2.keys || []).filter((k) => k !== "k_shell"); s2.shellLost = 1; save(p, d2);
        /* 第125版(vk): 取られる ところを 見せる。ヴァルカの 火は 流木だけ。はじかれた 貝笛が 燃える 流木に 落ち、ナギサが 自分で 火に 手を 入れて 拾う（両手の やけど。体の 形は 変わらない）。印 nagiDead は「マスターを 退いた」の 意味 */
        const eV = npcAt(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), fwd(p, 6, -1.5)), eN2 = npcAt(p, "§6ナギサ", PJ("nagisa", 8), fwd(p, 3.5, 1)); act(eN2, "guard"); hold(eN2, "flute");
        if (ok(eN2)) { camNear(p, eN2, 3, 1.2); await wait(10); }
        await say(p, "ヴァルカ", ["{closed}……勝負は ついた。笛を 離しな。"]);
        await say(p, "ナギサ", ["{angry,up}……いや。かあさんの 笛よ。"]);
        act(eV, "raise"); sound(p, "mob.blaze.shoot", 0.8);
        const w = fwd(p, 4.5, 2.8); if (w) { camPt(p, w, 4, 1.2); drift(p, fwd(p, 5.7, 4.1)); await blaze(p, w, 4); }
        act(eN2, "recoil"); hold(eN2); act(eV, 0);
        await narr(p, "夜の 浜", ["§7火の 粉が はぜて、ナギサの 手から 貝笛が はじかれた。", "§7貝笛は、燃える 流木の 中へ 転がった。"]);
        if (ok(eN2) && w) { await go(eN2, fwd(p, 4.7, 3.3) || { x: w.x - 0.8, y: w.y, z: w.z }, 10, true); act(eN2, "kneel"); burst(p.dimension, w, "minecraft:basic_smoke_particle", 8, 0.6, 0.4); camNear(p, eN2, 2.4, 0.6); await wait(12); }
        hold(eN2, "flute");
        await narr(p, "夜の 浜", ["§7ナギサは 迷わず、炎の 中へ 両手を 入れた。", "§7……貝笛を 握った 手から、白い 煙が 上がる。"]);
        if (ok(eN2)) burst(p.dimension, eN2.location, "minecraft:white_smoke_particle", 6, 0.4, 1);
        re(H.e, "shock", "!");
        await hsay(p, V(["{shock,!,up}ナギサさん！！"], ["{shock,!,up}ナギサさん……！"], ["{shock,!}……ナギサ！"], ["{shock,!,up}ナギサさん！！"]));
        if (ok(eV) && ok(eN2)) { const q = eN2.location; await go(eV, { x: q.x + 1.1, y: q.y, z: q.z + 0.4 }, 12); }
        re(eV, "closed", "…");   /* 笛を 取る ときだけ 目を そらす（r6e4 で ナギサが 言う）*/
        await give(eN2, eV, "flute"); act(eN2, "down");
        await say(p, "ヴァルカ", ["{closed,low}……離せば よかったんだ。なんで、離さなかった。", "{sad,low}……人に 向けた 火じゃ ない。でも、焼いたのは アタシの 火だ。言い訳は しない。"]);
        { const dn = load(p); if (dn) { qs(dn).nagiDead = 1; save(p, dn); } }
        if (ok(H.e) && ok(eV)) { const q = eV.location, P0 = p.location, n = Math.hypot(P0.x - q.x, P0.z - q.z) || 1; await go(H.e, { x: q.x + ((P0.x - q.x) / n) * 1.8, y: q.y, z: q.z + ((P0.z - q.z) / n) * 1.8 }, 12, true); act(H.e, "guard"); }   /* 第125版(tp): 火の 手前（こちら側）から 詰め寄る */
        await hsay(p, V(["{rage,怒,up}……それ、返しなさいよ。", "{rage,怒,jump}返しなさいって！！"], ["{angry,up}……それ、返して。", "{angry,up}……返して。"], ["{rage,怒}……それを 返せ。", "{rage,怒}……返せ。"], ["{rage,怒,up}……それを、お返し ください。", "{rage,怒,up}お返し ください！！"]));
        cut(p, "ヴァルカ");
        await say(p, "ヴァルカ", ["{closed,low}……預かり物だよ。番人に 会うのは、まだ 早い。", "{angry,low}取りかえしたけりゃ、§e岬の 灯台§f まで 来な。迎えの 舟は 夜明けだ。……逃げも 隠れも しないよ。"]);
        act(eV, 0); await leave(eV, p, 12, false);
        const eM2 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true); act(eM2, "run", false);
        if (ok(eM2) && ok(eN2)) { const q = eN2.location; await go(eM2, { x: q.x + 0.9, y: q.y, z: q.z }, 10, true); } act(eM2, "kneel");
        await say(p, "マリン", ["{cry,!,up}姉さん！！ 手が……！"]);
        await narr(p, "夜の 浜", ["§7マリンは 海水で 姉の 両手を 冷やし、自分の 上着の 袖を 裂いて 巻いた。"]);
        act(eN2, "kneel");
        await say(p, "ナギサ", ["{sad}……ごめんね、マリン。笛、取られちゃった。", "{closed,…}……離せば よかったのに、離せなかった。火に 手を 入れたのは、わたし。", "{sad,up}この 手じゃ、しばらく 櫂も 網も 握れない。深い 海は、なおさら。……港の マスターは、あなたに 頼む。この 石板を。"]);
        await hsay(p, V(["{sad,…,up}……ナギサさんの 手……"], ["{sad,…,up}……ナギサさんの 手が……"], ["{sad,…,up}……ナギサの 手……"], ["{sad,…,up}……ナギサさんの お手が……"]));
        act(eM2, "hold"); hold(eM2, "goggles");   /* 姉の ゴーグルを 額に かける */
        await say(p, "マリン", ["{closed}……潮は 引いても、必ず 満ちる。", "{angry,up}姉さんの 代わりに、わたしが 潜る。……でも その 前に、笛よ。§e岬の 灯台§f へ 行こう。"]);
        await bye(p, eN2, eM2);
      }
      /* 取りかえす（負けても ここから やりなおせる）。第125版(vk): 本当に 岬の 灯台へ 移ってから 戦う（その場では 戦わない）*/
      if (!(await confirm(p, "奪われた 貝笛", "§fヴァルカを §e岬の 灯台§f まで 追いかける？\n§7（マリンも いっしょに 戦う）", "追いかける", "あとで"))) { H.rm(); return false; }
      const LH = await capeGo(p, (L) => { const e = npcAt(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), fwd(p, 6.5, 1.2)); if (ok(e)) { hold(e, "flute"); if (L) try { e.teleport(e.location, { facingLocation: { x: L.x, y: e.location.y + 1.5, z: L.z } }); } catch {} } });
      const e2 = npcNear(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), true);
      if (ok(e2)) { camNear(p, e2, 3.2, 1.4); await wait(16); }   /* 灯台の 下で、海を 見て いる 背中 */
      heroNear(p); const eMc = npcNear(p, "§3潜水士 マリン", PJ("marin", 9));
      await hsay(p, V(["{angry,up}……ヴァルカ！"], ["{angry,up}……ヴァルカ。"], ["{angry}……ヴァルカ。"], ["{angry,up}……ヴァルカ！"]));
      if (ok(e2)) try { e2.teleport(e2.location, { facingLocation: p.getHeadLocation() }); } catch {}
      await say(p, "ヴァルカ", ["{closed}……来たね。舟より 先に。", "{angry,low}命令は 命令だ。笛が ほしけりゃ、力で 取りな。"]);
      await say(p, "マリン", ["{angry,up}……姉さんの 笛、返して もらう。"]);
      const r2 = await battle(p, team(["dragon", "nether"], 50, 3, 54), { name: sixName("valka"), arena: "岬の 灯台", asked: true, theme: "beach", hpk: 11, extra: 0.35, tag: "三の座", sboss: true, speaker: "ヴァルカ",
        guests: team(["aqua"], 48, 2).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "なんで…… さっきは 手も 足も 出なかった くせに！", low: "……参謀に、なんて 言えば……" } });
      const d3 = load(p); if (!d3) { H.rm(); return false; }
      if (r2 !== "win") { rm(e2); rm(eMc); await sayAt(p, "§3潜水士 マリン", PJ("marin", 9), "マリン", ["……一度 港で 立てなおそう。", "貝笛は、必ず 取りかえす。姉さんの ためにも。"]); H.rm(); return false; }
      const s3 = qs(d3); s3.shellLost = 0; s3.shellBack = 1; giveKey(p, d3, "k_shell"); save(p, d3);
      const eV3 = npcNear(p, "§c六影 幹部 ヴァルカ", PJ("valka", 10), true), eM3 = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true); act(eV3, "kneel"); hold(eV3, "flute");
      await say(p, "ヴァルカ", ["{sweat,息}……負けは 負けだ。笛は 返す。……アタシは 嘘は つかない。"]);
      act(eV3, 0); if (ok(eV3) && ok(eM3)) { const q = eM3.location; await go(eV3, { x: q.x + 1.1, y: q.y, z: q.z + 0.3 }, 10); }
      await give(eV3, eM3, "flute"); act(eM3, "show", false);
      big(p, "§b§l海神の 貝笛を 取りかえした！", "§fもう 二度と はなさない");
      await say(p, "ヴァルカ", ["{closed}……参謀に、なんて 言えば いいんだか。", "{closed,low}……姉さんの 手、海水で 冷やし 続けな。三日は。"]);
      act(eV3, 0); { const q = away(eV3, p, 10); if (q) await go(eV3, q, 24); } await bye(p, eV3);   /* 岬を 下りて いく（見えて いる うちに 消さない）*/
      cut(p); await hsay(p, V(["{sad}……ナギサさん、なんで 離さなかったんだろ。火の 中だよ。"], ["{sad}……ナギサさん、どうして 離さなかったのかしら。火の 中なのに。"], ["{closed}……火の 中でも 離さなかった。なんで。"], ["{sad}……ナギサさんは、なぜ 火の 中でも 離さなかったのでしょう。"]));
      cut(p, "マリン"); re(eM3, "closed", "…");
      await say(p, "マリン", ["{closed}……かあさんの 笛 だから。わたし、かあさんの 顔を 覚えて ないの。", "{sad}姉さんは 覚えてる。だから、あの 笛を 離せない。……わたしの 分まで、持ってて くれたんだ。"]);
      await say(p, "マリン", ["{smile,up}……でも、もう 大丈夫。取りかえした。", "{?}ヴァルカの 言ってた『参謀』……六影を 動かしてる 人。いったい 誰なの。", "§7→ ゴーグルを 持って 沖の 深い 海へ。沈んだ 神殿の 前で 貝笛を 吹く"]);
      await hsay(p, V(["{angry,up}……誰でも いい。ナギサさんの 手の 分、ぜったい 許さない。"], ["{angry,up}……誰でも いいの。ナギサさんの 手の 分、許さないわ。"], ["{angry,up}……誰でも いい。ナギサの 手の 分、返して もらう。"], ["{angry,up}……どなたでも 構いません。ナギサさんの 手の 分、決して 許しません。"]));
      rm(eM3); H.rm();
      return true;
    } },
  { r: 6, hint: "§fゴーグルを 持って §bマリノアの 沖§f へ。§e水面の ブイ§f の 下へ 潜り、海の 底の §e沈んだ 神殿§f の 前で 海神の 貝笛を 吹こう §7（大潮の うちに。右上の 案内。舟や 泳ぎで 沖へ）", key: "k_shell", tgt: (p) => diveTgt(p), where: (c) => diveOk(c), whereMsg: "§7ここでは 音が 響かない。§fマリノアの 沖、§eブイの 下§f の 海の 底（沈んだ 神殿の 前）まで 潜って 吹こう §7（右上の 案内）",
    pre: (c) => (has(c, "k_goggle") ? null : "§7暗くて 何も 見えない……潜水ゴーグルが 必要だ。"),
    run: async (p, d) => {
      const H = heroBox(p);
      /* 第125版(vk): 海の 底の 沈んだ 神殿（deepsea の 海溝）。神殿の 引きの 絵 → 泡が 立ちのぼり、番人が 神殿の 戸口から 現れる */
      const DV = diveAt(), deep = !!(DV && DV.B !== undefined); try { p.addEffect("water_breathing", 900, { showParticles: false }); } catch {}
      const eMd = deep ? npcAt(p, "§3潜水士 マリン", PJ("marin", 9), { x: DV.x + 2, y: DV.B + 1, z: DV.z + 2 }) : npcNear(p, "§3潜水士 マリン", PJ("marin", 9)); hold(eMd, "flute");   /* 第125版(co): 約束どおり マリンが 先に 潜る */
      if (deep) { camAt(p, { x: DV.x + 9, y: DV.B + 14, z: DV.z - 8 }, { x: DV.x, y: DV.B + 8, z: DV.z + 12 }, 0.8); await narr(p, "沈んだ 神殿", ["§7マリンが 先に 潜り、あなたたちは その 泡を 追った。海の 底に、折れた 柱と 丸い 屋根の 神殿が 眠って いた。"]); }
      if (ok(eMd)) { act(eMd, "show"); camNear(p, eMd, 2.6, 0.8); }
      await narr(p, "沈んだ 神殿", ["§7……マリンが 貝笛を 吹くと、低い 音が 柱の あいだを 渡って いった。"]); sound(p, "note.flute", 0.7); act(eMd, 0);
      const q = deep ? { x: DV.x, y: DV.B + 2, z: DV.z + 4 } : fwd(p, 6, 0, -2);
      for (let k = 0; k < 4; k++) { burst(p.dimension, q, "minecraft:bubble_column_up_particle", 8, 0.6 + k * 0.4, 0); await wait(3); }
      sound(p, "mob.elderguardian.curse", 0.8); shake(p, 0.5, 0.8); if (q) camLowUp(p, q);
      big(p, "§3§l沈んだ 神殿の 番人", "§f貝笛の 音が 海の 底へ 響いた", "mob.elderguardian.curse");
      H.e; await hsay(p, V(["{shock,!,up}……下から 何か 上がって くる！ おっきい……！"], ["{shock,!,up}……下から 何か 上がって くるわ！ おおきい……！"], ["{shock,!}……下から 来る。でかい。"], ["{shock,!,up}……下から 何かが 上がって きます！ 大きい……！"]));
      const lv = 52;
      const res = await battle(p, bossOne(["aqua"], lv, 32), { name: "神殿の 番人", arena: "沈んだ 神殿", theme: "beach", hpk: 3.9, extra: 0.4, tag: "神殿の番人", sboss: true, speaker: "神殿の 番人", guests: team(["aqua"], 50, 2).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "……海ノ 誓イヲ……知ル者カ……", low: "……認メヨウ……陸ノ 子ヨ……" } });
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { H.e; await hsay(p, V(["{sweat,汗}番人、海の 底へ 戻っちゃった……。貝笛は まだ 使えるよ。"], ["{sweat,汗}番人、海の 底へ 戻っちゃったわ……。貝笛は まだ 使えるわよ。"], ["{closed}番人は 海の 底へ 戻った。貝笛は まだ 使える。"], ["{sweat,汗}番人は 海の 底へ 戻って しまいました……。貝笛は まだ 使えます。"])); rm(eMd); H.rm(); return false; }
      { const e = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true); if (ok(e)) camNear(p, e, 2.4, 0.8); await say(p, "マリン", ["{smile,tears,up}……番人、認めて くれた。……姉さんの 百、まだ 終わって ないよね。"]); await leave(e, p, 10, false); }
      giveKey(p, d2, "k_crest");
      const got = reward(p, d2, 18000, [["e_rainbow", 1], ["SEED3", 1], ["i_trpick", 1], ["tms_bird", 1]]); save(p, d2);
      gotShow(p, "§3§l潮の 紋章を 託された！", got);
      /* 港へ 戻って、ナギサに 知らせる */
      await goPlace(p, "harbor", 6, "港の 桟橋");
      const eN = npcAt(p, "§6ナギサ", PJ("nagisa", 8), fwd(p, 3.5)); act(eN, "sad");
      const eM = npcNear(p, "§3潜水士 マリン", PJ("marin", 9), true);
      if (ok(H.e) && ok(eN)) { const l = eN.location; await go(H.e, { x: l.x + 0.9, y: l.y, z: l.z + 0.4 }, 10); act(H.e, "kneel"); }
      await hsay(p, V(["{sad,…}……ナギサさん。番人、ちゃんと 答えて くれたよ。", "{sad,up}……ごめんなさい。あの 夜の 浜で、間に 合わなかった。"], ["{sad,…}……ナギサさん。番人、ちゃんと 答えて くれたわ。", "{sad,up}……ごめんなさい。あの 夜の 浜で、間に 合わなかったの。"], ["{sad,…}……ナギサ。番人は 答えた。", "{sad,up}……ごめん。あの 夜の 浜で、間に 合わなかった。"], ["{sad,…}……ナギサさん。番人は、ちゃんと 答えて くれました。", "{sad,up}……申し訳 ありません。あの 夜の 浜で、間に 合いませんでした。"]));
      act(eN, "hold");   /* やけどの 手で、不器用に 頭を なでる */
      await say(p, "ナギサ", ["{smile,up}間に 合ったよ。マリンが、潜ったんだから。"]);
      await hsay(p, V(["{cry,tears,up}……っ。"], ["{cry,tears,up}……っ。"], ["{cry,tears}……っ。"], ["{cry,tears,up}……っ。"]));   /* こらえきれずに、一粒だけ */
      act(eN, 0); act(H.e, 0); act(eM, "guard");
      await say(p, "マリン", ["{angry,!}今度は わたしが 港の マスター。……城で 待ってる。手加減 しないから！", "§7→ マリノアの 城で 地方マスター マリンに 挑もう"]);
      { const eS = npcNear(p, "§7学者 セオ", TRAITOR_JOB); act(eS, "run", false); await wait(12); act(eS, 0);   /* 第125版: 伏線。セオが 背を 向けて 手帳の 頁を 破る */
        await say(p, "セオ", ["{sweat,汗}……浜で 火が 出たと、町で 聞きました。", "{sad}……遅く なりました。ナギサさんの 手当てを させて ください。"]);
        if (ok(eS)) { const q = away(eS, p, 3); if (q) await go(eS, q, 14); act(eS, "hold"); camNear(p, eS, 2.4, 1.4); await wait(8); }
        await wait(6);   /* 第124版(合議): 頁を 破る 芝居は 祭りの 支度の 夜（ep_r6）に 1回だけ。ここは 破れた あとに 気づく */
        cut(p); await hsay(p, V(["{?}……セオさん。手帳、一枚 やぶれた あとが ある。"], ["{?}……セオさん。手帳に、一枚 やぶれた あとが あるわ。"], ["{closed}……セオ。手帳、一枚 破れてる。"], ["{?}あの、セオさん。手帳に 一枚、やぶれた あとが……"]));
        act(eS, 0);
        await say(p, "セオ", ["{closed}……読まなくて いい 頁です。", "{smile,low}……番人に、もう 会えたんですね。……よかった。ナギサさんの 手が、無駄に ならなくて。"]);
        { const g7 = palEnt(p); if (g7) { camNear(p, g7, 2.2, 0.7); await wait(8); } await pal(p, ["……むらさきの、インクの におい。"]); rmCine(g7); }
        cut(p); await hsay(p, V(["{?}……インク？ 手帳を 書いてた だけ、だよね。", "{closed}……今は ナギサさんの 手当てが 先。"], ["{?}……インクの におい？ 手帳を 書いて いた だけ、よね。", "{closed}……今は、ナギサさんの 手当てが 先ね。"], ["{closed}……インク。何を 書いて、何を 破った。", "{closed}……今は 手当てが 先。"], ["{?}……インクの におい、ですか。手帳を 書いて いらした だけ、ですよね。", "{closed}……今は、ナギサさんの 手当てが 先です。"]));
        await leave(eS, p, 8, false); }
      rm(eN); rm(eM); H.rm();
      return true;
    } },
  { r: 6, seal: 8, nospot: 1, hint: "§fマリノア諸島の §6地方マスター マリン（ナギサの 跡つぎ）§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(8),
    run: async (p, d) => {
      await gateOpen(p, 7, "セオ", ["（手紙）ネクロス冥府領への 道が 開きましたね。", "冥府に、どうしても 調べたい ものが あります。§e冥王の 城の 中庭§f で 会いましょう。……あなたに、話して おかなければ ならない ことも あります。"]);
      const H = heroBox(p, true);
      await hsay(p, V(["{?}……セオさんの 字、なんだか ふるえてる。"], ["{sad}……セオさんの 字、いつもより 弱いわ。"], ["{closed}……字が 乱れてる。"], ["{?}……セオさんの 字、いつもと ちがう 気が します。"]));
      sound(p, "mob.parrot.fly", 1);
      await say(p, "レイ", ["（手紙）セオから 前に もらった 研究メモの 写し。光に かざしたら、§e消し跡§f が あった。", "消されてたのは『冥府』と『鍵』って 字だ。……気に なる。オレも 冥府へ 行く。先に 着いたら、勝手に 動くなよ。"]);
      await hsay(p, V(["{shock,!}……消し跡。わたしの 写しにも、あった。"], ["{shock,…}……消し跡。最初に もらった メモにも、あったわね。"], ["{closed}……消し跡。最初から、あった。"], ["{shock,!}消し跡……。わたしの 頂いた メモにも ありました。"]));
      act(H.e, "raise"); flash(p, true); await narr(p, "", ["§7……研究メモを 光に かざすと、『冥府』『鍵』。同じ 所に、同じ 消し跡が あった。"]); act(H.e, 0);
      H.rm(); return true; } },
  { r: 7, ch: "第8章 冥府の 霊廟", at: "court", hint: "§fネクロス冥府領の §e冥王の 城の 中庭§f へ 行こう §7（セオとの 待ち合わせ。右上の 案内）", trig: (c) => c.r === 7 && !(Date.now() - (c.s.ch8no || 0) < 90000),
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch8a) {   /* 第106版: 冥王の 葬列・セオの 回し者。第122版: 護衛を 引き受けるか えらぶ */
        big(p, "§5§l冥王の 城の 中庭", "§7黒い 行列が、霊廟へ 向かう 支度を して いる", "mob.wither.ambient");
        const eM = npcAt(p, "§5冥王 モルテ", PJ("morte", 15), fwd(p, 4, 1.5));
        /* 第124版: 葬列は 6人（2列×3。先頭の 2人の あいだを あけて、棺を 運ぶ 列に 見せる）。同じ 名札でも 別の 人に なる よう 見えない 印を 足す */
        const CS = [[6, -1.2], [6, 1.2], [8, -1], [8, 1], [10, -1], [10, 1]], cs = CS.map(([a, b], k) => npcAt(p, "§8葬列の 民" + "§r".repeat(k), 23, fwd(p, a, b))), c1 = cs[0]; for (const c of cs) act(c, "sad");
        await say(p, "冥王 モルテ", [(qs(d).epx || {}).road7 ? "{closed,low}……来て くれたか。葬列の 道を 清めて くれた 礼を 言う。" : "{closed,low}……ようこそ、死者の 国へ。わしは この 地を 治める 冥王 モルテ。", "{sad}今日は 葬列の 日だ。家族が『送る』と 決めた 石の 者たちを、年に 一度 §e霊廟§f へ 送る。", (qs(d).epx || {}).road7 ? "{closed,up}……約束どおり、葬列の 護衛を 頼む。" : "{angry,up}近ごろ 影の モンスターが 棺を 狙って くる。……石板を 持つ 者よ。護衛を 頼めるか。"]);
        await hsay(p, V(["{?}……なんで わたしたちに？ 城の 兵士さんは？"], ["{?}どうして、わたしたちに？"], ["{?}なぜ わたしたち。兵は？"], ["{?}あの、なぜ わたしたちに お声を？"]));
        await say(p, "冥王 モルテ", ["{sad}兵の 半分は 影に 呑まれて 眠った。……セオという 学者から 聞いたのだ。おまえたちは 影に 呑まれぬ、と。", "{closed}その 学者なら、霊廟の 奥で 調べものを して おる。葬列の 行き先も 霊廟だ。"]);
        const ans = (qs(d).epx || {}).road7 ? 0 : await choose(p, "冥王 モルテ", "§5§l冥王 モルテ§r\n\n§f「葬列の 護衛を 頼めるか」", [["引き受ける", ICON("i_book")], ["今は 断る", ICON("i_close")]]);   /* 第124版: 葬列の 道で もう 引き受けて いれば 聞かない */
        if (ans !== 0) {
          await say(p, "冥王 モルテ", ["{closed}……そうか。無理は 言わぬ。気が 変われば、また 中庭へ 来て くれ。", "§7（しばらく してから 中庭に 来ると、もう一度 頼まれる）"]);
          rm(eM); for (const c of cs) rm(c); H.rm();
          const dn = load(p); if (dn) { qs(dn).ch8no = Date.now(); save(p, dn); }
          return "next";
        }
        await hsay(p, V(["{angry}引き受けた！ 棺には ぜったい さわらせない。"], ["{closed}……分かりました。お見送り、お手伝い します。"], ["{closed}引き受ける。セオにも 会わなきゃ ならないし。"], ["{closed}お引き受け します。死者の 方々を、お守り します。"]));
        if (ok(c1)) { camPt(p, c1.location, 6, 1.5); cs.forEach((c, k) => { const q = fwd(p, CS[k][0] + 5, CS[k][1]); if (q) go(c, q, 30); }); await wait(20); }   /* 全員 そろって 門の 方へ */
        { const a = fwd(p, 8, 3), b = fwd(p, 3); if (a && b) { await shadowFlow(p, a, b, 16); shake(p, 0.4, 0.5); } }
        act(H.e, "guard"); re(H.e, "shock", "!");
        await hsay(p, V(["{angry,!}来た！ 棺には さわらせないよ！"], ["{angry,!}来たわ！ 棺には さわらせない！"], ["{angry,!}来た。棺には 触らせない。"], ["{angry,!}来ました！ 棺には 触れさせません！"]));
        const r1 = await battle(p, team(["nether", "nether", "animal"], 54, 3, 14), { name: "墓場の モンスター", arena: "冥王の 葬列", theme: "soulvalley", speaker: "墓場の モンスター", lines: { half: "……ヒツギ……ヨコセ……", low: "……ネムラセテ……" } });
        rm(eM); for (const c of cs) rm(c);
        if (r1 !== "win") { await sayAt(p, "§5冥王 モルテ", PJ("morte", 15), "冥王 モルテ", ["……棺が 倒れた。死者に 申し訳が 立たぬ。", RT(p)]); H.rm(); return false; }
        const eM2 = npcNear(p, "§5冥王 モルテ", PJ("morte", 15), true); act(eM2, "kneel");
        if (ok(eM2)) { camNear(p, eM2, 4.5, 1.0, 0.4); await wait(8); camNear(p, eM2, 1.9, 1.0, 1.3); await wait(26); }   /* 第125版(rs): 棺の そばに ひざを つく 冥王へ ゆっくり 寄る */
        await say(p, "冥王 モルテ", ["{closed}……無事に 送り出せた。礼を 言う。", "{sad,up}棺の 中は、石に なった 子どもだった。", "{closed,low}……母親が、白い 灯籠を 選んだ。わしは 止めなんだ。", "{sad}……石化は 年々 広がって おる。この 国の 墓は、もう 足りぬ。"]);
        cut(p); await hsay(p, V(["{?}……ねえ、冥王さま。石に なった 人って、ほんとに 死んでるの？"], ["{?}……冥王さま。石に なった 人は、本当に 亡くなって いるの？"], ["{?}石に なった 人は、死んでる？ 確かめた？"], ["{?}……冥王さま。石に なった 方は、本当に 亡くなって いるのでしょうか。"]));
        cut(p, "冥王"); re(eM2, "closed", "…");
        await say(p, "冥王 モルテ", ["{closed}……分からぬ。死者を 送るのが わしの 務めだが、石の 者だけは 送り方が 分からぬ。", "{sad,low}それでも 墓は 要る。……待つ 者が、待ち疲れて しまうからだ。"]);
        act(eM2, 0); await leave(eM2, p, 8, false);   /* 第124版: 棺の 方へ 歩いて もどる */
        await hsay(p, V(["{sad,…}……石に なった、子ども……。"], ["{sad}……子ども、だったのね。"], ["{closed}……子ども。"], ["{sad}……お子さん、だったのですね。"]));
        const eA = npcNear(p, "§5六影の 回し者", PJ("noxa", 9)); act(eA, "point");
        if (epD(d, "r7e3")) await hsay(p, V(["{shock,!}……葬列の 道で 見てた、黒い 外套の 人！"], ["{shock,!}……葬列の 道で こっちを 見てた、黒い 外套の 人だわ。"], ["{closed}……葬列の 道の、黒い 外套。"], ["{shock,!}……葬列の 道で 見て おられた、黒い 外套の 方です！"]));   /* 第125版 A36 */
        /* 第124版: 回し者は 六の座の 言いつけで 来た（参謀とは 別の 命令）。待ち合わせの 相手が 力ずくで 連れて いく、を なくす */
        await say(p, "回し者", ["{angry,low}……参謀さまは 霊廟の 奥だ。だが、六の座さまの お言いつけでな。『石板の 子を、参謀に 会わせるな』と。", "ここで 引き返して もらう。抵抗するなら、力ずくで。"]);
        await hsay(p, V(["{shock,…}……霊廟の 奥？ セオさんも、霊廟の 奥に いるって……", "{?}六の座……？ 参謀って、ヴァルカの 言ってた 人だよね。六影の 中で、命令が 二つ あるの？"], ["{shock,…}……霊廟の 奥？ セオさんも、霊廟の 奥だって……", "{?}……六の座？ 六影の 中で、命令が 二つ あるの？"], ["{shock,…}……霊廟の 奥。セオと 同じ 場所。", "{?}六の座。参謀とは 別の 命令。……六影は、一つに まとまって ない。"], ["{shock,…}……霊廟の 奥？ セオさんも、霊廟の 奥に おられると……", "{?}六の座……？ 六影の 中で、ご命令が 二つ あるのですか？"]));
        const r2 = await battle(p, team(["nether", "beast", "golem"], 56, 3, 18), { name: "六の座の 回し者", arena: "回し者", theme: "soulvalley", speaker: "回し者", lines: { half: "……聞いて いた より 強い", low: "六の座さま…… 申し訳……" } });
        rm(eA);
        if (r2 !== "win") { await sayAt(p, "§5六影の 回し者", PJ("noxa", 9), "回し者", ["……眠って いろ", RT(p)]); H.rm(); return false; }
        const eA2 = npcNear(p, "§5六影の 回し者", PJ("noxa", 9), true); act(eA2, "recoil");
        const bq = ok(eA2) ? eA2.location : fwd(p, 3);
        await say(p, "回し者", ["{sweat,汗}……くそっ！ 参謀の 書きつけを 写して、六の座さまへ 届ける ところ だったのに……！", "{angry,low}……葬列の 道の 抜け道で、一枚 なくしたのも 痛かったが な。"]);
        act(eA2, 0); await leave(eA2, p, 12, true);
        burst(p.dimension, bq, "minecraft:white_smoke_particle", 5, 0.4, 0.1); sound(p, "item.book.page_turn", 1);   /* 紙の 束が 落ちる */
        if (ok(H.e) && bq) { await go(H.e, bq, 10); act(H.e, "kneel"); await wait(6); act(H.e, "hold"); hold(H.e, "letter"); }
        await hsay(p, V(["{?}……紙の 束。表に『上への 報告の 写し』。……これ、セオさんの 研究メモと 同じ 字だ。", "{shock,!,up}『六本目の 鍵: 鍵を 持たず、モンスターと 絆を 結んだ 者。……あの 旅人と 相棒。石板を 読む たびに 記録 する。……レイも 試す』……！？"], ["{?}……紙の 束。表に『上への 報告の 写し』。……これ、セオさんの 研究メモと 同じ 字だわ。", "{shock,!,up}『六本目の 鍵: 鍵を 持たず、モンスターと 絆を 結んだ 者。……あの 旅人と 相棒。石板を 読む たびに 記録 する。……レイも 試す』……！？"], ["{?}……紙の 束。表に『上への 報告の 写し』。セオの メモと 同じ 字。", "{shock,!,up}『六本目の 鍵: 鍵を 持たず、モンスターと 絆を 結んだ 者。……あの 旅人と 相棒。石板を 読む たびに 記録 する。……レイも 試す』……。"], ["{?}……紙の 束です。表に『上への 報告の 写し』と。……セオさんの 研究メモと 同じ 字ですね。", "{shock,!,up}『六本目の 鍵: 鍵を 持たず、モンスターと 絆を 結んだ 者。……あの 旅人と 相棒。石板を 読む たびに 記録 する。……レイも 試す』……！？"]));
        act(H.e, "raise"); if (ok(H.e)) { camNear(p, H.e, 1.8, 1.9); flash(p, true); await wait(10); }   /* 最後の 頁を 光に かざす */
        await hsay(p, V(["{?,up}……最後の 頁、インクで 塗りつぶして ある。光に かざすと……", "{shock,!,up}『影は 知る 者に 宿る。……だから、話しては ならない』……？"], ["{?,up}……最後の 頁、インクで 塗りつぶして あるわ。光に かざすと……", "{shock,!,up}『影は 知る 者に 宿る。……だから、話しては ならない』……？"], ["{?,up}……最後の 頁は 塗りつぶし。光に かざす。", "{shock,!,up}『影は 知る 者に 宿る。……だから、話しては ならない』……。"], ["{?,up}……最後の 頁が、インクで 塗りつぶされて います。光に かざすと……", "{shock,!,up}『影は 知る 者に 宿る。……だから、話しては ならない』……？"]));
        act(H.e, "hold");
        await hsay(p, V(["{closed}……わたしの 手帳。荒野の 壁画の 台座、半分 削れてた 文字。", "{shock,!,jump}『影は 知る……に 宿る』……同じ 文句だ！ セオさん、続きを 知ってたんだ……！"], ["{closed}……わたしの 手帳。荒野の 壁画の 台座の 文字。", "{shock,…}『影は 知る……に 宿る』……同じ。セオさんは、続きを 知って いたのね。"], ["{closed}手帳の 写し。壁画の 台座。", "{shock,!}『影は 知る……に 宿る』。……一致する。セオは 続きを 知ってた。"], ["{closed}わたしの 手帳……荒野の 壁画の 台座の 文字です。", "{shock,!}『影は 知る……に 宿る』……同じです。セオさんは、続きを ご存じ だった……？"]));
        act(H.e, 0);
        if (hallUp(7)) {   /* 第124版: 葬列の 行き先（霊廟）を 冥王が 教える */
          const eM9 = npcNear(p, "§5冥王 モルテ", PJ("morte", 15));
          await say(p, "冥王 モルテ", ["{closed}……霊廟は 冥府の 谷の 大地の そば、紫の 灯の ともる 墓所だ。学者は その 奥の、冥王家の 墓所に おる。葬列と ともに 下りるが よい。"]);
          await bye(p, eM9);
        }
        const d1 = load(p); if (d1) { qs(d1).ch8a = 1; save(p, d1); } d = d1 || d;
      }
      /* 第124版: 冥府の 霊廟の 奥（冥王家の 墓所。棺の 列・大きな 棺・流されなかった 灯籠）へ 本当に 移る。ない 世界は 今までどおり（冥府の 大地。なければ 玉座の 間）*/
      const hq = await goHall(p, 7, "冥府の 霊廟の 奥"), v7 = hq ? caveInfo(7) : null;
      const cq7 = !hq && facAt("r7crypt") ? facFront("r7crypt", 3) : null;   /* 第125版(tp): 広間が ない 世界は ソウラの 霊廟（ep_r7 で 建てた）の 戸口の 前 */
      if (!hq) { const q = cq7 ? { x: Math.floor(cq7.x), y: Math.floor(cq7.y), z: Math.floor(cq7.z) } : placeOf("stage", 7, true) || placeOf("throne", 7, true); await sceneAt(p, q, cq7 ? "霊廟の 戸口" : "霊廟の 奥"); }
      big(p, "§5§l冥府の 霊廟", hq ? "§f棺の ならぶ 霊廟の 奥で、セオが 待っていた" : cq7 ? "§f霊廟の 戸口で、セオが 待っていた" : "§f霊廟の 奥で、セオが 待っていた", "mob.wither.spawn");
      const e = hq ? npcAt(p, "§7学者 セオ", TRAITOR_JOB, { x: v7.altar.x, y: v7.hall.y, z: v7.altar.z - 2 }) : npcNear(p, "§7学者 セオ", TRAITOR_JOB);   /* 第124版(dir#20): 名乗るまでは 学者の 名札。霊廟では 冥王家の 大きな 棺の 前 */
      { const S8 = stageOf(p); await arrive(e); if (S8) { camAt(p, S8.at(-7, 4.5 * S8.side, 5.5), S8.at(3, 0, 1), 0.8); await wait(30); } if (ok(e)) { camNear(p, e, 3.2, 1.4); await wait(10); } }   /* 第124版(fix2): 霊廟の 奥の 引きの 絵 → セオへ */
      H.e;
      try { if (ok(e)) { const l = e.location, P0 = p.location; e.teleport(l, { facingLocation: { x: 2 * l.x - P0.x, y: l.y + 1.5, z: 2 * l.z - P0.z } }); e.setDynamicProperty("mrpg:away", true); } } catch {}   /* 第125版(rs): セオは 背を 向けて 待って いる */
      if (ok(H.e)) { act(H.e, "hold"); hold(H.e, "letter"); camNear(p, H.e, 1.6, 1.2); await wait(14); }   /* 紙の 束と 研究メモを 見くらべる */
      await narr(p, "", ["§7手の 中の『報告の 写し』と、セオの 研究メモ。……筆の くせが、同じ だった。"]);
      act(H.e, 0); hold(H.e);
      if (ok(e)) { camNear(p, e, 5, 1.5, 0.4); await wait(10); camNear(p, e, 2, 1.5, 1.6); await wait(34); try { e.setDynamicProperty("mrpg:away", undefined); e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} await wait(10); }   /* 沈黙 → 背中へ ゆっくり 寄る → ふり向く */
      cut(p, "セオ");
      await say(p, "セオ", ["{closed,low}来て くれましたね。……もう、隠す 必要は ありません。"]);
      re(H.e, "shock", "!");   /* 第124版(fix2): 驚くのは 明かした あと */
      await sixMark(p, e, "theo");   /* 第125版: セオが 六影の 名乗りで 名乗り直す。第124版(dir#19): 台詞より 先に 札 */
      try { if (ok(e)) e.nameTag = "§5六影 参謀 セオ"; } catch {}
      await say(p, "セオ", ["{closed,up}……六影、二の座。参謀の セオです。", "{closed,up}ガロも、ヴァルカも、僕の 指示で 動いて いました。サンドリアの 密告も、僕です。", "{closed}王墓に 入るには 砂王の 許しが 要る。……君たちを まちがって 牢に 入れさせれば、王は おわびに 許しを 出す。そう 考えたんです。", "{closed,low}砂王は、法を 守って 人を 見なかった ことを、七年 悔いて いる 人だと……記録で 知って いました。", "{closed,low}ヴァルカの 言った、王墓へ 向かった『仲間』は、僕です。王墓の 主を 封じられるのは 君だけ。だから 地図と、王の 許しが 要った。"]);
      cut(p, "セオ");   /* 第125版 Q22 */
      await say(p, "セオ", ["{closed}下の 者への 命令は、年寄りの 字で 書きました。疑いが、オルドさんへ 向くように。……すみません。"]);
      if (ok(H.e)) { re(H.e, "shock", "!"); camNear(p, H.e, 1.5, 1.55); await wait(18); }   /* 第124版(fix2): 明かした 直後の リオの 反応 */
      await hsay(p, V(["{shock,…,up}……うそ。だって、森で 一緒に 戦って くれたのに……"], ["{shock,…}……うそ、でしょう？ 森で、一緒に……"], ["{shock,…}……あの メモの 消し跡。そういう ことか。"], ["{shock,…,up}そんな……森で、一緒に 戦って くださったのに……"]));
      await hsay(p, V(["{rage,怒,up}なんで！？ 何の ために そんな ことを したの！ ちゃんと 話して！"], ["{sad,up}……どうして？ 何の ために？ 話して、セオさん。"], ["{angry}目的は。全部 話して。"], ["{sad,up}なぜですか……！ 何の ために、こんな ことを！"]));
      cut(p, "セオ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
      await say(p, "セオ", ["{sad,…}……言えません。", "{closed,low}§e話せば、君に 影が 宿る§f。……それだけは、させない。"]);
      act(H.e, "hold");
      await hsay(p, V(["{shock,!}……水晶の 洞くつで 見た、石の 町。わたし、手帳に『学者の 家』って 書いた。", "{sad,up}……あの 町。セオさんの……"], ["{shock,!}……水晶の 洞くつで 見た、石の 町。わたし、手帳に『学者の 家』って 書いたの。", "{sad,up}……あの 町。セオさんの……"], ["{shock,!}……水晶で 見た 石の 町。手帳に『学者の 家』と 書いた。", "{sad,up}……あの 町、セオの……"], ["{shock,!}……水晶の 洞くつで 見た、石の 町。わたし、手帳に『学者の 家』と 記しました。", "{sad,up}……あの 町は、セオさんの……"]));
      act(H.e, 0);
      await say(p, "セオ", ["{closed}そうです。灰の 降った 冬の 夜、町は 一夜で 石に なりました。僕の 家族も。", "{sad}母は 家で。弟は……ほたるを 見に 行った 里の 小川で。"]);
      { const sx = qs(load(p) || d);   /* 第125版: 世界の 依頼「月光草の 花束」「返って こない 絵本」を 済ませた 人だけ */
        if (wl(sx, "wq1c")) { await hsay(p, V(["{shock,…}……ルミエの、石の 男の子。毎年 だれかが 花を 置いて いくって……"], ["{shock,…}……ルミエの 石の 男の子。毎年、だれかが 花を 置いて いくって……"], ["{shock,…}……ルミエの 石の 男の子。毎年 置かれる 花。"], ["{shock,…}……ルミエの、石の 男の子。毎年 どなたかが 花を 置いて いくと……"]));
          await say(p, "セオ", ["{closed,…}……近くには、行けないんです。", "{sad,low}顔を 見たら、もう 引き返せなく なるから。"]); }
        if (wl(sx, "wq1b")) { await hsay(p, V(["{sad}リーフィの 貸本屋さんが 言ってた。一度 読めば 忘れない 学者さんの こと。"], ["{sad}……リーフィの 貸本屋さんが、一度 読めば 忘れない 学者さんの お話を して いたわ。"], ["{closed}リーフィの 貸本屋。一度 読めば 忘れない 学者。"], ["{sad}リーフィの 貸本屋さんが、一度 読めば 忘れない 学者さんの ことを 話して おられました。"]));
          await say(p, "セオ", ["{sad,low}……忘れられないんです。読んだ ものも、見た ものも。", "{closed}……それで、知りすぎて しまう。"]); } }
      await say(p, "セオ", ["{closed}……だから、引けないんです。", "{up}一つ だけ 言える ことが あります。§e君と 相棒が 要る§f。"]);
      /* 後を 追って きた レイが 割って 入る */
      const eR = npcNear(p, "§bレイ", RIVAL_JOB); act(eR, "run", false); await wait(12); act(eR, 0);
      await say(p, "レイ", ["{angry,!}……聞いたぞ、セオ。二の座だと？ なら、おまえの 上に まだ 一人 いるのか。"]);   /* 第124版: 一の座の 気配（終章まで 明かさない）*/
      await say(p, "セオ", ["{closed,…}……それも、言えません。"]);
      await say(p, "レイ", ["{angry,!}なら これは 答えろ！ メモの 消し跡……『鍵』って、何の ことだ！"]);
      await say(p, "レイ", ["{angry,!}……それに、この かけら。おまえが くれた『お守り』だ。……最初から 知ってて 渡したのか。"]);   /* 第125版: 渡した 本人が 止める 矛盾を、試しが 狂った 場面に する */
      await say(p, "セオ", ["{closed,low}……知って いました。かけらに 耐えられる 器か、確かめる ために。", "{shock,!}でも……早すぎる。ここまで 呑まれるとは。……レイくん、今すぐ 手放して ください！ 僕の 見立てが 甘かった！"]);
      act(eR, "raise"); sound(p, "mob.wither.ambient", 1.2);
      if (ok(eR)) { camNear(p, eR, 1.4, 1.6); redGlow(eR); await wait(14); try { eR.nameTag = "§5影に 呑まれた レイ"; } catch {} }   /* 竜の 目が 赤黒く にごる */
      await say(p, "レイ", ["{angry,low}……っ、やめろ……かけらが 言うんだ。もっと 力を やる、選ばれる 側に して やるって。", "{rage}……今の オレは、選ばれる 側だ。……来いよ。", "{sad,up}……止めて、くれ。"]);
      act(eR, 0);
      await hsay(p, V(["{rage,怒,jump}レイの ばか！！ そんなので 勝って、村長が 喜ぶとでも 思うの！？"], ["{sad,!}レイくん、しっかり して！ 村長さんが 悲しむわ！"], ["{angry,!}レイ。止めて ほしいなら、止める。"], ["{rage,怒}レイさん！ 目を 覚まして ください！ 村長さまが 悲しまれます！"]));
      await duel(p, "§5§l暴走", "§fかけらの 毒気に あてられ、レイの 竜が 我を 忘れて 暴れだす！", { fams: ["dragon"] });
      const lv = 58;
      // v3.0: 星の かけらに 呑まれた レイと 戦う（セオは 見ている だけ。セオとの 戦いは 竜骨の 祭壇で）
      const res = qs(load(p) || d).theoBetray ? "win" : await battle(p, team(["dragon", "nether", "dragon"], lv, 4, 40, leadOf("dragon", lv)), { name: "影に 呑まれた レイ", arena: "裏切り", theme: "soulvalley", hpk: 3.2, extra: 0.35, tag: "ライバル", sboss: true, speaker: "レイ", lines: { half: "まだだ……かけらが もっと よこせって 言ってんだよ！", low: "なんで……なんで おまえばっかり……！" } });
      rm(e); rm(eR);
      const d2 = load(p); if (!d2) { H.rm(); return false; }
      if (res !== "win") { await sayAt(p, "§5六影 参謀 セオ", TRAITOR_JOB, "セオ", ["{sad}……かけらが 強すぎる。……一度 下がって ください。", RT(p)]); H.rm(); return false; }
      const s = qs(d2); if (!s.theoBetray) { s.theoBetray = true; save(p, d2); }   /* 第123版: 勝った ことを すぐ 保存（あとの 場面で 抜けても もう 戦わない） */
      const e3 = npcNear(p, "§5六影 参謀 セオ", TRAITOR_JOB, true), eR2 = npcNear(p, "§5影に 呑まれた レイ", RIVAL_JOB, true); try { if (ok(eR2)) eR2.nameTag = "§bレイ"; } catch {} act(eR2, "kneel");
      await say(p, "セオ", ["{closed}……かけらが 割れましたか。……レイくん、すみません。君を 試したのは、僕の 罪です。", "僕は §6ラグナ§f の 竜骨の 祭壇へ 行きます。そこで 儀式を 終わらせる。", "{up}……君と 相棒が 要る。来て ください。"]);
      re(H.e, "angry", "!"); await hsay(p, V(["{angry,!,up}待って！ 今すぐ 行く！"], ["{angry,!,up}待って……！ 今すぐ 行くわ！"], ["{angry,!}待て。今 行く。"], ["{angry,!,up}お待ち ください！ 今すぐ 参ります！"]));
      cut(p, "セオ"); await say(p, "セオ", ["{closed}……ラグナへの 道は、まだ 遠い。石板を 一つずつ 封じて いけば、いずれ 開きます。", "{sad,low}……そこで、待って います。"]);
      H.e; act(e3, 0); if (ok(e3) && ok(H.e)) { lookAt(p, e3); re(e3, "sad", "…"); await wait(10); }   /* 幼なじみの 目を 見られない */
      await wait(16); await say(p, "セオ", ["{sad,up}……ごめん。"]);   /* 第124版(fix2): 謝る 行は 下からの 絵に しない */
      if (hq && v7) { camPt(p, { x: v7.hall.x - 7, y: v7.hall.y, z: v7.hall.z + 1 }, 3, 0.4, 0); await wait(16); }   /* 池の ふちの、流されなかった 灯籠 */
      if (ok(e3)) { await memory(p, e3, "セオの 手帳の いちばん 後ろ", ["§7手帳の いちばん 後ろに、子どもの 描いた 小さな 絵が はさまって いる。§f二人の 兄弟と、一冊の 本§7。", "§7セオの 手には、葬列で 流す はずだった §f灯籠§7。弟の 名前が 書いて ある。", "§8……流されない まま、火だけが 消えて いた。"]);
        await say(p, "セオ", ["{sad,…}……弟です。石に なる ときの 顔を、僕は 一日も 忘れられない。", "{closed,low}一つだけ 忘れたい ことが あるのに、記録の 力は、それだけを 消して くれないんです。", "{sad,low}……弟の 名前は、書けるのに、声に 出せないんです。"]);
        act(e3, "up"); camNear(p, e3, 1.5, 1.5); await wait(10);   /* 第125版: すべてが つながる（ルミエの 石の 少年）*/
        await say(p, "セオ", ["{closed,up}……弟は、ほたるの 里に いる。……だから 僕は、あの 里の 小川の そばだけは 通れないんです。"]); act(e3, 0); }
      await leave(e3, p, 12, false);
      await narr(p, "霊廟の 奥", ["§7セオが 立って いた 床に、火の 消えた 白い 灯籠が 一つ、残されて いた。"]);
      await say(p, "レイ", ["{sad,…}……鍵……？ オレは、ただの 試し だったのか。", "{cry,tears,up}選ばれる 側に なれるって……あれは 全部、オレが 聞きたかった 言葉 だった だけだ。", "{closed}……おまえが 止めて くれた。今度は オレが セオを 止める。……じいちゃんにも、謝らないと。"]);
      cut(p); await hsay(p, V(["{sad}……村長、きっと 怒らないよ。レイが 帰って くるだけで、ほっほって 笑うよ。"], ["{sad}……村長さんは、きっと 怒らないわ。あなたが 無事なら、それで いいって。"], ["{closed}……村長は 怒らない。たぶん。"], ["{sad}……村長さまは、きっと お怒りに なりません。ご無事なら、それで よいと。"]));
      cut(p, "レイ");
      await say(p, "レイ", ["{sad,…}……知ってる。だから、きついんだ。", "{closed}怒って くれた ほうが、まだ 楽だった。"]);
      const g = palEnt(p); if (g && ok(eR2)) { const l = eR2.location; place(g, p, { x: l.x + 0.8, y: l.y, z: l.z + 0.6 }); camNear(p, g, 2.2, 0.8); await wait(10); }   /* 相棒が レイの 手に 鼻を 押しあてる */
      await pal(p, ["……レイ、ないてた。"]);
      await say(p, "レイ", [`{smile,…}……へへ。ありがとな、${palNm(p)}。`]);
      if (ok(g)) particle(g, "minecraft:villager_happy", 0.5); rmCine(g); act(eR2, 0); await leave(eR2, p, 10, false);   /* 第124版: レイは 一人で 歩いて いく（相棒は 足もとへ もどる）*/
      await hsay(p, V(["{sad}……レイ。", "{angry,up}ヨミさんの 石板から。……一つずつ 封じて、ラグナまで セオさんを 追いかける。", "§7→ ネクロスの 城で 地方マスター ヨミに 挑もう"], ["{sad}……レイくん。", "{closed}ヨミさんの 石板から 封じましょう。ラグナへの 道は、その 先よ。", "§7→ ネクロスの 城で 地方マスター ヨミに 挑もう"], ["{closed}……ヨミの 石板から。封じて、ラグナまで 追う。", "§7→ ネクロスの 城で 地方マスター ヨミに 挑もう"], ["{sad}……レイさん。", "{closed}ヨミさんの 石板から 封じて まいりましょう。ラグナへの 道は、その 先に あります。", "§7→ ネクロスの 城で 地方マスター ヨミに 挑もう"]));
      reward(p, d2, 20000, [["e_rainbow", 1], ["s_all3", 1], ["tms_undead", 1]]); save(p, d2);
      H.rm();
      return true;
    } },
  { r: 7, seal: 10, nospot: 1, hint: "§fネクロス冥府領の §6地方マスター ヨミ§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(10),
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).yomiStone) {   /* 第106版: ヨミが 石に なる。第122版: 封印の 揺れを 追って 来た ヨミが 割って 入る */
        big(p, "§5§l宵闇", "§7影が、こちらへ 伸びて くる", "mob.wither.ambient");
        { const far = fwd(p, 12, 4), nr = fwd(p, 3); if (far && nr) { camPt(p, far, 6, 1); await shadowFlow(p, far, nr, 22); } }
        const eY = npcAt(p, "§6宵闇の 地方マスター ヨミ", PJ("yomi", 8), fwd(p, 6, -2));
        if (ok(eY)) { const q = fwd(p, 2.2); if (q) await go(eY, q, 8, true); act(eY, "guard"); }
        boom(p.dimension, fwd(p, 3) || p.location); flash(p, false); shake(p, 0.6, 0.6);
        await say(p, "ヨミ", ["{angry,!,low}……下がって！ ラグナの 方で、だれかが 鍵を 動かした。封印の 揺れが、逆に 流れて くる……！", "{closed}石板の 守り手どうしは、石板ごしに 声が 届くの。森の 精霊から、あなたたちへ 伝言。", "{up}『印を 分けあう 二人、離れるな』"]);
        act(eY, "kneel"); await stoneFx(p, eY);   /* つま先から 灰色に */
        await narr(p, "宵闇", ["§7影が ヨミの 足に からみつき、足もとから 灰色の 石に 変わって いく――"]);   /* 第124版: 何が 起きたかを 地の文で */
        await hsay(p, V(["{shock,!,jump}ヨミさん、足が……！"], ["{shock,…}ヨミさん、足が……"], ["{shock,!}……ヨミ、足が。"], ["{shock,!,up}ヨミさん、お足が……！"]));
        const g = palEnt(p); if (g && ok(eY)) { const l = eY.location; place(g, p, { x: l.x + 0.7, y: l.y, z: l.z + 0.7 }); camNear(p, g, 2, 0.8); await wait(8); }
        act(eY, "hold");   /* 相棒の 額に 手を 当てる */
        await say(p, "ヨミ", ["{smile}……いい子。この 子を、手放しちゃ だめ。", "{closed,…}……影は、知る 者に……。……あの 学者を、ひとりに しないで……"]);
        await stoneFx(p, eY); try { setJob(eY, PJ("yomi_stone", 8)); eY.nameTag = "§7ヨミの 石像"; } catch {} act(eY, 0);
        if (ok(eY)) { camNear(p, eY, 2.2, 1.3); await wait(20); camNear(p, eY, 10, 4.5, 1.8); await wait(34); }   /* 第125版(rs): 石に なった ヨミから ゆっくり 引く */
        rmCine(g);
        act(H.e, "hold");   /* 相棒を 強く 抱く。泣かない */
        await hsay(p, V(["{sad,…,up}…………。", "{closed,up}……離れない。約束する。ヨミさんの 名前、手帳に 書く。"], ["{sad,…}…………。", "{closed}……離れないわ。ヨミさんの お名前、手帳に 書いて おくね。"], ["{sad,…}……。", "{closed}……離れない。手帳に、ヨミと 書いた。"], ["{sad,…}…………。", "{closed}……離れません。ヨミさんの お名前、手帳に 記します。"]));
        techo(p, "ヨミ");
        act(H.e, 0); rm(eY);
        const dy = load(p); if (dy) { qs(dy).yomiStone = 1; save(p, dy); }
      }
      await gateOpen(p, 8, null, null);
      const eR = npcNear(p, "§bレイ", RIVAL_JOB); act(eR, "run", false); await wait(12); act(eR, 0);
      cut(p, "レイ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
      await say(p, "レイ", ["{sad}……間に 合わなかったか。……石に された。でも、石の 人は まだ 生きてる。ヨミの こと、オレは 忘れない。", hqDown(qs(load(p) || d), 8) ? "{closed}冥府の 回し者を つかまえて 吐かせた。セオは ラグナへ 行く 前に、§9フロストヘイムの 雪山§f へ 寄る。『§e双子の 鍵§f を 迎えに』だと。" : "{closed}冥府の 回し者を つかまえて 吐かせた。セオは ラグナへ 行く 前に、§9フロストヘイムの 雪山§f の §e六影の 氷の 隠れ家§f へ 寄る。『§e双子の 鍵§f を 迎えに』だと。", "{up}……今度は、一緒に 行かせて くれ。"]);
      cut(p); await hsay(p, V(["{closed}……当たり前でしょ。今さら 何 言ってるの。", "{sad,up}ヨミさんの 伝言、聞いたよね。『離れるな』って。……レイも、だよ。"], ["{smile}……もちろんよ。", "{sad}ヨミさんも 言ってたわ。『離れるな』って。……レイくんも、一緒よ。"], ["{closed}……勝手に しろ。……ヨミが 言ってた。『離れるな』。", "{closed}レイも 数に 入れとく。"], ["{smile}……もちろんです。", "{sad}ヨミさんも『離れるな』と おっしゃいました。……レイさんも、ごいっしょに。"]));
      cut(p, "レイ"); re(eR, "closed");
      await say(p, "レイ", ["{closed}……ああ。雪山は 冷える。竜の 翼の 下に 入れて やるよ。"]);
      rm(eR); H.rm(); return true;
    } },
  /* 第124版: 六影の 氷の 隠れ家（洞くつの 広間）で 演じる。双子は セオに かくまわれて いる。3分 できない 世界は 今までどおり 大地で（alt）*/
  { r: 8, hq: 8, ch: "第9章 雪山の 双子", at: "hall", hint: "§fフロストヘイム雪山の §e六影の 氷の 隠れ家§f へ 行こう §7（白銀の 雪原の そば、紫の 灯の 氷の 門。部屋を 下りきった 大広間。レイと 共闘）", trig: (c) => c.r === 8,
    alt: { at: "land0", hint: "§fフロストヘイム雪山の §e大地（ステージ）§f へ 行こう §7（レイと 共闘。右上の 案内）" },
    run: async (p, d) => { iceFix(p); try { return await (async () => {   /* 氷の 池は、勝っても 負けても 抜けても 必ず もどす（finally）*/
      const H = heroBox(p, true), inH = hallHere(p, 8), v8 = inH ? caveInfo(8) : null, met8 = epD(d, "r8e3");
      if (!qs(d).ch9a) {   /* 第106版: 雪崩の 中の 六影。第122版: かけらを 捨てた レイ */
        const eR0 = npcNear(p, "§bレイ", RIVAL_JOB);
        await say(p, "レイ", ["{closed}……割れた かけらの 残り、氷の 割れ目に 捨てて きた。", "{blush,汗}じいちゃんには、オレの 口から 言う。……先に 言うなよ。今度は 一緒に 行く。"]);
        if (ok(H.e) && ok(eR0)) { const l = eR0.location; await go(H.e, { x: l.x + 0.8, y: l.y, z: l.z + 0.8 }, 8); act(H.e, "raise"); sound(p, "random.pop", 1.2); act(eR0, "recoil"); }   /* 背中を ばしんと たたく */
        await hsay(p, V(["{smile,♪,jump}じゃあ、帰ったら 一番に 聞かせてね！"], ["{smile}じゃあ、帰ったら 一番に 聞かせてね。"], ["{smile,…}……なら、帰ったら 一番に。横で 聞いてる。"], ["{smile}では、帰ったら 一番に お聞かせ くださいね！"]));
        await say(p, "レイ", ["{sweat,汗}……いてて。", "{closed}……いいか。冥府で おまえが 拾った 紙に『六本目の 鍵』って あったろ。……回し者が 吐いた。双子は『二人で 一つの 鍵』だ。", "{closed}あの 二人を 止めれば、セオの 儀式は 止まる。"]);   /* 第124版: 何を しに 来たか */
        act(H.e, 0); act(eR0, 0);
        if (inH) {   /* 第124版: 隠れ家の 中（見張りとの 戦いは 切った。里の 話の 焼き直しに なる）。寝床が 二つと、絵本 */
          big(p, "§f§l六影の 氷の 隠れ家", "§7氷の 広間に、たき火と、小さな 寝床が 二つ――", "random.orb");
          { const S9 = stageOf(p); if (S9) { camAt(p, S9.at(-7, 4.5 * S9.side, 5.5), { x: v8.altar.x, y: v8.altar.y + 0.6, z: v8.altar.z }, 0.8); await wait(26); } }
          camAt(p, { x: v8.altar.x + 3, y: v8.altar.y + 2.2, z: v8.altar.z - 4 }, { x: v8.altar.x, y: v8.altar.y, z: v8.altar.z }, 0); await wait(18);   /* 青と 桃色の 寝床 */
          act(H.e, "point");
          await hsay(p, epD(d, "r1e2") ? V(["{sad}……机の 上に 絵本。竜が 星を さがす お話。……セオさんが ピピちゃんに 読んでた のと、同じ。"], ["{sad}……机の 上に、絵本。……セオさんが ピピちゃんに 読んで いた のと、同じ 本ね。"], ["{closed}……絵本。竜が 星を さがす 話。セオが ピピに 読んでた 本と 同じ。"], ["{sad}……机の 上に 絵本が。……セオさんが ピピさんに 読んで いらした のと、同じ ご本です。"]) : V(["{sad}……机の 上に 絵本。竜が 星を さがす お話。……だれかが ここで、読んで あげてたんだ。"], ["{sad}……机の 上に、絵本。……だれかが ここで、読んで あげて いたのね。"], ["{closed}……絵本。竜が 星を さがす 話。だれかが ここで 読んで やってた。"], ["{sad}……机の 上に 絵本が。……どなたかが ここで、読んで あげて いたのですね。"]));
          act(H.e, 0); cut(p, "レイ");
          await say(p, "レイ", ["{closed,low}……寝床が 二つ。たき火は まだ あたたかい。……いるぞ。"]);
          const d1 = load(p); if (d1) { qs(d1).ch9a = 1; save(p, d1); } d = d1 || d;
        } else {
        sound(p, "random.explode", 0.6); shake(p, 0.9, 1.4);
        big(p, "§f§l雪崩", "§7山が 鳴った――", "random.explode");
        { const q = fwd(p, 14, 0, 6); if (q) { camPt(p, q, 8, 1); for (let k = 0; k < 6; k++) { burst(p.dimension, fwd(p, 14 - k * 2, 0, 6 - k), "minecraft:white_smoke_particle", 12, 2.5, 0); await wait(3); } } }
        act(H.e, "guard"); act(eR0, "guard");
        await hsay(p, V(["{shock,!,jump}雪の 中から 六影が 突っこんで くる！"], ["{shock,!}雪の 中から 六影が 来るわ！"], ["{angry,!}雪の 中から 六影。来る。"], ["{shock,!,up}雪の 中から 六影が 突っこんで きます！"]));
        const r = await battle(p, team(["beast", "aqua", "golem"], 62, 3, 22), { name: "雪崩の 中の 六影", arena: "雪崩", theme: "snow", speaker: "六影", guests: team(["dragon"], 60, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "前が 見えない……！", low: "……退け！ 雪に 呑まれるぞ！" } });
        rm(eR0);
        if (r !== "win") { await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["雪が ひどすぎる！ いったん 戻ろう！"]); H.rm(); return false; }
        const d1 = load(p); if (d1) { qs(d1).ch9a = 1; save(p, d1); } d = d1 || d;
        }
      }
      const fin9 = !!(qs(d).ch9c || qs(d).rouDead);   /* 第106版: 双子に 勝った あとの やり直しでは 双子を 出さない */
      /* 第125版(rs): 双子は 寝床の そばに もう いる（引きの 絵に 映る）→ 手を つないだ まま 歩いて 来る。ほしい もの: 引きはなされない こと／あなた: セオを 止め、二人に 帰る 場所を 伝える */
      const BED = inH && v8 ? { x: v8.altar.x, y: v8.altar.y, z: v8.altar.z } : fwd(p, 10, 0);
      const e = fin9 ? null : await putAt(p, "§9双子の 幹部 ロウ", PJ("rou", 10), BED && { x: BED.x - 0.7, y: BED.y, z: BED.z }), eU = fin9 ? null : await putAt(p, "§d双子の 幹部 ルウ", PJ("ruu", 10), BED && { x: BED.x + 0.7, y: BED.y, z: BED.z });
      if (!fin9) {
        act(e, "hold"); act(eU, "hold");
        if (BED) { camPt(p, BED, 6, 1.4, 0); await wait(18); }   /* 寝床の 前に 立って いる 二人 */
        await Promise.all([go(e, fwd(p, 5, -0.6), 22), go(eU, fwd(p, 5, 0.6), 22)]);   /* 手を つないだ まま 前へ */
        if ((qs(load(p) || d).epx || {}).six5) await narr(p, "", ["§8……雪あかりの 窓べで、手を つないで いた 二つの 影。"]);   /* 第125版(rs): 第5章の「そのころ」の 答え */
        await sixMark(p, e, "twins");
        if (met8) await hsay(p, V(["{shock,!}……祠で『止まって』って 言って くれた 声！"], ["{shock,!}……祠で、止めて くれた 声ね。"], ["{shock,!}……祠の、止めた 声。"], ["{shock,!}……祠で 止めて くださった お声です！"]));
        cut(p, "ロウ");
        await say(p, "ロウ", [met8 ? "{closed}ボクは ロウ。……祠の 雪庇の こと、教えたのは ボクだよ。" : "{closed}ボクは ロウ。", "{closed}村を 出た 夜、雪の 中で 拾われて、施設に 入れられた。", "{sad}施設の 大人たちは、ボクたちを 別々の 家に やろうと した。セオさまだけが、二人 一緒に 引き取って くれた。"]);
        await say(p, "ロウ", [inH ? "{closed,up}ここは 六影の 隠れ家。セオさまは『儀式の 日に 迎えに 来る。それまで だれも 上げるな』って 言った。" : "{closed,up}セオさまは『儀式の 日に 迎えに 来る。それまで だれも 上げるな』って 言った。", "{closed}だから、あなたたちを セオさまの 所へは 行かせないよ。"]);
        cut(p, "ルウ");
        await say(p, "ルウ", [met8 ? "{angry}ボクは ルウ。……祠で『帰って』って 言ったのも ボクだもん。" : "{angry}ボクは ルウ。", "{angry,up}ロウと 離される くらいなら、ここで 氷に なった ほうが ましだもん。"]);
        await say(p, "ロウ", ["{closed}ボクたちは、二人で 一つの §e鍵§f。片方 だけじゃ、何も 開かない。"]);
        cut(p); await hsay(p, V(["{sad}……セオさんが 二人を 守って くれたのは、分かった。", "{?}でも セオさん、今 一人で 危ない ことを しようと してる。止めたいの。……二人も、手伝って くれない？"], ["{sad}……セオさんが、二人を 守って くれたのね。", "{?}でも、セオさんは 今 ひとりで 危ない ことを しようと して いるの。一緒に 止めて くれない？"], ["{closed}セオが 二人を 守ったのは 分かった。", "{?}でも セオは 今、一人で 危ない 橋を 渡ってる。止めたい。手を 貸して。"], ["{sad}……セオさんが お二人を 守って いらしたのは、分かりました。", "{?}ですが セオさんは 今、おひとりで 危ない ことを なさろうと して います。一緒に 止めて いただけませんか。"]));
        if (ok(e)) { camNear(p, e, 1.4, 1.5); await wait(6); } re(e, "closed", "…");
        await say(p, "ロウ", ["{closed,up}……知ってるよ。セオさま、夜 ずっと 起きてる。", "{sad,up}でも、ボクたちには セオさましか いないんだよ。"]);
        cut(p, "ルウ"); re(eU, "angry");
        await say(p, "ルウ", ["{angry,up}こ、こわくなんか ないもん。……帰る 場所が ある 人に、ボクたちの ことは 分からないもん。"]);
        { const eRw = npcNear(p, "§bレイ", RIVAL_JOB, true); await say(p, "レイ", ["{angry}オレは もう かけらには 頼らない。セオを 止めるって 決めたんだ。……行こう。"]); act(eRw, "guard"); }   /* 第125版: レイは その場に 残る */
      }
      if (!qs(d).ch9b && !fin9) {
        /* 第125版(rs): なぞかけを やめ、手袋の 一拍（二人が 何を こわがって いるか）*/
        if (ok(eU)) { camNear(p, eU, 1.6, 1.0, 0.5); await wait(12); }
        await narr(p, "", ["§7白い 手袋と 黒い 手袋。片っぽずつ はめて、あいた 手を ぎゅっと つないで いる。"]);
        await hsay(p, epD(d, "r8e1") ? V(["{sad,up}……その 手袋。サンダの シロウさんが 話してた、おかあさんの 編み目……。"], ["{sad,up}……その 手袋。サンダで シロウさんが 話して いた 編み目ね。"], ["{closed,up}……その 手袋。サンダの、シロウの 母親の 編み目。"], ["{sad,up}……その 手袋。サンダで シロウさんが お話し して いた 編み目です。"]) : V(["{sad,up}……その 手袋、片っぽずつ なんだね。"], ["{sad,up}……手袋、片っぽずつ なのね。"], ["{closed,up}……手袋、片っぽずつ。"], ["{sad,up}……手袋を、片方ずつ なのですね。"]));
        act(eU, "guard");
        await say(p, "ルウ", ["{angry,up}サンダの ことは 言わないで！ ……あの 里は、ボクたちを 二つに 分けようと したんだもん。"]);
        act(eU, 0); cut(p, "ロウ");
        await say(p, "ロウ", ["{sad}……ルウ。だいじょうぶ。手は、はなさないよ。"]);
        const d1 = load(p); if (d1) { qs(d1).ch9b = 1; save(p, d1); } d = d1 || d;
      }
      const done9 = !!(qs(load(p) || d).ch9c || qs(load(p) || d).rouDead);   /* 第106版: 勝った あとに 抜けても もう 戦わない */
      if (!done9) await duel(p, "§9§l双子", inH ? "§f氷の 広間で 二体が 同時に 動く！" : "§f雪崩の 中で 二体が 同時に 動く！", { fams: ["beast", "aqua"] });   /* 第124版: 名乗りの 札は 同じ 場面で 2回 出さない */
      const lv = 66;
      const res = done9 ? "win" : await battle(p, team(["beast", "aqua", "dragon"], lv, 4, 64), { name: sixName("twins"), arena: inH ? "氷の 広間" : "双子の 幹部", theme: "icepeak", hpk: 5, extra: 0.4, tag: "四・五の座", sboss: true, speaker: "ロウ＆ルウ", guests: team(["dragon", "animal"], lv, 2, 20).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "ルウ、そこは 氷が 厚いよ！ ――うん、ロウ！", low: "そんな……ボクたちの 連携が……！" } });
      const d2 = load(p); if (!d2) { rm(e); rm(eU); H.rm(); return false; }
      if (res !== "win") { rm(e); rm(eU); await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["すまない、今のは オレの せいだ。……もう一度 行こう。"]); H.rm(); return false; }
      if (!qs(d2).ch9c) { qs(d2).ch9c = 1; save(p, d2); }
      rm(e); rm(eU);
      /* 第113版: ロウは 氷の 下に 落ち、仮面の 戦士に 引き上げられて 双子ごと 連れ去られる（印 rouDead は「この 場面を 見た」の 意味の まま）。第122版: 目の 前で 起きる */
      if (!qs(d2).rouDead) {
        const eR = npcNear(p, "§bレイ", RIVAL_JOB, true);
        const eO = await putAt(p, "§9双子の 幹部 ロウ", PJ("rou", 10), fwd(p, 5, -0.6)), eL = await putAt(p, "§d双子の 幹部 ルウ", PJ("ruu", 10), fwd(p, 5, 0.6));   /* 第125版(rs): 戦いの あとも 同じ 所に（暗転の 中で）*/
        act(eO, "kneel"); act(eL, "kneel");
        const IP = v8 && v8.pool ? null : (() => { const S9 = stageOf(p), a = facAt("r8pond", p.location, 60) || (S9 ? facBuild(p, S9, "r8pond", "icepond", 8, Math.floor(S9.P.y)) : null); return a && facMark("r8pond", "ice", p.location); })();   /* 第125版(tp): 広間で ない ときは 雪の 上に 薄い 氷の 池を 建てる */
        const ice = (v8 && v8.pool) || IP || fwd(p, 8, -2);   /* 第124版: 広間の 西の、薄い 氷の 池 */
        if (IP) { camPt(p, IP, 6, 0.4); await wait(10); }
        await say(p, "ルウ", ["{cry,!,up}……やだ。セオさまの ところへ 行く！ ロウ、逃げよう！"]);
        act(eL, 0); if (ok(eL) && ice) { const l = eL.location, n = Math.hypot(ice.x - l.x, ice.z - l.z) || 1; go(eL, { x: ice.x - ((ice.x - l.x) / n) * 1.6, y: l.y, z: ice.z - ((ice.z - l.z) / n) * 1.6 }, 12, true); }   /* 第125版(rs): 池の 方へ かけだす */
        cut(p, "ロウ");
        await say(p, "ロウ", ["{shock,!,up}ルウ、そっちは だめ！ 氷が 薄い！"]);
        act(eO, 0); if (ok(eO) && ice) await go(eO, ice, 12, true);   /* ルウを 追いこして 前に 出る */
        if (ok(eL) && ok(eO)) { act(eO, "give", false); const l = eL.location, o = eO.location; go(eL, { x: l.x + (l.x - o.x) * 1.4, y: l.y, z: l.z + (l.z - o.z) * 1.4 }, 6); }   /* ルウを 岸へ 押しもどす */
        if (IP) facState("r8pond", 1);   /* 第125版(tp): 池の まん中の 氷が 割れる */
        const broke = !!(((v8 && v8.pool && iceBreak(p, 8)) || IP) && (() => { try { const b = p.dimension.getBlock({ x: Math.floor(ice.x), y: Math.floor(ice.y) - 1, z: Math.floor(ice.z) }); return !!(b && (b.isAir || b.isLiquid)); } catch { return false; } })());   /* 本当に 割る（ほかの 人が 広間に いる ときは 割らない）。場面の 終わりに 必ず もどす。第124版: 割れたのを 確かめてから 沈める（割れて いない 氷の 中へ 沈めない）*/
        sound(p, "random.glass", 1.2); shake(p, 0.4, 0.4); burst(p.dimension, ice, "minecraft:white_smoke_particle", 10, 1, 0.1);
        big(p, "§b§l氷が 割れる", "§fロウの 足もとが 割れて、黒い 水が 口を あけた", "random.glass");
        if (ok(eO)) { const l = eO.location; if (broke) try { eO.teleport({ x: l.x, y: l.y - 2.2, z: l.z }); } catch {} else burst(p.dimension, l, "minecraft:white_smoke_particle", 12, 0.6, 0.2); await wait(6); if (ok(eO)) { smokeOut(eO, 3); await wait(4); } } rm(eO);   /* 第124版(cam): 水の 下・煙の 中で 消える */   /* 白い 水が、ロウを 飲みこんで 閉じた */
        qs(d2).rouDead = 1; save(p, d2);
        if (ok(H.e)) { const q = (v8 && v8.pool) || IP ? { x: ice.x + 2.6, y: ice.y, z: ice.z - 0.8 } : fwd(p, 6, -1.5); if (q) await go(H.e, q, 8, true); }   /* 割れた 氷に 飛びつこうと する */
        if (ok(eR) && ok(H.e)) { const l = H.e.location; await go(eR, { x: l.x - 0.6, y: l.y, z: l.z - 0.6 }, 6, true); act(eR, "hold"); act(H.e, "recoil"); }
        await say(p, "レイ", ["{angry,!,up}ばか、おまえまで 落ちるぞ！"]);
        act(H.e, 0); act(eR, 0);
        await say(p, "ルウ", ["{shock,…}……ロウ？", "{cry,tears,up}ボクが『逃げよう』なんて 言ったから……ロウが、ボクを 押して……"]);
        { const h = heroFind(p); if (ok(h)) { camNear(p, h, 1.7, 1.4, 0.5); await wait(10); } }   /* 聞いて いる 仲間の 顔 */
        await say(p, "ルウ", ["{sad,up}……セオさまは、やさしい 人なんだ。でも、読んだ ものを 何でも 覚えて しまうの。", "{sad}……知りすぎたら、セオさまが 危ない。"]);
        /* 仮面の 戦士（必ず 負ける・十魔将の 予告） */
        const eX = await putAt(p, "§4仮面の 戦士", PJ("argo", 10), ice ? { x: ice.x + (v8 ? 2.4 : 1.2), y: ice.y, z: ice.z + (v8 ? 0.8 : 0) } : fwd(p, 8)); await drop(p, eX, v8 ? 5 : 6);   /* 第125版(rs): 暗転の 中で 岩棚の 上から 飛び降りる（歩いて 来て から 浮かない）*/
        if ((qs(load(p) || d).epx || {}).six5) await narr(p, "", ["§8……卓の 影の 中に いた、白い 仮面。"]);
        await sixMark(p, eX, "argo");   /* 第125版: 吹雪の 向こうから、白い 仮面の 戦士 */
        act(eX, "kneel"); if (ok(eX)) { camNear(p, eX, 2.6, 0.6); burst(p.dimension, ice, "minecraft:white_smoke_particle", 8, 0.6, 0.1); await wait(14); }   /* 割れた 氷に 腕を 差し入れる */
        const eO2 = await putAt(p, "§9ロウ", PJ("rou", 10), v8 && ice ? { x: ice.x + 2.4, y: ice.y, z: ice.z + 2 } : ice); act(eO2, "down"); act(eX, "hold");   /* 第125版(rs): 引き上げた ロウは 歩いて 来ない（暗転の 中で 寝かせる）*/   /* 広間では 池の ふちの 床に 寝かせる */
        await hsay(p, V(["{shock,!,up}あの 仮面の 人、ロウを 引き上げた……！", "{sad,?}……息は してる。でも、目を 開けない……。"], ["{shock,!,up}あの 仮面の 人、ロウを 引き上げたわ……！", "{sad,?}……息は してる。でも、目を 開けないの……。"], ["{shock,!}仮面の やつ、ロウを 引き上げた。", "{sad}……息は ある。目は 開かない。"], ["{shock,!,up}あの 仮面の 方、ロウさんを 引き上げました……！", "{sad,?}……息は あります。でも、目を 開けません……。"]));
        if (ok(eL) && ok(eX)) { const l = eX.location; await go(eL, { x: l.x - 0.7, y: l.y, z: l.z }, 8, true); act(eL, "hold"); }   /* 外套に しがみつく */
        await say(p, "ルウ", ["{cry,tears,up}……返して。ロウを、返して。"]);
        /* 第124版: 双子を 迎えに 来た セオと、預かると 言う アルゴ（六影の 中の 対立）。広間では セオは 入口の 暗がりから */
        { const eT = npcAt(p, "§5六影 参謀 セオ", TRAITOR_JOB, v8 ? { x: v8.entry.x, y: v8.entry.y, z: v8.entry.z + 1.5 } : fwd(p, 11, 4)); if (ok(eT) && ok(eX)) { camNear(p, eX, 2.4, 1.6); await wait(12); camNear(p, eT, 3.5, 1.4); await wait(16); }   /* 第125版: 仮面の 戦士が セオを じっと 見る */
          await hsay(p, v8 ? V(["{shock,!}……入口の 暗がりに、セオさん……！？"], ["{shock,!}……入口の 暗がりに、セオさん……？"], ["{shock,!}……入口の 暗がり。セオ……？"], ["{shock,!}……入口の 暗がりに、セオさんが……！？"]) : V(["{shock,!}……吹雪の 向こう、セオさん……！？"], ["{shock,!}……吹雪の 向こう、セオさん……？"], ["{shock,!}……吹雪の 向こう。セオ……？"], ["{shock,!}……吹雪の 向こうに、セオさん……！？"]));
          await say(p, "セオ", ["{shock,!,up}ロウ！！"]);
          await say(p, "仮面の 戦士", ["{angry,low}……来るな、参謀。おまえが 近づく ほど、この 子らは 知る。"]);
          await say(p, "セオ", ["{sad}……六の座。その 子たちを、返して ください。迎えに 来たんです。"]);
          await say(p, "仮面の 戦士", ["{closed,low}『否』。儀式の 日まで、我が 預かる。……知りすぎるな。"]);
          if (ok(eT)) re(eT, "sad", "…"); }
        await hsay(p, V(["{angry,!,up}待って！ ロウを どこへ 連れて いくの！"], ["{sad,!}待って……！ ロウくんを、どこへ 連れて いくの？"], ["{angry,!}待て。ロウを どこへ 連れて いく。"], ["{angry,!,up}お待ち ください！ ロウさんを どこへ 連れて いくのですか！"]));
        await say(p, "仮面の 戦士", ["{angry,low}……追うなら、斬る。"]);
        act(H.e, "guard");
        await battle(p, team(["sword", "nether", "dragon"], 90, 3, 60), { name: sixName("argo"), arena: "？？？", theme: "icepeak", hpk: 30, extra: 0.6, tag: "仮面の 戦士", heal: false, asked: true,
          scripted: { turns: 2, lines: ["§4§l仮面の 戦士の 一閃！", "§7……何が 起きたのか 見えなかった"] }, lines: { half: "『否』" } });
        flash(p, true); await wait(2); rm(eX); rm(eO2); rm(eL); rm(eR); rmName(p, "§4仮面の 戦士", "§9ロウ", "§d双子の 幹部 ルウ");   /* 第124版(cam): 光の 中で 下げる */
        shake(p, 0.5, 0.4);
        big(p, "§8……", "§7気が つくと、戦士も 双子も いなかった", "random.orb");
        { const eT2 = npcNear(p, "§5六影 参謀 セオ", TRAITOR_JOB, true); if (ok(eT2)) { await wait(14); camNear(p, eT2, 3.2, 1.4); re(eT2, "sad", "…"); await wait(14); }   /* 第124版: セオは 何も できずに 去る */
          await narr(p, v8 ? "氷の 隠れ家" : "雪山", [v8 ? "§7入口の 暗がりで、セオが こちらを 見て……目を そらして、消えた。" : "§7吹雪の 向こうで、セオが こちらを 見て……目を そらして、消えた。"]);
          if (ok(eT2)) await leave(eT2, p, 10, false); }
        const cq = fwd(p, 4); burst(p.dimension, cq, "minecraft:white_smoke_particle", 4, 0.3, 0.1);   /* 雪の 上に 札が 一枚 */
        { const dg = load(p); if (dg) { qs(dg).glove = 1; save(p, dg); } }   /* 第125版: 双子の 手袋が 片方だけ 落ちて いた（終章で 返す）*/
        const eR3 = npcNear(p, "§bレイ", RIVAL_JOB, true);
        if (ok(H.e) && cq) { await go(H.e, cq, 10); act(H.e, "kneel"); await wait(6); act(H.e, "hold"); hold(H.e, "letter"); }
        await hsay(p, V(["{?}……札が 一枚。『双子は 預かる。§5六影§f 六の座』", "{shock,!,up}六の座……。セオさんは 二の座 なのに。", "{sad,…}……やっぱり、六影は 一つじゃ ない。"], ["{?}……札が 一枚。『双子は 預かる。§5六影§f 六の座』", "{shock,!,up}六の座……。セオさんは 二の座 なのに。", "{sad,…}……やっぱり、六影は 一つじゃ ないのね。"], ["{?}……札。『双子は 預かる。§5六影§f 六の座』", "{shock,!,up}六の座。セオは 二の座。", "{closed}……やっぱり、六影は 一つじゃ ない。"], ["{?}……札が 一枚 あります。『双子は 預かる。§5六影§f 六の座』", "{shock,!,up}六の座……。セオさんは 二の座 ですのに。", "{sad,…}……やはり、六影は 一つでは ないのですね。"]));
        hold(H.e, "glove"); act(H.e, "show", false);
        await hsay(p, V(["{sad}……それと、手袋が 片方だけ。……双子の、右手の ほう。", "{closed}あずかって おく。いつか、返すんだから。"], ["{sad}……それと、手袋が 片方だけ。……双子の、右手の ほうね。", "{closed}あずかって おくわ。いつか、返すの。"], ["{sad}……手袋が 片方。双子の 右手。", "{closed}預かる。いつか 返す。"], ["{sad}……それと、手袋が 片方だけ。……双子の、右手の ほうです。", "{closed}お預かり して おきます。いつか、お返し しますから。"]));
        await keyHand(p, "k_glove");   /* 第125版: だいじなもの（データだけ）*/
        act(H.e, "sad"); cut(p, "レイ");
        await say(p, "レイ", ["{closed}……手、ふるえてるぞ。"]);
        await hsay(p, V(["{angry,汗}……寒い だけ。"], ["{sad,汗}……寒い だけよ。"], ["{angry,汗}……寒い だけ。"], ["{sweat,汗}……寒い だけです。"]));
        await say(p, "レイ", ["{closed}……鍵ごと 持って いかれた。もう 祭壇で 止める しか ない。"]);   /* 第124版: 章の 結果を 一文で */
        cut(p); await hsay(p, V(["{sad}……ルウの『返して』が、まだ 耳に 残ってる。", "{angry,up}ラグナで ぜんぶ 取りかえす。ロウも、ルウも、セオさんも。その 前に、この 地方の 石板だね。"], ["{sad}……ルウくんの『返して』が、まだ 耳に 残ってるの。", "{closed,up}ラグナで、みんなを 取りもどしましょう。まずは この 地方の 石板ね。"], ["{closed}……ルウの『返して』が 耳に 残ってる。", "{angry}ラグナで 全部 取り返す。先に この 地方の 石板。"], ["{sad}……ルウさんの『返して』が、まだ 耳に 残って います。", "{closed,up}ラグナで、皆さんを 取りもどしましょう。まずは この 地方の 石板です。"]));
        act(H.e, 0); rm(eR3);
      }
      { const d9 = load(p) || d2; reward(p, d9, 26000, [["e_king", 1], ["SEED3", 2], ["i_awaken", 1], ["tms_insect", 1]]); save(p, d9); }
      H.rm();
      return true;
    })(); } finally { iceFix(p); } } },
  { r: 8, seal: 12, nospot: 1, hint: "§fフロストヘイムの §6地方マスター シデン§f に 勝とう §7（勝つと 石板が もらえる。負けても また 挑める）", trig: (c) => c.s.bs.includes(12),
    run: async (p, d) => {
      await gateOpen(p, 9, null, null);
      /* 第122版: その 夜、オルドの 手紙が 届く */
      const H = heroBox(p, true), eR = npcNear(p, "§bレイ", RIVAL_JOB);
      sound(p, "mob.parrot.fly", 1); burst(p.dimension, fwd(p, 2, 0, 1.5), "minecraft:white_smoke_particle", 5, 0.4, 0.5);
      act(H.e, "hold"); hold(H.e, "letter");
      await hsay(p, V(["{!,jump}あ、手紙！ ……村長の 字だ。読むね。"], ["{!}あら、お手紙。……村長さんの 字ね。読むわ。"], ["{closed}手紙。村長の 字。読む。"], ["{!}あ、お手紙です。……村長さまの 字ですね。読みます。"]));
      await say(p, "オルド", ["（手紙）ラグナへの 道が 開いた。セオという 若者は、知りすぎて おる。知りすぎた 者には、影が 寄る。……わしは、それを 一度 見た。", "……わしも 行く。二十年前の しくじりを、今度こそ 終わらせる。"]);
      re(H.e, "closed", "…"); await wait(16); re(H.e, "shock", "?");   /* 三回 読みなおす */
      await hsay(p, V(["{?,up}……『わしも 行く』って、どういう こと？", "{sweat,汗}あの人、牧場の 坂で 息切れ してたよね？"], ["{?,up}……『わしも 行く』って、どういう ことかしら？", "{sweat,汗}村長さん、牧場の 坂で 息切れ してたわよね？"], ["{?,up}……『わしも 行く』？", "{sweat,汗}牧場の 坂で 息切れ してたのに。"], ["{?,up}……『わしも 行く』とは、どういう ことでしょう？", "{sweat,汗}村長さま、牧場の 坂で 息切れ されて いましたよね？"]));
      re(eR, "closed", "…"); if (ok(eR)) { camNear(p, eR, 1.6, 1.6); await wait(16); }   /* レイは、笑わなかった */
      await say(p, "レイ", ["{closed}……じいちゃんが 自分の ことを『しくじり』って 書いたのは、初めて 見た。", "{angry,low}二十年前に 何が あったのか。……ラグナで、本人の 口から 聞く。"]);
      cut(p); await hsay(p, V(["{sad}……うん。村長が 来るなら、なおさら 急がなきゃ。"], ["{sad}……ええ。村長さんが 来る 前に、着いて いたいわね。"], ["{closed}……急ごう。村長より 先に 着く。"], ["{sad}……はい。村長さまより 先に、参りましょう。"]));
      act(H.e, 0); rm(eR); H.rm();
      return true;
    } },
  /* 第124版: 六影 本拠地（竜骨の 門 → 奥の 竜骨の 祭壇）。門の 前で 始まり、祭壇の 間へ 入る。3分 できない 世界は 今までどおり 大地で（alt）*/
  { r: 9, hq: 9, ch: "第10章 竜骨の 決戦", at: "cave", hint: "§f終焉の地 ラグナの §e六影 本拠地（竜骨の 門）§f へ 行こう §7（ラグナの 大地の そば、紫の 灯と 骨の 門。レイと 共闘。右上の 案内）", trig: (c) => c.r === 9,
    alt: { at: "land0", hint: "§f終焉の地 ラグナの §e大地（竜骨の 祭壇）§f へ 行こう §7（レイと 共闘。右上の 案内）" },
    run: async (p, d) => {
      const H = heroBox(p, true);
      if (!qs(d).ch10a) {   /* 第106版: 本拠地の 門番・ベリル 最後 */
        big(p, "§5§l六影 本拠地", "§7紫の 光の 柱の 下、竜の 骨で できた 門", "mob.enderdragon.growl");
        const eG = npcNear(p, "§c六影 中隊長 ガロ", PJ("garo", 9)); act(eG, "guard");
        if (ok(eG)) { camNear(p, eG, 3, 1.4); await wait(10); }
        await say(p, "ガロ", ["{closed,low}……急いでるんだろ。手短に いく。", "{closed,low}……よう。また 昇進した。§e中隊長§f だ。部下は もう 一人も いねえ。", "{sad}門番を やれと 言われた。……でもな、参謀の 言う『戻る』は、いつまで 待っても 来なかった。"]);
        act(eG, "hold");   /* 腰の 帽子を 握りしめる */
        if (ok(eG)) { camNear(p, eG, 1.4, 0.9, 0.5); await wait(12); }   /* 第125版(rs2): 握りしめた 帽子の 寄り */
        if (ok(eG)) await go(eG, fwd(p, 4, 3.2), 12);   /* 門の 前から 一歩 わきへ よけて 道を あける */
        await say(p, "ガロ", ["{closed}行けよ。奥の 番兵どもは 本気で 来る。……オレは、何も 見なかった ことに する。"]);
        await otsAt(p, eG, H.e, 8);   /* ガロの 肩ごしに 幼なじみ（ガロに 言う）*/
        await hsay(p, V(["{sad}……ピコくん、迎えに 行って あげて。団の 医者じゃ なくて、あなたが。"], ["{sad}……ピコくん、迎えに 行って あげて。団の お医者さんじゃ なくて、あなたが。"], ["{closed}……ピコを 迎えに 行け。団の 医者じゃ なく、あなたが。"], ["{sad}……ピコさんを、迎えに 行って あげて ください。団の お医者さまでは なく、あなたが。"]));
        re(eG, "shock", "…"); cut(p, "ガロ");
        await say(p, "ガロ", ["{sad,low}……オレが 行って、いいのか。名前を 売った やつが、迎えに。"]);
        cut(p); await hsay(p, V(["{angry,up}いいに 決まってるでしょ！ ピコが 最初に 呼ぶのは、ぜったい『兄ちゃん』だよ。"], ["{smile,up}いいのよ。ピコくんが 目を さまして 最初に 呼ぶのは、きっと あなたの ことだもの。"], ["{closed}いい。ピコが 起きて 最初に 呼ぶのは、たぶん『兄ちゃん』。"], ["{smile,up}よいのです。ピコさんが 最初に 呼ぶのは、きっと『兄ちゃん』ですから。"]));
        act(eG, "hold"); await wait(8); act(eG, 0); await leave(eG, p, 12, false);
        if (!wonOf(p, "gate10")) {   /* 第124版: 門番とは 戦わない。レイの 竜が 吠えて 道を 開ける（連戦を 減らす）*/
          const g1 = npcAt(p, "§5本拠地の 門番", PJ("noxa", 9), fwd(p, 5, -1.5)), g2 = npcAt(p, "§5本拠地の 門番", PJ("noxa", 9), fwd(p, 5, 1.5)); act(g1, "guard"); act(g2, "guard");
          await say(p, "門番", ["{angry,!,low}通すな！ 儀式を 守れ！"]);
          sound(p, "mob.enderdragon.growl", 0.7); shake(p, 0.5, 0.5);
          await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["{angry,!,up}どけ！ ……ここで 止まってる ひまは ないんだ！"]);
          act(g1, "recoil"); act(g2, "recoil"); await wait(8); await leave(g1, p, 10, false); await leave(g2, p, 10, false);
          { const eRg = npcNear(p, "§bレイ", RIVAL_JOB, true); if (ok(eRg)) { camNear(p, eRg, 2.6, 1.6); burst(p.dimension, { x: eRg.location.x, y: eRg.location.y + 1.6, z: eRg.location.z }, "minecraft:white_smoke_particle", 6, 0.8, 0.2); sound(p, "dig.stone", 0.6); await wait(8); } }   /* 第124版(dir#29): 竜の 羽に 石の 粉（第11章の 前触れ）*/
          await hsay(p, V(["{?}……レイ、竜の 羽……灰色に なってない？"], ["{?}……レイくん。竜の 羽、少し 灰色じゃ ない？"], ["{?}……レイ。竜の 羽、灰色。"], ["{?}……レイさん、竜の 羽が 灰色に……？"]));
          await say(p, "レイ", ["{sweat}……大丈夫だ。ちょっと、羽が 重い だけだ。"]);
          setWon(p, "gate10");
        }
        const eB = npcNear(p, "§5六影 ベリル", PJ("beryl", 9));
        await say(p, "ベリル", [epD(d, "r9e2") ? "{closed}……待って。一つだけ。すぐ 済むから。……約束どおり、来たの。" : "{closed}……待って。一つだけ。すぐ 済むから。……門番の 交代で、ここに 回されたの。", "{sad}ねえ、知ってた？ 参謀さまの 儀式が 終わったら、六影は なくなるんだって。", "わたし、結局 一度も 仲間に して もらえなかった。座に、わたしの 名前は 一度も 書かれなかった。", "{angry,up}だから 最後に 一度だけ。わたしが ここに いた 意味を、ちょうだい。"]);
        await hsay(p, V(["{?}……団が なくなるのに、なんで まだ 戦うの？"], ["{sad}……団が なくなるのに、どうして まだ？"], ["{?}団は 消える。それでも 戦う 理由は？"], ["{sad}団が なくなるのに、なぜ まだ 戦うのですか？"]));
        await say(p, "ベリル", ["{closed}……一度も 勝てない まま 終わるのが、いや なの。"]);
        await sixMark(p, eB, "beryl");
        const r2 = await battle(p, team(["beast", "blob", "golem"], 72, 3, 16), { name: sixName("beryl"), arena: "最後の 願い", theme: "endcity", hpk: 1.4, extra: 0.35, tag: "幹部候補", sboss: true, speaker: "ベリル", lines: { half: "今日の わたしは、本気なの！", low: "……やっぱり、だめ、か" } });
        rm(eB);
        if (r2 !== "win") { await sayAt(p, "§5六影 ベリル", PJ("beryl", 9), "ベリル", ["……勝った。初めて、勝った。……なのに、どうして 嬉しく ないの。", RT(p)]); H.rm(); return false; }
        const eB2 = npcNear(p, "§5六影 ベリル", PJ("beryl", 9), true); act(eB2, "kneel");
        await say(p, "ベリル", ["{sad,…}……負けた。", "{sad,up}ねえ。六影が なくなったら、わたし、どこへ 行けば いいの。"]);
        act(eB2, 0);
        await memory(p, eB2, "白紙の 台本", ["§7ベリルが 胸に かかえて いるのは、表紙の すりきれた §f一座の 台本§7。", "§7道化芸の 一座は 影に 飲まれて 消えた。袖で 台詞を ささやいて いた 彼女だけが 残った。", "§8……最後の 頁は、白紙の まま。"]);
        await say(p, "ベリル", ["{sad}一座の みんなの 名前は、ここに ある。……わたしの 名前だけ、書く 前に 一座が 消えたの。", "{sad,up}……ねえ。そこに、わたしの 名前、書いて いい？"]);
        if (ok(H.e) && ok(eB2)) { const l = eB2.location; await go(H.e, { x: l.x + 0.8, y: l.y, z: l.z + 0.6 }, 10); act(H.e, "hold"); }   /* ペンを 差し出す */
        await hsay(p, V(["{smile}……じゃあ、書こう。ほら、ペン。……自分の 名前は、自分で 書いて いいんだよ。"], ["{smile}……じゃあ、書きましょう。ほら、ペン。……自分の 名前は、自分で 書いて いいのよ。"], ["{closed}……書こう。ペン。自分の 名前は、自分で 書けば いい。"], ["{smile}……では、書きましょう。どうぞ、ペンです。……ご自分の 名前は、ご自分で 書いて よいのです。"]));
        act(eB2, "hold");   /* 台本を 差し出す */
        sound(p, "item.book.page_turn", 1);
        await narr(p, "白紙の 台本", ["§7ベリルは ペンを 受け取って、台本の 最後の 頁に、自分で §fベリル§7 と 書いた。"]);
        await say(p, "ベリル", ["{closed}……ベ、リ、ル。", "{smile,…}……ちゃんと、書いて ある。"]);
        cut(p, "");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
        await hsay(p, V(["{smile,♪,up}……うん。わたしの 手帳にも、書いて おくね。"], ["{smile,up}……ええ。わたしの 手帳にも、書いて おくわね。"], ["{smile,up}……うん。わたしの 手帳にも 書いて おく。"], ["{smile,up}……はい。わたしの 手帳にも、記して おきますね。"]));
        { const sx = qs(load(p) || d), c1 = wl(sx, "wq1d"), m5 = wl(sx, "wq5d");   /* 第125版: 世界の 依頼「道化の 鈴」「名前を 映す 鏡」を 済ませた 人だけ */
          if (c1) { await hsay(p, V(["{smile}それとね。ウッディの ギンジさんが、白紙の 紙の 冠の 名札を 彫って 待ってるよ。"], ["{smile}それとね。ウッディの ギンジさんが、紙の 冠の 名札を 彫って 待って いるの。"], ["{closed}ウッディの ギンジが、紙の 冠の 名札を 彫って 待ってる。"], ["{smile}それと、ウッディの ギンジさんが、紙の 冠の 名札を 彫って お待ちです。"]));
            await say(p, "ベリル", ["{shock,…}……あの 冠。……一座で いちばん 下の 役の、紙の 冠。", "{sad,up}……落とした ままだった。"]); }
          if (m5) { await hsay(p, V(["{smile,up}プリズムの セレナさんも。名前が 決まったら、いちばんに 鏡に 映すって。"], ["{smile,up}プリズムの セレナさんもね。名前が 決まったら、いちばんに 鏡に 映すって。"], ["{closed}プリズムの セレナも。名前が 決まったら、鏡に 映すと。"], ["{smile,up}プリズムの セレナさんも、名前が 決まったら いちばんに 鏡に 映すと。"]));
            await say(p, "ベリル", ["{smile,tears}……割った 鏡の、お店。……今度は、言える。"]); } }
        await say(p, "ベリル", ["{smile,up}……ありがとう。行って。あの 人を、止めて あげて。"]);
        act(eB2, 0); act(H.e, 0); await leave(eB2, p, 12, false);
        const d1 = load(p); if (d1) { qs(d1).ch10a = 1; save(p, d1); } d = d1 || d;
      }
      /* 第125版: 竜骨の 祭壇。六本の 鍵の 儀式 → 守り手の 試し → 最後の 記録で セオが 影に 宿られる → ヒロインが かばって 亡くなる → オルドと ハクが 押さえ、セオは 影ごと 王冠の 石板へ */
      if (qs(load(p) || d).heroDead) { H.rm(); return true; }
      /* 第124版: 門の 奥、竜骨の 祭壇の 間へ（十四の 石板の 円・六本の 鍵の くぼみ）。ない 世界は その場で */
      const hq = await goHall(p, 9, "竜骨の 祭壇"), v9 = hq ? caveInfo(9) : null;
      const eT = hq ? npcAt(p, "§5六影 参謀 セオ", TRAITOR_JOB, { x: v9.altar.x, y: v9.hall.y, z: v9.altar.z - 3 }) : npcNear(p, "§5六影 参謀 セオ", TRAITOR_JOB), eR = npcNear(p, "§bレイ", RIVAL_JOB);
      big(p, "§4§l竜骨の 祭壇", "§f竜の 骨の 祭壇で、セオが 石板を 円に 並べている", "mob.enderdragon.growl");
      if (hq) { await arrive(eT); camAt(p, { x: v9.hall.x, y: v9.hall.y + 7, z: v9.hall.z - 6 }, { x: v9.hall.x, y: v9.hall.y - 0.5, z: v9.hall.z + 1 }, 0); await wait(22); }   /* 床の 十四の 石板の 円 */
      if (ok(eT)) { camNear(p, eT, 3, 1.2, hq ? 0 : 0.6); await wait(8); }
      if (!qs(d).ch10g && !qs(d).ch10b) {
        if (ok(eT)) turnTo(eT, hq ? { x: v9.altar.x, y: v9.altar.y, z: v9.altar.z } : fwd(p, 14, 0, 1));   /* 第125版(rs2): セオは 祭壇の 石板を 見おろした まま、背中で 言う */
        await say(p, "セオ", ["{closed,low}……やっと、そろいました。"]);
        turnTo(eT); if (ok(eT)) { try { eT.teleport(eT.location, { facingLocation: p.getHeadLocation() }); } catch {} }   /* ふり向く */
        if (ok(eT)) { camNear(p, eT, 4.5, 1.4, 0.4); await wait(4); camNear(p, eT, 2, 1.5, 1.8); }   /* 第125版(rs): 謝る 行は ゆっくり 寄る */
        await say(p, "セオ", ["{sad,up}来ましたね。……すみません。本当に、すみません。"]);
        await hsay(p, V(["{angry,!,up}セオさん、もう やめて！ ここで 何を する つもりなの！"], ["{sad,up}セオさん……もう やめて。ここで、何を するの？"], ["{angry}セオ。ここで 何を する。"], ["{angry,up}セオさん、お願い です、もう おやめ ください！ 何を なさる おつもりですか！"]));
        await say(p, "セオ", ["{closed}§e六本の 鍵§f を 祭壇に はめる 儀式です。仲間たちから 預かった 鍵と、僕の 一本。", "{up}鍵を 持つ 者は、石板に 拒まれる。最後に 石板を 開けられるのは、鍵を 持たず、モンスターと 絆を 結んだ 者。……君と、相棒です。", "{sad}最後に、確かめさせて ください。石板の 守り手が、君たちに 道を あけるか どうか。"]);
        await say(p, "セオ", ["{closed,low}六本は、首領の 命で、今日だけ 集められました。双子の 鍵は、アルゴが 届けて くれた。……二人は、預けた ままです。", "{closed}ベリルさんの 水晶で、祭壇の 影を 一晩だけ 閉じこめて おけます。"]);   /* 第125版 A46・A28 */
        { const eA = npcNear(p, "§4仮面の 戦士", PJ("argo", 10)); act(eA, "guard"); if (ok(eA)) { camNear(p, eA, 2.4, 1.5); await wait(10); }   /* 第125版: 決まり「鍵が 盾に なる」。アルゴが 止める */
          await say(p, "アルゴ", ["{angry,low}……参謀。§e鍵を 手放すな§f。", "{closed}鍵は 盾だ。身に つけて いる 間は、影は 入れない。……六本 全部を 祭壇に はめれば、その 間、我らは 丸裸だ。"]);
          await say(p, "セオ", ["{closed}……わかって います。一瞬で 終わらせます。", "{sad}ルミエに いる 弟の 石に、ひびが 入りはじめた。……崩れたら、戻れない。"]);
          await say(p, "セオ", ["{sad,low}……もう、待てないんです。"]);
          re(eA, "closed", "…"); act(eA, "guard"); }   /* 第125版(co): アルゴは 祭壇の 端に 残る */
        const c0 = ok(eT) ? eT.location : fwd(p, 6);
        if (c0) { for (let k = 0; k < 7; k++) { const a = (k / 7) * Math.PI * 2; burst(p.dimension, { x: c0.x + Math.cos(a) * 4, y: c0.y, z: c0.z + Math.sin(a) * 4 }, "minecraft:soul_particle", 6, 0.5, 0.2); await wait(2); } camLowUp(p, c0); }
        sound(p, "mob.wither.spawn", 0.8); shake(p, 0.7, 1); flash(p, false);
        big(p, "§6§l十四の 主の 写し", "§f封じた 主たちの 写しが、セオの 呼びかけに 応えて 並ぶ", "mob.wither.spawn");
        act(eR, "guard"); act(H.e, "guard");
        await say(p, "レイ", ["{angry,!,low}……確かめたいなら、確かめさせて やる。背中は 任せた！"]);
        await duel(p, "§6§l主の 写し", "§f三体の 写しが 左右と 空から 同時に 来る！", { fams: ["dragon", "golem"] });
        const lv0 = 72;
        const r3 = await battle(p, [...bossOne(["dragon", "golem"], lv0, 60, 1), ...team(["dragon", "golem"], lv0, 2, 40)], { name: "十四の 主の 写し", arena: "守り手", theme: "endcity", hpk: 3.6, extra: 0.35, sboss: true, tag: "守り手", speaker: "守り手", guests: team(["dragon"], lv0, 1, 30).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……カギ……カ……？", low: "……トオレ……ロクホンメ……" } });
        if (r3 !== "win") { rm(eT); rm(eR); await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["……くそ、いったん 引こう！ 立てなおして、もう一度だ！"]); H.rm(); return false; }
        const dg = load(p); if (dg) { qs(dg).ch10g = 1; save(p, dg); } d = dg || d;
      }
      if (!qs(d).ch10t) {
        const eT1 = npcNear(p, "§5六影 参謀 セオ", TRAITOR_JOB, true); H.e;
        const AC = hq && v9.altar ? v9.altar : (() => { const S10 = stageOf(p); return facAt("r9altar", p.location, 60) || (S10 ? facBuild(p, S10, "r9altar", "altar", 9, Math.floor(S10.P.y)) : null); })(); crysRing(p, AC, true);   /* 第125版(tp): 祭壇と まわりの 水晶（広間で ない ときは 祭壇も 建てる）*/
        await say(p, "セオ", ["{smile,…}……やはり。守り手が、君たちに 道を あけた。"]);
        { const c1 = ok(eT1) ? eT1.location : fwd(p, 6); if (c1) for (let k = 0; k < 6; k++) { const a = (k / 6) * Math.PI * 2; burst(p.dimension, { x: c1.x + Math.cos(a) * 2.2, y: c1.y + 0.3, z: c1.z + Math.sin(a) * 2.2 }, "minecraft:totem_particle", 5, 0.3, 0.3); sound(p, "random.anvil_land", 0.6 + k * 0.1); await wait(4); } }
        if (hq) camAt(p, { x: v9.hall.x, y: v9.hall.y + 4.5, z: v9.hall.z + 1.5 }, { x: v9.hall.x, y: v9.hall.y - 0.5, z: v9.hall.z + 7 }, 0);   /* 壇の 手前の 六つの くぼみ */
        big(p, "§6§l六本の 鍵", "§f祭壇の 六つの くぼみに、鍵が はまって いく", "random.anvil_land"); if (hq) await wait(16);
        await say(p, "セオ", ["{closed}……これで 鍵は そろった。あとは、最後の 記録を 読めば――", "{closed,low}鍵を 目覚めさせるには、鍵の ほんとうの 名を 声に 出す。……それを 知るのは、僕だけ。"]);
        act(eT1, "hold"); sound(p, "item.book.page_turn", 1); if (ok(eT1)) { camNear(p, eT1, 1.8, 1.5); await wait(10); }
        await hsay(p, V(["{shock,!,up}その 頁……マリノアで 破った 頁！"], ["{shock,…}……その 頁。マリノアで 破った……"], ["{shock,!}……マリノアで 破った 頁だ。"], ["{shock,!}その 頁は……マリノアで お破りに なった……！"]));
        await say(p, "セオ", ["{closed,low}『王冠の 石板の 奥。影の 鍵の、ほんとうの 名は――』"]);
        { const far = fwd(p, 12, -4); if (far && ok(eT1)) { camPt(p, eT1.location, 4, 1.2); await shadowFlow(p, far, eT1.location, 16); } }
        big(p, "§4§l影", "", "mob.wither.spawn"); flash(p, false); shake(p, 0.8, 1);
        if (AC) { camPt(p, AC, 6, 0.6); crysRing(p, AC, false); }   /* 第125版(tp): 本当に 割れる */
        sound(p, "random.glass", 1); await narr(p, "", ["§7祭壇の まわりの 水晶が、音を 立てて いっせいに 割れた。"]);
        act(eT1, 31); await wait(8); act(eT1, "kneel"); redGlow(eT1);   /* よろけて から ひざを つく */
        await say(p, "セオ", ["{shock,!,up}……っ！？ 頭の 中に、何かが……！", "{rage}……離れて ください！ 僕から、離れて……！"]);
        try { if (ok(eT1)) eT1.nameTag = "§4影に 呑まれる セオ"; } catch {}
        cut(p, "レイ");   /* 第125版: 話す 人へ カメラを 切りかえる（止まった まま 話が 進まない ように）*/
        await say(p, "レイ", ["{angry,!}セオの 子たちが 暴れだした！ ……止めるぞ！"]);
        big(p, "§4§l六影 二の座 ―― 記録の指", "§4…キ…ロク…ハ…", "mob.wither.ambient"); shake(p, 0.5, 0.6); redGlow(eT1); await wait(20);   /* 第124版(dir#24): 呑まれていく 最中は 落ちついた 名乗りに しない */
        act(eT1, 0);
        await duel(p, "§4§l影に 呑まれる セオ", "§fセオの 子たちの 目が、赤黒く にごる！", { fams: ["nether"] });
        const lv = 74;
        const res = await battle(p, team(["nether", "nether", "dragon"], lv, 3, 52), { name: sixName("theo"), arena: "竜骨の 祭壇", theme: "endcity", hpk: 2.6, extra: 0.4, sboss: true, tag: "参謀", speaker: "セオ", guests: team(["dragon"], lv, 1, 30).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……止まらない……体が、勝手に……！", low: "……今の うちに……逃げて……" } });
        if (res !== "win") { rm(eT1); rm(eR); await sayAt(p, "§bレイ", RIVAL_JOB, "レイ", ["……まだだ。あいつを 止める！ もう一回！"]); H.rm(); return false; }
        const dt = load(p); if (dt) { qs(dt).ch10t = 1; save(p, dt); } d = dt || d;
      }
      /* 暴走 → かばう（戦いの あと もどった セオと レイを そのまま 使う）*/
      const eT2 = ok(eT) ? eT : npcNear(p, "§4影に 呑まれる セオ", TRAITOR_JOB, true), eR2 = ok(eR) ? eR : npcNear(p, "§bレイ", RIVAL_JOB, true); const eH = H.e;
      try { if (ok(eT2)) eT2.nameTag = "§4暴走 セオ"; } catch {} rmName(p, "§5六影 参謀 セオ", "§4影に 呑まれる セオ"); place(eT2, p, fwd(p, 6)); place(eR2, p, fwd(p, 3, 2.4));
      act(eT2, "up"); redGlow(eT2); shake(p, 0.6, 1); sound(p, "mob.wither.ambient", 0.8);
      if (ok(eT2)) { camNear(p, eT2, 2.6, 1.4); await wait(10); }
      big(p, "§4§l暴 走", "§fセオの 背中から、影が あふれ出す", "mob.wither.spawn");
      act(eT2, 22); pillar(eT2, [0.5, 0.1, 0.7], 2);   /* のけぞり、足もとに 紫の 柱 */
      await narr(p, "", ["§7祭壇の 六つの くぼみの うち、セオの 一本……赤い 紐の 鍵が 割れて 転がった。"]);   /* 第125版 A47 */
      await say(p, "セオ", ["{rage,low,stagger}……ア……アア……", "{rage,up}……ミツ……ケタ……§4ロクホンメ§f……"]);
      big(p, "§c§l！", "§f影の 槍が、まっすぐ あなたへ", "mob.wither.shoot");
      if (ok(eH)) { const q = fwd(p, 1.3); if (q) await go(eH, q, 4, true); act(eH, "guard"); }   /* 幼なじみが 前に 飛びだす */
      if (ok(eT2) && ok(eH)) await shadowFlow(p, eT2.location, eH.location, 8);
      flash(p, false); shake(p, 1, 0.8); sound(p, "mob.wither.break_block", 0.8);
      act(eH, "down"); if (ok(eH)) { camNear(p, eH, 1.8, 0.6); await wait(18); }
      /* 第124版(dir#25): 最期の 3行は 1行ずつ（ヒロイン → 相棒の 寄り → ゆっくり ヒロインへ）*/
      await hsay(p, V(["{smile,…}……よかった。あなたに、当たらなくて。"], ["{smile,…}……よかった。あなたは、けが して ない。"], ["{closed}……当たったのが、わたしで よかった。"], ["{smile,…}……ご無事で、よかった。"]));
      const g = palEnt(p); if (g && ok(eH)) { const l = eH.location; await go(g, { x: l.x + 0.7, y: l.y, z: l.z + 0.5 }, 10); dEmote(g, "sigh"); anim(g, "hurt"); camNear(p, g, 2, 0.8); await wait(10); }   /* 相棒が 鼻を 押しあてる */
      await hsay(p, V(["{sad}……手帳、まだ……白い 頁が、いっぱい……"], ["{sad}……ごはん、ちゃんと 食べてね……手帳の 続きも……"], ["{sad}……手帳。続きは、あなたが 書いて。……字、汚くても いいから。"], ["{sad}……手帳の 続き、どうか……お願い します……"]));
      if (ok(eH)) { camNear(p, eH, 1.3, 0.5); await wait(10); }
      await hsay(p, V(["{smile,…}……続き、書いてね。……約束、だよ……"], ["{smile,…}……おねがい、ね……"], ["{smile,…}……泣かないで。……ばか。"], ["{smile,…}……おそばに いられて、しあわせ でした……"]));
      re(eH, "closed"); sound(p, "item.book.put", 1);   /* 手帳が 落ちる */
      if (ok(eH)) { camPt(p, eH.location, 1.6, 0.2); await wait(12); }
      cmd(p, "stopsound @s"); await wait(30);
      await pal(p, ["……ねえ。……おきて。"]);
      await narr(p, "", ["§7首から 落ちた コンパスの 針が、どこも 指さずに 回りつづけて いる。"]);   /* 第125版 Q18 */
      rmCine(g);
      { const eA = npcNear(p, "§4仮面の 戦士", PJ("argo", 10)); if (ok(eA)) { await wait(16); act(eA, "kneel"); camNear(p, eA, 2, 1.5); sound(p, "random.glass", 0.8); burst(p.dimension, { x: eA.location.x, y: eA.location.y + 1.6, z: eA.location.z }, "minecraft:critical_hit_emitter", 4, 0.2, 0); await wait(12); }   /* 第125版: アルゴは 間に 合わず、仮面が さらに 割れる */
        await say(p, "アルゴ", ["{sad,low}……また、守れなかった。"]);
        if (ok(eA)) await leave(eA, p, 10, false); }
      /* オルドと ハクが 駆けつけ、暴走した セオを 押さえる */
      const hk = hakuEnt(p, fwd(p, 4, -2)), eO = npcNear(p, "§eオルド", PJ("ordo", 8), true);
      if (ok(eO) && ok(hk)) { const l = hk.location; place(eO, p, { x: l.x + 0.6, y: l.y, z: l.z - 0.6 }); ride(hk, eO); }
      await drop(p, hk, 5); boom(p.dimension, ok(hk) ? hk.location : p.location); sound(p, "mob.ravager.roar", 1); flash(p, true);
      await say(p, "オルド", ["{angry,!,up}セオ！！ 目を 覚まさんか！！"]);
      if (ok(hk) && ok(eT2)) { const l = eT2.location; await go(hk, { x: l.x + 1, y: l.y, z: l.z + 0.6 }, 6, true); }   /* ハクが 跳びかかって 押さえる */
      act(eT2, "kneel"); sound(p, "mob.ravager.roar", 1.4); shake(p, 0.8, 0.8);
      if (ok(eT2) && ok(hk)) { await shadowFlow(p, eT2.location, hk.location, 10); camNear(p, hk, 3, 1); }
      await stoneFx(p, hk); await stoneFx(p, hk, "§7ハクの 石像");
      await wait(16); await say(p, "オルド", ["{closed,…}……ハク。"]); await wait(16);   /* 第124版(fix2): 石に なった ハクを 見せる 間 */
      if (ok(eT2)) { re(eT2, "shock", "…"); camNear(p, eT2, 1.8, 1.5); await wait(16); }
      await say(p, "セオ", ["{shock,…,up}……僕は……何を……。", "{cry,tears}……この 手で……あの 子を……", "{sad,low}……そうか。§c王も、こうだったのか§f。"]);
      if (ok(eT2)) { const l = eT2.location; await shadowFlow(p, l, hq ? { x: v9.altar.x, y: v9.altar.y, z: v9.altar.z + 1 } : { x: l.x, y: l.y + 5, z: l.z }, 14); } flash(p, false); rm(eT2);   /* 第124版: 祭壇の 間では 奥の 祭壇の 方へ */
      big(p, "§8……", "§7セオは 影ごと、祭壇の 奥の 闇へ 沈んで 消えた", "mob.wither.death");
      await wait(14);
      if (ok(eR2) && ok(eH)) { const l = eH.location; await go(eR2, { x: l.x - 0.8, y: l.y, z: l.z + 0.5 }, 8, true); } act(eR2, "kneel");
      if (ok(eR2) && ok(eH)) { const a = eR2.location, b = eH.location, m = { x: (a.x + b.x) / 2, y: Math.min(a.y, b.y) + 0.6, z: (a.z + b.z) / 2 }, dx = b.x - a.x, dz = b.z - a.z, n = Math.hypot(dx, dz) || 1; camAt(p, { x: m.x - (dz / n) * 3, y: m.y + 2.5, z: m.z + (dx / n) * 3 }, m, 1.0); await wait(14); }   /* 第124版(fix2): レイと 倒れた ヒロインを 上から */
      await say(p, "レイ", ["{cry,tears}……おい。……返事 しろよ。", "{sad}オレが、もっと 早く 動いて いれば……"]);
      if (ok(eO)) { act(eO, "kneel"); await wait(6); }
      await say(p, "オルド", ["{sad,low}……わしが、遅すぎた。"]);
      if (ok(eO)) { act(eO, 0); turnTo(eO, hq ? { x: v9.altar.x, y: v9.altar.y, z: v9.altar.z } : fwd(p, 14, 0, 2)); }   /* 第125版(rs2): 立ちあがり、セオが 沈んだ 祭壇の 奥へ 背を 向ける */
      await pastCard(p, "§7―― 二十年前"); if (ok(eO)) await pushIn(p, eO, 22);   /* 二十年前の 話は 回想の 札 → 背中へ ゆっくり 寄る */
      await say(p, "オルド", ["{closed}二十年前と 同じじゃ。……知りすぎた 者に、影が 宿った。", "{closed,low}……あの 引かれ方。王冠の 石板じゃ。"]);
      turnTo(eO);
      await narr(p, "旅の 手帳", [`§f${HN(p)}§7 の 手には、書きかけの §f旅の 手帳§7 が にぎられて いた。`, "§7手帳の 名前の 頁には、旅で 出会った 人たちの 名前が、ていねいな 字で 並んで いた。"]);
      let got10 = [];
      { const dz = load(p); if (dz) { const sz = qs(dz); sz.heroDead = 1; sz.theoGone = 1; sz.hakuStone = 1; sz.ch10b = 1; got10 = reward(p, dz, 40000, [["e_king", 1], ["i_awaken", 1], ["SEED3", 2], ["s_all3", 1], ["tms_king", 1]]) || []; save(p, dz); } }
      act(eR2, 0); act(eO, 0);
      await bye(p, eR2, eO, eH); rmCine(hk); H.rm();
      await narr(p, "竜骨の 祭壇", ["§7……旅の 仲間は、もう いない。"]);   /* 第124版(dir#26,27): 喪失の 行だけ。間を 取ってから 案内と ほうび */
      await wait(40);
      try { p.sendMessage("§7→ エンドの 竜の 見晴らし台へ（右上の 案内）"); for (const x of got10) p.sendMessage(`§7${x}`); } catch {}
      return true;
    } },
  { r: 9, seal: 13, nospot: 1, hint: "§fソラから 受け取った §d石板§f で ラグナの §6主§f を 封印しよう §7（ソラの 試しは エンドの 竜の 見晴らし台。石板は 道具から 使う）", trig: (c) => c.s.bs.includes(13),
    run: async (p, d) => {
      const H = heroBox(p, true);   /* 第125版(ce): ソラとは 見晴らし台で 戦い、石板を 受け取った（r9e5）。ここは 主を 封じた あと（ソラは 出ない）*/
      await narr(p, "ラグナの 主", ["§7ラグナの 主は、石板の 中で 静かに なった。", "§7地方の 石板は、これで 全部。……残るのは 王冠の 石板。セオが 沈んだ 先だ。"]);
      await gateOpen(p, 10, "レイ", ["（手紙）竜の 羽が 石に なりかけてる。天空郷の 風なら 治ると 聞いて、連れて きた。竜は 雲の 島の 端（いちばん 風の 当たる 所）に いる。……§eかぜの 塔の 町 ゼファー§f の 入口で 待ってる。", "……セオを 止めに 行くのは、どっちか。勝負で 決めたい。"]);
      { const g13 = palEnt(p); if (g13) { camNear(p, g13, 2.2, 0.7); await wait(10); } await pal(p, ["……かばんの 手帳、まだ あの子の におい。", "……つぎの 頁、いっしょに いこう。"]); rmCine(g13); }
      H.rm(); return true;
    } },
  { r: 10, ch: "第11章 最後の ライバル", at: "land0", hint: "§fセレスティア天空郷の §e雲の 島の 端§f へ 行こう §7（レイが 待って いる。右上の 案内）", trig: (c) => c.r === 10 || c.s.ending,
    run: async (p, d) => {
      if (qs(d).ending) return true;
      /* 第125版(ce): 旅の 仲間の いない 旅。夜明けの 雲の 島の 端（cloudedge）。レイが 欲しい もの = 自分が セオを 止めて しくじり帳の 頁を 破る ／ 手放す もの = だれかに 選ばれる こと・頁を 破る こと ／ 勝負の あと = 自分で 役目（ルミナを 守る）を 決める */
      big(p, "§6§l雲の 島の 端", "§f夜明け。大きな 竜の 石像の 前で、レイが 待っている");
      const y10 = Math.floor((stageOf(p) || { P: p.location }).P.y), ER = facAt("r10edge", p.location, 60) || facBuild(p, stageOf(p), "r10edge", "cloudedge", 10, y10) || facSide(p, stageOf(p), 16, "r10edge", "cloudedge", 10, y10) || facSide(p, stageOf(p), -16, "r10edge", "cloudedge", 10, y10), EMK = (n) => facMark("r10edge", n, p.location);
      const sq = (ER && EMK("dragon")) || fwd(p, 5, 2.6), dr = monEnt(p, sq, DRAGON_SP(), "§7竜の 石像");
      const e = await putAt(p, "§bライバル レイ", RIVAL_JOB, (ER && EMK("ray")) || fwd(p, 4, 1), sq); act(e, "hold");   /* 第125版(ce): 夜明けから ずっと 竜の そばに いる（歩いて 来ない）*/   /* 石の 竜の 首を、いつもの ように なでる */
      if (ok(dr)) { camNear(p, dr, 4, 1.5); burst(p.dimension, dr.location, "minecraft:white_smoke_particle", 6, 1, 1); await wait(16); }
      await say(p, "レイ", ["{smile,…}……来たか。ゆうべの 話の 続きだ。……こいつの 前で、決めたかった。", "{sad}朝日が 当たっても、冷たい ままだ。かけらの 代わりに、こいつが 持って いかれたんだと 思う。", "{closed,…}……オレの せいだ。"]);
      const g = palEnt(p); if (g && ok(dr)) { const l = dr.location; place(g, p, { x: l.x - 1, y: l.y, z: l.z }); camNear(p, g, 2.2, 0.8); await wait(8); }   /* 相棒が 石の 竜に 鼻を 押しあてる */
      await pal(p, ["……まだ、なかに いる。"]);
      rmCine(g);
      act(e, 0);
      await say(p, "レイ", ["{closed}……塔の 下で、おまえ フウタの 名前を 書いたよな。", "{sad}あいつの 手帳の 続きを 書くのは、もう おまえだ。……こいつと ハクの 名前も、書いて やって くれ。"]);
      sound(p, "item.book.page_turn", 1);
      await narr(p, "旅の 手帳", ["§7あなたは 手帳を 開き、名前の 頁の 続きに 書いた。", `§fハク・レイの 竜・${HN(p)}`, "§7（空の 声より 前に 石に なった 者と、死んだ 者。……古い インクは、もう 届かない。それでも、呼ぶ 日の ために）"]);
      techo(p, "ハク"); techo(p, "レイの 竜"); techo(p, HN(p));
      act(e, "show"); hold(e, "notebook");
      if (ok(e)) { camNear(p, e, 1.8, 1.3); await wait(10); }
      await narr(p, "しくじり帳", ["§7レイが しくじり帳を 開いた。最後の 頁の、レイの 字。§f『竜骨の 祭壇。動けなかった。』"]);
      act(e, "raise"); hold(e);
      await say(p, "レイ", ["{closed}……セオは、王冠の 石板の 中だ。祭壇で、影ごと 沈むのを オレも 見た。", "{angry,up}……セオを 止めに 行くのは、どっちか。王座の 扉を くぐれるのは、杯を 勝ちぬいた 一人だけだ。その 一人を、§eここで 決めよう§f。", "{closed}オレが 勝ったら、この 頁を 破る。……かけらも 竜も なしの、ほんとの オレで やりたい。手加減は なしだ。"]);
      cut(p, ""); act(e, "raise");
      await say(p, "レイ", ["{closed,…}……これ、じいちゃんの 古い 腕輪だ。旅に 出る 朝、黙って 渡された。", "{up}相棒と 心が そろうと、熱く なる。……今の オレの 全部を、ぶつける。"]);   /* 第125版: 闘魔解放を はじめて 見せる（戦いの 中で 1回）*/
      act(e, "guard");
      rmCine(dr);
      await duel(p, "§b§l雲の 上の 一騎打ち", "§f竜の いない レイの 子が 真っ向から 飛びこむ！", { fams: ["animal", "beast"] });
      const lv = 80;
      const res = qs(load(p) || d).reiFinal ? "win" : await battle(p, team(["animal", "beast", "golem"], lv, 4, 8, leadOf("beast", lv)), { name: "ライバル レイ（最後の 勝負）", tmx: "rei", arena: "最後の ライバル戦", theme: "sky", hpk: 1.0, extra: 0.3, sboss: true, tag: "ライバル", speaker: "レイ", lines: { half: "まだだ……オレも 全部 出しきる！", low: "……ハハ、やっぱ おまえは すげえよ。" } });
      rm(e);
      const d2 = load(p); if (!d2) return false;
      if (res !== "win") { await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", ["{closed}……オレの 勝ちだ。", "{sad}でも、頁を 破る 気に なれねえ。……もう一度、来い。"]); return false; }
      const s = qs(d2); if (!s.reiFinal) { s.reiW = (s.reiW || 0) + 1; s.reiFinal = 1; save(p, d2); }   /* 第123版: 勝った ことを すぐ 保存（あとの 場面で 抜けても 戦いの ほうびが 2回 出ない） */
      const dr2 = monEnt(p, sq, DRAGON_SP(), "§7竜の 石像"), e2 = ER ? await putAt(p, "§bライバル レイ", RIVAL_JOB, EMK("ray") || fwd(p, 4, 1)) : npcNear(p, "§bライバル レイ", RIVAL_JOB, true);   /* 第125版(ce): 竜の 横に もどって いる */
      act(e2, "up"); if (ok(e2)) { camNear(p, e2, 2, 1.6); await wait(20); }   /* しばらく 空を 見上げる */
      act(e2, "kneel"); hold(e2, "notebook"); sound(p, "item.book.page_turn", 0.8);
      await narr(p, "しくじり帳", ["§7レイは しくじり帳を 開いた。……破らなかった。", "§7『動けなかった』の 下に、小さく 書き足した。§f『全部 出して、負けた。』"]);
      act(e2, 0); hold(e2);
      await say(p, "レイ", ["{smile,…}……完敗だ。しくじりじゃ ない 負けは、はじめてだ。", "{closed}……本当は、わかってたんだ。§eあいつを 止めるのは、あいつの 友だ§f。……オレじゃ ない。", "{up}行け。オレは ルミナを 守る。……あの 子の 墓も、ハクも。だれかに 言われたんじゃ ない。オレが 決めた。"]);
      await narr(p, "コンパス", ["§7あなたは、あの子が 作った コンパスを 見た。……針は まだ、どこも 指さずに 回って いる。"]);
      if (ok(e2)) { camNear(p, e2, 1.7, 1.4); await wait(8); }
      await say(p, "レイ", ["{closed}……針が 決まらねえなら、決まるまで 歩けよ。", "{smile,up}あいつも、ずっと そうしてた。", "{closed}じいちゃんが 言ってた。王座の 扉は、§eすべての 杯を 勝ちぬいた 者にだけ 開く§f。……闘技場を 開いた 人の 掟だって。", "§7→ §cルミナの 闘技場§7 で カップを 勝ちぬき、闘技場の 奥の 王座へ"]);
      if (ok(e2) && ok(dr2)) { if (!ER) await go(e2, { x: dr2.location.x + 1.6, y: e2.location.y, z: dr2.location.z + 0.6 }, 10); try { e2.teleport(e2.location, { facingLocation: dr2.location }); } catch {} act(e2, "hold"); camNear(p, dr2, 3, 1.4); await wait(6); }
      await say(p, "レイ", ["{closed,…}……ちょっと 行って くる。ルミナまでな。"], dr2);   /* 石の 竜に */
      act(e2, 0); if (ER) { const q = fwd(p, 0.5, 9); if (q && ok(e2)) await go(e2, q, 24); await gone(p, e2); } else await leave(e2, p, 10, false); rmCine(dr2);   /* 端の 手すりと 反対の 道へ */
      reward(p, d2, 30000, [["e_king", 1], ["SEED3", 1], ["i_awaken", 1], ["i_trpick", 1], ["tms_sword", 1]]); save(p, d2);
      return true;
    } },
  { r: 99, nospot: 1, ch: "終章 歴史再び", hint: "§f王冠の 石板は ルミナの 闘技場の 奥の 王座に ある。扉は 闘技場を 開いた 人の 掟で §eカップを ぜんぶ 勝ちぬいた 者§f にだけ 開く。カップを 勝って §c闘技場の 奥の 王座§f へ。石板を ぜんぶ 封印したら 王冠の 石板へ §7（進み具合は ガイドブック ＞ ストーリー）", trig: (c) => !!c.s.ending || (!c.s.finIntro && !c.s.final && !(EP_HOOK.block && EP_HOOK.block(c.d, 1e9))),   /* 第125版: 終章に 入ったら その場で 闘技場へ 向かう 場面（1回）*/
    run: async (p, d) => {
      if (!qs(d).ending) { if (!qs(d).finIntro && !qs(d).final) await cupScene(p, "turn"); return "next"; }   /* 第125版: 石板が ルミナへ 鳴る → 闘技場の 前で オルドが 掟を 話す。段は 進めない */
      if (!wonOf(p, "e0") && !pgAway(d)) { setWon(p, "e0"); d = load(p) || d; }   /* 第125版: もう 救い出した あとの セーブ（前の 版）は 墓の 場面を 見せない */
      if (!wonOf(p, "e0")) {   /* 第125版: セオの 記録。ルミナの 外れ、牧場の そばの ヒロインの 墓。レイが セオの 最後の メモを 届けに 来る */
        await sceneAt(p, placeOf("ranch", 0, true), "オルドの 牧場の そば");
        const hn = HN(p), gq = (() => { const SG0 = stageOf(p); const a = facAt("herograve", p.location, 60) || (SG0 ? facBuild(p, SG0, "herograve", "grave", 0, Math.floor(SG0.P.y)) : null); return (a && facMark("herograve", "stone", p.location)) || fwd(p, 4.5, 0); })();   /* 第125版(tp): 丘の 小さな 墓（石の 墓標・野の 花）を 建てる */
        const hk = hakuEnt(p, fwd(p, 6, -3.2)), dr = monEnt(p, fwd(p, 6.5, 3.4), DRAGON_SP(), "§7竜の 石像"); if (ok(hk)) hk.nameTag = "§7ハクの 石像";
        if (gq) { camPt(p, gq, 3, 0.6); burst(p.dimension, gq, "minecraft:villager_happy", 6, 0.6, 0.2); await wait(16); }
        await narr(p, "小さな 墓", [`§7牧場の そばの 丘に、小さな 墓が ある。§f${hn}§7 の 墓だ。`, "§7墓の 前には、野の 花。……あなたが 供えた、書きかけの §f旅の 手帳§7。", "§8手帳の 最後の 頁は、まだ 白紙の ままだ。"]);
        const eO = npcNear(p, "§eオルド", PJ("ordo", 8)); act(eO, "hold");
        await say(p, "オルド", ["{closed,…}……海と 牧場が、いっぺんに 見える 場所じゃ。あの 子は、ここが 好きじゃった。", "{sad}地図を 全部 描くのが 夢じゃと 言うて おった。……わしは、何も して やれなんだ。"]);
        act(eO, 0);
        const eR = npcNear(p, "§bレイ", RIVAL_JOB); act(eR, "hold");
        await say(p, "レイ", ["{closed}……ここに いたか。", "{?}……その 手帳、セオのか。", "{up}最後の 頁……光に かざして みろ。"]);
        sound(p, "item.book.page_turn", 1); if (ok(eR)) { camNear(p, eR, 1.8, 1.3); await wait(12); }
        await narr(p, "セオの 手帳", ["§7光に かざすと、にじんだ 影の 下から、一行だけ 字が 浮かんだ。", "", "§f『死んだ 者の 名は、§4魂の 帳§f に 載る。", "§f　載る 前なら、呼び戻せる』"]);
        await say(p, "レイ", ["{angry,!,up}……呼び戻せる、だと。", "{sad,low}……おまえ、言ってたよな。あいつが 最後に『記録を、残して おいた』って。……これの ことだ。きっと。"]);
        re(eO, "shock", "!");
        await say(p, "オルド", ["{shock,…,up}……魂の 帳。ソウラの 霊廟に 写しが ある と いう、あれか。", "{closed}剣の 家の 古い 話じゃ。死んだ 者の 名を 書く、裁きの 王の 帳。", "{up}……アルカトラスの 王なら、もっと 知って おるかも しれん。", "{closed}……王には、わしから 使いを 出しておく。"]);
        await say(p, "レイ", ["{smile,…}……行けよ。オレは ここで、ハクと 竜を 見て る。", "{closed}あの 手帳は、おまえが 持って いけ。……名前を 書く 場所が、まだ 残ってる。"]);
        { const dt = load(p); if (dt) { const st = qs(dt); st.theoMemo = 1; st.techo = [...new Set([...(st.techo || []), hn])]; save(p, dt); } }
        await narr(p, "旅の 手帳", ["§7墓の 前の 手帳を 拾って、あなたは かばんに しまった。"]);
        await bye(p, eO, eR); rmCine(hk); rmCine(dr);
        setWon(p, "e0"); d = load(p) || d;
      }
      if (EP_HOOK.endLinks && !(qs(d).epx || {}).endM) { try { await EP_HOOK.endLinks(p); } catch (e) { console.warn(`[MonsterRPG] endLinks: ${e}`); } d = load(p) || d; }   /* 第125版: すべてが つながる（それぞれの 町）*/
      if (!qs(d).m1) {   /* 第106版: 魔1「鍵の 外れた 夜」。第125版: 壁画は 魂の 帳の 王を 鍔に 封じた 日 */
        big(p, "§4§l鍵の 外れた 夜", "§7アルカトラス城の 地下から 地鳴り", "ambient.weather.thunder");
        camFade(p); shake(p, 0.3, 0.8); await wait(12);
        await narr(p, "地鳴り", ["§7その 夜、アルカトラス城の 地下から 地鳴りが した。", "§f城の 使いが 走って きた。§6「王が お呼びです。……地下の 封印庫が、鳴って おります」"]);
        await goPlace(p, "court", 0, "アルカトラス城の 中庭");
        let eK = npcNear(p, "§6アルカ十三世", PJ("arca13", 15));
        await say(p, "アルカ十三世", ["§7（王は 夜着の まま、中庭に 立って いた）", "……すまぬ。この 夜を、余は 千年分の 見張りの 果てに 迎えた。", "……オルドの 使いが、昼の うちに 来た。魂の 帳を 知りたいと？ ……ならば 見せねば なるまい。玉座の 奥の 封印の 扉に、千年 見張って きた 絵が ある"]);
        await bye(p, eK); await goPlace(p, "throne", 0, "玉座の 奥の 封印の 扉の 前"); eK = npcNear(p, "§6アルカ十三世", PJ("arca13", 15), true);
        await narr(p, "封印の 扉", ["§7玉座の 奥、地下の 封印庫へ 下りる 扉。その 上に、古い 壁画が あった。", "§f冠を かぶった 王が、大きな §4帳§f を 抱いて 座って いる。", "§7その 前に、刀を 持つ 剣士と、槌を 持つ 鍛冶。§f剣士の 手には、小さな §c鍔§f。", "§8……壁画の 下で、封印の 石が 割れて いた。"]);
        await say(p, "アルカ十三世", ["{closed}死んだ 者の 名を 帳に 書き、行き先を 決める 王。§4エンマ§f。", "{sad}千年前、§6剣の 家§f と §6クロガネの 鍛冶§f が、あの 王を 鍔に 封じた。……狂った 王と して、な", "{up}鍔は、剣の 家が 守って おる。当主は §eカゲツ§f じゃ"]);
        big(p, "§4§l影が あふれた！", "§f封印庫から 影の モンスターが 中庭へ！", "mob.wither.spawn");
        await bye(p, eK); await goPlace(p, "court", 0, "アルカトラス城の 中庭"); eK = npcNear(p, "§6アルカ十三世", PJ("arca13", 15), true);
        const eT = npcNear(p, "§e衛兵の 子 トト", 9); act(eT, "run", false); await wait(10); act(eT, "guard");
        await say(p, "衛兵の 子 トト", ["ぼくも 戦う！ 父さんは この 城の 衛兵なんだ。……影に やられて、まだ 目を さまさない けど。"]);
        const r = await battle(p, team(["nether", "nether", "dragon"], 92, 3, 50), { name: "封印庫から あふれた 影", arena: "城下町の 夜", theme: "underworld", speaker: "影", guests: team(["beast"], 85, 1).map((t) => ({ ...t, owner: "衛兵の 子 トト" })), lines: { half: "……チョウ……ヲ……", low: "……ナヲ……カケ……" } });
        rm(eT); if (!ok(eK)) eK = npcNear(p, "§6アルカ十三世", PJ("arca13", 15), true);
        if (r !== "win") { await say(p, "アルカ十三世", ["……引け！ 体勢を 立てなおすのだ", RT(p)]); rm(eK); return false; }
        await say(p, "アルカ十三世", ["……礼を 言う。千年、見張って きた 甲斐が あった。", "封印が ゆるんで おる。鍔が 持ち主を 呼んで おるのだ。", "§e伝説の マスター§f カゲツに 会え。§7ルミナの 闘技場で 寝て おる。……勝てば、話を 聞いて くれよう"]);
        rm(eK);
        const d1 = load(p); if (d1) { qs(d1).m1 = 1; save(p, d1); }
      }
      return true;
    } },
  { r: 99, nospot: 1, ch: "魔神編", hint: "§f伝説の マスター カゲツ（裏ボス）に 勝とう §7（ルミナの 闘技場）", trig: (c) => has(c, "k_hilt") && !!c.s.hiltGot,
    run: async (p, d) => {   /* 第125版: カゲツは 鍔を 託して 眠る */
      await establish(p, p.location, "ルミナの 闘技場の 奥"); big(p, "§4§l魔神編", "§f赤黒く 光る 鍔が、持ち主を 呼んでいる", "mob.wither.spawn");
      const eK = npcNear(p, "§7カゲツ", PJ("kagetsu", 8), true); act(eK, "down");
      await wait(10); act(eK, "up"); await wait(8); act(eK, "hold");
      await say(p, "カゲツ", ["{closed,息}ふぁ……起きちまった。……魂の 帳を さがして るんだってな", "{up}千年前、おれの 先祖の §6剣の 家§f と、§6クロガネ§f の 鍛冶で、帳の 王 §4エンマ§f を その 鍔に 封じた。", "{sad,…}狂った 王だと 言われた。……ほんとうの ところは、だれも 知らねえ", "{closed}鍔の 中には、帳ごと エンマが 眠って る。帳を 開けるのは、あいつだけだ"]);
      await say(p, "カゲツ", ["{closed,息}……おれは もう 眠い。千年分の 眠気が、いっぺんに 来やがった", "{smile,…}鍔は おまえに 託す。クロガネの 弟子 §cムサシ§f を たずねろ。……あいつの 家が 打った 鍔だ", "{smile,closed}そうだ。……オルドに 伝えて くれ。§e百と 三勝§f。……そう 言えば、わかる"]);
      act(eK, "down"); sound(p, "random.fizz", 0.4); await wait(20);
      { const dk = load(p); if (dk) { qs(dk).kagetsuDead = 1; save(p, dk); } }
      await narr(p, "魔神の鍔", ["§7カゲツは 釣り竿を 握った まま、静かに 寝息を 立てはじめた。§8……もう 起きない 気が した。", "§4託された 鍔が、赤黒く 脈を 打つ……", "§e→ §fはがねの 村 §eクロガネ§f で §cムサシ§f を さがそう §7（右上の 案内）"]);
      rm(eK);
      return true;
    } },
  { r: 99, hint: "§fカゲツの 弟子 §cムサシ§f を さがそう §7（はがねの 村 クロガネに いる 武士に 話しかける）", trig: (c) => !!c.s.musashiJoin,
    spot: (p, d) => majinSpot(d), run: async (p, d) => majinMid(p, d) },
  { r: 99, hint: "§fムサシと §5閻魔の神殿§f へ 行き、魔神の鍔を 捧げよう §7（神殿の 前で ガイドブックを 使う）", trig: () => false, run: async () => false },
];
const POST = MQ.findIndex((x) => x.r === 99);
/* 第106版: 神殿へ 行く 前に 魔4〜魔6を すませる（前の 版で この 段を こえた セーブは そのまま） */
export function majinReady(d) { const s = qs(d), k = MQ.findIndex((x) => x.r === 99 && /ムサシ§f を さがそう/.test(x.hint || "")); return !!s.m6 || k < 0 || (s.mq ?? 0) > k; }
/* 第108版: 魔4（クロガネの 工房）→ 魔5（アルカトラス地方の 5つの 斬り跡を 1か所ずつ 歩いて 回る）→ 魔6（宿で 見る 悪夢）
   1回の 呼び出しで 1場面だけ。次の 場所は 右上と 足もとの「！」で 案内する */
const CRACK = [["丘の 割れ目", 30], ["川辺の 割れ目", 100], ["森の 割れ目", 170], ["谷の 割れ目", 240], ["王冠の 割れ目", 310]];
function crackPos(n) { const s0 = SP(), R = WREGIONS[0], a = CRACK[n][1] * Math.PI / 180, rr = Math.min(170, R.r * 0.55); return { x: Math.floor(s0.x + R.c[0] + Math.cos(a) * rr), z: Math.floor(s0.z + R.c[1] + Math.sin(a) * rr) }; }
function majinSpot(d) {
  const s = qs(d);
  if (!s.m4) { const t = musashiTownInfo(); if (!t || !t.pos) return null; const o = t.t && townOut(t.t.id, 0.9, "工房"); return o ? { key: "m4", x: o.x, y: null, z: o.z, nm: "クロガネの 外れの 工房", np: 1 } : null; }   /* 第122版: 噴水の 広場では なく 町外れ */
  const n = s.m5 || 0;
  if (n < CRACK.length) { const q = crackPos(n); return { key: "m5_" + n, x: q.x, y: null, z: q.z, nm: `アルカトラス地方の ${CRACK[n][0]}`, r: 6 }; }
  if (!s.m6) { let best = null; try { for (const t of TOWNS) { const q = getTown(t.id); if (!q || !q.built || !q.y) continue; const sp2 = innOf(t.id); if (!sp2) continue; if (!best) best = { key: "m6", ...sp2, nm: t.name + "（宿屋）", np: 1 }; if (t.id === "t0") { best = { key: "m6", ...sp2, nm: t.name + "（宿屋）", np: 1 }; break; } } } catch {} return best; }
  return null;
}
/* 第125版: ヒロインが まだ 戻って いない（第10章で 亡くなり、常世編の 結末を まだ 見て いない）*/
export const pgAway = (d) => { const s = qs(d); return !!(s.heroDead && !s.heroBack); };
async function majinMid(p, d) {
  if (!qs(d).m4) {   /* 魔4 クロガネの 工房（第125版: 鍔に ふれた ムサシに、はじめて エンマの 声が 宿る） */
    big(p, "§c§l開かずの 部屋", "§fクロガネの 工房に 影が 群がる", "mob.blaze.shoot");
    const eMu = npcNear(p, "§6ムサシ", PJ("musashi", 19), true);
    await say(p, "ムサシ", ["{closed}ここが うちの 工房だ。親父は 奥の 部屋を、一度も 開けなかった。", "{angry,!,up}……おい、見ろ。屋根の 上に 影が 群がって やがる。鍔に 引かれて きたんだ！"]);
    act(eMu, "guard");
    if (!wonOf(p, "m4v")) {
      await duel(p, "§c§l工房の 屋根の 上", "§fムサシと 並んで 影を 払う！", { a: "musashi", fams: ["nether", "nether"] });
      const r = await battle(p, team(["nether", "nether", "dragon"], 92, 3, 50), { name: "鍔に 群がる 影", arena: "鍛冶場の 屋根", theme: "volcano", speaker: "影", guests: [{ sid: "musashi", lv: 90, q: 1, plus: 15, owner: "ムサシ" }], lines: { half: "……ツバ……カエセ……", low: "……オウ……ガ……メザメル……" } });
      if (r !== "win") { await say(p, "ムサシ", ["{sweat,息}……くそっ、数が 多すぎる。一度 下がるぞ！", RT(p)]); rm(eMu); return false; }
      setWon(p, "m4v");
    }
    const eMa = ok(eMu) ? eMu : npcNear(p, "§6ムサシ", PJ("musashi", 19), true);
    await narr(p, "開かずの 部屋", ["§7影が 消えると、奥の 部屋の 錠が、ひとりでに 外れて いた。", "§7中には §f少女の 石像§7 と、古い 鍛冶の 覚え書き。", "§f覚え書きの 最後の 頁: §6「帳の 王を 鍔に 封ず。王の 妹 §fサヤ§6 の 石の 身は、王が 戻る 日まで、わが 家が 守る」"]);
    await say(p, "ムサシ", ["{shock,…}……うちの 家は、千年 この 子を 守って きたのか。", "{sad}エンマの 妹……サヤ。石の まま、ずっと ここに。"]);
    await say(p, "ムサシ", ["{closed}……親父が 言ってた。昔、奥の 部屋を 開けようと して 破門に なった、赤い 髪の 弟子が いたって。"]);   /* 第124版(dir#45): ヴァルカの 破門と つなぐ */
    act(eMa, "raise"); sound(p, "mob.wither.ambient", 0.5); if (ok(eMa)) { burst(p.dimension, eMa.location, "minecraft:basic_flame_particle", 10, 0.7, 1); camNear(p, eMa, 2, 1.4); await wait(12); }
    await narr(p, "鍔", ["§7ムサシが 鍔に 指を ふれた とたん、鍔が 赤黒く 燃えた。"]);
    await say(p, "ムサシ", ["{rage,…,low}§4……帰る。わが 座へ。帳を 開く 時だ。"]);
    act(eMa, "kneel");
    await say(p, "ムサシ", ["{shock,汗,jump}……っ！ 今の、俺の 声じゃ ねえ！", "{closed,息}……エンマだ。あいつ、俺の 体を 借りて、自分の 神殿へ 帰ろうと してる。", "{angry,up}上等だ。……連れてって やるよ。ただし、話は 聞かせて もらうぜ"]);
    await narr(p, "斬り跡", ["§7鍔が 見せる 景色が ある。§fアルカトラス地方に 残る、§65つの 斬り跡§f。", "§e→ §f斬り跡を たどろう §7（右上の 案内と「！」）"]);
    rm(eMa); rm(eMu);
    const d1 = load(p); if (d1) { qs(d1).m4 = 1; save(p, d1); }
    return "next";
  }
  const n = qs(d).m5 || 0;
  if (n < CRACK.length) {   /* 魔5 千年前の 斬り跡（1か所ずつ）。第125版: 帳の 王 エンマの 記憶 */
    const where = CRACK[n][0];
    big(p, `§6§l斬り跡 ${n + 1}/5`, `§f${where}に 残像が 立ち上がる`, "block.amethyst_block.chime");
    let r = "win";
    if (n === 0) {   /* 裁きの 座：帳を 狙う 亡者の 群れを、残像の エンマと 払う */
      await narr(p, where, ["§7割れ目に 触れると、千年前の 景色が 重なった。", "§7冠を かぶった 王が、大きな 帳に 名前を 書いて いる。§4魂の 帳§f だ。一人ずつ、生きて いるか 死んだかを 書き分けて いた。", "§f王の 名は §4エンマ§f。死んだ 者の 名を 記す、裁きの 王。", "§7帳を 奪おうと、亡者の 群れが 押し寄せる。……エンマが こちらに 気づいて、短く うなずいた。"]);
      r = await battle(p, team(["beast", "nether", "beast"], 90, 3, 46), { name: "帳を 狙う 亡者（千年前）", arena: where, theme: "ruins", speaker: "亡者", guests: [{ sid: "enma", lv: 80, q: 1, plus: 0, owner: "残像の エンマ" }], lines: { half: "……ナヲ……ケセ……", low: "……カエリ……タイ……" } });
    } else if (n === 1) {   /* 妹と 鍔：戦いは ない */
      await narr(p, where, ["§7川べりで、少女が 笑って いる。", "§f「兄さまの 帳に、わたしの 名前は 載らないでね。……ずっと 先まで」", "§7エンマは 照れて、帳を 閉じた。§8少女の 名は §fサヤ§8。エンマの、ただ 一人の 妹だった。"]);
      const eMu = npcNear(p, "§6ムサシ", PJ("musashi", 19)); act(eMu, "kneel");
      await say(p, "ムサシ", ["{closed,…}……工房の 石の 子だ。こんな 顔で 笑うのか"]);
      act(eMu, 0); await leave(eMu, p, 8, false);
    } else if (n === 2) {   /* 石に なった 村：石の 番兵と 戦う */
      await narr(p, where, ["§8ある 朝、サヤが 石に なって いた。", "§7村じゅうが 灰色に 止まった。§8空の 上から、§5邪神の 影§8 が 見て いた。", "§7石に なった 番兵たちが、ゆっくりと こちらを 向く――"]);
      await duel(p, "§7§l石の 番兵", "§f石に なりかけた 番兵が 動き出す！", { fams: ["golem"] });
      r = await battle(p, team(["golem", "golem", "dragon"], 92, 3, 50), { name: "石に なった 村の 番兵", arena: where, theme: "ruins", speaker: "番兵", lines: { half: "……イシニ……ナル……", low: "……アリガトウ……" } });
    } else if (n === 3) {   /* 邪神の 命令：影と 戦う */
      await narr(p, where, ["§5「石に なった 者は、死者だ。帳に 記せ」", "§7邪神の 声が、裁きの 座に 響いた。§f石の 人たちの 中には、サヤも いた。", "§4エンマは 筆を 折った。§f「石の 者は、生きて いる。§c記さぬ§f」", "§7割れ目から、命令を 運ぶ 影が あふれ出す。"]);
      r = await battle(p, team(["nether", "nether", "dragon"], 94, 3, 54), { name: "邪神の 命令の 影", arena: where, theme: "underworld", speaker: "影", lines: { half: "……シルセ……", low: "……ナゼ……サカラウ……" } });
    } else {   /* 封印：残像の エンマ（1体の 強敵） */
      await narr(p, where, ["§f邪神に 逆らった 王は、§c狂った 王§f と 呼ばれた。", "§7剣の 家の 剣士と、クロガネの 鍛冶が 来た。§8……王は、刀を 抜かなかった。", "§8エンマは 帳を 胸に 抱いた まま、自分から 鍔の 中へ 入った。", "§4残像の エンマ§7 が、最後に 一度だけ、こちらに 刀を 向けた。"]);
      await duel(p, "§4§l残像の エンマ", "§fムサシと 残像の 刀が 交わる！", { a: "musashi", b: "enma" });
      r = await battle(p, [{ sid: "enma", lv: 95, q: 1, plus: 60 }], { name: "残像の エンマ", arena: where, theme: "palace", speaker: "エンマ", hpk: 0.6, extra: 0.3, lines: { half: "……", low: "……サヤ……" } });
      if (r === "win") await narr(p, "最後の 残像", ["§8鍔の 中へ 消える 前、エンマは 一度だけ ふり返った。", "§8残像に 音は ない。口だけが、§f「待って いろ」§8 の 形に 動いて いた。"]);
    }
    if (r !== "win") return false;
    const dn = load(p); if (dn) { qs(dn).m5 = n + 1; if (n + 1 >= CRACK.length) qs(dn).m5b = 1; save(p, dn); }
    if (n + 1 < CRACK.length) { try { p.sendMessage(`§e→ §f次は §6${CRACK[n + 1][0]}§f §7（右上の 案内と「！」）`); } catch {} return "next"; }
    try { p.sendMessage("§e→ §fどこかの 町の 宿屋で 休もう §7（広場の「！」）"); } catch {}
    return "next";
  }
  if (!qs(d).m6) {   /* 魔6: 悪夢（宿で 眠ると エンマの 側から 見た 夢） */
    big(p, "§4§l悪夢", "§7宿屋の 布団で 目を 閉じると――", "mob.wither.ambient");
    await narr(p, "悪夢", ["§8……夢の 中で、自分は §4エンマ§8 だった。", "§8千年、鍔の 中は 暗かった。帳を 抱いて、ずっと 数えて いた。§7石に された 者の 数を。", "§8神殿に 来た 小さな 旅人を、一太刀で 斬った。§7……帰り道を ふさぐ 者は、だれで あっても。"]);
    await battle(p, [{ sid: "enma", lv: 100, q: 1, plus: 99 }], { name: "夢の 中の エンマ", arena: "悪夢", theme: "hell", heal: false, asked: true, speaker: "エンマ",
      scripted: { turns: 1, lines: ["§4§l国崩", "§7……一瞬で、すべてが 斬られた"] }, lines: { half: "……" } });
    await narr(p, "目覚め", ["§7目が 覚めると、ムサシが 鍔を にらんで 座って いた。", "§cムサシ§f「……あいつ、ずっと 待ってたんだな。妹が 戻る 日を」", "§f……§5閻魔の神殿§f へ 行こう。鍔を 捧げる 時だ。§7（神殿の 前で ガイドブックを 使う）"]);
    const d1 = load(p); if (d1) { qs(d1).m6 = 1; save(p, d1); }
  }
  return true;
}
/* 第125版: 終章に 入ったか（第11章 レイとの 勝負の あと）。せいかんカップと 終章の はじめの 場面は ここから */
export function finaleOn(d) { const s = qs(d); return !!s.ending || (POST >= 0 && (s.mq ?? 0) >= POST); }
/* 第125版: カップの あとの 旅の 仲間の ひとこと（闘技場を 開いた 人の 伏線）。亡くなって いる あいだは 出さない */
const CUPH = {
  0: V(["わたし、あの 像の 人、ちょっと 気に なる。名前、なんで 削れちゃったんだろ？"], ["像の 人の お名前……すり減って しまって、さびしいわね。"], ["像の 名前だけ、きれいに すり減ってる。……風の せいとは 思えない。"], ["像の お名前だけ 読めないのは……少し、ふしぎですね。"]),
  2: V(["すべての 杯を 勝ちぬいた 者だけ、かあ。……わたしたちで、開けちゃおうよ！"], ["扉が 開く 人を、最初から 決めて あるのね。……まるで、だれかを 待って いるみたい。"], ["掟で 扉の 相手を 決めてる。……奥に、守りたい ものが あるんだ。"], ["掟で 扉を 守るなんて……奥に、よほど 大切な ものが あるのでしょうね。"]),
  5: V(["賞品が 石板って、変だよね？ 石板を 封じられる 人に、わざと 渡してる みたい。"], ["石板を 賞品に した 人……だれかに、封じて ほしかったのかしら。"], ["封じられる 者に 石板を 渡す 仕組み。……作った 人は、知ってたんだ。"], ["石板を 封じられる 方に、わざと 届けて いるような……そんな 気が します。"]),
};
export function cupHero(d, ci) { try { const L = CUPH[ci]; if (!L || !d || heroAway(d)) return []; const h = HEROES.find((x) => x[0] === qs(d).hero); if (!h) return []; return (L[HT[h[0]] || "g"] || L.g).map((x) => `§d${h[1]}§f「${x}」`); } catch { return []; } }
/* 第122版: 闘技場の 最後の カップ（仮面の 王者 → オルド）と 星冠王の 場面。story.js から 呼ぶ。
   k: "mask"（決勝の 前）・"ordoWin"（オルドに 勝った あと）・"zeph0"（星冠王の 前）・"zeph1"（星冠王に 勝った あと）
   返り値: "ordo"（仮面を 取った）・"mask"（仮面の まま）・true */
/* 第125版: 世界の 依頼を 済ませた 人だけの 一言（c が 偽なら 何も しない）。nl: 地の文 / e・who・sl: 話す 人 */
async function wlSay(p, c, nm, nl, e, who, sl) { if (!c) return; if (nl && nl.length) await narr(p, nm, nl); if (who && sl) { if (ok(e)) { camNear(p, e, 1.8, 1.5); await wait(6); } await say(p, who, sl); } }
/* 第125版: 終章の はじめ。封じた 石板が ルミナの 闘技場へ 向かって 鳴る（なぜ 闘技場か・なぜ 今か）→ 暗転して 闘技場の 前へ */
function arenaQ() { try { const nm = "ルミナの 闘技場", q = spotOf("t0", "plaza"); if (q) return { x: Math.floor(q.x), y: q.y, z: Math.floor(q.z), nm }; const t = TOWNS.find((u) => u.id === "t0"), tp = t ? townPos(t) : null; return tp ? { x: Math.floor(tp.x), y: null, z: Math.floor(tp.z), nm } : null; } catch { return null; } }
async function finTurn(p) {
  const l = p.location, t = TOWNS.find((u) => u.id === "t0"), tp = t ? townPos(t) : null, dx = tp ? tp.x - l.x : 0, dz = tp ? tp.z - l.z : 1, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n, q = { x: l.x + ux * 9, y: l.y + 2.5, z: l.z + uz * 9 };
  { const b = fwd(p, 1.5, 0, 1.2); if (b) { camPt(p, b, 2.5, 0.6); burst(p.dimension, b, "minecraft:totem_particle", 8, 0.6, 0.3); } sound(p, "block.amethyst_block.chime", 1); await wait(12); }
  await narr(p, "石板の 光", ["§7かばんの 中で、封じた 石板が いっせいに 鳴りだした。", "§7細い 光が より集まって、一本の 線に なる。"]);
  camAt(p, { x: l.x - ux * 3, y: l.y + 2.4, z: l.z - uz * 3 }, q, 1.4); burst(p.dimension, q, "minecraft:totem_particle", 10, 1.2, 0.3); await wait(14);
  await narr(p, "石板の 光", [n < 160 ? "§7光の 先は、すぐ そこ。……始まりの 町 §eルミナ§7 の §e闘技場§7 だ。" : "§7光の 先は、始まりの 町 §eルミナ§7。……町の §e闘技場§7 だ。", "§8地面の ずっと 深くから、同じ 音が 返って くる。"]);
  { const b = fwd(p, 2, 0, 0.6); if (b) { camPt(p, b, 3.5, 1.6, 1); await wait(10); } }
  await narr(p, "石板の 光", ["§7……王冠の 石板が、目を さまそうと して いる。セオが 沈んだ、あの 石板が。", "§f今、行かなければ。"]);
  await sceneAt(p, arenaQ(), "ルミナの 闘技場");
}
export async function cupScene(p, k) {
  const d = load(p); if (!d) return true; const s = qs(d);
  const H = heroBox(p, true), L = [];
  const N = (nm, job, q) => { const e = q ? npcAt(p, nm, job, q) : npcNear(p, nm, job, true); L.push(e); return e; };
  let out = true;
  try {
    if (k === "intro" || k === "turn") {   /* 第125版: 終章の はじめ。なぜ 闘技場を 勝ちあがるのか（オルドは 創設者の 名を 言わない。知れば 余計な ものまで 知る）。turn: 物語の 段から（石板が 鳴る → 闘技場へ 移る）*/
      if (k === "turn") {
        await finTurn(p);
        const c1 = N("§7観客の 子", 9, fwd(p, 5, -3.5)), c2 = N("§7観客の 父さん", 9, fwd(p, 6, -2.2));   /* 観客が 歩いて 入って くる */
        if (ok(c1)) { camNear(p, c1, 3.2, 1.4); await wait(10); }
        sound(p, "random.levelup", 0.3);
        await narr(p, "ルミナの 闘技場", ["§7中から、だれかの 名を 呼ぶ 声が 三度。……§fわっと、歓声が わいた。", "§7観客の 子「はやく はやく！ 次の 試合、始まっちゃう！」"]);
        { const q = fwd(p, 8, 1.5, 2); if (q) camPt(p, q, 7, 1.5, 1.2); }
        await Promise.all([leave(c1, p, 10, true), leave(c2, p, 10, false)]); rm(c1); rm(c2);
      }
      const eO = N("§eオルド", PJ("ordo", 8), fwd(p, 6)), eR = N("§bレイ", RIVAL_JOB, fwd(p, 3, 2.4));
      if (k === "intro") big(p, "§6§l終章 歴史再び", "§f闘技場の 受付の 前で、長老が 待って いた", "random.orb");
      if (ok(eO)) { const q = fwd(p, 3.2); camNear(p, eO, 3, 1.2); if (q) await go(eO, q, 16); }
      await say(p, "オルド", ["{closed}……来たか。セオは 王冠の 石板の 中じゃ。ラグナで、影ごと 沈むのを この目で 見た。", "{closed}王冠の 石板は、この 闘技場の 下に 眠って おる。奥の 王座が、その 扉を 守って おるんじゃ。"]);
      if (ok(eO)) { camNear(p, eO, 1.8, 1.5); await wait(8); }
      await say(p, "オルド", [k === "turn" ? "{sad}石板が 鳴ったじゃろう。……王冠が、目を さましかけて おる。" : "{sad}……地の 底で、王冠が 目を さましかけて おる。", "{closed}影が セオの 中で 育ち きれば、封印は 内から 割れる。……そう なれば、石に なるのは 一つの 町では すまん。"]);   /* 第125版: なぜ 今か */
      if (wl(s, "wq1e")) { await narr(p, "森の 守り歌", ["§7ルミエの 守り歌が 頭に うかんだ。§f『王冠が 静まるまで、起こしては ならぬ』"]); if (ok(eO)) { camNear(p, eO, 2, 1.4); await wait(6); } await say(p, "オルド", ["{closed}……森の 守り歌か。よう 覚えて おったな。", "{closed}その 王冠じゃ。歌が 残るほど 昔から、ここで 眠って おる。"]); }   /* 第125版: 世界の 依頼「森の 守り歌」を 済ませた 人だけ */
      { const dq = fwd(p, 8, 0, 2); if (dq) { camPt(p, dq, 5, 1.2); burst(p.dimension, dq, "minecraft:totem_particle", 6, 1, 0.4); await wait(12); } }
      await say(p, "オルド", ["{up}まだ 封じて いない 石板の うち 四枚は、カップの 優勝の 賞品と して、ここに 置かれて おる。"]);
      re(eR, "closed", "?"); await say(p, "レイ", ["{closed}……カップを 全部、だろ。前に じいちゃんに 聞いた。……けど、なんで 闘技場の 掟が、王冠の 扉に かかってんだ。"]);
      if (ok(eO)) { camNear(p, eO, 1.8, 1.5); await wait(8); }
      await say(p, "オルド", ["{sad}力ずくでは 開かん。入口の 掟を 見たじゃろう。§e『王座の 扉は、すべての 杯を 勝ちぬいた 者にだけ 開く』§f", "{closed}掟は、この 闘技場を 開いた 男が、扉 そのものに かけた。……力ずくでは、だれも 通れん。わしでも、王でもな。"]);
      re(eR, "angry", "!"); await say(p, "レイ", ["{angry,up}……だれなんだよ、その 男。"]);
      if (ok(eO)) { camNear(p, eO, 1.6, 1.6); await wait(8); }
      await say(p, "オルド", ["{closed,…}……それは、王座の 前で 本人に 聞け。わしの 口から 言えば、余計な ものまで 知る ことに なる。", "{up}カップを ぜんぶ 勝ちぬけ。決勝には、二十年 闘技場を 守って きた 王者が おる。"]);
      if (ok(eR)) { camNear(p, eR, 1.8, 1.4); await wait(6); }
      await say(p, "レイ", ["{?}……じいちゃん、やけに くわしいな。"]);
      await say(p, "オルド", ["{sweat,汗}……ほっほ。年寄りは 物知りなんじゃ。", "§7→ 闘技場の カップを ぜんぶ 勝ちぬき、§c星冠の 王座§7 の 扉を 開こう"]);
      { const d1 = load(p); if (d1) { qs(d1).finIntro = 1; save(p, d1); } }
      return true;
    }
    if (k === "mask") {
      const eO = N("§7仮面の 王者", PJ("ordo", 8), fwd(p, 6));
      big(p, "§6§lけっしょう", "§f反対側の 門から、仮面の 人影が 歩いて くる", "raid.horn");
      if (ok(eO)) { const q = fwd(p, 4); camNear(p, eO, 3, 1.2); if (q) await go(eO, q, 18); }   /* つえを ついて、腰が 少し 曲がって いる */
      if (!(s.hakuStone || s.ending)) {   /* 第10章より 前は 仮面の まま 何も 言わない */
        re(eO, "closed", "…");
        await hsay(p, V(["{?,up}……あの 歩き方、どこかで……？"], ["{?,up}……あの 歩き方、どこかで……？"], ["{?,up}……あの 歩き方。どこかで。"], ["{?,up}……あの 歩き方、どこかで……？"]));
        return (out = "mask");
      }
      if (s.ordoMask) { await say(p, "オルド", ["{smile}ほっほ。また 来たか。……手加減は せんぞ。"]); return (out = "ordo"); }
      const eR = N("§bレイ", RIVAL_JOB, fwd(p, 2.5, 2.4));   /* 第125版: 旅の 仲間の かわりに レイが 付き添う */
      if (ok(eO)) { camNear(p, eO, 1.6, 1.6); await wait(16); }
      act(eO, "raise"); flash(p, true); sound(p, "random.orb", 1);   /* 仮面に 手を かけて、はずす */
      try { if (ok(eO)) eO.nameTag = "§eオルド"; } catch {}
      act(eO, 0);
      await say(p, "オルド", ["{smile,up}……ほっほ。待たせたのう。"]);
      re(eR, "shock", "!");
      await say(p, "レイ", ["{shock,!,up}……じいちゃん！？ 腰、痛いんじゃ なかったのかよ！"]);
      await say(p, "オルド", ["{smile,汗}痛いとも。……ほっほ。"]);
      sound(p, "random.levelup", 0.4); burst(p.dimension, p.location, "minecraft:villager_happy", 10, 6, 1.5);   /* 観客席が どっと わく */
      /* オルドの 後ろに 並んだ 子たち。ハクは いない */
      const g1 = monEnt(p, fwd(p, 5, -1.5), "nbea003", ""), g2 = monEnt(p, fwd(p, 5.5, 1.5), "nbea036", "");
      if (ok(g1)) { camNear(p, g1, 3, 0.8); await wait(14); }
      await say(p, "レイ", ["{sad,…}……ハク なしで、まだ 戦うのか。"]);
      rmCine(g1); rmCine(g2);
      await say(p, "オルド", ["{closed}わしの 戦いは、ラグナで 終わった。じゃから、これは わしの 戦いでは ない。ハクの あとに 育てた、この 子たちの 戦いじゃ。", "{up}大事な ものを 失っても、前には 進める。……それを、王冠の 石板へ 行く 前の おまえさんに 見せて おきたかった。", "{smile,!}それが、わしの 最後の 仕事じゃ。"]);
      const d1 = load(p); if (d1) { qs(d1).ordoMask = 1; save(p, d1); }
      return (out = "ordo");
    }
    if (k === "ordoWin") {
      const eO = N("§eオルド", PJ("ordo", 8), fwd(p, 3.5)), eR = N("§bレイ", RIVAL_JOB, fwd(p, 3, 2.4)); act(eO, "kneel");
      await say(p, "オルド", ["{smile,…}……ほっほ。二十年ぶりに、負けたわい。"]);
      act(eO, 0);
      fadeOn(p, "0.3 0.6 0.6", "0 0 0", true); await wait(14);
      big(p, "§6§l闘技場の いちばん 奥", "§f重い 扉の 前で", "random.door_close");
      const dq = fwd(p, 7, 0, 1.5); if (dq) { camPt(p, dq, 5, 1); burst(p.dimension, dq, "minecraft:totem_particle", 8, 1.2, 0.5); await wait(14); }
      await say(p, "オルド", ["{closed}わしと、友の ゼファードは、王を 終わらせる ために 王冠の 石板に 入った。", "{sad}……わしは、途中で 引き返した。ハクが 影に 深手を 負わされてな。", "{closed}ハクを 連れて 戻るか、置いて 先へ 行くか。……わしは 戻る 方を 選んだ。"]);
      await say(p, "レイ", ["{sad,?}……ゼファードさんは？"]);
      await say(p, "オルド", ["{closed,up}一人で 残った。そして、最後の 封印者に なった。……二十年、あいつは あそこで、一人で 王を 押さえて おる。", "{angry,low}旅立ちの 日、ガロの 名乗った『§5六影§f』の 名に、わしが 怒った わけも 話そう。……あれは、わしの 親友が 背負った 名じゃ。", "{sad}知る ことの 怖さを、わしは あの 日 石板の 中で 知った。……じゃから、おまえさんたちには 何も 話せなんだ。"]);
      if (wl(s, "wq0e")) { await narr(p, "星の 地図", ["§7ハンナの 店の 箱の、星の 地図を 思い出した。§f「オルド」§7の 横の、指で こすって 消された 名前。"]); if (ok(eO)) { camNear(p, eO, 1.8, 1.5); await wait(6); } await say(p, "オルド", ["{sweat,汗}……ノルの やつ、しゃべりおったな。", "{closed}消したのは、あやつ 本人じゃ。名を 残すのを、だれより いやがる 男でな。"]); }   /* 第125版: 世界の 依頼「ふたりの 旅の 箱」を 済ませた 人だけ */
      await say(p, "オルド", ["{closed}……あやつが 闘技場を 去った 日から、わしは 仮面を つけて 決勝に 立った。", "{sad}杯が 止まれば、扉の 前に 立つ 者が いなく なる。……理由は 聞かなんだ。聞けば、わしも 知って しまうからの。"]);   /* 第125版: 仮面の 王者の わけ */
      if (ok(eR) && ok(eO)) { const l = eO.location; await go(eR, { x: l.x + 0.7, y: l.y, z: l.z + 0.7 }, 8); act(eR, "raise"); sound(p, "random.pop", 1); }   /* 腰を ちょっとだけ 強く たたく */
      await say(p, "オルド", ["{sweat,汗}いたたた。……ほっほ。", "§7→ 闘技場の 奥の 扉（星冠の 王座）へ"]);
      act(eR, 0);
      return true;
    }
    if (k === "zeph0") {
      const eZ = N("§c星冠王 ゼファード", PJ("zephard", 8), fwd(p, 5)), eR = N("§bレイ", RIVAL_JOB, fwd(p, 2.5, 2.4)); act(eZ, "kneel");   /* 玉座に 座った まま。足もとは もう 半分 石 */
      if (ok(eZ)) { burst(p.dimension, eZ.location, "minecraft:white_smoke_particle", 6, 0.6, 0.1); camNear(p, eZ, 2.6, 1.2); await wait(14); }
      { const mq = fwd(p, 7.5, -3.2, 1.4); if (mq) { if (!fading(p)) fadeOn(p, "0 0.2 0.5", "0 0 0", true); camAt(p, { x: mq.x + 2.6, y: mq.y + 1.2, z: mq.z + 1.6 }, mq, 0); await wait(4); camAt(p, { x: mq.x + 1.4, y: mq.y + 0.6, z: mq.z + 0.9 }, mq, 1.6); await wait(10); }   /* 第125版: 玉座の 間の 壁画（ゆっくり 寄る）*/
        await narr(p, "玉座の 間の 壁画", ["§7玉座の 後ろの 壁に、古い 壁画。§f十五の 小さな 台座§7 が、王冠を かこんで 並んで いる。", "§8……台座の 上は、どれも 空っぽに 描かれて いた。"]); }
      if (ok(eZ)) { camNear(p, eZ, 2.6, 1.2); await wait(8); }
      big(p, "§6§l星冠王 ゼファード", "§7闘技場の いちばん 奥、星冠の 王座の 主", "random.orb");   /* 第124版(dir#33): ここでは 六影の 名乗りに しない（首領の 名乗りは 戦いの あと）*/
      await say(p, "ゼファード", ["{closed,low}……杯の 勝者が 扉を 開けた。その 一刻だけ、わたしは 石板の 縁まで 出て 来られる。"]);
      if (ok(eZ)) { camNear(p, eZ, 2.2, 1.4); await wait(6); }
      await say(p, "ゼファード", ["{closed,low}……来たか。石板が 選んだ マスターよ。", "{smile,up}……オルドは 元気か。"]);
      await say(p, "レイ", ["{closed}……元気すぎるよ。腰が 痛いって 言いながら、闘技場で 暴れてた。"]);
      sound(p, "random.orb", 0.5);
      await say(p, "ゼファード", ["{smile}……ふ、ははは。二十年ぶりに、声を 立てて 笑った。"]);
      if (ok(eZ)) { camNear(p, eZ, 1.8, 1.5); await wait(8); }
      await say(p, "ゼファード", ["{closed}……三十五年前、わたしは この 闘技場を 開いた。", "{up}八つの 杯を 勝ちぬき、相棒と ここまで 来た 者は、おまえが 初めてだ。", "{angry,up}王座で 見せて もらう。おまえと 相棒が、§e六本目の 鍵§f に なれるか。"]);   /* 第125版: 星冠王＝闘技場を 開いた 人 */
      return true;
    }
    if (k === "zeph1") {
      /* 第125版: 王冠の 石板の 前で、首領 ゼファードが 六影の 正体と 千年前の 真相を 話す。影が セオの 中に 縛られて いる 今だけは、知っても 宿られない */
      const eZ = N("§c星冠王 ゼファード", PJ("zephard", 8), fwd(p, 4)), eR = N("§bレイ", RIVAL_JOB, fwd(p, 2.5, 2.4)); act(eZ, "kneel");
      await say(p, "ゼファード", ["{closed}……負けた、のか。この わたしが。", "{smile,up}……いや。おまえと 相棒なら、六本目の 鍵に なれる。"]);
      act(eZ, 0);
      await say(p, "ゼファード", ["{closed,low}……もう、隠す 意味も ない。影は あの 学者の 声で、世界じゅうに 読み聞かせた。", "{up}……だが おまえと 相棒には、絆と いう 盾が ある。話そう。"]);
      await sixMark(p, eZ, "zeph");   /* 第124版(dir#33): 首領の 名乗りは ここ */
      await say(p, "ゼファード", ["{closed}……六影を 作ったのは、わたしだ。"]);
      re(eR, "shock", "!"); await say(p, "レイ", ["{shock,!,up}……六影の、首領……！？"]);
      if (ok(eZ)) { camNear(p, eZ, 2, 1.5); await wait(10); }
      await say(p, "ゼファード", ["{closed}千年前、王 §6ヴァルグレイド§f は、邪神を 倒す ために、影の 鍵と 王冠の 石板の すべてを 調べつくした。", "{sad}いちばん 多くを 知った 王に、§4影が 宿った§f。王は 厄王と なり、人を 石に 変えはじめた。"]);
      await wlSay(p, wl(s, "wq9c"), "霧の 道しるべ", ["§7ラグナの 霧の 道しるべの 字が 頭に うかんだ。§f『聞こえた 声を 忘れるな』§7……竜の 声が 言って いたのは、この ことだった。"]);   /* 第125版: 世界の 依頼「霧の 案内」*/
      await say(p, "ゼファード", ["{closed}王の 親友、§5初代の 影 アルディス§f が、自分の 手で 王を 討ち、王冠の 石板に 封じた。", "{closed}鍵は 六つに 分けて、六人の 仲間で 守った。……それが、最初の 六影だ。"]);
      await say(p, "ゼファード", ["{sad,low}人々は アルディスを『王殺しの 裏切り者』と 呼び、壁画から 名を 削った。", "{sad}アルディスは 弁明せず、記録だけを 残した。"]);
      await wlSay(p, wl(s, "wq2a"), "王殺しの 墓", ["§7セプルクの 外れの、名を 削られた 墓が 頭に うかんだ。土の 中の 石板の 一文。§f『弁明は しない。記録だけを 残す』"], eZ, "ゼファード", ["{closed,…}……あの 墓まで 行ったか。", "{sad,low}王殺しと 呼ばれても、記録だけは 残した。……あれが、最初の 影だ。"]);   /* 第125版: 世界の 依頼「名の ない 墓」*/
      if (ok(eZ)) await memory(p, eZ, "廃都の 壁画", ["§7王の すぐ 隣、削り取られた 影の 跡。", "§7……そこに いたのは、王を 止めた 友だった。"]);   /* 第124版(dir#9,35): 絵を はさむ */
      if (ok(eR)) { camNear(p, eR, 1.6, 1.5); re(eR, "shock", "…"); await wait(12); }   /* 第124版(fix2): 長い 説明の 間に 聞く 人の 無言の 反応 */
      if (ok(eZ)) await memory(p, eZ, "手帳の 写し", ["§7あの子が 写した、削られた 影の 形……", "§7……ゼファードの 外套の 影と、同じ 形だった。"]);
      await say(p, "ゼファード", ["{closed}そして 掟を 作った。§e真実は 六つに 分け、一人に 一つずつ§f。だれも 全部は 知らない。", "{closed}鍵を 身に つけて いれば、影は 入れない。……全部を 知る わたしは、石板の 中に いるから 影が 届かなかった。"]);
      await say(p, "レイ", ["{closed}……あいつの 読みが、当たって たのか。『主じゃ なくて、王の 隣の だれか』って。"]);
      await say(p, "ゼファード", ["{closed}千年たって 封印が ゆるみ、二十年前から また 人が 石に なりはじめた。", "{sad}わたしは 各地の 王に 警告して 回ったが、誰も 信じなかった。王冠を 狙う 反逆者と して 追われた。"]);
      await wlSay(p, wl(s, "wq0d") || wl(s, "wq4c"), "二十年前の 男", [...(wl(s, "wq0d") ? ["§7ポカラの 書記の 日誌。『あの 目は、うそを つく 目では なかった』"] : []), ...(wl(s, "wq4c") ? ["§7ソーラの 老兵の 槍。『王を 責めるな。信じられぬのは、王が 悪いのでは ない』"] : []), "§7……どちらも、この 人の 話だった。"], eZ, "ゼファード", wl(s, "wq4c") ? ["{closed,…}……あの 老兵は、追い出す とき 目を そらさなかった。……いい 兵だ。"] : null);   /* 第125版: 世界の 依頼「老書記の 日誌」「老兵の 槍」*/
      await say(p, "ゼファード", ["{up}だから わたしは 石板に 入って 王を 押さえ、外で 鍵を 集める ために 六影を 作り直した。", "{sad}影は 知った 者に 宿る。だから 下っぱには 何も 教えず、騒がしい 下っぱを あえて 止めずに、影の 目を そらす 囮に した。"]);
      await say(p, "ゼファード", ["{sad}……人が 困って いるのを 知って いてな。その 責めは、わたしが 負う。"]);
      /* 第125版: 闘技場を 開いた わけ（杯は 六本目の 鍵を 探す ふるい）*/
      { const S = stageOf(p); if (S) { camAt(p, S.at(-6, 3.5 * S.side, 4.5), S.at(4, 0, 1.2), 0.8); await wait(14); } }
      await say(p, "ゼファード", ["{closed}……この 闘技場も、その ために 作った。", "{closed}三十五年前、オルドとの 旅から 戻った わたしは、王冠の 石板が 眠る この 地の 上に、闘技場を 開いた。"]);
      if (ok(eZ)) { camNear(p, eZ, 2.2, 1.3); await wait(8); }
      await say(p, "ゼファード", ["{up}六本目の 鍵は、鍵を 持たず、相棒と 絆を 結んだ 者。……だが、どこに いるかは わからぬ。", "{closed}だから 杯を 作った。§e杯は ふるいだ§f。相棒との 絆が いちばん 強い 者だけが、最後に 王座の 前に 残る。"]);
      { const S = stageOf(p); if (S) { camAt(p, S.at(-4, -3 * S.side, 3), S.at(5, 0, 2), 1); await wait(10); } }   /* 第125版: 歓声は 蓋 */
      await say(p, "ゼファード", ["{closed}もう 一つ。掟の 前半を 覚えて いるか。§e名乗りは 三度。勝った 者の 名は、客席の みんなで 呼ぶ§f。", "{up}名を 呼ぶ 声には、影は 宿れぬ。毎日 何千もの 声が、王冠の 真上で 名を 呼ぶ。……§eその 歓声が、封印の 蓋§f だ。"]);
      if (ok(eZ)) { camNear(p, eZ, 1.7, 1.5); await wait(8); }
      await say(p, "ゼファード", ["{closed,low}わたしは、剣より 声を 信じた。"]);
      if (ok(eZ)) { camNear(p, eZ, 2, 1.4); await wait(8); }
      await say(p, "ゼファード", ["{closed}『王座の 扉は、すべての 杯を 勝ちぬいた 者にだけ 開く』。……あれは、王冠の 石板の 扉に かけた 錠だ。ふさわしくない 者を、王冠に 近づけぬ ための。", "{up}賞品の 四枚の 石板も、わたしが 置いた。六本目の 鍵が、勝ちあがる 道すがら 封じて ゆける ように。"]);
      re(eR, "shock", "…"); await say(p, "レイ", ["{shock,…,up}……入口の 石像。名前が すり減ってた あれ……あんた だったのか。"]);
      await say(p, "ゼファード", ["{closed}名は、わたしが 削った。王に 追われる 者の 名を、子らの 闘技場に 残せぬ。", "{sad,low}……人の 名を 呼ばせる 場所を 作って、自分の 名だけは、だれにも 呼ばれぬ 所に 置いた。"]);
      if (ok(eZ)) { camNear(p, eZ, 1.6, 1.2); await wait(8); }
      await say(p, "ゼファード", ["{sad,low}……王墓の 壁の 字を 消そうと したのも、わたしだ。§e永遠を 願うな。願いは 石に なる§f。……あれを 読めば、だれでも 願って しまう。"]);   /* 第125版(H2) */
      if (ok(eZ)) { camNear(p, eZ, 1.9, 1.4); await wait(8); }
      await say(p, "ゼファード", ["{sad}二十年前、わたしが 石板に 入ってから、オルドは 仮面を つけて 決勝に 立ち つづけた。……杯を 止めぬ ために。理由も 聞かずに な。"]);
      if (ok(eR)) { camNear(p, eR, 1.6, 1.5); re(eR, "sad"); await wait(10); }
      await say(p, "レイ", ["{sad,up}……じいちゃん、腰が 痛いって 言いながら、ずっと……。"]);
      if (ok(eZ)) { camNear(p, eZ, 1.8, 1.4); await wait(8); }
      await say(p, "ゼファード", ["{closed,up}石板の 中から、王座の 窓ごしに、二十年、杯を 勝ちあがる 子らを 見て いた。……おまえが ひよっこカップに 出た 日も。", "{smile}跡を 継げる 者を、ずっと 待って いたのだ。"]);
      await say(p, "ゼファード", ["{sad,low}そして セオは、読んだ ものを 何も 忘れない 子だった。", "{sad,low}参謀として 五人の 記録を まとめる うちに、六つの うち 五つまで 知って しまった。"]);
      if (ok(eR)) { camNear(p, eR, 1.6, 1.5); re(eR, "sad"); await wait(12); }
      if (ok(eZ)) await memory(p, eZ, "破れた 頁", ["§7セオの 手帳の、破りとられた 頁の 跡。", "§7……五人分の 記録の 写しが、細かい 字で ぎっしりと 並んで いた。"]);
      await say(p, "ゼファード", ["{sad}家族を 早く 取り戻したくて、掟を 破り、最後の 記録を 手帳に 写した。", "{sad}セオは 鍵を 六本 祭壇に はめた 一瞬、盾の ない まま 全部を 知った、ただ 一人に なった。"]);
      await say(p, "レイ", ["{angry,up}……歴史の、くり返し かよ。"]);
      await say(p, "ゼファード", ["{closed}……鍵を 持つ 者たちを、呼んで おいた。"]);   /* 第125版(F4) */
      big(p, "§5§l六 影", "§f炎の 女、手を つないだ 双子、白い 仮面の 戦士が 歩いて くる", "mob.blaze.shoot");
      const W = (nm, job) => { const e = npcNear(p, nm, job); L.push(e); return e; };
      const eV = W("§c六影 三の座 ヴァルカ", PJ("valka", 10)), eRo = W("§9六影 四の座 ロウ", PJ("rou", 10)), eRu = W("§d六影 五の座 ルウ", PJ("ruu", 10)), eA = W("§4六影 六の座 アルゴ", PJ("argo", 10));
      act(eRo, "hold"); act(eRu, "hold");
      await say(p, "ヴァルカ", ["{smile,low}……アタシの §e試し§f は、まだ 終わって なかったのさ。", "{closed}アタシの 鍵は、鍛冶の 火。祭壇から 拾って、開かずの 部屋の 型で 打ちなおして きたよ。"]);
      await wlSay(p, wl(s, "wq3c"), "", [], eV, "ヴァルカ", ["{smile,low}……槌を 振るのは、ラヴィの ザクにも 手伝わせた。残りの 台座を 断った 腕だ。迷いの ない 鉄を 打つよ。"]);   /* 第125版: 世界の 依頼「ザクの つぐない」*/
      await say(p, "ロウ", ["{closed}ボクたちの 鍵は、二人で 一つだよ。"]);
      await say(p, "ロウ", ["{smile,up}……ボク、目を さました。ルウが、ずっと 呼んで くれてた。"]);
      await say(p, "アルゴ", ["{closed,low}……王の 影を 斬れる 刃。鍵は ここに ある。", "……だが、学者を 斬るのは、我では ない。"]);
      await say(p, "ゼファード", ["{closed}鍵は 五本。ヴァルカの 火、双子の 二つの 手、アルゴの 刃、そして わたしの 王冠。……おまえと 相棒で 六本。", "{closed}……王冠の 石板の 奥へ、道が 開く。", "{sad}セオは 王を 取りこんで、石板の 奥に いる。……止めて やって くれ。友として。", "{closed,up}わたしは 先に 石板へ 戻る。最後の 封印は、わたしが 持つ。……オルドに 伝えて くれ。『おまえの 弟子は、よい 子だ』と。"]);
      /* 第125版: 六影 一人ひとりの「捨てられない もの」 */
      const breath = async () => { const S = stageOf(p); if (S) camAt(p, S.at(-7, 4.5 * S.side, 5.5), S.at(3, 0, 1), 0.8); await wait(36); };   /* 第124版(dir#37): 山場の 間に 引きの 絵と 音の ない 間 */
      act(eV, "hold"); await memory(p, eV, "父の 刀", ["§7ヴァルカが 布を ほどく。§f結びを 打てない まま だった 父の 最後の 刀§7。", "§7影に 飲まれた 父が 打った 刀で、村が 一つ 滅んだ。……その 刀を、娘が 打ちなおした。"]);
      await say(p, "ヴァルカ", ["{closed,low}……ベリルに 言っときな。座に 名が 載ったら、影に 読まれる。アタシなりの、精いっぱい だったんだって。"]);   /* 第125版 Q21 */
      await say(p, "ヴァルカ", ["{closed}……鍵は、打ち直せた。結びは、まだだ。", "{sad,up}……でも、これは アンタには やらない。§eいつか、あの 坊やに§f。……謝るのは、その ときだ。"]);
      await wlSay(p, wl(s, "wq3b"), "焼けた 村の 木槌", ["§7あなたは 伝えた。§f「ススの ヨネ婆さんが、焼けた 村の 小さな 木槌を あずかってる」"], eV, "ヴァルカ", ["{closed,…}……そうかい。それも、あの 坊やに 渡して やる。"]);   /* 第125版: 世界の 依頼「焼けた 村の 木槌」*/
      if (ok(eV)) { camNear(p, eV, 2.2, 1.3); await wait(8); }
      await say(p, "ヴァルカ", ["{smile,up}アンタには こっち。……影を 斬る 方の 刀だ。"]);
      await wlSay(p, wl(s, "wq3d"), "クロガネの 槌", ["§7あなたは 伝えた。§f「カッパーの 宿の リンが、クロガネの 槌を あずかって 待ってる」"], eV, "ヴァルカ", ["{smile,…}……また 来るって 言ったからね。嘘は つかないさ。"]);   /* 第125版: 世界の 依頼「赤い 外套の 忘れもの」*/
      await breath();
      { const dg = load(p); if (dg && qs(dg).glove) { act(eRu, "hold"); camNear(p, eRu, 2, 1.3); await narr(p, "手袋", ["§7あなたは 雪山で 拾った、右手の 手袋を ルウに 返した。"]); await say(p, "ルウ", ["{shock,…}……あ。", "{smile,tears,up}……うれしい。……兄ちゃんの 編み目だ。"]); await say(p, "ロウ", ["{smile}……ルウが 泣いて 笑うの、はじめて 見た。"]);
        await narr(p, "手袋", ["§7あなたは 二人に 伝えた。§f「サンダの 雷祭りの やぐらで、兄ちゃんが 待ってる」"]); if (ok(eRo)) { camNear(p, eRo, 1.8, 1.4); await wait(8); }
        await say(p, "ロウ", ["{shock,…,up}……兄ちゃん。……白い 手袋を 編んで くれた、兄ちゃん。……覚えてる。"]); await say(p, "ルウ", ["{cry,tears,up}……会いたい。……会いに 行くんだもん。"]); } }
      await wlSay(p, wl(s, "wq8c"), "左右の 手袋", ["§7あなたは 伝えた。§f「サンダの アミ婆が、右と 左、同じ 目で 新しい 手袋を 編んで 待ってる」"], eRu, "ルウ", ["{smile,tears}……二つで 一つ、だもん。"]);   /* 第125版: 世界の 依頼「左右の 手袋」*/
      await breath();
      act(eA, "up"); if (ok(eA)) { camNear(p, eA, 1.8, 1.6); sound(p, "random.glass", 0.5); await wait(14); }
      await narr(p, "割れた 仮面", ["§7アルゴは レイの 方へ 向きなおり、割れた 仮面を 一度だけ 下ろした。"]);   /* 第125版: 仮面の 下は 見せず、見た 人の 顔で 伝える */
      if (ok(eR)) { camNear(p, eR, 1.6, 1.5); re(eR, "shock", "!"); await wait(10); }
      await say(p, "レイ", ["{shock,…}……その 傷。焼けて、紋の 形に なってる。", "{sad,low}冥府の 城の 旗と、同じ 紋だ。……冥王の 妃の。"]);
      act(eA, 0); if (ok(eA)) { camNear(p, eA, 2, 1.3); await wait(8); }
      await narr(p, "割れた 仮面", ["§7アルゴは 仮面を 戻した。……グランディアの 近衛の 家に 生まれ、十年前、冥王の 妃を かばって 影の 爪を 受けた 兵だった。"]);
      await wlSay(p, wl(s, "wq2c") || wl(s, "wq7d"), "割れた 仮面", [...(wl(s, "wq2c") ? ["§7仮面の まん中を まっすぐ 走る 割れ目。……オブリスの いちばん 古い 近衛の 面と、同じ 割れ目。"] : []), ...(wl(s, "wq7d") ? ["§7妃の 庭の ベンチの 下の 銀の 紋章にも、同じ まっすぐな 傷が あった。"] : [])], eA, "アルゴ", wl(s, "wq7d") ? ["{closed,low}……紋章は、冥王さまの 手に あるのか。……そうか。"] : null);   /* 第125版: 世界の 依頼「近衛の 面」「妃の 庭」*/
      if (ok(eA)) { camNear(p, eA, 1.5, 1.5); await wait(8); }
      act(eA, "kneel"); await say(p, "アルゴ", ["{closed,low}……旅の 仲間を、守れなかった。……すまない。", "{sad,low}……妃さまの ときも、そうだった。"]); act(eA, 0);
      await breath();
      act(eZ, "hold"); hold(eZ, "rope"); await memory(p, eZ, "ほどきかけの お守り", ["§7ゼファードの 手に、ほどきかけの §f紐の お守り§7。二十年前、妻と 五つの 娘と、生まれた ばかりの 娘を 置いて 石板に 入った 日の もの。", "§7妻には 編み上げた 一本を 渡した。もう 一本は、ほどけた まま。"]);
      if (ok(eZ)) { camNear(p, eZ, 1.8, 1.4); await wait(8); }
      await say(p, "ゼファード", ["{sad}……幕を 引くのは、幕を 上げた 者の 役目だ。", "{closed,up}これを、§e名も 知らぬ 娘に§f。……下の 娘は、名を つける 前に 家を 出た。"]);
      await give(eZ, null, "rope");
      if (ok(eZ)) { camNear(p, eZ, 1.6, 1.5); await wait(10); }
      await say(p, "ゼファード", ["{closed}王座の 窓からは、闘技場しか 見えぬ。", "{sad,up}風の 町の 塔は、娘らの いる 海が 見える ように 建てた。……一度も、見えは しなかったがな。"]);
      { const w6 = wl(s, "wq6b"), w6e = wl(s, "wq6e"), wb = wl(s, "wq10b"), we = wl(s, "wq10e");   /* 第125版: 世界の 依頼「嵐の 夜の 舟」「海神の 子守歌」「海の 方角の 星」「塔の 上の 遠めがね」*/
        await wlSay(p, w6 || w6e || wb || we, "娘らの いる 海", [...(w6 ? ["§7カモメールの 入り江の 櫂の 刻み字。§f『海の 向こうの 石へ。娘らが 待つ』"] : []), ...(w6e ? ["§7子守歌の 最後の 一節。§f『波の 向こうで 待つ 人に、この 歌が 届きますように』"] : []), ...(wb && !we ? ["§7ステラの 星図。何度も 海の 方角へ 引かれた 線。"] : []), ...(we ? ["§7ゼファーの 塔の 遠めがね。雲の 切れ目の ずっと 向こうに、青い 海が 光って いた。"] : [])], eZ, "ゼファード", we ? ["{shock,…}……見えたのか。あの 塔から、海が。", "{sad,up}……そうか。……見えたのか。"] : ["{closed,…}……そうか。……届いて いたか。"]); }
      if (ok(eV)) { camNear(p, eV, 1.6, 1.5); re(eV, "shock", "…"); await wait(10); }   /* 第124版(dir#18): ナギサの 手を 焼いたのは ヴァルカの 火 */
      await say(p, "ヴァルカ", ["{shock,…}……娘らの いる 海。……コラリアの、潜水士の 姉かい。", "{sad,low}アタシの 火で 焼いた 手だ。"]);
      await say(p, "ゼファード", ["{closed}……それも、わたしが 負う。"]);
      await wlSay(p, wl(s, "wq6d"), "借りは 返す", ["§7ケープの 灯台の、新しい 鉄の 継ぎ目。§f『借りは 返す』"], eV, "ヴァルカ", ["{closed}……あんな もんで 返せる 借りじゃ ない。わかってるさ。"]);   /* 第125版: 世界の 依頼「灯台の 修理」*/
      if ((qs(load(p) || d).epx || {}).mill10) { await narr(p, "出せなかった 手紙", ["§7あなたは 風の 塔で 見つけた 手紙を 差し出した。"]); if (ok(eZ)) { camNear(p, eZ, 1.8, 1.4); await wait(8); } await say(p, "ゼファード", ["{closed,…}……宛名は、娘らに 書かせて やって くれ。"]); }   /* 第124版(dir#31): 手紙の 回収 */
      { const ds = load(p); if (ds) { const q = qs(ds); q.sixJoin = 1; q.omamori = 1; q.vkBlade = 1; save(p, ds); } }
      await bye(p, eZ, eV, eRo, eRu, eA);
      if (EP_HOOK.kingsMarch) try { await EP_HOOK.kingsMarch(p); } catch (e) { console.warn(`[MonsterRPG] kings: ${e}`); }   /* 第125版: 王冠の 石板が 開き、11の 城の 王が 兵を 出す */
      if (ok(eR)) { camNear(p, eR, 2.2, 1.4); await wait(8); }
      await say(p, "レイ", ["{closed}……行けよ。石板を ぜんぶ 封じたら、王冠の 石板の 中だ。", "{sad,up}……あいつを、頼む。"]);
      return true;
    }
  } finally { if (inScene(p) && L.some(ok)) { camFade(p); await wait(10); } for (const e of L) rm(e); H.rm(); spkClean(p); }   /* 第124版(fix2): 暗く して から 下げる */
  return out;
}
/* 第125版: ラスボスの あと。影が はがれた セオが「斬って くれ」と 頼むが、主人公は 斬らずに 名を 呼ぶ（F2）。ゼファードは 石の 眠りに つく（1回だけ・印 theoCut）*/
export async function theoFinale(p) {
  const d = load(p); if (!d || qs(d).theoCut || qs(d).ending) return;
  const L = []; let bk = null, pal = null;
  const ovs = (e, k = 1.6) => { try { const P0 = p.location, l = e.location, dx = P0.x - l.x, dz = P0.z - l.z, n = Math.hypot(dx, dz) || 1; return camAt(p, { x: P0.x + (dx / n) * k + (dz / n) * 0.7, y: P0.y + 2.0, z: P0.z + (dz / n) * k - (dx / n) * 0.7 }, { x: l.x, y: l.y + 1.3, z: l.z }, 0.6); } catch { return false; } };   /* 主人公の 肩ごし */
  try {
    try { await stageBegin(p, { move: false }); } catch {}
    /* 1. 音が 消え、影が セオの 体から はがれて 空に 渦を 巻く。引きの 絵から ひざを ついた セオの 寄りへ */
    mood(p, "shadow"); cmd(p, "stopsound @s");   /* 第125版(snd): 霧を かけてから 音を 消す（雷も 消える）*/
    const tq = fwd(p, 4.5), eT = tq ? npcAt(p, "§7セオ", TRAITOR_JOB, tq) : npcNear(p, "§7セオ", TRAITOR_JOB, true); L.push(eT); act(eT, "kneel");
    if (ok(eT)) { camPt(p, eT.location, 8, 3); const l = eT.location; for (let k = 0; k < 8; k++) { const a = k * 0.8; try { p.dimension.spawnParticle("minecraft:portal_reverse_particle", { x: l.x + Math.cos(a) * (0.6 + k * 0.25), y: l.y + 0.6 + k * 0.45, z: l.z + Math.sin(a) * (0.6 + k * 0.25) }); } catch {} burst(p.dimension, l, "minecraft:basic_smoke_particle", 4, 0.5 + k * 0.2, 0.4 + k * 0.4); await wait(4); } }
    big(p, "§8§l影が はがれた", "", "beacon.deactivate");
    if (ok(eT)) { camNear(p, eT, 1.7, 1.0); await wait(18); }
    await say(p, "セオ", ["{sad,…,low}……やあ。ひどい 顔だな。……僕も、か。"]);
    /* 2. 手を 見る。指から 影が したたる */
    act(eT, "hold"); if (ok(eT)) { const l = eT.location; camPt(p, l, 1.4, 0.7); for (let k = 0; k < 3; k++) { burst(p.dimension, { x: l.x, y: l.y + 0.2, z: l.z }, "minecraft:squid_ink_bubble", 3, 0.3, 0.5 - k * 0.15); await wait(4); } }
    await say(p, "セオ", ["{closed,low}全部、覚えてるよ。記録の 力は、こういう ときも 忘れさせて くれないんだ。"]);
    /* 3. 主人公の 肩ごし。セオが ゆっくり 顔を 上げる */
    act(eT, "up"); if (ok(eT)) { ovs(eT); await wait(14); }
    await say(p, "セオ", ["{sad,up}……あの 子は、君の 前に 立った。僕の 槍の 前に。笑ってた。……笑ってたんだよ。"]);
    /* 4. 寄り。涙は 流さず、声だけが ふるえる */
    act(eT, 0); if (ok(eT)) { camNear(p, eT, 1.4, 1.2); await wait(12); }
    await say(p, "セオ", ["{sad,…,low}ごめん。……それしか 書けない。どんな 言葉も、記録には 足りない。"]);
    /* 5. 相棒の 寄り。相棒が 一歩 前へ */
    pal = palEnt(p); if (ok(pal) && ok(eT)) { const a = pal.location, l = eT.location, dx = l.x - a.x, dz = l.z - a.z, n = Math.hypot(dx, dz) || 1; await go(pal, { x: a.x + (dx / n) * 1.0, y: a.y, z: a.z + (dz / n) * 1.0 }, 10); camNear(p, pal, 2.2, 0.8); await wait(12); }
    await say(p, "セオ", ["{closed}君たちが 六本目の 鍵だった。……最初から 知ってた。だから、そばに いた。", "{sad,up}石板を 読む たびに、君たちの ことを 書いた。……いっしょに いた 日々も、全部。"]);
    /* 6. 空の 影が うなり、もう 一度 セオに 戻ろうと する。画面が ゆれる */
    sound(p, "mob.warden.roar", 0.6); shake(p, 0.5, 1.0); if (ok(eT)) { const l = eT.location; camPt(p, l, 5, 2.4); for (let k = 0; k < 3; k++) { burst(p.dimension, { x: l.x, y: l.y + 3.5 - k, z: l.z }, "minecraft:portal_reverse_particle", 8, 1.6 - k * 0.4, 0); await wait(4); } }
    act(eT, "guard");
    await say(p, "セオ", ["{angry,汗}……時間が ない。影は まだ、僕の 中を 居場所だと 思ってる。"]);
    /* 7. 立ち上がり、両手を 広げる。引きの 絵 */
    act(eT, "raise"); if (ok(eT)) { camPt(p, eT.location, 7, 1.6); await wait(14); }
    await say(p, "セオ", ["{closed,up}今の うちに、§c斬って くれ§f。千年前、アルディスが 王に そう したように。"]);
    /* 8. 主人公が ためらう。選ぶ 画面は 出さず、レイの 言葉を 思い出す（レイは ここに いない）*/
    if (ok(eT)) { const P0 = p.location, l = eT.location, dx = l.x - P0.x, dz = l.z - P0.z, n = Math.hypot(dx, dz) || 1; camAt(p, { x: P0.x + (dx / n) * 2.2 + (dz / n) * 0.6, y: P0.y + 1.6, z: P0.z + (dz / n) * 2.2 - (dx / n) * 0.6 }, { x: P0.x, y: P0.y + 1.5, z: P0.z }, 0.8); } await wait(20);   /* 第124版(fix2): ためらう あなたの 顔を セオの 側から（頭の 中に 入らない）*/
    await narr(p, "レイの 言葉", ["§7雲の 島の 端で、レイが 言った。§b「あいつを 止めるのは、あいつの 友だ」"]);   /* 第125版(F3) */
    /* 9. 第125版(F2): 斬らずに 名を 呼ぶ。三人目の アルディスに ならない */
    if (ok(eT)) { ovs(eT, 0.8); await wait(8); }
    await narr(p, "王冠の 石板の 奥", ["§7あなたは 刃を 下ろした。", "§7そして 旅の 手帳を 開き、§fセオ§7 の 名を、声に 出して 呼んだ。"]);
    sound(p, "item.book.page_turn", 1); flash(p, true);
    if (ok(eT)) { camNear(p, eT, 1.5, 1.4); await wait(10); }
    await say(p, "セオ", ["{shock,…,up}……斬らない、のか。", "{smile,…}……アルディスに、ならないんだね。……ありがとう。君に 会えて、よかった。"]);
    /* 10. 名を 呼ぶ 声に 影が 耐えきれず はがれる。白い 光。音が 消える */
    if (ok(eT)) { const l = eT.location; camPt(p, l, 5, 2.2); burst(p.dimension, { x: l.x, y: l.y + 2.5, z: l.z }, "minecraft:portal_reverse_particle", 10, 1.4, 0); await wait(6); }
    sound(p, "beacon.deactivate", 1); flash(p, true); shake(p, 0.6, 0.5); await wait(4); cmd(p, "stopsound @s"); fadeOn(p, "0 1.2 0.8", "255 255 255", true); await wait(16);
    /* 11. 白い 中で、たおれた セオの 寄り */
    act(eT, "down"); if (ok(eT)) { camPt(p, eT.location, 1.6, 0.5); await wait(18); }
    await say(p, "セオ", ["{closed,…,low}弟に……会えるかな。……いや。僕は、そっちには 行けないか。"]);
    /* 12. 手帳を 主人公の ほうへ 少しだけ 押す */
    act(eT, "hold"); sound(p, "item.book.put", 1); if (ok(eT)) { camPt(p, eT.location, 2.2, 0.6); await wait(10); }
    await say(p, "セオ", ["{smile,…,low}……§e記録を、残して おいた§f。"]);
    /* 13. セオは 光の 粒に なって 消え、王の 影も ちりぢりに。手帳だけが 石の 床に 残る。ゆっくり 引いて、一人と 一体だけが 立つ 広い 石板の 中 */
    if (ok(eT)) { const l = eT.location; for (let k = 0; k < 5; k++) { burst(p.dimension, l, "minecraft:endrod", 6, 0.4 + k * 0.3, 0.3 + k * 0.4); burst(p.dimension, { x: l.x, y: l.y + 3, z: l.z }, "minecraft:basic_smoke_particle", 6, 2 + k * 0.5, 0); await wait(5); }
      try { bk = p.dimension.spawnItem(new ItemStack("minecraft:book", 1), { x: l.x, y: l.y + 0.2, z: l.z }); bk.addTag?.("mrpg_temp"); } catch {}
      smokeOut(eT, 1); camPt(p, l, 2.2, 0.4); await wait(16); }   /* 第124版(cam): 光の 粒の 中で 消える */
    else rm(eT);
    try { if (ok(p)) cmd(p, "fog @s remove mq_shadow"); } catch {}
    await narr(p, "王冠の 石板の 奥", ["§7影は 最後に、セオの 魂を つかんで 闇の 底へ 引いた。", "§7セオの 体は、光の 粒に なって 消えた。千年 眠って いた 王の 気配も、もう ない。", "§7石の 床に、使いこまれた §f手帳§7 だけが 残って いる。"]);
    { const bq = ok(bk) ? bk.location : tq; if (bq) { camAt(p, { x: bq.x + 0.9, y: bq.y + 1.1, z: bq.z + 0.4 }, { x: bq.x, y: bq.y + 0.1, z: bq.z }, 1.2); sound(p, "item.book.page_turn", 1); await wait(16); } }   /* 手帳の 寄り */
    await narr(p, "手帳の 最後の 頁", ["§7弟の 描いた 小さな 絵と、一行だけ。", "§8……影に にじんで、読めない。"]);   /* 第124版(dir#39): 一文は 墓の 場面で 初めて 読む */
    if (wl(qs(d), "wq7c")) await narr(p, "手帳の 最後の 頁", ["§7……オニキスの 書庫に 置かれて いた 写しと、線 一本 ちがわない 竜の 絵だった。"]);   /* 第125版: 世界の 依頼「残された 写し」を 済ませた 人だけ */
    await narr(p, "手帳", ["§7あなたは セオの 手帳を 拾い上げた。"]);
    { const dz = load(p); if (dz) { const q = qs(dz); q.theoCut = 1; q.theoGone = 1; q.theoNote = 1; save(p, dz); } }
    const tq2 = ok(bk) ? bk.location : tq; if (tq2) for (const k of [4, 7, 10, 13]) { camPt(p, tq2, k, k * 0.35); await wait(12); }
    await narr(p, "王冠の 石板の 奥", ["§7広い 石板の 中に、あなたと 相棒だけが 立って いる。", "§8……石板の いちばん 奥で、ゼファードの 気配が 静かに 石の 眠りへ 沈んで いった。"]);
    await wait(10);
  } finally { for (const e of L) rm(e); rmCine(pal); try { if (bk && bk.isValid?.()) bk.remove(); } catch {} try { if (ok(p)) stageEnd(p); } catch {} }
}
async function gateOpen(p, r, who, line) {
  big(p, "§a§l道が 開けた！", `§f${RN(r)}へ 行けるように なった`, "ui.toast.challenge_complete");
  particle(p, "minecraft:totem_particle", 1.5);
  if (who) { const L = [].concat(line); for (let i = 0; i < L.length; i++) { const S = stageOf(p); if (S) { camAt(p, S.at(-3.5 + i * 1.5, (2.6 - i * 1.2) * S.side, 2.6 - i * 0.5), S.at(3, 0, 1.2), 1.2); await wait(4); } await say(p, who, [L[i]]); } }   /* 第125版(rs): 手紙の 行ごとに カメラを ゆっくり 動かす（同じ 絵で 3画面に しない）*/
}

// 前の バージョンの セーブ・チート: いまの 進みに あわせて 手順を 決める（だいじなもの も そろえる）
function fixMq(p, d) {
  const s = qs(d);
  // v2.9.13: 物語と 地方の 進みが そろって いる セーブは 順番を 守る（古い セーブで 物語が 遅れて いる ときは そのまま）
  if ((s.kg || 0) >= 1 && !s.hiltGot) { s.hiltGot = true; s.keys = [...new Set([...(s.keys || []), "k_hilt"])]; return true; }
  if (s.hiltGot && !(s.keys || []).includes("k_hilt")) { s.keys = [...(s.keys || []), "k_hilt"]; return true; }   /* v2.9.13: 前の 版で カゲツに 勝った 人 */
  /* v2.9.14: 前の 版で ムサシ（カゲツ）・エンマを 仲間に した 人は 魔神編を すませた ことに */
  if (!s.musashiJoin && (s.kg || 0) >= 1 && (d.own || []).includes(SPECIES.musashi?.idx)) { s.musashiJoin = 1; return true; }
  if (!s.enmaClear && s.enmaJoin) { s.enmaClear = 1; s.musashiJoin = 1; return true; }
  if (!s.ord && s.mq !== undefined && !s.ending && storyOpen(s) >= sealOpen(s)) { s.ord = 1; return true; }
  if (s.ending && (s.mq === undefined || s.mq < POST)) { s.mq = POST; for (const k of ["k_note", "k_light", "k_goggle"]) if (!(s.keys || []).includes(k)) giveKey(p, d, k); return true; }
  /* 第106版: 前の 版で 物語を 先まで 進めた セーブは、亡くなった 人の 印を そろえる（1回だけ） */
  /* 第122版: オルドは 亡くならない（代わりに ハクが 石に なる）。前の 版の 印を 置きかえる */
  if (s.ordoDead) { delete s.ordoDead; s.hakuStone = 1; return true; }
  if (s.mqSpot && s.mqSpot.v !== SPOT_V && !s.mqSpot.key) { delete s.mqSpot; delete s.estSeen; return true; }
  if (s.mqSpot && stOf(s)?.at === "cave" && s.mqSpot.cv !== CAVE_V && (() => { try { const v = caveInfo(MQ[s.mq ?? 0].r); return !!(v && v.built && v.cv === CAVE_V); } catch { return false; } })()) { delete s.mqSpot; delete s.estSeen; return true; }
  if (s.mqSpot && s.mqSpot.i === (s.mq ?? 0) && !s.mqSpot.key && stOf(s)?.at === "hall" && MQ[s.mq ?? 0].hq !== undefined) { delete s.mqSpot; delete s.estSeen; return true; }   /* 第124版: 広間で 始まる ように なった 段（第9章）の 前の 版の 目印は 捨てる */   /* 第125版: 洞くつが まだ できて いない ときは 目印を 消さない（毎回 消えて 始まらなかった）*/   /* 第128版: 前の 版の 洞くつの 入口の 目印は 選びなおす */   /* 第122版: 前の 版の 目印（城下の 広場・噴水の 横）を 読みこみで 捨てる */
  if (!s.v106 && s.mq !== undefined) {
    s.v106 = 1;
    const past = (re) => { const k = MQ.findIndex((x) => re.test(x.ch || x.hint || "")); return k >= 0 && (s.mq ?? 0) > k; };
    if (!s.nagiDead && past(/第7章/)) s.nagiDead = 1;
    { const k10 = MQ.findIndex((x) => x.seal === 10); if (!s.yomiStone && (s.bs || []).includes(10) && k10 >= 0 && (s.mq ?? 0) > k10) s.yomiStone = 1; }   /* 石に なる 場面を 見た あとだけ */
    if (!s.rouDead && past(/第9章/)) s.rouDead = 1;
    if (past(/第10章/)) { s.hakuStone = 1; s.ch10b = 1; }
    if (!s.kagetsuDead && s.enmaClear) s.kagetsuDead = 1;
    if (s.enmaClear) { s.m4 = s.m4 || 1; s.m5 = Math.max(s.m5 || 0, 5); s.m5b = 1; s.m6 = 1; }
    return true;
  }
  if (!s.v125 && s.mq !== undefined) {   /* 第125版: 前の 版で 第10章を こえた セーブは、新しい 筋の 印に そろえる（1回だけ）。クリア後で 旅の 仲間が いる セーブは「もう 救い出した あと」 */
    s.v125 = 1;
    const k10 = MQ.findIndex((x) => /第10章/.test(x.ch || ""));
    if (s.ending) { if (!s.heroDead) { s.heroDead = 1; s.heroBack = 1; } s.theoGone = 1; s.theoCut = 1; s.hakuStone = 1; s.ch10b = 1; s.ch10g = 1; s.ch10t = 1; }
    else if (k10 >= 0 && (s.mq ?? 0) > k10) { s.heroDead = 1; s.theoGone = 1; s.hakuStone = 1; s.ch10b = 1; s.ch10g = 1; s.ch10t = 1; }
    else if (k10 >= 0 && (s.mq ?? 0) === k10 && s.ch10b) s.ch10g = 1;
    return true;
  }
  if (s.mq !== undefined) return false;
  const u = openUpTo(d);
  let i = 0;
  if (u > 0) { i = MQ.findIndex((x) => x.r >= u); if (i < 0) i = POST; if (i > 0 && MQ[i].r === u && MQ[i - 1].r === u) i--; }
  s.mq = Math.max(0, i);
  if (u >= 1) { for (const k of ["k_note"]) if (!(s.keys || []).includes(k)) giveKey(p, d, k); }
  if (u >= 2) giveKey(p, d, "k_light");
  if (u >= 6) giveKey(p, d, "k_goggle");
  return true;
}
/* 第121版: チートブック「物語を 先へ 進める」。今の 段を とばして 次の 段へ（とばした 段で 立つ 印・だいじなもの・封印も そろえる）*/
export function cheatAdvance(p, n = 1) {
  const d = load(p); if (!d) return null;
  const s = qs(d); if (fixMq(p, d)) {}
  let moved = 0;
  for (let k = 0; k < n; k++) {
    if (EP_HOOK.skip && EP_HOOK.skip(p, d)) { moved++; continue; }   /* 第125版: 地方の 新しい 話を 先に とばす */
    const i = s.mq ?? 0, st = MQ[i]; if (!st || i >= POST - 1) break;
    const src = String(st.run || "") + String(st.trig || "");
    for (const m of src.matchAll(/s\.gate = \{ \.\.\.\(s\.gate \|\| \{\}\), (\d+): true \}/g)) s.gate = { ...(s.gate || {}), [m[1]]: true };
    if (st.seal !== undefined) { s.bsg = s.bsg || []; s.bs = s.bs || []; if (!s.bsg.includes(st.seal)) s.bsg.push(st.seal); if (!s.bs.includes(st.seal)) s.bs.push(st.seal); }
    for (const m of src.matchAll(/giveKey\(p,\s*\w+,\s*"(k_\w+)"/g)) if (!(s.keys || []).includes(m[1])) try { giveKey(p, d, m[1]); } catch {}
    for (const f of ["palMet", "hakuStone", "ch10b", "reiFinal", "yomiStone", "nagiDead", "rouDead", "ch1b"]) if (new RegExp(`\\.${f}\\s*=\\s*1`).test(src)) s[f] = 1;
    if (src.includes("jailEvent(")) s.jailDone = 1; if (/\.theoBetray\s*=\s*true/.test(src)) s.theoBetray = true;   /* 町の 暮らし（ch1b）・ランダムの レイの 段階（jailDone・theoBetray）も そろえる */
    const ch = st.ch || ""; if (/第7章/.test(ch)) s.nagiDead = 1; if (/第9章/.test(ch)) s.rouDead = 1; if (/第10章/.test(ch)) { s.hakuStone = 1; s.ch10b = 1; s.ch10g = 1; s.ch10t = 1; s.heroDead = 1; s.theoGone = 1; } if (st.seal === 10) s.yomiStone = 1;
    if (st.spot === garoSpot || /北の 門§f を 出て/.test(st.hint || "")) s.palMet = 1;
    s.mqPaid = i; s.mq = i + 1; delete s.mqHold; delete s.mqSpot; moved++;
  }
  s.introDone = s.introDone || 1; s.ord = 1;
  save(p, d); try { syncKeys(p, d); } catch {}
  const d2 = load(p), s2 = d2 ? qs(d2) : s, st2 = MQ[s2.mq ?? 0];
  return { moved, at: s2.mq ?? 0, last: (s2.mq ?? 0) >= POST - 1, hint: st2 ? storyNowHint(d2 || d) : "" };
}
// v2.9.10: いまの 目標と その 場所（画面の 下と チャットに 出す）
// v2.9.12: カゲツは 終の遺跡を こえるまで 出ない ので、それまでは 遺跡を 案内する
const KAGETU_PRE = "§fネクロスの §6終の遺跡§f を こえよう（遺跡を 8つ こえると 開く）。そのあと ルミナの 闘技場で 伝説の マスターに 挑もう";
function hintOf(st, d) { const h = hintOf0(st, d); const s = qs(d); return s.mqHold && s.mqHold.i === (s.mq ?? 0) && st && st.trig ? `${h} §e（ガイドブック → ストーリー →「物語の 戦いに 再挑戦」で もう一度）` : h; }
/* 第124版: 終章で 遺跡の 石板が 足りない とき（あと いくつ 遺跡を こえれば よいか）と、いちばん 近い まだ こえて いない 遺跡 */
function ruinLeft(s) { let need = 0; for (const [n, k] of Object.entries(RUIN_SLAB)) if (!(s.bsg || []).includes(k) && !(s.bs || []).includes(k)) need = Math.max(need, Number(n)); return Math.max(0, need - (s.ruins || 0)); }
const NRU = new Map();
function nearRuin(p) {
  const c = NRU.get(p.id); if (c && Date.now() - c.t < 10000) return c.q;
  let q = null; try { const R = REGION["minecraft:overworld"], L = p.location, rx0 = Math.floor(L.x / R), rz0 = Math.floor(L.z / R); let bd = 1e18;
    for (let dx = -4; dx <= 4; dx++) for (let dz = -4; dz <= 4; dz++) { const st = siteOf("minecraft:overworld", rx0 + dx, rz0 + dz); let r = null; try { r = getRuin(st.key); } catch {} if (r && (r.skip || (r.by || []).includes(p.id))) continue; if (TOWNS.some((t) => { const tq = townPos(t); return Math.hypot(tq.x - st.x, tq.z - st.z) < 80; })) continue; if (!r && ruinBlocked("minecraft:overworld", st)) continue; const dd = (st.x - L.x) ** 2 + (st.z - L.z) ** 2; if (dd < bd) { bd = dd; q = { x: st.x, z: st.z }; } } } catch {}
  NRU.set(p.id, { t: Date.now(), q }); return q;
}
function hintOf0(st, d) {
  if (st && st.r === 99 && /カゲツ/.test(st.hint) && !postOpen(d)) { const n = 8 - (qs(d).ruins || 0); return n > 0 && !rfInfo() ? `§f遺跡を あと §e${n}§f こ こえよう §7（8つ こえると ネクロスの §6終の遺跡§7 が 開く。そのあと ルミナの 闘技場で 伝説の マスターに 挑もう）` : KAGETU_PRE; }   /* 第124版: 終の遺跡が まだ 無い ときは 近い 遺跡を 指す */
  if (st && st.r === 99 && /カップ/.test(st.hint)) {   // v2.9.13: 終章は 進み具合で 書きかえる（カップ → 星冠王 → 石板の 封印 → 石板の王）
    const s = qs(d), n = (s.bs || []).length;
    if (!s.final && !s.finIntro) return "§f封じた 石板が ルミナの 方へ 鳴って いる。地面に 立ち止まろう §7（ルミナの §e闘技場§7 で オルドが 待って いる。セオの いる 王冠の 石板と、王座の 扉の ことを 話して くれる。闘技場の 受付でも 始まる）";   /* 第125版 */
    if (!s.final) return `§fルミナの 闘技場で カップを 勝ちぬき §c星冠王§f に 挑もう §7（カップ ${Math.min(8, s.cup || 0)}/8。王冠の 石板の 扉は、闘技場の 掟で すべての カップを 勝ちぬいた 者にだけ 開く。8つ 勝つと 闘技場の 王者「星冠王」に 挑める。カップに 出る ための マスターポイントは、フィールドの モンスターマスターに 勝つと たまる）`;
    if (n < BS_N - 1 && ruinLeft(s) > 0) return `§f遺跡の 石板が まだ ない。§6遺跡を あと ${ruinLeft(s)}こ§f こえよう §7（封印 ${n}/${BS_N - 1}。右上の 案内が いちばん 近い 遺跡を 指す。奥の ボスに 勝つと こえた ことに なる）`;
    if (n < BS_N - 1) return `§fのこりの 石板で 主を 封印しよう §7（封印 ${n}/${BS_N - 1}。ぜんぶ 封じると 王冠の 石板が 目を さます。石板は カップ・遺跡でも 手に入る）`;
    if (!s.bsFinal) return "§c王冠の 石板§f の 中へ 入り、§cセオ§f を 止めよう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【特別な石板】）";
  }
  // v2.9.13: マスターに 勝って 石板を もらったら、次は その 石板で 主を 封印（どこでも 使える）
  if (st && typeof st.seal === "number") { const s = qs(d); if ((s.bsg || []).includes(st.seal) && !(s.bs || []).includes(st.seal)) return `§fもらった §d石板§f で ${WREGIONS[st.r].short}の §6主§f を 封印しよう §7（ガイドブック ＞ 道具・装備 ＞ 道具・タマゴを 使う ＞【特別な石板】）`; }
  return st ? st.hint : "";
}
// v2.9.13: 章ごとの あらすじ（たどりついた 章だけ 見せる）
const SYNOPSIS = {
  "第1章 旅立ち": "旅立ちの 朝、ルミナの 外れの オルドの 牧場で、最初の 仲間を もらった（村長が なぜ モンスターを 育てて いるのかは、「昔、ちょっとな」と はぐらかされた）。オルドから、心を 呑む「王」と、十五の 石板の 話、そして「石板は 守り手に 勝った 者にだけ 渡す」という 決まりを 聞いた。孫の レイは「じいちゃんの 目が 正しいか 確かめる」と 勝負を 挑んで きた。｜北の 門の 外では、六影の ガロが 守って いた 少年 ピコが 影に 心を 呑まれ、眠った まま 起きなく なった。ピコは いじめる 側では なく、袋を 持たされた 見張りの 子だった。学者 セオは 研究メモの 写しを くれ、「影は 人の 多い 方へ 流れる」と 祭りの 原っぱへ 走った。",
  "第2章 森の 精霊石": "セオと 落ちあった シルヴァの 洞くつで、一座を 影に 呑まれて 行き場を なくした 六影の ベリルと 戦った。｜洞くつの 奥の 広間では、番人が 病んだ 精霊を 守って いた。精霊は 相棒を 見て「二人で 一つの 守り手の 印」と 言い、精霊石の 中で 眠った。｜森の 主を しずめた あと、女王エルゼは「人間が 森を 病ませた」と 疑ったが、戦いぶりを 見て 精霊石を 託して くれた。精霊は「廃都の 壁画に 同じ 影が 描かれて いる」と 告げた。",
  "第3章 廃都の 壁画": "廃都の 手前の 崖道で、修行帰りの ジンの 弟子たちを、待ち伏せて いた 砂ぼこり団から 助けた。壁画の 広間には、セオに 頼まれた レイが 先に 来て いた。王の 隣の 削られた 影を、レイは「十五番目の 主」、旅の 仲間は「王を 動かした だれか」と 読み、どちらの 読みを 先に 城へ 報告するかを かけて 勝負した。弟子は「ジン師匠は オルド殿に 一度も 勝てなかった」と 言った。",
  "第4章 炎の 幹部": "町外れの 鍛冶場は、石板を 円く 並べる 台座を 作れと 言われて 断った ために 燃やされて いた。爆弾班を 退け、打ちかけの 台座が 運ばれた 六影の 鋳造所で、幹部 ヴァルカと 溶岩の 上で 戦った。ヴァルカの 目当ては、クロガネの「開かずの 部屋」を 見る こと。仲間が 砂漠の 王墓へ 向かい、ベリルが 水晶を 集めて いると もらした。",
  "第5章 砂の 王墓": "サンドリア城の 城門で、六影の 密告により 捕まった。同じ 牢に いた レイ、そして 七年 牢に いる 老人 イザクに 助けられて 牢を 出た。砂王ラシードは 玉座の 間で 詫び、イザクを 赦して、王墓の 地図を くれた。王墓の 碑文「永遠を 願うな。願いは 石に なる」。王墓の 主を レイと 倒した。",
  "第6章 水晶の 洞くつ": "クリスタリアの 洞くつの 広間で、穴ぐらに 飛ばされた 班長ガロと 部下たちから 潜水士 マリンを 助けた。ガロは 眠った ままの ピコの ために、ベリルは 団の 座に 名前を 残す ために 戦って いた。曇った 水晶には 石に なった 街が 映って いた。マリンは「海神の 貝笛が 狙われて いる」と 港へ 誘った。",
  "第7章 海神の 貝笛": "港の 桟橋で 波を 数える ナギサに 貝笛を 託され、夜の 浜で ヴァルカに 奪われた。燃える 流木に 落ちた 笛を 拾おうと して、ナギサは 両手に やけどを 負い、港の マスターを マリンに ゆずった。｜岬の 灯台で ヴァルカに 勝って 貝笛を 取りかえし、沖の 海の 底の 沈んだ 神殿で 吹いた。「間に 合ったよ」と 言われて、旅の 仲間は 初めて 涙を こぼした。",
  "第8章 冥府の 霊廟": "冥王の 城の 中庭で 葬列の 護衛を 引き受け、セオの メモを 見つけた。『六本目の 鍵: 鍵を 持たず、モンスターと 絆を 結んだ 者』。最後の 頁には、壁画の 台座と 同じ『影は 知る 者に 宿る』。回し者は 六の座の 言いつけで「参謀に 会わせるな」と 立ちふさがった。霊廟の 奥で、セオは 六影の 二の座、参謀だと 明かした。目的を 聞いても「話せば、君に 影が 宿る」と だけ 言い、「君と 相棒が 要る」と 告げた。かけらに 呑まれた レイと 戦い、かけらは 割れた。セオは「ごめん」と 一言 残して ラグナへ 向かった。｜ヨミは「印を 分けあう 二人、離れるな」と 伝えて 石に なった。",
  "第9章 雪山の 双子": "かけらを 捨てた レイと、雪山の 六影の 氷の 隠れ家へ。双子の 幹部は セオに かくまわれて いた。「二人で 一つの 鍵」だと いう 双子は、引きはなされる ことを 何より こわがって いた。片っぽずつの 手袋の 二人と 戦った。ルウは「知りすぎたら、参謀さんが 危ない」と もらした。氷の 下に 落ちた ロウを 仮面の 戦士が 引き上げ、迎えに 来た セオにも 渡さず、双子ごと 連れ去った。札には「双子は 預かる。六影 六の座 アルゴ」。その 夜、オルドから「わしも 行く」と 手紙が 届いた。",
  "第10章 竜骨の 決戦": "ラグナの 竜骨の 祭壇で、セオは 六本の 鍵を そろえる 儀式を して いた。守り手の 試しを 越えた あと、セオは マリノアで 破った 最後の 記録を 読み上げ、その とき 影が セオに 宿った。暴走した セオの 影の 槍から、旅の 仲間が あなたを かばって 亡くなった。駆けつけた オルドと ハクが セオを 押さえ、ハクは 石に なった。正気に もどった 一瞬、セオは「……そうか。王も、こうだったのか」と つぶやき、影ごと 王冠の 石板へ 消えた。",
  "第11章 最後の ライバル": "旅の 仲間の いない 旅。夜明けの 雲の 島の 端、石に なった 竜の 前で、手帳に ハクと 竜と 仲間の 名前を 書いた（古い インクは 届かない。それでも 呼ぶ 日の ために）。レイの しくじり帳の 最後の 頁は『竜骨の 祭壇。動けなかった。』。「王座の 扉を くぐる 一人」を かけた 最後の 勝負に 勝つと、レイは 頁を 破らずに『全部 出して、負けた。』と 書き足し、「あいつを 止めるのは、あいつの 友だ。……オレじゃ ない」と 言った。ルミナを 守るのは、レイが 自分で 決めた 役目。",
  "終章 歴史再び": "王冠の 石板の 扉は、闘技場の 掟で すべての カップを 勝ちぬいた 者にだけ 開く。闘技場の 最後の カップで 仮面の 王者 オルドと 戦い、闘技場の 奥の 王座で 星冠王 ゼファードと 向きあった。ゼファードは 六影の 一の座で、闘技場を 開いた 人。カップは、六本目の 鍵を 探す ための ふるいだった。千年前、王 ヴァルグレイドは 知りすぎて 影に 宿られ、親友の 初代の 影 アルディスが 王を 討って 石板に 封じた。壁画で 削られた「王の 隣の 影」は、王を 止めた 友だった。ヴァルカ・双子・アルゴが 鍵を 持って 味方に なり、あなたは 王冠の 石板の 中で、王を 取りこんだ 暴走セオと 戦った。正気に もどった セオは「今の うちに、斬って くれ」と 頼んだ。あなたは 刃を 下ろし、セオの 名を 呼んだ。影は はがれ、最後に セオの 魂を つかんで 闇の 底へ 引いた。最後の 言葉は「……記録を、残して おいた」。ゼファードは 石の 眠りに つき、ルミナには 旅の 仲間の 墓と、書きかけの 手帳だけが 残った。",
};
export function synopsisText(d) {
  const s = qs(d), i = s.mq ?? 0, cur = chapterOf0(d), L = ["§l§eこれまでの あらすじ", "§7（たどりついた 章だけ）", ""];
  for (let k = 0; k <= Math.min(i, MQ.length - 1); k++) {
    const ch = MQ[k].ch; if (!ch || !SYNOPSIS[ch] || !(k < i || s.chSeen === k)) continue;
    if (ch === cur && k >= i) { L.push(`§6§l${ch} §a（いま ここ）`, "§7（この 章の お話は これから……）", ""); continue; }   // v2.9.13: まだ 起きて いない ことは 書かない
    const sg = String(SYNOPSIS[ch]).split("｜"), sn = ch === cur ? Math.max(1, Math.min(sg.length, i - k)) : sg.length;   /* 第124版: 「いま ここ」の 章は 終えた 段の ぶんだけ（｜で 段ごとに 区切る）*/
    L.push(`§6§l${ch}${ch === cur ? " §a（いま ここ）" : ""}`, `§f${sg.slice(0, sn).join("")}${(() => { try { return EP_HOOK.syn ? EP_HOOK.syn(d, ch) : ""; } catch { return ""; } })()}`, "");
  }
  { let bl = ""; try { bl = EP_HOOK.book ? EP_HOOK.book(d) : ""; } catch {} if (bl) L.push(bl); }   /* 第126版: 本の 章の 一覧（まだの 章は ？？？）*/
  return L.join("\n");
}
/* 第126版: 章の 名前は 本の 表（bkeng.js の EP_HOOK.chapter）から。その 章が まだ 書かれて いなければ 今までの 章 */
export function chapterOf(d) { { let c = ""; try { c = EP_HOOK.chapter ? EP_HOOK.chapter(d) : ""; } catch {} if (c) return c; } return chapterOf0(d); }
function chapterOf0(d) { const s = qs(d), i = s.mq ?? 0; for (let k = Math.min(i, MQ.length - 1); k >= 0; k--) if (MQ[k].ch && (k < i || s.chSeen === k || (k === POST && i === POST) || (EP_HOOK.reached && EP_HOOK.reached(d, MQ[k].r)))) return MQ[k].ch; return ""; }   // v2.9.13: 始まった 章だけ（第125版: 地方の 新しい 話を 始めた 章も）
// uxprog68: クリア後の 目標（まだ 勝って いない 城の 王 → 近い 順）
function postGoal(p, d) {
  const s = qs(d); if (!s.ending) return null;
  const kw = s.kgw || {}, left = WREGIONS.map((R, i) => i).filter((i) => !kw[i]);
  if (!left.length) {   // 王を みな 倒した あと: 使って いない 神の石板 → カゲツ（40勝まで）
    const dg = s.dg || {}, own = (Array.isArray(s.dgs) ? s.dgs : []).filter((gi) => !dg[gi]);
    if (own.length) return { text: `神の石板で 神を 鎮めよう（まだ 仲間に して いない 神 ${own.length}柱・仲間にした 神 ${Object.keys(dg).length}/15）`, name: "", near: "", x: null, z: null, key: `dg${own.length}` };
    if ((s.kg || 0) < 40) { const t = TOWNS.find((t) => t.id === "t0"), tp = t ? townPos(t) : null; return { text: `カゲツに 勝って 神の石板を（あと ${10 - ((s.kg || 0) % 10)}勝）`, name: "ルミナの 闘技場", near: "§a闘技場の カゲツに 話しかけよう", x: tp ? tp.x : null, z: tp ? tp.z : null, key: `kgx${s.kg || 0}` }; }
    return null;
  }
  let best = null; for (const i of left) { const c = castleInfo(i) || castleSpot(i); if (!c) continue; const dd = Math.hypot(p.location.x - c.x, p.location.z - c.z); if (!best || dd < best.dd) best = { i, c, dd }; }
  if (!best) return null;
  return { text: `城の 王に 勝って 神の石板を（${WREGIONS.length - left.length}/${WREGIONS.length}）`, name: WREGIONS[best.i].castle.name, near: "§a城の 奥の 王に 話しかけよう", x: best.c.x, z: best.c.z, key: `kg${left.length}` };
}
export const GOAL_HOOKS = [];   /* 第76版: 追加ストーリーの 目標（null で ふつうの 目標） */
export function storyTarget(p, d) {
  for (const h of GOAL_HOOKS) { try { const g = h(p, d); if (g) return g; } catch {} }
  const s = qs(d), st = stOf(s);
  if (!st || (st.r === 99 && s.enmaClear && /閻魔/.test(st.hint))) return postGoal(p, d);   // uxprog68: 物語の あとは 城の 王・神の石板へ
  const text = String(hintOf(st, d) || "").replace(/§./g, "").replace(/\s+/g, " ").trim();
  const R = Math.max(0, Math.min(WREGIONS.length - 1, st.r ?? 0));
  const me = p.location; let here = -1; try { here = regAt(me); } catch {}
  let pos = null, name = "", near = "";
  const pl = st.tgt ? st.tgt(p) : st.key || !st.at ? null : PLACES.has(st.at) && st.at !== "hall" ? placeOf(st.at, R) : /^land\d$/.test(st.at) ? (() => { const S0 = landSites(R)[+st.at.slice(4)] || landSites(R)[0]; return S0 ? { x: S0.x + 24, z: S0.z, nm: `${WREGIONS[R].short}の 大地` } : null; })() : null;   /* 第122版: 場面の 場所を 指す */
  try {
    const isCv = (/洞くつ/.test(text) || st.at === "hall" || st.at === "cave") && CAVE_R.includes(R), cv = isCv ? caveInfo(R) : null;   /* 第124版: 文字では なく 段の 場所（at）で 見る（六影の アジトは「洞くつ」と 書かない）*/
    if (pl) { pos = pl; name = pl.nm; }
    else if (st.r === 99) {   // v2.9.12: クリア後は 天空郷では なく 本当の 場所へ
      if (/遺跡を あと/.test(text)) { const q = nearRuin(p); if (q) { pos = q; name = "まだ こえて いない 遺跡"; near = "§a遺跡の 奥の ボスに 勝とう"; } }
      else if (/閻魔/.test(text)) { if (s.enmaClear) return null; const a = altarInfo(); if (a) { pos = a; name = "閻魔の神殿"; } }
      else if (/クロガネ/.test(text)) { const M = musashiTownInfo(); if (M) { pos = M.pos; name = M.t.name; } }
      else if (/終の遺跡/.test(text)) { const a = rfInfo(); if (a) { pos = a; name = "終の遺跡"; } else { const c = castleInfo(7) || castleSpot(7); if (c) { pos = c; name = WREGIONS[7].name; } } }
      else if (/星冠王/.test(text)) { const t = TOWNS.find((t) => t.id === "t0"); if (t) { pos = townPos(t); name = "ルミナの 闘技場"; } }
      else if (/カゲツ/.test(text) && postOpen(d)) { const t = TOWNS.find((t) => t.id === "t0"); if (t) { pos = townPos(t); name = "ルミナの 闘技場"; } }
    }
    else if (cv && cv.built) {   // v2.9.12: 洞くつの 中では 奥の 広間を 指す・入口の 近くでは「階段を 下まで」
      const me2 = p.location, inside = cv.dt ? inCaveBox(R, me2) : me2.y < cv.y - 3 && (() => { const b = caveBox(R); return me2.x > b.x1 && me2.x < b.x2 && me2.z > b.z1 && me2.z < b.z2; })() && (!cv.hall || me2.z < cv.hall.z + 14);
      if (inside && cv.hall) { pos = cv.hall; name = cv.dt ? `${caveName(R)}の 奥の 大広間` : R === 1 || R === 5 ? "洞くつの 奥" : `${caveName(R)}の 奥`; near = cv.dt ? (cv.dir > 0 ? "§a部屋を 抜けて 上の 大広間へ 登ろう" : "§a部屋を 抜けて 奥の 大広間へ 下りよう") : "§a奥の 広間へ すすもう"; }
      else { pos = cv; name = caveName(R); near = cv.dt ? "§a入口から 中へ 入ろう（中の 部屋を 抜けた 奥が 大広間）" : "§a入口の 坂道を 奥まで 進もう"; }
    }
    else if (isCv) { const c = caveSite(R); pos = { x: c.x, y: 64, z: c.z + 20 }; name = caveName(R); }   // v2.9.12: まだ できて いない ときも 場所を 指す
    else if (/ステージ|大地/.test(text)) {
      // v2.9.12: 目的地が ぶれない ように いつも 同じ ステージ（できて いる ものを 優先・地方の 中で 決まった 順）
      let best = null; for (const L of landSites(R)) { const I = landInfo(L.key); if (I && I.skip) continue; const sc = I && I.built ? 0 : 1; if (!best || sc < best.sc) best = { ...L, sc, nm: (I && I.name) || "ステージ" }; }
      if (best) { pos = st.key ? { x: best.x + 24, z: best.z } : best; name = best.nm; }   /* 第123版: だいじなものを 使う 段は まん中の 柱（番人）を さけて 端へ（番人と 主の 連戦に しない）*/
    } else if (/もらった/.test(text)) {
      pos = null;   /* 第67版: もらった あとは 城を 指さない（石板は どこでも 使える） */
    } else if (/城|地方マスター|王さま|王様/.test(text)) {
      const c = castleInfo(R) || castleSpot(R); if (c) { pos = c; name = WREGIONS[R].castle.name; }
    } else if (/洞くつ|地下|海|水|歩いて|外を/.test(text) && here === R) {
      pos = null;   // その 地方の 中で する こと（場所は 自由）
    } else if (here !== R && !/町/.test(text)) {
      const c = castleInfo(R) || castleSpot(R); if (c) { pos = c; name = WREGIONS[R].name; }
    } else if (/町/.test(text)) {   // v2.9.12: 町が 目的地なら 地方の 外からでも その 町を 指す（ぶれない）
      let t = TOWNS.find((t) => text.includes(t.name.replace(/の 町|の 村/, "")));
      if (!t) { const c0 = castleInfo(R) || castleSpot(R); let bd = 1e18; for (const u of TOWNS) { const q = townPos(u); if (regAt(q) !== R) continue; const dd = (q.x - c0.x) ** 2 + (q.z - c0.z) ** 2; if (dd < bd) { bd = dd; t = u; } } }   // 城に いちばん 近い 町（いつも 同じ）   // v2.9.12: 名前の ない「町」は いちばん 近い その 地方の 町
      if (t) { pos = townPos(t); name = t.name; }
    }
    if (!pos && st.spot && !st.key && !st.nospot) { const q = st.spot(p, d); if (q && Number.isFinite(q.x)) { pos = q; name = q.nm || name; } }   /* 第126版: 段の 場所（北の 門の 外 など）は 町の 中に いても 右上で 指す */
  } catch {}
  if (s.mqSpot && s.mqSpot.i === (s.mq ?? 0) && !st.key && !st.nospot && st.at !== "hall" && !s.mqSpot.wait && (!pl || s.mqSpot.v === SPOT_V || /^land/.test(st.at))) { pos = { x: s.mqSpot.x + 0.5, z: s.mqSpot.z + 0.5 }; name = s.mqSpot.np ? s.mqSpot.nm : `${s.mqSpot.nm}の 広場`; near = "§a「！」の 目印の そばで 立ち止まろう"; }   /* 第108版: 物語の 待ち合わせ 場所へ 案内。第123版: 洞くつの 入口で「階段を 下まで」と 誘わない */
  return { text, name, near, x: pos ? pos.x : null, z: pos ? pos.z : null, key: `${s.mq ?? 0}` };
}
export function sagaHint(d) {
  const s = qs(d);
  const st = stOf(s);
  const L = [];
  { const ch = chapterOf(d); if (ch) L.push(`§d§l${ch}`); }
  { let eh = ""; try { eh = EP_HOOK.hint ? EP_HOOK.hint(d, true) : ""; } catch {} if (eh) L.push(`§6【メイン】§r${eh}`); else if (st && !(st.r === 99 && /閻魔/.test(st.hint) && s.enmaClear)) L.push(`§6【メイン】§r${hintOf(st, d)}`); }   /* 第125版: 地方の 話の 番号と 案内 */
  const g = gateHint(d); if (g) L.push(g);
  return L.join("\n");
}

// ---------- だいじなもの を 使う ----------
export async function useKey(p, d, id) {
  if (!d) return;
  const it = ITEMS[id], s = qs(d);
  if ((s.mqPaid ?? -1) === (s.mq ?? 0) && (s.mq ?? 0) < MQ.length - 1) { s.mq = (s.mq ?? 0) + 1; save(p, d); }   // v2.9.12
  const st = stOf(s), MQI = s.mq ?? 0;
  const c = ctx(p, d);
  if (st && st.key === id && EP_HOOK.block && EP_HOOK.block(d, s.mq ?? 0)) { await notice(p, it.name, `§fまだ その 時では ない。先に 地方の 話を 進めよう。\n\n§e${String(storyNowHint(d)).replace(/§[0-9a-fk-or]/g, "")}`); return; }   /* 第125版: 地方の 新しい 話が 先 */
  if (st && st.key === id) {
    if (st.pre) { const m = st.pre(c); if (m) { await notice(p, it.name, m); return; } }
    if (!st.where(c)) { await notice(p, it.name, `${it.desc || ""}\n\n${st.whereMsg}`); return; }
    let done = false;
    EVT.add(p.id);   // v2.9.2: だいじなもの から 始まった できごとの あいだも ほかの できごとを 止める
    MQASK.add(p.id); MQRUN.add(p.id); MQRUN_KEY.add(p.id); MQSTALE.delete(p.id); const tok = {}; MQTOK.set(p.id, tok); let stale = false;   /* 第124版 */
    try { await stageBegin(p, st.at === "hall" && hallHere(p, st.r) ? hallStage(st.r) : { move: !underwater(p), R: 10 }); done = await (MQ_OVR[s.mq ?? 0] ? MQ_OVR[s.mq ?? 0](p, d, st) : st.run(p, d)); } catch (e) { if (e === LATER) { laterClean(p); } else console.warn(`[MonsterRPG] saga key: ${e} ${e?.stack || ""}`); } finally { stale = MQTOK.get(p.id) !== tok; if (stale && MQRUN.has(p.id)) return; MQTOK.delete(p.id); try { stageEnd(p, true); } catch {} spkClean(p); heroTmpClean(p); EVT.delete(p.id); MQASK.delete(p.id); MQRUN.delete(p.id); MQRUN_KEY.delete(p.id); SPAWNED.delete(p.id); try { if (!inScene(p)) busy.delete(p.id); } catch {} }   /* 第124版: 戦いの あとの busy を 外す（ほかの 場面中は のこす）*/
    if (stale) return;   /* 第124版: 外した 古い 流れは 段を 進めない（ほうびも 出て いない）*/
    { const dx = load(p); if (!done && dx && qs(dx).mqPaid === MQI) done = true; }
    if (!done) try { p.sendMessage("§7準備が できたら、もう一度 だいじなものを 使おう。§8（右上の 案内が 場所を 教えて くれる）"); } catch {}
    const d2 = load(p); if (d2 && done) { const s2 = qs(d2); if ((s2.mq ?? 0) === MQI) { s2.mq = MQI + 1; save(p, d2); } }
    return;
  }
  if (id === "k_note") { await notice(p, it.name, ["§a§lセオの 研究メモ", "", sagaHint(d), "", `§7行ける 地方: ${WREGIONS.slice(0, Math.min(WREGIONS.length, openUpTo(d) + 1)).map((R) => R.short).join("・")}`].join("\n")); return; }
  if (id === "k_light" && st && CAVE_R.includes(st.r) && (/洞くつ/.test(st.hint) || st.at === "hall" || st.at === "cave")) { await notice(p, it.name, "§f懐中電灯は 持っているだけで 光る。\n§e右上の 案内の 洞くつの 入口から、坂道を いちばん 奥まで 進もう。"); return; }   /* v2.9.12 */
  if (id === "k_hilt") {   // v3.0: すすみぐあいで 言うことを かえる（先の 物語を 明かさない）
    const s = qs(d);
    const t = s.enmaClear ? "§f戦いの 中で ムサシに 使うと、鍔の 力を 借りられる。§7（ガイドブック →「魔神の鍔を 使う」）"
      : s.musashiJoin ? "§fムサシと いっしょに §5閻魔の神殿§f へ 行こう。§7（神殿の 前で ガイドブックを 使う）"
      : s.hiltGot ? "§fカゲツの 弟子 §cムサシ§f を たずねよう。§7（はがねの 村 §eクロガネ§7）" : "§f鍔は 何かを 呼んで いる……";
    await notice(p, it.name, `§c赤黒く 光る 鍔。剣の 家が 千年 守り、クロガネの 鍛冶が 打った 鍔だ。\n\n${t}`); return;
  }
  await notice(p, it.name, `§6だいじなもの§r\n${it.desc || ""}`);
}

// ---------- 状況 ----------
function ctx(p, d) {
  const s = qs(d), l = p.location, sp = SP();
  let u, dp, tw, sg;
  return {
    p, d, s, r: p.dimension.id === "minecraft:overworld" ? (() => { const o = townReg(l); return o >= 0 ? o : regAt(l); })() : -1, dist: Math.hypot(l.x - sp.x, l.z - sp.z),
    get town() { return tw === undefined ? (tw = townAt(l, 38) || null) : tw; },
    get stage() { return sg === undefined ? (sg = stageNear(p) || null) : sg; },
    under: () => (u === undefined ? (u = underground(p)) : u),
    cave: (R) => inCave(p, R),
    depth: () => (dp === undefined ? (dp = depthOf(p)) : dp),
  };
}

// ---------- NPCの からみ（ランダム）・ライバル・ステージの 番人 ----------
/* 第113版: レイの ようすは 物語の 進みで かわる（0: ライバル／1: かけらに 呑まれかけ／2: 裏切りの あと／3: 竜が 石に なった あと） */
export const reiPhase = (s) => (s.reiFinal ? 3 : s.theoBetray ? 2 : s.jailDone ? 1 : 0);
const REI_T = [
  { sub: "「……おまえか」", ask: "「……おまえか。この あたりで 六影の 足跡を 追ってた ところだ。……ついでだ、腕が 鈍って ないか 見て やろうか？」", no: "そうか。……六影に 気を つけろよ。じゃあな",
    hi: ["竜の 調子を 見たかった ところだ。……行くぞ", "勝負の あとで、足跡の 話を しよう"],
    win: ["……また 負けた。理屈じゃ 勝てても、腕じゃ 勝てないな", "強いな。……次は、負けない"], lose: ["オレの 勝ちだ。……鍛え直して こい", "勝った。……足跡の 話は、ちゃんと 聞かせて やる"] },
  { sub: "「……見つけた」", ask: "「……よう。こんな 所で 会うとはな。かけらの 力、試させて くれよ」§7（レイの 目が、かすかに 赤い）", no: "……ちっ。まあ いい。次は 逃がさない",
    hi: ["見ろよ、力が あふれて 止まらない。……今の オレは、選ばれる 側だ", "牢の ことを 考えると、かけらが 熱く なる。……来い"],
    win: ["……くそっ。まだ 足りない。もっとだ、もっと……", "なんでだよ……かけらが あっても 届かない……"], lose: ["ハハ……勝った。かけらが あれば、オレだって……", "見たか。……これが オレの 力だ。……オレの、だよな"] },
  { sub: "「……少し、いいか」", ask: "「……こんな 所で 会うとはな。付き合って くれないか。かけらなしの 腕を、取り戻したいんだ」", no: "そうだよな。……今の オレが 頼める 立場じゃ ない",
    hi: ["かけらの ない 竜は、前より 遅い。……それで いい。これが 本当の オレの 力だ", "裏切った オレと、まだ 戦って くれるんだな。……ありがとう"],
    win: ["……やっぱり おまえは 強い。オレも、もう 迷わない", "負けた。でも、かけらの ときより ずっと 気分が いい"], lose: ["勝った……のか。自分の 力で。……そうか", "ごめん、手加減 できなかった。今の オレには、これしか ないから"] },
  { sub: "「よう、また 会ったな！」", ask: "「よう！ 旅の とちゅうか？ こいつらと 鍛えてる ところだ。勝負、どうだ？」", no: "そっか、また 今度な。ルミナに 帰る 前に、もう一回 やろうぜ",
    hi: ["竜が 石に なってから、こいつらに 助けられて ばっかりだ。……見てくれよ", "じいちゃんの しくじり帳、新しい 頁が 増えたんだ。今日の 勝負も 書いて おく"],
    win: ["完敗！ ……悔しいけど、楽しかった", "やっぱり おまえは すげえよ。また 頼む"], lose: ["勝った！ ……竜にも 見せたかったな", "へへ、今日は オレの 勝ち。しくじり帳に 書いとく"] },
];
async function rival(p, d, r) {
  const s = qs(d), ph = reiPhase(s), T = REI_T[ph];
  const e = npcNear(p, "§bライバル レイ", RIVAL_JOB);
  big(p, "§b§lライバル レイ", `§f旅先で ばったり……${T.sub}`, "raid.horn");
  // v2.9: 勝負は 自分で えらぶ（断っても あとで また 会える）。第122版: ばったり 会って 一言 → えらぶ
  if (!(await confirm(p, "ライバル レイ", `§b§lレイ§r\n\n§f${T.ask}`, "勝負する", "今は やめる"))) { await say(p, "レイ", [T.no]); rm(e); const d2 = load(p); if (d2) { const s2 = qs(d2); s2.reiT = Date.now(); save(p, d2); } return; }
  const hiL = ph === 3 && s.stoneBack ? ["あいつ、起きてから 毎日 オレを 乗せたがるんだ。……今日の 勝負も 一緒だ", T.hi[1]] : T.hi;
  await say(p, "レイ", [pick(hiL)]);
  const lv = Math.min(100, WREGIONS[r].lv[1] + 2);
  const foe = ph === 3 && !s.stoneBack ? team(["animal", "beast", "golem"], lv, 3, 8 + (s.reiW || 0) * 4) : team(["dragon", "animal", "beast"], lv, 3, 8 + (s.reiW || 0) * 4, leadOf("dragon", lv));   /* 竜が 石の あいだは 竜を 出さない（戻ったら 出す）*/
  const res = await battle(p, foe, { name: "ライバル レイ", arena: "ライバル", speaker: "レイ", lines: { half: ph === 1 ? "まだだ……かけらが もっと よこせって 言ってる！" : "まだだ！ ここからだ！" } });
  rm(e);
  const d2 = load(p); if (!d2) return;
  const s2 = qs(d2);
  if (res === "win") { s2.reiR = [...new Set([...(s2.reiR || []), r])]; s2.reiW = (s2.reiW || 0) + 1; } else s2.reiT = Date.now();   /* v2.9.13: 負けたら また 会える */
  await sayAt(p, "§bライバル レイ", RIVAL_JOB, "レイ", [pick(res === "win" ? T.win : T.lose)]);
  reward(p, d2, res === "win" ? 3000 + lv * 120 : 500, res === "win" ? [[pick(["e_silver", "e_red", "e_blue", "SEED2"]), 1]] : []); save(p, d2);
}
/* 第106版: ステージの 番人は 大地の まん中の 柱の 前で「大地の 宝」を 守って いる。近づくと 姿を 見せる。
   勝つと 宝（タマゴ・能力の 種・お金）と 制覇の 印★。全部の ステージを 制覇すると 称号と 特別な ごほうび */
const STAGE_HINT = new Map();
function stageHint(p, st) { const now = Date.now(); if (now - (STAGE_HINT.get(p.id) || 0) < 60000) return; STAGE_HINT.set(p.id, now); try { barNote(p).setActionBar(`§b${st.name || "ステージ"}§f: まん中の 柱の 前で §6番人§f が 大地の 宝を 守って いる`); } catch {} }
async function stageGuard(p, d, st) {
  const lv = Math.max(5, Math.min(100, regionLv(p.location) + 3));
  const fam = Object.keys(WREGIONS[st.r].fams || { beast: 1 });
  const foe = bossOne(fam, lv, Math.floor(lv / 4), 0);
  /* 番人の 姿を 柱の 前に 出す */
  let g = null; try { const I = landInfo(st.key); g = p.dimension.spawnEntity(MON_TYPE, { x: st.x + 0.5, y: (I && I.y ? I.y + 1 : p.location.y), z: st.z + 2.5 }); g.addTag("mrpg_temp"); g.addTag("mrpg_cine"); setLook(g, foe[0].sid); (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(g.id); g.nameTag = "§6ステージの 番人"; try { g.teleport(g.location, { facingLocation: p.location }); } catch {} } catch {}
  try {
    big(p, `§6§l${st.name || "ステージ"}の 番人`, "§f大地の 宝を 守って いる", "mob.ravager.roar");
    const all = (qs(d).sv || []).length, total = WREGIONS.reduce((a, _, i) => a + landSites(i).length, 0);
    if (!(await confirm(p, "ステージの 番人", `§b${st.name || "ステージ"}§r\n\n§f柱の 前で 番人が 大地の 宝を 守って いる。\n\n§e勝つと: §fタマゴ・能力の 種・お金と 制覇の 印\n§7（いま ${all}/${total} の ステージを 制覇。全部 制覇すると 称号と 特別な ごほうび）\n§7断っても、また 柱に 近づけば 挑める`, "挑む", "今は やめておく"))) { const d0 = load(p); if (d0) { const s0 = qs(d0); s0.svT = { ...(s0.svT || {}), [st.key]: Date.now() }; save(p, d0); } return; }
    const TH = { underworld: "soulvalley", void: "endcity", crystal: "dripstone", sea: "beach", ruins: "ruins" };
    const res = await battle(p, foe, { name: "ステージの 番人", arena: st.name || "ステージ", theme: TH[st.theme] || st.theme, hpk: 1.8, extra: 0.2, tag: "番人", speaker: "番人" });
    const d2 = load(p); if (!d2) return;
    const s2 = qs(d2);
    if (res !== "win") { s2.svT = { ...(s2.svT || {}), [st.key]: Date.now() }; save(p, d2); return; }
    s2.sv = [...new Set([...(s2.sv || []), st.key])];
    const n = s2.sv.length, egg = lv >= 60 ? "e_red" : lv >= 30 ? "e_silver" : "e_bronze";
    const items = [[egg, 1], [lv >= 50 ? "SEED3" : "SEED2", 2]];
    const allDone = n >= total && !s2.svAll; if (allDone) { s2.svAll = 1; items.push(["e_rainbow", 1], ["SEED3", 5]); }
    const got = reward(p, d2, 800 + lv * 150, items); save(p, d2);
    await notice(p, "大地の 宝", [`§6${st.name || "ステージ"}§f を 制覇した！ §e（制覇 ${n}/${total}）`, "", ...got.map((x) => "§e" + x), ...(allDone ? ["", "§d§lすべての ステージを 制覇した！ §r§f特別な ごほうびを 受けとった"] : [])].join("\n"));
  } finally { try { if (g) { globalThis.__mqCine?.delete(g.id); if (g.isValid()) g.remove(); } } catch {} }
}
/* 第122版: ランダムの レイは 町・城の 外（旅の とちゅう）だけ */
function nearCastle(l) { try { for (let i = 0; i < WREGIONS.length; i++) { const k = castleInfo(i) || castleSpot(i); if (k && Math.hypot(l.x - k.x, l.z - k.z) < 85) return true; } } catch {} return false; }
// 町の うわさ（はじめて 着いた ときだけ・ちょっとした できごと）
const RUMOR = [
  ["§e町の 子ども", "ねえねえ、知ってる？ 夜に なると 強い モンスターが 出るんだって！", [["c_herb2", 2]]],
  ["§e宿屋の おかみ", "旅の 人、顔色が 悪いよ。これ 持って いきな。", [["c_herbs", 1]]],
  ["§e行商人", "石板？ さあねえ。でも 石板の 近くでは モンスターが 騒ぐって 話は 聞くよ。", [["g_sp", 1]]],
  ["§e老人", "わしの 若い ころはのう、地方の 主に 挑む 若者で 町が にぎわった ものじゃ。", [["e_bronze", 1]]],
  ["§e漁師", "海の 深い ところは 真っ暗だ。潜るなら ゴーグルが 要るぞ。", [["c_herb2", 1]]],
  ["§e鉱夫", "洞くつの 奥は 何も 見えねえ。灯りなしで 入るのは 無茶だぜ。", [["c_herb2", 1]]],
];
async function townRumor(p, d, t) {
  const s = qs(d);
  s.tv = [...new Set([...(s.tv || []), t.id])]; save(p, d);
  const [who, line, items] = pick(RUMOR);
  await tell(p, t.name, `${who}§r\n\n§f「${line}」`);
  const got = reward(p, d, 0, items); save(p, d);
  if (got.length) try { p.sendMessage(`§a${got.join("・")} を もらった！`); } catch {}
}

// ---------- だいじなもの の 効果（懐中電灯・ゴーグル）----------
const HINT_T = new Map();
function keyFx(p, d) {
  const under = underground(p), uw = underwater(p);
  if (under && !uw) {
    if (hasKey(p, "k_light")) try { p.addEffect("night_vision", 320, { showParticles: false }); } catch {}
    else if (p.location.y < 40 && Date.now() - (HINT_T.get(p.id) || 0) > 40000) { HINT_T.set(p.id, Date.now()); try { barNote(p).setActionBar("§7暗くて よく 見えない……§8（懐中電灯が あれば……）"); } catch {} }
  }
  if (uw) {
    if (hasKey(p, "k_goggle")) { try { if (!globalThis.__mqDeep?.has(p.id)) p.addEffect("night_vision", 320, { showParticles: false }); p.addEffect("water_breathing", 320, { showParticles: false }); } catch {} }   /* 第125版: 深海の 海溝の 中は 暗いまま（deepsea.js）*/
    else { const dp = depthOf(p); if (dp >= 10) { try { p.addEffect("blindness", 50, { showParticles: false }); } catch {} if (Date.now() - (HINT_T.get(p.id) || 0) > 20000) { HINT_T.set(p.id, Date.now()); try { barNote(p).setActionBar("§3深すぎて 何も 見えない……§8（潜水ゴーグルが あれば……）"); } catch {} } } }
  }
}

// ---------- ループ ----------
const SAFE = new Map(), LAST = new Map(), INREG = new Map(), EVT = new Set();
// v2.9.12: ぬけた 人の 物語の 印は 消す（ほかの 人の 物語や あとかたづけを 止めない）
try { world.afterEvents.playerLeave.subscribe((e) => { const id = e.playerId; for (const x of SPAWNED.get(id) || []) rm(x); EVT.delete(id); MQRUN_KEY.delete(id); MQASK.delete(id); MQRUN.delete(id); MQTOK.delete(id); SPAWNED.delete(id); SAFE.delete(id); LAST.delete(id); INREG.delete(id); }); } catch {}
let tick = 0;
const DREAM_CD = new Map();
function runEvt(p, fn) {
  if (EVT.has(p.id)) return;
  EVT.add(p.id); busy.add(p.id); const tk = {}; EVTOK.set(p.id, tk);
  system.run(async () => { try { await stageBegin(p, { lazy: true, move: false }); await fn(); await closeWide(p); } catch (e) { console.warn(`[MonsterRPG] saga: ${e} ${e?.stack || ""}`); } finally { if (EVTOK.get(p.id) !== tk && EVT.has(p.id)) return; EVTOK.delete(p.id); try { stageEnd(p, true); } catch {} heroTmpClean(p); EVT.delete(p.id);   /* 第124版: 「バグを 直す」の あと 新しい できごとが 動いて いたら、古い 流れは 片づけない */ busy.delete(p.id); clearSkip(p); try { for (const e of world.getDimension("overworld").getEntities({ type: "mrpg:npc", tags: ["mrpg_autospk"] })) if (e.getDynamicProperty("mrpg:spkOwner") === p.id) e.remove(); } catch {} } });
}
/* 第106版: 地方の さかいに またがる 城・町・ステージは、持ち主の 地方として あつかう（城の 半分が となりの 地方で 押しもどされて いた） */
function siteReg(l, up) {
  try {
    for (let i = 0; i <= Math.min(up, WREGIONS.length - 1); i++) { const c = castleSpot(i); if (c && Math.abs(l.x - c.x) <= 72 && Math.abs(l.z - c.z) <= 72) return i; }
    for (const t of TOWNS) { if (t.reg === undefined || t.reg > up) continue; const q = townPos(t); if (q && Math.abs(l.x - q.x) <= 70 && Math.abs(l.z - q.z) <= 70) return t.reg; }
    for (let i = 0; i <= Math.min(up, WREGIONS.length - 1); i++) for (const S of landSites(i)) if (Math.abs(l.x - S.x) <= 48 && Math.abs(l.z - S.z) <= 48) return i;
  } catch {}
  return -1;
}
/* 第122版: さかいに またがる 町・城は 持ち主の 地方（物語の 段の 判定。ステージは ふつうの 地方で 見る）*/
function townReg(l) {
  try { for (let i = 0; i < WREGIONS.length; i++) { const c = castleSpot(i); if (c && Math.hypot(l.x - c.x, l.z - c.z) <= 72) return i; }
    for (const t of TOWNS) { if (t.reg === undefined) continue; const q = townPos(t); if (q && Math.hypot(l.x - q.x, l.z - q.z) <= 62) return t.reg; } } catch {}
  return -1;
}
function gateCheck(p, d) {
  const l = p.location, up = openUpTo(d); let r = regAt(l);
  if (r > up) { const o = siteReg(l, up); if (o >= 0) r = o; }
  if (r <= up) {
    let og = true; try { og = p.isOnGround !== false; } catch {}
    if (og) SAFE.set(p.id, { x: l.x, y: l.y, z: l.z });
    else {   // v2.9.6: 乗って いる・飛んで いる ときは 真下の 地面を 記録（遠くへ もどされない ように）
      try { for (let k = 1; k < 48; k++) { const b = p.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y) - k, z: Math.floor(l.z) }); if (b && !b.isAir && !b.isLiquid) { SAFE.set(p.id, { x: l.x, y: Math.floor(l.y) - k + 1.05, z: l.z }); break; } if (b && b.isLiquid) break; } } catch {}
    }
    return true;
  }
  const back = SAFE.get(p.id);
  let mount = null; try { mount = p.getComponent("minecraft:riding")?.entityRidingOn; } catch {}
  const to = back || (() => { const h = homeInfo(), s = SP(); return h && h.built ? { x: h.x, y: h.y + 0.1, z: h.z } : { x: s.x, y: s.y + 0.2, z: s.z }; })();
  try { if (mount) { mount.getComponent("minecraft:rideable")?.ejectRider(p); mount.teleport(to); } } catch {}
  try { p.teleport(to); } catch {}
  try { p.addEffect("slow_falling", 60, { showParticles: false }); } catch {}
  big(p, "§7まだ やるべき ことが あるようだ……", "§f引き返そう", "random.door_close");
  const g = gateHint(d); if (g) try { p.sendMessage(`§7まだ やるべき ことが あるようだ、引き返そう。 ${g}`); } catch {}
  return false;
}
/* ---------- 第108版: 物語は 決まった 場所で 待つ（町の 広場・城の 広場）。着いた とたんに 戦いが 始まらない ---------- */
const DIR8 = ["東", "南東", "南", "南西", "西", "北西", "北", "北東"];
const dirOf = (a, b) => DIR8[Math.round(((Math.atan2(b.z - a.z, b.x - a.x) * 180 / Math.PI) + 360) % 360 / 45) % 8];
/* 第112版: 場面の 場所へ 移る（暗転 → その 場所へ → 引きの 絵で 場所の 名前）。場所が まだ ない ときは その場で 引きの 絵だけ */
function townOfReg(r) { try { for (const t of TOWNS) if (t.reg === r) { const q = getTown(t.id); if (q && q.built) return t.id; } } catch {} return null; }
function castleQ(r) { try { const ci = castleInfo(r); if (ci && ci.built && ci.m) return { x: Math.floor(ci.m.x), y: Math.floor(ci.m.y), z: Math.floor(ci.m.z) }; } catch {} return null; }   /* 第122版: 城の 中庭だけ（城下の 中段広場＝噴水の 横は 使わない）*/
/* 第112版: 場面の 場所へ 移る（暗転 → その 場所へ → 引きの 絵で 場所の 名前）。場所が まだ ない ときは その場で 名前だけ。第122版: 高さが 分からない 所は 着いてから 地面を さがす */
async function sceneAt(p, q, nm) {
  if (!ok(p)) return false;
  if (q && Math.hypot(q.x - p.location.x, q.z - p.location.z) > 6) {   /* 第124版: 近くの 名前の 場所（玉座の 間など）でも 舞台を 移す（名前だけ 変わって 同じ 所、を なくす）*/
    if (!darkNow(p)) { camFade(p); await wait(10); } if (!ok(p)) return false;
    const y0 = typeof q.y === "number" ? q.y : Math.floor(p.location.y);
    try { p.addEffect("slow_falling", 80, { showParticles: false }); p.teleport({ x: q.x + 0.5, y: y0 + 1, z: q.z + 0.5 }, { dimension: world.getDimension("overworld") }); } catch { q = null; }
    if (q) { await wait(14); if (!ok(p)) return false;
      let A = { x: q.x + 0.5, y: y0 + 1, z: q.z + 0.5 }; if (typeof q.y !== "number") { const g = goodSpot(q.x, q.z, y0 + 12); if (g) A = { x: g.x + 0.5, y: g.y, z: g.z + 0.5 }; }
      if (stageOf(p)) await stageMove(p, A); else { const g = goodSpot(A.x, A.z, A.y + 6); if (g) try { p.teleport({ x: g.x + 0.5, y: g.y, z: g.z + 0.5 }); } catch {} } }   /* 第123版: 着いた 先でも 開けた 所を 舞台に */
  } else if (nm && inScene(p) && !darkNow(p)) { camFade(p); await wait(10); }   /* 第124版: 場面が 切りかわる ときは 暗く して から（人が 目の 前で わかない）*/
  await establish(p, p.location, nm); return true;
}
/* 第125版(vk): 貝笛を 吹く 所。deepsea.js が DIVE.at を 入れる（沖の 海溝の 沈んだ 神殿の 前 {x,z,y,F,B,built}・まだ 決まって いない ときは {x,z} だけ・海の ない 世界は null）*/
export const DIVE = { at: null };
const diveAt = () => { try { return DIVE.at ? DIVE.at() : null; } catch { return null; } };
function diveOk(c) { const D = diveAt(); if (!D) return c.r === 6 && c.depth() >= 8; if (D.B === undefined) return false; const l = c.p.location; return Math.hypot(l.x - D.x, l.z - D.z) <= 14 && l.y < D.F - 4 && c.depth() >= 8; }   /* 神殿の 前の 海の 底だけ（浅瀬・ステージでは 起きない）*/
function diveTgt(p) { const D = diveAt(); if (!D) return null; if (D.built) buoy(p, D); return { x: D.x, z: D.z, nm: "マリノアの 沖の ブイ（下に 沈んだ 神殿）" }; }
function buoy(p, D) {   /* 水面の ブイ（ワールドに 1回。近くに 来た とき）*/
  try { if (world.getDynamicProperty("mrpg:epdeco:r6buoy") || Math.hypot(p.location.x - D.x, p.location.z - D.z) > 64) return; const dim = p.dimension, x = Math.floor(D.x), z = Math.floor(D.z);
    for (let y = 70; y > 50; y--) { const b = dim.getBlock({ x, y, z }); if (!b) return; if (b.isAir) continue; if (!/water/.test(b.typeId)) return; dim.runCommand(`setblock ${x} ${y} ${z} red_concrete`); dim.runCommand(`setblock ${x} ${y + 1} ${z} oak_fence`); dim.runCommand(`setblock ${x} ${y + 2} ${z} lantern`); world.setDynamicProperty("mrpg:epdeco:r6buoy", 1); return; } } catch {}
}
/* 第125版(vk): 「岬まで 追う」→ 本当に 岬の 灯台へ 移る。灯台（epfac の lighthouse・ワールドに 1回）は 浜の 舞台の 横に 建てる（建たない ときは 町の 外れの 岬に 着いてから 暗い 中で）。
   暗転 → 舞台を 移す（灯台を 向く）→ put(灯台): 先に 来て いる 人を 暗い うちに 置く → 場所の 札 → 灯台の 引きの 絵。返す 値: 灯台の 見る 点 */
async function capeGo(p, put = null) {
  if (!ok(p)) return null;
  const y0 = Math.floor(p.location.y); let L = facCur("r6cape");   /* 第127版(fac2): 前の 小さな 灯台なら 建てなおす */
  if (!L) { const S = stageOf(p); if (S) L = facSide(p, S, 30, "r6cape", "lighthouse", 6, y0) || facSide(p, S, -30, "r6cape", "lighthouse", 6, y0); }
  const F = L ? facFront("r6cape", 9) : townOut("t15", -0.4, "岬");
  fadeOn(p, "0.4 1.6 0.6", "0 0 0"); FADED.set(p.id, system.currentTick); await wait(10); if (!ok(p)) return null;
  if (F) { const y = Number.isFinite(F.y) ? F.y : y0; try { p.addEffect("slow_falling", 60, { showParticles: false }); p.teleport({ x: F.x, y: y + 1, z: F.z }); } catch {} await wait(6);
    if (stageOf(p)) try { await stageMove(p, { x: F.x, y: Number.isFinite(F.y) ? F.y : p.location.y, z: F.z }, { R: 12, noEst: true, ...(L ? { face: L } : {}) }); } catch {} }
  if (!L && stageOf(p)) L = facBuild(p, stageOf(p), "r6cape", "lighthouse", 6, Math.floor(p.location.y));
  if (put) try { put(L); } catch {}
  await establish(p, p.location, "岬の 灯台");
  if (L) { camPt(p, L, 11, 3); sound(p, "random.splash", 0.6); await wait(26); }
  return L;
}
/* 第122版: 名前の 場所へ 移る（placeOf の kind）。ない ときは その場で 名前だけ */
async function goPlace(p, kind, r, nm) { const q = placeOf(kind, r, true); return sceneAt(p, q, nm || (q && q.nm) || ""); }
const drama = async () => {};   /* 第115版: 山場の カメラ回しは やめた（酔う）*/   /* 山場: 主人公の まわりを ぐるりと */
function garoSpot() { try { const t = TOWNS.find((u) => u.id === "t0"), q = t ? getTown(t.id) : null; if (!q || !q.built) return null; return { key: "garo", x: Math.floor(q.x), y: null, z: Math.floor(q.z) - 52, nm: "ルミナの 北の 門の 外", np: 1 }; } catch { return null; } }   /* 第115版: ガロの 場面は 城へ 向かう 道の 上 */
async function goScene(p, r, nm) { return sceneAt(p, castleQ(r), nm); }
function innOf(id) { return spotOf(id, "inn"); }
function mqSpot(p, d, i, st) {
  const s = qs(d);
  if (st.spot) { const q = st.spot(p, d); if (!q) return null; if (s.mqSpot && s.mqSpot.i === i && s.mqSpot.key === q.key) return s.mqSpot; const sp = { i, ...q }; s.mqSpot = sp; save(p, d); return sp; }
  if (s.mqSpot && s.mqSpot.i === i && s.mqSpot.v === SPOT_V) return s.mqSpot;   /* 第122版: 前の 版の 目印（噴水の 広場）は 捨てて 選びなおす */   /* 第122版: 前の 版の 目印（噴水の 広場）は 新しい 場所に 決めなおす */
  const r = st.r >= 0 && st.r < WREGIONS.length ? st.r : regAt(p.location);
  /* 第112版: 場面の 場所（at）で 物語を 起こす（城・大地・洞くつの 入口）。町の 広場では ない ときは np（「広場」と 書かない） */
  if (st.at && st.at !== "town") {
    let q = null;
    try {
      if (PLACES.has(st.at)) { q = placeOf(st.at, r); if (q && q.wait) return { i, ...q, np: 1 }; if (q) q.v = SPOT_V; }
      else if (st.at === "castle") { q = placeOf("court", r); if (q) q.v = SPOT_V; }   /* 第122版: 城の 中庭（ci.m）*/
      else if (/^land\d$/.test(st.at)) { const S0 = landSites(r)[+st.at.slice(4)] || landSites(r)[0]; if (S0) q = { x: S0.x + 24, y: null, z: S0.z, nm: `${WREGIONS[r].short}の 大地` }; }   // 柱（まん中）の 番人と 重ならない ように 少し 外す
      else if (st.at === "cave") { const v = caveInfo(r), b = !!(v && v.built), c = b ? v : caveSite(r); if (c) q = { x: Math.floor(c.x), y: b ? Math.floor(v.y) : null, z: Math.floor(c.z) - 7, nm: `${caveName(r)}の 入口`, ...(b && v.cv === CAVE_V ? { cv: CAVE_V } : {}) }; if (q && !b && st.hq !== undefined) return { i, ...q, np: 1, wait: 1 }; }   /* 第124版: アジトの 門は できてから（3分 できなければ alt の 場所）*/
    } catch {}
    if (q) { const sp = { i, ...q, np: 1, v: SPOT_V }; s.mqSpot = sp; save(p, d); return sp; }
  }
  return null;   /* 第122版: 場所の 決まって いない 段は その場で 起きる（城や 町の 広場へ 呼ばない）*/
}
/* 第122版: 洞くつの 広間（11×11・高さ 6。入口は 南の 階段）。中心 hall から 内側 ±5 */
const HALL = { w: 4.6, z0: -3.5, z1: 5.2, h: 5.6 };   /* 前の 版（11×11）の 広間 */
function inHall(p, v) { try { const h = v.hall, l = p.location; if (v.R) return Math.hypot(l.x - h.x, l.z - h.z) <= v.R - 3.5 && Math.abs(l.y - h.y) <= 1 && p.isOnGround !== false; return Math.abs(l.x - h.x) <= HALL.w && l.z - h.z >= HALL.z0 && l.z - h.z <= HALL.z1 && Math.abs(l.y - h.y) <= 1 && p.isOnGround !== false; } catch { return false; } }
/* 第128版: 丸い 大広間（半径 R・天井 H）。舞台は まん中、奥の 祭壇を 向く。人は 入口か 柱の 陰から 歩いて 来る。カメラは 広間の 中だけ */
function hallStage(r) { const v = caveInfo(r); if (!v || !v.hall) return { move: false }; const h = v.hall;
  if (!v.R) return { anchor: { x: h.x, y: h.y, z: h.z + 0.5 }, move: true, R: 4, face: { x: h.x, z: h.z + 6 }, box: { x1: h.x - 5.4, x2: h.x + 5.4, y1: h.y + 0.2, y2: h.y + 5.7, z1: h.z - 5.4, z2: h.z + 5.4 } };
  const b = v.R - 1.2, al = v.altar || { x: h.x, z: h.z + 9 };
  return { anchor: { x: h.x, y: h.y, z: h.z }, move: true, R: 4, face: { x: al.x, z: al.z }, box: { x1: h.x - b, x2: h.x + b, y1: h.y + 0.2, y2: h.y + v.H - 2.5, z1: h.z - b, z2: h.z + b }, from: [v.entry, ...(v.shade || [])].filter(Boolean) }; }
/* 第128版: 洞くつの 祭壇（精霊の 石・曇った 水晶）。舞台が 広間に なければ 前 k マス */
function altarPt(p, r, k, dy = 0) { try { const v = caveInfo(r), S = stageOf(p); if (S && v && v.altar && Math.hypot(v.altar.x - S.P.x, v.altar.z - S.P.z) < 14) return { x: v.altar.x, y: v.altar.y + dy, z: v.altar.z }; } catch {} return fwd(p, k, 0, dy); }
function caveNote(p, r, v) { const now = Date.now(); if (now - (MARK.get(p.id) || 0) < 8000) return; MARK.set(p.id, now); try { barNote(p).setActionBar(v && v.built ? (inCave(p, r) ? `§e${caveName(r)}の 奥の 大広間まで 進もう §7（物語は 大広間で 始まる）` : `§e！ §f${caveName(r)}の 奥の 広間で 物語が 待って いる §7（右上の 案内で 入口へ）`) : `§7${caveName(r)}は まだ できて いない……§8（少し 待って、もう一度 近づこう）`); } catch {} }
/* 第124版: 六影の アジト（洞くつの 広間）。hq: 地方 を 持つ 段は 広間で 演じる。3分 待っても できない ときは 今までの 場所（alt）で 始める（進行不能に しない）*/
const HQW = new Map();
function hallUp(r) { try { const v = caveInfo(r); return !!(v && v.built && v.hall && v.R); } catch { return false; } }
function hqDown(s, r) { return !hallUp(r) && (s.hqF === r || CAVE_NO.has(r)); }
function stOf(s, i = s.mq ?? 0) { const st = MQ[i]; return st && st.alt && hqDown(s, st.r) ? (st.altv || (st.altv = { ...st, ...st.alt })) : st; }
function hqWait(p, d, i, st) {   /* true = アジトが できるのを 待って いる */
  if (!st || st.hq === undefined || hallUp(st.hq)) { HQW.delete(p.id); return false; }
  const s = qs(d); if (hqDown(s, st.hq)) return false;
  const w = HQW.get(p.id), now = system.currentTick; if (!w || w.i !== i || now < w.t) { HQW.set(p.id, { i, t: now }); return true; }
  if (now - w.t < 3600) return true;   /* 3分 */
  s.hqF = st.hq; save(p, d); HQW.delete(p.id); return false;
}
function hallHere(p, r) { try { const v = caveInfo(r); if (!hallUp(r) || p.dimension.id !== "minecraft:overworld") return false; const l = p.location; return Math.hypot(l.x - v.hall.x, l.z - v.hall.z) <= v.R + 1 && Math.abs(l.y - v.hall.y) <= 3; } catch { return false; } }
/* 場面の 途中で アジトの 広間へ 移る（暗転 → 広間の 入口 → 舞台）。できて いなければ false（今までの 流れ）*/
async function goHall(p, r, nm) {
  if (!hallUp(r) || !ok(p)) return false; const v = caveInfo(r);
  if (!hallHere(p, r)) { if (!darkNow(p)) { camFade(p); await wait(10); } if (!ok(p)) return false;
    try { p.teleport({ x: v.entry.x, y: v.entry.y + 0.1, z: v.entry.z + 1 }, { dimension: world.getDimension("overworld") }); } catch { return false; }
    await wait(14); if (!ok(p)) return false; }
  const o = hallStage(r); if (stageOf(p)) await stageMove(p, o.anchor, o); await establish(p, p.location, nm); return true;
}
/* 氷の 隠れ家の 薄い 氷の 池（本当に 割る・もどす）。ほかの 人が 広間に いる ときは 割らない（今までの 沈む 芝居）*/
function iceBox(r) { const v = caveInfo(r); if (!hallUp(r) || !v.pool) return null; const x = Math.floor(v.pool.x), y = Math.floor(v.hall.y) - 1, z = Math.floor(v.pool.z); return { v, x, y, z }; }
const ICEB = new Map();   /* 氷を 割った 人 → 地方 */
function iceFix(p, r = 8) {   /* p の 割った 氷を もどす（ほかの 人が 割って いる あいだは さわらない）*/
  try { const id = p && p.id; if ([...ICEB.keys()].some((k) => k !== id)) return; const b = iceBox(r); if (!b) return; const D = world.getDimension("overworld");
    for (const m of ["water", "flowing_water", "air"]) D.runCommand(`fill ${b.x - 1} ${b.y} ${b.z - 2} ${b.x + 1} ${b.y} ${b.z + 2} ice replace ${m}`); if (id) ICEB.delete(id); } catch {}
}
function iceBreak(p, r = 8) { try { const b = iceBox(r); if (!b) return false; if (ICEB.size || world.getAllPlayers().some((q) => q.id !== p.id && hallHere(q, r))) return false; world.getDimension("overworld").runCommand(`fill ${b.x - 1} ${b.y} ${b.z - 1} ${b.x + 1} ${b.y} ${b.z + 1} air replace ice`); ICEB.set(p.id, r); return true; } catch { return false; } }
/* 割った 人が 場面を 終えた・抜けた・落ちた あとに 残った 穴を もどす（2秒ごとの step から）*/
function iceSweep() { for (const [id, r] of ICEB) { const q = world.getAllPlayers().find((x) => x.id === id); if (q && EVT.has(id)) continue; ICEB.delete(id); iceFix(null, r); } }
/* 第122版: 地面に 立って 止まって いるか（走る・落ちる・泳ぐ・乗る あいだは 物語を 始めない）*/
function steady(p) {
  try { if (p.isOnGround === false || p.isSwimming || p.isFalling || p.isGliding || p.isSprinting) return false; } catch {}
  try { if (p.getComponent("minecraft:riding")?.entityRidingOn) return false; } catch {}
  try { const v = p.getVelocity?.(); if (v && Math.hypot(v.x, v.z) > 0.12) return false; } catch {}
  return true;
}
const MARK = new Map();
function mqMarker(p, sp) {
  const l = p.location, far = Math.hypot(sp.x - l.x, sp.z - l.z);
  const now = Date.now(); if (now - (MARK.get(p.id) || 0) > 20000) { MARK.set(p.id, now); try { barNote(p).setActionBar(sp.wait ? `§7${sp.nm}は まだ できて いない……§8（少し 待って、もう一度 近づこう）` : `§e！ §f${sp.nm}${sp.np ? "" : "の 広場"}で 物語が 待って いる §7（${dirOf(l, sp)}へ ${Math.round(far)}m）`); } catch {} }
  if (far > 64 || sp.wait) return;
  if (sp.y === null || sp.y === undefined) { const q = goodSpot(sp.x, sp.z, Math.floor(p.location.y) + 20); if (q) { const d0 = load(p); if (d0) { const s0 = qs(d0); if (s0.mqSpot && s0.mqSpot.i === sp.i) { Object.assign(s0.mqSpot, q); save(p, d0); } } Object.assign(sp, q); } if (sp.y === null || sp.y === undefined) return; }
  try {
    const dim = world.getDimension("overworld");
    if (dim.getEntities({ type: "mrpg:npc", tags: ["mrpg_mqspot"], location: { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 }, maxDistance: 6 }).length) return;
    const e = dim.spawnEntity("mrpg:npc", { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 });
    setJob(e, 7); e.addTag("mrpg_npc"); e.addTag("mrpg_mqspot"); e.nameTag = "§e§l！§r §f物語が 待って いる";
  } catch {}
}
/* 第111版: 物語の 場所は 平らで かわいた 地面に（崖・水・木の 上に なって いた）。まわり ±12 から いちばん よい 所を えらぶ */
function goodSpot(x0, z0, y0) {
  const D = world.getDimension("overworld"); let best = null, bv = 1e9;
  const bad = (x, y, z) => { try { const b = D.getBlock({ x, y: y - 1, z }); return !b || b.isLiquid || /water|lava|leaves|log|ice|cactus|fence|magma/.test(b.typeId); } catch { return true; } };
  for (const [dx, dz] of [[0, 0], [4, 0], [-4, 0], [0, 4], [0, -4], [8, 0], [-8, 0], [0, 8], [0, -8], [6, 6], [-6, -6], [6, -6], [-6, 6], [12, 0], [-12, 0], [0, 12], [0, -12]]) {
    const x = Math.floor(x0 + dx), z = Math.floor(z0 + dz), y = groundY(D, x, z, y0); if (typeof y !== "number" || bad(x, y, z)) continue;
    let rough = 0, ok2 = true; for (const [a, c] of [[2, 0], [-2, 0], [0, 2], [0, -2]]) { const yy = groundY(D, x + a, z + c, y + 4); if (typeof yy !== "number" || bad(x + a, yy, z + c)) { ok2 = false; break; } rough += Math.abs(yy - y); }
    if (!ok2) continue; const v = rough * 3 + Math.hypot(dx, dz) * 0.2; if (v < bv) { bv = v; best = { x, y, z }; } if (rough === 0 && dx === 0 && dz === 0) break;
  }
  return best;
}
function mqMarkerClear(sp) { try { for (const e of world.getDimension("overworld").getEntities({ type: "mrpg:npc", tags: ["mrpg_mqspot"], location: { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 }, maxDistance: 8 })) e.remove(); } catch {} }
function step(p) {
  const d = load(p);
  if (!d || !d.party || !d.party.length) return;
  const s = qs(d);
  if (fixMq(p, d)) save(p, d);
  if (!EVT.has(p.id) && inJail(p)) { const J0 = jailHere(p); releaseJail(p); try { clearJail(world.getDimension("overworld"), J0); } catch {} try { p.sendMessage("§7牢屋から 出られた。"); } catch {} return; }
  if (exempt(p) || EVT.has(p.id)) return;
  // 関所
  if (!gateCheck(p, d)) return;
  const c = ctx(p, d);
  // 閻魔の神殿（はじめて 近づいたとき 悪夢）
  try { if (!s.enmaDream && !s.enmaJoin && !s.musashiJoin && !s.enmaClear && nearAltar(p, 6) && canFight(d) && !(Date.now() - (DREAM_CD.get(p.id) || 0) < 60000)) { DREAM_CD.set(p.id, Date.now()); runEvt(p, () => dreamFlow(p, fight, homeTp)); return; } } catch {}   // v3.0: すぐ busy・始められない ときは 1分 あける
  // メインクエスト
  const i = s.mq ?? 0; hqWait(p, d, i, MQ[i]); const st = stOf(s, i); if (ICEB.size) iceSweep();   /* 第124版: アジトが 3分 できなければ 今までの 場所の 段（alt）*/
  if (!s.mqT || s.mqT.i !== i) { s.mqT = { i, t: Date.now() }; save(p, d); }   /* 第124版: この 段に 入った 時刻（バグを 直す → 30分 進まない とき）*/
  if (st && s.mqPaid === i && i < MQ.length - 1) { s.mq = i + 1; save(p, d); return; }   // v2.9.12: ごほうびを もらった 段は とちゅうで ぬけても 先へ（2回 もらえない）
  // v2.9.13: 「あとで」・負けた あとは、ガイドブック →「物語の 戦いに 再挑戦」で もう一度
  if (s.mqHold && s.mqHold.i !== i) { delete s.mqHold; save(p, d); }   // v2.9.13: 再挑戦は ガイドブックで えらぶ（えらぶまで 物語は 進まない）
  let epw = 0; if (EP_HOOK.step) { try { epw = EP_HOOK.step(p, d, c) || 0; } catch (e) { console.warn(`[MonsterRPG] saga ep: ${e}`); } if (epw === 2) return; }   /* 第125版: 地方の 新しい 話が 先（1: 待って いる・2: 始めた）*/
  if (st && st.trig && !s.mqHold && canFight(d) && !epw) {
    let go = false; try { go = st.trig(c); } catch {}
    if (!go && !st.key && !st.nospot && s.mqSpot && s.mqSpot.i === i) go = true;   /* 場所が 決まった あとは そこへ 行けば 始まる */
    if (go && !st.key && !steady(p)) go = false;   /* 第122版: 地面に 立って 止まって いる ときだけ 始める（走る・落ちる・泳ぐ・乗る あいだは 待つ）*/
    if (go && !st.key && st.at === "hall") {   /* 第122版: 洞くつは 広間の 床に 立ってから（階段の 途中・入口では 始めない）*/
      const v = caveInfo(st.r); if (!v || !v.built || !v.hall || !inHall(p, v)) { go = false; caveNote(p, st.r, v); }
    } else if (go && !st.key && !st.nospot) {   /* 第108版: 決まった 場所（広場）に 着いて から 始める */
      const sp = mqSpot(p, d, i, st);
      if (sp) { const l = p.location; if (sp.wait || Math.hypot(sp.x + 0.5 - l.x, sp.z + 0.5 - l.z) > (sp.r || 4) || (typeof sp.y === "number" && Math.abs(sp.y - l.y) > 6)) { mqMarker(p, sp); go = false; } else if (typeof sp.y === "number") mqMarkerClear(sp); }
    }
    if (go) {
      runEvt(p, async () => {
        const dd = load(p); if (!dd) return;
        const chNew = st.ch && qs(dd).chSeen !== i; if (chNew) { qs(dd).chSeen = i; save(p, dd); }   // v2.9.13: 章の はじまり（第124版(fix2): 札は 舞台の あと、引きの 絵の 上に）
        { const sp4 = qs(dd).mqSpot, at = !st.key && !st.nospot && sp4 && sp4.i === i ? { x: sp4.x + 0.5, y: typeof sp4.y === "number" ? sp4.y : p.location.y, z: sp4.z + 0.5 } : null; await stageBegin(p, st.at === "hall" ? hallStage(st.r) : at ? { anchor: at, move: true } : { move: false }); }   /* 第123版: 場面は 決まった 場所の 開けた 平らな 所で（プレイヤーを 立ち位置へ）*/
        if (st.at === "ranch" || st.at === "forge") try { const S9 = stageOf(p); if (S9) { decorPlace(p.dimension, st.at, S9.P, S9); S9.C?.clear?.(); } } catch {}   /* 第123版: 牧場の 柵と 納屋・鍛冶場の 炉と 金床 */
        if (chNew) { let chL = st.ch; try { chL = (EP_HOOK.chapter && EP_HOOK.chapter(dd)) || st.ch; } catch {} big(p, `§6§l${chL}`, "§f物語が 動きだす", "ui.toast.challenge_complete"); if (inScene(p) && (await openWide(p, null))) await wait(20); else await wait(50); }
        if (!st.key && !st.nospot && qs(dd).estSeen !== i) { qs(dd).estSeen = i; save(p, dd); const sp3 = qs(dd).mqSpot; await establish(p, p.location, st.ch ? null : (sp3 && sp3.i === i ? sp3.nm : null)); }   /* 第112版: 場面の 始めに 引きの 絵 */
        if (qs(dd).introDone && !qs(dd).hero && !(await heroJoin(p))) return;   /* 第115版: 前の 版から 遊んで いる 人にも 旅の 仲間を */
        let done = false, later = false, next = false; MQASK.add(p.id); MQRUN.add(p.id); MQSTALE.delete(p.id); const tok = {}; MQTOK.set(p.id, tok); let stale = false;
        try { done = await (MQ_OVR[i] ? MQ_OVR[i](p, dd, st) : st.run(p, dd)); if (done === "next") { next = true; done = false; } } catch (e) { if (e === LATER) later = true; else console.warn(`[MonsterRPG] saga mq: ${e} ${e?.stack || ""}`); } finally { stale = MQTOK.get(p.id) !== tok; if (!stale) { MQTOK.delete(p.id); MQASK.delete(p.id); MQRUN.delete(p.id); } if (!stale || !MQRUN.has(p.id)) heroTmpClean(p); }
        if (stale) return;   /* 第124版: 「バグを 直す」で 外した 古い 流れは 段・「あとで」・負けの 数を 動かさない */
        { const dx = load(p); if (!done && !later && dx && qs(dx).mqPaid === i) done = true; }
        if (later) laterClean(p);
        if (next) { SPAWNED.delete(p.id); return; }   /* 第108版: 同じ 段の 次の 場所へ（止めない） */
        if (!done) try { p.sendMessage(`§7準備が できたら ${st.key ? "もう一度 だいじなものを 使おう" : "ガイドブック ＞ ストーリー ＞「物語の 戦いに 再挑戦」を えらぼう"}。§8（右上の 案内が 場所を 教えて くれる）`); } catch {}
        SPAWNED.delete(p.id);
        const d2 = load(p); if (!d2) return; const s2 = qs(d2);
        if ((s2.mq ?? 0) === i) { if (done) { s2.mq = i + 1; delete s2.mqHold; } else { const l = p.location; s2.mqHold = { i, x: Math.floor(l.x), z: Math.floor(l.z) }; if (!later) s2.mqLose = { i, n: (s2.mqLose && s2.mqLose.i === i ? s2.mqLose.n : 0) + 1 }; } save(p, d2); }   // v2.9.13: 時間では なく 場所で もう一度
      });
      return;
    }
  }
  // 歩いた かず
  const l = p.location, pv = LAST.get(p.id); LAST.set(p.id, { x: l.x, z: l.z });
  const moved = pv ? Math.hypot(l.x - pv.x, l.z - pv.z) : 0;
  if (!canFight(d)) return;
  // ステージの 番人（はじめて 来たとき）
  const sg = c.stage;
  if (sg && !(s.sv || []).includes(sg.key) && (s.mq ?? 0) >= 2) {   /* 第106版: 柱（まん中）の そばに 来たら 番人が 出る。まわりでは 案内だけ */
    if (Math.hypot(p.location.x - sg.x, p.location.z - sg.z) < 7 && Date.now() - ((s.svT || {})[sg.key] || 0) > 30000) { runEvt(p, () => stageGuard(p, d, sg)); return; }
    stageHint(p, sg);
  }
  // 町の うわさ（はじめて 来たとき）
  const tw = c.town;
  if (tw && !(s.tv || []).includes(tw.id) && tw.id !== "t0") { runEvt(p, () => townRumor(p, d, tw)); return; }
  // ライバル（地方ごとに 1回・入って しばらく たってから）
  const ir = INREG.get(p.id); if (!ir || ir.r !== c.r) INREG.set(p.id, { r: c.r, t: Date.now() });
  if (c.r >= 2 && !c.town && !nearCastle(l) && (s.mq ?? 0) > MQ.findIndex((x) => /^第3章/.test(x.ch || "")) && !(s.reiR || []).includes(c.r) && Date.now() - (s.reiT || 0) > 600000 && Date.now() - (INREG.get(p.id)?.t || Date.now()) > 120000 && moved > 2 && Math.random() < 0.15) { runEvt(p, () => rival(p, d, c.r)); return; }
  // v2.9: NPCに からまれる 戦いは なし（うろついている モンスターマスターに 話しかけると 勝負できる）
}
export function initSaga() {
  system.runInterval(() => {
    tick++;
    for (const p of world.getAllPlayers()) {
      try {
        if (tick % 2 === 0) step(p);
        const d = load(p);
        if (d && tick % 2 === 1 && !busy.has(p.id)) keyFx(p, d);
        if (d && tick % 30 === 5 && !busy.has(p.id) && !EVT.has(p.id)) { const back = syncKeys(p, d); if (back.length) { save(p, d); try { p.sendMessage(`§d手元に なかった ものが もどってきた: §f${back.join("・")}`); } catch {} } }
      } catch (e) { console.warn(`[MonsterRPG] saga loop: ${e}`); }
    }
  }, 20);
}
// チート: 関所を なくす／もどす
export function setGateFree(d, v) { const s = qs(d); s.gateFree = !!v; }

// v2.9.8: 物語の とちゅうで ワールドを 閉じた ときに のこった 会話用の 人を 片づける（読みこみ 直後と、ときどき）
system.runInterval(() => {
  for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
    try { for (const e of world.getDimension(id).getEntities({ type: "mrpg:npc", tags: ["mrpg_saga"] })) { if (EVT.size === 0 && !(globalThis.__mqStageZ?.size > 0)) try { e.remove(); } catch {} } } catch {}   /* 第124版(fix2): だれかの 場面（闘技場・セオの 最後）の あいだは 消さない */
  }
}, 1200);

// v2.9.13: 「あとで」・負けて 止まって いる 物語の 戦い（ガイドブックから 再挑戦を えらぶ）
export function mqHeld(d) { try { if (EP_HOOK.held && EP_HOOK.held(d)) return true; const s = qs(d), i = s.mq ?? 0; return !!(s.mqHold && s.mqHold.i === i && MQ[i] && MQ[i].trig); } catch { return false; } }
export function mqRetry(p, d) {
  { const m = EP_HOOK.retry && EP_HOOK.retry(p, d); if (m) return m; }   /* 第125版: 地方の 新しい 話 */
  const s = qs(d); delete s.mqHold; save(p, d);
  const st = MQ[s.mq ?? 0];
  let here = false; try { here = !!(st && st.trig && st.trig(ctx(p, d))); } catch {}
  return here ? "§aもう一度 挑む！ §7（ガイドブックを 閉じると 始まる）" : `§aもう一度 挑む 準備が できた。§f${(() => { try { return hintOf0(st, d); } catch { return ""; } })()} §7（その 場所へ 行くと 始まる）`;
}

// v2.9.13: 「バグを 直す」用: 止まった 物語の できごとの しるしを 外す（呼んだ 人だけ）
export function sagaUnlock(p) {
  let n = 0;
  if (MQRUN.has(p.id)) MQSTALE.add(p.id);   /* 第124版 */
  MQTOK.delete(p.id); EVTOK.delete(p.id);
  for (const S of [EVT, MQASK, MQRUN, MQRUN_KEY]) if (S.has(p.id)) { S.delete(p.id); n++; }
  if (SPAWNED.has(p.id)) { laterClean(p); n++; }
  return n;
}
/* 第124版: 「バグを 直す → 物語が 進まない」用（呼んだ 人だけ）。今の 段の ようす */
export function mqFixInfo(p, d) {
  { const f = EP_HOOK.fix && EP_HOOK.fix(p, d); if (f) return f; }   /* 第125版: 地方の 新しい 話 */
  const s = qs(d), i = s.mq ?? 0, st = stOf(s, i); if (!st) return null;
  const need = !!(st.trig && !st.key && !st.nospot && (st.at || st.spot));
  let sp = null;
  if (need) { if (st.at === "hall") { const v = caveInfo(st.r); sp = v && v.built && v.hall ? { ...v.hall, nm: `${caveName(st.r)}の 広間` } : { wait: 1, nm: caveName(st.r) }; } else try { sp = mqSpot(p, d, i, st); } catch {} }
  return { i, st, need, sp, lose: s.mqLose && s.mqLose.i === i ? s.mqLose.n : 0, mins: s.mqT && s.mqT.i === i ? Math.floor((Date.now() - s.mqT.t) / 60000) : 0, canSkip: i < POST - 1, post: st.r === 99 };
}
/* 古い 目印・「あとで」を 捨てる（呼んだ あとで save）*/
export function mqSpotReset(p, d) {
  const s = qs(d), out = [];
  if (s.mqSpot) { if (typeof s.mqSpot.y === "number") mqMarkerClear(s.mqSpot); delete s.mqSpot; out.push("物語の 場所の 目印を 選びなおした"); }
  if (s.mqHold) { delete s.mqHold; out.push("「あとで」・負けて 止まって いた 物語の 戦いを、場所へ 行けば また 始まる ように した"); }
  delete s.estSeen; MARK.delete(p.id);
  try { if (EP_HOOK.reset) out.push(...EP_HOOK.reset(p, d)); } catch {}   /* 第125版: 地方の 新しい 話の 目印・「あとで」*/
  return out;
}
/* 右上の 案内の 場所へ ワープ（地面に 立てる 所。読みこまれて いない ときは 上空から ゆっくり 降りて 着地点を 探す）*/
export function storyWarp(p, d) {
  let g = null; try { g = storyTarget(p, d); } catch {}
  if (!g || typeof g.x !== "number" || typeof g.z !== "number") return null;
  const ow = world.getDimension("overworld"), x = Math.floor(g.x), z = Math.floor(g.z);
  const land = () => { try { const t = ow.getTopmostBlock({ x, z }); const q = t ? goodSpot(x, z, t.location.y + 1) : null; if (q) { p.teleport({ x: q.x + 0.5, y: q.y, z: q.z + 0.5 }, { dimension: ow }); return true; } } catch {} return false; };
  try { p.addEffect("slow_falling", 400, { showParticles: false }); } catch {}
  if (p.dimension.id !== "minecraft:overworld" || !land()) {
    try { p.teleport({ x: x + 0.5, y: 200, z: z + 0.5 }, { dimension: ow }); } catch { return null; }
    let n = 0; const again = () => { if (!ok(p) || land()) return; n++;
      if (n > 10) { try { const t = ow.getTopmostBlock({ x, z }); if (t) { p.teleport({ x: x + 0.5, y: t.location.y + 1.2, z: z + 0.5 }, { dimension: ow }); return; } } catch {} if (n > 40) return; try { p.addEffect("slow_falling", 400, { showParticles: false }); } catch {} }   /* 第124版: 良い 着地点が ない（海・木）ときも 真上の 地面へ。空の 上に 残さない */
      system.runTimeout(again, 20); }; system.runTimeout(again, 10);
  }
  return g.name || "物語の 場所";
}

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { HINT_T.delete(playerId); DREAM_CD.delete(playerId); } catch {} }); } catch {}
/* 第125版: 地方の 5話（sagaep.js・ep_r*.js）が 使う 部品。ここで まとめて わたす（中身は この ファイルの もの）*/
export const SGK = { offstage, offBegin, offEnd, OFFS, exitPt, say, hsay, pal, narr, npcNear, npcAt, heroNear, heroBox, heroOf, HN, V, act, hold, give, go, knock, knockP, leave, bye, re, cut, camPt, camNear, camLowUp, fwd, away, place, big, shake, flash, boom, burst, blaze, shadowFlow, engulf, memory, sixMark, palEnt, monEnt, rmCine, battle, reward, team, bossOne, leadOf, giveKey, keyHand, techo, wonOf, setWon, RT, sayAt, rm, rmName, sceneAt, goodSpot, steady, mqMarker, mqMarkerClear, runEvt, heroJoin, heroTmpClean, laterClean, MQASK, MQRUN, MQTOK, MQSTALE, SPAWNED, LATER, EVT, PJ, garoSpot, POST };
