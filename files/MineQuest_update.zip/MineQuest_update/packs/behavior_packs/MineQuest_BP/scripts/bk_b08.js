/* 第126版 本8「冥府の霊廟」（ネクロス冥府領・ソウラ／ファントム／冥王の城）— セオの 正体 — 作業 MB
   1 墓守の丘（r7e1）→ 2 灯籠流し（r7e2）→ 3 葬列の道（r7e3）→ 4 妃の庭の跡→城の書庫
   → MQ17: 5 城の中庭（葬列の 護衛。第125版 第8章の 撮り直しを 引きとる）・6 霊廟の奥（明かし）・7 霊廟の奥（レイ・C05）
   → MQ18: 8 冥王の城（ヨミに 勝った あと、石に）→ 9 もう一度の灯籠（C08）*/
import { world } from "@minecraft/server";
import { bkAdd, mqOver } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facAt, fac } from "./epfac.js";
import { townOut, placeOf, farOf } from "./storyplace.js";
import { caveInfo } from "./structures.js";
import { setJob, ok } from "./ui.js";
import { plazaOf, festSet, moveG, unstack, castleOut, gateSet } from "./pvplace.js";
import { H4, Y0, chOf, did, oldRun, toSet, mk, letter, tOut, near, PL, RJ, TJ } from "./bk_b05.js";

const { F, S1 } = FAC_OPS;
const T = (s) => (s && typeof s === "object" ? s : {});
const SOURA = "t26";
/* 霊廟の 奥の 座の 卓（広間が ない 世界）: 六つの 席の 卓・卓の 上の 手帳（書見台）・棺・紫の 灯 */
facAdd("b8seat", { D: [12, 14], box: [-1, -4, 8, 4], H: 5, look: [5, 0, 1.2], marks: { table: [5, 0, 1.1], book: [5, 0, 1.2], seat2: [5, 2, 0], coffin: [7, -3, 0], floor: [3, 0, 0], lan: [2, -3, 0] }, build: (P) => [
  F(-1, -4, -1, 8, 4, -1, "deepslate_tiles"), F(8, -4, 0, 8, 4, 4, "deepslate_bricks"), F(4, -1, 0, 6, 1, 0, "dark_oak_planks"), S1(5, 0, 1, "lectern"),
  S1(3, 0, 0, "dark_oak_stairs"), S1(7, 0, 0, "dark_oak_stairs"), S1(4, 2, 0, "dark_oak_stairs"), S1(6, 2, 0, "dark_oak_stairs"), S1(4, -2, 0, "dark_oak_stairs"), S1(5, 2, 0, "purple_wool"),
  F(7, -4, 0, 7, -2, 0, "polished_deepslate"), S1(8, -4, 3, "soul_lantern"), S1(8, 4, 3, "soul_lantern"), S1(2, -3, 0, "white_candle"),
] });
/* 妃の 庭の 跡（ファントム）: 枯れた 花壇・こわれた ベンチ・妃の 紋の 石 */
facAdd("b8garden", { D: [11, 13], box: [-1, -4, 6, 4], H: 3, look: [3, 0, 0.6], marks: { bench: [1, 3, 0], crest: [5, 0, 1] }, build: (P) => [
  F(2, -3, -1, 5, 3, -1, "coarse_dirt"), S1(2, -2, 0, "dead_bush"), S1(3, 1, 0, "wither_rose"), S1(4, -1, 0, "dead_bush"), S1(5, 2, 0, "dead_bush"),
  F(1, 3, 0, 2, 3, 0, "dark_oak_slab"), F(5, 0, 0, 5, 0, 1, "chiseled_deepslate"), S1(0, -4, 0, "cracked_deepslate_bricks"), S1(0, 4, 0, "cracked_deepslate_bricks"),
] });

/* ---------- 場所 ---------- */
const HILL0 = tOut(SOURA, "b8hill", 0.9, "ソウラの 外れの 墓守の 丘"), HILL = () => farOf("r7hill", SOURA, "ソウラの 墓守の 丘", 80, 260) || HILL0();   /* 第127版(fac2): 離れた 丘の 墓地 */
const RIVER = tOut(SOURA, "b8riv", -0.9, "ソウラの 川べり（灯籠流しの 水路）");
/* 第126版(PV): 灯籠流しの 夜は 町の 広場に 集まり、灯籠を 運んで 川べりへ */
const SPLAZA = () => { const q = plazaOf(SOURA, "たましいの 町 ソウラの 広場（灯籠流しの 夜）"); return q ? { x: q.x, z: q.z, nm: q.nm } : RIVER(); };
const ROAD = () => { const f = farOf("r7road", SOURA, "冥王の 葬列の 道", 90, 320); if (f) return f; const o = placeOf("road", 7); return o ? { x: o.x, z: o.z, nm: "冥王の 葬列の 道" } : null; };
const GARDEN0 = tOut(SOURA, "b8gdn", 0.3, "ファントムの 妃の 庭の 跡"), GARDEN = () => farOf("b8garden", SOURA, "ファントムの 妃の 庭の 跡", 90, 300) || GARDEN0();
const SEO8 = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", TJ, w);
const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", RJ, w);
const MORTE = (K, p, w = false) => K.npcNear(p, "§5冥王 モルテ", K.PJ("morte", 15), w);
const YOMI = (K, p, w = false) => K.npcNear(p, "§6ヨミ", K.PJ("yomi", 8), w);
/* 霊廟の 奥へ（アジトの 広間が あれば そこ、なければ 座の 卓の セット）。返す 値: 卓の 点 */
async function crypt(K, p, drop = []) {
  let v = null; try { v = caveInfo(7); } catch {}
  if (v && v.built && v.hall && v.R) { const al = v.altar || { x: v.hall.x, z: v.hall.z + 9 }; await K.moveTo(p, { x: v.hall.x, y: v.hall.y, z: v.hall.z }, "霊廟の 奥", drop, { x: al.x, y: v.hall.y + 1, z: al.z }, 4); return { x: al.x, y: v.hall.y + 1.1, z: al.z - 2 }; }
  const L = facAt("b8seat", p.location, 120) ? (await K.wait(1), facAt("b8seat", p.location, 120)) : await toSet(K, p, "b8seat", "b8seat", 7, "霊廟の 奥", drop);
  return mk("b8seat", "table", p) || L;
}

/* ---------- 町の 人 ---------- */
castAdd("b8beate", { nm: "ベアテ", role: "元侍女", col: "§d", gobi: "ですよ", skin: "maria2", town: SOURA, hide: (s) => !did(s, "b08e4"), at: near(RIVER, -2, -3),
  pre: ["{closed}……庭の 手入れは、もう だれも しないのですよ。"],
  after: [
    [(s) => !!s.ending, ["{smile}妃さまの 灯籠の 前で、陛下が 初めて 笑ったのですよ。……迎える 灯籠を 選んだ 人たちの おかげです。"]],
    [() => true, ["{sad}書庫の 窓辺の 席。……あの 席は、ヨミさまが 毎朝 椅子を 引いて おられたのですよ。"]],
  ] });

/* ---------- 1〜3話（第125版の 場面を 引きとる）---------- */
const E1 = { id: "b08e1", pv: 127, t: "たましいの町ソウラ（墓守の丘）", place: HILL, F: ["F27", "F28"],
  hint: "§fたましいの 町 §eソウラの 外れの 墓守の 丘§f へ 行こう",
  syn: "墓守の ユラが 帳の 写しを 読む。「写しは、もっと 古い 帳の 写し。元の 帳を 書いて いた 王さまは、ある 日 筆を 折った」。白い 灯籠は 送り、赤い 灯籠は 迎え。写しに ルミエの 石の 子の 名は なかった。灯籠屋で、紫の 指の 後ろ姿が 白い 灯籠を 買って いた。",
  async run(p, d, K) {
    return oldRun(p, d, K, E1, 7, "r7e1", { post: async (p, K) => {
      const eY = K.cast(p, "r7_yura"); K.act(eY, "hold"); K.hold(eY, "notebook");
      { const h = K.hero(p, false); if (h && ok(eY)) { await K.approach(p, h, eY, 2, 12); await K.ots(p, eY, h, 10); } }
      await K.hsay(p, H4("{?}……ユラちゃん。ルミエの 小川の、石の 男の子の 名前、写しに ある？", "{?}……ルミエの 石の 男の子の 名前、写しに 載って いる？", "{?}ルミエの 石の 子。写しに 名前は。", "{?}ルミエの 石の 男の子の お名前は、写しに ありますか。"), eY);
      await K.csay(p, "r7_yura", /*F27*/["{closed}……さがして みるのです。……ない のです。", "{smile}石に なった 人は、書かれて いないのです。死んで いないから なのです。"]);
      const q = K.fwd(p, 6, -3);
      if (q) await K.at(p, q, 16, 6, 1.4);
      await K.narr(p, /*F28*/["§7丘の 下の 灯籠屋で、外套の 後ろ姿が 白い 灯籠を 一つ 買って いく。", "§7左手の 中指だけ、紫の インクで 染まって いた。"], q);
      await K.hsay(p, H4("{?}……今の 人、白い 灯籠。送る ほう……。", "{?}……白い 灯籠。送る ほう、よね。", "{closed}……白。送る 灯籠。", "{?}……白い 灯籠。お送りする ほう……"));
    } });
  } };
const E2 = { id: "b08e2", t: "ソウラの川べり（灯籠流し）", place: SPLAZA, F: ["F06", "F37"],
  hint: "§fソウラの §e広場§f へ 行こう §7（灯籠流しの 夜。広場から 川べりへ）",
  syn: "灯籠流しの 夜。ピピが 来た。セオの 白い 灯籠には 火が 入って いなかった。「……弟です」。冥王モルテは「妃の 灯籠だけは、流せぬ」と 言った。",
  async run(p, d, K) { return oldRun(p, d, K, E2, 7, "r7e2", { post: async (p, K) => {
    const eM = K.cast(p, "r7_morte"); K.act(eM, "hold"); K.hold(eM, "lantern");
    await K.csay(p, "r7_morte", /*F37*/["{closed,low}……妃の 灯籠だけは、流せぬ。白も、赤も。……どちらも 選べぬ まま、十年だ。"]);
    /*F06 セオ「……弟です」は r7e2 の 場面 */
  } }); } };
const E3 = { id: "b08e3", pv: 127, t: "冥王の葬列の道", place: ROAD, fac: "r7nest", F: ["F08"],
  hint: "§f§e冥王の 葬列の 道§f の 墓場の モンスターを はらおう",
  syn: "イザクが 抜け道を 見つけ、紫の インクの、ひらいた 本の 判の 紙切れを 拾った。黒い 外套の 男が 見て いた。",
  async run(p, d, K) { return oldRun(p, d, K, E3, 7, "r7e3"); /*F08 紫の 判の 紙切れ（r7e3 の 場面）*/ } };

/* ---------- 4話 妃の庭の跡→冥王の城の書庫 ---------- */
const E4 = { id: "b08e4", pv: 127, t: "ファントムの妃の庭の跡→冥王の城の書庫", place: GARDEN, fac: "b8garden", F: ["F08", "F14", "F37"],
  hint: "§fソウラの 外れの §eファントムの 妃の 庭の 跡§f へ 行こう",
  syn: "元侍女ベアテに 会った。書庫の 写しの 貸し出し札に「イリア」、その 下に 紫の インクで「セオ」。窓辺の 卓には、一つだけ 椅子が 引いて ある 席が あった。ヨミが 毎日 引いて おくのだと いう。",
  async run(p, d, K) {
    const G = fac(K, p, "b8garden", "garden", 7, Y0(K, p));
    await K.open(p, "ファントムの 妃の 庭の 跡", "dusk");
    const eH = K.hero(p); if (G) await K.at(p, G, 14, 6, 1.2);
    const eB = K.cast(p, "b8beate"); K.act(eB, "hold"); K.hold(eB, "bouquet");
    await K.csay(p, "b8beate", ["{closed}……旅の 方。ここは 妃さまの 庭 だったのですよ。わたくしは 侍女の ベアテ。", "{sad}妃さまが 石に なって 十年。花は、わたくし 一人では 守れませんでした。"]);
    await K.csay(p, "b8beate", /*F14*/["{closed}妃さまの そばには、いつも 仮面の 近衛が 一人 いたのですよ。妃さまが 石に なった 夜から、姿を 見ないのです。"]);
    await K.hsay(p, H4("{?}……仮面の 近衛。荒野の 壁画にも 描いて あった。", "{?}……仮面の 近衛……。壁画の すみにも。", "{closed}仮面の 近衛。壁画で 見た。", "{?}仮面の 近衛……壁画にも 描かれて いました。"));
    await K.csay(p, "b8beate", ["{smile}妃さまは 本の 好きな 方でした。……城の 書庫を、ご案内 するのですよ。"]);
    /* 書庫へ */
    const Lb = await toSet(K, p, "b8lib", "library", 7, "冥王の 城の 書庫", [eB, K.hero(p, false)]);
    const eH2 = K.hero(p), eB2 = K.cast(p, "b8beate");
    K.act(eB2, "show"); K.hold(eB2, "scroll"); await K.push(p, eB2, 20, 3.5, 1.2, 1.1);
    K.card(p, "§8貸し出し札\n\n§7イリア\n§5セオ", 80); await K.wait(70);   /*F08 紫の インク*/
    await K.narr(p, ["§7古い 写しの 貸し出し札。上に「イリア」。その 下に、紫の インクで「セオ」。"], eB2);
    await K.hsay(p, H4("{shock,!}……セオさんの 名前！？ 紫の インク……葬列の 道の 紙切れと 同じ 色。", "{shock,…}……セオさん。紫の インク……", "{closed}……紫の インク。葬列の 道の 紙と 同じ。", "{shock,!}セオさんの お名前……紫の インク……"));
    await K.csay(p, "b8beate", ["{closed}妃さまと 同じ 写しを、若い 学者さんが 何度も 借りに 来たのですよ。"]);
    const q = Lb || K.fwd(p, 5, 2); await K.push(p, q, 22, 5, 2, 1);
    await K.narr(p, ["§7窓辺の 卓。椅子が 一つだけ、すぐ 座れる ように 引いて ある。"], q);
    await K.csay(p, "b8beate", /*F37*/["{sad}……ヨミさまが、毎朝 引いて おられるのですよ。あの 学者さんの 席を。", "{closed}陛下も 同じ。妃さまの 灯籠を、流せずに 持って おられる。……待つ 人ばかりの 城なのですよ。"]);
    K.pay(p, E4, 900, [["c_herbs", 2]]);
    await K.end(p, { leave: [eB2], card: "§7→ 冥王の 城の 中庭へ（セオとの 待ち合わせ）", kind: "dusk" });
    return true;
  } };

/* ---------- 5話 冥王の城の中庭（MQ17）---------- */
const E5 = { id: "b08e5", t: "冥王の城の中庭", battles: 2, F: ["F07"],
  hint: "§fネクロス冥府領の §e冥王の 城の 中庭§f へ 行こう §7（セオとの 待ち合わせ）",
  syn: "葬列の 護衛を 頼まれた（城の 中庭から 葬列の 道へ）。棺の 中は 石の 子ども。黒い 外套の 男（六の座の 回し者）が「参謀に 会わせるな」と 立ちふさがった。葬列の 道で 見て いた 男だった。",
  async run(p, d, K) {
    await K.open(p, "冥王の 城の 中庭", "castle");
    const eH = K.hero(p), eM = MORTE(K, p);
    const cf = K.fwd(p, 6, 1.5); if (cf) { const x = Math.floor(cf.x), y = Math.floor(cf.y), z = Math.floor(cf.z); K.cmd(p, `fill ${x} ${y} ${z} ${x + 1} ${y} ${z} dark_oak_slab keep`); }
    await K.say(p, "冥王 モルテ", ["{closed,low}……来て くれたか。今日は 葬列の 日だ。家族が『送る』と 決めた 石の 者を、霊廟へ 送る。", "{angry,up}近ごろ 影の モンスターが 棺を 狙う。……護衛を 頼む。セオと いう 学者も、霊廟の 奥で 待って おる。"]);
    await K.hsay(p, H4("{angry}引き受けた！ 棺には ぜったい さわらせない。", "{closed}……分かりました。お手伝い します。", "{closed}引き受ける。セオにも 会う。", "{closed}お引き受け します。"));
    if (cf) await K.push(p, cf, 20, 4, 1.6, 0.4);
    await K.narr(p, ["§7黒い 棺の ふたが、少し ずれて いる。中に、小さな 石の 子ども。"], cf);
    /* 第126版(PV): 葬列は 城門を 出て 葬列の 道へ。墓場の モンスターと 回し者とは 城の 外で 戦う */
    { const RD = castleOut(7, "冥王の 城の 城門の 外（葬列の 道）") || ROAD(); if (RD) { const CQ = placeOf("court", 7); if (CQ) gateSet(p, "c7gate", RD, CQ, Y0(K, p)); await K.narr(p, ["§7鐘が 鳴り、葬列は 城門を 出た。黒い 棺を かついで、霊廟への 道を 進む。"], cf); await moveG(K, p, RD, "冥王の 城門の 外（葬列の 道）", [eM].filter(ok)); K.hero(p); MORTE(K, p); const c2 = K.fwd(p, 4, 1.5); if (c2) { const x = Math.floor(c2.x), y = Math.floor(c2.y), z = Math.floor(c2.z); K.cmd(p, `fill ${x} ${y} ${z} ${x + 1} ${y} ${z} dark_oak_slab keep`); } } }
    const a = K.fwd(p, 8, 3), b = K.fwd(p, 3); if (a && b) { await K.shadowFlow(p, a, b, 16); K.shake(p, 0.4, 0.5); }
    const r1 = await K.battle(p, K.team(["nether", "nether", "animal"], 54, 3, 14), { name: "墓場の モンスター", arena: "冥王の 葬列", theme: "soulvalley", speaker: "墓場の モンスター", lines: { half: "……ヒツギ……ヨコセ……", low: "……ネムラセテ……" } });
    if (r1 !== "win") { await K.sayAt(p, "§5冥王 モルテ", K.PJ("morte", 15), "冥王 モルテ", ["……棺が 倒れた。", K.RT(p)]); return false; }
    const eM2 = MORTE(K, p, true); K.act(eM2, "kneel");
    await K.say(p, "冥王 モルテ", ["{sad,up}……母親が、白い 灯籠を 選んだ。わしは 止めなんだ。", "{closed,low}石の 者だけは、送り方が 分からぬ。……それでも 墓は 要る。待つ 者が、待ち疲れて しまうからだ。"]);
    const eA = K.npcNear(p, "§5黒い 外套の 男", K.PJ("noxa", 9)); K.act(eA, "point");
    await K.hsay(p, H4("{shock,!}……葬列の 道で 見てた 人！", "{shock,!}……葬列の 道で、こっちを 見てた 人だわ。", "{closed}……葬列の 道の、黒い 外套。", "{shock,!}葬列の 道で 見て おられた 方です！"));
    await K.say(p, "黒い 外套の 男", ["{angry,low}……六の座さまの お言いつけだ。『石板の 子を、参謀に 会わせるな』。", "{closed}ここで 引き返して もらう。"]);
    await K.hsay(p, H4("{?}……参謀に 会わせるな？ 六影の 中で、命令が 二つ ある の？", "{?}……会わせるな？ 六影の 中で、命令が 二つ……？", "{closed}参謀とは 別の 命令。六影は 一つじゃ ない。", "{?}参謀に 会わせるな……？ 六影の 中で ご命令が 二つ？"));
    const r2 = await K.battle(p, K.team(["nether", "beast", "golem"], 56, 3, 18), { name: "六の座の 回し者", arena: "回し者", theme: "soulvalley", speaker: "黒い 外套の 男", lines: { half: "……聞いて いた より 強い", low: "六の座さま…… 申し訳……" } });
    if (r2 !== "win") { await K.sayAt(p, "§5黒い 外套の 男", K.PJ("noxa", 9), "黒い 外套の 男", ["……眠って いろ", K.RT(p)]); return false; }
    const eA2 = K.npcNear(p, "§5黒い 外套の 男", K.PJ("noxa", 9), true); K.act(eA2, "recoil");
    await K.say(p, "黒い 外套の 男", ["{sweat,汗}……くそっ！ 参謀の 書きつけを 写して、届ける ところ だったのに……！"]);
    K.act(eA2, 0); await K.leave(eA2, p, 12, true);
    K.sound(p, "item.book.page_turn", 1);
    K.act(eH, "hold"); K.hold(eH, "letter"); await K.up(p, eH, 12);
    await K.hsay(p, H4(["{?}……落として いった 紙。表に『上への 報告の 写し』。", "{shock,!}……この 字、セオさんの 研究メモと 同じ くせ……！"], ["{?}……紙の 束。『上への 報告の 写し』。", "{shock,…}……セオさんの 研究メモと、同じ 字……"], ["{closed}紙の 束。『上への 報告の 写し』。", "{shock,!}……セオの メモと 同じ 字。"], ["{?}紙の 束です。『上への 報告の 写し』と。", "{shock,!}……セオさんの メモと、同じ 筆跡です……"]));
    await K.hsay(p, H4(["{shock,!,up}『鍵を 持たず、モンスターと 絆を 結んだ 者。あの 旅人と 相棒。……レイも 試す』……！？"], ["{shock,!,up}『あの 旅人と 相棒を 記録 する。……レイも 試す』……？"], ["{shock,!}『旅人と 相棒を 記録。レイも 試す』。"], ["{shock,!,up}『あの 旅人と 相棒。……レイも 試す』……！？"]));
    await K.say(p, "冥王 モルテ", ["{closed}……霊廟は、紫の 灯の ともる 墓所だ。学者は その 奥に おる。"]);
    await K.end(p, { bye: [eM2], kind: "castle" });
    return true;
  } };

/* ---------- 6話 霊廟の奥（明かし）---------- */
const E6 = { id: "b08e6", t: "霊廟の奥（アジト）", F: ["F05", "F08", "F09", "F19", "F20", "F40"], ans: ["qb021", "qb052"],
  hint: "§f霊廟の 奥へ",
  syn: "座の 卓に 開いた 手帳。表紙に、研究メモと 同じ 紫の 判。二の座の 外套で 立って いた のは、セオだった。「下の 者への 命令は、年寄りの 字で 書きました。疑いが オルドさんへ 向くように」。灰の 降った 冬の 夜、セオの 町は 一夜で 石に なった。ルミエの 石の 子は、弟の ノエ。「弟の 名前は、書けるのに、声に 出せないんです」。",
  async run(p, d, K) {
    const tb = await crypt(K, p, [K.hero(p, false)]);
    const eH = K.hero(p);
    if (tb) await K.push(p, tb, 24, 6, 2.2, 0.4);
    await K.narr(p, /*F08*/["§7六つの 席の 卓。その 上に、開いた ままの 手帳。", "§7表紙に、紫の インクの 判。ひらいた 本の 形。……旅の 最初に もらった 研究メモと、同じ 判だった。"], tb);
    const eS = SEO8(K, p); K.turn(eS, tb || p.location);
    if (ok(eS)) await K.push(p, eS, 34, 5, 2, 1.5);
    await K.narr(p, ["§7卓の 向こうに、紫の 布の 外套。……二の座の 席に、だれかが 立って いる。"], eS);
    K.turn(eS, null); K.turn(eS, p.location);
    await K.say(p, "セオ", /*F08*/["{closed,low}……この 判を、覚えて いて くれたんですね。"]);
    await K.sixMark(p, eS, "theo");
    try { if (ok(eS)) eS.nameTag = "§5六影 参謀 セオ"; } catch {}
    await K.say(p, "セオ", ["{closed,up}……六影、二の座。参謀の セオです。", "{closed}ガロも、ヴァルカも、僕の 指示で 動いて いました。サンドリアの 密告も、僕です。"]);
    await K.say(p, "セオ", /*F05*/ /*F09*/["{closed}下の 者への 命令は、年寄りの 字で 書きました。……疑いが、オルドさんへ 向くように。", "{sad,low}……すみません。"]);
    await K.up(p, eH, 14);
    await K.hsay(p, H4(["{shock,…,up}……じいさんの 字って、村長の ことだと 思ってた……。", "{rage,怒,up}なんで！？ 森で 一緒に 戦って くれたのに！"], ["{shock,…}……そんな。森で、一緒に……", "{sad,up}……どうして？ 話して、セオさん。"], ["{shock,…}……あの メモの 消し跡。そういう ことか。", "{angry}目的は。全部 話して。"], ["{shock,…,up}そんな……森で、ご一緒に……", "{sad,up}なぜですか……！"]));
    await K.say(p, "セオ", ["{sad,…}……言えません。", "{closed,low}話せば、君に 影が 宿る。……それだけは、させない。"]);
    await K.hsay(p, H4("{shock,!}……水晶の 洞くつで 見た、石の 町。本の 看板の 家……あの 町、セオさんの……", "{shock,!}……水晶で 見た 石の 町。本の 看板の 家。……あなたの……", "{shock,!}……水晶の 幻の 町。本の 看板。セオの……", "{shock,!}水晶で 見た 石の 町……本の 看板の お家……セオさんの……"));
    await K.say(p, "セオ", /*F40*/ /*F19*/["{closed}そうです。灰の 降った 冬の 夜、町は 一夜で 石に なりました。母も。", "{sad}弟は……ほたるを 見に 行った 里の 小川で。"]);
    await K.flashback(p, { label: "§7―― 十二年前　灰の 降った 冬の 夜　ルミエの 小川", tod: "night", ptc: "night",   /* 第127版: セオと ノエの 夜を 絵で */
      actors: { t: { nm: "§7十二の セオ", job: K.PJ("m6_pip", 6), at: [2.6, -1], look: "n" }, n: { nm: "§7七つの ノエ", job: 6, at: [4.2, 0.8], look: [6, 2] } },
      beats: [
        ["narr", "§7十二年前の 冬の 夜。町の 集まりを ぬけ出した 兄弟が、ルミエの 小川に 来て いた。", "n"],
        ["fx", "light", [5, 1.5, 1.2]], ["fx", "ash", [4, 0, 2.4]],
        ["say", "n", "{smile,☆,up}兄ちゃん、見て！ 冬ほたる！ 灰の 中で 光ってる！", "t"],
        ["say", "t", "{sweat,汗}ノエ、帰ろう。物語の 続きが 始まる。母さんが 心配する。", "n"],
        ["go", "t", [3.6, 0.1], 10],
        ["say", "n", "{smile,…,up}……もう ちょっと。……ずっと、見て いたい。", [6, 2]],
        ["fx", "light", [4.2, 0.8, 1.4]], ["act", "n", "up"],
        ["narr", "§7その 声の まま、男の 子は 灰色に なって いった。兄の 手は、袖を つかんだ まま だった。", "n"],
        ["say", "t", "{cry,tears,up}……ノエ？ ……ノエ！", "n"],
      ] });
    const g = SEO8(K, p, true) || eS; K.act(g, "hold"); K.hold(g, "lantern");
    if (ok(g)) await K.push(p, g, 22, 3, 1, 1);
    await K.narr(p, ["§7セオの 腰に、火を 入れた ことの ない 白い 灯籠。小さな 字で「ノエ」と 書いて ある。"], g);
    await K.say(p, "セオ", /*F20*/["{sad,…}……弟です。ルミエの 小川の、石の 子。", "{closed,low}弟の 名前は、書けるのに、声に 出せないんです。"]);
    await K.hsay(p, H4("{sad,…}……だから、小川に 近づかなかったんだ。", "{sad}……だから、あの 小川には 近づけなかったのね。", "{closed}……小川を 避けてた 理由。", "{sad}……それで、小川に お近づきに ならなかったのですね。"));
    await K.say(p, "セオ", ["{closed,up}一つ だけ 言える ことが あります。§e君と 相棒が 要る§f。……全部を 知る ために。"]);
    return true;
  } };

/* ---------- 7話 霊廟の奥（レイ）---------- */
const E7 = { id: "b08e7", t: "霊廟の奥（レイ）", F: ["F21", "F51"],
  hint: "§f霊廟の 奥で",
  syn: "レイが 来た。「お守りだと？」。セオ「紐は、ほどけやすく 結びました。器か、確かめる ために」。レイの 目に 紫の 文字。相棒が かけらを くわえて 引きはがし、モルテが かけらを 白い 灯籠に 封じた。セオは 雪の 北へ 去った。",
  async run(p, d, K) {
    if (!K.S(p) || !facAt("b8seat", p.location, 40)) await K.open(p, "霊廟の 奥", "cave");
    const eH = K.hero(p), eS = SEO8(K, p, true) || K.npcNear(p, "§5六影 参謀 セオ", TJ, true); try { if (ok(eS)) eS.nameTag = "§5六影 参謀 セオ"; } catch {}
    const w = chOf(K, p, "c05") === "w";
    const eR = REI(K, p); K.act(eR, "run", false); await K.wait(10); K.act(eR, 0);
    K.act(eR, "hold"); K.hold(eR, "orb"); await K.low(p, eR, 12);
    await K.say(p, "レイ", ["{angry,!}……聞いたぞ、セオ。この かけら、お守りだと？"]);
    await K.say(p, "セオ", /*F51*/["{closed,low}……紐は、ほどけやすく 結びました。", "{closed}かけらに 耐える 器か、確かめる ために。"]);
    await K.say(p, "レイ", ["{rage}……『君は、選ばれる 人ですよ』。あれも、試しか。"]);
    K.act(eR, "raise"); K.sound(p, "mob.wither.ambient", 1.2);
    if (ok(eR)) { await K.push(p, eR, 16, 3, 1.3, 1.6); K.burst(p.dimension, eR.location, "minecraft:redstone_wire_dust_particle", 8, 0.35, 1.4); }
    await K.narr(p, ["§7レイの 目の 奥を、紫の 文字が 流れて いく。"], eR);
    try { if (ok(eR)) eR.nameTag = "§5影に 宿られた レイ"; } catch {}
    await K.say(p, "レイ", /*F21*/ w ? ["{sad,low}……おまえは 止めた。聞かなかったのは オレだ。", "{rage}……来いよ。止めて みろ。"] : ["{rage,low}……おまえも 黙ってた。", "{rage}……来いよ。今度は 何か 言って みろ。"]);
    await K.duel(p, "§5§l暴走", "§fかけらに 宿られた レイの 竜が 我を 忘れて 暴れだす！", { fams: ["dragon"] });
    const R1 = await K.battle(p, K.team(["dragon", "nether", "dragon"], 58, 4, 40, K.leadOf("dragon", 58)), { name: "影に 宿られた レイ", arena: "霊廟の 奥", theme: "soulvalley", hpk: 3.2, extra: 0.35, sboss: true, speaker: "レイ", lines: { half: "まだだ……！", low: "なんで おまえばっかり……！" } });
    if (R1 !== "win") { await K.sayAt(p, "§5六影 参謀 セオ", TJ, "セオ", ["{sad}……一度 下がって ください。", K.RT(p)]); return false; }
    if (!w) {
      const eR1 = REI(K, p, true); K.act(eR1, "stagger");
      await K.say(p, "レイ", ["{rage,up}……まだだ。かけらが、もっと よこせって……！"]);
      const R2 = await K.battle(p, K.team(["dragon", "nether"], 60, 3, 44), { name: "影に 宿られた レイ（二段目）", arena: "霊廟の 奥", theme: "soulvalley", hpk: 3.4, extra: 0.35, sboss: true, speaker: "レイ", lines: { half: "……止めろ……", low: "……止めて、くれ" } });
      if (R2 !== "win") { await K.sayAt(p, "§5六影 参謀 セオ", TJ, "セオ", ["{sad}……かけらが 深い。一度 下がって。", K.RT(p)]); return false; }
    }
    const eR2 = REI(K, p, true); K.act(eR2, "kneel"); try { if (ok(eR2)) eR2.nameTag = "§bレイ"; } catch {}
    const g = K.palEnt(p); if (g && ok(eR2)) { const l = eR2.location; K.place(g, p, { x: l.x + 0.8, y: l.y, z: l.z + 0.6 }); K.camNear(p, g, 2, 0.7); await K.wait(10); }
    await K.narr(p, ["§7相棒が レイの 手に 飛びつき、かけらを くわえて 引きはがした。"], g || eR2);
    await K.pal(p, ["……とった。もう、だいじょうぶ。"]);
    const eM = MORTE(K, p); K.act(eM, "hold"); K.hold(eM, "lantern"); await unstack(K, p, eM, [eS, eH]);
    await K.say(p, "冥王 モルテ", ["{closed,low}……その かけら、わしが 預かる。白い 灯籠に 封じ、霊廟の 奥へ 納める。……送る ための 灯籠は、閉じこめる ことにも 使える。"]);
    await K.narr(p, ["§7モルテが かけらを 白い 灯籠に 入れ、霊廟の いちばん 奥の 棚へ 納めた。"], eM);
    K.rmCine(g);
    await K.say(p, "セオ", ["{closed}……レイくん、すみません。君を 試したのは、僕の 罪です。", "{sad,low}僕は 北へ 行きます。……ごめん。"]);
    K.act(eS, 0); await K.leave(eS, p, 12, false);
    await K.narr(p, ["§7去って いく セオの 外套の 肩に、北の 雪が 白く 残って いた。"]);
    await K.say(p, "レイ", ["{cry,tears,up}選ばれる 側に なれるって……あれは 全部、オレが 聞きたかった 言葉 だった だけだ。", "{closed}……今度は オレが セオを 止める。"]);
    K.pay(p, E7, 20000, [["e_rainbow", 1], ["s_all3", 1], ["tms_undead", 1]]);
    await K.end(p, { leave: [eR2], bye: [eM], card: "§7→ ネクロスの 城で 地方マスター ヨミに 挑もう", kind: "cave" });
    return true;
  } };

/* ---------- 8話 冥王の城（ヨミに 勝った あと）---------- */
const E8 = { id: "b08e8", t: "冥王の城", place: PL("court", 7, "冥王の 城"), F: ["F03", "F31"],
  hint: "§fネクロス冥府領の §6地方マスター ヨミ§f に 勝とう",
  syn: "ヨミは 一行の 前に 立ちふさがった。友を 追わせない ために。戦いの あと、ヨミは「あの 人が 戻るまで、ここで 待てたら」と 言いかけて、石に なった。",
  async run(p, d, K) {
    await K.open(p, "冥王の 城", "castle");
    const eH = K.hero(p), eY = YOMI(K, p); K.act(eY, "kneel");
    await K.say(p, "ヨミ", ["{sweat,息}……負けた。……でも、北へは 行かせたく なかった。", "{closed}あの 人を、ひとりで 追わせたら、あなたたちに 斬られる 気が して。"]);
    await K.hsay(p, H4("{sad}……斬らないよ。連れて 帰りたいだけ。", "{sad}……斬らないわ。連れ戻したいの。", "{closed}斬らない。連れ戻す。", "{sad}斬りは しません。お連れ 帰りしたいのです。"));
    const g = K.palEnt(p); if (g && ok(eY)) { const l = eY.location; K.place(g, p, { x: l.x + 0.7, y: l.y, z: l.z + 0.7 }); K.camNear(p, g, 2, 0.8); await K.wait(8); }
    K.act(eY, "hold");
    await K.say(p, "ヨミ", /*F31*/["{smile}……いい子。この 子を、手放しちゃ だめ。片方が 呑まれても、もう 片方が 呼べば 戻れる。"]);
    K.rmCine(g);
    await K.push(p, eY, 26, 3.5, 1.5, 1.3);
    K.burst(p.dimension, ok(eY) ? eY.location : p.location, "minecraft:white_smoke_particle", 10, 0.6, 0.2);
    await K.say(p, "ヨミ", /*F03*/["{closed,…}……あの 人が 戻るまで、ここで 待てたら――"]);
    try { if (ok(eY)) { setJob(eY, K.PJ("yomi_stone", 8)); eY.nameTag = "§7ヨミの 石像"; } } catch {}
    K.act(eY, 0);
    await K.narr(p, ["§7言い終わる 前に、ヨミは 足もとから 灰色の 石に なった。待つ 顔の まま。"], eY);
    if (ok(eY)) { K.camNear(p, eY, 10, 4.5, 1.8); await K.wait(30); }
    await K.hsay(p, H4(["{sad,…,up}…………。", "{closed,up}……ヨミさんの 名前、手帳に 書く。"], ["{sad,…}…………。", "{closed}……ヨミさんの お名前、書いて おくね。"], ["{closed}……手帳に、ヨミと 書いた。"], ["{sad,…}…………。", "{closed}……ヨミさんの お名前、記します。"]));
    K.techo(p, "ヨミ");
    await K.end(p, { bye: [eY], card: "§7→ ソウラの 川べりで、もう 一度 灯籠流しが ある", kind: "castle" });
    return true;
  } };

/* ---------- 9話 ソウラの川べり（もう一度の灯籠・C08）---------- */
const E9 = { id: "b08e9", t: "ソウラの川べり（もう一度の灯籠）", place: SPLAZA, F: ["F28"], keys: ["k_redlan"],
  hint: "§fソウラの §e広場§f へ もどろう §7（もう 一度の 灯籠流し。灯籠を 受け取って 川べりへ）",
  syn: "赤い 迎え灯籠は 一つ。名を 書いた。幼なじみは「ぜったい 連れて 帰る」と 言った。",
  skip: (s) => { s.epx = { ...T(s.epx), lantern7: 1 }; },
  async run(p, d, K) {
    festSet(p, "r7soura", p.location, Y0(K, p));
    await K.open(p, "ソウラの 広場（夜）", "night", "night");
    let eH = K.hero(p), eY = K.cast(p, "r7_yura"); K.act(eY, "hold"); K.hold(eY, "lantern");
    await K.csay(p, "r7_yura", ["{sad}……赤い 迎え灯籠、もう 一つ しか ないのです。", "{closed}名前を 書いて 流すと、その 人が 帰り道を 見失わないのです。"]);
    await K.give(eY, eH, "lantern");
    await K.push(p, eH, 20, 3, 1.2, 1.1);
    await K.narr(p, ["§7手の 中に、赤い 灯籠が 一つ。去った 友と、石に なった ばかりの 友。"], eH);
    const c = await K.pick(p, "c08");
    if (c === "t") await K.narr(p, /*F28*/["§7灯籠に「セオ」と 書いた。"], eH);
    else await K.narr(p, /*F28*/["§7灯籠に「ヨミ」と 書いた。"], eH);
    { const RV = RIVER(); if (RV) { await K.moveTo(p, RV, "ソウラの 川べり（夜）", [eY]); const e1 = K.hero(p); if (ok(e1)) eH = e1; const e2 = K.cast(p, "r7_yura"); if (ok(e2)) { eY = e2; K.hold(eY, "lantern"); } } }
    const W = (() => { try { const v = JSON.parse(world.getDynamicProperty("mrpg:epdeco:r7river") || "null"); if (!Array.isArray(v) || !v.length) return null; const m = v[v.length >> 1]; return Math.hypot(m[0] - p.location.x, m[2] - p.location.z) < 30 ? { x: m[0], y: m[1] + 0.6, z: m[2] } : null; } catch { return null; } })();
    const q = W || K.fwd(p, 4); if (q) { K.burst(p.dimension, q, "minecraft:basic_flame_particle", 4, 0.3, 0.2); await K.at(p, q, 20, 5, 1); }
    await K.narr(p, ["§7赤い 火が、川を ゆっくり 下って いく。"], q);
    await K.csay(p, "r7_yura", [c === "t" ? "{shock,…}……敵の 名前を、迎え灯籠に 書く 人、初めて 見たのです。" : "{sad}……石に なった 友だちの 名前。ヨミさまも、きっと 帰り道を 見つけるのです。"]);
    await K.hsay(p, H4("{angry,tears,up}……ぜったい 連れて 帰る。", "{sad,up}……ぜったい、連れて 帰るわ。", "{closed}……ぜったい 連れて 帰る。", "{closed,tears,up}……必ず、お連れ 帰ります。"));
    K.pay(p, E9, 1200, [["gift_candle", 1]]);
    await K.end(p, { leave: [eY], card: "§f― 第8章 冥府の 霊廟 おわり ―", kind: "night", t: 60 });
    return true;
  } };

bkAdd("b08", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
mqOver(18, null, { cond: async () => true });
