// 第126版: 邪闘十魔将（常世編）の 固有の ギミック。battle.js の 常世の 魔将の 設定（master.ruinsBoss）から tkSetup を 呼ぶ。
// 状態は 戦い（B.tk）ごとに 持つ（マルチで まざらない）。core.js の つなぎ目: B.tkg.start / end / dmg / hit / heal / act / after / ai
import { world } from "@minecraft/server";
import { MOVES, SPECIES } from "./data.js";
import { alive, pick, ri, rnd, fighter, makeMonster, calcStats, stat, aiDecide } from "./core.js";

/* 区の 並び（0 が 十冠・9 が 一冠）。元に する 種族・色（部位ごと 0〜16: 1赤 4金 9水色 12紫 14白 15灰 16黒）・影の 粒 */
export const TK_CROWN = ["十冠", "九冠", "八冠", "七冠", "六冠", "五冠", "四冠", "三冠", "二冠", "一冠"];
export const TK_NM = ["ヒフミ＆シゴロ", "イトマ", "テルグ", "サイオウバ", "ハドラ", "ザキュラス", "ガムラ", "リョウマ", "ギレンドドロス", "ベルガ"];
export const TK_SP0 = ["hgol16", "xk14", "xk20", "nbea093", "hdra15", "ed147", "ngol081", "sam03", "xk19", "xk42"];
export const TK_SP = TK_SP0.map((s, i) => (SPECIES[s] ? s : ["xk19", "xk14", "xk20", "xk03", "xk27", "xk21", "xk32", "xk34", "xk19", "xk42"].find((x) => SPECIES[x]) || Object.keys(SPECIES)[0]));
export const TK_LOOK = [
  { h: 14, b: 14, a: 14, l: 14, c: 1, w: 14 }, { h: 1, b: 16, a: 12, l: 12, c: 1, w: 16 }, { h: 1, b: 16, a: 9, l: 16, c: 1, w: 9 }, { h: 1, b: 16, a: 4, l: 16, c: 1, w: 16 },
  { h: 1, b: 16, a: 16, l: 16, c: 1, w: 7 }, { h: 1, b: 16, a: 12, l: 16, c: 1, w: 12 }, { h: 1, b: 16, a: 16, l: 16, c: 1, w: 5 }, { h: 1, b: 16, a: 16, l: 16, c: 1, w: 10 },
  { h: 1, b: 16, a: 15, l: 16, c: 1, w: 15 }, { h: 1, b: 16, a: 4, l: 16, c: 1, w: 12 },
];
export const TK_LOOK2 = { h: 16, b: 16, a: 16, l: 16, c: 1, w: 16 };   /* 黒い 片割れ シゴロ */
export const TK_PT = ["minecraft:white_smoke_particle", "minecraft:portal_reverse_particle", "minecraft:endrod", "minecraft:totem_particle", "minecraft:spore_blossom_ambient_particle", "minecraft:soul_particle", "minecraft:electric_spark_particle", "minecraft:snowflake_particle", "minecraft:lava_particle", "minecraft:dragon_breath_trail"];
export const TK_GNAME = ["サイコロ勝負", "糸と 人形", "回る 鏡", "禍福の 反転", "生える 首", "夜と 昼", "雷眼の 視線", "一騎打ちと 居合", "三重の 鎧", "王の 命令"];
/* 渡し守の 短い 教え（はじめて 戦う 前に 1回）*/
export const TK_LESSON = [
  ["§e双子は 毎ラウンド サイコロを 振る。", "§f「1・2・3」は 双子の 受ける ダメージが 2倍、「4・5・6」は 双子の 攻撃が 2.5倍。", "§7片方を 倒したら、3ラウンドの うちに もう 片方も 倒せ。でないと 振り直しで よみがえる"],
  ["§e人形が いる あいだ、イトマには なにも 効かない。", "§f全体攻撃で 人形を まとめて 壊せ。人形は 3ラウンドで 組み直される。", "§7糸に かかった 子は 味方を ねらう。状態を 治す 技か、イトマへの 強化消しで 切れる"],
  ["§e鏡は 毎ラウンド 一つの 系統を 跳ね返す（物理・魔法・息・武の 順）。", "§f鏡の 色で 次の 系統が わかる。跳ね返されない 系統で 攻めろ。", "§7HPが 半分を 切ると、鏡は 二枚に なる"],
  ["§e2ラウンドごとに、禍と 福が 反転する。", "§f反転中は 攻撃が 相手を 回復させ、回復の 技が サイオウバへの ダメージに なる。", "§7反転すると 味方の 強化と 弱体も 入れかわる。反転の 前の 弱体は、反転中の 力に なる"],
  ["§eHPが 4分の1 減るたびに、首が 1本 生えて 行動が ふえる。", "§f区切りを 越える その ラウンドに 炎属性で 撃てば、傷口が 焼けて 首は 生えない。"],
  ["§e3ラウンドごとに 夜と 昼が かわる。", "§f夜は 光属性 いがいの ダメージが 3分の1、攻撃で 血を 吸われる。昼は 光属性が 2.5倍。", "§7夜は 守りと 回復、昼に 光で 一気に"],
  ["§e単眼は、前の ラウンドで いちばん ダメージを 与えた 子を 見つめる。", "§f見つめられた 子は よけられず、ラウンドの 頭に 雷が 落ちる。攻める 子を かえて 雷を 散らせ。", "§7霧や 眠り・混乱で 眼を 閉じさせると、2ラウンド 受ける ダメージが 1.5倍"],
  ["§e戦えるのは 1体だけ。2ラウンドごとに 交代できる（戦わせたい 子だけ 技を えらぶ）。", "§f構えの あいだは 武系と 物理系を 居合で 斬り返す。魔法や 息で 攻めろ。", "§7構えを 解いた ラウンドは 武系が 1.5倍"],
  ["§e岩・光・闇、三枚の 鎧が ある あいだ、ダメージは 4分の1。", "§f岩は 物理系か 通常攻撃、光の 鎧は 闇属性、闇の 鎧は 光属性で 割れる。", "§7鎧は 4ラウンドごとに 1枚 組み直される。三枚 割れた あいだに 全力で"],
  ["§e毎ラウンド、王が 命令を 下す。破った 子は 重い 罰を 受け、その 行動も 消される。", "§f命令を 読んで 技を えらべ。罰を 受けても よい 子を 決めて おけ。", "§7HPが 半分を 切ると 命令は 二つ。3ラウンドごとに これまでの 九人の 力を 借りる"],
];
const HALF = [
  ["§f§lヒフミ「……シゴロ、本気で 振ろう」", "§8§lシゴロ「うん。ここからは ぜんぶ 賭ける」", "§c双子の 行動が 2回に なった！"],
  ["§5§lイトマ「人形あそびは おしまい。……つぎは あなたたちが 人形よ」", "§c糸が 2本に なった！"],
  ["§b§lテルグ「映せ、映せ。……二枚目を 出そう」", "§c鏡が 二枚に なった！ 二つの 系統を 跳ね返す"],
  ["§6§lサイオウバ「禍は 福に、福は 禍に。……どちらも 同じ 馬の 背よ」", "§c禍福の 祈りが 強く なった！"],
  ["§2§lハドラ（すべての 首が 同時に ほえた）", "§cハドラの 攻撃が 強く なった！"],
  ["§9§lザキュラス「夜を のばそう。……朝は もう 来ない」", "§c夜が 長く なった（4ラウンド）！ 吸う 血も ふえる"],
  ["§e§lガムラ（単眼が 赤く 光り、広場に 雷が 落ちた）", "§c雷が 2本 落ちる ように なった！"],
  ["§c§lリョウマ「……鞘を 捨てる」", "§c構えの 時間が 長く なった（2ラウンド 構えて 1ラウンド 解く）！"],
  ["§7§lギレンドドロス「鎧は 永遠に 組み直す。……永遠が、のぞみだった」", "§c鎧の 組み直しが 3ラウンドごとに なった！"],
  ["§5§lベルガ「ひざまずけ。……命令は 二つだ」", "§c命令が 二つに なった！"],
];

const T = (B) => B.turn || 1;
const isAtkMv = (mv) => !!mv && (mv.kind === "attack" || mv.kind === "drain" || mv.kind === "reckless");
const catOf = (mv) => (!mv ? null : mv.basic && !mv.wdep ? "phys" : mv.cat || null);
const mvOfA = (a) => (!a ? null : a.kind === "attack" ? a.actor && a.actor.atk : a.kind === "move" ? MOVES[a.move] : null);
const foesA = (B) => alive(B.allies);
const num = (v, d = 0) => (Number.isFinite(v) ? v : d);
const CAT_COL = { phys: ["§c赤", "物理系"], magic: ["§9青", "魔法系"], breath: ["§a緑", "息系"], weapon: ["§6金", "武系"] };
const once = (B, key, log, line) => { const k = `${T(B)}:${key}`; if (B.tk.said.has(k)) return; B.tk.said.add(k); log.push(line); };
function fxAt(B, f, id, n = 3, dy = 0.2) { try { const e = f && f.ent; if (!e || !e.isValid()) return; const l = e.location; for (let k = 0; k < n; k++) e.dimension.spawnParticle(id, { x: l.x + rnd(-1.5, 1.5), y: l.y + dy + Math.random(), z: l.z + rnd(-1.5, 1.5) }); } catch {} }
function sfx(B, id, pitch = 1) { for (const x of B.players || []) try { x.p.playSound(id, { volume: 1, pitch }); } catch {} }
function shake(B, pw = 0.5, t = 0.6) { for (const x of B.players || []) try { x.p.runCommand(`camerashake add @s ${pw} ${t} positional`); } catch {} }
/* じかに ダメージ（ギミックの 雷・罰・祈り）。死なせない ときは 1 残す */
function hurt(B, t, d, fx, keep1 = true) {
  if (!t || t.hp <= 0) return 0;
  d = Math.max(1, Math.floor(num(d, 1)));
  if (keep1) d = Math.min(d, t.hp - 1);
  if (d <= 0) return 0;
  t.hp = Math.max(0, t.hp - d);
  if (fx) { (fx.dmg = fx.dmg || []).push({ t, d, crit: false, weak: false }); if (fx.hit && !fx.hit.includes(t)) fx.hit.push(t); }
  return d;
}
const mkFx = (actor, name, el = "dark") => ({ actor, anim: "cast", el, hit: [], ko: [], healed: [], cat: "magic", tier: 2, hits: 1, mvName: name });
function makeFoe(B, sp, nm, src, hp) {
  const m = makeMonster(sp, 100, true); m.plus = 50; m.nm = nm; const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  const g = fighter(m, "e");
  if (src) { g.mx = { ...src.mx }; g.m.sz = "G"; g.moves = [...src.moves]; g.aiTac = src.aiTac; g.fixedKit = true; g.isBoss = true; g.infMP = true; g.smart = src.smart; Object.assign(g.tr, { critguard: true, laststand: true }); }
  if (hp) g.mx.hp = hp;
  g.hp = g.mx.hp; g.php = g.mx.hp; g.mp = g.mx.mp; g.name = nm;
  B.enemies.push(g); return g;
}

/* ---------- 魔将ごとの ギミック ---------- */
const G = [];
/* 十冠 ヒフミ＆シゴロ: サイコロ勝負 */
G[0] = {
  setup(B, M) {
    M.name = "ヒフミ"; M.m.nm = "ヒフミ"; M.m.tint = TK_LOOK[0]; M.mx.hp = 10000; M.hp = M.php = 10000;
    Object.assign(M.tr, { acts: [1, 2], extra: 0.15 });
    const g = makeFoe(B, M.m.sp, "シゴロ", M, 10000); tame(g); g.m.tint = TK_LOOK2; g.tkGen = true; Object.assign(g.tr, { acts: [1, 2], extra: 0.15 }); g.bossTraits = M.bossTraits;
    B.tk.twins = [M, g];
  },
  start(B, log) {
    const t = T(B), tw = B.tk.twins;
    for (const x of tw) if (x.hp <= 0 && x.tkDeadT && t - x.tkDeadT >= 3 && tw.some((y) => y !== x && y.hp > 0)) {   /* 振り直し */
      x.hp = Math.floor(x.mx.hp / 2); x.tkDeadT = 0; x.revived = false; x.lsUsed = false; try { B.tk.H.standUp(x); } catch {}
      log.push(`§d§l振り直し！ §r§d${x.name}が HP半分で よみがえった！`); sfx(B, "random.totem", 1.2);
    }
    const r = Math.random(), kind = r < 0.3 ? "low" : r < 0.6 ? "high" : r < 0.75 ? "zoro" : r < 0.82 ? "pin" : "none";
    B.tk.roll = kind;
    for (const x of tw) x.tr.acts = B.tk.half ? [2, kind === "high" ? 3 : 2] : [1, kind === "high" ? 3 : 2];
    let dice;
    if (kind === "low") dice = [1, 2, 3]; else if (kind === "high") dice = [4, 5, 6];
    else if (kind === "zoro") { const v = ri(2, 6); dice = [v, v, v]; } else if (kind === "pin") dice = [1, 1, 1];
    else { do { dice = [ri(1, 6), ri(1, 6), ri(1, 6)]; } while (dice[0] === dice[1] && dice[1] === dice[2] || [...dice].sort().join() === "1,2,3" || [...dice].sort().join() === "4,5,6"); }
    dice = dice.sort(() => Math.random() - 0.5);
    const face = dice.join("・");
    sfx(B, "random.click", 0.8); for (const x of tw) fxAt(B, x, x === tw[0] ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 4);
    if (kind === "low") log.push(`§6§lサイコロの 目：${face}！ §r§a双子の 受ける ダメージが 2倍！ §7今が 攻めどき`);
    else if (kind === "high") log.push(`§6§lサイコロの 目：${face}！ §r§c双子の 攻撃が 2.5倍・手数も ふえる！ §7守りを かためろ`);
    else if (kind === "zoro") {
      const L = tw.filter((x) => x.hp > 0);
      if (L.length === 2) { const [a, b] = L, ha = a.hp; a.hp = Math.min(a.mx.hp, b.hp); b.hp = Math.min(b.mx.hp, ha); log.push(`§d§lゾロ目：${face}！ §r§d双子の HPが 入れかわった！`); }
      else log.push(`§d§lゾロ目：${face}！ §r§7……片割れが いないので、何も 起きない`);
    } else if (kind === "pin") {
      for (const x of [...B.allies, ...B.enemies]) if (x.buf) for (const k of Object.keys(x.buf)) x.buf[k] = 0;
      log.push(`§f§lピンゾロ：${face}！ §r§fその場の 強化と 弱体が すべて 消えた！`);
    } else log.push(`§7§lサイコロの 目：${face} §r§7（目なし。何も 起きない）`);
    for (const x of tw) if (x.hp <= 0 && x.tkDeadT && tw.some((y) => y !== x && y.hp > 0)) log.push(`§c${x.name}が 倒れて いる！ §f${3 - (t - x.tkDeadT)}ラウンドの うちに ${tw.find((y) => y !== x).name}を 倒さないと 振り直し`);
    return `§6サイコロ：${face}`;
  },
  end(B) { const t = T(B); for (const x of B.tk.twins) if (x.hp <= 0 && !x.tkDeadT) x.tkDeadT = t - 1; },
  dmg(B, f, t, d) { if (B.tk.roll === "low" && t && t.tkGen) d *= 2; if (B.tk.roll === "high" && f && f.tkGen) d *= 2.5; return d; },
  ai(f, B) { if (f.tkGen && B.tk.roll === "low" && Math.random() < 0.45) return { actor: f, kind: "defend" }; return null; },
  half() {},
};
/* 九冠 イトマ: 糸と 人形 */
const DOLL_SP = SPECIES.hime045 ? "hime045" : "xmac00";
G[1] = {
  setup(B, M) {
    B.tk.dolls = [];
    for (let k = 0; k < 3; k++) { const g = makeFoe(B, DOLL_SP, "人形", null, 2200); g.tkDoll = true; g.m.tint = { h: 16, b: 14, a: 16, l: 16, c: 1, w: 16 }; tame(g); g.tr.acts = [1, 1]; g.tr.extra = 0; g.tr.dmgcap = 0; g.tr.gcounter = 0; g.fixedKit = true; g.moves = []; g.smart = 1; for (const s of ["atk", "wpn", "mat", "brt"]) g.mx[s] = Math.floor(M.mx[s] * 0.3); g.mx.def = Math.floor(M.mx.def * 0.5); g.mx.mdf = Math.floor(M.mx.mdf * 0.5); g.mx.spd = Math.floor(M.mx.spd * 0.8); B.tk.dolls.push(g); }
  },
  start(B, log) {
    const t = T(B), M = B.tk.M;
    for (const g of B.tk.dolls) if (g.hp <= 0 && g.tkDeadT && t - g.tkDeadT >= 3 && M.hp > 0) { g.hp = g.mx.hp; g.tkDeadT = 0; g.revived = false; try { B.tk.H.standUp(g); } catch {} log.push(`§5人形が 糸で 組み直された！`); }
    for (const a of B.allies) a.tkIto = 0;
    const live = foesA(B).filter((x) => !x.guest), n = B.tk.half ? 2 : 1, got = [];
    for (let k = 0; k < n && live.length > 1; k++) { const c = live.filter((x) => !got.includes(x)); const v = pick(c); if (v) { v.tkIto = t; got.push(v); } }
    const nd = B.tk.dolls.filter((g) => g.hp > 0).length;
    sfx(B, "mob.spider.say", 0.7); fxAt(B, M, TK_PT[1], 4, 2);
    log.push(nd ? `§5§l人形 ${nd}体 §r§5― 人形が いる あいだ、イトマには 効かない` : `§a§l人形が いない！ §r§aイトマに 攻撃が とどく！`);
    if (got.length) log.push(`§5イトマの 糸が §f${got.map((x) => x.name).join("・")}§5 に からみついた！ §7（攻撃が 味方へ 向かう・状態を 治すと 切れる）`);
    return nd ? `§5人形 ${nd}体：イトマは 無傷` : "§a人形が いない！";
  },
  end(B) { const t = T(B); for (const g of B.tk.dolls) if (g.hp <= 0 && !g.tkDeadT) g.tkDeadT = t; },
  dmg(B, f, t, d, mv, log) {
    if (t === B.tk.M && B.tk.dolls.some((g) => g.hp > 0)) { once(B, `ito${f ? f.name : ""}`, log, "§5イトマは 人形の 糸に 守られて いる！ §7（人形を 先に 壊せ）"); return 0; }
    return d;
  },
  act(B, a, log) {
    const f = a.actor, mv = mvOfA(a);
    if (!f || f.side !== "a" || f.tkIto !== T(B) || !isAtkMv(mv) || (mv.target !== "enemy" && mv.target !== "enemies" && mv.target !== "rand2")) return null;
    const c = alive(B.allies).filter((x) => x !== f);
    if (!c.length) return null;
    const v = pick(c); log.push(`§5§l糸に あやつられて、${f.name}は ${v.name}を ねらった！`);
    return { a: { ...a, target: v, forced: true } };
  },
  after(B, a, fx, log) {
    const M = B.tk.M, mv = mvOfA(a);
    if (a.actor && a.actor.side === "a" && mv && (mv.dispel || mv.dispelhit) && fx && (fx.hit || []).includes(M) && B.allies.some((x) => x.tkIto)) { for (const x of B.allies) x.tkIto = 0; log.push("§b強化消しで イトマの 糸が 切れた！"); }
    if (M.hp <= 0) for (const g of B.tk.dolls) if (g.hp > 0) { g.hp = 0; if (fx && fx.ko && !fx.ko.includes(g)) fx.ko.push(g); once(B, "dollfall", log, "§7糸が 切れ、人形は 崩れ落ちた"); }
  },
  half() {},
};
/* 八冠 テルグ: 回る 鏡 */
const MIR = ["phys", "magic", "breath", "weapon"];
G[2] = {
  start(B, log) {
    const t = T(B), k = (t - 1) % 4, n = B.tk.half ? 2 : 1;
    B.tk.refl = MIR.slice(k, k + n).concat(k + n > 4 ? MIR.slice(0, k + n - 4) : []);
    const nx = (k + n) % 4, nxt = MIR.slice(nx, nx + n).concat(nx + n > 4 ? MIR.slice(0, nx + n - 4) : []);
    sfx(B, "block.amethyst_block.chime", 0.8); fxAt(B, B.tk.M, "minecraft:endrod", 6, 2);
    log.push(`§b§l鏡の 色：${B.tk.refl.map((c) => CAT_COL[c][0]).join("と ")} §r§f― ${B.tk.refl.map((c) => CAT_COL[c][1]).join("と ")}を 跳ね返す！`);
    log.push(`§7次の ラウンドの 鏡は ${nxt.map((c) => CAT_COL[c][0] + "§7（" + CAT_COL[c][1] + "）").join("と ")}`);
    return `§b鏡：${B.tk.refl.map((c) => CAT_COL[c][1]).join("・")}を 跳ね返す`;
  },
  hit(B, f, t, mv, log) { if (t === B.tk.M && f.side === "a" && (B.tk.refl || []).includes(catOf(mv))) { log.push(`§b§l鏡が ${f.name}の ${CAT_COL[catOf(mv)][1]}を 2倍に して 跳ね返した！`); B.tk.bnc = f; return "bounce"; } return null; },
  dmg(B, f, t, d) { if (!f && B.tk.bnc && t === B.tk.bnc) { B.tk.bnc = null; return d * 2; } return d; },
};
/* 七冠 サイオウバ: 禍福の 反転 */
const revRound = (t) => (t - 1) % 4 >= 2;
function flipBuf(B) { for (const x of B.allies) if (x.buf) for (const k of Object.keys(x.buf)) if (x.buf[k]) x.buf[k] = -x.buf[k]; }
G[3] = {
  start(B, log) {
    const t = T(B), rev = revRound(t);
    if (rev && !B.tk.rev) { B.tk.rev = true; flipBuf(B); shake(B, 0.5, 0.6); sfx(B, "mob.evocation_illager.prepare_wololo", 0.8); log.push("§d§l反転！ §r§d禍と 福が 入れかわった。§f攻撃は 相手を 回復させ、回復の 技が ダメージに なる！", "§d味方の 強化と 弱体も 入れかわった"); }
    else if (!rev && B.tk.rev) { B.tk.rev = false; flipBuf(B); log.push("§7反転が とけた。強化と 弱体が もとに もどった"); }
    fxAt(B, B.tk.M, TK_PT[3], 5, 1);
    if (!rev) log.push(revRound(t + 1) ? "§e§l次の ラウンドで 反転する！ §r§7（今の 弱体は 反転中の 強化に なる）" : "§7ふつうの ラウンド（あと 2ラウンドで 反転）");
    return rev ? "§d反転中：回復が ダメージに" : revRound(t + 1) ? "§e次の ラウンドで 反転" : "§7ふつうの ラウンド";
  },
  dmg(B, f, t, d, mv, log, fx) {
    if (!B.tk.rev || !t || t.hp <= 0) return d;
    const h = Math.min(t.mx.hp - t.hp, Math.floor(d));
    if (h > 0) { t.hp += h; if (fx && fx.healed) fx.healed.push(t); (fx.heal = fx.heal || []).push({ t, d: h }); }
    log.push(`§d反転！ ${t.name}は ダメージの かわりに HPが ${h} 回復した`);
    return 0;
  },
  heal(B, f, t, mv, log, fx) {
    if (!B.tk.rev) return false;
    if (fx.tkRev) return true; fx.tkRev = true;
    const v = f.side === "a" ? B.tk.M : f, k = mv.target === "allies" ? 1.3 : 1;
    const d = hurt(B, v, (stat(f, "mat") * 0.6 + stat(f, "mdf") * 0.4 + 6) * 1.2 * k * (mv.heal || 1) * rnd(0.9, 1.1), fx, false);
    log.push(`§d§l反転！ §r§d回復の 光が ${v.name}を 焼いた！ ${d}の ダメージ`);
    if (v.hp <= 0) { if (!fx.ko.includes(v)) fx.ko.push(v); log.push(v.side === "e" ? `§6${v.name}を 倒した！` : `§c${v.name}は 力つきた…`); }
    return true;
  },
  act(B, a, log) {
    const f = a.actor, M = B.tk.M, t = T(B);
    if (f !== M || M.hp <= 0) return null;
    if (B.tk.rev) {   /* 禍福の 祈り: 反転で 祝福が 災いに */
      const fx = mkFx(M, "禍福の 祈り", "light"); log.push("§6§lサイオウバの 禍福の 祈り！ §r§d反転した 祝福が 災いに かわる！");
      for (const v of alive(B.allies)) { const d = hurt(B, v, Math.min(v.mx.hp * 0.3, (stat(M, "mat") * 0.6 + stat(M, "mdf") * 0.4) * 0.55 * (B.tk.half ? 1.4 : 1) * rnd(0.9, 1.1)), fx, false); log.push(`${v.name}に ${d}の ダメージ！`); if (v.hp <= 0) { fx.ko.push(v); log.push(`§c${v.name}は 力つきた…`); } }
      return { fx };
    }
    if (revRound(t + 1) && B.tk.proph !== t) {   /* 禍の 予言: 反転の 前に 弱体を かける（反転中は 強化に なる）*/
      B.tk.proph = t; const fx = mkFx(M, "禍の 予言", "dark"); log.push("§5§lサイオウバの 禍の 予言！ §r§7味方の 力が 下がった……");
      for (const v of alive(B.allies)) { for (const k of ["atk", "mat", "def"]) v.buf[k] = Math.max(-6, (v.buf[k] || 0) - 1); fx.hit.push(v); }
      fx.down = true; return { fx };
    }
    return null;
  },
};
/* 六冠 ハドラ: 生える 首 */
const headActs = (h) => [Math.min(5, h + 1), Math.min(5, h + 1)];
G[4] = {
  setup(B, M) { B.tk.heads = 1; B.tk.cut = 0; M.tr.acts = headActs(1); M.tr.extra = 0; },
  start(B, log) {
    const M = B.tk.M, nxt = Math.max(0, Math.ceil(M.hp - M.mx.hp * (0.75 - 0.25 * B.tk.cut)));
    fxAt(B, M, TK_PT[4], 4, 1.5);
    log.push(`§2§l首 ${B.tk.heads}本 §r§2（${B.tk.heads + 1}回 行動）`);
    if (B.tk.cut < 3) log.push(`§7次の 区切りまで あと ${nxt}。§6区切りを 越える ラウンドに 炎属性で 撃てば 首は 生えない`);
    return `§2首 ${B.tk.heads}本：${B.tk.heads + 1}回 行動`;
  },
  dmg(B, f, t, d, mv) { if (t === B.tk.M && f && f.side === "a" && (mv.el === "fire" || mv.el2 === "fire")) B.tk.fireT = T(B); if (f === B.tk.M) d *= (B.tk.half ? 1.2 : 1) * (1 + 0.35 * (B.tk.heads - 1)); return d; },
  end(B, log) {
    const M = B.tk.M; if (M.hp <= 0) return;
    const k = Math.max(0, Math.min(3, Math.floor((1 - M.hp / M.mx.hp) / 0.25 + 1e-9)));
    const t = T(B) - 1;
    while (B.tk.cut < k) {
      B.tk.cut++;
      if (B.tk.fireT === t) log.push("§6§l炎で 傷口を 焼いた！ §r§6新しい 首は 生えなかった");
      else { B.tk.heads++; M.tr.acts = headActs(B.tk.heads); log.push(`§2§lハドラの 首が 生えた！ §r§2首 ${B.tk.heads}本（${B.tk.heads + 1}回 行動）`); sfx(B, "mob.enderdragon.growl", 0.9); }
    }
  },
};
/* 五冠 ザキュラス: 夜と 昼 */
const nightOf = (B) => { const t = T(B), L = B.tk.half ? [4, 2] : [3, 3], c = L[0] + L[1]; return ((t - 1 - (B.tk.halfT || 0)) % c + c) % c < L[0]; };
G[5] = {
  start(B, log) {
    const n = nightOf(B); B.tk.night = n;
    fxAt(B, B.tk.M, n ? "minecraft:soul_particle" : "minecraft:totem_particle", 5, 1.5); sfx(B, n ? "mob.bat.idle" : "random.orb", 0.8);
    log.push(n ? "§9§l夜 §r§9― 光属性 いがいの ダメージは 3分の1。ザキュラスは 攻撃で 血を 吸う" : "§e§l昼 §r§e― 光属性の ダメージが 2.5倍！ §7今が 攻めどき");
    return n ? "§9夜：光 いがいは 3分の1・吸血" : "§e昼：光属性 2.5倍";
  },
  dmg(B, f, t, d, mv, log) {
    const M = B.tk.M;
    if (t === M) { if (B.tk.night && mv.el !== "light") d *= 0.35; if (!B.tk.night && mv.el === "light") d *= 2.5; }
    if (f === M && B.tk.night && t && t.side === "a" && M.hp > 0) { const h = Math.min(M.mx.hp - M.hp, Math.floor(d * (B.tk.half ? 1.2 : 1))); if (h > 0) { M.hp += h; once(B, `drain${t.name}`, log, `§5ザキュラスは 血を 吸った（+${h}）`); } }
    return d;
  },
  ai(f, B) { if (f === B.tk.M && !B.tk.night && Math.random() < 0.25) return { actor: f, kind: "defend" }; return null; },
  half(B) { B.tk.halfT = T(B) - 1; },
};
/* 四冠 ガムラ: 雷眼の 視線 */
const eyeShut = (B, M) => !!((B.weather && B.weather.t > 0 && B.weather.w === "fog") || M.mistT > 0 || M.capT > 0 || (M.ail && (M.ail.sleep > 0 || M.ail.conf > 0 || M.ail.charm > 0 || M.ail.fear > 0)));
G[6] = {
  setup(B) { B.tk.dealt = new Map(); B.tk.shut = 0; },
  start(B, log) {
    const M = B.tk.M, t = T(B);
    for (const a of B.allies) a.tkEv0 = false;
    const s = B.tk.stare;
    if (B.tk.shut >= t) { log.push(`§e§l眼が 閉じて いる！ §r§aガムラの 受ける ダメージ 1.5倍（あと ${B.tk.shut - t + 1}ラウンド）`); B.tk.stare = null; return "§a眼が 閉じた：1.5倍"; }
    if (s && s.hp > 0 && B.allies.includes(s)) {
      s.tkEv0 = true; const fx = { hit: [] };
      B.tk.stN = B.tk.prev === s ? Math.min(4, (B.tk.stN || 1) + 1) : 1; B.tk.prev = s;
      const d = hurt(B, s, s.mx.hp * 0.2 * B.tk.stN * (B.tk.half ? 1.3 : 1), fx, true);
      log.push(`§e§l雷眼！ §r§e見つめられた ${s.name}に 雷が 落ちた！ ${d}の ダメージ §7（この ラウンド よけられない${B.tk.stN > 1 ? `・${B.tk.stN}回 つづけて 見つめられ 雷が 強く なった` : ""}）`);
      fxAt(B, s, "minecraft:electric_spark_particle", 8, 1); sfx(B, "ambient.weather.thunder", 1); shake(B, 0.4, 0.4);
      if (B.tk.half) { const o = pick(alive(B.allies).filter((x) => x !== s)); if (o) { const d2 = hurt(B, o, o.mx.hp * 0.12, fx, true); log.push(`§e2本目の 雷が ${o.name}に 落ちた！ ${d2}の ダメージ`); } }
      return `§e雷眼：${s.name}を 見つめて いる`;
    }
    B.tk.prev = null;     log.push("§e単眼が、こちらを 見て いる…… §7（いちばん ダメージを 与えた 子が ねらわれる）");
    return "§e単眼が 見て いる";
  },
  dmg(B, f, t, d) {
    const M = B.tk.M;
    if (t === M) { if (B.tk.shut >= T(B)) d *= 1.5; if (f && f.side === "a") B.tk.dealt.set(f, (B.tk.dealt.get(f) || 0) + d); }
    return d;
  },
  end(B, log) {
    const M = B.tk.M, t = T(B) - 1;
    if (M.hp > 0 && B.tk.shut < t && eyeShut(B, M)) { B.tk.shut = t + 2; log.push("§a§lガムラの 眼が 閉じた！ §r§a2ラウンド、受ける ダメージが 1.5倍"); }
    let top = null, v = 0; for (const [f, d] of B.tk.dealt) if (f.hp > 0 && d > v) { v = d; top = f; }
    B.tk.dealt.clear();
    B.tk.stare = B.tk.shut > t ? null : top;
    if (B.tk.stare) log.push(`§e単眼が ${B.tk.stare.name}を 見つめた……`);
  },
  ai(f, B, opt) {
    const s = B.tk.stare;
    if (f !== B.tk.M || !s || s.hp <= 0) return null;
    const r = aiDecide(f, B, opt); if (r && (r.kind === "attack" || (r.kind === "move" && MOVES[r.move] && MOVES[r.move].target === "enemy"))) r.target = s;
    return r;
  },
};
/* 三冠 リョウマ: 一騎打ちと 居合 */
const stanceOf = (B) => { const t = T(B); return B.tk.half ? (t - 1) % 3 < 2 : Math.floor((t - 1) / 2) % 2 === 0; };
const dKey = (f) => f.owner || "_";
const dOk = (B, D) => !!D && D.hp > 0 && B.allies.includes(D);
/* その 子の 側の 一騎打ちの 子（入れかえで 場に いない 子・倒れた 子は 数えない）。なかま（guest）は だれかの 一騎打ちが 続く かぎり 守られる */
function duelFor(B, f) { const dl = B.tk.dl; if (!dl) return null; const D = dl.get(dKey(f)); if (dOk(B, D)) return D; return f.guest ? [...dl.values()].find((x) => dOk(B, x)) || null : null; }
G[7] = {
  start(B, log) {
    const t = T(B), L = alive(B.allies), dl = (B.tk.dl = B.tk.dl || new Map());   /* 第124版: 共闘では 人ごとに 1体ずつ 一騎打ち */
    if (B.tk.duel && !dl.size) dl.set(dKey(B.tk.duel), B.tk.duel);
    for (const [k, D] of [...dl]) if (!dOk(B, D)) dl.delete(k);
    const L2 = L.filter((x) => !x.guest); for (const x of L2) if (!dl.has(dKey(x))) dl.set(dKey(x), x);
    if (!dl.size && L[0]) dl.set(dKey(L[0]), L[0]);
    B.tk.duel = [...dl.values()][0] || null;
    B.tk.swOk = t % 2 === 1; B.tk.swT = 0; B.tk.swK = new Set(); B.tk.st = stanceOf(B);
    fxAt(B, B.tk.M, TK_PT[7], 5, 2);
    log.push(B.tk.st ? "§c§l居合の 構え §r§c― 武系と 物理系は 斬り返される！ §7魔法や 息で 攻めろ" : "§a§l構えを 解いた §r§a― 武系の ダメージ 1.5倍！");
    log.push(`§f一騎打ち：戦うのは §e${dl.size ? [...dl.values()].map((x) => x.name).join("・") : "？"}§f。${B.tk.swOk ? "§7この ラウンドは 交代できる（戦わせたい 子だけ 技を えらぶ）" : "§7ほかの 子は 見守る"}`);
    return B.tk.st ? "§c居合の 構え：武・物理は 斬り返す" : "§a構えを 解いた：武系 1.5倍";
  },
  act(B, a, log) {
    const f = a.actor; if (!f || f.side !== "a" || f.hp <= 0) return null;
    const dl = (B.tk.dl = B.tk.dl || new Map()), sk = (B.tk.swK = B.tk.swK || new Set()), k = dKey(f), D = duelFor(B, f), set = (x) => { dl.set(k, x); B.tk.duel = [...dl.values()].find((y) => dOk(B, y)) || x; };
    if (f === D) { if (B.tk.swOk) sk.add(k); return null; }
    if (!D && !f.guest) { set(f); log.push(`§e§l${f.name}が 倒れた 仲間に かわって 一騎打ちに 名乗り出た！`); return null; }   /* 第124版: ラウンドの 途中で 倒れても・入れかえても 次の 子が すぐ 戦える（防御でも）*/
    if (a.kind === "defend") return null;
    if (B.tk.swOk && !sk.has(k) && !f.guest) { set(f); sk.add(k); log.push(`§e§l${f.name}が 一騎打ちに 名乗り出た！`); return null; }
    log.push(`§7一騎打ちの 掟： ${f.name}は 手を 出せない`);
    return { fx: { actor: f, anim: "guard", el: null, hit: [], ko: [], healed: [], cat: null } };
  },
  hit(B, f, t, mv, log) { if (t === B.tk.M && f.side === "a" && B.tk.st && (catOf(mv) === "phys" || catOf(mv) === "weapon")) { log.push(`§c§l居合！ §r§cリョウマは ${f.name}の 攻撃を 斬り返した！`); return "bounce"; } return null; },
  dmg(B, f, t, d, mv, log) {
    if (t === B.tk.M && !B.tk.st && catOf(mv) === "weapon") d *= 1.5;
    if (f === B.tk.M && t && t.side === "a") { const D = duelFor(B, t); if (!D || D === t) return d; once(B, `duel${t.name}`, log, `§7（見守る ${t.name}には 刃が とどかない）`); return 0; }
    return d;
  },
  ai(f, B, opt) {
    const Ds = [...(B.tk.dl || new Map()).values()].filter((x) => dOk(B, x)); if (f !== B.tk.M || !Ds.length) return null;
    const r = aiDecide(f, B, opt); if (r && (r.kind === "attack" || (r.kind === "move" && MOVES[r.move] && MOVES[r.move].target === "enemy")) && !Ds.includes(r.target)) r.target = pick(Ds);
    return r;
  },
};
/* 二冠 ギレンドドロス: 三重の 鎧 */
const ARM = [["rock", "岩", 2], ["light", "光", 2], ["dark", "闇", 2]];
const armTxt = (B) => ARM.map(([k, n, mx]) => `${B.tk.arm[k] > 0 ? "§f" : "§8"}${n}${"■".repeat(B.tk.arm[k])}${"□".repeat(mx - B.tk.arm[k])}`).join(" ");
G[8] = {
  setup(B) { B.tk.arm = { rock: 2, light: 2, dark: 2 }; },
  start(B, log) {
    const any = ARM.some(([k]) => B.tk.arm[k] > 0);
    fxAt(B, B.tk.M, TK_PT[8], 4, 1);
    log.push(`§7§l鎧：${armTxt(B)} §r${any ? "§7― ダメージは 4分の1" : "§a― 鎧が ない！ 全力で！"}`);
    if (any) log.push("§7岩は 物理系か 通常攻撃、光の 鎧は 闇属性、闇の 鎧は 光属性で 割れる");
    return any ? `§7鎧：${ARM.filter(([k]) => B.tk.arm[k] > 0).map(([, n]) => n).join("・")}` : "§a鎧が ない！";
  },
  dmg(B, f, t, d, mv, log) {
    if (t !== B.tk.M || !f || f.side !== "a" || mv.gc) return d;
    const c = catOf(mv), A = B.tk.arm;
    const hitK = (c === "phys" || mv.basic) && A.rock > 0 ? "rock" : mv.el === "dark" && A.light > 0 ? "light" : mv.el === "light" && A.dark > 0 ? "dark" : null;
    if (hitK) { A[hitK]--; const nm = ARM.find((x) => x[0] === hitK)[1]; if (A[hitK] <= 0) { log.push(`§6§l${nm}の 鎧が 割れた！`); sfx(B, "random.break", 0.7); } else log.push(`§6${nm}の 鎧に ひびが 入った（のこり ${A[hitK]}）`); }
    return ARM.some(([k]) => A[k] > 0) ? d * 0.25 : d;
  },
  end(B, log) {
    const t = T(B) - 1, ev = B.tk.half ? 3 : 4;
    if (B.tk.M.hp > 0 && t % ev === 0) { const b = ARM.find(([k]) => B.tk.arm[k] <= 0); if (b) { B.tk.arm[b[0]] = b[2]; log.push(`§7§lギレンドドロスは ${b[1]}の 鎧を 組み直した！`); } }
  },
};
/* 一冠 ベルガ: 王の 命令（九人の ギミックも ときどき）*/
const ORD = [
  ["phys", "物理を 使うな", (a, mv) => catOf(mv) === "phys" && isAtkMv(mv)],
  ["magic", "魔法を 使うな", (a, mv) => !!mv && mv.cat === "magic"],
  ["heal", "回復するな", (a, mv) => !!mv && !!(mv.heal || mv.revive || mv.regen)],
  ["same", "同じ 技を 二度 使うな", (a, mv, B) => a.kind === "move" && B.tk.used.has(a.move)],
  ["first", "いちばんに 動くな", (a, mv, B) => !B.tk.moved],
  ["defend", "守るな", (a) => a.kind === "defend"],
  ["weapon", "武器を 使うな", (a, mv) => !!mv && mv.cat === "weapon"],
  ["breath", "息を 吐くな", (a, mv) => !!mv && mv.cat === "breath"],
];
G[9] = {
  start(B, log) {
    const t = T(B), n = B.tk.half ? 2 : 1, L = [...ORD].sort(() => Math.random() - 0.5);
    B.tk.ord = L.slice(0, n); B.tk.used = new Set(); B.tk.moved = false; B.tk.bor = null;
    if (t % 3 === 0) {   /* 九人の 力を 借りる */
      const k = ri(0, 2);
      if (k === 0) { const c = pick(MIR); B.tk.bor = { k: "mirror", c }; log.push(`§5ベルガは テルグの 鏡を 借りた！ §f${CAT_COL[c][1]}を 跳ね返す`); }
      else if (k === 1) { B.tk.bor = { k: "dice" }; log.push("§5ベルガは 双子の サイコロを 借りた！ §c目は 4・5・6 ― ベルガの 攻撃が 2倍"); }
      else { B.tk.bor = { k: "night" }; log.push("§5ベルガは ザキュラスの 夜を 借りた！ §9光属性 いがいの ダメージは 半分"); }
    }
    fxAt(B, B.tk.M, TK_PT[9], 5, 2); sfx(B, "mob.wither.ambient", 0.6);
    log.unshift(`§5§l王の 命令：${B.tk.ord.map((o) => "「" + o[1] + "」").join("")} §r§7（破った 子は 重い 罰）`);
    return `§5命令：${B.tk.ord.map((o) => o[1]).join("・")}`;
  },
  act(B, a, log) {
    const f = a.actor, ail = (f && f.ail) || {}; if (!f || f.side !== "a") return null;
    if (f.hp <= 0 || f.bkT > 0 || f.restT > 0 || (f.boundT && f.boundT === T(B)) || ail.freeze > 0 || ail.sleep > 0) return null;   /* 第124版: 動けない 子は 罰しない */
    const mv = mvOfA(a), bad = (B.tk.ord || []).filter((o) => { try { return o[2](a, mv, B); } catch { return false; } });
    if (!bad.length) return null;
    const st = a.kind === "defend" ? null : ail.para > 0 && Math.random() < 0.5 ? "p" : ail.fear > 0 && Math.random() < 0.6 ? "f" : null;   /* しびれ・おびえで 動けなかった ときも 罰しない（確率は core と 同じ）*/
    if (st) { f.actT = T(B); log.push(st === "p" ? `§e${f.name}は しびれて 動けない！` : `§8${f.name}は おびえて 逃げ回っている！`); return { fx: { actor: f, anim: st === "p" ? null : "guard", el: null, hit: [], ko: [], healed: [], cat: null } }; }
    B.tk.moved = true;
    const d = hurt(B, f, f.mx.hp * 0.4 * bad.length, null, true), bt = `§4§l命令違反！ §r§4${f.name}は「${bad.map((o) => o[1]).join("」「")}」を 破り、`;
    log.push(d > 0 ? `${bt}王の 罰を 受けた！ ${d}の ダメージ・この 行動は 消された` : `${bt}王の 罰に ひざを ついた！ この 行動は 消された`);
    sfx(B, "ambient.weather.thunder", 1.3);
    const fx = { actor: f, anim: "guard", el: "dark", hit: d > 0 ? [f] : [], ko: [], healed: [], cat: null, dmg: d > 0 ? [{ t: f, d, crit: false, weak: false }] : [] }; return { fx };
  },
  after(B, a, fx) {
    if (fx && (fx.mid || (fx.anim && (a.kind === "defend" || a.kind === "tame")))) { B.tk.moved = true; if (a.actor && a.actor.side === "a" && fx.mid && fx.mid !== "basic") (B.tk.used = B.tk.used || new Set()).add(fx.mid); }   /* 第124版: 実際に 動いた あとで 数える */
    if (B.tk.pend && B.tk.pend.length) { if (fx) { (fx.dmg = fx.dmg || []).push(...B.tk.pend); for (const x of B.tk.pend) if (fx.hit && !fx.hit.includes(x.t)) fx.hit.push(x.t); } B.tk.pend = []; } },
  hit(B, f, t, mv, log) { const b = B.tk.bor; if (b && b.k === "mirror" && t === B.tk.M && f.side === "a" && catOf(mv) === b.c) { log.push(`§b§l借りた 鏡が ${f.name}の ${CAT_COL[b.c][1]}を 跳ね返した！`); return "bounce"; } return null; },
  dmg(B, f, t, d, mv) { const b = B.tk.bor; if (b && b.k === "dice" && f === B.tk.M) d *= 2; if (b && b.k === "night" && t === B.tk.M && mv.el !== "light") d *= 0.5; return d; },
};

/* 種族の 特性で ギミックが くずれない ように（打たれて 全能力 上昇・毎ターン 大回復・ダメージ上限 など）は 外す */
const TR_OFF = ["hurtbuf", "regen", "startregen", "killheal", "lifesteal", "dmgcap", "killbuf", "famking", "critheal", "pinch", "halfbuf", "startbuf", "startall", "allyfam", "revive", "undying"];
function tame(f) { if (!f || !f.tr) return; for (const k of TR_OFF) { const v = f.tr[k]; f.tr[k] = typeof v === "object" && v !== null ? {} : typeof v === "boolean" ? false : 0; } f.tr.taken = {}; }
/* 魔将ごとの 攻めの 強さ（模擬戦で 決めた）*/
const TK_CAP = 1500;
const TK_OFF = [0.85, 0.3, 1.4, 0.6, 2.0, 0.55, 0.85, 0.42, 0.3, 1.4];
/* ---------- 共通の つなぎ目 ---------- */
const NOP = () => null;
const HOOKS = {
  start(B, log) {
    const g = G[B.tk.i], t = T(B);
    if (B.tk.lastStart === t) return null; B.tk.lastStart = t; B.tk.said.clear();
    if (t === 1) {
      for (const f of B.enemies) if (f.ent && f.m && f.m.tint) try { B.tk.H.setLook(f.ent, f.m.sp, f.m); } catch {}
      log.push(`§4§l邪闘十魔将 ${TK_CROWN[B.tk.i]} ${TK_NM[B.tk.i]} §r§c― 固有の ギミック「${TK_GNAME[B.tk.i]}」`);
    }
    for (const f of B.enemies) if (f.tkGen && f.hp > 0) { fxAt(B, f, "minecraft:basic_smoke_particle", 2, 0); fxAt(B, f, TK_PT[B.tk.i], 2, 0); if (f.buf) for (const k of Object.keys(f.buf)) if (f.buf[k] > 2) f.buf[k] = 2; }   /* 魔将の 強化は +2段まで（守りを 積みつづけて ギミックが 消えない ように）*/
    for (const f of B.allies) if (f.buf) for (const k of Object.keys(f.buf)) if (f.buf[k] < -4) f.buf[k] = -4;   /* 弱体は −4段まで（攻めが 0に なって 長引かない ように）*/
    const L = B.tk.twins || [B.tk.M], hpN = L.reduce((s, x) => s + Math.max(0, x.hp), 0), hpM = L.reduce((s, x) => s + x.mx.hp, 0);
    if (!B.tk.half && hpN > 0 && hpN <= hpM * 0.5) {   /* 本気の 場面 */
      B.tk.half = true; try { (g.half || NOP)(B); } catch {}
      log.push(`§4§l― ${TK_NM[B.tk.i]}が 本気に なった ―`, ...HALF[B.tk.i]);
      sfx(B, "mob.wither.spawn", 0.7); shake(B, 0.8, 1.2);
      for (const f of L) if (f.hp > 0) { fxAt(B, f, TK_PT[B.tk.i], 12, 1); fxAt(B, f, "minecraft:redstone_ore_dust_particle", 6, 3); }
      if (B.tk.i === 6) { for (const p of B.players || []) try { p.p.runCommand("camera @s fade time 0.05 0.1 0.3 color 255 255 220"); } catch {} sfx(B, "ambient.weather.thunder", 0.7); }
      const sub = []; const nm = g.start ? g.start(B, sub) : null; log.push(...sub);
      return `§4§l本気！ §r${nm || ""}`;
    }
    return g.start ? g.start(B, log) : null;
  },
  end(B, log) { const g = G[B.tk.i]; if (g.end) g.end(B, log); },
  dmg(B, f, t, d, mv, log, fx, opt) {
    const g = G[B.tk.i]; if (f && f.tkGen && t && t.side === "a") d *= B.tk.off || 1;
    if (t && t.tkGen && f && f.side === "a" && fx) {   /* 邪闘の 守り: 1回の 行動で 1体に 与える ダメージは TK_CAP まで（ギミックの 倍率は この あと）*/
      if (t.tkCapFx !== fx) { t.tkCapFx = fx; t.tkCapU = 0; }
      const left = TK_CAP - t.tkCapU; if (left <= 0) { once(B, `cap${f.name}`, log, `§8（邪闘の 守り：1回の 行動で ${TK_CAP}まで）`); return 0; }
      if (d > left) { d = left; once(B, `cap${f.name}`, log, `§8（邪闘の 守り：1回の 行動で ${TK_CAP}まで）`); }
      t.tkCapU += d;
    }
    if (!g.dmg || !mv) return d; const r = g.dmg(B, f, t, d, mv, log, fx || {}, opt); return Number.isFinite(r) ? Math.max(0, r) : d; },
  hit(B, f, t, mv, log) { const g = G[B.tk.i]; return g.hit && f && mv ? g.hit(B, f, t, mv, log) : null; },
  heal(B, f, t, mv, log, fx) { const g = G[B.tk.i]; return g.heal && f ? !!g.heal(B, f, t, mv, log, fx) : false; },
  act(B, a, log) { const g = G[B.tk.i]; return g.act && a && a.actor ? g.act(B, a, log) : null; },
  after(B, a, fx, log) { const g = G[B.tk.i]; if (g.after && a) g.after(B, a, fx, log); for (const f of B.enemies) if (f.tkGen && f.buf) for (const k of Object.keys(f.buf)) if (f.buf[k] > 2) f.buf[k] = 2; },
  ai(f, B, opt) { const g = G[B.tk.i]; if (!g.ai || !f || f.side === "a" || f.owner) return null; return g.ai(f, B, opt); },
  /* 第124版: 出血・毒・火傷・トゲ・最後の報い（core の tkDot から）。魔将の 守りだけ 通す（ふやさない）*/
  dot(B, t, d, log) {
    const i = B.tk.i, M = B.tk.M;
    if (t === M) {
      if (i === 1 && (B.tk.dolls || []).some((g) => g.hp > 0)) { once(B, "itoDot", log, "§5イトマは 人形の 糸に 守られて いる！ §7（人形を 先に 壊せ）"); return 0; }
      if (i === 5 && B.tk.night) d *= 0.35;
      if (i === 8 && B.tk.arm && ARM.some(([k]) => B.tk.arm[k] > 0)) d *= 0.25;
      if (i === 9 && B.tk.bor && B.tk.bor.k === "night") d *= 0.5;
    }
    return d > 0 ? Math.max(1, Math.min(TK_CAP, Math.floor(d))) : 0;
  },
};
/* battle.js から: 魔将の 能力が きまった あとに 1回 */
export function tkSetup(B, i, H) {
  if (!B || !B.enemies || !B.enemies[0] || !(i >= 0 && i < 10)) return;
  const M = B.enemies[0];
  B.tk = { i, M, H: H || {}, said: new Set(), half: false };
  tame(M); M.tkGen = true; M.m.tint = TK_LOOK[i]; M.name = TK_NM[i]; M.m.nm = TK_NM[i];
  M.bossTraits = [...(M.bossTraits || []), `固有の ギミック「${TK_GNAME[i]}」`, `邪闘の 守り（1回の 行動で 受ける ダメージ ${TK_CAP}まで）`, "出血・まひに 強い"];
  B.tk.off = (globalThis.__tkK && globalThis.__tkK[i]) || TK_OFF[i];   /* ギミックを 読む 時間が ある ように 魔将の 与える ダメージを おさえる（模擬戦で 決めた）*/
  { const L = (M.moves || []).filter((id) => { const v = MOVES[id]; return v && !v.heal && !v.regen && !v.revive && !v.reraise && v.kind !== "drain" && !v.drain && !(v.buff && !isAtkMv(v) && Object.values(v.buff).some((x) => x > 0)); }); if (L.length >= 3) M.moves = L; }   /* 回復・吸収・自分の 強化は 持たない（守りは ギミックで）*/
  if (G[i].setup) G[i].setup(B, M);
  B.tkg = HOOKS;
}
export const TK_DEBUG = { G, HOOKS, nightOf, stanceOf, revRound };
