/* 第126版 裏7「帳の王」（閻魔の 神殿）— 作業 UA。MQ27 = 9話。オーナー決定: 常世パック 必須（パックなしは 裏6 の あと「続きは 追加ストーリー」）
   エンマは ムサシの 体を 借りて 座へ 帰る。戦いでは 峰で 打ち、帳を 背に かばう。帳に 幼なじみと セオの 名は ない */
import { bkAdd, bkHas, mqOver, BKE, tokoyoOn, chActive } from "./bkeng.js";
import { facAdd, FAC_OPS, fac, facMark } from "./epfac.js";
import { MQ } from "./saga.js";
import { altarPos, PG_GATE } from "./postgame.js";
import { possessBegin, restoreMusashi } from "./majin.js";
import { ok } from "./ui.js";
import { load, save } from "./store.js";
import { qs } from "./quest.js";
import { UA } from "./bk_u01.js";
const { F, S1 } = FAC_OPS;

/* 閻魔の 神殿の 中（門の 前の 止まった 渡し舟の 水・回廊の 柱と 帳を 書く 王の 像（書見台）・最後の 一体は 手が 空・玉座・帳の 机・奥の 下りの 石段）*/
facAdd("u_temple", { D: [9, 11, 8], box: [-1, -4, 9, 4], H: 5, look: [7, 0, 1], marks: { ferry: [0, -2, 0], statue: [3, -2, 0], last: [5, 2, 0], throne: [8, 0, 1], desk: [7, 1, 1], stairs: [8, -3, 0] }, build: () => [
  F(1, -4, -1, 9, 4, -1, "polished_blackstone_bricks"), F(0, -4, -1, 0, 4, -1, "water"), F(0, -3, 0, 0, -1, 0, "dark_oak_slab"), S1(0, -4, 0, "dark_oak_fence"),
  F(1, -3, 0, 1, -3, 3, "polished_blackstone"), F(1, 3, 0, 1, 3, 3, "polished_blackstone"), F(3, -3, 0, 3, -3, 3, "polished_blackstone"), F(3, 3, 0, 3, 3, 3, "polished_blackstone"), F(5, -3, 0, 5, -3, 3, "polished_blackstone"), F(5, 3, 0, 5, 3, 3, "polished_blackstone"),
  S1(1, -2, 0, "lectern"), S1(1, 2, 0, "lectern"), S1(3, -2, 0, "lectern"), S1(3, 2, 0, "lectern"), S1(5, -2, 0, "lectern"),
  F(7, -2, 0, 8, 2, 0, "blackstone"), S1(8, 0, 1, "polished_blackstone_stairs"), F(9, -1, 0, 9, 1, 3, "polished_blackstone"), S1(7, 1, 1, "lectern"), S1(7, 2, 1, "chain"),
  F(8, -4, 0, 9, -3, 0, "air"), S1(8, -3, -1, "polished_blackstone_brick_stairs"), S1(9, -3, -2, "polished_blackstone_brick_stairs"), S1(1, 0, 0, "soul_lantern"), S1(6, 0, 0, "soul_lantern"),
] });

const PINN = UA.bld("t4", ["inn"], "ポカラの 宿");
const TEMPLE = () => { try { const a = altarPos(); return a ? { x: a.x + 4, z: a.z + 4, nm: "閻魔の 神殿" } : null; } catch { return null; } };
const temple = (K, p) => fac(K, p, "u_temple", "u_temple", 7, UA.Y(K, p));
const M = (K, p, k) => facMark("u_temple", k, p.location);
function enmaEnt(K, p, q) { const e = K.monEnt(p, q || K.fwd(p, 5), "enma", "§4エンマ"); if (ok(e)) try { e.addTag("mrpg_spkm"); e.setDynamicProperty("mrpg:spk", "エンマ"); } catch {} return e; }
const ferryman = (K, p) => K.npcNear(p, "§7渡し守", K.PJ("m6_gramps", 8));
function clearMark(s) { s.enma = Math.max(1, s.enma || 0); s.tkRoad = 1; }

bkAdd("u07", [
  { id: "u07e1", t: "向かい合う 頁", place: PINN, F: ["F43"], battles: 0,
    hint: "§fひだまりの 村 §eポカラの 宿§f で 夜を 明かそう",
    syn: "ポカラの 宿の 悪夢。旅の 手帳の 名前の 頁で、イザクの 頁と エンマの 頁が 向かい合って いた。自分で 自分を 閉じこめた 二人。",
    async run(p, d, K) {
      await K.open(p, "ポカラの 宿（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      await K.narr(p, ["§7その 夜、夢を 見た。"], eM);
      await K.past(p, "§8―― 夢");
      K.sound(p, "item.book.page_turn", 0.8);
      /*F43*/ await K.narr(p, ["§7旅の 手帳の、名前の 頁。§f老人イザク§7 の 頁の 向かいに、知らない 頁が 一枚 増えて いる。", "§8……§4エンマ§8。", "§7七年 かけて 自分の 名を 削った 老人と、自分から 鍔に 入った 王。§8二つの 頁が、鏡の ように 向かい合って いた。"]);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{shock,汗}……っ。……おまえも 見たのか。顔に 書いて ある。", "{closed}……字は 読めねえが、今の 顔は 読める。"], null);
      await K.end(p, { leave: [eM], kind: "night", card: "§7→ 朝、閻魔の 神殿へ" });
      return true;
    } },
  { id: "u07e2", t: "止まった 渡し舟", place: TEMPLE, fac: "u_temple", ans: ["qu061"], battles: 0,
    hint: "§f§5閻魔の 神殿§f の 門へ 行こう",
    syn: "閻魔の 神殿の 門。止まった 渡し守の 舟。渡し守「帳の 王は、狂って などおらなんだ」。",
    async run(p, d, K) {
      temple(K, p); const fq = M(K, p, "ferry");
      await K.open(p, "閻魔の 神殿の 門", "dusk");
      if (fq) await K.push(p, fq, 22, 5, 0.6);
      await K.narr(p, ["§7門の 前の 黒い 水に、小さな 舟が 止まって いる。§8櫂は、千年 動いて いない。"], fq);
      const eF = ferryman(K, p), eM = UA.mu(K, p, true);
      await K.up(p, eF, 10);
      await K.say(p, "渡し守", ["{closed}……鍔の 音が した。千年ぶりだ。", "{up}ここが、帳の 王の 神殿よ。"], eM);
      await K.say(p, "ムサシ", ["{?}じいさん、王さまを 知ってるのか。狂った 王だって 聞いた。"], eF);
      await K.say(p, "渡し守", ["{sad}……帳の 王は、狂って などおらなんだ。", "{closed}狂って おったのは、書けと 命じた ほうよ。"], eM);
      await K.end(p, { leave: [eM], bye: [eF], card: "§7→ 神殿の 回廊へ" });
      return true;
    } },
  { id: "u07e3", t: "空の 手", place: TEMPLE, fac: "u_temple", battles: 0,
    hint: "§f§5閻魔の 神殿§f の 回廊を 進もう",
    syn: "回廊の 柱ごとに、帳を 書く 王の 像。どれも 筆を 持ち、最後の 一体だけ 手が 空だった。",
    async run(p, d, K) {
      temple(K, p); const aq = M(K, p, "statue"), lq = M(K, p, "last");
      await K.open(p, "閻魔の 神殿の 回廊", "dusk");
      if (aq) await K.push(p, aq, 20, 4, 1.2);
      await K.narr(p, ["§7柱ごとに、書見台に 向かう 王の 像。§8どれも 筆を 持ち、帳に 何かを 書いて いる。"], aq);
      if (lq) await K.push(p, lq, 22, 3.5, 1);
      await K.narr(p, ["§7最後の 一体だけ、書見台が ない。§f手が、空だ。"], lq);
      const eM = UA.mu(K, p, true);
      await UA.tap(K, p, eM, lq);
      await K.say(p, "ムサシ", ["{closed}……ほかの 像は、筆の 先まで 詰まった 音だ。", "{sad}こいつだけ、手の 中が 空っぽの 音が する。……筆を、置いたんだな。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 玉座へ" });
      return true;
    } },
  { id: "u07e4", t: "体を 貸す", place: TEMPLE, fac: "u_temple", battles: 0,
    hint: "§f§5閻魔の 神殿§f の 玉座へ",
    syn: "玉座の 前で ムサシ「体を 貸す。話は それからだ」。エンマが 出た。",
    async run(p, d, K) {
      temple(K, p); const tq = M(K, p, "throne");
      await K.open(p, "閻魔の 神殿の 玉座", "dusk");
      if (tq) await K.push(p, tq, 22, 6, 1.4);
      await K.narr(p, ["§7主の いない 玉座。§8かばんの 中で、鍔が 燃える ように 熱い。"], tq);
      const eM = UA.mu(K, p, true);
      if (tq) await K.approach(p, eM, tq, 2, 14);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{closed,up}……着いたぜ、エンマ。おまえの 座だ。", "{angry,!,low}体を 貸す。……話は、それからだ。"], null);
      K.sound(p, "mob.wither.spawn", 0.5); K.shake(p, 0.6, 0.8); K.act(eM, "kneel");
      if (ok(eM)) for (let k = 0; k < 6; k++) { K.burst(p.dimension, eM.location, k % 2 ? "minecraft:basic_flame_particle" : "minecraft:basic_smoke_particle", 4, 0.5, 0.3 + k * 0.3); await K.wait(3); }
      const at = ok(eM) ? { ...eM.location } : null; if (ok(eM)) K.rm(eM);
      const eE = enmaEnt(K, p, at);
      await K.up(p, eE, 12);
      await K.say(p, "エンマ", ["……帰った。", "帳を 開く 前に、確かめる。……鍔を 運んで きた 者が、帳を 預けるに 足るか。"], null);
      await K.end(p, { bye: [eE], card: "§4→ 帳の 王 エンマと 刀を 交える（玉座で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u07e5", t: "峰打ち", place: TEMPLE, fac: "u_temple", battles: 1,
    skip(s) { clearMark(s); },
    hint: "§f§5閻魔の 神殿§f の 玉座で、エンマと 戦おう",
    syn: "エンマとの 戦い。エンマは ムサシの 体を 傷つけない ように 峰で 打ち、帳を 背に かばい 続けた。",
    async run(p, d, K) {
      temple(K, p); const tq = M(K, p, "throne");
      await K.open(p, "閻魔の 神殿の 玉座", "dusk");
      const eE = enmaEnt(K, p, tq ? { x: tq.x, y: tq.y, z: tq.z - 1.5 } : null);
      await K.up(p, eE, 10);
      await K.say(p, "エンマ", ["……来い。"], null);
      if (!K.replay(p)) possessBegin(p);
      let r = null;
      try { r = await K.battle(p, [{ sid: "enma", lv: 100, q: 1, plus: 99 }], { name: "エンマ（ムサシの 体）", arena: "閻魔の 裁き場", theme: "hell", enma: true, enmaN: 0, speaker: "エンマ", lines: { half: "……峰で 足りる。", low: "……帳には、ふれさせぬ。" } }); }
      finally { restoreMusashi(p); }
      if (r !== "win") { await K.say(p, "エンマ", ["……まだ 足りぬ。出直せ。"], null); await K.end(p, { bye: [eE] }); return false; }
      await K.narr(p, ["§7エンマは 最後まで 刃を 返さなかった。§8峰だけで 打ち、背の 帳を かばい 続けた。"], eE);
      await K.say(p, "エンマ", ["……負けた。……だから、見せる。"], null);
      if (!K.replay(p)) { const dd = load(p); if (dd) { clearMark(qs(dd)); save(p, dd); } }
      K.pay(p, this, 500000, [["i_tal9", 1]]);
      await K.end(p, { bye: [eE], card: "§7→ 玉座の 机" });
      return true;
    } },
  { id: "u07e6", t: "折れた 筆", place: TEMPLE, fac: "u_temple", F: ["F27"], battles: 0,
    hint: "§f§5閻魔の 神殿§f の 玉座の 机を 見よう",
    syn: "玉座の 机に、折れた 筆。鎖で 綴じた 帳の 頁は、白い 所ばかり。その 下に、破れた 紙「石の 者を、死者と 書け」。",
    async run(p, d, K) {
      temple(K, p); const kq = M(K, p, "desk");
      await K.open(p, "閻魔の 神殿の 玉座", "dusk");
      if (kq) await K.push(p, kq, 24, 3, 0.8);
      /*F27*/ await K.narr(p, ["§7玉座の 机に、§f折れた 筆§7。§8鎖で 綴じた 帳は、白い 頁ばかりだ。"], kq);
      K.sound(p, "item.book.page_turn", 0.8);
      await K.narr(p, ["§7白い 頁の 下に、破れた 紙が 一枚。§4『石の 者を、死者と 書け』§8……邪神の 命令。"], kq);
      const eE = enmaEnt(K, p, kq ? { x: kq.x - 1.5, y: kq.y - 1, z: kq.z } : null), eM = UA.mu(K, p, true);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{shock}……戻った。体、返して もらったぜ。", "{?}……この 紙、何て 書いて ある。読んで くれ、エンマ。"], eE);
      await K.say(p, "エンマ", ["『石の 者を、死者と 書け』。"], eM);
      await K.end(p, { leave: [eM], bye: [eE], card: "§7→ エンマが 帳を 開く" });
      return true;
    } },
  { id: "u07e7", t: "われは、書かなかった", place: TEMPLE, fac: "u_temple", F: ["F27"], ans: ["qu011", "qu031", "qu051"], battles: 0,
    hint: "§f§5閻魔の 神殿§f の 玉座で、エンマの 話を 聞こう",
    syn: "エンマ「われは、書かなかった」。帳を めくっても、幼なじみと セオの 名は ない（生きて いる）。「ソウラの 写しは、われの 帳の 写しだ」。",
    async run(p, d, K) {
      temple(K, p); const kq = M(K, p, "desk");
      await K.open(p, "閻魔の 神殿の 玉座", "dusk");
      const eE = enmaEnt(K, p, kq ? { x: kq.x - 1.5, y: kq.y - 1, z: kq.z } : null), eM = UA.mu(K, p, true);
      await K.up(p, eE, 10);
      await K.say(p, "エンマ", ["石の 者は、生きて いる。止まって、待って いる だけだ。", "書けば、呼ぶ 声も 届かなく なる。……われは、書かなかった。"], eM);
      await K.say(p, "エンマ", ["筆を 折った。帳を 汚さぬ ために、自ら 鍔に 入った。……王冠から 漏れる ささやきを 斬り、妹を 守る ために。"], eM);
      await K.say(p, "ムサシ", ["{sad}……狂った 王なんか じゃ ねえ。", "{closed}……書かなかった だけだ。"], eE);
      K.sound(p, "item.book.page_turn", 1); if (kq) await K.push(p, kq, 20, 3, 0.8);
      await K.narr(p, [`§7エンマが 帳を めくる。千年分の 頁。§8指が 止まらない。……最後まで めくりきった。`, `§f${K.HN(p)}§7 の 名も、§fセオ§7 の 名も、どこにも ない。`], kq);
      await K.say(p, "エンマ", ["……載って おらぬ。死んで おらぬ。", "ソウラの 霊廟の 写しは、われの 帳の 写しだ。あれに 無いなら、ここにも 無い。"], eM);
      await K.say(p, "ムサシ", ["{shock,!,up}……呼び戻せるって ことだな！", "{?}じゃあ、魂は どこだ。帳じゃ ねえなら、どこへ 連れて 行かれた。"], eE);
      await K.say(p, "エンマ", ["……下だ。この 座の、ずっと 下。"], eM);
      await K.end(p, { leave: [eM], bye: [eE], card: "§7→ 神殿の 奥の 石段へ" });
      return true;
    } },
  { id: "u07e8", t: "動きだす 舟", place: TEMPLE, fac: "u_temple", battles: 0,
    hint: "§f§5閻魔の 神殿§f の 奥の 石段へ",
    syn: "神殿の 奥の 石段。止まって いた 渡し守の 舟が、千年ぶりに 動きだした。",
    async run(p, d, K) {
      temple(K, p); const sq = M(K, p, "stairs"), fq = M(K, p, "ferry");
      await K.open(p, "閻魔の 神殿の 奥", "dusk");
      if (sq) await K.push(p, sq, 20, 5, 0.4);
      await K.narr(p, ["§7玉座の 奥に、下りの §f石段§7。§8冷たい 風と、たくさんの 名を 呼ぶ 声が 上って くる。"], sq);
      K.sound(p, "random.splash", 0.6);
      if (fq) { K.burst(p.dimension, fq, "minecraft:splash_particle", 12, 0.8, 0.3); await K.at(p, fq, 16, 5, 0.8); }
      const eF = ferryman(K, p), eM = UA.mu(K, p, true);
      await K.say(p, "渡し守", ["{shock}……舟が、動いた。", "{smile,up}千年ぶりに、櫂が 水を 覚えて おる。……乗るか。"], eM);
      await K.say(p, "ムサシ", ["{smile,☆}乗る。……いい 音だ、じいさん。水の 音が 生きてる。"], eF);
      await K.end(p, { leave: [eM], bye: [eF], card: "§7→ 石段の 前で、見送りの 人が 待って いる" });
      return true;
    } },
  { id: "u07e9", t: "百と四", place: TEMPLE, fac: "u_temple", F: ["F25"], battles: 0,
    hint: "§f§5閻魔の 神殿§f の 石段の 前",
    syn: "カゲツの 言伝への 返事。座＝ゼ: 見舞いに 来た オルド「……ばかもん。百と 四じゃ」。座＝オ: ゼファード「あやつなら、百と 四と 言う」。",
    async run(p, d, K) {
      temple(K, p); const o = K.ch(p, "c20") === "o";
      await K.open(p, "閻魔の 神殿の 石段", "dusk");
      const eM = UA.mu(K, p, true), who = o ? "ゼファード" : "オルド", eO = K.npcNear(p, o ? "§6ゼファード" : "§eオルド", K.PJ(o ? "zephard" : "ordo", 8));
      await K.up(p, eO, 10);
      await K.say(p, who, o ? ["{closed}……若いの。神殿へ 行くと 聞いた。", "{?}剣の 家の 寝ぼすけから、何か 預かって おらぬか。"] : ["{smile}……見舞いじゃ。神殿へ 下りる 孫の 友を、見送らん わけには いかん。", "{?}寝ぼすけから、何か 預かっとるじゃろ。"], eM);
      await K.say(p, "ムサシ", ["{closed}言伝だ。一字も 変えねえ。", "{up}『オルドに 伝えて くれ。§e百と 三勝§f』。"], eO);
      /*F25*/ await K.up(p, eO, 12);
      if (o) await K.say(p, "ゼファード", ["{smile,…}……あやつなら、§e百と 四§f と 言う。", "{closed}最後の 一つは、自分の 不戦勝だと な。……二人とも 生きて 数えて おる。それで よい。"], eM);
      else await K.say(p, "オルド", ["{closed,…}…………。", "{smile,up}……ばかもん。§e百と 四§f じゃ。最後の 一つは、わしの 不戦勝 じゃろうが。"], eM);
      await K.say(p, "ムサシ", ["{smile}……その 数、帰ったら 寝ぼすけに 言って やる。", "{smile,up}……今、笑ったな。よし。行くぞ。"], eO);
      await UA.zeph(K, p);
      await K.end(p, { leave: [eM], bye: [eO], card: "§5→ 石段の 下、常世へ（右上の 案内）" });
      return true;
    } },
]);

/* MQ27: 裏7（常世パックの ときだけ。パックなしは bkeng.js の packGate が 裏6 の あとで 待たせる）*/
const MQ27 = ["u07e1", "u07e2", "u07e3", "u07e4", "u07e5", "u07e6", "u07e7", "u07e8", "u07e9"];
const SAME = (a, b) => { const A = BKE.get(a), B = BKE.get(b); return A && B && A.place === B.place; };
if (MQ[27]) { MQ[27].trig = (c) => !!c.s.ending && tokoyoOn(); MQ[27].run = async () => true; MQ[27].hint = "§fムサシと §5閻魔の 神殿§f へ 行こう §7（右上の 案内）"; }
mqOver(27, async (p, d, K, c) => {
  const L = c.undone; if (!L.length) return true;
  for (let i = 0; i < L.length; i++) { if (!(await c.play(L[i]))) return false; if (i + 1 < L.length && !SAME(L[i], L[i + 1])) return "next"; }
  return true;
}, { cond: async () => true, spot: (p, d) => { const s = qs(d); const id = MQ27.find((x) => !bkHas(s, x)); const e = id && BKE.get(id); let q = null; try { q = e && e.place ? e.place(p) : null; } catch {} return q ? { x: Math.floor(q.x), y: null, z: Math.floor(q.z), nm: q.nm, key: id, np: 1 } : null; } });
/* 神殿の 前で ガイドブックを 開いた とき（裏7 が 済むまでは 物語の「！」で 進む。前の 版の 鍔を 捧げる 流れは 使わない）*/
PG_GATE.story = (d) => { try { const s = qs(d); if (!s.ending || s.enmaClear || !chActive("u07")) return ""; if (!tokoyoOn()) return PG_GATE.enma ? PG_GATE.enma(d) || "§7鍔は 静かな ままだ……" : ""; return "§7ムサシ「……ここだ。けど、物語の 目印の 所から 入る」\n§8（右上の 案内の「！」で 立ち止まろう）"; } catch { return ""; } };
