// 第126版: 廃都 グランディア（ルインズ荒野の 城）。人の 住まない 崩れた 都の 設計図（置くのは structures.js の runPlan）
// 高さは 都（capitalPlan）と 同じ: 北の 丘 +12・中段 +5・下段 0。物語の 場所（中段 3,5,-6）・ワープ（下段 0,0,23）は そのまま 使える
import { Blue, palOf, __parts } from "./city.js";
const { terrain, blendOut, noise } = __parts;

export const RUIN_V = 1;
const STONE = ["cracked_stone_bricks", "stone_bricks", "mossy_stone_bricks", "cobblestone", "cracked_stone_bricks"];
const RUB = ["cobblestone", "gravel", "mossy_cobblestone", "cracked_stone_bricks", "andesite"];
const LOGX = 'dark_oak_log ["pillar_axis"="x"]', LOGZ = 'dark_oak_log ["pillar_axis"="z"]';

/* 物語の 舞台の 目印（中心・y=下段の 地面 からの ずれ）*/
export const RUIN_MARK = { street: { x: 0.5, y: 0, z: 33.5 }, mural: { x: -36.5, y: 5, z: -0.5 }, court: { x: 0.5, y: 12, z: -26.5 }, hall: { x: 0.5, y: 12, z: -39.5 } };

export function ruinPlan(i, seed) {
  const pal = { ...palOf("castle"), ground: "coarse_dirt", cliff: ["stone", "cobblestone", "andesite", "stone"] };
  const B = new Blue(seed || 1000 + i), R = 72, WALL = 50, s = (seed || i) * 31 + 7;
  const sq = (x, z) => Math.max(Math.abs(x), Math.abs(z), Math.abs(x) + Math.abs(z) - (WALL - 10));
  const H0 = (x, z) => {
    const d = Math.hypot(x, z), q = sq(x, z), n = noise(x + 500, z + 500, s, 14);
    if (d > R) return null;
    if (q > WALL + 9) { const t = Math.min(1, (q - WALL - 9) / 8);
      if (Math.abs(x) <= 4 && z > 0) return 0; if (Math.abs(z - 26) <= 4 && Math.abs(x) > WALL) return 0;
      const north = z < -6 ? Math.min(1, (-6 - z) / 26) : 0; return 2 * Math.round((-1 + t * (3 + north * 8) + n * 3 - (d > R - 4 ? (d - R + 4) * 1.5 : 0)) / 2); }
    if (q > WALL + 1) return (Math.abs(x) <= 4 && z > 0) || (Math.abs(z - 26) <= 4 && Math.abs(x) > WALL) ? 0 : -1;
    if (z < -19) return 12;
    if (z < -12) return 5 + (-12 - z);
    if (z < 14) return 5;
    if (z < 19) return 5 - (z - 13);
    return 0;
  };
  const H = (x, z) => blendOut(H0(x, z), x, z, WALL + 12, R);
  terrain(B, R, H, pal, -18);
  /* 前の 都の 高い 塔・尖塔を 消す（城壁の 内がわ）*/
  for (let z = -WALL - 3; z <= WALL + 3; z += 8) B.fill(-WALL - 3, 30, z, WALL + 3, 58, Math.min(WALL + 3, z + 7), "air");

  /* 置かない 所（舞台の 目印の まわり・道）と 建物の 四角 */
  const CL = [[-8, 26, 8, 40], [-3, 14, 3, WALL + 2], [-4, -20, 4, -11], [0, -9, 6, -3], [-2, 20, 2, 26], [-41, -4, -31, 3], [-24, -4, -14, 2], [-6, -32, 6, -21], [-3, -43, 3, -36], [-WALL, 24, WALL, 28]];
  const free = (x1, z1, x2, z2, p = 0) => !CL.some((q) => x1 - p <= q[2] && x2 + p >= q[0] && z1 - p <= q[3] && z2 + p >= q[1]);
  const flat = (x1, z1, x2, z2) => { const h = H(x1, z1); if (h === null) return null; for (const [a, b] of [[x2, z1], [x1, z2], [x2, z2], [(x1 + x2) >> 1, (z1 + z2) >> 1]]) if (H(a, b) !== h) return null; return h; };
  const inWall = (x1, z1, x2, z2, m = 4) => [[x1, z1], [x2, z1], [x1, z2], [x2, z2]].every(([a, b]) => sq(a, b) <= WALL - m);

  /* 折れた 柱（倒れた 先 dx,dz）*/
  const column = (x, y, z, hmax, dx = 0, dz = 0) => {
    const hh = B.ri(1, hmax); B.set(x, y, z, "chiseled_stone_bricks"); if (hh > 1) B.fill(x, y + 1, z, x, y + hh - 1, z, B.pick(["stone_bricks", "cracked_stone_bricks", "stone_bricks"]));
    if ((dx || dz) && hh < 4) { const L = B.ri(2, 3); B.fill(x + dx * 2, y, z + dz * 2, x + dx * (1 + L), y, z + dz * (1 + L), dx ? 'stone_bricks' : 'cracked_stone_bricks'); }
    return hh;
  };
  /* 崩れた 家（屋根なし・壁は ところどころ）*/
  const ruinHouse = (x, z, w, d, face) => {
    const x1 = x - (w >> 1), x2 = x1 + w - 1, z1 = z - (d >> 1), z2 = z1 + d - 1;
    if (!free(x1, z1, x2, z2, 1)) return false;
    const h = flat(x1 - 1, z1 - 1, x2 + 1, z2 + 1); if (h === null) return false;
    CL.push([x1, z1, x2, z2]);
    B.fill(x1, h - 1, z1, x2, h - 1, z2, B.pick(["cobblestone", "stone_bricks", "mossy_cobblestone", "dark_oak_planks"]));
    const wb = B.pick(STONE);
    for (const [ax, az, bx, bz, f] of [[x1, z1, x2, z1, "n"], [x1, z2, x2, z2, "s"], [x1, z1 + 1, x1, z2 - 1, "w"], [x2, z1 + 1, x2, z2 - 1, "e"]]) {
      const n = Math.max(bx - ax, bz - az);
      for (let k = 0; k <= n; k += 3) { const k2 = Math.min(n, k + 2), mid = n >> 1; if (f === face && k <= mid && k2 >= mid) continue;
        let hh = B.ri(0, 4); if (B.r() < 0.18) hh = B.ri(5, 8); if (!hh) continue;
        if (ax === bx) B.fill(ax, h, az + k, ax, h + hh - 1, az + k2, wb); else B.fill(ax + k, h, az, ax + k2, h + hh - 1, az, wb); }
    }
    for (const [a, b] of [[x1, z1], [x2, z1], [x1, z2], [x2, z2]]) if (B.r() < 0.6) B.fill(a, h, b, a, h + B.ri(2, 6), b, "dark_oak_log");
    if (B.r() < 0.5) { const zz = B.ri(z1 + 1, z2 - 1); B.fill(x1 + 1, h, zz, x2 - 1, h, zz, LOGX); }
    const rx = B.ri(x1 + 1, x2 - 2), rz = B.ri(z1 + 1, z2 - 2); B.fill(rx, h, rz, rx + 1, h, rz + B.ri(0, 1), B.pick(RUB));
    return { h, x1, z1, x2, z2 };
  };
  /* 枯れ木 */
  const deadTree = (x, z) => {
    if (!free(x - 2, z - 2, x + 2, z + 2)) return; const h = H(x, z); if (h === null) return; const t = B.ri(3, 6);
    B.set(x, h - 1, z, "coarse_dirt"); B.fill(x, h, z, x, h + t, z, "dark_oak_log");
    B.fill(x + 1, h + t - 1, z, x + B.ri(1, 2), h + t - 1, z, LOGX); B.fill(x, h + t - 2, z - B.ri(1, 2), x, h + t - 2, z - 1, LOGZ);
    if (B.r() < 0.5) B.set(x - 1, h + t, z, LOGX);
    CL.push([x - 1, z - 1, x + 1, z + 1]);
  };
  /* 崩れた 塔（八角形・屋根なし・上が 欠けて いる）*/
  const brokenTower = (x, g, z, r, h) => {
    const c = Math.max(1, Math.round(r * 0.42)), m = B.pick(STONE), y = g - 4;
    B.fill(x - r + c, y, z - r, x + r - c, g + h, z + r, m); B.fill(x - r, y, z - r + c, x + r, g + h, z + r - c, m);
    if (r > 2) { B.fill(x - r + c + 1, g, z - r + 1, x + r - c - 1, g + h, z + r - 1, "air"); B.fill(x - r + 1, g, z - r + c + 1, x + r - 1, g + h, z + r - c - 1, "air"); }
    const sx = B.r() < 0.5 ? -1 : 1, cut = B.ri(2, Math.max(3, h >> 1)); B.fill(x, g + h - cut, z - r, x + sx * r, g + h, z + r, "air");
  };

  /* ---------- 城壁（崩れて ところどころ 穴）---------- */
  { const r = WALL, c = 10;
    const seg = (x1, z1, x2, z2) => { const h0 = H((x1 + x2) >> 1, (z1 + z2) >> 1); if (h0 === null) return; let hh = B.ri(3, 8); const u = B.r(); if (u < 0.12) hh = 0; else if (u < 0.3) hh = B.ri(1, 2); B.fill(x1, h0 - 4, z1, x2, h0 + hh - 1, z2, B.pick(STONE)); };
    for (let k = -r + c; k <= r - c; k += 4) { const k2 = Math.min(r - c, k + 3);
      if (!(k2 >= -3 && k <= 3)) seg(k, r - 1, k2, r + 1);
      seg(k, -r - 1, k2, -r + 1);
      for (const sx of [-1, 1]) if (!(k2 >= 22 && k <= 30)) seg(sx * r - 1, k, sx * r + 1, k2); }
    for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { for (let k = 0; k <= c; k += 2) { const x = sx * (r - c + k), z = sz * (r - k); seg(x - 1, z - 1, x + 1, z + 1); }
      const tx = sx * (r - c / 2), tz = sz * (r - c / 2), th = H(tx, tz); if (th !== null) brokenTower(tx, th, tz, 4, B.ri(8, 16)); }
    for (const s2 of [-6, 6]) { brokenTower(s2, 0, r, 3, B.ri(8, 14)); for (const sx of [-1, 1]) brokenTower(sx * r, 0, 26 + s2, 3, B.ri(8, 14)); }
  }

  /* ---------- 大通り（砂と 瓦礫）と 崩れた 広場 ---------- */
  for (let z = 19; z <= WALL + 1; z++) B.fill(-3, -1, z, 3, -1, z, B.pick(["gravel", "sand", "coarse_dirt", "cobblestone", "gravel"]));
  for (let x = -WALL + 1; x <= WALL - 1; x += 6) if (Math.abs(x) > 3) B.fill(x, -1, 25, Math.min(WALL - 1, x + 5), -1, 27, B.pick(["gravel", "sand", "coarse_dirt"]));
  B.fill(-8, -1, 26, 8, -1, 40, "stone_bricks");
  for (let n = 0; n < 14; n++) { const x = B.ri(-8, 6), z = B.ri(26, 38); B.fill(x, -1, z, x + B.ri(0, 2), -1, z + B.ri(0, 2), B.pick(["gravel", "cracked_stone_bricks", "coarse_dirt", "sand", "mossy_stone_bricks"])); }
  for (let k = 0; k < 10; k++) { const a = (k / 10) * Math.PI * 2, x = Math.round(Math.cos(a) * 11), z = 33 + Math.round(Math.sin(a) * 11); if (Math.abs(x) <= 4) continue; const hh = column(x, 0, z, 7, Math.sign(x), 0); if (hh >= 6 && B.r() < 0.5) B.set(x, hh, z, "soul_lantern"); }
  CL.push([-12, 21, 12, 45]);
  for (const z of [44, 49]) for (const x of [-6, 6]) column(x, 0, z, 6, Math.sign(x), 0);
  /* 坂と 階段 */
  for (let z = 14; z <= 18; z++) { const h = H(0, z); B.fill(-3, h - 1, z, 3, h - 1, z, B.pick(["stone_bricks", "cracked_stone_bricks", "cobblestone"])); }
  for (let z = -19; z <= -12; z++) { const h = H(0, z); B.fill(-4, h - 1, z, 4, h - 1, z, B.pick(["stone_bricks", "cracked_stone_bricks", "mossy_stone_bricks"])); if (B.r() < 0.6) B.set(B.pick([-5, 5]), h, z, B.pick(RUB)); }

  /* ---------- 中段: 噴水の あと（水の ない 割れた 池）---------- */
  B.fill(-14, 4, -10, 14, 4, 12, "cracked_stone_bricks");
  for (let n = 0; n < 18; n++) { const x = B.ri(-14, 12), z = B.ri(-10, 10); B.fill(x, 4, z, x + B.ri(0, 2), 4, z + B.ri(0, 2), B.pick(["gravel", "coarse_dirt", "stone_bricks", "mossy_stone_bricks"])); }
  B.fill(-3, 4, 1, 3, 4, 7, "stone_bricks"); B.fill(-3, 5, 1, 3, 5, 7, "stone_brick_wall", "outline"); B.fill(-2, 4, 2, 2, 4, 6, "gravel"); B.fill(-2, 5, 2, 2, 5, 6, "air");
  B.set(-3, 5, 4, "air"); B.set(2, 5, 7, "air"); B.fill(0, 5, 4, 0, 6, 4, "chiseled_stone_bricks"); B.set(1, 5, 5, "stone_brick_slab");
  B.fill(-8, 5, -9, -7, 5, -8, "cracked_stone_bricks"); B.set(-8, 6, -9, "chiseled_stone_bricks"); B.fill(-6, 5, -9, -4, 5, -9, "stone_bricks");
  CL.push([-4, 0, 4, 8], [-9, -10, -3, -7]);
  for (const [x, z] of [[-13, -9], [13, -9], [-13, 11], [13, 11]]) column(x, 5, z, 6);

  /* ---------- 壁画の ある 広間（屋根の 半分 落ちた 神殿・中段の 西）---------- */
  { const x1 = -42, x2 = -24, z1 = -10, z2 = 8, y = 5;
    B.fill(x1 - 1, y - 1, z1 - 1, x2 + 1, y - 1, z2 + 1, "stone_bricks");
    for (let n = 0; n < 10; n++) { const x = B.ri(x1, x2 - 2), z = B.ri(z1, z2 - 2); B.fill(x, y - 1, z, x + B.ri(0, 2), y - 1, z + B.ri(0, 2), B.pick(["cracked_stone_bricks", "mossy_stone_bricks", "gravel"])); }
    B.fill(x1, y, z1, x2, y + 10, z1, "stone_bricks"); B.fill(x1, y, z1, x1, y + 10, z2, "stone_bricks");
    for (let x = x1 + 2; x < x2; x += 3) B.fill(x, y + B.ri(8, 10), z1, x + 1, y + 10, z1, "air");
    for (let x = x1 + 3; x < x2 - 2; x += 5) B.fill(x, y + 4, z1, x, y + 6, z1, "air");
    for (let x = x1 + 1; x <= x2; x += 3) { const hh = B.ri(0, 5); if (hh) B.fill(x, y, z2, Math.min(x2, x + 2), y + hh - 1, z2, B.pick(STONE)); }
    for (let z = z1 + 1; z < z2; z += 3) { const z3 = Math.min(z2 - 1, z + 2); if (z3 >= -2 && z <= 0) continue; const hh = z < 0 ? B.ri(6, 11) : B.ri(1, 6); B.fill(x2, y, z, x2, y + hh - 1, z3, B.pick(STONE)); }
    B.fill(x1, y + 11, z1, x2, y + 11, -4, "stone_bricks");
    for (let x = x1; x <= x2; x += 3) { const L = B.ri(0, 3); if (L) B.fill(x, y + 11, -3, Math.min(x2, x + 2), y + 11, -4 + L, B.pick(["stone_bricks", "cracked_stone_bricks"])); }
    for (let x = -38; x <= -26; x += 4) { B.set(x, y, -6, "chiseled_stone_bricks"); B.fill(x, y + 1, -6, x, y + 10, -6, "stone_bricks"); column(x, y, 5, 6, 0, x === -30 ? 1 : 0); }
    for (let n = 0; n < 6; n++) { const x = B.ri(-30, -26), z = B.ri(3, 7); B.fill(x, y, z, x + B.ri(0, 1), y + B.ri(0, 1), z, B.pick(RUB)); }
    for (const [x, z] of [[x1 + 1, z1 + 1], [x2 - 1, z1 + 1]]) B.set(x, y + 9, z, "web");
    /* 壁画（西の 壁の 内がわ）: 太陽・祈る 人たち・まん中に 削られた 影の あと */
    const X = x1, M = (z, yy, b) => B.set(X, y + yy, z, b), MF = (za, ya, zb, yb, b) => B.fill(X, y + ya, za, X, y + yb, zb, b);
    MF(-7, 1, 5, 9, "white_terracotta"); MF(-8, 0, -8, 10, "chiseled_stone_bricks"); MF(6, 0, 6, 10, "chiseled_stone_bricks"); MF(-8, 10, 6, 10, "chiseled_stone_bricks"); MF(-7, 0, 5, 0, "chiseled_stone_bricks");
    MF(-7, 1, 5, 1, "brown_terracotta"); MF(-2, 8, 0, 9, "yellow_terracotta"); M(-3, 9, "orange_terracotta"); M(1, 9, "orange_terracotta"); M(-1, 7, "orange_terracotta");
    for (const [z, c] of [[-6, "blue_terracotta"], [-4, "blue_terracotta"], [3, "red_terracotta"], [5, "red_terracotta"]]) { MF(z, 2, z, 4, c); M(z, 5, "light_gray_terracotta"); M(z + (z < 0 ? 1 : -1), 4, c); }
    MF(-2, 2, -2, 3, "cobblestone"); MF(0, 2, 0, 3, "cobblestone"); MF(-2, 4, 0, 6, "cobblestone"); M(-1, 7, "cobblestone"); M(-3, 5, "cobblestone"); M(1, 5, "cobblestone");
    M(-3, 6, "black_terracotta"); M(1, 4, "black_terracotta"); M(-1, 2, "gray_terracotta"); M(0, 7, "black_terracotta");
    CL.push([x1 - 1, z1 - 1, x2 + 1, z2 + 1]);
  }

  /* ---------- ジンの 城（北の 丘）: 崩れた 城壁・中庭・奥の 間 ---------- */
  { const y = 12, X1 = -14, X2 = 14, Z1 = -47, Z2 = -19;
    B.fill(X1, y - 1, Z1, X2, y - 1, Z2, "stone_bricks");
    for (let n = 0; n < 16; n++) { const x = B.ri(X1, X2 - 2), z = B.ri(Z1, Z2 - 2); B.fill(x, y - 1, z, x + B.ri(0, 2), y - 1, z + B.ri(0, 2), B.pick(["cracked_stone_bricks", "mossy_stone_bricks", "gravel", "coarse_dirt"])); }
    const wseg = (ax, az, bx, bz) => { let hh = B.ri(2, 8); if (B.r() < 0.15) hh = 0; if (hh) B.fill(ax, y, az, bx, y + hh - 1, bz, B.pick(STONE)); };
    for (let k = X1; k <= X2; k += 3) { wseg(k, Z1, Math.min(X2, k + 2), Z1); if (k + 2 < -3 || k > 3) wseg(k, Z2, Math.min(X2, k + 2), Z2); }
    for (let k = Z1 + 1; k < Z2; k += 3) for (const x of [X1, X2]) wseg(x, k, x, Math.min(Z2 - 1, k + 2));
    for (const [x, z] of [[X1, Z1], [X2, Z1], [X1, Z2], [X2, Z2]]) brokenTower(x, y, z, 3, B.ri(7, 13));
    for (const x of [-4, 4]) { B.fill(x, y, Z2 + 1, x, y + B.ri(3, 7), Z2 + 1, "chiseled_stone_bricks"); }
    /* 奥の 間（天守）: 奥の 半分だけ 屋根が のこる */
    const kx1 = -10, kx2 = 10, kz1 = -45, kz2 = -35;
    B.fill(kx1, y - 1, kz1, kx2, y - 1, kz2, "polished_andesite"); B.fill(-1, y - 1, kz1 + 1, 1, y - 1, kz2, "red_wool");
    for (let z = kz1 + 2; z < kz2; z += 3) B.set(B.pick([-1, 1]), y - 1, z, "cracked_stone_bricks");
    B.fill(kx1, y, kz1, kx2, y + 11, kz1, "stone_bricks");
    for (let z = kz1 + 1; z < kz2; z += 3) for (const x of [kx1, kx2]) B.fill(x, y, z, x, y + (z < -40 ? B.ri(9, 11) : B.ri(3, 8)), Math.min(kz2 - 1, z + 2), B.pick(STONE));
    for (let x = kx1; x <= kx2; x += 3) { const x3 = Math.min(kx2, x + 2); if (x3 >= -1 && x <= 1) continue; B.fill(x, y, kz2, x3, y + B.ri(4, 11), kz2, B.pick(STONE)); }
    B.fill(kx1, y + 12, kz1, kx2, y + 12, -42, "stone_bricks"); for (let x = kx1; x <= kx2; x += 3) { const L = B.ri(0, 2); if (L) B.fill(x, y + 12, -41, Math.min(kx2, x + 2), y + 12, -42 + L, "cracked_stone_bricks"); }
    for (const z of [-43, -40, -37]) for (const x of [-6, 6]) { if (z === -43) { B.set(x, y, z, "chiseled_stone_bricks"); B.fill(x, y + 1, z, x, y + 11, z, "stone_bricks"); } else column(x, y, z, 7, Math.sign(x), 0); }
    B.fill(-1, y, kz1 + 1, 1, y, kz1 + 1, "cracked_stone_bricks"); B.set(0, y + 1, kz1 + 1, "chiseled_stone_bricks"); B.set(1, y + 1, kz1 + 1, "stone_brick_slab");
    for (const [x, z] of [[-8, -37], [8, -36], [-8, -43]]) B.fill(x, y, z, x + 1, y + B.ri(0, 1), z + 1, B.pick(RUB));
    for (const [x, z] of [[kx1 + 1, kz1 + 1], [kx2 - 1, kz1 + 1]]) B.set(x, y + 10, z, "web");
    for (const x of [-4, 4]) B.set(x, y, kz1 + 2, "soul_lantern");
    CL.push([kx1, kz1, kx2, kz2]);
    for (const [x, z] of [[-10, -24], [11, -29]]) deadTree(x, z);
    B.set(-6, y, -33, "soul_lantern"); B.set(6, y, -33, "soul_lantern");
    CL.push([X1 - 1, Z1 - 1, X2 + 1, Z2]);
  }
  /* 丘の 貴族の 館（崩れて いる）*/
  for (const sx of [-1, 1]) ruinHouse(sx * 31, -34, 13, 11, sx < 0 ? "e" : "w");

  /* ---------- 屋根の 落ちた 家々 ---------- */
  const chests = [];
  for (const z of [34, 44]) for (const x of [-44, -32, -20, 20, 32, 44]) { const w = B.pick([7, 9]), d = B.pick([7, 9]), xx = x + B.ri(-1, 1); if (!inWall(xx - (w >> 1), z - (d >> 1), xx + (w >> 1), z + (d >> 1), 3)) continue; const r = ruinHouse(xx, z, w, d, B.pick(["n", "s"])); if (r && chests.length < 3 && B.r() < 0.4) chests.push(r); }
  for (const z of [-6, 6]) for (const x of [22, 33, 44]) { const w = B.pick([7, 9]), d = 9, xx = x + B.ri(-1, 1); if (!inWall(xx - (w >> 1), z - (d >> 1), xx + (w >> 1), z + (d >> 1))) continue; const r = ruinHouse(xx, z, w, d, "w"); if (r && chests.length < 4 && B.r() < 0.4) chests.push(r); }
  for (const r of chests) { const x = r.x1 + 1, z = r.z2 - 1; B.set(x, r.h, z, "chest"); B.lootC(x, r.h, z, false); }

  /* ---------- 瓦礫・枯れ木・枯れ草 ---------- */
  for (let n = 0; n < 40; n++) { const x = B.ri(-WALL + 4, WALL - 4), z = B.ri(-WALL + 4, WALL - 4); if (!inWall(x, z, x + 1, z + 1) || !free(x, z, x + 1, z + 1, 1)) continue; const h = flat(x, z, x + 1, z + 1); if (h === null) continue; B.fill(x, h, z, x + B.ri(0, 1), h, z + B.ri(0, 1), B.pick(RUB)); if (B.r() < 0.4) B.set(x, h + 1, z, B.pick(["stone_brick_slab", "cobblestone", "gravel"])); }
  for (let n = 0; n < 30; n++) { const x = B.ri(-WALL + 4, WALL - 6), z = B.ri(-12, WALL - 6), s2 = B.ri(1, 2); if (!inWall(x, z, x + s2, z + s2) || !free(x, z, x + s2, z + s2)) continue; const h = flat(x, z, x + s2, z + s2); if (h === null) continue; B.fill(x, h - 1, z, x + s2, h - 1, z + s2, B.pick(["gravel", "sand", "coarse_dirt", "cobblestone"])); }
  for (let n = 0; n < 14; n++) { const x = B.ri(-WALL + 6, WALL - 6), z = B.ri(-10, WALL - 6); if (inWall(x - 2, z - 2, x + 2, z + 2, 6)) deadTree(x, z); }
  for (let n = 0; n < 60; n++) { const a = B.r() * Math.PI * 2, dd = WALL + 11 + B.r() * (R - WALL - 13), x = Math.round(Math.cos(a) * dd), z = Math.round(Math.sin(a) * dd), h = H(x, z); if (h === null || (Math.abs(x) < 6 && z > WALL) || (Math.abs(z - 26) < 6 && Math.abs(x) > WALL)) continue;
    const u = B.r(); if (u < 0.35) deadTree(x, z); else if (u < 0.55) { B.fill(x, h, z, x + 1, h + B.ri(0, 1), z + 1, B.pick(["cobblestone", "andesite", "mossy_cobblestone"])); } else { B.set(x, h - 1, z, "coarse_dirt"); B.set(x, h, z, "deadbush"); } }
  for (let n = 0; n < 50; n++) { const x = B.ri(-WALL + 4, WALL - 4), z = B.ri(-WALL + 4, WALL - 4); if (!inWall(x, z, x, z) || !free(x, z, x, z, 1)) continue; const h = H(x, z); if (h === null) continue; B.set(x, h - 1, z, "coarse_dirt"); B.set(x, h, z, "deadbush"); }

  B.walk = []; B.npc = []; B.spots = [];
  B.mark = { throne: { x: 0.5, y: 12, z: -42.5 }, master: { ...RUIN_MARK.court }, gate: { x: 0.5, y: 0, z: WALL + 6.5 }, r: R, ruin: RUIN_MARK };
  return B;
}
