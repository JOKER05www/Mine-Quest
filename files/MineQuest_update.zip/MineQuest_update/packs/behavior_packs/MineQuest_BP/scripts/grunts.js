// 第125版: 組織の 下っぱ（名前と 口ぐせ つき・20人）。町の 外を うろつき、旅人を ゆすったり モンスターを いじめたり して いる
// 見つけたら 話しかけて 勝負 → 勝つと 追いはらえる。はじめて 勝った 下っぱからは、ゆすった 物を 取り返せる（1人 1回だけ）
// 軽く: 1人の プレイヤーに 1組まで・10秒ごとに 出すか 決める・動かない（向きだけ）
import { world, system } from "@minecraft/server";
import { ok, busy, choose, ICON, setJob, sound, barNote, isLite } from "./ui.js";
import { load, save } from "./store.js";
import { PSKIN } from "./skinjobs.js";
import { SPECIES, ORDER } from "./data.js";
import { setLook, TYPE, hooks } from "./field.js";
import { groundY, TOWNS, townPos, castleSpot } from "./structures.js";
import { inBattle } from "./battle.js";
import { regionLv, regionIdxAt } from "./worldmap.js";
import { NPC_HOOKS } from "./npchook.js";
import { storyQuiet } from "./townlife.js";
import { boon } from "./boon.js";
import { rankCap } from "./quest.js";
import { ORG, GRUNTS, fmtO } from "./gangnames.js";

export const GR = { fight: null, rate: 0.22 };   /* テストで 差しかえ できる */
const G = new Map();   /* プレイヤー id → 組 */
const CD = new Map();
const COOL = () => (isLite() ? 360 : 240) * 1000;
const OW = () => world.getDimension("minecraft:overworld");
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const B = (t, i) => [t, ICON(i)];
const VICTIMS = ["m6_ruben", "m6_tomas", "aoi", "m6_kenta", "m6_otis", "m6_pip", "m6_samir", "m6_eirik", "m6_umi", "m6_jin2"];
const say = (p, who, l) => { try { p.sendMessage(`§5${who}§f「${fmtO(l)}」`); } catch {} };
const rm = (e) => { if (ok(e)) try { globalThis.__mqCine?.delete(e.id); e.remove(); } catch {} };
/* 勝った 下っぱの 記録（プレイヤーごと）*/
export function beaten(p) { try { const v = JSON.parse(p.getDynamicProperty("mrpg:grb") || "[]"); return Array.isArray(v) ? v : []; } catch { return []; } }
function markBeaten(p, id) { const L = beaten(p); if (L.includes(id)) return false; L.push(id); try { p.setDynamicProperty("mrpg:grb", JSON.stringify(L)); } catch {} return true; }

/* 町・城の そば（まだ できて いない 町も 予定地で 見る）*/
function nearTown(l) {
  try { for (const t of TOWNS) { const q = townPos(t); if (Math.hypot(q.x - l.x, q.z - l.z) < 64) return true; } for (let i = 0; i < 11; i++) { const c = castleSpot(i); if (c && Math.hypot(c.x - l.x, c.z - l.z) < 84) return true; } } catch {}
  return false;
}
function spot(p) {
  const l = p.location;
  for (let k = 0; k < 6; k++) {
    const a = Math.random() * Math.PI * 2, r = 20 + Math.random() * 14, x = l.x + Math.cos(a) * r, z = l.z + Math.sin(a) * r;
    const y = groundY(p.dimension, x, z, Math.floor(l.y)); if (typeof y !== "number" || Math.abs(y - l.y) > 8) continue;
    if (hooks.inTown({ x, y, z }, p.dimension.id) || nearTown({ x, z })) continue;
    try { const t = p.dimension.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) }); if (t && t.location.y > y + 1) continue; } catch {}
    return { x: Math.floor(x) + 0.5, y, z: Math.floor(z) + 0.5 };
  }
  return null;
}
function npc(at, key, name, face) {
  const S = PSKIN[key]; let e; try { e = OW().spawnEntity("mrpg:npc", at); } catch { return null; }
  try { if (S) setJob(e, S[0]); e.addTag("mrpg_npc"); e.addTag("mrpg_temp"); e.addTag("mrpg_grunt"); e.nameTag = name; e.triggerEvent("mrpg:still"); e.teleport(at, { facingLocation: face }); } catch {}
  return e;
}
function monV(at, face) {
  const L = ORDER.filter((k) => SPECIES[k] && !SPECIES[k].hidden && !SPECIES[k].giant && /^[FED]$/.test(SPECIES[k].rank || "") && (SPECIES[k].sz === "S" || SPECIES[k].sz === "M"));
  let e; try { e = OW().spawnEntity(TYPE, at); } catch { return null; }
  try { (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(e.id); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); e.addTag("mrpg_grunt"); setLook(e, L.length ? pick(L) : ORDER[0]); e.triggerEvent("mrpg:make_battle"); e.teleport(at, { facingLocation: face }); } catch {}
  return e;
}
/* だれも 連れて いない 下っぱを えらぶ（地方に 住む 人を 先に）*/
function chooseGrunt(r) {
  const used = new Set([...G.values()].map((g) => g.g.id));
  let L = GRUNTS.filter((g) => g.home === r && !used.has(g.id));
  if (!L.length) L = GRUNTS.filter((g) => g.home <= r && !used.has(g.id));
  return L.length ? pick(L) : null;
}
export function spawnGroup(p) {
  let r = 0; try { r = Math.max(0, Math.min(10, regionIdxAt(p.location))); } catch {}
  const g = chooseGrunt(r); if (!g) return null;
  const at = spot(p); if (!at) return null;
  const kind = Math.random() < 0.55 ? "yusuri" : "ijime", a = Math.random() * Math.PI * 2, vat = { x: at.x + Math.cos(a) * 1.8, y: at.y, z: at.z + Math.sin(a) * 1.8 };
  { const y = groundY(p.dimension, vat.x, vat.z, Math.floor(at.y)); if (typeof y === "number" && Math.abs(y - at.y) <= 1) vat.y = y; else { vat.x = at.x + 1; vat.z = at.z; } }
  const e = npc(at, g.sk, `§5${ORG}の 下っぱ §f${g.nm}`, { x: vat.x, y: vat.y + 1, z: vat.z }); if (!e) return null;
  const vk = pick(VICTIMS), vn = PSKIN[vk] ? PSKIN[vk][1] : "旅人";
  const v = kind === "yusuri" ? npc(vat, vk, `§f${vn}`, { x: at.x, y: at.y + 1.5, z: at.z }) : monV(vat, at);
  if (!v) { rm(e); return null; }
  try { e.setDynamicProperty("mrpg:grOwner", p.id); v.setDynamicProperty("mrpg:grOwner", p.id); e.setProperty("mrpg:act", 16); if (kind === "yusuri") v.setProperty("mrpg:act", 17); } catch {}
  const grp = { pid: p.id, g, kind, e, v, vn, at, t0: Date.now(), st: "wait" };
  G.set(p.id, grp);
  try { barNote(p).setActionBar(kind === "yusuri" ? `§5${ORG}の 下っぱ §f${g.nm}§5 が 旅人を おどして いる！ §7（話しかけよう）` : `§5${ORG}の 下っぱ §f${g.nm}§5 が、石板の 匂いを さがして 野生の モンスターを 追い回して いる！ §7（話しかけよう）`); } catch {}
  sound(p, "note.bass", 0.7); say(p, g.nm, pick(g.meet));
  return grp;
}
function endGroup(pid, flee) {
  const grp = G.get(pid); if (!grp) return; G.delete(pid);
  if (flee && ok(grp.e)) { try { grp.e.setProperty("mrpg:act", 19); OW().spawnParticle("minecraft:white_smoke_particle", grp.e.location); } catch {} system.runTimeout(() => rm(grp.e), 20); } else rm(grp.e);
  system.runTimeout(() => rm(grp.v), flee ? 40 : 0);
}
/* 10秒ごと: 出すか 決める・はなれたら 片づける */
system.runInterval(() => {
  const now = Date.now();
  for (const p of world.getAllPlayers()) {
    try {
      const grp = G.get(p.id);
      if (grp) {
        const far = p.dimension.id !== "minecraft:overworld" || Math.hypot(p.location.x - grp.at.x, p.location.z - grp.at.z) > 72;
        if (grp.st !== "battle" && grp.st !== "talk" && (far || now - grp.t0 > 300000 || !ok(grp.e) || !ok(grp.v) || globalThis.__mqStageZ?.has(p.id))) endGroup(p.id, false);
        continue;
      }
      if (p.dimension.id !== "minecraft:overworld" || busy.has(p.id) || (CD.get(p.id) || 0) > now || globalThis.__mqStageZ?.has(p.id)) continue;
      if (inBattle(p) || storyQuiet(p) || hooks.inTown(p.location, p.dimension.id) || nearTown(p.location) || (hooks.noSpawn && hooks.noSpawn(p))) continue;
      if (Math.random() > GR.rate) continue;
      { const d = load(p); if (!d || !(d.party || []).some((m) => m.hp > 0)) continue; }
      CD.set(p.id, now + COOL());
      spawnGroup(p);
    } catch {}
  }
}, 200);
/* 3秒ごと: 下っぱは いばる・旅人は こまる（向きと しぐさだけ）*/
system.runInterval(() => {
  for (const grp of G.values()) {
    if (grp.st !== "wait" || !ok(grp.e) || !ok(grp.v)) continue;
    try { const t = Math.floor(Date.now() / 3000) % 2; grp.e.setProperty("mrpg:act", t ? 16 : 18); if (grp.kind === "ijime") OW().spawnParticle("minecraft:villager_angry", { x: grp.v.location.x, y: grp.v.location.y + 1.2, z: grp.v.location.z }); } catch {}
  }
}, 60);

/* 勝負 */
async function duel(p, grp) {
  const g = grp.g, fight = GR.fight || (await import("./story.js")).fight, { team } = await import("./saga.js");
  let lv = 5; try { lv = Math.max(3, Math.floor(regionLv(p.location) || 5) + 1); } catch {}
  let n = 2; try { n = rankCap(load(p)) >= 5 ? 3 : 2; } catch {}
  grp.st = "battle"; busy.delete(p.id);
  let res = null;
  try { res = await fight(p, { team: team(g.fams, lv, n) }, { tier: 1, fam: "", npc: null, theme: "arena", name: `${ORG}の ${g.nm}`, arena: "下っぱ との 勝負", speaker: g.nm, lines: { half: g.kuchi, low: pick(g.lose) } }); } catch (e) { console.warn(`[MonsterRPG] grunt fight: ${e}`); }
  try { if (ok(p)) busy.add(p.id); } catch {}
  return res;
}
async function talkTo(p, grp) {
  if (grp.lock) return; grp.lock = true; grp.st = "talk";
  const g = grp.g, first = !beaten(p).includes(g.id);
  busy.add(p.id);
  try {
    const head = grp.kind === "yusuri" ? `§5${g.nm}§f「${fmtO(first ? pick(g.meet) : pick(g.again))}」\n§f${grp.vn}「た、助けて ください……！ 大事な 物を とられて……」` : `§5${g.nm}§f「${fmtO(first ? pick(g.meet) : pick(g.again))}」\n§7（「石板に なつく やつは どいつだ！」と、小さな モンスターを ゆさぶって いる……）`;
    const s = await choose(p, `${ORG}の 下っぱ ${g.nm}`, `${head}\n\n§7口ぐせ:「${fmtO(g.kuchi)}」`, [B("§l勝負して 追いはらう", "i_battle"), B("見のがす", "i_close")]);
    if (s !== 0) { say(p, g.nm, "へっ、こわく なったか？"); grp.st = "wait"; return; }
    const res = await duel(p, grp);
    if (!ok(p)) { endGroup(grp.pid, false); return; }
    if (res !== "win") { say(p, g.nm, pick(g.win)); grp.st = "wait"; grp.t0 = Date.now() - 200000; try { barNote(p).setActionBar("§7負けて しまった……もう一度 話しかければ 再挑戦できる"); } catch {} return; }
    say(p, g.nm, pick(g.lose));
    let got = "";
    if (markBeaten(p, g.id)) { const d = load(p); if (d) { got = boon(p, d, 1); save(p, d); } }   /* はじめて 勝った ときだけ 取り返せる */
    const thanks = grp.kind === "yusuri" ? `§f${grp.vn}「ありがとう！ とられた 物が もどって きた！ ……これ、お礼に 受け取って ください」` : "§7（モンスターは うれしそうに 鳴いて、草むらの 中から 何かを くわえて きた）";
    const body = got ? `${thanks}\n\n§a取り返した 物: ${got}\n§7（${g.nm}を 追いはらった。${beaten(p).length}/${GRUNTS.length}人）` : `${grp.kind === "yusuri" ? `§f${grp.vn}「助かりました……！」` : "§7（モンスターは ほっと した ように 走って いった）"}\n\n§7（${g.nm}からは もう 取り返す 物が ない。${beaten(p).length}/${GRUNTS.length}人）`;
    sound(p, "random.levelup", 1.1);
    await choose(p, `${g.nm}を 追いはらった！`, body, [B("§lOK", "i_back")]);
    endGroup(grp.pid, true);
  } finally { grp.lock = false; busy.delete(p.id); if (G.get(p.id) === grp && grp.st === "talk") grp.st = "wait"; }
}
NPC_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_grunt")) return false;
  const grp = [...G.values()].find((x) => x.e === e || x.v === e || (ok(x.e) && x.e.id === e.id) || (ok(x.v) && x.v.id === e.id));
  if (!grp) { rm(e); return true; }
  if (grp.pid !== p.id) { say(p, grp.g.nm, "なんだ？ お前に 用は ない！"); return true; }
  if (grp.st === "battle" || grp.lock || busy.has(p.id)) return true;
  talkTo(p, grp).catch(() => {}); return true;
});
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => endGroup(playerId, false)); } catch {}
/* 組の ない 下っぱ（ワールドを 閉じた・遠くで 消せなかった）を 片づける */
function sweep() {
  const own = new Set(); for (const g of G.values()) for (const e of [g.e, g.v]) try { if (e) own.add(e.id); } catch {}
  let L = []; try { L = OW().getEntities({ tags: ["mrpg_grunt"] }); } catch {}
  for (const e of L) try { if (!own.has(e.id)) rm(e); } catch {}
}
system.runInterval(sweep, 1200);
system.runTimeout(sweep, 90);
export const __grunt = { G, CD, spawnGroup, endGroup, talkTo, sweep, beaten };
