// 第125版: 層の 地図。クリスタリアの 外れの「水晶の 大坑」（地上・らせんの 段の 大きな 穴）と その 下の「晶窟」（地下 3層の 大空洞）、
// マリノア沖の 深海の まわりの「外洋の 群島」（小島・入り江・海蝕洞・灯台・沈んだ 遺跡・さんご礁・漂う 難破船）
// 探索: ワープ点（ふれると 開く → ガイドブック → 探索手帳 →「層の 地図」から ワープ）・水晶の 結晶（水晶の 欠片・1人 1回）・宝箱（1人 1回）・精鋭（10分で また 出る）・仕掛け・手記
// 建物: ワールドに 1回。近づいたら（120）区画ごとに 少しずつ 置く（enqueue・tickingarea は 1つずつ）。先に 殻（tuff）で 固めてから くりぬく
// 軽く: 10tick ごとに プレイヤーだけ 見る（箱の 中の 人だけ 細かく）。精鋭・野生は 40tick ごと。野生は 地下だけ 数を しぼって 出す
import { world, system } from "@minecraft/server";
import { ITEMS } from "./data.js";
import { load, save } from "./store.js";
import { ok, busy, sound, barNote, heavy, warming, isLite, giveItem, countItem, takeItem, showTitle, notice, choose, ICON, gold } from "./ui.js";
import { WREGIONS, landSites, regionLv, LAYOUT } from "./worldmap.js";
import { enqueue, building, TOWNS, townPos, castleInfo, castleSpot, caveBox, CAVE_R, surfaceY } from "./structures.js";
import { TYPE, initWild, hooks, findPet } from "./field.js";
import { battleHooks, inBattle } from "./battle.js";
import { boon } from "./boon.js";
import { rankCap, storyLootOk } from "./quest.js";
import { XT, EXR } from "./explore.js";
import { spawnBoss } from "./explore2.js";
import { pickWild } from "./field.js";
import { __ds, floorAt } from "./deepsea.js";

export const LM_V = 1;
const KC = "mrpg:lmc", KS = "mrpg:lms", PK = "mrpg:lmp";
const OW = () => world.getDimension("minecraft:overworld");
export const LMW = { cap: [4, 2, 1], resp: 600000, fcap: 16384 };   /* 地下の 野生の 上限（重さ 0/1/2）・精鋭が また 出るまで（ms）・1回の fill の 大きさ */
const SHARD = "x_shard";

/* ---------- コマンドの 下書き（絶対座標・区画で 切る・大きい fill は 分ける）---------- */
class LP {
  constructor() { this.o = []; }
  fill(x1, y1, z1, x2, y2, z2, b, m = "") { this.o.push([Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2), Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), b, m]); }
  set(x, y, z, b) { this.o.push([x, y, z, x, y, z, b, "", 1]); }
}
function splitTo(L, a, cap) {
  const [x1, y1, z1, x2, y2, z2, b, m, s] = a;
  if (s) { L.push(`setblock ${x1} ${y1} ${z1} ${b}`); return; }
  const v = (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
  if (v <= cap) { L.push(`fill ${x1} ${y1} ${z1} ${x2} ${y2} ${z2} ${b}${m ? " " + m : ""}`); return; }
  const dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
  if (dx >= dz && dx >= dy) { const k = (x1 + x2) >> 1; splitTo(L, [x1, y1, z1, k, y2, z2, b, m], cap); splitTo(L, [k + 1, y1, z1, x2, y2, z2, b, m], cap); }
  else if (dz >= dy) { const k = (z1 + z2) >> 1; splitTo(L, [x1, y1, z1, x2, y2, k, b, m], cap); splitTo(L, [x1, y1, k + 1, x2, y2, z2, b, m], cap); }
  else { const k = (y1 + y2) >> 1; splitTo(L, [x1, y1, z1, x2, k, z2, b, m], cap); splitTo(L, [x1, k + 1, z1, x2, y2, z2, b, m], cap); }
}
/* box = {x1,x2,z1,z2}（無ければ 全部）。順番は そのまま */
export function cmdsOf(ops, box = null, cap = LMW.fcap) {
  const L = [];
  for (const a of ops) {
    if (!box) { splitTo(L, a, cap); continue; }
    const x1 = Math.max(a[0], box.x1), x2 = Math.min(a[3], box.x2), z1 = Math.max(a[2], box.z1), z2 = Math.min(a[5], box.z2);
    if (x1 > x2 || z1 > z2) continue;
    splitTo(L, [x1, a[1], z1, x2, a[4], z2, a[6], a[7], a[8]], cap);
  }
  return L;
}
/* 丸（3列ずつの 帯）。r の 内側に おさまる 形 */
function disc(P, cx, cz, r, y1, y2, b, m = "", rz = r) {
  const st = r <= 8 ? 1 : 3;
  for (let x0 = -r; x0 <= r; x0 += st) {
    const x1 = Math.min(r, x0 + st - 1), q = x0 <= 0 && x1 >= 0 ? 0 : Math.min(Math.abs(x0), Math.abs(x1)) === Math.abs(x0) ? Math.abs(x1) : Math.abs(x0);
    const t = 1 - (q * q) / (r * r); if (t < 0) continue; const hw = Math.floor(rz * Math.sqrt(t)); if (hw < 0) continue;
    P.fill(cx + x0, y1, cz - hw, cx + x1, y2, cz + hw, b, m);
  }
}
export const inDisc = (cx, cz, r, x, z, rz = r) => { const dx = x - cx, dz = z - cz; return (dx * dx) / (r * r) + (dz * dz) / (rz * rz) <= 1; };
const rng = (seed) => { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };

/* ---------- 晶窟の 形（中心からの ずれ）---------- */
/* 広間: id・中心 x z・半幅・半奥・高さ・層 */
export const HALLS = [
  ["H1", 0, 0, 28, 28, 20, 1, "大空洞"], ["H2", -62, -8, 16, 14, 12, 1, "採掘基地"], ["H3", 60, 24, 14, 16, 14, 1, "東の 晶洞"], ["H4", 14, -66, 14, 12, 10, 1, "北の 坑道"],
  ["H5", -36, 52, 30, 22, 22, 2, "地底湖"], ["H6", 56, -46, 22, 20, 18, 2, "古代の 遺跡"], ["H7", -68, -56, 18, 18, 16, 2, "光る きのこの 森"], ["H8", 44, 48, 10, 10, 10, 2, "峡間"],
  ["H9", 6, -4, 26, 26, 24, 3, "結晶の 大広間"], ["H10", -62, 30, 15, 15, 14, 3, "青の 淵"], ["H11", 70, 62, 13, 13, 12, 3, "最深の 祠"],
];
export const TUNS = [["H1", "H2", 4], ["H1", "H3", 4], ["H1", "H4", 3], ["H5", "H8", 4], ["H8", "H6", 4], ["H5", "H7", 3], ["H9", "H10", 4], ["H9", "H11", 3]];
/* 縦穴: x z（4×4 の 角）・上の 層と 広間・下の 層と 広間 */
export const SHAFTS = [[-60, -30, 1, "H2", 2, "H7"], [52, 36, 1, "H3", 2, "H8"], [-50, 36, 2, "H5", 3, "H10"], [44, -36, 2, "H6", 3, "H9"]];
export const RING = [62, 54, 46, 38, 30, 22, 14];
export const fk = (S, k) => S.G - 5 * (k + 1);
const H = (id) => HALLS.find((h) => h[0] === id);
export const lvY = (S, l) => (l === 1 ? S.f1 : l === 2 ? S.f2 : S.f3);
export function hallBox(S, h) { const f = lvY(S, h[6]); return { x1: S.x + h[1] - h[3], x2: S.x + h[1] + h[3], z1: S.z + h[2] - h[4], z2: S.z + h[2] + h[4], f, top: f + h[5] }; }
/* 道の 2本の 箱（x を 先に、次に z）*/
export function tunBoxes(ax, az, bx, bz, w) { const lo = -(w >> 1), hi = lo + w - 1; return [[Math.min(ax, bx) + lo, az + lo, Math.max(ax, bx) + hi, az + hi], [bx + lo, Math.min(az, bz) + lo, bx + hi, Math.max(az, bz) + hi]]; }
const RAMP_A = (k) => ((20 - 105 * k) * Math.PI) / 180;
const SH = (y) => (y < 0 ? "deepslate" : "tuff");

/* 地面 G（9点の まん中）。水・高低差の 大きい 所は ダメ */
export function judgeLand(dim, c, lim = 16) {
  const pts = [[0, 0]]; for (let k = 0; k < 8; k++) pts.push([Math.round(Math.cos((k * Math.PI) / 4) * 50), Math.round(Math.sin((k * Math.PI) / 4) * 50)]);
  const ys = [];
  for (const [a, b] of pts) {
    const y = surfaceY(dim, c.x + a, c.z + b); if (y === null || y === undefined) return null;
    let bl; try { bl = dim.getBlock({ x: c.x + a, y: y - 1, z: c.z + b }); } catch { return null; }
    if (!bl || bl.isLiquid || /water|lava|ice/.test(bl.typeId)) return { bad: "water" };
    ys.push(y - 1);
  }
  ys.sort((a, b) => a - b);
  if (ys[ys.length - 1] - ys[0] > lim) return { bad: "steep" };
  const G = ys[4]; if (G < 56 || G > 150) return { bad: "height" };
  let f1 = G - 59; if (f1 - 40 < -54) f1 = -14;
  return { G, f1, f2: f1 - 20, f3: f1 - 40 };
}

/* ---------- 大坑と 晶窟の 下書き。R = 記録（ワープ点・結晶・宝箱・手記・仕掛け・精鋭・野生の 点）---------- */
export function planChasm(S) {
  const P = new LP(), X = S.x, Z = S.z, G = S.G, r = rng(Math.abs(X * 73856093 ^ Z * 19349663));
  const R = { w: [], n: [], c: [], t: [], z: [], e: [], sp: [] };
  const A = (dx, dz) => [X + dx, Z + dz];
  const node = (lay, dx, y, dz) => { const [x, z] = A(dx, dz); R.n.push([`c.n${R.n.length + 1}`, x, y, z, lay]); return [x, y, z]; };
  const chest = (lay, dx, y, dz, rare = 0) => { const [x, z] = A(dx, dz); R.c.push([`c.c${R.c.length + 1}`, x, y, z, lay, rare]); };
  const note = (lay, dx, y, dz, t) => { const [x, z] = A(dx, dz); R.t.push([`c.t${R.t.length + 1}`, x, y, z, lay, t]); };
  const wp = (lay, dx, y, dz, n) => { const [x, z] = A(dx, dz); R.w.push([`c.w${R.w.length + 1}`, x, y, z, lay, n]); };
  const hb = HALLS.map((h) => [h, hallBox(S, h)]);
  /* ===== 1. 殻 ===== */
  disc(P, X, Z, RING[0], G - 7, G - 6, "tuff", "replace air");   /* 縁の 下の すきま */
  for (const [h, b] of hb) {
    const s = SH(b.f);
    P.fill(b.x1 - 1, b.top, b.z1 - 1, b.x2 + 1, b.top, b.z2 + 1, s);
    P.fill(b.x1 - 1, b.f, b.z1 - 1, b.x1 - 1, b.top, b.z2 + 1, s); P.fill(b.x2 + 1, b.f, b.z1 - 1, b.x2 + 1, b.top, b.z2 + 1, s);
    P.fill(b.x1, b.f, b.z1 - 1, b.x2, b.top, b.z1 - 1, s); P.fill(b.x1, b.f, b.z2 + 1, b.x2, b.top, b.z2 + 1, s);
  }
  const tunAll = [];
  for (const [a, b, w] of TUNS) { const ha = H(a), hbb = H(b), f = lvY(S, ha[6]); for (const t of tunBoxes(ha[1], ha[2], hbb[1], hbb[2], w)) tunAll.push([t, f]); }
  for (const [x, z, lu, hu, ll, hl] of SHAFTS) {
    const u = H(hu), l = H(hl);
    for (const t of tunBoxes(x + 1, z + 1, u[1], u[2], 4)) tunAll.push([t, lvY(S, lu)]);
    for (const t of tunBoxes(x + 1, z + 1, l[1], l[2], 4)) tunAll.push([t, lvY(S, ll)]);
  }
  for (const [[x1, z1, x2, z2], f] of tunAll) P.fill(X + x1 - 1, f, Z + z1 - 1, X + x2 + 1, f + 6, Z + z2 + 1, SH(f));
  for (const [x, z, lu, , ll] of SHAFTS) { const fu = lvY(S, lu), fl = lvY(S, ll); P.fill(X + x - 1, fl, Z + z - 1, X + x + 4, fu + 6, Z + z + 4, SH(fl)); }
  /* ===== 2. くりぬく ===== */
  for (const [h, b] of hb) {
    P.fill(b.x1, b.f + 1, b.z1, b.x2, b.top - 5, b.z2, "air");
    P.fill(b.x1 + 4, b.top - 4, b.z1 + 4, b.x2 - 4, b.top - 1, b.z2 - 4, "air");
    P.fill(b.x1, b.f, b.z1, b.x2, b.f, b.z2, SH(b.f));
    for (const [cx, cz] of [[b.x1, b.z1], [b.x2 - 2, b.z1], [b.x1, b.z2 - 2], [b.x2 - 2, b.z2 - 2]]) P.fill(cx, b.f + 1, cz, cx + 2, b.top, cz + 2, SH(b.f));
  }
  for (const [[x1, z1, x2, z2], f] of tunAll) { P.fill(X + x1, f + 1, Z + z1, X + x2, f + 5, Z + z2, "air"); P.fill(X + x1, f, Z + z1, X + x2, f, Z + z2, SH(f)); }
  for (const [x, z, lu, , ll] of SHAFTS) { const fu = lvY(S, lu), fl = lvY(S, ll); P.fill(X + x, fl + 1, Z + z, X + x + 3, fu + 5, Z + z + 3, "air"); P.fill(X + x + 1, fl + 1, Z + z + 1, X + x + 1, fu, Z + z + 1, "scaffolding"); P.fill(X + x, fu, Z + z, X + x + 3, fu, Z + z + 3, "scaffolding"); }
  /* 大坑: 段ごとに くりぬいて 床 → 次の 段 */
  const FB = ["calcite", "tuff", "smooth_basalt", "calcite", "tuff", "smooth_basalt", "calcite"];
  for (let k = 0; k < RING.length; k++) { disc(P, X, Z, RING[k], fk(S, k) + 1, k ? fk(S, k - 1) : G + 10, "air"); disc(P, X, Z, RING[k], fk(S, k), fk(S, k), FB[k]); }
  for (let k = 0; k < RING.length - 1; k++) {   /* 坂（らせん）*/
    const a = RAMP_A(k), f = fk(S, k), f2 = fk(S, k + 1);
    for (let j = 1; j <= 4; j++) { const d = RING[k + 1] - j + 1, x = X + Math.round(Math.cos(a) * d), z = Z + Math.round(Math.sin(a) * d); P.fill(x - 1, f2, z - 1, x + 1, f - j, z + 1, "smooth_basalt"); }
    const x0 = X + Math.round(Math.cos(a) * (RING[k + 1] + 2)), z0 = Z + Math.round(Math.sin(a) * (RING[k + 1] + 2)); P.fill(x0 - 1, f + 1, z0 - 1, x0 + 1, f + 3, z0 + 1, "air");
  }
  /* 縁から 1段目へ（野営地の 側）*/
  { const a = Math.PI; for (let j = 1; j <= 4; j++) { const d = RING[0] - j + 1, x = X + Math.round(Math.cos(a) * d), z = Z + Math.round(Math.sin(a) * d); P.fill(x - 1, fk(S, 0), z - 1, x + 1, G - j, z + 1, "smooth_basalt"); P.fill(x - 1, G - j + 1, z - 1, x + 1, G + 3, z + 1, "air"); } }
  /* 坑の 口 → 大空洞の 湖 */
  const h1 = hallBox(S, H("H1"));
  disc(P, X, Z, 11, S.f1 - 6, S.f1 - 1, "tuff"); disc(P, X, Z, 10, S.f1 - 4, S.f1, "water");
  disc(P, X, Z, 5, h1.top - 5, fk(S, 6), "air");
  P.fill(X + 5, S.f1 - 3, Z, X + 5, fk(S, 6), Z, "scaffolding");
  for (const [dx, dz] of [[6, 0], [-6, 0], [0, 6], [0, -6], [4, 4], [-4, 4], [4, -4], [-4, -4]]) P.set(X + dx, fk(S, 6), Z + dz, "polished_basalt");
  /* 地底湖・青の 淵 */
  const h5 = H("H5"), L5 = { x: X - 30, z: Z + 56 };
  disc(P, L5.x, L5.z, 19, S.f2 - 6, S.f2 - 1, "tuff", "", 13); disc(P, L5.x, L5.z, 18, S.f2 - 4, S.f2, "water", "", 12);
  for (const [dx, dz] of [[-8, 2], [7, -3]]) { disc(P, L5.x + dx, L5.z + dz, 3, S.f2 - 4, S.f2 + 1, "tuff"); P.fill(L5.x + dx - 1, S.f2 + 1, L5.z + dz - 1, L5.x + dx + 1, S.f2 + 1, L5.z + dz + 1, "moss_block"); }
  const L10 = { x: X - 62, z: Z + 26 }; disc(P, L10.x, L10.z, 8, S.f3 - 5, S.f3 - 1, "deepslate"); disc(P, L10.x, L10.z, 7, S.f3 - 3, S.f3, "water"); disc(P, L10.x, L10.z, 4, S.f3 - 4, S.f3 - 4, "sea_lantern");
  /* ===== 3. 飾り ===== */
  /* 灯り: 天井（広間）・道の 天井 */
  for (const [h, b] of hb) { const lt = h[6] === 2 && h[0] === "H7" ? "shroomlight" : h[6] === 1 ? "shroomlight" : "sea_lantern"; for (let x = b.x1 + 5; x <= b.x2 - 5; x += 8) for (let z = b.z1 + 5; z <= b.z2 - 5; z += 8) P.set(x, b.top, z, lt); }
  for (const [[x1, z1, x2, z2], f] of tunAll) { if (x2 - x1 > z2 - z1) { for (let x = x1 + 3; x <= x2; x += 9) P.set(X + x, f + 6, Z + ((z1 + z2) >> 1), "sea_lantern"); } else for (let z = z1 + 3; z <= z2; z += 9) P.set(X + ((x1 + x2) >> 1), f + 6, Z + z, "sea_lantern"); }
  /* 滝（天井の 近くの 岩だなから）*/
  P.fill(X - 21, h1.top - 7, Z - 27, X - 19, h1.top - 7, Z - 26, "tuff"); P.set(X - 20, h1.top - 6, Z - 27, "water");
  const b5 = hallBox(S, h5); P.fill(X - 33, b5.top - 7, b5.z2 - 1, X - 29, b5.top - 7, b5.z2, "tuff"); P.set(X - 31, b5.top - 6, b5.z2, "water"); P.set(X - 30, b5.top - 6, b5.z2, "water");
  /* --- 地上: 野営地（縁の 外・西）--- */
  P.fill(X - 86, G + 1, Z - 11, X - 66, G + 10, Z + 11, "air"); P.fill(X - 86, G - 4, Z - 11, X - 66, G - 1, Z + 11, "dirt", "replace air"); P.fill(X - 86, G, Z - 11, X - 66, G, Z + 11, "coarse_dirt");
  P.fill(X - 86, G, Z - 1, X - 63, G, Z + 1, "spruce_planks");
  for (const [tx, tz, col] of [[-84, -9, "white_wool"], [-78, -9, "light_gray_wool"], [-84, 5, "white_wool"]]) { P.fill(X + tx, G + 1, Z + tz, X + tx + 3, G + 2, Z + tz + 3, col); P.fill(X + tx + 1, G + 3, Z + tz, X + tx + 2, G + 3, Z + tz + 3, col); P.fill(X + tx + 1, G + 1, Z + tz + (tz < 0 ? 3 : 0), X + tx + 2, G + 2, Z + tz + (tz < 0 ? 3 : 0), "air"); P.fill(X + tx + 1, G + 1, Z + tz + 1, X + tx + 2, G + 1, Z + tz + 2, "air"); }
  P.set(X - 72, G + 1, Z - 5, "campfire"); P.set(X - 70, G + 1, Z - 8, "barrel"); P.set(X - 70, G + 2, Z - 8, "barrel"); P.set(X - 69, G + 1, Z - 8, "barrel"); P.set(X - 72, G + 1, Z + 7, "crafting_table"); P.set(X - 71, G + 1, Z + 7, "cartography_table");
  for (const [dx, dz] of [[-67, -3], [-67, 3], [-80, -2], [-80, 2]]) { P.fill(X + dx, G + 1, Z + dz, X + dx, G + 2, Z + dz, "spruce_fence"); P.set(X + dx, G + 3, Z + dz, "lantern"); }
  wp("g", -76, G + 1, 0, "野営地"); chest("g", -84, G + 1, 0); note("g", -73, G + 1, 7, "t1");
  /* 展望台（南・北に 張り出す）*/
  for (const s of [1, -1]) { const z1 = Z + s * 54, z2 = Z + s * 72; P.fill(X - 1, G + 1, Math.min(z1, z2), X + 1, G + 4, Math.max(z1, z2), "air"); P.fill(X - 1, G, Math.min(z1, z2), X + 1, G, Math.max(z1, z2), "spruce_planks"); P.fill(X - 2, G + 1, Math.min(z1, z2), X - 2, G + 1, Math.max(z1, z2) - (s > 0 ? 0 : 0), "spruce_fence"); P.fill(X + 2, G + 1, Math.min(z1, z2), X + 2, G + 1, Math.max(z1, z2), "spruce_fence"); P.fill(X - 1, G + 1, z1, X + 1, G + 1, z1, "spruce_fence"); P.fill(X - 2, G - 6, z2 - s * 2, X - 2, G - 1, z2 - s * 2, "spruce_log"); P.fill(X + 2, G - 6, z2 - s * 2, X + 2, G - 1, z2 - s * 2, "spruce_log"); }
  /* クレーン（ring0）*/
  for (const deg of [40, 140, 320]) {
    const a = (deg * Math.PI) / 180, x = X + Math.round(Math.cos(a) * 58), z = Z + Math.round(Math.sin(a) * 58), f = fk(S, 0), ux = -Math.sign(Math.round(Math.cos(a) * 10)) || 0, uz = -Math.sign(Math.round(Math.sin(a) * 10)) || 0;
    P.fill(x, f + 1, z, x, f + 16, z, "spruce_log"); P.fill(x - 1, f + 1, z - 1, x + 1, f + 1, z + 1, "spruce_planks");
    for (let j = 1; j <= 9; j++) P.set(x + ux * j, f + 16, z + uz * j, "spruce_planks");
    P.fill(x + ux * 9, f + 10, z + uz * 9, x + ux * 9, f + 15, z + uz * 9, "chain"); P.set(x + ux * 9, f + 9, z + uz * 9, "barrel");
  }
  /* 足場（段の 壁）*/
  for (const [k, deg] of [[1, 150], [3, 30], [5, 250]]) { const a = (deg * Math.PI) / 180, d = RING[k + 1] - 1, x = X + Math.round(Math.cos(a) * d), z = Z + Math.round(Math.sin(a) * d); P.fill(x, fk(S, k + 1) + 1, z, x, fk(S, k), z, "scaffolding"); }
  /* レール（坂と かさならない 所）*/
  for (let k = 1; k <= 5; k++) for (const deg of [0, 180]) {
    const near = [k - 1, k].some((j) => j >= 0 && j < 6 && Math.abs((((RAMP_A(j) * 180) / Math.PI - deg) % 360 + 540) % 360 - 180) < 25); if (near) continue;
    const d = ((RING[k] + RING[k + 1]) >> 1) + 1, x = X + (deg ? -d : d); P.fill(x, fk(S, k) + 1, Z - 5, x, fk(S, k) + 1, Z + 5, "rail"); P.set(x + (deg ? -1 : 1), fk(S, k) + 1, Z + 6, "barrel");
  }
  wp("g", 0, fk(S, 6) + 1, -10, "坑の 底"); chest("g", -9, fk(S, 6) + 1, 6);
  /* 地上の 結晶（段の 床・10）*/
  for (let k = 0; k < 6; k++) for (const off of k < 4 ? [115, 245] : [80]) {
    const a = ((off + k * 37) * Math.PI) / 180, d = (RING[k] + RING[k + 1]) >> 1; node("g", Math.round(Math.cos(a) * d), fk(S, k) + 1, Math.round(Math.sin(a) * d));
  }
  R.e.push(["c.e1", X + 0, fk(S, 3) + 1, Z + 34, "g"]);
  /* --- H1 大空洞 --- */
  for (const [dx, dz] of [[-18, -18], [18, 16], [-16, 20]]) P.fill(X + dx, S.f1 + 1, Z + dz, X + dx + 1, S.f1 + 14, Z + dz + 1, "tuff");
  for (let i = 0; i < 10; i++) { const dx = Math.round((r() - 0.5) * 48), dz = Math.round((r() - 0.5) * 48); if (Math.hypot(dx, dz) > 13) P.set(X + dx, S.f1 + 1, Z + dz, `glow_lichen ["multi_face_direction_bits"=1]`); }
  node("u", -22, S.f1 + 1, 14); node("u", 22, S.f1 + 1, -20);
  /* --- H2 採掘基地 --- */
  { const cx = X - 62, cz = Z - 8, f = S.f1;
    P.fill(cx - 14, f + 1, cz + 4, cx + 14, f + 1, cz + 4, "rail"); P.fill(cx - 4, f, cz - 12, cx + 4, f, cz + 12, "spruce_planks");
    for (const [tx, tz] of [[-12, -11], [7, -11], [-12, 7]]) { P.fill(cx + tx, f + 1, cz + tz, cx + tx + 3, f + 2, cz + tz + 3, "brown_wool"); P.fill(cx + tx + 1, f + 3, cz + tz, cx + tx + 2, f + 3, cz + tz + 3, "brown_wool"); P.fill(cx + tx + 1, f + 1, cz + tz + 1, cx + tx + 2, f + 2, cz + tz + 3, "air"); }
    for (const [dx, dz] of [[-6, -6], [6, -6], [-6, 8], [6, 8]]) { P.fill(cx + dx, f + 1, cz + dz, cx + dx, f + 3, cz + dz, "spruce_fence"); P.set(cx + dx, f + 4, cz + dz, "lantern"); }
    for (const [dx, dz] of [[10, 9], [11, 9], [10, 10]]) P.set(cx + dx, f + 1, cz + dz, "barrel");
    P.fill(cx + 12, f + 1, cz - 3, cx + 12, f + 9, cz - 3, "spruce_log"); P.fill(cx + 8, f + 10, cz - 3, cx + 12, f + 10, cz - 3, "spruce_planks"); P.fill(cx + 8, f + 6, cz - 3, cx + 8, f + 9, cz - 3, "chain"); P.set(cx + 8, f + 5, cz - 3, "iron_block");
    P.set(cx - 2, f + 1, cz - 3, "campfire");
  }
  wp("u", -62, S.f1 + 1, 2, "採掘基地"); chest("u", -50, S.f1 + 1, -13); note("u", -58, S.f1 + 1, -3, "t2");
  node("u", -76, S.f1 + 1, -2); node("u", -50, S.f1 + 1, 2);
  /* --- H3 東の 晶洞 --- */
  { const b = hallBox(S, H("H3")); P.fill(b.x1 - 1, b.f + 1, b.z1 - 1, b.x1 - 1, b.top, b.z2 + 1, "amethyst_block", "replace tuff"); P.fill(b.x2 + 1, b.f + 1, b.z1 - 1, b.x2 + 1, b.top, b.z2 + 1, "calcite", "replace tuff"); P.fill(b.x1, b.top, b.z1, b.x2, b.top, b.z2, "amethyst_block", "replace tuff");
    for (let i = 0; i < 6; i++) { const x = b.x1 + 3 + Math.floor(r() * (b.x2 - b.x1 - 6)), z = b.z1 + 3 + Math.floor(r() * (b.z2 - b.z1 - 6)), hh = 3 + Math.floor(r() * 6); P.fill(x, b.f + 1, z, x + 1, b.f + hh, z + 1, "amethyst_block"); P.set(x, b.f + hh + 1, z, "amethyst_cluster"); } }
  chest("u", 70, S.f1 + 1, 34); node("u", 50, S.f1 + 1, 12); node("u", 68, S.f1 + 1, 12); node("u", 52, S.f1 + 1, 32);
  /* --- H4 北の 坑道 --- */
  { const cx = X + 14, cz = Z - 66, f = S.f1; for (const dz of [-8, 0, 8]) { P.fill(cx - 10, f + 1, cz + dz, cx - 10, f + 6, cz + dz, "spruce_log"); P.fill(cx + 10, f + 1, cz + dz, cx + 10, f + 6, cz + dz, "spruce_log"); P.fill(cx - 10, f + 7, cz + dz, cx + 10, f + 7, cz + dz, "spruce_planks"); } P.fill(cx - 2, f + 1, cz - 11, cx - 2, f + 1, cz + 11, "rail"); }
  node("u", 6, S.f1 + 1, -76); node("u", 22, S.f1 + 1, -56); R.e.push(["c.e2", X + 14, S.f1 + 1, Z - 62, "u"]);
  /* --- H5 地底湖 --- */
  wp("u", -58, S.f2 + 1, 52, "地底湖"); chest("u", -38, S.f2 + 2, 58); node("u", -23, S.f2 + 2, 53); node("u", -60, S.f2 + 1, 38); node("u", -14, S.f2 + 1, 70);
  /* --- H6 古代の 遺跡（仕掛け①）--- */
  { const b = hallBox(S, H("H6")), cx = X + 56, cz = Z - 46, f = S.f2;
    P.fill(b.x1 + 3, f, b.z1 + 3, b.x2 - 3, f, b.z2 - 3, "stone_bricks", "replace tuff"); P.fill(cx - 5, f, cz - 5, cx + 5, f, cz + 5, "chiseled_stone_bricks");
    for (const [dx, dz, hh] of [[-16, -14, 15], [-16, 0, 9], [-16, 14, 15], [16, -14, 4], [16, 0, 15], [16, 14, 11]]) P.fill(cx + dx, f + 1, cz + dz, cx + dx + 1, f + hh, cz + dz + 1, hh > 12 ? "stone_bricks" : "cracked_stone_bricks");
    P.fill(cx - 9, f + 1, cz + 16, cx - 2, f + 4, cz + 16, "mossy_stone_bricks"); P.fill(cx + 3, f + 1, cz - 17, cx + 9, f + 3, cz - 17, "cracked_stone_bricks");
    P.fill(cx - 3, f + 1, cz - 3, cx + 3, f + 1, cz + 3, "polished_andesite"); P.fill(cx - 1, f + 2, cz - 1, cx + 1, f + 2, cz + 1, "chiseled_stone_bricks");
    const pts = [[-12, -8], [12, -8], [0, 12]]; for (const [dx, dz] of pts) { P.fill(cx + dx, f + 1, cz + dz, cx + dx, f + 2, cz + dz, "chiseled_stone_bricks"); P.set(cx + dx, f + 3, cz + dz, "amethyst_block"); }
    R.z.push(["c.z1", pts.map(([dx, dz]) => [cx + dx, f + 1, cz + dz]), 60, "u", "古代の 柱"]); }
  wp("u", 56, S.f2 + 1, -30, "古代の 遺跡"); note("u", 52, S.f2 + 1, -46, "t3"); node("u", 70, S.f2 + 1, -62); node("u", 42, S.f2 + 1, -62);
  /* --- H7 光る きのこの 森 --- */
  { const b = hallBox(S, H("H7")), f = S.f2; P.fill(b.x1, f, b.z1, b.x2, f, b.z2, "moss_block");
    for (const [dx, dz, hh] of [[-10, -10, 9], [8, -6, 12], [-6, 9, 7], [10, 10, 10], [0, 0, 6]]) { const x = X - 68 + dx, z = Z - 56 + dz; P.fill(x, f + 1, z, x, f + hh, z, "mushroom_stem"); P.fill(x - 2, f + hh + 1, z - 2, x + 2, f + hh + 1, z + 2, dx % 4 ? "red_mushroom_block" : "brown_mushroom_block"); P.set(x, f + hh, z, "shroomlight"); P.set(x + 1, f + hh, z, "shroomlight"); }
    for (let i = 0; i < 12; i++) P.set(b.x1 + 2 + Math.floor(r() * (b.x2 - b.x1 - 4)), f + 1, b.z1 + 2 + Math.floor(r() * (b.z2 - b.z1 - 4)), `glow_lichen ["multi_face_direction_bits"=1]`); }
  chest("u", -80, S.f2 + 1, -68); note("u", -56, S.f2 + 1, -44, "t5"); node("u", -82, S.f2 + 1, -44); node("u", -54, S.f2 + 1, -70); R.e.push(["c.e3", X - 68, S.f2 + 1, Z - 48, "u"]);
  /* --- H9 結晶の 大広間 --- */
  { const b = hallBox(S, H("H9")), f = S.f3; P.fill(b.x1 + 2, f, b.z1 + 2, b.x2 - 2, f, b.z2 - 2, "calcite");
    for (const [dx, dz, hh] of [[-14, -14, 14], [14, -12, 18], [-12, 12, 10], [14, 14, 16], [-18, 0, 8], [18, 2, 9]]) { const x = X + 6 + dx, z = Z - 4 + dz; P.fill(x - 1, f + 1, z - 1, x + 1, f + hh, z + 1, "amethyst_block"); P.fill(x, f + hh + 1, z, x, f + hh + 3, z, "amethyst_block"); P.set(x, f + hh + 4, z, "amethyst_cluster"); P.set(x + 2, f + 1, z, "budding_amethyst"); } }
  wp("u", 6, S.f3 + 1, -24, "結晶の 大広間"); chest("u", 6, S.f3 + 1, 18, 1); node("u", -10, S.f3 + 1, 8); node("u", 22, S.f3 + 1, -20); R.e.push(["c.e4", X + 6, S.f3 + 1, Z + 6, "u"]);
  /* --- H10 青の 淵 / H11 最深の 祠（仕掛け②）--- */
  node("u", -72, S.f3 + 1, 40);
  { const cx = X + 70, cz = Z + 62, f = S.f3; P.fill(cx - 5, f + 1, cz - 5, cx + 5, f + 1, cz + 5, "polished_deepslate"); P.fill(cx - 2, f + 2, cz - 2, cx + 2, f + 2, cz + 2, "deepslate_tiles");
    for (const [dx, dz] of [[-5, -5], [5, -5], [-5, 5], [5, 5]]) P.fill(cx + dx, f + 2, cz + dz, cx + dx, f + 9, cz + dz, "chiseled_deepslate");
    P.set(cx, f + 3, cz, "crying_obsidian");
    const pts = [[-9, -9], [9, -9], [0, 10]]; for (const [dx, dz] of pts) { P.fill(cx + dx, f + 1, cz + dz, cx + dx, f + 2, cz + dz, "chiseled_deepslate"); P.set(cx + dx, f + 3, cz + dz, "amethyst_block"); }
    R.z.push(["c.z2", pts.map(([dx, dz]) => [cx + dx, f + 1, cz + dz]), 45, "u", "祠の 柱"]); }
  chest("u", 70, S.f3 + 3, 64, 1); note("u", 74, S.f3 + 2, 58, "t4"); node("u", 80, S.f3 + 1, 72);
  /* 結晶・宝箱・手記・ワープ点（最後に 置く）*/
  for (const [, x, y, z] of R.n) P.set(x, y, z, "amethyst_cluster");
  for (const [, x, y, z] of R.c) P.set(x, y, z, "chest");
  for (const [, x, y, z] of R.t) P.set(x, y, z, "lectern");
  for (const [, x, y, z] of R.w) { P.set(x, y, z, "lodestone"); P.set(x, y + 1, z, "end_rod"); P.fill(x - 1, y - 1, z - 1, x + 1, y - 1, z + 1, "polished_deepslate"); }
  /* 野生の 点（広間の 床）*/
  for (const [h, b] of hb) for (const [u, v] of [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]]) R.sp.push([Math.round(b.x1 + (b.x2 - b.x1) * u), b.f + 1, Math.round(b.z1 + (b.z2 - b.z1) * v)]);
  R.box = { x1: X - 100, x2: X + 99, z1: Z - 100, z2: Z + 99, y1: S.f3 - 6, y2: S.f1 + 21, g1: fk(S, 6) - 2, g2: S.G + 12 };
  return { ops: P.o, R };
}
export const TILES = [[-100, -1, -100, -1], [0, 99, -100, -1], [-100, -1, 0, 99], [0, 99, 0, 99]];

/* ---------- 群島（深海の 中心からの ずれ）---------- */
export const SEAF = [
  ["I1", 100, -20, 11, "isle", "灯台の 小島"], ["I2", -100, 30, 16, "cove", "入り江の 島"], ["I3", 20, 110, 12, "rock", "岩の 小島"], ["I4", -60, -106, 13, "twin", "双子島"],
  ["B0", 0, -72, 4, "buoy", "海溝の 浮標"], ["R1", 70, 80, 18, "reef"], ["R2", -112, -40, 14, "reef"], ["U1", 80, -100, 20, "ruin", "沈んだ 遺跡"],
  ["F1", 130, 40, 8, "wreck"], ["F2", -128, 90, 8, "wreck"], ["F3", -10, -128, 8, "wreck"],
];
function islet(P, x, z, r, W, top = "grass_block") {
  disc(P, x, z, r + 4, W - 20, W - 6, "stone", "replace water"); disc(P, x, z, r + 2, W - 5, W - 1, "sand", "replace water");
  disc(P, x, z, r, W, W + 1, "sand"); disc(P, x, z, r - 3, W + 2, W + 2, top); disc(P, x, z, r - 3, W + 3, W + 8, "air");
}
function palm(P, x, y, z) { P.fill(x, y, z, x, y + 5, z, "jungle_log"); P.fill(x - 2, y + 6, z, x + 2, y + 6, z, "jungle_leaves"); P.fill(x, y + 6, z - 2, x, y + 6, z + 2, "jungle_leaves"); P.set(x, y + 7, z, "jungle_leaves"); }
function wreckHull(P, x, z, W, ax) {   /* 半分 沈んだ 小さな 船（甲板 W+1）*/
  const f = (a1, y1, b1, a2, y2, b2, b, m) => (ax ? P.fill(x + a1, y1, z + b1, x + a2, y2, z + b2, b, m) : P.fill(x + b1, y1, z + a1, x + b2, y2, z + a2, b, m));
  f(-7, W - 3, -2, 7, W - 3, 2, "dark_oak_planks"); f(-7, W - 2, -3, 7, W + 1, 3, "spruce_planks"); f(-6, W - 2, -2, 6, W + 1, 2, "water"); f(-5, W + 1, -2, 5, W + 1, 2, "spruce_planks");
  f(-7, W + 2, -3, 7, W + 2, 3, "dark_oak_fence"); f(-6, W + 2, -2, 6, W + 2, 2, "air"); f(0, W + 2, 0, 0, W + 8, 0, "spruce_log"); f(1, W + 5, -3, 1, W + 7, -1, "white_wool"); f(6, W - 2, -3, 7, W + 2, 3, "water");
}
/* 群島の 置き方: 場所ごとに 決まった ずれから 少しずつ 回して、町・城・ステージ・深海の 建物・ほかの 島に かからない 所を 1回だけ 決める */
export function seaOff(S, F) { const q = S.pos && S.pos[F[0]]; return q ? q : [F[1], F[2]]; }
const seaOk = (O, F, a, b, placed) => { const r = F[3]; if (Math.max(Math.abs(a), Math.abs(b)) + r > 148) return false; if (F[4] !== "buoy" && Math.max(Math.abs(a), Math.abs(b)) - r - 4 < 62) return false;
  if (placed.some(([pa, pb, pr]) => Math.hypot(pa - a, pb - b) < pr + r + 10)) return false; return O.every(([ox, oz, rr]) => Math.hypot(ox - a, oz - b) - rr - r - 6 >= 20); };
export function seaFit(S) {
  const O = obstacles(false).map(([x, z, r]) => [x - S.x, z - S.z, r]), placed = [], pos = {};
  for (const F of SEAF) {
    const a0 = Math.atan2(F[2], F[1]), d0 = Math.hypot(F[1], F[2]); let got = null;
    for (const da of [0, 25, -25, 50, -50, 75, -75, 100, -100, 140, -140, 180]) { for (const dk of [1, 0.85, 1.12, 0.75]) { const a = Math.round(Math.cos(a0 + (da * Math.PI) / 180) * d0 * dk), b = Math.round(Math.sin(a0 + (da * Math.PI) / 180) * d0 * dk); if (seaOk(O, F, a, b, placed)) { got = [a, b]; break; } } if (got) break; }
    pos[F[0]] = got; if (got) placed.push([got[0], got[1], F[3]]);
  }
  return pos;
}
/* 1つの 場所の 下書き。fl(x,z) = 海の 底。もどり: ops と 記録 */
export function planSea(S, F, W, fl) {
  const [id, , , r0, kind] = F, [dx, dz] = seaOff(S, F), x = S.x + dx, z = S.z + dz, P = new LP(), rr = rng(Math.abs((S.x + dx) * 92821 ^ (S.z + dz) * 68917));
  const R = { w: [], n: [], c: [], t: [], z: [], e: [], sp: [] };
  let nN = 0, nC = 0; const node = (a, y, b) => { R.n.push([`s.${id}n${++nN}`, a, y, b, "s"]); }, chest = (a, y, b, rare = 0) => { R.c.push([`s.${id}c${++nC}`, a, y, b, "s", rare]); };
  const wp = (a, y, b) => R.w.push([`s.${id}w`, a, y, b, "s", F[5]]), note = (a, y, b, t) => R.t.push([`s.${id}t`, a, y, b, "s", t]);
  if (kind === "isle") {
    islet(P, x, z, r0, W); const y = W + 3;
    P.fill(x - 2, y, z - 2, x + 2, y + 15, z + 2, "quartz_block"); for (let k = 0; k < 4; k++) P.fill(x - 2, y + 2 + k * 4, z - 2, x + 2, y + 3 + k * 4, z + 2, "red_terracotta");
    P.fill(x - 1, y, z - 1, x + 1, y + 15, z + 1, "air"); P.fill(x, y, z, x, y + 15, z, "scaffolding"); P.fill(x - 1, y, z - 2, x - 1, y + 1, z - 2, "air");
    P.fill(x - 3, y + 16, z - 3, x + 3, y + 16, z + 3, "quartz_block"); P.fill(x - 3, y + 17, z - 3, x + 3, y + 17, z + 3, "iron_bars", ""); P.fill(x - 2, y + 17, z - 2, x + 2, y + 17, z + 2, "air");
    for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) P.fill(x + a, y + 17, z + b, x + a, y + 18, z + b, "quartz_pillar"); P.fill(x - 2, y + 19, z - 2, x + 2, y + 19, z + 2, "quartz_block"); P.set(x, y + 19, z, "sea_lantern"); P.set(x, y + 20, z, "red_concrete"); P.set(x, y + 16, z, "scaffolding");
    chest(x + 2, y + 17, z, 1); note(x + 4, y, z - 4, "s1"); wp(x - 4, y, z + 4);
    for (const [a, b] of [[5, 3], [-5, -2], [2, -6], [-3, 6]]) node(x + a, y, z + b);
    const buoys = [[x + 24, z], [x - 20, z + 14], [x + 4, z - 24]]; for (const [a, b] of buoys) { P.set(a, W, b, "sea_lantern"); P.set(a, W + 1, b, "oak_fence"); }
    R.z.push([`s.${id}z`, buoys.map(([a, b]) => [a, W + 1, b]), 120, "s", "灯の 浮標"]);
    R.e.push([`s.${id}e`, x + 5, y, z - 5, "s"]); R.sp.push([x - 5, y, z]);
  } else if (kind === "cove") {
    islet(P, x, z, r0, W); disc(P, x + 9, z, 9, W - 4, W + 8, "air"); disc(P, x + 9, z, 9, W - 4, W, "water");   /* 東に ひらく 入り江 */
    const y = W + 3; disc(P, x - 6, z, 6, y, y + 4, "stone"); P.fill(x - 19, W + 1, z - 1, x - 2, W + 3, z + 1, "air"); P.fill(x - 19, W - 1, z - 1, x - 2, W, z + 1, "water"); P.fill(x - 8, W, z + 1, x - 5, W, z + 1, "stone");   /* 海蝕洞（西の 海から）*/
    P.set(x - 7, W + 4, z, "sea_lantern"); chest(x - 7, W + 1, z + 1);
    palm(P, x - 2, y, z - 8); palm(P, x - 1, y, z + 9); wp(x - 4, y, z - 10); note(x + 1, W + 2, z + 12, "s3");
    for (const [a, b] of [[-10, -6], [2, 12], [-9, 7]]) node(x + a, y, z + b);
    R.e.push([`s.${id}e`, x + 1, y, z - 6, "s"]); R.sp.push([x - 4, y, z - 4]);
  } else if (kind === "rock") {
    disc(P, x, z, r0 + 4, W - 20, W - 1, "stone", "replace water"); disc(P, x, z, r0, W, W + 6, "stone"); disc(P, x, z, r0 - 4, W + 7, W + 10, "stone"); P.fill(x - 3, W + 11, z - 2, x + 1, W + 12, z + 2, "stone");
    disc(P, x, z, r0 - 4, W + 10, W + 10, "grass_block", "replace stone");
    P.fill(x - r0 - 1, W + 1, z - 1, x + 2, W + 3, z + 1, "air"); P.fill(x - r0 - 1, W - 1, z - 1, x + 2, W, z + 1, "water"); P.fill(x - 1, W + 1, z - 3, x + 2, W + 4, z + 3, "air"); P.set(x + 1, W + 5, z, "sea_lantern"); chest(x + 2, W + 1, z + 2);
    wp(x - 2, W + 11, z + 3); for (const [a, b] of [[3, -3], [-4, 2], [0, 6]]) node(x + a, W + 11, z + b);
    R.e.push([`s.${id}e`, x + 2, W + 11, z - 2, "s"]); R.sp.push([x - 3, W + 11, z - 3]);
  } else if (kind === "twin") {
    islet(P, x - 10, z + 6, 7, W, "sand"); islet(P, x + 10, z - 6, 7, W, "sand"); palm(P, x - 10, W + 3, z + 6);
    wp(x + 10, W + 3, z - 8); node(x - 12, W + 3, z + 3); node(x + 12, W + 3, z - 4); node(x - 8, W + 3, z + 8);
  } else if (kind === "buoy") {
    P.fill(x - 3, W, z - 3, x + 3, W, z + 3, "spruce_planks"); P.fill(x - 3, W + 1, z - 3, x + 3, W + 1, z + 3, "spruce_fence"); P.fill(x - 2, W + 1, z - 2, x + 2, W + 1, z + 2, "air"); P.fill(x - 3, W + 1, z, x - 3, W + 1, z, "air");
    P.fill(x - 2, W - 3, z - 2, x - 2, W - 1, z - 2, "spruce_log"); P.fill(x + 2, W - 3, z + 2, x + 2, W - 1, z + 2, "spruce_log"); wp(x, W + 1, z);
  } else if (kind === "reef") {
    const CO = ["brain_coral_block", "tube_coral_block", "fire_coral_block", "horn_coral_block", "bubble_coral_block"];
    for (let k = 0; k < 26; k++) { const a = rr() * Math.PI * 2, d = rr() * r0, a2 = Math.round(x + Math.cos(a) * d), b2 = Math.round(z + Math.sin(a) * d), f = fl(a2, b2); if (f === null || f > W - 3) continue; const hh = 1 + Math.floor(rr() * 3); P.fill(a2, f + 1, b2, a2, Math.min(W - 2, f + hh), b2, CO[k % 5]); if (k % 3 === 0) P.set(a2 + 1, f + 1, b2, "sea_pickle"); if (k % 6 === 1 && nN < 2) node(a2, Math.min(W - 2, f + hh) + 1, b2); }
  } else if (kind === "ruin") {
    for (let k = 0; k < 9; k++) { const a = (k / 9) * Math.PI * 2, d = 8 + (k % 3) * 4, a2 = Math.round(x + Math.cos(a) * d), b2 = Math.round(z + Math.sin(a) * d), f = fl(a2, b2); if (f === null || f > W - 4) continue; const hh = 3 + Math.floor(rr() * 9); P.fill(a2, f + 1, b2, a2 + 1, Math.min(W - 3, f + hh), b2 + 1, k % 2 ? "prismarine_bricks" : "mossy_stone_bricks"); }
    const f0 = fl(x, z); if (f0 !== null && f0 <= W - 5) { P.fill(x - 4, f0, z - 4, x + 4, f0, z + 4, "prismarine_bricks"); P.fill(x - 4, f0 + 1, z + 4, x + 4, Math.min(W - 3, f0 + 4), z + 4, "cracked_stone_bricks"); P.fill(x - 1, f0 + 1, z + 4, x + 1, Math.min(W - 3, f0 + 3), z + 4, "water"); chest(x, f0 + 1, z, 1); note(x + 2, f0 + 1, z - 2, "s2"); P.set(x - 2, f0 + 1, z - 2, "sea_lantern"); node(x + 3, f0 + 1, z + 2); }
  } else if (kind === "wreck") {
    const ax = Math.abs(dx) > Math.abs(dz); wreckHull(P, x, z, W, ax); chest(x + (ax ? -3 : 0), W + 2, z + (ax ? 0 : -3));
  }
  for (const [, a, y, b] of R.n) P.set(a, y, b, "amethyst_cluster");
  for (const [, a, y, b] of R.c) P.set(a, y, b, "chest");
  for (const [, a, y, b] of R.t) P.set(a, y, b, "lectern");
  for (const [, a, y, b] of R.w) { P.set(a, y, b, "lodestone"); P.set(a, y + 1, b, "end_rod"); }
  return { ops: P.o, R, box: { x1: x - r0 - 6, x2: x + r0 + 6, z1: z - r0 - 6, z2: z + r0 + 6 } };
}

/* ---------- 記録 ---------- */
const MEM = {};
function siteOf(k) { if (!(k in MEM)) { try { MEM[k] = JSON.parse(world.getDynamicProperty(k) || "null"); } catch { MEM[k] = null; } } return MEM[k]; }
function setSiteOf(k, v) { MEM[k] = v; try { world.setDynamicProperty(k, v ? JSON.stringify(v) : undefined); } catch {} REG = null; }
export const siteC = () => siteOf(KC), siteS = () => siteOf(KS);
const sp = () => { try { const s = world.getDefaultSpawnLocation(); return { x: s.x, z: s.z }; } catch { return { x: 0, z: 0 }; } };
export function obstacles(withSea = true) {
  const o = [];
  for (const t of TOWNS) { try { const q = townPos(t); o.push([q.x, q.z, 55]); } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) {
    try { const c = castleInfo(i) || castleSpot(i); if (c) o.push([c.x, c.z, 85]); } catch {}
    try { for (const L of landSites(i)) o.push([L.x, L.z, 45]); } catch {}
  }
  for (const i of CAVE_R) { try { const b = caveBox(i); o.push([(b.x1 + b.x2) / 2, (b.z1 + b.z2) / 2, Math.hypot(b.x2 - b.x1, b.z2 - b.z1) / 2 + 12]); } catch {} }
  if (withSea) try { const d = __ds.site(); if (d && d.x !== undefined) o.push([d.x, d.z, 160]); } catch {}
  return o;
}
let CANDS = null;
export function candsC() {
  if (CANDS && LAYOUT.ok) return CANDS;
  const R = WREGIONS.find((r) => r.id === "crys"), s = sp(), cx = s.x + R.c[0], cz = s.z + R.c[1];
  const a0 = R.c[0] || R.c[1] ? Math.atan2(R.c[1], R.c[0]) : Math.PI, O = obstacles(), out = [];
  for (let dist = R.r + 40; dist <= R.r + 460 && out.length < 8; dist += 30) for (const dg of [0, 20, -20, 40, -40, 60, -60, 90, -90, 120, -120]) {
    const a = a0 + (dg * Math.PI) / 180, x = Math.round(cx + Math.cos(a) * dist), z = Math.round(cz + Math.sin(a) * dist);
    if (out.length < 8 && O.every(([ox, oz, r]) => Math.hypot(ox - x, oz - z) - r >= 90) && out.every((q) => Math.hypot(q.x - x, q.z - z) >= 120)) out.push({ x, z });
  }
  CANDS = out; return out;
}
/* 記録（ワープ点など）を 1つに まとめる */
let REG = null;
export function reg() {
  if (REG) return REG;
  const out = { w: [], n: [], c: [], t: [], z: [], e: [], sp: [], cbox: null, sbox: null, isles: [] };
  const C = siteC(); if (C && C.reg && C.built) { for (const k of ["w", "n", "c", "t", "z", "e", "sp"]) out[k].push(...C.reg[k]); out.cbox = C.reg.box; }
  const S = siteS(); if (S && S.reg) { for (const k of ["w", "n", "c", "t", "z", "e", "sp"]) out[k].push(...(S.reg[k] || [])); out.sbox = { x1: S.x - 150, x2: S.x + 150, z1: S.z - 150, z2: S.z + 150 }; }
  out.at = new Map(); for (const k of ["n", "c", "t", "w"]) for (const a of out[k]) out.at.set(`${a[1]}|${a[2]}|${a[3]}`, [k, a]);
  REG = out; return out;
}
export const totals = () => { const C = siteC(); return C && C.reg ? C.reg : null; };

/* ---------- 建てる ---------- */
let BLD = false, FAILT = 0;
const nearAny = (pl, q, r) => pl.some((p) => Math.hypot(p.location.x - q.x, p.location.z - q.z) < r);
function scanThen(c, r, cb) { enqueue(OW(), [], () => cb(true), [{ x: c.x - r, y: 40, z: c.z - r }, { x: c.x + r, y: 70, z: c.z + r }], () => cb(false)); }
function runTile(S) {
  const t = TILES[S.tile]; if (!t) return;
  const { ops } = planChasm(S), box = { x1: S.x + t[0], x2: S.x + t[1], z1: S.z + t[2], z2: S.z + t[3] }, cmds = cmdsOf(ops, box);
  BLD = true;
  enqueue(OW(), cmds, () => {
    BLD = false; const v = { ...siteC(), tile: S.tile + 1 }; if (v.tile >= TILES.length) v.built = true; setSiteOf(KC, v);
    if (v.built) { for (const q of world.getAllPlayers()) if (Math.hypot(q.location.x - S.x, q.location.z - S.z) < 200) try { q.sendMessage("§d地の 底から、水晶の 鳴る 音が した……§7（クリスタリアの 外れに 大きな 穴が ある。ガイドブック → 探索手帳 →「層の 地図」）"); } catch {} }
    else runTile(v);
  }, [{ x: box.x1, y: S.f3 - 6, z: box.z1 }, { x: box.x2, y: S.G + 12, z: box.z2 }], () => { BLD = false; FAILT = Date.now() + 300000; }, 8);
}
export function tryChasm(plist) {
  if (BLD || building() || warming() || heavy() >= 2 || Date.now() < FAILT) return;
  const S0 = siteC(); if (S0 && (S0.built || S0.none)) return;
  if (S0 && S0.G !== undefined) { if (nearAny(plist, S0, 120) || (S0.tile > 0 && nearAny(plist, S0, 400))) runTile(S0); return; }
  const L = candsC(), ci = S0 ? S0.ci || 0 : 0, c = L[ci];
  if (!c) { setSiteOf(KC, { v: LM_V, none: true }); return; }
  if (!nearAny(plist, c, 200)) return;
  BLD = true;
  scanThen(c, 60, (loaded) => {
    BLD = false; if (!loaded) { FAILT = Date.now() + 300000; return; }
    const J = judgeLand(OW(), c, ci < 4 ? 16 : 30);   /* 平らな 所が なければ 少し 険しくても よい */
    if (!J || J.bad) { if (J) setSiteOf(KC, { v: LM_V, ci: ci + 1 }); else FAILT = Date.now() + 60000; return; }
    const S = { v: LM_V, ci, x: c.x, z: c.z, ...J, tile: 0, built: false }; S.reg = planChasm(S).R; setSiteOf(KC, S);
  });
}
/* 海: 深海が できてから。場所ごとに 読みこみ → 海か 調べる → 建てる */
function waterCol(dim, x, z) {
  for (let y = 80; y > 40; y--) { let b; try { b = dim.getBlock({ x, y, z }); } catch { return null; } if (!b) return null; if (b.isAir) continue; if (!/water/.test(b.typeId) || y < 57 || y > 64) return { bad: 1 }; const f = floorAt(dim, x, z, y); return f !== null && f <= y - 3 ? { W: y, f } : { bad: 1 }; }
  return { bad: 1 };
}
export function trySea(plist) {
  if (BLD || building() || warming() || heavy() >= 2 || Date.now() < FAILT) return;
  const D = __ds.site(); if (!D || !D.built) return;
  let S = siteS(); if (S && S.built) return;
  if (!S) { S = { v: LM_V, x: D.x, z: D.z, k: 0, ok: [], reg: { w: [], n: [], c: [], t: [], z: [], e: [], sp: [] }, isl: [] }; S.pos = seaFit(S); setSiteOf(KS, S); }
  if (!nearAny(plist, S, 160) && !(S.k > 0 && nearAny(plist, S, 400))) return;
  const F = SEAF[S.k]; if (!F) { setSiteOf(KS, { ...S, built: true }); return; }
  const [ox0, oz0] = seaOff(S, F), c = { x: S.x + ox0, z: S.z + oz0 }, rr = F[3] + 6;
  if (!S.pos || !S.pos[F[0]]) { const v = { ...S, k: S.k + 1 }; if (v.k >= SEAF.length) v.built = true; setSiteOf(KS, v); return; }   /* 町・城・ステージに 近い 所は とばす */
  BLD = true;
  enqueue(OW(), [], () => {
    const dim = OW(), pts = [[0, 0], [rr - 6, 0], [-(rr - 6), 0], [0, rr - 6], [0, -(rr - 6)]].map(([a, b]) => waterCol(dim, c.x + a, c.z + b));
    if (pts.some((q) => q === null)) { BLD = false; FAILT = Date.now() + 60000; return; }
    const next = (built, R) => { const v = { ...siteS(), k: S.k + 1 }; if (built) { v.ok = [...v.ok, F[0]]; for (const kk in R) v.reg[kk] = [...(v.reg[kk] || []), ...R[kk]]; if (["isle", "cove", "rock", "twin"].includes(F[4])) v.isl = [...(v.isl || []), [c.x, c.z, F[3] + 2]]; } if (v.k >= SEAF.length) v.built = true; setSiteOf(KS, v); };
    if (pts.some((q) => q.bad)) { BLD = false; next(false); return; }
    const W = pts[0].W, P = planSea(S, F, W, (x, z) => floorAt(dim, x, z, W));
    enqueue(dim, cmdsOf(P.ops), () => { BLD = false; next(true, P.R); }, [{ x: P.box.x1, y: W - 22, z: P.box.z1 }, { x: P.box.x2, y: W + 22, z: P.box.z2 }], () => { BLD = false; FAILT = Date.now() + 300000; }, 8);
  }, [{ x: c.x - rr, y: 50, z: c.z - rr }, { x: c.x + rr, y: 70, z: c.z + rr }], () => { BLD = false; FAILT = Date.now() + 300000; });
}

/* ---------- プレイヤーの 記録（1人ずつ）---------- */
export function pOf(p) { try { const v = JSON.parse(p.getDynamicProperty(PK) || "null"); if (v && typeof v === "object") return { w: v.w || [], n: v.n || [], c: v.c || [], t: v.t || [], z: v.z || [] }; } catch {} return { w: [], n: [], c: [], t: [], z: [] }; }
function pSave(p, v) { try { p.setDynamicProperty(PK, JSON.stringify(v)); return true; } catch { return false; } }
const NOTE = {
  t1: ["鉱夫の 日誌", "§f七段目を 掘った 日、底が 抜けた。下に 青く 光る 空洞が ある。\n§fロープを ふやせ。あと、口の 下の 水たまりは 深いから、落ちても 平気だ……たぶん"],
  t2: ["基地の 掲示", "§f・地底湖の 水は 飲める\n§f・紫の 塔の 広間（いちばん 下）には 一人で 行くな。大きな 結晶食いが いる\n§f・欠片は 野営地の 鉱夫が 道具と かえて くれる（探索手帳の 交換）"],
  t3: ["古い 石板", "§f晶の 民は 歌で 石を 育てた。\n§f三つの 柱に 続けて ふれよ。眠る 歌が 目を さます"],
  t4: ["祠の 文字", "§fここは 大地の 心臓に いちばん 近い 所。\n§f水晶は 大地の 記憶。欠片を 持ち帰る 者は、記憶の 番人と なる"],
  t5: ["走り書き", "§fきのこの 森の 光は 夜でも 消えない。\n§f迷ったら 光の 多い ほうへ。縦穴の 足場は しゃがめば ゆっくり 降りられる"],
  s1: ["灯台守の 記録", "§f三つの 浮標の 灯に、灯が 消えないうちに 続けて ふれる こと。\n§f先代は そう 言って、灯台の 上の 箱の 鍵を 海へ 投げた"],
  s2: ["沈んだ 石碑", "§f海の 底の 町も、晶の 民と 同じ 歌を 知って いた。\n§f歌は 潮に のって、大坑の 底まで 届いた という"],
  s3: ["流れ着いた 手紙", "§f入り江の 洞に 宝を 隠した。潮が 引いても 見えない 奥の 奥に。\n§f……拾った 人へ。大事に 使って くれ"],
};
function collectNode(p, a) {
  const v = pOf(p); if (v.n.includes(a[0])) { try { barNote(p).setActionBar("§7この 結晶は もう 取った（1人 1回）"); } catch {} return false; }
  v.n.push(a[0]); if (!pSave(p, v)) return false;
  giveItem(p, `mrpg:${SHARD}`, 1); sound(p, "block.amethyst_cluster.break", 1.2); sound(p, "random.orb", 1.4);
  const T = mapCount(p, a[4]); try { barNote(p).setActionBar(`§d水晶の 欠片 +1 §7（${T.nm}の 結晶 ${T.n[0]}/${T.n[1]}）`); } catch {}
  return true;
}
function openChest(p, a) {
  const v = pOf(p); if (v.c.includes(a[0])) { try { p.sendMessage("§7この 宝箱は もう 開けた §8（中身は 1人 1回）"); } catch {} sound(p, "random.chestclosed", 1, 0.5); return false; }
  const d = load(p); if (!d) return false;
  v.c.push(a[0]); if (!pSave(p, v)) return false;
  const rare = !!a[5], got = []; for (let n = 0; n < (rare ? 2 : 1); n++) try { got.push(boon(p, d, rare ? 2 : 1)); } catch {}
  let lv = 40; try { lv = regionLv({ x: a[1], z: a[3] }); } catch {}
  const g = Math.max(200, Math.round(lv * (rare ? 120 : 50))); d.gold = (d.gold || 0) + g; save(p, d);
  giveItem(p, `mrpg:${SHARD}`, rare ? 3 : 2); got.push(`§d水晶の 欠片 ×${rare ? 3 : 2}`);
  sound(p, rare ? "random.levelup" : "random.chestopen", 1, 0.8);
  try { p.sendMessage(`${rare ? "§6§l大きな 宝箱！ " : "§e宝箱を 開けた！ "}§r${got.join("§7、")}§7、${gold(g)}`); } catch {}
  return { got, g };
}
async function readNote(p, a) {
  const v = pOf(p), N = NOTE[a[5]] || ["手記", ""]; if (!v.t.includes(a[0])) { v.t.push(a[0]); pSave(p, v); }
  if (busy.has(p.id)) return; busy.add(p.id); try { await notice(p, N[0], N[1]); } finally { busy.delete(p.id); }
}
function unlockWp(p, a) {
  const v = pOf(p); if (v.w.includes(a[0])) return false; v.w.push(a[0]); if (!pSave(p, v)) return false;
  sound(p, "beacon.activate", 1.2); try { showTitle(p, `§bワープ点「${a[5]}」`, { subtitle: "§7ガイドブック → 探索手帳 →「層の 地図」から ここへ ワープ できる", fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  return true;
}
/* 仕掛け: 柱に 続けて ふれる（時間内）。1人ずつ */
const PZ = new Map();
function touchSwitch(p, z, i) {
  const v = pOf(p); if (v.z.includes(z[0])) return null;
  const now = Date.now(); let st = PZ.get(p.id);
  if (!st || st.id !== z[0] || now > st.t0 + z[2] * 1000) st = { id: z[0], t0: now, got: new Set() };
  if (st.got.has(i)) { PZ.set(p.id, st); return st; }
  st.got.add(i); PZ.set(p.id, st); sound(p, "block.amethyst_block.chime", 0.8 + st.got.size * 0.2, 1);
  try { p.dimension.spawnParticle("minecraft:totem_particle", { x: z[1][i][0] + 0.5, y: z[1][i][1] + 3, z: z[1][i][2] + 0.5 }); } catch {}
  if (st.got.size >= z[1].length) {
    PZ.delete(p.id); v.z.push(z[0]); pSave(p, v);
    const d = load(p); const got = []; if (d) { try { got.push(boon(p, d, 2)); } catch {} save(p, d); }
    giveItem(p, `mrpg:${SHARD}`, 5); got.push("§d水晶の 欠片 ×5"); sound(p, "random.levelup", 1);
    try { showTitle(p, `§d§l${z[4]}が 歌った`, { subtitle: "§f仕掛けを といた！", fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10 }); p.sendMessage(`§d§l仕掛けを といた！ §rもらった: ${got.join("§7、")}`); } catch {}
    return "done";
  }
  try { barNote(p).setActionBar(`§d${z[4]} ${st.got.size}/${z[1].length} §7（のこり ${Math.max(0, Math.ceil((st.t0 + z[2] * 1000 - now) / 1000))}秒）`); } catch {}
  return st;
}

/* ---------- 精鋭（決まった 場所・10分で また 出る）と 地下の 野生 ---------- */
const ELV = new Map(), NEXT = new Map(), WILD = new Set();
const crysR = () => WREGIONS.find((r) => r.id === "crys");
function eliteTick(all) {
  const G = reg(); if (!G.e.length) return;
  const now = Date.now();
  for (const [id, x, y, z, lay] of G.e) {
    const e = ELV.get(id), alive = e && ok(e);
    const P = all.filter((p) => Math.hypot(p.location.x - x, p.location.z - z) < 64 && Math.abs(p.location.y - y) < 24);
    if (alive) { if (!P.length) { let fighting = false; try { fighting = e.hasTag("mrpg_battle"); } catch {} if (!fighting) { try { e.remove(); } catch {} ELV.delete(id); NEXT.set(id, 0); } } continue; }
    if (e) ELV.delete(id);
    if (now < (NEXT.get(id) || 0)) continue;
    const q = P.find((p) => Math.hypot(p.location.x - x, p.location.z - z) < 32 && !busy.has(p.id)); if (!q) continue;
    let lv = 50; try { lv = Math.min(100, regionLv({ x, z }) + 8); } catch {}
    const sid = pickWild(lay === "s" ? "ocean" : "cave", lv, lay === "s" ? null : crysR());
    const ne = spawnBoss(q, sid, lv, "mrpg_lme", "精鋭", { x, y, z });
    if (ne) { try { ne.addTag(`mrpg_lme_${id.replace(/\./g, "_")}`); } catch {} ELV.set(id, ne); NEXT.set(id, now + LMW.resp); }
  }
}
export const inUnder = (l) => { const b = reg().cbox; return !!b && l.x >= b.x1 && l.x <= b.x2 && l.z >= b.z1 && l.z <= b.z2 && l.y >= b.y1 && l.y <= b.y2; };
export const wildCap = (n = world.getAllPlayers().length) => Math.max(1, (isLite() ? 1 : LMW.cap[heavy()] ?? 1) - (n >= 3 ? 1 : 0));
function wildTick(all) {
  for (const e of [...WILD]) if (!ok(e)) WILD.delete(e);
  const G = reg(); if (!G.cbox || !G.sp.length) return;
  const P = all.filter((p) => inUnder(p.location) && !busy.has(p.id)); if (!P.length) return;
  if (WILD.size >= wildCap(all.length)) return;
  const pts = G.sp.filter((q) => inUnder({ x: q[0], y: q[1], z: q[2] }) && P.every((p) => Math.hypot(p.location.x - q[0], p.location.z - q[2]) >= 10) && P.some((p) => Math.hypot(p.location.x - q[0], p.location.z - q[2]) <= 44 && Math.abs(p.location.y - q[1]) < 12));
  if (!pts.length) return;
  const q = pts[Math.floor(Math.random() * pts.length)];
  try { const d = OW(), b0 = d.getBlock({ x: q[0], y: q[1], z: q[2] }), b1 = d.getBlock({ x: q[0], y: q[1] + 1, z: q[2] }); if (!b0 || !b1 || !b0.isAir || !b1.isAir) return; } catch { return; }
  try { const e = OW().spawnEntity(TYPE, { x: q[0] + 0.5, y: q[1], z: q[2] + 0.5 }); e.addTag("mrpg_lmw"); try { initWild(e); } catch {} WILD.add(e); } catch {}
}
function wildClean(all) {
  for (const e of [...WILD]) { if (!ok(e)) { WILD.delete(e); continue; } let fighting = false; try { fighting = e.hasTag("mrpg_battle") || e.hasTag("mrpg_pet"); } catch {} if (fighting) continue; const l = e.location; if (!all.some((p) => Math.hypot(p.location.x - l.x, p.location.z - l.z) < 64)) { try { e.remove(); } catch {} WILD.delete(e); } }
}
battleHooks.push((B, x) => {
  const { p } = x; if (B.result !== "win" || !(B.wtags || []).includes("mrpg_lme")) return;
  try { if (!p.isValid()) return; } catch { return; }
  giveItem(p, `mrpg:${SHARD}`, 3); try { p.sendMessage("§d§l精鋭を 倒した！ §r§d水晶の 欠片 ×3 §7（精鋭は しばらくすると また 現れる）"); } catch {}
});

/* ---------- 見回り ---------- */
const WARN = new Set();
function near(p, a, r = 2.2, dy = 3) { const l = p.location; return Math.hypot(l.x - (a[1] + 0.5), l.z - (a[3] + 0.5)) <= r && Math.abs(l.y - a[2]) <= dy; }
const inBoxXZ = (b, l, m = 0) => !!b && l.x >= b.x1 - m && l.x <= b.x2 + m && l.z >= b.z1 - m && l.z <= b.z2 + m;
let TK = 0;
system.runInterval(() => {
  TK++;
  let all; try { all = world.getAllPlayers(); } catch { return; }
  const ow = all.filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
  if (TK % 2 === 0) { try { if (TK % 4 === 0) tryChasm(ow); else trySea(ow); } catch (x) { console.warn(`[MonsterRPG] lm build: ${x}`); } }
  const G = reg(); if (!G.cbox && !G.sbox) return;
  const inside = ow.filter((p) => inBoxXZ(G.cbox, p.location) || inBoxXZ(G.sbox, p.location));
  for (const p of inside) {
    if (busy.has(p.id)) continue;
    for (const a of G.w) if (near(p, a)) unlockWp(p, a);
    for (const z of G.z) z[1].forEach((q, i) => { if (near(p, [0, q[0], q[1], q[2]], 1.8, 3)) touchSwitch(p, z, i); });
  }
  if (TK % 4 === 0) { try { eliteTick(ow); wildTick(ow); } catch (x) { console.warn(`[MonsterRPG] lm tick: ${x}`); } }
  if (TK % 20 === 0) wildClean(ow);
}, 10);
try {
  world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    try { if (ev.isFirstEvent === false) return; const b = ev.block; if (!b || b.dimension.id !== "minecraft:overworld") return; const hit = reg().at.get(`${b.location.x}|${b.location.y}|${b.location.z}`); if (!hit) return;
      ev.cancel = true; const p = ev.player, [k, a] = hit;
      system.run(() => { try { if (k === "n") collectNode(p, a); else if (k === "c") openChest(p, a); else if (k === "t") readNote(p, a); else if (k === "w") { if (!unlockWp(p, a)) try { barNote(p).setActionBar(`§bワープ点「${a[5]}」§7（探索手帳 →「層の 地図」から ワープ）`); } catch {} } } catch {} }); } catch {}
  });
  world.beforeEvents.playerBreakBlock.subscribe((ev) => {
    try { const b = ev.block; if (!b || b.dimension.id !== "minecraft:overworld") return; const hit = reg().at.get(`${b.location.x}|${b.location.y}|${b.location.z}`); if (!hit) return; ev.cancel = true;
      if (hit[0] === "n") { const p = ev.player; system.run(() => { try { collectNode(p, hit[1]); } catch {} }); } } catch {}
  });
} catch {}
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => { try { if (p.dimension.id === "minecraft:overworld" && inUnder(p.location)) return true; } catch {} return prev ? prev(p) : false; }; });
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { PZ.delete(playerId); WARN.delete(playerId); }); } catch {}

/* ---------- ガイドブック: 層の 地図 ---------- */
export const MAPS = [["g", "地上", "水晶の 大坑", "§d"], ["u", "地下", "晶窟", "§5"], ["s", "海", "外洋の 群島", "§b"]];
export function mapCount(p, lay) {
  const G = reg(), v = pOf(p), f = (L, got) => { const A = L.filter((a) => a[4] === lay); return [A.filter((a) => got.includes(a[0])).length, A.length]; };
  return { nm: (MAPS.find((m) => m[0] === lay) || [])[2] || "", w: f(G.w, v.w), n: f(G.n, v.n), c: f(G.c, v.c), t: f(G.t, v.t), z: f(G.z.map((z) => [z[0], 0, 0, 0, z[3]]), v.z) };
}
/* 文字の 地図（11×11）: Ｗ 開いた ワープ点・？ まだ・＠ 自分 */
export function asciiMap(p, lay) {
  const G = reg(), v = pOf(p), W = G.w.filter((a) => a[4] === lay); if (!W.length) return "";
  const box = lay === "s" ? G.sbox : G.cbox; if (!box) return "";
  const N = 11, cell = (x, z) => [Math.max(0, Math.min(N - 1, Math.floor(((x - box.x1) / (box.x2 - box.x1 + 1)) * N))), Math.max(0, Math.min(N - 1, Math.floor(((z - box.z1) / (box.z2 - box.z1 + 1)) * N)))];
  const g = Array.from({ length: N }, () => Array(N).fill("§8・"));   /* ◆○■ は 画面で ⊠ に なるので 全角の 字だけ */
  if (lay === "s") for (const [x, z] of siteS()?.isl || []) { const [i, j] = cell(x, z); g[j][i] = "§2島"; }
  if (lay === "s") { const S = siteS(); if (S) { const [i, j] = cell(S.x, S.z); g[j][i] = "§1海"; } }
  if (lay === "g") { const C = siteC(); if (C) for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const x = box.x1 + ((i + 0.5) / N) * 200, z = box.z1 + ((j + 0.5) / N) * 200; if (Math.hypot(x - C.x, z - C.z) < 62) g[j][i] = "§7〇"; } }
  for (const a of W) { const [i, j] = cell(a[1], a[3]); g[j][i] = v.w.includes(a[0]) ? "§bＷ" : "§3？"; }
  try { const l = p.location; if (inBoxXZ(box, l)) { const [i, j] = cell(l.x, l.z); g[j][i] = "§e＠"; } } catch {}
  return g.map((r) => r.join("")).join("\n");
}
export async function lmTeleport(p, a) {
  if (busy.has(p.id)) return false; try { if (inBattle(p)) return false; } catch {}
  if (!pOf(p).w.includes(a[0])) return false;
  try { p.teleport({ x: a[1] + 0.5, y: a[2], z: a[3] + 2.5 }, { dimension: OW() }); const pet = findPet(p); if (pet) pet.teleport({ x: a[1] + 1.5, y: a[2], z: a[3] + 2.5 }, { dimension: OW() }); } catch { return false; }
  sound(p, "mob.endermen.portal", 1); return true;
}
export const LMX = [
  { n: "水晶の 欠片 ×5 → 経験の結晶 ×2", need: [[SHARD, 5]], give: ["f_exp1k", 2] },
  { n: "水晶の 欠片 ×8 → 命の雫", need: [[SHARD, 8]], give: ["c_drop", 1] },
  { n: "水晶の 欠片 ×15 → 名匠の槌", need: [[SHARD, 15]], give: ["rf_2", 1] },
  { n: "水晶の 欠片 ×30 → 昇格の砥石", need: [[SHARD, 30]], give: ["rf_4", 1] },
];
for (const x of LMX) EXR.push(x);
async function lmExchange(p, d) {
  for (;;) {
    const k = await choose(p, "欠片の 交換", `§7水晶の 欠片: §d${countItem(p, `mrpg:${SHARD}`)}`, [...LMX.map((x) => [`§l${x.n}`, ICON("i_shop")]), ["§7戻る", ICON("i_back")]]);
    const x = LMX[k]; if (!x) return;
    const it = ITEMS[x.give[0]]; if (!it) continue;
    if (!storyLootOk(it, null, rankCap(load(p) || d))) { await notice(p, "欠片の 交換", "§7物語を もう少し 進めると 交換できる。"); continue; }
    if (countItem(p, `mrpg:${SHARD}`) < x.need[0][1] || !takeItem(p, `mrpg:${SHARD}`, x.need[0][1])) { await notice(p, "欠片の 交換", "§7欠片が たりない。結晶を さがそう。"); continue; }
    giveItem(p, `mrpg:${x.give[0]}`, x.give[1]); sound(p, "random.anvil_use", 1.2);
    await notice(p, "欠片の 交換", `§a${it.name} ×${x.give[1]} を 手に入れた！`);
  }
}
export async function mapPage(p, lay) {
  for (;;) {
    const G = reg(), M = MAPS.find((m) => m[0] === lay), T = mapCount(p, lay), v = pOf(p);
    const C = siteC(), S = siteS(), site = lay === "s" ? S : C;
    let where;
    if (lay === "s") { const D = __ds.site(); where = S ? `§f場所: §bマリノア沖の 深海の まわり§f（X ${S.x}・Z ${S.z}）${S.built ? "" : "\n§7近くの 海へ 行くと 島が できて いく"}` : D && D.x !== undefined ? `§7深海（X ${D.x}・Z ${D.z}）の まわりの 海に ある。まず 深海を 見つけよう` : "§7まず マリノア沖の 深海を 見つけよう（探索手帳 →「深海」）"; }
    else { const c = C && C.x !== undefined ? C : candsC()[(C && C.ci) || 0]; where = c ? `§f場所: §dクリスタリアの 外れ§f（およそ X ${c.x}・Z ${c.z}）${C && C.built ? "" : "\n§7まだ 見つかって いない。近くへ 行くと（120 ブロック）できる"}` : "§7このワールドには 大坑を 作れる 所が なかった"; }
    if (lay === "u" && C && C.G !== undefined) where += `\n§7行き方: 大坑の 底の 口から 下の 湖へ 飛びこむ（足場で 登れる）。層: 上層 Y${C.f1}・中層 Y${C.f2}・深層 Y${C.f3}`;
    const body = [`${M[3]}§l${M[1]}: ${M[2]}`, where, "", asciiMap(p, lay), lay === "s" ? "§bＷ ワープ点 §3？ まだ §2島 §1海 深海 §e＠ 自分" : "§bＷ ワープ点 §3？ まだ §7〇 大坑 §e＠ 自分", "",
      `§bワープ点 §f${T.w[0]}/${T.w[1]}　§d結晶 §f${T.n[0]}/${T.n[1]}　§e宝箱 §f${T.c[0]}/${T.c[1]}`, `§7手記 §f${T.t[0]}/${T.t[1]}　§6仕掛け §f${T.z[0]}/${T.z[1]}　§c精鋭 §f${G.e.filter((e) => e[4] === lay).length}か所 §7（10分で また 出る）`,
      "§7結晶（紫の 小さな 結晶）は 使う／こわすと 水晶の 欠片。宝箱・結晶は 1人 1回。ワープ点（光る 棒の ついた 石）に ふれると ワープ できる"].join("\n");
    const W = G.w.filter((a) => a[4] === lay && v.w.includes(a[0]));
    const k = await choose(p, `層の 地図 ${M[1]}`, body, [...W.map((a) => [`§b§l${a[5]}へ ワープ`, ICON("i_run")]), ["§d欠片の 交換", ICON("i_shop")], ["§7戻る", ICON("i_back")]]);
    if (k < 0 || k > W.length) return;
    if (k === W.length) { await lmExchange(p, load(p)); continue; }
    if (site && (await lmTeleport(p, W[k]))) return true;
  }
}
async function lmMenu(p, d) {
  for (;;) {
    const L = MAPS.map((m) => { const T = mapCount(p, m[0]); return [`${m[3]}§l${m[1]}: ${m[2]}\n§8ワープ ${T.w[0]}/${T.w[1]}・結晶 ${T.n[0]}/${T.n[1]}・宝箱 ${T.c[0]}/${T.c[1]}`, ICON("i_zukan")]; });
    const k = await choose(p, "層の 地図", "§f地上・地下・海の 探検の 地図。§7ワープ点・結晶・宝箱の 数が わかる", [...L, ["§7戻る", ICON("i_back")]]);
    if (k < 0 || k >= MAPS.length) return;
    if (await mapPage(p, MAPS[k][0])) return;
  }
}
XT.menu.push(["§d§l層の 地図\n§8大坑・晶窟・群島・ワープ", lmMenu, "i_zukan"]);

export const __lm = { siteC, siteS, setSiteOf, KC, KS, PK, candsC, judgeLand, planChasm, planSea, cmdsOf, tryChasm, trySea, reg, pOf, collectNode, openChest, unlockWp, touchSwitch, eliteTick, wildTick, wildClean, ELV, NEXT, WILD, PZ, lmTeleport, mapPage, mapCount, asciiMap, lmExchange, reset: () => { for (const k in MEM) delete MEM[k]; REG = null; CANDS = null; BLD = false; FAILT = 0; } };
