/* 第126版 本20「歴史再び」（王冠の 間・錠の 座）— ゼファード【本編の 最終章】— 作業 ME
   章題「歴史再び」の 意味: 千年前、アルディスは 王を 斬って 錠に した。同じ 形の 場面（影に 呑まれた 者を 前に、刃を 持つ 友）が もう一度 めぐって くる。
   歴史が くり返されかけ、主人公は 斬らずに 名を 呼んで、くり返しを 断つ。章題は 前半では「くり返す」と 読め、終わりで「くり返さない」と 読み替わる。
   分かる: ゼファードは 錠の 座に 二十年 座る 六影の 首領で、二十年前の 星の 冠の 男で、ナギサと マリンの 父。灰の 冬は 彼の 一度の 願い。沈んだ 神殿の 石の 女は ミナモ。命令書は セオが 書いた 偽物。
   問い: 抜けた 幼なじみの 魂を、呼び戻せるのか（→裏15 qb201）。セオは どこへ 消えたのか（→裏14 qb202）
   引きとった もの: cupScene「zeph0／zeph1」（星冠王＝闘技場を 開いた 人・杯は ふるい・歓声は 蓋・名は わたしが 削った・六影の 名乗り＝ルビの 名札）、theoFinale（斬らずに 名を 呼ぶ）、
   links.js の それぞれの 町（双子と シロウ・トンボと ヴァルカ）と おっとうの 編み目（紐）→ b20e10。MQ24 = b20e10（s.ending を 立てる。mqOver）
   場所: 王冠の 間（b20crown: 闘技場の 横の 掘り下げた 広間。灰の 床・錠の 座・背の 石板・床の 格子・奥の 壁の 紫の 名前・裂け目・石段）*/
import { world } from "@minecraft/server";
import { bkAdd, mqOver, bkHas } from "./bkeng.js";
import { MQ, EP_HOOK } from "./saga.js";
import { facAt, facFront } from "./epfac.js";
import { placeOf } from "./storyplace.js";
import { ok, showTitle } from "./ui.js";
import { load, save } from "./store.js";
import { qs, giveCrown } from "./quest.js";
import { J, MK, setB, sOf, setS, REI, ORDO, NP, fade, afterAdd, fin, again, face, toP, nearM } from "./bk_b17.js";
import { ARENA } from "./bk_b19.js";
import { at2 } from "./bk_b01.js";

/* ---------- 場所 ---------- */
const RD = () => { const v = J("mrpg:epdeco:b19ringat"), m = v && MK(v, "worn"); if (m) return { x: Math.floor(m.x), z: Math.floor(m.z), nm: "闘技場の 奥の 扉の 下" }; const a = ARENA(); return a ? { ...a, nm: "闘技場の 奥の 扉の 下" } : null; };
const CV = () => J("mrpg:epdeco:b20crownat");
const CRP = (n, nm) => () => { const v = CV(), m = v && MK(v, n); if (m) return { x: Math.floor(m.x), y: Math.floor(m.y), z: Math.floor(m.z), nm, r: 5 }; return RD(); };
const HALL = CRP("front", "王冠の 間"), BACK = CRP("back", "王冠の 奥"), UNDER = CRP("under", "格子の 下");
/* 王冠の 間（掘り下げた 石の 広間。床に 灰。約 330 ブロック ＋ 掘る 空気）*/
const crown = (K, p) => setB(K, p, "b20crown", [
  [0, -6, -6, 14, 6, -1, "air"], [0, -6, -7, 14, 6, -7, "deepslate", "keep"],
  ...[0, 1, 2, 3, 4].map((k) => [k, -6, -7, k, -5, -2 - k, "deepslate_tiles"]),
  [15, -6, -6, 15, 6, -1, "deepslate_bricks"], [3, -7, -6, 3, -7, -1, "polished_deepslate"], [3, 7, -6, 3, 7, -1, "polished_deepslate"], [9, -7, -6, 9, -7, -1, "polished_deepslate"], [9, 7, -6, 9, 7, -1, "polished_deepslate"],
  [3, -6, -3, 3, -6, -3, "soul_lantern"], [9, 6, -3, 9, 6, -3, "soul_lantern"], [3, 6, -3, 3, 6, -3, "soul_lantern"], [9, -6, -3, 9, -6, -3, "soul_lantern"],
  [12, 0, -6, 12, 0, -6, "polished_deepslate_slab"], [12, -1, -6, 12, -1, -5, "polished_deepslate_wall"], [12, 1, -6, 12, 1, -5, "polished_deepslate_wall"], [13, -1, -6, 13, 1, -4, "chiseled_deepslate"],
  [9, -2, -1, 13, 2, -1, "iron_bars"],
  [5, -2, -6, 5, -2, -6, "light_gray_concrete_powder"], [7, 1, -6, 7, 1, -6, "light_gray_concrete_powder"], [10, -3, -6, 10, -3, -6, "light_gray_concrete_powder"], [6, 3, -6, 6, 3, -6, "gray_carpet"], [11, 2, -6, 11, 2, -6, "gray_carpet"], [8, -4, -6, 8, -4, -6, "gray_carpet"], [4, 1, -6, 4, 1, -6, "gray_carpet"], [11, -1, -6, 11, -1, -6, "light_gray_concrete_powder"],
  [15, -5, -5, 15, -3, -3, "purple_glazed_terracotta"], [15, 3, -5, 15, 5, -3, "purple_glazed_terracotta"], [15, -1, -6, 15, 1, -3, "air"], [16, -1, -6, 16, 1, -3, "black_concrete"], [16, 0, -5, 16, 0, -5, "crying_obsidian"]],
  { D: 2, side: 18, look: [12, 0], R: 90, marks: { front: [7, 0, -6], seat: [12, 0, -6], slab: [13, 0, -4], grate: [11, 0, -1], under: [10, -3, -6], back: [13, 3, -6], wall: [14.5, -4, -4], rift: [14.5, 0, -5], stair: [0, -5.5, -1], ash: [6, 0, -6], deep: [12, -1, -5] } });
const into = async (K, p, v, nm = "王冠の 間") => { const q = MK(v, "front"); if (!q) return; if (Math.hypot(q.x - p.location.x, q.z - p.location.z) < 4 && Math.abs(q.y - p.location.y) < 2) return; await K.moveTo(p, q, nm, [], MK(v, "seat"), 6); };
const ZEPH = (K, p, still = true) => NP(K, p, "§c星冠王 ゼファード", "zephard", still);
const seatZ = async (K, p, v) => { const e = await K.put(p, "§c星冠王 ゼファード", nearM(K, p, v, "seat", 5, 0), p.getHeadLocation(), K.PJ("zephard", 8)); K.act(e, "kneel"); return e; };

/* ---------- 町の 人の その後 ---------- */
afterAdd("r6marin", [[(s) => !!s.ending, ["{smile,up}紐、姉さんと 二人で 続きを 編んでるの。……一目ずつ。", "{closed}封を 切ったのは、わたし。……海の 名、おっとうも 同じ ことを 考えてた。"]]]);
afterAdd("r6nagisa", [[(s) => !!s.ending, ["{smile}毎朝 百 数えるのは、もう やめたの。……数えなくても、帰って くる 人が いるって わかったから。"]]]);
afterAdd("r3tombo", [[(s) => !!s.ending, ["{smile,!}ヨネ婆の 木槌で、毎朝 一本 打つッス！ ……村の 名前を、柄に 彫ったッス。"]]]);
afterAdd("r8_shirou", [[(s) => !!s.ending, ["{smile}手袋の 色を 見なくても、声で わかるべさ。……ロウと ルウだべさ。"]]]);

/* ---------- 話 ---------- */
const E1 = { id: "b20e1", t: "灰の 床", place: RD, F: ["F19", "F57"], ans: ["qb181", "qb191"],
  hint: "§f闘技場の §e奥の 扉§f から 下へ §7（右上の 案内）",
  syn: "扉の 下は、王冠の 間だった。床に 灰が 積もり、石の 椅子に 星の 冠の 男が 座って いた。肘かけに 二十年分の 刻み。一本だけ、深く えぐれて いた。",
  async run(p, d, K) {
    const v = crown(K, p);
    await K.open(p, "闘技場の 奥の 扉の 下", "ash");
    if (v) { await K.at(p, MK(v, "stair"), 12, 4, 1); await into(K, p, v); }
    K.mood(p, "shadow");
    const ash = MK(v, "ash") || K.fwd(p, 3, 0, 0.1);
    await K.at(p, ash, 16, 2.6, 0.2);
    await K.narr(p, ["§7石段の 下の 広間。……§e王冠の 間§7。", "§7床一面に、灰が 積もって いる。足を 置くと、音も なく 沈んだ。"], ash);
    const gq = MK(v, "grate"); if (gq) { K.burst(p.dimension, gq, "minecraft:white_smoke_particle", 4, 1, -0.5); await K.at(p, gq, 14, 3, -1.5); }
    await K.narr(p, ["§7天井の 一角に 四角い §f格子§7。すき間から、闘技場の 歓声が 降って くる。……あの 表彰台の 床の 下が、ここ だった。"], gq);   /*F57*/
    const eZ = await seatZ(K, p, v);
    await K.push(p, eZ, 24, 5, 1.6);
    await K.narr(p, ["§7奥の 石の 椅子に、星の 冠の 紋の 外套の 男が 座って いた。"], eZ);
    const dq = MK(v, "deep") || K.fwd(p, 5, -0.6, 0.6);
    await K.at(p, dq, 16, 1.2, 0.2);
    await K.narr(p, ["§7石の 肘かけに、細い §f刻み§7 が びっしり。……数えきれない ほど。", "§7その 中に 一本だけ、深く えぐれた 刻みが あった。"], dq);   /*F19*/
    await K.up(p, eZ, 12);
    await K.say(p, "ゼファード", ["{closed,low}……来たか。"]);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……ほしの におい。……あの 鐘と、おなじ ひとの におい。"]); K.rmCine(g); }
    await K.say(p, "ゼファード", ["{closed,low}……杯の 勝者を、二十年 待った。", "{up}座った まま だが、許せ。……立つと、錠が ゆるむ。"]);
    K.pay(p, E1, 3000, []);
    await fin(K, p, { bye: [eZ], card: "§7→ 錠の 座の 前で", kind: "ash" });
    return true;
  } };

const E2 = { id: "b20e2", t: "座った まま", place: HALL, battles: 1,
  hint: "§f§e王冠の 間§f の 奥へ §7（星冠王が 待って いる）",
  syn: "ゼファードは 座った まま 戦った。立とうと すると、床の ひびが 広がった。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v);
    await K.open(p, "王冠の 間", "ash"); K.mood(p, "shadow");
    let eZ = await seatZ(K, p, v);
    await K.low(p, eZ, 12);
    await K.say(p, "ゼファード", ["{closed}……三十五年前、わたしは この 上に 闘技場を 開いた。", "{angry,up}杯を 勝ちぬいた 者よ。おまえと 相棒が、§e六つ目§f に なれるか。……ここで 見せて もらう。"]);
    await K.duel(p, "§c§l錠の 座", "§f星冠王は 立たない。座った まま、星の 光を 放つ！", { fams: ["king", "dragon"] });
    const r = sOf(p).final ? "win" : await K.battle(p, K.team(["king", "dragon", "sword"], 95, 4, 60), { name: "星冠王 ゼファード", arena: "王冠の 間", theme: "palace", speaker: "ゼファード", final: true, sboss: true, tag: "星冠王", lines: { half: "……立てば、錠が ゆるむ。座った まま 行くぞ。", low: "……そうか。そうで なくては。" } });
    if (r !== "win") { await K.say(p, "ゼファード", ["{closed}……まだ 届かぬか。……また 来い。"]); return false; }
    eZ = again(K, p, eZ, "§c星冠王 ゼファード", K.PJ("zephard", 8));
    const fl = MK(v, "ash") || K.fwd(p, 3, 0, 0.1);
    K.act(eZ, "up"); K.sound(p, "dig.stone", 0.8); K.shake(p, 0.3, 0.5);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, fl, "minecraft:portal_reverse_particle", 8, 1 + i, 0); await K.wait(4); }
    await K.at(p, fl, 14, 2.4, 0.2);
    await K.narr(p, ["§7ゼファードが 腰を 浮かせた とたん、床の ひびが 音を 立てて 広がった。", "§7……ゼファードは 座り直した。ひびが、止まった。"], fl);
    K.act(eZ, "kneel");
    await K.up(p, eZ, 10);
    await K.say(p, "ゼファード", ["{smile}……ふ、ははは。二十年ぶりに、声を 立てて 笑った。", "{closed}……負けた。この わたしが。"]);
    setS(p, (s) => { s.final = true; });
    { const dd = load(p); if (dd) { try { giveCrown(p, dd); } catch {} save(p, dd); } }
    K.pay(p, E2, 200000, [["e_king", 1], ["e_rainbow", 2], ["i_awaken", 1]]);
    await fin(K, p, { bye: [eZ], card: "§7→ 戦いの あと", kind: "ash" });
    return true;
  } };

const E3 = { id: "b20e3", t: "わたしの 字", place: HALL, F: ["F05", "F11", "F13", "F59"], ans: ["qb031", "qb081", "qb122"],
  hint: "§f§e王冠の 間§f に 残ろう §7（ゼファードが 話す）",
  syn: "アルゴが 投げ落とした 命令書を、ゼファードは 見た。「わたしの 字だ。わたしは 書いて いない」。椅子の 背の 石板には、セプルクの 墓碑と 同じ 一文と、王を 斬った 友の 名「アルディス」。ゼファードは 六影の 一の座だった。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v);
    await K.open(p, "王冠の 間", "ash");
    const eZ = await seatZ(K, p, v);
    await K.sixMark(p, eZ, "zeph");   /* 首領の 名乗り（ルビの 名札）*/
    await K.say(p, "ゼファード", ["{closed}……六影を 組み直したのは、わたしだ。§e一の座§f。……鍵は 持たぬ。この 座に 座る ことが 役目だ。"]);
    const st = MK(v, "stair") || K.fwd(p, -3, 2, 3);
    const eA = NP(K, p, "§4アルゴ", "argo"); K.act(eA, "hold"); K.hold(eA, "letter");
    if (ok(eA)) await K.up(p, eA, 12);
    await K.say(p, "アルゴ", ["{closed,low}……見ろ。"]);
    K.hold(eA); await K.give(eA, eZ, "letter");
    await K.narr(p, ["§7アルゴは 一枚の 紙を 置いて、石段の 上へ 戻った。§f竜祭りの 夜に 鍵を 持って 来い§7 と 書いた、首領の 字の 命令書。"], eZ);
    if (ok(eA)) await K.leave(eA, p, 8, false);
    K.act(eZ, "show"); K.hold(eZ, "letter");
    await K.up(p, eZ, 12);
    await K.say(p, "ゼファード", ["{shock,…,low}……わたしの 字だ。", "{closed,low}わたしは 書いて いない。……わたしの 字を 写せる 者は、一人しか おらぬ。"]);   /*F05*/
    K.hold(eZ);
    const sq = MK(v, "slab") || K.fwd(p, 6, 0, 1.2);
    await K.at(p, sq, 18, 1.8, 0.4);
    await K.narr(p, ["§7椅子の 背に、古い 石板が はめこまれて いた。……§f六枚目§7。", "§f『弁明は しない。記録だけを 残す』§7……セプルクの 名の ない 墓の 碑と、同じ 一文。", "§7その 下に、削られずに 残った 名前。§f『アルディス』"], sq);   /*F59*/
    await K.flashback(p, { label: "§7―― 千年前　グランディアの 王の 間", tod: "night", ptc: "ash",   /* 第127版: アルディスが 王を 斬った 夜を 絵で /*F13*/
      actors: { k: { nm: "§6王", job: K.PJ("arca13", 8), at: [5, 0], look: "a" }, a: { nm: "§7アルディス", job: K.PJ("m6_sage", 8), at: [2.6, 0], look: "k", hold: "katana" } },
      beats: [
        ["narr", "§7千年前。王の 間に、影に 宿られた 王と、その 友が 向かい合って いた。", "k"],
        ["fx", "ash", [5, 0, 1.6]],
        ["say", "k", "{closed,low}……アルディス。正気で いられるのは、あと 少しだ。", "a"],
        ["say", "a", "{sad}……できない。おまえを 斬るなど。", "k"],
        ["say", "k", "{closed}斬れ。……わたしが、わたしで ある うちに。", "a"],
        ["go", "a", [4, 0], 10], ["act", "a", "raise"], ["snd", "item.trident.hit", 0.8], ["fx", "light", [5, 0, 1]], ["act", "k", "kneel"],
        ["say", "a", "{cry,low}……弁明は しない。記録だけを 残す。", "k"],
        ["narr", "§7人々は 彼を 王殺しと 呼び、壁画から 削った。……二度 削られた 影の、上の 跡。", "a"],
      ] });
    await K.say(p, "ゼファード", ["{closed}千年前、王の 友 アルディスが、影に 宿られた 王を 斬った。人は 彼を 王殺しと 呼び、壁画から 削った。", "{sad,low}……わたしも、アルディスに なろうと した。"]);
    await K.say(p, "ゼファード", ["{closed}闘技場の 入口の 像の 名も、§e名は、わたしが 削った§f。王に 追われた 者の 名を、子らの 闘技場に 残せぬ。", "{sad,low}人の 名を 呼ばせる 場所を 作って、自分の 名だけは、だれにも 呼ばれぬ 所に 置いた。"]);   /*F11*/
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……なまえ、けずっても、においは のこってた。"]); K.rmCine(g); }
    await K.say(p, "ゼファード", ["{smile,…}……そうか。においは、削れぬか。"]);
    K.pay(p, E3, 3000, []);
    await fin(K, p, { bye: [eZ, eA], card: "§7→ 錠の 座の 肘かけ", kind: "ash" });
    return true;
  } };

const E4 = { id: "b20e4", t: "八年目の 冬", place: HALL, F: ["F04", "F19"], ans: ["qb051"],
  hint: "§f§e王冠の 間§f に 残ろう §7（ゼファードの 腕輪）",
  syn: "ゼファードの 闘魔の 腕輪は、爪が 一本 欠けて いた。王墓の 壁の 爪跡の 短い 一本と 同じ。「消しきれなかった」。灰の 冬の ことを 訊くと、深い 刻みに 指を 置いた。「……八年目の 冬だ」。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v);
    await K.open(p, "王冠の 間", "ash");
    const eZ = await seatZ(K, p, v); K.act(eZ, "hold");
    const wq = ok(eZ) ? { x: eZ.location.x, y: eZ.location.y + 1, z: eZ.location.z } : K.fwd(p, 5, 0, 1);
    await K.at(p, wq, 14, 1.2, 0.1);
    await K.narr(p, ["§7ゼファードの 腕の、闘魔の 腕輪。……爪が §f一本 欠けて§7 いる。", "§7サンドリアの 王墓の 壁に 残って いた 爪跡。あの 短い 一本と、同じ 形。"], wq);   /*F04*/
    await K.say(p, "ゼファード", ["{closed,low}……§e永遠を 願うな。願いは 石に なる§f。……あの 字は、読めば だれでも 願って しまう。", "{sad,low}爪で 消そうと した。……消しきれなかった。"]);
    await K.narr(p, ["§7あなたは 訊いた。……灰の 降った 冬の ことを。"]);
    K.act(eZ, 0);
    const dq = MK(v, "deep") || K.fwd(p, 5, -0.6, 0.6);
    await K.at(p, dq, 18, 1.1, 0.2);
    await K.narr(p, ["§7ゼファードの 指が、深く えぐれた 一本の 刻みに 置かれた。"], dq);   /*F19*/
    await K.up(p, eZ, 12);
    await K.say(p, "ゼファード", ["{closed,low}……八年目の 冬だ。", "{sad,low}一度だけ、願った。娘らの 顔が 見たい、と。……手首の 紐を 引いた 指が、肘かけから 離れた。"]);
    const fl = MK(v, "ash") || K.fwd(p, 3, 0, 0.1);
    await K.at(p, fl, 14, 2.6, 0.2);
    await K.narr(p, ["§7その 一晩、影は 灰に なって 世界に 降った。……この 床の 灰は、その 夜の もの だった。"], fl);
    await K.say(p, "ゼファード", ["{closed}ラヴィの 村も、グロウの 坑道も、ルミエの 小川も。……数えるのを、やめた。", "{sad}その 責めは、わたしが 負う。"]);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……この はい、ふゆの におい。……あなたの こどもの ころの においも する。"]); K.rmCine(g); }
    await fin(K, p, { bye: [eZ], card: "§7→ 格子の 下へ、だれかが 下りて くる", kind: "ash" });
    return true;
  } };

const E5 = { id: "b20e5", t: "ロウ！", place: UNDER, F: ["F12", "F14", "F35", "F36", "F37", "F49"], ans: ["qb032", "qb112"],
  hint: "§f§e王冠の 間§f の §e格子の 下§f へ §7（石段を だれかが 下りて くる）",
  syn: "ヴァルカ、アルゴ、眠る ロウを 背負った ルウが 下りて きた。アルゴは 仮面を 外した。ルウは 格子の 上の 客席へ、生まれて 初めての 大声で「ロウ！」。客席が 三度 続けて 呼び、ロウが 目を 開けた。「……ルウ。……声、大きかったよ」。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v, "格子の 下");
    await K.open(p, "格子の 下", "ash");
    const eV = await K.put(p, "§cヴァルカ", K.fwd(p, 4, -3), null, K.PJ("valka", 10)); K.act(eV, "hold"); K.hold(eV, "key");
    await K.low(p, eV, 12);
    await K.say(p, "ヴァルカ", ["{smile,low}……熱いのは 好きかい？ 祭壇で 割れた 赤い 鍵、打ち直して きたよ。", "{closed}アタシの 試しは、まだ 終わってなかった。"]);
    const eA = await K.put(p, "§4アルゴ", K.fwd(p, 3.6, -0.6), null, K.PJ("argo", 8)), eRu = await K.put(p, "r8_ruu", K.fwd(p, 4.8, 1.0), null), eRo = await K.put(p, "r8_rou", K.fwd(p, 6.4, 3), null); K.act(eRo, "prone");
    await K.two(p, eRu, eRo, 14);
    await K.narr(p, ["§7ルウが、眠った ままの ロウを 背負って 石段を 下りて きた。ロウの 手は、まだ 冷たい。"], eRo);
    await K.up(p, eA, 12);
    K.act(eA, "up"); K.sound(p, "random.glass", 0.5);
    await K.narr(p, ["§7アルゴが、ひびの 入った 白い 仮面を 外した。……頬に、焼けて 紋の 形に なった 傷。", "§7冥王の 城の 旗と 同じ、§f妃の 紋§7。"], eA);   /*F37*/
    await K.say(p, "アルゴ", ["{closed,low}……妃さまの 近衛だった。……守れなかった。", "{sad,low}……竜祭りの 夜も。"]);
    K.act(eA, 0);
    const k = K.ch(p, "c11") || "k";
    if (k === "k") {
      await K.narr(p, ["§7あなたは かばんから、雪山で 拾った §f黒い 右手の 手袋§7 を 出して、ルウに 渡した。"], eRu);
      await K.give(eRu, null, "glove");
      setS(p, (s) => { if (Array.isArray(s.keys)) s.keys = s.keys.filter((x) => x !== "k_glove"); });
    } else await K.narr(p, ["§7ルウは、胸に しまって いた §f黒い 右手の 手袋§7 を 出して、ロウの 手に 重ねた。"], eRu);   /*F35*/
    K.act(eRu, "hold"); K.hold(eRu, "glove"); face(K, eRu, eRo);
    await K.say(p, "ルウ", [k === "k" ? "{sad,…}……兄ちゃんの 編み目、だもん。……ロウの 手、つめたいんだもん。" : "{sad,…}……ずっと 持ってたんだもん。……ロウの 手、まだ つめたいんだもん。"], eRo);
    const gq = MK(v, "grate") || K.fwd(p, 4, 0, 4);
    await K.at(p, gq, 12, 3, -2);
    await K.narr(p, ["§7格子の 上から、闘技場の 客席の ざわめきが 降って くる。"], gq);
    K.act(eRu, "up"); face(K, eRu, eRo);
    await K.up(p, eRu, 12);
    await K.say(p, "ルウ", ["{angry,tears,!,up}……ロウ――！！"]);   /*F49*/
    await K.narr(p, ["§7ルウの、生まれて 初めての 大声だった。"], eRu);
    await K.narr(p, ["§f（格子の 上）「……ロウ！」"], gq);
    await K.narr(p, ["§f「ロウ！！」"], gq);
    await K.narr(p, ["§f「ロウ――！！」", "§7客席が、三度 続けて 名前を 呼んだ。レイの 声が、いちばん 大きかった。"], gq);   /*F12*/
    K.flash(p, true); K.sound(p, "random.levelup", 0.6);
    K.act(eRo, "up");
    await K.up(p, eRo, 14);
    await K.say(p, "ロウ", ["{closed,…}……ルウ。", "{smile,…}……声、大きかったよ。"]);   /*F36*/
    await K.two(p, eRu, eRo, 12);
    await K.say(p, "ルウ", ["{cry,smile,tears,up}……ロウ。……手、あったかいんだもん。"], eRo);
    await K.narr(p, ["§7ロウの 白い 手袋の 右手と、ルウの 黒い 手袋。……あいた 方の 素手が、つながった。"], eRo);   /*F14*/
    K.pay(p, E5, 4000, []);
    await fin(K, p, { bye: [eV, eA, eRu, eRo], card: "§7→ 錠の 座の 前へ", kind: "ash" });
    return true;
  } };

const E6 = { id: "b20e6", t: "ほどきかけの 紐", place: HALL, F: ["F10", "F17", "F22", "F33", "F34", "F52", "F53", "F68"], ans: ["qb062", "qb071", "qb072", "qb161"],
  hint: "§f§e王冠の 間§f の 錠の 座の 前へ §7（ゼファードの 手首）",
  syn: "ゼファードの 手首に、ほどきかけの 紐。沈んだ 神殿の 石の 女の 話を 聞くと、指が 肘かけから 浮いた。「……あれは、笛を 持って 出たのか」。ヴァルカは ベリルを 座に 入れなかった わけを 話した。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v);
    await K.open(p, "王冠の 間", "ash");
    const eZ = await seatZ(K, p, v); K.act(eZ, "hold"); K.hold(eZ, "rope");
    const wq = ok(eZ) ? { x: eZ.location.x, y: eZ.location.y + 1, z: eZ.location.z } : K.fwd(p, 5, 0, 1);
    await K.at(p, wq, 14, 1.2, 0.1);
    await K.narr(p, ["§7ゼファードの 手首に、§fほどきかけの 紐§7。三つ 編んで 一つ 返す、ナギサの 紐と 同じ 結び方。"], wq);   /*F10*/
    const c16 = K.ch(p, "c16") || "s";
    if (c16 === "r") {
      await K.narr(p, ["§7あなたは 風の 塔の 箱に あった 手紙の ことを 話した。……封を 切って、読んだ ことも。"]);
      await K.say(p, "ゼファード", ["{closed,…}……読んだか。", "{sad,low}ならば、言う ことは 少ない。……娘らの 父だ。"]);   /*F33*/
    } else {
      await K.narr(p, ["§7あなたは 風の 塔の 箱の ことを 話した。封は、切らずに 持って いる。"]);
      await K.say(p, "ゼファード", ["{closed}……塔の 箱を 開けたか。あの 紐と 手紙を 置いたのは、わたしだ。", "{sad,low}コラリアに 娘が 二人 いる。……わたしの 娘だ。下の 子には、名を つける 前に 家を 出た。"]);   /*F33*/
    }
    await K.say(p, "ゼファード", ["{closed}塔の 遠めがねは、娘らの いる 海へ 向けて 固めた。……一度も、見えは しなかった。"]);   /*F53*/
    await K.say(p, "ゼファード", ["{sad,low}……マリンは、わたしの 顔を 知らぬ。"]);   /*F34*/
    await K.narr(p, ["§7あなたは 話した。沈んだ 神殿の、珊瑚に 覆われた 石の 女の ことを。§f笛を 持つ 形の 手§7。"]);
    const c07 = K.ch(p, "c07") || "p";
    await K.narr(p, [c07 === "p" ? "§7浜の 火の 中から 笛を 取り出したのは 相棒だった。前足に、焼け跡が 残って いる。" : "§7浜の 火の 中の 笛に、ナギサが 手を 伸ばした。……その 手は、焼けた。"]);   /*F52*/
    K.hold(eZ);
    const dq = MK(v, "deep") || K.fwd(p, 5, -0.6, 0.6);
    await K.at(p, dq, 14, 1.1, 0.2);
    K.sound(p, "dig.stone", 0.6); K.shake(p, 0.2, 0.3);
    await K.narr(p, ["§7ゼファードの 指が、肘かけから 浮いた。……床が 低く 鳴った。"], dq);
    await K.up(p, eZ, 14);
    await K.say(p, "ゼファード", ["{shock,…,low}……あれは、笛を 持って 出たのか。", "{sad,tears,low}……§eミナモ§f。……わたしを 呼びに、海へ。"]);   /*F68*/
    K.act(eZ, "kneel");
    await K.narr(p, ["§7指は、もう一度 肘かけに 戻った。……床の 音が、止んだ。"], dq);
    await K.say(p, "ゼファード", ["{closed}参謀が 娘らを 番人に 会わせたく なかったのは、それを 知って いたからだ。……母が 石だと 知れば、娘らは 願う。"]);
    const eV = NP(K, p, "§cヴァルカ", "valka", false, 10); K.act(eV, "hold");
    await K.say(p, "ヴァルカ", [c07 === "p" ? "{sad,low}……アタシの 火が、アンタの 相棒を 焼いた。" : "{sad,low}……アタシが 焼いた 手だ。あの 姉さんの。"], eZ);
    await K.say(p, "ゼファード", ["{closed}……それも、わたしが 負う。"], eV);
    await K.low(p, eV, 12);
    await K.say(p, "ヴァルカ", ["{closed,low}……ベリルに 言っときな。座に 載ったら、影に 読まれる。", "{sad}……アタシなりの、精いっぱい だったんだよ。"]);   /*F17*/
    await K.say(p, "ヴァルカ", ["{smile,low}だから 言ったろ。§e試しだ§fって。"]);   /*F22*/
    K.pay(p, E6, 3000, []);
    await fin(K, p, { bye: [eZ, eV], card: "§7→ 王冠の 奥で、何かが 動いた", kind: "ash" });
    return true;
  } };

const E7 = { id: "b20e7", t: "紫の 名前", place: BACK, battles: 1,
  hint: "§f§e王冠の 奥§f へ §7（影の セオ）",
  syn: "王冠の 奥の 壁 いっぱいに、紫の インクで 書いた 名前。その 前で、影に 宿られた セオと 戦った。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v, "王冠の 奥");
    await K.open(p, "王冠の 奥", "ash"); K.mood(p, "shadow");
    const wl = MK(v, "wall") || K.fwd(p, 7, -2, 2);
    await K.at(p, wl, 18, 3, 0.6);
    await K.narr(p, ["§7奥の 壁 いっぱいに、§5紫の インク§7 の 字。……名前、名前、名前。", "§7一度 見た 字を そっくり 写せる 手で、何千と 書いた 名前。"], wl);
    let eT = K.npcNear(p, "§5影の セオ", 18); K.act(eT, "hold"); K.hold(eT, "notebook");
    if (ok(eT)) { K.burst(p.dimension, eT.location, "minecraft:portal_reverse_particle", 8, 0.6, 1.6); await K.up(p, eT, 12); }
    await K.say(p, "セオ", ["{closed,low}……やあ。来ると 思って いましたよ。……いや。来ると、知って いた。", "{angry,low}全部 書いて おけば、何も 失わない。……ここに、君の 名前だけが ない。"]);
    await K.duel(p, "§5§l影の セオ", "§f紫の インクが、壁から あふれ出す！", { fams: ["nether", "dragon"] });
    const r = await K.battle(p, K.team(["nether", "dragon", "king"], 96, 4, 60), { name: "影の セオ", arena: "王冠の 奥", theme: "underworld", speaker: "セオ", sboss: true, tag: "参謀", form2: "theo", lines: { half: "……書けない。君の 名前だけが、書けない。", low: "……やめて くれ。……読ませないで くれ。" } });
    if (r !== "win") { await K.say(p, "セオ", ["{closed,low}……また、来れば いい。"]); return false; }
    eT = again(K, p, eT, "§5影の セオ", 18); K.act(eT, "kneel");
    await fin(K, p, { bye: [eT], card: "§7→ 王冠の 奥（そのまま）", kind: "ash" });
    return true;
  } };

/* 本20-8: 本編 最後の 戦いの あと（オーナー要望: あっさり 消えない。ゆっくり 10拍。主人公の 言葉）
   1 影が はがれかけ、ひざを つく → 2 覚えて いる ことの 重さ → 3 あの 子の こと → 4「斬って くれ」→ 5 レイの 言葉・刃を 下ろす
   → 6 主人公の 言葉（一人で 全部を 背負った 友へ、名を 呼んで）→ 7 相棒が 三度「セオ」→ 8 目の 文字が 消える・セオの 答え → 9 手帳を 投げる → 10 闇へ 沈む・静かな 絵 */
const E8 = { id: "b20e8", t: "斬って くれ", place: BACK, keys: ["k_tnote"],
  hint: "§f§e王冠の 奥§f に 残ろう §7（セオが ひざを ついた）",
  syn: "セオは「斬って くれ。アルディスが 王に したように」と 言った。あなたは 刃を 下ろし、一人で 全部を 背負って きた 友の 名を 呼んだ。相棒が「セオ」と 三度 鳴いた。セオの 目の 文字が 一瞬 消え、セオは 手帳を あなたに 投げて、奥の 裂け目の 闇へ 沈んで いった。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v, "王冠の 奥");
    await K.open(p, "王冠の 奥", "ash"); K.mood(p, "shadow");
    const eT = await K.put(p, "§5影の セオ", nearM(K, p, v, "back", 4.5, 0.6), p.getHeadLocation(), 18); K.act(eT, "kneel");
    /* 1. 影が はがれかけ、ひざを つく（引き → 寄り）*/
    if (ok(eT)) { for (let k = 0; k < 4; k++) { K.burst(p.dimension, eT.location, "minecraft:portal_reverse_particle", 6, 0.6 + k * 0.3, 0.6 + k * 0.5); await K.wait(5); } }
    await K.pull(p, eT, 26);
    await K.narr(p, ["§7奥の 壁の 名前の 前で、セオが ひざを ついて いた。肩から、紫の 影が 糸の ように 立ちのぼって いる。"], eT);
    await K.push(p, eT, 24, 4.5, 1.2);
    await K.say(p, "セオ", ["{sad,…,low}……やあ。ひどい 顔だな。……僕も、か。"]);
    /* 2. 忘れられない 頭 */
    const wl = MK(v, "wall") || K.fwd(p, 7, -2, 2);
    await K.at(p, wl, 16, 2.6, 0.6);
    await K.say(p, "セオ", ["{closed,low}この 壁の 名前、一つ 残らず 覚えてる。……忘れさせて くれないんだ、この 頭は。", "{sad,low}ノエの 声も。母さんの 声も。……祭壇で 読んだ 最後の 一枚も。"]);
    /* 3. あの 子の こと */
    await K.up(p, eT, 14);
    await K.say(p, "セオ", ["{sad,up}……あの 子は、君の 前に 立った。僕の 槍の 前に。……笑ってた。", "{sad,…,low}ごめん。……それしか 書けない。どんな 言葉も、記録には 足りない。"]);
    /* 4. 斬って くれ */
    K.sound(p, "mob.warden.roar", 0.6); K.shake(p, 0.5, 1.0);
    K.act(eT, "raise"); await K.pull(p, eT, 22);
    await K.say(p, "セオ", ["{angry,汗}……時間が ない。影は まだ、僕の 中を 居場所だと 思ってる。", "{closed,up}今の うちに、§c斬って くれ§f。……千年前、アルディスが 王に そう したように。"]);
    /* 5. レイの 言葉・刃を 下ろす */
    await K.narr(p, ["§7雲の 島の 端で、レイが 言った。§b「止めるのは、あいつの 友だ」"]);
    await K.ots(p, K.hero(p, false) || eT, eT, 12);
    await K.narr(p, ["§7あなたは 刃を 上げ……そして、ゆっくり 下ろした。"], eT);
    /* 6. 主人公の 言葉 */
    toP(K, p, eT);
    await K.say(p, p.name, ["……斬らない。アルディスの 続きは、ここで 終わりに する。", "セオ。十二年、だれにも 言えない ことを、全部 一人で 覚えて きたんだろ。"], eT);
    await K.up(p, eT, 12);
    await K.say(p, p.name, ["きみが 書いた 名前は、一つずつ 呼んで 迎えに 行く。……その 最後の 一人は、きみだ。セオ。"], eT);
    /* 7. 相棒が 三度 */
    const g = K.palEnt(p); if (g && ok(eT)) { await K.approach(p, g, eT, 1.4); K.turn(g, eT.location); }
    for (let i = 0; i < 3; i++) { if (g) { K.sound(p, "mob.wolf.bark", 1 - i * 0.1); K.burst(p.dimension, g.location, "minecraft:note", 2, 0.3, 1.2); await K.up(p, g, 8); } await K.pal(p, [["……セオ。", "……セオ！", "……セオ――！"][i]]); }
    K.rmCine(g);
    /* 8. 目の 文字が 消える・セオの 答え */
    K.flash(p, true);
    if (ok(eT)) await K.push(p, eT, 22, 3.5, 1.5);
    await K.narr(p, ["§7セオの 目の 中を 流れて いた 紫の 文字が、一瞬、すっと 消えた。……十二年ぶりの、ただの 目だった。"], eT);
    K.act(eT, "kneel");
    await K.say(p, "セオ", ["{shock,…,up}……斬らない、のか。", "{cry,smile,tears}……アルディスに、ならないんだね。……君に 会えて、よかった。"]);
    await K.low(p, eT, 12);
    await K.say(p, "セオ", ["{cry,tears,low}……名前を 呼ばれるのが、こんなに 重いなんて。……書く 側に いると、知らなかった。"]);
    /* 9. 手帳を 投げる */
    K.sound(p, "mob.warden.roar", 0.5); K.act(eT, "hold"); K.hold(eT, "notebook");
    await K.say(p, "セオ", ["{angry,汗,low}……戻って くる。影が。……これを。君なら、読める。"]);
    K.hold(eT); await K.give(eT, null, "notebook");
    const bq = K.fwd(p, 1.2, 0, 0.3);
    await K.at(p, bq, 14, 1.4, 0.3);
    await K.narr(p, ["§7セオは 手帳を、あなたに 向かって 投げた。§f二本の 紐と 留め金の ついた、セオの 手帳§7。", "§7赤い 子どもの 紐が、ほどけかけて 揺れて いた。"], bq);
    K.key(p, "k_tnote");
    /* 10. 闇へ 沈む・静かな 絵 */
    const rq = MK(v, "rift") || K.fwd(p, 6, 0, 1);
    for (let k = 0; k < 4; k++) { K.burst(p.dimension, rq, "minecraft:portal_reverse_particle", 10, 1 + k * 0.3, 0); await K.wait(5); }
    K.act(eT, "up");
    await K.say(p, "セオ", ["{smile,tears,low}……ノエに 会ったら、兄さんは 今日、名前を 呼ばれたって 言うよ。"]);
    if (ok(eT)) await K.leave(eT, p, 8, false);
    await K.pull(p, rq, 30);
    await K.narr(p, ["§7セオは 振り返らずに、奥の 壁の §0裂け目§7 へ 歩いて いった。……紫の 影が、その 背中を 包んで 沈んだ。", "§7裂け目の 向こうは、どこまでも 白い 頁の ような 闇。……§5常世§7 への 口だと、だれかが 呼んで いた。"], rq);
    K.sound(p, "item.book.page_turn", 1); await K.at(p, bq, 18, 2.2, 0.4);
    await K.narr(p, ["§7石の 床に、あなたと 相棒の 影だけが 残った。", "§7手帳の 最後の 頁は、影に にじんで 読めない。……あとで、明るい 所で 開こう。"]);   /* 謎A三層（強める）*/
    K.pay(p, E8, 3000, []);
    await fin(K, p, { bye: [eT], card: "§7（だいじなもの: セオの 手帳）", kind: "ash" });
    return true;
  } };

/* 本20-9: 錠が ゆるむ → ゼファードの 報われなかった 二十年（戦いは ない。ゆっくり 寄る）→ 名を 三度 呼ぶ → 選択 C20 → 静かな 絵
   オーナー要望: ラスボスの あと あっさり 消えない。名を 呼ぶ 主題・紐・コンパス・海へ 向いた 遠めがね で 報いる */
const E9 = { id: "b20e9", t: "錠の 座", place: HALL,
  hint: "§f§e王冠の 間§f の 錠の 座へ §7（錠が ゆるんで いる）",
  syn: "錠が ゆるみ、床の 灰が 舞い上がった。ゼファードは 二十年 座り、三十五年 待った ことを 話した。あなたは あの 子の コンパスと 箱の 紐を 見せ、削られた 名前を 呼んだ。仲間と 客席が 三度 続けた。ゆるんだ 錠の 座に、だれが 座るか。",
  async run(p, d, K) {
    const v = crown(K, p); await into(K, p, v);
    await K.open(p, "王冠の 間", "ash");
    let eZ = await seatZ(K, p, v);
    const fl = MK(v, "ash") || K.fwd(p, 3, 0, 0.2);
    /* 1. 錠が ゆるむ。灰が 舞う（引き → 寄り）*/
    for (let i = 0; i < 4; i++) { K.burst(p.dimension, fl, "minecraft:white_smoke_particle", 12, 3, 1 + i); K.shake(p, 0.25, 0.3); await K.wait(5); }
    await K.pull(p, fl, 26);
    await K.narr(p, ["§7床の 灰が、ゆっくり 舞い上がった。……錠が、ゆるんで いる。"], fl);
    /* 2. 座った ままの 男。石に なりかけた 足、ふるえる 指（寄り）*/
    const ft = ok(eZ) ? { x: eZ.location.x, y: eZ.location.y + 0.3, z: eZ.location.z } : fl;
    await K.at(p, ft, 14, 1.6, 0.1);
    await K.narr(p, ["§7ゼファードの 足は、膝の 上まで 灰色の 石に なって いた。肘かけの 指が、小さく ふるえて いる。"], ft);
    await K.push(p, eZ, 24, 4.5, 1.6);
    await K.say(p, "ゼファード", ["{closed,low}……闘技場を 開いて 三十五年。この 座に 座って 二十年。", "{sad,low}子らの 足音と 歓声だけを 聞いて、刻みを 一本ずつ 増やした。"]);
    /* 3. 見えなかった 海・一度の 願い */
    const dq = MK(v, "deep") || K.fwd(p, 5, -0.6, 0.6);
    await K.at(p, dq, 14, 1.1, 0.2);
    await K.say(p, "ゼファード", ["{sad,low}塔の 遠めがねは、海へ 向けて 固めた。……一度も、海は 見えなかった。", "{closed,low}見たいと 願ったのは、一晩だけだ。……その 一晩で、世界に 灰が 降った。"]);
    await K.up(p, eZ, 12);
    await K.say(p, "ゼファード", ["{closed,low}……わたしの 名は、像から 削った。呼ばれる 資格は ない。", "{sad,low}このまま 石に なって、だれにも 呼ばれず 終わるのが、似合いだ。"]);
    /* 4. コンパス（あの 子が 組んだ。行きたい 場所の 方を 指す）*/
    await K.narr(p, ["§7あなたは 首から 下げた §fコンパス§7 を 外して、ゼファードの 手のひらに 置いた。", "§7あの 子が 組んだ、§f行きたい 場所の 方を 指す§7 コンパス。"], eZ);
    const hq = ok(eZ) ? { x: eZ.location.x, y: eZ.location.y + 1, z: eZ.location.z } : K.fwd(p, 4, 0, 1);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, hq, "minecraft:endrod", 2, 0.2, 0.1); await K.wait(6); }
    await K.at(p, hq, 18, 1, 0.1);
    await K.narr(p, ["§7旅の あいだ、一度も 止まらなかった 針が、ぴたりと 止まった。", "§7……壁の 向こう、ずっと 遠くの §b海§7 の 方角を 指して。"], hq);
    await K.up(p, eZ, 12);
    await K.say(p, "ゼファード", ["{shock,…,low}……海、か。", "{sad,tears,low}……わたしが 行きたかった 場所を、この 針は 知って いたのか。"]);
    /* 5. 箱の 紐と、手首の 紐 */
    await K.narr(p, ["§7あなたは 風の 塔の 箱に あった §f紐§7 を 出した。三つ 編んで 一つ 返す、編みかけの 紐。"], eZ);
    K.act(eZ, "hold"); K.hold(eZ, "rope");
    await K.at(p, hq, 14, 1.2, 0.1);
    await K.narr(p, ["§7ゼファードの 手首の、ミナモが 編んだ ほどきかけの 紐。……二本の 編み目が、一目も ちがわずに 並んだ。"], hq);
    await K.say(p, "ゼファード", ["{cry,tears,low}……ミナモ。おまえは 笛を 持って、わたしを 呼びに 来たのだな。", "{sad,low}二十年、わたしは 呼ばれて いた。……聞こえない ふりを して いた。"]);
    K.hold(eZ); K.act(eZ, "kneel");
    /* 6. あなたの 言葉（名を 呼ぶ 旅の 答え）*/
    await K.ots(p, K.hero(p, false) || eZ, eZ, 10);
    await K.narr(p, ["§7あなたは 錠の 座の 前に ひざを ついた。"], eZ);
    await K.say(p, p.name, ["……像の 名前は 削れても、ここで 待った 二十年までは 削れない。", "名前を 呼ぶ 場所を 作った 人の 名前を、今日は みんなで 呼ぶ。"], eZ);   /* 主人公が 話すのは 山場だけ（ここは 2行）*/
    await K.up(p, eZ, 10);
    /* 7. 仲間が 石段を 下りて きて、ひざを つく */
    const eO = ORDO(K, p), eR = REI(K, p), eM = K.cast(p, "mimi"), eG = K.cast(p, "gonza");
    await K.wide(p, 14);
    for (const e of [eO, eR, eM, eG]) K.act(e, "kneel");
    await K.two(p, eO, eZ, 12);
    await K.say(p, "オルド", ["{smile,tears,…}……ほっほ。二十年ぶりじゃな、ゼファード。", "{closed}名を 呼ぶ 声には 影は 宿れん。……おまえさんが 教えて くれた ことじゃ。"], eZ);
    face(K, eZ, eO);
    await K.say(p, "レイ", ["{closed,up}……客席の みんなにも、名前を 伝えて きた。格子の 上で 待ってる。"], eZ);
    /* 8. 名を 三度（格子の 上の 客席と 仲間）*/
    const gq = MK(v, "grate") || K.fwd(p, 4, 0, 4);
    await K.narr(p, ["§f「ゼファード！」"], eM);
    await K.at(p, gq, 10, 3, -2);
    await K.narr(p, ["§f（格子の 上）「ゼファード！！」"], gq);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, gq, "minecraft:totem_particle", 8, 2, -1); await K.wait(4); }
    await K.pull(p, fl, 24);
    await K.narr(p, ["§f「ゼファード――！！」", "§7王冠の 間の 灰が、歓声に 押されて 金色に 光りながら 舞った。"], fl);
    await K.push(p, eZ, 26, 4, 1.5);
    K.act(eZ, "up");
    await K.say(p, "ゼファード", ["{cry,smile,tears,low}……呼ばれた。……三十五年ぶりに、自分の 名を。", "{smile,tears,low}子らの 歓声の 中に、わたしの 名が あった。……それで、十分だ。"]);
    K.act(eZ, "kneel");
    /* 9. 選択 C20（どちらも 失う ものを 一拍）*/
    await K.two(p, eO, eZ, 12);
    await K.say(p, "ゼファード", ["{closed}……錠は まだ、だれかが 座って いなければ 閉じきらぬ。座った 者は、少しずつ 石に なる。", "{sad,low}オルド。……おまえには 孫が いる。"], eO);
    await K.say(p, "オルド", ["{closed}おまえさんには 娘が おる。……海で、百を 数えて 待っとる 娘がな。", "{smile,…}今度は、わしが 座る。……二度は 引き返さん。"], eZ);
    await K.narr(p, ["§7二人は、あなたを 見た。"]);
    const c = await K.pick(p, "c20");
    if (c === "o") {
      K.act(eZ, "up");
      await K.up(p, eZ, 14);
      await K.narr(p, ["§7ゼファードが、二十年ぶりに 立ち上がった。石の 足が きしみ、ふらついた 腕を、オルドが 支えた。"], eZ);
      if (ok(eO) && ok(eZ)) await K.approach(p, eO, eZ, 1);
      K.act(eO, "kneel");
      await K.low(p, eO, 14);
      await K.say(p, "オルド", ["{smile,…}……ほっほ。座り心地は、悪くないのう。", "{closed}レイに 言うて おく。……百と 三勝じゃ。寝ぼすけに 負け越すなよ。"], eR);
      face(K, eR, eO);
      await K.say(p, "レイ", ["{cry,tears,up}……じいちゃん。", "{closed,tears}……しくじり帳には 書かねえ。……じいちゃんが 選んだ ことだ。"], eO);
      await K.say(p, "ゼファード", ["{sad,tears,low}……すまぬ。……ありがとう、友よ。", "{closed,up}海を、見て くる。"], eO);
      if (ok(eZ)) await K.leave(eZ, p, 9, false);
      /* 10. 静かな 絵: 石段の 上の 光へ 歩く 背中。座に ひとり、灰の 中の オルド */
      await K.pull(p, eO, 34);
      await K.narr(p, ["§7石段の 上から、細い 光が 差して いた。……その 光の 方へ、星の 冠の 外套が 一段ずつ のぼって いった。", "§7錠の 座の オルドは、干し草の 紐を 指に 巻いて、目を 閉じた。"], eO);
    } else {
      await K.up(p, eZ, 14);
      await K.say(p, "ゼファード", ["{closed}……わたしが 座り続ける。幕を 引くのは、幕を 上げた 者の 役目だ。", "{smile,tears,low}オルド。紐と 手紙を、娘らに。……おまえの 手で。"], eO);
      await K.say(p, "オルド", ["{sad,tears}……わかった。わしの 手で 届ける。……おまえさんの 名を 添えてな。"], eZ);
      K.act(eZ, "hold"); K.hold(eZ, "compass");
      await K.at(p, hq, 14, 1.2, 0.1);
      await K.narr(p, ["§7ゼファードは 海を 指す 針を、しばらく 見つめて いた。……それから、コンパスを あなたの 手に 戻した。"], hq);
      await K.say(p, "ゼファード", ["{smile,tears,low}……これは、組んだ 子に 返して やれ。その 子にも、行きたい 場所が ある はずだ。", "{closed,low}海の 方角は、もう 覚えた。"]);
      K.hold(eZ); K.act(eZ, "kneel");
      for (let k = 0; k < 5 && ok(eZ); k++) { K.burst(p.dimension, eZ.location, "minecraft:white_smoke_particle", 6, 0.6, k * 0.4); await K.wait(6); }
      await K.push(p, eZ, 28, 4, 1.3);
      await K.narr(p, ["§7ゼファードの 体が、足もとから 静かに 石へ 変わって いった。", "§7……指は 最後まで 肘かけを 離さず、顔は、壁の 向こうの 海の 方を 向いて いた。"], eZ);
      /* 10. 静かな 絵: 石の 王と、海を 指す 針 */
      await K.pull(p, eZ, 34);
      await K.narr(p, ["§7あなたの 手の 中で、コンパスの 針が、まだ 海の 方を 指して いた。", "§7格子の 上から、もう 一度だけ、小さな 声が 降って きた。§f「……ゼファード」"], eZ);
    }
    await K.narr(p, ["§7舞い上がった 灰が、静かに 床へ 戻った。……錠が、閉じた。"], fl);
    await fin(K, p, { bye: [eO, eZ, eR, eM, eG], card: "§7→ 地上へ。それぞれの 町へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 終話（各地。MQ24・s.ending）---------- */
const REC = (k) => J(`mrpg:epdeco:${k}at`);
async function goSet(K, p, q, look, nm) { if (!q) { await fade(K, p); return false; } const r = await K.moveTo(p, q, nm, [], look || null, 12); await K.wait(12); return !!r; }
const E10 = { id: "b20e10", t: "それぞれの 町", F: ["F23", "F24", "F35", "F36", "F60"],
  hint: "§f王冠の 間の 石段を 上がろう §7（それぞれの 町へ。ガイドブック ＞ ストーリー）",
  syn: "ラヴィで ヴァルカは トンボに 村の ことを 話した。サンダで 双子が 帰り、シロウは 手袋の 色を 見ずに 名前を 呼んだ。コラリアに 紐と 手紙が 届いた。グランディア城で、預かって いた 鞘を ジンに 返した。剣は 十二年ぶりに 鞘に 納まった。エンドの 鱗の 墓標の 前で、セオの 手帳の 最後の 頁を 開いた。「魂の 帳に 名が なければ、呼び戻せる」。",
  async run(p, d, K) {
    const s0 = sOf(p), c04 = K.chGet(s0, "c04") || "s", c11 = K.chGet(s0, "c11") || "k", c16 = K.chGet(s0, "c16") || "s", c20 = K.chGet(s0, "c20") || "z";
    await K.open(p, "王冠の 間", "day");
    await K.narr(p, ["§7王冠の 間の 錠が 閉じて、いく日か たった。", "§7世界の あちこちで、待って いた 人の もとへ 帰る 人が いた。"]);
    /* ラヴィ: ヴァルカと トンボ・ヨネ婆の 木槌 */
    { const SM = facAt("r3smithy"), SF = SM && facFront("r3smithy", 5); await goSet(K, p, SF, SM, "ようがんの 里 ラヴィ"); }
    K.card(p, "§f― ようがんの 里 ラヴィ 鍛冶場 ―", 60);
    const eT = K.cast(p, "r3tombo"), eG = K.cast(p, "r3gen"); K.act(eT, "hold"); K.hold(eT, "hammer");
    await K.csay(p, "r3gen", ["{closed}……客だでい、トンボ。"], eT);
    const eV = NP(K, p, "§cヴァルカ", "valka", false, 10); K.act(eV, "hold");
    await K.low(p, eV, 14);
    await K.say(p, "ヴァルカ", ["{sad,up}十二年前、親父の 刀が 一つの 村を 焼いた。……アンタの 村だ。", "{closed,low}……ごめん。謝るのは、渡す ときだって 決めてた。"], eT);   /*F23*/
    if (c04 === "p") {
      K.hold(eV, "box"); await K.give(eV, eT, "box");
      await K.say(p, "ヴァルカ", ["{closed}……親父の 刀は、鋳造所で 溶けて 鉄の かたまりに なった。", "{sad,up}アンタの 村を 焼いた 鉄だ。……アンタが 打ちな。"], eT);
    } else {
      K.hold(eV, "katana");
      await K.say(p, "ヴァルカ", ["{closed}……アンタの 最初の 刀、ホムラ。ひびが 入ってたね。", "{smile,up}アタシと 二人で 打ち直そう。親父の 刀の 結びも、その あとだ。"], eT);
    }
    await K.csay(p, "r3tombo", ["{sad,no}……殴らないッス。鍛冶屋の 手は、殴る ために あるんじゃ ないッス。", "{cry,tears,up}……受け取るッス。打った 人の 心は 刃に 出るって、親方が 言ってたッス。"], eV);   /*F24*/
    const eY = NP(K, p, "§eヨネ婆", "baba"); K.act(eY, "hold"); K.hold(eY, "hammer");
    await K.say(p, "ヨネ婆", ["{closed}……焼けた 村の、小さな 木槌じゃ。持ち主が 来るのを、十二年 待っとった。", "{smile}トンボ。……おまえの 手に 合う 大きさじゃろう。"], eT);
    await K.give(eY, eT, "hammer");
    await K.narr(p, ["§7トンボは 木槌を 握った。……焦げ跡の 手に、ぴったり だった。"], eT);   /*F60*/
    await K.bye(p, eT, eG, eV, eY);
    /* サンダ: 双子と シロウ・アミ婆の 手袋 */
    { const A = REC("r8yagura"); await goSet(K, p, A ? { x: A.x + 7, y: A.y - 3, z: A.z } : null, A, "らいうんの 里 サンダ"); }
    K.card(p, "§f― らいうんの 里 サンダ ―", 60);
    const eS = K.cast(p, "r8_shirou"); K.act(eS, "hold");
    await K.csay(p, "r8_shirou", ["{smile,…,up}……雪道の 向こうから、二つの 足音が するべさ。"]);
    const eRo = K.cast(p, "r8_rou"), eRu = K.cast(p, "r8_ruu"); K.act(eRo, "hold"); K.act(eRu, "hold");
    await K.two(p, eRo, eRu, 12);
    await K.csay(p, "r8_rou", ["{smile,up}……ただいま、兄ちゃん。"], eS);
    await K.csay(p, "r8_ruu", [c11 === "r" ? "{smile,tears,up}……手袋、ずっと 持ってたんだもん。" : "{smile,tears,up}……ただいま、だもん。"], eS);
    if (c11 === "k") { await K.narr(p, ["§7あなたは、ルウから 預かり直した 黒い 手袋を、シロウに 渡した。"], eS); }
    await K.up(p, eS, 12);
    face(K, eS, eRo);
    await K.csay(p, "r8_shirou", ["{cry,smile,tears,up}……ロウ。……ルウ。", "{smile}色 見なくても わかるべさ。声で わかるべさ。"], eRo);   /*F35*/
    const eAm = NP(K, p, "§eアミ婆", "baba"); K.act(eAm, "hold"); K.hold(eAm, "glove");
    await K.say(p, "アミ婆", ["{smile}右と 左、同じ 目で 編んだんじゃ。……両手に はめて ごらん。"], eRu);
    await K.give(eAm, eRu, "glove");
    await K.narr(p, ["§7二人は 新しい 手袋を 両手に はめた。白と 黒の 指輪の 半分は、手袋の 上から 指に。", "§7……そして 手袋の まま、手を つないだ。"], eRo);   /*F36*/
    face(K, eRo, eRu);
    await K.csay(p, "r8_rou", ["{smile}……手袋の ままでも、はなれないよ。"], eRu);
    await K.bye(p, eS, eRo, eRu, eAm);
    /* コラリア: 紐と 手紙（C20 で 届ける 人が 変わる）*/
    { const H = placeOf("harbor", 6, true); await goSet(K, p, H, null, "しおかぜの 港町 コラリア"); }
    K.card(p, "§f― しおかぜの 港町 コラリア ―", 60);
    const eM = K.cast(p, "r6marin"), eN = K.cast(p, "r6nagisa"); K.act(eM, "hold"); K.act(eN, "hold");
    const eC = c20 === "o" ? NP(K, p, "§eゼファード", "zephard") : ORDO(K, p); K.act(eC, "hold"); K.hold(eC, "rope");
    if (c20 === "o") {
      await K.low(p, eC, 14);
      await K.say(p, "ゼファード", ["{closed,low}……ナギサ。……マリン。"], eN);
      await K.narr(p, ["§7ナギサは 口の 中で 数を 数えた。……九十八、九十九、§f百§7。", "§7数え終えると、黙って 自分の 手首の 紐を 差し出した。"], eN);
      await K.csay(p, "r6nagisa", ["{cry,tears,up}……おかえり なさい。……かあさんの ぶんも。"], eC);
    } else {
      face(K, eC, eM);
      await K.say(p, "オルド", ["{closed}……二十年前、牧場で 一晩 かけて 紐を 編んだ 男が おった。名の ない 赤子の ためにな。", "{sad}その 男から、預かって きた。……おまえさんたちの 父親じゃ。"], eM);
    }
    await K.give(eC, eM, "rope");
    await K.narr(p, ["§7あなたは 風の 塔の 箱の §f紐§7 と §f手紙§7 を、マリンに 渡した。"], eM);
    setS(p, (s) => { if (Array.isArray(s.keys)) s.keys = s.keys.filter((x) => x !== "k_cord" && x !== "k_letter"); s.epx = { ...(s.epx || {}), cord6: 1, endM: 1 }; s.omamori = 1; });
    face(K, eM, eN);
    await K.csay(p, "r6marin", c16 === "r" ? ["{closed,…}……封、切れてる。", "{smile,tears}……先に、読んだんだ。いいよ。"] : ["{closed}……封、わたしが 切る。", "{shock,tears,up}『つけるなら、星の 名では なく、海の 名を』……かあさんが つけた 名前と、同じだ。"], eN);
    toP(K, p, eM);
    await K.csay(p, "r6marin", ["{smile,tears,up}……姉さんと 二人で、続きを 編む。"]);
    await K.bye(p, eM, eN, eC);
    /* グランディア城: ジンの 鞘（本3-8「あれが 静まった 日に、ここへ 返しに 来い」の 回収。第127版）*/
    { const C2 = placeOf("court", 2, true); await goSet(K, p, C2 ? { x: C2.x, y: C2.y, z: C2.z } : null, null, "廃都 グランディア城の 中庭"); }
    K.card(p, "§f― 廃都 グランディア城の 中庭 ―", 60);
    const wq2 = at2(K, p, 7, 2.6), eW2 = await K.put(p, "§7石に なった アサギ", wq2, null, K.PJ("kaori", 8)); if (ok(eW2)) K.turn(eW2, at2(K, p, 7, 2.6, 8));
    const eJ = K.cast(p, "r2jin"); K.hold(eJ, "katana");
    if (ok(eJ)) { await K.approach(p, eJ, eW2 || wq2, 1.6); K.act(eJ, "work"); }
    await K.pull(p, eJ, 18);
    await K.narr(p, ["§7石の 奥方の 前で、ジンが 鞘の ない 剣を 布で 磨いて いた。……荒野の 空が、澄んで いた。"], eJ);
    K.act(eJ, 0); toP(K, p, eJ);
    await K.up(p, eJ, 10);
    await K.csay(p, "r2jin", ["{closed}……来たか。", "{?,low}……静まったか。"]);
    if (ok(eJ)) await K.approach(p, eJ, p, 1.8);
    await K.narr(p, ["§7あなたは うなずいて、預かって いた §f鞘§7 を 差し出した。"], eJ);
    K.hold(eJ, "box"); K.sound(p, "random.click", 0.6);
    await K.up(p, eJ, 12);
    await K.csay(p, "r2jin", ["{closed,low}……傷 一つ ない。……おまえの 方が、よほど 大事に 持って いた。"]);
    K.turn(eJ, eW2 ? eW2.location : wq2); K.hold(eJ, "katana");
    if (ok(eJ)) await K.approach(p, eJ, eW2 || wq2, 1.4);
    K.sound(p, "random.click", 1);
    await K.push(p, eJ, 22, 3.6, 1.3);
    await K.narr(p, ["§7カチ、と 小さな 音が した。十二年、抜いた ままだった 剣が、鞘に 納まった。"], eJ);
    if (ok(eW2)) await K.ots(p, eJ, eW2, 10);
    await K.csay(p, "r2jin", ["{closed,low}……アサギ。静まったぞ。……剣を、納めた。", "{sad,low}夜明けには 戻ると 言って、十二年 かかった。"], eW2 || wq2);
    toP(K, p, eJ); await K.up(p, eJ, 10);
    await K.csay(p, "r2jin", ["{closed}礼を 言う。……待つのは 慣れて いる。これからは、剣を 納めた 手で 待つ。"]);
    K.act(eJ, "work"); K.turn(eJ, eW2 ? eW2.location : wq2);
    await K.pull(p, eW2 || eJ, 16);
    await K.bye(p, eJ, eW2);
    /* エンド: 鱗の 墓標と セオの 手帳 */
    const R9 = J("mrpg:epdeco:r9graveat");   /* 第126版(I1): 本14-9 で 建てた 鱗の 墓標（bk_b13 grave）と 同じ 場所。無い 世界だけ 小さく 建てる */
    { const G = (R9 && typeof R9.x === "number" ? R9 : null) || facAt("u_scalegrave") || facAt("u15grave"); const q = G ? { x: G.x - 3, y: G.y, z: G.z } : placeOf("stage", 9, true); await goSet(K, p, q, G, "終焉の 地 エンド"); }
    K.card(p, "§f― 終焉の 地 エンド 鱗の 墓標 ―", 60);
    const gv = R9 && typeof R9.x === "number" ? null : setB(K, p, "b20grave", [[4, 0, 0, 4, 0, 1, "prismarine_bricks"], [4, 0, 2, 4, 0, 2, "end_rod"], [3, -1, 0, 3, 1, 0, "moss_carpet", "keep"]], { D: 1, look: [4, 0], marks: { stone: [4, 0, 1.2] } });
    const gS = gv ? MK(gv, "stone") : { x: R9.x + 1.2, y: R9.y, z: R9.z };
    await K.at(p, gS || K.fwd(p, 4, 0, 1), 18, 3, 1);
    await K.narr(p, ["§7竜の 鱗を 重ねた 墓標の 横に、石に なった あの 子が 眠って いる。"], gS);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7あなたは セオの 手帳を 開いた。光に かざすと、影の にじみの 下から、最後の 頁の 一行が 浮かんだ。", "§f『魂の 帳に 名が なければ、呼び戻せる』"]);   /* 本20終話（植える）*/
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……あの子の におい、まだ ここに いる。……とおくで、まってる。"]); K.rmCine(g); }
    await K.narr(p, ["§7千年前の 友は、斬って 錠に した。……あなたは、斬らずに 名を 呼んだ。", "§7歴史は、くり返さなかった。"]);
    K.pay(p, E10, 50000, [["e_king", 1]]);
    try { showTitle(p, "§6§lマインクエスト", { subtitle: "§f― 第20章 歴史再び ―", fadeInDuration: 20, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
    try { for (const q of world.getAllPlayers()) q.sendMessage(`§6§l★ ${p.name}が 物語を 見届けた！ ★`); } catch {}
    await fin(K, p, { card: "§f― 本編 おわり ―\n§7→ 呼び戻す 道を さがそう（ガイドブック ＞ ストーリー）", kind: "day", t: 70 });
    return true;
  } };

bkAdd("b20", [E1, E2, E3, E4, E5, E6, E7, E8, E9, E10]);
/* MQ24 = b20e10（s.ending は FLAGFIX で 立つ）。前の 版で 終章に 入って いた 人（finIntro・final）も、本の 話が 済めば 進む */
mqOver(24, async (p, d, K, c) => c.play("b20e10"), { cond: async () => true });
try { const st = MQ[24]; if (st) { st.trig = (c) => !!c.s.ending || !(EP_HOOK.block && EP_HOOK.block(c.d, 1e9)); st.run = async () => true; st.hint = "§f王冠の 間の 石段を 上がろう §7（それぞれの 町へ）"; } } catch {}   /* 前の 版の 終章の 場面（墓・それぞれの 町・鍵の 外れた 夜）は 本20終話と 裏の 章へ */
