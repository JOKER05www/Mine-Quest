// 第106版: 冒険者協会の 依頼（F〜X級）・酒場・レストラン
// 依頼は 1つずつ 受ける。掲示板は 協会ごと・日ごとに かわる。報酬は 仲間を 強くする 道具・進化石・石板・タマゴ
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES, ORDER, EGGS } from "./data.js";
import { load, save } from "./store.js";
import { choose, notice, confirm, ICON, MON_ICON, giveItem, takeItem, countItem, sound, barNote, gold, ok } from "./ui.js";
import { battleHooks } from "./battle.js";
import { rankCap, storyLootOk } from "./quest.js";
import { exOf, exSave, giveGold, hash, dayNo, MATS } from "./explore.js";
import { spawnBoss } from "./explore2.js";
import { NPC_HOOKS } from "./npchook.js";
import { npcJob, townAt, castleInfo } from "./structures.js";
import { WREGIONS } from "./worldmap.js";

const B = (t, icon) => [t, icon];
const say = (p, m) => { try { p.sendMessage(m); } catch {} };
const rnd = () => Math.random();
export const GR = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
const GCOL = ["§7", "§f", "§a", "§b", "§9", "§d", "§6", "§c", "§4§l"];
export const gName = (r) => `${GCOL[r]}${GR[r]}級§r`;
const NEED = [0, 30, 90, 200, 380, 650, 1000, 1500, 2200];     /* 冒険者ランクに 上がる ための 合計 ポイント */
const PT = [10, 15, 22, 32, 45, 60, 80, 105, 140];            /* 依頼 1つの ポイント */
const LV = [8, 15, 24, 34, 46, 58, 72, 86, 100];             /* 手配モンスターの Lv */
const GOLD = [600, 1200, 2500, 5000, 9000, 16000, 30000, 55000, 100000];
const DIST = [120, 160, 220, 280, 340, 400, 460, 520, 600];   /* 調査・手配の 場所までの きょり */
const DAY_MAX = 6;                                            /* 1日に 報告できる 依頼の 数（全部の 協会で） */
const FAM = { blob: "粘液系", animal: "動物系", beast: "獣系", aqua: "水系", dragon: "竜系", golem: "物質系", sword: "剣系", nether: "魔系" };
const FAMS = Object.keys(FAM);
const MON_RANK = ["F", "E", "D", "C", "B", "A", "S", "SS"];

// ---------- 報酬 ----------
const STATS = ["hp", "mp", "atk", "def", "mat", "mdf", "spd", "wpn", "brt"];
const SL_F = ["blob", "beast", "aqua", "golem", "sword", "dragon", "animal", "nether"];
function pool(r) {
  const seed = (t) => STATS.map((s) => `s_${s}${t}`);
  const evo = Object.keys(ITEMS).filter((id) => ITEMS[id].kind === "evostone");
  const egg = (L) => L.filter((id) => EGGS[id]);
  const sl = (t) => [`sl${t}`, ...SL_F.map((f) => `sl${t}_${f}`)];
  const bs = Object.keys(ITEMS).filter((id) => ITEMS[id].kind === "bslab");
  const P = [
    { a: seed(""), b: ["lv_1", "f_exp", "c_herb2"], c: egg(["e_white", "e_bronze"]) },
    { a: seed(""), b: ["lv_1", "f_exp2", "g_sp"], c: [...egg(["e_bronze"]), "sl0"] },
    { a: [...seed(""), ...seed("2")], b: ["lv_3", "g_sp", ...evo], c: [...egg(["e_bronze", "e_silver"]), ...sl(0)] },
    { a: seed("2"), b: ["lv_3", "g_sp2", ...evo], c: [...egg(["e_silver", "e_red", "e_blue", "e_green", "e_black"]), ...sl(1)] },
    { a: [...seed("2"), ...seed("3")], b: ["lv_5", "g_sp2", "i_tal1", ...evo], c: [...egg(["e_silver", "e_red", "e_blue", "e_green", "e_black"]), ...sl(1), ...sl(2)] },
    { a: [...seed("3"), "s_all"], b: ["lv_5", "g_sp3", "i_tal1", "f_exp5k", ...evo], c: [...egg(["e_rainbow", "e_red", "e_blue"]), ...sl(2)] },
    { a: [...seed("3"), "s_all2", "s_allm"], b: ["lv_10", "g_sp3", "i_tal1", "i_limit", ...evo], c: [...egg(["e_rainbow"]), ...sl(3), ...bs] },
    { a: [...seed("4"), "s_all3"], b: ["lv_10", "g_sp4", "i_tal9", "i_limit", "i_trpick"], c: [...egg(["e_rainbow", "e_king"]), ...sl(3), ...bs] },
    { a: ["s_all4", "s_all3", ...seed("4")], b: ["i_lvmax", "i_plus10", "i_tal9", "g_sp4", "i_awaken"], c: [...egg(["e_king", "e_god"]), "sx_king", "sx_god", ...bs] },
  ][r];
  for (const k of ["a", "b", "c"]) P[k] = P[k].filter((id) => ITEMS[id]);
  return P;
}
/* 報酬を 決める（受けた ときに 決めて 見せる）。物語で まだ 出せない 物は 1つ 下の 物か お金に */
function rollReward(r, h, cap) {
  const out = [];
  for (const [k, n] of [["a", r >= 6 ? 2 : 1], ["b", 1], ["c", 1]]) {
    for (let j = 0; j < n; j++) {
      let id = null;
      for (let rr = r; rr >= 0 && !id; rr--) { const L = pool(rr)[k].filter((x) => storyLootOk(ITEMS[x], EGGS[x]?.ranks, cap)); if (L.length) id = L[(h >>> (3 * j + k.charCodeAt(0) % 7)) % L.length]; }
      if (id) out.push(id);
    }
  }
  return out;
}

// ---------- 掲示板 ----------
const pick = (L, h) => L[h % L.length];
function bossFor(r, h) {
  const R = MON_RANK[Math.min(7, Math.max(0, r - 1))];
  let L = ORDER.filter((s) => { const S = SPECIES[s]; return S && S.rank === R && !S.hidden && !S.fuseonly && !S.metalmon && S.fam !== "king" && S.fam !== "god"; });
  if (!L.length) L = ORDER.filter((s) => SPECIES[s] && SPECIES[s].wild && !SPECIES[s].hidden);
  return pick(L, h);
}
const EPI = ["畑を 荒らす", "旅人を おそう", "橋を こわした", "家畜を ねらう", "夜に あばれる", "商隊を おそった", "遺跡に 住みついた", "村を おびやかす", "湖を 毒した", "山道を ふさぐ"];
const WHO = ["農家の おばあさん", "宿屋の 主人", "見習い 騎士", "行商人", "漁師", "学者", "鍛冶屋", "教会の シスター", "子どもたち", "町長"];
/* 依頼 1つを 作る（k: 種類） */
function makeQ(src, r, h, cap, gx, gz) {
  const kinds = r <= 1 ? ["hunt", "deliver", "survey", "show"] : ["hunt", "deliver", "survey", "show", "boss", "boss"];
  const k = pick(kinds, h >>> 2);
  const who = pick(WHO, h >>> 5);
  const q = { id: `${src}:${dayNo()}:${h % 100000}`, r, k, who, rw: rollReward(r, h >>> 1, cap), g: GOLD[r], pt: PT[r] };
  if (k === "hunt") { q.fam = pick(FAMS, h >>> 7); q.c = 3 + ((h >>> 9) % 3) + Math.floor(r / 2); q.n = `${FAM[q.fam]}の モンスターを ${q.c}体 たおす`; }
  else if (k === "deliver") { const L = MATS.filter((id) => ITEMS[id]); q.item = pick(L, h >>> 7); q.c = 2 + r + ((h >>> 9) % 3); q.n = `${ITEMS[q.item].name}を ${q.c}こ とどける`; }
  else if (k === "show") { q.fam = pick(FAMS, h >>> 7); q.lv = Math.min(100, 10 + r * 11); q.n = `${FAM[q.fam]}の Lv${q.lv}以上の 仲間を 見せる`; }
  else {
    const a = ((h >>> 11) % 360) * Math.PI / 180, dd = DIST[r] + ((h >>> 13) % 60);
    q.x = Math.round(gx + Math.cos(a) * dd); q.z = Math.round(gz + Math.sin(a) * dd);
    if (k === "survey") q.n = `${dirName(gx, gz, q.x, q.z)}の ふしぎな 場所を 調べる（${dd}ブロック）`;
    else { q.sid = bossFor(r, h >>> 15); q.lv = LV[r]; q.epi = pick(EPI, h >>> 17); q.n = `手配: ${q.epi} ${SPECIES[q.sid]?.name || "モンスター"}（Lv${q.lv}）を たおす`; }
  }
  return q;
}
const dirName = (x0, z0, x1, z1) => { const a = Math.atan2(z1 - z0, x1 - x0) * 180 / Math.PI; const D = ["東", "南東", "南", "南西", "西", "北西", "北", "北東"]; return D[Math.round(((a + 360) % 360) / 45) % 8]; };
export function board(src, d, e, gx, gz) {
  const cap = rankCap(d), my = rankOf(e), top = Math.min(8, cap, my + 1), L = [];
  for (let k = 0; k < 6; k++) { const h = hash(`gq:${src}:${dayNo()}:${k}`); const r = Math.max(0, Math.min(top, top - 2 + (k % 3))); L.push(makeQ(src, r, h, cap, gx, gz)); }
  return L.sort((a, b) => a.r - b.r);
}
// ---------- 冒険者の 記録 ----------
function G(e) { e.gq = e.gq && typeof e.gq === "object" ? e.gq : {}; const g = e.gq; g.pt = g.pt || 0; g.n = g.n || 0; g.done = g.done && g.done.d === dayNo() ? g.done : { d: dayNo(), ids: [], x: [] }; g.done.x = g.done.x || []; return g; }
export const rankOf = (e) => { const p = e?.gq?.pt || 0; let r = 0; for (let k = 0; k < NEED.length; k++) if (p >= NEED[k]) r = k; return r; };
const qText = (q) => `${gName(q.r)} §f${q.n}`;
const rwText = (q) => [`§e${q.g.toLocaleString()} タヨ`, ...q.rw.map((id) => `§b${ITEMS[id]?.name || id}`)].join("§7・");

/* 達成 しているか（hunt・survey・boss は 記録、deliver・show は 報告の ときに 見る） */
function progressText(p, d, q) {
  if (q.k === "hunt") return `§f${Math.min(q.got || 0, q.c)} / ${q.c} 体`;
  if (q.k === "deliver") return `§fもって いる: ${countItem(p, `mrpg:${q.item}`)} / ${q.c} こ`;
  if (q.k === "show") return [...d.party, ...(d.bench || [])].some((m) => SPECIES[m.sp]?.fam === q.fam && m.lv >= q.lv) ? "§a条件に あう 仲間が いる" : "§7条件に あう 仲間が いない";
  const dd = Math.round(Math.hypot(p.location.x - q.x, p.location.z - q.z));
  return q.ok ? "§a達成！ 協会に 報告しよう" : `§f目的地: ${dirName(p.location.x, p.location.z, q.x, q.z)}へ ${dd}ブロック §7(x ${q.x}, z ${q.z})`;
}
function canReport(p, d, q) {
  if (q.k === "hunt") return (q.got || 0) >= q.c;
  if (q.k === "deliver") return countItem(p, `mrpg:${q.item}`) >= q.c;
  if (q.k === "show") return [...d.party, ...(d.bench || [])].some((m) => SPECIES[m.sp]?.fam === q.fam && m.lv >= q.lv);
  return !!q.ok;
}
async function report(p, q) {
  const e = exOf(p), g = G(e);
  if (g.done.ids.length >= DAY_MAX) { await notice(p, "冒険者協会", `§7今日は もう ${DAY_MAX}つ 報告した。明日 また 来てね`); return false; }
  if (q.k === "deliver" && !takeItem(p, `mrpg:${q.item}`, q.c)) return false;
  const d = load(p); if (!d) return false;
  const cap = rankCap(d), got = [giveGold(d, q.g)];
  save(p, d);
  for (const id of q.rw) { if (!ITEMS[id] || !storyLootOk(ITEMS[id], EGGS[id]?.ranks, cap)) continue; giveItem(p, `mrpg:${id}`, 1); got.push(`§b${ITEMS[id].name}`); }
  const r0 = rankOf(e); g.pt += q.pt; g.n++; g.done.ids.push(q.id); g.cur = null; exSave(p, true);
  const r1 = rankOf(e);
  sound(p, "random.levelup");
  await notice(p, "依頼 達成！", `§f${q.who}「ありがとう！ たすかったよ」\n\n§6ほうび: ${got.join("§7・")}\n§f冒険者ポイント §e+${q.pt}§7（合計 ${g.pt}）`);
  if (r1 > r0) { sound(p, "ui.toast.challenge_complete"); await notice(p, "冒険者ランク アップ！", `§f受付「おめでとうございます！ あなたは 今日から ${gName(r1)} §fの 冒険者です」\n§7${r1 < 8 ? `${gName(Math.min(8, r1 + 1))} §7の 依頼まで 受けられる` : "§7すべての 依頼を 受けられる"}`); }
  return true;
}
async function current(p) {
  for (;;) {
    const d = load(p); if (!d) return; const e = exOf(p), g = G(e), q = g.cur;
    if (!q) { await notice(p, "受けている 依頼", "§7いまは 何も 受けて いない"); return; }
    const c = await choose(p, "受けている 依頼", `${qText(q)}\n§7依頼人: ${q.who}\n${progressText(p, d, q)}\n\n§6ほうび: ${rwText(q)}`, [B(canReport(p, d, q) ? "§a§l報告する" : "§7報告する（まだ）", ICON("i_help")), B("§cあきらめる", ICON("i_back")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) { if (!canReport(p, d, q)) { await notice(p, "依頼", "§7まだ 終わって いない"); continue; } await report(p, q); return; }
    if (c === 1) { if (await confirm(p, "依頼", "§fこの 依頼を あきらめる？\n§7（ポイントは 減らない。今日は もう 受けられない）", "あきらめる", "やめる")) { const e2 = exOf(p), g2 = G(e2); if (g2.cur) g2.done.x.push(g2.cur.id); g2.cur = null; exSave(p, true); } return; }
    return;
  }
}
async function boardMenu(p, src, gx, gz, title) {
  for (;;) {
    const d = load(p); if (!d) return; const e = exOf(p), g = G(e);
    const L = board(src, d, e, gx, gz), my = rankOf(e), top = Math.min(8, rankCap(d), my + 1);
    const c = await choose(p, title, `§fあなたの ランク: ${gName(my)} §7（${top > my ? `${gName(top)} §7まで 受けられる` : "いまの ランクまで"}）\n§7掲示板は 毎日 かわる・1日 ${DAY_MAX}つまで 報告できる`,
      [...L.map((q) => B(`${g.done.ids.includes(q.id) || g.done.x.includes(q.id) ? "§8済 " : g.cur?.id === q.id ? "§a受注中 " : ""}${gName(q.r)} §0${q.n}`, ICON("i_help"))), B("§7戻る", ICON("i_back"))]);
    const q = L[c]; if (!q) return;
    if (g.done.ids.includes(q.id) || g.done.x.includes(q.id)) { await notice(p, "依頼", "§7この 依頼は もう 終わった"); continue; }
    if (g.cur && g.cur.id === q.id) { await current(p); continue; }
    if (g.cur) { await notice(p, "依頼", `§7受けられる 依頼は 1つだけ。いまの 依頼:\n${qText(g.cur)}`); continue; }
    if (!(await confirm(p, `${GR[q.r]}級の 依頼`, `${qText(q)}\n§7依頼人: ${q.who}\n\n§6ほうび: ${rwText(q)}\n§f冒険者ポイント +${q.pt}`, "受ける", "やめる"))) continue;
    const e2 = exOf(p), g2 = G(e2); if (g2.cur) continue; g2.cur = { ...q, got: 0 }; exSave(p, true);
    sound(p, "random.orb"); say(p, `§6[依頼] ${GR[q.r]}級「${q.n}」を 受けた`);
  }
}
async function card(p) {
  const e = exOf(p), g = G(e), r = rankOf(e);
  await notice(p, "冒険者カード", [`§f冒険者ランク: ${gName(r)}`, `§fポイント: §e${g.pt}${r < 8 ? ` §7/ 次の ランク ${NEED[r + 1]}` : ""}`, `§f達成した 依頼: §e${g.n}`, `§f今日の 報告: §e${g.done.ids.length} / ${DAY_MAX}`, "", "§7ランクは F→E→D→C→B→A→S→SS→X。物語を 進めると 上の 級の 依頼が 出る"].join("\n"));
}
export async function guildMenu(p, src, at) {
  const gx = Math.floor(at.x), gz = Math.floor(at.z);
  for (;;) {
    const e = exOf(p), g = G(e);
    const c = await choose(p, "冒険者協会", `§f受付「ようこそ、冒険者協会へ！ 町の 人の 困りごとを あつめて います」\n§7ランク ${gName(rankOf(e))} §7・受注中: ${g.cur ? g.cur.n : "なし"}`,
      [B("§6§l依頼掲示板\n§8F〜X級の 依頼", ICON("i_help")), B("§l受けている 依頼\n§8報告・あきらめる", ICON("i_zukan")), B("§l冒険者カード", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) await boardMenu(p, src, gx, gz, "依頼掲示板");
    else if (c === 1) await current(p);
    else if (c === 2) await card(p);
    else return;
  }
}
// ---------- 酒場・レストラン ----------
const DRINK = [["fd_tea", "薬草ミルク", 400], ["fd_soup", "あたたかい スープ", 600], ["fd_egg", "温泉卵の つまみ", 500]];
const DISH = [["fd_stew", "地方の シチュー", 900], ["fd_curry", "火山カレー", 1500], ["fd_cake", "天空ケーキ", 1100], ["fd_bento", "旅の 弁当", 1000], ["fd_onigiri", "おにぎり定食", 700]];
const RUMOR = [
  "最近 北の 山で 大きな 影を 見た って 冒険者が 言ってたぜ",
  "協会の 掲示板は 毎朝 はりかわる。いい 依頼は 早い者勝ちさ",
  "ランクを 上げると 石板や タマゴの 依頼が 出てくる らしい",
  "手配モンスターは 仲間に できない。だが ほうびは でかいぞ",
  "噂じゃ『邪闘十魔将』とか いう 連中が 各地で うごいて いる……",
  "六影の 下っぱが このへんを うろついてたよ。気をつけな",
  "遠くの 調査依頼は 地図の 座標を 見ると 迷わないぜ",
  "うちの 料理人の カレーを 食うと 力が わいて くるんだ",
];
async function eat(p, title, L, line) {
  const d = load(p); if (!d) return;
  const c = await choose(p, title, `§f${line}\n§7食べると 次の 戦い 3回 仲間が 強く なる §8（お金 ${gold(d.gold || 0)}）`, [...L.filter(([id]) => ITEMS[id]).map(([id, n, pr]) => B(`§l${n}\n§8${pr} タヨ`, ICON("i_shop"))), B("§7戻る", ICON("i_back"))]);
  const it = L.filter(([id]) => ITEMS[id])[c]; if (!it) return;
  const d2 = load(p); if (!d2 || (d2.gold || 0) < it[2]) { await notice(p, title, "§7お金が たりない"); return; }
  d2.gold -= it[2]; save(p, d2);
  const e = exOf(p); e.food = { k: it[0], n: 3 }; e.ck2 = (e.ck2 || 0) + 1; exSave(p, true);
  sound(p, "random.burp"); await notice(p, title, `§a${it[1]}を 味わった！ §f次の 戦い 3回 強く なる`);
}
async function tavern(p, e0) {
  const at = e0.location;
  for (;;) {
    const c = await choose(p, "酒場", "§fマスター「いらっしゃい。旅の 話でも 聞いて いくかい？」", [B("§l飲みものを たのむ", ICON("i_shop")), B("§lうわさ話を 聞く", ICON("i_help")), B("§6§l酒場の 依頼\n§8冒険者からの 頼み", ICON("i_help")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) await eat(p, "酒場", DRINK, "マスター「何に する？」");
    else if (c === 1) { const k = hash(`rm:${dayNo()}:${p.id}:${Math.floor(Date.now() / 60000)}`) % RUMOR.length; await notice(p, "うわさ話", `§fマスター「${RUMOR[k]}」`); }
    else if (c === 2) await boardMenu(p, `tv${Math.floor(at.x / 64)}_${Math.floor(at.z / 64)}`, at.x, at.z, "酒場の 依頼");
    else return;
  }
}
// ---------- 依頼の 進み ----------
battleHooks.push((B0, x) => {
  const { p } = x; try { if (!p.isValid()) return; } catch { return; }
  if (B0.result !== "win" || B0.pvp) return;
  const e = exOf(p), q = e.gq?.cur; if (!q) return;
  if (q.k === "hunt" && !B0.master) {
    const n = (B0.enemies || []).filter((f) => SPECIES[f.m?.sp]?.fam === q.fam).length; if (!n) return;
    q.got = Math.min(q.c, (q.got || 0) + n); exSave(p, true);
    try { barNote(p).setActionBar(`§6[依頼] ${FAM[q.fam]} ${q.got} / ${q.c}${q.got >= q.c ? " §a達成！ 協会に 報告しよう" : ""}`); } catch {}
  } else if (q.k === "boss" && (B0.wtags || []).includes("mrpg_gq")) {
    q.ok = true; exSave(p, true); say(p, "§6[依頼] 手配モンスターを たおした！ 協会に 報告しよう");
  }
});
const BOSS = new Map();   // 人 → 出した 手配モンスターの id
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try {
      if (p.dimension.id !== "minecraft:overworld") continue;
      const e = exOf(p), q = e.gq?.cur; if (!q || q.ok || (q.k !== "survey" && q.k !== "boss")) continue;
      const L = p.location, dd = Math.hypot(L.x - q.x, L.z - q.z);
      if (dd > 40) { try { barNote(p).setActionBar(`§6[依頼] §f${dirName(L.x, L.z, q.x, q.z)}へ ${Math.round(dd)}ブロック`); } catch {} continue; }
      if (q.k === "survey") { if (dd < 6) { q.ok = true; exSave(p, true); sound(p, "random.orb"); say(p, "§6[依頼] 調査を 終えた！ ふしぎな 足あとを 記録した。協会に 報告しよう"); } else try { barNote(p).setActionBar(`§6[依頼] §fもうすこし… あと ${Math.round(dd)}ブロック`); } catch {} continue; }
      const id = BOSS.get(p.id); let live = false; if (id) try { const b = world.getEntity(id); live = ok(b); } catch {}
      if (!live) { const b = spawnBoss(p, q.sid, q.lv, "mrpg_gq", `【手配】${q.epi}`, null, 0); if (b) { BOSS.set(p.id, b.id); say(p, `§c[依頼] 手配モンスターが あらわれた！`); } }
    } catch {}
  }
}, 40);
world.afterEvents.playerLeave?.subscribe?.(({ playerId }) => { const id = BOSS.get(playerId); BOSS.delete(playerId); if (id) try { world.getEntity(id)?.remove(); } catch {} });
// ---------- 話しかけ ----------
NPC_HOOKS.push((p, e) => {
  const j = npcJob(e);
  if (j === 22) { const at = e.location; const t = townAt(at, 60); system.run(() => guildMenu(p, t ? t.id : `g${Math.floor(at.x / 64)}_${Math.floor(at.z / 64)}`, at)); return true; }
  if (j === 20) { system.run(() => tavern(p, e)); return true; }
  if (j === 21) { system.run(() => eat(p, "レストラン", DISH, "料理人「今日の おすすめは どれも 自信作だよ！」")); return true; }
  return false;
});
export const __guild = { board, makeQ, rollReward, pool, G, rankOf, NEED, report, canReport };
