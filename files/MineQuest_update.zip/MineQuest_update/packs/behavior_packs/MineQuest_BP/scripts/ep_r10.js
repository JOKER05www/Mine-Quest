/* 第125版: 第11地方 セレスティア（かぜの 塔の 町 ゼファー・雲の 島）の 5話
   1 空の 声（collapse.js: 世界中の 人が 影を 知る・世界の 今）→ 1 風の 町（塔守 カザミ翁。塔は「二十年前、ひとりの 旅人が 建てた」）
   → 2 手帳（旅人が 残した 箱。古い インクと 出せなかった 手紙。風車を 直し、石に なった 孫の 名前を 書く）
   → 3 雲の 島（六影の 名を かたる 残党 ドンゴと チョロ）→ 4 レイの 理由（雲の 島の 小屋）
   → 5 最後の 勝負（今の 段）→ 5 門番の 旅（ゴンザが 送り出しに 来る）→ ルミナの 鐘・旅立ちの 道（collapse.js）
   旅の 仲間は もう いない（台詞なし）。レイが 付き添う
   第125版(ce): 章の 問い「帰る 場所は、まだ あるか」。塔の 星見の 間（epfac windroom）・雲の 島の 端（cloudedge）。伏線: 遠めがね・星図・編みかけの 紐（ゼファードの 海）／鐘の 縁の「名は 三度 呼べ」（歓声の 掟）。/tmp/zf/celestia125.md */
import { epAdd } from "./sagaep.js";
import { castAdd, doomed, doomKnown } from "./cast.js";
import { placeOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, groundY } from "./structures.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok, choose } from "./ui.js";
import { fac } from "./epfac.js";
import { SPECIES, ORDER } from "./data.js";
import { ZEPH_OUT } from "./collapse.js";
import { WREGIONS } from "./worldmap.js";

const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* 第125版(rs): b の そば k マス */
/* ---------- 場所 ---------- */
const zeph = () => { const t = TOWNS.find((u) => u.id === "t55"); if (!t) return null; const g = getTown("t55"); return g && g.built ? { x: g.x, y: g.y, z: g.z } : townPos(t); };
const ISLE = () => { const q = placeOf("stage", 10); return q ? { x: q.x, z: q.z, nm: "雲の 島の 端" } : null; };
const ISLE_ROAD = () => { const a = zeph(), b = placeOf("stage", 10); if (!a || !b) return ISLE(); return { x: Math.floor(a.x + (b.x - a.x) * 0.55), z: Math.floor(a.z + (b.z - a.z) * 0.55), nm: "雲の 島へ 渡る 道" }; };
const HUT = () => { const a = zeph(), b = placeOf("stage", 10); if (!b) return null; if (!a) return { x: b.x - 22, z: b.z, nm: "雲の 島の 小屋" }; const L = Math.hypot(a.x - b.x, a.z - b.z) || 1; return { x: Math.floor(b.x + ((a.x - b.x) / L) * 24), z: Math.floor(b.z + ((a.z - b.z) / L) * 24), nm: "雲の 島の 小屋" }; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("kazami", { nm: "カザミ翁", role: "塔守", gobi: "じゃて", skin: "m6_sage", town: "t55", from: "r10e1",
  at: () => { const o = ZEPH_OUT(); return o ? { x: o.x + 10, z: o.z - 4 } : null; },
  pre: ["{smile}風の 町 ゼファーへ よう 来なすったんじゃて。"],
  after: [
    [(s) => !!s.ending, ["{smile}風車が 回って おるんじゃて。……塔を 建てた あの 旅人も、どこかで 見て おるじゃろう。", "{closed}手紙は、いつか 届くべき 人に 届くんじゃて。"]],
    [(s) => doomKnown(s) && !!st(s).mill10, ["{smile}風が もどった おかげで、灰も 町に 積もらんのじゃて。", "{closed}……孫の フウタは、毎朝 手帳の 字を 見せて くれと 言うんじゃて。あんたの 字が、好きなんじゃと。"]],
    [(s) => doomKnown(s), ["{sad}……風が 止まって しもうたんじゃて。風車も、塔の 鐘も、だまった ままじゃて。"]],
    [() => true, ["{smile}この 塔は、二十年前に ひとりの 旅人が 建てたんじゃて。"]],
  ] });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
const DRAG = () => (SPECIES.hdra12 ? "hdra12" : ORDER.find((x) => SPECIES[x].fam === "dragon" && SPECIES[x].sz === "L" && !SPECIES[x].hidden) || ORDER[0]);
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
/* 風の 塔（ワールドに 1回。舞台から 14マス はなれた 所）と 風車の 羽（+ と × を 入れかえて 回る）*/
function towerAt(p, c, y0) {
  const T = { x: Math.floor(c.x) - 14, z: Math.floor(c.z) - 6 };   /* 第124版: 町と 反対側（町の 中に 建てない）*/
  for (const [a, b] of [[0, 0], [0, 12], [-4, 6], [-6, -6], [-6, 12]]) {   /* 第124版: 地面が なければ 同じ 側の ほかの 場所も さがす（空を 映さない）*/
    const q = { x: T.x + a, z: T.z + b }; let y = null; try { y = groundY(p.dimension, q.x, q.z, y0 + 6); } catch {}
    if (typeof y === "number" && Math.abs(y - y0) <= 5) return { ...q, y };
  }
  return { ...T, y: y0, no: true };   /* 地面が ない ときは 建てない */
}
/* 第125版(ce): 風の 塔の 星見の 間（epfac の windroom・ワールドに 1回）。新しい ワールドでは この 部屋の 上の 柱が 塔（T = 柱の 根もと）*/
const RAW = (k) => { try { return JSON.parse(world.getDynamicProperty(`mrpg:epdeco:${k}at`) || "null"); } catch { return null; } };
const LW = (v, a, b, h = 0) => ({ x: v.o[0] + a * v.f[0] - b * v.f[1] + 0.5, y: v.o[1] + h, z: v.o[2] + a * v.f[1] + b * v.f[0] + 0.5 });
const MK = (v, n) => { const m = v && v.m && v.m[n]; return m ? { x: m[0], y: m[1], z: m[2] } : null; };
function room(K, p, y0, build = true) {
  let v = RAW("r10room"); if (!v && build) { fac(K, p, "r10room", "windroom", 10, y0); v = RAW("r10room"); }
  return v && Array.isArray(v.o) && Math.hypot(v.x - p.location.x, v.z - p.location.z) < 72 ? v : null;
}
/* レンズの ない 遠めがね: 部屋の 窓ぎわに、海（マリノア）の 方角へ 向けて 固める（ワールドに 1回）*/
function seaGlass(K, p, v) {
  const k = "mrpg:epdeco:r10glass"; let g = null; try { g = JSON.parse(world.getDynamicProperty(k) || "null"); } catch {} if (g && typeof g.x === "number") return g;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  const R = WREGIONS[6], c = LW(v, 4, 0), sx = R ? s0.x + R.c[0] - c.x : 1, sz = R ? s0.z + R.c[1] - c.z : 0, fx = v.f[0], fz = v.f[1];
  const da = sx * fx + sz * fz, db = -sx * fz + sz * fx, [ua, ub] = Math.abs(db) >= Math.abs(da) ? [0, Math.sign(db) || 1] : [Math.sign(da) || 1, 0];
  const q = LW(v, 4 + ua * 2, ub * 2), wx = ua * fx - ub * fz, wz = ua * fz + ub * fx, fd = wx > 0 ? 5 : wx < 0 ? 4 : wz > 0 ? 3 : 2, X = Math.floor(q.x), Z = Math.floor(q.z);
  K.cmd(p, `setblock ${X} ${v.o[1]} ${Z} birch_fence`); K.cmd(p, `setblock ${X} ${v.o[1] + 1} ${Z} lightning_rod ["facing_direction"=${fd}]`);
  g = { x: X + 0.5, y: v.o[1] + 1.2, z: Z + 0.5, wx, wz }; try { world.setDynamicProperty(k, JSON.stringify(g)); } catch {}
  return g;
}
function tower(K, p, c, y0) {
  const T = towerAt(p, c, y0), k = "mrpg:epdeco:r10tower";
  let v = 0; try { v = Number(world.getDynamicProperty(k) || 0); } catch {}
  if (!v) { const R = room(K, p, y0); if (R) { const q = LW(R, 4, 0), A = { x: Math.floor(q.x), y: R.o[1] + 6, z: Math.floor(q.z), room: 1 }; mill(K, p, A, 0); try { world.setDynamicProperty(k, 1); world.setDynamicProperty(`${k}at`, JSON.stringify(A)); } catch {} return A; } }   /* 第125版(ce): 部屋つきの 塔 */
  if (v) { let A = null; try { A = JSON.parse(world.getDynamicProperty(`${k}at`) || "null"); } catch {} if (A && typeof A.x === "number") return A; const o = { x: Math.floor(c.x) + 14, z: Math.floor(c.z) - 6 }; let y = null; try { y = groundY(p.dimension, o.x, o.z, y0 + 6); } catch {} return { ...o, y: typeof y === "number" && Math.abs(y - y0) <= 5 ? y : y0 }; }   /* 前の 版で 建てた 塔 */
  const f = (a, b, cc, d, e, g, bl) => K.cmd(p, `fill ${a} ${b} ${cc} ${d} ${e} ${g} ${bl} keep`);
  if (T.no) { delete T.no; f(T.x - 1, T.y - 8, T.z - 1, T.x + 1, T.y - 1, T.z + 1, "stone_bricks"); }   /* 第124版: 地面が なくても 土台ごと 建てて 記録する（あとの 話で 初めて 建つ ことが ない ように）*/
  f(T.x - 1, T.y, T.z - 1, T.x + 1, T.y + 9, T.z + 1, "stone_bricks");
  f(T.x - 2, T.y + 10, T.z - 2, T.x + 2, T.y + 10, T.z + 2, "spruce_slab");
  K.cmd(p, `setblock ${T.x} ${T.y + 11} ${T.z} bell keep`);
  for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) K.cmd(p, `setblock ${T.x + a} ${T.y + 11} ${T.z + b} lantern keep`);
  mill(K, p, T, 0);
  try { world.setDynamicProperty(k, 1); world.setDynamicProperty(`${k}at`, JSON.stringify(T)); } catch {}
  return T;
}
function mill(K, p, T, ph) {
  if (T.no) return;
  const x = T.x - 2, hy = T.y + 7;
  K.cmd(p, `fill ${x} ${hy - 3} ${T.z - 3} ${x} ${hy + 3} ${T.z + 3} air replace white_wool`);
  for (let i = -3; i <= 3; i++) {
    if (ph % 2 === 0) { K.cmd(p, `setblock ${x} ${hy + i} ${T.z} white_wool keep`); K.cmd(p, `setblock ${x} ${hy} ${T.z + i} white_wool keep`); }
    else { K.cmd(p, `setblock ${x} ${hy + i} ${T.z + i} white_wool keep`); K.cmd(p, `setblock ${x} ${hy + i} ${T.z - i} white_wool keep`); }
  }
}

/* ---------- 1話 風の 町 ---------- */
/* 第125版(ce): 原因 = 竜を 治す はずの 風が 止まった ／ 目的 = 風が 止まった わけ ／ 障害 = 風車を 直して いた フウタが 石・声では 戻らない ／ 選択 = 翁が 二十年 見せなかった 箱を 見せる */
const toward = (e, q, k) => { if (!ok(e) || !q) return q; const A = e.location, dx = A.x - q.x, dz = A.z - q.z, n = Math.hypot(dx, dz) || 1; return { x: q.x + (dx / n) * k, y: A.y, z: q.z + (dz / n) * k }; };   /* q の k マス 手前 */
const FUTA = (R, K, p) => (R ? LW(R, -1.5, -3.5) : K.fwd(p, 5, -2.5));   /* 石の フウタは 塔の 戸口の そば */
const DOOR = () => { const v = RAW("r10room"); if (!v || !Array.isArray(v.o)) return ZEPH_OUT(); const q = LW(v, -4, 0); return { x: Math.floor(q.x), z: Math.floor(q.z), nm: "風の 塔の 戸口" }; };
const E1 = { id: "r10e1", n: 2, t: "風の 町", at: 0, ord: 1, place: ZEPH_OUT,
  hint: "§fかぜの 塔の 町 §eゼファー§f の 外れ（風の 塔の 下）で、塔守の 話を 聞こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "風の 止まった ゼファーで、塔守の カザミ翁に 会った。町の 外れの 塔は「二十年前、ひとりの 旅人が 建てた」もの。背の 高い 無口な 男で、毎晩 遠くの 空ばかり 見て いた。塔の 戸口の そばで、風車を 直して いた 孫の フウタが 石に なって いた。町の 人は 毎朝、フウタの 名を 三度 呼ぶ。旅人が 鐘の 縁に 刻んで いった 決まり「帰らぬ 者の 名は、三度 呼べ」。……声だけでは、戻らなかった。カザミ翁は、二十年 だれにも 見せなかった 旅人の 箱を、あなたたちに 見せると 言った。",
  set: { met10: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), T = tower(K, p, c, y0), R = room(K, p, y0, false), BELL = (R && MK(R, "bell")) || { x: T.x, y: T.y + 10, z: T.z };
    await K.open(p, "ゼファーの 外れ（風の 塔の 下）", "ash");
    K.sound(p, "ambient.weather.thunder", 0.8, 0.3);
    await K.at(p, { x: T.x, y: T.y + 8, z: T.z }, 18, 9, 0);
    await K.narr(p, ["§7石の 塔が、灰の 空に 細く 立って いる。", "§7塔の 風車は、ぴたりと 止まった まま だった。"], { x: T.x, y: T.y + 6, z: T.z });
    const eR = REI(K, p); K.act(eR, "hold");
    if (ok(eR)) { await K.walkCam(p, eR, toward(eR, R ? MK(R, "front") : { x: T.x + 3, y: y0, z: T.z + 2 }, R ? 3 : 0), 18); K.turn(eR, { x: T.x, y: T.y + 8, z: T.z }); }   /* 止まった 風車の 塔を 見上げる */
    await K.say(p, "レイ", ["{closed}……風の 町なのに、風が ない。……灰の せいか。", "{sad}……これじゃ、島の 端の 竜に 風が 届かねえ。"]);
    K.turn(eR);
    const eK = K.cast(p, "kazami"); K.act(eK, "hold");
    await K.csay(p, "kazami", ["{smile}ほう、旅の 人かね。こんな 空の 日に、よう 来なすったんじゃて。", "{closed}わしは カザミ。この 塔の 番を して おる じじいじゃて。"]);
    await K.say(p, "レイ", ["{?}……塔の 番？ 町の 塔じゃ ないのか。"], eK);
    K.act(eK, "point");
    await K.csay(p, "kazami", ["{closed}この 塔は、二十年前に ひとりの 旅人が 建てたんじゃて。", "{smile}背の 高い、無口な 男じゃった。星を 見る ための 塔じゃと 言うて、一人で 石を 積んだんじゃて。"]);
    K.act(eK, 0);
    await K.push(p, eK, 22, 4.2, 1.7);
    await K.csay(p, "kazami", ["{sad,up}毎晩 塔に こもって、遠くの 空ばかり 見とったんじゃて。……あれは、だれかを 思う 目じゃった。"]);
    K.re(eR, "shock", "…");
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{shock,…,up}……背の 高い、星を 見る 男。", "{closed}ガキの ころ、ノルじいの 昔話で 聞いた。……じいちゃんと、いつも 一緒だった やつ。"]);
    await K.csay(p, "kazami", ["{?}ほう？ ……旅人は 塔を 建てると、ある 冬の 朝、いなく なったんじゃて。", "{closed}塔に、箱を 一つ 残して な。……鍵穴も、ふたの すき間も ない 箱じゃて。"]);
    /* 石に なった 孫（塔の 戸口の そば）*/
    const eF = await K.put(p, "§7石に なった フウタ", FUTA(R, K, p), R ? MK(R, "door") : null, K.PJ("m6_sota", 9)); K.act(eF, "up");   /* 石の 子は 歩いて 来ない（暗転の 中で 立たせる）*/
    if (ok(eK) && ok(eF)) { await K.walkCam(p, eK, nearPt(eK, eF, 1.2), 16); K.act(eK, "kneel"); }   /* 翁が 石の 孫の 前へ 歩いて ひざを つく */
    await K.at(p, eF ? eF.location : K.fwd(p, 4), 12, 3, 1.2);
    await K.csay(p, "kazami", ["{sad,up}……空から 声が した 朝、孫の フウタが 石に なって しもうたんじゃて。", "{cry,tears,up}塔の 上で、風車の 羽を 直して おった ところ じゃった。……風が 止まったのも、その 朝じゃて。"]);
    /* 町の 人が 来て、名を 三度 呼ぶ（旅人の 決まり）*/
    const eW = K.npcNear(p, "§f粉ひきの ミサ", K.PJ("hanna", 8)), eG = K.npcNear(p, "§f大工の ゴロ", K.PJ("m6_genzo", 8));
    await Promise.all([ok(eW) && ok(eF) ? K.go(eW, nearPt(eW, eF, 1.7), 22) : 0, ok(eG) && ok(eF) ? K.go(eG, nearPt(eG, eF, 2.1), 24) : 0]);
    await K.narr(p, ["§7灰の 中を、町の 人が 二人 歩いて きた。……石の 子の 前に、だまって 立つ。"], eF);
    K.act(eW, "hold");
    await K.say(p, "粉ひきの ミサ", ["{sad,up}……フウタ。"]);
    await K.say(p, "大工の ゴロ", ["{sad,up}フウタ。"]);
    await K.csay(p, "kazami", ["{closed,up}……フウタや。"]);
    await K.narr(p, ["§7三度。……石の 子は、答えなかった。"], eF);
    await K.csay(p, "kazami", ["{closed}……塔の 旅人が 残して いった 決まりじゃて。鐘の 縁に、刻んで あるんじゃ。"]);
    K.sound(p, "block.bell.hit", 0.25);
    await K.at(p, BELL, 16, 3.5, 0.3);
    await K.narr(p, ["§7塔の 上の 鐘。縁に、細い 字が 刻まれて いる。", "§f『帰らぬ 者の 名は、三度 呼べ。呼ばれる 名は、迷わない』"], BELL);
    await K.say(p, "レイ", ["{sad,up}……届いて ねえじゃ ねえか。"], eK);
    await K.csay(p, "kazami", ["{sad,up}それでも 呼ぶんじゃて。……呼ぶのを やめたら、ほんとうに いなく なって しまうでな。"], eR);
    K.act(eW, 0);
    await Promise.all([K.leave(eW, p, 9, false), K.leave(eG, p, 9, false)]);   /* 町の 人は 一礼して 町へ もどる */
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{sad,up}……声だけじゃ、戻らねえのか。", "{closed}……さっきの 商人が 言ってた。名を 呼んで、記録の インクで 書けば 戻るって。……インクなら、灰の 中で 拾った。"]);
    await K.narr(p, ["§7あなたは かばんから 旅の 手帳を 出した。……あの子の 丸い 字で 書いた 名前の 頁が、風の ない 空気の 中で 重かった。"], eK);
    await K.csay(p, "kazami", ["{closed}……その 手帳に、名前を 書いて 歩いとる 人かね。", "{closed,up}……一つ、ためして みたい ことが あるんじゃて。旅人の 箱は、塔の 中に ある。"]);
    await K.csay(p, "kazami", ["{sad,up}二十年、だれにも 見せなんだ 箱じゃて。……あんたらには、見せようと 思う。"]);
    K.pay(p, E1, 2000, [["x_celes", 2]]);
    K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 0 0 0"); await K.wait(10);
    await K.end(p, { leave: [eK], bye: [eR, eF], card: "§7→ 風の 塔の 戸口へ（カザミ翁が 旅人の 箱を 出して 待って いる）", kind: "ash" });
    return true;
  } };

/* ---------- 2話 手帳（風の 塔の 星見の 間）---------- */
/* 第125版(ce): 原因 = 翁が 箱を 出す ／ 目的 = 箱を 開け、フウタを 戻す ／ 障害 = 鍵穴が ない・インクの 決まり ／ 選択 = 最初に 書く 名（フウタ／旅の 仲間）／ 結果 = 風が もどり、レイは 竜の もとへ 急ぐ
   塔の 中: 出せなかった 手紙・箱の 底の 編みかけの 紐（三つ目ごとに 一つ 返す）・レンズの ない 遠めがね（海の 方角に 固めて ある）・星図の 写し（港の 灯り）・ラベルの 決まり・手帳の 初めの 頁の 古い 紙きれ */
const LETTER = ["§f『§8（宛名は しみで にじんで 読めない）§fへ。", "§f紐の お守りは、まだ 編めない。ほどいては 編み、ほどいては 編み、とうとう 冬に なった。", "§fこの 塔からは、おまえたちの 眠る 港の 灯りは 見えない。それでも 毎晩、同じ 海の 方角を 見て いる。", "§f父さんは、幕を 引きに 行く。幕を 上げた 者の、役目だから。", "§fいつか この 手紙を 出せる 日が 来たら――』", "§8（そこで 字は とぎれて いる。名前は ない。……父より、とだけ）"];
const E2 = { id: "r10e2", n: 3, t: "手帳", at: 0, ord: 2, place: DOOR, fac: "r10room",
  hint: "§fゼファーの 外れの §e風の 塔の 戸口§f へ 行こう §7（カザミ翁が 旅人の 箱を 出して 待って いる。右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "風の 塔の 中の 星見の 間。旅人が 残した 箱は、相棒が 鼻を 押しあてると 開いた。古い インク壺と、出せなかった 手紙（「紐の お守りは、まだ 編めない」「港の 灯りは 見えない」「父さんは、幕を 引きに 行く」）。箱の 底には、三つ目ごとに 一つ 返して 編みかけた 紐の 切れ端。窓ぎわの 遠めがねは レンズが 抜かれ、ある 方角に 固められて いた。星図の 写しの 線も、同じ 方角へ。旅の 手帳の いちばん 初めの 頁には、幼い 字で あなたの 名前が 何度も 書かれた 古い 紙きれ。あなたは 古い インクで 名前を 書き、フウタは 戻った。「ずっと、名前を 呼ばれとる 夢を 見とった」。風車が 回り、ゼファーに 風が もどった。レイは 竜の 待つ 島の 端へ 走った。",
  set: { mill10: 1 },
  fx: { xp: ["t55", 120] },
  skip: (s) => { s.epx = { ...(s.epx || {}), mill10: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), T = tower(K, p, c, y0), R = room(K, p, y0), G = R ? seaGlass(K, p, R) : null;
    await K.open(p, R ? "風の 塔（星見の 間）" : "風の 塔の 下", "ash");
    if (R) { const F0 = LW(R, -4, 0), P0 = p.location; if (Math.hypot(F0.x - P0.x, F0.z - P0.z) > 6) await K.moveTo(p, F0, "風の 塔の 戸口", [], MK(R, "in"), 10); }   /* 前の 版で 1話を 済ませた ワールド */
    const IN = R ? MK(R, "in") : K.fwd(p, 3, 1.5), DESK = R ? MK(R, "desk") : K.fwd(p, 4, 0), CH = R ? MK(R, "chart") : null;
    /* 塔の 中: 翁は 星図の 机の 前で 箱を 抱いて 待って いる → レイが 戸口から 入る */
    const eK = R ? await K.put(p, "kazami", DESK, CH) : K.cast(p, "kazami"); K.act(eK, "hold"); K.hold(eK, "box");
    if (R) await K.at(p, DESK, 18, 3.6, 1.3);
    const eR = REI(K, p); K.act(eR, "hold");
    if (ok(eR) && R) await K.walkCam(p, eR, IN, 20);
    await K.csay(p, "kazami", ["{closed}……これが 旅人の 箱じゃて。二十年、だれが 何を しても 開かなんだ。"], eR);
    const g = K.palEnt(p);
    if (g) { if (ok(eK)) await K.go(g, nearPt(g, eK, 1.1), 12); await K.push(p, g, 22, 4.2, 1.7); K.burst(p.dimension, g.location, "minecraft:endrod", 4, 0.5, 0.8); }   /* 相棒が 箱へ 歩み寄る */
    await K.pal(p, ["……この 箱、なつかしい においが する。"]);
    K.sound(p, "random.chestopen", 1); K.flash(p, true);
    await K.narr(p, ["§7相棒が 鼻を 押しあてると、箱の ふたに 光の すじが 走った。", "§7……ことり、と 小さな 音を 立てて、箱が 開いた。"], g);
    K.re(eK, "shock", "!");
    await K.csay(p, "kazami", ["{shock,!,up}……開いたんじゃて！ 二十年 開かなんだ 箱が……！"]);
    await K.say(p, "レイ", ["{shock,…,up}……鍵を 持たず、モンスターと 絆を 結んだ 者……。セオが 祭壇で、そう 言ってた。"], g);
    K.rmCine(g);
    /* 手紙 */
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7中には、古い §fインク壺§7 と、封の 切られて いない §f手紙§7 が 一通。", "§7宛名は 古い しみで にじんで、一字も 読めない。"], eK);
    K.hold(eK, "letter"); K.act(eK, "show", false);
    if (ok(eK) && ok(eR)) await K.approach(p, eK, eR, 1.6);   /* 翁が レイの 前へ 歩み寄って 手紙を 見せる */
    await K.memory(p, eK, "出せなかった 手紙", LETTER.slice(0, 2));
    await K.narr(p, LETTER.slice(2, 4), eR);
    await K.narr(p, LETTER.slice(4), eK);
    K.act(eR, "hold");
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{shock,…,up}……紐の お守り。ほどいては 編み……", "{sad}じいちゃんが 墓標の 前で 言ってた。娘の ために、紐を 編もうと して……編めなかった 男。"]);
    /* 箱の 底: 編みかけの 紐 */
    K.act(eK, "show", false); K.hold(eK, "rope");
    await K.narr(p, ["§7箱の 底に、干し草を 編みかけて ほどいた 切れ端が、いくつも 残って いた。", "§7どれも、三つ目ごとに 一つ 返して ある。"], eK);
    await K.say(p, "レイ", ["{shock,…,up}……三つ 編んで、一つ 返す。……じいちゃんの 連れの、編み方だ。"], eK);
    K.sound(p, "item.book.page_turn", 0.8);
    await K.narr(p, ["§7あなたは 旅の 手帳を めくった。マリノアの 頁に、あの子の 丸い 字。", "§f『ナギサさんの お守りの 紐。三つ目ごとに 一つ 返す、ふしぎな 編み方』"]);
    await K.say(p, "レイ", ["{closed,…}……あいつ、どこまで 書いてんだよ。"]);
    K.hold(eK, "letter");
    await K.csay(p, "kazami", ["{sad,up}……旅人は、とうとう 出さずに 行って しもうたんじゃて。", "{closed}あんたが 持って いって くれ。……届くべき 人に、いつか 届くじゃろう。"], eR);
    await K.give(eK, null, "letter");
    /* レンズの ない 遠めがね（海の 方角に 固めて ある）*/
    if (G) {
      K.act(eK, "point");
      await K.csay(p, "kazami", ["{closed}……あの 男は 毎晩、その 遠めがねを のぞいとった。"]);
      K.act(eK, 0);
      if (ok(eR)) { await K.walkCam(p, eR, toward(eR, G, 1.1), 14); K.turn(eR, { x: G.x + G.wx * 8, y: G.y, z: G.z + G.wz * 8 }); }   /* 窓ぎわへ 歩き、筒の 先を のぞく */
      await K.at(p, G, 18, 2.4, 0.2);
      await K.narr(p, ["§7窓ぎわの 台に、銅の 筒が 固めて ある。のぞいても、灰色の 雲しか 見えない。", "§7……レンズが、抜かれて いた。"], G);
      await K.say(p, "レイ", ["{?,up}……動かねえ。ずっと、同じ 方を 向いた ままだ。"], eK);
      await K.csay(p, "kazami", ["{sad}レンズは、去る 前の 晩に 外して いったんじゃて。『いつか、だれかが 同じ 方を 見たく なったら』と 言うてな。"], eR);
      K.turn(eR);
    }
    /* 星図の 写し */
    if (CH) {
      await K.push(p, CH, 24, 3.2, 1.0, 0.2);
      await K.narr(p, ["§7机の 上に、星図の 写し。星と 星を 結ぶ 線が、何度も 何度も、同じ 方角へ 引かれて いる。", "§7すみに、小さな 字。§f『港の 灯りは、ここからは 見えない』"], CH);
      await K.csay(p, "kazami", ["{closed}ステラの 星読みに 習うた 星じゃと 言うとった。……あの 方角に 何が あるかは、とうとう 言わなんだ。"], eR);
    }
    /* コンパス */
    await K.narr(p, ["§7あなたは、あの子が 作った コンパスを、遠めがねの 横に かざした。", "§7……針は 回りつづけて、どこも 指さなかった。"], G || IN);
    if (ok(eR)) await K.ots(p, eR, p.location, 12);
    await K.say(p, "レイ", ["{sad}……それ、まだ 回ってんのか。"]);
    /* インクの ラベル・手帳の いちばん 初めの 頁 */
    K.hold(eK, "potion");
    await K.narr(p, ["§7インク壺の ラベルに、手紙と 同じ 細い 字。", "§f『影が 書いた ばかりの 石に。古い 石には 効かぬ』"], eK);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7あなたは 旅の 手帳の、いちばん 初めの 頁を 開いた。……古い 紙きれが 一枚、はさまって いた。", `§7幼い 字で、§f${p.name}§7 と 何度も、何度も。すみに 小さく §f『おきて』§7。`]);
    if (ok(eR)) await K.approach(p, eR, p, 1.6);
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{shock,…,up}……あいつ、こんな ガキの ころから……。", "{sad,up}……おまえの 名前、ずっと 呼んでたんだな。"]);
    /* 選ぶ: 古い インクで、最初に 書く 名前 */
    const hn = K.HN(p);
    let pick = 0; try { pick = await choose(p, "古い インク", "§f二十年 眠って いた インク。……最初に、だれの 名前を 書く？", [["§lフウタ\n§7塔守の 孫・石に なった 子", ""], [`§l${hn}\n§7旅の 仲間`, ""]]); } catch {}
    if (pick === 1) {
      K.sound(p, "item.book.page_turn", 1);
      await K.narr(p, [`§7あなたは 古い インクに ペンを ひたし、§f${hn}§7 と 書いた。`, "§7……インクは 光らなかった。字は ただ、黒く 乾いて いった。"], IN);
      await K.csay(p, "kazami", ["{sad,low}……石の 者には、とどく。……逝った 者の 名には、とどかんのじゃて。"], eR);
      if (ok(eR)) K.turn(eR, R ? LW(R, 6, 3, 1.5) : K.fwd(p, 20, 8));   /* 背を 向ける */
      await K.say(p, "レイ", ["{closed,…}……わかってた。……わかってたよ。", "{sad,up}……フウタの 名前、書いて やれ。"]);
      K.turn(eR); K.setFlag(p, "hn10");
    }
    /* 戸口の 外の 石の 子へ */
    const eF = await K.put(p, "§7石に なった フウタ", FUTA(R, K, p), R ? MK(R, "door") : null, K.PJ("m6_sota", 9)); K.act(eF, "up"); K.hold(eK, "brush");
    if (R) await Promise.all([K.go(eK, MK(R, "door"), 12), K.go(eR, LW(R, 1, 1), 12)]);   /* 戸口を 通って 外へ */
    if (ok(eK) && ok(eF)) { await K.walkCam(p, eK, nearPt(eK, eF, 1.2), 16); K.act(eK, "kneel"); }   /* 翁が 戸口を 出て 孫の 前に ひざを つく */
    if (ok(eR) && ok(eF)) K.go(eR, nearPt(eR, eF, 2.3), 18);
    await K.at(p, eF ? eF.location : K.fwd(p, 4), 12, 3, 1.2);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7あなたは 箱の 古い インクに ペンを ひたし、手帳の 名前の 続きに §fフウタ§7 と 書いた。", "§7……二十年 眠って いた インクが、青く 光った。"], eF);
    for (let k = 0; k < 6 && ok(eF); k++) { K.burst(p.dimension, eF.location, k % 2 ? "minecraft:villager_happy" : "minecraft:totem_particle", 6, 0.6, k * 0.3); await K.wait(3); }
    try { if (ok(eF)) eF.nameTag = "§f塔守の 孫 フウタ"; } catch {} K.act(eF, 0); K.sound(p, "random.levelup", 0.7);
    await K.say(p, "塔守の 孫 フウタ", ["{shock,?,up}……あれ？ じいちゃん……？ 風車の 羽、まだ 直して ない のに……"]);
    await K.csay(p, "kazami", ["{cry,tears,up}フウタ……！ よかった、よかったんじゃて……！"]);
    await K.say(p, "塔守の 孫 フウタ", ["{closed,up}……ずっと、だれかに 名前を 呼ばれとる 夢を 見とった。……毎朝、三回。"], eK);
    await K.csay(p, "kazami", ["{smile,tears,up}……呼ばれる 名は、迷わんのじゃて。"], eF);
    try { p.sendMessage("§7【だいじな ことが わかった】 §f町の 人が 石に なったら、話しかけて §e記録のインク§f で 手帳に 名前を 書けば 戻せる §7（空の 声の あとに 石に なった 人だけ。昔の 石には きかない）"); } catch {}
    K.techo(p, "フウタ");
    /* 風車を 回す */
    await K.say(p, "塔守の 孫 フウタ", ["{smile,up}風車、回さなきゃ！ 歯車が かたいから、二人で 押して！"]);
    K.act(eR, "guard");
    await K.say(p, "レイ", ["{angry,up}……よし。せーの、で いくぞ。"]);
    for (let i = 0; i < 6; i++) { mill(K, p, T, i + 1); K.sound(p, "block.grindstone.use", 0.6 + i * 0.1); K.burst(p.dimension, { x: T.x - 2, y: T.y + 7, z: T.z }, "minecraft:white_smoke_particle", 6, 2.5, 0); if (i === 2) await K.at(p, { x: T.x - 2, y: T.y + 7, z: T.z }, 4, 8, 0); await K.wait(5 - Math.min(3, i)); }
    mill(K, p, T, 0); K.sound(p, "block.bell.hit", 1); K.flash(p, true);
    await K.at(p, { x: T.x, y: T.y + 10, z: T.z }, 14, 12, 0);
    await K.narr(p, ["§7風車が 回りだし、塔の 鐘が 一度 鳴った。", "§7ゼファーの 町に 風が もどり、積もった 灰を 空へ 吹き上げた。"], { x: T.x, y: T.y + 8, z: T.z });
    K.act(eR, 0);
    await K.csay(p, "kazami", ["{smile,tears,up}……風じゃ。風が もどったんじゃて。……ありがとう、旅の 人。"]);
    /* レイは 竜の もとへ（手紙の「天空郷の 風なら 治る」）*/
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{shock,…,up}……風。……これなら、こいつの 羽も――", "{angry,up}島の 端へ 行く！ 竜を 風に 当てて くる。……雲の 島へ 渡る 道で 追いつけ！"]);
    await K.leave(eR, p, 10, true);
    /* 最後の 頁 */
    await K.narr(p, ["§7あなたは 手帳の 最後の 頁を めくった。", "§7……白紙の まま だった。§8『旅の 最後に、二人で 書こう』"], eK);
    K.pay(p, E2, 3000, [["dm_ink", 2], ["x_celes", 2]]);
    await K.end(p, { bye: [eK, eF], card: "§7→ 雲の 島へ 渡る 道へ（レイを 追う。右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 3話 雲の 島（六影の 名を かたる 残党）---------- */
const E3 = { id: "r10e3", n: 4, t: "雲の 島", at: 0, ord: 3, place: ISLE_ROAD, fac: "r10road",
  hint: "§f§e雲の 島へ 渡る 道§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "雲の 島へ 渡る 道で、家財を 抱えて 逃げる 人たちを、ルミナの 祭りで 会った ドンゴと チョロが おどして いた。「六影は もう ない。今は おれたちが 六影だ」。チョロは、石に なった 母ちゃんの ために インクを 盗もうと して いた。竜の もとへ 急いで いた レイは、足を 止めて 人々の 前に 立った。逃げる おばあさんが 自分の インクを チョロに 渡すと、二人は 影の 群れから 人々を 守って 戦い、ルミナへ 向かった。日が 暮れ、レイは 竜を 見に 島の 端へ 走った。",
  set: { dongo10: 1 },
  async run(p, d, K) {
    const FW = fac(K, p, "r10road", "waypost", 10, Y(K, p));   /* 第125版(pl): 道しるべ（札・灯り・荷） */
    await K.open(p, "雲の 島へ 渡る 道", "ash");
    if (FW) await K.at(p, FW, 14, 6, 1.2);
    const eR = REI(K, p);
    const r1 = K.npcNear(p, "§7逃げる おばあさん", K.PJ("baba", 9)), r2 = K.npcNear(p, "§7逃げる 旅人", K.PJ("m6_otis", 8)); K.act(r1, "kneel"); K.act(r2, "hold"); K.hold(r1, "brush"); K.hold(r2, "box");
    if (ok(r2)) K.go(r2, K.fwd(p, 3, -3.5), 18); if (ok(r1)) K.go(r1, K.fwd(p, 3.5, -2.5), 20);   /* 第125版(rs): 家財を 抱えて こちらへ 逃げて くる */
    await K.narr(p, ["§7雲の 島へ 渡る 道を、家財を 抱えた 人たちが 歩いて いた。", "§7……その 前に、見覚えの ある 二人が 立ちふさがって いる。"], r1);
    if (ok(eR) && ok(r1)) await K.approach(p, eR, r1, 1.4);   /* レイが おばあさんの 前に 出る */
    const eD = K.npcNear(p, "§c下っぱ ドンゴ", K.PJ("noxa", 9)), eC = K.npcNear(p, "§c下っぱ チョロ", K.PJ("noxb", 9)); K.act(eD, "point");
    await K.low(p, eD, 12);
    await K.say(p, "ドンゴ", ["{angry,low}へっへっ。六影は もう ない。……今は、おれたちが §5六影§f だ。", "{angry}インクと 食い物を 置いて いきな。逆らえば、影に 食わせるぜ。"]);
    await K.say(p, "逃げる おばあさん", ["{cry,tears,up}……この インクは、石に なった 孫の ために……"]);
    await K.say(p, "レイ", ["{angry}……急いでんだよ、こっちは。……竜が 待ってる。"], eD);   /* 第125版(ce): 急ぐ 足を 止めて 人の 前に 立つ */
    K.act(eR, "guard");
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{rage,怒,up}……その 名前を、軽く 口に するな！！", "{angry}おまえらが 名乗れる ほど、軽い 名前じゃ ねえんだよ！"]);
    await K.say(p, "チョロ", ["{sweat,汗}あ、兄貴……あれ、ルミナの 祭りの ときの……！"]);
    if (!K.flag(p, "r10e3a")) {
      const r = await K.battle(p, K.team(["beast", "nether", "animal"], 76, 3, 16), { name: "六影の 名を かたる 残党", arena: "雲の 道", theme: "sky", hpk: 1.4, extra: 0.25, speaker: "ドンゴ", guests: K.team(["animal"], 75, 1, 10).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "な、なんだ こいつら……！", low: "ひ、ひいいっ！" } });
      if (r !== "win") return lose(K, p, "§c下っぱ ドンゴ", K.PJ("noxa", 9), "ドンゴ", "{smile}へっ、インクは もらって いくぜ。");
      K.setFlag(p, "r10e3a");
    }
    const eD2 = K.npcNear(p, "§c下っぱ ドンゴ", K.PJ("noxa", 9), true), eC2 = K.npcNear(p, "§c下っぱ チョロ", K.PJ("noxb", 9), true); K.act(eD2, "down"); K.act(eC2, "kneel");
    await K.push(p, eC2, 22, 4.2, 1.7);
    await K.say(p, "チョロ", ["{cry,tears,up}……ごめんなさいっす……！ 母ちゃんが、石に なっちまったんす……！", "{sad}インクが あれば 戻るって 聞いて……でも、おいらたち、金なんて ないっす……"]);
    await K.say(p, "レイ", ["{closed,up}……盗んだ インクで 書いた 名前で、母ちゃんが 喜ぶと 思うか。"], eC2);
    await K.say(p, "チョロ", ["{cry,…}……………………。"]);
    K.act(r1, "hold");
    await K.give(r1, eC2, "brush");
    await K.say(p, "逃げる おばあさん", ["{sad,up}……持って いきな。", "{smile}名前を 呼んで あげな。……孫の ぶんは、また 作って もらうから。"], eC2);
    await K.say(p, "チョロ", ["{cry,tears,up}……っ、ありがとう……ございますっす……！！"]);
    /* 影の 群れ */
    K.sound(p, "mob.wither.ambient", 1); K.shake(p, 0.5, 0.8); K.mood(p, "shadow");
    const far = K.fwd(p, 12, -4); await K.shadowFlow(p, far, K.fwd(p, 6, 0), 14);
    K.act(eD2, "guard"); K.act(eC2, "guard"); await K.up(p, eD2, 8);   /* 第125版(ce): 跳ね起きて 構える 顔 */
    await K.say(p, "ドンゴ", ["{shock,!,up}影の 群れだ……！ さわぎを 聞きつけて 来やがった！"]);
    await K.say(p, "ドンゴ", ["{angry,up}……チョロ、立て！ ばあさんたちの 前に 出ろ！ ……今度は、守る 側だ！"]);
    if (!K.flag(p, "r10e3b")) {
      await K.duel(p, "§5§l影の 群れ", "§f灰の 中から、黒い 影の モンスターが あふれだす！", { fams: ["nether"] });
      const r = await K.battle(p, K.team(["nether", "nether", "dragon"], 77, 3, 22), { name: "影の 群れ", arena: "雲の 道", theme: "underworld", hpk: 1.8, extra: 0.3, speaker: "影", guests: [...K.team(["beast"], 74, 1, 8).map((t) => ({ ...t, owner: "ドンゴ" })), ...K.team(["animal"], 74, 1, 10).map((t) => ({ ...t, owner: "レイ" }))], lines: { half: "……シッテ……シマッタ……", low: "……ナヲ……ヨブナ……" } });
      if (r !== "win") return lose(K, p, "§bレイ", 17, "レイ", "{sweat,汗}……下がれ！ 一度 立てなおす！");
      K.setFlag(p, "r10e3b");
    }
    await K.narr(p, ["§7影の 群れは 灰に もどって、風に 散った。"]);
    await K.say(p, "ドンゴ", ["{closed,汗}……へっ。おれたちの 柄じゃ ねえ ことを しちまった。", "{smile,up}このまま ばあさんたちを ルミナまで 送る。……六影の 名前は、もう 使わねえ。"]);
    await K.say(p, "チョロ", ["{smile,tears,up}母ちゃんの 名前、呼んで くるっす！ ……ありがとうっす！"]);
    if (ok(eR)) await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{closed}……日が 暮れる。竜の とこへ 行って くる。", "{sad,up}島の 小屋で 待ってて くれ。……話が ある。"]);
    K.pay(p, E3, 4000, [["dm_bell", 1], ["dm_ink", 1]]);
    await K.end(p, { leave: [eR, eD2, eC2, r1, r2], card: "§7→ 雲の 島の 小屋へ（夜。レイは 竜を 見に 島の 端へ。右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 4話 レイの 理由（雲の 島の 小屋）---------- */
const E4 = { id: "r10e4", n: 5, t: "レイの 理由", at: 0, ord: 4, place: HUT, fac: "r10hut",
  hint: "§f§e雲の 島の 小屋§f へ 行こう §7（右上の 案内。レイが 待って いる）",
  syn: "夜、島の 端から もどった レイは「風は 当たった。でも、ほどけなかった」と 言った。空の 声より 前の 石には、風も インクも 届かない。雲の 島の 小屋で、レイは 六影の 側に ついた わけを 話した。いつも じいちゃんの 背中ばかり 見て いた こと。牢を 出た あと、話を 聞いて くれたのは セオだけ だった こと。「君は 選ばれる 人だ」と かけらを もらって、うれしかった こと。祭壇で セオの 泣きそうな 顔を 見ても、動けなかった こと。祖父の しくじりを 写した しくじり帳の 最後の 頁だけが、レイの 字だった。『竜骨の 祭壇。動けなかった。』「……あいつを 止めるのは、たぶん――」その 先は、風に 消えた。その 夜、レイは 一度も 横に ならなかった。",
  set: { reiWhy: 1 },
  async run(p, d, K) {
    const FQ = fac(K, p, "r10hut", "cabin", 10, Y(K, p)), FF = fac(K, p, "r10fire", "fire", 10, Y(K, p));   /* 第125版(fac): 雲の 島の 小屋と たき火 */
    await K.open(p, "雲の 島の 小屋（夜）", "night");
    K.ambient(p, "night", K.S(p) ? K.S(p).Cn : p.location); K.sound(p, "fire.fire", 0.5);
    if (FQ) await K.at(p, FQ, 12, 7, 1.4);
    const eR = REI(K, p);
    if (ok(eR) && FF) { await K.walkCam(p, eR, { x: FF.x - 1.4, y: FF.y, z: FF.z }, 18); }   /* 第125版(ce): 島の 端から 暗い 道を 歩いて もどり、たき火の そばに 座る */
    K.act(eR, "kneel");
    await K.say(p, "レイ", ["{closed}……風、当たってた。島の 端で、いちばん 強く。", "{sad}……でも、ほどけなかった。羽の 先も。……空の 声より 前の 石には、風も インクも 届かねえんだな。"]);   /* 第125版(ce): 手紙の「天空郷の 風なら 治る」の 答え */
    await K.say(p, "レイ", ["{closed}……座れよ。火、あったまるぞ。", "{sad}明日の 勝負の 前に、話して おきたい ことが ある。"]);
    if (FF) await K.at(p, FF, 10, 3, 0.6);   /* たき火 */
    if (ok(eR)) K.turn(eR, FF || K.fwd(p, 6));   /* 火を 見つめて 話す */
    await K.memory(p, eR, "§7―― 昔　レイの 話", ["§7小さい ころから、レイは じいちゃんの 背中ばかり 見て いた。", "§7じいちゃんは、いつも 遠くの 空を 見て いた。……レイの ほうは、見なかった。"]);
    await K.say(p, "レイ", ["{sad,up}……じいちゃんは、おまえを 見てた。最初の 仲間を 選ぶ 日も、旅に 出る 日も。", "{closed}オレは、選ばれなかった。……そう 思ってた。"]);
    K.act(eR, "hold");
    await K.say(p, "レイ", ["{sad}牢を 出た あと、オレの 話を 聞いて くれたのは、セオ だけ だった。", "{smile,…,up}かけらを くれた 夜、あいつ 言ったんだ。『君は 選ばれる 人だ』って。……うれしかったんだよ。"]);
    await K.say(p, "レイ", ["{closed}だから かけらを 手放せなかった。あいつの 役に 立てば、選ばれる 側に なれると 思った。", "{angry,up}……バカだよな。かけらの 声と、あいつの 声の 区別も ついて なかった。"]);
    const g = K.palEnt(p); if (g) { const l = ok(eR) ? eR.location : g.location; try { g.teleport({ x: l.x + 1.4, y: l.y, z: l.z + 0.8 }); } catch {} K.burst(p.dimension, g.location, "minecraft:heart_particle", 3, 0.4, 0.8); await K.push(p, g, 22, 4.2, 1.7); }
    K.act(eR, "hold");
    await K.say(p, "レイ", ["{smile,up}……おまえの 相棒は、ずっと おまえを 選んでる。……いいな、そういうの。", "{closed}選ばれる って、だれかに 決めて もらう ことじゃ なかったんだ。"]);
    K.rmCine(g);
    K.act(eR, 0);
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{sad,up}……祭壇で、あいつ 泣きそうな 顔を してた。影に 呑まれる 直前に。", "{cry,tears,up}オレは、それを 見ても、動けなかった。……あの 子が 前に 出た ときも。"]);
    /* 第125版(ce): しくじり帳（祖父の しくじりを 写した 帳面）の 最後の 頁 */
    K.act(eR, "show"); K.hold(eR, "notebook");
    await K.narr(p, ["§7レイが 腰の 帳面を 開いた。じいちゃんの しくじりを 写した §fしくじり帳§7。", "§7最後の 頁だけ、レイの 字だった。§f『竜骨の 祭壇。動けなかった。』"], eR);
    await K.say(p, "レイ", ["{closed}……じいちゃんの しくじりを 写して、同じ ことだけは しないって 決めてた。", "{sad,up}……なのに、いちばん でかい 頁が、オレのだ。"]);
    K.act(eR, 0); K.hold(eR);
    await K.say(p, "レイ", ["{closed,up}……あいつを 止めるのは、たぶん――"]);
    K.sound(p, "mob.enderdragon.flap", 0.5); K.burst(p.dimension, K.S(p) ? K.S(p).Cn : p.location, "minecraft:white_smoke_particle", 12, 2.5, 1);
    await K.narr(p, ["§7強い 風が 吹いて、火が 大きく ゆれた。", "§7……レイの 言葉の 続きは、風の 音に 消えた。"]);
    await K.say(p, "レイ", ["{closed,no}……なんでも ない。", "{angry,up}明日、島の 端で 決めよう。セオを 止めに 行くのは、おまえか オレか。……手加減は なしだ。"]);
    K.pay(p, E4, 2000, [["fd_stew", 2]]);
    await K.night(p, FF || FQ, "§7その 夜、レイは 一度も 横に ならなかった。", "§7……夜明け。島の 端の 方から、風を 切る 音が 聞こえて いた。", [eR]);   /* 第125版(ce): 寝る → 朝（場面転換）*/
    await K.end(p, { card: "§7→ 雲の 島の 端で、レイと 最後の 勝負（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 5話 門番の 旅（最後の 勝負の あと。ゴンザが 送り出しに 来る）---------- */
const E5 = { id: "r10e5", n: 7, t: "門番の 旅", at: 1, ord: 0, place: ISLE, fac: "r10edge",
  hint: "§f§e雲の 島の 端§f で、だれかが あなたを さがして いる §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "レイとの 勝負の あと、雲の 島の 端に、ルミナの 門番 ゴンザが あらわれた。「門番が 門を 離れたのは、生まれて 初めて」。ルミナには 各地から 人が 集まり、あなたを 待って いる。大通りは 取り憑かれた 人で あふれ、北の 門の 鐘を 鳴らせば 影が 引くと いう。ゴンザは 先に 帰り、門を 開けて 待つと 言った。",
  set: { gonza10: 1 },
  async run(p, d, K) {
    await K.open(p, "雲の 島の 端", "day");
    const EM = RAW("r10edge"), dq = (EM && Math.hypot(EM.x - p.location.x, EM.z - p.location.z) < 60 && MK(EM, "dragon")) || K.fwd(p, 6, 3), dr = K.monEnt(p, dq, DRAG(), "§7竜の 石像");   /* 第125版(ce): 台座の 上の 竜 */
    const eG = K.cast(p, "gonza"); K.act(eG, "hold"); K.hold(eG, "basket");
    if (ok(eG)) { await K.walkCam(p, eG, K.fwd(p, 2.8, 1.2), 20); K.act(eG, "stagger"); }   /* 第125版(rs): 吊り橋を 渡りきって よろよろ 歩いて 来る */
    await K.csay(p, "gonza", ["{sweat,汗,up}……はあ、はあ……やっと、見つけたでござる……！", "{sweat,汗}雲の 島の 吊り橋は、拙者には ちと 高すぎたでござる……。"]);
    K.act(eG, 0);
    await K.push(p, eG, 22, 4.2, 1.7);
    await K.csay(p, "gonza", ["{closed,up}……門番が 門を 離れたのは、生まれて 初めてでござる。", "{smile}ミミ殿の パンを、届けに 来たでござる。……それと、伝言を。"]);
    { const h0 = K.hero(p, false); if (ok(eG) && ok(h0)) await K.approach(p, eG, h0, 1.4); }   /* 第125版(rs): かごを 渡しに 歩み寄る */
    await K.give(eG, null, "basket"); K.hold(eG, "spear");
    K.act(eG, "hold");
    await K.csay(p, "gonza", ["{smile,up}ルミナに、各地から 人が 集まって おるでござる。……みんな、あなたを 待って おる。", "{closed}王冠の 石板へ 行く 前に、一度だけ、帰って ほしいでござる。"]);
    K.act(eG, 0);
    await K.csay(p, "gonza", ["{closed}……レイ殿とは、吊り橋の たもとで すれちがったでござる。『門は、オレも 守る』と 言うて、先に ルミナへ。"]);
    await K.csay(p, "gonza", ["{sad,up}……旅の 仲間の ことは、オルド殿から 聞いたでござる。", "{closed}拙者は 門を 守る ことしか できぬ。……だから、帰る 場所だけは、必ず 守るでござる。"]);
    if (dr) { await K.push(p, dr, 22, 4.2, 1.7); }
    await K.csay(p, "gonza", ["{sad}……レイ殿の 竜でござるか。……いつか、ルミナの 門を くぐる 日が 来るでござるよ。"], dr);
    K.act(eG, "point");
    await K.csay(p, "gonza", ["{angry,up}ただ、気を つけるでござる。ルミナの 大通りは、取り憑かれた 人で あふれて おる。", "{closed}北の 門の 外の §e鐘§f を 鳴らせば、影は しばらく 引くでござる。……昔から、そう 決まって おる。"]);
    K.act(eG, 0);
    await K.csay(p, "gonza", ["{smile,up}拙者は 先に もどって、門を 開けて 待つでござる！"]);
    K.pay(p, E5, 2000, [["gift_bread", 3]]);
    K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 0 0 0"); await K.wait(10);
    await K.end(p, { leave: [eG], bye: [dr], card: "§7→ 始まりの町 §eルミナ§7 の 南の 入口へ もどろう（右上の 案内）", kind: "day" });
    K.rmCine(dr);
    return true;
  } };

epAdd(10, [E1, E2, E3, E4, E5], { steps: { 0: [6, "最後の 勝負"] } });
export const __r10 = { ISLE, ISLE_ROAD, HUT, towerAt, LW, seaGlass, DOOR };
export const __doom = { doomed, doomKnown };
