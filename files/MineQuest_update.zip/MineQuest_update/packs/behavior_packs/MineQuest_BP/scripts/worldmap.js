// v2.3: アストラ大陸の 地方（ワンダーランド風の いろいろな 世界）。データと 位置の 計算だけ
import { world, system } from "@minecraft/server";

// c=中心（リスポーンからの ずれ） r=半径 lv=[はじめ,おわり] fams=すむ 系統 style=町の 見た目 ruin=遺跡の テーマ land=ステージの テーマ（dgthemes） rm=地方マスター（rmaster.js の 番号）
export const WREGIONS = [
  { id: "arca", name: "アルカトラス地方", short: "アルカトラス", c: [0, 0], r: 760, lv: [1, 13], fams: { beast: 3, animal: 4, blob: 3 }, style: "village", ruin: "moss", land: ["forest", "cherry", "forest"], rm: 0,
    castle: { name: "アルカトラス城", at: [0, -330], wall: "stone_bricks", roof: "dark_oak_planks", acc: "oak_log" }, col: "§a",
    desc: "なだらかな 丘と 森と 川が どこまでも 続く、豊かな 大自然の 田舎。始まりの町 ルミナが ある。",
    towns: [], pre: ["こむぎの", "かざぐるまの", "おがわの", "ひだまりの", "ぼくじょうの", "はなばたけの", "いずみの", "どんぐりの"], kana: ["ハーベル", "ミルト", "リール", "ポカラ", "モーモ", "ペタラ", "クレス", "ノッポ"] },
  { id: "silva", name: "シルヴァ大森林", short: "シルヴァ", c: [1150, 350], r: 620, lv: [10, 22], fams: { animal: 5, beast: 2 }, style: "forest", ruin: "moss", land: ["forest", "mushroom", "swamp"], rm: -1,
    castle: { name: "樹上の 砦 シルヴァン", wall: "spruce_planks", roof: "spruce_log", acc: "mossy_cobblestone" }, col: "§2",
    desc: "空が 見えないほど 木が 茂る 大森林。きのこと 虫たちの 国。",
    towns: [], pre: ["こもれびの", "きこりの", "ほたるの", "きのこの", "こけの", "ふるきの", "つたの", "ねっこの"], kana: ["リーフィ", "ウッディ", "ルミエ", "マシュール", "モッシュ", "エルダ", "アイビ", "ルート"] },
  { id: "ruins", name: "ルインズ荒野", short: "ルインズ", c: [350, 1250], r: 620, lv: [16, 28], fams: { nether: 3, sword: 3, golem: 2, beast: 1 }, style: "castle", ruin: "ruin", land: ["ruins", "ruins", "desert"], rm: 1,
    castle: { name: "廃都 グランディア城", wall: "cracked_stone_bricks", roof: "mossy_stone_bricks", acc: "chiseled_stone_bricks" }, col: "§7",
    desc: "むかし 栄えた 王国の なれの はて。崩れた 都と 墓標が 風に 鳴る、寂れた 荒野。",
    towns: [], pre: ["はいきょの", "ぼひょうの", "さびた", "わすれじの", "かぜなりの", "くずれた", "いしだたみの", "ほろびの"], kana: ["ガレキ", "セプルク", "ラスティ", "オブリス", "ヒュール", "クランブ", "ペイヴ", "ルイナ"] },
  { id: "volka", name: "ヴォルカ火山帯", short: "ヴォルカ", c: [-1050, 1000], r: 620, lv: [24, 36], fams: { dragon: 3, nether: 2, golem: 3, beast: 1 }, style: "volcano", ruin: "nether", land: ["volcano", "volcano", "underworld"], rm: 2,
    castle: { name: "鍛冶王の 城 フォルジア", wall: "polished_blackstone_bricks", roof: "red_nether_brick", acc: "magma" }, col: "§c",
    desc: "大地が 赤く 脈打つ 火山の 国。鍛冶師と 竜が 住む。",
    towns: [], pre: ["ひのこの", "てつの", "ようがんの", "はがねの", "ふいごの", "すすけた", "あかがねの", "ほむらの"], kana: ["スパーク", "アイアンベル", "ラヴィ", "クロガネ", "ベローズ", "スス", "カッパー", "ホムラ"] },
  { id: "sand", name: "サンドリア砂漠", short: "サンドリア", c: [-1450, -150], r: 660, lv: [30, 42], fams: { golem: 3, nether: 3, animal: 2, dragon: 1 }, style: "desert", ruin: "desert", land: ["desert", "desert", "ruins"], rm: -1,
    castle: { name: "砂の 王宮 サンドリア", wall: "cut_sandstone", roof: "smooth_sandstone", acc: "chiseled_sandstone" }, col: "§e",
    desc: "見わたす かぎりの 砂の 海。オアシスの 町と、砂に 埋もれた 王墓。",
    towns: [], pre: ["オアシスの", "すなかぜの", "たいようの", "おうぼの", "しんきろうの", "さきゅうの", "ひすいの", "らくだの"], kana: ["ミラージュ", "デューン", "ソーラ", "ファラ", "ファタ", "サハラ", "ジェイド", "キャメロ"] },
  { id: "crys", name: "クリスタリア", short: "クリスタリア", c: [-850, -1350], r: 620, lv: [34, 46], fams: { golem: 3, blob: 2, nether: 2, dragon: 1 }, style: "crystal", ruin: "crystal", land: ["crystal", "cave", "crystal"], rm: 3,
    castle: { name: "水晶宮 プリズマ", wall: "calcite", roof: "amethyst_block", acc: "smooth_basalt" }, col: "§d",
    desc: "地面から 水晶が 生える 不思議な 地方。音が よく 響く。",
    towns: [], pre: ["すいしょうの", "こだまの", "あおい 洞の", "ひかりごけの", "にじいろの", "しずくの", "いしの 花の", "めいきゅうの"], kana: ["クォーツ", "エコー", "アズール", "グロウ", "プリズム", "ドロプ", "ジェム", "ラビリン"] },
  { id: "mari", name: "マリノア諸島", short: "マリノア", c: [950, -1550], r: 660, lv: [42, 54], fams: { aqua: 5, animal: 2, blob: 2 }, style: "port", ruin: "water", land: ["coast", "sea", "coast"], rm: 4,   /* 第125版: 海の 地方は 森を やめて 岬と 入り江 */
    castle: { name: "海神の 城 ネプトゥナ", wall: "prismarine_bricks", roof: "dark_prismarine", acc: "sea_lantern" }, col: "§b",
    desc: "大小の 島が 連なる 海の 地方。港町と、海に 沈んだ 神殿。",
    towns: [], pre: ["しおかぜの", "さんごの", "うみねこの", "しんじゅの", "みさきの", "なぎさの", "うずしおの", "いりえの"], kana: ["マリーナ", "コラリア", "カモメール", "パール", "ケープ", "ナギサ", "メイル", "コーヴ"] },
  { id: "necro", name: "ネクロス冥府領", short: "ネクロス", c: [2250, -250], r: 660, lv: [50, 62], fams: { nether: 5, animal: 1 }, style: "dark", ruin: "deep", land: ["underworld", "underworld", "void"], rm: 5,
    castle: { name: "冥王の 城 タナトス", wall: "polished_blackstone_bricks", roof: "crimson_planks", acc: "soul_lantern" }, col: "§5",
    desc: "日の 光が 届かない 冥府の 地。死者と 魔物が 夜を 歩く。終の遺跡は この 地に 眠る。",
    towns: [], pre: ["よいやみの", "たましいの", "ぼちの", "すみいろの", "ゆうれいの", "つきのない", "ねむりの", "まよいの"], kana: ["ノクト", "ソウラ", "グレイヴ", "オニキス", "ファントム", "ニュームーン", "スリープ", "ロスト"] },
  { id: "frost", name: "フロストヘイム雪山", short: "フロストヘイム", c: [1700, 2050], r: 700, lv: [58, 70], fams: { beast: 3, aqua: 2, dragon: 2, golem: 1 }, style: "snow", ruin: "snow", land: ["snow", "snow", "crystal"], rm: 6,
    castle: { name: "氷雷の 城 ヘイムダル", wall: "packed_ice", roof: "blue_ice", acc: "snow" }, col: "§f",
    desc: "雷鳴の とどろく 雪と 氷の 山脈。吹雪の 中に 古い 城が ある。",
    towns: [], pre: ["ゆきどけの", "こおりの", "らいうんの", "やまびこの", "ふぶきの", "しろがねの", "つららの", "オーロラの"], kana: ["スノウ", "アイシクル", "サンダ", "ピーク", "ブリザ", "シルバ", "ツララ", "オーロ"] },
  { id: "ragna", name: "終焉の地 ラグナ", short: "ラグナ", c: [-1750, 2300], r: 720, lv: [64, 78], fams: { dragon: 4, nether: 2, sword: 2 }, style: "dark", ruin: "end", land: ["void", "volcano", "void"], rm: 7,
    castle: { name: "竜骨の 城 ラグナロク", wall: "end_bricks", roof: "purpur_block", acc: "obsidian" }, col: "§4",
    desc: "かつて 世界が 終わりかけた 場所。竜の 骨が 大地に 突き立つ。",
    towns: [], pre: ["さいはての", "りゅうこつの", "たそがれの", "おわりの", "くろい 空の", "ほしおちの", "いにしえの", "はてなき"], kana: ["エンド", "ボーン", "トワイラ", "ラスト", "ノワール", "メテオ", "エンシェ", "インフィ"] },
  { id: "celes", name: "セレスティア天空郷", short: "セレスティア", c: [-2700, -1900], r: 820, lv: [72, 92], fams: { animal: 3, dragon: 3, golem: 2, blob: 1 }, style: "sky", ruin: "end", land: ["sky", "sky", "cherry"], rm: -1,
    castle: { name: "天空城 セレスティア", wall: "quartz_bricks", roof: "smooth_quartz", acc: "gold_block" }, col: "§6",
    desc: "雲より 高い 浮島の 郷。最も 強い モンスターたちが 空を 舞う。",
    towns: [], pre: ["くもの 上の", "かぜの 塔の", "ほしぞらの", "てんしの", "にじの 橋の", "はねの", "そらいろの", "ひかりの"], kana: ["ニンブス", "ゼファー", "ステラ", "エンジェ", "アーチ", "フェザー", "アジュール", "ルーチェ"] },
];
// v3.0: 世界を ちぢめる（次の 町・城・地方まで 300〜500 ブロック。配布マップにも 入る 大きさ）
export const WS = 0.35;
// 物語の 順に うずまき状に ならべる（となりの 地方の 中心まで 約 420〜500）
const NEWC = { arca: [0, 0], silva: [430, -40], ruins: [330, 380], volka: [-110, 470], sand: [-480, 200], crys: [-430, -260], mari: [0, -470], necro: [450, -470], frost: [880, -200], ragna: [820, 300], celes: [520, 720] };
for (const R of WREGIONS) { R.c = NEWC[R.id] || [Math.round(R.c[0] * WS), Math.round(R.c[1] * WS)]; R.r = R.id === "arca" ? 270 : 235; if (R.castle && R.castle.at) R.castle.at = [Math.round(R.castle.at[0] * WS), Math.round(R.castle.at[1] * WS)]; }
/* 第99版: 新しい ワールドは 町・城・ステージを 中心に 寄せた 配置（LAYOUT 2・配布マップの 地形も これに 合わせて 小さく）。
   前から 遊んで いる ワールド（町や 城の 記録が ある）は 今までの 配置（LAYOUT 1）の まま。ワールドに 1回だけ 決めて 覚える */
export const LAYOUT2 = {"k":0.7,"regions":[[0,0,189],[301,-28,165],[231,266,165],[-77,329,165],[-336,140,165],[-301,-182,165],[0,-329,165],[315,-329,165],[616,-140,165],[574,210,165],[364,504,165]],"castles":[[95,-168],[367,124],[284,197],[-20,347],[-342,128],[-396,-235],[-41,-353],[249,-384],[665,-33],[611,193],[493,518]],"lands":[[[91,66],[-114,129],[-121,-93]],[[322,-171],[294,-77],[449,-89]],[[100,174],[184,225],[245,302]],[[-20,452],[-245,334],[-41,243]],[[-470,193],[-288,24],[-442,99]],[[-384,-122],[-178,-173],[-456,-320]],[[-63,-474],[-30,-234],[26,-433]],[[316,-479],[462,-314],[213,-482]],[[698,-260],[760,-77],[561,-59]],[[701,245],[514,232],[610,300]],[[431,433],[268,606],[489,629]]],"towns":{"t0":[0,0],"t1":[154,-25],"t2":[-127,18],"t3":[-2,126],"t4":[-14,-124],"t5":[194,114],"t6":[-279,227],"t7":[185,-273],"t8":[-254,-308],"t9":[290,35],"t10":[85,286],"t11":[-153,233],"t12":[-225,115],"t13":[-231,-71],"t14":[-133,-275],"t15":[62,-297],"t16":[211,-151],"t17":[418,18],"t18":[396,238],"t19":[109,408],"t20":[-137,360],"t21":[-394,275],"t22":[-396,-3],"t23":[-288,-188],"t24":[-150,-398],"t25":[133,-400],"t26":[309,-282],"t27":[485,125],"t28":[345,352],"t29":[233,414],"t30":[-126,484],"t31":[-342,388],"t32":[-553,108],"t33":[-502,-185],"t34":[-359,-374],"t35":[-164,-523],"t36":[109,-522],"t37":[378,-386],"t38":[510,-182],"t39":[587,55],"t40":[496,342],"t41":[334,487],"t42":[57,562],"t43":[-217,570],"t44":[-452,445],"t45":[-575,231],"t46":[-507,-60],"t47":[-564,-292],"t48":[-276,-466],"t49":[-51,-585],"t50":[227,-592],"t51":[456,-483],"t52":[588,-280],"t53":[697,113],"t54":[586,428],"t55":[380,604],"t56":[137,657],"t57":[-124,652],"t58":[-365,547],"t59":[-548,365],"t60":[-676,130],"t61":[-654,-136],"t62":[-580,-416],"t63":[-383,-566],"t64":[-145,-665],"t65":[120,-655],"t66":[374,-575],"t67":[546,-397],"t68":[655,-151]}};
/* 第108版: 城・町・ステージの 間を もっと あける 配置（城下町と 町が となりあって いた）。新しい ワールドは これ */
export const LAYOUT3 = {"k":0.7,"regions":[[0,0,189],[301,-28,182],[231,266,198],[-77,329,165],[-336,140,165],[-301,-182,165],[0,-329,165],[315,-329,165],[616,-140,165],[574,210,165],[364,504,165]],"castles":[[104,-159],[391,127],[236,264],[-63,369],[-353,125],[-405,-243],[-10,-330],[275,-397],[695,-43],[691,222],[529,582]],"lands":[[[92,77],[-105,146],[-132,-54]],[[357,-157],[342,-71],[468,-73]],[[79,163],[123,339],[258,398]],[[-18,497],[-286,350],[-40,221]],[[-471,193],[-281,10],[-478,71]],[[-372,-111],[-156,-163],[-481,-354]],[[-64,-480],[-60,-204],[52,-496]],[[344,-513],[483,-291],[208,-514]],[[705,-271],[804,-124],[563,-89]],[[796,308],[525,278],[607,334]],[[430,444],[266,606],[469,704]]],"towns":{"t0":[0,0],"t1":[146,-8],"t2":[-104,44],"t3":[-9,112],"t4":[-43,-104],"t5":[236,108],"t6":[-261,251],"t7":[236,-242],"t8":[-269,-322],"t9":[259,-13],"t10":[57,262],"t11":[-149,238],"t12":[-198,105],"t13":[-227,-90],"t14":[-160,-282],"t15":[145,-310],"t16":[259,-131],"t17":[505,21],"t18":[423,280],"t19":[83,431],"t20":[-212,420],"t21":[-380,311],"t22":[-415,-19],"t23":[-254,-200],"t24":[-181,-413],"t25":[119,-419],"t26":[348,-258],"t27":[541,178],"t28":[354,367],"t29":[188,471],"t30":[-136,507],"t31":[-352,426],"t32":[-570,114],"t33":[-544,-171],"t34":[-357,-393],"t35":[-164,-524],"t36":[123,-569],"t37":[431,-378],"t38":[514,-188],"t39":[602,83],"t40":[507,378],"t41":[334,491],"t42":[59,620],"t43":[-225,577],"t44":[-463,448],"t45":[-575,231],"t46":[-520,-61],"t47":[-564,-292],"t48":[-277,-472],"t49":[-51,-585],"t50":[233,-613],"t51":[489,-492],"t52":[585,-288],"t53":[777,90],"t54":[603,436],"t55":[367,614],"t56":[158,674],"t57":[-124,652],"t58":[-365,547],"t59":[-548,365],"t60":[-681,131],"t61":[-654,-136],"t62":[-580,-416],"t63":[-383,-566],"t64":[-145,-665],"t65":[122,-682],"t66":[390,-604],"t67":[547,-395],"t68":[643,-191]}};
export const LAYX = (v) => (v === 3 ? LAYOUT3 : LAYOUT2);
export const LAYOUT = { v: 1, k: 1, ok: false }, LAYOUT_HOOKS = [];
const BASE1 = WREGIONS.map((R) => ({ c: [...R.c], r: R.r, at: R.castle.at ? [...R.castle.at] : null }));
export function applyLayout(v) {
  if (LAYOUT.v === v) return;
  LAYOUT.v = v; LAYOUT.k = v >= 2 ? LAYX(v).k : 1;
  WREGIONS.forEach((R, i) => { if (v >= 2) { const LX = LAYX(v), g = LX.regions[i]; R.c = [g[0], g[1]]; R.r = g[2]; R.castle.at = [...LX.castles[i]]; } else { R.c = [...BASE1[i].c]; R.r = BASE1[i].r; if (BASE1[i].at) R.castle.at = [...BASE1[i].at]; else delete R.castle.at; } });
  LS_MEMO.clear();
  for (const h of LAYOUT_HOOKS) try { h(v); } catch {}
}
function playedBefore() {
  try { for (const k of ["mrpg:town:t0", "mrpg:home", "mrpg:castle:0", "mrpg:land:0:0", "mrpg:land:0:1"]) if (world.getDynamicProperty(k) !== undefined) return true; } catch {}
  try { if (typeof world.getDynamicPropertyIds === "function" && world.getDynamicPropertyIds().some((k) => /^mrpg:(town|castle|land|cave|home|ruin|rfin|altar|rs2_|jailslots)/.test(k))) return true; } catch {}
  return false;
}
export function ensureLayout() {
  if (LAYOUT.ok) return;
  let v; try { v = world.getDynamicProperty("mrpg:layout"); } catch { return; }   /* まだ 読めない ときは 次に */
  if (v !== 1 && v !== 2 && v !== 3) { v = playedBefore() ? 1 : 3; try { world.setDynamicProperty("mrpg:layout", v); } catch { return; } }
  LAYOUT.ok = true; applyLayout(v);
}
try { system.run(() => ensureLayout()); } catch {}
export const HOME = 0;

function sp() { try { const s = world.getDefaultSpawnLocation(); return { x: s.x, z: s.z }; } catch { return { x: 0, z: 0 }; } }
// ずれ（dx,dz）→ 地方の 番号
export function regionIdx(dx, dz) {
  let best = 0, bv = 1e9;
  WREGIONS.forEach((R, i) => { const v = Math.hypot(dx - R.c[0], dz - R.c[1]) / R.r; if (v < bv) { bv = v; best = i; } });
  return best;
}
export const regionAt = (loc) => { const s = sp(); return WREGIONS[regionIdx(loc.x - s.x, loc.z - s.z)]; };
export const regionIdxAt = (loc) => { const s = sp(); return regionIdx(loc.x - s.x, loc.z - s.z); };
// 地方の レベル（中心から 外へ・リスポーンから 遠い ほど 強い）
function regionLv0(dx, dz, i) {
  const R = WREGIONS[i];
  const dc = Math.hypot(R.c[0], R.c[1]), d = Math.hypot(dx, dz);
  const t = dc < R.r ? Math.min(1, d / R.r) : Math.max(0, Math.min(1, (d - (dc - R.r)) / (2 * R.r)));
  const far = Math.max(0, Math.hypot(dx - R.c[0], dz - R.c[1]) - R.r * 1.3);   // 地方の 外れの もっと 先
  return Math.min(100, Math.round(R.lv[0] + (R.lv[1] - R.lv[0]) * t + far / (60 * WS)));
}
// v3.0: 地方の さかい（となりの 弱い 地方から 約 60 ブロック）は 弱い ほうに なめらかに つなぐ（序盤に 強い 野生が 歩いて こない）
export function regionLv(loc) {
  const s = sp(), dx = loc.x - s.x, dz = loc.z - s.z;
  const nd = WREGIONS.map((R, k) => [Math.hypot(dx - R.c[0], dz - R.c[1]) / R.r, k]).sort((a, b) => a[0] - b[0]);
  const [n1, i1] = nd[0], [n2, i2] = nd[1];
  const l1 = regionLv0(dx, dz, i1), l2 = WREGIONS[i2].lv[0];
  if (l2 >= l1) return l1;
  const t = Math.max(0, Math.min(1, (n2 - n1) / 0.25));
  return Math.round(l2 + (l1 - l2) * t);
}
export const castlePos = (i) => { if (!LAYOUT.ok) ensureLayout(); const s = sp(), R = WREGIONS[i], a = R.castle.at || R.c; return { x: Math.floor(s.x + a[0]), z: Math.floor(s.z + a[1]) }; };
// ステージ（テーマの 大地）: 地方ごとに 3か所
// v3.0: 町・城と 重ならない 場所を えらぶ（スポーンからの ずれで 1回だけ・地方の 順に まとめて 計算して 覚える）
let AVOID = []; const LS_MEMO = new Map();
export function setAvoidPoints(list) { AVOID = list; LS_MEMO.clear(); }
function siteOffsets(i) {
  if (!LAYOUT.ok) ensureLayout();
  if (LAYOUT.v >= 2) return LAYX(LAYOUT.v).lands[i];
  if (!LS_MEMO.has(i)) for (let k = 0; k < WREGIONS.length; k++) if (!LS_MEMO.has(k)) siteOffsets1(k);   // よぶ 順番で 結果が かわらない ように
  return LS_MEMO.get(i);
}
function siteOffsets1(i) {
  const R = WREGIONS[i], out = [];
  const others = () => [...AVOID, ...[...LS_MEMO.values()].flat(), ...out];
  R.land.forEach((th, k) => {
    const a0 = ((k * 120 + i * 37) * Math.PI) / 180; let best = null, bv = -1;
    for (const f of [0.5, 0.62, 0.38, 0.72]) for (let j = 0; j < 18; j++) {
      const a = a0 + (j % 2 ? 1 : -1) * Math.ceil(j / 2) * (Math.PI / 9), x = R.c[0] + Math.cos(a) * R.r * f, z = R.c[1] + Math.sin(a) * R.r * f;
      if (regionIdx(x, z) !== i) continue;
      const d = Math.min(1e9, ...others().map((p) => Math.hypot(p[0] - x, p[1] - z)));
      if (d > bv) { bv = d; best = [Math.round(x), Math.round(z)]; }
      if (d >= 110) break;
    }
    out.push(best || [Math.round(R.c[0] + Math.cos(a0) * R.r * 0.5), Math.round(R.c[1] + Math.sin(a0) * R.r * 0.5)]);
  });
  LS_MEMO.set(i, out); return out;
}
export function landSites(i) {
  const s = sp(), R = WREGIONS[i], off = siteOffsets(i);
  return R.land.map((th, k) => ({ key: `mrpg:land:${i}:${k}`, theme: th, x: Math.floor(s.x + off[k][0]), z: Math.floor(s.z + off[k][1]) }));
}

// 町の 名前（地方ごとに かぶらない）
const KIND = ["村", "町", "里", "村", "町", "港", "市", "砦"];
const TN_MEMO = new Map();
export function townName(i, k) {   // v3.0: 同じ 地方で 名前が かぶらない ように（前の 町で 使った 名前の 部品は とばす）
  const key = i * 1000 + k; if (TN_MEMO.has(key)) return TN_MEMO.get(key);
  const R = WREGIONS[i], n = R.pre.length, L = R.kana.length, usedB = new Set();
  let out = "";
  for (let q = 0; q <= k; q++) {
    const a = R.pre[q % n];
    let bi = (q + Math.floor(q / n) * 3) % L, tries = 0;
    while (usedB.has(R.kana[bi]) && tries++ < L) bi = (bi + 1) % L;
    let b = R.kana[bi]; if (usedB.has(b)) { for (const sx of ["ヶ丘", "の里", "台", "ヶ浜", "の森"]) if (!usedB.has(b + sx)) { b = b + sx; break; } } usedB.add(b);   /* 第71版:「２」を やめる */
    const kind = R.id === "mari" && q % 2 === 0 ? "港" : R.id === "ruins" && q % 3 === 2 ? "砦" : KIND[q % 3];
    out = `${a} ${kind} ${b}`;
  }
  TN_MEMO.set(key, out); return out;
}

// v3.0: 地方に あう 地面か（町を 置く 場所えらび）。+1 あう・-1 あわない・-2 水
const FIT = {
  arca: [/grass_block|dirt|flower|short_grass|oak/, /snow|ice|sand|terracotta|mycelium/],
  silva: [/grass_block|moss|mud|leaves|log|fern|podzol/, /snow|ice|sand|terracotta/],
  ruins: [/coarse_dirt|gravel|stone|andesite|terracotta|red_sand|dirt/, /snow|ice|leaves|flower/],
  volka: [/stone|andesite|basalt|blackstone|gravel|tuff|magma|coarse_dirt|red_sand|terracotta/, /snow|ice|leaves|flower|short_grass|fern/],
  sand: [/sand|sandstone|terracotta|deadbush|cactus/, /snow|ice|leaves|grass_block|moss/],
  crys: [/stone|calcite|tuff|andesite|diorite|gravel|amethyst/, /snow|leaves|flower|sand/],
  mari: [/sand|grass_block|palm|jungle/, /snow|ice|terracotta|stone/],
  necro: [/soul|podzol|coarse_dirt|gravel|stone|mycelium|dark_oak/, /snow|ice|flower|sand/],
  frost: [/snow|ice|spruce|powder/, /sand|terracotta|jungle|acacia|flower/],
  ragna: [/stone|basalt|blackstone|netherrack|gravel|terracotta|red_sand/, /snow|ice|flower|leaves/],
  celes: [/grass_block|flower|cherry|birch|dirt/, /snow|ice|sand|terracotta/],
};
export function fitScore(regionId, typeId) {
  const id = String(typeId || "").replace("minecraft:", ""); if (/water|lava/.test(id)) return -2;
  const F = FIT[regionId]; if (!F) return 0;
  return F[0].test(id) ? 1 : F[1].test(id) ? -1 : 0;
}
