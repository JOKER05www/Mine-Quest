// 第125版: 前の 版の ステージ（平らな 大地・テーマが 変わった 大地・見た目の 版が 古い 大地）を、近づいた ときに 1つずつ 作りなおす。
// 安全の ため: 出来事（地下の 部屋）が ある ステージ・プレイヤーが 作った ものが ある ステージ・人が 上に いる ステージは さわらない。
// 作りなおしでは 宝箱を 置かない（ごほうびは 1回）。重くしない: 10秒に 1回だけ 見て、1回に 1か所。
import { world, system } from "@minecraft/server";
import { WREGIONS, landSites } from "./worldmap.js";
import { LAND_PV } from "./dgthemes.js";
import { landInfo, makeLand, landQ, building } from "./structures.js";
import { busy, warming } from "./ui.js";
import { stageNear } from "./stage.js";
import { EVS, evInfo } from "./stageev.js";

/* プレイヤーが 置く ブロック（ステージの 地形には 使わない もの）*/
const PB = /bed|door|crafting_table|furnace|smoker|glass|wool|concrete|glazed|bookshelf|barrel|anvil|enchanting|brewing|hopper|torch|sign|banner|campfire|loom|composter|bell|shulker|frame|flower_pot|candle|carpet|rail|farmland|hay_block|terracotta|_stairs|_slab|bricks_wall|crafter|lectern|chiseled_bookshelf/;
export function landNeedsRedo(L, li) {
  if (!li || !li.built || li.skip || li.nr) return false;
  return li.theme !== L.theme || !li.tv || (li.pv || 1) < (LAND_PV[L.theme] || 1);
}
export const landHasEvent = (i, k) => EVS.some((e) => e.r === i && e.k === k) && !!evInfo(i);
/* 9×9 点を 見る。null = 読みこまれて いない / true = 作った ものが ある */
export function playerBuilt(dim, x, z, y) {
  for (let dx = -20; dx <= 20; dx += 5) for (let dz = -20; dz <= 20; dz += 5) {
    if (dx * dx + dz * dz > 24 * 24) continue;
    let t = null; try { t = dim.getTopmostBlock({ x: Math.floor(x + dx), z: Math.floor(z + dz) }); } catch { return null; }
    if (!t) return null;
    if (t.location.y > y + 40 || PB.test(t.typeId)) return true;
  }
  return false;
}
const TRIED = new Set();
export function redoTick() {
  if (building() || warming()) return false;
  const ow = world.getDimension("overworld"), PL = world.getAllPlayers().filter((p) => p.dimension.id === "minecraft:overworld");
  if (!PL.length) return false;
  for (let i = 0; i < WREGIONS.length; i++) {
    const S = landSites(i);
    for (let k = 0; k < S.length; k++) {
      const L = S[k]; if (TRIED.has(L.key) || landQ(L.key)) continue;
      const li = landInfo(L.key); if (!landNeedsRedo(L, li) || typeof li.y !== "number") continue;
      const d = Math.min(...PL.map((p) => Math.hypot(p.location.x - L.x, p.location.z - L.z)));
      if (d > 96 || d < 36) continue;   /* 近くに 来た とき。上に 立って いる ときは 待つ（うまらない ように）*/
      if (PL.some((p) => busy.has(p.id) && Math.hypot(p.location.x - L.x, p.location.z - L.z) < 140) || stageNear(L.x, L.z)) continue;
      if (landHasEvent(i, k)) { world.setDynamicProperty(L.key, JSON.stringify({ ...li, nr: 1 })); continue; }
      const pb = playerBuilt(ow, L.x, L.z, li.y); if (pb === null) continue;
      if (pb) { world.setDynamicProperty(L.key, JSON.stringify({ ...li, nr: 1 })); continue; }
      TRIED.add(L.key);
      makeLand(L, ow, li.y, false, true);
      return true;
    }
  }
  return false;
}
system.runInterval(() => { try { redoTick(); } catch {} }, 200);
