// 第122版: 物語の 場面の 場所（目印）。町の 噴水の 広場は 使わない
// 城の 中庭・玉座の 間・城の 門の 前・町の 外れ・鍛冶場・オルドの 牧場・洞くつの 広間・港の 桟橋・宿・大聖堂の 前・廃都（大通り・壁画の 広間）
// 返す 形: { x, y, z, nm, r?, wait? }。y が null の ときは 現地で 地面を さがす。wait は「まだ できて いない（待つ）」
import { world } from "@minecraft/server";
import { WREGIONS, landSites, regionIdx } from "./worldmap.js";
import { castleInfo, castleSpot, caveInfo, caveSite, caveName, landInfo, TOWNS, getTown, townPos, caveBox, DG_ALL, siteOf, getRuin } from "./structures.js";

export const SPOT_V = 122;
export const PLACES = new Set(["ranch", "court", "throne", "gate", "out", "forge", "harbor", "beach", "inn", "church", "hall", "street", "mural", "stage", "road", "library"]);
const F = (q) => ({ x: Math.floor(q.x), y: typeof q.y === "number" ? Math.floor(q.y) : null, z: Math.floor(q.z) });
export function spotOf(id, k) { try { const w = JSON.parse(world.getDynamicProperty(`mrpg:walk:${id}`) || "null"); const q = w && Array.isArray(w.p) && w.p.find((x) => x[0] === k); return q ? { x: w.x + q[1], y: w.y + q[2], z: w.z + q[3], ...(q.length >= 6 ? { fx: w.x + q[4] + 0.5, fz: w.z + q[5] + 0.5 } : {}) } : null; } catch { return null; } }
/* 第125版(pl): 町の 建物の 前（戸口の 外 2マス）。kinds を 順に さがす。fx,fz = 建物の 中（舞台は そちらを 向く）*/
export const BLD_NM = { inn: "宿", shop: "店", forge: "鍛冶屋", armor: "防具屋", tavern: "酒場", library: "図書館", cafe: "カフェ", diner: "食堂", home: "家", home2: "家", home3: "家", harbor: "港", plaza: "広場", eggs: "タマゴ屋" };
export function bldOf(tid, kinds, nm) {
  const t = TOWNS.find((u) => u.id === tid); if (!t) return null;
  for (const k of [].concat(kinds)) {
    const q = spotOf(tid, k); if (!q) continue;
    let x = q.x + 0.5, z = q.z + 0.5;
    if (Number.isFinite(q.fx)) { const dx = x - q.fx, dz = z - q.fz, n = Math.hypot(dx, dz) || 1; x += (dx / n) * 2; z += (dz / n) * 2; }
    return { x: Math.floor(x), y: q.y, z: Math.floor(z), nm: nm || `${t.name}の ${BLD_NM[k] || k}`, tid, k, ...(Number.isFinite(q.fx) ? { fx: q.fx, fz: q.fz } : {}) };
  }
  return null;
}
const built = (id) => { try { const q = getTown(id); return !!(q && q.built); } catch { return false; } };
/* その 地方の 町（城に いちばん 近い。右上の 案内と 同じ 決まり）。ルミナの 地方は ルミナ */
export function regTown(r) {
  if (r === 0) { const t = TOWNS.find((u) => u.id === "t0"); if (t) return { t, q: townPos(t) }; }
  let c = null; try { c = castleInfo(r) || castleSpot(r); } catch {}
  let best = null, bd = 1e18;
  for (const t of TOWNS) { if (t.reg !== r) continue; const q = townPos(t); const dd = c ? (q.x - c.x) ** 2 + (q.z - c.z) ** 2 : 0; if (dd < bd) { bd = dd; best = { t, q }; } }
  return best;
}
/* 町の 中心から 城と 反対の 方へ 56マス（turn だけ 回す）*/
function outOf(r, turn, nm, t0 = null) {
  const T = t0 ? { t: t0, q: townPos(t0) } : regTown(r); if (!T) return null;
  let c = null; try { c = castleInfo(r) || castleSpot(r); } catch {}
  const q = T.q, a0 = (c && Math.hypot(q.x - c.x, q.z - c.z) > 1 ? Math.atan2(q.z - c.z, q.x - c.x) : Math.PI / 2) + turn;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  /* 同じ 地方の 中で、ほかの 城・町に 近すぎない 向き（決まった 順に 試す）*/
  for (const da of [0, 0.8, -0.8, 1.6, -1.6, 2.4, -2.4, Math.PI]) {
    const a = a0 + da, x = Math.floor(q.x + Math.cos(a) * 56), z = Math.floor(q.z + Math.sin(a) * 56);
    let bad = regionIdx(x - s0.x, z - s0.z) !== r;
    if (!bad) for (let i = 0; i < WREGIONS.length && !bad; i++) { if (i === r) continue; try { const k = castleInfo(i) || castleSpot(i); if (k && Math.hypot(k.x - x, k.z - z) < 90) bad = true; } catch {} }
    if (!bad) for (const u of TOWNS) { if (u.id === T.t.id) continue; const w = townPos(u); if (Math.hypot(w.x - x, w.z - z) < 50) { bad = true; break; } }
    if (!bad) return { x, y: null, z, nm: `${T.t.name}の ${nm}`, tid: T.t.id };
  }
  return { x: Math.floor(q.x + Math.cos(a0) * 56), y: null, z: Math.floor(q.z + Math.sin(a0) * 56), nm: `${T.t.name}の ${nm}`, tid: T.t.id };
}
/* 名前の 町の 外れ（城と 反対・その 町の 地方の 中）*/
export function townOut(tid, turn, nm) { const t = TOWNS.find((u) => u.id === tid); if (!t) return null; const o = outOf(t.reg, turn, nm, t); return o; }
/* オルドの 牧場（ルミナの 外の 放牧地）。一度 場面が 起きたら その 場所を 記録する */
export function ranchSpot() {
  try { const v = JSON.parse(world.getDynamicProperty("mrpg:ranch") || "null"); if (v && typeof v.y === "number") return { x: v.x, y: v.y, z: v.z, nm: "オルドの 牧場", rec: 1 }; } catch {}
  const o = outOf(0, 0.9, "外れ"); return o ? { ...o, nm: "オルドの 牧場" } : null;
}
export function ranchSave(q) { try { if (q && typeof q.y === "number") world.setDynamicProperty("mrpg:ranch", JSON.stringify({ x: Math.floor(q.x), y: Math.floor(q.y), z: Math.floor(q.z) })); } catch {} }
/* 場所を 決める。need: 場面の とちゅうで 移る とき（できて いない 所へは 移らない）*/
export function placeOf(kind, r, need = false) {
  try {
    const R = WREGIONS[r]; if (!R) return null;
    const ci = castleInfo(r), cb = !!(ci && ci.built && ci.m);
    const cs = () => { if (need) return null; const c = castleSpot(r); return c ? { x: Math.floor(c.x), y: null, z: Math.floor(c.z), nm: R.castle.name } : null; };
    const land = (n, nm) => { const L = landSites(r)[n] || landSites(r)[0]; if (!L) return null; const I = landInfo(L.key); if (need && !(I && I.built)) return null; return { x: Math.floor(L.x) + 14, y: null, z: Math.floor(L.z) + 6, nm }; };
    switch (kind) {
      case "ranch": { const q = ranchSpot(); return q && (!need || q.rec || built("t0")) ? q : null; }
      case "court": return cb ? { ...F(ci.m), nm: `${R.castle.name}の 中庭` } : cs();
      case "throne": return cb && ci.k ? { ...F(ci.k), nm: `${R.castle.name} 玉座の 間` } : cs();
      case "gate": return cb ? { ...F({ x: ci.m.x, y: ci.m.y, z: ci.m.z + 5 }), nm: `${R.castle.name}の 城門の 内側` } : cs();   /* 門の 外は 城下の 像に 近い（9マス）ので、くぐった 内側 */
      case "out": case "forge": {
        if (kind === "forge" && r === 3) { const T = regTown(3), q = T && farOf("r3forge", T.t.id, "ようがんの 里 ラヴィの 外れの 鍛冶場", 80, 220); if (q) return q; }   /* 第127版(fac2): ラヴィの 鍛冶場は 町から 80 以上 離れた 広い 所（大きな 鍛冶場の 屋敷が 建つ）*/
        const o = outOf(r, kind === "forge" ? 0.9 : 0, kind === "forge" ? "外れの 鍛冶場" : "外れの 丘"); return o && (!need || built(o.tid)) ? o : null; }
      case "harbor": case "beach": {
        const T = regTown(r), h = T && spotOf(T.t.id, "harbor");
        if (h) return kind === "harbor" ? { ...F(h), nm: `${T.t.name}の 港の 桟橋` } : { x: Math.floor(h.x) + 26, y: null, z: Math.floor(h.z) - 6, nm: `${T.t.name}の 夜の 浜` };
        const o = outOf(r, kind === "beach" ? -0.9 : 0, kind === "beach" ? "夜の 浜" : "港"); return o && (!need || built(o.tid)) ? o : null;
      }
      case "stage": return land(0, `${R.short}の 大地`);
      case "road": {   /* 町と 城を 結ぶ 街道の とちゅう（城の 外、城から 95マス 町の 方へ）*/
        const T = regTown(r), c = (() => { try { return castleInfo(r) || castleSpot(r); } catch { return null; } })(); if (!T || !c) return null;
        let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
        const L = Math.hypot(T.q.x - c.x, T.q.z - c.z) || 1, ux = (T.q.x - c.x) / L, uz = (T.q.z - c.z) / L;
        for (const k of [95, 85, 110, 75]) { if (k > L - 50) continue; const x = Math.floor(c.x + ux * k), z = Math.floor(c.z + uz * k); if (regionIdx(x - s0.x, z - s0.z) === r) return { x, y: null, z, nm: r === 2 ? "廃都の 手前の 崖道" : `${R.short}の 街道`, tid: T.t.id }; }
        const o = outOf(r, 0, "街道"); return o ? { ...o, nm: r === 2 ? "廃都の 手前の 崖道" : `${R.short}の 街道` } : null;
      }
      case "inn": { const T = regTown(r), q = T && spotOf(T.t.id, "inn"); return q ? { ...F(q), nm: `${T.t.name}の 宿` } : null; }
      case "library": {   /* 第127版(fac3): 城の 書庫 ＝ 城の 丘の 西の 本の 館（capitalPlan の 館 x-31・z-34。戸は 東）の 戸の 前。前は「玉座」で、城が まだ ない ときは 城の 中心（噴水の 0.7 マス）に なって いた */
        let w = null; try { w = JSON.parse(world.getDynamicProperty(`mrpg:walk:c${r}`) || "null"); } catch {}
        if (cb && w && Number.isFinite(w.x) && Number.isFinite(w.y)) return { x: w.x - 23, y: w.y + 12, z: w.z - 34, nm: `${R.castle.name}の 書庫`, fx: w.x - 30.5, fz: w.z - 33.5 };
        if (need) return null; const c = castleSpot(r); return c ? { x: Math.floor(c.x) - 23, y: null, z: Math.floor(c.z) - 34, nm: `${R.castle.name}の 書庫` } : null;
      }
      case "church": { const q = spotOf(`c${r}`, "church"); return q ? { ...F(q), nm: `${R.castle.name} 大聖堂の 前` } : null; }
      case "hall": { const v = caveInfo(r); if (v && v.built && v.hall) return { ...F(v.hall), nm: `${caveName(r)}の 広間`, r: 7 }; if (need) return null; const c = caveSite(r); return { x: Math.floor(c.x), y: null, z: Math.floor(c.z), nm: `${caveName(r)}の 広間`, wait: 1 }; }
      case "street": case "mural": {
        const ru = ci && ci.ruin && ci.ruin[kind];
        if (ru) return { ...F(ru), nm: kind === "street" ? "廃都の 崩れた 大通り" : "廃都 壁画の 広間" };
        return land(kind === "street" ? 0 : 1, kind === "street" ? "廃都の 跡（崩れた 大通り）" : "廃都の 跡（壁画の 広間）");
      }
    }
  } catch {}
  return null;
}
/* 第123版: 牧場と 鍛冶場は 何も ない 野原に ならない ように、場面の まわりに 小道具を 1回だけ 置く（舞台の 外側。立ち位置と カメラを ふさがない）*/
import { groundY as _gy } from "./structures.js";
import { facBuild } from "./epfac.js";
export function decorPlace(dim, kind, P, S = null) {
  if (!P || (kind !== "ranch" && kind !== "forge")) return false;
  if (kind === "forge" && S && S.f) { const q = facBuild({ dimension: dim }, S, "r3smithy", "smithy", 3, Math.floor(P.y)); if (q) { try { world.setDynamicProperty("mrpg:decor:forgeat", JSON.stringify({ x: q.x, y: Math.floor(q.y - 1.4), z: q.z })); } catch {} return true; } }   /* 第125版(pl): 刀鍛冶の 鍛冶場（人の すぐ 後ろ）。建てられない 所は 前の 作業場 */
  const key = `mrpg:decor:${kind}`;
  try { const v = JSON.parse(world.getDynamicProperty(key) || "null"); if (v && Math.hypot(v.x - P.x, v.z - P.z) < 64) return false; } catch {}   /* 第123版: 2人目の 舞台が 少し ずれても 2つ目を 作らない */
  const cx = Math.floor(P.x), cz = Math.floor(P.z), y0 = Math.floor(P.y);
  /* 第123版: 納屋・作業場は 近い 町と 反対の 側へ（ルミナの 塀の 中に 納屋が できて いた）*/
  const TQ = []; for (const t of TOWNS) { try { const q = townPos(t); if (Math.hypot(q.x - cx, q.z - cz) < 130) TQ.push(q); } catch {} }
  const far = kind === "ranch" ? [19, -12] : [-12, 0]; let sx = 1, sz = 1, best = -1;   /* 納屋・作業場の まん中が いちばん 町から 遠く なる 向き */
  for (const a of [1, -1]) for (const b of [1, -1]) { let m = 1e9; for (const q of TQ) m = Math.min(m, Math.hypot(cx + far[0] * a - q.x, cz + far[1] * b - q.z)); if (m > best + 0.5) { best = m; sx = a; sz = b; } }
  const mx = (x) => cx + (x - cx) * sx, mz = (z) => cz + (z - cz) * sz;
  const gy = (x, z) => { try { const y = _gy(dim, mx(x), mz(z), y0); return typeof y === "number" && Math.abs(y - y0) <= 4 ? y : null; } catch { return null; } };
  const put = (x, y, z, b) => { try { dim.runCommand(`setblock ${mx(x)} ${y} ${mz(z)} ${b} keep`); } catch {} };
  const at = (dx, dz, b, up = 0) => { const y = gy(cx + dx, cz + dz); if (y !== null) put(cx + dx, y + up, cz + dz, b); };
  if (kind === "ranch") {
    const R = 12;   /* 放牧地の 柵（四方に 3マスの 入口）*/
    for (let i = -R; i <= R; i++) for (const [dx, dz] of [[i, -R], [i, R], [-R, i], [R, i]]) { if (Math.abs(i) <= 1) continue; at(dx, dz, "oak_fence"); }
    for (const [dx, dz] of [[-15, -6], [-15, -5], [-16, -6], [15, 8], [16, 8], [15, 9]]) at(dx, dz, "hay_block");
    for (const [dx, dz] of [[-15, 4], [-15, 5]]) at(dx, dz, "cauldron");
    /* 小さな 納屋（柵の 外・北東）*/
    const bx = 17, bz = -14, by = gy(cx + bx, cz + bz);
    if (by !== null && [[0, 0], [4, 0], [0, 3], [4, 3]].every(([a, b]) => gy(cx + bx + a, cz + bz + b) !== null)) {   /* すみが 水・崖なら 建てない */
      for (let x = 0; x < 5; x++) for (let z = 0; z < 4; z++) { const edge = x === 0 || x === 4 || z === 0 || z === 3, g = edge ? gy(cx + bx + x, cz + bz + z) : null; for (let h = g !== null && g < by ? g - by : 0; h < 3; h++) if (edge && !(z === 3 && x === 2 && h < 2)) put(cx + bx + x, by + h, cz + bz + z, x === 0 || x === 4 ? "spruce_log" : "spruce_planks"); put(cx + bx + x, by + 3, cz + bz + z, "spruce_slab"); }
      put(cx + bx + 2, by, cz + bz + 1, "hay_block");
    }
    { const y = gy(cx + 2, cz + R + 2); if (y !== null) { put(cx + 2, y, cz + R + 2, "oak_fence"); put(cx + 2, y + 1, cz + R + 2, "lantern"); } }
  } else {
    /* 鍛冶場: 屋根だけの 作業場（舞台の 西 10マス）と 炉・金床・煙突 */
    const fx = -15, fz = -3, fy = gy(cx + fx + 3, cz + fz + 3) ?? gy(cx + fx, cz + fz);   /* 高さは 作業場の まん中で（すみが 崖・水でも 作る）*/   /* 第123版: 舞台の 人・引きの カメラ（後ろ 6）から 9マス 以上 はなす */
    if (fy !== null && [[0, 0], [6, 0], [0, 6], [6, 6]].every(([a, b]) => gy(cx + fx + a, cz + fz + b) !== null)) {   /* すみが 水・崖なら 建てない */
      try { dim.runCommand(`fill ${mx(cx + fx)} ${fy - 1} ${mz(cz + fz)} ${mx(cx + fx + 6)} ${fy - 1} ${mz(cz + fz + 6)} stone_bricks replace grass_block`); } catch {}   /* 草だけ 置きかえる（水・溶岩・道・建物の 床は そのまま）*/
      for (const [x, z] of [[0, 0], [6, 0], [0, 6], [6, 6]]) { const g = gy(cx + fx + x, cz + fz + z); for (let h = g !== null && g < fy ? g - fy : 0; h < 3; h++) put(cx + fx + x, fy + h, cz + fz + z, "dark_oak_log"); }
      for (let x = 0; x <= 6; x++) for (let z = 0; z <= 6; z++) put(cx + fx + x, fy + 3, cz + fz + z, "dark_oak_slab");
      put(cx + fx + 1, fy, cz + fz + 1, "blast_furnace"); put(cx + fx + 2, fy, cz + fz + 1, "blast_furnace");
      put(cx + fx + 3, fy, cz + fz + 3, "anvil"); put(cx + fx + 4, fy, cz + fz + 1, "smithing_table");
      put(cx + fx + 1, fy, cz + fz + 4, "lava_cauldron"); put(cx + fx + 5, fy, cz + fz + 5, "barrel");
      for (let h = 2; h < 6; h++) put(cx + fx + 1, fy + 1 + h, cz + fz + 1, "cobblestone_wall");   /* air keep は 何も しない ので 送らない */
      try { world.setDynamicProperty("mrpg:decor:forgeat", JSON.stringify({ x: mx(cx + fx + 3) + 0.5, y: fy, z: mz(cz + fz + 3) + 0.5 })); } catch {}   /* 第124版(合議): 第4章の 火事は 作業場で 燃やす */
      put(cx + fx + 1, fy, cz + fz + 2, "campfire");   /* 宙に 浮かない ように 地面に */
    }
  }
  try { world.setDynamicProperty(key, JSON.stringify({ x: cx, z: cz })); } catch {}
  return true;
}
/* 第127版(fac): 町・城・ステージ（大地）・洞くつ・遺跡から 離れた 広い 所（物語の 施設を 建てる 場所）。
   c の まわり rMin〜rMax の 輪を 調べ、いちばん 何も ない 所（近い 物から の あき）を えらぶ。同じ 地方の 中・地方の 境から 30 以上 内側。
   一度 決めた 所は 記録する（mrpg:osite）。施設どうしも 離す */
const OSK = "mrpg:osite";
const osAll = () => { try { return JSON.parse(world.getDynamicProperty(OSK) || "{}") || {}; } catch { return {}; } };
export function stageAvoid(L, rLand = 100, rCave = 30) {
  for (let i = 0; i < WREGIONS.length; i++) { try { for (const S of landSites(i)) L.push([S.x, S.z, rLand]); } catch {} }
  for (const i of DG_ALL) { try { if (!caveInfo(i)) continue; const b = caveBox(i); L.push([(b.x1 + b.x2) / 2, (b.z1 + b.z2) / 2, Math.hypot(b.x2 - b.x1, b.z2 - b.z1) / 2 + rCave]); } catch {} }
  return L;
}
export function openSite(key, c, reg, rMin = 90, rMax = 450, nm = "", near = []) {
  const all = osAll(); if (all[key] && Number.isFinite(all[key].x)) return { x: all[key].x, z: all[key].z, nm: nm || all[key].nm || "" };
  if (!c || !Number.isFinite(c.x)) return null;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  const av = near.filter(Boolean).slice();
  for (const t of TOWNS) { try { const q = getTown(t.id), w = q && q.built ? q : townPos(t); av.push([w.x, w.z, 75]); } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) { try { const k = castleInfo(i) || castleSpot(i); if (k) av.push([k.x, k.z, 100]); } catch {} }
  stageAvoid(av, 90, 30);
  for (const [k, v] of Object.entries(all)) if (k !== key && v && Number.isFinite(v.x)) av.push([v.x, v.z, 48]);   /* 第127版(fac2): 施設どうし 48（はじまりの 地方は せまい）*/
  const inReg = (x, z) => regionIdx(x - s0.x, z - s0.z) === reg;
  const ruinD = (x, z) => { let m = 1e9; try { const R = 176, rx = Math.floor(x / R), rz = Math.floor(z / R); for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { const s = siteOf("minecraft:overworld", rx + a, rz + b); const r = getRuin(s.key); if (r && r.skip) continue; m = Math.min(m, Math.hypot(s.x - x, s.z - z) - 40); } } catch {} return m; };
  let best = null;
  for (let r = rMin; r <= rMax; r += 20) for (let a = 0; a < 32; a++) {
    const t = (a / 32) * Math.PI * 2 + r * 0.013, x = Math.floor(c.x + Math.cos(t) * r), z = Math.floor(c.z + Math.sin(t) * r);
    if (!inReg(x, z) || ![[30, 0], [-30, 0], [0, 30], [0, -30]].every(([dx, dz]) => inReg(x + dx, z + dz))) continue;
    let m = ruinD(x, z); for (const [X, Z, D] of av) m = Math.min(m, Math.hypot(X - x, Z - z) - D);
    const v = Math.min(m, 60) - r * 0.03;
    if (!best || v > best.v) best = { x, z, v, m };
  }
  if (!best) return null;
  all[key] = { x: best.x, z: best.z, nm }; try { world.setDynamicProperty(OSK, JSON.stringify(all)); } catch {}
  return { x: best.x, z: best.z, nm, m: Math.round(best.m) };
}
/* 第127版(fac2): 町の 外れ（55〜60）では なく、町から 離れた 広い 所（openSite）。戦い・旅の 場面と、大きな セットの ある 場面。
   key ごとに 1か所（本の 話と 地方の 話で 同じ キーを 使う）。中心は tid の 町（建った 町なら その 中心）*/
export function farOf(key, tid, nm, rMin = 90, rMax = 320, near = []) {
  const t = TOWNS.find((u) => u.id === tid); if (!t) return null;
  let c = null; try { const g = getTown(tid); c = g && g.built ? g : townPos(t); } catch {} if (!c) return null;
  const q = openSite(key, c, t.reg, rMin, rMax, nm, near); return q ? { x: q.x, z: q.z, nm } : null;
}
