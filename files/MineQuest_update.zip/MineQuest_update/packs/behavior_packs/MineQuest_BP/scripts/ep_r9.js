/* 第125版: 第10地方 ラグナ（さいはての 村 エンド・竜骨の 城 ラグナロク）の 5話
   1 さいはての 村（竜の 巫女 シズク。竜の 鱗の 墓標の 言い伝え）→ 2 最後の 静けさ（竜祭りの 夜。旅の 仲間と 手帳を 書く。ベリルは 明日の 願いを 残す）
   → 3 守り手（儀式を 止めようと する 竜骨の 守り手。オルドと ハクが しんがりに 残る）→ 4 祭壇（今の 段: 儀式・旅の 仲間の 死・ハクの 石化）
   → 5 墓標（第125版(ce): 祭壇の あと すぐ。見晴らし台で 弔い → ソラの 試し（ここで 戦う。勝つと 石板）→ シズクが 竜の 鱗の 墓標を 立てる。城下町では 戦わない）
   祭壇と ベリルの 最後の 願い（戦い）は 今の 段に ある。ここでは その 前後を ふくらませる（同じ ことを 二度 しない）*/
import { epAdd } from "./sagaep.js";
import { castAdd, doomed, doomKnown } from "./cast.js";
import { townOut, placeOf, bldOf, farOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, groundY } from "./structures.js";
import { world } from "@minecraft/server";
import { qs, giveSlab } from "./quest.js";
import { load, save } from "./store.js";
import { rmTeam } from "./rmaster.js";
import { ok, choose, ICON } from "./ui.js";
import { SPECIES, ORDER } from "./data.js";
import { regionIdx } from "./worldmap.js";
import { heroType } from "./saga.js";
import { fac, facFront } from "./epfac.js";

/* ---------- 場所 ---------- */
const endC = () => { const t = TOWNS.find((u) => u.id === "t27"); if (!t) return null; const g = getTown("t27"); return g && g.built ? { x: g.x, y: g.y, z: g.z } : townPos(t); };
const LOOK = () => { const f = farOf("r9look", "t27", "エンドの 竜の 見晴らし台", 90, 260); if (f) return f; const o = townOut("t27", 0, "竜の 見晴らし台"); return o ? { x: o.x, z: o.z, nm: "エンドの 外れ（竜の 見晴らし台）" } : null; };
const FESTR = () => bldOf("t27", ["plaza", "inn"], "さいはての 村 エンドの 広場（竜祭り）") || (() => { const o = townOut("t27", -0.9, "竜祭りの 広場") || townOut("t27", 0.9, "竜祭りの 広場"); return o ? { x: o.x, z: o.z, nm: "エンドの 外れ（竜祭りの 広場）" } : null; })();   /* 第125版(rs): 祭りは 村の 広場（古い 町は 外れ）*/
const ROAD = () => {   /* エンドから 竜骨の 祭壇（ラグナの 大地）へ 6割 進んだ 道（地方の 中）*/
  const a = endC(), b = placeOf("stage", 9); if (!a || !b) { const r = placeOf("road", 9); return r ? { x: r.x, z: r.z, nm: "竜骨の 祭壇への 道" } : null; }
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  for (const f of [0.6, 0.5, 0.7, 0.4]) { const x = Math.floor(a.x + (b.x - a.x) * f), z = Math.floor(a.z + (b.z - a.z) * f); if (regionIdx(x - s0.x, z - s0.z) === 9) return { x, z, nm: "竜骨の 祭壇への 道" }; }
  return { x: Math.floor((a.x + b.x) / 2), z: Math.floor((a.z + b.z) / 2), nm: "竜骨の 祭壇への 道" };
};

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("shizuku", { nm: "シズク", role: "竜の 巫女", gobi: "ございます", skin: "sakuya", town: "t27", from: "r9e1",
  at: () => { const c = endC(); return c ? { x: c.x - 9, y: c.y, z: c.z + 9 } : null; },
  pre: ["{smile}竜の 村 エンドへ ようこそ おいで くださいました。"],
  after: [
    [(s) => !!s.ending, ["{smile}空が 晴れたので ございます。……鱗の 墓標に、今朝は 花が 一輪 ふえて おりました。", "{closed}だれかが、名前を 呼びに 来られたので ございましょう。"]],
    [(s) => doomKnown(s), ["{closed}灰が 降っても、墓標の 鱗は くもりません。……毎朝 みがいて おります。", "{sad}村の 人の 名前も、竜に 覚えて もらって おります。一人も、忘れさせは いたしません。"]],
    [(s) => doomed(s) && !!st(s).grave9, ["{smile}あの方の 名前は、竜が 覚えて おります。……あなたさまも、どうか 忘れないで くださいませ。"]],
    [(s) => !!s.heroDead, ["{sad}……祭壇の ことは、竜が 教えて くれました。", "{closed}見晴らし台で お待ちして おります。……竜の 鱗を、一枚 いただいて まいりました。"]],
    [(s) => !!st(s).fest9, ["{smile}竜祭りの 灯籠は、今も 空の どこかを ただよって おりましょう。"]],
    [() => true, ["{smile}竜祭りの 灯りは、竜の 背骨の 数だけ ともすので ございます。"]],
  ] });
castAdd("sora", { nm: "ソラ", role: "地方マスター", col: "§6", gobi: "", skin: "sora" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
const ORDO = (K, p, w = false) => K.npcNear(p, "§eオルド", K.PJ("ordo", 8), w);
const HAKU = () => (SPECIES.hbea14 ? "hbea14" : SPECIES.hbea01 ? "hbea01" : ORDER[0]);
const DRAG = () => (SPECIES.hdra12 ? "hdra12" : ORDER.find((x) => SPECIES[x].fam === "dragon" && SPECIES[x].sz === "L" && !SPECIES[x].hidden) || HAKU());
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
const HNm = (K, p) => { try { return K.HN(p); } catch { return "旅の 仲間"; } };
/* 竜の 鱗の 墓標（ワールドに 1回。舞台の 横）*/
async function grave(K, p, q) {
  if (!q) return; let v = 0; try { v = Number(world.getDynamicProperty("mrpg:epdeco:r9grave") || 0); } catch {}
  let y = null; try { y = groundY(p.dimension, Math.floor(q.x), Math.floor(q.z), Math.floor(q.y) + 4); } catch {}
  if (typeof y !== "number" || Math.abs(y - q.y) > 4) y = Math.floor(q.y);
  const x = Math.floor(q.x), z = Math.floor(q.z), put = (dx, dy, dz, b) => K.cmd(p, `setblock ${x + dx} ${y + dy} ${z + dz} ${b} keep`);
  if (!v) try { world.setDynamicProperty("mrpg:epdeco:r9graveat", JSON.stringify({ x: x + 0.5, y, z: z + 0.5 })); } catch {}   /* 第124版: 建てた 場所を 記録 */
  const steps = [[0, 0, 0, "polished_deepslate"], [0, 1, 0, "prismarine"], [0, 2, 0, "prismarine"], [0, 3, 0, "end_rod"], [1, 0, 0, "lily_of_the_valley"], [-1, 0, 0, "cornflower"], [0, 0, 1, "poppy"], [0, 0, -1, "lily_of_the_valley"]];
  for (const [k, [dx, dy, dz, b]] of steps.entries()) { if (!v) put(dx, dy, dz, b); K.burst(p.dimension, { x: x + 0.5 + dx, y: y + dy, z: z + 0.5 + dz }, "minecraft:villager_happy", 3, 0.4, 0.4); if (k === 0 || k === steps.length - 1) K.sound(p, dy ? "dig.stone" : "dig.grass", 0.8); await K.wait(5); }
  try { world.setDynamicProperty("mrpg:epdeco:r9grave", 1); } catch {}
}

/* ---------- 1話 さいはての 村 ---------- */
const E1 = { id: "r9e1", pv: 127, n: 1, t: "さいはての 村", at: 0, ord: 0, place: LOOK, fac: "r9look",
  hint: "§fラグナの §eさいはての 村 エンド§f の 外れ（竜の 見晴らし台）へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "竜を まつる さいはての 村 エンドで、竜の 巫女 シズクに 出会った。村では 大切な 人が 亡くなると、竜の 鱗で 墓標を 立てる。竜は その 名を 覚えて、千年 墓を 守るのだと いう。祭壇への 道は 竜祭りの 夜が 明けるまで 霧に 閉ざされて いた。ハクに 乗った オルドが 追いついた。シズクは オルドを 見て「四十年ぶり」と 言いかけた。",
  set: { met9: 1 },
  async run(p, d, K) {
    const FQ = fac(K, p, "r9look", "lookout", 9, Y(K, p));   /* 第125版(fac): 石の 見晴らし台（手すり・灯り）*/
    await K.open(p, "エンドの 竜の 見晴らし台", "day");
    K.sound(p, "mob.enderdragon.growl", 0.3);
    if (FQ) await K.at(p, FQ, 12, 7, 1.5);
    const eH = K.hero(p), eR = REI(K, p);
    const S = K.S(p), far = S ? S.at(26, -6, 10) : K.fwd(p, 20, -6, 10);
    const FF = FQ && facFront("r9look", 1.6), FS = FF ? (() => { const dx = FF.x - FQ.x, dz = FF.z - FQ.z, n = Math.hypot(dx, dz) || 1; return (s) => ({ x: FF.x - (dz / n) * s, y: Y(K, p), z: FF.z + (dx / n) * s }); })() : null;   /* 第125版(rs2): 見晴らし台の 前（台の 中へ 歩きこまない）*/
    if (ok(eR) && FS) { await K.walkCam(p, eR, FS(-1.3), 18); K.turn(eR, far); }   /* 第125版(rs): レイが 見晴らし台の 手すりへ 歩き、骨の 方を 見る */
    if (ok(eH) && FS) K.go(eH, FS(1.3), 16);
    await K.at(p, far, 18, 12, 0);
    await K.narr(p, ["§7地平線の 向こうに、山より 大きな 竜の 骨が 横たわって いた。", "§7白い 背骨が、雲の 下まで 続いて いる。"], far);
    await K.hsay(p, K.V(["{shock,!,up}うわあ……！ あれ、ぜんぶ 骨！？ 地図に 描ききれないよ！"], ["{shock,…,up}……大きい。あれが 竜の 骨なのね。"], ["{shock,…}……でかい。地図の 縮尺が 足りない。"], ["{shock,!,up}なんて 大きな……！ 地図の 紙が 足りません……！"]));
    K.act(eR, "hold");
    await K.say(p, "レイ", ["{closed}竜骨の 祭壇は、あの 骨の 根もとだ。……セオは、もう そこに いる。"], eH);
    const eS = K.cast(p, "shizuku"); K.act(eS, "hold"); K.hold(eS, "bell");
    await K.csay(p, "shizuku", ["{smile}ようこそ、さいはての 村 エンドへ。わたくしは 竜の 巫女、シズクで ございます。", "{closed}竜が、朝から 落ちつかぬ ようすで ございましたので……お客さまが 来られると 思って おりました。"]);
    await K.hsay(p, K.V(["{smile,♪}竜の 巫女さん！ ……竜の 声が わかるの？"], ["{smile}竜の 巫女さん……竜の 声が、聞こえるの？"], ["{?}……竜の 声が、聞こえるのか。"], ["{smile}竜の 巫女さま……竜の お声が、聞こえるのですか？"]));
    K.act(eS, "point"); if (ok(eS)) K.turn(eS, far);   /* 第125版(rs2): 竜骨の 方へ 向いて 語る */
    await K.csay(p, "shizuku", ["{smile,nod}少しだけ で ございます。あの 竜骨は、千年前に 祭壇を 守って いた 竜の なきがら。", "{closed,up}村では、こう 伝わって おります。……千年前、王の 友だった お方が、あの 祭壇の 前で 一晩 泣いて いた、と。"], eH);
    await K.past(p, "§7―― 千年前　竜骨の 祭壇"); await K.at(p, far, 16, 14, 1);   /* 第125版(rs2): 言い伝えは 回想の 札 → 骨の 根もとの 祭壇 */
    K.act(eS, 0); K.turn(eS);
    await K.ots(p, eS, eH, 8);   /* シズクの 肩ごしに 幼なじみ */
    await K.hsay(p, K.V(["{sad,?,up}王の 友だちが、泣いて いたの……？ なんで？"], ["{sad,up}……王さまの お友だちが？ どうして……"], ["{closed,?,up}……王の 友が？ 理由は。"], ["{sad,?,up}王さまの ご友人が……？ なぜ、泣いて おられたのでしょう。"]));
    await K.csay(p, "shizuku", ["{sad,no}それは、竜も 語りませぬ。……ただ、その お方が 去った あと、祭壇の 前に 竜の 鱗の 墓標が 一つ 立って いたので ございます。"]);
    K.act(eS, "hold");
    await K.approach(p, eS, eH, 1.9); await K.push(p, eS, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "shizuku", ["{closed,up}この 村では、大切な 人が 亡くなると、竜の 鱗で 墓標を 立てます。", "{smile,up}竜は その 名を 覚えて いて、千年 その 墓を 守るので ございます。"]);
    await K.hsay(p, K.V(["{smile,…}……すてきな 話。……でも、まだ 当分は いらないかな！ えへへ。"], ["{smile}……やさしい 言い伝え ね。……今は まだ、いらないけれど。"], ["{closed}……悪くない。今は、いらない けど。"], ["{smile}……やさしい お話です。……今は まだ、いりませんけれど。"]));
    K.re(eR, "closed", "…");
    await K.say(p, "レイ", ["{angry,up}……のんびり してる ひまは ない。祭壇へ 急ぐぞ。"]);
    K.act(eS, "guard");
    await K.csay(p, "shizuku", ["{sad,no}お待ち くださいませ。祭壇への 道は、竜祭りの 夜が 明けるまで、竜の 霧に 閉ざされて おります。", "{closed}だれが 何を しても、霧は 晴れませぬ。……竜が、祭りの 夜だけは 静かに 眠りたいと 申しますので。"]);
    await K.say(p, "レイ", ["{sweat,汗}……くそっ。じゃあ、セオも 祭壇の 中で 足止め か。", "{closed}……一晩 だけ だぞ。"]);
    /* オルドと ハク */
    K.sound(p, "mob.ravager.roar", 0.9); K.shake(p, 0.3, 0.5);
    const hq = K.fwd(p, 7, 3.5), hk = K.monEnt(p, K.fwd(p, 20, 9), HAKU(), "§fハク");   /* 第125版(rs2): ハクは 遠くから 土けむりを 立てて かけて くる */
    if (hk) { const w = K.go(hk, hq, 22, true); await K.at(p, hq, 14, 9, 1.5); await w; K.burst(p.dimension, hk.location, "minecraft:white_smoke_particle", 8, 1.2, 0.2); await K.push(p, hk, 22, 4.2, 1.7); }
    const eO = ORDO(K, p); K.act(eO, "hold");
    await K.say(p, "オルド", ["{smile,息}……ふう。間に 合ったわい。わしも 行くと、手紙に 書いた じゃろう。"]);
    await K.hsay(p, K.V(["{shock,!,up}村長！？ 腰、痛いって 言ってたのに！？"], ["{shock,up}村長さん！ ……あんなに 遠かったのに。"], ["{shock,!}……村長。息切れは。"], ["{shock,!,up}村長さま！？ お体は……！"]));
    await K.say(p, "オルド", ["{smile}ハクに 乗って 来たんじゃ。……わしの 足は、とっくに こやつの 足じゃよ。"]);
    await K.say(p, "レイ", ["{blush,汗}……じいちゃん。年寄りが 無理 すんなよ。"], eO);
    K.act(eS, 0); K.re(eS, "shock", "!");
    await K.up(p, eS, 12);
    await K.csay(p, "shizuku", ["{shock,…,up}……オルドさま？ まあ……祖母から 聞いて おります。四十年前、お二人で 来られた――"]);
    K.act(eO, "point"); if (ok(eO)) K.turn(eO, far);   /* 第125版(rs2): 竜骨の 方へ 背を 向けて さえぎる */
    await K.say(p, "オルド", ["{closed,low}……シズク。その 話は、ええ。"]);
    await K.csay(p, "shizuku", ["{sad,nod}……失礼 いたしました。"]);
    await K.hsay(p, K.V(["{?}……（お二人？ 村長と、だれ？）"], ["{?}……（お二人……？）"], ["{?}……（二人。もう 一人は 誰だ）"], ["{?}……（お二人……？ どなたと……？）"]));
    K.act(eO, 0); K.turn(eO);
    await K.csay(p, "shizuku", ["{smile,up}今夜は 竜祭りで ございます。村の 外れの 広場に、竜の 背骨の 数だけ 灯りを ともします。", "{smile}どうか、皆さまも。……旅の 方の 名前も、竜に 覚えて もらいましょう。"]);
    K.pay(p, E1, 2000, [["c_herbs2", 2]]);
    await K.end(p, { leave: [eS, eO], bye: [eR], card: "§7― 竜祭りの 夜 ―\n§7→ エンドの 外れの §e竜祭りの 広場§7 へ（右上の 案内）", kind: "day" });
    K.rmCine(hk);
    return true;
  } };

/* ---------- 2話 最後の 静けさ（竜祭りの 夜）---------- */
const MEM = [
  ["ルミナ", "{smile,♪,up}収穫祭の 約束、まだ 一つ 残ってる。……ミミちゃん、パン 焼いて 待ってるかな。", "{smile,up}ミミちゃんとの 約束、まだ 残ってるわ。", "{closed,up}ミミとの 約束。まだ 残ってる。", "{smile,up}ミミさんとの お約束、まだ 残って おります。"],
  ["シルヴァ", "{smile}ほたるの 森で、セオさんに 会ったんだよね。……本を 一度 読んだら、ぜんぶ 覚えちゃう 人。", "{sad}ほたるの 森で、セオさんに 会ったのよね。", "{closed}ほたるの 森。セオに 会った 場所。", "{sad}ほたるの 森で、セオさまに お会い しましたね。"],
  ["ヴォルカ", "{smile}ラヴィの 鍛冶場の 火、熱かったなあ。トンボくん、刀 打てたかな。", "{smile}ラヴィの 火、熱かったわね。", "{smile}ラヴィの 火。熱かった。", "{smile}ラヴィの 火は、熱う ございました。"],
  ["サンドリア", "{sweat,汗}……牢屋の ことは、レイが いる 前では 言わないで おく。", "{sweat}……牢屋の 話は、やめて おくわね。", "{sweat,汗}牢屋の 話は、なし。", "{sweat,汗}……牢の お話は、やめて おきますね。"],
  ["マリノア", "{sad}夜の 浜で、セオさんが 手帳を 破った。……あれ、何だったんだろう。", "{sad}夜の 浜で、セオさんが 手帳を 破ったわね……", "{closed}夜の 浜。セオが 頁を 破った。", "{sad}夜の 浜で、セオさまが 頁を……"],
  ["ネクロス", "{sad,…}灯籠流し……。セオさん、弟さんの 灯籠、流せなかったね。", "{sad}灯籠流し……セオさん、流せなかったわね。", "{sad}灯籠。セオは 流せなかった。", "{sad}灯籠流しで、セオさまは……"],
];
const DREAM = [["牧場で のんびり したい", "§7ノルじいの 牧場で、相棒と 昼寝"], ["また 新しい 旅に 出たい", "§7地図の 外へ"], ["旅で 会った みんなに 会いに 行きたい", "§7手帳の 名前の 頁の 順に"]];
export const DREAM_TXT = DREAM.map((x) => x[0]);
const E2 = { id: "r9e2", n: 2, t: "最後の 静けさ", at: 0, ord: 1, place: FESTR,
  hint: "§fエンドの 外れの §e竜祭りの 広場§f へ 行こう §7（右上の 案内。今夜は 竜祭り。「！」の 目印の そばで 立ち止まろう）",
  syn: "竜祭りの 夜。竜の 背骨の 数だけ 灯籠が ともった。旅の 仲間と 手帳を 開いて、これまでの 旅を 話した。「この 旅が 終わったら」の 答えも、手帳に 書いて くれた。仲間は 名前の 頁の いちばん 上に あなたと 相棒の 名前を 書き、最後の 頁を「旅の 最後に、二人で 書こう」と 白紙の まま 残した。広場の 端で 灯りを 見て いた ベリルは、「明日、門の 前で。最後に 一つ だけ、お願いが ある」と 言って 去った。",
  set: { fest9: 1, met9: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest9: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "r9fest", 1, c, y0);
    await K.open(p, "エンドの 竜祭り（夜）", "night");
    K.sound(p, "note.harp", 0.6); K.sound(p, "note.bell", 0.5);
    K.ambient(p, "night", { x: c.x, y: y0, z: c.z });
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{smile,☆,jump}わあ……！ 灯りが、竜の 背骨みたいに ならんでる！"], ["{smile,♪}……きれい。灯りが、ずっと 向こうまで 続いてる。"], ["{smile}……灯りの 列。竜の 背骨の かたちだ。"], ["{smile,☆}まあ……灯りが、竜の 背骨の ように……！"]));
    const eS = K.cast(p, "shizuku"); K.act(eS, "raise"); K.hold(eS, "chochin");   /* 第125版(rs2): 灯籠を 手に */
    if (ok(eS) && ok(eH)) await K.approach(p, eS, eH, 1.8);   /* 第125版(rs): 灯籠を 持って 歩み寄る */
    if (ok(eH)) K.go(eH, K.fwd(p, 2.5, -2.4), 18);   /* 屋台の 灯りの 下へ */
    await K.csay(p, "shizuku", ["{smile}竜祭りは、空へ 名前を 呼ぶ 祭りで ございます。", "{closed}会いたい 人、忘れたくない 人の 名前を 灯籠に 書いて、竜の 背骨に そって 飛ばすので ございます。"]);
    K.act(eS, 0);
    await K.hsay(p, K.V(["{smile,♪,up}名前を 書いて 飛ばすの……？ じゃあ、わたしの 手帳の 出番だね！"], ["{smile,up}名前を……。じゃあ、わたしの 手帳が 役に 立つわね。"], ["{smile,up}名前なら、手帳に ある。"], ["{smile,up}お名前でしたら、わたしの 手帳に たくさん ございます。"]));
    /* 手帳を 開いて 旅の 思い出 */
    K.act(eH, "hold"); K.hold(eH, "notebook"); K.sound(p, "item.book.page_turn", 1);
    await K.push(p, eH, 22, 4.2, 1.7);
    await K.narr(p, ["§7旅の 仲間は 灯りの 下に 座って、すりきれた §f旅の 手帳§7 を 開いた。", "§7地図の 頁と、旅で 会った 人の 名前の 頁が、交互に 綴じて ある。"], eH);
    const ty = { g: 1, o: 2, c: 3, t: 4 }[heroType(p)] || 1;
    await K.past(p, "§7―― 旅の 思い出");   /* 第125版(rs): 手帳の 頁は 回想の 札 */
    let k = 0;
    for (const m of MEM) {
      if (k % 2 === 0) { K.cmd(p, "camera @s fade time 0.2 0.3 0.3 color 20 15 30"); await K.wait(8); }
      await K.narr(p, [`§7― ${m[0]} の 頁 ―`], eH);
      await K.hsay(p, [m[ty]]);
      k++;
    }
    K.act(eH, 0);
    const eR = REI(K, p); if (ok(eR) && ok(eH)) await K.approach(p, eR, eH, 2.2); K.act(eR, "hold");   /* 第125版(rs2): レイが 灯りの 下の 二人の そばへ */
    await K.say(p, "レイ", ["{blush,汗}……おい。牢の 頁、オレの 名前に 丸が ついてるじゃ ねえか。", "{closed}……まあ、いい。消すなよ。"]);
    await K.hsay(p, K.V(["{smile,♪}消さないよーだ。"], ["{smile}消さないわ。"], ["{smile}消さない。"], ["{smile}消しません。"]), eR);
    K.act(eR, 0);
    /* この 旅が 終わったら */
    await K.push(p, eH, 22, 4.2, 1.7);
    await K.hsay(p, K.V(["{smile,…,up}……ねえ。この 旅が 終わったら、何 したい？"], ["{smile,up}……ねえ。この 旅が 終わったら、何を したい？"], ["{closed,up}……この 旅が 終わったら。何を したい。"], ["{smile,up}……あの。この 旅が 終わりましたら、何を なさりたいですか？"]));
    let pick = 0; try { pick = await choose(p, "この 旅が 終わったら", "§f旅の 仲間が、手帳を ひざに のせて 待って いる。", DREAM.map((x) => [`§l${x[0]}\n${x[1]}`, ICON("i_help")])); } catch {}
    if (!(pick >= 0 && pick <= 2)) pick = 0;
    K.setFlag(p, "dream", pick);
    const R = [
      K.V(["{smile,♪,up}牧場で 昼寝！ いいね、ノルじいの 干し草の 上で！ ……書いとく！"], ["{smile,up}牧場で のんびり……ふふ、あなたらしいわ。書いて おくわね。"], ["{smile,up}……昼寝か。悪くない。書く。"], ["{smile,up}牧場で のんびり……すてきです。書いて おきますね。"]),
      K.V(["{smile,☆,up}また 旅！？ ……地図、もう一冊 いるじゃん！ 書いとく！"], ["{smile,up}また 旅に……ふふ。地図が もう 一冊 いるわね。書いて おくわ。"], ["{smile,up}……また 旅か。地図、もう 一冊。書く。"], ["{smile,up}また 旅に……！ 地図を もう 一冊 ご用意 しますね。書いて おきます。"]),
      K.V(["{smile,tears,up}……みんなに 会いに？ うん、うん……手帳の 名前の 順に、ぜんぶ 回ろう！ 書いとく！"], ["{smile,tears,up}……みんなに 会いに。……やさしいのね。書いて おくわ。"], ["{smile,up}……手帳の 名前の 順に、か。……いい 答え。書く。"], ["{smile,tears,up}……皆さまに 会いに……。書いて おきます。"]),
    ][pick];
    await K.hsay(p, R);
    K.act(eH, "hold"); K.hold(eH, "notebook"); K.sound(p, "item.book.page_turn", 1);
    await K.hsay(p, K.V(["{smile,up}わたしはね、地図を ぜんぶ 描きあげて……それを 持って、もう 一回 あなたと 相棒と、ぜんぶの 町を 回るの。", "{smile,♪}だって、一人で 見ても つまらないもん。"], ["{smile,up}わたしは……地図を 描きあげて、あなたと 相棒と、もう 一度 ぜんぶの 町を 回りたいわ。", "{smile}一人で 見る 景色は、半分 だから。"], ["{closed,up}わたしは……地図を 描きあげる。それを 持って、あなたと 相棒と、もう 一回 回る。", "{smile}一人だと、つまらない から。"], ["{smile,up}わたしは……地図を 描きあげて、あなたさまと 相棒さんと、もう 一度 すべての 町を。", "{smile}お一人で 見る 景色は、さびしいですから。"]));
    await K.narr(p, ["§7仲間は 名前の 頁の いちばん 上の 行に、あなたと 相棒の 名前を 書いた。", "§7それから 手帳の 最後の 頁を めくって、何も 書かずに 指で なぞった。"], eH);
    await K.up(p, eH, 12);
    await K.hsay(p, K.V(["{smile,up}最後の 頁は、白紙の まま 取って おくね。……旅の 最後に、二人で 書こう。約束！"], ["{smile,up}最後の 頁は、白紙の まま。……旅の 最後に、二人で 書きましょう。約束よ。"], ["{smile,up}最後の 頁は、白紙。旅の 最後に、二人で 書く。……約束。"], ["{smile,up}最後の 頁は、白紙の まま。……旅の 最後に、二人で 書きましょう。お約束です。"]));
    K.act(eH, 0);
    /* ベリル（明日の 願い）*/
    const eB = K.npcNear(p, "§5六影 ベリル", K.PJ("beryl", 9)); K.act(eB, "hold");
    await K.low(p, eB, 12);
    await K.hsay(p, K.V(["{shock,!}……ベリルちゃん！？"], ["{shock}……ベリルちゃん？"], ["{shock,!}……ベリル。"], ["{shock,!}ベリルさん……！"]));
    await K.say(p, "ベリル", ["{closed}……戦いに 来たんじゃ ないの。今夜は、みんな 休むって 決まりだから。", "{sad}……祭りって、こういう ものなのね。一座に いた ころは、いつも 袖から 見て いたの。"]);
    K.hold(eH, "chochin"); K.act(eH, "give"); if (ok(eH) && ok(eB)) await K.approach(p, eH, eB, 1.6); await K.ots(p, eB, eH, 8);   /* 第125版(rs2): 灯籠を 持って ベリルの 前へ（ベリルの 肩ごしに 幼なじみ）*/
    await K.hsay(p, K.V(["{smile,up}灯籠、一つ あげる！ 名前、書こうよ。"], ["{smile,up}……灯籠、一つ どうぞ。名前を 書きましょう？"], ["{smile}灯籠。一つ やる。"], ["{smile,up}灯籠を、お一つ どうぞ。お名前を 書きましょう？"]), eB);
    K.act(eB, 0);
    await K.say(p, "ベリル", ["{sad,no,up}……名前を 書く 紙は、わたしには ないの。", "{closed}……明日、門の 前で。最後に 一つ だけ、お願いが ある。"]);
    await K.leave(eB, p, 9, false);
    /* 灯籠を 飛ばす */
    K.act(eH, 0); for (const e of [eH, eS, eR]) { K.hold(e, "chochin"); K.act(e, "raise"); }   /* 第125版(rs2): 三人で 灯籠を かかげる */
    for (let i = 0; i < 4; i++) { for (let j = 0; j < 6; j++) { const a = (j / 6) * Math.PI * 2 + i; K.burst(p.dimension, { x: c.x + Math.cos(a) * (3 + i), y: y0 + 2 + i * 2, z: c.z + Math.sin(a) * (3 + i) }, j % 2 ? "minecraft:endrod" : "minecraft:basic_flame_particle", 2, 0.3, 0); } K.sound(p, "note.chime", 0.6 + i * 0.15); await K.wait(6); }
    await K.at(p, { x: c.x, y: y0 + 9, z: c.z }, 18, 9, 2);
    await K.narr(p, ["§7灯籠が 竜の 背骨に そって、夜空へ のぼって いく。", "§7ミミ、ゴンザ、ノルじい、オルド、レイ……手帳の 名前が、灯りに なって 空を わたった。"]);
    for (const e of [eH, eS, eR]) { K.act(e, 0); K.hold(e); }
    await K.up(p, eH, 14);
    await K.hsay(p, K.V(["{smile,…,up}……ねえ。ずっと、こうして いられたら いいのにね。"], ["{smile,…,up}……ずっと、こうして いられたら いいのに。"], ["{closed,…,up}……ずっと、こうなら いいのに。"], ["{smile,…,up}……ずっと、こうして いられましたら……。"]));
    await K.at(p, { x: c.x, y: y0 + 6, z: c.z }, 14, 5, 1);   /* 第125版 Q17: 竜骨の 灯りが 一つだけ 消え、また ともる */
    await K.narr(p, ["§7竜骨の 灯りが 一つだけ、ふっと 消え……また、ともった。"]);
    await K.csay(p, "shizuku", ["{closed}……竜が、ひとつ 数えなおして おります。"], eH);
    K.pay(p, E2, 2500, [["gift_bread", 2]]);
    await K.night(p, null, "§7灯籠が 消えて、村が 眠りに つく。", "§7……夜が 明けた。祭壇の 方の 霧が、うすく ほどけて いく。");   /* 第125版(pl): 夜 → 夜明け */
    await K.end(p, { leave: [eS, eR], card: "§7― 夜が 明けると、竜の 霧が 晴れた ―\n§7→ 竜骨の 祭壇への 道へ（右上の 案内）", kind: "night", t: 54 });
    return true;
  } };

/* ---------- 3話 守り手（儀式を 止めようと する 竜骨の 守り手）---------- */
const E3 = { id: "r9e3", n: 3, t: "守り手", at: 0, ord: 2, place: ROAD, fac: "r9road",
  hint: "§f§e竜骨の 祭壇への 道§f へ 行こう §7（右上の 案内。霧が 晴れた。「！」の 目印の そばで 立ち止まろう）",
  syn: "霧の 晴れた 道で、竜骨の 守り手が 目を さました。守り手も 儀式を 止めたがって いた。シズクが 聞き取った 竜の 声は「鍵を 手放せば、知る 者に 宿る」。祭壇の 方角に 紫の 光の 柱が 立つと、守り手は 怒りで 骨の 竜を 呼びつづけた。オルドと ハクが しんがりに 残り、あなたたちは 祭壇へ 走った。",
  set: { guard9: 1 },
  async run(p, d, K) {
    const FW = fac(K, p, "r9road", "waypost", 9, Y(K, p));   /* 第125版(pl): 祭壇への 道しるべ */
    await K.open(p, "竜骨の 祭壇への 道", "ash");
    if (FW) await K.at(p, FW, 14, 6, 1.2);
    K.sound(p, "ambient.weather.thunder", 0.4);
    const eH = K.hero(p), eR = REI(K, p), eS = K.cast(p, "shizuku"), eO = ORDO(K, p);
    if (ok(eR) && FW) { await K.walkCam(p, eR, { x: FW.x - 1.2, y: Y(K, p), z: FW.z }, 16); K.turn(eR, K.fwd(p, 20, 0, 4)); }   /* 第125版(rs): レイが 道しるべの 先へ 歩き、祭壇の 方を にらむ */
    const hk = K.monEnt(p, K.fwd(p, 2.5, -3), HAKU(), "§fハク");
    await K.csay(p, "shizuku", ["{closed}……この 先は、竜骨の 内側で ございます。竜の 声が……ざわめいて おります。"]);
    K.act(eO, "hold");
    await K.say(p, "オルド", ["{closed}……嫌な 風じゃ。ハクの 毛が、逆立って おる。"], hk);
    const q = K.fwd(p, 9, 0);
    K.boom(p.dimension, q); K.sound(p, "mob.enderdragon.growl", 0.9); K.shake(p, 0.6, 0.8);
    const g1 = K.monEnt(p, q, DRAG(), "§6竜骨の 守り手");
    await K.at(p, q, 14, 7, 2);
    K.act(eS, "kneel");
    await K.csay(p, "shizuku", ["{shock,!,up}竜骨の 守り手……！ 祭壇を 守る 竜の 魂で ございます！", "{sad}儀式を 止めようと、目を 覚まされたので ございます……！"]);
    await K.hsay(p, K.V(["{angry,!,up}止めたいのは わたしたちも 同じだよ！ 通して！"], ["{angry,up}止めたいのは、わたしたちも 同じなの！ お願い、通して！"], ["{angry,!,up}止めたいのは こっちも 同じだ。通せ。"], ["{angry,up}わたしたちも 止めたいのです！ どうか、お通し ください！"]));
    await K.say(p, "竜骨の 守り手", ["{angry,low}……カギヲ……モツモノモ……モタヌモノモ……トオサヌ……"]);
    K.act(eR, "guard"); K.act(eH, "guard");
    await K.say(p, "レイ", ["{angry,!,up}話の 通じる 相手じゃ ねえ！ ……背中は 任せた！"]);
    if (!K.flag(p, "r9e3a")) {
      K.rmCine(g1);
      await K.duel(p, "§6§l竜骨の 守り手", "§f千年 祭壇を 守った 竜の 魂が、骨の 翼を ひろげる！", { fams: ["dragon"] });
      const r = await K.battle(p, [...K.bossOne(["dragon"], 71, 40, 1), ...K.team(["dragon", "golem"], 70, 2, 20)], { name: "竜骨の 守り手", arena: "竜骨の 道", theme: "endcity", hpk: 2.4, extra: 0.3, sboss: true, tag: "守り手", speaker: "竜骨の 守り手", guests: K.team(["dragon"], 70, 1, 20).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……ナゼ……カギヲ……アツメル……", low: "……シル……モノニ……カゲ……" } });
      if (r !== "win") { K.rmCine(hk); return lose(K, p, "§bレイ", 17, "レイ", "{sweat,汗}……くそ、骨の くせに しぶとい！ いったん 立てなおすぞ！"); }
      K.setFlag(p, "r9e3a");
    } else K.rmCine(g1);
    const g2 = K.monEnt(p, q, DRAG(), "§6竜骨の 守り手"); K.burst(p.dimension, q, "minecraft:white_smoke_particle", 10, 1.6, 0.4);
    await K.narr(p, ["§7守り手は 骨の 膝を つき、低く うなった。", "§7その 声は、どこか 泣いて いる ように 聞こえた。"], g2);
    K.act(eS, "hold");
    await K.approach(p, eS, eH, 1.9); await K.push(p, eS, 24, 4.5, 1.7);   /* 第125版(rs): 気持ちの 行は 歩み寄って ゆっくり 寄る */
    await K.csay(p, "shizuku", ["{sad,…,up}……竜が、こう 申して おります。", "{closed,up}『鍵を 手放せば、知る 者に 宿る』……と。"]);
    await K.hsay(p, K.V(["{shock,!,up}……知る 者に、宿る……？ セオさん、いろんな こと 知ってる 人だよ……！"], ["{shock,…,up}……知る 者に……？ セオさんは、何でも 覚えて しまう 人なのに……"], ["{shock,!,up}……セオは、全部 覚える。……まずい。"], ["{shock,!,up}知る 者に……！ セオさまは、何でも 覚えて おられる お方……！"]));
    K.re(eO, "shock", "!");
    await K.say(p, "オルド", ["{shock,…,up}……！ ……あの 若造、まさか――"], eH);
    /* 祭壇の 方角に 紫の 光の 柱 */
    const S = K.S(p), pil = S ? S.at(30, 8, 0) : K.fwd(p, 30, 8);
    for (let i = 0; i < 6; i++) { K.burst(p.dimension, { x: pil.x, y: pil.y + i * 3, z: pil.z }, "minecraft:portal_reverse_particle", 8, 1.2, 0); await K.wait(2); }
    K.sound(p, "mob.wither.spawn", 0.5); K.shake(p, 0.5, 1); K.mood(p, "shadow");
    await K.at(p, { x: pil.x, y: pil.y + 6, z: pil.z }, 18, 16, 0);
    await K.narr(p, ["§7祭壇の 方角に、紫の 光の 柱が 立った。", "§7……儀式が、始まった。"], { x: pil.x, y: pil.y + 4, z: pil.z });
    K.sound(p, "mob.enderdragon.growl", 1.1); K.shake(p, 0.7, 1);
    await K.say(p, "竜骨の 守り手", ["{rage,low}……オオオ……ハジマッタ……トメル……トメル……！"]);
    K.act(eR, "guard");
    await K.say(p, "レイ", ["{angry,!,up}骨の 竜が また 起きて くる……！ きりが ねえ！"]);
    K.rmCine(g2);   /* 第124版(dir#22): 2回目の 波は 戦わない（オルドと ハクが 食い止める 絵だけ）*/
    const g3 = K.monEnt(p, q, DRAG(), "§6竜骨の 守り手"); K.burst(p.dimension, q, "minecraft:soul_particle", 10, 1.6, 0.6);
    if (ok(eO) && hk && ok(hk)) { await K.walkCam(p, eO, K.fwd(p, 4, -1.6), 16); K.turn(eO, q); }   /* 第125版(rs2): オルドが ハクの 横へ 出て、守り手に 向かって 立つ */
    K.act(eO, "guard");
    if (hk && ok(hk)) { K.sound(p, "mob.ravager.roar", 1.2); await K.push(p, hk, 22, 4.2, 1.7); }
    await K.say(p, "オルド", ["{angry,!,up}……ここは わしと ハクが 押さえる。行け！", "{closed}守り手は、わしらを 通さん かわりに、おまえさんたちを 追う ひまも ないわい。"]);
    await K.say(p, "レイ", ["{shock,!,up}じいちゃん！？ 一人じゃ 無理だ！"]);
    K.turn(eO); await K.ots(p, eR, eO, 8);   /* ふり向く（レイの 肩ごしに オルド）*/
    await K.say(p, "オルド", ["{smile,up}年寄りを なめるな。……すぐ 追いつく。", "{closed}セオを 止めろ。……二十年前と 同じ ことを、くり返させる な。"], eR);
    await K.hsay(p, K.V(["{sad,up}……ハク、村長を おねがいね。……ぜったい、あとで 会おうね！"], ["{sad,up}……ハク、村長さんを おねがい。あとで 会いましょう。"], ["{sad,up}……ハク。村長を たのむ。あとで。"], ["{sad,up}……ハクさん、村長さまを お願い いたします。のちほど、必ず。"]), hk);
    if (hk && ok(hk)) { K.burst(p.dimension, hk.location, "minecraft:heart_particle", 3, 0.4, 1); }
    K.act(eS, "hold");
    await K.csay(p, "shizuku", ["{closed}……竜の 加護が、ありますように。わたくしは、ここで 祈って おります。"]);
    K.pay(p, E3, 3000, [["c_revive2", 2], ["x_ragna", 2]]);
    await K.end(p, { leave: [eH, eR], bye: [eO, eS], card: "§c→ 竜骨の 祭壇へ 急げ！（右上の 案内）", kind: "ash" });
    K.rmCine(hk); K.rmCine(g3);
    return true;
  } };

/* ---------- 5話 墓標（祭壇の あと。見晴らし台で 弔い → ソラの 試し → 墓標）---------- */
const E5 = { id: "r9e5", pv: 127, n: 5, t: "墓標", snd: "item.book.page_turn", at: 1, ord: 0, place: LOOK, fac: "r9look",
  hint: "§fさいはての 村 §eエンドの 竜の 見晴らし台§f へ もどろう §7（右上の 案内。シズクが 待って いる）",
  syn: "エンドの 見晴らし台で、シズクが 竜骨から いただいた 鱗で 墓標を 立てた。レイは 野の 花を、オルドは 干し草で 編んだ 紐の お守りを 供えた。あなたは 鱗に 仲間の 名前を 刻み、手帳の 名前の 頁にも 書いた。竜祭りの 夜の 頁には、あなたの「旅が 終わったら」が 書いて あった。最後の 頁は、白紙の まま だった。鱗は 二枚。もう 一枚は オルドが 持って、ふるさとの 丘の 墓へ 帰る。",
  set: { grave9: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), grave9: 1 }; },
  async run(p, d, K) {
    const FQ = fac(K, p, "r9look", "lookout", 9, Y(K, p));
    await K.open(p, "エンドの 竜の 見晴らし台（夕暮れ）", "dusk");
    if (FQ) await K.at(p, FQ, 12, 7, 1.5);
    const hn = HNm(K, p), eR = REI(K, p); K.act(eR, "kneel");
    await K.say(p, "レイ", ["{closed,low}……来たか。", "{sad}天空郷へ 行く 前に、ここに 来たかった。"]);
    const eS = K.cast(p, "shizuku"); K.act(eS, "show"); K.hold(eS, "tablet");
    await K.csay(p, "shizuku", ["{sad}……竜骨から、鱗を 一枚 いただいて まいりました。", "{closed,up}竜が、許して くださいました。……あの方の 名前を、覚えて おきたいと。"]);
    const eO = ORDO(K, p); K.act(eO, "hold");
    await K.say(p, "オルド", ["{closed,low}……わしが、遅すぎた。", "{sad}わしと ハクが 着いた ときには、もう……。ハクまで、石に して しもうた。"], eR);
    const eSo = K.cast(p, "sora"); K.act(eSo, "hold");
    if (ok(eSo) && ok(eR)) { await K.approach(p, eSo, eR, 2.2); K.turn(eSo, K.fwd(p, 20, -6, 10)); }   /* 第125版(rs): ソラは レイの 横へ 歩き、竜骨の 方を 見る */
    await K.csay(p, "sora", ["{closed}……竜骨の 見張り台から、見て いた。……鱗の 墓標を 立てるのは、ひさしぶりだ。"]);
    K.turn(eSo);
    /* 第125版(ce): ソラの 試し（ここで 戦う）。竜の 教え「墓標に 名を 刻む 者は、立って いられる 者で なければ ならない」。勝つと ラグナの 石板 */
    if (!(qs(load(p) || d).rm || []).includes(7) && !K.flag(p, "r9sora")) {
      if (ok(eSo)) await K.approach(p, eSo, K.S(p) ? K.S(p).P : p.location, 2.6);
      await K.push(p, eSo, 22, 4.2, 1.7);
      await K.csay(p, "sora", ["{closed,up}……竜は 教える。墓標に 名を 刻む 者は、自分の 足で 立って いられる 者で なければ ならない、と。", "{angry,up}ラグナの 石板は 渡す。……その 前に、まだ 立てるか、ここで 見せて くれ。"]);
      await K.say(p, "レイ", ["{angry,tears,up}……今かよ。こんな ときに。"], eSo);
      await K.csay(p, "sora", ["{closed}今だ。……泣くのを やめろ とは 言わない。泣きながらで いい。"], eR);
      await K.duel(p, "§6§l見晴らし台の 試し", "§f竜骨を 背に、地方マスター ソラが 立ちはだかる！", { fams: ["dragon"] });
      const r = await K.battle(p, rmTeam(load(p) || d, 7), { name: "ラグナの 地方マスター ソラ", arena: "竜の 見晴らし台", theme: "endcity", speaker: "ソラ", lines: { half: "……まだ 立つか。", low: "……立って いるな。" } });
      if (r !== "win") { await K.csay(p, "sora", ["{closed}……ひざを ついても いい。また 来い。ここで 待つ。", K.RT(p)]); return false; }
      { const d3 = load(p); if (d3) { const s3 = qs(d3); s3.rm = s3.rm || []; if (!s3.rm.includes(7)) s3.rm.push(7); s3.rmw = s3.rmw || {}; s3.rmw[7] = (s3.rmw[7] || 0) + 1; d3.gold = (d3.gold || 0) + 61000; const b = giveSlab(p, d3, 13); save(p, d3); try { if (b) p.sendMessage(`§d§l${b.name}§r §7を 受け取った（道具から 触れると 石板の 中へ）`); } catch {} } }
      K.setFlag(p, "r9sora");
      const eSo2 = K.cast(p, "sora", true); K.act(eSo2, "show"); K.hold(eSo2, "tablet");
      await K.csay(p, "sora", ["{smile}……立って いた。受け取れ。", "{closed}ラグナの 主を 封じれば、天空郷への 道が 開く。……先に、名を 刻もう。"]);
      K.act(eSo2, 0); K.hold(eSo2);
    }
    /* 墓標を 立てる */
    const S = K.S(p); let gq = S ? S.at(5.5, -2.6, 0) : K.fwd(p, 5.5, -2.6);
    try { const A = JSON.parse(world.getDynamicProperty("mrpg:epdeco:r9graveat") || "null"); if (A && typeof A.x === "number" && Math.hypot(A.x - p.location.x, A.z - p.location.z) < 30) gq = A; } catch {}   /* 第124版: 前に 建てた 墓標の 場所を 映す */
    K.act(eS, "raise");
    if (ok(eS)) { await K.walkCam(p, eS, { x: gq.x - 1.2, y: gq.y, z: gq.z }, 16); K.act(eS, "kneel"); }   /* 第125版(rs): 鱗を 抱いて 墓標の 場所へ 歩き、ひざを つく */
    await K.at(p, gq, 10, 3.5, 1);
    await K.csay(p, "shizuku", ["{closed}竜よ。いま ひとつ、名を あずけます。"]);
    await grave(K, p, gq);
    K.sound(p, "note.chime", 0.6); K.burst(p.dimension, gq, "minecraft:endrod", 8, 0.8, 2.6);
    await K.at(p, gq, 16, 3, 1.4);
    await K.narr(p, ["§7青い 鱗の 墓標が、夕日を うけて 光った。", "§7鱗の まわりに、白い すずらんと 青い 花が 咲いた。"], gq);
    K.act(eS, 0);
    /* 供える */
    K.act(eR, "show"); K.hold(eR, "bouquet");
    await K.say(p, "レイ", ["{sad,up}……花、これしか 見つからなかった。……あいつ、青い 花が 好きだったよな。"]);
    K.act(eR, 0); K.hold(eR); K.act(eO, "show"); K.hold(eO, "rope");
    await K.push(p, eO, 22, 4.2, 1.7);
    await K.say(p, "オルド", ["{closed,up}……牧場の 干し草で 編んだ、紐の お守りじゃ。", "{sad}昔、ある 男が、娘の ために 編もうと して……とうとう 編めなんだ。", "{closed,low}……三つ 編んで、一つ 返す。あやつの 編み方じゃ。", "{sad}……わしは、編めた。"]);
    K.act(eO, 0);
    await K.say(p, "レイ", ["{?,…}……じいちゃん。その 男って――"]);
    await K.say(p, "オルド", ["{closed,no}……今は、ええ。"]);
    /* 名前を 刻む・手帳 */
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, [`§7あなたは 鱗に §f${hn}§7 と 刻んだ。`, "§7それから 旅の 手帳を 開いて、名前の 頁にも 同じ 名前を 書いた。"], gq);
    K.techo(p, hn);
    const dr = (qs(load(p) || d).epx || {}).dream;
    K.act(eR, "hold"); K.hold(eR, "notebook"); K.hold(eO);
    await K.say(p, "レイ", ["{shock,…,up}……竜祭りの 頁、見せて くれ。", typeof dr === "number" && DREAM_TXT[dr] ? `{sad,tears,up}『旅が 終わったら、${DREAM_TXT[dr]}』……あいつ、おまえの 答えまで 書いてたのかよ。` : "{sad,tears,up}……『旅が 終わったら』……あいつ、こんな ことまで 書いてたのかよ。"]);
    await K.narr(p, ["§7手帳の 最後の 頁は、白紙の まま だった。", "§8『旅の 最後に、二人で 書こう』"], eR);
    K.act(eR, "kneel");
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{cry,tears,up}……っ、なんで、白紙なんだよ……！ 二人で 書くって、言ったんだろ……！"]);
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:heart_particle", 3, 0.4, 0.9); await K.up(p, g, 12); }
    await K.pal(p, ["……あの子の におい、まだ 手帳に のこってる。"]);
    K.rmCine(g);
    K.act(eS, "show"); K.hold(eS, "tablet"); K.hold(eR);
    await K.csay(p, "shizuku", ["{sad,up}……鱗は、二枚 いただいて まいりました。", "{closed}一枚は、ここに。もう 一枚は……どうか、ふるさとの お墓に。"], eO);
    K.act(eO, "hold");
    await K.say(p, "オルド", ["{closed,up}……わしが 連れて 帰る。牧場と 海が いっぺんに 見える 丘じゃ。……あの 子は、あそこが 好きじゃった。", "{sad}ハクも、いつか 必ず。……あやつを 石の まま には、して おかん。"]);
    K.act(eO, 0);
    await K.csay(p, "sora", ["{closed,up}……ラグナの 竜は、名を 呼ぶ 者が いる かぎり、墓を 守る。", "{up}……主を 封じたら、天空郷へ 行け。……立ち止まるのは、あとで いい。"]);
    K.act(eR, "up");
    await K.say(p, "レイ", ["{angry,tears,up}……先に 天空郷へ 行ってる。かぜの 塔の 町の 入口で、待ってる。", "{closed,up}……泣くのは、これで 最後だ。"]);
    await K.csay(p, "shizuku", ["{smile,tears,up}……行って らっしゃいませ。竜と いっしょに、お待ち して おります。"]);
    K.pay(p, E5, 5000, [["c_revive2", 2], ["x_ragna", 3]]);
    K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 0 0 0"); await K.wait(10);
    await K.end(p, { leave: [eR, eSo, eO], bye: [eS], card: "§f― 第10章 竜骨の 決戦 おわり ―\n§7→ ソラの 石板で ラグナの 主を 封印しよう（右上の 案内）", kind: "dusk", t: 60 });
    return true;
  } };

epAdd(9, [E1, E2, E3, E5], { steps: { 0: [4, "祭壇"], 1: [6, "ラグナの 主の 封印"] } });
export const __r9 = { LOOK, FESTR, ROAD, grave };
