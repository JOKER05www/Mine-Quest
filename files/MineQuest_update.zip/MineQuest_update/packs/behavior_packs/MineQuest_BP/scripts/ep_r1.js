/* 第125版: 第2地方 シルヴァ（ほたるの 里 ルミエ）の 5話
   1話 消えた ほたる（新）→ 2話 薬草さがし（新。セオの 記録の 力・夜の 本読みと 弟の 絵）→ 3話 白紙の 座（新。ベリルが 座を 求める）
   → 4話 洞くつの 奥（今の 段: 洞くつの 入口・奥の 大広間）→ 5話 ほたる祭り（今の 段: 森の 主 → 新: やり直しの ほたる祭り）
   書き方は ep_r0.js の 頭の 説明の とおり。場所は 里の 外れ（噴水・町の 中の 道・坂の 途中は 使わない）*/
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, spotOf, openSite, stageAvoid } from "./storyplace.js";
import { TOWNS, getTown, townPos, castleSpot, groundY } from "./structures.js";
import { regionIdx } from "./worldmap.js";
import { world } from "@minecraft/server";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok } from "./ui.js";
import { fac, facAt } from "./epfac.js";
import { plazaOf, festSet, crowd, moveG } from "./pvplace.js";   /* 第126版(PV): 祭りは 里の 広場 */

/* ---------- 場所: ルミエの 外れ（ほかの 町・城・洞くつ・大地から はなれた 向き）---------- */
const TID = "t17", REG = 1;
const SP0 = () => { try { return world.getDefaultSpawnLocation(); } catch { return { x: 0, y: 64, z: 0 }; } };
const TC = () => { const t = TOWNS.find((u) => u.id === TID); if (!t) return null; const q = getTown(TID); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const PLQ = {};
function ring(key, R, nm, near = []) {
  if (PLQ[key]) return PLQ[key];
  const c = TC(); if (!c) return null; const s0 = SP0(), avoid = near.filter(Boolean);
  for (const t of TOWNS) if (t.id !== TID) { const q = townPos(t); avoid.push([q.x, q.z, 44]); }
  for (let i = 0; i < 11; i++) { const k = castleSpot(i); if (k) avoid.push([k.x, k.z, 72]); }
  for (const k of ["out", "road", "hall", "stage"]) { const q = placeOf(k, REG); if (q) avoid.push([q.x, q.z, 22]); }
  stageAvoid(avoid, 70);   /* 第127版(fac): どの 地方の ステージ（大地）からも 離す */
  let best = null;
  for (let a = 0; a < 16; a++) { const t = (a / 16) * Math.PI * 2, x = Math.floor(c.x + Math.cos(t) * R), z = Math.floor(c.z + Math.sin(t) * R); if (regionIdx(x - s0.x, z - s0.z) !== REG) continue; let m = 1e9; for (const [X, Z, D] of avoid) m = Math.min(m, Math.hypot(X - x, Z - z) - D); if (!best || m > best.m) best = { x, z, m }; }
  if (!best) best = townOut(TID, 0.5, nm);
  return (PLQ[key] = best ? { x: best.x, z: best.z, nm } : null);
}
const SPRING = () => openSite("r1spring", TC(), REG, 90, 300, "ルミエの 奥の ほたるの 小川") || ring("spring", 56, "ほたるの 里 ルミエの 外れの ほたるの 小川");   /* 第127版(fac2): 町の 外れ 56 → 離れた 広い 所 */
const FESTP = () => { const q = plazaOf(TID, "ほたるの 里 ルミエの 広場（ほたる祭り）"); return q ? { x: q.x, z: q.z, nm: q.nm } : SPRING(); };
/* 第127版(fac): 薬草の 森（ピピの 天幕）と 病んだ 森は 里から 離れた 広い 森（ステージ・雪の 地方から 離れた 所）*/
const HERB = () => { const a = SPRING(); return openSite("r1herb", TC(), REG, 90, 450, "ルミエの 奥の 薬草の 森", [a && [a.x, a.z, 40]]) || ring("herb", 60, "ルミエの 外れの 薬草の 森", [a && [a.x, a.z, 34]]); };
const SICK = () => { const a = SPRING(), b = HERB(); return (b && openSite("r1sick", b, REG, 50, 200, "ルミエの 奥の 病んだ 森", [a && [a.x, a.z, 40]])) || ring("sick", 74, "ルミエの 外れの 病んだ 森", [a && [a.x, a.z, 34], b && [b.x, b.z, 34]]); };
const standAt = (k, dx, dz, f) => () => { for (const kk of [].concat(k, "inn")) { const q = spotOf(TID, kk); if (q) return { x: q.x + dx, y: q.y, z: q.z + dz }; } const o = f(); return o ? { x: o.x + dx, z: o.z + dz } : null; };   /* 第125版(pl): 仕事に 合う 建物の 前（なければ 宿）*/

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
const fall = (s) => !!s.heroDead && !s.ending;   /* 世界が 滅びかける ころ（第10章の あと 〜 終章の 前）*/
castAdd("r1hakka", { nm: "ハッカ婆", role: "里長", gobi: "ですのう", skin: "c7_hakka", town: TID, from: "r1e1", at: standAt("home", 3, 2, SPRING),
  pre: ["{smile}ようこそ、ほたるの 里へ。……今は、ほたるが おらんのですのう。"],
  after: [
    [(s) => !!s.heroBack, ["{smile,tears}まあ……二人 そろって 顔を 見せに 来て くだすったのですのう。", "{smile}ほたるも 今夜は、いつもより 明るう 光って おりますのう。"]],
    [(s) => !!s.ending, ["{closed}空が 晴れましたのう。ほたるは 今年も 帰って きましたのう。", "{sad}……帰って こない 灯りの ぶんまで、今夜は ようけ 光って おりますのう。"]],
    [fall, ["{sad}里の 者が 一人、また 一人と 石に……。空も ずっと 暗いのですのう。", "{angry}忘れ草の 香の 作り方なら、この 婆が 知って おりますのう。材料を 集めて くだされ。"]],
    [(s) => !!st(s).fest1, ["{smile,♪}ほたる祭りの 夜は、ほんに よう ございましたのう。", "{smile}里の 若い 衆が、小川の そばに 茶屋を 開いたのですのう。旅の 方も 寄って いきなされ。"]],
    [() => true, ["{sad}ほたるが 帰るまで、祭りは おあずけですのう。", "{closed}森の 洞くつの こと、どうか よろしゅう たのみますのう。"]],
  ] });
castAdd("r1pipi", { nm: "ピピ", role: "薬師見習いの", gobi: "なのだ", skin: "nico", town: TID, from: "r1e2", at: standAt("shop", -3, 3, SPRING),
  pre: ["{smile}ピピは 薬師の 見習いなのだ！"],
  after: [
    [(s) => !!s.heroBack, ["{smile,☆}おかえりなのだ！ 二人とも、薬の いらない 顔を して いるのだ！", "{smile,♪}ピピは もう 見習いじゃ ないのだ。本物の 薬師なのだ！"]],
    [(s) => !!s.ending, ["{closed}ピピは 薬師に なったのだ。セオに もらった 本は、毎晩 読んで いるのだ。", "{sad}……読んで くれる 声が ないのは、ちょっと さびしいのだ。"]],
    [fall, ["{angry}記録の インクは、ほたる苔から 作れるのだ！ 影の しずくを 持って くれば、作って あげるのだ！", "{sad}……石に なった 人の 名前を、ちゃんと 書いて あげて ほしいのだ。"]],
    [(s) => !!st(s).fest1, ["{smile,♪}ピピは 薬師に なるって 決めたのだ！ ハッカ婆にも 言ったのだ！", "{smile}いつか 遠くの 町まで、薬を 届けに 行くのだ。"]],
    [(s) => !!st(s).r1page, ["{sweat,汗}病んだ 森で 助けて もらったのは、ないしょなのだ。ハッカ婆に しかられるのだ。", "{?}……あの 灰色の 服の 子、また 一人で 森に いないか 心配なのだ。"]],
    [() => true, ["{smile}セオの 本、また 読んで ほしいのだ。竜が 星を さがす お話なのだ。"]],
  ] });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
const out = async (K, p, e, run = false) => { if (!ok(e)) return; const q = K.away(e, p, 12), l = e.location; if (!q || Math.hypot(q.x - l.x, q.z - l.z) < 4) return K.bye(p, e); return K.leave(e, p, 12, run); };   /* 歩いて 去る（道が ふさがって いる ときは 暗転で 下げる）*/
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
const FIREFLY = ["minecraft:villager_happy", "minecraft:endrod"];
/* 小川の そばの 石の 男の子（ワールドに 1回。子どもの 背たけの 石。舞台の 外側）*/
const SQ = (c, y0) => ({ x: Math.floor(c.x) - 9, y: y0, z: Math.floor(c.z) - 5 });
function stoneKid(K, p, c, y0) { const k = "mrpg:epdeco:t17stone"; try { if (world.getDynamicProperty(k)) return; } catch {} const q = SQ(c, y0); let gy = null; try { gy = groundY(p.dimension, q.x, q.z, y0 + 6); } catch {} if (typeof gy !== "number" || Math.abs(gy - y0) > 4) return; K.cmd(p, `setblock ${q.x} ${gy} ${q.z} cobblestone_wall keep`); K.cmd(p, `setblock ${q.x} ${gy + 1} ${q.z} stone keep`); try { world.setDynamicProperty(k, 1); } catch {} }
function flies(K, p, at, n = 6, r = 4) { if (!at) return; for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, q = { x: at.x + Math.cos(a) * r * Math.random(), y: at.y + 0.6 + Math.random() * 2.2, z: at.z + Math.sin(a) * r * Math.random() }; try { p.dimension.spawnParticle(FIREFLY[i % 2], q); } catch {} } }

/* ---------- 1話 消えた ほたる ---------- */
const E1 = { id: "r1e1", pv: 127, n: 1, t: "消えた ほたる", at: 0, ord: 0, place: SPRING, fac: "r1brook",
  hint: "§fほたるの 里 §eルミエの 外れの ほたるの 小川§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まると、里長の §eハッカ婆§7 が 待って いる）",
  syn: "ほたるの 里 ルミエでは、去年の 初雪の 夜、ほたるが 一匹も 光らなかった。森の 葉は 灰色に くすんで いた。里長の ハッカ婆は「初雪の 夜の ほたる祭りは、このままでは 開けない」と 嘆いた。薬師見習いの ピピと 出会い、小川の 上で 一匹だけ 光った ほたるが、森の 洞くつの 方へ 消えて いくのを 見た。",
  set: { met1: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    K.deco(p, "t17fest", 9, c, y0);
    const FQ = fac(K, p, "r1brook", "brook", REG, y0);   /* 第125版(fac): 石の 岸の 小川と 板の 橋 */
    await K.open(p, "ほたるの 里 ルミエの 外れ ほたるの 小川", "night");
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{shock,…,up}……あれ？ ここ、ほたるの 里 だよね？", "{sad}一匹も 飛んでない……。"], ["{sad,…,up}……静か。ほたるの 里 なのに、光が 一つも ないわ。"], ["{closed,…}……ほたるの 里。なのに 一匹も いない。"], ["{shock,…,up}……あの、ほたるの 里と 聞いて いたのですが……。", "{sad}光が、一つも ありませんね。"]));
    const eK = K.cast(p, "r1hakka"); K.act(eK, "hold"); K.hold(eK, "staff");
    await K.csay(p, "r1hakka", ["{closed}……ようこそ、旅の お方。わたしは この 里の 長、ハッカですのう。", "{sad,up}去年の 初雪の 夜、ほたるが 一匹も 光らなかったのですのう。"], eH);
    K.act(eK, 0);
    await K.hsay(p, K.V(["{?}消えちゃった？ 森で 何か あったの？"], ["{?}……何が あったの？"], ["{?}原因は？"], ["{?}何か、心当たりは ありますか？"]));
    await K.csay(p, "r1hakka", ["{closed}森の 葉が 灰色に くすんで、小川の 水が 濁ったのですのう。", "{sad}ほたるは、きれいな 水と 苔が ないと 生きられませぬ。"], eH);
    const sq = FQ || { x: c.x - 8, y: y0, z: c.z + 3 };
    K.burst(p.dimension, sq, "minecraft:basic_smoke_particle", 6, 1.2, 0.2);
    await K.at(p, sq, 14, 5, 1);
    await K.narr(p, ["§7小川の 水は 灰色に 濁り、岸の 苔は 茶色く 枯れて いた。", "§7祭りの 灯り柱だけが、火の ない まま 並んで いる。"], sq);
    await K.csay(p, "r1hakka", ["{sad,up}初雪の 夜が、ほたる祭り。……里の 子らが、一年で いちばん 楽しみに して おる 夜なのですのう。"]);
    const eP = K.cast(p, "r1pipi"); K.act(eP, "run");
    await K.csay(p, "r1pipi", ["{!,jump}ハッカ婆ーっ！ 小川の 下の 苔も、ぜんぶ 枯れて いたのだ！", "{sad,up}ピピの 薬じゃ、もう 間に合わないのだ……。"], eK);
    K.act(eP, 0);
    await K.csay(p, "r1hakka", ["{smile}この 子は ピピ。薬師の 見習いですのう。", "{closed}小さい ころから、この 婆が 育てて おりますのう。"], eH);
    await K.hsay(p, K.V(["{smile,♪}ピピちゃん、はじめまして！ ……薬で ほたるを 治すの？"], ["{smile}はじめまして、ピピちゃん。……ほたるの お薬を 作って いるの？"], ["{closed}……ピピ。ほたるの 薬？"], ["{smile}はじめまして、ピピさん。ほたるの お薬ですか？"]));
    K.act(eP, "point");
    await K.csay(p, "r1pipi", ["{angry,!}ほたるじゃ ないのだ。森を 治すのだ！", "{smile,☆}森が 元気に なれば、ほたるは ぜったい 帰って くるのだ！"], eH);
    await K.csay(p, "r1pipi", ["{sweat,汗}……って、本に 書いて あったのだ。"]);
    K.act(eP, 0);
    const g = K.palEnt(p);
    if (g) { K.burst(p.dimension, g.location, "minecraft:basic_smoke_particle", 3, 0.4, 0.3); await K.up(p, g, 12); }
    await K.hsay(p, K.V(["{sad}……この子も、枯れた 苔の においを かいで、しょんぼり してる。"], ["{sad}……この子も、さびしそう。"], ["{closed}……相棒も 元気が ない。"], ["{sad}……この子も、しょんぼり して いますね。"]));
    /* 石の 男の子（ピピが 毎日 話しかける）*/
    { stoneKid(K, p, c, y0); const kq = SQ(c, y0); K.act(eP, "kneel"); await K.at(p, kq, 12, 2.6, 0.9);
      await K.narr(p, ["§7小川の そばに、小さな 男の子の 石像が ある。……いや、石に なった 男の子だ。"], kq);
      await K.csay(p, "r1pipi", ["{sad,up}……石の 子、今日も ほたる いないのだ。ごめんなのだ。", "{smile}ピピは 毎日、この 子に 話しかけてるのだ。さびしく ない ように なのだ。", "{closed}ハッカ婆が 言ってたのだ。十二年前、ほたるを 見に 来た よその 子が、一夜で 石に なったのだ。……影に 眠らされるのとは ちがう、もっと 古い 災い なのだ。"], eH); K.act(eP, 0); }
    /* 一匹だけの ほたる（洞くつの 方へ 消える）*/
    const fq = { x: c.x - 5, y: y0 + 1, z: c.z - 6 };
    K.sound(p, "random.orb", 1.6);
    for (let k = 0; k < 3; k++) { K.burst(p.dimension, fq, "minecraft:endrod", 2, 0.3, 0.6); await K.wait(5); }
    await K.at(p, fq, 16, 3, 0.8);
    await K.csay(p, "r1pipi", ["{shock,!,up}い、今の……！ ほたるなのだ！ 一匹だけ、森の 奥へ……！"]);
    K.rmCine(g);
    await K.csay(p, "r1hakka", ["{closed,low}……森の 奥の 洞くつには、森を 守る 精霊さまが おると、言い伝えが ありますのう。", "{sad}じゃが 今は 森の 生き物が 気が 立って、だれも 近づけませぬのう。"], eH);
    K.act(eH, "raise");
    await K.hsay(p, K.V(["{angry,!,up}だったら、わたしたちが 調べて くる！ ほたる祭り、ぜったい やろうよ！"], ["{closed,up}……わたしたちが 行くわ。ほたる祭り、あきらめないで。"], ["{angry,up}……行く。初雪までに、間に合わせる。"], ["{angry,up}わたしたちが 参ります！ ほたる祭り、あきらめないで ください！"]));
    K.act(eH, 0);
    await K.csay(p, "r1hakka", ["{shock,…}……旅の お方が？", "{smile,tears,up}……ほんに、ありがたい ことですのう。"]);
    await K.csay(p, "r1hakka", ["{closed}そう いえば、きのう 学者さんが 一人、森の 洞くつを 調べに 行かれましたのう。"]);
    await K.hsay(p, K.V(["{smile,!,up}学者さん……セオさんだ！ 洞くつで 待ってるって、手紙に あった！"], ["{smile,up}……きっと セオさんね。洞くつで 会う 約束なの。"], ["{closed,up}……セオだ。洞くつで 会う 約束。"], ["{smile,!,up}セオさんです！ 洞くつで お会いする 約束を して います。"]));
    K.act(eP, "raise");
    await K.csay(p, "r1pipi", ["{angry,arms}薬草も 足りないのだ。あしたの 朝、外れの 森へ 摘みに 行くのだ！", "{smile,♪,up}……手伝って くれたら、うれしいのだ。"], eH);
    K.act(eP, 0);
    K.pay(p, E1, 150, [["c_herb", 2]]);
    await K.end(p, { leave: [eK, eP], card: "§7→ あしたの 朝、ルミエの 外れの 薬草の 森で ピピと 薬草を さがそう（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 2話 薬草さがし（セオの 記録の 力・祭りの 中止・夜の 本読み）---------- */
const E2 = { id: "r1e2", n: 2, t: "薬草さがし", at: 0, ord: 1, place: HERB, fac: "r1tent",
  hint: "§fルミエの 外れの §e薬草の 森§f で ピピと 薬草を さがそう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "ピピの 薬の 本は、いちばん 大事な ページが 虫に 食われて いた。森で 会った 学者セオは、十二年前に 一度 読んだ だけの その ページを、一字も まちがえずに 口に した。けれど 里では、ほたる祭りの 取りやめが 決まった。その 夜、セオは 泣き つかれた ピピに 本を 読んで やった。手帳から こぼれたのは、弟が 描いた 小さな 絵だった。",
  set: { met1: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    const FT = fac(K, p, "r1tent", "tent", REG, y0);   /* 第125版(fac): 森の 天幕と 焚き火 */
    await K.open(p, "ルミエの 外れ 薬草の 森", "day");
    let eH = K.hero(p); const eP = K.cast(p, "r1pipi"); K.act(eP, "raise");
    await K.csay(p, "r1pipi", ["{smile,♪,jump}来て くれたのだ！ 今日は、この 本の 薬を 作るのだ！"]);
    K.act(eP, "show"); K.hold(eP, "notebook");
    await K.csay(p, "r1pipi", ["{sad,up}……でも、いちばん 大事な ページが、虫に 食われて 読めないのだ。"], eH);
    K.act(eP, 0);
    K.act(eP, 0); let eS = THEO(K, p); K.act(eS, "hold"); K.hold(eS, "notebook");
    await K.say(p, "セオ", ["{smile}……やあ。声が したので、来て みました。", "{closed}洞くつの 前で 待つ つもりでしたが、森の 様子が 気に なって。"], eH);
    await K.hsay(p, K.V(["{smile,♪,jump}セオさん！ ちょうど よかった！"], ["{smile}セオさん。……会えて よかった。"], ["{closed}……セオ。ちょうど いい。"], ["{smile}セオさん！ ちょうど よい ところに。"]));
    await K.csay(p, "r1pipi", ["{?}だれなのだ？ ひょろっと してるのだ。"]);
    await K.say(p, "セオ", ["{smile,汗}学者の セオです。……ひょろっと しているのは、本ばかり 読んで いるからですね。"]);
    K.act(eS, 0);
    await K.say(p, "セオ", ["{!}その 本……『森の 薬草 百選』ですね。虫に 食われた ところは……", "{closed}『ほたる苔の 薬。夜露の 落ちた あと、北向きの 岩の 苔を 三枚』"], eP);
    await K.say(p, "セオ", ["{closed}『月見草の 根を ひとつまみ。小川の 水で 七たび 洗う』……でしたね。"]);
    await K.csay(p, "r1pipi", ["{shock,!,jump,up}ぜ、ぜんぶ 合ってるのだ！？ 見ても いないのに！"]);
    await K.say(p, "セオ", ["{smile}十二年前に、ルミエの 宿で 一度 読んだ ことが あるんです。"]);
    await K.hsay(p, K.V(["{shock,!,up}十二年前！？ 一回で 覚えちゃったの！？"], ["{shock,…,up}……一度 読んだ だけで？"], ["{shock,…,up}……十二年前の 一回で、一字も ちがわない？"], ["{shock,!,up}じゅ、十二年前に 一度 だけ……ですか？"]));
    K.act(eS, "hold");   /* 第125版 Q4: 虫食いの 頁に 書きこむ */
    await K.csay(p, "r1pipi", ["{shock,!}……書きこんだ 字、本の 字と そっくりなのだ。どっちが 本物か わからないのだ！"]);
    await K.say(p, "セオ", ["{smile,汗}一度 見た 字は、手が 覚えて しまうんです。"]);
    K.act(eS, 0);
    await K.up(p, eS, 12);
    await K.say(p, "セオ", ["{closed,…,up}……覚えて しまうんです。読んだ ものは、何でも。", "{sad,low}……忘れたくても。"]);
    await K.hsay(p, K.V(["{?,up}……セオさん？"], ["{?,up}……セオさん？"], ["{?,up}……セオ？"], ["{?,up}……セオさん？"]));
    K.act(eS, "hold");
    await K.say(p, "セオ", ["{smile,汗}あ、いえ。学者の 自慢話です。……さあ、苔を さがしましょう。"], eH);
    K.act(eS, 0);
    /* 苔さがし（時が 流れる）*/
    K.cmd(p, "camera @s fade time 0.4 0.6 0.5 color 20 30 10"); await K.wait(12);
    const rq = { x: c.x + 7, y: y0, z: c.z - 4 };
    K.burst(p.dimension, rq, "minecraft:villager_happy", 6, 0.8, 0.3);
    await K.narr(p, ["§7三人は 北向きの 岩を 一つずつ 見て 回った。", "§7苔の ほとんどは 灰色に 枯れて いたが、岩の 影に、まだ 緑が 残って いた。"], rq);
    /* 野生が 飛び出す */
    const w1 = K.monEnt(p, { x: rq.x + 1, y: y0, z: rq.z + 1 }, K.wildSp("animal"), "");
    K.sound(p, "mob.wolf.growl", 0.8); K.shake(p, 0.25, 0.4); if (ok(w1)) K.burst(p.dimension, w1.location, "minecraft:villager_angry", 4, 0.5, 0.8);
    await K.at(p, rq, 14, 4, 1);
    await K.say(p, "セオ", ["{sweat,汗}森の 子です！ 病んだ 森に おびえて いるだけ……しずめて あげて ください！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,up}こわくないよ！ ちょっと だけ、おとなしく してて！"], ["{sad,up}……ごめんね。少しだけ、がまんして。"], ["{angry,up}……しずめる。けがは させない。"], ["{angry,up}落ちついて ください！ しずめます！"]));
    if (!K.flag(p, "r1e2w")) {
      K.rmCine(w1);
      const r = await K.battle(p, K.team(["animal", "blob"], 10, 2).map((t) => ({ ...t, lv: 10, q: 0 })), { name: "病んだ 森の 野生", arena: "薬草さがし", theme: "forest", easy: true, speaker: "森の モンスター", lines: { half: "……グルル……", low: "……キュウ……" } });
      if (r !== "win") return lose(K, p, "§7学者 セオ", 18, "セオ", "{sweat,汗,up}だ、大丈夫ですか！？ いったん 里へ もどりましょう。");
      K.setFlag(p, "r1e2w");
    } else K.rmCine(w1);
    eH = K.hero(p, false); eS = THEO(K, p, true);
    const eP2 = K.cast(p, "r1pipi", true); K.act(eP2, "kneel");
    K.burst(p.dimension, rq, "minecraft:villager_happy", 8, 1, 0.4);
    await K.csay(p, "r1pipi", ["{smile,☆,up}あったのだ！ 北向きの 岩の 苔、三枚なのだ！"]);
    K.act(eP2, 0);
    /* 祭りの 取りやめ */
    const eK = K.cast(p, "r1hakka"); K.act(eK, "hold"); K.hold(eK, "staff");
    await K.csay(p, "r1hakka", ["{sad,up}……ピピ。里の みなと 話し合って、決めましたのう。", "{closed,up}今年の ほたる祭りは、取りやめ……いえ。ほたるが 帰るまで、日を 決めずに おきますのう。"], eP2);
    await K.csay(p, "r1pipi", ["{shock,!,up}え……！？"]);
    await K.csay(p, "r1hakka", ["{sad}森が 病んで おるのに、灯りを ともして 浮かれる わけには まいりませぬのう。"]);
    await K.csay(p, "r1pipi", ["{cry,tears,up}……そんな……！ ピピ、苔 とって きたのだ！ 薬、作れるのだ！！"]);
    await K.csay(p, "r1hakka", ["{sad,up}……すまんのう、ピピ。"]);
    await K.hsay(p, K.V(["{sad,up}ピピちゃん……。", "{?,up}ハッカさん、薬が できたら 森も 治るかも しれないんだよ。それでも だめ？"], ["{sad,up}……ピピちゃん。", "{?,up}ハッカさん。薬が できれば、森は 治るかも しれないわ。それでも……？"], ["{sad,up}……ピピ。", "{?,up}ハッカ。薬が できても、だめ？"], ["{sad,up}ピピさん……。", "{?,up}ハッカさま。お薬が できれば、森が 治るかも しれません。それでも……？"]), eK);
    await K.csay(p, "r1hakka", ["{closed}……婆とて、やりたいのですのう。", "{sad,low}じゃが 祭りの 灯りは、気の 立った 森の 生き物を 寄せる。子らを 森の きわに 集める わけには いきませぬ。"], eH);
    await K.csay(p, "r1hakka", ["{smile,up}ほたるが 帰った その 夜に、灯りを ともしましょう。……それが 婆の 約束ですのう。"], eP2);
    K.act(eK, 0);
    await K.bye(p, eK);
    /* その 夜（本読み）*/
    K.cmd(p, "camera @s fade time 0.5 1.2 0.6 color 0 0 10"); await K.wait(22);
    K.ambient(p, "night", { x: c.x, y: y0, z: c.z });
    if (FT) await K.at(p, FT, 10, 5, 1);
    await K.narr(p, ["§7その 夜。ピピは 泣き つかれて、森の 天幕で 毛布に くるまった。", "§7セオが 小さな 灯りを ともし、一冊の 絵本を ひらいた。"], eS);
    K.act(eP2, "down"); K.act(eS, "hold"); K.hold(eS, "notebook");
    K.sound(p, "item.book.page_turn", 1);
    await K.say(p, "セオ", ["{smile}……『むかし むかし、星を 数えるのが 大好きな 竜が いました』", "{closed}『竜は 毎晩、なくした 星を さがして、夜の 空を 飛びました』"], eP2);
    await K.csay(p, "r1pipi", ["{closed,…}……その 竜……星、見つけたのだ……？"]);
    await K.say(p, "セオ", ["{smile,up}……ええ。最後の ページで、ちゃんと。"]);
    await K.csay(p, "r1pipi", ["{closed,息}……よかった……のだ……すう……。"]);
    await K.memory(p, eS, "セオの 手帳", ["§7絵本を 閉じた とき、セオの 手帳から 一枚の 紙が すべり落ちた。", "§7子どもの 描いた 絵。§f背の 高い 兄と、小さな 弟と、一冊の 本§7。すみに『にいちゃん』と ある。"]);
    await K.two(p, eH, eS, 10);
    await K.hsay(p, K.V(["{smile}……かわいい 絵。セオさんが 描いたの？"], ["{smile}……やさしい 絵ね。"], ["{?}……その 絵、だれの？"], ["{smile}……すてきな 絵ですね。"]), eS);
    await K.up(p, eS, 12);
    await K.say(p, "セオ", ["{closed,…,up}……弟が、描いて くれたんです。", "{smile,low}本を 読んで やると、すぐ 寝て しまう 子でした。……ちょうど、この 子みたいに。"]);
    await K.hsay(p, K.V(["{smile}弟さん、今は どこに いるの？"], ["{smile}弟さんは、今 どちらに？"], ["{?}弟は、今 どこ？"], ["{smile}弟さんは、今 どちらに？"]));
    K.act(eS, 0);
    await K.say(p, "セオ", ["{sad,…,up}…………遠くに、います。"]);
    K.sound(p, "item.book.put", 1); K.act(eS, "hold"); K.hold(eS);
    await K.hsay(p, K.V(["{sad,…}……そっか。"], ["{sad}……そう。"], ["{closed}……そう。"], ["{sad}……そう、ですか。"]));
    await K.say(p, "セオ", ["{closed}……今日の ことを、書いて おきます。", "{smile}あなたと、相棒の ことも。旅の 記録は、学者の くせですから。"], eH);
    K.act(eS, 0);
    K.pay(p, E2, 200, [["c_herbs", 1], ["gift_tea", 1]]);
    await K.night(p, facAt("r1tent", p.location), "§7その 夜。ピピは 天幕の 寝床で、薬草の 袋を 抱いて 眠った。", "§7……朝。天幕の 寝床は、からっぽ だった。", [eP2]);   /* 第125版(pl): 夜 → 朝の 天幕（ピピが いない）*/
    await K.end(p, { leave: [eS], bye: [eP2], card: "§7― 翌朝、ピピの 姿が 天幕から 消えて いた ―", kind: "night" });
    return true;
  } };

/* ---------- 3話 白紙の 座（ピピを 助ける・灰色の 少女と 白紙の 座の 紙）。第125版(tm): 六影の 席は「座」で そろえる ---------- */
const E3 = { id: "r1e3", n: 3, t: "白紙の 座", at: 0, ord: 2, place: SICK, fac: "r1grove",
  hint: "§fピピが ひとりで 森へ！ §eルミエの 外れの 病んだ 森§f へ 急ごう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "祭りを あきらめきれない ピピは、薬の 最後の 材料を 取りに、一人で 病んだ 森へ 入った。囲まれた ピピを 助けた あと、灰色の 服の 少女が『座』と 書かれた 紙を 落として いった。六つの 行と、白紙の 行が 一つ。少女は「座に、わたしの 名前を 書いて ほしい」と 願い、石板を 持つ 子を 待つ と 決めた。セオは「書庫の 目録の 書式に 似て いる」と だけ 言って 紙を 返し、幼なじみが それを しまった。",
  set: { r1page: 1, met1: 1 },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    const FW = fac(K, p, "r1grove", "deadwood", 1, Y(K, p));   /* 第125版(pl): 病んだ 森（枯れ木・きのこ・青い 灯り） */
    await K.open(p, "ルミエの 外れ 病んだ 森", "ash");
    if (FW) await K.at(p, FW, 14, 6, 1.2);
    /* 第125版(pl): 先に ピピの 側（森の 奥で 囲まれて いる）を 映し、そこへ 仲間が 走って 来る */
    const fq = { x: c.x + 6, y: y0, z: c.z + 2 };
    const eP = K.cast(p, "r1pipi", true); K.act(eP, "kneel");
    const w1 = K.monEnt(p, { x: fq.x + 1.5, y: y0, z: fq.z - 1 }, K.wildSp("beast"), ""), w2 = K.monEnt(p, { x: fq.x - 1.5, y: y0, z: fq.z + 1.5 }, K.wildSp("animal"), "");
    for (const w of [w1, w2]) if (ok(w)) K.burst(p.dimension, w.location, "minecraft:villager_angry", 4, 0.5, 0.8);
    await K.narr(p, ["§7灰色に くすんだ 森の 奥。月見草の 前で、小さな 影が 囲まれて いる。"], eP);
    let eH = K.hero(p);
    await K.hsay(p, K.V(["{sweat,汗,up}ピピちゃーん！ どこ！？"], ["{sweat,汗,up}ピピちゃん……どこに いるの！？"], ["{angry,up}……ピピ！ 返事して！"], ["{sweat,汗,up}ピピさーん！ どちらですか！？"]));
    K.sound(p, "mob.wolf.growl", 1); K.shake(p, 0.3, 0.4);
    await K.csay(p, "r1pipi", ["{cry,tears,up}た、助けてなのだ……！ 月見草を とって いたら、囲まれたのだ……！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,怒,up}ピピちゃんから はなれて！！"], ["{angry,up}……その子から、はなれて！！"], ["{rage,怒,up}……はなれろ！！"], ["{angry,怒,up}ピピさんから お離れ なさい！！"]));
    if (!K.flag(p, "r1e3w")) {
      K.rmCine(w1); K.rmCine(w2);
      const r = await K.battle(p, K.team(["beast", "animal"], 12, 3).map((t) => ({ ...t, q: 0 })), { name: "病んだ 森の 群れ", arena: "白紙の 座", theme: "forest", speaker: "森の モンスター", lines: { half: "……グルル……コエ……", low: "……キュウ……ン……" } });
      if (r !== "win") return lose(K, p, "§e薬師見習いの ピピ", K.PJ("nico", 8), "ピピ", "{cry,tears,up}だ、だいじょうぶなのだ！？ ……いっしょに 逃げるのだ！");
      K.setFlag(p, "r1e3w");
    } else { K.rmCine(w1); K.rmCine(w2); }
    eH = K.hero(p, false);
    const eP2 = K.cast(p, "r1pipi", true); K.act(eP2, "up");
    await K.csay(p, "r1pipi", ["{cry,smile,up}……こ、こわかったのだ……。ありがとうなのだ……！"]);
    await K.hsay(p, K.V(["{angry,up}もう！ 一人で 来ちゃ だめ！", "{smile,tears}……でも、無事で よかった。"], ["{sad,up}……一人で 来ちゃ、だめよ。", "{smile,tears}でも、無事で よかった。"], ["{angry,up}……一人で 行くな。", "{closed}……無事で よかった。"], ["{angry,up}お一人で 来ては いけません！", "{smile,tears}……でも、ご無事で よかった。"]));
    K.act(eP2, "show"); K.hold(eP2, "bouquet");
    await K.csay(p, "r1pipi", ["{sad}……ほたる祭りが なくなるの、いやだったのだ。", "{smile,up}でも、月見草の 根、とれたのだ。これで 薬が できるのだ。"], eH);
    K.act(eP2, 0);
    /* 灰色の 少女 */
    (async () => { for (let i = 0; i < 3; i++) { K.sound(p, "step.grass", 1); await K.wait(4); } })();   /* 足音 */
    const eB = K.npcNear(p, "§5灰色の 少女", K.PJ("beryl", 9));
    await K.low(p, eB, 14);
    await K.say(p, "灰色の 少女", ["{closed,low}……ここも、ちがう。精霊の 石は、もっと 奥……。"]);
    K.re(eH, "shock", "!");
    await K.hsay(p, K.V(["{?,up}……あなた、だれ？"], ["{?,up}……あなたは？"], ["{?,up}……だれ。"], ["{?,up}ど、どちらさまですか？"]));
    await K.say(p, "灰色の 少女", ["{sad,…}…………。"]);
    await out(K, p, eB, false);
    await K.csay(p, "r1pipi", ["{?}……何か 落として いったのだ。"]);
    const pg = { x: c.x + 3, y: y0, z: c.z - 2 };
    K.burst(p.dimension, pg, "minecraft:white_smoke_particle", 3, 0.3, 0.1);
    await K.at(p, pg, 14, 2.6, 0.5);
    await K.narr(p, ["§7落ちて いたのは、一枚の 古い 紙。", "§7上に『§f座§7』と だけ あり、その 下に 六つの 行。字は かすれて 読めない。", "§7……いちばん 下に、何も 書いて いない §f白紙§7の 行が 一つ。"], pg);
    await K.hsay(p, K.V(["{?}座……？ 座る 所の こと？ いちばん 下の 行だけ、何も 書いて ない。"], ["{?}座……？ 六つの 行の 下に、何も 書いて ない 行が 一つ あるわ。"], ["{?}……座。六つの 行と、白紙が 一つ。"], ["{?}座……ですが、いちばん 下の 行だけ 白紙ですね。"]));
    /* そのころ、森の さらに 奥（第127版: 主人公の いない 場面。あなたと 仲間・ピピは 映さない）*/
    await K.offstage(p, async (V, C) => {
      const { eB2, eN } = C;
      await K.two(p, eB2, eN, 12);
      await K.say(p, "六影の 団員", ["{smile,low}へっへ。候補さまが 青い 顔して、どう したい。"], eB2);
      await K.say(p, "灰色の 少女", ["{sad,…}……座の 紙、落とした。", "{sad,low}……座の わたしの 行は、まだ 白紙。"], eN);
      await K.say(p, "六影の 団員", ["{closed}白紙で 当たり前さ。おまえは まだ 候補だろ。"], eB2);
      await K.up(p, eB2, 12);
      await K.say(p, "灰色の 少女", ["{sad,up}……座に、わたしの 名前を 書いて ほしいの。", "{closed,up}座に 名前が あれば、だれかが わたしを 覚えて いて くれる。……帰る 場所が、できる。"], eN);
      await K.say(p, "六影の 団員", ["{smile}だったら 石板を 一枚 持って きな。そしたら 上の 人も、考えて くれるかもな。"], eB2);
      K.act(eB2, "guard");
      await K.say(p, "灰色の 少女", ["{angry,low}……持って くる。精霊の 石の そばに、石板の 子が 来る。……そこで。"], eN);
    }, { set: "fb_deepwood", card: "§7― そのころ、森の さらに 奥 ―", cast: (V) => ({ eB2: V.actor("§5灰色の 少女", K.PJ("beryl", 9), [3, -0.9], V.at(3, 1.1)), eN: V.actor("§c六影の 団員", K.PJ("noxa", 9), [3, 1.1], V.at(3, -0.9)) }) });
    /* もどる */
    const eS = THEO(K, p); K.act(eS, "run"); await K.wait(10); K.act(eS, 0);
    await K.say(p, "セオ", ["{sweat,汗}はあ、はあ……悲鳴が 聞こえたので……！ ピピさん、無事ですか！"]);
    await K.csay(p, "r1pipi", ["{smile,☆,jump}セオ！ 月見草、とれたのだ！"]);
    K.act(eH, "show"); K.hold(eH, "letter");
    await K.hsay(p, K.V(["{?}セオさん、これ 見て。灰色の 服の 女の子が 落として いったの。"], ["{?}セオさん。灰色の 服の 女の子が、これを 落として いったの。"], ["{closed}セオ。灰色の 子が 落とした。座の 紙、白紙。"], ["{?}セオさん、これを。灰色の 服の 方が 落として いかれました。"]), eS);
    K.act(eH, 0);
    await K.up(p, eS, 12);
    await K.give(eH, eS, "letter");
    await K.say(p, "セオ", ["{closed}……古い 紙ですね。書庫の 目録の 書式に 似て いる。"]);   /* 第125版 Q5: あずからずに 返す */
    await K.give(eS, eH, "letter");
    await K.hsay(p, K.V(["{smile}じゃあ、わたしが 持っとく。落とした 子に 返せる ように。"], ["{smile}じゃあ、わたしが 持って おくわ。落とした 子に 返せる ように。"], ["{closed}わたしが 持っとく。落とした 子に 返す。"], ["{smile}では、わたしが お預かり します。落とした 子に お返し できる ように。"]));
    await K.say(p, "セオ", ["{closed,up}僕は 洞くつの 入口で 待って います。森が 病んだ わけは、きっと 奥の 精霊に。"]);
    K.act(eP2, "raise");
    await K.csay(p, "r1pipi", ["{angry,!,up}ピピは 薬を 作るのだ！ 祭りが なくなっても、森が 治ったら、ほたるは 帰って くるのだ！"]);
    await K.hsay(p, K.V(["{smile,up}うん！ 森は わたしたちが 治す。約束！"], ["{smile,up}ええ。森は わたしたちに まかせて。約束よ。"], ["{smile,up}……森は 治す。約束。"], ["{smile,up}はい。森は わたしたちが。約束です。"]));
    K.act(eP2, 0);
    K.pay(p, E3, 250, [["c_herb", 3]]);
    await K.end(p, { leave: [eS, eP2], card: "§7→ シルヴァの 洞くつの 入口へ。セオが 待って いる（右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 5話 ほたる祭り（森の 主を しずめた あと。里の 発展度が 上がり、祭りが 開かれる）---------- */
const E5 = { id: "r1e5", n: 5, t: "ほたる祭り", at: 3, ord: 0, place: FESTP,
  hint: "§fほたるの 里 ルミエの §e広場§f で §6ほたる祭り§f が 開かれる §7（右上の 案内。そのあと ルインズ荒野へ）",
  syn: "森の 主が 眠り、水が 澄んで、ほたるが 帰って きた。取りやめた ほたる祭りは、里の みなで やり直された。書庫へ 向かう 前の セオも 駆けつけ、ピピに 竜の 絵本を ゆずった。ピピは「本物の 薬師に なる」と 決め、里には 小川の 茶屋が できた。",
  set: { fest1: 1, met1: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), fest1: 1 }; },
  fx: { xp: [TID, 160], fest: TID },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p), C = { x: c.x, y: y0, z: c.z };
    festSet(p, "t17", c, y0); const cw = crowd(K, p, 3, "§7里の 人");
    await K.open(p, "ルミエの 広場（ほたる祭り）", "fest", "night");
    for (let k = 0; k < 4; k++) { flies(K, p, C, 8, 7); await K.wait(3); }
    K.sound(p, "note.harp", 0.8); K.sound(p, "note.bell", 0.6);
    let eH = K.hero(p);
    await K.hsay(p, K.V(["{shock,☆,jump,up}わあ……！ ほたるが、いっぱい……！！"], ["{smile,tears,up}……ほたる。こんなに、たくさん……！！"], ["{shock,…,up}……光ってる。全部、ほたる。"], ["{shock,☆,up}まあ……！ ほたるが、こんなに……！！"]));
    flies(K, p, C, 10, 5);
    await K.wide(p, 18);
    let eK = K.cast(p, "r1hakka"); K.act(eK, "hold"); K.hold(eK, "staff");
    await K.csay(p, "r1hakka", ["{smile,tears,up}……帰って きた。ほたるが、ほんに 帰って きたのですのう。", "{smile}森の 主が 眠り、水が 澄んで、苔が 戻った。……旅の お方の おかげですのう。"], eH);
    K.act(eK, 0);
    await K.csay(p, "r1hakka", ["{closed,up}取りやめた 祭りじゃが、みなで 話し合って 決めましたのう。", "{smile,♪}今夜、やり直しますのう。"]);
    let eP = K.cast(p, "r1pipi"); K.act(eP, "raise");
    await K.csay(p, "r1pipi", ["{smile,☆,jump}ピピの 薬も、小川に まいたのだ！ 苔が 元気に なったのだ！"], eK);
    K.act(eP, 0);
    let eS = THEO(K, p);
    await K.say(p, "セオ", ["{smile}……間に 合いましたか。書庫へ 行く 前に、これだけは 見て おきたくて。"]);
    K.act(eP, "run");
    await K.csay(p, "r1pipi", ["{smile,♪,jump}セオ！ 見るのだ、ほたるなのだ！"]);
    K.act(eP, 0);
    await K.up(p, eP, 10);
    await K.csay(p, "r1pipi", ["{angry,!,up}……それと、ピピ、決めたのだ。", "{smile,tears,up}ピピは、本物の 薬師に なるのだ！ 遠くの 町の 人にも、薬を 届けるのだ！"], eK);
    await K.csay(p, "r1hakka", ["{smile,tears,up}……そうですか。ピピが、そう 決めたのですのう。"]);
    K.act(eS, "hold"); K.hold(eS, "notebook");
    await K.say(p, "セオ", ["{smile,up}……いい 夢です。記録して おきます。", "{closed,up}『ほたるの 帰った 夜、ピピさんが 薬師に なると 決めた』と。"], eP);
    await K.say(p, "セオ", ["{smile}この 絵本は、ピピさんに あげます。竜が 星を さがす お話です。"]);
    await K.csay(p, "r1pipi", ["{shock,!,up}……いいのだ！？ セオの 宝物じゃ ないのだ？"]);
    await K.up(p, eS, 10);
    await K.say(p, "セオ", ["{smile,closed,up}だから、です。……僕は もう、全部 覚えて いますから。"]);
    K.act(eS, 0);
    /* 石の 子へ 灯りを 見せに 行く ピピ（灯りの 列は 外れの 小川まで）。セオは 近づかない */
    await K.csay(p, "r1pipi", ["{smile,♪,up}石の 子にも、ほたるを 見せて あげるのだ！ セオも 来るのだ！"], eS);
    { const B = SPRING(); let bc = c, by = y0, eS2 = eS;
      if (B) { await moveG(K, p, B, "ルミエの 外れの ほたるの 小川（灯りを 運ぶ）", [eK, ...cw]); bc = { x: B.x + 0.5, z: B.z + 0.5 }; by = Y(K, p); fac(K, p, "r1brook", "brook", REG, by); eS2 = THEO(K, p); const e1 = K.cast(p, "r1pipi"); if (ok(e1)) eP = e1; const e2 = K.hero(p); if (ok(e2)) eH = e2; }
      stoneKid(K, p, bc, by);
      const kq = SQ(bc, by); flies(K, p, kq, 6, 1.5); await K.at(p, kq, 12, 2.6, 0.9);
      await K.up(p, eS2, 10);
      await K.say(p, "セオ", ["{closed,…,up}……僕は、ここで 見て います。"]);
      if (ok(eS2)) { const l = eS2.location; try { eS2.teleport(l, { facingLocation: { x: l.x + (l.x - kq.x), y: l.y + 1.5, z: l.z + (l.z - kq.z) } }); } catch {} K.re(eS2, "sad", "…"); }
      await K.up(p, eS2, 18);
      if (B) { await moveG(K, p, FESTP(), "ルミエの 広場（ほたる祭り）", [eS2, eP]); const e3 = K.cast(p, "r1hakka"); if (ok(e3)) eK = e3; const e4 = K.cast(p, "r1pipi"); if (ok(e4)) eP = e4; const e5 = K.hero(p); if (ok(e5)) eH = e5; eS = THEO(K, p); } }
    /* 祭りの 輪 */
    for (const e of [eK, eP, eH]) K.act(e, 9);
    K.ambient(p, "fest", C); K.sound(p, "note.pling", 0.8);
    const g = K.palEnt(p); if (g) K.burst(p.dimension, g.location, "minecraft:note_particle", 5, 0.5, 1);
    for (let k = 0; k < 3; k++) { flies(K, p, C, 10, 8); await K.wait(4); }
    await K.wide(p, 24);
    for (const e of [eK, eP, eH]) K.act(e, 0);
    K.rmCine(g);
    K.act(eK, "hold"); K.hold(eK, "pouch");
    await K.csay(p, "r1hakka", ["{smile}里の 名物、ほたる茶ですのう。旅の おともに、持って いきなされ。"]);
    await K.give(eK, eH, "pouch");
    const got = K.pay(p, E5, 500, [["mei_silva", 2], ["gift_tea", 1], ["c_herbs", 1]]);
    if (got.length) K.big(p, "§a§lほたるの 里の おくりもの", `§e${got.join("・")}`);
    K.act(eK, 0);
    await K.hsay(p, K.V(["{smile,tears,up}……ほたる、きれいだね。ありがとう、みんな！"], ["{smile,tears,up}……ありがとう。きっと 忘れないわ。"], ["{smile,up}……ありがとう。いい 夜だった。"], ["{smile,tears,up}……ありがとう ございました。忘れません。"]));
    await K.csay(p, "r1pipi", ["{smile,♪,up}いって らっしゃいなのだ！ 次に 会う ときは、ピピは 薬師なのだ！"]);
    await K.csay(p, "r1hakka", ["{smile,up}いって らっしゃいませ。……ほたるの 灯りが、帰り道を 照らしますのう。"]);
    await K.end(p, { leave: [eS], bye: [eK, eP, ...cw], card: "§f― 第2章 森の 精霊石 おわり ―\n§7→ 次は ルインズ荒野の はいきょの 村 ガレキへ（右上の 案内）", kind: "fest", t: 60 });
    return true;
  } };

epAdd(1, [E1, E2, E3, E5], { steps: { 0: [4, "洞くつの 奥（入口で セオと）"], 1: [4, "洞くつの 奥（大広間）"], 2: [5, "ほたる祭り（森の 主）"] } });
