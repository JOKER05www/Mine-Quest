// フォーム・インベントリ・演出の共通処理
import { system, world, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { ITEMS, SPECIES, CURRENCY } from "./data.js";

export const wait = (t) => new Promise((r) => system.runTimeout(r, Math.max(1, t)));
export const ok = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
// v2.9.13: いつから 止まって いるか（「バグを 直す」で 本当に 止まった ときだけ 外す ため）
export const busy = new (class extends Set {
  constructor() { super(); this.since = new Map(); }
  add(k) { if (!super.has(k)) this.since.set(k, Date.now()); return super.add(k); }
  delete(k) { this.since.delete(k); return super.delete(k); }
})();
export const UI_ACT = new Map();   // 人 → 最後に 画面を 出した／答えた 時刻
// v2.9.6: ぬけた 人は 「いそがしい」を はずす（入りなおしたら すぐ 遊べる）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { busy.delete(playerId); try { bagCache.delete(playerId); } catch {} }); } catch {}   // disconnect: 抜けた 人の バッグの キャッシュも 捨てる
// ---- 軽量モード（設定で オン）----
let LITE = false, LITE_ADDON = false;
export const isLite = () => LITE;
export const liteAddon = () => LITE_ADDON;
export function refreshLite() {
  try { LITE_ADDON = !!world.scoreboard?.getObjective?.("mrpg_lite"); } catch { LITE_ADDON = false; }
  let w = false;
  try { w = world.getDynamicProperty("mrpg:lite") === true; } catch {}
  LITE = w;   // v3.0: 軽量化パックは なくなった（設定だけで きめる）
}
system.runInterval(refreshLite, 100);
system.run(refreshLite);   // v3.0: 入って すぐの 子にも 正しい しるしを
// v1.7: 処理の 重さを はかって 自動で 軽くする（TPS: 1秒あたりの tick 数。ふつうは 20）
let TPS = 20, lastT = Date.now(), HEAVY = 0;
const BOOT_T = Date.now();
system.runInterval(() => {
  const now = Date.now(), dt = (now - lastT) / 1000; lastT = now;
  if (dt > 0) TPS = TPS * 0.6 + Math.min(20, 100 / dt) * 0.4;
  HEAVY = TPS < 13 ? 2 : TPS < 17 ? 1 : 0;
}, 100);
export const tps = () => TPS;
// 0=ふつう 1=重い 2=とても重い（軽量モードは いつも 1 以上）
export const heavy = () => Math.max(HEAVY, LITE ? 1 : 0);
// ワールドに 入った 直後は 処理速度を 優先（出現・建物づくり・レイドを 待つ）
export const warming = () => Date.now() - BOOT_T < (LITE ? 90 : 45) * 1000;

export const ICON = (n) => `textures/ui/mrpg/${n}`;
export const EXH = {};   /* 第101版: 探索（explore.js）の 入口。menu から 直接 import すると 読みこみの 順が まわるので ここ経由 */
export const MON_ICON = (sp) => `textures/ui/mrpg/m_${sp}`;
export const ITEM_ICON = (id) => `textures/items/mrpg/${id}`;
// v1.7: ロゴ（文字で 表示。画像の グリフは 使わない）
export const LOGO_ROWS = ["§6§lMINE §f§lQUEST", "§e― マインクエスト ―"];
export const LOGO = "§6§lMINE §f§lQUEST";
export function showLogo(p, sub = "") {
  try { showTitle(p, LOGO, { subtitle: sub || "§eマインクエスト", fadeInDuration: 10, stayDuration: 70, fadeOutDuration: 20 }); } catch {}
}
export const LINE = "§6◆━━━━━━━━━━━━━━◆§r";
// v1.4: 文字の 見切れ対策（全角=2・半角=1 で 数えて 長すぎる 行は「…」で 切る）
const cw = (c) => (c.charCodeAt(0) < 0x100 || (c >= "\uff61" && c <= "\uff9f") ? 1 : 2);
export function clip(text, max) {
  let out = "", w = 0;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === "§" && i + 1 < text.length) { out += c + text[i + 1]; i++; continue; }
    const k = cw(c);
    if (w + k > max) return out.replace(/(§.)+$/, "") + "…";
    out += c; w += k;
  }
  return out;
}
export const widthOf = (t) => { let w = 0; for (let i = 0; i < t.length; i++) { if (t[i] === "§") { i++; continue; } w += cw(t[i]); } return w; };
// v2.9.6: 1行目が 長い ときは 切らずに 2行目へ まわす（スペースの ところで 折る）。それでも 長い ときだけ「…」
function splitAt(t, max) {
  let w = 0, cut = -1, last = -1, col = "";
  for (let i = 0; i < t.length; i++) {
    if (t[i] === "§") { col = t[i] + (t[i + 1] || ""); i++; continue; }
    if (t[i] === " " || t[i] === "・" || t[i] === "（") last = i;
    w += cw(t[i]); if (w > max) { cut = i; break; }
  }
  if (cut < 0) return [t, ""];
  const at = last > 0 && last > cut - 14 ? last : cut;
  const head = t.slice(0, at), tail = t.slice(at).replace(/^ +/, "");
  // 色と 太字を 引きつぐ（§r の あとの ものだけ）
  const codes = head.match(/§./g) || []; const k = codes.lastIndexOf("§r"); const keep = (k >= 0 ? codes.slice(k + 1) : codes).join("");
  return [head, keep + tail];
}
export const fitButton = (text, l1 = 34, l2 = 36) => {
  let L = String(text).split("\n").map((ln) => ln.replace(/ +/g, " ").replace(/§$/, ""));
  if (widthOf(L[0]) > l1) {
    const [a, b] = splitAt(L[0], l1);
    if (L.length === 1) L = [a, b];
    else if (widthOf(b) + widthOf(L[1]) + 1 <= l2) L = [a, b + " " + L[1]];
  }
  return L.slice(0, 2).map((ln, i) => clip(ln, i ? l2 : l1)).join("\n");
};
export const title = (t) => { t = String(t); return widthOf(t) > 30 ? `§l§e${clip(t, 34)}` : `§l§e${t}`; };   /* 第75版: ◆ の かざりは ⊠ に なるので やめた */   // v2.9.7: 長い タイトルは かざりを はずして 見切れない ように
export const gold = (n) => `§e${n.toLocaleString ? n.toLocaleString() : n} ${CURRENCY}§r`;

export async function show(p, form) {
  // v2.8: 画面が ずっと ひらけない ときは 待ちつづけない（約1分で あきらめる。戦いや 物語が 止まって 詰まない ように）
  for (let n = 0; ; n++) {
    try { UI_ACT.set(p.id, Date.now()); } catch {}
    const r = await form.show(p);
    try { UI_ACT.set(p.id, Date.now()); } catch {}
    if (r.canceled && r.cancelationReason === "UserBusy" && n < 120) { await wait(10); continue; }
    return r;
  }
}
// buttons: 文字列 または [文字列, アイコン]
/* 第70版: マス目の ボタンは せまいので 1行 18（全角 9字）で 折り返し、3行まで */
function hardCut(t, max) {   // 第70版: 空白で なく 幅で 切る（色は 引きつぐ）
  let w = 0, i = 0;
  for (; i < t.length; i++) { if (t[i] === "§") { i++; continue; } const k = cw(t[i]); if (w + k > max) break; w += k; }
  const head = t.slice(0, i), codes = head.match(/§./g) || [], r = codes.lastIndexOf("§r"), keep = (r >= 0 ? codes.slice(r + 1) : codes).join("");
  return [head, keep + t.slice(i).replace(/^ +/, "")];
}
export function gridFit(text, max = 20, lines = 3) {   /* 第73版: マスの 文字の 幅（全角 10字） */
  const src = String(text).split("\n").map((x) => x.replace(/ +/g, " ")).filter((x, k, a) => x !== "" || k === 0);
  const out = [];
  for (let k = 0; k < src.length && out.length < lines; k++) {
    let ln = src[k]; const room = Math.max(1, lines - out.length - (src.length - 1 - k));   // あとの 行（値・ランクなど）の ぶんを のこす
    for (let r = 0; ln && r < room; r++) {
      if (r === room - 1) { out.push(clip(ln, max)); ln = ""; break; }
      let [a, b] = splitAt(ln, max);
      if (b && widthOf(a) * 3 < max) { const h = hardCut(ln, max); a = h[0]; b = h[1]; }   /* 「○」「表」だけで 1行 使わない */
      out.push(a); ln = b;
    }
  }
  if (out.length >= lines && src.length > lines && !out[lines - 1].endsWith("…")) out[lines - 1] = clip(out[lines - 1] + " " + src.slice(lines).join(" "), max);
  return out.slice(0, lines).join("\n");
}
export const GRID_ON = true;   /* 第73版: マス目を 作り直して もどす（Chest UI と 同じ 作り。実機で 表示を 確かめた） */
export const GRID_MAX = 16;   /* 1画面 4行まで（12こまでは 3列・13〜16こは 4列。スマホ・Switch の 画面の 高さに おさまる） */
export const GRID_MARK = "§m§q";   /* 題名の 先頭の 目印（§m§q§0§3 = 3行・§m§q§0§4 = 4行。リソースパックの mq_grid.json） */
export const GRID_BODY = 4;   /* 第75版: 説明欄の 行数（4行の マス目）。3行の マス目は 8行まで（写真で 測った 文字の 大きさ） */
export const gridBodyMax = (n) => (n <= 9 ? 8 : GRID_BODY);
const pxOf = (t) => { let w = 0; for (const c of String(t).replace(/§./g, "")) w += c === " " ? 4 : cw(c) >= 2 ? 11 : 6.5; return w; };
export const bodyLines = (b) => String(b || "").split("\n").reduce((a, l) => a + Math.max(1, Math.ceil(pxOf(l) / 540)), 0);   /* 第75版: 全角 11・半角 6.5（写真で 測った）・文字 0.65倍・はば 約 385 */
/* paged の ボタンの 総数（前・次・さがす・戻る こみ） */
const pagedTotal = (n, extra) => { const per = 12 - extra - 4; return extra + Math.min(n, per) + (n > per ? 3 : 0) + 1; };
/* paged が マス目に なるか（ボタンの 文字を 3〜4行で 作る ときの めやす） */
export const pagedGrid = (body, n, extra = 0) => GRID_ON && n + extra > 5 && extra <= 5 && bodyLines(body) + 2 <= gridBodyMax(pagedTotal(n, extra));
/* 第74版: マス目の 文字で 出ない 記号（◆■▲ などが ⊠ に なる）を 出る 文字に */
const GSAFE = { "■": "=", "□": "-", "◆": "+", "◇": "-", "●": "*", "○": "o", "◎": "@", "★": "!", "☆": "!", "△": "^", "▲": ">", "▼": "v", "━": "-", "※": "*", "―": "-", "←": "<", "→": ">", "↑": "+", "↓": "-" };
/* 暗い マスでも 読める 色に（§8 灰 → §7・§0 黒 → §f・§1 紺 と §9 青 → §b・§4 赤 → §c・§5 紫 → §d） */
const GCOL = { "8": "7", "0": "f", "1": "b", "9": "b", "4": "c", "5": "d" };
/* 第75版: 縦の 一覧でも ◆■▲ などは ⊠ に なる（写真で 確認）ので 記号だけ 置きかえる（色は そのまま） */
export const glyphSafe = (t) => String(t ?? "").replace(/[■□◆◇●○◎★☆△▲▼━※―←→↑↓]/g, (c) => GSAFE[c]);
export const gridSafe = (t) => String(t ?? "").replace(/[■□◆◇●○◎★☆△▲▼━※―←→↑↓]/g, (c) => GSAFE[c]).replace(/§([0-9a-z])/g, (m, k) => (GCOL[k] ? "§" + GCOL[k] : m));
/* 第74版: マスの 文字を 見た目の 幅（半角 6・全角 9・空白 4・太字 +1）で 折り返す。maxPx は 文字 1倍の ときの はば */
export function gridWrap(text, maxPx, lines) {
  const out = [];
  const src = String(text).split("\n").map((x) => x.replace(/ +/g, " ")).filter((x, k) => x !== "" || k === 0);
  let carry = "";
  for (let k = 0; k < src.length && out.length < lines; k++) {
    let ln = carry + src[k], bold = false; carry = "";
    const room = Math.max(1, lines - out.length - (src.length - 1 - k));
    for (let r = 0; ln && r < room; r++) {
      let w = 0, cut = -1, brk = -1, codes = "";
      for (let i = 0; i < ln.length; i++) {
        if (ln[i] === "§") { const c = ln[i + 1] || ""; if (c === "l") bold = true; else if (c === "r") bold = false; i++; continue; }
        if (ln[i] === " " || ln[i] === "・" || ln[i] === "（" || ln[i] === "【") brk = i;
        w += (ln[i] === " " ? 4 : cw(ln[i]) >= 2 ? 11 : 6.5) + (bold ? 1 : 0);
        if (w > maxPx) { cut = i; break; }
      }
      if (cut < 0) { out.push(ln); ln = ""; break; }
      if (r === room - 1) { let head = ln.slice(0, cut); while (head && pxW(head + "…") > maxPx) head = head.slice(0, -1); out.push(head.replace(/§.?$/, "") + "…"); ln = ""; break; }
      const at = brk > 0 && brk > cut - 6 ? brk : cut, head = ln.slice(0, at);
      const cs = head.match(/§./g) || [], z = cs.lastIndexOf("§r"); codes = (z >= 0 ? cs.slice(z + 1) : cs).join("");
      out.push(head); ln = codes + ln.slice(at).replace(/^ +/, "");
    }
  }
  return out.slice(0, lines).join("\n");
}
const pxW = (t) => { let w = 0, b = false; for (let i = 0; i < t.length; i++) { if (t[i] === "§") { const c = t[i + 1]; if (c === "l") b = true; else if (c === "r") b = false; i++; continue; } w += (t[i] === " " ? 4 : cw(t[i]) >= 2 ? 11 : 6.5) + (b ? 1 : 0); } return w; };
const gridMark = (n) => GRID_MARK + (n <= 9 ? "§0§3" : n <= 12 ? "§0§4" : "§1§4");
export async function choose(p, t, body, buttons, grid = null) {
  if (grid === null) grid = buttons.length >= 7;   /* 第70版: ボタンが 多い 画面は マス目に */
  if (!GRID_ON) grid = false;
  if (grid && buttons.length > GRID_MAX) { if (bodyLines(body) + 1 > GRID_BODY) grid = false; else return choosePaged(p, t, body, buttons); }   /* 第73版: 16こを こえる ときは ページに 分ける */
  if (grid && bodyLines(body) > gridBodyMax(buttons.length)) grid = false;   /* 説明が 長い 画面は 縦の 一覧 */
  const f = grid ? new ActionFormData().title(gridMark(buttons.length) + gridSafe(`§l§e${t}`)).body(gridSafe(body)) : new ActionFormData().title(glyphSafe(title(t))).body(glyphSafe(body));
  const fb = !grid ? (x) => glyphSafe(fitButton(x)) : buttons.length > 12 ? (x) => gridSafe(gridWrap(x, 100, 3)) : (x) => gridSafe(gridWrap(x, 150, 3));   /* 第75版: 文字 0.6倍・3行まで（マスの 文字の はば 3列 約96・4列 約63。1倍の 幅で 150・100） */
  for (const b of buttons) {
    if (Array.isArray(b)) { if (b[1]) f.button(fb(b[0]), b[1]); else f.button(fb(b[0])); }
    else f.button(fb(b));
  }
  const r = await show(p, f);
  return r.canceled ? -1 : r.selection;
}
/* 第73版: ボタンが 多い 画面（12こ 超え）を マス目の ページに 分ける。いちばん 下の ボタン（戻る・閉じる）は どの ページにも 出す。返すのは もとの 番号 */
const CP_MEM = new Map();   /* 前に 見て いた ページ（ワールドを 閉じると 消える） */
async function choosePaged(p, t, body, buttons) {
  const last = buttons.length - 1, list = buttons.slice(0, last), per = GRID_MAX - 3, pages = Math.ceil(list.length / per), key = `${p.id}:${t}:${buttons.length}`;
  for (let page = Math.min(pages - 1, CP_MEM.get(key) || 0); ;) {
    if (CP_MEM.size > 300) CP_MEM.clear(); CP_MEM.set(key, page);
    const sl = list.slice(page * per, page * per + per), btns = [...sl];
    const hasPrev = page > 0, hasNext = page < pages - 1;
    if (hasPrev) btns.push(["§9← 前の ページ", ICON("i_back")]);
    if (hasNext) btns.push(["§9次の ページ →", ICON("i_run")]);
    btns.push(buttons[last]);
    const s = await choose(p, t, `${body}\n§8― ${page + 1} / ${pages} ページ ―`, btns, true);
    if (s < 0) return -1;
    if (s === btns.length - 1) return last;
    if (s < sl.length) return page * per + s;
    if (hasPrev && s === sl.length) page--; else page++;
  }
}
export const notice = (p, t, body) => choose(p, t, body, [["§lOK", ICON("i_back")]]);
export async function confirm(p, t, body, yes = "はい", no = "いいえ") {
  return (await choose(p, t, body, [[`§2§l${yes}`, ICON("i_party")], [`§c${no}`, ICON("i_close")]])) === 0;
}
export async function modal(p, t, build) {
  const f = new ModalFormData().title(title(t));
  build(f);
  const r = await show(p, f);
  return r.canceled ? null : r.formValues;
}

// ---- インベントリ ----
// v2.9.10: ほかの 表示が 出た ときを おぼえる（次の 目標の 表示で 上書き しない）
export const BAR_T = new Map();
export function barNote(p) { try { BAR_T.set(p.id, Date.now()); } catch {} return p.onScreenDisplay; }
// v2.9.11: 色コードを 切らずに 見える 文字数で 切る
export function clipT(t, n) { const s = String(t ?? ""); let k = 0, i = 0; for (; i < s.length; i++) { if (s[i] === "§") { i++; continue; } if (++k > n) break; } return i < s.length ? s.slice(0, i).replace(/§$/, "") + "§r…" : s; }
export function inv(p) { return p.getComponent("minecraft:inventory")?.container; }
// ---------- v2.2: バッグ（インベントリの かわりに 道具・素材・装備を しまう 場所。セーブと いっしょに プレイヤーに 保存）----------
const BAG_KEY = "mrpg:bag", BAG_CHUNK = 30000, bagCache = new Map();
// インベントリに のこす 物（右クリックで 使う 物）
export const BAG_KEEP = new Set(["monster_book", "navi", "cheat_book"]);
const keepInInv = (id) => BAG_KEEP.has(id) || ["rod", "key"].includes(ITEMS[id]?.kind);   // v2.8: だいじなもの は 持ち物に（v2.9.10: 物語の 石板は バッグへ）
export const ALWAYS_BAG = (id) => ITEMS[id]?.kind === "bslab" || ITEMS[id]?.kind === "dslab";   /* 第68版: 神の石板も */   // v2.9.10: 物語の 石板は いつも バッグの 中（持ち物の 枠を 使わない）
export function bagLoad(p) {
  if (bagCache.has(p.id)) return bagCache.get(p.id);
  let b = { i: {}, g: [] };
  try { const n = p.getDynamicProperty(`${BAG_KEY}#n`); if (typeof n === "number") { let s = ""; for (let x = 0; x < n; x++) s += p.getDynamicProperty(`${BAG_KEY}#${x}`) || ""; b = JSON.parse(s); } } catch {}
  b.i = b.i || {}; b.g = b.g || [];
  if (ok(p)) bagCache.set(p.id, b); return b;   // 抜けた 人では キャッシュしない
}
export function bagSave(p, b) {
  if (!ok(p)) return;   // 抜けた 人の 古い 画面からは 書かない（キャッシュも 変えない）
  bagCache.set(p.id, b);
  try {
    const s = JSON.stringify(b), n = Math.max(1, Math.ceil(s.length / BAG_CHUNK)), old = p.getDynamicProperty(`${BAG_KEY}#n`);
    for (let x = 0; x < n; x++) p.setDynamicProperty(`${BAG_KEY}#${x}`, s.slice(x * BAG_CHUNK, (x + 1) * BAG_CHUNK));
    if (typeof old === "number") for (let x = n; x < old; x++) p.setDynamicProperty(`${BAG_KEY}#${x}`, undefined);
    p.setDynamicProperty(`${BAG_KEY}#n`, n);
  } catch {}
}
export const autoBag = (p) => { try { return p.getDynamicProperty("mrpg:autobag") !== false; } catch { return true; } };
export function bagAdd(p, id, n = 1) { const b = bagLoad(p); b.i[id] = (b.i[id] || 0) + n; bagSave(p, b); }
export function bagAddGear(p, id, roll) { const b = bagLoad(p); b.g.push([id, roll || null]); bagSave(p, b); }
const invCount = (p, id) => { const c = inv(p); if (!c) return 0; let n = 0; for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (it?.typeId === id) n += it.amount; } return n; };
export function countItem(p, id) {
  const sid = id.replace("mrpg:", "");
  return invCount(p, id) + (id.startsWith("mrpg:") ? bagLoad(p).i[sid] || 0 : 0);
}
export function takeItem(p, id, n = 1) {
  if (countItem(p, id) < n) return false;
  const c = inv(p);
  for (let i = 0; c && i < c.size && n > 0; i++) {
    const it = c.getItem(i);
    if (it?.typeId !== id) continue;
    const k = Math.min(n, it.amount);
    n -= k;
    if (it.amount > k) { it.amount -= k; c.setItem(i, it); } else c.setItem(i, undefined);
  }
  if (n > 0) { const b = bagLoad(p), sid = id.replace("mrpg:", ""); b.i[sid] = (b.i[sid] || 0) - n; if (b.i[sid] <= 0) delete b.i[sid]; bagSave(p, b); }
  return true;
}
// v2.9.12: 物を 受けとった 時刻（これより 前の バックアップには もどせない）
export function markGot(p) { try { p.setDynamicProperty("mrpg:gotT", Date.now()); } catch {} }
export function giveItem(p, id, n = 1) {
  if (String(id).startsWith("mrpg:")) markGot(p);
  const sid = id.replace("mrpg:", "");
  const isRpg = id.startsWith("mrpg:") && ITEMS[sid];
  if (isRpg && ((autoBag(p) && !keepInInv(sid)) || ALWAYS_BAG(sid))) {
    if (["weapon", "armor", "acc"].includes(ITEMS[sid].kind)) { const b = bagLoad(p); for (let x = 0; x < n; x++) b.g.push([sid, null]); bagSave(p, b); }
    else bagAdd(p, sid, n);
    return;
  }
  const c = inv(p);
  const max = isRpg && ["weapon", "armor", "acc"].includes(ITEMS[sid].kind) ? 1 : 64;
  while (n > 0) {
    const k = Math.min(n, max); n -= k;
    let rest;
    try { rest = c?.addItem(new ItemStack(id, k)); } catch { return; }
    if (rest) {
      // v2.9.12: 持ち物が いっぱいの ときは 足もとに 落とさず バッグへ（だいじなものが 見つからなく ならない）
      if (isRpg) { try { if (["weapon", "armor", "acc"].includes(ITEMS[sid].kind)) { const b = bagLoad(p); for (let x = 0; x < rest.amount; x++) b.g.push([sid, null]); bagSave(p, b); } else bagAdd(p, sid, rest.amount); try { p.sendMessage(`§7持ち物が いっぱいなので ${ITEMS[sid].name}は バッグに 入れた`); } catch {} continue; } catch {} }
      try { p.dimension.spawnItem(rest, p.location); } catch {}
    }
  }
}
// インベントリへ 直接（バッグから 取り出す とき）
export function giveInv(p, id, n = 1, stackFn) {
  const c = inv(p), sid = id.replace("mrpg:", ""), gearK = ITEMS[sid] && ["weapon", "armor", "acc"].includes(ITEMS[sid].kind);
  while (n > 0) {
    const k = gearK ? 1 : Math.min(n, 64); n -= k;
    let rest; try { rest = c?.addItem(stackFn ? stackFn() : new ItemStack(id, k)); } catch { return; }
    if (rest) try { p.dimension.spawnItem(rest, p.location); } catch {}
  }
}
export function invFree(p) { const c = inv(p); if (!c) return 0; let n = 0; for (let i = 0; i < c.size; i++) if (!c.getItem(i)) n++; return n; }
// インベントリの マインクエストの 道具を ぜんぶ バッグへ（ブック・コンパス・釣竿は のこす）
export function stowAll(p, decode) {
  const c = inv(p); if (!c) return 0;
  const b = bagLoad(p); let n = 0;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it?.typeId?.startsWith("mrpg:")) continue;
    const sid = it.typeId.slice(5);
    if (!ITEMS[sid] || keepInInv(sid)) continue;
    if (["weapon", "armor", "acc"].includes(ITEMS[sid].kind)) { let lore = []; try { lore = it.getLore(); } catch {} for (let x = 0; x < it.amount; x++) b.g.push([sid, decode ? decode(lore) : null]); }
    else b.i[sid] = (b.i[sid] || 0) + it.amount;
    n += it.amount; c.setItem(i, undefined);
  }
  bagSave(p, b); return n;
}
export function rpgItems(p) {
  const c = inv(p); const out = {};
  if (c) for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it?.typeId?.startsWith("mrpg:") && ITEMS[it.typeId.slice(5)]) out[it.typeId.slice(5)] = (out[it.typeId.slice(5)] || 0) + it.amount;
  }
  const b = bagLoad(p);
  for (const [id, n] of Object.entries(b.i)) if (ITEMS[id] && n > 0) out[id] = (out[id] || 0) + n;
  for (const [id] of b.g) if (ITEMS[id]) out[id] = (out[id] || 0) + 1;
  return out;
}

// ---- 演出 ----
export function cmd(e, c) {
  try { if (typeof e.runCommand === "function") e.runCommand(c); else e.runCommandAsync(c); } catch {}
}
export function anim(e, name, hold = false) {
  if (!ok(e)) return;
  cmd(e, `playanimation @s animation.mrpg.${name} none 0.1 "${hold ? "0" : "q.any_animation_finished"}" mrpg.act`);
}
export function particle(e, name, dy = 1) {
  if (!ok(e)) return;
  try { const l = e.location; e.dimension.spawnParticle(name, { x: l.x, y: l.y + dy, z: l.z }); } catch {}
}
export function sound(p, id, pitch = 1) { try { p.playSound(id, { pitch, volume: 0.8 }); } catch {} }
export function subtitle(p, a, b) {
  try { showTitle(p, " ", { subtitle: a, fadeInDuration: 0, stayDuration: 50, fadeOutDuration: 6 }); } catch {}
  if (b) try { barNote(p).setActionBar(b); } catch {}
}
export const FAM_COLOR = { animal: "§a", nether: "§4", blob: "§b", beast: "§6", bird: "§e", plant: "§a", insect: "§q", aqua: "§3", golem: "§n", undead: "§7", demon: "§5", dragon: "§c", machine: "§9", sword: "§i", king: "§g", god: "§d", hime: "§m", nether: "§4", end: "§u" };
export const famColor = (sp) => FAM_COLOR[SPECIES[sp]?.fam] || "§f";
// ランクの いろ: F白 E灰 D黄 C緑 B青 A赤 S桃 SS黄金 X紫
export const RANK_COLOR = { F: "§f", E: "§7", D: "§e", C: "§a", B: "§9", A: "§c", S: "§d", SS: "§6§l", X: "§5§l" };
export const rankTag = (r) => `${RANK_COLOR[r] || "§f"}[${r}]§r`;
export const rankOf = (sp) => rankTag(SPECIES[sp]?.rank || "F");
export const monRank = (m) => m.awk || SPECIES[m.sp]?.rank || "F";   // v2.9.6: 闘魔覚醒の ランクも 出す
export const monName = (m) => `${m.kw ? "§6極" : ""}${m.ht ? "§6◆" : ""}${m.shiny ? "§e★" : ""}${famColor(m.sp)}${m.nm || SPECIES[m.sp]?.name || "?"}`;
export const monInfo = (m) => `§8Lv${m.lv} ${rankTag(monRank(m))}${m.plus ? `§8+${m.plus}` : ""} §3${m.sz || SPECIES[m.sp]?.sz || "M"}`;
export const monLabel = (m) => `${monName(m)} ${monInfo(m)}`;
// ボタン用（2行: 名前 ／ くわしく）。見切れない ように
export const monLabel2 = (m, extra = "") => `${monName(m)}\n${monInfo(m)}${extra ? " " + extra : ""}`;

// ---- ページ送りつきの一覧 ----
// items: [ラベル, アイコン]。戻り値: 選んだ番号（-1 = 戻る）
// UX案: 4ページ 以上の 一覧に「さがす・ページを とぶ」（ボタンの 文字で しぼる。返す 番号は もとの 一覧の 番号）
const kanaK = (s) => String(s || "").replace(/§./g, "").replace(/[ぁ-ゖ]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 0x60)).replace(/\s/g, "").toLowerCase();
export async function paged(p, t, body, items, per = 8, extra = [], st = null, gridOpt = null) {   // st: { page, q } を わたすと 前の ページ・しぼりこみを おぼえる
  const grid = GRID_ON && (gridOpt ?? true) && pagedGrid(body, gridOpt ? Math.max(6, items.length) : items.length, extra.length);   /* 説明が 長いと 縦（ページの 行の ぶんも 見る） */   /* 第70版: 6こ 以上は マス目で 1画面に 多く（下に ページ移動・さがす） */
  if (grid) per = 12 - extra.length - 4;   /* 第73版: 前・次・さがす・戻るの ぶんを のこして 12こ（3列）に おさめる */
  let page = (st && st.page) || 0, q = (st && st.q) || "", idx = items.map((_, i) => i);
  if (q) { const w = kanaK(q); idx = idx.filter((i) => kanaK(Array.isArray(items[i]) ? items[i][0] : items[i]).includes(w)); }
  for (;;) {
    const pages = Math.max(1, Math.ceil(idx.length / per));
    if (page >= pages) page = pages - 1;
    const sl = idx.slice(page * per, page * per + per);
    const btns = [...extra, ...sl.map((i) => items[i])];
    const nav = [];
    if (page > 0) nav.push("prev");
    if (page < pages - 1) nav.push("next");
    if (items.length > per * 3 || q || (grid && pages > 1)) nav.push("find");
    for (const n of nav) btns.push(n === "prev" ? ["§9← 前の ページ", ICON("i_back")] : n === "next" ? ["§9次の ページ →", ICON("i_run")] : [`§eさがす・ページを とぶ${q ? ` §8「${q.slice(0, 6)}」${idx.length}件` : ""}`, ICON("i_scout")]);
    btns.push(["§7戻る", ICON("i_close")]);
    const head = pages > 1 || q ? `${body}${q ? `\n§eしぼりこみ「${q}」 ${idx.length}件` : ""}\n§8― ${page + 1} / ${pages} ページ ―` : body;
    const s = await choose(p, t, head, btns, grid);
    if (s < 0 || s === btns.length - 1) return -1;
    if (s < extra.length) return -2 - s;
    const k = s - extra.length;
    if (k < sl.length) { if (st) { st.page = page; st.q = q; } return sl[k]; }
    const n = nav[k - sl.length];
    if (n === "find") {
      const v = await modal(p, "さがす・ページを とぶ", (f) => { f.textField("ボタンの 文字で しぼる（空に すると ぜんぶ）", "例: ほのお", q); if (pages > 1) f.slider("ページ", 1, pages, 1, page + 1); });
      if (!v) continue;
      const nq = String(v[0] || "").trim();
      if (nq !== q) { q = nq; const w = kanaK(q); idx = items.map((_, i) => i).filter((i) => !w || kanaK(Array.isArray(items[i]) ? items[i][0] : items[i]).includes(w)); page = 0; }
      else if (pages > 1) page = Math.max(0, Math.min(pages - 1, Math.round(v[1]) - 1));
      continue;
    }
    page += n === "prev" ? -1 : 1;
  }
}
export function meter(cur, max, len = 10, full = "§a", empty = "§8") {
  const n = Math.max(0, Math.min(len, Math.round((cur / Math.max(1, max)) * len)));
  return full + "■".repeat(n) + empty + "■".repeat(len - n) + "§r";
}
// v2.4.4: ランダムな 能力の 実（t: 1=+1〜3 2=+10 3=+50 4=+100）
const SEED_ST = ["hp", "mp", "atk", "def", "mat", "mdf", "spd", "wpn", "brt"];
export const seedId = (t) => `s_${SEED_ST[Math.floor(Math.random() * SEED_ST.length)]}${t > 1 ? t : ""}`;

// v2.9.12: タイトルは ここから 出す（右上の 案内が 出て いる タイトルを 消さない ように 時間を 記録）
export const TITLE_T = new Map();
export function showTitle(p, t, o = {}) {
  try { TITLE_T.set(p.id, Date.now() + ((o.fadeInDuration ?? 10) + (o.stayDuration ?? 70) + (o.fadeOutDuration ?? 20)) * 50 + 300); } catch {}
  try { p.onScreenDisplay.setTitle(t, o); } catch {}
}

// v2.9.12: NPCの 仕事は ダイナミックプロパティにも 記録（遠くで 作った 城・町の NPCで プロパティが 初期値に もどっても 直せる）
export function setJob(e, j) {
  try { e.setDynamicProperty("mrpg:jobd", j); } catch {}
  try { e.setProperty("mrpg:job", j); } catch {}
  system.runTimeout(() => { try { if (e.isValid() && e.getProperty("mrpg:job") !== j) e.setProperty("mrpg:job", j); } catch {} }, 5);
}

// v2.9.12: 画面の 上・左の 表示（タイトルの 文字に "MQ1:"〜"MQ4:"・"MQL:"・"MQG:" を つけて 送ると 画面の 決まった 場所に のこる）
// タイトルは 1つしか 出せないので、人ごとに 1tickに 1つずつ 送る（同じ 場所の 古い 文字は 新しい 文字で 上書き）
const HQ = new Map();   // pid -> Map(ch -> text)
const HSENT = new Map();   // pid -> Map(ch -> text)
export function hudSend(p, ch, text) {
  try {
    const sent = HSENT.get(p.id), sv = sent && sent.get(ch);
    if (sv && sv[0] === text && (text === "" || Date.now() - sv[1] < 3000)) { HQ.get(p.id)?.delete(ch); return; }   // 空の ものは 送り直さない   // 3秒ごとに 送り直す（とどかなかった ときの 保険）
    let q = HQ.get(p.id); if (!q) HQ.set(p.id, (q = new Map()));
    q.set(ch, text);
  } catch {}
}
export function hudForget(pid) { HQ.delete(pid); HSENT.delete(pid); }
system.runInterval(() => {
  if (!HQ.size) return;
  const now = Date.now();
  for (const [pid, q] of HQ) {
    if (!q.size) { HQ.delete(pid); continue; }
    if (now < (TITLE_T.get(pid) || 0)) continue;   // 技の 名前を 出して いる あいだは まつ
    let p = null; try { p = world.getEntity(pid); } catch {} if (!ok(p)) { HQ.delete(pid); continue; }
    const ch = q.has("MQT") ? "MQT" : q.has("MQS") ? "MQS" : q.keys().next().value, text = q.get(ch); q.delete(ch);   // 技の 名前を 先に
    try { p.onScreenDisplay.setTitle(`${ch}:${text}`, { fadeInDuration: 0, stayDuration: 0, fadeOutDuration: 0 }); let s = HSENT.get(pid); if (!s) HSENT.set(pid, (s = new Map())); s.set(ch, [text, Date.now()]); } catch {}
  }
}, 1);
try { world.afterEvents.playerLeave.subscribe((e) => hudForget(e.playerId)); world.afterEvents.playerSpawn.subscribe((e) => { if (e.initialSpawn) hudForget(e.player.id); }); } catch {}
export function hudResend(pid, ch) { try { HSENT.get(pid)?.delete(ch); } catch {} }

// v2.9.12: 戦いの 技の 名前（画面の まんなか。ふつうの タイトルを 使わないので 上・左の 表示を じゃま しない）
const BT_TOK = new Map();
export function battleTitle(p, title, sub, ticks = 40) {
  try {
    const tok = (BT_TOK.get(p.id) || 0) + 1; BT_TOK.set(p.id, tok);
    hudSend(p, "MQT", title && title.trim() ? title : ""); hudSend(p, "MQS", sub || "");
    system.runTimeout(() => { if (BT_TOK.get(p.id) !== tok) return; hudSend(p, "MQT", ""); hudSend(p, "MQS", ""); }, ticks);
  } catch {}
}
// v2.9.12: 戦いの 枠（上・左・まんなか）に 何か 出た まま か
export function hudBusy(pid) { const s = HSENT.get(pid), q = HQ.get(pid); for (const ch of ["MQ1", "MQ2", "MQ3", "MQ4", "MQL", "MQT", "MQS"]) { if (s && s.get(ch) && s.get(ch)[0]) return true; if (q && q.get(ch)) return true; } return false; }

// v3.0 第63版: ぬけた 人の 記録を 消す（メモリが ふえ続けない）
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { try { UI_ACT.delete(playerId); BT_TOK.delete(playerId); BAR_T.delete(playerId); TITLE_T.delete(playerId); } catch {} }); } catch {}
