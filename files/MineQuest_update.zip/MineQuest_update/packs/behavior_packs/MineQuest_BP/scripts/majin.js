// v2.9.14: 魔神編（カゲツに 勝った あと）。ムサシと 魔神の鍔と エンマ
import { world, system } from "@minecraft/server";
import { talk, tell } from "./talk.js";   /* 第108版: 会話は フォームで 止めない */
import { SPECIES, ITEMS, MOVES } from "./data.js";
const MOVES_OK = (id) => !!MOVES[id];
import { makeMonster, addMon, calcStats, STATS, TAL_MAX, canJoin, fixParty, hpBack, canBench, benchUse } from "./core.js";
import { load, save, mark, allMons, allMonsDeep } from "./store.js";
import { busy, ok, notice, confirm, sound, particle, setJob, showTitle, countItem, choose, ICON, anim } from "./ui.js";
import { TOWNS, townPos, getTown } from "./structures.js";
import { heroOf } from "./stage2.js";
const HTY = { hero_rio: "g", hero_chloe: "g", hero_hana: "g", hero_lulu: "g", hero_yuna: "o", hero_shion: "o", hero_mia: "c", hero_leaf: "c", hero_nami: "c", hero_mel: "t", hero_kaede: "t", hero_cecil: "t" };   /* 第124版: ヒロインの 話し方（saga.js の HT と 同じ）*/
const hv = (p, L) => { const h = heroOf(p); return L[(h && HTY[h.key]) || "g"] || L.g; };
import { scene, act, go, knock, knockP, shake, flash, fx, wave, fade, pause, spot, lookAt, lookUp, camAt, emote, PJ, HAKU_SP, stoneFx } from "./stage2.js";
import { RU_GATE, RU_HOOK, TK_GUIDE } from "./ruinsarea.js";
import { M_START, M_ATTACK, M_CRIT, M_KILL, M_HURT, M_PINCH, M_FAINT, M_WIN, M_MAJIN, M_FIELD } from "./musashi_lines.js";

export const MUSASHI_TOWN = "t42";   /* 第69版: はがねの 村 クロガネ（刀鍛冶の 村）。名前で さがし直す */
const musashiTownId = () => { try { return (TOWNS.find((t) => /クロガネ/.test(t.name)) || { id: MUSASHI_TOWN }).id; } catch { return MUSASHI_TOWN; } };
export const MUSASHI_JOB = 19;
const COL = "§c§l";
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const qs = (d) => d.story || (d.story = {});
export const hasTsuba = (p) => countItem(p, "mrpg:k_hilt") > 0;
export function musashiTownInfo() { const t = TOWNS.find((x) => x.id === musashiTownId()); if (!t) return null; const i = getTown(t.id); return { t, pos: i && i.built ? i : townPos(t), built: !!(i && i.built) }; }
async function say(p, who, lines, c = COL) { await talk(p, who, lines, c); }
/* 第125版: ヒロインが 第10章で 亡くなり、まだ 戻って いない あいだは 場面に 立たせない（印は 表の 物語と 共通: heroDead・heroBack）*/
export const pgGone = (d) => { const s = (d && d.story) || {}; return !!(s.heroDead && !s.heroBack); };
const heroIn = (p) => { try { return !pgGone(load(p)); } catch { return true; } };
const story_mon = (d) => allMons(d).find((m) => m.sp === "musashi" && m.storyMusashi) || allMons(d).find((m) => m.sp === "musashi");
const anyMusashi = (d) => allMonsDeep(d).some((m) => m && m.sp === "musashi");

// ---- 町の ムサシ（仲間に なる 前の プレイヤーが 近くに いる ときだけ 立っている）----
system.runInterval(() => {
  const M = musashiTownInfo(); if (!M || !M.built || typeof M.pos.y !== "number") return;
  const ow = world.getDimension("minecraft:overworld");
  let want = false;
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue;
    if (Math.hypot(p.location.x - M.pos.x, p.location.z - M.pos.z) > 72) continue;
    let d = null; try { d = load(p); } catch {}
    if (d && !qs(d).musashiJoin && !qs(d).musashiMet) want = true;   /* 第126版: 裏1 で 会った あとは 旅の 連れ（町には 立たない）*/
  }
  let have = []; try { have = ow.getEntities({ type: "mrpg:npc", tags: ["mrpg_musashi"] }); } catch {}
  if (!want) { if (globalThis.__mqStageZ?.size > 0) return; for (const e of have) try { e.remove(); } catch {} return; }   /* 第124版(cam): 場面の あいだは 消さない（仲間に なった 場面の 途中で 町の ムサシが 消えない）*/
  have = have.filter((e) => ok(e)); for (const e of have.slice(1)) try { e.remove(); } catch {}
  if (have.length) return;
  try {
    // v3.0: 建物の 中や 屋根に ならない 場所（地面の 高さが 町と ほぼ 同じ 所）を さがして 立つ
    let pos = null;
    for (const [dx, dz] of [[7.5, 6.5], [-6.5, 6.5], [6.5, -7.5], [-7.5, -6.5], [0.5, 9.5], [9.5, 0.5], [0.5, -9.5], [-9.5, 0.5], [3.5, 3.5]]) {
      let top = null; try { top = ow.getTopmostBlock({ x: Math.floor(M.pos.x + dx), z: Math.floor(M.pos.z + dz) }); } catch {}
      const ty = top ? top.location.y + 1 : null;
      if (ty === null || M.pos.y === null || M.pos.y === undefined) continue;
      if (Math.abs(ty - M.pos.y) <= 2 && !/water|lava/.test(String(top.typeId))) { pos = { x: M.pos.x + dx, y: ty, z: M.pos.z + dz }; break; }
    }
    if (!pos) pos = { x: M.pos.x + 0.5, y: (M.pos.y ?? 64) + 1, z: M.pos.z + 0.5 };
    const e = ow.spawnEntity("mrpg:npc", pos);
    setJob(e, MUSASHI_JOB); e.addTag("mrpg_npc"); e.addTag("mrpg_musashi");
    e.nameTag = "§7さすらいの 武士";
  } catch {}
}, 100);

// ---- 話しかける ----
export async function musashiTalk(p, ent) {
  let d = load(p); if (!d) return;
  const s = qs(d);
  if (s.musashiJoin) { await notice(p, "ムサシ", "§7（ムサシは もう 仲間だ。ガイドブックの「ストーリー」→「ムサシと 話す」で 話せる）"); return; }
  if (s.musashiMet || s.ending) { await say(p, "さすらいの 武士", [pick(["……ん？ 槌の 音を 聞きに 来たのか。", "この 村は いい 音が する。……俺の 用は、まだ 先だ。"])], "§7§l"); return; }   /* 第126版: 出会いは 物語（裏1）で。町では 話すだけ */
  if (!(s.ending && s.hiltGot && hasTsuba(p))) {
    await say(p, "さすらいの 武士", [pick(["うちの 鍔が 外に 出たって 噂を 聞いた。……師匠、何を 考えてる", "師匠は「まだ 早い」の 一点張りだ。くそっ……。", "……ん？ なんだ、見せもんじゃねえぞ。", "急がねえと……あいつは もう 千年も ひとりなんだ。"])], "§7§l");
    return;
  }
  if (s.musashiMet) { await say(p, "ムサシ", ["よう、来たか。……準備は いいか？ 腕だめしだ！"]); return "spar"; }   // v3.0 第63版: 2回目からは 1行
  // 鍔を 見つける（第125版: クロガネの 鍛冶の 家の 末。鍔は 自分の 家が 打った もの）
  await scene(p, async (C) => {
    const M = ok(ent) ? C.keep(ent) : C.npc("§7さすらいの 武士", MUSASHI_JOB, 3.5);
    const H = heroIn(p) ? C.hero() : null, hs = async (L) => { if (C.hn) await talk(p, C.hn, L, "§d"); };
    await say(p, "さすらいの 武士", ["{shock,!,jump}……おい、待て！ その 鍔……", "{cry,tears,up}ちくしょう、§eきれいだ§f……！ なんで こんなに きれいなんだよ……！"], "§7§l");
    await hs(["{sweat,汗}え、ちょ…… 泣いてる！？ 大の 大人が！？"]);
    act(M, "raise"); sound(p, "mrpg.slash", 1); shake(p, 0.3, 0.3);
    await say(p, "さすらいの 武士", ["{rage,怒,low}……おい、その 鍔、どこで 手に 入れた！ 答えに よっちゃ 斬るぞ！"], "§7§l");
    await tell(p, "あなた", "§7（カゲツに 託された ことを 話した）");
    if (M) { act(M, "bow"); try { M.nameTag = "§cムサシ"; } catch {} }
    await say(p, "ムサシ", ["{shock,…}師匠が……お前に 託したのか。", "{blush,汗}……悪い、名乗ってなかった。俺は §cムサシ§f。カゲツ師匠の 弟子で、§6クロガネの 鍛冶の 家§f の 末っ子だ。"]);
    act(M, "hold");
    await say(p, "ムサシ", ["{closed,up}……この 鍔の 銘、うちの ものだ。千年前、§6うちの 先祖§f が 打った。", "{sad}打ったのは クロガネ、千年 守って きたのは 師匠の §6剣の 家§f。", "{closed}中に 封じられて いるのは §4エンマ§f。死んだ 者の 名を 帳に 書く、裁きの 王だ。"]);
    act(M, 0);
    await say(p, "ムサシ", ["{sad,up}狂った 王だって 言われてる。……でも ガキの ころ、鍔の そばで 寝ると、夢で だれかが 泣いてたんだ。", "{angry,low}狂った やつは、あんな ふうに 泣かねえ。"]);
    if (s.enmaDream) await say(p, "ムサシ", ["{shock,!}……お前、神殿で 夢を 見たのか？ 鍔の ない 刀を 下げた 男の。", "それが エンマだ。鍔が 外に 出て、あいつを 呼んで る。"]);
    if (s.theoMemo) await say(p, "ムサシ", ["{closed}……魂の 帳に 名前が 載る 前なら、呼び戻せる？", "{smile,up}帳を 開けるのは、エンマだけだ。……だったら、会いに 行くしか ねえな"]);
    act(M, "point"); await say(p, "ムサシ", ["{smile,☆,low}……その 前に、師匠が 認めた 腕、見せてくれ。本気で 行くぞ！"]);
    await hs(["{smile,☆}よーし、やっちゃえ！ ……槌で なんでも 叩く 剣士なんかに 負けないでよ？"]);
  });
  { const d1 = load(p); if (d1) { qs(d1).musashiMet = 1; save(p, d1); } }   // v3.0 第63版: 出会いの 場面は 1回だけ
  return "spar";
}
// 腕だめし（story.js の fight を もらう）→ 仲間に
export async function musashiSpar(p, fight) {
  try { return await musashiSpar0(p, fight); } finally { busy.delete(p.id); }   // v3.0: とちゅうで 終わっても 印を のこさない
}
async function musashiSpar0(p, fight) {
  let res = null;
  try { const d0 = load(p); if (d0 && !qs(d0).musashiJoin) { const { duel } = await import("./cine.js"); await duel(p, "§c§l炉の 前の 一騎打ち", "§fムサシの 子と 火花を 散らす！", { b: "musashi" }); } } catch {}   /* 第106版: 魔3 */
  for (let k = 0; k < 6; k++) {
    const d0 = load(p); if (!d0) return;
    for (const m of d0.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d0);
    busy.delete(p.id);
    res = await fight(p, { team: [{ sid: "musashi", lv: 90, q: 1, plus: 15 }] }, { tier: 2, name: "ムサシ", fam: "", npc: null, arena: "ムサシの 腕だめし", theme: "shrine", speaker: "ムサシ", lines: { half: "やるじゃねえか……まだまだ！", low: "へへ……強えな、お前。" } });
    busy.add(p.id);
    if (res === "win") break;
    let again = false; try { again = await confirm(p, "負けて しまった……", "§c§lムサシ§r§f「どうした、そんな もんか？ もう 一回 来い！」\n\n§fもう一度 挑みますか？ §7（仲間は 全回復する）", "もう一度 挑む", "あとで"); } catch {}
    if (!again) { await say(p, "ムサシ", ["準備が できたら また 来い。鍔は お前が 持ってろ。師匠が 選んだのは お前だ。"]); return; }
  }
  if (res !== "win") { try { await say(p, "ムサシ", ["今日は ここまでだ。仲間を 鍛えて また 来い。……待ってるぜ。"]); } catch {} return; }
  const d = load(p); if (!d) return;
  const s = qs(d);
  if (s.musashiJoin) return;   // 2回 仲間に ならない
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  await scene(p, async (C) => {
    const M = C.npc("§cムサシ", MUSASHI_JOB, 3.5), H = heroIn(p) ? C.hero() : null;
    act(M, "kneel"); shake(p, 0.3, 0.3); await pause(10); act(M, 0);
    await say(p, "ムサシ", ["{smile,息}……ははっ、すげえな お前。師匠が 託す わけだ。", "{smile,☆,up}決めた、俺も 行く。エンマを 斬りに じゃねえ、話を 聞きに だ。", "{smile}鍔は お前が 持っててくれ。……頼んだぜ。"]);
    if (C.hn) { act(H, "cheer"); await talk(p, C.hn, hv(p, { g: ["{smile,♪,jump}やったね！ 仲間 ふえた！ ……ねえ、なんで わたしの コンパス 叩いたの？"], o: ["{smile}よかったわね。仲間が ふえたわ。……あら、わたしの コンパスを 叩いて どうしたの？"], c: ["{smile,…}……仲間が 増えた。……なぜ わたしの コンパスを 叩く。"], t: ["{smile}やりましたね！ 仲間が 増えました。……あの、なぜ わたしの コンパスを 叩くのですか？"] }), "§d"); act(M, "hold"); await say(p, "ムサシ", ["{closed}……鳴らして みねえと、信じられねえ たちなんだ。……いい 音だ。三日 寝ずに 作った 音が する。"]); }
  });
  const m = makeMonster("musashi", 60, true);
  m.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(m.tal[k], 20)])); m.storyMusashi = 1;
  const c = calcStats(m); m.hp = c.hp; m.mp = c.mp;
  addMon(d, m); mark(d.own, "musashi"); mark(d.seen, "musashi");
  s.musashiJoin = 1; s.musashiMet = 1;
  save(p, d);
  try { showTitle(p, "§c§lムサシが 仲間に なった！", { subtitle: "§f次は §6クロガネの 工房§f へ", fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {}
  sound(p, "random.levelup", 1.2); particle(p, "minecraft:totem_particle", 1.3);
  await notice(p, "魔神編", ["§c§lムサシが 仲間に なった！", "", "§fまずは ムサシの 家、§6クロガネの 工房§f へ。§7（右上の 案内）", "§7（ガイドブック → ストーリー →「ムサシと 話す」）"].join("\n"));
}

/* 第126版: 裏3-8（クロガネの 宿）で ムサシが 仲間に 入る（物語の ムサシ。1回だけ）。ほうびは 章が 出す */
export function musashiJoinMon(p) {
  const d = load(p); if (!d) return false; const s = qs(d);
  if (!anyMusashi(d)) { const m = makeMonster("musashi", 60, true); m.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(m.tal[k], 20)])); m.storyMusashi = 1; const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; addMon(d, m); mark(d.own, "musashi"); mark(d.seen, "musashi"); }
  s.musashiJoin = 1; s.musashiMet = 1; save(p, d); return true;
}
/* 第126版: 裏7-5 エンマとの 戦いの 前（ムサシは 体を 貸して いる ので 仲間から 外す。戦いの あと restoreMusashi で もどす）*/
export function possessBegin(p) {
  const d = load(p); if (!d) return false; const s = qs(d); const mus = story_mon(d); if (!mus) return false;
  const inParty = d.party.indexOf(mus), inBench = (d.bench || []).indexOf(mus);
  if (inParty >= 0 && d.party.length <= 1) return false;
  if (inParty >= 0) { d.party.splice(inParty, 1); d.box.push(mus); }
  if (inBench >= 0) { d.bench.splice(inBench, 1); d.box.push(mus); }
  s.possess = { id: mus.id, idx: inParty, bidx: inBench, subs: [] }; save(p, d); return true;
}
// ---- ムサシと 話す（ガイドブック）----
export const MUSASHI_EXTRA = [];   /* 第76版: { label, cond(p,d,s), run(p,d) } を 追加ストーリーが 入れる */
const TOPICS = [
  ["家の こと", (s) => ["俺は クロガネの 刀鍛冶の 家の 末っ子だ。親父は 鍔ばかり 打ってた。", "工房の 奥の 部屋には、千年 石の 女の子が 眠ってた。……エンマの 妹、サヤだ。", "うちの 家は、エンマが 戻る 日まで あの子を 守る って 約束を してたんだ。"]],
  ["鍔の こと", (s) => ["この 鍔は 千年前、うちの 先祖が 打った。帳の 王を 封じる ための 鍔だ。", "剣の 家が 守って、クロガネが 打つ。二つの 家で 一人の 王を 閉じこめた。", s.enmaClear ? "今は 鍔を 通して、エンマの 力を 少し 借りられる。いざって ときは 掲げてくれ。" : "鍔の 奥で、エンマは 帳を 抱いて 待ってる。……自分の 神殿へ 帰る 日を。"]],
  ["エンマの こと", (s) => s.enmaClear ? ["話して みりゃ、無口な 王様だ。妹の ことに なると、急に 早口に なる。", "邪神に『石の 者は 死者だ、帳に 書け』と 言われて、筆を 折ったんだ。", "それで 狂った 王に された。……俺は、あいつを 狂ってるとは 思わねえ。"] : ["エンマは 死んだ 者の 名を 帳に 書いて、行き先を 決める 王だった。", "千年前、なにかが あって、狂った 王と 呼ばれて 鍔に 封じられた。", s.enmaDream ? "お前が 夢で 見た 男。あれが 鍔を なくした エンマだ。" : "……鍔に ふれると、あいつの 声が 聞こえる 気が する。"]],
  ["魂の 帳の こと", (s) => s.enmaClear ? ["魂の 帳には、生きてるか 死んだかが 書き分けて ある。『死者』と 書かれた 名は 戻れねえ。", "載って いない 名は、まだ どこかに いる。……常世に、な。", "お前の 大事な 二人も、そこだ。……取り返しに 行こうぜ。"] : ["死んだ 者の 名は、魂の 帳に 載る。……師匠の 家に 伝わる 話だ。", "載る 前なら、呼び戻せる？ ……その メモを 書いた やつ、相当 調べたんだな。", "帳を 開けるのは、エンマだけだ。"]],
  ["カゲツの こと", (s) => s.kagetsuDead ? ["師匠は…… 鍔を お前に 託した 日に、釣り竿を 握った まま 眠った。", "千年分の 眠気が いっぺんに 来たんだとよ。……ずっと『眠い』って 言ってたもんな。", "ちくしょう。……いい 寝顔 だったぜ。"] : ["師匠の 家は、千年 鍔を 守ってきた 剣の 家だ。", "普段は 釣りして 昼寝してる くせに、刀を 持つと 別人だ。", "ルミナの オルドじいさんとは、若い ころからの 好敵手 なんだと。"]],
  ["刀の こと", (s) => ["この 金の 柄の 刀は、親父が 打って くれた。銘は ない。", "「名前を つけると 刀が 驕る」ってのが 親父の 口ぐせだ。", "エンマの 刀を 受け止める ために、毎日 振ってきた。"]],
  ["これから", (s) => s.enmaClear ? ["……変な 気分だぜ。千年前の 王様と 旅を するなんてな。", "鍔を 掲げれば、俺の 体に エンマの 力が 宿る。いざって ときは 使ってくれ。", s.heroBack ? "みんな 帰って きた。……次は、どこへ 行く？" : "常世への 道は、神殿の 奥だ。サヤも、お前の 二人も、待ってる。"] : ["斬り跡を 辿って、あいつの 座へ 行く。……着いたら、体を 貸して やる。", "……何が 起きても、エンマを 斬るなよ。話を 聞くんだ。", "おまえの 石の 中身も、同じ 道の 先だ。……今、うなずいたな。"]],
];
export function canTalkMusashi(d) { const s = qs(d); return !!s.musashiJoin; }
export async function musashiTalkMenu(p, d) {
  let s = qs(d);
  for (;;) {
    const ex = MUSASHI_EXTRA.filter((t) => { try { return t.cond(p, d, s); } catch { return false; } });   /* 第76版: 追加ストーリーの 話題 */
    let i = await choose(p, "ムサシと 話す", `§c§lムサシ§r\n§7${s.enmaClear ? "カゲツの 弟子。今は 鍔を 通して エンマと 旅を している" : "カゲツの 弟子。エンマを 救う ため 仲間に なった"}`, [...ex.map((t) => [t.label, ICON("i_fight")]), ...TOPICS.map(([t]) => [`§l${t}`, ICON("i_help")]), ["§7戻る", ICON("i_back")]]);
    if (i >= 0 && i < ex.length) { await ex[i].run(p, d); const d2 = load(p); if (!d2) return; d = d2; s = qs(d); continue; }
    if (i < 0 || i - ex.length >= TOPICS.length) return;
    i -= ex.length;
    s.mtalk = [...new Set([...(s.mtalk || []), i])]; save(p, d);
    await say(p, "ムサシ", TOPICS[i][1](s));
  }
}
// ときどき チャットで ひとこと（ムサシが パーティに いる とき）
const CHAT = M_FIELD.map((l) => ["ムサシ", l]);
const CHAT_E = [["エンマ", "……人の 世は、騒がしいな。だが 嫌いでは ない。"], ["ムサシ", "おい エンマ、勝手に 鍔から 話しかけるな。びっくりするだろ。"], ["エンマ", "……刀が 鍔を 取り戻した。今は それで 足りる。"]];
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try {
      if (busy.has(p.id) || Math.random() > 0.4) continue;
      const d = load(p); if (!d) continue; const s = qs(d);
      if (!s.musashiJoin || !d.party.some((m) => m.sp === "musashi")) continue;
      let pool = s.enmaClear ? CHAT : CHAT.filter(([, l]) => !/エンマ|魔神|鍔|冥府/.test(l));   // v3.0: 先の 話は しない
      if (s.kagetsuDead) pool = pool.map((x) => (/師匠、元気かな/.test(x[1]) ? ["ムサシ", "師匠、向こうでも 釣り してるかな。……してるな、絶対。"] : x));
      const [who, line] = pick(s.enmaClear && d.party.some((m) => m.sp === "enma") ? [...pool, ...CHAT_E] : pool);
      p.sendMessage(`§${who === "エンマ" ? "4" : "c"}${who}§f「${line}」`);
    } catch {}
  }
}, 20 * 60 * 3);

// ---- 神殿: 鍔を 捧げる → ムサシに 取り憑く → 倒すと ムサシに もどる ----
export async function possessionFlow(p, d, fight) {
  const s = qs(d);
  let mus = story_mon(d);
  if (!mus && anyMusashi(d)) { await notice(p, "閻魔の神殿", "§7ムサシは 牧場に いるようだ。§fパーティか 預かり所に もどしてから 来よう。"); return true; }
  if (!mus && s.musashiBack) { await notice(p, "閻魔の神殿", "§7ムサシが いない……。§f（ムサシが 自動で 戻って くるのは 1回だけ。もう 戻って こない。困ったら ガイドブック → 「バグを 直す」）"); return true; }
  if (!mus) {   // v2.9.14: ムサシが いない（前の 版で わかれた など）→ 1度だけ 物語の ムサシを もどす
    s.musashiBack = 1;
    mus = makeMonster("musashi", 60, true); mus.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(mus.tal[k], 20)])); mus.storyMusashi = 1;
    const c0 = calcStats(mus); mus.hp = c0.hp; mus.mp = c0.mp; addMon(d, mus); mark(d.own, "musashi"); save(p, d);
    await tell(p, "閻魔の神殿", "§c§lムサシ§r§f「おーい！ 置いてくなよ！ ……神殿だろ？ 俺も 行く！」");
  }
  if (!d.party.some((m) => m !== mus && m.hp > 0)) { await notice(p, "閻魔の神殿", "§cムサシ§f「待て。何が 起きるか わからねえ。ほかの 仲間も 連れて こい！」\n§7ムサシ 以外に 戦える 仲間を 表（パーティ）に 入れてから 来よう。§8（裏の 子は 仲間メニューで 表へ・倒れた 子は 宿屋で）"); return true; }
  /* 第125版: 神殿の 場面。エンマは ムサシの 体を 使って、自分の 座へ 帰って きた */
  await scene(p, async (C) => {
    const M = C.npc("§cムサシ", MUSASHI_JOB, 2.5, 1.4);
    const alt = spot(p, 6, 0);
    if (alt) { camAt(p, spot(p, 3, -2, 1.6) || p.location, alt); fx(p.dimension, "minecraft:basic_flame_particle", alt, 16, 0.6); sound(p, "mob.blaze.shoot", 0.8); shake(p, 0.3, 0.6); await pause(20); }
    await tell(p, "閻魔の神殿", "§7玉座の 前で、鍔が 燃えて いる。§f主の いない 玉座が、ムサシを 待って いた。");
    if (M) lookAt(p, M);
    act(M, "raise"); await say(p, "ムサシ", ["{closed,up}……着いたぜ、エンマ。お前の 座だ。", "{angry,!,low}約束だ。話は 聞かせて もらう。……体は、ちょっとだけ 貸して やる！"]);
    sound(p, "mob.wither.spawn", 0.6); sound(p, "ambient.weather.thunder", 0.8);   /* 第125版(snd): 見て いる 人だけ（ほかの 人に ばらさない）*/
    try { p.runCommand("camera @s fade time 0.3 0.8 0.5 color 60 0 0"); } catch {}
    if (M) { for (let k = 0; k < 12; k++) { const l = M.location; fx(p.dimension, k % 2 ? "minecraft:basic_flame_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(k * 0.9) * 1.3, y: l.y + 0.2 + k * 0.15, z: l.z + Math.sin(k * 0.9) * 1.3 }, 3, 0.2); await pause(2); } act(M, "kneel"); }
    await say(p, "ムサシ", ["{rage,cry,up}ぐっ……！ これが……千年分の、帳の 重さか……！"]);
    let E = null; if (M) { const at = { ...M.location }; flash(p, "160 0 0"); shake(p, 0.9, 0.8); await wave(p, at, "minecraft:basic_flame_particle"); knockP(p, at); try { M.remove(); } catch {} E = C.mon("enma", 0.01, 0); if (E) try { E.teleport(at); } catch {} }
    try { showTitle(p, "§4§l帳の 王 エンマ", { subtitle: "§7ムサシの 体で、千年ぶりに 座へ 帰った", fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 15 }); } catch {}
    if (E) { lookAt(p, E); anim(E, "enma_draw"); }   /* 刀を 抜いて 名乗る */
    await say(p, "エンマ", ["……帰った。", "帳を 開く 前に、確かめる。……鍔を 運んで きた 者が、帳を 預けるに 足るか"], "§4§l");
    anim(E, "enma_sheathe");
  });
  // ムサシは この 戦いの あいだ 仲間から はずす（取り憑かれて いる）
  const inParty = d.party.indexOf(mus);
  if (inParty >= 0) { d.party.splice(inParty, 1); d.box.push(mus); }
  const inBench = (d.bench || []).indexOf(mus); if (inBench >= 0) { d.bench.splice(inBench, 1); d.box.push(mus); }   // 第69版: 裏の ムサシも はずす
  // v3.0: あいた 枠には 預かり所の 強い 子が 一時的に 入る（戦いの あとで もどる）
  const subs = [];
  if (inParty >= 0) {
    const pool = d.box.filter((m) => m && m !== mus && m.sp !== "musashi" && m.sp !== "enma" && !m.storyMusashi).sort((a, b) => (b.lv || 0) - (a.lv || 0) || (b.plus || 0) - (a.plus || 0));
    for (const m of pool) { if (subs.length >= 3) break; if (canJoin(d, m)) { d.box.splice(d.box.indexOf(m), 1); d.party.push(m); subs.push(m); } }
    if (subs.length) await notice(p, "閻魔の神殿", `§7ムサシの かわりに、預かり所から §f${subs.map((m) => m.nm || SPECIES[m.sp]?.name).join("・")}§7 が かけつけた！\n（戦いの あとで 預かり所に もどる）`);
  }
  s.possess = { id: mus.id, idx: inParty, bidx: inBench, subs: subs.map((m) => m.id) }; save(p, d);
  let res = null;
  try {
    res = await fight(p, { team: [{ sid: "enma", lv: 100, q: 1, plus: 99 }] }, { tier: 2, name: "エンマ（ムサシの 体）", fam: "", npc: null, arena: "閻魔の 裁き場", theme: "hell", enma: true, enmaN: 0, friends: true, speaker: "エンマ", lines: { win: "……", lose: "……" } });
  } finally { restoreMusashi(p); }
  d = load(p); if (!d) return true;
  const st = qs(d);
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  if (res !== "win") {
    save(p, d);
    await scene(p, async (C) => {
      const M = C.npc("§cムサシ", MUSASHI_JOB, 3, 0.8, 0, "veil"); act(M, "kneel"); if (M) fx(p.dimension, "minecraft:basic_smoke_particle", M.location, 10, 0.6);
      await tell(p, "閻魔の神殿", "§7赤黒い 霧は ムサシの 体から 抜け、鍔の 中へ 戻っていった。§d魔神の鍔が 手元に 戻った。");
      await say(p, "ムサシ", ["{sweat,息,up}はぁ、はぁ……あいつ、泣いてた 気が する。もう一度 行こう。"]);
      await tell(p, "閻魔の神殿", "§7（神殿の 前で もう一度 ガイドブックを 使う）");
    });
    return true;
  }
  // 勝った: ムサシに もどる・エンマが 帳を 開く（第125版）
  const first = !st.enmaClear;
  try { p.runCommand("camera @s fade time 0.4 1.0 0.8 color 255 255 255"); } catch {}
  await scene(p, async (C) => {
    const M = C.npc("§cムサシ", MUSASHI_JOB, 3, 0.8, 0, "veil");
    act(M, "down"); if (M) { lookAt(p, M); fx(p.dimension, "minecraft:basic_smoke_particle", M.location, 12, 0.8); }
    await tell(p, "決着", "§f赤黒い 霧が ムサシの 体から ほどけ、玉座の 前に 集まって いく……");
    act(M, "kneel"); await say(p, "ムサシ", ["{closed,息}……っ、はぁ……戻った、のか……？", "{shock,!,jump}……おい、見ろ。玉座に 誰か 座ってる。"]);
    const E = C.mon("enma", 9, 0); if (E) { lookAt(p, E); await go(E, spot(p, 4.5, -0.8), 24); emote(E, "dots"); }
    if (!first) {
      await say(p, "エンマ", ["……腕は 鈍って おらぬ。帳は、変わらず ここに ある。"], "§4§l");
      await fade(E, "minecraft:basic_flame_particle");
      return;
    }
    await say(p, "エンマ", ["……負けた。だから、話す。", "われは §4魂の 帳§f に、生きて いるか 死んだかを 書き分け、行き先を 決める 王。『死者』と 書いた 名は、もう 戻らぬ。", "千年前、邪神が 頼んだ。『石の 者を、死者と 書いて ください』。……断ると、妹を 預かると 言った"], "§4§l");
    await say(p, "エンマ", ["石の 者の 中に、妹 §dサヤ§f が いた。……石の 者は、生きて いる。われは 記さなかった。", "逆らった 王は、狂った 王と 呼ばれ、鍔に 封じられた。……それで よい。帳を 汚さずに 済んだ"], "§4§l");
    act(M, 0); await say(p, "ムサシ", ["{sad,up}……そういう ことかよ。ちくしょう。"]);
    const away = pgGone(load(p));
    if (away) {
      await tell(p, "あなた", "§7（セオの メモを 見せた。§f『死んだ 者の 名は、魂の 帳に 載る。載る 前なら、呼び戻せる』§7）");
      await say(p, "エンマ", ["……その 字の 主の 名と、おまえの 連れの 名を 言え。", "帳を 開く。"], "§4§l");
      sound(p, "item.book.page_turn", 1); flash(p, "40 0 40"); if (E) fx(p.dimension, "minecraft:soul_particle", E.location, 16, 1.2); await pause(20);
      await tell(p, "魂の 帳", ["§7エンマは、千年分の 頁を めくった。", "§7……指が 止まらない。最後の 頁まで、めくりきった。", "§c二人の 名は、どこにも 載って いなかった。"]);
      await say(p, "エンマ", ["……載って おらぬ。", "ソウラの 霊廟の 帳は、われの §4魂の 帳§f の 写しだ。", "邪神の 影に 殺された 者、影に 飲まれた 者は、死者に なれぬ。魂は §5常世§f へ 連れ去られる。", "邪神の 国だ。十の 魔将が、魂を 一つずつ 抱えて 番を して おる"], "§4§l");
      await say(p, "ムサシ", ["{shock,!,up}……つまり、まだ 呼び戻せるって ことだな！？"]);
    } else {
      await say(p, "エンマ", ["……邪神の 影に 飲まれた 魂は、帳に 載らぬ。§5常世§f へ 連れ去られる。", "おまえは もう、大事な 者を 取り戻した 顔を して おる。……ならば、われの 番だ"], "§4§l");
    }
    await say(p, "エンマ", ["……妹も、そこに いる。", "千年、待たせた。……道を 開く"], "§4§l");
    if (E) lookAt(p, E);
    const gq = spot(p, 7, 0); sound(p, "mob.wither.spawn", 0.5); shake(p, 0.6, 1); flash(p, "60 0 80");
    if (gq) { camAt(p, spot(p, 2.5, -2, 1.6) || p.location, gq); for (let k = 0; k < 8; k++) { fx(p.dimension, k % 2 ? "minecraft:soul_particle" : "minecraft:portal", { x: gq.x, y: gq.y + 0.3 + k * 0.3, z: gq.z }, 6, 0.8); await pause(3); } }
    await tell(p, "常世への 道", ["§5玉座の 奥の 床が 割れ、下へ 続く 黒い 石段が 現れた。", "§7石段の 下から、冷たい 風と、たくさんの 名前を 呼ぶ 声が 聞こえる。"]);
    await say(p, "エンマ", ["われは 鍔へ 戻る。小僧と 力を 分け合おう。……常世では、共に 刀を 振る"], "§4§l");
    if (E) { const l = E.location, q = p.location; for (let k = 0; k <= 10; k++) { const t = k / 10; fx(p.dimension, "minecraft:basic_flame_particle", { x: l.x + (q.x - l.x) * t, y: l.y + 1 + (q.y - l.y) * t, z: l.z + (q.z - l.z) * t }, 3, 0.2); await pause(2); } }
    await fade(E, "minecraft:basic_flame_particle");
    act(M, "point"); await say(p, "ムサシ", ["{smile,tears,up}……へっ。勝手な 王様だぜ。", "{smile,☆}行こうぜ。サヤも、お前の 二人も、迎えに 行く！"]);
  });
  st.enmaClear = 1; st.enma = (st.enma || 0) + 1;
  if (first) st.tkRoad = 1;   /* 第125版: エンマが 常世への 道を 開いた */
  const got = [];
  if (first) {   // v3.0: エンマは 仲間に ならない。鍔を ムサシに 使うと エンマの 姿に
    got.push("§c§lムサシが 仲間に もどった！", "§d魔神の鍔が 手元に 戻った。", "§d魔神の鍔: §f戦いの 中で ムサシの HPが 半分 以下の とき 使うと、§4魔神エンマ§f が 顕現する（全回復・全能力 2段階 上昇・3〜4回行動・魔神の闘気・最優先行動 など）");
  } else got.push("§d魔神の鍔が 手元に 戻った。");
  d.gold += 500000; got.push("§e50万タヨ");
  save(p, d);
  try { p.sendMessage(`§4§l★ エンマが 帳の 王の 座へ 帰り、ムサシを 取り戻した！ ★`); } catch {} sound(p, "ui.toast.challenge_complete", 1);   // v3.0: ほかの 人には 流さない（ネタバレ）
  try { showTitle(p, "§4§l魔神編 クリア", { subtitle: "§fエンマが 常世への 道を 開いた", fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
  await notice(p, "魔神編 クリア！", got.join("\n"));
  { const dk = load(p); const sk = dk && qs(dk); if (sk && sk.kagetsuDead && !sk.kagetsuMsg) { sk.kagetsuMsg = 1; save(p, dk); try { await kagetsuWord(p); } catch (e) { console.warn(`[MonsterRPG] kagetsuWord: ${e}`); } } }   /* 第116版: カゲツの 伝言を ルミナの オルドへ */
  if (first) await tkRoadNext(p);
  return true;
}
/* 第125版: 常世への 道の 先。追加パックが あれば 行くか きく。なければ 案内と 入れ方を 見せる */
export async function tkRoadNext(p) {
  if (RU_GATE.on && RU_HOOK.enter) {
    let go1 = false; try { go1 = await confirm(p, "常世への 道", "§5玉座の 奥の 黒い 石段を 下りますか？\n§7（あとで 行く ときは、閻魔の神殿の 前で ガイドブックを 使う）", "下りる", "あとで"); } catch {}
    if (go1) await RU_HOOK.enter(p, true);
    return;
  }
  await notice(p, "常世編", TK_GUIDE.join("\n"));
}
/* 第116版: ルミナの 牧場。石の ハクに 手を 置く オルドへ、カゲツの 伝言を 届ける */
export function kagetsuWord(p) {
  return scene(p, async (C) => {
    try { p.runCommand("camera @s fade time 0.4 0.8 0.6 color 0 0 0"); } catch {}
    try { showTitle(p, " ", { subtitle: "§7― ルミナの 牧場 ―", fadeInDuration: 8, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
    const Hk = C.mon(HAKU_SP, 5, 0.9), O = C.npc("§eオルド", PJ("ordo", 8), 4.2, -0.3), H = heroIn(p) ? C.hero() : null;
    if (Hk) try { Hk.nameTag = "§7ハク（石）"; } catch {}
    act(O, "hold"); stoneFx(p, Hk, 8);
    if (O) camAt(p, spot(p, 1.6, 1.4, 1.6) || p.location, { x: O.location.x, y: O.location.y + 1.4, z: O.location.z });
    await pause(16);
    await tell(p, "ルミナの 牧場", ["§7牧場の すみ。石に なった §fハク§7 の 背中に 手を 置いて、§eオルド§7 が 北の 空を 見て いた。"]);
    if (H) { await go(H, spot(p, 3, -1.2), 10); act(H, "sad"); await talk(p, C.hn, hv(p, { g: ["{sad,…}……村長。カゲツさんから、伝言。", "{closed}『オルドに 伝えて くれ。§e百と 三勝§f』……そう 言えば わかるって。"], o: ["{sad,…}……村長さん。カゲツさんから、伝言よ。", "{closed}『オルドに 伝えて くれ。§e百と 三勝§f』……そう 言えば わかるって。"], c: ["{sad,…}……村長。カゲツから 伝言。", "{closed}『オルドに 伝えて くれ。§e百と 三勝§f』。それで わかると。"], t: ["{sad,…}……村長さま。カゲツさんから、ご伝言です。", "{closed}『オルドに 伝えて くれ。§e百と 三勝§f』……そう 申せば わかると。"] }), "§d"); }
    else await tell(p, "ルミナの 牧場", ["§fあなたは カゲツの 言葉を 伝えた。§e『オルドに 伝えて くれ。百と 三勝』"]);
    await pause(20);
    await say(p, "オルド", ["{closed,…}…………。"], "§e");
    sound(p, "random.orb", 0.4); act(O, "up"); lookUp(p, spot(p, 6, -1, 6) || p.location);
    await say(p, "オルド", ["{smile,up}……ばかもん。§e百と 四§f じゃ。", "{smile}最後の 一つは、わしの 不戦勝 じゃろうが。"], "§e");
    if (H) act(H, "up");
    await tell(p, "北の 空", [`§7オルドは 泣かなかった。${C.hn ? `§d${C.hn}§7 も` : "あなたも"} 泣かなかった。`, `§7ただ、しばらく ${C.hn ? "みんなで" : "二人で"} 北の 空を 見て いた。`]);
    stoneFx(p, Hk, 4); await pause(20);
  });
}
// 取り憑かれて いた ムサシを パーティに もどす（ぬけた ときも 読みこみ 直しで もどる）
export function restoreMusashi(p) {
  try {
    const d = load(p); if (!d) return; const s = qs(d); if (!s.possess) return;
    for (const sid of s.possess.subs || []) for (const L of [d.party, d.bench || []]) { const j = L.findIndex((m) => m.id === sid); if (j >= 0) { d.box.push(L.splice(j, 1)[0]); break; } }   /* 第69版: 裏に 入った 助っ人も */   // v3.0: 助っ人は 預かり所へ
    const i = d.box.findIndex((m) => m.id === s.possess.id);
    if (i >= 0 && s.possess.idx >= 0 && !canJoin(d, d.box[i]) && canBench(d, d.box[i])) { const [m] = d.box.splice(i, 1); d.bench = d.bench || []; d.bench.push(m); }   /* 第69版: 表が いっぱいなら 裏へ */
    else if (i >= 0 && s.possess.idx >= 0 && canJoin(d, d.box[i])) { const [m] = d.box.splice(i, 1); d.party.splice(Math.min(s.possess.idx, d.party.length), 0, m); try { fixParty(d); } catch {} }
    else if (i >= 0 && (s.possess.bidx ?? -1) >= 0) { const [m] = d.box.splice(i, 1); d.bench = d.bench || []; d.bench.splice(Math.min(s.possess.bidx, d.bench.length), 0, m); while (benchUse(d) > 4 && d.bench.length > 1) { let j = d.bench.length - 1; while (j >= 0 && d.bench[j] === m) j--; if (j < 0) break; d.box.push(d.bench.splice(j, 1)[0]); } }   // 第69版: 裏に もどす（あふれた 子は 預かり所へ）
    if (!d.party.length) { const src = (d.bench || []).length ? d.bench : d.box; if (src.length) d.party.push(src.shift()); }   /* 第69版 */
    delete s.possess; save(p, d);
  } catch {}
}
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => { if (initialSpawn) system.runTimeout(() => restoreMusashi(p), 40); }); } catch {}

// ---- 戦いの 中の ムサシの ひとこと（チャット）----
const say1 = (B, list, tag = "ムサシ") => { const l = pick(list); for (const x of B.players || []) try { x.p.sendMessage(`§c§l${tag}§r§f「${l}」`); } catch {} };
const isMus = (f) => f && f.m && f.m.sp === "musashi" && f.side === "a" && !f.guest;
export function musashiBattleStart(B) { try { if (B.pvp) return; const f = (B.allies || []).find(isMus); if (f) { B.mSaid = {}; say1(B, M_START); } } catch {} }
export function musashiAct(B, a, fx) {
  try {
    if (!B || B.pvp || !fx) return;
    const me = (B.allies || []).find(isMus); if (!me) return;
    B.mSaid = B.mSaid || {};
    const ko = fx.ko || [], dmg = fx.dmg || [];
    if (ko.includes(me)) { say1(B, M_FAINT); return; }
    if (a.actor === me) {
      if (ko.some((t) => t.side === "e")) { say1(B, M_KILL); return; }
      if (dmg.some((x) => x.crit && x.t.side === "e")) { say1(B, M_CRIT); return; }
      if (Math.random() < 0.3) say1(B, M_ATTACK);   /* 第89版: せりふを 20種類に したので 言う 回数も 減らす */
      return;
    }
    if (dmg.some((x) => x.t === me && x.d > 0)) {
      if (me.hp > 0 && me.hp < me.mx.hp * 0.3 && !B.mSaid.pinch) { B.mSaid.pinch = 1; say1(B, M_PINCH); return; }
      if (Math.random() < 0.35) say1(B, M_HURT);
    }
  } catch {}
}
export function musashiWin(B) { try { if (!B.pvp && (B.allies || []).some((f) => isMus(f) && f.hp > 0)) say1(B, M_WIN); } catch {} }
// ---- 戦いの 中で 魔神の鍔を 使う（ムサシ → エンマの 姿）----
export const ENMA_MOVES = ["g_hades6", "xp_dark6", "g_hades3", "du_fire_dark"];
export function tsubaReady(p, d, mine) { try { const s = qs(d); return !!(s.enmaClear && hasTsuba(p) && mine.some((f) => f.m && f.m.sp === "musashi" && f.hp > 0 && f.hp <= f.mx.hp * 0.5 && !f.lookAs)); } catch { return false; } }   // v3.0: ムサシの HPが 半分 以下の とき
export function tsubaTransform(f, log) {
  if (!f || f.hp <= 0 || f.hp > f.mx.hp * 0.5 || f.lookAs) return false;   // v3.0: ムサシの HPが 半分 以下の ときだけ
  f.lookAs = "enma"; f.name = "魔神エンマ（ムサシ）";
  // 顕現: 全回復・全能力 2段階 上昇・特性が かわる
  f.hp = f.mx.hp; f.mp = f.mx.mp; f.dead = false; for (const k of Object.keys(f.ail || {})) f.ail[k] = 0; f.boundT = 0;
  if (f.m) { f.m.hp = hpBack(f); f.m.mp = f.mp; }
  for (const k of ["atk", "wpn", "mat", "def", "mdf", "spd", "brt"]) f.buf[k] = Math.min(6, (f.buf[k] || 0) + 2);
  f.tr = { ...f.tr, acts: [3, 4], majinAura: 0.3, first: true, topPri: true, nocap: true, critguard: true, dealt: { ...(f.tr.dealt || {}), weapon: ((f.tr.dealt || {}).weapon || 0) + 0.3, phys: ((f.tr.dealt || {}).phys || 0) + 0.3 } };
  if (f.tr0) f.tr0 = { ...f.tr0, tr: { ...f.tr } };   // 打ち消されても もどる
  for (const id of [...ENMA_MOVES, "sig_enma"]) if (MOVES_OK(id) && !f.moves.includes(id)) f.moves.push(id);
  log.push("§4§lムサシは 魔神の鍔を 掲げた！", "§4赤黒い 霧が ムサシを 包み……§l魔神エンマが 顕現した！", "§d全回復・全能力 2段階 上昇！", "§5特性: §f3〜4回行動・魔神の闘気（相手を ときどき 動けなく する）・最優先行動・上限なし・会心無効・武系と 物理系 +30%");
}
