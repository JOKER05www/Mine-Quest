/* 第126版 裏6「斬り跡・下」（こもれびの 森／谷の 割れ目／王冠の 割れ目）— 作業 UA。段なし（前27）
   常世パックが ない 人は、この 章の 終わり（6-8）で「続きは 追加ストーリー」（bkeng.js の packGate・PG_GATE）*/
import { bkAdd, tokoyoOn } from "./bkeng.js";
import { facAdd, FAC_OPS, fac, facMark } from "./epfac.js";
import { ok } from "./ui.js";
import { UA } from "./bk_u01.js";
const { F, S1 } = FAC_OPS;

/* 森の 斬り跡（割れ目・そばの 木 二本）*/
facAdd("u_forestcrack", { D: [9, 11, 8], box: [-1, -5, 6, 5], H: 7, look: [2, 0, 0], marks: { crack: [2, 0, 0] }, build: () => [
  F(1, -3, -3, 2, 3, -1, "air"), F(1, -3, -4, 2, 3, -4, "deepslate"), F(0, -3, -1, 0, 3, -1, "mossy_cobblestone"), F(3, -3, -1, 3, 3, -1, "mossy_cobblestone"),
  F(5, -3, 0, 5, -3, 4, "oak_log"), F(4, -4, 4, 6, -2, 5, "oak_leaves"), F(5, 3, 0, 5, 3, 4, "oak_log"), F(4, 2, 4, 6, 4, 5, "oak_leaves"), S1(4, 0, 0, "fern"),
] });
/* 谷の 割れ目（両側の 岩の 崖・あいだの 細い 割れ目）*/
facAdd("u_valley", { D: [10, 12, 9], box: [-1, -6, 7, 6], H: 6, look: [3, 0, 0], marks: { crack: [3, 0, 0] }, build: () => [
  F(1, -6, 0, 6, -4, 4, "stone"), F(1, 4, 0, 6, 6, 4, "stone"), F(2, -4, 5, 5, -4, 5, "andesite"), F(2, 4, 5, 5, 4, 5, "andesite"),
  F(2, -1, -3, 6, 0, -1, "air"), F(2, -1, -4, 6, 0, -4, "deepslate"),
] });
/* 王冠の 割れ目（ルミナの 外れ。深い 割れ目と、底へ 下りる 石の 階段）*/
facAdd("u_crowncrack", { D: [10, 12, 9], box: [-1, -4, 8, 4], H: 3, look: [3, 0, -1], marks: { crack: [3, 0, -1], stairs: [6, 0, -2], top: [2, 0, 0] }, build: () => [
  F(1, -2, -5, 7, 2, -1, "air"), F(1, -2, -6, 7, 2, -6, "deepslate_tiles"), F(0, -3, -1, 8, -3, -1, "cobbled_deepslate"), F(0, 3, -1, 8, 3, -1, "cobbled_deepslate"),
  S1(2, 0, -2, "stone_brick_stairs"), S1(3, 0, -3, "stone_brick_stairs"), S1(4, 0, -4, "stone_brick_stairs"), S1(5, 0, -5, "stone_brick_stairs"), F(2, 0, -6, 7, 0, -6, "stone_bricks"),
  S1(7, 0, -5, "soul_lantern"),
] });

const C3 = UA.far("u_crack3", "t9", 0.6, "こもれびの 森の 斬り跡", 80, 260);   /* 第127版(fac2): 町の 外れ → 離れた 森・谷・丘 */
const C4 = UA.far("u_crack4", "t0", 2.4, "谷の 割れ目", 90, 280);
const C5 = UA.far("u_crack5", "t0", -1.2, "王冠の 割れ目", 90, 280);
const PINN = UA.bld("t4", ["inn"], "ポカラの 宿");
const ghost = (K, p, q, nm, job) => { const e = K.npcNear(p, nm, job, true); if (ok(e) && q) try { e.teleport({ x: q.x, y: q.y ?? e.location.y, z: q.z }); } catch {} if (ok(e)) K.burst(p.dimension, e.location, "minecraft:white_smoke_particle", 10, 0.6, 1); return e; };
const mghost = (K, p, q, sid, nm) => { const e = K.monEnt(p, q, sid, nm); if (ok(e)) K.burst(p.dimension, e.location, "minecraft:white_smoke_particle", 12, 0.8, 1.2); return e; };
const fade = (K, p, e) => { if (ok(e)) K.burst(p.dimension, e.location, "minecraft:white_smoke_particle", 12, 0.6, 1); };

bkAdd("u06", [
  { id: "u06e1", pv: 127, t: "鞘を 差し出す 形", place: C3, fac: "u_crack3", battles: 0,
    hint: "§fシルヴァ大森林 §eこもれびの 森§f の 斬り跡へ 行こう §7（斬り跡 3）",
    syn: "こもれびの 森の 斬り跡。剣王カムトケの 残像が、鞘を 差し出す 形を なぞって 消えた。",
    async run(p, d, K) {
      const Q = fac(K, p, "u_crack3", "u_forestcrack", 1, UA.Y(K, p)), cq = facMark("u_crack3", "crack", p.location);
      await K.open(p, "こもれびの 森の 斬り跡", "day");
      if (Q) await K.at(p, Q, 14, 6, 1.6);
      const eM = UA.mu(K, p, true);
      await UA.ear(K, p, eM, cq);
      await K.say(p, "ムサシ", ["{closed}……ひゅう、ひゅう、って 鳴ってる。底の ほうから。", "{smile}こいつは『ひゅう割れ』だな。"], cq);
      await UA.en(K, p, ["{rage,low}§4……斬り跡、だ。千年前に、われが 付けた。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{sweat,汗}……名前が あるなら 先に 言え。", "{?}で、この 跡に 何が 残ってる。"], null);
      const eK = null;
      await K.flashback(p, { set: "fb_oldforest", label: "§7―― 千年前　こもれびの 森", tod: "dusk", ptc: "dust",   /* 第127版: 斬り跡の 残像を 回想の 絵で */
        actors: { ka: { nm: "§6冠の 剣士", job: K.PJ("m6_aldo", 8), at: [3, 0.9], look: "en", hold: "katana" }, en: { nm: "§4若い エンマ", job: K.PJ("c7_enma_y", 9), at: [3.2, -1], look: "ka", hold: "katana" } },
        beats: [
          ["narr", "§7千年前の 森。冠を つけた 剣士が、兄弟弟子の 前に 立って いた。", "ka"],
          ["say", "ka", "{closed}……その 刀には、ささやきが 宿って いる。おまえの 声では ない 声だ。", "en"],
          ["say", "en", "{angry,low}聞こえて いる。……だが、まだ 手放せぬ。", "ka"],
          ["hold", "ka", "box"], ["act", "ka", "give"],
          ["say", "ka", "{sad}なら、せめて 鞘に 納めろ。……兄弟子の 頼みだ。", "en"],
          ["narr", "§7冠の 剣士は、両手で §f鞘§7 を 差し出した。……刀を 納めて くれと 言う ように。", "ka"],
        ] });
      await UA.en(K, p, ["{rage,low}§4……カムトケ。剣王。われの 兄弟弟子だ。"], null);
      await K.say(p, "ムサシ", ["{shock}……知り合いか、エンマ。"], null);
      await UA.en(K, p, ["{closed,low}§4……兄弟弟子だ。……あれは、われを 止めに 来た。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{?}止めに？ じゃあ、さっきの 鞘は……", "{closed}刀を 納めろって、頼んでたのか。"], null);
      await UA.en(K, p, ["{rage,low}§4……その 頼みを、われは 聞かなかった。"], null);
      await K.say(p, "ムサシ", ["{sad,…}……そうか。", "{closed}もう 少し ここに いさせて くれ。指で 確かめたい 形が ある。"], cq);
      await K.end(p, { leave: [eM], bye: [eK], card: "§7→ 森で もう少し（斬り跡で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u06e2", pv: 127, t: "斬りたく なかった", place: C3, fac: "u_crack3", battles: 0,
    hint: "§fこもれびの §e森の 斬り跡§f",
    syn: "ムサシが 鞘の 形を 指で なぞった。「千年前の やつも、斬りたく なかったんだな」。",
    async run(p, d, K) {
      fac(K, p, "u_crack3", "u_forestcrack", 1, UA.Y(K, p)); const cq = facMark("u_crack3", "crack", p.location);
      await K.open(p, "こもれびの 森", "day");
      const eM = UA.mu(K, p, true);
      if (cq) await K.approach(p, eM, cq, 1.2, 12);
      K.act(eM, "kneel"); await K.up(p, eM, 10);
      await K.narr(p, ["§7ムサシは 割れ目の 縁を、鞘の 形に 指で なぞった。"], eM);
      await K.say(p, "ムサシ", ["{shock,…}……ここだけ、跡が 丸い。……鞘の 口の 形だ。"], cq);
      await K.say(p, "ムサシ", ["{sad,…}……千年前の やつも、斬りたく なかったんだな。", "{closed}納めろって 差し出してた。……斬った ほうも、止めた ほうも。"], null);
      K.act(eM, 0);
      await UA.en(K, p, ["{rage,low}§4……斬らねば ならなかった。斬らねば、王冠から 漏れる。"], null);
      await K.say(p, "ムサシ", ["{?}漏れる？ 何が。……おい、黙るなよ。"], null);
      await K.narr(p, ["§7エンマは 答えなかった。§8割れ目の 底で、風だけが 鳴って いる。"], cq);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}……一つ、二つ、三つ。", "{sweat,…}……親父に 習った 槌の 数だ。黙られると、数えたく なる。"], null);
      await UA.en(K, p, ["{closed,low}§4……今は 言えぬ。最後の 斬り跡で、見せる。"], null);
      await K.say(p, "ムサシ", ["{angry}……見せるって 言ったな。約束だぞ。", "{?}次は どこだ。……谷？ 岩の 割れた 所か。"], null);
      await UA.en(K, p, ["{closed,low}§4……アルカトラスの 谷だ。崖の あいだに、まっすぐな 跡が ある。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{smile}よし。……お前も、足が もう そっちを 向いてるな。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 谷の 割れ目へ（斬り跡 4）" });
      return true;
    } },
  { id: "u06e3", pv: 127, t: "ガルダバラの 型", place: C4, fac: "u_crack4", battles: 0,
    hint: "§eアルカトラス地方の 谷の 割れ目§f へ 行こう §7（斬り跡 4）",
    syn: "谷の 割れ目。刀神ガルダバラの 型の 残像。ムサシは 見て 真似を したが、一度では できずに 転んだ。",
    async run(p, d, K) {
      const Q = fac(K, p, "u_crack4", "u_valley", 0, UA.Y(K, p)), cq = facMark("u_crack4", "crack", p.location);
      await K.open(p, "谷の 割れ目", "day");
      if (Q) await K.at(p, Q, 14, 7, 2.4);
      await K.narr(p, ["§7両側に 岩の 崖。§8底に、まっすぐな 割れ目が 一筋。"], Q);
      const eG = mghost(K, p, cq ? { x: cq.x, y: cq.y, z: cq.z + 1 } : K.fwd(p, 5), "god30", "§7刀神の 残像");
      if (ok(eG)) await K.push(p, eG, 22, 6, 2.4);
      await K.narr(p, ["§7刀神 §fガルダバラ§7 の 残像が、一つの 型を 見せた。§8踏みこみ、ひねり、下から 斬り上げる。"], eG);
      const eM = UA.mu(K, p, true);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{shock,…}……今の、ずばっ、じゃ ねえ。ぎゅっ、しゅばっ、だ。", "{smile}『ぎゅっしゅば斬り』だな。"], eG);
      await UA.en(K, p, ["{closed,low}§4……刀神 ガルダバラの 型だ。名は、別に ある。"], eG);
      await K.say(p, "ムサシ", ["{smile,!}名前は 後だ。……見えた。やって みる。"], eG);
      K.act(eM, "raise"); await K.wait(6); K.act(eM, "knocked"); K.sound(p, "damage.fallsmall", 0.8); await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{sweat,汗}……いてえ。", "{closed}足が 逆だ。……いや、逆か？ 俺が 逆なのか。"], eG);
      K.act(eM, 0);
      await UA.en(K, p, ["{rage,low}§4……右足からだ、小僧。"], eG);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{?}……右足？ 踏みこむ 方か、ひねる 方か。"], eG);
      await UA.en(K, p, ["{closed,low}§4……踏みこむ 足も、ひねる 軸も、右だ。左は 後から ついて 来させろ。"], eG);
      await K.say(p, "ムサシ", ["{sweat}……両方 右か。そりゃ 転ぶ わけだ。", "{closed}もう 一回 見せて くれ。……今度は 目じゃ なくて、音で 覚える。"], eG);
      await UA.en(K, p, ["{closed,low}§4……型は 待たぬ。残像が 消える 前に、もう 一度 立ち止まれ。"], eG);
      await K.end(p, { leave: [eM], bye: [eG], card: "§7→ もう 一度（谷の 割れ目で 立ち止まろう）" });
      return true;
    } },
  { id: "u06e4", pv: 127, t: "三度目の 型", place: C4, fac: "u_crack4", battles: 1,
    hint: "§fアルカトラス地方の §e谷の 割れ目§f で、型の 残像と 戦おう",
    syn: "三度目で 型が 決まった。熱い 一撃が、刀神の 型の 残像を 払った。",
    async run(p, d, K) {
      fac(K, p, "u_crack4", "u_valley", 0, UA.Y(K, p));
      await K.open(p, "谷の 割れ目", "day");
      const eM = UA.mu(K, p, true);
      K.act(eM, "raise"); await K.wait(6); K.act(eM, "knocked"); await K.wait(8); K.act(eM, 0);
      await K.say(p, "ムサシ", ["{sweat}……二度目。", "{angry,up}三度目だ。右足から。……見てろ！"], null);
      await UA.en(K, p, ["{rage,low}§4……踏みこみ、ひねり、斬り上げ。……三つで 一つだ。"], null);
      await K.say(p, "ムサシ", ["{closed}……どん、ぎゅっ、しゅば。……どん、ぎゅっ、しゅば。"], null);
      await K.narr(p, ["§7谷の 底に、刀神の 残像が もう 一度 立った。§8……型を 待って いる。"], null);
      K.act(eM, "guard"); K.sound(p, "mrpg.slash", 1);
      const r = await K.battle(p, [{ sid: "god30", lv: 92, q: 1, plus: 40 }], { name: "刀神の 型の 残像", arena: "谷の 割れ目", theme: "ruins", speaker: "残像", guests: [{ sid: "musashi", lv: 85, q: 1, plus: 12, owner: "ムサシ" }], hpk: 0.7, lines: { half: "……ミギアシ……", low: "……ミゴト……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……まだ 足が ついて こねえ。", K.RT(p)], null); await K.end(p, { bye: [eM] }); return false; }
      K.act(eM, "pump"); await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{smile,☆}……決まった。", "{smile}今の、刃が 鳴った。斬った 音じゃ ねえ、決まった 音だ。"], null);
      await UA.en(K, p, ["{closed,low}§4……三度で 決めたか。……悪くない。"], null);
      await K.say(p, "ムサシ", ["{shock,!}……今、褒めたか？ エンマが？"], null);
      await UA.en(K, p, ["{closed,low}§4……型が 鳴った。それを 言った だけだ。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{smile,汗}……素直じゃ ねえな。", "{closed}けど、手の ひらが まだ 熱い。親父の 工房の 鉄と、同じ 熱さだ。"], null);
      K.pay(p, this, 2500, [["c_fruit", 3]]);
      await K.say(p, "ムサシ", ["{?}……次で 最後か。王冠の 割れ目、ルミナの 外れだったな。", "{closed}行こう。……お前の 足も、もう そっちを 向いてる。"], null);
      await K.end(p, { leave: [eM], card: "§7→ 最後の 斬り跡、王冠の 割れ目へ（ルミナの 外れ）" });
      return true;
    } },
  { id: "u06e5", pv: 127, t: "歓声の 底", place: C5, fac: "u_crack5", battles: 0,
    hint: "§fルミナの 外れの §e王冠の 割れ目§f へ 行こう §7（斬り跡 5）",
    syn: "王冠の 割れ目。王の 影の 残像。割れ目の 底から、闘技場の 歓声が かすかに 聞こえた。",
    async run(p, d, K) {
      const Q = fac(K, p, "u_crack5", "u_crowncrack", 0, UA.Y(K, p)), cq = facMark("u_crack5", "crack", p.location);
      await K.open(p, "王冠の 割れ目", "dusk");
      if (cq) await K.push(p, cq, 24, 6, 0.2);
      K.sound(p, "random.levelup", 0.08); K.sound(p, "mob.villager.yes", 0.15);
      await K.narr(p, ["§7深い 割れ目。§8底から、§f闘技場の 歓声§8 が かすかに 上って くる。"], cq);
      const eM = UA.mu(K, p, true);
      await UA.ear(K, p, eM, cq);
      await K.say(p, "ムサシ", ["{shock}……闘技場だ。この 下は、ルミナの 闘技場の 下に つながってる。", "{closed}細え 道だ。……風が、ささやいてる。"], null);
      await K.say(p, "ムサシ", ["{?}……エンマ。ここも、お前の 斬り跡か。"], cq);
      await UA.en(K, p, ["{rage,low}§4……ここが、最後の 斬り跡だ。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{?}ささやきって、何を 言ってんだ。……俺には、言葉に 聞こえねえ。"], null);
      await UA.en(K, p, ["{closed,low}§4……聞くな。耳を 貸すと、底へ 引かれる。"], null);
      const eS = ghost(K, p, cq ? { x: cq.x + 1, y: cq.y + 1, z: cq.z } : null, "§8王の 影の 残像", K.PJ("c7_valgreid", 8));
      await K.up(p, eS, 10);
      await K.narr(p, ["§8冠を かぶった 影が、割れ目の 上に 立った。§7口は 動いて いるのに、言葉に ならない。"], eS);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{shock}……冠の 影だ。", "{closed,…}一つ、二つ、三つ。……一つ 休む。"], eS);
      await K.say(p, "ムサシ", ["{sweat,汗}……こっちを 見てる。口が、何か 言いたがってる 形だ。"], eS);
      await UA.en(K, p, ["{rage,low}§4……王の 影の 残像だ。言葉は、もう 残って おらぬ。"], eS);
      await K.say(p, "ムサシ", ["{angry}……来るなら 来い。けど 今は、足が 冷えてる。", "{closed}一度 引いて、息を 整える。……すぐ 戻るぞ。"], null);
      await K.end(p, { leave: [eM], bye: [eS], kind: "dusk", card: "§7→ 影が 襲って くる（割れ目で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u06e6", pv: 127, t: "斬ったのは ささやき", place: C5, fac: "u_crack5", ans: ["qu041"], battles: 1,
    hint: "§fルミナの 外れの §e王冠の 割れ目§f で、影の 残像と 戦おう",
    syn: "王の 影の 残像と 戦った。消えた あと、割れ目の 奥に 石の 階段。エンマが 千年前に 斬ったのは、王冠から 漏れた ささやきだった。",
    async run(p, d, K) {
      fac(K, p, "u_crack5", "u_crowncrack", 0, UA.Y(K, p)); const sq = facMark("u_crack5", "stairs", p.location);
      await K.open(p, "王冠の 割れ目", "dusk");
      const eM = UA.mu(K, p, true);
      await K.say(p, "ムサシ", ["{angry,!}来るぞ！ ……声が でけえ。耳を ふさげ！"], null);
      await UA.en(K, p, ["{rage,low}§4……小僧、声を 聞くな。刃の 音だけ 聞け。"], null);
      await K.say(p, "ムサシ", ["{closed}……刃の 音だけ。……わかった。"], null);
      const r = await K.battle(p, K.team(["nether", "dragon", "nether"], 94, 3, 54), { name: "王の 影の 残像", arena: "王冠の 割れ目", theme: "underworld", speaker: "影", lines: { half: "……シッテ……ホシイ……", low: "……カナエヨ……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……ささやきが 耳に 入る。一度 離れる。", K.RT(p)], null); await K.end(p, { bye: [eM] }); return false; }
      await UA.en(K, p, ["{rage,low}§4……これだ。千年前、われが 斬ったのは。", "§4王冠から 漏れる、ささやき。……聞いた 者に、知りたいと 思わせる 声だ。"], null);
      await K.say(p, "ムサシ", ["{closed}……斬ったのは 人じゃ ねえ。声だったのか。"], null);
      await UA.en(K, p, ["{closed,low}§4……人は 斬って おらぬ。漏れた 声だけを、千年前に 断った。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{?}……じゃあ なんで みんな、お前を 狂った 王って 呼ぶんだ。"], null);
      await UA.en(K, p, ["{closed,low}§4……斬った ものが、見えぬ からだ。見えぬ ものを 斬る 者は、狂って 見える。"], null);
      await K.say(p, "ムサシ", ["{sad,…}……音なら、俺にも 聞こえた。お前は 狂ってねえ。"], null);
      if (sq) { K.sound(p, "dig.stone", 0.7); await K.push(p, sq, 22, 5, 0.2); }
      await K.narr(p, ["§7影が 消えると、割れ目の 奥に §f石の 階段§7 が 見えた。§8下へ、下へ。"], sq);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{shock,…}……階段だ。下から、冷てえ 風が 上って くる。", "{?}ここを 下りたら、何が ある。"], sq);
      await UA.en(K, p, ["{closed,low}§4……上で 話す。まず、階段の 上へ。"], null);
      K.pay(p, this, 3000, [["c_fruit", 3]]);
      await K.end(p, { leave: [eM], kind: "dusk", card: "§7→ 階段の 上へ" });
      return true;
    } },
  { id: "u06e7", pv: 127, t: "わが 座", place: C5, fac: "u_crack5", battles: 0,
    hint: "§fルミナの 外れの §e王冠の 割れ目§f の 階段の 上",
    syn: "階段の 上で、エンマが 言った。「この 先が、わが 座」。",
    async run(p, d, K) {
      fac(K, p, "u_crack5", "u_crowncrack", 0, UA.Y(K, p)); const sq = facMark("u_crack5", "stairs", p.location), tq = facMark("u_crack5", "top", p.location);
      await K.open(p, "王冠の 割れ目の 階段", "dusk");
      const eM = UA.mu(K, p, true);
      if (tq) await K.walkCam(p, eM, tq, 18);
      if (sq) await K.at(p, sq, 14, 4, 0.4);
      await K.narr(p, ["§7石の 階段の 上。§8下から、古い 紙の 匂いが 上って くる。"], sq);
      await UA.en(K, p, ["{rage,low}§4……この 先が、わが 座。"], sq ? null : eM);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{shock}……座？ 座ってのは、王さまの 椅子か。"], null);
      await UA.en(K, p, ["{closed,low}§4……帳の 王の 座だ。千年、空けて ある。"], null);
      await K.say(p, "ムサシ", ["{closed}……一つ、二つ、三つ。", "{sweat}……足が 震えてる。数えると、少し 止まる。"], null);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}……体が 勝手に 下りたがってる。", "{angry}待て、エンマ。今夜は 宿だ。……朝に 行く。お前の 座でも、夜中に 押しかけるのは 失礼だろ。"], null);
      await UA.en(K, p, ["{rage,low}§4……千年 待った。一夜くらい、待てる。"], null);
      await K.say(p, "ムサシ", ["{smile}……そう 言うと 思った。", "{closed}ポカラの 宿だ。……お前も、腹 減ってる 顔だな。"], null);
      await UA.en(K, p, ["{closed,low}§4……小僧。……礼は、言わぬ。"], null);
      await K.say(p, "ムサシ", ["{smile}いらねえよ。言われたら、槌で 叩いて 確かめる。"], null);
      await K.narr(p, ["§7階段に 背を 向けると、§8下の 闇が 一度だけ、小さく 鳴った。"], sq);
      await K.end(p, { leave: [eM], kind: "dusk", card: "§7→ ポカラの 宿で 夜を 明かそう" });
      return true;
    } },
  { id: "u06e8", t: "朝に 神殿へ", place: PINN, battles: 0,
    hint: "§fひだまりの 村 §eポカラの 宿§f で 休もう",
    syn: "ポカラの 宿の 夜。次の 朝、閻魔の 神殿へ 行く。",
    async run(p, d, K) {
      await K.open(p, "ポカラの 宿（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      await K.up(p, eM, 10);
      await K.narr(p, ["§7ポカラの 宿の 夜。§8窓の 外で、虫が 鳴いて いる。"], eM);
      await K.say(p, "ムサシ", ["{closed}……一つ、二つ、三つ。", "{smile}明日、王さまの 座だ。……斬りに じゃ ねえ。話を 聞きに。"], null);
      await UA.en(K, p, ["{closed,low}§4……千年ぶりだ。……話を 聞きに 来る 者は、その 千年、一人も いなかった。"], null);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{closed,low}§4……小僧。明日、帳を 見ても、驚くな。"], null);
      await K.say(p, "ムサシ", ["{closed}……驚くか どうかは、見てから 決める。", "{smile}字は 読めねえから、お前が 読め。俺は 音を 聞く。"], null);
      await UA.en(K, p, ["{closed,low}§4……それで よい。"], null);
      await K.say(p, "ムサシ", ["{smile}……お前も 寝ろ。明日は 早え。", "{closed}……目が もう、半分 閉じてるぞ。"], null);
      await K.night(p, eM ? eM.location : null, "§8ムサシは 鍔に 手のひらを 当てた まま、眠った。", "§7朝。", []);
      await UA.zeph(K, p);
      if (!tokoyoOn()) {
        await K.narr(p, ["§d続きは 追加ストーリー「常世編」で。", "§7（常世パックを 入れると、閻魔の 神殿へ 進める。それまで ヒロインの 石は 眠った まま）"], eM);
        await K.end(p, { leave: [eM], card: "§d続きは 追加ストーリー" });
      } else await K.end(p, { leave: [eM], card: "§7→ 閻魔の 神殿へ（右上の 案内）" });
      return true;
    } },
]);
