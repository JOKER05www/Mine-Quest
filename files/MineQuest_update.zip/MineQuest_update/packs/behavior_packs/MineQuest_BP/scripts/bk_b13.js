/* 第126版 本13「竜祭り」（終焉の地ラグナ・エンド／竜骨の門）— 作業 MD
   1 見晴らし台（シズク・オルドとハク）→ 2 竜祭り（名を灯籠に三度・座の紙を返す・手帳の白紙）→ 3 夜更け（「ずっと、こうして」・灯りが一つ消える）
   → 4 祭壇への道（守り手・オルドの紐）→ 5 竜骨の門（ガロ C01/C06・眠るピコをオルドがルミナへ）→ 6 門の内側（ベリル戦）→ 7 手当て（ベリルが自分で名を書く）
   → 8 骨の階段（上に双子を抱えた仮面の戦士・赤い外套・セオの影）→ 9 階段の途中（夜明けまでに道が閉じる）
   引きとった古い話: r9e1→b13e1・r9e2→b13e2・r9e3→b13e4（EP_OFF は bkAdd が OLD2NEW で入れる）。MQ21（b13e5〜b14e8）の mqOver は bk_b14.js
   ラグナ（本13〜15）で 使う 場所・人・セット・墓標の 道具を ここに まとめ、bk_b14／bk_b15 が import する */
import { bkAdd } from "./bkeng.js";
import { castAdd, doomKnown } from "./cast.js";
import { facAdd, FAC_OPS, facFront, facMark } from "./epfac.js";
import { farOf as farOf127 } from "./storyplace.js";
import { townOut, placeOf, bldOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, groundY, caveInfo } from "./structures.js";
import { world } from "@minecraft/server";
import { ok } from "./ui.js";
import { SPECIES, ORDER } from "./data.js";
import { regionIdx } from "./worldmap.js";
import { heroType } from "./saga.js";

const { F, S1 } = FAC_OPS;
/* ---------- セット（1回だけ建てる。どれも 400 ブロック まで）---------- */
/* 竜骨の門（アジトが まだ できて いない 世界だけ）: 骨の 柱と 梁・紫の 灯・奥の 寝床 */
facAdd("bonegate", { D: [10, 12, 9], box: [-1, -4, 7, 4], H: 8, look: [2, 0, 3], marks: { gate: [2, 0, 0], inside: [5, 0, 0], bed: [6, 3, 0], front: [-1, 0, 0] }, build: () => [
  F(0, -1, -1, 6, 1, -1, "end_stone_bricks"), F(2, -3, 0, 3, -3, 5, "bone_block"), F(2, 3, 0, 3, 3, 5, "bone_block"), F(2, -3, 6, 3, 3, 6, "bone_block"), S1(2, -2, 5, "bone_block"), S1(2, 2, 5, "bone_block"),
  S1(3, 0, 7, "crying_obsidian"), S1(1, -4, 0, "dark_oak_fence"), S1(1, -4, 1, "soul_lantern"), S1(1, 4, 0, "dark_oak_fence"), S1(1, 4, 1, "soul_lantern"),
  F(6, 2, 0, 6, 4, 0, "white_carpet"), S1(7, 3, 0, "hay_block"), S1(5, -3, 0, "barrel"),
] });
/* 祭壇へ 続く 骨の 階段（六段・両わきに 紫の 灯）*/
facAdd("bonestair", { D: [9, 11, 8], box: [-1, -3, 8, 3], H: 9, look: [4, 0, 3], marks: { foot: [0, 0, 0], mid: [3, 0, 3], top: [6, 0, 6] }, build: () => [
  F(1, -1, 0, 1, 1, 0, "bone_block"), F(2, -1, 0, 2, 1, 1, "bone_block"), F(3, -1, 0, 3, 1, 2, "bone_block"), F(4, -1, 0, 4, 1, 3, "bone_block"), F(5, -1, 0, 5, 1, 4, "bone_block"), F(6, -1, 0, 6, 1, 5, "bone_block"),
  F(1, -2, 0, 6, -2, 0, "end_stone_bricks"), F(1, 2, 0, 6, 2, 0, "end_stone_bricks"), S1(2, -2, 1, "soul_lantern"), S1(5, 2, 1, "soul_lantern"), F(7, -2, 5, 7, 2, 8, "bone_block"),
] });
/* 竜骨の 祭壇（洞くつの 広間が ない 世界だけ）: 紫の 壇・五つの 形の くぼみ・床の 丸い くぼみ・骨の 背 */
facAdd("keyaltar", { D: [10, 12, 9], box: [-1, -4, 7, 4], H: 6, look: [3, 0, 1.4], marks: { altar: [3, 0, 0], round: [1, 0, 0], back: [5, 0, 0], left: [2, -3, 0], right: [2, 3, 0] }, build: () => [
  F(2, -3, -1, 5, 3, -1, "purpur_block"), F(6, -3, 0, 6, 3, 4, "bone_block"), S1(6, 0, 5, "crying_obsidian"),
  S1(3, -2, -1, "polished_blackstone"), S1(3, -1, -1, "gilded_blackstone"), S1(3, 1, -1, "chiseled_polished_blackstone"), S1(3, 2, -1, "crying_obsidian"), S1(4, 0, -1, "obsidian"),
  F(0, -1, -1, 1, 1, -1, "end_stone_bricks"), S1(1, 0, -1, "chiseled_quartz_block"),
  S1(1, -4, 0, "dark_oak_fence"), S1(1, -4, 1, "soul_lantern"), S1(1, 4, 0, "dark_oak_fence"), S1(1, 4, 1, "soul_lantern"),
] });

/* ---------- 場所 ---------- */
export const endC = () => { const t = TOWNS.find((u) => u.id === "t27"); if (!t) return null; const g = getTown("t27"); return g && g.built ? { x: g.x, y: g.y, z: g.z } : townPos(t); };
export const LOOK = (nm = "エンドの 竜の 見晴らし台") => { const f = farOf127("r9look", "t27", nm, 90, 260); if (f) return f; const o = townOut("t27", 0, "竜の 見晴らし台"); return o ? { x: o.x, z: o.z, nm } : null; };   /* 第127版(fac2): 町の 外れ 56 → 離れた 岬の 丘 */
const FESTR = (nm = "さいはての 村 エンドの 広場（竜祭り）") => bldOf("t27", ["plaza", "inn"], nm) || (() => { const o = townOut("t27", -0.9, "竜祭りの 広場") || townOut("t27", 0.9, "竜祭りの 広場"); return o ? { x: o.x, z: o.z, nm } : null; })();
export const ROAD = () => {
  const a = endC(), b = placeOf("stage", 9); if (!a || !b) { const r = placeOf("road", 9); return r ? { x: r.x, z: r.z, nm: "竜骨の 祭壇への 道" } : null; }
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  for (const f of [0.6, 0.5, 0.7, 0.4]) { const x = Math.floor(a.x + (b.x - a.x) * f), z = Math.floor(a.z + (b.z - a.z) * f); if (regionIdx(x - s0.x, z - s0.z) === 9) return { x, z, nm: "竜骨の 祭壇への 道" }; }
  return { x: Math.floor((a.x + b.x) / 2), z: Math.floor((a.z + b.z) / 2), nm: "竜骨の 祭壇への 道" };
};

/* ---------- 人・小道具（本13〜15 共通）---------- */
export const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
export const REI = (K, p, w = false) => K.npcNear(p, "§bレイ", 17, w);
export const ORDO = (K, p, w = false) => K.npcNear(p, "§eオルド", K.PJ("ordo", 8), w);
export const HAKU = () => (SPECIES.hbea14 ? "hbea14" : SPECIES.hbea01 ? "hbea01" : ORDER[0]);
export const DRAG = () => (SPECIES.hdra12 ? "hdra12" : ORDER.find((x) => SPECIES[x].fam === "dragon" && SPECIES[x].sz === "L" && !SPECIES[x].hidden) || HAKU());
export const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
export const HNm = (K, p) => { try { return K.HN(p); } catch { return "旅の 仲間"; } };
export const won = (K, p, k) => { try { const d = K.load(p); return !!(d && (K.qs(d)[k] || (K.qs(d).epx || {})[k])); } catch { return false; } };
export const ctr = (K, p) => { const S = K.S(p); return S ? { x: S.P.x, y: S.P.y, z: S.P.z } : { x: p.location.x, y: p.location.y, z: p.location.z }; };
/* 石に なる（足もとから 灰色に。名札を かえる）*/
export async function stoneFx(K, p, e, nm) {
  if (!ok(e)) return; K.sound(p, "dig.stone", 0.6);
  for (let k = 0; k < 6; k++) { if (!ok(e)) return; K.burst(p.dimension, e.location, k % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.6, k * 0.35); await K.wait(4); }
  K.sound(p, "dig.stone", 0.8); try { e.setProperty("mrpg:mv", false); } catch {} if (nm) try { e.nameTag = nm; } catch {}
}
/* 石に なった 幼なじみ（体だけ。暗転の 中で 立たせる。歩かない）*/
export async function heroStone(K, p, q, look = null) {
  const d = K.load(p), key = d && K.qs(d).hero; const e = await K.put(p, `§7石の ${HNm(K, p)}`, q, look, K.PJ(key || "hero_rio", 9));
  try { if (ok(e)) e.setProperty("mrpg:mv", false); } catch {} K.act(e, "up"); return e;
}
/* 竜の 鱗の 墓標（ワールドに 1回。見晴らし台の 横）。場所は mrpg:epdeco:r9graveat（前の 版と 同じ）*/
export const graveAt = (p) => { try { const A = JSON.parse(world.getDynamicProperty("mrpg:epdeco:r9graveat") || "null"); if (A && typeof A.x === "number" && Math.hypot(A.x - p.location.x, A.z - p.location.z) < 40) return A; } catch {} return null; };
export async function grave(K, p, q) {
  if (!q) return; let v = 0; try { v = Number(world.getDynamicProperty("mrpg:epdeco:r9grave") || 0); } catch {}
  let y = null; try { y = groundY(p.dimension, Math.floor(q.x), Math.floor(q.z), Math.floor(q.y) + 4); } catch {}
  if (typeof y !== "number" || Math.abs(y - q.y) > 4) y = Math.floor(q.y);
  const x = Math.floor(q.x), z = Math.floor(q.z), put = (dx, dy, dz, b) => K.cmd(p, `setblock ${x + dx} ${y + dy} ${z + dz} ${b} keep`);
  if (!v) try { world.setDynamicProperty("mrpg:epdeco:r9graveat", JSON.stringify({ x: x + 0.5, y, z: z + 0.5 })); } catch {}
  const steps = [[0, 0, 0, "polished_deepslate"], [0, 1, 0, "prismarine"], [0, 2, 0, "prismarine"], [0, 3, 0, "end_rod"], [1, 0, 0, "lily_of_the_valley"], [-1, 0, 0, "cornflower"], [0, 0, 1, "poppy"], [0, 0, -1, "lily_of_the_valley"]];
  for (const [k, [dx, dy, dz, b]] of steps.entries()) { if (!v) put(dx, dy, dz, b); K.burst(p.dimension, { x: x + 0.5 + dx, y: y + dy, z: z + 0.5 + dz }, "minecraft:villager_happy", 3, 0.4, 0.4); if (k === 0 || k === steps.length - 1) K.sound(p, dy ? "dig.stone" : "dig.grass", 0.8); await K.wait(5); }
  try { world.setDynamicProperty("mrpg:epdeco:r9grave", 1); } catch {}
}
/* 墓標が まだ ない 世界（見のがした 頁・移し替えた セーブ）: 演出なしで 置く */
export function graveQuick(K, p, q) { if (!q || graveAt(p)) return; let y = null; try { y = groundY(p.dimension, Math.floor(q.x), Math.floor(q.z), Math.floor(q.y) + 4); } catch {} if (typeof y !== "number" || Math.abs(y - q.y) > 4) y = Math.floor(q.y); const x = Math.floor(q.x), z = Math.floor(q.z); for (const [dx, dy, dz, b] of [[0, 0, 0, "polished_deepslate"], [0, 1, 0, "prismarine"], [0, 2, 0, "prismarine"], [0, 3, 0, "end_rod"], [1, 0, 0, "lily_of_the_valley"], [-1, 0, 0, "cornflower"]]) K.cmd(p, `setblock ${x + dx} ${y + dy} ${z + dz} ${b} keep`); try { world.setDynamicProperty("mrpg:epdeco:r9graveat", JSON.stringify({ x: x + 0.5, y, z: z + 0.5 })); world.setDynamicProperty("mrpg:epdeco:r9grave", 1); } catch {} }
/* 見晴らし台の 前（台の 中へ 歩きこまない）*/
export function lookFront(K, p, FQ) { const FF = FQ && facFront("r9look", 1.6); if (!FF) return null; const dx = FF.x - FQ.x, dz = FF.z - FQ.z, n = Math.hypot(dx, dz) || 1; return (s) => ({ x: FF.x - (dz / n) * s, y: Y(K, p), z: FF.z + (dx / n) * s }); }
/* 墓標の 場所（なければ 台の 横）*/
export function graveSpot(K, p) { const A = graveAt(p); if (A) return A; const S = K.S(p); return S ? S.at(5.5, -2.6, 0) : K.fwd(p, 5.5, -2.6); }
/* 洞くつ（六影 本拠地）の 広間 */
export const hall9 = () => { const v = caveInfo(9); return v && v.built && v.hall ? v : null; };
export const sixT = (K, p, key, nm, d = 9, w = false) => K.npcNear(p, nm, K.PJ(key, d), w);

/* ---------- 町の 人の その後 ---------- */
const st = (s) => s.epx || {};
castAdd("shizuku", { nm: "シズク", role: "竜の 巫女", gobi: "ございます", skin: "sakuya", town: "t27", from: "r9e1",
  at: () => { const c = endC(); return c ? { x: c.x - 9, y: c.y, z: c.z + 9 } : null; },
  pre: ["{smile}竜の 村 エンドへ ようこそ おいで くださいました。"],
  after: [
    [(s) => !!s.ending, ["{smile}鱗の 墓標の 横の あの方を、今朝も 竜と いっしょに みがいて おります。", "{closed}……名前は、竜が 千年 守ります。迎えに 来られる 日まで。"]],
    [(s) => doomKnown(s), ["{closed}灰が 降っても、墓標の 鱗は くもりません。……毎朝 みがいて おります。", "{sad}村の 人の 名前も、竜に 覚えて もらって おります。一人も、忘れさせは いたしません。"]],
    [(s) => !!st(s).grave9 && (s.mq ?? 0) >= 23, ["{smile}あの方の 石と 墓標は、わたくしが お預かり して おります。", "{closed}レイさまの 竜の 名も、毎朝 三度ずつ 呼んで おります。"]],
    [(s) => !!st(s).grave9, ["{smile}あの方の 名前は、竜が 覚えて おります。……あなたさまも、どうか 忘れないで くださいませ。"]],
    [(s) => !!s.heroDead, ["{sad}……祭壇の ことは、竜が 教えて くれました。見晴らし台で お待ちして おります。"]],
    [(s) => !!st(s).fest9, ["{smile}竜祭りの 灯籠は、今も 空の どこかを ただよって おりましょう。"]],
    [() => true, ["{smile}竜祭りの 灯りは、竜の 背骨の 数だけ ともすので ございます。"]],
  ] });
castAdd("endkid", { nm: "トキワ", role: "灯籠売りの 子", gobi: "", skin: "c7_tokiwa", town: "t27", from: "r9e2",
  at: () => { const c = endC(); return c ? { x: c.x + 6, y: c.y, z: c.z - 7 } : null; },
  pre: ["{smile}竜祭りの 灯籠、いかが？ 名前を 書いて 飛ばすんだよ。"],
  after: [
    [(s) => !!s.ending, ["{smile}今年の 灯籠で いちばん 高く とんだのは、あの お姉ちゃんの 名前だったよ。……村の みんなで 三回 呼んだから。"]],
    [(s) => !!s.heroDead, ["{sad}……あの お姉ちゃんの 灯籠、ぼく まだ 一つ 持ってる。", "{closed}次の 竜祭りで、いっしょに 飛ばそうね。"]],
    [() => true, ["{smile}灯籠は、三回 名前を 呼んでから 手を はなすんだよ。そしたら 迷わないって。"]],
  ] });

/* ---------- 1話 見晴らし台 ---------- */
const E1 = { id: "b13e1", pv: 127, t: "さいはての 村", place: () => LOOK(), fac: "r9look",
  hint: "§fラグナの §eさいはての 村 エンド§f の 外れ（竜の 見晴らし台）へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "竜を まつる さいはての 村 エンドで、竜の 巫女 シズクに 会った。「四十年前、十の とき、二人の 若い 方が ここで 一晩じゅう 竜骨を 見て おられました」。そこへ オルドが ハクに 乗って 追いついた。シズクの 言う 二人の 片方は、オルドだった。祭壇への 道は、竜祭りの 夜にしか 開かない。",
  F: ["F09", "F10"], set: { met9: 1 }, battles: 0,
  async run(p, d, K) {
    const FQ = K.fac(p, "r9look", "lookout", 9, Y(K, p));
    await K.open(p, "エンドの 竜の 見晴らし台", "day");
    K.sound(p, "mob.enderdragon.growl", 0.3);
    if (FQ) await K.at(p, FQ, 12, 7, 1.5);
    const eH = K.hero(p), eR = REI(K, p);
    const S = K.S(p), far = S ? S.at(26, -6, 10) : K.fwd(p, 20, -6, 10), FS = lookFront(K, p, FQ);
    if (ok(eR) && FS) { await K.walkCam(p, eR, FS(-1.3), 18); K.turn(eR, far); }
    if (ok(eH) && FS) K.go(eH, FS(1.3), 16);
    await K.at(p, far, 18, 12, 0);
    await K.narr(p, ["§7地平線の 向こうに、山より 大きな 竜の 骨が 横たわって いた。", "§7白い 背骨が、雲の 下まで 続いて いる。"], far);
    await K.hsay(p, K.V(["{shock,!,up}うわあ……！ あれ、ぜんぶ 骨！？ 地図に 描ききれないよ！"], ["{shock,…,up}……大きい。あれが 竜の 骨なのね。"], ["{shock,…}……でかい。地図の 縮尺が 足りない。"], ["{shock,!,up}なんて 大きな……！ 地図の 紙が 足りません……！"]));
    K.act(eR, "hold");
    await K.say(p, "レイ", ["{closed}双子の 隠れ家の 暦に、丸が ついてた。竜祭りの 夜。……祭壇は、あの 骨の 根もとだ。"], eH);
    K.turn(eR);
    const eS = K.cast(p, "shizuku"); K.act(eS, "hold"); K.hold(eS, "bell");
    await K.csay(p, "shizuku", ["{smile}ようこそ、さいはての 村 エンドへ。わたくしは 竜の 巫女、シズクで ございます。", "{closed}竜が 朝から 落ちつかぬ ようすで ございましたので……お客さまが 来られると 思って おりました。"]);
    await K.hsay(p, K.V(["{smile,♪}竜の 巫女さん！ ……竜の 声が わかるの？"], ["{smile}竜の 巫女さん……竜の 声が、聞こえるの？"], ["{?}……竜の 声が、聞こえるのか。"], ["{smile}竜の 巫女さま……竜の お声が、聞こえるのですか？"]));
    K.act(eS, "point"); if (ok(eS)) K.turn(eS, far);
    await K.csay(p, "shizuku", ["{smile,nod}竜の 言葉だけで ございます。人の 心は、わたくしにも わかりませぬ。", "{closed,up}あの 竜骨は、一年に 一度、竜祭りの 夜にだけ、祭壇への 道を 開きます。"], eH);
    K.turn(eS);
    await K.ots(p, eS, eH, 8);
    await K.csay(p, "shizuku", ["{smile,up}……四十年前、わたくしが 十の とき。二人の 若い 方が、ここで 一晩じゅう 竜骨を 見て おられました。", "{closed}一人は 背の 高い、星の 話ばかり なさる 方。もう 一人は……白い 大きな 獣を 連れて おられました。"], eH);
    await K.flashback(p, { set: "fb_dragonlook", label: "§7―― 四十年前　竜の 見晴らし台", tod: "night", ptc: "night",   /* 第127版: シズクが 見た 二人を 絵で */
      actors: { z: { nm: "§6背の 高い 若者", job: K.PJ("zephard", 8), at: [3.4, 0.9], look: [12, 0] }, o: { nm: "§e白い 獣を 連れた 若者", job: K.PJ("m6_brother", 8), at: [3.2, -1], look: "z" }, s: { nm: "§7十の シズク", job: 6, at: [1.2, 2.2], look: "z" } },
      beats: [
        ["narr", "§7四十年前の 夜。見晴らし台の 端で、若い 二人が 竜骨を 見つめて いた。", "z"],
        ["act", "z", "point"],
        ["say", "z", "{smile,up}見ろ。竜骨の 祭壇の 上の 星だ。……あの 骨の 奥に、ひびが ある。", "o"],
        ["say", "o", "{closed}……ひび？ 骨に か。", "z"],
        ["say", "z", "{closed}いや。もっと 深い ものに だ。……一晩 見て いれば 分かる。", "o"],
        ["act", "z", 0],
        ["say", "s", "{?,up}……お兄さんたち、竜の 言葉が 分かるの？", "o"],
        ["say", "o", "{smile}分からん。こいつは 星の 話しか せん。……わしの 相棒の ほうが、まだ 話が 通じる。", "s"],
        ["narr", "§7二人は 朝まで、竜骨から 目を はなさなかった。", [8, 0, 3]],
      ] });
    await K.hsay(p, K.V(["{?,up}白い 大きな 獣……？ ……それって――"], ["{?,up}白くて 大きな……？"], ["{?}……白い 獣。どこかで。"], ["{?,up}白い 大きな……？ もしかして……"]));
    /* オルドと ハク（遠くから 土けむりを 立てて かけて くる）*/
    K.sound(p, "mob.ravager.roar", 0.9); K.shake(p, 0.3, 0.5);
    const hq = K.fwd(p, 7, 3.5), hk = K.monEnt(p, K.fwd(p, 20, 9), HAKU(), "§fハク");
    if (hk) { const w = K.go(hk, hq, 22, true); await K.at(p, hq, 14, 9, 1.5); await w; K.burst(p.dimension, hk.location, "minecraft:white_smoke_particle", 8, 1.2, 0.2); await K.push(p, hk, 22, 4.2, 1.7); }
    const eO = ORDO(K, p); K.act(eO, "hold");
    await K.say(p, "オルド", ["{smile,息}……ほっほ。間に 合ったわい。竜祭りに 行くと、手紙に 書いた じゃろう。"]);
    await K.hsay(p, K.V(["{shock,!,up}村長！？ 腰、痛いって 言ってたのに！？"], ["{shock,up}村長さん！ ……あんなに 遠かったのに。"], ["{shock,!}……村長。息切れは。"], ["{shock,!,up}村長さま！？ お体は……！"]), eO);
    await K.say(p, "オルド", ["{smile}ハクに 乗って 来たんじゃ。……わしの 足は、とっくに こやつの 足じゃよ。"], eH);
    await K.say(p, "レイ", ["{?}……じいちゃん。なんで 祭りの 日まで 知ってんだよ。"], eO);
    K.act(eS, 0); K.re(eS, "shock", "!");
    await K.up(p, eS, 12);
    await K.csay(p, "shizuku", ["{shock,…,up}……その 獣。……オルドさま？ まあ……四十年前の、お二人の――"]);
    K.act(eO, "point"); if (ok(eO)) K.turn(eO, far);   /* 竜骨の 方へ 背を 向けて さえぎる */
    await K.say(p, "オルド", ["{closed,low}……シズク。その 話は、ええ。……昔、ちょっとな。"]);   /*F09*/
    await K.csay(p, "shizuku", ["{sad,nod}……失礼 いたしました。"], eO);
    await K.say(p, "レイ", ["{angry,up}……また それかよ。『昔、ちょっと』。……もう 一人は だれだ。"], eO);
    K.act(eO, 0); K.turn(eO);
    await K.say(p, "オルド", ["{closed}……星の 好きな 男じゃった。生まれたばかりの 娘に、紐を 編んで やる 男じゃ。", "{sad}……今夜は 祭りじゃろう。湿っぽい 話は、竜も 好かん。"], eR);   /*F10*/
    await K.hsay(p, K.V(["{?}……（紐を 編む 人。……マリノアで 見た 紐の 話と、同じ？）"], ["{?}……（紐……。手帳に 書いた 気が する）"], ["{?}……（紐。手帳の マリノアの 頁）"], ["{?}……（紐を 編む お方……手帳に 何か ございました ような）"]));
    await K.csay(p, "shizuku", ["{smile,up}今夜は 竜祭りで ございます。村の 広場に、竜の 背骨の 数だけ 灯りを ともします。", "{smile}どうか、皆さまも。……旅の 方の 名前も、竜に 覚えて もらいましょう。"], eH);
    K.pay(p, E1, 2000, [["c_herbs2", 2]]);
    await K.end(p, { leave: [eS, eO], bye: [eR], card: "§7― 竜祭りの 夜 ―\n§7→ エンドの §e広場§7 へ（右上の 案内）", kind: "day" });
    K.rmCine(hk);
    return true;
  } };

/* ---------- 2話 竜祭り（夜）---------- */
const MEM = [
  ["ルミナ", "{smile,♪,up}収穫祭の 約束、まだ 一つ 残ってる。……ミミちゃん、パン 焼いて 待ってるかな。", "{smile,up}ミミちゃんとの 約束、まだ 残ってるわ。", "{closed,up}ミミとの 約束。まだ 残ってる。", "{smile,up}ミミさんとの お約束、まだ 残って おります。"],
  ["シルヴァ", "{smile}ほたるの 里で、セオさん、ピピちゃんの 本を 一字も まちがえずに 書いて くれたよね。", "{sad}ほたるの 里で、セオさんが ピピちゃんの 本を 書きこんで くれたのよね。", "{closed}ほたるの 里。セオが、ピピの 本を 写した。", "{sad}ほたるの 里で、セオさまが ピピさんの 本を 書きこんで くださいましたね。"],
  ["マリノア", "{sad}ナギサさんの お守りの 紐。三つ目ごとに 一つ 返す、ふしぎな 編み方。", "{sad}ナギサさんの 紐……三つ目ごとに 一つ 返すの。", "{closed}ナギサの 紐。三つ目ごとに 一つ 返す。", "{sad}ナギサさまの 紐は、三つ目ごとに 一つ 返す 編み方でした。"],
  ["ネクロス", "{sad,…}灯籠流し……。セオさん、弟さんの 灯籠、流せなかったね。", "{sad}灯籠流し……セオさん、流せなかったわね。", "{sad}灯籠。セオは 流せなかった。", "{sad}灯籠流しで、セオさまは……"],
];
const E2 = { id: "b13e2", t: "竜祭り", place: () => FESTR(), snd: "item.book.page_turn",
  hint: "§fさいはての 村 §eエンドの 広場§f へ 行こう §7（今夜は 竜祭り。右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "竜祭りは、会いたい 人の 名前を 灯籠に 書いて、三度 呼んでから 空へ 飛ばす 祭り。旅の 仲間は 手帳の 最後の 頁を 見せた。「ここは 白紙。二人で 書こう」。広場の 端に いた ベリルに、仲間は 森で 拾って から 預かって いた 座の 紙を 返した。",
  F: ["F30", "F50", "F67"], set: { fest9: 1, met9: 1 }, battles: 0,
  skip: (s) => { s.epx = { ...(s.epx || {}), fest9: 1 }; },
  async run(p, d, K) {
    const c = ctr(K, p), y0 = Y(K, p);
    K.deco(p, "r9fest", 1, c, y0);
    await K.open(p, "エンドの 竜祭り（夜）", "night");
    K.sound(p, "note.harp", 0.6); K.ambient(p, "night", { x: c.x, y: y0, z: c.z });
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{smile,☆,jump}わあ……！ 灯りが、竜の 背骨みたいに ならんでる！"], ["{smile,♪}……きれい。灯りが、ずっと 向こうまで 続いてる。"], ["{smile}……灯りの 列。竜の 背骨の かたちだ。"], ["{smile,☆}まあ……灯りが、竜の 背骨の ように……！"]));
    const eS = K.cast(p, "shizuku"); K.act(eS, "raise"); K.hold(eS, "chochin");
    if (ok(eS) && ok(eH)) await K.approach(p, eS, eH, 1.8);
    await K.csay(p, "shizuku", ["{smile}竜祭りは、空へ 名前を 呼ぶ 祭りで ございます。会いたい 人、忘れたくない 人の 名前を 灯籠に 書いて……", "{closed,up}三度 呼んでから、手を はなします。三度 呼ばれた 名は、迷わないと 申します。"], eH);
    K.act(eS, 0);
    /* 村の 子が 名を 三度 呼んで 灯籠を 飛ばす */
    const eK = K.cast(p, "endkid"); K.act(eK, "raise"); K.hold(eK, "chochin");
    await K.say(p, "灯籠売りの 子 トキワ", ["{smile,up}おばあちゃん。……おばあちゃん。……おばあちゃん！"]);
    if (ok(eK)) { K.burst(p.dimension, eK.location, "minecraft:basic_flame_particle", 4, 0.3, 2.4); K.sound(p, "note.chime", 0.7); await K.at(p, { x: eK.location.x, y: eK.location.y + 5, z: eK.location.z }, 14, 4, 0); }
    K.act(eK, 0); K.hold(eK);
    await K.hsay(p, K.V(["{smile,♪,up}名前を 書いて 飛ばすの……？ じゃあ、わたしの 手帳の 出番だね！"], ["{smile,up}名前を……。じゃあ、わたしの 手帳が 役に 立つわね。"], ["{smile,up}名前なら、手帳に ある。"], ["{smile,up}お名前でしたら、わたしの 手帳に たくさん ございます。"]), eK);
    K.act(eH, "hold"); K.hold(eH, "notebook"); K.sound(p, "item.book.page_turn", 1);
    await K.push(p, eH, 22, 4.2, 1.7);
    await K.narr(p, ["§7旅の 仲間は 灯りの 下に 座って、すりきれた §f旅の 手帳§7 を 開いた。", "§7地図の 頁と、旅で 会った 人の 名前の 頁が、交互に 綴じて ある。"], eH);
    const ty = { g: 1, o: 2, c: 3, t: 4 }[heroType(p)] || 1;
    await K.narr(p, ["§7頁を めくる たびに、会った 人の 顔が 浮かぶ。"], eH);   /* 第128版: 回想の 札を 出さない（札だけで 昔の 絵が ない ため）*/   /* 第128版(lore): 「旅の はじまりの 朝」の 回想は 本1（旅立ちは 収穫祭）と 合わず、オルドの 台詞も 作り話なので やめた */
    for (const m of MEM) { await K.narr(p, [`§7― ${m[0]} の 頁 ―`], eH); await K.hsay(p, [m[ty]]); }
    const eR = REI(K, p); if (ok(eR) && ok(eH)) await K.approach(p, eR, eH, 2.2); K.act(eR, "hold");
    await K.say(p, "レイ", ["{?}……牢の 頁、オレの 名前に 丸が ついてるじゃ ねえか。", "{closed}……消すなよ。"]);
    await K.hsay(p, K.V(["{smile,♪}消さないよーだ。"], ["{smile}消さないわ。"], ["{smile}消さない。"], ["{smile}消しません。"]), eR);
    K.act(eR, 0);
    /* 最後の 頁 */
    K.sound(p, "item.book.page_turn", 0.9); await K.up(p, eH, 12);
    await K.narr(p, ["§7仲間は、手帳の 最後の 頁を めくって 見せた。……何も 書いて いない。"], eH);
    await K.hsay(p, K.V(["{smile,up}ここは 白紙。……旅の 最後に、二人で 書こう。約束！"], ["{smile,up}ここは 白紙の まま。……旅の 最後に、二人で 書きましょう。約束よ。"], ["{smile,up}ここは 白紙。旅の 最後に、二人で 書く。……約束。"], ["{smile,up}ここは 白紙の まま。……旅の 最後に、二人で 書きましょう。お約束です。"]));   /*F30*/
    await K.hsay(p, K.V(["{smile}地図を ぜんぶ 描きあげて、あなたと 相棒と もう一回 ぜんぶの 町を 回るの。……そしたら ここに 書くんだ。"], ["{smile}地図を 描きあげて、もう 一度 ぜんぶの 町を 回ったら……そこに 書くの。"], ["{closed}地図が 描けて、もう 一回 回ったら。そこに 書く。"], ["{smile}地図を 描きあげ、もう 一度 すべての 町を 回りましたら……そこに 書きます。"]), eR);
    K.act(eH, 0); K.hold(eH);
    /* ベリル（座の 紙を 返す）*/
    const eB = sixT(K, p, "beryl", "§5六影 ベリル"); K.act(eB, "hold");
    await K.low(p, eB, 12);
    await K.hsay(p, K.V(["{shock,!}……ベリルちゃん！"], ["{shock}……ベリルちゃん？"], ["{shock,!}……ベリル。"], ["{shock,!}ベリルさん……！"]), eB);
    await K.say(p, "ベリル", ["{closed}……戦いに 来たんじゃ ないの。灯籠の あいだは 休む 決まり。……夜更け、霧が 晴れたら、門の 前で。", "{sad}……祭りって、こういう ものなのね。一座に いた ころは、いつも 袖から 見て いたの。"]);
    K.hold(eH, "paper"); K.act(eH, "give"); if (ok(eH) && ok(eB)) await K.approach(p, eH, eB, 1.6); await K.ots(p, eB, eH, 8);
    await K.hsay(p, K.V(["{smile,up}これ、返すね。森で 拾ってから、ずっと 手帳に はさんでたの。"], ["{smile,up}これ……返すわね。森で 拾ってから、手帳に はさんで おいたの。"], ["{closed}返す。森で 拾った。ずっと はさんでた。"], ["{smile,up}お返し いたします。森で 拾ってから、ずっと 手帳に。"]), eB);   /*F50 強（返す）*/
    await K.give(eH, eB, "paper");
    K.act(eB, "hold"); K.hold(eB, "paper");
    await K.at(p, ok(eB) ? { x: eB.location.x, y: eB.location.y + 1.2, z: eB.location.z } : c, 12, 1.6, 0);
    await K.narr(p, ["§7座の 紙。六つの 行と、一つだけ 白紙の 行。"], eB);
    await K.say(p, "ベリル", ["{shock,…,up}……捨てられたと 思ってた。", "{sad}……ありがとう。座の わたしの 行は、まだ 白紙。……書く 場所は、門で 決める。"], eH);
    await K.say(p, "ベリル", ["{closed}……竜祭りの 夜に、鍵を 持って 来いって。みんな、あの 骨の 根もとへ 呼ばれてる。"], eR);   /*F67 回（暦の 丸 → 竜祭り）*/
    K.act(eB, 0);
    /* 灯籠を 飛ばす */
    for (const e of [eH, eS, eR]) { K.hold(e, "chochin"); K.act(e, "raise"); }
    await K.hsay(p, K.V(["{smile,up}じゃあ、手帳の 名前、ぜんぶ 飛ばそう。……三回ずつ ね！"], ["{smile,up}手帳の 名前、ぜんぶ……三度ずつ 呼びましょう。"], ["{smile}手帳の 名前。三回ずつ。"], ["{smile,up}手帳の お名前を、三度ずつ。"]));
    for (let i = 0; i < 4; i++) { for (let j = 0; j < 6; j++) { const a = (j / 6) * Math.PI * 2 + i; K.burst(p.dimension, { x: c.x + Math.cos(a) * (3 + i), y: y0 + 2 + i * 2, z: c.z + Math.sin(a) * (3 + i) }, j % 2 ? "minecraft:endrod" : "minecraft:basic_flame_particle", 2, 0.3, 0); } K.sound(p, "note.chime", 0.6 + i * 0.15); await K.wait(6); }
    await K.at(p, { x: c.x, y: y0 + 9, z: c.z }, 18, 9, 2);
    await K.narr(p, ["§7灯籠が 竜の 背骨に そって、夜空へ のぼって いく。", "§7ミミ、ゴンザ、ノルじい、オルド、レイ……手帳の 名前が、灯りに なって 空を わたった。"]);
    for (const e of [eH, eS, eR]) { K.act(e, 0); K.hold(e); }
    K.pay(p, E2, 2500, [["gift_bread", 2]]);
    await K.end(p, { leave: [eS, eK, eB], card: "§7― 夜更け ―\n§7→ 広場の 灯りの 下で（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 3話 夜更け ---------- */
const E3 = { id: "b13e3", t: "夜更け", place: () => FESTR("エンドの 広場（竜祭りの 夜更け）"), snd: "item.book.page_turn",
  hint: "§fエンドの §e広場§f の 灯りの 下へ §7（竜祭りの 夜更け。右上の 案内）",
  syn: "祭りの 灯りが 減った 夜更け。旅の 仲間が「……こうして いられたら、って 思っちゃった。……変なの」と つぶやいた。竜骨の 灯りが 一つだけ 消え、また ともった。シズク「……竜が、ひとつ 数えなおして おります」。夜明けに、祭壇の 方の 霧が ほどけた。",
  F: ["F03", "F29"], battles: 0,
  async run(p, d, K) {
    const c = ctr(K, p), y0 = Y(K, p);
    K.deco(p, "r9fest", 1, c, y0);
    await K.open(p, "竜祭りの 夜更け", "night");
    K.ambient(p, "night", { x: c.x, y: y0, z: c.z });
    const eH = K.hero(p), eR = REI(K, p);
    K.act(eR, "kneel"); if (ok(eR)) K.turn(eR, K.fwd(p, 20, -4, 6));
    await K.narr(p, ["§7広場の 灯りが、一つ、また 一つと 消えて いく。", "§7レイは 少し はなれた 所で、竜の 首に もたれて 骨の 山を 見て いた。"], eR);
    const g = K.palEnt(p); if (g && ok(eH)) { await K.go(g, { x: eH.location.x + 0.9, y: eH.location.y, z: eH.location.z + 0.4 }, 10); K.burst(p.dimension, g.location, "minecraft:heart_particle", 2, 0.3, 0.9); }
    if (ok(eH)) { K.act(eH, "kneel"); await K.two(p, eH, g || eH, 12); }
    await K.hsay(p, K.V(["{smile,…}……霧が 晴れたら、祭壇だね。セオさん、止められるかな。"], ["{smile,…}……霧が 晴れたら、ね。セオさん、止められるかしら。"], ["{closed}……霧が 晴れたら。止める。"], ["{smile,…}……霧が 晴れたら、で ございますね。"]));
    await K.up(p, eH, 14);
    await K.hsay(p, K.V(["{smile,…,up}……ねえ。こうして いられたら、って 思っちゃった。……変なの。"], ["{smile,…,up}……こうして いられたら、って 思っちゃった。……変ね。"], ["{closed,…,up}……こうなら、って 思った。……変だ。"], ["{smile,…,up}……こうして いられたら、と 思って しまいました。……変ですね。"]));   /*F03 植: 願いの 言葉 */
    K.rmCine(g);
    const far = K.fwd(p, 24, -4, 10);
    await K.at(p, far, 16, 12, 2);
    K.sound(p, "block.end_portal_frame.fill", 0.4);
    await K.narr(p, ["§7竜骨の 背骨に 並んだ 灯りが 一つだけ、ふっと 消え……", "§7……また、ともった。"], far);
    const eS = K.cast(p, "shizuku"); K.act(eS, "hold"); K.hold(eS, "chochin");
    if (ok(eS) && ok(eH)) await K.approach(p, eS, eH, 2);
    await K.ots(p, eS, eH, 8);
    await K.csay(p, "shizuku", ["{closed,up}……竜が、ひとつ 数えなおして おります。"], eH);   /*F29 植 */
    await K.hsay(p, K.V(["{?,up}数えなおす？"], ["{?,up}……数えなおす？"], ["{?}……何を。"], ["{?,up}数えなおす、とは……？"]), eS);
    await K.csay(p, "shizuku", ["{sad,no}竜が 覚えて いる 名の 数で ございます。……それ以上は、竜も 申しませぬ。"], eH);
    await K.hsay(p, K.V(["{smile,up}……じゃあ、さっき 飛ばした 名前も、竜が 数えて くれたのかな。"], ["{smile}……さっきの 灯籠の 名前も、数えて もらえたのかしら。"], ["{closed}……さっきの 名前も、数に 入ったのか。"], ["{smile}……先ほどの 灯籠の お名前も、数えて いただけたのでしょうか。"]), eS);
    await K.csay(p, "shizuku", ["{smile,closed}……はい。灯籠に 書かれた 名は、竜が 覚えて おります。", "{closed}四十年、わたくしが 見て きた かぎり、一つも 落とした ことは ございませぬ。"], eH);
    K.act(eS, 0);
    await K.hsay(p, K.V(["{smile}……変なの。……でも、ちょっと 寒く なってきた。寝よっか。"], ["{smile}……ふしぎね。……もう 休みましょう。"], ["{closed}……寝る。"], ["{smile}……ふしぎな お話です。……休みましょう。"]), eS);
    K.act(eH, 0); K.act(eR, 0);
    K.pay(p, E3, 1000, [["fd_stew", 1]]);
    await K.night(p, null, "§7灯籠が 消えて、村が 眠りに つく。", "§7……夜明け前。祭壇の 方の 霧が、うすく ほどけて いく。", [eS]);
    await K.end(p, { leave: [eR], card: "§7― 霧が 晴れた ―\n§7→ 竜骨の 祭壇への 道へ（右上の 案内）", kind: "dusk", t: 50 });
    return true;
  } };

/* ---------- 4話 祭壇への 道（守り手・オルドの 紐）---------- */
const E4 = { id: "b13e4", t: "守り手", place: ROAD, fac: "r9road",
  hint: "§f§e竜骨の 祭壇への 道§f へ 行こう §7（霧が 晴れた。右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "霧の 晴れた 道で、竜骨の 守り手が 目を さました。守り手は だれも 通さない。戦って 道を あけた あと、オルドが 手首の 干し草の 紐を 見せた。「三つ 編んで、一つ 返す。あやつの 結び方じゃ」。シズクは 言った。「竜は、願った 顔の まま 眠ります」。",
  F: ["F10"], set: { guard9: 1 }, battles: 1,
  async run(p, d, K) {
    const FW = K.fac(p, "r9road", "waypost", 9, Y(K, p));
    await K.open(p, "竜骨の 祭壇への 道", "ash");
    if (FW) await K.at(p, FW, 14, 6, 1.2);
    const eH = K.hero(p), eR = REI(K, p), eS = K.cast(p, "shizuku"), eO = ORDO(K, p);
    if (ok(eR) && FW) { await K.walkCam(p, eR, { x: FW.x - 1.2, y: Y(K, p), z: FW.z }, 16); K.turn(eR, K.fwd(p, 20, 0, 4)); }
    const hk = K.monEnt(p, K.fwd(p, 2.5, -3), HAKU(), "§fハク");
    await K.csay(p, "shizuku", ["{closed}……この 先は、竜骨の 内側で ございます。竜の 声が……ざわめいて おります。"], eR);
    K.act(eO, "hold");
    await K.say(p, "オルド", ["{closed}……嫌な 風じゃ。ハクの 毛が、逆立って おる。"], hk);
    K.turn(eR);
    const q = K.fwd(p, 9, 0);
    K.boom(p.dimension, q); K.sound(p, "mob.enderdragon.growl", 0.9); K.shake(p, 0.6, 0.8);
    const g1 = K.monEnt(p, q, DRAG(), "§6竜骨の 守り手");
    await K.at(p, q, 14, 7, 2);
    K.act(eS, "kneel");
    await K.csay(p, "shizuku", ["{shock,!,up}竜骨の 守り手……！ 祭壇を 守る 竜の 魂で ございます！"], g1);
    await K.say(p, "竜骨の 守り手", ["{angry,low}……カギヲ……モツモノモ……モタヌモノモ……トオサヌ……"]);
    K.act(eR, "guard"); K.act(eH, "guard");
    await K.say(p, "レイ", ["{angry,!,up}話の 通じる 相手じゃ ねえ！ ……背中は 任せた！"]);
    K.rmCine(g1);
    if (!K.flag(p, "b13e4a")) {
      await K.duel(p, "§6§l竜骨の 守り手", "§f千年 祭壇を 守った 竜の 魂が、骨の 翼を ひろげる！", { fams: ["dragon"] });
      const r = await K.battle(p, [...K.bossOne(["dragon"], 71, 40, 1), ...K.team(["dragon", "golem"], 70, 2, 20)], { name: "竜骨の 守り手", arena: "竜骨の 道", theme: "endcity", hpk: 2.4, extra: 0.3, sboss: true, tag: "守り手", speaker: "竜骨の 守り手", guests: K.team(["dragon"], 70, 1, 20).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……ナゼ……カギヲ……アツメル……", low: "……ネガウナ……ネムルゾ……" } });
      if (r !== "win") { K.rmCine(hk); return lose(K, p, "§bレイ", 17, "レイ", "{sweat,汗}……骨の くせに しぶとい！ いったん 立てなおすぞ！"); }
      K.setFlag(p, "b13e4a");
    }
    const g2 = K.monEnt(p, q, DRAG(), "§6竜骨の 守り手"); K.burst(p.dimension, q, "minecraft:white_smoke_particle", 10, 1.6, 0.4);
    await K.narr(p, ["§7守り手は 骨の 膝を つき、低く うなって、霧の 中へ 引いて いった。"], g2);
    K.rmCine(g2);
    K.act(eS, "hold");
    await K.approach(p, eS, eH, 1.9); await K.push(p, eS, 24, 4.5, 1.7);
    await K.csay(p, "shizuku", ["{sad,…,up}……竜が、こう 申して おります。", "{closed,up}『竜は、願った 顔の まま 眠る』……と。"], eH);
    await K.hsay(p, K.V(["{?,up}……願った 顔の まま？ 王墓の 壁の 人たちみたいに？"], ["{sad,up}……願った 顔の まま……。"], ["{closed}……願うと、眠る。"], ["{sad,up}願った お顔の まま……。"]), eS);
    /* オルドの 紐 */
    K.act(eO, "show"); K.hold(eO, "rope");
    if (ok(eO)) { await K.approach(p, eO, eR, 1.8); await K.at(p, { x: eO.location.x, y: eO.location.y + 1.1, z: eO.location.z }, 12, 1.5, 0); }
    await K.narr(p, ["§7オルドが 袖を まくった。手首に、干し草で 編んだ 古い 紐。"], eO);
    await K.say(p, "オルド", ["{closed}……三つ 編んで、一つ 返す。あやつの 結び方じゃ。", "{sad,low}教わった とおりに 編むと、ほどけん。……四十年、ほどけなんだ。"], eR);   /*F10*/
    await K.say(p, "レイ", ["{?,up}……あやつって、だれだよ。ゆうべの 星の 男か。"], eO);
    await K.say(p, "オルド", ["{closed,no}……祭壇が 先じゃ。"], eR);
    K.act(eO, 0); K.hold(eO);
    K.pay(p, E4, 3000, [["c_revive2", 2], ["x_ragna", 2]]);
    await K.end(p, { leave: [eR, eS, eO], card: "§c→ 六影 本拠地の §e竜骨の 門§c へ（右上の 案内）", kind: "ash" });
    K.rmCine(hk);
    return true;
  } };

/* ---------- MQ21 の 話（門・階段）。門の 場所: アジトの 入口が あれば そこ（段の 舞台の まま）。なければ 骨の 門を 建てる ---------- */
export async function gateSet(K, p) { if (hall9()) return null; return K.fac(p, "r9gate", "bonegate", 9, Y(K, p)); }
const MG = (n) => facMark("r9gate", n);

/* 5話 竜骨の 門（ガロ・眠る ピコ。C01 で 戦うか、C06 で 台詞）*/
const E5 = { id: "b13e5", t: "竜骨の 門",
  hint: "§f終焉の地 ラグナの §e六影 本拠地（竜骨の 門）§f へ §7（右上の 案内）",
  syn: "竜骨の 門に ガロが 立って いた。「参謀の『戻れ』は 来なかった」。門の 奥の 寝床で、ピコが 眠って いた。ガロ「……屋根の ある 所へ、連れてって やって くれ」。オルドが ハクの 背に ピコを 乗せ、ルミナへ 発った。",
  F: ["F18"],
  async run(p, d, K) {
    const FG = await gateSet(K, p);
    await K.open(p, "六影 本拠地（竜骨の 門）", "ash");
    if (FG) await K.at(p, FG, 14, 8, 2);
    K.big(p, "§5§l竜骨の 門", "§7紫の 光の 下、竜の 骨で できた 門", "mob.enderdragon.growl");
    const eH = K.hero(p), eR = REI(K, p);
    const eG = K.npcNear(p, "§c六影 中隊長 ガロ", K.PJ("garo", 9)); K.act(eG, "guard");
    await K.up(p, eG, 10);
    await K.say(p, "ガロ", ["{closed,low}……よう。また 昇進した。中隊長だ。部下は もう 一人も いねえ。", "{sad}門番を やれと 言われた。……参謀の『戻れ』は、いつまで 待っても 来なかった。"], eH);
    const c01 = K.ch(p, "c01");
    await K.say(p, "ガロ", [K.chV(K.qs(K.load(p)), "c06", { k: "{closed}……グロウで、黙っててくれたな。", t: "{closed,no}…………。", _: "{closed}……。" })], eH);
    K.act(eG, "hold");
    await K.at(p, ok(eG) ? { x: eG.location.x, y: eG.location.y + 1, z: eG.location.z } : K.fwd(p, 4), 12, 1.4, 0);
    await K.narr(p, [c01 === "k" ? "§7ガロの 腰には、古い 坑夫帽が 一つ だけ。" : "§7ガロの 腰に、古い 坑夫帽と……小さな 帽子が 一つ。", K.chIs(K.qs(K.load(p)), "c06", "t") ? "§7ガロは、こちらと 目を 合わせない。" : "§7ガロの 手が、帽子の つばを なぞった。"], eG);   /*F18*/
    if (c01 === "k") {
      await K.say(p, "ガロ", ["{angry,low}……帽子を 持ってる やつに、借りは 作らねえ。", "{angry,up}通りたきゃ、腕で 通れ。"]);
      if (!K.flag(p, "b13e5a")) {
        await K.duel(p, "§c§l門番 ガロ", "§f部下の いない 中隊長が、門の 前に 立つ！", { fams: ["golem"] });
        const r = await K.battle(p, K.team(["golem", "beast"], 72, 3, 12), { name: "六影 中隊長 ガロ", arena: "竜骨の 門", theme: "endcity", hpk: 1.3, extra: 0.25, speaker: "ガロ", lines: { half: "……まだだ。", low: "……へっ。強く なりやがって。" } });
        if (r !== "win") return lose(K, p, "§c六影 中隊長 ガロ", K.PJ("garo", 9), "ガロ", "{closed}……出なおして こい。");
        K.setFlag(p, "b13e5a");
      }
      const eG2 = K.npcNear(p, "§c六影 中隊長 ガロ", K.PJ("garo", 9), true); K.act(eG2, "kneel");
      await K.say(p, "ガロ", ["{closed,汗}……借りは、なしだ。……その 帽子、落とすなよ。"], eH);
      K.act(eG2, 0);
    } else {
      if (ok(eG)) await K.go(eG, K.fwd(p, 4, 3.2), 12);   /* 一歩 わきへ よけて 道を あける */
      await K.say(p, "ガロ", ["{closed}……借りは 返す。行け。オレは、何も 見なかった ことに する。"], eH);
    }
    /* 奥の 寝床の ピコ */
    const bq = MG("bed") || K.fwd(p, 6, 3.5);
    const ePc = await K.put(p, "§d手下 ピコ", bq, null, K.PJ("pico", 9)); K.act(ePc, "down");
    await K.at(p, bq, 14, 3, 0.6);
    await K.narr(p, ["§7門の 奥の 寝床で、小さな 子が 眠って いた。ガロの 袖の 切れ端を、にぎった まま。"], ePc);
    const eG3 = K.npcNear(p, "§c六影 中隊長 ガロ", K.PJ("garo", 9), true);
    if (ok(eG3) && ok(ePc)) { await K.approach(p, eG3, ePc, 1.2); K.act(eG3, "kneel"); }
    await K.say(p, "ガロ", ["{sad}……北の 門で 眠ってから、一度も 起きねえ。団の 医者も 首を ふった。", "{sad,low}……ここは 屋根が ねえ。骨の 天井だ。"], ePc);
    const eO = ORDO(K, p); K.act(eO, "hold");
    if (ok(eG3)) await K.ots(p, eG3, eO, 8);
    await K.say(p, "ガロ", ["{closed,up}……じいさん。屋根の ある 所へ、連れてって やって くれ。"], eO);
    await K.say(p, "オルド", ["{closed}……ルミナの わしの 牧場に、干し草の 屋根が ある。……ハクの となりは、あったかいぞ。"], eG3);
    await K.say(p, "レイ", ["{shock,up}じいちゃん、祭壇は――"], eO);
    await K.say(p, "オルド", ["{closed}子を 骨の 天井の 下に 寝かせて 進める 祭壇なぞ、ない。……祭壇は、おまえたちに 任せる。"], eR);
    const hk = K.monEnt(p, K.fwd(p, 3, -3), HAKU(), "§fハク");
    if (hk && ok(ePc)) await K.go(hk, { x: ePc.location.x - 1, y: ePc.location.y, z: ePc.location.z }, 14);
    K.sound(p, "mob.ravager.ambient", 0.6);
    await K.narr(p, ["§7オルドが ピコを 抱きあげ、ハクの 背に 乗せた。ピコの 手が、ガロの 袖を はなした。"], hk || ePc);
    K.rm(ePc);
    await K.hsay(p, K.V(["{sad,up}……ピコくん、起きたら『兄ちゃん』って 呼ぶよ。ぜったい。"], ["{sad,up}……起きたら、最初に あなたを 呼ぶわ。きっと。"], ["{closed}起きたら、『兄ちゃん』って 呼ぶ。"], ["{sad,up}目を 覚ましたら、きっと『兄ちゃん』と。"]), eG3);
    await K.say(p, "ガロ", ["{closed,…}……ああ。……オレも、あとで 行く。屋根の 下まで。"], eH);
    const gone = [];
    if (hk) gone.push(K.go(hk, K.fwd(p, -14, -6), 30, true));
    if (ok(eO)) gone.push(K.leave(eO, p, 12, false));
    await Promise.all(gone);
    K.pay(p, E5, 2000, [["c_revive2", 1]]);
    await K.end(p, { leave: [eG3], card: "§7→ 門の 内側へ", kind: "ash", t: 30 });
    K.rmCine(hk);
    return true;
  } };

/* 6話 門の 内側（ベリル戦）*/
const E6 = { id: "b13e6", t: "門の 内側",
  hint: "§f§e竜骨の 門の 内側§f へ §7（右上の 案内）",
  syn: "門の 内側で、ベリルが 待って いた。「一度も 勝てない まま 終わるのが、いや」。約束どおりの 戦い。",
  battles: 1,
  async run(p, d, K) {
    await gateSet(K, p);
    await K.open(p, "竜骨の 門の 内側", "ash");
    const iq = MG("inside"); if (iq) await K.at(p, iq, 12, 5, 1.4);
    const eH = K.hero(p), eB = sixT(K, p, "beryl", "§5六影 ベリル"); K.act(eB, "hold"); K.hold(eB, "paper");
    await K.up(p, eB, 10);
    await K.say(p, "ベリル", ["{closed}……来たのね。約束どおり。", "{sad}ねえ。今夜の 儀式が 終わったら、六影は なくなるんだって。……ヴァルカが、そう 言ってた。"], eH);
    await K.hsay(p, K.V(["{?,up}なくなるのに……なんで まだ 戦うの？"], ["{sad,up}なくなるのに、どうして？"], ["{?}なくなる。それでも 戦う 理由は。"], ["{sad,up}なくなるのに、なぜ……？"]), eB);
    await K.say(p, "ベリル", ["{closed,up}……一度も 勝てない まま 終わるのが、いや。……ヴァルカには、ないしょ。", "{angry,up}本気で 来て。……手を ぬかれたら、また 白紙の ままだから。"], eH);
    await K.hsay(p, K.V(["{closed,up}……わかった。手は、ぬかないよ。"], ["{closed}……わかったわ。本気で 行く。"], ["{closed}……ぬかない。"], ["{closed,up}……承知 しました。本気で 参ります。"]), eB);
    await K.say(p, "ベリル", ["{smile,low}……ありがとう。", "{angry}一座で 習った 立ち回り、全部 見せる。"], eH);
    K.hold(eB);
    if (!(won(K, p, "ch10a") || K.flag(p, "b13e6a"))) {
      await K.duel(p, "§5§l白紙の ベリル", "§f座の ない 六影が、最後に 一度 だけ 本気を 出す！", { fams: ["beast", "blob"] });
      const r = await K.battle(p, K.team(["beast", "blob", "golem"], 72, 3, 16), { name: "六影 ベリル", arena: "最後の 願い", theme: "endcity", hpk: 1.4, extra: 0.35, tag: "幹部候補", sboss: true, speaker: "ベリル", lines: { half: "今日の わたしは、本気なの！", low: "……やっぱり、だめ、か" } });
      if (r !== "win") return lose(K, p, "§5六影 ベリル", K.PJ("beryl", 9), "ベリル", "……勝った。初めて。……なのに、どうして 嬉しく ないの。");
      K.setFlag(p, "b13e6a");
    }
    const eB2 = sixT(K, p, "beryl", "§5六影 ベリル", 9, true); K.act(eB2, "kneel");
    await K.up(p, eB2, 10);
    await K.say(p, "ベリル", ["{sad,…}……負けた。……でも、本気だった。今の わたしの、全部。", "{closed}……ふしぎ。負けたのに、白紙じゃ ない 感じが する。"], eH);
    await K.hsay(p, K.V(["{smile,up}すごかったよ、ベリルちゃん。……ほんきの 顔、はじめて 見た。"], ["{smile}……すごかったわ。本気の 顔、はじめて 見た。"], ["{smile}……強かった。本気の 顔だった。"], ["{smile}……お見事でした。本気の お顔、はじめて 拝見しました。"]), eB2);
    await K.say(p, "ベリル", ["{sad,low}……腕、すりむいた。……少しだけ、休ませて。"], eH);
    K.pay(p, E6, 3000, [["c_revive2", 1]]);
    await K.end(p, { bye: [eB2], card: "§7→ 門の 内側（手当て）", kind: "ash", t: 26 });
    return true;
  } };

/* 7話 手当て（ベリルが 自分で 名を 書く）*/
const E7 = { id: "b13e7", t: "手当て",
  hint: "§f§e竜骨の 門の 内側§f で §7（右上の 案内）",
  syn: "戦いの あと、旅の 仲間が ベリルの 手当てを した。ベリルは 座の 紙の 白紙の 行に、自分で 名を 書いた。「ヴァルカは、一度も 載せて くれなかった」。行の 横には、石に なった 一座の 名前も。",
  F: ["F50", "F17", "F16", "F56"], ans: ["qb022"], battles: 0,
  async run(p, d, K) {
    await gateSet(K, p);
    await K.open(p, "竜骨の 門の 内側（手当て）", "ash");
    const eH = K.hero(p), eB = sixT(K, p, "beryl", "§5六影 ベリル"); K.act(eB, "kneel");   /* 門の 柱の 陰から 歩いて 来て 座る */
    if (ok(eH) && ok(eB)) { await K.approach(p, eH, eB, 1.2); K.act(eH, "kneel"); K.hold(eH, "bandage"); }
    await K.two(p, eH, eB, 12);
    await K.hsay(p, K.V(["{sad}……じっと してて。包帯、巻くから。"], ["{sad}……動かないで。手当て するわね。"], ["{closed}……動くな。巻く。"], ["{sad}……そのまま で。お手当て いたします。"]), eB);
    K.hold(eH);
    K.hold(eB, "paper"); K.act(eB, "hold");
    await K.at(p, ok(eB) ? { x: eB.location.x, y: eB.location.y + 1, z: eB.location.z } : K.fwd(p, 3), 12, 1.5, 0);
    await K.narr(p, ["§7ベリルが 座の 紙を ひざに 広げた。六つの 行。いちばん 下の 行だけ、白紙。", "§7紙の 角が、少し 焼けて いる。"], eB);
    await K.say(p, "ベリル", ["{sad}……ヴァルカは、一度も 載せて くれなかった。", "{closed}『アンタは 載らなくて いい』って。……わたし、いらない 子なんだと 思ってた。"], eH);   /*F17*/
    await K.hsay(p, K.V(["{smile}……ペン、あるよ。自分の 名前は、自分で 書いて いいんだよ。"], ["{smile}……ペン、どうぞ。自分の 名前は、自分で 書いて いいのよ。"], ["{closed}ペン。自分の 名前は、自分で 書けば いい。"], ["{smile}……どうぞ、ペンを。ご自分の お名前は、ご自分で 書いて よいのです。"]), eB);
    K.sound(p, "item.book.page_turn", 1);
    await K.push(p, eB, 22, 3.6, 1.2);
    await K.narr(p, ["§7ベリルは ペンを 受け取って、白紙の 行に、ゆっくり §fベリル§7 と 書いた。", "§7それから 行の 横に、小さな 字で 一座の 名前を 一つずつ。……セプルクの 芝居小屋で、幕の 上がった まま 石に なった 人たち。"], eB);   /*F50・F56（F50 回・F56 強）*/
    await K.say(p, "ベリル", ["{closed}……ベ、リ、ル。", "{smile,…}……書いて ある。わたしの 字で。"], eH);
    await K.hsay(p, K.V(["{smile,♪}わたしの 手帳にも 書いとくね。……ベリルちゃん。"], ["{smile}わたしの 手帳にも、書いて おくわね。"], ["{smile}手帳にも 書く。"], ["{smile}わたしの 手帳にも、記して おきます。"]), eB);
    await K.say(p, "ベリル", ["{sad,up}……ルミナの パン屋の 子。名前を 聞きそびれたの。……あの 子も、きっと。", "{smile}行って。あの 人を、止めて あげて。"], eH);   /*F16*/
    K.act(eB, 0); K.hold(eB); K.act(eH, 0);
    K.pay(p, E7, 2000, [["gift_bread", 1]]);
    await K.end(p, { leave: [eB], card: "§7→ 祭壇へ 続く 骨の 階段へ", kind: "ash", t: 24 });
    return true;
  } };

/* 8話 骨の 階段 */
const E8 = { id: "b13e8", t: "骨の 階段",
  hint: "§f§e祭壇へ 続く 骨の 階段§f へ",
  syn: "祭壇へ 続く 骨の 階段。上の 方に、双子を 抱えた 仮面の 戦士、赤い 外套、そして セオの 影が 見えた。",
  battles: 0,
  async run(p, d, K) {
    const FS = K.fac(p, "r9stair", "bonestair", 9, Y(K, p));
    await K.open(p, "祭壇へ 続く 骨の 階段", "ash");
    const top = facMark("r9stair", "top") || K.fwd(p, 12, 0, 6), foot = facMark("r9stair", "foot") || K.fwd(p, 4);
    if (FS) await K.at(p, FS, 14, 8, 3);
    const eR = REI(K, p), eH = K.hero(p);
    if (ok(eR)) { await K.walkCam(p, eR, foot, 16); K.turn(eR, top); }
    await K.at(p, top, 14, 10, 2);
    const eA = await K.put(p, "§4仮面の 戦士", top, null, K.PJ("argo", 10)); K.act(eA, "hold");
    const eV = await K.put(p, "§c六影 幹部 ヴァルカ", { x: top.x + 1.6, y: top.y, z: top.z + 0.6 }, null, K.PJ("valka", 9));
    const eT = await K.put(p, "§5六影 参謀 セオ", { x: top.x - 1.4, y: top.y, z: top.z + 1.2 }, null, 18);
    if (ok(eT)) K.turn(eT, K.fwd(p, 30, 0, 8));
    await K.narr(p, ["§7階段の 上。白い 仮面の 戦士が、眠る 子を 一人 抱え、もう 一人の 手を 引いて いる。", "§7その 横に 赤い 外套。……その 先、背を 向けた 細い 影。"], eA);
    await K.hsay(p, K.V(["{shock,!,up}……ロウくんと ルウちゃん！ ……ヴァルカさんも！"], ["{shock,up}……双子……！ ヴァルカさんまで……"], ["{shock,!}……双子。ヴァルカ。……セオ。"], ["{shock,!,up}ロウさんと ルウさん……！ ヴァルカさまも……！"]), eV);
    await K.say(p, "レイ", ["{angry,low}……あいつら、セオに 鍵を 届けに 来たんだ。", "{closed}……仮面の やつ、ロウを 抱えた まま だ。まだ 起きて ねえのか。"], eH);
    await K.hsay(p, K.V(["{sad,up}……ルウちゃん、ずっと ロウくんの 手を にぎってる。"], ["{sad}……ルウちゃん、ロウくんの 手を 離さないのね。"], ["{closed}……ルウは、手を 離さない。"], ["{sad}……ルウさん、ロウさんの お手を 離しませんね。"]), eR);
    if (ok(eR)) await K.ots(p, eR, eT, 10);
    await K.narr(p, ["§7細い 影は、ふり向かなかった。……手帳を 開く 音が、風に 乗って 落ちて きた。"], eT);
    await K.say(p, "レイ", ["{angry,up}……セオ！ ……聞こえてて、無視か。"]);
    const g8 = K.palEnt(p); if (g8) await K.up(p, g8, 8);
    await K.pal(p, ["……あの ひと、かみの におい。……ずっと、おなじ ページの におい。"]);
    K.rmCine(g8);
    await K.bye(p, eA, eV, eT);
    K.pay(p, E8, 1000, []);
    await K.end(p, { card: "§7→ 階段を 登る", kind: "ash", t: 22 });
    return true;
  } };

/* 9話 階段の 途中 */
const E9 = { id: "b13e9", t: "階段の 途中",
  hint: "§f§e骨の 階段§f を 登る",
  syn: "竜骨の 道は、夜明けとともに 閉じる。骨の 階段が 下から 霧に 沈みはじめた。四人と 相棒は、ふり返らずに 登った。",
  battles: 0,
  async run(p, d, K) {
    K.fac(p, "r9stair", "bonestair", 9, Y(K, p));   /*（ラグナ 回: 本9 の 張り紙が 追いやった 先が、ここ）*/
    await K.open(p, "骨の 階段の 途中", "dusk");
    const mid = facMark("r9stair", "mid") || K.fwd(p, 8, 0, 3), top = facMark("r9stair", "top") || K.fwd(p, 12, 0, 6);
    const eR = REI(K, p), eH = K.hero(p);
    K.burst(p.dimension, K.fwd(p, 1, 0), "minecraft:white_smoke_particle", 12, 2.4, 0.2);
    await K.narr(p, ["§7東の 空が、白みはじめた。", "§7下の 段から、竜の 霧が 骨の 階段を 呑みこんで いく。"], K.fwd(p, 2, 0, 1));
    await K.say(p, "レイ", ["{angry,up}夜明けまでに 上まで 行かなきゃ、道が 閉じる！ 走るぞ！", "{closed}振り向くな。霧に 足を 取られたら、戻れねえ。"], eH);
    await K.hsay(p, K.V(["{angry,up}うん！ ……手、はなさないでね！"], ["{angry,up}ええ……！ 遅れないで！"], ["{angry}行く。"], ["{angry,up}はい……！ 参りましょう！"]), eR);
    const g = K.palEnt(p);
    await Promise.all([ok(eR) ? K.walkCam(p, eR, mid, 18) : 0, ok(eH) ? K.go(eH, { x: mid.x + 1, y: mid.y, z: mid.z }, 18, true) : 0, g ? K.go(g, { x: mid.x - 1, y: mid.y, z: mid.z }, 16, true) : 0]);
    await K.at(p, top, 14, 7, 2);
    await K.narr(p, ["§7骨の 段を 一つ 登るたび、竜の 背骨が 低く 鳴った。", "§7あの 子の 首の コンパスの 針は、まっすぐ 上を さして いた。"], top);
    await Promise.all([ok(eR) ? K.walkCam(p, eR, top, 18) : 0, ok(eH) ? K.go(eH, { x: top.x + 1, y: top.y, z: top.z }, 20, true) : 0]);
    K.rmCine(g);
    await K.hsay(p, K.V(["{closed,up}……着いた。"], ["{closed,up}……着いたわ。"], ["{closed}……着いた。"], ["{closed,up}……着きました。"]), eR);
    await K.say(p, "レイ", ["{closed,low}……息、整えろ。", "{angry}セオが 何を する 気でも、オレたちで 止める。"], eH);
    await K.hsay(p, K.V(["{smile,up}うん。……コンパスも、こっちだって 言ってる。"], ["{smile}ええ。……コンパスも、この 先を さして いるわ。"], ["{closed}……針も、この 先だ。"], ["{smile}はい。……コンパスも、この 先を さして おります。"]), eR);
    K.pay(p, E9, 1000, []);
    await K.end(p, { card: "§4→ 竜骨の 祭壇", kind: "ash", t: 22 });
    return true;
  } };

bkAdd("b13", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
