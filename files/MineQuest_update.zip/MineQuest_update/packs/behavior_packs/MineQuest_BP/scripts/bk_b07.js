/* 第126版 本7「海神の貝笛」（マリノア諸島・コラリア／ケープ／ネプトゥナ）— 作業 MB
   1 コラリア（r6e1）→ 2 祭りの浜（r6e2: セオが 頁を 破る）→ MQ14: 3 港の桟橋・4 夜の浜（C07）・5 岬の灯台（第125版の ヴァルカの 筋と 灯台を 引きとる）
   → 6 嵐の前の舟小屋（r6e4 を 書きなおし: C07 で 手が かわる）→ MQ15: 7 沖の沈んだ神殿（深海の 潜り）→ MQ16: 8 ネプトゥナ（マリンに 勝った あと）→ 9 海神祭（r6e6 を 書きなおし）*/
import { bkAdd, mqOver } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facAt, facCur, facSide, facFront, facBuild, fac } from "./epfac.js";
import { townOut, placeOf, bldOf, regTown, farOf } from "./storyplace.js";
import { plazaOf, moveG } from "./pvplace.js";
import { world } from "@minecraft/server";
import { DIVE } from "./saga.js";
import { countItem, takeItem, ok } from "./ui.js";
import { H4, Y0, chOf, did, oldRun, mk, letter, tOut, near, PL, SEO, REI } from "./bk_b05.js";

const { F, S1 } = FAC_OPS;
const T = (s) => (s && typeof s === "object" ? s : {});
/* 石の 女（海の ない 世界・点検用。深海では 神殿の 前に 直に 置く）*/
facAdd("b7statue", { D: [11, 13], box: [-1, -3, 5, 3], H: 5, look: [3, 0, 1.6], marks: { hands: [3, 0, 1.6], gate: [1, 0, 0] }, build: (P) => [
  F(0, -3, -1, 5, 3, -1, "prismarine_bricks"), F(5, -3, 0, 5, 3, 4, "dark_prismarine"), F(3, 0, 0, 3, 0, 2, "stone"), S1(3, 0, 3, "brain_coral_block"), S1(3, -1, 2, "tube_coral_block"), S1(3, 1, 1, "fire_coral_block"),
  S1(2, 0, 2, "stone_button"), F(1, -3, 0, 1, -2, 3, "prismarine"), F(1, 2, 0, 1, 3, 3, "prismarine"), S1(4, 2, 0, "sea_lantern"), S1(4, -2, 0, "sea_lantern"),
] });

/* ---------- 場所 ---------- */
const HUT0 = tOut("t15", "hut", 0.9, "網元の 舟小屋"), HUT = () => farOf("r6hut", "t15", "コラリアの 網元の 舟着き場", 80, 220) || HUT0();   /* 第127版(fac2): 町の 外れ 56 → 離れた 入り江（大きな 舟小屋と 船だまり）*/
/* 第126版(PV): 戦いの ある 夜の 浜は 町の 外（港の 浜から 城壁の 外へ 54マス）*/
const BEACHOUT = () => { const q = placeOf("beach", 6, true), T = regTown(6), c = T ? T.q : plazaOf("t15"); if (!q || !c) return q; const dx = q.x - c.x, dz = q.z - c.z, n = Math.hypot(dx, dz) || 1; if (n >= 50) return q; return { x: Math.floor(c.x + (dx / n) * 54), y: null, z: Math.floor(c.z + (dz / n) * 54), nm: "コラリアの 外れの 夜の 浜" }; };
/* 第126版(PV): 海神祭は 町の 中の 港の 浜辺 */
const FEST = () => { const q = bldOf("t15", ["harbor"], "コラリアの 港の 浜辺") || plazaOf("t15", "コラリアの 広場"); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm } : tOut("t15", "fst", -1.3, "祭りの 浜")(); };
const PIER = () => { const q = placeOf("harbor", 6); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm || "コラリアの 港の 桟橋" } : tOut("t15", "pier", 0.2, "コラリアの 港の 桟橋")(); };
const NAGI = (K, p, w = false) => K.npcNear(p, "§6ナギサ", K.PJ("nagisa", 8), w);
const MARIN = (K, p, w = false) => K.npcNear(p, "§3マリン", K.PJ("marin", 9), w);
const VALKA = (K, p, w = false) => K.npcNear(p, "§c六影 ヴァルカ", K.PJ("valka", 10), w);
const zaza = (K, p) => K.cast(p, "r6zaza");
/* 浜の 燃える 流木（焚き火と 流木の 半ブロック）*/
function drift(K, p, q, wood = []) { const put = (o, b) => { if (!o) return; const x = Math.floor(o.x), z = Math.floor(o.z), y = Math.floor(o.y); K.cmd(p, `setblock ${x} ${y} ${z} ${b} keep`); }; put(q, "campfire"); for (const w of wood) put(w, "birch_slab"); }
async function blaze(K, p, at, k = 4) { if (!at) return; for (let j = 0; j < k; j++) { K.burst(p.dimension, at, j % 2 ? "minecraft:basic_flame_particle" : "minecraft:lava_particle", 8, 0.8 + j * 0.4); K.burst(p.dimension, at, "minecraft:basic_smoke_particle", 6, 1.4, 2); await K.wait(3); } }
/* 岬の 灯台へ 移る（第125版 capeGo と 同じ 灯台 r6cape を 使う。暗転 → 灯台の 前 → 引きの 絵）*/
async function cape(K, p, drop = []) {
  let L = facCur("r6cape");   /* 第127版(fac2): 前の 小さな 灯台なら 建てなおす */
  if (!L) { const S = K.S(p); if (S) L = facSide(p, S, 30, "r6cape", "lighthouse", 6, Y0(K, p)) || facSide(p, S, -30, "r6cape", "lighthouse", 6, Y0(K, p)); }
  const Fq = L ? facFront("r6cape", 9) : townOut("t35", -0.4, "岬");
  if (Fq) await K.moveTo(p, Fq, "岬の 灯台", drop, L || null, 12); else await K.open(p, "岬の 灯台", "dusk");
  if (!L && K.S(p)) L = facBuild(p, K.S(p), "r6cape", "lighthouse", 6, Y0(K, p));
  if (L) { K.camPt(p, L, 11, 3); K.sound(p, "random.splash", 0.6); await K.wait(26); }
  return L;
}

/* ---------- 町の 人 ---------- */
castAdd("r6nagisa", { nm: "ナギサ", role: "", col: "§6", gobi: "", skin: "nagisa", town: "t15", hide: (s) => !did(s, "b07e3"), at: near(FEST, 3, 3),
  pre: ["{closed}……一、二、三。"],
  after: [
    [(s) => !!s.ending && (s.ch || {}).c07 === "n", ["{smile}包帯、やっと 取れたよ。あとは 残るけど……この 手で 網も 結べる。", "{closed}……潮は 引いても、必ず 満ちる。"]],
    [(s) => !!s.ending, ["{smile}あなたの 相棒の 前足、まだ 跡が ある？ ……ありがとうって、ずっと 言いたかった。"]],
    [(s) => !!s.heroDead, ["{sad}……潮が、満ちない。こんな 海、初めて。", "{closed}でも 数えるよ。……一、二、三。"]],
    [(s) => did(s, "b07e9"), ["{smile,♪}九十八、九十九、百。……ね、ちゃんと 満ちたでしょ。"]],
    [(s) => (s.ch || {}).c07 === "n", ["{sad}この 手じゃ、まだ 潜れない。……だから、マリンを 信じて 数えるの。"]],
    [() => true, ["{closed}……笛、返って きて よかった。かあさんの 紐も、ほら。"]],
  ] });

/* ---------- 1話 さんごの町コラリア ---------- */
const E1 = { id: "b07e1", pv: 127, t: "さんごの町コラリア", place: HUT, fac: "r6hut", F: ["F68"],
  hint: "§fさんごの 町 §eコラリア§f の 網元の 舟小屋へ 行こう",
  syn: "網元ザザは 姉妹の 親がわり。十年前の 嵐の 夜、二人の 母ミナモは 神殿の 貝笛を 持ち出して 舟を 出した。浜に 戻ったのは、笛だけだった。",
  async run(p, d, K) {
    return oldRun(p, d, K, E1, 6, "r6e1", { ots: true, post: async (p, K) => {
      const eZ = zaza(K, p); { const q = K.fwd(p, 2.4, -1.8); if (q) await K.go(eZ, q, 14); } K.act(eZ, "hold"); K.hold(eZ, "net");
      await K.csay(p, "r6zaza", /*F68*/["{sad}……あの 夜、ミナモは 神殿の 貝笛を 持って 出たっぺ。", "{closed}朝に なって、浜に 戻って きたのは、笛 だけだったっぺ。……舟も、ミナモも、戻らなかったっぺ。"]);
      await K.hsay(p, H4("{sad}……笛だけ、戻って きたんだ。", "{sad}……笛だけが、浜に。", "{closed}笛だけ。……覚えて おく。", "{sad}笛だけが、浜に……"));
    } });
  } };
/* ---------- 2話 コラリアの祭りの浜 ---------- */
const E2 = { id: "b07e2", t: "コラリアの祭りの浜", place: FEST, F: ["F07"],
  hint: "§fコラリアの §e港の 浜辺§f で 海神祭の 支度を 手伝おう",
  syn: "海神の 歌を 聞いた。夜、焚き火の そばで、セオが 背を 向けて 手帳の 頁を 一枚 破った。見て いたのは 相棒だけ だった。",
  skip: (s) => { s.epx = { ...T(s.epx), prep6: 1 }; },
  async run(p, d, K) { return oldRun(p, d, K, E2, 6, "r6e2"); /*F07 頁を 破る（相棒だけが 見る）は r6e2 の 場面 */ } };

/* ---------- 3話 コラリアの港の桟橋（MQ14）---------- */
const E3 = { id: "b07e3", t: "コラリアの港の桟橋", F: ["F10"],
  hint: "§fマリノア諸島の §e港の 桟橋§f へ 行こう §7（マリンと 姉が 待って いる）",
  syn: "ナギサは 毎朝 桟橋で 波を 百 数える。手首に 紐。「三つ 編んで、一つ 返す」ふしぎな 結び方。貝笛は 母の 形見だった。",
  async run(p, d, K) {
    await K.open(p, "コラリアの 港の 桟橋", "day");
    const eH = K.hero(p), eN = NAGI(K, p); K.act(eN, "point");
    await K.say(p, "ナギサ", ["{closed}……九十七、九十八。今日は 満ちるのが 遅いな。"]);
    K.act(eN, 0);
    await K.say(p, "ナギサ", ["{shock,!,jump}……うわっ！？ いつから いたの？"]);
    const eM = MARIN(K, p);
    await K.say(p, "マリン", ["{smile}姉さん、この 人たちが 水晶の 洞くつで 助けて くれたの。"]);
    await K.say(p, "ナギサ", ["{smile,♪,up}マリンを！？ ありがとう、ありがとう！ わたしは 姉の ナギサ。この 港の 地方マスターよ。", "{smile}毎朝 百 数えて、今日 船を 出すか 決めるの。港の 仕事は、まず 潮を 読む こと。"]);
    K.act(eN, "show"); await K.push(p, eN, 22, 3.5, 1, 1.1);
    await K.narr(p, /*F10*/["§7ナギサの 手首に、色あせた 紐。三つ 編んで、一つ 返す……ふしぎな 結び目が 続いて いる。"], eN);
    await K.hsay(p, H4("{?}その 紐、変わった 結び方だね。", "{?}……きれいな 紐。変わった 結び方ね。", "{?}結び方が 変。", "{?}変わった 結び方の 紐ですね。"));
    await K.say(p, "ナギサ", ["{closed}かあさんの。……三つ 編んで、一つ 返す。だれに 教わったのかは、聞きそびれた。"]);
    K.act(eN, "hold"); K.hold(eN, "flute");
    await K.say(p, "マリン", ["{closed}……六影が §6海神の 貝笛§f を 狙ってる。深い 海で 吹くと、沈んだ 神殿の 番人が 目を 覚ます 笛。"]);
    await K.say(p, "ナギサ", ["{closed}笛は わたしが 持つ。かあさんの 笛だから。", "{smile}今夜は 大潮。§e夜の 浜§f から 潮の 道が 沖へ 伸びる。……いっしょに 来て。"]);
    await K.hsay(p, H4("{smile}うん。浜まで いっしょに 行く！", "{smile}ええ。いっしょに 行くわ。", "{closed}行く。", "{smile}お供 いたします。"));
    await K.night(p, null, "§7―― 日が 沈み、大潮の 夜が 来た。", "");
    return true;
  } };

/* ---------- 4話 夜の浜（燃える流木・C07）---------- */
const E4 = { id: "b07e4", t: "夜の浜（燃える流木）", battles: 1, F: ["F52"],
  hint: "§f夜の 浜へ",
  syn: "ヴァルカが 浜の 流木に 火を 放った。「番人に 会うのは、まだ 早い。参謀の 言いつけさ」。笛は はじかれて 火の 中へ。ナギサが 手を 伸ばした。",
  async run(p, d, K) {
    { const q = BEACHOUT(); if (q) await moveG(K, p, q, "夜の 浜（町の 外れ）"); else await K.open(p, "夜の 浜", "night", "night"); fac(K, p, "b7beach", "beachcamp", 6, Y0(K, p)); }   /* 浜の 流木と 小舟（何も ない 浜に しない）*/
    const eH = K.hero(p), eN = NAGI(K, p), eM = MARIN(K, p); K.hold(eN, "flute");
    const f = K.fwd(p, 7);
    drift(K, p, K.fwd(p, 9.5, -3.6), [K.fwd(p, 10.6, -4.4), K.fwd(p, 10.4, -2.6)]);
    K.sound(p, "random.explode", 0.8); K.shake(p, 0.6, 0.8);
    if (f) { K.camPt(p, f, 6, 2); await blaze(K, p, f, 6); }
    K.big(p, "§c§l浜が 燃えている！", "§f炎の 中から、だれかが 歩いて くる", "mob.blaze.shoot");
    const eV = VALKA(K, p);
    await K.low(p, eV, 12);
    await K.say(p, "ヴァルカ", ["{smile,low}その 貝笛、いただくよ。", "{closed}燃やしたのは 流木だけだ。火の 輪の 外に いりゃ、だれも 焼けない。"]);
    await K.hsay(p, H4("{rage,怒,jump}ヴァルカ！ なんで 貝笛まで！？", "{angry}……どうして 貝笛を？", "{angry}何に 使う。", "{angry}ヴァルカ！ なぜ 貝笛を！"));
    await K.say(p, "ヴァルカ", /*F52*/["{closed}……番人に 会うのは、まだ 早い。参謀の 言いつけさ。", "{angry}アタシは 嘘は つかない。命令なら、大事な もんでも 取る。"]);
    await K.sixMark(p, eV, "valka");
    await K.battle(p, K.team(["dragon", "nether"], 70, 3, 40), { name: "六影 ヴァルカ", arena: "奪われた 貝笛", theme: "beach", speaker: "ヴァルカ", hpk: 30, extra: 0.6, heal: false,
      scripted: { turns: 2, lines: ["§c§lヴァルカの 竜が 炎の 渦を 起こした！", "§7熱で 視界が ゆがむ……！"] }, lines: { half: "やるねえ……でも ムダだよ！" } });
    if (!K.replay(p)) { const dd = K.load(p); if (dd) { const s = K.qs(dd); { const n = countItem(p, "mrpg:k_shell"); if (n > 0) takeItem(p, "mrpg:k_shell", n); } s.keys = (s.keys || []).filter((k) => k !== "k_shell"); s.shellLost = 1; K.save(p, dd); } }
    const eV2 = VALKA(K, p, true), eN2 = NAGI(K, p, true); K.act(eN2, "guard"); K.hold(eN2, "flute");
    K.act(eV2, "raise"); K.sound(p, "mob.blaze.shoot", 0.8);
    const w = K.fwd(p, 4.5, 2.8); if (w) { K.camPt(p, w, 4, 1.2); drift(K, p, K.fwd(p, 5.7, 4.1)); await blaze(K, p, w, 4); }
    K.act(eN2, "recoil"); K.hold(eN2);
    await K.narr(p, ["§7火の 粉が はぜて、ナギサの 手から 貝笛が はじかれた。", "§7貝笛は、燃える 流木の 中へ 転がった。"], w);
    K.act(eN2, "kneel"); await K.up(p, eN2, 10);
    await K.narr(p, ["§7ナギサが、炎の 中へ 手を 伸ばす。"], eN2);
    const g = K.palEnt(p); if (g && w) { K.place(g, p, K.fwd(p, 3.2, 1.8)); K.camNear(p, g, 2.2, 0.7); await K.wait(8); }
    const c = await K.pick(p, "c07");
    if (c === "p") {
      if (g && w) { await K.go(g, w, 8); K.burst(p.dimension, w, "minecraft:white_smoke_particle", 8, 0.5, 0.4); K.camNear(p, g, 2, 0.6); await K.wait(10); }
      await K.narr(p, ["§7相棒が 炎の 中へ 飛びこみ、貝笛を くわえて 転がり出た。", "§7前足の 毛が、黒く 焼けて いる。"], g);
      await K.pal(p, ["……あつい。でも、とった。"]);
      if (!K.replay(p)) { const dd = K.load(p); if (dd) { K.qs(dd).palBurn = 1; K.save(p, dd); } }
      K.act(eV2, 0); if (ok(eV2) && g) { await K.approach(p, eV2, g, 1.4, 12); }
      await K.say(p, "ヴァルカ", ["{closed,low}……健気な 子だ。", "{sad,low}アタシの 火が、アンタの 相棒を 焼いた。……言い訳は しない。笛は 預かる。"]);
    } else {
      K.burst(p.dimension, w || p.location, "minecraft:white_smoke_particle", 8, 0.5, 1);
      await K.narr(p, ["§7ナギサは 迷わず、炎の 中へ 両手を 入れた。", "§7……貝笛を 握った 手から、白い 煙が 上がる。"], eN2);
      await K.hsay(p, H4("{shock,!,up}ナギサさん！！", "{shock,!,up}ナギサさん……！", "{shock,!}……ナギサ！", "{shock,!,up}ナギサさん！！"));
      if (ok(eV2) && ok(eN2)) await K.approach(p, eV2, eN2, 1.1, 12);
      K.re(eV2, "closed", "…"); await K.give(eN2, eV2, "flute"); K.act(eN2, "down");
      await K.say(p, "ヴァルカ", ["{closed,low}……離せば よかったんだ。なんで、離さなかった。", "{sad,low}人に 向けた 火じゃ ない。でも、焼いたのは アタシの 火だ。"]);
    }
    await K.hsay(p, H4(["{rage,怒,up}……それ、返しなさいよ！"], ["{angry,up}……それ、返して。"], ["{rage,怒}……返せ。"], ["{rage,怒,up}……お返し ください！"]));
    await K.say(p, "ヴァルカ", ["{closed,low}……預かり物だよ。番人に 会うのは、まだ 早い。", "{angry,low}取りかえしたけりゃ、§e岬の 灯台§f まで 来な。……逃げも 隠れも しないよ。"]);
    K.act(eV2, 0); await K.leave(eV2, p, 12, false);
    const eM2 = MARIN(K, p, true); if (ok(eM2) && ok(eN2)) await K.approach(p, eM2, eN2, 0.9, 10); K.act(eM2, "kneel");
    if (c === "n") { await K.say(p, "マリン", ["{cry,!,up}姉さん！！ 手が……！"]); await K.narr(p, ["§7マリンは 海水で 姉の 両手を 冷やし、自分の 上着の 袖を 裂いて 巻いた。"], eN2); }
    else await K.say(p, "マリン", ["{sad,up}……姉さん、けがは？ ……よかった。"]);
    await K.say(p, "ナギサ", c === "n" ? ["{sad}……ごめんね、マリン。この 手じゃ、しばらく 櫂も 網も 握れない。", "{sad,up}港の マスターは、あなたに 頼む。"] : ["{sad}……わたしの 代わりに、あの 子が 焼けた。", "{closed}マリン。……港の マスター、あなたに 頼む。わたしは 数える 方に 回る。"]);
    await K.say(p, "マリン", ["{closed}……潮は 引いても、必ず 満ちる。", "{angry,up}笛を 取りかえそう。§e岬の 灯台§f へ。"]);
    K.rmCine(g); await K.bye(p, eN2, eM2);
    return true;
  } };

/* ---------- 5話 岬の灯台 ---------- */
const E5 = { id: "b07e5", t: "岬の灯台", F: ["F23"], keys: ["k_shell"],
  hint: "§fヴァルカを §e岬の 灯台§f まで 追いかけよう",
  syn: "マリンと ヴァルカを 岬の 灯台まで 追った。ヴァルカは「笛は 返す。アタシは 嘘は つかない」と 言った。",
  async run(p, d, K) {
    const L = await cape(K, p, [K.hero(p, false)]);
    const eV = VALKA(K, p); K.hold(eV, "flute"); if (L) K.turn(eV, L);
    if (ok(eV)) await K.push(p, eV, 22, 5, 3.2, 1.4);
    await K.narr(p, ["§7灯台の 下で、赤い 外套の 背中が 海を 見て いた。"], eV);
    const eH = K.hero(p), eM = MARIN(K, p);
    await K.hsay(p, H4("{angry,up}……ヴァルカ！", "{angry,up}……ヴァルカ。", "{angry}……ヴァルカ。", "{angry,up}……ヴァルカ！"));
    K.turn(eV, null); K.turn(eV, p.location);
    const c4 = chOf(K, p, "c04");
    if (c4 === "s") {
      await K.say(p, "ヴァルカ", ["{closed}……来たね。", "{closed,low}鋳造所で、アンタらは 親父の 刀を 引き出した。……借りは 返す。"]);
      if (ok(eV) && ok(eM)) await K.approach(p, eV, eM, 1.1, 12);
      await K.give(eV, eM, "flute");
      await K.say(p, "ヴァルカ", /*F23*/["{closed}笛は 返す。アタシは 嘘は つかない。……参謀には、アタシが 言う。"]);
    } else {
      await K.say(p, "ヴァルカ", ["{closed}……来たね。命令は 命令だ。笛が ほしけりゃ、力で 取りな。"]);
      await K.say(p, "マリン", ["{angry,up}……姉さんの 笛、返して もらう。"]);
      const r = await K.battle(p, K.team(["dragon", "nether"], 50, 3, 54), { name: "六影 ヴァルカ", arena: "岬の 灯台", theme: "beach", hpk: 11, extra: 0.35, sboss: true, speaker: "ヴァルカ", guests: K.team(["aqua"], 48, 2).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "やるじゃないか！", low: "……参謀に、なんて 言えば……" } });
      if (r !== "win") { await K.sayAt(p, "§3マリン", K.PJ("marin", 9), "マリン", ["……一度 港で 立てなおそう。", K.RT(p)]); return false; }
      const eV3 = VALKA(K, p, true), eM3 = MARIN(K, p, true); K.act(eV3, "kneel");
      await K.say(p, "ヴァルカ", /*F23*/["{sweat,息}……負けは 負けだ。笛は 返す。アタシは 嘘は つかない。"]);
      K.act(eV3, 0); if (ok(eV3) && ok(eM3)) await K.approach(p, eV3, eM3, 1.1, 10);
      await K.give(eV3, eM3, "flute");
    }
    const eM4 = MARIN(K, p, true); K.act(eM4, "show");
    K.big(p, "§b§l海神の 貝笛を 取りかえした！", "§fもう 二度と はなさない");
    if (!K.replay(p)) { const dd = K.load(p); if (dd) { const s = K.qs(dd); s.shellLost = 0; s.shellBack = 1; K.save(p, dd); } }
    K.key(p, "k_shell");
    const eV4 = VALKA(K, p, true);
    await K.say(p, "ヴァルカ", ["{closed}……番人の 所へは、行くんだろうね。", "{closed,low}止めは しない。……けど、覚えときな。会わない ほうが いい 顔も ある。"]);
    K.act(eV4, 0); await K.leave(eV4, p, 12, false);
    await K.say(p, "マリン", ["{closed}……わたし、かあさんの 顔を 覚えて ないの。姉さんは 覚えてる。だから、あの 笛を 離せない。", "{angry,up}……でも、取りかえした。今度は わたしが 潜る。"]);
    K.pay(p, E5, 3000, [["e_blue", 1]]);
    await K.end(p, { leave: [eM4], card: "§7→ 嵐が 来る 前に、網元の 舟小屋へ（右上の 案内）", kind: "dusk" });
    return true;
  } };

/* ---------- 6話 嵐の前の舟小屋 ---------- */
const E6 = { id: "b07e6", pv: 127, t: "嵐の前の舟小屋", place: HUT, fac: "r6hut", F: ["F10"],
  hint: "§fコラリアの §e網元の 舟小屋§f へ 行こう §7（嵐の 前）",
  syn: "嵐の 前の 舟小屋で、ナギサは 母の 形見の 紐を マリンの ゴーグルに 結んだ。「三つ目ごとに 一つ 返す、ふしぎな 結び方」。",
  skip: (s) => { s.epx = { ...T(s.epx), storm6: 1 }; },
  async run(p, d, K) {
    const FH = fac(K, p, "r6hut", "boathut", 6, Y0(K, p));
    await K.open(p, "網元の 舟小屋（嵐の 前）", "dusk");
    const eH = K.hero(p);
    if (FH) await K.at(p, FH, 14, 6, 1.4);
    K.sound(p, "ambient.weather.rain", 0.6);
    const n = chOf(K, p, "c07") === "n";
    const eN = NAGI(K, p), eM = MARIN(K, p), eZ = zaza(K, p);
    await K.csay(p, "r6zaza", ["{closed}……風が 変わったっぺ。今夜は 舟は 出せねえ。"]);
    if (n) { K.act(eN, "hold"); await K.up(p, eN, 10); await K.narr(p, ["§7ナギサの 両手に、白い 包帯。"], eN); }
    await K.say(p, "ナギサ", ["{closed}マリン、ゴーグル 貸して。"]);
    K.act(eN, "work"); await K.push(p, eN, 20, 3, 1, 1.1);
    await K.narr(p, /*F10*/[n ? "§7包帯の 指で、ナギサは 手首の 紐を ほどき、マリンの ゴーグルの 帯に 結び直した。" : "§7ナギサは 手首の 紐を ほどき、マリンの ゴーグルの 帯に 結び直した。"], eN);
    await K.say(p, "ナギサ", ["{smile}かあさんの 形見の 紐。三つ目ごとに 一つ 返す、ふしぎな 結び方。", "{closed}潜る ときは、あなたが 持って いって。……わたしの 分も。"]);
    await K.say(p, "マリン", ["{sad,up}……姉さん。"]);
    await K.hsay(p, H4("{sad}……三つ目ごとに、一つ 返す。……だれかに 届く ように、かな。", "{sad}……返す 一目。だれかへの 印かしら。", "{closed}一つ 返す 結び目。意味が ありそう。", "{sad}一つ 返す 結び目……どなたかへの 合図でしょうか。"));
    await K.csay(p, "r6zaza", ["{closed}……ミナモも、その 結び方で 網を 繕っとったっぺ。だれに 教わったか、とうとう 言わなかったっぺ。"]);
    K.pay(p, E6, 800, [["c_herbs", 2]]);
    await K.end(p, { leave: [eZ], bye: [eN, eM], card: "§7→ ゴーグルと 貝笛を 持って §bマリノアの 沖§7へ。ブイの 下の 沈んだ 神殿の 前で 吹こう", kind: "night" });
    return true;
  } };

/* ---------- 7話 沖の沈んだ神殿（MQ15）---------- */
const diveAt = () => { try { return DIVE.at ? DIVE.at() : null; } catch { return null; } };
function statue(p, D) {   /* 神殿の 前に 珊瑚に 覆われた 石の 女（ワールドに 1回）*/
  try { if (world.getDynamicProperty("mrpg:epdeco:b7statue_d")) return; const x = Math.floor(D.x), y = Math.floor(D.B) + 1, z = Math.floor(D.z) + 6, dim = p.dimension;
    for (const c of [`fill ${x} ${y} ${z} ${x} ${y + 1} ${z} stone`, `setblock ${x} ${y + 2} ${z} brain_coral_block`, `setblock ${x - 1} ${y + 1} ${z} tube_coral_block`, `setblock ${x + 1} ${y} ${z} fire_coral_block`, `setblock ${x} ${y} ${z - 1} sea_lantern`]) dim.runCommand(c);
    world.setDynamicProperty("mrpg:epdeco:b7statue_d", 1); } catch {}
}
const E7 = { id: "b07e7", t: "沖の沈んだ神殿", battles: 1, F: ["F52", "F68"], keys: ["k_crest"],
  hint: "§fゴーグルを 持って §bマリノアの 沖§f へ。§e水面の ブイ§f の 下へ 潜り、§e沈んだ 神殿§f の 前で 海神の 貝笛を 吹こう",
  syn: "海の 底の 神殿の 番人「海ノ 誓イヲ 知ル者カ」。奥に、珊瑚に 覆われた 石の 女。両手が 笛を 口に あてる 形で、貝笛が ぴったり 合った。番人は 門を 閉じ、一行を 押し戻した。潮の 紋章を 託された。",
  async run(p, d, K) {
    const DV = diveAt(), deep = !!(DV && DV.B !== undefined);
    try { p.addEffect("water_breathing", 900, { showParticles: false }); } catch {}
    let SQ = null;
    if (deep) { statue(p, DV); SQ = { x: DV.x, y: DV.B + 2.5, z: DV.z + 6 }; K.camPt(p, { x: DV.x, y: DV.B + 8, z: DV.z + 10 }, 12, 4); await K.narr(p, ["§7マリンが 先に 潜り、あなたたちは その 泡を 追った。海の 底に、折れた 柱と 丸い 屋根の 神殿が 眠って いた。"]); }
    else { const L = fac(K, p, "b7statue", "b7statue", 6, Y0(K, p)); await K.open(p, "沖の 沈んだ 神殿", "day"); SQ = mk("b7statue", "hands", p) || L; }
    const eH = K.hero(p), eM = MARIN(K, p); K.hold(eM, "flute"); K.act(eM, "show");
    await K.up(p, eM, 10);
    await K.narr(p, ["§7マリンが 貝笛を 吹くと、低い 音が 柱の あいだを 渡って いった。"], eM); K.sound(p, "note.flute", 0.7);
    const q = SQ ? { x: SQ.x, y: SQ.y - 1.5, z: SQ.z - 3 } : K.fwd(p, 6);
    for (let k = 0; k < 4; k++) { K.burst(p.dimension, q, "minecraft:bubble_column_up_particle", 8, 0.6 + k * 0.4, 0); await K.wait(3); }
    K.big(p, "§3§l沈んだ 神殿の 番人", "§f貝笛の 音が 海の 底へ 響いた", "mob.elderguardian.curse");
    await K.narr(p, ["§7……神殿の 戸口から、大きな 影が 上がって くる。"], q);
    await K.say(p, "神殿の 番人", ["{closed,low}……海ノ 誓イヲ、知ル者カ。"]);
    await K.hsay(p, H4("{shock,!}……ち、誓い？ 知らない！ でも、話を 聞いて！", "{sad}……誓いは、知らないわ。でも……", "{closed}知らない。……通して。", "{shock}存じません。けれど、どうか……"));
    if (SQ) await K.push(p, SQ, 26, 6, 2.2, 0);
    await K.narr(p, /*F68*/["§7番人の 背の 奥に、珊瑚に 覆われた 石の 女が 立って いた。", "§7両手を 口元に あてて いる。……笛を 吹く 形の まま。"], SQ);
    const eM2 = MARIN(K, p, true); K.act(eM2, "hold");
    if (ok(eM2) && SQ) await K.approach(p, eM2, SQ, 1.2, 14);
    await K.narr(p, ["§7マリンが 貝笛を 近づけると、石の 手の 形に、ぴたりと 合った。"], SQ);
    await K.say(p, "マリン", ["{shock,…}……合う。この 笛、この 手の ために あるみたい。", "{sad,?}……あなた、だれ？"]);
    K.shake(p, 0.6, 0.8); K.sound(p, "mob.elderguardian.curse", 0.8);
    await K.say(p, "神殿の 番人", /*F52*/["{angry,low}……マダ、早イ。……門ヲ、閉ジル。"]);
    const res = await K.battle(p, K.bossOne(["aqua"], 52, 32), { name: "神殿の 番人", arena: "沈んだ 神殿", theme: "beach", hpk: 3.9, extra: 0.4, sboss: true, speaker: "神殿の 番人", guests: K.team(["aqua"], 50, 2).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "……海ノ 誓イヲ……", low: "……認メヨウ……陸ノ 子ヨ……" } });
    if (res !== "win") { await K.hsay(p, H4("{sweat,汗}押し戻された……。貝笛は まだ 使えるよ。", "{sweat}……押し戻されたわ。貝笛は まだ 使える。", "{closed}押し戻された。笛は まだ 使える。", "{sweat}押し戻されました……。貝笛は まだ 使えます。")); return false; }
    await K.narr(p, ["§7番人は 戦いを やめ、神殿の 門を 閉じた。石の 女は、門の 向こうに 見えなく なった。", "§7水が うねり、一行は 外へ 押し戻された。……手の 中に、潮の 形の 紋章が 一つ 残って いた。"], q);
    K.key(p, "k_crest");
    const eM3 = MARIN(K, p, true);
    await K.say(p, "マリン", ["{sad,up}……あの 人、ずっと 笛を 吹く 形で 待ってた。……だれを？", "{closed}紋章は、通って いい しるし だって。……でも 門は、閉じちゃった。"]);
    await K.hsay(p, H4("{sad}……また 来よう。きっと、また 開く。", "{sad}……いつか、また 来ましょう。", "{closed}また 来る。", "{sad}いつか、また 参りましょう。"));
    K.pay(p, E7, 18000, [["e_rainbow", 1], ["SEED3", 1], ["i_trpick", 1], ["tms_bird", 1]]);
    await K.say(p, "マリン", ["{angry,up}……港へ 帰ろう。わたし、マスターに なる。城で 待ってる。手加減 しないから！", "§7→ マリノアの 城（海神の 城ネプトゥナ）で 地方マスター マリンに 挑もう"]);
    await K.end(p, { leave: [eM3], kind: "day" });
    return true;
  } };

/* ---------- 8話 海神の城ネプトゥナ（マリンに 勝った あと）---------- */
const E8 = { id: "b07e8", t: "海神の城ネプトゥナ", place: PL("court", 6, "海神の 城 ネプトゥナ"), F: ["F34"],
  hint: "§fマリノア諸島の §6地方マスター マリン§f に 勝とう",
  syn: "マリンに 勝った。マリンは 笛を 胸に 抱いて 眠って いた。笛の 穴に、母の 紐の 切れ端が 詰まって いた。「おっとうの 顔、知らない」。",
  async run(p, d, K) {
    await K.open(p, "海神の 城 ネプトゥナ", "castle");
    const eH = K.hero(p), eM = MARIN(K, p); K.act(eM, "kneel");
    await K.say(p, "マリン", ["{sweat,息}……負けた。強いね。石板は、あなたたちに。"]);
    K.act(eM, "show"); K.hold(eM, "flute"); await K.push(p, eM, 22, 3.5, 1, 1.1);
    await K.narr(p, ["§7マリンの 笛の 穴に、色あせた 紐の 切れ端が 詰まって いる。"], eM);
    await K.say(p, "マリン", ["{closed}……昨日の 夜、この 笛を 胸に 抱いて 寝たの。そしたら、穴に これが。", "{sad}かあさんの 紐。……かあさんが 吹く とき、いつも ここに 結んでたって 姉さんが。"]);
    await K.hsay(p, H4("{?}……お父さんは？", "{?}……お父さまは？", "{?}父親は。", "{?}お父さまは……？"));
    await K.say(p, "マリン", /*F34*/["{closed,…}……おっとうの 顔、知らない。", "{sad}わたしに 名前を つける 前に、いなく なったって。名前は、かあさんが 一人で つけた。"]);
    await K.hsay(p, H4("{sad}……下の 子の 名前は、まだ 決めて ない……。サンドリアの 王さまの 話。", "{sad}……『下の 子の 名は まだ』……。どこかで 聞いた ような。", "{closed}……『下の 子の 名は まだ』。砂王の 話。", "{sad}『下の 子の 名は まだ』……砂王さまの お話と……"));
    await K.say(p, "マリン", ["{?}……え？"]);
    await K.hsay(p, H4("{sweat}……ううん、なんでも ない。手帳に 書いとく。", "{sweat}……いいえ、なんでもないの。", "{closed}……なんでもない。", "{sweat}いえ、なんでも ありません。"));
    await K.end(p, { bye: [eM], kind: "castle" });
    await letter(K, p, "セオ", ["（手紙）ネクロス冥府領への 道が 開きましたね。冥府に、どうしても 調べたい ものが あります。", "§e冥王の 城の 中庭§f で 会いましょう。……あなたに、話して おかなければ ならない ことも あります。"], "§fネクロス冥府領へ 行けるように なった");
    await K.say(p, "レイ", ["（手紙）セオから 前に もらった 研究メモの 写し。光に かざしたら、§e消し跡§f が あった。", "オレも 冥府へ 行く。先に 着いたら、勝手に 動くなよ。"]);
    await K.hsay(p, H4("{shock,!}……消し跡。わたしの 写しにも、あった。", "{shock,…}……消し跡。最初の メモにも、あったわね。", "{closed}……消し跡。最初から。", "{shock,!}消し跡……わたしの メモにも。"));
    return true;
  } };

/* ---------- 9話 コラリアの海神祭 ---------- */
const E9 = { id: "b07e9", t: "コラリアの海神祭", place: FEST,
  hint: "§fコラリアの §e港の 浜辺§f へ もどろう §7（海神祭）",
  syn: "ナギサが 浜で 百 数えた。「百。……満ちたよ」。そして 海神の 貝笛が 鳴った。",
  skip: (s) => { s.epx = { ...T(s.epx), fest6: 1 }; },
  async run(p, d, K) {
    await K.open(p, "コラリアの 港の 浜辺（海神祭）", "fest", "dusk");
    K.sound(p, "note.harp", 0.8);
    const n = chOf(K, p, "c07") === "n";
    const eH = K.hero(p), eN = NAGI(K, p), eM = MARIN(K, p), eZ = zaza(K, p);
    K.act(eN, "point"); await K.up(p, eN, 10);
    await K.say(p, "ナギサ", ["{closed}……九十八、九十九。", "{smile,up}百。……満ちたよ。"]);
    K.ambient(p, "fest", p.location);
    if (!n) {
      K.act(eN, "hold"); K.hold(eN, "flute"); await K.push(p, eN, 22, 4, 1.4, 1.2);
      await K.narr(p, ["§7ナギサが 貝笛を 吹いた。沖の 海が、青く 光った。"], eN); K.sound(p, "note.flute", 1);
      await K.csay(p, "r6zaza", ["{smile,tears}……おっかあの 吹き方、そっくりだっぺ。"]);
      await K.say(p, "ナギサ", ["{smile,up}……あなたの 相棒の おかげ。前足、まだ 痛む？"]);
      const g = K.palEnt(p); if (g) { K.camNear(p, g, 2.2, 0.7); await K.wait(8); } await K.pal(p, ["……へいき。ふえ、きれい。"]); K.rmCine(g);
    } else {
      K.act(eN, "hold"); await K.up(p, eN, 10);
      await K.narr(p, ["§7包帯の 手では、笛を 持てない。"], eN);
      await K.say(p, "ナギサ", ["{smile}マリン。……あなたが 吹いて。"]);
      K.act(eM, "show"); K.hold(eM, "flute"); await K.push(p, eM, 22, 4, 1.4, 1.2);
      await K.narr(p, ["§7マリンが、初めて 人前で 貝笛を 吹いた。沖の 海が、青く 光った。"], eM); K.sound(p, "note.flute", 1);
      await K.csay(p, "r6zaza", ["{smile,tears}……おっかあの 吹き方、そっくりだっぺ。"]);
      await K.say(p, "マリン", ["{blush}……姉さんの 音には、まだ 遠いけど。"]);
    }
    await K.hsay(p, H4("{smile,tears}……きれい。海が、こたえてる みたい。", "{smile,tears}……海が、聞いて いるみたい。", "{smile}……いい 音。", "{smile,tears}海が、答えて いるようです。"));
    K.pay(p, E9, 800, [["gift_candle", 1]]);
    await K.end(p, { leave: [eZ], bye: [eN, eM], card: "§f― 第7章 海神の 貝笛 おわり ―\n§7→ 次は ネクロス冥府領の 町 ソウラへ（右上の 案内）", kind: "night", t: 60 });
    return true;
  } };

bkAdd("b07", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ14 は 桟橋 → 夜の 浜 → 岬の 灯台（第125版で 貝笛を 取りかえして いれば 場面は とばす）*/
mqOver(14, null, { cond: async () => true });
mqOver(15, null, { cond: async () => true });
mqOver(16, null, { cond: async () => true });
