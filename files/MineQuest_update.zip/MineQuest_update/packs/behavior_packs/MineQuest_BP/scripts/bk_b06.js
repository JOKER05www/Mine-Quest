/* 第126版 本6「水晶の洞くつ」（クリスタリア・グロウ／アズール／プリズマ）— 作業 MB
   1 グロウ（r5e1）→ 2 古い坑道（r5e2）→ 3 アズール → 4 洞くつの入口（ガロ。r5e3 を 書きなおし: ガンテツは ここに いない）
   → MQ12: 5 晶洞の大広間（C06）・6 水晶の幻・7 ベリルと三つ巴 → MQ13: 8 水晶宮（ゴウに 勝った あと。r5e5 を まとめた）→ 9 グロウの夜（r5e6）*/
import { bkAdd, mqOver } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, facAt, facBuild, facMark, fac } from "./epfac.js";
import { townOut, placeOf, bldOf, openSite } from "./storyplace.js";
import { caveInfo, caveSite } from "./structures.js";
import { H4, Y0, chOf, did, oldRun, toSet, mk, letter, tOut, near, PL } from "./bk_b05.js";
import { ok } from "./ui.js";

const { F, S1 } = FAC_OPS;
const T = (s) => (s && typeof s === "object" ? s : {});
/* ---------- 施設 ---------- */
/* ゴウの 岩: 顔の ある 岩と、その 前に 並ぶ 薬の 瓶 */
facAdd("b6rock", { D: [11, 13], box: [-1, -3, 5, 3], H: 4, look: [3, 0, 1.2], marks: { rock: [4, 0, 1.2], bottles: [2, 0, 0.3] }, build: (P) => [
  F(4, -1, 0, 5, 1, 2, "stone"), S1(4, 0, 3, "cobblestone"), S1(3, -1, 1, "chiseled_stone_bricks"), S1(3, 1, 1, "chiseled_stone_bricks"), S1(3, 0, 0, "mossy_cobblestone"),
  S1(2, -2, 0, "brewing_stand"), S1(2, -1, 0, "flower_pot"), S1(2, 0, 0, "brewing_stand"), S1(2, 1, 0, "flower_pot"), S1(2, 2, 0, "brewing_stand"), F(0, -3, -1, 5, 3, -1, "calcite"), S1(5, 2, 0, "amethyst_cluster"),
] });
/* ボルトの 店先: 作業台・かぶとを 置いた 台 */
facAdd("b6bolt", { D: [10, 12], box: [-1, -3, 4, 3], H: 4, look: [2, 0, 1.1], marks: { helm: [2, 1, 1] }, build: (P) => [
  F(4, -3, 0, 4, 3, 3, "spruce_planks"), F(0, -3, 4, 4, 3, 4, "spruce_slab"), S1(2, 1, 0, "crafting_table"), S1(2, -1, 0, "grindstone"), S1(3, 2, 0, "barrel"), S1(3, -2, 2, "lantern"), S1(0, -3, 0, "spruce_fence"), S1(0, 3, 0, "spruce_fence"),
] });

/* ---------- 場所 ---------- */
const GLOW = () => bldOf("t33", ["plaza", "inn"], "ひかりごけの 村 グロウの 広場") || tOut("t33", "gl", 0.4, "坑道前の 広場")();
const AZUR = () => bldOf("t23", ["shop", "smith", "inn"], "あおい洞の 町 アズールの 道具屋") || tOut("t23", "az", 0.5, "アズールの 外れの 店先")();
const GATE = () => { let c = null; try { c = caveInfo(5) || caveSite(5); } catch {} return c ? { x: Math.floor(c.x), z: Math.floor(c.z) - 14, nm: "クリスタリアの 洞くつの 入口の 前" } : null; };
const GARO = (K, p, w = false) => K.npcNear(p, "§c顔を 布で 隠した 班長", K.PJ("garo", 9), w);
const MARIN = (K, p, w = false) => K.npcNear(p, "§3潜水士 マリン", K.PJ("marin", 9), w);
const MINI = (K, p, w = false) => [K.npcNear(p, "§c六影の 下っぱ ドスコ", K.PJ("noxa", 9), w), K.npcNear(p, "§c六影の 下っぱ ヒョロ", K.PJ("noxb", 9), w)];
/* 晶洞の 祭壇（曇った 水晶）。広間が あれば その 祭壇、なければ 水晶の 祭壇を 建てる */
function altar(K, p) {
  try { const v = caveInfo(5), S = K.S(p); if (S && v && v.altar && Math.hypot(v.altar.x - S.P.x, v.altar.z - S.P.z) < 16) return { x: v.altar.x, y: v.altar.y + 1, z: v.altar.z }; } catch {}
  const S = K.S(p); const a = facAt("r5altar", p.location, 60) || (S ? facBuild(p, S, "r5altar", "crysaltar", 5, Y0(K, p)) : null); const m = a && facMark("r5altar", "altar", p.location);
  return m ? { x: m.x, y: m.y + 1, z: m.z } : a;
}

/* ---------- 町の 人 ---------- */
castAdd("r5gantetsu", { nm: "ガンテツ", role: "鉱夫頭", gobi: "だべ", skin: "m6_crystal", town: "t33", from: "r5e1", at: near(GLOW, 3, -3),
  pre: ["{closed}……暗い 村だべ。足もと、気を つけるだべ。"],
  after: [
    [(s) => !!s.heroBack, ["{smile,☆}おお、二人 そろって 帰って きたべか！ ……こけが、いちばん 明るく 光っとるだべ。"]],
    [(s) => !!s.ending && (s.ch || {}).c06 === "t", ["{closed}……毎晩、牧場の 方の 道に 灯りを 一つ 置いとるだべ。あいつが いつ 通っても ええように。"]],
    [(s) => !!s.ending, ["{smile}三つ 掘ったら 一つ 返す。今じゃ 子どもでも 知っとる 決まりだべ。"]],
    [(s) => !!s.heroDead, ["{sad}空が 暗く なって、こけが また 弱って きたべ。……だども、灯りは 分けとるだべ。"]],
    [(s) => did(s, "b06e9") && (s.ch || {}).c06 === "t", ["{smile}こけが もどって、村が 明るく なったべ。", "{sad}……布で 顔を 隠しとっても、親友の せがれの 背中は わかるだべ。"]],
    [(s) => did(s, "b06e9"), ["{smile}こけが もどって、村が 明るく なったべ。", "{closed}……ドルガの せがれも、どこかで 生きとると ええだべ。"]],
    [() => true, ["{sad}コロが 見つかって、ほっと しただべ。……おらが、ちゃんと 見て やらにゃ。"]],
  ] });
castAdd("b6bolt", { nm: "ボルト", role: "道具屋", col: "§e", gobi: "だっちゃ", skin: "m6_pierre", town: "t23", hide: (s) => !did(s, "b06e3"), at: near(AZUR, 2, 2),
  pre: ["{smile}かぶと、磨くっちゃ？"],
  after: [
    [(s) => !!s.ending, ["{smile}あの ちっこい かぶと、まだ 棚の いちばん 上 だっちゃ。取りに 来る まで、毎朝 磨くっちゃ。"]],
    [() => true, ["{closed}……あいつ、昔は この かぶとを かぶって、坑道の 入口で 父ちゃんを 待っとったっちゃ。"]],
  ] });
castAdd("r5gou", { nm: "ゴウ", role: "地方マスター", col: "§6", gobi: "", skin: "gou", town: "t34", hide: (s) => !did(s, "b06e8"), at: () => { const q = placeOf("court", 5, true); return q ? { x: q.x + 3, y: q.y ?? undefined, z: q.z } : null; },
  pre: ["{closed}……勝負なら、城で。"],
  after: [
    [(s) => !!s.ending, ["{smile}岩が、一度だけ 目を 開けた 気が した。……薬の 瓶は、もう 買って いない。待つ ことに した。"]],
    [() => true, ["{closed}かけらを 売った 金で 買った 薬だ。……飲ませる 口も ない 岩に、毎日 並べて いる。"]],
  ] });

/* ---------- 1話 ひかりごけの村グロウ ---------- */
const E1 = { id: "b06e1", t: "ひかりごけの村グロウ", place: GLOW, fac: "r5glow",
  hint: "§fひかりごけの 村 §eグロウ§f へ 行こう §7（右上の 案内）",
  syn: "グロウは 昼でも 暗かった。鉱夫頭ガンテツは 掘りすぎを 悔やんで いた。家の 壁には グロウの 坑夫の 紋。息子の コロは「とうちゃんが こけを 殺した」と 叫んだ。",
  async run(p, d, K) {
    return oldRun(p, d, K, E1, 5, "r5e1", { post: async (p, K) => {
      const S = K.S(p), q = S ? S.at(6, 3 * S.side, 2) : null;
      if (q) { K.cmd(p, `setblock ${Math.floor(q.x)} ${Math.floor(q.y)} ${Math.floor(q.z)} chiseled_stone_bricks keep`); await K.push(p, q, 18, 4, 1.4, 0); }
      await K.narr(p, ["§7家の 壁に、つるはしと 水晶を 組んだ 紋が 刻まれて いる。グロウの 坑夫の 紋だ。"], q);
      await K.hsay(p, H4("{?}……この 紋、どこかで 見たような……。手帳に 描いとこ。", "{?}……坑夫の 紋。覚えて おくわね。", "{closed}……坑夫の 紋。覚えた。", "{?}……坑夫の 紋。記して おきます。"));
    } });
  } };
/* ---------- 2話 グロウの古い坑道 ---------- */
/* 第127版(fac): 古い 坑道は 村から 離れた 山肌（坑口・やぐら・ずり山・奥の 広間）*/
const MINE5 = () => { const c = townOut("t33", 0, "x"); return (c && openSite("r5mine", c, 5, 90, 450, "グロウの 先の 古い 坑道")) || tOut("t33", "mn", -1.4, "外れの 古い 坑道")(); };
const E2 = { id: "b06e2", t: "グロウの古い坑道", place: MINE5, fac: "r5mine", pv: 127,
  hint: "§fグロウの 外れの §e古い 坑道§f へ コロを さがしに 行こう",
  syn: "コロは 古い 坑道の 奥で、母が 子守唄を 歌った 場所の こけを 守って いた。",
  async run(p, d, K) { return oldRun(p, d, K, E2, 5, "r5e2"); } };

/* ---------- 3話 あおい洞の町アズール ---------- */
const E3 = { id: "b06e3", t: "あおい洞の町アズール", place: AZUR, fac: "b6bolt",
  hint: "§fあおい洞の 町 §eアズール§f の 道具屋へ 行こう",
  syn: "道具屋の ボルトは、小さな かぶとを 磨いて 待って いた。昔 グロウの 坑道の 入口で 父を 待って いた 子の かぶとだ。（記録の 断片）",
  async run(p, d, K) {
    const L = fac(K, p, "b6bolt", "b6bolt", 5, Y0(K, p));
    const eH = K.hero(p);
    await K.open(p, "あおい洞の 町 アズール", "day");
    if (L) await K.at(p, L, 14, 6, 1.2);
    K.sound(p, "block.grindstone.use", 0.6);
    const eB = K.cast(p, "b6bolt"); K.act(eB, "work");
    await K.csay(p, "b6bolt", ["{smile}いらっしゃい だっちゃ！ ……あ、それ 見とるっちゃね。"]);
    const hm = mk("b6bolt", "helm", p) || L; K.act(eB, "show"); K.hold(eB, "box");
    await K.push(p, hm || eB, 20, 4, 1.3, 1);
    await K.narr(p, ["§7台の 上に、子ども用の 小さな かぶと。ぴかぴかに 磨かれて、前に つるはしと 水晶の 紋。", "§7内側に、灰色の 染みが 一つ。拭いても 落ちない。（記録の 断片）"], hm);
    await K.csay(p, "b6bolt", ["{closed}グロウの 坑夫の せがれの かぶと だっちゃ。坑道が 崩れた 朝、入口に 落ちとったっちゃ。", "{sad}あいつ、一人で 村を 出ちまって。……取りに 来たら 渡すって、毎朝 磨いとるっちゃ。"]);
    await K.hsay(p, H4("{?}……その 子、名前は？", "{?}……その 子の 名前は？", "{?}名前は。", "{?}その お子さんの お名前は？"));
    await K.csay(p, "b6bolt", ["{smile,汗}それが、本人が『その 名で 呼ぶな』って 言うっちゃ。……笑っちまうっちゃ、ちっこい くせに。"]);
    await K.hsay(p, H4("{smile}……ちゃんと、取りに 来るといいね。", "{smile}……いつか、取りに 来て くれると いいわね。", "{closed}……来ると いいな。", "{smile}いつか、取りに いらっしゃると よいですね。"));
    await K.csay(p, "b6bolt", ["{smile}そう だっちゃ。……洞くつに 行くなら、入口の 連中に 気を つけて。最近、変な 班長が 仕切っとるっちゃ。"]);
    K.pay(p, E3, 500, [["mei_crys", 1]]);
    await K.end(p, { leave: [eB], card: "§7→ クリスタリアの 洞くつの 入口へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 4話 洞くつの入口（ガロ）---------- */
const E4 = { id: "b06e4", t: "洞くつの入口", place: GATE, battles: 1, F: ["F18", "F19"],
  hint: "§fクリスタリアの §e洞くつの 入口の 前§f へ 行こう §7（水晶を 運び出す 者たちが いる）",
  syn: "洞くつの 入口で、顔を 布で 隠した 六影の 班長に 会った。腰に グロウの 紋の 坑夫帽。「おやじが 埋まったのは、灰の 降った 冬だ」。ガロだった。",
  skip: (s) => { s.epx = { ...T(s.epx), garo5: 1 }; },
  set: { garo5: 1 },
  async run(p, d, K) {
    const FC = fac(K, p, "r5camp", "cryscamp", 5, Y0(K, p));
    const eH = K.hero(p);
    await K.open(p, "クリスタリアの 洞くつの 入口", "day");
    if (FC) await K.at(p, FC, 14, 6, 1.2);
    K.sound(p, "block.amethyst_block.chime", 0.8);
    const [eA, eB] = MINI(K, p); K.act(eA, "hold"); K.act(eB, "hold");
    await K.two(p, eA, eB, 12);
    await K.say(p, "ドスコ", ["{smile}よいしょ、よいしょ。今日も 水晶 どっさりだぜ。"]);
    await K.say(p, "ヒョロ", ["{sweat,汗}兄貴、奥の 潜水士の 女、どう します？ ずっと にらんで くるんすよ……。"]);
    const eG = GARO(K, p); K.act(eG, "arms");
    await K.low(p, eG, 14);
    await K.say(p, "班長", ["{closed,low}……しゃべりすぎだ。運べ。"]);
    await K.hsay(p, H4("{shock,!}……その 声。ガロ！？", "{shock,…}……その 声、ガロさん？", "{closed}……ガロ。布で 隠しても、声で わかる。", "{shock,!}その お声……ガロさん、ですか？"));
    await K.say(p, "ガロ", ["{closed,low}……ちっ。班長 なんて 名ばかりさ。ルミナで お前に 負けて、こんな 穴ぐらに 飛ばされた。"]);
    const cap = chOf(K, p, "c01") !== "k";
    K.act(eG, "show"); await K.push(p, eG, 22, 3.5, 0.9, 0.9);
    await K.narr(p, /*F18*/ cap ? ["§7ガロの 腰に、二つの 帽子。つるはしと 水晶の 紋の 古い 坑夫帽と、小さな 帽子。"] : ["§7ガロの 腰に、つるはしと 水晶の 紋の 古い 坑夫帽が 一つ。"], eG);
    await K.hsay(p, H4("{?}……その 紋、グロウの 家の 壁と 同じ……。", "{?}……グロウの 家の 壁の 紋と、同じだわ。", "{closed}……グロウの 紋。", "{?}グロウの お家の 壁の 紋と、同じです。"));
    if (cap) await K.hsay(p, H4("{sad}……小さい 方は、ピコくんの。", "{sad}……小さい 帽子、ピコくんのね。", "{closed}……小さい 方は ピコの。", "{sad}小さい 方は、ピコさんの……"));
    await K.say(p, "ガロ", /*F19*/["{closed,low}……おやじの だ。坑夫だった。", "{sad,low}おやじが 埋まったのは、灰の 降った 冬だ。……オレは 十二で 村を 出た。"]);
    await K.say(p, "ガロ", ["{angry,low}水晶を 運び出す まで、ここは 通さねえ。……ドスコ、ヒョロ。立ってる だけで いい。"]);
    K.act(eA, "guard"); K.act(eB, "guard"); K.act(eH, "guard");
    const r = await K.battle(p, K.team(["golem", "nether", "animal"], 41, 3, 8), { name: "六影の 下っぱ ドスコと ヒョロ", arena: "洞くつの 入口", theme: "crystal", speaker: "ドスコ", lines: { half: "立ってる だけって 言ったのに！", low: "は、班長ぉ……" } });
    if (r !== "win") { await K.sayAt(p, "§c顔を 布で 隠した 班長", K.PJ("garo", 9), "ガロ", ["{closed}……帰れ。", K.RT(p)]); return false; }
    const [a2, b2] = MINI(K, p, true); K.act(a2, "down"); K.act(b2, "kneel");
    const eG2 = GARO(K, p, true);
    await K.say(p, "ガロ", ["{closed,low}……もう いい。お前ら、水晶を 奥へ 運べ。", "{sad}……ピコは、まだ 眠ってる。命令書に あった。石板を 集めれば、呑まれた 心も 戻ると。"]);
    await K.bye(p, a2, b2);
    await K.say(p, "ガロ", ["{angry,low}奥へは 来るな。……来たら、今度は オレが 相手だ。"]);
    K.act(eG2, 0); await K.leave(eG2, p, 10, false);
    await K.hsay(p, H4("{angry,up}……奥に 捕まってる 人が いる。行こう！", "{closed,up}……奥の 潜水士さん、助けなきゃ。", "{closed}行く。奥に 捕まってる 人が いる。", "{closed,up}奥の 潜水士さんを、お助け しましょう。"));
    K.pay(p, E4, 500, [["mei_crys", 1]]);
    await K.end(p, { card: "§7→ 洞くつの 坂道を 下りきった §e奥の 晶洞の 大広間§7へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 5話 晶洞の大広間（C06）---------- */
const E5 = { id: "b06e5", t: "晶洞の大広間（アジト）", F: ["F18"],
  hint: "§fクリスタリアの §e水晶の 洞くつ§f の §e奥の 晶洞の 大広間§f へ",
  syn: "広間で ガロの 部下たちが 潜水士マリンを 捕まえて いた。ガロは「通して やる。代わりに、ここで 見た ことは グロウで 言うな」と 言った。",
  async run(p, d, K) {
    await K.open(p, "晶洞の 大広間", "cave");
    const eH = K.hero(p), eM = MARIN(K, p, true); K.act(eM, "kneel");
    const eG = GARO(K, p), [eA, eB] = MINI(K, p);
    await K.say(p, "マリン", ["{cry,!,up}……助けて！ わたしは マリノアの 潜水士、マリン。", "{sad}水晶を 運ぶ 船を 出せって 言われて、断ったら ここまで 連れて こられたの。"]);
    await K.hsay(p, H4("{rage,怒}ガロ！ その 人を 放して！", "{angry}……ガロさん。その 人を 放して。", "{angry}ガロ。放せ。", "{angry}ガロさん！ その方を お放し ください！"));
    K.act(eG, "arms"); await K.up(p, eG, 12);
    await K.say(p, "ガロ", /*F18*/["{closed,low}……通して やる。潜水士も 放す。奥も 好きに しろ。", "{angry,low}代わりに、ここで 見た ことは §eグロウで 言うな§f。……オレの 顔の ことも、紋の ことも。"]);
    await K.hsay(p, H4("{?}……グロウの ガンテツさん、ずっと さがしてるよ。", "{sad}……グロウの 人たち、あなたを 待って いるのよ。", "{closed}……グロウで 待ってる 人が いる。", "{sad}グロウの 方々が、お待ちです。"));
    await K.say(p, "ガロ", ["{sad,low}……だから 言うなって 言ってんだ。"]);
    const c = await K.pick(p, "c06");
    if (c === "k") {
      await K.hsay(p, H4("{closed}……わかった。言わない。", "{closed}……分かったわ。言わない。", "{closed}言わない。", "{closed}……承知 いたしました。申しません。"));
      await K.say(p, "ガロ", ["{closed}……借りじゃ ねえ。取り引きだ。", "{closed,low}ドスコ、ヒョロ、潜水士を 放せ。行くぞ。"]);
      K.act(eM, 0); await K.bye(p, eA, eB); K.act(eG, 0); await K.leave(eG, p, 12, false);
    } else {
      await K.hsay(p, H4("{angry,up}……言うよ。ガンテツさんに。待ってる 人に、黙ってられない！", "{sad,up}……ごめんなさい。待って いる 人に、黙っては いられない。", "{closed}言う。待ってる 人が いるから。", "{sad,up}申し訳 ありません。お待ちの 方に、黙っては おけません。"));
      K.re(eG, "angry", "怒");
      await K.say(p, "ガロ", ["{angry,low}……そうかよ。なら、ここは 通さねえ。ドスコ、ヒョロ！"]);
      K.act(eA, "guard"); K.act(eB, "guard"); K.act(eH, "guard");
      const r = await K.battle(p, K.team(["golem", "nether", "animal"], 42, 3, 10), { name: "六影 班長 ガロと 部下たち", arena: "晶洞の 大広間", theme: "cave", speaker: "ガロ", lines: { half: "……言うなって 言ったろ！", low: "……くそっ" } });
      if (r !== "win") { await K.sayAt(p, "§3潜水士 マリン", K.PJ("marin", 9), "マリン", ["{sweat,汗}……一度 引いて。また 来て。", K.RT(p)]); return false; }
      const [a2, b2] = MINI(K, p, true), eG2 = GARO(K, p, true); K.act(eG2, "kneel");
      const eT = K.cast(p, "r5gantetsu"); K.act(eT, "run", false); await K.wait(10); K.act(eT, 0);
      await K.csay(p, "r5gantetsu", ["{shock,!,up}……広間で 戦の 音が するって、坑夫が……！", "{shock,…}……その 背中。その 腰の 坑夫帽。……ドルガの……"], eG2);
      await K.two(p, eT, eG2, 12);
      await K.say(p, "ガロ", ["{closed,low}……人ちがいだ、おやっさん。"]);
      K.act(eG2, 0); await K.leave(eG2, p, 12, true); await K.bye(p, a2, b2);
      await K.csay(p, "r5gantetsu", ["{cry,tears}……逃げる 足の 速さまで、おやじに そっくりだべ。", "{closed}……知らせて くれて、ありがとうだべ。"]);
      await K.leave(eT, p, 10, false);
    }
    K.act(eM, "raise");
    await K.say(p, "マリン", ["{smile}……ありがとう。奥に、だれかが 水晶を 集めてる 祭壇が あるの。……いっしょに 来て。"]);
    return true;
  } };

/* ---------- 6話 晶洞の奥（水晶の 幻）---------- */
const E6 = { id: "b06e6", t: "晶洞の奥（水晶の幻）", F: ["F40"],
  hint: "§f晶洞の 奥の 祭壇へ",
  syn: "曇った 水晶に 幻が 映った。石に なった 町、止まった 噴水、本の 看板の 家。灰が 降って いた。",
  async run(p, d, K) {
    const q = altar(K, p);
    if (!K.S(p) || !q) await K.open(p, "晶洞の 奥", "cave");
    const eH = K.hero(p), eM = MARIN(K, p);
    if (q) { await K.push(p, q, 22, 5, 2, 0.4); for (let k = 0; k < 4; k++) { K.burst(p.dimension, q, "minecraft:portal_reverse_particle", 8, 0.7, 0); await K.wait(3); } }
    K.big(p, "§d§l水晶の 幻", "§f曇った 水晶に 何かが 映る", "block.amethyst_block.chime");
    await K.narr(p, /*F40*/["§7水晶の 中に、町が 映る。石だたみ、噴水、人も 犬も……灰色の 石に なって 止まって いる。", "§7空から、灰が 降って いる。"], q);
    await K.hsay(p, H4(["{shock,!,up}……人も、噴水の しぶきまで、石に なって 止まってる。"], ["{shock,…}……町ごと、石に なってる。"], ["{closed}……町が 全部 石。"], ["{shock,!}町ごと……石に なって います。"]));
    if (q) await K.at(p, { x: q.x, y: q.y + 0.6, z: q.z }, 16, 1.8, 0);
    await K.narr(p, ["§7通りの 角に、本の 形の 看板を 下げた 家。窓辺に、小さな 灯り。"], q);
    await K.hsay(p, H4(["{?}……本の 看板の 家。学者さんの 家、かな。", "{closed}メモしとこ。『石の 町・本の 看板の 家・灰』。"], ["{?}……本の 看板の 家。", "{closed}書き留めて おくわ。『石の 町・本の 看板・灰』。"], ["{closed}本の 看板。メモ。『石の 町・本の 看板・灰』。"], ["{?}本の 看板の お家……", "{closed}記して おきます。『石の 町・本の 看板・灰』。"]));
    await K.say(p, "マリン", ["{sad,…}……この 町、どこに あるんだろう。海の 向こう？ 山の 奥？"]);
    if (q) { K.camPt(p, q, 4, 0.5); await K.shadowFlow(p, q, p.location, 14); }
    K.shake(p, 0.5, 0.5);
    await K.hsay(p, H4("{shock,!}水晶から 影が あふれて くる！", "{shock}……影が……！", "{closed}影。来る。", "{shock,!}影が あふれて きます！"));
    return true;
  } };

/* ---------- 7話 晶洞の奥（ベリルと 三つ巴）---------- */
const E7 = { id: "b06e7", t: "晶洞の奥（ベリル）", battles: 1, F: ["F17"], keys: ["k_goggle"],
  hint: "§f晶洞の 奥の 祭壇で",
  syn: "影を 箱に 封じに 来た ベリルと、マリンと、三つ巴に なった。ヴァルカが 迎えに 来て「座に 載るのは、知る 者だけだ。アンタは、載らなくて いい」。ベリルの 肩が 落ちた。マリンは 潜水ゴーグルを くれた。",
  async run(p, d, K) {
    const q = altar(K, p);
    if (!K.S(p)) await K.open(p, "晶洞の 奥", "cave");
    const eH = K.hero(p), eM = MARIN(K, p), eB = K.npcNear(p, "§5六影 ベリル", K.PJ("beryl", 9));
    if (q) { K.burst(p.dimension, q, "minecraft:endrod", 14, 0.8, 0.05); K.sound(p, "block.amethyst_block.break", 0.8); }
    await K.say(p, "ベリル", ["{closed}……動かないで。影は この 箱に 封じる。", "{angry}わたしの 任務は、この 洞くつの §d曇った 水晶§f を 集める こと。その 水晶から 離れて。"]);
    await K.say(p, "マリン", ["{angry,!}……水晶を 運ぶ 船の 話も、あなたたちね。もう 好きには させない！"]);
    await K.hsay(p, H4("{?}……ちょっと 待って、三人で にらみ合ってる 場合じゃ……！", "{sad}……三人とも、待って……！", "{closed}……三つ巴。めんどう。", "{sweat}み、皆さん、落ち着いて……！"));
    await K.sixMark(p, eB, "beryl");
    const r = await K.battle(p, K.team(["beast", "blob", "golem"], 45, 3, 36), { name: "六影 ベリル", arena: "晶洞の 奥", theme: "crystal", hpk: 5, extra: 0.3, sboss: true, speaker: "ベリル", guests: K.team(["aqua"], 43, 1).map((t) => ({ ...t, owner: "マリン" })), lines: { half: "二対一……それでも、引けない！", low: "……どうして、いつも こうなの……" } });
    if (r !== "win") { await K.sayAt(p, "§5六影 ベリル", K.PJ("beryl", 9), "ベリル", ["……また 来る。", K.RT(p)]); return false; }
    const eB2 = K.npcNear(p, "§5六影 ベリル", K.PJ("beryl", 9), true); K.act(eB2, "kneel");
    await K.say(p, "ベリル", ["{sad,…}……また、だめ。", "{sad,low}……座の わたしの 行は、まだ 白紙。", "{closed,up}石板を 持って きたら、わたしの 名前を 座に 書いて もらえるの。……一座が あった ことも、だれかが 覚えて いて くれる。"]);
    const eV = K.npcNear(p, "§c六影 ヴァルカ", K.PJ("valka", 10));
    await K.say(p, "ヴァルカ", ["{closed,low}……水晶は もう じゅうぶんだ。のこりは 山へ 返しな。", "{closed}ベリル、帰るよ。"]);
    await K.say(p, "ベリル", ["{sad,up}……ヴァルカさま。わたしの 名前、座に……"]);
    await K.up(p, eV, 12);
    await K.say(p, "ヴァルカ", /*F17*/["{closed}……座に 載るのは、§e知る 者§f だけだ。", "{sad,low}アンタは、載らなくて いい。"]);
    K.act(eB2, "sad"); await K.push(p, eB2, 20, 3.5, 1.6, 1.2);
    await K.narr(p, ["§7ベリルの 肩が、すとんと 落ちた。声は 出さなかった。"], eB2);
    await K.leave(eB2, p, 12, false); await K.leave(eV, p, 12, false);
    await K.hsay(p, H4("{angry}……『載らなくて いい』って、ひどくない？", "{sad}……あんな 言い方、ないわ。", "{closed}……冷たい 言い方。", "{sad}あんまりな お言葉です。"));
    await K.say(p, "マリン", ["{closed}……そうかな。追い返す 人の 顔に 見えなかった。", "{sad}海で 子どもを 岸へ 押し返す ときの 顔。……姉さんが、わたしに よく する 顔だよ。"]);
    K.act(eM, "hold"); K.hold(eM, "goggles"); await K.give(eM, eH, "goggles");
    await K.say(p, "マリン", ["{smile,☆}お礼に、わたしの 予備の §6潜水ゴーグル§f を。深い 海でも 目が 利く。", "{up}マリノアの 港の 桟橋で 待ってる。姉さんにも、会って ほしい。"]);
    K.key(p, "k_goggle");
    K.pay(p, E7, 9000, [["e_blue", 1], ["i_inherit", 1], ["tms_aqua", 1]]);
    await K.end(p, { leave: [eM], card: "§7→ クリスタリアの 城（水晶宮プリズマ）で 地方マスター ゴウに 挑もう", kind: "cave" });
    return true;
  } };

/* ---------- 8話 水晶宮プリズマ（ゴウに 勝った あと）---------- */
const E8 = { id: "b06e8", t: "水晶宮プリズマ", place: PL("court", 5, "水晶宮 プリズマの 中庭"),
  hint: "§fクリスタリアの §6地方マスター ゴウ§f に 勝とう",
  syn: "ゴウに 勝つと、宮の 奥に 顔の ある 岩が あった。岩の 前に、薬の 瓶が 並んで いた。石板の かけらを 売った 金で 買った 薬だった。ゴウは「掘った 水晶の 三つに 一つは 山へ 返せ」と 教えた。",
  skip: (s) => { s.epx = { ...T(s.epx), gou5: 1 }; },
  async run(p, d, K) {
    const L = fac(K, p, "b6rock", "b6rock", 5, Y0(K, p));
    const eH = K.hero(p);
    await K.open(p, "水晶宮 プリズマ", "castle"); const eGo = K.cast(p, "r5gou"); K.act(eGo, "hold");
    await K.csay(p, "r5gou", ["{closed}……強いな。石板は 渡す。……その 前に、見て ほしい ものが ある。"]);
    const rk = mk("b6rock", "rock", p) || L, bt = mk("b6rock", "bottles", p) || L;
    if (rk) await K.push(p, rk, 24, 7, 3.4, 1.4);
    await K.narr(p, ["§7宮の 奥に、人の 顔の ような くぼみの ある 岩。"], rk);
    if (bt) await K.at(p, bt, 16, 3.6, 1.4);
    await K.narr(p, ["§7岩の 前に、薬の 瓶が ずらりと 並んで いる。どれも、封を 切って いない。"], bt);
    await K.csay(p, "r5gou", ["{sad,up}……岩の 子だった。俺の 相棒だ。", "{closed}ある 朝、本当の 岩に なって いた。……薬代に、石板の かけらを 売った。その 金で、薬を 買った。毎日 一つ。"]);
    await K.hsay(p, H4("{sad}……飲ませられないのに？", "{sad}……飲めないのに、毎日？", "{closed}……飲めない 薬を。", "{sad}お飲みに なれないのに、毎日……"));
    await K.csay(p, "r5gou", ["{closed}並べて いると、返事を 待って いられる。", "{smile,息}……グロウの 話は 聞いた。鉱夫頭に 伝えて くれ。掘った 水晶の 三つに 一つは、山へ 返せ。石は 光を 貯める。こけに 分けて くれる。"]);
    await K.end(p, { bye: [eGo], kind: "castle" });   /* 第128版: ガンテツと コロは 城に 来ない（言づては 9話 グロウで）*/
    await letter(K, p, "マリン", ["（手紙）マリノア諸島への 道が 開いたね。", "コラリアの 港で 待ってる。姉さんは 毎朝、§e港の 桟橋§f で 海に 向かって 数を 数えてるよ。"], "§fマリノア諸島へ 行けるように なった");
    return true;
  } };

/* ---------- 9話 グロウ（夜）---------- */
const E9 = { id: "b06e9", t: "グロウ（夜）", place: GLOW, fac: "r5glow",
  hint: "§fグロウの §e広場§f へ もどろう §7（ひかりごけが もどる）",
  syn: "こけが 光った。ガンテツは「あいつが 帰る 場所は、明るく して おく」と 言った。",
  skip: (s) => { s.epx = { ...T(s.epx), moss5: 1 }; },
  async run(p, d, K) {
    const t = chOf(K, p, "c06") === "t";
    return oldRun(p, d, K, E9, 5, "r5e6", { pre: async (p, K) => { K.hero(p); K.cast(p, "r5gantetsu"); K.cast(p, "r5lulu"); }, swap: (p, id, L) => (id === "r5gantetsu" && L.some((x) => /ガロ/.test(x)) ? (t ? ["{closed}……布で 顔を 隠しとっても、わかっただべ。あいつは、生きとった。", "{smile,up}あいつが 帰る 場所は、明るく して おくだべ。"] : ["{closed}……ドルガの せがれも、どこかで この 光を 見とると ええだべ。", "{smile,up}いつか 帰るなら、明るく して おくだべ。"]) : L) });
  } };

bkAdd("b06", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ13: ゴウに 勝った あと（水晶宮）。古い 話（r5e5）を 済ませた セーブは 場面を とばし、石板の 段の 条件（勝った こと）だけ */
mqOver(13, null, { cond: async () => true });
