/* 第126版 本17「最後のライバル」（セレスティア・雲の島）— 作業 ME
   分かる: 影は ルミナの 方角へ 降りて いった。レイは「選ばれる」のを やめ、自分で 選ぶ。 問い: ルミナで 何が 待って いるのか（→本18 qb171）
   引きとった 古い 話: r10e4（レイの 理由）→ b17e1、r10e5（門番の 旅）→ b17e8（ゴンザは 島へ 来ない。鳥便だけ）。MQ23（最後の 勝負）→ b17e5・b17e6（mqOver）
   場所: 雲の 島の 小屋（r10hut・r10fire）／島の 村（b17vil）／祠（b17hokora）／島の 森（b17grove）／島の 端（r10edge = cloudedge。今日の セットを そのまま）／港（b17port）
   ここに 本17〜20 で 使う 小さな 道具（ME）も 置く */
import { world, system } from "@minecraft/server";
import { bkAdd, mqOver } from "./bkeng.js";
import { castAdd, CAST } from "./cast.js";
import { facAdd, FAC_OPS } from "./epfac.js";
import { TOWNS, getTown, townPos } from "./structures.js";
import { ok } from "./ui.js";
import { load, save } from "./store.js";
import { qs } from "./quest.js";
import { SPECIES, ORDER } from "./data.js";
import { __r10 } from "./ep_r10.js";

/* ---------- ME: 本17〜20 の 道具 ---------- */
export const J = (k) => { try { return JSON.parse(world.getDynamicProperty(k) || "null"); } catch { return null; } };
export const MK = (v, n) => { const m = v && v.m && v.m[n]; return m ? { x: m[0], y: m[1], z: m[2] } : null; };
/* 小さな セット（町の そば など facBuild が 建てない 所）。舞台の 前 D マスに 1回だけ。ops = [a0,b0,h0, a1,b1,h1, ブロック, モード?] */
export function setB(K, p, key, ops, o = {}) {
  const k = `mrpg:epdeco:${key}at`, v0 = J(k);
  if (v0 && Array.isArray(v0.o) && Math.hypot(v0.o[0] - p.location.x, v0.o[2] - p.location.z) < (o.R || 80)) return v0;
  const S = K.S(p); if (!S || !S.f) return null;
  const f = Math.abs(S.f.x) >= Math.abs(S.f.z) ? { x: Math.sign(S.f.x) || 1, z: 0 } : { x: 0, z: Math.sign(S.f.z) || 1 };
  const c = S.at(o.D ?? 6, o.side || 0), O = { x: Math.floor(c.x), y: Math.floor(S.P.y) + (o.dy || 0), z: Math.floor(c.z) };
  const W = (a, b) => ({ x: O.x + a * f.x - b * f.z, z: O.z + a * f.z + b * f.x });
  for (const op of ops) { const [a0, b0, h0, a1, b1, h1, bl, m] = op; const p0 = W(a0, b0), p1 = W(a1, b1); K.cmd(p, `fill ${p0.x} ${O.y + h0} ${p0.z} ${p1.x} ${O.y + h1} ${p1.z} ${bl}${m ? ` ${m}` : ""}`); }
  const lk = W(...(o.look || [2, 0])), v = { x: lk.x + 0.5, y: O.y + 1, z: lk.z + 0.5, o: [O.x, O.y, O.z], f: [f.x, f.z], m: {} };
  for (const [n, [a, b, h]] of Object.entries(o.marks || {})) { const q = W(a, b); v.m[n] = [q.x + 0.5, O.y + h, q.z + 0.5]; }
  try { world.setDynamicProperty(k, JSON.stringify(v)); } catch {}
  return v;
}
export const sOf = (p) => { try { return qs(load(p) || {}); } catch { return {}; } };
export const setS = (p, fn) => { const d = load(p); if (!d) return; try { fn(qs(d)); } catch {} save(p, d); };
export const REI = (K, p, still = false) => K.npcNear(p, "§bレイ", 17, still);
export const ORDO = (K, p, still = false) => K.npcNear(p, "§eオルド", K.PJ("ordo", 8), still);
export const NP = (K, p, nm, skin, still = false, d = 8) => K.npcNear(p, nm, K.PJ(skin, d), still);
export const HAKU_SP = () => (SPECIES.hbea14 ? "hbea14" : SPECIES.hbea01 ? "hbea01" : ORDER[0]);
export const DRAG_SP = () => (SPECIES.hdra12 ? "hdra12" : ORDER.find((x) => SPECIES[x].fam === "dragon" && SPECIES[x].sz === "L" && !SPECIES[x].hidden) || ORDER[0]);
export const fade = async (K, p) => { K.cmd(p, "camera @s fade time 0.3 0.45 0.4 color 0 0 0"); await K.wait(10); };
export const fin = async (K, p, o) => { await K.end(p, o); K.cmd(p, "fog @s remove mq_shadow"); K.cmd(p, "fog @s remove mq_six"); };
/* 印の 点が 舞台の そば（同じ 高さ・maxd マス 以内）なら それ、なければ 舞台の 前 */
export const nearM = (K, p, v, n, a = 4.5, b = 0, maxd = 7) => { const m = MK(v, n), S = K.S(p), P = S ? S.P : p.location; return m && Math.hypot(m.x - P.x, m.z - P.z) <= maxd && Math.abs(m.y - P.y) < 2.5 ? m : K.fwd(p, a, b); };
/* 戦いの あとは 役者が 入れかわる ことが ある（同じ 名前の 人を 拾いなおす）*/
export const again = (K, p, e, nm, job) => (ok(e) ? e : K.npcNear(p, nm, job, true));
/* 向き: a を b へ、b を a へ（b が 点なら a だけ）。toP: プレイヤーへ */
export const face = (K, a, b) => { const B = b && (b.location || b); const A = a && a.location; if (ok(a) && B) K.turn(a, B); if (b && b.location && ok(b) && A) K.turn(b, A); };
export const toP = (K, p, e) => { if (ok(e)) K.turn(e, p.location); };
export const Yof = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
/* 町の 人の その後（前の 章の 人の after の 先頭に 足す。同じ 行を 二度 足さない。ほかの ファイルが あとから castAdd しても 足し直す）*/
const AFTER = [];
function apply1(id, rows) { const c = CAST[id]; if (!c) return; const S = c._me || (c._me = new Set()); if (S.has(rows)) return; S.add(rows); c.after = [...rows, ...(c.after || [])]; }
export function afterAdd(id, rows) { AFTER.push([id, rows]); apply1(id, rows); }
try { system.runTimeout(() => { for (const [id, rows] of AFTER) apply1(id, rows); }, 40); } catch {}
/* ルミナ */
export const LUM = () => { const t = TOWNS.find((u) => u.id === "t0"); if (!t) return null; const g = getTown("t0"); return g && g.built ? { x: g.x, y: g.y, z: g.z } : townPos(t); };
export const SOUTH = () => { const c = LUM(); return c ? { x: Math.floor(c.x), z: Math.floor(c.z) + 40, nm: "ルミナの 南の 入口" } : null; };

/* ---------- 場所（セレスティア）---------- */
const { ISLE, ISLE_ROAD, HUT } = __r10;
const lerp = (a, b, t, side = 0) => { if (!a || !b) return a || b; const dx = b.x - a.x, dz = b.z - a.z, n = Math.hypot(dx, dz) || 1; return { x: Math.floor(a.x + dx * t - (dz / n) * side), z: Math.floor(a.z + dz * t + (dx / n) * side) }; };
const VIL = () => { const q = lerp(ISLE_ROAD(), ISLE(), 0.55, 14); return q ? { x: q.x, z: q.z, nm: "雲の 島の 村" } : null; };
const HOK = () => { const q = lerp(ISLE_ROAD(), ISLE(), 0.75, -16); return q ? { x: q.x, z: q.z, nm: "雲の 島の 祠" } : null; };
const GROVE = () => { const q = lerp(ISLE_ROAD(), ISLE(), 0.35, -14); return q ? { x: q.x, z: q.z, nm: "雲の 島の 森" } : null; };
const PORT = () => { const q = lerp(ISLE_ROAD(), ISLE(), 0.15, 20); return q ? { x: q.x, z: q.z, nm: "雲の 島の 港" } : null; };
const { F, S1 } = FAC_OPS;
/* 島の 村: 小さな 家 二つと 井戸と 柵（約 170 ブロック）*/
facAdd("skyvillage", { D: [10, 12, 9], box: [-1, -6, 7, 6], H: 5, look: [3, 0, 1.2], marks: { well: [3, 0, 0.5], door: [5, -3, 0], pen: [1, 4, 0] }, build: (P) => [
  F(4, -6, 0, 7, -3, 2, P.plank, "hollow"), F(4, -6, 3, 7, -3, 3, P.slab), S1(5, -3, 0, "air"), S1(5, -3, 1, "air"), S1(6, -3, 1, "glass_pane"),
  F(4, 3, 0, 7, 6, 2, P.plank, "hollow"), F(4, 3, 3, 7, 6, 3, P.slab), S1(5, 3, 0, "air"), S1(5, 3, 1, "air"),
  F(2, -1, 0, 4, 1, 0, P.wall), S1(3, 0, 0, "water"), F(2, -1, 1, 2, -1, 2, P.fence), F(4, 1, 1, 4, 1, 2, P.fence), F(2, -1, 3, 4, 1, 3, P.slab),
  F(0, 2, 0, 0, 6, 0, P.fence), F(0, 2, 0, 2, 2, 0, P.fence), S1(1, 5, 0, "hay_block"), S1(0, -5, 1, P.lamp), S1(0, -5, 0, P.fence)] });
/* 島の 森: 白樺の 木 四本と こけ（約 110 ブロック）*/
facAdd("skygrove", { D: [9, 11, 8], box: [-1, -5, 7, 5], H: 7, look: [3, 0, 1.2], marks: { mid: [3, 0, 0] }, build: () => [
  ...[[1, -4], [5, -3], [2, 4], [6, 3]].flatMap(([a, b]) => [F(a, b, 0, a, b, 3, "birch_log"), F(a - 1, b - 1, 3, a + 1, b + 1, 4, "birch_leaves", "keep"), S1(a, b, 5, "birch_leaves")]),
  F(2, -2, 0, 4, 2, 0, "moss_carpet", "keep"), S1(3, -1, 0, "fern"), S1(4, 1, 0, "lily_of_the_valley")] });

/* ---------- 町の 人 ---------- */
castAdd("b17oba", { nm: "島の おばば", role: "祠守", gobi: "ねえ", skin: "baba", from: "b17e3", at: () => HOK(),
  pre: ["{smile}雲の 上まで よう 来たねえ。"],
  after: [[(s) => !!s.ending, ["{smile}南の 空が 晴れたねえ。祠の 鈴も、よう 鳴るように なったよ。", "{closed}竜の 子の 坊やは、借りた 子の 名前を まだ 全部 覚えとるそうだねえ。"]],
    [() => true, ["{closed}紫の 流れは、南へ 降りたねえ。……ルミナの 方だよ。"]]] });
castAdd("b17kid", { nm: "ツグミ", role: "島の 子", gobi: "", skin: "taro", from: "b17e2", at: () => VIL(),
  pre: ["{smile}雲の 上の 村だよ！"],
  after: [[(s) => !!s.ending, ["{smile,up}レイの 兄ちゃん、手紙 くれたよ！ モフと トゲの 名前、ちゃんと 書いて あった！"]],
    [() => true, ["{smile}モフは 返して もらったよ。……名前、ちゃんと 呼んで くれたんだって。"]]] });

/* ---------- 話 ---------- */
const E1 = { id: "b17e1", t: "レイの 告白", place: HUT, fac: "r10hut", F: ["F21"],
  hint: "§f§e雲の 島の 小屋§f へ 行こう §7（右上の 案内。レイが 待って いる）",
  syn: "夜の 雲の 島の 小屋で、レイは 六影の 側に ついた わけを 話した。「選ばれる 側に なれると 思った」。しくじり帳の 最後の 頁だけが、レイの 字だった。",
  async run(p, d, K) {
    const FQ = K.fac(p, "r10hut", "cabin", 10, Yof(K, p)), FF = K.fac(p, "r10fire", "fire", 10, Yof(K, p));
    await K.open(p, "雲の 島の 小屋（夜）", "night");
    K.sound(p, "fire.fire", 0.5);
    if (FQ) await K.at(p, FQ, 12, 7, 1.4);
    const eR = REI(K, p);
    if (ok(eR) && FF) await K.walkCam(p, eR, { x: FF.x - 1.4, y: FF.y, z: FF.z }, 18);   /* 島の 端から 歩いて もどり、火の そばに 座る */
    K.act(eR, "kneel");
    await K.say(p, "レイ", ["{closed}……風、当たってた。島の 端で、いちばん 強く。", "{sad}……でも、竜の 羽は ほどけなかった。"]);
    await K.say(p, "レイ", ["{closed}……座れよ。明日の 勝負の 前に、話して おきたい ことが ある。"]);
    if (FF) await K.at(p, FF, 10, 3, 0.6);
    K.turn(eR, FF || K.fwd(p, 6));
    await K.flashback(p, { label: "§7―― 十年前　ルミナの 牧場", tod: "dusk", ptc: "dust",   /* 第127版: レイの 小さい ころを 絵で */
      actors: { o: { nm: "§eオルド", job: K.PJ("ordo", 8), at: [5, 0], look: [12, 0] }, r: { nm: "§b七つの レイ", job: K.PJ("rei", 6), at: [2.4, -0.6], look: "o", hold: "notebook" } },
      beats: [
        ["narr", "§7十年前の 夕方。牧場の 柵の 前で、オルドが 一人、遠くの 空を 見て いた。", "o"],
        ["say", "r", "{smile,up}じいちゃん！ 見て、竜の 絵 かいた！", "o"],
        ["say", "o", "{closed}……おう。", [12, 0]],
        ["go", "r", [3.8, -0.4], 10],
        ["say", "r", "{?,up}じいちゃん、どこ 見てるの？ ……おれの 絵、見て ないじゃん。", "o"],
        ["say", "o", "{closed,…}……北の 空じゃ。昔、置いて きた ものが ある。", [12, 0]],
        ["act", "r", "sad"],
        ["narr", "§7じいちゃんは、いつも 遠くの 空を 見て いた。……レイの ほうは、見なかった。", "r"],
      ] });
    await K.say(p, "レイ", ["{sad,up}牢を 出た あと、オレの 話を 聞いて くれたのは、セオ だけ だった。", "{smile,…,up}かけらを くれた 夜、あいつ 言ったんだ。『君は 選ばれる 人だ』って。"]);
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{closed}……選ばれる 側に なれると 思った。うれしかったんだよ。", "{angry,up}……バカだよな。かけらの 声と、あいつの 声の 区別も ついて なかった。"]);   /*F21*/
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:heart_particle", 3, 0.4, 0.8); await K.up(p, g, 12); }
    await K.pal(p, ["……レイ、ひの においと、さびしい におい。"]);
    K.rmCine(g);
    await K.say(p, "レイ", ["{smile,up}……おまえの 相棒は、ずっと おまえを 選んでる。", "{?}選ばれる って、だれかに 決めて もらう ことだったのか？ ……わかんなく なった。"]);
    K.act(eR, "show"); K.hold(eR, "notebook");
    await K.narr(p, ["§7レイが 腰の §fしくじり帳§7 を 開いた。じいちゃんの しくじりを 写した 帳面。", "§7最後の 頁だけ、レイの 字だった。§f『竜骨の 祭壇。動けなかった。』"], eR);
    await K.say(p, "レイ", ["{sad,up}……じいちゃんと 同じ ことだけは しないって 決めてた。……なのに、いちばん でかい 頁が、オレのだ。", "{closed,up}……あいつを 止めるのは、たぶん――"]);
    K.act(eR, 0); K.hold(eR);
    K.sound(p, "mob.enderdragon.flap", 0.5); K.burst(p.dimension, FF || p.location, "minecraft:white_smoke_particle", 12, 2.5, 1);
    await K.narr(p, ["§7強い 風が 吹いて、火が 大きく ゆれた。……言葉の 続きは、風の 音に 消えた。"], FF);
    await K.say(p, "レイ", ["{closed,no}……なんでも ない。", "{angry,up}明日、島の 村で 仲間を 借りる。それから 島の 端で 決めよう。"]);
    K.pay(p, E1, 2000, [["fd_stew", 2]]);
    await K.night(p, FF || FQ, "§7その 夜、レイは 一度も 横に ならなかった。", "§7……夜明け。村の 方から、子どもの 声が 聞こえる。", [eR]);
    await fin(K, p, { card: "§7→ 雲の 島の §e村§7 へ（右上の 案内）", kind: "day" });
    return true;
  } };

const E2 = { id: "b17e2", t: "借りた 仲間", place: VIL, fac: "b17vil",
  hint: "§f§e雲の 島の 村§f へ 行こう §7（レイが 仲間を 借りに 行った）",
  syn: "竜を 失った レイは、島の 村で モンスターを 借りた。一体ずつ 名前を 聞いて 回り、しくじり帳の 新しい 頁に 書いて いった。",
  async run(p, d, K) {
    K.fac(p, "b17vil", "skyvillage", 10, Yof(K, p));
    await K.open(p, "雲の 島の 村", "day");
    const eR = REI(K, p), eK = K.cast(p, "b17kid");
    const m1 = K.monEnt(p, K.fwd(p, 4.5, 2), K.wildSp("animal"), "§aモフ"), m2 = K.monEnt(p, K.fwd(p, 5, -2), K.wildSp("beast"), "§aトゲ");
    K.act(eR, "kneel");
    await K.say(p, "レイ", ["{closed}……よし。おまえの 名前は？"], m1);
    if (m1) { K.burst(p.dimension, m1.location, "minecraft:note", 2, 0.3, 1); await K.up(p, m1, 10); }
    await K.csay(p, "b17kid", ["{smile,up}モフだよ！ 聞いても 答えないよ、兄ちゃん！"], eR);
    K.re(eR, "sweat", "汗");
    await K.say(p, "レイ", ["{sweat,汗}……本人に 聞かねえと、組んだ 気が しねえんだよ。", "{closed}モフ。……で、おまえは？"], m2);
    if (m2) { K.sound(p, "mob.wolf.growl", 1.2); await K.up(p, m2, 10); }
    await K.csay(p, "b17kid", ["{smile}トゲ！ かむから 気を つけてね！"], eR);
    K.act(eR, "show"); K.hold(eR, "notebook"); K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7レイは しくじり帳の 新しい 頁に、§fモフ・トゲ§7 と 書いた。", "§7……いちばん 上に、小さく §f『借りた 仲間』§7。"], eR);
    await K.csay(p, "b17kid", ["{?,up}しくじり帳に 書くの？ しくじりじゃ ないのに？"]);
    await K.say(p, "レイ", ["{closed}……名前を 書く 帳面が、これしか ねえんだよ。", "{smile,up}夕方には 返す。名前 呼んだら 来るか、ためして くる。"]);
    K.act(eR, 0); K.hold(eR);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……モフ、レイの こと、もう すき。"]); K.rmCine(g); }
    K.pay(p, E2, 1500, [["fd_milk", 2]]);
    await fin(K, p, { leave: [eR], bye: [eK, m1, m2], card: "§7→ 村の 先の §e祠§7 で、島の おばばが 南の 空を 見て いる", kind: "day" });
    return true;
  } };

const E3 = { id: "b17e3", t: "南へ 降りた", place: HOK, fac: "b17hokora",
  hint: "§f§e雲の 島の 祠§f へ 行こう §7（島の おばばが 何かを 見た）",
  syn: "祠守の おばばは、鐘楼から 流れた 紫の 影が、雲を くぐって 南へ 降りて いくのを 見て いた。ルミナの 方へ。",
  async run(p, d, K) {
    const H = K.fac(p, "b17hokora", "hokora", 10, Yof(K, p));
    await K.open(p, "雲の 島の 祠", "day");
    if (H) await K.at(p, H, 14, 4, 1.2);
    const eO = K.cast(p, "b17oba"); K.act(eO, "hold");
    await K.csay(p, "b17oba", ["{closed}……来たねえ。鐘が 止まった 夜、紫の 流れが 祠の 上を 通ったよ。"]);
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{?}……どっちへ 行った。"], eO);
    K.act(eO, "point");
    const sky = K.fwd(p, 9, -4, 7); K.burst(p.dimension, sky, "minecraft:portal_reverse_particle", 8, 2, 0);
    await K.at(p, sky, 16, 8, 0);
    await K.csay(p, "b17oba", ["{sad}南へ 降りたよ。雲を くぐって、ずうっと 下。……ルミナの 方だねえ。"]);
    K.re(eR, "shock", "!");
    await K.say(p, "レイ", ["{shock,…,up}……ルミナ。じいちゃんの いる 町だ。", "{angry}なんで ルミナなんだよ。あそこには 石板も 何も……"]);
    await K.csay(p, "b17oba", ["{closed}何が あるかは、行った 者にしか わからんよ。……祠の 鈴は、名前を 呼ぶ ための ものだよ。忘れんでねえ。"], eR);
    K.act(eO, 0);
    await K.say(p, "レイ", ["{closed}……勝負は 延ばさねえ。森で 腕を 合わせて、それから 島の 端だ。"]);
    K.pay(p, E3, 1500, [["dm_ink", 1]]);
    await fin(K, p, { leave: [eR], bye: [eO], card: "§7→ 島の §e森§7 で、影の 残りかすが うごめいて いる", kind: "day" });
    return true;
  } };

const E4 = { id: "b17e4", t: "島の 森", place: GROVE, fac: "b17grove", battles: 1,
  hint: "§f雲の 島の §e森§f へ 行こう §7（影の 残りかす。レイと いっしょに）",
  syn: "島の 森で、影の 残りかすと 戦った。レイは 借りた モフと トゲの 名を 呼び、二体は ちゃんと 来た。",
  async run(p, d, K) {
    K.fac(p, "b17grove", "skygrove", 10, Yof(K, p));
    await K.open(p, "雲の 島の 森", "ash");
    let eR = REI(K, p); K.act(eR, "guard");
    await K.shadowFlow(p, K.fwd(p, 12, 3), K.fwd(p, 5, 0), 12);
    await K.say(p, "レイ", ["{angry,up}……来たな。借りた 二体の 初陣だ。", "{closed}モフ！ トゲ！ ……名前 呼んだら、来いよ。"]);
    const r = await K.battle(p, K.team(["nether", "dragon", "nether"], 82, 3, 30), { name: "影の 残りかす", arena: "雲の 島の 森", theme: "sky", speaker: "影", guests: K.team(["animal", "beast"], 78, 2).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……ナヲ……ヨブナ……", low: "……ミナミヘ……" } });
    if (r !== "win") { await K.say(p, "レイ", ["{sweat,汗}……下がるぞ！ 立てなおしだ。"]); return false; }
    eR = again(K, p, eR, "§bレイ", 17); K.act(eR, 0);
    await K.say(p, "レイ", ["{smile,…}……来た。名前、呼んだら、ちゃんと 来た。", "{closed}……悪くねえ。"]);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……かげ、みなみの においが した。"]); K.rmCine(g); }
    toP(K, p, eR);
    await K.say(p, "レイ", ["{angry,up}……明日の 朝、島の 端で 待ってる。手加減は なしだ。"]);
    K.pay(p, E4, 4000, [["i_awaken", 1]]);
    await fin(K, p, { leave: [eR], card: "§7→ §e雲の 島の 端§7 で、レイと 最後の 勝負（右上の 案内）", kind: "day" });
    return true;
  } };

/* MQ23: 島の 端（今日の cloudedge の セット）*/
async function edge(K, p) {
  K.fac(p, "r10edge", "cloudedge", 10, Yof(K, p));
  const v = J("mrpg:epdeco:r10edgeat"), near = v && Math.hypot(v.x - p.location.x, v.z - p.location.z) < 60;
  return { dq: (near && MK(v, "dragon")) || K.fwd(p, 6, 3), rq: (near && MK(v, "ray")) || K.fwd(p, 4, 1) };
}
const E5 = { id: "b17e5", t: "最後の 頁", hint: "§fセレスティアの §e雲の 島の 端§f へ 行こう §7（レイと 最後の 勝負。右上の 案内）",
  syn: "夜明けの 島の 端。石に なった 竜の 前で、レイは しくじり帳を 見せた。最後の 頁に、一行だけ「セオを 止める」。",
  async run(p, d, K) {
    const { dq, rq } = await edge(K, p);
    await K.open(p, "雲の 島の 端", "day");
    const dr = K.monEnt(p, dq, DRAG_SP(), "§7竜の 石像"), eR = await K.put(p, "§bレイ", rq, dq, 17); K.act(eR, "hold");   /* 夜明けから ずっと 竜の そばに いる */
    if (dr) { K.burst(p.dimension, dr.location, "minecraft:white_smoke_particle", 6, 1, 1); await K.up(p, dr, 14); }
    await K.say(p, "レイ", ["{smile,…}……来たか。こいつの 前で、決めたかった。", "{sad}朝日が 当たっても、冷たい ままだ。"]);
    const g = K.palEnt(p); if (g && dr) { await K.approach(p, g, dr, 1.2); await K.up(p, g, 10); }
    if (g && dr) K.turn(g, dr.location);
    await K.pal(p, ["……まだ、なかに いる。"]);
    K.rmCine(g); toP(K, p, eR);
    await K.say(p, "レイ", ["{?,up}……いる、のか。", "{closed}……そうか。なら、呼ぶ 日まで ここで 待たせとく。"]);
    K.act(eR, "show"); K.hold(eR, "notebook"); K.sound(p, "item.book.page_turn", 1);
    await K.up(p, eR, 10);
    await K.narr(p, ["§7しくじり帳の『動けなかった』の 次の 頁。……一行だけ、太い 字で 書いて あった。", "§f『セオを 止める』"], eR);
    await K.say(p, "レイ", ["{closed}ゆうべ、火が 消えてから 書いた。", "{angry,up}止めに 行くのは どっちか。……ここで 決めよう。"]);
    K.act(eR, 0); K.hold(eR);
    K.rmCine(dr); await K.bye(p, eR); K.cmd(p, "fog @s remove mq_shadow");
    return true;
  } };
const E6 = { id: "b17e6", t: "最後の 勝負", F: ["F21"], battles: 1,
  syn: "雲の 上の 一騎打ち。全部 出して 負けた レイは、頁を 破らずに 書き足した。「止めるのは、あいつの 友だ」。レイは ルミナを 守ると、自分で 決めた。",
  async run(p, d, K) {
    const { dq, rq } = await edge(K, p);
    const eR = K.npcNear(p, "§bレイ", 17, true) || (await K.put(p, "§bレイ", rq, null, 17)); K.act(eR, "raise");
    const c05 = K.ch(p, "c05") || "s";
    await K.low(p, eR, 12);
    await K.say(p, "レイ", [c05 === "w" ? "{closed}……王墓の 前で、おまえは 止めた。オレは 聞かなかった。" : "{closed}……王墓の 前で、おまえは 黙ってた。オレは それに 甘えた。",
      c05 === "w" ? "{angry,up}あのとき 止めた おまえに、勝ちたかった。" : "{angry,up}あのとき 黙ってた おまえに、何か 言わせたかった。"]);
    await K.say(p, "レイ", ["{closed,…}……じいちゃんの 古い 腕輪だ。相棒と 心が そろうと、熱く なる。", "{up}かけらも 竜も なしの、今の オレの 全部を ぶつける！"]);
    K.act(eR, "guard");
    await K.duel(p, "§b§l雲の 上の 一騎打ち", "§f竜の いない レイが 真っ向から 飛びこむ！", { fams: ["animal", "beast"] });
    const r = sOf(p).reiFinal ? "win" : await K.battle(p, K.team(["animal", "beast", "golem"], 80, 4, 8, K.leadOf("beast", 80)), { name: "ライバル レイ（最後の 勝負）", tmx: "rei", arena: "最後の ライバル戦", theme: "sky", hpk: 1.0, extra: 0.3, sboss: true, tag: "ライバル", speaker: "レイ", lines: { half: "まだだ……オレも 全部 出しきる！", low: "……ハハ、やっぱ おまえは すげえよ。" } });
    if (r !== "win") { await K.say(p, "レイ", ["{closed}……オレの 勝ちだ。でも、頁を 破る 気に なれねえ。……もう一度、来い。"]); return false; }
    setS(p, (s) => { if (!s.reiW1726) { s.reiW = (s.reiW || 0) + 1; s.reiW1726 = 1; } });
    const e2 = ok(eR) ? eR : K.npcNear(p, "§bレイ", 17, true);
    K.act(e2, "up"); await K.up(p, e2, 20);
    K.act(e2, "kneel"); K.hold(e2, "notebook"); K.sound(p, "item.book.page_turn", 0.8);
    await K.narr(p, ["§7レイは しくじり帳を 開いた。……破らなかった。", "§7『セオを 止める』の 下に、小さく 書き足した。§f『全部 出して、負けた。』"], e2);
    K.act(e2, 0); K.hold(e2);
    await K.say(p, "レイ", ["{smile,…}……完敗だ。しくじりじゃ ない 負けは、はじめてだ。", "{closed}……わかってたんだ。§e止めるのは、あいつの 友だ§f。……オレじゃ ない。"]);   /*F21*/
    await K.push(p, e2, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{up}行け。オレは ルミナを 守る。じいちゃんも、ハクも。", "{closed}だれかに 言われたんじゃ ない。……オレが 選んだ。"]);
    const dr = K.monEnt(p, dq, DRAG_SP(), "§7竜の 石像");
    if (ok(e2) && dr) { await K.approach(p, e2, dr, 1.4); K.turn(e2, dr.location); await K.at(p, dr.location, 14, 3, 1.4); }
    await K.say(p, "レイ", ["{closed,…}……ちょっと 行って くる。すぐ 呼びに 来るからな。"], dr);
    K.rmCine(dr);
    K.pay(p, E6, 30000, [["e_king", 1], ["SEED3", 1], ["i_awaken", 1], ["i_trpick", 1], ["tms_sword", 1]]);
    await fin(K, p, { leave: [e2], card: "§7レイは、自分で 役目を 選んだ", kind: "day" });
    return true;
  } };

const E7 = { id: "b17e7", t: "紫の 渦", place: () => { const q = ISLE(); return q ? { x: q.x, z: q.z, nm: "雲の 島の 端" } : null; }, fac: "r10edge",
  hint: "§f§e雲の 島の 端§f で 南の 空を 見よう §7（レイが 呼んで いる）",
  syn: "雲の 切れ間から、はるか 下の ルミナが 見えた。町の 上に、紫の 渦が 巻いて いた。",
  async run(p, d, K) {
    await edge(K, p);
    await K.open(p, "雲の 島の 端", "day");
    const eR = REI(K, p); K.act(eR, "point");
    await K.say(p, "レイ", ["{shock,!,up}……おい、見ろ。雲が 割れる。"]);
    const q = K.fwd(p, 14, 0, -6); for (let i = 0; i < 4; i++) { K.burst(p.dimension, q, "minecraft:portal_reverse_particle", 10, 2 + i, 0.2); K.burst(p.dimension, q, "minecraft:white_smoke_particle", 6, 4, 0); await K.wait(4); }
    await K.pull(p, q, 30);
    await K.narr(p, ["§7雲の 切れ間の ずっと 下に、小さな 町が 見えた。§e始まりの 町 ルミナ§7。", "§7その 真上に、紫の 渦が ゆっくり 回って いる。"], q);
    await K.say(p, "レイ", ["{angry,…,up}……ルミナの 真上だ。じいちゃんの 牧場の 方まで、影が 落ちてる。", "{closed}港へ 急ごう。舟なら 夕方には 着く。"]);
    K.act(eR, 0);
    await fin(K, p, { leave: [eR], card: "§7→ 雲の 島の §e港§7 へ（右上の 案内）", kind: "ash" });
    return true;
  } };

const E8 = { id: "b17e8", t: "鳥便", place: PORT, fac: "b17port", F: ["F47"],
  hint: "§f雲の 島の §e港§f へ 行こう §7（ルミナへ 渡る 舟）",
  syn: "港に、ルミナの 門番 ゴンザからの 鳥便が 届いて いた。紙には 一行だけ。「門は 閉めたでござる」。",
  async run(p, d, K) {
    const B = K.fac(p, "b17port", "boathut", 10, Yof(K, p));
    await K.open(p, "雲の 島の 港", "day");
    if (B) await K.at(p, B, 12, 5, 1.2);
    const eR = REI(K, p);
    const bird = K.monEnt(p, K.fwd(p, 3.5, 1.5), K.wildSp("bird") || K.wildSp("animal"), "§f鳥便");
    if (bird) { K.sound(p, "mob.parrot.fly", 1); await K.up(p, bird, 12); }
    await K.say(p, "レイ", ["{?}……ルミナの 鳥便だ。足に 紙が 結んで ある。"], bird);
    K.act(eR, "show"); K.hold(eR, "letter");
    await K.narr(p, ["§7小さな 紙に、ゴンザの 大きな 字で 一行だけ。", "§f『門は 閉めたでござる』"], eR);   /*F47*/
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{shock,…}……それだけか。だれが 来ても 開けて 待つって 言ってた 門番が、閉めた？", "{angry,up}……何が あったか、書いて ねえ。"]);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……かみ、いそいだ におい。ゴンザの あせ。"]); K.rmCine(g); }
    toP(K, p, eR);
    await K.say(p, "レイ", ["{closed}……行って 確かめるしか ねえ。"]);
    K.act(eR, 0); K.hold(eR); K.rmCine(bird);
    K.pay(p, E8, 2000, [["gift_bread", 2]]);
    await fin(K, p, { leave: [eR], card: "§7→ 港の 舟で、南の ルミナへ", kind: "day" });
    return true;
  } };

const E9 = { id: "b17e9", t: "南へ", place: PORT, fac: "b17port",
  hint: "§f雲の 島の §e港§f の 舟に 乗ろう §7（南の ルミナへ）",
  syn: "舟は 雲を 下り、夕方、ルミナの 南の 入口に 着いた。町の 上で、紫の 渦が 回って いた。",
  async run(p, d, K) {
    K.fac(p, "b17port", "boathut", 10, Yof(K, p));
    await K.open(p, "雲の 島の 港", "day");
    const eR = REI(K, p);
    const eS = NP(K, p, "§7渡し守", "m6_dock"); K.act(eS, "hold");
    await K.say(p, "渡し守", ["{closed}南の 町へかい。……雲を 下りると、灰が 降って おるそうな。"], eR);
    await K.say(p, "レイ", ["{closed}それでも 行く。……舟を 出して くれ。"], eS);
    K.sound(p, "random.splash", 0.6);
    if (!(await K.moveTo(p, SOUTH(), "ルミナの 南の 入口", [eS, eR]))) await fade(K, p);
    K.ambient(p, "ash", K.S(p) ? K.S(p).Cn : p.location);
    const eR2 = REI(K, p);
    await K.say(p, "レイ", ["{shock,…,up}……着いた。……ルミナだ。", "{angry}門が……閉まってる。"]);
    K.pay(p, E9, 2000, [["dm_bell", 1]]);
    await fin(K, p, { leave: [eR2], card: "§f― 第17章 最後の ライバル おわり ―\n§7→ ルミナの §e南の 入口§7（右上の 案内）", kind: "ash", t: 56 });
    return true;
  } };

bkAdd("b17", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ23: 島の 端の 2話（場所は 今日の 雲の 島の 端）。移し替えで 済んだ ときは 待つ ものなし */
mqOver(23, async (p, d, K, c) => { if (!(await c.play("b17e5"))) return false; return await c.play("b17e6"); },
  { cond: async () => true, spot: () => { const q = ISLE(); return q ? { x: Math.floor(q.x), y: null, z: Math.floor(q.z), nm: "雲の 島の 端", key: "b17edge" } : null; } });
/* 町の 人の その後 */
afterAdd("kazami", [[(s) => !!(s.epx && s.epx.gonza10) && !s.ending, ["{closed}港から 南へ 舟が 出たんじゃて。……レイの 坊主は、竜に 声を かけてから 出て いったじゃて。"]]]);
