/* 第125版: 物語の 人が 手に 持つ 小道具（mrpg:hold。0 = なし）。名前の 一覧は holdnames.js（npchold.py が 作る）
   hold(e, "hammer") で 持たせ、hold(e) で 手を 空に する。場面が 終わると stagecore が 舞台の 人の 手を 空に する */
import { HOLDS } from "./holdnames.js";
const IX = new Map(HOLDS.map((n, i) => [n, i + 1]));
export const holdIx = (n) => (typeof n === "number" ? (n >= 0 && n <= HOLDS.length ? n : 0) : IX.get(n) || 0);
export function hold(e, n = 0) { try { if (!e || !e.isValid()) return; const v = holdIx(n); if ((e.getProperty("mrpg:hold") || 0) !== v) e.setProperty("mrpg:hold", v); } catch {} }
export const unhold = (e) => hold(e, 0);
export { HOLDS };
