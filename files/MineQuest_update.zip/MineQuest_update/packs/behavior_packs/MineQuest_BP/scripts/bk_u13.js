/* 第126版 裏13「静寂の 区」（常世・中の 区）— 作業 UB
   区7（三冠 リョウマ・静寂）: 1〜4話 前 → 5話 向かい合う（一騎打ち）→ 後: 勝った 一拍 → 6話（唇を 読む）→ 7話（音が 戻る）→ 8話（野営地の 夜・サヤ）
   音の ない 区では 聞き槌が 鳴らない（ムサシが いちばん 怖い 場面）。エンマは 声を 使わず 画面の 字だけで 道を 示す */
import { K } from "./bkeng.js";
import { U } from "./bk_u08.js";
import { SGK } from "./saga.js";
import { act, hold, fx, fade, PJ } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
const { F, S1, ok } = U;
const V = (g, o, c, t) => ({ g, o, c, t });
const hush = (p) => { try { p.runCommand("stopsound @s"); } catch {} };
const ink = (p, L, foc = null) => K.narr(p, [].concat(L).map((x) => `§4${x}`), foc);   /* 鍔の 字（声なし）*/

facAdd("u13lamp", { D: [10, 12, 14], box: [0, -5, 6, 5], H: 3, look: [3, 0, 1], marks: { sign: [0, -3, 1], row: [3, 0, 1.5], deep: [6, 0, 1.2] },
  build: () => [S1(0, -3, 0, "oak_sign"), ...[1, 3, 5].flatMap((a) => [S1(a, -2, 0, "stone_brick_wall"), S1(a, -2, 1, "lantern"), S1(a, 2, 0, "stone_brick_wall"), S1(a, 2, 1, "lantern")]), F(6, -1, 0, 6, 1, 0, "polished_andesite"), S1(6, 0, 1, "soul_lantern")] });

const fight7 = U.fight(7, async (p, C) => {
  await K.open(p, "常世 ― 静寂の 区の 奥");
  K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)); hush(p);
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  const e = U.boss(p, C, 7, 10, 0);
  if (ok(e)) { await K.low(p, e, 16); await K.at(p, U.top(e), 18, 5, 0); }
  SGK.big(p, "§4§lリョウマ", "§7三冠"); await K.wait(30); hush(p);
  await U.say(p, "リョウマ", ["{closed,low}……静かに。刃は、音より 先に 届く"], mu);
  await U.say(p, "リョウマ", ["{angry,!,up}一騎打ちだ。一人ずつ 来い"]);
  await K.up(p, mu, 8);
  await U.M(p, mu, ["{closed}……ああ。一人ずつ だな。……音が なくても、刃の 重さは 手に くる。"], "guard");
}, async (p, C) => {
  K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)); hush(p);
  const e = U.boss(p, C, 7, 7, 0);
  if (ok(e)) { await K.at(p, U.top(e), 14, 5, 0); act(e, "kneel"); }
  await U.narr(p, ["§7音の ない 剣戟が、終わった。§8リョウマが、刀を 静かに 鞘へ 戻した。"], e);
});

U.reg("u13", [
  { id: "u13e1", t: "静かに", free: false,
    syn: "静寂の 区の 入口に、書記 マルタの「静かに」の 札。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 静寂の 区の 入口");
        const l = K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)), sg = facMark("u13lamp", "sign", p.location) || l;
        if (sg) await K.at(p, sg, 16, 3, 0.6);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        await U.rec(p, C, 7, ["§7『書記 マルタ。最後に 書いた 字は「静かに」。……子どもが 泣き止まなかった』", "§8その 横に、一本の 刀傷。石を 音も なく 斬った 跡だった。"], "shiori", "hold");
        await U.H(p, V(["{closed}……入口の 札、『静かに』って 書いてある"], ["{closed}……入口の 札に『静かに』と 書いて あるわ"], ["{closed}……札に『静かに』"], ["{closed}……入口の 札に『静かに』と 書かれて います"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……音を 消された 区か。", "{sweat,汗}……俺の いちばん 苦手な 場所だ。"], "hold");
        await U.lesson(p, C, 7, mu);
        await U.end(p, C, { card: "§7→ 区の 中へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u13e2", t: "鳴らない 槌", free: false,
    syn: "音の ない 区で、ムサシの 聞き槌が 鳴らなかった。何度 叩いても。手が 震え、口が 槌の 数を 数えて いるのに、声が 出ない。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 静寂の 区");
        K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)); hush(p);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        act(mu, "point"); hold(mu, "hammer");
        for (let k = 0; k < 3; k++) { hush(p); act(mu, k % 2 ? "point" : "hold"); await K.wait(8); }
        await U.narr(p, ["§7ムサシが 腰の 聞き槌で、足もとの 石を 叩いた。§8……音が、しない。", "§7もう 一度。もう 一度。§8……しない。"], mu);
        await K.push(p, mu, 26, 2.6, 1.2, 1.5);
        act(mu, "kneel"); hush(p);
        await U.narr(p, ["§7ムサシの 手が 震えて いた。§8唇が 動いて いる。……一つ、二つ、三つ。槌の 数を 数えて いる。でも、声が 出て いない。"], mu);
        await U.say(p, "ムサシ", ["{shock,…}（…………。……………。）"]);
        await K.two(p, mu, so || mu, 12);
        await U.H(p, V(["{sad,…}……ムサシ。……聞こえてないよね、わたしの 声も"], ["{sad,…}……ムサシ。……わたしの 声も、聞こえて いないのね"], ["{sad,…}……ムサシ。……聞こえてない"], ["{sad,…}……ムサシさん。……わたしの 声も、届いて いないのですね"]), mu);
        await U.narr(p, ["§8……槌が 鳴らない ムサシは、目を 閉じた 人の ように 見えた。"]);
        await U.end(p, C, { card: "§7→ 画面に、字が 浮かんだ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u13e3", t: "鍔の 字", free: false,
    syn: "エンマが ムサシの 口を 借りずに、字だけで 道を 示した。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 静寂の 区（灯籠の 列）");
        const l = K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)), row = facMark("u13lamp", "row", p.location) || l; hush(p);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none");
        if (ok(mu)) { fx(p.dimension, "minecraft:basic_flame_particle", mu.location, 10, 0.4); await K.up(p, mu, 10); }
        await ink(p, ["……小僧。声は いらぬ。字を 見よ"], mu);
        if (row) await K.at(p, row, 16, 5, 1);
        await ink(p, ["……灯籠の 列を 奥へ。三つ 数えて、右"]);
        await K.up(p, so, 8);
        await U.H(p, V(["{smile}……エンマさんの 字、読めるよ。ムサシ、わたしが 指さすから"], ["{smile}……エンマさんの 字、読めるわ。ムサシ、わたしが 指さすから"], ["{smile}……読める。ムサシ、わたしが 指す"], ["{smile}……エンマさんの 字、読めます。ムサシさん、わたしが 指さしますね"]), mu);
        act(so, "point"); if (ok(mu) && row) await K.walkCam(p, mu, row, 18);
        await ink(p, ["……刃の 重さだけ、覚えて おけ。……音は、あとで 返して やる"], mu);
        await U.end(p, C, { card: "§7→ 灯籠の 列の 奥" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u13e4", t: "灯籠の 奥の 光", free: false,
    syn: "石の 灯籠の 列の 奥に、小さな 光が 閉じこめられて いた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 静寂の 区の 奥");
        const l = K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)), dp = facMark("u13lamp", "deep", p.location) || l; hush(p);
        if (dp) { await K.push(p, dp, 24, 6, 2.2, 0.6); for (let k = 0; k < 8; k++) try { p.dimension.spawnParticle("minecraft:endrod", { x: dp.x + Math.cos(k) * 0.3, y: dp.y + 0.6 + k * 0.05, z: dp.z + Math.sin(k) * 0.3 }); } catch {} }
        await U.narr(p, ["§7灯籠の 列の いちばん 奥。§f小さな 光§7 が 一つ、石の 灯籠に 閉じこめられて いた。§8……かすかに、ふるえて いる。"], dp);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        act(mu, "kneel"); hush(p);
        await U.narr(p, ["§7ムサシが 光の 前に ひざを ついた。§8叩かなかった。……耳を 寄せた。"], mu);
        if (ok(mu)) fx(p.dimension, "minecraft:basic_flame_particle", mu.location, 8, 0.4);
        await ink(p, ["……サヤ"], mu);
        await U.end(p, C, { card: "§7→ 光の 前に、刀を 持つ 男が 立った" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u13e5", t: "音の ない 一騎打ち", free: false, run: fight7, syn: "三冠リョウマとの 一騎打ち。音の ない 剣戟。" },
  { id: "u13e6", t: "唇の 言葉", free: false, ans: ["qu032"],
    syn: "リョウマの 唇が 動いた。エンマが 読む「ムサシに 伝えろ。いい 太刀筋 だった」。リョウマは 千年前、エンマを 鍔に 封じた 剣の 家の 剣士。サヤの 魂を 守る ために 常世へ 下り、神に 名を 書かれて 区の 主に された。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 静寂の 区の 奥");
        K.fac(p, "u13lamp", "u13lamp", 99, U.y0(p)); hush(p);
        const ry = C.npc("§7リョウマ", PJ("sam03", 8), 4.2, 0.8, 0, "smoke"); act(ry, "kneel"); hold(ry, "katana");
        if (ok(ry)) await K.push(p, ry, 20, 3, 1.4, 1.5);
        await U.narr(p, ["§7膝を ついた リョウマの 唇が、ゆっくり 動いた。§8……音は ない。"], ry);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none");
        if (ok(mu)) fx(p.dimension, "minecraft:basic_flame_particle", mu.location, 8, 0.4);
        await ink(p, ["……『ムサシに 伝えろ。いい 太刀筋 だった』"], ry);
        await K.up(p, mu, 10);
        await U.say(p, "ムサシ", ["{shock,…,up}（…………。）"]);
        await ink(p, ["……千年前、われを 鍔に 封じた 剣の 家の 剣士だ。名は リョウマ"], ry);
        await ink(p, ["……サヤの 魂を 守ろうと、ひとりで 常世へ 下りた。神に 名を 書かれ、この 区の 主に された。……それでも、灯籠の 奥の 光だけは、千年 守って いた"], so);
        await ink(p, ["……かつて、われに 刀を 教えた 者だ。……あれに 褒められたのは、われも 一度きりだ"], mu);
        if (ok(ry)) { hold(ry, 0); act(ry, "bow"); await fade(ry, "minecraft:endrod"); }
        await U.end(p, C, { card: "§7→ 区の 外へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u13e7", t: "コン", free: false,
    syn: "区の 外へ 出ると、音が 戻った。聞き槌が「コン」。ムサシは その場に 座りこんだ。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 静寂の 区の 外");
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        K.sound(p, "ambient.cave", 0.4); await K.wait(10);
        act(mu, "point"); hold(mu, "hammer"); await K.wait(6); K.sound(p, "random.anvil_land", 0.5, 1.9); await K.wait(8);
        await U.narr(p, ["§f……コン。"], mu);
        hold(mu, 0); act(mu, "kneel");
        await K.push(p, mu, 22, 3, 1.4, 1);
        await U.narr(p, ["§7ムサシは その場に、すとんと 座りこんだ。"], mu);
        await U.M(p, mu, ["{closed,tears}……鳴った。", "{closed}……一つ、二つ、三つ。……一つ 休む。……鳴った。"], "kneel");
        await K.two(p, mu, so || mu, 10);
        await U.H(p, V(["{smile,tears}……おかえり、ムサシの 音"], ["{smile,tears}……おかえりなさい、ムサシの 音"], ["{smile,tears}……おかえり。ムサシの 音"], ["{smile,tears}……おかえりなさい、ムサシさんの 音"]), mu);
        await U.E(p, mu, ["……音は 返した。……リョウマの ぶんも、聞いて おけ"]);
        await U.M(p, mu, ["{smile}……ああ。いい 太刀筋だったって？ ……あの 刀、三千年 鳴りっぱなしだった。やっと 静かに なったな。", "{smile}……今度 お前の 太刀筋も 聞かせろ、エンマ。"], "kneel");
        await U.end(p, C, { card: "§7→ 夜。§e野営地§7 へ", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u13e8", t: "あれ、わたしの 名前？", free: false, F: ["F41"],
    syn: "野営地の 夜。小さな 光が、ムサシの 槌の 音を たどって 来た。サヤの 魂「毎晩 コン、コンって。あれ、わたしの 名前？」。ムサシ「リンって 呼んでた」。彼女の 口から「サヤ」を 聞いて、はじめて 本当の 名で 呼んだ。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await U.toCamp(p);
        await K.open(p, "常世 ― 野営地の 夜", "night", "night");
        const mu = U.mu(C, 2.6, 1.4), so = U.soul(p, C, 3, -1.6, "none"); act(mu, "kneel");
        await K.up(p, mu, 8);
        act(mu, "point"); hold(mu, "hammer");
        for (let k = 0; k < 4; k++) { if (k < 3) K.sound(p, "random.anvil_land", 0.3, 1.9); await K.wait(10); }
        hold(mu, 0);
        await U.narr(p, ["§7ムサシが 槌で、たき火の 石を 叩いた。§f三つ 叩いて、一つ 休む。"], mu);
        const sy = C.npc("§dサヤ", PJ("sayo", 9), 6, 0.6, 0, "smoke"); act(sy, "hold");
        if (ok(sy)) { fx(p.dimension, "minecraft:endrod", sy.location, 10, 0.5); const l = mu.location; await K.walkCam(p, sy, { x: l.x + 1.4, y: l.y, z: l.z + 0.6 }, 22); }
        await U.narr(p, ["§7音を たどる ように、小さな 光が 歩いて 来た。§f……光の 中に、少女の 姿。"], sy);
        /*F41 回: 工房の 石の 娘の 音 ＝ 毎晩の コン、コン */
        await U.say(p, "サヤ", ["{smile,?}……毎晩、コン、コン、って。", "{smile,?,up}三つ 叩いて、一つ 休む。……あれ、わたしの 名前？"], mu);
        await K.two(p, mu, sy, 10);
        await U.M(p, mu, ["{shock,…,up}……聞こえて たのか。", "{closed}……お前の 石は、ちいさい 鈴みたいに 鳴ってた。だから『リン』って 呼んでた。……勝手に つけた 名前だ。"], "up");
        await K.up(p, sy, 8);
        await U.say(p, "サヤ", ["{smile,tears}……わたしの 名前は、サヤ。", "{smile,☆}でも、リンも 好き。千年で いちばん、あったかい 音だった。"], mu);
        await U.M(p, mu, ["{closed,low}……サヤ。", "{smile,tears}……今、本人から 聞いた。これで 本物だ。"], "kneel");
        if (ok(mu)) fx(p.dimension, "minecraft:basic_flame_particle", mu.location, 14, 0.7);
        await U.E(p, mu, ["……サヤ。", "……千年、待たせた。クロガネの 工房に、おまえの 体が ある。神の 頁が ほどければ、帰れる。それまで、小僧の 槌の 音の そばに いろ"]);
        await U.say(p, "サヤ", ["{smile,☆,up}うん。……兄さまも、ちゃんと 帰って きてね"]);
        await U.H(p, V(["{smile}……サヤちゃん。手帳に 書いとくね。……書けないけど、覚えとく"], ["{smile}……サヤちゃん。手帳に 書いて おくわね。……書けないから、覚えて おく"], ["{smile}……サヤ。覚えとく"], ["{smile}……サヤさん。手帳に 書いて おきます。……書けないので、覚えて おきます"]), sy);
        U.flag(p, "sisterDone"); U.flag(p, "enmaAlly");
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 二冠の §e城壁の 区§7 へ（右上の 案内）", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(7, ["u13e1", "u13e2", "u13e3", "u13e4", "u13e5"], ["u13e6", "u13e7", "u13e8"]);
