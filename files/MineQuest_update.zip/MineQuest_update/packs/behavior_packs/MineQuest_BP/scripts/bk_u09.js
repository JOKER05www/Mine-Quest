/* 第126版 裏9「遊び場と人形」（常世・下の 区）— 作業 UB
   区0（十冠 ヒフミ＆シゴロ・遊び場）: 1話 前 → 2話 向かい合う（戦いは ruins.js）→ 後: 勝った 一拍 → 3話
   区1（九冠 イトマ・人形）: 4・5話 前 → 6話 向かい合う → 後: 勝った 一拍 → 7話（選択 U09）→ 8話（区の 門）*/
import { K } from "./bkeng.js";
import { U } from "./bk_u08.js";
import { act, hold, fx, fade, PJ } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
const { F, S1, ok } = U;

facAdd("u09play", { D: [10, 12, 14], box: [0, -5, 6, 5], H: 4, look: [3, 0, 1], marks: { sand: [2, -3, 0.5], slide: [4, 3, 1.5], swing: [5, -2, 1.5] },
  build: () => [F(1, -4, -1, 3, -2, -1, "sand"), F(3, 2, 0, 5, 2, 0, "smooth_stone_slab"), F(3, 3, 0, 3, 3, 1, "cut_copper_stairs"), F(4, 3, 0, 4, 3, 0, "cut_copper"), F(5, 3, 0, 5, 3, 0, "cut_copper_slab"),
    F(5, -4, 0, 5, -4, 2, "iron_bars"), F(5, 0, 0, 5, 0, 2, "iron_bars"), F(5, -3, 3, 5, -1, 3, "iron_bars"), S1(5, -2, 2, "chain"), S1(5, -2, 1, "oak_slab")] });
facAdd("u09doll", { D: [10, 12, 14], box: [0, -5, 4, 5], H: 4, look: [2, 0, 1.5], marks: { shelf: [3, 0, 1.5], gate: [0, 0, 1] },
  build: () => [F(3, -5, 0, 3, 5, 0, "spruce_planks"), F(3, -5, 1, 3, 5, 1, "skeleton_skull"), F(3, -5, 2, 3, 5, 2, "spruce_slab"), F(4, -5, 0, 4, 5, 3, "spruce_planks"), F(3, -5, 3, 3, 5, 3, "skeleton_skull"), F(1, -5, 0, 1, -5, 2, "spruce_fence"), F(1, 5, 0, 1, 5, 2, "spruce_fence")] });
facAdd("u09gate", { D: [9, 11, 13], box: [0, -3, 1, 3], H: 6, look: [0, 0, 4], small: true, near: 4, marks: { crest: [-0.5, 0, 4.2] },
  build: () => [F(0, -3, 0, 0, -3, 4, "stone_bricks"), F(0, 3, 0, 0, 3, 4, "stone_bricks"), F(0, -3, 5, 0, 3, 5, "stone_bricks"), F(0, -2, 4, 0, 2, 4, "stone_brick_slab"), S1(0, 0, 4, "hay_block")] });

/* ---- 区0 の 勝った あと: 双子が サイコロを 振らなく なる ---- */
const fight0 = U.fight(0, async (p, C) => {
  await K.open(p, "常世 ― 遊び場の 区");
  K.fac(p, "u09play", "u09play", 99, U.y0(p));
  const mu = U.mu(C); await K.up(p, mu, 8);
  K.sound(p, "random.click", 0.8); await U.narr(p, ["§7どこかで、サイコロを 振る 音が した。"]);
  const a = U.boss(p, C, 0, 11, -2.4, "ヒフミ"), b = U.boss(p, C, 0, 11, 2.4, "シゴロ", true);
  await U.bossIn(p, a, 0);
  await U.say(p, "ヒフミ", ["{smile,♪,jump}あはは！ 来た 来た。シゴロ、お客さんだよ"], mu);
  await U.say(p, "シゴロ", ["{smile,…}うん。……ずっと、だれも 来なかったもんね"]);
  await U.say(p, "ヒフミ", ["{smile,☆,up}ここの 子たちは、ボールを 追いかける とちゅうで 止まっちゃった。だから ぼくらが、同じ 午後を 遊んで あげてる"]);
  await U.M(p, mu, ["{angry,怒}ガキの 遊びってのはな、日が 暮れたら 終わるもんだ。……三千年 暮れねえ 遊びが あるかよ！"], "guard");
  await U.say(p, "シゴロ", ["{angry,low}……じゃあ、次は ぼくらの 番。", "{smile}さあ、振るよ"]);
}, async (p, C) => {
  const a = U.boss(p, C, 0, 7, -2.4, "ヒフミ"), b = U.boss(p, C, 0, 7, 2.4, "シゴロ", true);
  await K.at(p, U.top(a) || p.location, 12, 7, 0);
  await U.say(p, "シゴロ", ["{sad,…}……負けちゃった。ヒフミ、つぎの 目は？"]);
  await U.say(p, "ヒフミ", ["{smile,closed}もう 振らなくて いいよ。……みんなと 遊ぼう"]);
  K.sound(p, "random.click", 0.5); await U.narr(p, ["§7白と 黒の サイコロが 石段に 転がって、それきり 動かなく なった。"]);
  for (const e of [a, b]) if (ok(e)) await fade(e, "minecraft:white_smoke_particle");
});
/* ---- 区1: イトマ ---- */
const fight1 = U.fight(1, async (p, C) => {
  await K.open(p, "常世 ― 人形の 区");
  K.fac(p, "u09doll", "u09doll", 99, U.y0(p));
  const mu = U.mu(C); await K.up(p, mu, 8);
  const e = U.boss(p, C, 1, 11, 0); await U.bossIn(p, e, 1);
  await U.say(p, "イトマ", ["{smile,…,low}あの 方は もう 決めてる。§c相棒を もらう§f って。", "{smile,♪}だから、糸で 連れて 行くの。……今まで みたいに"], mu);
  await U.M(p, mu, ["{rage,怒,jump}ふざけんな！ こいつの 相棒は こいつの もんだ！ 誰にも やらねえ！"], "guard");
  await U.E(p, mu, ["……糸は、刀で 断てる。小僧、迷うな"]);
}, async (p, C) => {
  const e = U.boss(p, C, 1, 7, 0); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "イトマ", ["{smile}負けちゃった。……ねえ。糸、切れちゃったね"]);
  const pu = C.npc("§e案内人", PJ("toma", 8), 4, 1.8, 0, "veil"); act(pu, "hold");
  if (ok(pu)) { await K.up(p, pu, 12); fx(p.dimension, "minecraft:endrod", pu.location, 6, 0.6); }
  await U.narr(p, ["§7糸が 切れた。案内人の 人形は、§8最後に 誰でも ない 顔に なって、崩れた。"], pu);
  if (ok(pu)) await fade(pu, "minecraft:basic_smoke_particle");
  if (ok(e)) await fade(e, "minecraft:portal_reverse_particle");
  U.flag(p, "camelio");
});

U.reg("u09", [
  { id: "u09e1", t: "遊び場の 区", free: false,
    syn: "遊び場の 区では、ボールを 追う 子らの 午後が、何度も くり返して いた。",
    async run(p, d, K) {
      const Cx = U.C(p);
      try {
        await K.open(p, "常世 ― 遊び場の 区");
        const pl = K.fac(p, "u09play", "u09play", 99, U.y0(p)), sand = facMark("u09play", "sand", p.location) || pl;
        if (pl) await K.at(p, pl, 16, 8, 1.5);
        const kids = [Cx.npc("", PJ("m6_pip", 8), 6, -2, 0, "veil"), Cx.npc("", PJ("mimi", 8), 6.5, 0, 0, "veil"), Cx.npc("", PJ("m6_paolo", 8), 6, 2, 0, "veil")];
        for (const k of kids) { act(k, "run"); hold(k, 0); } hold(kids[0], "orb");
        await K.wide(p, 16);
        const tgt = sand || p.location;
        for (let r = 0; r < 2; r++) { await Promise.all(kids.filter(ok).map((k, j) => K.go(k, { x: tgt.x + j - 1, y: k.location.y, z: tgt.z + (r ? 2 : -2) }, 14, true))); K.sound(p, "random.pop", 0.4, 1.4); }
        await U.narr(p, ["§7子らが ボールを 追って、走って いく。§8……同じ 角で 転び、同じ 声で 笑い、また 最初の 所へ 戻る。"], kids[1]);
        const mu = U.mu(Cx); await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……同じ 足音だ。さっきと 同じ 順で、同じ 強さで 鳴った。", "{shock,…}……三回 聞いて、三回とも 同じだ。人の 足は、そんなに 正直じゃ ねえ。"], "hold");
        await U.E(p, mu, ["……同じ 午後を、ずっと くり返して おる。終わりの 来ない 午後だ"]);
        for (const k of kids) act(k, "cheer");
        await U.rec(p, Cx, 0, ["§7『子ども ミナ、リク、ソラ、ハル。ボールを 追いかけて いた。四人とも 笑って いる』", "§8そばの 石段に、白と 黒の サイコロが 一つずつ。だれかの 字で「次は ぼくらの 番」。"], "stoneknight", "run");
        await U.E(p, mu, ["……『次は ぼくらの 番』と 書いて ある"]);
        await U.M(p, mu, ["{angry,…}……順番待ちが 三千年か。", "{closed}……並んでる 方も、たまったもんじゃ ねえな。"], "arms");
        await U.lesson(p, Cx, 0, mu);
        await U.end(p, Cx, { card: "§7→ サイコロの 音の 方へ" });
        return ok(p);
      } finally { Cx.end(); }
    } },
  { id: "u09e2", t: "次は ぼくらの 番", free: false, run: fight0, syn: "区の 主 ヒフミ＆シゴロ「次は ぼくらの 番」。サイコロ勝負。" },
  { id: "u09e3", t: "ボールの 行き先", free: false,
    syn: "転がった ボールを 相棒が くわえて 戻った。渡す 相手は、もう いなかった。ムサシが ボールを 叩くと、見た目より ずっと 年寄りの 音が した。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 遊び場の 区（夕方の まま）");
        const pl = K.fac(p, "u09play", "u09play", 99, U.y0(p));
        const kids = [C.npc("", PJ("m6_pip", 8), 6, -1.5, 0, "veil"), C.npc("", PJ("mimi", 8), 6.5, 1.5, 0, "veil")]; for (const k of kids) act(k, "cheer");
        await K.wide(p, 14); K.flash(p); K.sound(p, "block.amethyst_block.chime", 1);
        await U.narr(p, ["§7石の 子らが 一度だけ 笑って、光に なって 消えた。"]);
        for (const k of kids) if (ok(k)) await fade(k, "minecraft:endrod");
        const pm = U.pal(p, C, 7, 2);
        if (pm && ok(pm.e)) { const to = { x: p.location.x + 1.2, y: p.location.y, z: p.location.z + 0.6 }; await K.walkCam(p, pm.e, to, 22); K.re(pm.e, null, "q"); }
        await U.narr(p, [`§fあなたの ${pm ? pm.nm : "相棒"}が、転がって きた ボールを くわえて 戻って きた。`, "§8……渡す 相手は、もう いなかった。"], pm && pm.e);
        const mu = U.mu(C); await K.up(p, mu, 8);
        await U.tap(p, mu);
        await U.M(p, mu, ["{closed}……コン。……中で まだ、何か 跳ねてる 音が する。縫い目も ねえ。"], "hold");
        await U.E(p, mu, ["……この 街の 民は、鉄より 軽く、革より 丈夫な ものを 作った"]);
        await U.M(p, mu, ["{shock,?}見た目は 先の 世だ。けど 鳴りが 年寄りなんだよ。……いや、逆か？"], "up");
        await K.two(p, mu, pm && pm.e ? pm.e : mu, 10);
        await U.M(p, mu, ["{sad,…}……いい子だ。……持って 帰ろうぜ、それ。"], "kneel");
        await U.end(p, C, { leave: [mu], card: "§7→ 九冠の §e人形の 区§7 へ（右上の 案内）" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u09e4", t: "人形の 棚", free: false, F: ["F54"],
    syn: "人形の 区の 棚には、人形が いっぱいに 並んで いた。どれも、町の 案内人が 抱いて いた 人形と 同じ 顔だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 人形の 区");
        const sh = K.fac(p, "u09doll", "u09doll", 99, U.y0(p)), shelf = facMark("u09doll", "shelf", p.location) || sh;
        if (shelf) await K.push(p, shelf, 26, 8, 3, 0.5);
        /*F54 強: 棚の 人形が みな 案内人の 人形の 顔 */
        const dolls = [C.npc("", PJ("toma", 8), 6, -2.4, 0, "veil"), C.npc("", PJ("toma", 8), 6, 0, 0, "veil"), C.npc("", PJ("toma", 8), 6, 2.4, 0, "veil")]; for (const x of dolls) act(x, "kneel");
        await U.narr(p, ["§7棚と いう 棚に、人形が ぎっしり 並んで いた。", "§fどれも 同じ 顔。§7……ルミナでも、ほかの 町でも、案内人の 腕の 中に あった 顔だ。"], shelf);
        const mu = U.mu(C); await K.up(p, mu, 8);
        act(mu, "kneel"); await U.narr(p, ["§7ムサシは 一体の 人形に 耳を 寄せた。"], mu);
        await U.M(p, mu, ["{closed}……どれも 息を してねえ。", "{shock,…}けど、どれも こっちを 向いてる。俺らが 歩くと、首の 向きが 変わってる。"], "kneel");
        await U.rec(p, C, 1, ["§7『案内人 トマ。旅人を 町へ 案内して いた。……この 名前を、どこかで 聞いた 気が する』", "§8その 手首には、切れた 糸が 一本、からまって いた。"], "toma", "hold");
        await U.E(p, mu, ["……案内人 トマ、と ある。手首に、切れた 糸"]);
        await U.M(p, mu, ["{angry}……糸か。野営地の あれも、糸の 匂いが した。"], "guard");
        await U.lesson(p, C, 1, mu);
        await U.end(p, C, { card: "§7→ 糸の 先から、声が した" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u09e5", t: "ずっと 後ろに", free: false, F: ["F54"],
    syn: "九冠イトマ「ルミナから、ずっと、あなたの 後ろに いた」。町の 案内人が 抱いて いた 人形は、イトマだった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 人形の 区の 奥");
        K.fac(p, "u09doll", "u09doll", 99, U.y0(p));
        const mu = U.mu(C); await K.up(p, mu, 8);
        for (let k = 0; k < 6; k++) try { p.dimension.spawnParticle("minecraft:endrod", { x: p.location.x + 2, y: p.location.y + 2 + k * 1.2, z: p.location.z + 1 }); } catch {}
        const pu = C.npc("§e案内人", PJ("toma", 8), 4.2, 1.8, 0, "veil"); act(pu, "hold"); if (ok(pu)) await K.up(p, pu, 12);
        /*F54 回: 案内人の 人形は イトマ。ずっと 主人公の 後ろに いた */
        await U.say(p, "イトマ", ["{smile}……やあ。久しぶり。", "{smile,?,up}覚えて ない？ ルミナで 最初に 会ったじゃ ないか。§e案内人§f だよ"], mu);
        await U.M(p, mu, ["{shock,!,jump}な、なんだ あの 声！ 糸の 先から しゃべってやがる！"], "guard");
        await U.say(p, "イトマ", ["{smile,…,low}あの 案内人は、わたしの 人形。ワープも、遊び方も、ぜんぶ 糸で しゃべらせたの"]);
        await K.push(p, pu, 18, 3, 1.6, 1.5);
        await U.say(p, "イトマ", ["{smile,♪,up}ルミナから、ずっと、あなたの 後ろに いた"]);
        await U.narr(p, ["§7……どの 町でも、案内人は あなたの 少し 後ろに 立って いた。§8振り返ると、いつも 人形が こちらを 見て いた。"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}糸で しゃべらせた 声か。……どうりで、あの 案内人の 声には 揺れが なかった。"], "guard");
        await U.E(p, mu, ["……小僧には、聞こえて いたか"]);
        await U.M(p, mu, ["{closed}生きてる 声は、もっと 揺れる。"]);
        U.flag(p, "camelio");
        await U.end(p, C, { card: "§7→ 糸の 主が、棚の 上から 下りて くる" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u09e6", t: "糸の 主", free: false, run: fight1, syn: "九冠イトマとの 戦い。糸が 切れると、案内人の 人形は 誰でも ない 顔に なって 崩れた。" },
  { id: "u09e7", t: "糸の 先", free: false,
    syn: "糸の 切れた イトマが、小さな 人形の 姿で 残った。放すか、案内を 続けて もらうか。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 人形の 区");
        K.fac(p, "u09doll", "u09doll", 99, U.y0(p));
        const mu = U.mu(C);
        const it = C.npc("§5イトマ", PJ("toma", 8), 3.6, -0.6, 0, "smoke"); act(it, "kneel"); if (ok(it)) await K.up(p, it, 14);
        await U.say(p, "イトマ", ["{sad,…}……糸が 一本だけ 残った。これで、区と 区の あいだくらいは 案内 できる", "{closed}放して くれたら、わたしは わたしの 一日へ 帰る。……案内人 トマが 旅人を 待って いた、あの 一日へ"], mu);
        await K.two(p, mu, it, 10);
        await U.M(p, mu, ["{?}……どっちが いいんだ、お前は。"], "hold");
        await U.say(p, "イトマ", ["{smile,…}どっちでも。……でも、この 先の 塔が 明日を 迎えたら、区ごと わたしも 崩れる。それは 覚えて おいて"]);
        await K.ots(p, mu, p, 10);
        await U.M(p, mu, ["{closed}……お前が 決めろ。こいつの 糸を 持ってるのは、お前だ。"], undefined, p);
        const v = await K.pick(p, "u09");
        if (v === "f") {
          if (ok(it)) { act(it, "bow"); fx(p.dimension, "minecraft:endrod", it.location, 8, 0.6); }
          await U.say(p, "イトマ", ["{smile,closed}……ありがとう。旅人を 待つ 一日、きらいじゃ なかったの"]);
          if (ok(it)) await fade(it, "minecraft:endrod");
          await U.narr(p, ["§7最後の 糸が ほどけた。§8……区と 区を つなぐ 案内は、もう ない。"]);
          await U.M(p, mu, ["{closed}……歩いて 行けば いい。足音が 道を 覚える。"], "hold");
        } else {
          if (ok(it)) { act(it, "hold"); hold(it, "rope"); }
          await U.say(p, "イトマ", ["{smile,♪}じゃあ、もう少し 後ろに いるね。……今度は、ちゃんと 声を かけて から"]);
          await U.narr(p, ["§7イトマは 小さな 人形の 姿で、あなたの 少し 後ろに ついた。§8……区と 区の あいだは、糸が 教えて くれる。"]);
          await U.M(p, mu, ["{angry,汗}……後ろに 立つなら、足音くらい 立てろよ。"], "arms");
        }
        await U.end(p, C, { leave: [mu], card: "§7→ 区の 門へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u09e8", t: "麦の 紋", free: false, F: ["F55"],
    syn: "区の 門の 上に、麦の 紋が 彫って あった。ムサシ「ルミナの パン屋の 看板と、同じ 形だ」。常世の 人々は、今の 町の 人と つながって いる。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 人形の 区の 門");
        const g = K.fac(p, "u09gate", "u09gate", 99, U.y0(p)), cr = facMark("u09gate", "crest", p.location) || g;
        if (cr) await K.at(p, cr, 18, 5, 0);
        const mu = U.mu(C); await K.up(p, mu, 8);
        /*F55 強: 区の 門の 麦の 紋 */
        await U.M(p, mu, ["{shock,?,up}……おい、あの 紋。", "{closed}ルミナの パン屋の 看板と、同じ 形だ。字は 読めねえが、形なら 覚えてる。"], "point");
        await U.E(p, mu, ["……麦の 紋だ。この 区の 先、鏡の 区の 家の 紋でも ある"]);
        await U.M(p, mu, ["{?}……三千年前の 門に、今の パン屋の 看板か。", "{closed}……ここの 連中、俺らの じいさんの じいさんの、もっと 前の 誰かかも な。"], "hold");
        if (K.ch(p, "u09") === "k") await U.narr(p, ["§7後ろで、小さな 人形が うなずいた。"]);
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 八冠の §e鏡の 区§7 へ（右上の 案内）" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(0, ["u09e1", "u09e2"], ["u09e3"]);
U.ward(1, ["u09e4", "u09e5", "u09e6"], ["u09e7", "u09e8"]);
