// 第127版: 育成・編成の 相談（ゲームの データから 作る ので いつも 正しい）。町の 人・トークブックが 使う
// tipOf(種類, d, r) → { t: 文, f: 点検用の 中身 }。r は 0〜1 の 数（決まった 文を 出したい ときに 渡す）
import { SPECIES, ORDER, RANKS, FAMILIES, FAM_MIX3, NATURES, ST_NAME, EL_NAME, RES_MULT, COMBOS, SKILLS, TRAITS, WEATHER, FAM_BONUS_TEXT } from "./data.js";
import { SKILL_N, SIZE_SLOT, PARTY_CAP, TM_STAT, TERR_NAME, BAND_NAME } from "./core.js";

export const FN = Object.fromEntries(FAMILIES.map((f) => [f.id, f.name]));
const NG = /ムサシ|エンマ|サヤ|ゼファード|セオ|アルゴ|イトマ|リョウマ|ベルガ|ヴォルナグ|ヴァルグレイド|セレネ/;   /* 名前に ネタバレの ある 種族は 相談に 出さない */
/* ソースに 書いて ある 決まりを 写した もの（点検で core.js・battle.js と くらべる）*/
export const HID = [0.01, 0.35, 0.6];   /* 隠れ特性: 親に 0・1・2体 いると 子に 出る 割合 */
export const PLUS2 = [1.15, 5, 2], PLUS4 = [1.2, 6, 5];   /* 配合の プラス値: 親の 平均×a ＋ レベルの 合計÷b ＋ c */
export const SCOUT = { hurt: 0.8, charm: 20, sleep: 6, item: 30, trait: 25, wild: 95, master: 40 };
export const BOOK = [[25, "小"], [50, "中"], [75, "大"], [99, "極"]];
const rk = (sp) => RANKS.indexOf((SPECIES[sp] || {}).rank);
const pickR = (L, r) => L[Math.floor((r ?? Math.random()) * L.length) % Math.max(1, L.length)];
const okSp = (id) => { const S = SPECIES[id]; return S && !S.hidden && !S.special && !S.special4 && !S.metalmon && !["king", "god"].includes(S.fam) && !NG.test(S.name); };
/* 相談に 使う 種族: 自分の 仲間 → 見た ことの ある 種族 → 低い ランク */
function spPool(d) {
  const mine = [...((d && d.party) || []), ...((d && d.bench) || [])].map((m) => m && m.sp).filter(okSp);
  if (mine.length) return [...new Set(mine)];
  const seen = new Set(((d && d.seen) || []).concat((d && d.own) || []));
  const L = ORDER.filter((id) => okSp(id) && seen.has(SPECIES[id].idx));
  return L.length ? L : ORDER.filter((id) => okSp(id) && rk(id) <= 2);
}
export const plusOf = (pl, lv) => { const n = pl.length, [a, b, c] = n === 4 ? PLUS4 : PLUS2, avg = pl.reduce((x, y) => x + y, 0) / n, ls = lv.reduce((x, y) => x + y, 0); return Math.min(999, Math.floor(avg * a) + Math.floor(ls / b) + c); };
export const TIPK = {
  mix: (d, r) => {
    const fam = [...new Set(((d && d.party) || []).map((m) => m && SPECIES[m.sp] && SPECIES[m.sp].fam).filter((f) => f && FN[f] && !["king", "god"].includes(f)))];
    let key = null; if (fam.length >= 2) { const k = [fam[0], fam[1]].sort().join("|"); if (FAM_MIX3[k]) key = k; }
    if (!key) key = pickR(Object.keys(FAM_MIX3), r);
    const band = Math.floor(((r ?? Math.random()) * 7) % 3), [a, b] = key.split("|"), [x, y] = FAM_MIX3[key][band];
    return { t: `${FN[a]}と ${FN[b]}を 配合すると、親の いちばん 高い ランクが ${BAND_NAME[band]}なら、子は ${FN[x]}${x === y ? "" : `か ${FN[y]}`}に なる。ランクの 帯が かわると 生まれる 系統も かわる`, f: { key, band, x, y } };
  },
  plus: (d, r) => {
    const four = (r ?? Math.random()) < 0.35, n = four ? 4 : 2, pl = Array.from({ length: n }, (_, i) => 5 + ((Math.floor((r ?? Math.random()) * 97) + i * 13) % 30)), lv = Array.from({ length: n }, (_, i) => 20 + ((Math.floor((r ?? Math.random()) * 53) + i * 7) % 25));
    const v = plusOf(pl, lv);
    return { t: `配合の プラス値は、親の プラス値と レベルで 決まる。たとえば ${pl.map((x, i) => `+${x}・Lv${lv[i]}`).join("と ")}の ${n}体なら、子は +${v}。レベルを 上げてから 配合すると 得なんだ（4体配合は 親の 平均が ${PLUS4[0]}倍に なる）`, f: { pl, lv, v } };
  },
  hid: () => ({ t: `隠れ特性は、親の どちらかが 持って いれば ${Math.round(HID[1] * 100)}%、両方 持って いれば ${Math.round(HID[2] * 100)}%で 子に 出る。どちらも 持って いないと ${Math.round(HID[0] * 100)}%しか ない`, f: { HID } }),
  skn: (d, r) => { const z = pickR(["S", "M", "L", "G"], r); return { t: `覚えられる スキルの 数は 体の 大きさで 決まる。S は ${SKILL_N.S}つ、M は ${SKILL_N.M}つ、L は ${SKILL_N.L}つ、G は ${SKILL_N.G}つ。闘魔覚醒すると 1つ ふえる（${z} なら ${SKILL_N[z] + 1}つ）`, f: { z } }; },
  slot: () => ({ t: `仲間の 枠は ${PARTY_CAP}つ。S は ${SIZE_SLOT.S}枠、M は ${SIZE_SLOT.M}枠、L は ${SIZE_SLOT.L}枠、G は ${SIZE_SLOT.G}枠 使う。大きい 子 一体か、小さい 子を ならべるか ── 編成は そこから 考えると いい`, f: { SIZE_SLOT, PARTY_CAP } }),
  scout: () => ({ t: `スカウトは、相手が 弱って いるほど 心が ひらく（体力が 減ると 最大 ${1 + SCOUT.hurt}倍）。魅了なら ＋${SCOUT.charm}、眠りや 氷づけなら ＋${SCOUT.sleep}。道具は 1回 ＋${SCOUT.item}まで。野生は ${SCOUT.wild}%まで 上がるが、人の 連れて いる 子は ${SCOUT.master}%までだ`, f: SCOUT }),
  tm: () => ({ t: `闘魔覚醒は、プラス値が 99に なった 子だけが できる。能力が ${TM_STAT}倍に なって、スキルの 枠が 1つ ふえる。神系（Xランク）は 覚醒できない`, f: { TM_STAT } }),
  tmx: () => ({ t: "闘魔解放は、闘魔の 腕輪が いる。戦いの 中で 1回・1体だけ。その 戦いの 終わりまで 全能力 +1段階、与える ダメージ +10%。闘魔覚醒した 子か、同じ 系統の 闘魔石を 持って いる 子が 使える。神系は できない", f: {} }),
  wx: (d, r) => { const k = pickR(Object.keys(WEATHER), r), W = WEATHER[k]; return { t: `天気で 技の 強さが かわる。${W[0]}なら ${W[3]}。天気を かえる 技を 持つ 子が 一体 いると、戦いの 流れが 変わる`, f: { k, s: W[3] } }; },
  terr: (d, r) => { const k = pickR(Object.keys(TERR_NAME), r); return { t: `戦う 場所にも 属性が ある。${TERR_NAME[k]}では ${EL_NAME[k]}の 技が 1.2倍。地方の 石板に 挑む 前に、そこの 地形に 合う 技を 持たせて おくと いい`, f: { k } }; },
  res: (d, r) => {
    const L = spPool(d).filter((id) => Object.values(SPECIES[id].res || {}).some((v) => v === -1 || v === 2 || v === 4));
    const id = pickR(L.length ? L : spPool(d), r), S = SPECIES[id], R = S.res || {};
    const weak = Object.keys(R).filter((e) => R[e] === -1 && EL_NAME[e]), nul = Object.keys(R).filter((e) => (R[e] === 2 || R[e] === 4) && EL_NAME[e]);
    const t = weak.length ? `${S.name}は ${weak.map((e) => EL_NAME[e]).join("・")}に 弱い（${RES_MULT[-1]}倍）。` : "";
    const u = nul.length ? `${nul.map((e) => EL_NAME[e]).join("・")}は ${R[nul[0]] === 4 ? "吸いこむ" : "効かない"}。` : "";
    return { t: `${t}${u}${t || u ? "" : `${S.name}は 目立った 弱点が ない。`}相手の 系統だけで なく、属性の 得手不得手まで 図鑑で 見て おくと 負けが 減る`, f: { id, weak, nul } };
  },
  nat: (d, r) => { const N = pickR(NATURES, r); return { t: `性格『${N.name}』の 子は ${ST_NAME[N.up]}が 伸びやすく、${ST_NAME[N.down]}が 伸びにくい。配合で 性格を えらべる ときは、その 子の 役目に 合わせて`, f: { n: N.name, up: N.up, down: N.down } }; },
  combo: (d, r) => {
    const [id, a, b] = pickR(COMBOS, r), sn = (x) => { const L = [].concat(x), k = L.find((y) => SKILLS[`${y}0`] || SKILLS[`${y}1`]); const n = ((k && (SKILLS[`${k}0`] || SKILLS[`${k}1`])) || {}).name || String(L[0]); return n.replace(/・.*$/, "") + (L.length > 1 ? "』など『" : ""); };
    const nm = ((SKILLS[`${id}0`] || SKILLS[`${id}1`] || {}).name || "合わせ技").replace(/・.*$/, ""), an = sn(a).replace(/』など『$/, ""), bn = sn(b).replace(/』など『$/, "");
    return { t: `配合の 親たちが『${an}』${[].concat(a).length > 1 ? "の なかま" : ""}と『${bn}』${[].concat(b).length > 1 ? "の なかま" : ""}の スキルを 持って いると、子は『${nm}』を 覚えられる。親の 段が 高いほど、合わせ技の 段も 上がる`, f: { id, a, b } };
  },
  team: (d, r) => {
    const k = Math.floor((r ?? Math.random()) * 3) % 3, Z = ["S", "M", "L", "G"], sz = (z) => SIZE_SLOT[z];
    const T = [[["S", "S", "S", "S"], "S が 4体"], [["M", "M"], "M が 2体"], [["L", "S"], "L と S"]][k], n = T[0].reduce((a, z) => a + SKILL_N[z], 0);
    return { t: `${T[1]}なら 枠は ちょうど ${T[0].reduce((a, z) => a + sz(z), 0)}つ、覚えられる スキルは 合わせて ${n}。数で 押すか、大きい 子の 技の 幅で 押すか。相手の 数が 多い 戦いは 小さい 子を ならべる ほうが 手数で 勝てる`, f: { set: T[0], n } };
  },
  book: () => ({ t: `親の プラス値が ${BOOK.map(([v]) => v).join("・")}を こえて いて、子が 受けつがなかった スキル（20pt 以上 振った もの）が 3つ 以上 あると、魔書が 生まれる。捨てた スキルを あとで 戻せる`, f: { BOOK } }),
  fam: (d, r) => { const k = pickR(Object.keys(FAM_BONUS_TEXT).filter((f) => FN[f] && f !== "god"), r); return { t: `${FN[k]}の 子は ${FAM_BONUS_TEXT[k]}。同じ 系統で そろえるか、苦手を 消し合う ように 混ぜるか。強い 編成は たいてい 後の ほうだ`, f: { k } }; },
  trait: (d, r) => {
    const L = spPool(d).filter((id) => (SPECIES[id].traits || []).some((t) => TRAITS[t]));
    const id = pickR(L.length ? L : spPool(d), r), S = SPECIES[id], tl = (S.traits || []).filter((t) => TRAITS[t]), t0 = pickR(tl.length ? tl : [null], r);
    if (!t0) return { t: `${S.name}は 特性より 能力で 勝負する 子だ。スキルで 補って やると いい`, f: { id } };
    return { t: `${S.name}の 特性『${TRAITS[t0].name}』は ${TRAITS[t0].desc}。特性を 生かす 編成を 考えると、同じ 子でも 別人みたいに 強く なる`, f: { id, tr: t0 } };
  },
};
export const TIP_KINDS = Object.keys(TIPK);
export function tipOf(kind, d, r) { const f = TIPK[kind] || TIPK.slot; try { return f(d, r); } catch { return TIPK.slot(d, r); } }
