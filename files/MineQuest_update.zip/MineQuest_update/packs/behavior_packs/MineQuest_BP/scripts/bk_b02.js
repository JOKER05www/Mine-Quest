/* 第126版 本2「森の精霊石」（シルヴァ大森林・ルミエ／リーフィ／シルヴァン）— 作業 MA
   ・古い 話 r1e1・r1e2・r1e3・r1e5（ep_r1.js）を 生かす。新しい 話: 3話 天幕の 朝・4話 リーフィの 貸本屋
   ・MQ3 = b02e6（洞くつの 入口・ベリル）／MQ4 = b02e7（奥の 大広間・精霊・守り手の 印）／MQ5 = b02e8（森の 主・女王 エルゼ ＋ 砦の 下の 切り株）*/
import { bkAdd, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { H4, Y, OLDE, oldRun, mqRun, once, gy, at2, out } from "./bk_b01.js";
import { placeOf, bldOf } from "./storyplace.js";
import { ok } from "./ui.js";

const C0 = (K, p) => { const S = K.S(p); return S && S.opt && S.opt.anchor ? S.opt.anchor : p.location; };
const PL = (oid) => (p) => { const o = OLDE(oid); try { return o ? o.place(p) : null; } catch { return null; } };
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
const LIB = () => bldOf("t9", ["library", "shop", "inn"], "こもれびの 村 リーフィの 貸本屋");

/* ---------- 登場人物 ---------- */
castAdd("b02lend", { nm: "ネネ", role: "貸本屋の", gobi: "ね", skin: 12, town: "t9", hide: (s) => !bkHas(s, "b02e4"),
  at: () => { const q = LIB(); return q ? { x: q.x, y: q.y, z: q.z } : null; },
  pre: ["{smile}本なら 一冊 一日 ね。"],
  after: [
    [(s) => !!s.ending, ["{smile}あの 学者さん、また 来て くれたら いいね。……返して もらって ない 本は、ないんだけどね。"]],
    [(s) => bkHas(s, "b02e9"), ["{smile}ピピちゃん、薬の 本を 毎日 借りに 来るね。もう 半分は 覚えちゃったね。"]],
    [() => true, ["{closed}一度 読んだら 忘れない 学者さん。……忘れられない、とも 言ってたね。"]],
  ] });

/* ---------- 1話 ほたるの 里ルミエ（古い r1e1 ＋ 石の 子の 足もとの 切れ端）---------- */
const E1 = { id: "b02e1", pv: 127, t: "消えた ほたる", F: ["F06", "F65"], battles: 0, fac: "r1brook",
  place: PL("r1e1"),
  hint: "§fほたるの 里 §eルミエの 外れの ほたるの 小川§f へ 行こう §7（里長の §eハッカ婆§7 が 待って いる）",
  syn: "ルミエでは ほたるが 消え、森の 葉が 灰色に くすんで いた。ルミエの ほたるは 初雪の 夜に 光る「冬ほたる」。薬師見習いの ピピは、小川の そばの 石の 男の子に 毎日 話しかけて いる。石の 子の 足もとには、灰色の 染みの ついた 絵本の 切れ端が 落ちて いた。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r1e1", E1))) return false;
    const c = C0(K, p), y0 = Y(K, p), kq = { x: Math.floor(c.x) - 9, y: y0, z: Math.floor(c.z) - 5 };
    once("b02scrap", () => { const y = gy(p, kq.x + 1, kq.z, y0); if (y !== null) K.cmd(p, `setblock ${kq.x + 1} ${y} ${kq.z} light_gray_carpet keep`); });
    await K.open(p, "ほたるの 小川（夕ぐれ）", "dusk", "dusk");
    const eP = K.cast(p, "r1pipi"), eH = K.hero(p);
    await K.push(p, { x: kq.x + 1.5, y: y0, z: kq.z + 0.5 }, 24, 4, 1.4, 0.2);   /* 石の 子の 足もと /*F65*/
    await K.narr(p, ["§7石の 男の子の 足もとに、絵本の 切れ端。灰色の 染みが、字の 上に しみて いる。"], { x: kq.x + 1.5, y: y0, z: kq.z + 0.5 });
    await K.up(p, eP, 8);
    await K.csay(p, "r1pipi", ["{sad}その 切れ端、ピピが 来た ときから あるのだ。……石の 子の 本、なのだ。", "{smile,up}初雪の 夜に なったら、冬ほたるを 見せて あげるのだ。ルミエの ほたるは、初雪の 夜に 光るのだ。"], eH);   /* /*F06*/
    await K.hsay(p, H4(["{smile}冬ほたる……。見たいな。"], ["{smile}冬ほたる。きれいな 名前ね。"], ["{closed}冬ほたる。……初雪の 夜。"], ["{smile}冬ほたる……すてきな 名前ですね。"]), eP);
    await K.end(p, { leave: [eP] });
    return true;
  } };

/* ---------- 2話 ルミエの 薬草の 森（古い r1e2）---------- */
const E2 = { id: "b02e2", t: "薬草さがし", F: ["F05"], battles: 1, fac: "r1tent", pv: 127,
  place: PL("r1e2"),
  hint: "§fルミエの 外れの §e薬草の 森§f で ピピと 薬草を さがそう",
  syn: "ピピの 薬の 本は、大事な 頁が 虫に 食われて いた。学者セオは その 頁を、一字も まちがえずに 書きこんだ。「本の 字と そっくりで、どっちが 本物か 分からないのだ」。セオは「十二年前に、ルミエの 宿で 一度 読んだ ことが あるんです」と 言った。その 夜、セオは 泣き つかれた ピピに 竜の 絵本を 読んだ。",
  async run(p, d, K) {
    return oldRun(p, d, K, "r1e2", E2);   /* セオが 虫食いの 頁を 書きこむ /*F05*/
  } };

/* ---------- 3話 ルミエの 天幕（新）---------- */
const E3 = { id: "b02e3", t: "天幕の 朝", F: ["F06"], battles: 0, fac: "r1tent", pv: 127,
  place: PL("r1e2"),
  hint: "§fルミエの 外れの §e薬草の 森の 天幕§f へ もどろう §7（ピピが いない）",
  syn: "朝の 天幕に ピピの 姿は なく、寝床に 竜の 絵本が 残って いた。表紙の 裏に、子どもの 字で「セオにいちゃんの」。セオは だまって 本を 閉じた。ハッカ婆は「祭りは 日を 決めませぬ。初雪 しだいですのう」と 言い、ピピは きのう リーフィの 貸本屋に いたと 教えた。",
  async run(p, d, K) {
    const tq = K.fac(p, "r1tent", "tent", 1, Y(K, p)) || at2(K, p, 7, 0, 1);
    await K.open(p, "ルミエの 天幕（朝）", "day");
    const eH = K.hero(p), eS = THEO(K, p); K.hold(eS, "notebook");
    await K.at(p, tq, 16, 3.2, 0.6);
    await K.narr(p, ["§7天幕の 寝床は からっぽ。毛布の 上に、ゆうべの 竜の 絵本が 開いた まま。"], tq);
    if (ok(eS)) await K.walkCam(p, eS, at2(K, p, 5.5, 0.8), 14);
    K.act(eS, "show");
    await K.push(p, eS, 22, 3, 1.2, 1.1);   /* 表紙の 裏 /*F06*/
    await K.narr(p, ["§7拾いあげた 絵本の 表紙の 裏。子どもの 字で、大きく「セオにいちゃんの」。"], eS);
    K.act(eS, "hold"); K.sound(p, "item.book.put", 1);
    await K.up(p, eS, 10);
    await K.say(p, "セオ", ["{closed,…}…………。"]);
    await K.hsay(p, H4(["{?}セオさん、その 字……"], ["{?}……セオさん。その 字は……"], ["{?}……その 字。"], ["{?}セオさん、その 字は……"]), eS);
    await K.say(p, "セオ", ["{smile}……古い 本ですから。それより、ピピさんです。"]);
    const eK = K.cast(p, "r1hakka"); K.hold(eK, "staff");
    await K.up(p, eK, 8);
    await K.csay(p, "r1hakka", ["{sad}ピピは 朝から おりませんのう。……祭りの ことで、すねて おるのですのう。", "{closed}ルミエの 祭りは、日を 決めませぬ。初雪 しだいですのう。"], eH);
    await K.csay(p, "r1hakka", ["{?,up}そう いえば ピピは きのう、§eリーフィの 貸本屋§f で 何か 借りて おりましたのう。"], eH);
    await K.hsay(p, H4(["{!,up}リーフィ！ 行って みよう！"], ["{!}リーフィね。行きましょう。"], ["{closed}リーフィ。行く。"], ["{!}リーフィですね。参りましょう。"]), eK);
    await K.end(p, { leave: [eS, eK], card: "§7― こもれびの 村 リーフィへ ―" });
    return true;
  } };

/* ---------- 4話 リーフィの 貸本屋（新）---------- */
const E4 = { id: "b02e4", t: "リーフィの 貸本屋", F: ["F05"], battles: 0,
  place: () => LIB(),
  hint: "§fこもれびの 村 §eリーフィの 貸本屋§f へ 行こう §7（ピピの 行き先を 聞く）",
  syn: "リーフィの 貸本屋の ネネは、ピピが「病んだ 森の 地図」を 借りて いったと 言った。セオの ことも 覚えて いた。「一度 読んだら 忘れない 学者さん。……忘れられない、とも 言ってたね」。",
  async run(p, d, K) {
    await K.open(p, "こもれびの 村 リーフィの 貸本屋", "day");
    const eH = K.hero(p), eN = K.cast(p, "b02lend"); K.hold(eN, "notebook");
    await K.up(p, eN, 10);
    await K.csay(p, "b02lend", ["{smile}いらっしゃい。……ピピちゃん？ きのうの 夕方、来たね。", "{?}『病んだ 森の 地図』を 借りて いったね。薬の 材料が どうとか 言ってたね。"], eH);
    await K.hsay(p, H4(["{shock,!,up}病んだ 森！？ ひとりで！？"], ["{shock,…}……ひとりで、病んだ 森へ？"], ["{shock,!}……ひとりで 行った。"], ["{shock,!,up}ひ、ひとりで 病んだ 森へ……！？"]), eN);
    await K.csay(p, "b02lend", ["{closed}地図の 返し日は、きょう だね。……返しに 来て くれると いいね。"]);
    /* セオの こと /*F05*/
    await K.csay(p, "b02lend", ["{?}そう いえば、昔、ルミエの 宿に 泊まった 学者さんが ここにも 来たね。", "{closed}一度 読んだら 忘れない 学者さん。……忘れられない、とも 言ってたね。"], eH);
    await K.up(p, eH, 8);
    await K.hsay(p, H4(["{?,…}……忘れられない、か。……それより ピピ！ 急ごう！"], ["{sad}……忘れられない、ね。……ピピちゃんを 追いましょう。"], ["{closed}……忘れられない。……今は ピピ。行く。"], ["{sad}……忘れられない、ですか。……ピピさんを 追いましょう！"]));
    await K.end(p, { leave: [eN], card: "§7― ルミエの 外れの 病んだ 森へ ―" });
    return true;
  } };

/* ---------- 5話 病んだ 森（古い r1e3）---------- */
const E5 = { id: "b02e5", t: "白紙の 座", F: ["F16", "F50"], battles: 1, fac: "r1grove", pv: 127,
  place: PL("r1e3"),
  hint: "§fピピが ひとりで 森へ！ §eルミエの 外れの 病んだ 森§f へ 急ごう",
  syn: "病んだ 森で 囲まれた ピピを 助けた。灰色の 服の 少女が 紙を 落とした。六つの 行と、白紙の 行が 一つ。セオは「古い 紙ですね。書庫の 目録の 書式に 似て いる」と 返し、幼なじみは「落とした 子に 返せる ように、わたしが 持っとく」と しまった。",
  async run(p, d, K) {
    return oldRun(p, d, K, "r1e3", E5);   /* 座の 紙・白紙の 行 /*F50 F16*/
  } };

/* ---------- 6話 大樹の 根の 洞くつ（MQ3。今の 段の 場面: セオ・懐中電灯・ベリル）---------- */
const E6 = { id: "b02e6", t: "大樹の 根の 洞くつ", stage: { move: false },
  hint: "§fシルヴァ大森林の §e大樹の 根の 洞くつ（入口）§f へ 行こう §7（セオが 待って いる）",
  syn: "洞くつの 入口で セオと 落ちあい、懐中電灯を 受け取った。六影の 幹部候補 ベリルが 現れ、石板を 賭けて 戦った。「帰る 場所は、もう 六影しか ない」。",
  async run(p, d, K) {
    return mqRun(p, d, 3);
  } };

/* ---------- 7話 洞くつの 奥の 大広間（MQ4。霧が 主人公と 相棒だけ 避ける ＋ 今の 段の 場面）---------- */
const E7 = { id: "b02e7", t: "守り手の 印", F: ["F02", "F31"], keys: ["k_mark"],
  hint: "§fシルヴァの §e大樹の 根の 洞くつ§f を 下りきった §e奥の 大広間§f へ 行こう",
  syn: "精霊の 紫の 霧が 一行を 包んだが、あなたと 相棒の まわりだけ 避けて 流れた。精霊は「届かない 者だけが、主の 前に 立てる」と 言い、守り手の 印を 残した。「二人で 一つ。片方が 呑まれても、もう 片方が 呼べば 戻れる」。相棒が はじめて 話した。",
  async run(p, d, K) {
    await K.open(p, "洞くつの 奥の 大広間", "night");
    const eH = K.hero(p), g = K.palEnt(p), c = C0(K, p);
    /* 紫の 霧が 主人公と 相棒だけ 避ける /*F31*/
    await K.wide(p, 16);
    for (let i = 0; i < 3; i++) { K.burst(p.dimension, { x: c.x, y: c.y + 1, z: c.z }, "minecraft:portal_reverse_particle", 18, 3.2, 0.3); await K.wait(6); }
    await K.narr(p, ["§7奥から 紫の 霧が 流れて きて、一行を 包む。……幼なじみが 目を こする。", "§7けれど あなたと 相棒の まわりだけ、霧は ふれずに 避けて 流れた。"], g || eH);
    await K.up(p, eH, 8);
    await K.hsay(p, H4(["{shock,…}……頭の 中で、だれかが ささやいてる……。あなたは 平気なの？"], ["{shock,…}……耳の 奥で、何か ささやいてる。あなたは……平気なの？"], ["{shock}……何か 聞こえる。……あなたは、聞こえないの？"], ["{shock,…}……何か、ささやき声が……。あなたは、平気なのですか？"]));
    if (g) K.rmCine(g);
    return mqRun(p, d, 4);   /* 精霊・守り手の 印・相棒の 声 /*F02*/
  } };

/* ---------- 8話 樹上の 砦シルヴァン（MQ5。森の 主・女王 エルゼ ＋ 砦の 下の 切り株と 石の 妖精）---------- */
const E8 = { id: "b02e8", t: "樹上の 砦", F: ["F05"], stage: { move: false },
  hint: "§f森の 精霊石を §bシルヴァの ステージ（大地）§f で 使おう",
  syn: "精霊石の 光で 弱った 森の 主を、殺さずに しずめた。樹上の 砦 シルヴァンの 女王 エルゼが 人間の 罪を 問うた。砦の 下には 人の 斧の 跡の 切り株と、石に なった 妖精の 列。一行は 頭を 下げて 謝った。精霊は「同じ 影が、廃都の 壁画に 描かれて いる」と 告げた。",
  async run(p, d, K) {
    const s0 = K.qs(K.load(p) || d);
    await K.open(p, "シルヴァの 大地", "day");
    const eH = K.hero(p);
    if (!(s0.gate || {})[1]) {
      const q = at2(K, p, 8, 0);
      K.sound(p, "mob.ravager.roar", 0.7); K.shake(p, 0.9, 1.2);
      K.burst(p.dimension, q, "minecraft:spore_blossom_ambient_particle", 12, 2.5, 0.5);
      await K.at(p, q, 14, 6, 1.6);
      K.big(p, "§2§l森の 主が 目を さました！", "§f精霊石の 光に 引かれて", "mob.ravager.roar");
      const eS = THEO(K, p); K.act(eS, "run", false);
      await K.up(p, eS, 8);
      await K.say(p, "セオ", ["{!}森の 主が……！ 精霊石の 光で 弱って いる 今しか ありません。", "{angry}倒すのでは なく、しずめて 眠らせて ください！"]);
      if (!K.flag(p, "b02e8w")) {
        await K.duel(p, "§2§l森の 主", "§a弱った 主を しずめろ！", { fams: ["animal"] });
        const r = await K.battle(p, K.bossOne(["animal", "animal"], 22, 40, 2), { name: "森の 主", arena: "森の 主", theme: "forest", hpk: 6, extra: 0.3, tag: "森の主", sboss: true, speaker: "森の 主", lines: { half: "……グルル……", low: "……ネム……イ……" } });
        if (r !== "win") { await K.sayAt(p, "§7学者 セオ", 18, "セオ", ["{sweat,汗}いったん 引きましょう。もう一度 精霊石を！", K.RT(p)]); return false; }
        K.setFlag(p, "b02e8w");
      }
      const dd = K.load(p); if (dd) { const ss = K.qs(dd); ss.gate = { ...(ss.gate || {}), 1: true }; K.save(p, dd); }
      K.burst(p.dimension, q, "minecraft:villager_happy", 10, 2.5, 0.6);
      const eS2 = THEO(K, p, true);
      await K.up(p, eS2, 8);
      await K.say(p, "セオ", ["{smile}……眠りました。葉の 色が、戻って いく。"]);
      /* 精霊の 声 → 石の 裏の 字（セオは 読みかけて やめる）/*F05*/
      K.sound(p, "random.orb", 0.8);
      await K.narr(p, ["§7精霊石の 中から、小さな 声。「……わたしの 根を 枯らした 影と 同じ 影が、§e廃都グランディアの 壁画§7に 描かれて いる」"], eH);
      K.act(eS2, "hold"); K.hold(eS2, "orb");
      await K.up(p, eS2, 8);
      await K.say(p, "セオ", ["{closed}……石の 裏に、古い 文字が ありますね。『影を 知る 者は――』", "{sad,…}…………いえ。知らない ほうが いい ことも あります。"]);
      await K.hsay(p, H4(["{?}学者さんなのに？"], ["{?}学者さんが、そんな ことを 言うの？"], ["{?}学者が それを 言う？"], ["{?}学者の 方が、そう おっしゃるのですか？"]), eS2);
      await K.say(p, "セオ", ["{closed}学者 だから、ですよ。一度 読んだ 字は、頭から 出て いかない。", "{smile}……廃都には レイくんも 向かって います。僕は 書庫に 寄って から 追います。"]);
      K.act(eS2, 0);
      await K.end(p, { leave: [eS2], card: "§7― 樹上の 砦 シルヴァンへ ―" });
    }
    /* 樹上の 砦 シルヴァン（砦の 下）*/
    const q = placeOf("court", 1);
    if (q) await K.moveTo(p, { x: q.x, y: q.y, z: q.z }, "樹上の 砦 シルヴァン（砦の 下）"); else await K.open(p, "樹上の 砦 シルヴァン（砦の 下）", "day");
    const y0 = Y(K, p), base = at2(K, p, 7, 0);
    once("b02stumps", () => { for (const [a, b] of [[7, -3], [8, 1], [6, 3]]) { const w = at2(K, p, a, b), y = gy(p, w.x, w.z, y0); if (y !== null) K.cmd(p, `setblock ${Math.floor(w.x)} ${y} ${Math.floor(w.z)} stripped_oak_log`); } for (const b of [-2, -1, 0, 1, 2]) { const w = at2(K, p, 10, b), y = gy(p, w.x, w.z, y0); if (y !== null) K.cmd(p, `setblock ${Math.floor(w.x)} ${y} ${Math.floor(w.z)} stone_brick_wall`); } });
    const eH2 = K.hero(p), eE = K.npcNear(p, "§a女王 エルゼ", K.PJ("elze", 8));
    await K.up(p, eE, 8);
    await K.say(p, "女王 エルゼ", ["{closed,low}わたしは 樹上の 民の 女王、エルゼ。……主を 殺さずに しずめたのは 見て いた。", "{angry,up}でも 先に 聞かせて。森を 病ませたのは、人間でしょう。"]);
    await K.at(p, base, 16, 4, 0.8);
    await K.narr(p, ["§7砦の 下。人の 斧の 跡が 残る 切り株が 並び、その 奥に、小さな 妖精の 形の 石が 一列。"], base);
    await K.up(p, eE, 8);
    await K.say(p, "女王 エルゼ", ["{closed,low}……斧を 入れたのは 人。石に なったのは、止めに 入った 子たち。"]);
    if (ok(eH2)) K.act(eH2, "bow");
    await K.hsay(p, H4(["{sad,up}……ごめんなさい。わたしたちが 切った わけじゃ ないけど……人が やった ことだから。"], ["{sad,up}……ごめんなさい。人が した ことを、人として 謝らせて。"], ["{closed,up}……ごめん。人の したこと。"], ["{sad,up}……申し訳 ありません。人の した ことを、お詫びします。"]), eE);
    await K.up(p, eE, 8);
    await K.say(p, "女王 エルゼ", ["{closed}……謝る 人間は、はじめて 見たわ。", "{smile,up}精霊を 運ぶのを 許します。森は、少しだけ 覚えて おく。"]);
    K.act(eH2, 0);
    K.pay(p, E8, 4500, [["e_bronze", 1], ["SEED2", 2], ["tms_plant", 1]]);
    K.big(p, "§a§l道が 開けた！", "§fルインズ荒野へ 行けるように なった", "ui.toast.challenge_complete");
    await K.end(p, { leave: [eE], card: "§7― ルインズ荒野の はいきょの 村 ガレキへ ―" });
    const d2 = K.load(p); if (d2) { K.qs(d2).ch2c = 1; K.save(p, d2); }
    return true;
  } };

/* ---------- 9話 ルミエの ほたる祭り（初雪）（初雪 ＋ 古い r1e5）---------- */
const E9 = { id: "b02e9", t: "冬ほたるの 祭り", F: ["F06", "F65"], battles: 0,
  place: PL("r1e5"),   /* 第126版(PV): 祭りは 里の 広場（石の 子へは 外れの 小川まで 灯りを 運ぶ）*/
  hint: "§fほたるの 里 ルミエの §e広場§f で §6ほたる祭り§f が 開かれる §7（初雪の 夜。そのあと ルインズ荒野へ）",
  syn: "初雪の 夜、冬ほたるが 帰って きた。ほたる祭りの 灯りの 中で、セオだけ 小川に 背を 向けて 立った。「僕は、ここで 見て います」。セオは 竜の 絵本を ピピに あげた。",
  async run(p, d, K) {
    await K.open(p, "ルミエ（初雪の 夜）", "snow", "night");
    const c = C0(K, p);
    for (let i = 0; i < 2; i++) { K.burst(p.dimension, { x: c.x, y: c.y + 4, z: c.z }, "minecraft:snowflake_particle", 20, 5, 0.1); await K.wait(8); }
    await K.narr(p, ["§7初雪。……里の 屋根の 上に、一つ、また 一つ、白い 光が ともる。冬ほたるだ。"], { x: c.x, y: c.y + 2, z: c.z });
    if (!(await oldRun(p, d, K, "r1e5", E9))) return false;   /* セオは 小川に 背を 向ける /*F06 F65*/
    K.key(p, "k_fest1");
    return true;
  } };

bkAdd("b02", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
