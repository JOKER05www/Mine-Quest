/* 第125版: 地方ごとの 5話（物語を 濃くする しくみ）
   ・今の 物語の 段（saga.js の MQ）は そのまま。段の 番号（s.mq）は かえない
   ・新しい 話は MQ の 段と 段の あいだに 入る。どこに 入るかは「その 地方の 何番目の 段の 前か」（at）で 決める
       at: 0 = その 地方の 最初の 段の 前 ／ at: 1 = 2番目の 段の 前 ／ at: 段の 数 = 最後の 段の あと（次の 地方の 段の 前）
   ・地方ごとの 進みは s.ep[地方] = 済んだ 話の 数。ほかの 記録: s.epHold（あとで・負け）・s.epSpot（場所の 目印）・s.epPaid（ほうびを わたした 話）・s.epx（話の 中の 印）
   ・古い セーブ: 1回だけ（s.epv）そろえる。その 地方の 段を もう 越えて いれば 済み。今 いる 段の 前の 話は、その 段を もう 始めて いれば 済み、まだなら 遊べる
   ・チート「物語を 先へ 進める」・「バグを 直す → 物語が 進まない」の とばす は、新しい 話を 1つ ずつ 済みに する（ほうびは 出さない。ep.skip(s) で 印だけ そろえる）
   ・話を 書く 場所: ep_r0.js 〜 ep_r10.js（地方ごとに 1つ。ほかの 担当と ぶつからない）。書き方は ep_r0.js の 頭と 中身を 手本に する
   ・登場人物は cast.js の castAdd で 登録する（話の あとも 町に 立って「その後」を 話す）
   ・演出の 決まり（引きの 絵・2行ごとに カメラ・気持ちの 行は 寄り・3行に 1回 しぐさ・歩いて 出入り・終わりは 引きの 絵）は K の 部品が 守る。K.say／K.csay／K.hsay は 2行ごとに 聞き手の 顔へ 切りかえる */
import { world, system } from "@minecraft/server";
import { MQ, EP_HOOK, GOAL_HOOKS, SGK, storyNowHint, heroType, KEYSRC } from "./saga.js";
import { qs } from "./quest.js";
import { load, save } from "./store.js";
import { ok, wait, sound, hudSend, anim } from "./ui.js";
import { WREGIONS } from "./worldmap.js";
import { stageBegin, stageOf, arrive, stageMove, standY } from "./stagecore.js";
import { talk, establish, camAt, cineCard, mood, camN, lookAt, fadeOn, openWide, sceneTime } from "./talk.js";
import { canFight } from "./core.js";
import { SPECIES, ORDER, ITEMS } from "./data.js";
import { groundY, TOWNS, getTown } from "./structures.js";
import { CAST, CAST_HOOK, castTag, castJob } from "./cast.js";
import { townXpBy } from "./town.js";
import { openStoryFest } from "./citylife.js";
import { duel } from "./cine.js";
import { facAt } from "./epfac.js";

/* ---------- 登録 ---------- */
export const EPS = {};   /* 地方 → [話] */
const META = {};   /* 地方 → { steps: { 段の 番号（地方の 中）: [話の 番号, 題] } } */
const BYID = new Map();
/* 第126版: 本の 章（bkeng.js の bkAdd）が 引きとった 古い 話（id → (d) => 済んだか）。止めた 話は 進みでは とばし、済んだかは 新しい 話で 見る */
export const EP_OFF = new Map();
/* 話の 形: { id, n, t, at, place(p) → {x, z, nm, y?}, hint, syn, run(p, d, K) → true で 済み, skip(s), fx: { fest, xp: [町, 数], deco }, stage: {...} } */
export function epAdd(r, list, meta = {}) {
  const L = EPS[r] || [];
  for (const e of list) { if (!e || !e.id || BYID.has(e.id)) { console.warn(`[MonsterRPG] ep: 同じ id か id なし ${e && e.id}`); continue; } const x = { r, ...e }; L.push(x); BYID.set(e.id, x); }
  L.sort((a, b) => (a.at - b.at) || (a.ord ?? 0) - (b.ord ?? 0)); EPS[r] = L; META[r] = { ...(META[r] || {}), ...meta };
  ABS.clear();
}
const ABS = new Map();
function regIdx(r) { const o = []; MQ.forEach((x, i) => { if (x.r === r) o.push(i); }); return o; }
export function absOf(e) { if (ABS.has(e.id)) return ABS.get(e.id); const L = regIdx(e.r); const v = !L.length ? -1 : e.at < L.length ? L[e.at] : L[L.length - 1] + 1; ABS.set(e.id, v); return v; }
const REGS = () => Object.keys(EPS).map(Number).sort((a, b) => a - b);
export const chapterName = (r) => { const k = MQ.find((x) => x.r === r && x.ch); return k ? k.ch : ""; };

/* ---------- 進み ---------- */
const E = (s) => { if (!s.ep || typeof s.ep !== "object") s.ep = {}; return s.ep; };
function started(s, i) {
  if ((s.mqHold && s.mqHold.i === i) || s.estSeen === i || s.chSeen === i || s.mqPaid === i) return true;
  const st = MQ[i]; if (st && st.seal !== undefined && (s.bsg || []).includes(st.seal)) return true;
  for (const k in s) if (k.startsWith(`w_mq${i}_`)) return true;
  return false;
}
function migrate(s) {
  if (s.epv || s.mq === undefined) return false;
  s.epv = 1; const ep = E(s), i = s.mq, go = started(s, i);
  for (const r of REGS()) {
    const L = EPS[r], idx = regIdx(r), last = idx[idx.length - 1]; let n = 0;
    if (s.ending || (last !== undefined && i > last)) n = L.length;
    else for (const e of L) { const a = absOf(e); if (a < 0) continue; if (a < i || (a === i && go)) n++; else break; }
    const n0 = ep[r] || 0; ep[r] = Math.max(n0, n);
    for (let k = n0; k < n; k++) { const e = L[k]; if (!e) continue; try { e.skip && e.skip(s); } catch {} if (e.set) { s.epx = s.epx || {}; Object.assign(s.epx, e.set); } }   /* 第124版: 済みに した 話の 印も つける（finish と 同じ）*/
  }
  return true;
}
function nDone(s, r) { const L = EPS[r] || [], i = s.mq ?? 0; let n = Math.min(L.length, E(s)[r] || 0); while (n < L.length && (EP_OFF.has(L[n].id) || (absOf(L[n]) >= 0 && absOf(L[n]) < i))) n++; return n; }
export function epPending(d) {
  try { const s = qs(d); if (s.mq === undefined || s.ending) return null; migrate(s); const i = s.mq;
    for (const r of REGS()) { const L = EPS[r], n = nDone(s, r); if (n < L.length && absOf(L[n]) === i) return L[n]; } } catch {}
  return null;
}
export function epDone(d, id) { const e = BYID.get(id); if (!e) return true; if (EP_OFF.has(id)) { try { return !!EP_OFF.get(id)(d); } catch { return false; } } const s = qs(d); if (s.ending) return true; migrate(s); return nDone(s, e.r) > (EPS[e.r] || []).indexOf(e); }
CAST_HOOK.done = epDone;
/* 話の 中の 印（とちゅうで 抜けても くり返さない）*/
export const flag = (p, k) => { try { const d = load(p); return !!(d && (qs(d).epx || {})[k]); } catch { return false; } };
export function setFlag(p, k, v = 1) { const d = load(p); if (!d) return; const s = qs(d); s.epx = s.epx || {}; s.epx[k] = v; save(p, d); }
function worldOnce(key, fn) { try { if (world.getDynamicProperty(key)) return false; world.setDynamicProperty(key, 1); fn(); return true; } catch { return false; } }
function townFx(e) {
  const f = e.fx; if (!f) return;
  worldOnce(`mrpg:epfx:${e.id}`, () => { try { if (f.xp) townXpBy(f.xp[0], f.xp[1]); } catch {} try { if (f.fest) openStoryFest(f.fest); } catch {} });
}
function finish(s, e, skipped = false) {
  const ep = E(s), k = (EPS[e.r] || []).indexOf(e);
  ep[e.r] = Math.max(ep[e.r] || 0, k + 1);
  for (const x of ["epHold", "epSpot", "epPaid", "epLose", "epT"]) delete s[x];
  if (skipped) try { e.skip && e.skip(s); } catch {}
  if (e.set) { s.epx = s.epx || {}; Object.assign(s.epx, e.set); }
  townFx(e);
}

/* ---------- 場所 ---------- */
function spotFor(p, d, e) {
  const s = qs(d);
  if (s.epSpot && s.epSpot.id === e.id && (s.epSpot.pv || 0) === (e.pv || 0)) return s.epSpot;   /* 第127版(fac2): 場所を 移した 話（pv）は 決めなおす */
  let q = null; try { q = e.place(p); } catch {}
  if (!q || !Number.isFinite(q.x) || !Number.isFinite(q.z)) return null;
  s.epSpot = { id: e.id, i: `ep:${e.id}`, x: Math.floor(q.x), y: Number.isFinite(q.y) ? Math.floor(q.y) : null, z: Math.floor(q.z), nm: q.nm || "", np: 1, r: q.r || 4, ...(e.pv ? { pv: e.pv } : {}), ...(Number.isFinite(q.fx) ? { fx: q.fx, fz: q.fz } : {}) };   /* 第125版(pl): fx,fz = 町の 建物の 中（舞台は 建物を 向く）*/
  save(p, d); return s.epSpot;
}

/* ---------- 毎秒（saga.js の step から）---------- */
EP_HOOK.step = (p, d) => {
  const e = epPending(d); if (!e) return 0;
  const s = qs(d); let dirty = false;
  if (!s.epT || s.epT.id !== e.id) { s.epT = { id: e.id, t: Date.now() }; dirty = true; }
  if (s.epHold && s.epHold.id !== e.id) { delete s.epHold; dirty = true; }
  if (s.epPaid === e.id) { finish(s, e); save(p, d); return 1; }   /* ほうびを わたした あとで 落ちた */
  if (dirty) save(p, d);
  if (s.epHold || !canFight(d)) return 1;
  const sp = spotFor(p, d, e); if (!sp) return 1;
  const l = p.location;
  if (Math.hypot(sp.x + 0.5 - l.x, sp.z + 0.5 - l.z) > sp.r || (typeof sp.y === "number" && Math.abs(sp.y - l.y) > 6)) { const y0 = sp.y; SGK.mqMarker(p, sp); if (y0 !== sp.y) save(p, d); return 1; }
  if (!SGK.steady(p)) return 1;
  if (typeof sp.y === "number") SGK.mqMarkerClear(sp);
  start(p, e, { ...sp });
  return 2;
};
const EPR = new Map();   /* 第124版(fix2): 今 流して いる 話の 地方（粒・飾りの 色）*/
const regStyle = (p) => { try { return WREGIONS[EPR.get(p.id)]?.style || ""; } catch { return ""; } };
/* 第125版(pl): はじめて 来た 町の 引きの 絵（近くの 町が 建って いる ときだけ。読まれて いない 遠くは 映さない）*/
async function townPan(p, e, at) {
  try {
    if (flag(p, `pan${e.r}`)) return; let T = null, bd = 130;
    for (const t of TOWNS) { const g = getTown(t.id); if (!g || !g.built) continue; const dd = Math.hypot(g.x - at.x, g.z - at.z); if (dd < bd) { bd = dd; T = { t, g }; } }
    setFlag(p, `pan${e.r}`); if (!T) return;
    const c = { x: T.g.x, y: T.g.y, z: T.g.z }, ux = Math.sign(at.x - c.x) || 1, uz = Math.sign(at.z - c.z) || 1;
    fadeOn(p, "0.2 0.3 0.5", "0 0 0"); await wait(6);
    camAt(p, { x: c.x + ux * 46, y: c.y + 30, z: c.z + uz * 46 }, { x: c.x, y: c.y + 4, z: c.z }, 0); cineCard(p, `§f― ${T.t.name} ―`, 50); await wait(34);
    camAt(p, { x: c.x + ux * 14, y: c.y + 9, z: c.z + uz * 12 }, { x: c.x, y: c.y + 3, z: c.z }, 1.4); await wait(26);
    camAt(p, { x: c.x + ux * 6, y: c.y + 6, z: c.z - 22 }, { x: c.x, y: c.y + 3, z: c.z - 36 }, 1.2); await wait(24);
    fadeOn(p, "0.2 0.3 0.4", "0 0 0"); await wait(6);
  } catch {}
}
function start(p, e, sp) {
  EPR.set(p.id, e.r);
  SGK.runEvt(p, async () => {
    const dd = load(p); if (!dd) return;
    if (qs(dd).epSeen !== e.id) { qs(dd).epSeen = e.id; save(p, dd); SGK.big(p, `§6§l${chapterName(e.r) || "物語"}`, `${nW(e.n)} ${e.t}`, e.snd === undefined ? "ui.toast.challenge_complete" : e.snd);   /* 第125版(snd): 暗い 話は e.snd（ページを めくる 音など）*/ await wait(50); }
    const at = { x: sp.x + 0.5, y: typeof sp.y === "number" ? sp.y : p.location.y, z: sp.z + 0.5 };
    { const fq = (e.fac ? facAt(e.fac, at, 60) : null) || (Number.isFinite(sp.fx) ? { x: sp.fx, z: sp.fz } : null); await stageBegin(p, { anchor: at, move: true, noEst: true, ...(fq ? { face: fq } : {}), ...(Number.isFinite(sp.fx) ? { R: 14, bshot: { x: sp.fx, y: (typeof sp.y === "number" ? sp.y : at.y) + 2.5, z: sp.fz } } : fq ? { bshot: fq } : {}), ...(e.stage || {}) }); }   /* 第125版(fac): 建てた 施設が あれば そちらを 向く */
    await townPan(p, e, at);   /* 第125版(pl): 地方に はじめて 来た とき、町の 上から 家なみ → 広場 → 門 を 見せる（1回）*/
    { const dh = load(p) || dd; if (qs(dh).introDone && !qs(dh).hero && !(await SGK.heroJoin(p))) return; }
    let done = false, later = false; SGK.MQASK.add(p.id); SGK.MQRUN.add(p.id); SGK.MQSTALE.delete(p.id); const tok = {}; SGK.MQTOK.set(p.id, tok); let stale = false;
    try { done = (await e.run(p, load(p) || dd, K)) === true; } catch (x) { if (x === SGK.LATER) later = true; else console.warn(`[MonsterRPG] ep ${e.id}: ${x} ${x?.stack || ""}`); }
    finally { stale = SGK.MQTOK.get(p.id) !== tok; if (!stale) { SGK.MQTOK.delete(p.id); SGK.MQASK.delete(p.id); SGK.MQRUN.delete(p.id); } if (!stale || !SGK.MQRUN.has(p.id)) SGK.heroTmpClean(p); }
    if (stale) return;
    if (later) SGK.laterClean(p);
    SGK.SPAWNED.delete(p.id);
    const d2 = load(p); if (!d2) return; const s2 = qs(d2);
    if (!done && s2.epPaid === e.id) done = true;
    const cur = epPending(d2);
    if (cur && cur.id === e.id) { if (done) finish(s2, e); else { s2.epHold = { id: e.id }; if (!later) s2.epLose = { id: e.id, n: (s2.epLose && s2.epLose.id === e.id ? s2.epLose.n : 0) + 1 }; } save(p, d2); }
    if (!done) try { p.sendMessage("§7準備が できたら ガイドブック ＞ ストーリー ＞「物語の 戦いに 再挑戦」を えらぼう。§8（右上の 案内が 場所を 教えて くれる）"); } catch {}
  });
}

/* ---------- 案内・ガイドブック・チート・バグを 直す ---------- */
const nW = (n) => (n > 5 ? "5話 つづき" : `${n}話`);   /* 第124版(dir#32): 1地方 5話。6 より 後は「5話 つづき」 */
const label = (e) => `§d${nW(e.n)} ${e.t}§r `;
EP_HOOK.hint = (d, full = false) => {
  const e = epPending(d); if (e) return `${full ? label(e) : ""}${e.hint}`;
  if (!full) return "";
  try { const s = qs(d), i = s.mq ?? 0, st = MQ[i]; if (!st || st.r === 99) return ""; const M = META[st.r]; if (!M || !M.steps) return ""; const k = regIdx(st.r).indexOf(i), x = M.steps[k]; if (!x) return ""; return `§d${nW(x[0])} ${x[1]}§r ${storyNowHint(d)}`; } catch { return ""; }
};
EP_HOOK.block = (d, k) => { const e = epPending(d); return !!e && absOf(e) <= k; };
EP_HOOK.skip = (p, d) => { const e = epPending(d); if (!e) return false; finish(qs(d), e, true); return true; };
EP_HOOK.held = (d) => { const e = epPending(d), s = qs(d); return !!(e && s.epHold && s.epHold.id === e.id); };
EP_HOOK.retry = (p, d) => { const e = epPending(d), s = qs(d); if (!e || !s.epHold || s.epHold.id !== e.id) return null; delete s.epHold; save(p, d); return `§aもう一度 挑む 準備が できた。§f${e.hint} §7（その 場所へ 行くと 始まる）`; };
EP_HOOK.fix = (p, d) => {
  const e = epPending(d); if (!e) return null; const s = qs(d); let sp = null; try { sp = spotFor(p, d, e); } catch {}
  return { i: s.mq ?? 0, st: { r: e.r, hint: e.hint, at: "ep" }, need: true, sp, lose: s.epLose && s.epLose.id === e.id ? s.epLose.n : 0, mins: s.epT && s.epT.id === e.id ? Math.floor((Date.now() - s.epT.t) / 60000) : 0, canSkip: true, post: false, ep: e.id };
};
EP_HOOK.reset = (p, d) => {
  const s = qs(d), out = [];
  if (s.epSpot) { if (typeof s.epSpot.y === "number") SGK.mqMarkerClear(s.epSpot); delete s.epSpot; out.push("地方の 話の 目印を 選びなおした"); }
  if (s.epHold) { delete s.epHold; out.push("「あとで」・負けて 止まって いた 地方の 話を、場所へ 行けば また 始まる ように した"); }
  return out;
};
EP_HOOK.reached = (d, r) => { try { const e = epPending(d); return (!!e && e.r === r) || nDone(qs(d), r) > 0; } catch { return false; } };   /* 章の 名前（ガイドブック・あらすじ）: その 地方の 新しい 話を 始めて いれば、その 章 */
EP_HOOK.syn = (d, ch) => {
  const s = qs(d), o = [];
  for (const r of REGS()) { if (chapterName(r) !== ch) continue; for (const e of EPS[r]) if (e.syn && epDone(d, e.id)) o.push(`§7・${nW(e.n)} ${e.t}: §f${e.syn}`); }
  return o.length ? `\n${o.join("\n")}` : "";
};
GOAL_HOOKS.unshift((p, d) => {
  const e = epPending(d); if (!e) return null;
  let sp = null; try { sp = spotFor(p, d, e); } catch {}
  return { text: String(e.hint).replace(/§./g, "").replace(/\s+/g, " ").trim(), name: sp ? sp.nm : "", near: "§a「！」の 目印の そばで 立ち止まろう", x: sp ? sp.x + 0.5 : null, z: sp ? sp.z + 0.5 : null, key: `ep:${e.id}` };
});

/* ---------- 演出の 部品（K）---------- */
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
const pairs = (L) => { const o = []; for (let i = 0; i < L.length; i += 2) o.push(L.slice(i, i + 2)); return o; };
/* 聞いて いる 人（あなた・旅の 仲間）の 顔へ 一瞬 切りかえる */
async function react(p, who = null) {
  const S = stageOf(p); if (!S) return;
  if (who && ok(who)) { SGK.camNear(p, who, 1.6, 1.5, 0); await wait(12); return; }   /* 第124版(fix2): 切り返しは カット */
  { const V = OV(p); if (V) { camAt(p, V.at(-4, 2.2, 2.2), V.at(3, 0, 1.4), 0); await wait(12); return; } }   /* 第127版: 別視点では あなたを 映さない */
  camAt(p, S.at(1.7, 0.55 * S.side, 1.65), S.at(0, 0, 1.5), 0); await wait(12);
}
/* 「同じ カメラは 2行まで」: 1行ずつ 話し、カメラが 2行 かわって いなければ 次の 行の 前に 切りかえる
   （同じ 人が 続く ときは 聞き手の 顔・話す 人が かわった のに 映らなかった ときは 話す 人へ）*/
const RUN = new Map();
const OV = (p) => { try { return globalThis.__mqOffV?.get(p.id) || null; } catch { return null; } };   /* 第127版: 別視点の 舞台 */
const spk = (p, who) => { const S = stageOf(p); if (!S) return null; const k = String(who).replace(/§./g, ""), L = S.ents.filter((o) => ok(o) && o.typeId === "mrpg:npc" && String(o.nameTag || "").replace(/§./g, "").includes(k)); return L.find((o) => String(o.nameTag || "").replace(/§./g, "").split(" ").pop() === k) || L[0] || null; };   /* 第125版: 名前が 同じ 人を 先に */
function camSeen(p) { const n = camN(p), r = RUN.get(p.id) || { n: -1, c: 0, who: "" }; if (r.n !== n) { r.n = n; r.c = 0; } RUN.set(p.id, r); return r; }
function counted(p, who, moved) { const r = camSeen(p); r.c = moved ? 1 : r.c + 1; r.n = camN(p); r.who = who; }
async function chunked(p, lines, fn, lis, who = "") {
  const A = [].concat(lines);
  for (let i = 0; i < A.length; i++) {
    const r = camSeen(p);
    if (r.c >= 2) { const e = r.who === who ? null : spk(p, who); if (e && ok(e)) { lookAt(p, e); await wait(4); } else await react(p, lis); camSeen(p); }   /* 第124版(fix2): talk と 同じ 絵（撮り直さない）*/
    const n0 = camN(p); await fn([A[i]]); counted(p, who, camN(p) !== n0);
  }
}
const heroE = (p) => { try { return SGK.heroBox(p).e; } catch { return null; } };
const POSTS = [[-10, -7], [10, -7], [-10, 7], [10, 7], [0, -11], [0, 11]];
/* 第124版(fix2): 祭りの 飾りは 地方に 合わせる */
const DECO_TH = { desert: { fence: "birch_fence", pumpkin: "decorated_pot", carved_pumpkin: "decorated_pot", jack_o_lantern: "decorated_pot" }, volcano: { fence: "nether_brick_fence", pumpkin: "campfire", carved_pumpkin: "campfire", jack_o_lantern: "campfire", hay_block: "air" }, snow: { fence: "spruce_fence", pumpkin: "snow_block", carved_pumpkin: "snow_block", jack_o_lantern: "snow_block", hay_block: "snow_block" }, dark: { lantern: "end_rod", pumpkin: "purpur_block", carved_pumpkin: "purpur_block", jack_o_lantern: "purpur_block" } };
function ambient(p, kind, at) {
  const dim = p.dimension; if (!at) return;
  const pt = (n, q) => { try { dim.spawnParticle(n, q); } catch {} };
  const st = regStyle(p), DAY = { desert: ["minecraft:falling_dust_sand_particle"], snow: ["minecraft:snowflake_particle", "mrpg:wx_flake"], volcano: ["minecraft:lava_particle", "minecraft:basic_smoke_particle"], forest: ["minecraft:spore_blossom_ambient_particle"], port: ["mrpg:wx_mote"], sky: ["mrpg:wx_mote"], dark: ["minecraft:endrod"] }[st] || ["minecraft:villager_happy"];   /* 第124版(fix2): 昼の 粒は 地方に 合わせる（呪いの 印に 見える 竜の 卵の 粉は 使わない）*/
  if (kind === "fest") for (const [x, z] of POSTS) pt("minecraft:basic_flame_particle", { x: at.x + x, y: at.y + 2.6, z: at.z + z });   /* 祭りの 炎は 柱の 上だけ（空中に 火の玉を 出さない）*/
  for (let i = 0; i < (kind === "snow" ? 16 : 10); i++) { const a = (i / 10) * Math.PI * 2, r = 3 + (i % 3) * 2, q = { x: at.x + Math.cos(a) * r, y: at.y + 1.5 + (i % 4) * 0.6, z: at.z + Math.sin(a) * r };
    if (kind === "fest") pt("minecraft:villager_happy", q);
    else if (kind === "night") { if (i < 6) pt("minecraft:endrod", q); }   /* 夜は ゆっくり 漂う 光 */
    else if (kind === "ash") pt(i % 2 ? "minecraft:basic_smoke_particle" : "minecraft:soul_particle", q);
    else if (kind === "snow") pt("minecraft:snowflake_particle", q);
    else if (kind === "castle") pt("minecraft:villager_happy", q);
    else if (kind === "dusk") { if (i % 2) pt("minecraft:falling_dust_dragon_egg_particle", q); }
    else pt(DAY[i % DAY.length], q); }
}
/* 第125版: 話の ほうびと いっしょに 渡す だいじなもの（渡す 人が 小道具を 手渡した すぐ あと）*/
const EPK = { r0e6: ["k_fest0"], r1e5: ["k_fest1"], r2e5: ["k_fest2"], r3e5: ["k_fest3"], r4e6: ["k_fest4"], r5e6: ["k_fest5"], r6e6: ["k_fest6"], r7e6: ["k_wlan", "k_fest7"], r8e1: ["k_mitt"], r10e2: ["k_hnote", "k_letter"] };
EP_HOOK.epDone = (d, id) => epDone(d, id);   /* keyitems.js の 説明の かわり */
KEYSRC.push((d) => Object.entries(EPK).filter(([id]) => BYID.has(id) && epDone(d, id)).flatMap(([, L]) => L));   /* 前の 版で 済ませた 話 */
/* K.flashback(p, { label, at?, here?, tod?, ptc?, actors: { k: { nm, job, at: [a, b], act?, hold?, look? } }, beats: [...] })
   回想: 暗転 → 札「―― ○○年前」→ 昔の 舞台（別の 舞台・時刻・ほこりの 粒・かすんだ 空気）→ 昔の 人が 拍を 演じる → 暗転で もどる
   拍: ["say", k, 行, 相手k?]・["narr", 文, k か [a,b,dy]?]・["act", k, しぐさ]・["hold", k, 物]・["go", k, [a, b], tick?]・["face", k, 相手k か [a,b]]・["at", [a, b, dy], tick?, 距離?]・["wide"]・["fx", fire|ash|snow|spark|light, [a, b, dy]]・["snd", 音, 高さ?]・["wait", tick] */
const FB_PT = { ash: ["minecraft:white_ash", "minecraft:basic_smoke_particle"], dust: ["minecraft:falling_dust_sand_particle", "minecraft:white_ash"], snow: ["minecraft:snowflake_particle", "minecraft:white_ash"], ember: ["minecraft:lava_particle", "minecraft:basic_smoke_particle"], night: ["minecraft:endrod", "minecraft:white_ash"] };
async function flashback(p, o = {}) {   /* 第127版: 拍の 行は K.say（2行ごとに 絵を かえる・点検の 相手）*/
  if (!ok(p)) return;
  const TOD = { day: 6000, dusk: 12400, night: 17000, dawn: 23300 }[o.tod || "dusk"], solo = (() => { try { return world.getAllPlayers().length === 1; } catch { return false; } })();
  let t0 = null; try { t0 = world.getTimeOfDay(); } catch {}
  const A = {}, NM = {};
  const cast = (V) => {
    if (solo && TOD !== undefined) try { world.setTimeOfDay(TOD); } catch {}
    cmd(p, "fog @s push mrpg:ruins mq_fb"); system.runTimeout(() => { try { if (ok(p) && !SGK.OFFS.has(p.id)) cmd(p, "fog @s remove mq_fb"); } catch {} }, 20 * 120);
    for (const k in o.actors || {}) { const x = o.actors[k]; const e = V.actor(x.nm, x.job ?? 8, x.at || [3, 0]); A[k] = e; NM[k] = String(x.nm).replace(/§./g, ""); if (ok(e)) { if (x.act) SGK.act(e, x.act); if (x.hold) SGK.hold(e, x.hold); } }
    for (const k in o.actors || {}) { const x = o.actors[k], e = A[k]; if (!ok(e)) continue; const L = x.look && A[x.look] ? A[x.look].location : Array.isArray(x.look) ? V.at(x.look[0], x.look[1] || 0) : null; if (L) try { e.teleport(e.location, { facingLocation: { x: L.x, y: L.y + 1.5, z: L.z } }); } catch {} }
  };
  await SGK.offstage(p, async (V) => {
    const PT = FB_PT[o.ptc || "dust"] || FB_PT.dust, puff = () => { for (let i = 0; i < 8; i++) { const a = i * 0.785; try { p.dimension.spawnParticle(PT[i % PT.length], V.at(2 + Math.cos(a) * 4, Math.sin(a) * 4, 1 + (i % 3) * 0.7)); } catch {} } };
    const near = (e) => { let b = null, bd = 99; for (const k in A) { const f = A[k]; if (!ok(f) || f === e) continue; const d = Math.hypot(f.location.x - e.location.x, f.location.z - e.location.z); if (d < bd) { bd = d; b = f; } } return b; };
    const pt = (q) => (Array.isArray(q) ? V.at(q[0], q[1] || 0, q[2] ?? 1) : q && q.location ? q.location : q);
    puff(); camAt(p, V.at(-4.5, 2, 2.4), V.at(3, 0, 1.2), 1.6); await wait(22);
    let n = 0;
    for (const b of o.beats || []) {
      if (!ok(p)) break; const [k, a1, a2, a3] = b; if (n++ % 3 === 0) puff();
      if (k === "say") { const e = A[a1]; if (!ok(e)) continue; const to = A[a3] || near(e); if (ok(to)) try { to.teleport(to.location, { facingLocation: { x: e.location.x, y: e.location.y + 1.5, z: e.location.z } }); } catch {} await K.say(p, NM[a1], [a2], to || null); }
      else if (k === "narr") { const q = typeof a2 === "string" ? A[a2] : pt(a2); if (q && q.location) SGK.camNear(p, q, 3.2, 1.4); else if (q) SGK.camPt(p, q, 4.5, 0.2); else camAt(p, V.at(-6, 3 * (n % 2 ? 1 : -1), 3.5), V.at(3, 0, 1), 0.8); await SGK.narr(p, "", [a1]); const r = camSeen(p); r.c = 1; r.who = ""; }
      else if (k === "act") SGK.act(A[a1], a2);
      else if (k === "hold") SGK.hold(A[a1], a2);
      else if (k === "face") { const e = A[a1], t = A[a2] || pt(a2); if (ok(e) && t) try { const L = t.location || t; e.teleport(e.location, { facingLocation: { x: L.x, y: L.y + 1.5, z: L.z } }); } catch {} }
      else if (k === "go") { const e = A[a1]; if (ok(e)) { SGK.camNear(p, e, 4, 1.4, 0.8); await SGK.go(e, V.at(a2[0], a2[1] || 0), a3 || 20); } }
      else if (k === "at") { const q = pt(a1); if (q) { SGK.camPt(p, q, a3 || 3.5, 0.2, 0.5); await wait(8); SGK.camPt(p, q, Math.max(1.6, (a3 || 3.5) * 0.55), 0.2, (a2 || 24) / 20); await wait(a2 || 24); } }
      else if (k === "wide") { camAt(p, V.at(-8, 4.5 * (n % 2 ? 1 : -1), 5), V.at(3, 0, 1), 1.2); await wait(a1 || 24); }
      else if (k === "fx") { const q = pt(a2 || [3, 0, 0.5]); const id = { fire: "minecraft:basic_flame_particle", ash: "minecraft:white_ash", snow: "minecraft:snowflake_particle", spark: "minecraft:lava_particle", light: "minecraft:endrod" }[a1] || "minecraft:white_ash"; if (q) SGK.burst(p.dimension, q, id, 10, 1.2, 0.3); }
      else if (k === "snd") sound(p, a1, a2 || 1);
      else if (k === "wait") await wait(a1 || 10);
    }
    for (const k in A) SGK.act(A[k], 0);
    camAt(p, V.at(-10, 5, 6), V.at(3, 0, 1), 1.4); await wait(20);
  }, { at: o.at, here: o.here, cast, card: o.label || "§7―― 昔" });
  try { cmd(p, "fog @s remove mq_fb"); } catch {}
  if (solo && t0 !== null && TOD !== undefined) try { world.setTimeOfDay(t0); } catch {}
}
export const K = {
  ...SGK,
  S: stageOf, wait, sound, flag, setFlag, mood, duel, anim,
  cmd: (p, c) => { const m = /^camera @s fade time ([\d. ]+?) color (\d+ \d+ \d+)\s*$/.exec(String(c)); return m ? fadeOn(p, m[1], m[2]) : cmd(p, c); },   /* 第124版(fix2): 暗転は 1か所で 覚える（重ねない）*/
  turn(e, q) { try { if (!ok(e)) return; if (!q) { e.setDynamicProperty("mrpg:away", undefined); return; } e.teleport(e.location, { facingLocation: { x: q.x, y: (q.y ?? e.location.y) + 1.5, z: q.z } }); e.setDynamicProperty("mrpg:away", true); } catch {} },   /* 向きを 決めて、話しても 向きを かえない（背を 向ける 芝居）*/
  /* 人 */
  cast: (p, id, noWalk = false) => SGK.npcNear(p, castTag(id), castJob(id), noWalk),
  hero: (p, walk = true) => (walk ? SGK.heroNear(p) : heroE(p)),
  /* せりふ（2行ごとに 聞き手へ 切りかえ）*/
  csay: (p, id, lines, lis = null) => chunked(p, lines, (L) => talk(p, CAST[id] ? CAST[id].nm : id, L, CAST[id] ? CAST[id].col : "§6", lis), lis, CAST[id] ? CAST[id].nm : id),
  say: (p, who, lines, lis = null) => chunked(p, lines, (L) => SGK.say(p, who, L, lis), lis, who),
  hsay: (p, lines, lis = null) => { const L = Array.isArray(lines) ? lines : lines[heroType(p)] || lines.g; const h = SGK.heroOf(p); return chunked(p, L, (x) => SGK.hsay(p, x, lis), lis, h ? h.name : ""); },
  narr: async (p, lines, focus = null) => { const P = pairs([].concat(lines)); for (const L of P) { if (focus && ok(focus)) SGK.camNear(p, focus, 3.2, 1.4); else if (focus && focus.x !== undefined) SGK.camPt(p, focus, 4, 1.2); else { const V = OV(p), S = V || stageOf(p); if (S) camAt(p, S.at(-3.5, 2.6 * (S.side || 1), 2.8), S.at(3, 0, 1), 0.6); } await SGK.narr(p, "", L); const r = camSeen(p); r.c = L.length; r.who = ""; } },
  /* カメラ */
  async open(p, nm, kind = "day", tod = null) {   /* tod: 祭りの 夜など 粒と 時刻が ちがう とき（"night" / "dusk"）*/   /* 始まりの 引きの 絵（2〜3秒）: 高い 所から 場所と 天気を 見せ、ゆっくり 寄る */
    const S = stageOf(p); if (!S) { await establish(p, p.location, nm); return; }
    ambient(p, kind, S.Cn);
    if (kind === "ash") mood(p, "shadow");   /* 第125版(snd): 夜・夕暮れは 霧も 雷も なし */
    sceneTime(p, tod || kind);   /* 第124版(fix2): 夜・夕ぐれは 時刻も（1人の ときだけ。場面の 終わりで もどす）*/
    system.runTimeout(() => { if (ok(p)) ambient(p, kind, S.Cn); }, 28);
    await openWide(p, nm);   /* 第125版(pl): 町の 建物・施設の 場面は 引きの あと 建物（戸口・看板）を 映してから 人へ */ { const f = S.opt && S.opt.bshot; if (f && Number.isFinite(f.x)) { SGK.camPt(p, { x: f.x, y: Number.isFinite(f.y) ? f.y : S.P.y + 1.5, z: f.z }, 6, 1.6); await wait(16); } }   /* 第124版(fix2): 暗い 所から 高い 引き → ゆっくり 寄る（talk.js の 章の 始めと 同じ）*/
  },
  async up(p, e, t = 14) { await arrive(e); if (ok(e)) { SGK.camNear(p, e, 1.45, 1.55); await wait(t); } },   /* 寄り（顔）*/
  async low(p, e, t = 14) { await arrive(e); if (!ok(e)) return; const l = e.location, P0 = p.location, dx = P0.x - l.x, dz = P0.z - l.z, n = Math.hypot(dx, dz) || 1; camAt(p, { x: l.x + (dx / n) * 2.3, y: l.y + 0.35, z: l.z + (dz / n) * 2.3 }, { x: l.x, y: l.y + 1.8, z: l.z }, 0.5); await wait(t); },   /* 下から 見上げる */
  async two(p, a, b, t = 14) { await arrive(a); await arrive(b); if (!ok(a) || !ok(b)) return; if (String(a.id) > String(b.id)) [a, b] = [b, a]; const A = a.location, B = b.location, m = { x: (A.x + B.x) / 2, y: Math.max(A.y, B.y) + 1.3, z: (A.z + B.z) / 2 }, dx = B.x - A.x, dz = B.z - A.z, n = Math.hypot(dx, dz) || 1; camAt(p, { x: m.x - (dz / n) * 4.5, y: m.y + 0.5, z: m.z + (dx / n) * 4.5 }, m, 0.6); await wait(t); },   /* 二人を 横から */
  async wide(p, t = 20) { const S = OV(p) || stageOf(p); if (!S) return; camAt(p, S.at(-7, 4.5 * (S.side || 1), 5.5), S.at(3, 0, 1), 0.8); await wait(t); },   /* 引き */
  async at(p, q, t = 16, k = 4, dy = 1.2) { if (q) { SGK.camPt(p, q, k, dy); await wait(t); } },   /* 物や 場所を 映す */
  async walkCam(p, e, to, ticks = 20) { if (!ok(e) || !to) return; const g = SGK.go(e, to, ticks); for (let k = 0; k < ticks; k += 6) { if (ok(e)) SGK.camNear(p, e, 3.2, 1.3); await wait(6); } await g; },   /* 歩きながら 追う */
  /* 終わり: 引きの 絵（去って いく 背中）→ セリフと 画面を 消す */
  async end(p, o = {}) {
    const S = stageOf(p), fade = [...(o.bye || [])];
    const go = (o.leave || []).filter(ok).map((e) => { const q = SGK.away(e, p, 9); if (!q || Math.hypot(q.x - e.location.x, q.z - e.location.z) < 4) { fade.push(e); return null; } fade.push(e); return SGK.go(e, SGK.exitPt ? SGK.exitPt(p, e, 9) || q : q, 26); }).filter(Boolean);   /* 第124版(cam): 背を 向けて 歩き、最後の 暗転で 下げる */   /* 道が ふさがって いて 歩けない 人は 暗転で 下げる */
    { const h = heroE(p); if (h) fade.push(h); }
    if (S) { camAt(p, S.at(-4, 2.4 * S.side, 2.6), S.at(4, 0, 1.3), 0.8); await wait(14); camAt(p, S.at(-11, 6.5 * S.side, 8), S.at(4, 0, 1), 2.2); }   /* 第124版(cam): 終わりも なめらかに 引く */
    if (o.card) cineCard(p, o.card, 70);
    if (o.kind) ambient(p, o.kind, S ? S.Cn : p.location);
    await wait(o.t || 46); await Promise.all(go);
    try { hudSend(p, "MQD", ""); } catch {}
    await SGK.bye(p, ...fade.filter(ok));
    RUN.delete(p.id);
  },
  /* ほうび（1回だけ。s.epPaid に この 話の id）*/
  pay(p, e, g, items = []) { const d = load(p); if (!d) return []; const s = qs(d); if (s.epPaid === e.id) return []; const got = SGK.reward(p, d, g, items, false); s.epPaid = e.id; for (const k of EPK[e.id] || []) if (ITEMS[k] && !(s.keys || []).includes(k)) { SGK.giveKey(p, d, k); got.push(`§6${ITEMS[k].name}`); } save(p, d); return got; },   /* 第125版: 場面の だいじなもの（データだけ）*/
  /* 小道具: 祭りの 飾り（ワールドに 1回だけ。lvl 0 畑・1 屋台・2 やり直しの 祭り）。center は 話の 場所 */
  deco(p, key, lvl, center, y0) {
    const dim = p.dimension, cx = Math.floor(center.x), cz = Math.floor(center.z), k = `mrpg:epdeco:${key}`, TH = DECO_TH[regStyle(p)] || {}, B = (b) => TH[b] || (b === "oak_fence" ? TH.fence || b : b);
    let v = 0; try { v = Number(world.getDynamicProperty(k) || 0); } catch {} if (lvl === 9 ? v > 2 : v > lvl) return false;   /* 第124版: やり直しの 祭り（lvl 2）の あとは 影で 暗く もどさない（ほかの 人の 祭りを 消さない）*/
    const gy = (x, z) => { try { const y = groundY(dim, x, z, y0 + 6); return typeof y === "number" && Math.abs(y - y0) <= 4 ? y : null; } catch { return null; } };
    const put = (x, z, b, up = 0, keep = true) => { b = B(b); if (b === "air") return; const y = gy(cx + x, cz + z); if (y !== null) cmd(p, `setblock ${cx + x} ${y + up} ${cz + z} ${b}${keep ? " keep" : ""}`); };
    const isF = (x, y, z) => { try { return /fence/.test(dim.getBlock({ x, y, z })?.typeId || ""); } catch { return false; } };
    const top = (x, y, z, b) => { const t = (() => { try { return dim.getBlock({ x, y, z })?.typeId || ""; } catch { return "x"; } })(); if (isF(x, y - 1, z) && /air|lantern|wool|end_rod/.test(t)) cmd(p, `setblock ${x} ${y} ${z} ${B(b)}`); };   /* 柱の 上だけ（木や 家を 削らない）*/
    const post = (x, z, lit) => { const y = gy(cx + x, cz + z); if (y === null) return; for (let h = 0; h < 2; h++) cmd(p, `setblock ${cx + x} ${y + h} ${cz + z} ${B("oak_fence")} keep`); top(cx + x, y + 2, cz + z, lit ? "lantern" : "air"); };

    if (lvl === 0) { for (let x = 12; x <= 17; x++) for (let z = -3; z <= 3; z++) { const y = gy(cx + x, cz + z); if (y === null) continue; cmd(p, `setblock ${cx + x} ${y - 1} ${cz + z} farmland`); cmd(p, `setblock ${cx + x} ${y} ${cz + z} ${z === 0 ? "air" : (x + z) % 3 ? "wheat" : "carrots"} keep`); } put(11, -4, "hay_block"); put(11, 4, "hay_block"); put(18, 0, "composter"); }
    if (lvl === 1 || lvl === 2) { for (const [x, z] of POSTS) post(x, z, true); for (const [x, z, c] of [[-12, 0, "red_wool"], [-9, -10, "yellow_wool"], [-9, 10, "orange_wool"]]) { for (const [a, b] of [[0, 0], [0, 2]]) { const y = gy(cx + x + a, cz + z + b); if (y === null) continue; cmd(p, `setblock ${cx + x + a} ${y} ${cz + z + b} ${B("oak_fence")} keep`); cmd(p, `setblock ${cx + x + a} ${y + 1} ${cz + z + b} ${B("oak_fence")} keep`); top(cx + x + a, y + 2, cz + z + b, c); } put(x, z + 1, c, 2); put(x, z + 1, "barrel"); } put(-11, -3, "pumpkin"); put(-11, 3, "carved_pumpkin"); put(11, -6, "hay_block"); }
    if (lvl === 2) { for (const [x, z] of [[-6, -12], [6, -12], [-6, 12], [6, 12]]) post(x, z, true); for (const [x, z] of [[-13, -5], [-13, 5], [13, -8], [13, 8]]) put(x, z, "poppy"); put(-12, 6, "jack_o_lantern"); put(12, -9, "jack_o_lantern"); }
    if (lvl === 9) { for (const [x, z] of POSTS.slice(0, 4)) post(x, z, false); }   /* 影に 倒された 灯り（やり直しの 祭りで もどる）*/
    try { world.setDynamicProperty(k, lvl === 9 ? 1 : lvl + 1); } catch {}
    return true;
  },
  ambient,
  /* 第125版(pl): 人が 別の 場所に いる とき: 暗転 → 前の 人を 暗い 中で 下げる → その 場所へ 舞台を 移す（建物を 向く）→ 場所の 引きの 絵。あとから 来る 人は K.cast／K.hero で 歩いて 来る */
  /* 第125版(pl): 時が たつ（暗転 → 夜の 絵 → 暗転 → 朝の 絵）。q: 映す 所（家・天幕・寝床）。1人の ときだけ 空の 時刻も かえる */
  async night(p, q, a = "", b = "", drop = []) {
    if (!ok(p)) return; const S = stageOf(p), at = q || (S ? S.Cn : p.location), solo = (() => { try { return world.getAllPlayers().length === 1; } catch { return false; } })();
    fadeOn(p, "0.4 0.5 0.4", "0 0 0"); await wait(10); for (const e of drop) if (ok(e)) SGK.rm(e); if (solo) try { world.setTimeOfDay(18000); } catch {}
    SGK.camPt(p, at, 8, 2.4); if (a) await SGK.narr(p, "", [a]); else await wait(36);
    fadeOn(p, "0.4 0.6 0.4", "0 0 0"); await wait(10); if (solo) try { world.setTimeOfDay(1000); } catch {}
    SGK.camPt(p, at, 5, 1.4); if (b) await SGK.narr(p, "", [b]); else await wait(30);
  },
  async moveTo(p, q, nm, drop = [], look = null, R = 12) {
    if (!q || !ok(p)) return false;
    fadeOn(p, "0.35 0.5 0.45", "0 0 0"); await wait(8);
    for (const e of drop) if (ok(e)) SGK.rm(e);
    try { await stageMove(p, { x: q.x, y: Number.isFinite(q.y) ? q.y : p.location.y, z: q.z }, { R, ...(look ? { face: look } : {}), noEst: true }); } catch {}
    await wait(6); if (look) { SGK.camPt(p, look, 7, 1.6); await wait(18); } else await establish(p, p.location, nm);
    return true;
  },
  /* 第125版(rs): 演出の 部品（ここ 1か所）。ots: a の 肩ごしに b（人か 点）・push: ゆっくり 寄る・pull: ゆっくり 引く・mark: 舞台の 点へ 歩く・past: 回想の 札・put: 暗転の 中で 決まった 所に 立たせる */
  async ots(p, a, b, t = 14) { if (!ok(a) || !b) return; const A = a.location, B = b.location || b, dx = B.x - A.x, dz = B.z - A.z, n = Math.hypot(dx, dz) || 1, ux = dx / n, uz = dz / n; camAt(p, { x: A.x - ux * 1.7 - uz * 0.75, y: A.y + 1.9, z: A.z - uz * 1.7 + ux * 0.75 }, { x: B.x, y: (B.y ?? A.y) + 1.4, z: B.z }, 0.5); await wait(t); },
  async push(p, q, t = 30, k0 = 5, k1 = 1.8, dy = 1.4) { const Q = q && q.location ? q.location : q; if (!Q) return; SGK.camPt(p, Q, k0, dy, 0.4); await wait(8); SGK.camPt(p, Q, k1, dy, t / 20); await wait(t); },
  async pull(p, q, t = 36) { const Q = q && q.location ? q.location : q; if (!Q) return; SGK.camPt(p, Q, 2, 1.4, 0.4); await wait(8); SGK.camPt(p, Q, 11, 5, t / 20); await wait(t); },
  async approach(p, e, to, k = 1.8, t = 14) { const T = to && to.location ? to.location : to; if (!ok(e) || !T) return; const A = e.location, dx = A.x - T.x, dz = A.z - T.z, n = Math.hypot(dx, dz) || 1; if (n <= k + 0.6) return; await SGK.go(e, { x: T.x + (dx / n) * k, y: A.y, z: T.z + (dz / n) * k }, t); },   /* 気持ちの 行の 前に 相手へ 歩み寄る */
  mark(p, e, a, b, ticks = 16) { const S = stageOf(p); return S && ok(e) ? SGK.go(e, S.at(a, b), ticks) : Promise.resolve(); },
  async past(p, label = "§7―― 昔") { fadeOn(p, "0.3 0.5 0.6", "40 30 20"); await wait(8); cineCard(p, label, 60); },
  async put(p, id, q, look = null, job = 8) { const S = stageOf(p); if (!S || !q) return null; if (fadeOn(p, "0.25 0.3 0.45")) await wait(6); const c = CAST[id], e = SGK.npcNear(p, c ? castTag(id) : id, c ? castJob(id) : job, true, true); if (!ok(e)) return e; const y = standY(S.dim, q.x, q.z, Number.isFinite(q.y) ? q.y : S.P.y, S.C), t = { x: q.x, y: y ?? (Number.isFinite(q.y) ? q.y : S.P.y), z: q.z }; S.mem.set(e.nameTag, { ...t }); S.dest.set(e.id, { ...t }); try { e.teleport(t, { facingLocation: look || p.getHeadLocation() }); } catch {} return e; },
  flashback: (p, o) => flashback(p, o),
  wildSp: (fam, sz = "S") => ORDER.find((x) => SPECIES[x] && SPECIES[x].fam === fam && SPECIES[x].sz === sz && !SPECIES[x].hidden) || ORDER[0],
};
export const __ep = { EPS, BYID, migrate, nDone, finish, spotFor, absOf, K, META };
