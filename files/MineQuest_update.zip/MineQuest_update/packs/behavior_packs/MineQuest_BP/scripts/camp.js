// 第106版: キャンプ（ガイドブック → 冒険 → キャンプ）。その場に テントを はって、パーティと スタンバイの 子 みんなと すごす
// テントは エンティティ（ブロックを 置かない）。はなれる・戦い・次元を まちがえる と 自動で 片づける
import { world, system } from "@minecraft/server";
import { load, save } from "./store.js";
import { ITEMS } from "./data.js";
import { notice, choose, ICON, barNote, showTitle, sound, EXH, gold } from "./ui.js";
import { inDungeon } from "./dungeon.js";
import { inRuins } from "./ruinsarea.js";
import { findPet, spawnPet, hooks } from "./field.js";
import { inBattle } from "./battle.js";
import { exOf, exSave } from "./explore.js";
import { __bond } from "./bond.js";
import { heroInfo, heroSpawn, heroDespawn, heroLine, inStory, FAV } from "./heroswim.js";   /* 第124版: 旅の 仲間も キャンプに 来る */
import { PLAYMODE, giveBall, takeBallItem, dropBall, spawnCrowd, clearCrowd, crowdTick, runnersOf, gather, isCrowd, __pf } from "./playfun.js";

const OWID = "minecraft:overworld", OW = () => world.getDimension(OWID);
const KEY = "mrpg:camp";
const B = (t, icon) => [t, icon];
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const CAMP = new Map();   /* pid -> { tent, c } */
export const inCamp = (p) => { try { return typeof p.getDynamicProperty(KEY) === "string"; } catch { return false; } };
const campOf = (p) => { try { const v = p.getDynamicProperty(KEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } };
PLAYMODE.push((p) => { const c = campOf(p); return c ? { ...c, flat: false } : null; });
hooks.petHold = ((prev) => (p) => (prev && prev(p)) || inCamp(p))(hooks.petHold);
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => inCamp(p) || (prev ? prev(p) : false); });

/* 第124版: 旅の 仲間（ヒロイン）。たき火（料理の 場所）の そばに 座って、料理・ひと休みに ひとこと */
const HL = {
  come: { g: ["キャンプ！ たき火 つけよ、たき火！", "わーい、テントだ！ 今夜は ここで 寝るの？"], o: ["ふふ、外で ごはん。なんだか 楽しいわね。", "火の そば、あったかい……。"], c: ["……悪くない 場所。風も 弱い。", "野営か。たき火の 番は まかせて。"], t: ["キャンプですね。お手伝い します！", "火の 番は わたしが いたします。"] },
  fav: { g: ["{d}！ わたしの 大好物！ おかわり ある！？"], o: ["{d}……わたしの 好きな もの、おぼえてて くれたの？"], c: ["……{d}。好物。……ありがと。"], t: ["{d}……！ わたしの 好物です。うれしい……！"] },
  eat: { g: ["おいしー！ みんなで 食べると もっと おいしいね！"], o: ["おいしい……。体の 中から あったまるわ。"], c: ["……うん、おいしい。腕を 上げたね。"], t: ["とても おいしいです。ごちそうさまでした。"] },
  rest: { g: ["ふあ……ちょっと だけ 寝ても いい？ ちょっと だけ……"], o: ["少し 休みましょ。……星が きれいね。"], c: ["休める ときに 休む。……肩、貸して あげる。"], t: ["少し 休みましょう。見張りは わたしが します。"] },
  bye: { g: ["もう おしまい？ また キャンプ しようね！"], o: ["楽しかった。また 来ましょうね。"], c: ["……片づけ 完了。行こう。"], t: ["片づけ、終わりました。参りましょう。"] },
};
function campHero(p, C) {
  if (!C || (C.hero && C.hero.isValid?.()) || !heroInfo(p) || inStory(p)) return null;
  const c = C.c, at = { x: c.x + 0.4, y: c.y, z: c.z + 1.4 }, fire = { x: c.x + 1.8, y: c.y + 0.6, z: c.z };
  const e = heroSpawn(p, at, { face: fire }); if (!e) return null;
  try { e.setProperty("mrpg:act", 1); e.setDynamicProperty("mrpg:act0", 1); e.triggerEvent("mrpg:still"); } catch {}
  C.hero = e; return e;
}
const DISH = [["fd_curry", "キャンプカレー", 600], ["fd_stew", "ぐつぐつ シチュー", 400], ["fd_bento", "みんなの おにぎり弁当", 450], ["fd_cake", "たき火の パンケーキ", 500], ["fd_tea", "あったか 薬草茶", 200]];

export async function startCamp(p) {
  if (p.dimension.id !== OWID) { await notice(p, "キャンプ", "§7キャンプは 地上（オーバーワールド）だけ"); return false; }
  let bad = null; try { bad = typeof p.getDynamicProperty("mrpg:pret") === "string" ? "遊び場の 中" : inDungeon(p) ? "石板の 中" : inRuins && inRuins(p) ? "遺跡の 中" : inBattle(p) ? "戦いの 間" : null; } catch {}
  if (bad) { await notice(p, "キャンプ", `§7${bad}では キャンプできない`); return false; }
  if (inCamp(p)) { await campMenu(p); return true; }
  const d = load(p); if (!d || !(d.party || []).length) { await notice(p, "キャンプ", "§7仲間が いない"); return false; }
  let v = { x: 0, z: 1 }; try { const w = p.getViewDirection(); const h = Math.hypot(w.x, w.z) || 1; v = { x: w.x / h, z: w.z / h }; } catch {}
  const tx = p.location.x + v.x * 4, tz = p.location.z + v.z * 4, ty = __pf.groundY(tx, tz, Math.floor(p.location.y), false);
  if (Number.isNaN(ty) || Math.abs(ty - p.location.y) > 3) { await notice(p, "キャンプ", "§7ここは でこぼこか 水の 上で テントを はれない。平らな 所で もう一度"); return false; }
  let tent = null; try { tent = OW().spawnEntity("mrpg:tent", { x: Math.floor(tx) + 0.5, y: ty, z: Math.floor(tz) + 0.5 }); tent.nameTag = "§6キャンプ §7（たたくと メニュー）"; tent.setDynamicProperty("mrpg:cown", p.id); } catch { await notice(p, "キャンプ", "§7テントを はれなかった"); return false; }
  const c = { x: Math.floor(tx) + 0.5, y: ty, z: Math.floor(tz) + 0.5 };
  try { p.setDynamicProperty(KEY, JSON.stringify(c)); } catch {}
  try { const pet = findPet(p); if (pet) pet.remove(); } catch {}
  CAMP.set(p.id, { tent, c });
  spawnCrowd(p, { ...c, flat: false });
  { const C = CAMP.get(p.id), e = campHero(p, C); if (e) heroLine(p, HL.come, e, 9); }
  giveBall(p);
  sound(p, "random.levelup", 0.9);
  try { showTitle(p, "§6§lキャンプ！", { subtitle: "§fボールを 投げる・なでる・テントで ごはん", fadeInDuration: 0, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
  return true;
}
export function endCamp(p, why) {
  const C = CAMP.get(p.id); CAMP.delete(p.id);
  if (C && okE(C.tent)) try { C.tent.remove(); } catch {}
  if (C && C.hero) { if (why === "片づけた" && okE(C.hero)) heroLine(p, HL.bye); heroDespawn(p, C.hero); }
  try { for (const e of OW().getEntities({ type: "mrpg:tent" })) if (e.getDynamicProperty("mrpg:cown") === p.id) e.remove(); } catch {}
  clearCrowd(p); dropBall(p.id); takeBallItem(p);
  try { p.setDynamicProperty(KEY, undefined); } catch {}
  if (why) try { barNote(p).setActionBar(`§7キャンプを 片づけた（${why}）`); } catch {}
  system.runTimeout(() => { try { const d = load(p); const m = d && d.out && [...d.party, ...(d.bench || []), ...(d.box || [])].find((x) => x.id === d.out); if (m && !findPet(p)) spawnPet(p, m); } catch {} }, 10);
}
const COOK = new Map();
async function cook(p) {
  const d = load(p); if (!d) return;
  const L = DISH.filter(([id]) => ITEMS[id]);
  const k = await choose(p, "キャンプの 料理", `§fみんなで 食べると きずなが 深まる\n§7次の 戦い 3回 強く なる §8（お金 ${gold(d.gold || 0)}）`, [...L.map(([id, n, pr]) => B(`§l${n}\n§8材料代 ${pr} タヨ`, ICON("i_shop"))), B("§7戻る", ICON("i_back"))]);
  const it = L[k]; if (!it || !inCamp(p)) return;
  const d2 = load(p); if (!d2 || (d2.gold || 0) < it[2]) { await notice(p, "キャンプ", "§7お金が たりない"); return; }
  d2.gold -= it[2]; save(p, d2);
  const e = exOf(p); e.food = { k: it[0], n: 3 }; e.ck2 = (e.ck2 || 0) + 1; exSave(p, true);
  const c = campOf(p); if (c) gather(p, { x: c.x + 1.8, z: c.z - 0.2 });
  try { for (let n = 0; n < 6; n++) system.runTimeout(() => { try { OW().spawnParticle("minecraft:campfire_smoke_particle", { x: c.x + 1.8, y: c.y + 1.2, z: c.z }); } catch {} }, n * 6); } catch {}
  sound(p, "random.burp");
  { const h = heroInfo(p), C = CAMP.get(p.id); if (h && C && okE(C.hero)) heroLine(p, FAV[h.key] === it[0] ? { [h.t]: HL.fav[h.t].map((x) => x.replace("{d}", it[1])) } : HL.eat, C.hero, 2); }
  const day = Math.floor(Date.now() / 1800000); let up = 0;
  if (COOK.get(p.id) !== day && e.ckD !== day) { COOK.set(p.id, day); e.ckD = day; exSave(p, true); for (const r of runnersOf(p)) try { __bond.addNk(p, r.m, 3, "キャンプの ごはん"); up++; } catch {} }
  await notice(p, "キャンプの 料理", `§a${it[1]}が できた！ §fみんなで いっしょに 食べた。${up ? `\n§dみんなの きずなが 深まった（+3）` : "\n§7（きずなは 30分に 1回まで）"}\n§f次の 戦い 3回 強く なる`);
}
/* 第124版: ひと休み（ヒロインと たき火の そばで。少し 回復する だけ）*/
async function rest(p) {
  const C = CAMP.get(p.id); if (!C || !okE(C.hero)) return;
  heroLine(p, HL.rest, C.hero);
  try { C.hero.setProperty("mrpg:act", 8); system.runTimeout(() => { try { if (okE(C.hero)) C.hero.setProperty("mrpg:act", 1); } catch {} }, 120); } catch {}
  try { p.addEffect("regeneration", 100, { amplifier: 1, showParticles: false }); barNote(p).setActionBar("§7たき火の そばで 少し 休んだ"); } catch {}
  try { const c = C.c; for (let n = 0; n < 4; n++) system.runTimeout(() => { try { OW().spawnParticle("minecraft:campfire_smoke_particle", { x: c.x + 1.8, y: c.y + 1.2, z: c.z }); } catch {} }, n * 8); } catch {}
}
export async function campMenu(p) {
  for (;;) {
    if (!inCamp(p)) return;
    const n = runnersOf(p).length;
    const c = await choose(p, "キャンプ", `§f仲間 ${n}匹と キャンプ中\n§7ボールを 投げると みんなで 取りあう。なでると よろこぶ`, [B("§6§l料理を つくる\n§8みんなで ごはん", ICON("i_shop")), B("§lみんなを 集める", ICON("i_run")), B("§lボールを もらう", ICON("i_skill")), B("§cキャンプを 片づける", ICON("i_back")), ...(okE(CAMP.get(p.id)?.hero) ? [B(`§lひと休み\n§8${heroInfo(p)?.name || ""}と たき火の そばで`, ICON("i_skill"))] : []), B("§7閉じる", ICON("i_back"))]);
    if (c === 0) await cook(p);
    else if (c === 1) { const cc = campOf(p); for (const r of runnersOf(p)) { r.st = "follow"; r.tt = -40; } try { barNote(p).setActionBar("§fみんな 集まって きた！"); } catch {} return; }
    else if (c === 2) { giveBall(p); return; }
    else if (c === 3) { endCamp(p, "片づけた"); return; }
    else if (c === 4 && okE(CAMP.get(p.id)?.hero)) { await rest(p); return; }
    else return;
  }
}
EXH.camp = startCamp;
/* テントを たたく・さわる → メニュー */
const tentHit = (p, e) => { if (e?.typeId !== "mrpg:tent") return false; let own = null; try { own = e.getDynamicProperty("mrpg:cown"); } catch {} if (own !== p.id) { try { barNote(p).setActionBar("§7ほかの 人の テント"); } catch {} return true; } system.run(() => campMenu(p).catch(() => {})); return true; };
world.afterEvents.entityHitEntity.subscribe(({ damagingEntity: p, hitEntity: e }) => { if (p?.typeId === "minecraft:player") tentHit(p, e); });
try { world.afterEvents.playerInteractWithEntity?.subscribe(({ player: p, target: e }) => tentHit(p, e)); } catch {}
/* 見はり（2tick）: 動き・自動で 片づけ */
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (!inCamp(p)) continue;
    try {
      const c = campOf(p); if (!c) continue;
      const C = CAMP.get(p.id);
      if (!C) { endCamp(p, "もう一度 はってね"); continue; }   /* ワールドを 開きなおした */
      if (p.dimension.id !== OWID) { endCamp(p, "ちがう 世界へ 行った"); continue; }
      if (Math.hypot(p.location.x - c.x, p.location.z - c.z) > 32) { endCamp(p, "はなれた"); continue; }
      if (inBattle(p)) { endCamp(p, "戦いに なった"); continue; }
      if (!okE(C.tent)) { endCamp(p, "テントが なくなった"); continue; }
      crowdTick(p, { ...c, flat: false });
      if ((C.ht = (C.ht || 0) + 1) % 20 === 0 && !okE(C.hero)) campHero(p, C);   /* 第124版: 物語の あとなど いなく なったら もどる */
    } catch {}
  }
}, 2);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { const C = CAMP.get(playerId); CAMP.delete(playerId); if (C && okE(C.tent)) try { C.tent.remove(); } catch {} }); } catch {}
/* 起動した とき: 残った テントと 仲間を 片づける */
system.runTimeout(() => { try { const live = new Set([...CAMP.values()].map((C) => C.tent?.id)); for (const e of OW().getEntities({ type: "mrpg:tent" })) if (!live.has(e.id)) try { e.remove(); } catch {} for (const e of OW().getEntities({ tags: ["mrpg_crowd"] })) if (!isCrowd(e.id)) try { e.remove(); } catch {} } catch {} }, 100);   /* いま 使って いる ものは のこす */
/* 第124版: 60秒ごとに 人の 近くだけ、持ち主の いない テントと 遊び場の 仲間を 消す（抜けた とき 読みこまれて いなかった もの）*/
system.runInterval(() => { try { const live = new Set([...CAMP.values()].map((C) => C.tent?.id)); for (const q of world.getAllPlayers()) { if (q.dimension.id !== "minecraft:overworld") continue; const at = { location: q.location, maxDistance: 96 };
  for (const e of OW().getEntities({ type: "mrpg:tent", ...at })) if (!live.has(e.id)) try { e.remove(); } catch {}
  for (const e of OW().getEntities({ tags: ["mrpg_crowd"], ...at })) if (!isCrowd(e.id)) try { e.remove(); } catch {} } } catch {} }, 1200);
export const __camp = { CAMP, startCamp, endCamp, campMenu, cook, inCamp };
{ const H = (globalThis.__mqSkin = globalThis.__mqSkin || {}); H.camp = startCamp; }   /* 第124版: スキンシップブックから 呼ぶ */
