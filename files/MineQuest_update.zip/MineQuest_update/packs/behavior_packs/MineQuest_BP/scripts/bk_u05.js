/* 第126版 裏5「斬り跡・上」（ポカラの 丘／おがわの 里 リール）— 作業 UA。段なし（前27 の 自由な 話）*/
import { bkAdd, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, fac, facMark } from "./epfac.js";
import { ok } from "./ui.js";
import { UA } from "./bk_u01.js";
const { F, S1 } = FAC_OPS;

/* 斬り跡（地面の 細い 割れ目。底は 黒い 石。そばに 一輪の 花）*/
facAdd("u_crack", { D: [9, 11, 8], box: [-1, -5, 5, 5], H: 3, look: [2, 0, 0], marks: { crack: [2, 0, 0], flower: [4, 1, 0] }, build: (P) => [
  F(1, -4, -3, 2, 4, -1, "air"), F(1, -4, -4, 2, 4, -4, "deepslate"), F(0, -4, -1, 0, 4, -1, "cobbled_deepslate"), F(3, -4, -1, 3, 4, -1, "cobbled_deepslate"),
  S1(4, 1, 0, "poppy"), S1(4, -3, 0, P.plant || "short_grass"), S1(0, 4, 0, "dandelion"),
] });
/* 川辺の 斬り跡（川の 流れ・岸の 石・板の 橋・岸に 走る 割れ目）*/
facAdd("u_rivercrack", { D: [10, 12, 9], box: [-1, -6, 7, 6], H: 3, look: [3, 0, 0], marks: { crack: [2, -2, 0], bridge: [5, 0, 1] }, build: () => [
  F(4, -6, -1, 6, 6, -1, "water"), F(4, -6, -2, 6, 6, -2, "gravel"), F(3, -6, -1, 3, 6, -1, "stone"), F(7, -6, -1, 7, 6, -1, "stone"),
  F(4, 0, 0, 6, 1, 0, "spruce_slab"), F(1, -4, -3, 2, -1, -1, "air"), F(1, -4, -4, 2, -1, -4, "deepslate"), S1(2, 3, 0, "blue_orchid"), S1(1, 4, 0, "short_grass"),
] });

castAdd("u_pkid", { nm: "ポッコ", role: "ポカラの 子", gobi: "", skin: "taro", town: "t4", at: () => { const q = UA.bld("t4", ["plaza", "home"], "")(); return q ? { x: q.x + 2, z: q.z + 2 } : null; },
  hide: (s) => !bkHas(s, "u05e3"),
  after: [[() => true, ["{smile}あの 侍の 小さい 槌、ほしかったなあ。……でも 人は 叩かないって。じゃあ 何を 叩くんだろ？"]]] });
castAdd("u_rinn", { nm: "セキ", role: "リールの 宿の 主", gobi: "", skin: "m6_dario", town: "t3", at: () => { const q = UA.bld("t3", ["inn"], "")(); return q ? { x: q.x + 2, z: q.z } : null; },
  hide: (s) => !bkHas(s, "u05e7"),
  after: [[() => true, ["{smile}宿帳に あの 侍の 名、書いて やったよ。じっと 見て『細えな』だと。……字は、細い もんさ。"]]] });

const C1 = UA.far("u_crack1", "t4", 0.6, "ポカラの 丘の 割れ目", 80, 260);   /* 第127版(fac2): 町の 外れ → 離れた 丘 */
const PKV = UA.bld("t4", ["plaza", "home", "shop"], "ひだまりの 村 ポカラ");
const C2 = UA.far("u_crack2", "t3", 0.6, "リールの 川辺の 斬り跡", 80, 260);   /* 第127版(fac2): 町の 外れ → 離れた 川辺 */
const RINN = UA.bld("t3", ["inn"], "おがわの 里 リールの 宿");
const crack = (K, p) => fac(K, p, "u_crack1", "u_crack", 0, UA.Y(K, p));
const river = (K, p) => fac(K, p, "u_crack2", "u_rivercrack", 0, UA.Y(K, p));
/* 残像（千年前の 人の 姿。煙の 中で 立ち、消える）*/
function ghost(K, p, q, nm, job) { const e = K.npcNear(p, nm, job, true); if (ok(e) && q) try { e.teleport({ x: q.x, y: q.y ?? e.location.y, z: q.z }); } catch {} if (ok(e)) K.burst(p.dimension, e.location, "minecraft:white_smoke_particle", 10, 0.6, 1); return e; }

bkAdd("u05", [
  { id: "u05e1", pv: 127, t: "斬った 音", place: C1, fac: "u_crack1", battles: 0,
    hint: "§fアルカトラス地方 §eひだまりの 村 ポカラの 丘§f の 割れ目へ 行こう §7（斬り跡 1）",
    syn: "ポカラの 丘の 割れ目。ムサシが 耳を 当てた。「斬った 音が、まだ 残ってる」。",
    async run(p, d, K) {
      const Q = crack(K, p);
      await K.open(p, "ポカラの 丘の 割れ目", "day");
      if (Q) await K.push(p, Q, 22, 6, 0.4);
      await K.narr(p, ["§7丘の 草の 中に、まっすぐな 細い 割れ目。§8刀で 一筋、地面を 引いた ような。"], Q);
      const eM = UA.mu(K, p, true);
      await UA.ear(K, p, eM, Q);
      await K.say(p, "ムサシ", ["{shock,…}……斬った 音が、まだ 残ってる。", "{closed}千年 前の 音だ。……地面が 覚えてやがる。"], null);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{?}……耳を 当てて みるか。", "{closed}底の ほうで 鳴ってる。キン、って 細い 音だ。"], p);
      await K.narr(p, ["§7あなたも 割れ目の そばに しゃがんだ。§8……風の 音に まじって、遠い 金物の 響きが する。"], Q);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}一太刀だ。迷いの ねえ 太刀筋。", "{sad}……けど、最後だけ 音が 揺れてる。斬った あとで、何か 振り返った 音だ。"], Q);
      await UA.en(K, p, ["{rage,low}§4……われの 太刀だ。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{?}何を 斬った。……言わねえのか。"], p);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……見れば わかる、と 言った。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{angry}……字より 確か、ってやつか。じゃあ 見るまで 待つ。"], p);
      await K.end(p, { leave: [eM], card: "§7→ 割れ目から 何かが 立ち上がる（もう一度 割れ目へ）" });
      return true;
    } },
  { id: "u05e2", pv: 127, t: "花を かばう 形", place: C1, fac: "u_crack1", battles: 1,
    hint: "§fポカラの 丘の §e割れ目§f で、残像と 向き合おう",
    syn: "割れ目から 残像が 立ち上がり、戦いに なった。消える 前、残像は 花を 一輪 かばう 形を なぞった。",
    async run(p, d, K) {
      const Q = crack(K, p), fq = facMark("u_crack1", "flower", p.location);
      await K.open(p, "ポカラの 丘の 割れ目", "day");
      const eM = UA.mu(K, p, true);
      if (Q) K.burst(p.dimension, Q, "minecraft:white_smoke_particle", 14, 0.8, 1.2);
      await K.say(p, "ムサシ", ["{angry,!}……立った。残像だ。", "{closed}斬るんじゃ ねえ、止めるだけだ！ 行くぞ！"], null);
      const r = await K.battle(p, K.team(["nether", "beast", "nether"], 90, 3, 46), { name: "斬り跡の 残像（千年前）", arena: "丘の 割れ目", theme: "ruins", speaker: "残像", lines: { half: "……サセヌ……", low: "……ハナ……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……強え。一度 引く。", K.RT(p)], null); await K.end(p, { bye: [eM] }); return false; }
      const eG = ghost(K, p, fq ? { x: fq.x - 0.8, y: fq.y, z: fq.z } : null, "§7残像", K.PJ("m6_bram", 8));
      if (fq) await K.push(p, fq, 22, 3.5, 0.5);
      K.act(eG, "kneel");
      await K.narr(p, ["§7消える 前に、残像は 一輪の 花の 上に 体を 丸めた。§8……斬撃から、花を かばう 形。"], fq || eG);
      if (ok(eG)) K.burst(p.dimension, eG.location, "minecraft:white_smoke_particle", 10, 0.5, 1);
      await K.say(p, "ムサシ", ["{closed,…}……斬った やつが、花を かばったのか。", "{?}何から 守ったんだ。"], null);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{closed}……斬られる 側の 形じゃ ねえ。斬った 側が、花の 前に しゃがんだんだ。", "{?}斬る 前か。後か。"], p);
      await K.narr(p, ["§7残像が 消えた あとも、一輪の 花は 風に 揺れて いた。"], fq || eM);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……後だ。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{shock}……しゃべったな。", "{closed}斬ってから、花を かばった。……何から だよ。"], p);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……次の 斬り跡で、聞け。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{sweat}……村で 一休み する。腹が 鳴ってる。お前のだ。"], p);
      K.pay(p, this, 1500, [["c_fruit", 2]]);
      await K.end(p, { leave: [eM], bye: [eG], card: "§7→ ポカラの 村で 一休み" });
      return true;
    } },
  { id: "u05e3", t: "人を 叩く もんじゃ ねえ", place: PKV, battles: 0,
    hint: "§fひだまりの 村 §eポカラ§f へ 行こう",
    syn: "ポカラの 村で、子どもが 聞き槌を ほしがった。ムサシ「これは 人を 叩く もんじゃ ねえ」。",
    async run(p, d, K) {
      await K.open(p, "ひだまりの 村 ポカラ", "day");
      const eK = K.cast(p, "u_pkid"), eM = UA.mu(K, p, true);
      await K.up(p, eK, 10);
      await K.csay(p, "u_pkid", ["{smile,☆}ねえ、その 小さい 槌 ちょうだい！", "{smile}それで 兄ちゃんの 頭 コンって したい！"], eM);
      K.act(eM, "no");
      await K.say(p, "ムサシ", ["{sweat}だめだ。これは 人を 叩く もんじゃ ねえ。", "{closed}物に 聞く 槌だ。人には、耳を 寄せる。"], eK);
      await K.csay(p, "u_pkid", ["{?}……耳？"], eM);
      K.act(eM, "kneel"); await K.wait(8);
      await K.say(p, "ムサシ", ["{smile}……ほら。お前の 腹、鳴ってる。家に 帰れ。"], eK);
      K.act(eM, 0);
      await K.csay(p, "u_pkid", ["{shock,!}ほんとに 聞こえた！？ ……帰る！"], eM);
      await K.ots(p, eM, eK, 8);
      await K.say(p, "ムサシ", ["{smile}……走るな。転ぶ 音が する。"], eK);
      await K.up(p, eK, 8);
      await K.csay(p, "u_pkid", ["{smile}兄ちゃん、名前は？"], eM);
      await K.ots(p, eM, eK, 8);
      await K.say(p, "ムサシ", ["{closed}ムサシ。……お前は。"], eK);
      await K.up(p, eK, 8);
      await K.csay(p, "u_pkid", ["{smile,☆}ポッコ！ ……また 来てね、ムサシ！"], eM);
      await K.narr(p, ["§7ポッコは 振り返り 振り返り、坂の 上の 家へ 走って いった。"], eK);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}ポッコ。覚えた。", "{smile}……人の 名前は、こうやって 覚えるんだ。"], p);
      await K.end(p, { leave: [eK, eM], card: "§7→ おがわの 里 リールの 川辺へ（斬り跡 2）" });
      return true;
    } },
  { id: "u05e4", pv: 127, t: "載らないでね", place: C2, fac: "u_crack2", F: ["F41"], battles: 0,
    hint: "§fアルカトラス地方 §eおがわの 里 リールの 川辺§f の 斬り跡へ 行こう",
    syn: "リールの 川辺の 斬り跡。サヤの 残像が 笑った。「兄さまの 帳に、わたしの 名前は 載らないでね」。",
    async run(p, d, K) {
      const Q = river(K, p), cq = facMark("u_crack2", "crack", p.location);
      await K.open(p, "リールの 川辺の 斬り跡", "day");
      if (Q) await K.at(p, Q, 14, 6, 1.4);
      const eM = UA.mu(K, p, true);
      await UA.ear(K, p, eM, cq);
      await K.flashback(p, { set: "fb_river", label: "§7―― 千年前　リールの 川辺", tod: "dusk", ptc: "dust",   /* 第127版: 斬り跡の 残像を 回想の 絵で */
        actors: { sa: { nm: "§fサヤ", job: K.PJ("sayo", 9), at: [3, 0.9], look: "en" }, en: { nm: "§4若い エンマ", job: K.PJ("c7_enma_y", 9), at: [3.2, -1], look: "sa", hold: "notebook" } },
        beats: [
          ["narr", "§7千年前の 夕暮れ。川辺で、帳を 抱えた 兄と、妹が 並んで いた。", "en"],
          ["say", "en", "{closed}……今日も 帳に、名を 書いた。送られて いく 者たちの 名だ。", "sa"],
          ["say", "sa", "{smile}兄さまの 帳に、わたしの 名前は 載らないでね。", "en"],
          ["say", "en", "{?}……載るのは、死んだ 時だけだ。", "sa"],
          ["say", "sa", "{smile,♪}だから。……ずっと 先まで。", "en"],
          ["act", "en", "nod"],
        ] });   /*F41*/
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{shock,…}……工房の 石の 娘だ。こんな 顔で 笑うのか。", "{closed}帳に 名が 載るのは、死んだ 時だろ。……載らないで、って。"], null);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{?}……見たか。笑ってた。", "{closed}石の 顔と 同じだ。……けど、動いてた。"], p);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……覚えて いる。あの 日の 夕暮れも。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}……リンの 声、初めて 聞いた。", "{sad}壁ごしの リン、リン より、ずっと 細え 声だった。"], p);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{?}エンマ。お前の 帳に、あいつの 名前は 載ってるのか。"], p);
      await UA.en(K, p, ["{rage,low}§4……載せて おらぬ。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}……そうか。なら、まだ 呼べる。", "{smile}シズクが 読んだ 頁と 同じだ。名が なければ、呼び戻せる。"], p);
      await K.end(p, { leave: [eM], card: "§7→ 川辺に 残像が 立つ（もう一度 川辺へ）" });
      return true;
    } },
  { id: "u05e5", pv: 127, t: "川辺の 残像", place: C2, fac: "u_crack2", battles: 1,
    hint: "§fリールの §e川辺§f で 残像と 戦おう",
    syn: "川辺の 割れ目から 残像が あふれ、戦った。",
    async run(p, d, K) {
      const Q = river(K, p);
      await K.open(p, "リールの 川辺の 斬り跡", "day");
      const eM = UA.mu(K, p, true);
      if (Q) K.burst(p.dimension, Q, "minecraft:white_smoke_particle", 14, 0.8, 1.2);
      await K.say(p, "ムサシ", ["{angry}来るぞ。……川の 音に まぎれて、足音が しねえ。気を つけろ！"], null);
      const r = await K.battle(p, K.team(["nether", "golem", "nether"], 91, 3, 48), { name: "川辺の 残像（千年前）", arena: "リールの 川辺", theme: "ruins", speaker: "残像", lines: { half: "……カクナ……", low: "……カクナ……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……一度 引く。", K.RT(p)], null); await K.end(p, { bye: [eM] }); return false; }
      await K.say(p, "ムサシ", ["{closed}……「書くな」って 言ってた。何度も。", "{?}誰に 言ってたんだ。……王さまに か。"], null);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……われにだ。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{shock}……お前に？ 書くなって、帳にか。", "{closed}帳を 書くのが 王の 仕事なんだろ。"], p);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……宿で 話す。小僧、川の 音が うるさい。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{angry}川の せいに すんな。", "{closed}……まあ いい。宿まで 待つ。"], p);
      await K.narr(p, ["§7川の 流れが、割れ目の 中へ 細く 落ちて いく。§8……さっきの 声は、もう 聞こえない。"], Q || eM);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}……二つ目だ。あと 三つ。", "{sweat}……足が 冷てえ。橋を 使えば よかった。"], p);
      K.pay(p, this, 1500, [["c_fruit", 2]]);
      await K.end(p, { leave: [eM], card: "§7→ リールの 宿で 休もう" });
      return true;
    } },
  { id: "u05e6", t: "字は 嘘を つかぬ", place: RINN, battles: 0,
    hint: "§fおがわの 里 §eリールの 宿§f で 休もう",
    syn: "宿で、ムサシと エンマが 言い合った。エンマ「字は 嘘を つかぬ」ムサシ「書いた やつは つく」。",
    async run(p, d, K) {
      await K.open(p, "リールの 宿（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      await K.narr(p, ["§7宿の 部屋。ムサシは 壁の 張り紙を にらんで いる。§8読めないのに。"], eM);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……『川で 遊ぶ ときは、大人と』。そう 書いて ある。"], null);
      await K.say(p, "ムサシ", ["{sweat}勝手に 読むな、エンマ。", "{closed}……書いて あるだけだろ。"], null);
      await UA.en(K, p, ["{rage,low}§4字は、嘘を つかぬ。"], null);
      await K.push(p, eM, 16, 3, 1.4);
      await K.say(p, "ムサシ", ["{angry,up}書いた やつは つく。", "{closed}……音は つかねえ。叩けば、中身の とおりに 鳴る。"], null);
      await UA.en(K, p, ["{rage,low}§4……小僧。だから われは、書かなかった。"], null);
      await K.say(p, "ムサシ", ["{shock}……何を。……おい、寝るな。……寝やがった。"], null);
      await K.narr(p, ["§7ムサシは 鍔を 布で 包み直し、壁の 張り紙を もう一度 見た。"], eM);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{?}……なあ。書かなかったって、何を だと 思う。", "{closed}あいつ、帳の 王なんだろ。王が 書かねえって、よっぽどだ。"], p);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{sad}……あの 石の 娘の 名か。それとも、もっと 別の 何かか。", "{closed}……明日、聞く。寝てる やつは 叩かねえ。"], p);
      await K.end(p, { leave: [eM], kind: "night", card: "§7→ 朝" });
      return true;
    } },
  { id: "u05e7", t: "細い 字", place: RINN, battles: 0,
    hint: "§fリールの §e宿§f の 朝",
    syn: "朝、宿の 主が ムサシの 代わりに 宿帳に 名を 書いて くれた。ムサシは 書かれた 字を じっと 見て「……これが 俺か。細えな」。",
    async run(p, d, K) {
      await K.open(p, "リールの 宿の 朝", "day");
      const eI = K.cast(p, "u_rinn"), eM = UA.mu(K, p, true);
      await K.csay(p, "u_rinn", ["{smile}お侍さん、宿帳に 名前を。……あ、書けないのかい。じゃあ 言いな。", "{closed}む、さ、し、と。"], eM);
      K.sound(p, "item.book.page_turn", 0.7); K.hold(eI, "book");
      await K.give(eI, eM, "book");
      await K.push(p, eM, 18, 2.8, 1.4);
      await K.say(p, "ムサシ", ["{closed,…}……これが 俺か。", "{smile}細えな。"], eI);
      await K.say(p, "ムサシ", ["{closed}……書いた 名前は 信じねえ。けど、お前の 口から 言って 書いたなら、まあ いい。"], eI);
      await K.up(p, eI, 8);
      await K.csay(p, "u_rinn", ["{?}……あんた、字を 習う 気は ないのかい。"], eM);
      await K.ots(p, eM, eI, 8);
      await K.say(p, "ムサシ", ["{closed}ねえ。……覚えたら、書いた 字を 信じちまいそうだ。"], eI);
      await K.up(p, eI, 8);
      await K.csay(p, "u_rinn", ["{smile}変わった お侍さんだ。……おれは セキ。この 宿の 主だ。"], eM);
      await K.ots(p, eM, eI, 8);
      await K.say(p, "ムサシ", ["{closed}セキ。……覚えた。声で。"], eI);
      await K.narr(p, ["§7ムサシは 宿帳を 返す 前に、自分の 名の 字を 指で 一度 なぞった。"], eM);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……良い 字だ。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{smile}……細えけど、悪くねえ 字だ。", "{closed}行くぞ。川の 向こうだ。"], p);
      await K.end(p, { leave: [eM], bye: [eI], card: "§7→ 川を 渡って 次の 斬り跡へ" });
      return true;
    } },
  { id: "u05e8", pv: 127, t: "川を 渡る", place: C2, fac: "u_crack2", battles: 0,
    hint: "§fリールの §e川辺§f の 橋を 渡ろう",
    syn: "板の 橋で 川を 渡った。次の 斬り跡は、こもれびの 森。",
    async run(p, d, K) {
      const Q = river(K, p), bq = facMark("u_crack2", "bridge", p.location);
      await K.open(p, "リールの 川辺", "day");
      const eM = UA.mu(K, p, true);
      if (bq) { await K.walkCam(p, eM, bq, 20); await K.at(p, bq, 14, 5, 1.4); }
      await K.say(p, "ムサシ", ["{smile}……橋が 鳴る。古い けど、まだ 渡れる 音だ。", "{closed}森へ 行く。残像が、だんだん 近く なってる。"], null);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{?}……橋の 音、わかるか。", "{closed}古い 板は、踏むと 低く 鳴る。腐った 板は、鳴らねえ。"], p);
      await K.up(p, eM, 8);
      await UA.en(K, p, ["{rage,low}§4……板の 端に『重い 荷は 一人ずつ』と 書いて ある。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{sweat}……書いて あるだけだろ。", "{closed}……一人ずつ 渡る。お前が 先だ。"], p);
      K.sound(p, "step.wood", 0.6);
      await K.narr(p, ["§7板の 橋が、足の 下で 低く 鳴った。§8……一つ、二つ、三つ。"], bq || eM);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}……二つの 斬り跡で、わかった ことが ある。", "{sad}斬った 王は、何かを かばってた。花と、妹と。"], p);
      await UA.en(K, p, ["{rage,low}§4……かばいきれては、おらぬ。"], null);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}……だから 行くんだろ。残りは 三つ。森だ。"], p);
      await UA.zeph(K, p);
      await K.end(p, { leave: [eM], card: "§7→ シルヴァ大森林 §eこもれびの 森§7 の 斬り跡へ（右上の 案内）" });
      return true;
    } },
]);
