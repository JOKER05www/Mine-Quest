// 第106版: ライバル レイ（やさしくて 元気）。対戦中の ひとこと
const pick = (L) => L[Math.floor(Math.random() * L.length)];
export const R_START = ["よっしゃ、勝負だ！ 手加減なしで いこうぜ！", "待ってたよ！ 今日も 楽しもうな！", "お互い ベスト 出しきろうぜ！"];
export const R_GOOD = ["おおー、いいじゃん！ マジで 強いな！", "うわ、今の すげえ！ やるなあ！", "ちょ、強すぎだろ！ 楽しくなってきた！", "いい 連携だな……！ 見とれちゃったよ", "マジか、そこ 狙うんだ！ さすが！"];
export const R_MINE = ["よし、いけるいける！", "ナイス、相棒！", "ふふん、こっちも 負けてないぜ！"];
export const R_LOSE1 = ["くーっ、やられた！ でも まだまだ！", "大丈夫、まだ 終わってないからな！"];
export const R_PINCH = ["やばい やばい……！ でも 最後まで 楽しむぞ！", "ここから 逆転、見せてやる……！"];
export const R_WIN = ["へへ、今回は オレの 勝ち！ でも ほんと ギリギリだった！", "楽しかった！ また やろうな！"];
export const R_LOSS = ["あー、負けた！ でも すっげえ 楽しかった！ お前 ほんと 強いよ！", "完敗！ ……次は 負けないからな、約束だぞ！"];
const isRei = (B) => B && B.master && /レイ/.test(String(B.master.name || "")) && !/レイド|ノクス団/.test(String(B.master.name || ""));   /* 第106版: 闇落ちの レイは 明るい ことを 言わない */
const say = (B, L) => { const l = pick(L); for (const x of B.players || []) try { x.p.sendMessage(`§b§lレイ§r§f「${l}」`); } catch {} };
const ratio = (L) => { let h = 0, m = 0; for (const f of L || []) { m += f.mx.hp || 1; h += Math.max(0, f.hp); } return m ? h / m : 0; };
export function reiStart(B) { try { if (isRei(B)) { B.rSaid = { t: 0 }; say(B, R_START); } } catch {} }
export function reiAct(B, a, fx) {
  try {
    if (!isRei(B) || !fx) return;
    const s = B.rSaid || (B.rSaid = { t: 0 }); s.t++;
    if (s.t - (s.last || -9) < 2) return;   /* 言いすぎない */
    const ko = fx.ko || [], dmg = fx.dmg || [];
    const mine = B.allies.includes(a.actor);
    let L = null;
    if (mine && ko.some((t) => t.side === "e")) L = ratio(B.enemies) < 0.35 && !s.pinch ? (s.pinch = 1, R_PINCH) : R_LOSE1;
    else if (mine && (dmg.some((x) => x.crit) || ratio(B.allies) > ratio(B.enemies) + 0.2) && Math.random() < 0.45) L = R_GOOD;
    else if (!mine && ko.some((t) => t.side === "a") && Math.random() < 0.6) L = R_MINE;
    if (L) { s.last = s.t; say(B, L); }
  } catch {}
}
export function reiEnd(B, won) { try { if (isRei(B)) say(B, won ? R_LOSS : R_WIN); } catch {} }
