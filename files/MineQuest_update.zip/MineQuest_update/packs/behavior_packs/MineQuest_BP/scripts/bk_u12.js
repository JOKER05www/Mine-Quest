/* 第126版 裏12「十二年前の 頁」（常世・中の 区／セオの 町／雷鳴の 区）— 作業 UB
   1〜5話: 区5 の 後（bk_u11.js の U.ward(5) の 続き）。時計の 区と 雷鳴の 区の すきまに 綴じこまれた 十二年前の 夜読みの 町（セット u12town）
   区6（四冠 ガムラ・雷鳴）: 6話 前 → 7話 向かい合う → 後: 勝った 一拍（兵士ガイが 剣を 鞘に 納める・鍔の わけ）→ 8話（野営地の 夜）*/
import { K, } from "./bkeng.js";
import { U } from "./bk_u08.js";
import { act, hold, fx, fade, PJ } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
import { ruSite } from "./ruins.js";
const { F, S1, ok } = U;
const V = (g, o, c, t) => ({ g, o, c, t });

facAdd("u12town", { D: [10, 12, 14], box: [-3, -6, 6, 5], H: 5, look: [2, 0, 1.5], marks: { fount: [-1.5, -4, 0.6], door: [1, 1, 1], sign: [1, 3, 2.5], post: [1, 2, 1.2], desk: [3, 1, 1], edge: [6, -5, 1] },
  build: () => [F(-3, -6, 0, 0, -3, 0, "stone_bricks"), F(-2, -5, 0, -1, -4, 0, "water"),
    F(2, -1, 0, 6, 3, 3, "spruce_planks"), F(3, 0, 1, 5, 2, 3, "air"), F(3, 0, 0, 5, 2, 0, "spruce_planks"), F(2, 1, 1, 2, 1, 2, "air"), S1(2, 2, 1, "stripped_oak_log"), S1(2, 2, 2, "stripped_oak_log"),
    S1(1, 3, 2, "bookshelf"), F(2, -1, 4, 6, 3, 4, "dark_oak_slab"), S1(4, 1, 1, "lectern"), S1(5, 2, 1, "bookshelf"), S1(5, 0, 1, "red_bed")] });
facAdd("u12gate", { D: [10, 12, 14], box: [0, -3, 1, 3], H: 7, look: [0, 0, 2], small: true, near: 4, marks: { gate: [-0.6, 0, 1] },
  build: () => [F(0, -3, 0, 1, -3, 5, "polished_blackstone_bricks"), F(0, 3, 0, 1, 3, 5, "polished_blackstone_bricks"), F(0, -3, 6, 1, 3, 6, "polished_blackstone_brick_slab"), S1(0, -3, 6, "lightning_rod"), S1(0, 3, 6, "lightning_rod"), F(0, -2, 0, 0, 2, 0, "iron_bars")] });

/* 時計の 区と 雷鳴の 区の すきま */
const GAP = () => { const a = ruSite(5), b = ruSite(6); return a && b ? { x: Math.floor((a.x + b.x) / 2), z: Math.floor((a.z + b.z) / 2) } : null; };
const ASH = (p, n = 10) => { const l = p.location; for (let k = 0; k < n; k++) try { p.dimension.spawnParticle(k % 2 ? "minecraft:basic_smoke_particle" : "minecraft:falling_dust_dragon_egg_particle", { x: l.x + (k - n / 2) * 1.3, y: l.y + 5, z: l.z + 3 + (k % 3) }); } catch {} };
const town = async (p, K) => { const t = K.fac(p, "u12town", "u12town", 99, U.y0(p)); ASH(p); return t; };

const fight6 = U.fight(6, async (p, C) => {
  await K.open(p, "常世 ― 雷鳴の 区");
  K.fac(p, "u12gate", "u12gate", 99, U.y0(p));
  const mu = U.mu(C), so = U.soul(p, C, 2.4, -1.8, "none"); await K.up(p, mu, 8);
  const e = U.boss(p, C, 6, 11, 0); await U.bossIn(p, e, 6);
  await U.say(p, "ガムラ", ["{angry,…}……見て いた。", "{closed,up}門を 守った 兵士を。三千年、ずっと。剣を 抜いた まま、一度も 倒れなかった"], mu);
  await U.H(p, V(["{shock,!}あの 目……どこへ 行っても、こっちを 見てた 目だ"], ["{shock,!}あの 目……どこへ 行っても、こっちを 見てた 目だわ"], ["{shock,!}……あの 目。どこでも こっちを 見てた"], ["{shock,!}あの 目……どこへ 行っても、こちらを 見て いた 目です"]), e);
  await U.M(p, mu, ["{shock,汗}……あの 目、瞬きの 音が しねえ。"], "guard");
  await U.say(p, "ガムラ", ["{rage,!,low,roar}おまえも 見て やる。最後まで 立って いられるか"]);
}, async (p, C) => {
  K.fac(p, "u12gate", "u12gate", 99, U.y0(p)); const g = facMark("u12gate", "gate", p.location);
  const e = U.boss(p, C, 6, 7, 0); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "ガムラ", ["{closed,…}……見事だ。あの 兵士と、同じ 目を して いる"]);
  if (ok(e)) await fade(e, "minecraft:electric_spark_particle");
  const gy = C.npc("", PJ("guy", 8), 4.6, 1.2, 0, "veil"); act(gy, "guard"); hold(gy, "katana");
  if (ok(gy)) await K.up(p, gy, 14);
  K.sound(p, "random.anvil_land", 0.3, 1.4); hold(gy, 0); act(gy, "bow");
  await U.narr(p, ["§7門の 前の 兵士 ガイの 石が、§f剣を 鞘に 納めて§7、消えた。"], gy || g);
  if (ok(gy)) await fade(gy, "minecraft:endrod");
  /* 今日の ムサシと エンマ（鍔の わけ）*/
  const mu = U.mu(C); await K.up(p, mu, 8);
  await U.tap(p, mu);
  await U.M(p, mu, ["{closed}……三千年、抜きっぱなしの 刀だった。……重い 音が した。"], "hold");
  await U.E(p, mu, ["……千年 守り続けた 者なら、ほかにも いる"]);
  await U.M(p, mu, ["{sad,up}……なあ エンマ。うちの 先祖が、お前を 鍔に 閉じこめたんだよな。……すまねえ"], "bow");
  await U.E(p, mu, ["……閉じよと 頼んだのは、われだ。われが 死ねば、帳は 神の 手に 落ちる。……だから クロガネに 頼んだ。決して 折れぬ 鍔で、われを 閉じよ、と"]);
  await U.E(p, mu, ["……そして、妹を 頼む、と。千年、約束を 守ったのは おまえの 家だ"]);
  act(mu, "kneel"); await U.narr(p, ["§7ムサシは 何も 言わずに、腰の 鍔に 手のひらを 当てた。"], mu);
  await U.M(p, mu, ["{closed,low}……一つ、二つ、三つ。……親父が 毎朝 叩いてた 数だ。", "{closed}……あれ、お前への 返事 だったのか。"], "kneel");
  await U.E(p, mu, ["……ああ。千年、毎朝 聞こえて いた"]);
});

U.reg("u12", [
  { id: "u12e1", t: "ここだけ 音が 若え", free: false, F: ["F40"], ans: ["qb061"],
    syn: "区と 区の すきまで、ムサシが 足を 止めた。「ここだけ、音が 若え」。灰の 降る 町。噴水と、本の 看板の 家。三千年前の 都の 中に、十二年前の 一夜が あとから 綴じこまれて いた。水晶に 映った 石の 町は、ここだった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        { const g = GAP(); if (g && U.inR(p) && Math.hypot(g.x - p.location.x, g.z - p.location.z) > 24) await K.moveTo(p, { x: g.x + 0.5, z: g.z + 0.5 }, "区と 区の すきま"); }
        await K.open(p, "常世 ― 区と 区の すきま", "ash");
        const t = await town(p, K), fo = facMark("u12town", "fount", p.location) || t, sg = facMark("u12town", "sign", p.location) || t;
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        act(mu, "hold"); await U.tap(p, mu);
        /*F40 回: 水晶の 幻の 石の 町 ＝ 十二年前の 夜読みの 町。「ここだけ、音が 若え」*/
        await U.M(p, mu, ["{shock,?}……待て。", "{closed}……ここだけ、音が 若え。"], "hold");
        await U.M(p, mu, ["{closed}街は どこ 叩いても 三千年の 音なのに、この 一角は……十年と ちょっとだ。"]);
        if (fo) await K.at(p, fo, 16, 5, 0.6);
        await U.narr(p, ["§7灰が 降って いた。§f小さな 噴水と、§e本の 看板の 家§f。§8……ここだけ、建物の 形が 違う。今の 世の 町の 形だ。"], sg);
        await U.E(p, mu, ["……あとから 綴じこまれた 頁だ。灰の 冬の 夜の"]);
        await U.M(p, mu, ["{?}……灰の 冬？"], "hold", p);
        await K.up(p, so, 8);
        await U.H(p, V(["{sad}……十二年前の 冬。灰が 降った 夜。……わたしたちが 四歳の"], ["{sad}……十二年前の 冬よ。灰が 降った 夜。……わたしたちが 四歳の"], ["{sad}……十二年前の 冬。灰の 夜。わたしたちは 四歳"], ["{sad}……十二年前の 冬です。灰が 降った 夜。……わたしたちが 四歳の"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……十二年か。叩いた 音と 合う。"], "hold", so);
        await U.H(p, V(["{shock,…}……この 町、見た ことが ある。クリスタリアの 水晶の 中に 映ってた 町だ"], ["{shock,…}……この 町、見た ことが あるわ。水晶の 中に 映って いた 町よ"], ["{shock,…}……この 町。水晶に 映ってた 町"], ["{shock,…}……この 町、見覚えが あります。水晶の 中に 映って いた 町です"]), mu);
        await U.M(p, mu, ["{closed}……未来でも 昔でも ねえ。十二年前の 灰の 夜が、ここに 挟まってる。"], "hold", so);
        await U.H(p, V(["{sad,…}……水晶の 町には、石の 人が いっぱい いた。……ここに、いるのかな"], ["{sad,…}……水晶の 町には、石の 人が たくさん いたわ。……ここに、いるのかしら"], ["{sad,…}……水晶の 町には 石の 人が いた。ここに いる？"], ["{sad,…}……水晶の 町には、石の 方が 大勢 いました。……ここに、いらっしゃるのでしょうか"]), mu);
        await U.E(p, mu, ["……灰の 夜に 止まった 者らだ。奥で 確かめよ"]);
        await U.M(p, mu, ["{closed}……噴水の ほうだ。紙を めくる 音が、途中で 止まってる。……行くぞ。"], "point", p);
        await U.H(p, V(["{closed}……うん。行こう"], ["{closed}……ええ。行きましょう"], ["{closed}……行く"], ["{closed}……はい。参りましょう"]), mu);
        await U.end(p, C, { card: "§7→ 噴水の 広場へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u12e2", t: "夜読みの 広場", free: false,
    syn: "広場では、物語を 読み聞かせる 人たちが、本を 開いた まま 石に なって いた。冬の 夜の 行事、夜読みの 途中だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 夜読みの 広場", "ash", "night");
        const t = await town(p, K), fo = facMark("u12town", "fount", p.location) || t;
        const rd = [C.npc("", PJ("lili5", 8), 5, -1.6, 0, "veil"), C.npc("", PJ("milfy", 8), 5.4, 0.2, 0, "veil"), C.npc("", PJ("m6_pip", 8), 4.4, 1.8, 0, "veil")];
        act(rd[0], "show"); hold(rd[0], "notebook"); act(rd[1], "show"); hold(rd[1], "notebook"); act(rd[2], "kneel");
        if (fo) await K.at(p, fo, 14, 6, 0.8);
        for (const x of rd.slice(0, 2)) if (ok(x)) await K.up(p, x, 12);
        await U.narr(p, ["§7噴水の まわりで、大人たちが 本を 開いた まま 石に なって いた。§8ひざを 抱えて 聞く 子どもの 石も。"], rd[2]);
        await U.narr(p, ["§8……頁を めくる 音は、どこからも しない。物語の 途中で 止まった 顔だった。"], rd[0]);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        await U.H(p, V(["{sad,…}……開いた 本の 表紙に、『夜読み』って ある。", "{sad}冬の 長い 夜に、町の みんなで 物語を 読む 行事……なんだって"], ["{sad,…}……開いた 本の 表紙に、『夜読み』と あるわ。", "{sad}冬の 長い 夜に、町の みんなで 物語を 読む 行事……なのね"], ["{sad,…}……本の 表紙。『夜読み』。", "{sad}冬の 夜に、町の みんなで 物語を 読む、らしい"], ["{sad,…}……開いた 本の 表紙に、『夜読み』と あります。", "{sad}冬の 長い 夜に、町の みんなで 物語を 読む 行事……のようです"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{?}……みんなで 物語を 読む？ 字の 読めねえ 奴は、どうすんだ。"], "hold", so);
        await K.up(p, so, 8);
        await U.H(p, V(["{smile}……だから 声に 出して 読むんだよ。読めない 子も、聞けば わかる"], ["{smile}……だから 声に 出して 読むのよ。読めない 子も、聞けば わかるもの"], ["{smile}……だから 声に 出す。読めない 子も、聞けば わかる"], ["{smile}……ですから、声に 出して 読むのです。読めない 子も、聞けば わかります"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……いい 町だな。俺みてえな のにも、物語が 届く。"], "hold", so);
        await U.tap(p, mu);
        await U.M(p, mu, ["{closed}……本を 開いた まま だ。続きを 読む 声が、十二年 止まってる。"], "hold");
        await U.H(p, V(["{sad}……十二年。わたしたちが 四歳の ときから、ずっと"], ["{sad}……十二年。わたしたちが 四歳の ときから、ずっとね"], ["{sad}……十二年。四歳の ときから"], ["{sad}……十二年。わたしたちが 四歳の ときから、ずっと"]), mu);
        await U.E(p, mu, ["……読む 声の まま 止まった 者は、続きを 読まれれば 起きるやも しれぬ"]);
        await U.H(p, V(["{?}……じゃあ 今、続きを 読んだら？"], ["{?}……では 今、続きを 読んだら？"], ["{?}……今 読めば？"], ["{?}……では 今、続きを 読みましたら？"]), mu);
        await U.E(p, mu, ["……この 頁が 綴じられて いる 間は、届かぬ。ほどける 日まで、待て"]);
        await U.M(p, mu, ["{closed}……あとで 読みに 来ような。……奥に、本の 看板の 家が ある。"], "point", p);
        await U.H(p, V(["{smile}……うん。約束"], ["{smile}……ええ。約束ね"], ["{smile}……約束"], ["{smile}……はい。お約束です"]), mu);
        await U.end(p, C, { card: "§7→ 本の 看板の 家へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u12e3", t: "二冊目の 絵本", free: false, F: ["F06"],
    syn: "本の 看板の 家に、石に なった セオの 母が いた。手に 二冊目の 絵本。子ども部屋の 机に、竜の 絵の 原画。ピピが 持って いた 絵本と 同じ 竜だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 本の 看板の 家", "ash", "night");
        const t = await town(p, K), dr = facMark("u12town", "door", p.location) || t, desk = facMark("u12town", "desk", p.location) || t;
        if (dr) await K.at(p, dr, 14, 5, 1.5);
        const mo = C.npc("", PJ("rosa", 8), 4.4, 0.6, 0, "veil"); act(mo, "show"); hold(mo, "notebook");
        if (ok(mo)) await K.push(p, mo, 22, 4, 1.7, 1.2);
        await U.narr(p, ["§7戸口の 内側に、女の 人が 石に なって いた。§8胸に、二冊目の 絵本を 抱いて。"], mo);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, so, 8);
        await U.H(p, V(["{sad,…}……この 人、セオさんの お母さんだ。目が、そっくり"], ["{sad,…}……この 方、セオさんの お母さまよ。目が、そっくり"], ["{sad,…}……セオの 母親。目が 同じ"], ["{sad,…}……この 方、セオさんの お母さまです。目が、そっくりで"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……顔は 俺には わからねえ。……けど、本の 抱え方が 丁寧だ。", "{?}……誰に 読む つもり だったんだろな。"], "hold", so);
        await K.up(p, so, 8);
        await U.H(p, V(["{closed}……表紙に『二』って ある。二冊目の 絵本だ"], ["{closed}……表紙に『二』と あるわ。二冊目の 絵本ね"], ["{closed}……表紙に『二』。二冊目"], ["{closed}……表紙に『二』と あります。二冊目の 絵本です"]), mu);
        /*F06 回: 竜の 絵の 原画（絵本の 竜）*/
        if (desk) await K.at(p, desk, 14, 2.4, 0.6);
        await U.narr(p, ["§7子ども部屋の 机に、竜の 絵が 一枚。§f……クレヨンの 竜。ピピが 大事に して いた 絵本の 竜と、同じ 顔だった。"]);
        await U.H(p, V(["{shock,!}……これ、絵本の 竜の 元の 絵だ。下に 名前……『ノエ』"], ["{shock,!}……これ、絵本の 竜の 元の 絵よ。下に 名前……『ノエ』"], ["{shock,!}……絵本の 竜の 元の 絵。名前……『ノエ』"], ["{shock,!}……これ、絵本の 竜の 元の 絵です。下に お名前……『ノエ』"]));
        await U.M(p, mu, ["{closed}……弟が 描いた 竜を、兄貴が 本に したのか。"], "hold", so);
        await U.H(p, V(["{sad}……セオさん、この 絵を ずっと 覚えてたんだ。忘れられない 人だから"], ["{sad}……セオさん、この 絵を ずっと 覚えて いたのね。忘れられない 人だから"], ["{sad}……セオは この 絵を 覚えてた。忘れられない から"], ["{sad}……セオさんは、この 絵を ずっと 覚えて いらしたのですね。忘れられない 方だから"]), mu);
        await U.E(p, mu, ["……忘れられぬ 頭は、重い。……だが 弟の 竜は、それで 本に なった"]);
        await U.M(p, mu, ["{?}……母ちゃんの ほうは、帰ったら 起きるのか。"], "hold", p);
        await U.E(p, mu, ["……頁が ほどけ、名を 呼ぶ 者が いれば"]);
        await U.M(p, mu, ["{closed}……なら、呼ぶのは あいつだな。……戸口の 柱も、見て いいか。"], "hold", p);
        await U.H(p, V(["{closed}……うん。柱、見に 行こう"], ["{closed}……ええ。柱を 見に 行きましょう"], ["{closed}……柱を 見る"], ["{closed}……はい。柱を 見に 参りましょう"]), mu);
        await U.end(p, C, { card: "§7→ 戸口の 柱" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u12e4", t: "背比べの 柱", free: false,
    syn: "戸口の 柱に、兄弟の 背比べの 刻み。ノエの 刻みは、十二年前で 止まって いた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 本の 看板の 家の 戸口", "ash", "night");
        const t = await town(p, K), po = facMark("u12town", "post", p.location) || t;
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none");
        if (ok(mu) && po) await K.walkCam(p, mu, po, 16);
        if (po) await K.push(p, po, 18, 3, 1.3, 0.2);
        await U.narr(p, ["§7戸口の 柱に、小さな 刻みが 二列 並んで いた。"], po);
        await U.H(p, V(["{closed}……読むね。左が『セオ』、右が『ノエ』", "{sad,…}……ノエの 列、ここで 止まってる。十二年前の 冬"], ["{closed}……読むわね。左が『セオ』、右が『ノエ』", "{sad,…}……ノエの 列、ここで 止まって いるわ"], ["{closed}……左が『セオ』、右が『ノエ』", "{sad,…}……ノエの 列は、ここで 止まってる"], ["{closed}……お読みします。左が『セオ』、右が『ノエ』", "{sad,…}……ノエさんの 列は、ここで 止まって います"]), mu);
        await U.H(p, V(["{closed}……あれ。セオさんの 列も、同じ 夜で 止まってる"], ["{closed}……あら。セオさんの 列も、同じ 夜で 止まって いるわ"], ["{closed}……セオの 列も、同じ 夜で 止まってる"], ["{closed}……あの。セオさんの 列も、同じ 夜で 止まって います"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……兄貴の ほうは 町の 外で 生き残って、背が 伸びた。……柱だけ、置いてかれたんだ。"], "hold", so);
        act(mu, "kneel"); await U.narr(p, ["§7ムサシは 柱に 手のひらを 当てた。叩かなかった。"], mu);
        await U.M(p, mu, ["{closed}……うちの 工房の 柱と 同じだ。毎朝 一本ずつ 刻んでた。", "{sad}……刻む 手が 止まった 柱は、こういう 音を してる。"], "kneel");
        await K.up(p, so, 8);
        await U.H(p, V(["{?}……どんな 音？"], ["{?}……どんな 音なの？"], ["{?}……どんな 音？"], ["{?}……どんな 音、ですか？"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed,low}……戸を 叩いても、誰も 出て こねえ 音だ。"], "kneel", so);
        await U.M(p, mu, ["{closed}……うちのは 止まらなかった。親父が 死んでも、兄貴が 叩いてる。"], "kneel", so);
        await U.E(p, mu, ["……止まらぬ 柱も、止まった 柱も。どちらも 待って いる 印だ"]);
        await U.H(p, V(["{sad}……ノエくんの 列も、いつか また 刻めると いいね"], ["{sad}……ノエくんの 列も、いつか また 刻めると いいわね"], ["{sad}……ノエの 列も、また 刻めると いい"], ["{sad}……ノエさんの 列も、いつか また 刻めると いいですね"]), mu);
        await U.M(p, mu, ["{?}……町の 外れで、何か 光った。……見に 行くか。"], "up", p);
        await U.end(p, C, { card: "§7→ 町の 外れ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u12e5", t: "冬ほたる", free: false, F: ["F65"],
    syn: "町の 外れの 森の 向こうに、冬ほたるの 光が 見えた。ルミエの 方角。十二年前、兄弟が 夜読みを 抜け出して 見に 行った 光だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 夜読みの 町の 外れ", "night", "night");
        const t = await town(p, K), ed = facMark("u12town", "edge", p.location) || t;
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none");
        const far = { x: p.location.x + 14, y: p.location.y + 3, z: p.location.z + 10 };
        for (let k = 0; k < 14; k++) try { p.dimension.spawnParticle("minecraft:endrod", { x: far.x + Math.cos(k) * 4, y: far.y + (k % 4) * 0.6, z: far.z + Math.sin(k) * 4 }); } catch {}
        /*F65 回: 夜読みの 町から 見える 冬ほたる */
        await K.at(p, far, 22, 10, 0);
        await U.narr(p, ["§7町の 外れ。灰の 向こうの 森の 上に、§b小さな 光§7 が 浮かんで いた。"]);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{?}……なんだ、あの 光。音が しねえ。"], "up", p);
        await K.up(p, so, 8);
        await U.H(p, V(["{sad,…}……冬ほたる。初雪の 夜に だけ 光る ほたる。……ルミエの 方だ", "{sad}セオさんと 弟さん、夜読みを 抜け出して、あれを 見に 行ったんだね"], ["{sad,…}……冬ほたる。初雪の 夜に だけ 光るの。……ルミエの 方角ね", "{sad}セオさんと 弟さん、夜読みを 抜け出して、あれを 見に 行ったのね"], ["{sad,…}……冬ほたる。初雪の 夜だけ 光る。ルミエの 方", "{sad}セオと 弟は、あれを 見に 行った"], ["{sad,…}……冬ほたる、です。初雪の 夜に だけ 光る。……ルミエの 方角です", "{sad}セオさんと 弟さんは、夜読みを 抜け出して、あれを 見に 行ったのですね"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{?}……抜け出して？ 町の 行事を か。"], "up", so);
        await K.up(p, so, 8);
        await U.H(p, V(["{sad}……前に セオさんが 話して くれた。弟さんは『ずっと 見て いたい』って 言って……"], ["{sad}……前に セオさんが 話して くれたの。弟さんは『ずっと 見て いたい』と 言って……"], ["{sad}……セオが 話してた。弟は『ずっと 見て いたい』と 言って……"], ["{sad}……以前、セオさんが 話して くださいました。弟さんは『ずっと 見て いたい』と おっしゃって……"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……それで、石に なったのか。"], "hold", so);
        await U.E(p, mu, ["……『ずっと』は 願いだ。願いは、石に なる"]);
        await K.up(p, so, 8);
        await U.H(p, V(["{sad,…}……セオさんは『帰ろう』って 言ってた。だから 石に ならなかった"], ["{sad,…}……セオさんは『帰ろう』と 言って いたの。だから 石に ならなかった"], ["{sad,…}……セオは『帰ろう』と 言った。だから 石に ならなかった"], ["{sad,…}……セオさんは『帰ろう』と 言って いた。だから、石に ならなかったのです"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed,low}……帰ろう、か。……言った ほうが 残るのも、きついな。"], "hold", so);
        await U.M(p, mu, ["{closed}……灰の 中でも、あの 光だけは 音が しねえのに 届く。", "{closed}……見に 行きたく なる 光だ。"], "up");
        K.sound(p, "ambient.weather.thunder", 0.3, 0.6);
        await U.M(p, mu, ["{shock,!}……今の、雷か。……次の 区は あっちだ。"], "point", p);
        await U.H(p, V(["{closed}……うん。行こう、ムサシ"], ["{closed}……ええ。行きましょう、ムサシ"], ["{closed}……行こう、ムサシ"], ["{closed}……はい。参りましょう、ムサシさん"]), mu);
        await U.end(p, C, { card: "§7→ 四冠の §e雷鳴の 区§7 へ（右上の 案内）" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u12e6", t: "空の 目", free: false,
    syn: "雷鳴の 区の 空に、大きな 目が ひらいて いた。門の 前で、兵士 ガイが 剣を 抜いた まま 石に なって いた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 雷鳴の 区");
        const g = K.fac(p, "u12gate", "u12gate", 99, U.y0(p)), gq = facMark("u12gate", "gate", p.location) || g;
        const sky = { x: p.location.x + 6, y: p.location.y + 18, z: p.location.z + 12 };
        for (let k = 0; k < 14; k++) { const a = (k / 14) * Math.PI * 2; try { p.dimension.spawnParticle("minecraft:endrod", { x: sky.x + Math.cos(a) * 5, y: sky.y + Math.sin(a) * 2, z: sky.z }); } catch {} }
        K.sound(p, "ambient.weather.thunder", 0.8, 0.4); await K.at(p, sky, 20, 12, 0);
        await U.narr(p, ["§7空に、大きな §e目§7 が ひらいて いた。§8……どこへ 歩いても、こちらを 見て いる。"]);
        const mu = U.mu(C), so = U.soul(p, C, 2.6, -1.8, "none"); await K.up(p, mu, 8);
        await U.M(p, mu, ["{sweat,汗}……空から 見られてる。……背中が 重てえ。"], "guard", p);
        await U.H(p, V(["{shock,…}……門の 前に、誰か 立ってる"], ["{shock,…}……門の 前に、誰か 立って いるわ"], ["{shock,…}……門の 前に 誰か いる"], ["{shock,…}……門の 前に、どなたか 立って います"]), mu);
        if (gq) await K.at(p, gq, 14, 5, 1);
        await U.rec(p, C, 6, ["§7『兵士 ガイ。最後まで 門を 守った。剣を 抜いた 形の まま』"], "guy", "guard");
        await U.H(p, V(["{closed}……兵士 ガイ さん。最後まで、門を 守ったって"], ["{closed}……兵士 ガイ さん。最後まで、門を 守ったのね"], ["{closed}……兵士 ガイ。最後まで 門を 守った"], ["{closed}……兵士 ガイ さん。最後まで、門を 守られたそうです"]), mu);
        await K.up(p, mu, 8);
        await U.tap(p, mu);
        await U.M(p, mu, ["{closed}……三千年、刃を 抜いた まま。腕の 音が、ずっと 張りっぱなしだ。"], "hold", so);
        await U.E(p, mu, ["……抜いた 刃を、納める 時を 失った 者だ"]);
        await U.M(p, mu, ["{closed}……なら、納めさせて やる。あの 目の 主を 倒してな。"], "guard", p);
        await K.up(p, so, 8);
        await U.H(p, V(["{closed}……うん。ガイさん、もう 休ませて あげよう"], ["{closed}……ええ。ガイさん、もう 休ませて あげましょう"], ["{closed}……ガイを 休ませる"], ["{closed}……はい。ガイさんを、もう 休ませて さしあげましょう"]), mu);
        await U.lesson(p, C, 6, mu);
        await U.end(p, C, { card: "§7→ 空の 目が、降りて くる" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u12e7", t: "見続ける 者", free: false, run: fight6, syn: "四冠ガムラとの 戦い。勝つと、兵士ガイの 石が 剣を 鞘に 納めて 消えた。ムサシは 鍔の わけを 聞いた。" },
  { id: "u12e8", t: "書けるのに 呼べない", free: false, F: ["F20"],
    syn: "野営地の 夜。ムサシ「こいつが 言ってた。名前を 書けるのに 呼べねえ やつが いる、って」。幼なじみの 魂「……セオさん」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await U.toCamp(p);
        await K.open(p, "常世 ― 野営地の 夜", "night", "night");
        const mu = U.mu(C, 2.6, 1.4), so = U.soul(p, C, 3, -1.4, "none"); act(mu, "kneel"); act(so, "kneel");
        K.sound(p, "fire.fire", 0.6); await K.up(p, mu, 10);
        await U.narr(p, ["§7たき火の 前で、ムサシが 腰の 鍔を 膝に のせて いた。§8指で、鍔の 縁を ゆっくり なぞって いる。"], mu);
        await K.two(p, mu, so, 14);
        /*F20 強: 書けるのに 声に 出せない 名前 */
        await U.M(p, mu, ["{closed}……こいつが 言ってた。名前を 書けるのに、呼べねえ やつが いる、って。", "{closed}俺と 逆だ。俺は 呼べるけど、書けねえ。"], "kneel");
        await K.up(p, so, 10);
        await U.H(p, V(["{sad,…}……セオさん。", "{sad}弟さんの 名前、手帳には 何百回も 書いてるのに、声に 出せないんだって"], ["{sad,…}……セオさん、ね。", "{sad}弟さんの 名前、手帳には 何百回も 書いて いるのに、声に 出せないの"], ["{sad,…}……セオ。", "{sad}弟の 名前を、書けるのに 呼べない"], ["{sad,…}……セオさん、です。", "{sad}弟さんの お名前、手帳には 何百回も 書かれて いるのに、声に 出せないのだと"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{?}……セオってのは、お前らの 何だ。"], "kneel", so);
        await K.up(p, so, 8);
        await U.H(p, V(["{closed}……ずっと 旅を 助けて くれた 学者さん。……でも、六影の 人 だった"], ["{closed}……ずっと 旅を 助けて くれた 学者さん。……でも、六影の 人 だったの"], ["{closed}……旅を 助けて くれた 学者。……六影の 人 だった"], ["{closed}……ずっと 旅を 助けて くださった 学者さんです。……でも、六影の 方 でした"]), mu);
        await U.H(p, V(["{smile,…}……それでも、わたしは 友だちだと 思ってる"], ["{smile,…}……それでも、わたしは 友だちだと 思って いるわ"], ["{smile,…}……それでも 友だち"], ["{smile,…}……それでも、わたしは お友だちだと 思って います"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{?}……そいつは 今、どこに いる。"], "kneel", so);
        await U.E(p, mu, ["……わからぬ。だが 紫の 字を 書く 手が、塔の どこかに ある"]);
        await U.H(p, V(["{closed}……迎えに 行こう。セオさんも"], ["{closed}……迎えに 行きましょう。セオさんも"], ["{closed}……迎えに 行く。セオも"], ["{closed}……お迎えに 参りましょう。セオさんも"]));
        await U.M(p, mu, ["{closed}……ああ。呼ぶ 口が 三つ ありゃ、足りる。"], "kneel", so);
        await U.E(p, mu, ["……塔へ 行くには、次の 区を 越えねば ならぬ。……音の ない 区だ"]);
        await U.M(p, mu, ["{sweat,汗}……音の ない 区、か。……一つ、二つ、三つ。……嫌な 名前だ。"], "kneel", p);
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 三冠の §e音の ない 区§7 へ（右上の 案内）", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(6, ["u12e6", "u12e7"], ["u12e8"]);
