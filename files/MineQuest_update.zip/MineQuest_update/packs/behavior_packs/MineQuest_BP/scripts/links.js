/* 第125版: すべてが つながる（旅の とちゅうの 小さな 印を、終章・エンディング・クリア後で 回収する）
   ・王たちの 兵（終章: 王冠の 石板が 開く とき。saga.js の cupScene「zeph1」から EP_HOOK.kingsMarch）
   ・それぞれの 町（エンディングの あと: 双子と シロウ・トンボと ヴァルカ。saga.js の 終章の 段から EP_HOOK.endLinks）
   ・おっとうの 編み目（クリア後: コラリアで マリンに 話しかける）
   ・掟が 解けた（クリア後: 城の 王に 初めて 話しかける。王ごとに 1回。rmaster.js の KING_HOOK）
   場面は 1人ずつ（マルチでも 混ざらない）。印は 終わりの 直前に 立てる（とちゅうで 抜けたら もう一度 見られる）*/
import { system, world } from "@minecraft/server";
import { facAt, facFront } from "./epfac.js";
import { CAST } from "./cast.js";
import { K } from "./sagaep.js";
import { EP_HOOK, SGK } from "./saga.js";
import { load } from "./store.js";
import { qs } from "./quest.js";
import { ok, busy } from "./ui.js";
import { stageBegin, freeNear } from "./stagecore.js";
import { camAt, cineCard, fading } from "./talk.js";
import { NPC_HOOKS } from "./npchook.js";
import { KNAME, KSKIN, KING_HOOK } from "./rmaster.js";
import { WREGIONS } from "./worldmap.js";

const ex = (p) => { try { return qs(load(p) || {}).epx || {}; } catch { return {}; } };
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };
const turnTo = (e, q) => { if (K.turn) return K.turn(e, q); if (!ok(e) || !q) return; try { e.teleport(e.location, { facingLocation: { x: q.x, y: e.location.y + 1.5, z: q.z } }); e.setDynamicProperty("mrpg:away", true); } catch {} };   /* K.turn が まだ ない ときの 代わり */
const REC = (k) => { try { return JSON.parse(world.getDynamicProperty(k) || "null"); } catch { return null; } };
async function goSet(p, q, look, nm) { if (!q || !look) return false; const r = await K.moveTo(p, q, nm, [], look, 12); await K.wait(14); return !!r; }   /* 第125版(tp): 遠い 町へ 移る（読みこむ 間を 待つ）*/
const dark = async (p, c = "0 0 0") => { K.cmd(p, `camera @s fade time 0.15 0.25 0.3 color ${c}`); await K.wait(4); };   /* 第124版(fix2): 短い 暗転（暗い 間に 入れかえる）*/
/* ゆっくり 寄る（遠く 上 → 近く）*/
async function push(p, e, t = 14) {
  if (!ok(e)) return; const l = e.location, P = p.location, dx = P.x - l.x, dz = P.z - l.z, n = Math.hypot(dx, dz) || 1, u = { x: dx / n, z: dz / n }, look = { x: l.x, y: l.y + 1.4, z: l.z };
  camAt(p, { x: l.x + u.x * 5.5 + u.z * 1.5, y: l.y + 3.2, z: l.z + u.z * 5.5 - u.x * 1.5 }, look, fading(p) ? 0 : 0.8); await K.wait(3);   /* 第124版(fix2): 暗転の 外では なめらかに（大きく かわる ときは カット）*/
  camAt(p, { x: l.x + u.x * 2.4 + u.z * 0.5, y: l.y + 1.8, z: l.z + u.z * 2.4 - u.x * 0.5 }, look, 1.6); await K.wait(t);
}

/* ---------- 場面を 1人ぶん 走らせる（sagaep.js の start と 同じ 片づけ）---------- */
export function play(p, sc, at) {
  if (SGK.EVT.has(p.id) || busy.has(p.id)) return false;
  SGK.runEvt(p, async () => {
    await stageBegin(p, { anchor: at || p.location, move: true, noEst: true });
    SGK.MQASK.add(p.id); SGK.MQRUN.add(p.id); SGK.MQSTALE.delete(p.id); const tok = {}; SGK.MQTOK.set(p.id, tok);
    try { await sc.run(p, load(p), K); } catch (x) { if (x !== SGK.LATER) console.warn(`[MonsterRPG] link ${sc.id}: ${x} ${x?.stack || ""}`); }
    finally { if (SGK.MQTOK.get(p.id) === tok) { SGK.MQTOK.delete(p.id); SGK.MQASK.delete(p.id); SGK.MQRUN.delete(p.id); } SGK.heroTmpClean(p); SGK.SPAWNED.delete(p.id); }
  });
  return true;
}

/* ---------- 終章: 王冠の 石板が 開き、11の 城の 王が 兵を 出す ---------- */
const KL = [
  ["{angry,up}……掟の 時が 来た。『王冠の 扉が 開く 日、兵を 出して 町を 守れ』。千年、意味も 知らずに 守って きた 掟だ。兵を 出せ！", "{sad}……二十年前、父が 追い返した 男の 言葉が、今 わかる。"],
  "{closed,up}掟の 時が 来ました。森の 道を、守りなさい。",
  "{angry,up}主に 代わって 申し上げます。掟の 時が 来ました。門を 固めなさい。",
  "{angry,up}掟の 時だ！ 炉の 火を 落とすな、槌を 持て！",
  ["{closed,up}……掟の 時が 来た。砂の 兵よ、町へ 走れ。", "{sad}……二十年前、わしが 追い返した 男の 言葉が、今 わかる。"],
  "{smile,up}掟の 時が 来ましたね。……美しく、守りなさい。",
  "{angry,up}掟の 時が 来た！ 船を 出せ、港を 守れ！",
  "{closed,up}……掟の 時が 来たぞ。死者の 町に、影を 入れるな。",
  "{angry,up}掟の 時だ！ 雪の 道と 雷の 道、二手に 分かれよ！",
  "{closed,up}掟の 時が 来た。竜の 背に 乗り、空を 守れ。",
  "{closed,up}掟の 時が 来た。……風よ、兵を 運べ。",
];
const kingNm = (i) => KNAME[i] || `${(WREGIONS[i] && WREGIONS[i].castle && WREGIONS[i].castle.name) || "天空城"}の 王`;
const kingJob = (i) => (KSKIN[i] ? K.PJ(KSKIN[i], 15) : 15);
export async function kingsMarch(p) {
  if (ex(p).kingsM) return false;
  K.big(p, "§6§l掟の 時", "§f王冠の 石板が 開いた その とき、世界中の 城で", "raid.horn");
  let prev = [];
  const putAt = (nm, job, q) => { const e = K.npcNear(p, nm, job, true); if (ok(e) && q) try { const S = K.S(p), t = S ? freeNear(S, q, e, 1.4) || q : q; e.teleport(t, { facingLocation: p.getHeadLocation() }); if (S) { S.mem.set(nm, { ...t }); S.dest.set(e.id, { ...t }); } } catch {} return e; };   /* 第124版(cam): 暗転の 中で その 城に 立たせる（歩かせない・飛ばさない）*/
  for (let i = 0; i < KL.length; i++) {
    await dark(p); for (const e of prev) K.rm(e); prev = [];   /* 第124版(cam): 前の 王と 兵は 暗転の 中で 下げる */
    if (!ok(p)) return false;
    const sd = i % 2 ? 2.4 : -2.4, eK = putAt(`§6${kingNm(i)}`, kingJob(i), K.fwd(p, 6, sd));
    const g1 = putAt("§7城の 兵", K.PJ("glen", 16), K.fwd(p, 8, sd - 1.6)), g2 = putAt("§7城の 兵§r", K.PJ("glen", 16), K.fwd(p, 8, sd + 1.6));
    K.act(eK, i % 3 ? "raise" : "point"); K.act(g1, "guard"); K.act(g2, "guard");
    const rows = [];   /* 第124版(fix2): 3人に 1人の 王は 兵を 2列 4人に して、兵の 背中ごしに 王を 見上げる 引きの 絵 */
    if (i % 3 === 2) for (const [k, s] of [[3.2, -2.4], [3.2, -0.8], [3.2, 0.8], [3.2, 2.4], [2, -2.4], [2, 2.4]]) { const g = putAt(`§7城の 兵${"§r".repeat(rows.length + 2)}`, K.PJ("glen", 16), K.fwd(p, k, sd + s)); if (ok(g)) { K.act(g, "guard"); try { g.teleport(g.location, { facingLocation: eK.location }); } catch {} rows.push(g); } }
    cineCard(p, `§f― ${(WREGIONS[i] && WREGIONS[i].castle && WREGIONS[i].castle.name) || "天空城"} ―`, 40);
    if (rows.length && ok(eK)) { const a = K.fwd(p, 0.6, sd, 1.4), l = eK.location; if (a) camAt(p, a, { x: l.x, y: l.y + 2.2, z: l.z }, 0); await K.wait(20); }
    await push(p, eK, 8);
    await K.say(p, kingNm(i), [].concat(KL[i]));
    prev = [eK, g1, g2, ...rows];
    if (i === 0 || i === 5) { const q = K.fwd(p, 8, sd, 1); if (q) { camAt(p, { x: q.x - 2, y: q.y + 7, z: q.z }, q, 0.8); K.burst(p.dimension, q, "minecraft:totem_particle", 10, 3, 0.5); await K.wait(16); } }   /* 第124版(fix2): 合間の 絵は 王と 兵を 上から（だれも いない 絵・2回の 暗転を やめる）*/
  }
  await dark(p); for (const e of prev) K.rm(e);
  const gate = []; for (const s of [-4, -2, 0, 2, 4]) { const g = putAt(`§7門の 兵${"§r".repeat(gate.length + 1)}`, K.PJ("glen", 16), K.fwd(p, 7, s)); if (ok(g)) { K.act(g, "guard"); gate.push(g); } }   /* 第124版(fix2): 最後は 門で 兵が 横に 並ぶ 引きの 絵 */
  try { await K.shadowFlow(p, K.fwd(p, 14, 0), K.fwd(p, 8, 0), 12); } catch {}   /* 第125版(F8): 門へ 寄せる 影の 兵を 見せる */
  await K.narr(p, ["§7王たちは 理由を 知らない。ただ 千年 守った 二つ目の 掟だけを 信じて、兵を 出した。", "§7世界中の 町の 門で、槍を そろえた 兵が、影の 兵を 押し返して いく。"]);
  await K.bye(p, ...gate);
  K.setFlag(p, "kingsM");
  return true;
}

/* ---------- エンディングの あと: それぞれの 町 ---------- */
const ENDM = { id: "cn_endm", t: "それぞれの 町", pre: { ending: true, heroDead: 1, epx: { thunder8: 1 } },
  async run(p, d, K) {
    await K.open(p, "それぞれの 町", "day");
    await K.narr(p, ["§7王冠の 石板が 静まって、いく日か たった。", "§7世界の あちこちで、待って いた 人の もとへ 帰る 人が いた。"]);
    const S0 = K.S(p), HOME = S0 ? { x: S0.P.x, y: S0.P.y, z: S0.P.z } : null; let moved = false;   /* 第125版(tp): 札の 町へ 本当に 移る（やぐら・鍛冶場が ある ときだけ。終わったら もどる）*/
    /* サンダ: 双子と シロウ */
    { const A = REC("mrpg:epdeco:r8yaguraat"), c = A && CAST.r8_shirou && CAST.r8_shirou.at ? CAST.r8_shirou.at() : null, q = A ? (c ? { x: c.x - 3, y: A.y - 3, z: c.z - 2 } : { x: A.x + 7, y: A.y - 3, z: A.z }) : null;
      if (q) moved = (await goSet(p, q, A, "らいうんの 里 サンダ")) || moved; else await dark(p); }
    cineCard(p, "§f― らいうんの 里 サンダ 雷祭りの やぐら ―", 60);
    const eS = K.cast(p, "r8_shirou"); K.act(eS, "hold"); K.hold(eS, "glove");
    await K.pull(p, K.S(p) && K.S(p).Cn, 34);
    await K.csay(p, "r8_shirou", ["{smile,…,up}……雪道の 向こうから、二つの 足音が するべさ。"]);
    const eRo = K.cast(p, "r8_rou"), eRu = K.cast(p, "r8_ruu"); K.act(eRo, "hold"); K.act(eRu, "hold");
    await K.two(p, eRo, eRu, 12);
    await K.csay(p, "r8_rou", ["{smile,up}……ただいま、兄ちゃん。"], eS);
    await K.csay(p, "r8_ruu", ["{smile,tears,up}……ずっと、さみしかったんだもん。"], eS);
    await Promise.all([eRo, eRu].map((e, i) => { const q = nearPt(e, eS, 1); return q ? K.go(e, { x: q.x + (i ? 0.5 : -0.5), y: q.y, z: q.z }, 12) : null; }));
    for (const e of [eS, eRo, eRu]) K.act(e, 23);
    await K.two(p, eS, eRo, 12);
    await K.csay(p, "r8_shirou", ["{cry,smile,tears,up}……おかえり だべさ！ 手袋の もう 片っぽ、編んで 待ってたべさ！"]);
    await K.give(eS, eRu, "glove");
    await K.csay(p, "r8_shirou", ["{smile,tears,up}……名前、本人の 口から 聞かせて ほしいべさ。手袋に 縫いとって やるべさ。"], eRo);
    await K.csay(p, "r8_rou", ["{closed,up}……ロウ、だよ。白い ほうの 手。"], eS);
    await K.csay(p, "r8_ruu", ["{angry,tears,up}……ルウ、だもん。名前が 二つでも、手は はなさないもん。"], eS);
    await K.csay(p, "r8_shirou", ["{cry,smile,up}……ロウと、ルウ。……いい 名前だべさ。二人で 一つじゃ なくて、二人 そろって 二人だべさ。"], eRu);
    for (const e of [eS, eRo, eRu]) K.act(e, "up");
    const sky = K.fwd(p, 6, 0, 8); K.burst(p.dimension, sky, "minecraft:endrod", 10, 3, 0.3);
    await K.at(p, sky, 16, 7, 0);
    await K.narr(p, ["§7三人は 雷祭りの やぐらに ならんで、雪雲の 割れた 空を 見上げた。"], sky);
    for (const e of [eS, eRo, eRu]) K.act(e, 0);
    await K.bye(p, eS, eRo, eRu);
    /* ラヴィ: トンボと ヴァルカ */
    { const SM = facAt("r3smithy"), SF = SM && facFront("r3smithy", 5); if (SF) moved = (await goSet(p, SF, SM, "ようがんの 里 ラヴィ")) || moved; else await dark(p); }
    cineCard(p, "§f― ようがんの 里 ラヴィ 鍛冶場 ―", 60);
    const eT = K.cast(p, "r3tombo"), eG = K.cast(p, "r3gen"); K.act(eT, "hold"); K.hold(eT, "hammer");
    await K.pull(p, K.S(p) && K.S(p).Cn, 34);
    await K.csay(p, "r3gen", ["{closed}……客だでい、トンボ。"], eT);
    const eV = K.npcNear(p, "§cヴァルカ", K.PJ("valka", 10)); K.act(eV, "hold"); K.hold(eV, "katana");
    await K.low(p, eV, 14);
    await K.say(p, "ヴァルカ", ["{closed,up}……トンボ。約束の ものを 持って きた。", "{sad}この 刀は、アタシの 親父の 最後の 一本だ。結びは、アタシが 打った。"]);
    await K.push(p, eV, 22, 4.2, 1.7);
    await K.say(p, "ヴァルカ", ["{sad,up}十二年前、親父の 刀が 一つの 村を 焼いた。……アンタの 村だ。", "{closed,low}……ごめん。謝るのは、刀を わたす ときだって 決めてた。"]);
    if (ok(eV) && ok(eT)) { const l = eT.location; await K.go(eV, { x: l.x + 1.2, y: l.y, z: l.z + 0.4 }, 12); }
    await K.two(p, eV, eT, 12);
    K.sound(p, "armor.equip_iron", 1.1, 0.5);
    K.hold(eT); await K.give(eV, eT, "katana");
    await K.narr(p, ["§7トンボは 両手で、刀を 受け取った。"], eT);
    K.re(eT, "shock", "!");
    await K.push(p, eT, 22, 4.2, 1.7);
    await K.csay(p, "r3tombo", ["{shock,…,up}……おれの、村……ッス。"], eV);
    await K.say(p, "ヴァルカ", ["{closed,low}……殴って いい。それだけの ことを、黙って いた。"], eT);
    await K.csay(p, "r3tombo", ["{sad,no}……殴らないッス。鍛冶屋の 手は、殴る ために あるんじゃ ないッス。", "{cry,tears,up}……受け取るッス。打った 人の 心は 刃に 出るって、親方が 言ってたッス。この 刃、まっすぐッス。"]);
    turnTo(eG, K.away(eG, p, 3));
    await K.csay(p, "r3gen", ["{sad,tears}……いい 刃でい。わしは、もう 何も 言う ことが ねえ。"], eT);
    K.act(eT, 0); K.act(eV, 0);
    K.setFlag(p, "endM");
    await K.end(p, { leave: [eV], bye: [eT, eG], card: "§7それぞれの 町で、止まって いた 時間が 動きはじめた", kind: "fest" });
    if (moved && HOME) await K.moveTo(p, HOME, "オルドの 牧場の そば", [], null, 12);
    return true;
  } };
EP_HOOK.endLinks = async (p) => { await ENDM.run(p, load(p), K); };
EP_HOOK.kingsMarch = kingsMarch;

/* ---------- クリア後: おっとうの 編み目（コラリアの マリン）---------- */
const CORD = { id: "cn_cord6", t: "おっとうの 編み目", pre: { ending: true, heroDead: 1, omamori: 1 },
  async run(p, d, K) {
    await K.open(p, "コラリアの 祭りの 浜", "day");
    K.sound(p, "note.harp", 0.5);
    const eM = K.cast(p, "r6marin"); K.act(eM, "raise");
    await K.csay(p, "r6marin", ["{smile,up}……来て くれたんだ。海、やっと 青く もどったよ。"]);
    const eN = K.cast(p, "r6nagisa"); K.act(eN, "hold");
    await K.csay(p, "r6nagisa", ["{smile}……いらっしゃい。今日は、潮が 素直なの。"], eM);
    K.act(eM, 0); K.act(eN, 0);
    await K.narr(p, ["§7あなたは かばんから、ほどきかけの §f紐の お守り§7 を 取り出した。", "§7闘技場の 奥の 王座で、星冠王 ゼファードに 託された もの。……『名も 知らぬ 娘に』。"]);
    K.act(eM, "hold"); K.hold(eM, "rope"); K.re(eM, "shock", "!");
    await K.push(p, eM, 22, 4.2, 1.7);
    await K.csay(p, "r6marin", ["{shock,…,up}……それ、見せて。"]);
    const q = ok(eM) ? { x: eM.location.x, y: eM.location.y + 1, z: eM.location.z } : null;
    await K.at(p, q, 14, 1.6, 0.2);
    await K.narr(p, ["§7マリンは ゴーグルに 結んだ 髪紐を ほどいて、二本を ならべた。", "§7三つ目ごとに 一つ 返す、ふしぎな 編み目。……一目も、ちがわない。"], q);
    await K.push(p, eM, 22, 4.2, 1.7);
    await K.csay(p, "r6marin", ["{shock,tears,up}……おんなじ。かあさんの 形見と、おんなじ 編み方。", "{cry,tears,up}……おっとうの、編み目だ。"]);
    await K.two(p, eN, eM, 12);
    await K.csay(p, "r6nagisa", ["{shock,…,up}……かあさん、言ってた。『この 紐は、おっとうが 編んで くれた』って。", "{cry,tears,up}海の 向こうの 石に、おっとうが いる……ほんとう、だったんだ。"], eM);
    const eZ = K.cast(p, "r6zaza"); K.act(eZ, "hold");
    await K.csay(p, "r6zaza", ["{sad,tears,up}……おっかあは 最後まで、相手の 名を 言わなかったっぺ。……言えば 娘らに 何か 来ると、わかってたんだっぺか。"], eN);
    K.act(eZ, 0);
    if (K.flag(p, "mill10")) {   /* 第124版(dir#31): 風の 塔の 出せなかった 手紙を 娘らへ */
      await K.narr(p, ["§7あなたは 風の 塔で 見つけた、出せなかった §f手紙§7 を ナギサに 渡した。"], eN);
      K.act(eN, "hold"); K.hold(eN, "letter"); await K.up(p, eN, 12);
      await K.csay(p, "r6nagisa", ["{closed,up}……『この 塔からは、おまえたちの 眠る 港の 灯りは 見えない。』", "{cry,tears,up}『それでも 毎晩、同じ 海の 方角を 見て いる』……おっとう。"], eM);
      K.act(eN, 0);
    }
    K.act(eM, "hold");
    await K.up(p, eM, 12);
    await K.csay(p, "r6marin", ["{closed,up}……この 紐、預かって いい？", "{smile,tears,up}姉さんと 二人で、続きを 編む。……編み上がったら、渡しに 行く。おっとうに。"]);
    await K.csay(p, "r6nagisa", ["{smile,tears,up}……うん。この 指でも、一目ずつ なら 編める。約束。"], eM);
    K.act(eM, 0);
    K.setFlag(p, "cord6");
    await K.end(p, { leave: [eZ], bye: [eM, eN], card: "§7マリンと ナギサは、ほどきかけの 紐を 二人で 編みはじめた", kind: "day" });
    return true;
  } };
NPC_HOOKS.unshift((p, e) => {
  try {
    if (!e.hasTag("mrpg_cast") || e.getDynamicProperty("mrpg:cast") !== "r6marin") return false;
    const s = qs(load(p) || {}); if (!s.ending || (s.epx || {}).cord6) return false;
    const at = { ...e.location };
    system.run(() => { play(p, CORD, at); });
    return true;
  } catch { return false; }
});

/* ---------- クリア後: 城の 王「掟が 解けた」（王ごとに 1回）---------- */
const lawScene = (i) => ({ id: `cn_klaw${i}`, t: "掟が 解けた", pre: { ending: true, heroDead: 1 },
  async run(p, d, K) {
    const nm = kingNm(i), cn = (WREGIONS[i] && WREGIONS[i].castle && WREGIONS[i].castle.name) || "城";
    await K.open(p, `${cn}の 王座の 間`, "castle");
    const eK = K.npcNear(p, `§6${nm}`, kingJob(i)); K.act(eK, "hold"); K.hold(eK, "staff");
    await K.low(p, eK, 14);
    await K.say(p, nm, ["{closed,up}……来たか。王冠を 静めた 者よ。"]);
    await K.say(p, nm, ["{closed}この 城は 千年、一つの 掟を 守って きた。", "{closed,up}『王冠が 静まるまで、神の 石板を 開けては ならぬ』。"]);
    const q = K.fwd(p, 6.5, 3.2, 0.6); if (q) { const x = Math.floor(q.x), y = Math.floor(q.y - 0.6), z = Math.floor(q.z); K.cmd(p, `setblock ${x} ${y} ${z} chiseled_stone_bricks keep`); K.cmd(p, `setblock ${x} ${y + 1} ${z} white_carpet keep`); }   /* 第125版(tp): 布を かけた 小さな 台座 */
    K.burst(p.dimension, q, "minecraft:totem_particle", 6, 0.6, 0.4);
    await K.at(p, q, 16, 3, 0.6);
    await K.narr(p, ["§7玉座の 奥に、布を かけた 小さな 台座。", "§7布の すき間から、古い 石板の 光が もれて いる。"], q);
    await K.up(p, eK, 12);
    await K.say(p, nm, ["{sad}なぜ 開けては ならぬのか、わたしは 知らされて おらぬ。……ただ、守った。", "{closed}父も、その 父も。理由を 知らぬ まま、毎朝 布の ほこりを 払って きた。"]);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……石板、もう ないて ない。ねむってる においだけ。"]); K.rmCine(g); }
    K.act(eK, "raise");
    await K.say(p, nm, ["{smile,up}だが 王冠は 静まり、掟は 解けた。……やっと、開けられる。", "{smile}開けるのは、王冠を 静めた 者に。……そう 決めて おった。"]);
    K.act(eK, "guard");
    await K.up(p, eK, 10);
    await K.say(p, nm, ["{angry,up}手合わせ 願おう。勝てば、この 石板を そなたに 託す。"]);
    K.act(eK, 0);
    K.setFlag(p, `klaw${i}`);
    await K.end(p, { leave: [eK], card: "§7→ もう 一度 王に 話しかけると、手合わせが できる" });
    return true;
  } });
KING_HOOK.law = (p, i, d) => {
  try { const s = qs(d); if (!s.ending || (s.epx || {})[`klaw${i}`]) return null; } catch { return null; }
  return async () => { play(p, lawScene(i), p.location); };
};

export const LINKS = [ENDM, CORD, ...[...Array(11).keys()].map(lawScene)];
export const __links = { play, kingsMarch, ENDM, CORD, lawScene, KL };
