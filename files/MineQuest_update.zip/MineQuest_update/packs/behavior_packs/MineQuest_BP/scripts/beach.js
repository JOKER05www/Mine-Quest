// 第106版: 海辺の 人たち。砂浜（砂の 地面と すぐそばの 水）に 近づくと、水着の 人が 出てきて 遊びまわる
// 走る・水しぶき・はねる・ボールの 投げあい・日光浴。たたいた ボールは 近くの 人へ。話しかけると 自由に 話せる
import { world, system } from "@minecraft/server";
import { personName, nearNpcs } from "./names.js";
import { NPC_HOOKS } from "./npchook.js";
import { chatWith } from "./chat.js";
import { PSKIN } from "./skinjobs.js";
import { isLite, busy, barNote } from "./ui.js";
import { load, save } from "./store.js";
import { heroInfo, heroSpawn, inStory } from "./heroswim.js";   /* 第124版: 旅の 仲間も 水着で 遊ぶ */

const OW = () => world.getDimension("minecraft:overworld");
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const WHO = ["coral", "aqua", "sango", "mizuha", "natsume", "rio", "yuzu", "shizuku", "haru", "serika", "marina", "ange", "karen", "emma2", "rin"];   /* 第106版: 水着の 型（上乳・横乳・下乳・はだけた）を 2人ずつ */
const LINE = ["きゃっ、冷たい！", "そっち 行ったよー！", "えいっ！", "日焼け止め 塗った？", "あはは、びしょびしょ！", "ナイスキャッチ！", "海、最高〜！"];

export const BEACH = new Map();   /* id → { c, pts, npcs:[{e,st,t,tgt,hop}], ball:{e,a,b,t,n}|null, t } */
const CD = new Map();             /* 人 → 次に 砂浜を さがす 時刻 */
let NID = 0;

// ---------- 砂浜を さがす ----------
function surf(D, x, z, y0) {
  for (let y = Math.floor(y0) + 6; y >= Math.floor(y0) - 10; y--) {
    let b; try { b = D.getBlock({ x, y, z }); } catch { return null; }
    if (!b) return null;
    if (b.isAir) continue;
    return { b, y };
  }
  return null;
}
const isSand = (b) => /sand$|^minecraft:sand$|gravel/.test(b.typeId) && !/stone/.test(b.typeId);
function nearWater(D, x, y, z) {
  for (const [dx, dz] of [[3, 0], [-3, 0], [0, 3], [0, -3], [2, 2], [-2, -2], [2, -2], [-2, 2]]) {
    try { const b = D.getBlock({ x: x + dx, y, z: z + dz }), b2 = D.getBlock({ x: x + dx, y: y - 1, z: z + dz }); if ((b && b.typeId === "minecraft:water") || (b2 && b2.typeId === "minecraft:water")) return true; } catch {}
  }
  return false;
}
function findBeach(p) {
  const D = OW(), L = p.location, pts = [];
  for (let k = 0, KN = isLite() ? 20 : 40; k < KN && pts.length < 10; k++) {
    const a = Math.random() * Math.PI * 2, r = 6 + Math.random() * 22;
    const x = Math.floor(L.x + Math.cos(a) * r), z = Math.floor(L.z + Math.sin(a) * r);
    const s = surf(D, x, z, L.y); if (!s || !isSand(s.b)) continue;
    let up; try { up = D.getBlock({ x, y: s.y + 1, z }); } catch {} if (!up || !up.isAir) continue;
    pts.push({ x: x + 0.5, y: s.y + 1, z: z + 0.5, w: nearWater(D, x, s.y, z) });
  }
  if (pts.length < 5 || !pts.some((q) => q.w)) return null;
  const c = pts[0]; const near = pts.filter((q) => hv(q, c) < 20);
  return near.length >= 4 ? { c, pts: near } : null;
}

// ---------- 人を 出す ----------
function spawnPeople(G) {
  const n = isLite() ? 2 : 3, keys = [...WHO].sort(() => Math.random() - 0.5).slice(0, n);
  for (const key of keys) {
    const S = PSKIN[key]; if (!S) continue;
    const P = pick(G.pts); let e; try { e = OW().spawnEntity("mrpg:npc", { x: P.x, y: P.y, z: P.z }); } catch { continue; }
    try { e.setProperty("mrpg:job", S[0]); e.nameTag = `§b${personName(S[1], S[2], nearNpcs(P))}`; e.addTag("mrpg_npc"); e.addTag("mrpg_walker"); e.addTag("mrpg_beach"); } catch {}
    G.npcs.push({ e, key, nm: S[1], st: "walk", t: 0, tgt: pick(G.pts), hop: 0, x: P.x, y: P.y, z: P.z });
  }
}
/* 第124版: 近くの 人の 旅の 仲間（ヒロイン）も 水着で 遊びに 加わる（物語の 場面中は 加わらない・1つの 浜に 2人まで）*/
const HLN = { g: ["きゃー、冷たい！ でも 気持ちいい！", "それっ！ 水かけ 攻撃〜！", "次、わたしに パス パス！"], o: ["ふふ、波の 音、落ちつくわね。", "あら、砂が あったかい。", "そーっと……えいっ。ふふ、命中。"], c: ["……水、冷たい。でも 悪くない。", "パス。……ほら、取って。", "日焼け止め、ぬった？"], t: ["き、きゃっ！ 冷たいです……！", "いきますよ、それっ！", "たまには、こういうのも いいですね。"] };
function heroJoin(G) {
  let n = 0;
  for (const p of OW().getPlayers({ location: G.c, maxDistance: 40 })) {
    if (n >= 2) break; const h = heroInfo(p); if (!h || inStory(p)) continue;
    const P = pick(G.pts), e = heroSpawn(p, { x: P.x, y: P.y, z: P.z }, { swim: true, tags: ["mrpg_beach", "mrpg_walker"] }); if (!e) continue;
    G.npcs.push({ e, key: h.key, nm: h.name, hc: "§d", lines: HLN[h.t] || HLN.g, own: p.id, st: "walk", t: 0, tgt: pick(G.pts), hop: 0, x: P.x, y: P.y, z: P.z }); n++;
  }
}
function clearGroup(id) {
  const G = BEACH.get(id); if (!G) return;
  for (const r of G.npcs) try { if (okE(r.e)) r.e.remove(); } catch {}
  if (G.ball && okE(G.ball.e)) try { G.ball.e.remove(); } catch {}
  BEACH.delete(id);
}

// ---------- 3秒ごと: さがす・片づける ----------
system.runInterval(() => {
  const ps = world.getAllPlayers().filter((p) => { try { return p.dimension.id === "minecraft:overworld"; } catch { return false; } });
  for (const [id, G] of BEACH) if (!ps.some((p) => hv(p.location, G.c) < 72)) clearGroup(id);
  if (BEACH.size >= (isLite() ? 1 : 2)) return;
  const now = Date.now();
  for (const p of ps) {
    if ((CD.get(p.id) || 0) > now || busy.has(p.id)) continue;
    if ([...BEACH.values()].some((G) => hv(p.location, G.c) < 56)) continue;
    CD.set(p.id, now + 20000);
    const f = findBeach(p); if (!f) break;   /* 第106版: 1回に 調べるのは 1人だけ */
    const G = { ...f, npcs: [], ball: null, t: 0 }; BEACH.set(`b${++NID}`, G); spawnPeople(G); heroJoin(G);
    CD.set(p.id, now + 60000); break;
  }
}, 60);

// ---------- 4tickごと: 動く ----------
const STEP = 0.32;
function particle(name, at) { try { OW().spawnParticle(name, at); } catch {} }
function toss(G, a, b) {
  if (!G.ball || !okE(G.ball.e)) { let e; try { e = OW().spawnEntity("mrpg:ball", { x: a.x, y: a.y + 1.4, z: a.z }); } catch { return; } try { e.setProperty("mrpg:roll", true); e.addTag("mrpg_beachball"); } catch {} G.ball = { e, n: 0 }; }
  Object.assign(G.ball, { a: { x: a.x, y: a.y + 1.4, z: a.z }, b: { x: b.x, y: b.y + 1.4, z: b.z }, t: 0, to: b });
}
system.runInterval(() => {
  for (const [id, G] of BEACH) {
    G.t++;
    G.npcs = G.npcs.filter((r) => okE(r.e)); if (!G.npcs.length) { clearGroup(id); continue; }
    /* ボールは 山なりに 飛ぶ（6回で 着く）。着いたら 次の 人へ */
    const B = G.ball;
    if (B && okE(B.e) && B.a) {
      B.t++; const k = Math.min(1, B.t / 6), h = Math.max(1.5, hv(B.a, B.b) * 0.35);
      const at = { x: B.a.x + (B.b.x - B.a.x) * k, y: B.a.y + (B.b.y - B.a.y) * k + 4 * h * k * (1 - k), z: B.a.z + (B.b.z - B.a.z) * k };
      try { B.e.teleport(at); } catch {}
      if (k >= 1 && B.toP) {   /* 第110版: ラリー。プレイヤーへ 返した ボールを 打ち返せなかった */
        const R = G.rally; B.toP = null; try { B.e.remove(); } catch {} G.ball = null;
        const p = world.getAllPlayers().find((x) => R && x.id === R.pid);
        if (p && R) { try { p.sendMessage(`§bラリー おしまい！ §f${R.n}回 つづいた${R.n >= 10 ? " §e（すごい！）" : ""}`); } catch {} if (R.n >= 10) rallyPrize(p, R.n); }
        G.rally = null;
      } else if (k >= 1 && G.rally && Date.now() - G.rally.t < 8000) {   /* 受けた 人が プレイヤーへ 打ち返す */
        const holder = G.npcs.find((r) => r === B.to) || G.npcs[0], p = world.getAllPlayers().find((x) => x.id === G.rally.pid);
        if (holder && p) { holder.hop = 3; B.a = null; system.runTimeout(() => { let L = null; try { L = p.location; } catch {} if (okE(B.e) && L) { toss(G, { x: holder.x, y: holder.y, z: holder.z }, { x: L.x, y: L.y - 0.4, z: L.z }); if (G.ball) G.ball.toP = p.id; } else { try { B.e.remove(); } catch {} G.ball = null; G.rally = null; } }, 6); }
        else { try { B.e.remove(); } catch {} G.ball = null; G.rally = null; }
      } else if (k >= 1) {
        const holder = G.npcs.find((r) => r === B.to) || G.npcs[0];
        if (holder && G.npcs.length > 1 && B.n++ < 14) { holder.hop = 3; const nx = pick(G.npcs.filter((r) => r !== holder)); B.a = null; system.runTimeout(() => { if (okE(B.e) && okE(nx.e)) toss(G, { x: holder.x, y: holder.y, z: holder.z }, Object.assign(nx, {})); }, 8); }
        else { try { B.e.remove(); } catch {} G.ball = null; }
      }
    }
    for (const r of G.npcs) {
      r.t++;
      if (r.st === "rest") { if (r.t > 40) { r.st = "walk"; r.t = 0; r.tgt = pick(G.pts); } continue; }
      if (r.st === "splash") {
        if (r.t % 3 === 0) particle("minecraft:water_splash_particle_manual", { x: r.x, y: r.y + 0.3, z: r.z });
        r.hop = r.t % 6 < 3 ? 2 : 0;
        if (r.t > 24) { r.st = "walk"; r.t = 0; r.tgt = pick(G.pts); }
      }
      if (r.st === "walk") {
        const dx = r.tgt.x - r.x, dz = r.tgt.z - r.z, d = Math.hypot(dx, dz);
        if (d < STEP) {
          r.x = r.tgt.x; r.z = r.tgt.z; r.y = r.tgt.y; r.t = 0;
          const q = Math.random();
          if (r.tgt.w && q < 0.45) r.st = "splash";
          else if (q < 0.6 && !G.ball && G.npcs.length > 1) { const o = pick(G.npcs.filter((x) => x !== r)); toss(G, r, o); r.st = "rest"; r.t = 25; }
          else if (q < 0.75) { r.st = "rest"; try { r.e.setProperty("mrpg:mv", false); } catch {} }
          else r.tgt = pick(G.pts);
          if (Math.random() < 0.25) { const p = OW().getPlayers({ location: r, maxDistance: 10 })[0]; if (p) try { p.sendMessage(`${r.hc || "§b"}${r.nm}§f「${pick(r.lines || LINE)}」`); } catch {} }
        } else { const k = (r.run ? 1.5 : 1) * STEP / d; r.x += dx * Math.min(1, k); r.z += dz * Math.min(1, k); r.y += (r.tgt.y - r.y) * 0.3; }
      }
      const yy = r.y + (r.hop > 0 ? 0.35 * r.hop : 0); if (r.hop > 0) r.hop--;
      try { r.e.teleport({ x: r.x, y: yy, z: r.z }, { facingLocation: r.st === "walk" ? { x: r.tgt.x, y: r.tgt.y + 1.5, z: r.tgt.z } : (G.ball && okE(G.ball.e) ? G.ball.e.location : { x: r.x + 1, y: r.y + 1.5, z: r.z }) }); r.e.setProperty("mrpg:mv", r.st !== "rest"); } catch {}
    }
  }
}, 4);

/* ボールを たたくと 近くの 人へ 飛ぶ */
world.afterEvents.entityHitEntity.subscribe(({ damagingEntity: p, hitEntity: e }) => {
  if (p?.typeId !== "minecraft:player" || e?.typeId !== "mrpg:ball") return;
  for (const G of BEACH.values()) {
    if (!G.ball || !okE(G.ball.e) || G.ball.e.id !== e.id) continue;
    const r = G.npcs.slice().sort((a, b) => hv(a, p.location) - hv(b, p.location))[0]; if (!r) return;
    const back = G.ball.toP === p.id;   /* 返して もらった ボールを 打った ときだけ 数える（連打で ふえない）*/
    if (G.rally && G.rally.pid === p.id && !back && Date.now() - G.rally.t < 1500) return;
    G.rally = G.rally && G.rally.pid === p.id && back ? { pid: p.id, n: Math.min(30, G.rally.n + 1), t: Date.now() } : { pid: p.id, n: 1, t: Date.now() };
    toss(G, { x: e.location.x, y: e.location.y - 1.4, z: e.location.z }, r); G.ball.n = 0; G.ball.toP = null;
    try { barNote(p).setActionBar(`§bラリー §f${G.rally.n}回`); } catch {}
    try { p.sendMessage(`§b${r.nm}§f「${pick(["ナイス！", "わっ、上手〜！", "いくよー、それっ！"])}」`); } catch {}
    return;
  }
});
/* 第110版: ラリーが 10回 つづいたら（1日 1回）*/
function rallyPrize(p, n) {
  try { const dd = Math.floor(Date.now() / 86400000); if (p.getDynamicProperty("mrpg:rallyd") === dd) return; p.setDynamicProperty("mrpg:rallyd", dd); const d = load(p); if (!d) return; d.gold = (d.gold || 0) + 500 + n * 20; save(p, d); p.sendMessage(`§e浜辺の みんなから おこづかい！ §f${(500 + n * 20).toLocaleString()} タヨ`); } catch {}
}
/* 話しかける */
NPC_HOOKS.unshift((p, e) => {
  if (!e.hasTag("mrpg_beach")) return false;
  if (busy.has(p.id)) return true;
  for (const G of BEACH.values()) { const r = G.npcs.find((x) => x.e.id === e.id); if (r) { r.st = "rest"; r.t = 0; try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} chatWith(p, e, r.nm, "海辺", pick(["あ、こんにちは！ 泳ぎに 来たの？", "ふふ、見てた？", "いい 天気でしょ？ 海日和〜"])); return true; } }
  try { e.remove(); } catch {} return true;
});
/* 読みこみ直しで 残った 人は 片づける（今 動いて いる 人は のぞく）*/
system.runTimeout(() => {
  try { for (const e of OW().getEntities({ tags: ["mrpg_beach"] })) { if (![...BEACH.values()].some((G) => G.npcs.some((r) => r.e.id === e.id))) try { e.remove(); } catch {} } } catch {}
  try { for (const e of OW().getEntities({ tags: ["mrpg_beachball"] })) { if (![...BEACH.values()].some((G) => G.ball && G.ball.e.id === e.id)) try { e.remove(); } catch {} } } catch {}
}, 100);
/* 第106版: チャンクが 読みこまれなく なって 消し損ねた 人・ボール・演出の モンスターを 片づける（10秒ごと・人の 近くだけ） */
system.runInterval(() => {
  let TR = null; try { TR = globalThis.__mqTroubleIds ? globalThis.__mqTroubleIds() : null; } catch {}
  for (const p of world.getAllPlayers()) {
    try {
      if (p.dimension.id !== "minecraft:overworld") continue;
      const q = { location: p.location, maxDistance: 64 }, D = OW();
      for (const e of D.getEntities({ ...q, tags: ["mrpg_beach"] })) if (![...BEACH.values()].some((G) => G.npcs.some((r) => r.e.id === e.id))) e.remove();
      for (const e of D.getEntities({ ...q, tags: ["mrpg_beachball"] })) if (![...BEACH.values()].some((G) => G.ball && G.ball.e && G.ball.e.id === e.id)) e.remove();
      if (TR) for (const e of D.getEntities({ ...q, tags: ["mrpg_trouble"] })) if (!TR.has(e.id)) e.remove();
      for (const e of D.getEntities({ ...q, tags: ["mrpg_cine"] })) if (!globalThis.__mqCine || !globalThis.__mqCine.has(e.id)) e.remove();
    } catch {}
  }
}, 200);
export const __beach = { BEACH, CD, findBeach, spawnPeople, clearGroup, toss };
