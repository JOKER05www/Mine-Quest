/* 第126版 裏2「鍔の泣き声」（ルミナの 闘技場／アルカトラス城）— 作業 UA
   MQ25 = 2話・3話（鍔を 受け取る。カゲツとは 戦わない。カゲツ戦は 裏の 後の「伝説の マスター」に 残す）*/
import { world } from "@minecraft/server";
import { bkAdd, mqOver, bkHas, chActive } from "./bkeng.js";
import { PG_GATE } from "./postgame.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS, fac, facMark } from "./epfac.js";
import { MQ } from "./saga.js";
import { ok } from "./ui.js";
import { castleOut, gateSet, plazaOf, moveG } from "./pvplace.js";
import { placeOf, arenaOf } from "./storyplace.js";
import { UA } from "./bk_u01.js";
const { F, S1 } = FAC_OPS;

facAdd("u_stands", { D: [10, 12, 9], box: [-1, -5, 8, 5], H: 6, look: [6, 0, 3], marks: { top: [6, 0, 3] }, build: () => [   /* 闘技場の 客席（三段の 石の 段・いちばん 上の 席・旗）*/
  F(2, -5, 0, 3, 5, 0, "stone_bricks"), F(4, -5, 0, 5, 5, 1, "stone_bricks"), F(6, -5, 0, 7, 5, 2, "stone_bricks"), F(6, -5, 3, 6, 5, 3, "oak_slab"),
  F(8, -5, 0, 8, 5, 4, "stone_bricks"), S1(8, -3, 5, "red_wool"), S1(8, 3, 5, "red_wool"), S1(8, 0, 5, "lantern"),
] });
facAdd("u_vault", { D: [10, 12, 9], box: [-1, -4, 8, 4], H: 5, look: [7, 0, 2], marks: { mural: [7, 0, 2], vessel: [5, 3, 1], door: [1, 0, 1] }, build: () => [   /* 城の 封印庫: 石の 部屋・奥の 壁画（顔の 削れた 王）・器の 石板の 台・重い 戸 */
  F(0, -4, -1, 8, 4, -1, "polished_andesite"), F(8, -4, 0, 8, 4, 4, "stone_bricks"), F(1, -4, 0, 7, -4, 4, "stone_bricks"), F(1, 4, 0, 7, 4, 2, "stone_bricks"),
  F(8, -2, 1, 8, 2, 3, "white_terracotta"), F(8, -1, 2, 8, 1, 3, "brown_terracotta"), S1(8, 0, 3, "cracked_stone_bricks"), S1(8, 0, 2, "black_terracotta"),
  S1(5, 3, 0, "polished_deepslate"), S1(5, 3, 1, "chiseled_deepslate"), F(1, -1, 0, 1, -1, 2, "iron_bars"), F(1, 1, 0, 1, 1, 2, "iron_bars"),
  S1(3, -3, 0, "soul_lantern"), S1(3, 3, 0, "chain"),
] });

castAdd("u_kagetsu", { nm: "カゲツ", role: "", col: "§b", gobi: "", skin: "kagetsu" });
castAdd("u_toto", { nm: "トト", role: "衛兵の子", gobi: "", skin: "c7_toto", town: "t0", at: () => { const q = UA.place("court", 0)(); return q ? { x: q.x + 3, z: q.z + 2 } : null; },
  hide: (s) => !bkHas(s, "u02e7"),
  after: [
    [(s) => bkHas(s, "u07e7"), ["{smile}封印庫の 絵の 王さま、狂って なかったんだって？ ……ぼく、毎日 あの 絵に あいさつ してるんだ。"]],
    [() => true, ["{smile,☆}ぼく、封印庫の 番を してるんだ！ ……槍は まだ 小さいけど。", "{closed}奥の 石板、ときどき かたかた 揺れるんだよ。"]],
  ] });

/* 第128版(H1): 闘技場の 話は 本1・本19 と 同じ ルミナの 闘技場（町の 外の 1か所・セット b19ring）。カゲツは その 客席の 最上段（印 seat）*/
const ARENA = () => arenaOf("ルミナの 闘技場の 客席") || UA.out("stands", "t0", 0.25, "ルミナの 闘技場の 客席")();
const COURT = UA.place("court", 0, "アルカトラス城の 中庭");
const INN = UA.place("inn", 0, "城下の 宿");
const stands = (K, p) => fac(K, p, "b19ring", "cupring", 0, UA.Y(K, p));
function kagetsu(K, p) { const top = facMark("b19ring", "seat", p.location) || facMark("b19ring", "top", p.location); const e = K.cast(p, "u_kagetsu", true); if (ok(e) && top) try { e.teleport(top); } catch {} K.act(e, "down"); K.hold(e, "sword"); return e; }
/* 第128版(H1): 客席の 最上段（カゲツの 席の 横）へ 上る。暗転して 同じ 段の 2.5 マス 横に 立ち、席を 向く（話す 人を 近くから 映す）。小さな 形（印 seat が ない）なら 今の まま */
async function toSeat(K, p, nm = "ルミナの 闘技場の 客席の 最上段") { const v = facMark("b19ring", "seat", p.location), r = J("mrpg:epdeco:b19ringat"); if (!v || !r || !Array.isArray(r.f)) return false; const fx = r.f[0], fz = r.f[1]; return K.moveTo(p, { x: v.x + 2.5 * fz, y: v.y, z: v.z - 2.5 * fx }, nm, [], { x: v.x, y: v.y + 1, z: v.z }, 0); }
const J = (k) => { try { const s = world.getDynamicProperty(k); return typeof s === "string" ? JSON.parse(s) : null; } catch { return null; } };
const vault = (K, p) => fac(K, p, "u_vault", "u_vault", 0, UA.Y(K, p));
const crowd = (K, p, n = 2) => { for (let i = 0; i < n; i++) { K.sound(p, "random.levelup", 0.15); K.sound(p, "mob.villager.yes", 0.4); } };

bkAdd("u02", [
  { id: "u02e1", t: "最上段の 寝ぼすけ", place: ARENA, fac: "b19ring", battles: 0,
    hint: "§fルミナの §e闘技場の 客席の 最上段§f へ 行こう §7（言伝の 主が 寝て いる）",
    syn: "闘技場の 客席の いちばん 上で、老人が 赤黒い 鍔の 刀を 抱いて 眠って いた。ムサシは 鍔を 見て「ちくしょう、きれいだ」と 怒鳴り、聞き槌で 一度 叩いた。",
    async run(p, d, K) {
      const A = stands(K, p), eK = kagetsu(K, p);
      await K.open(p, "ルミナの 闘技場の 客席", "day");
      crowd(K, p);
      if (A) await K.at(p, A, 14, 7, 2.5);
      if (ok(eK)) await K.push(p, eK, 22, 5, 1.6);
      await K.narr(p, ["§7客席の いちばん 上。歓声の 中で、老人が §c赤黒い 鍔§7 の 刀を 抱いて 眠って いる。"], eK);
      await toSeat(K, p);   /* 第128版(H1): 下から 見上げた あと、最上段へ 上る */
      const eM = UA.mu(K, p, true);
      await K.walkCam(p, eM, UA.near(eM, eK || p, 1.6), 20);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{angry,!,up}……ちくしょう、§eきれいだ§f！", "{angry}なんで こんなに きれいなんだよ……！"], eK);
      await UA.tap(K, p, eM, eK ? eK.location : null);
      await K.say(p, "ムサシ", ["{shock,…}……鳴った。", "{sad}中で、誰か 泣いてる。"], eK);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{closed}……この 寝ぼすけが、言伝の 主だ。", "{sweat}歓声の 真ん中で 寝られる じいさんは、ほかに いねえ。"], p);
      if (ok(eK)) await K.push(p, eK, 16, 3, 1.4);
      await K.narr(p, ["§7歓声が 上がる たびに、老人の 腕の 中で 鍔が かすかに 震える。"], eK);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}鍔の 鉄は、いい 鉄だ。焼きも 狂ってねえ。", "{sad}……なのに 泣いてる。鉄が 泣く わけ ねえのに。"], eK);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{?}……お前も 聞こえるか。", "{closed}……聞こえねえ 顔だな。それで いい。聞こえる ほうが 変なんだ。"], p);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}起きるまで 待つ。……寝てる 人は 叩かねえ。", "{smile}次の 名乗りで、たぶん 起きる。"], eK);
      await K.end(p, { leave: [eM], bye: [eK], card: "§7→ 老人が 目を 覚ます（客席で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u02e2", t: "百と三勝", place: ARENA, fac: "b19ring", F: ["F25"], battles: 0,
    hint: "§fルミナの §e闘技場の 客席の 最上段§f で、目を 覚ました 老人の 話を 聞こう",
    syn: "老人カゲツが 目を 覚ました。「オルドに 伝えて くれ。百と 三勝」。",
    async run(p, d, K) {
      stands(K, p); const eK = kagetsu(K, p);
      await K.open(p, "ルミナの 闘技場の 客席", "day");
      await toSeat(K, p);   /* 第128版(H1): 最上段の カゲツの そばへ */
      const eM = UA.mu(K, p, true);
      crowd(K, p, 1); K.act(eK, "up"); await K.up(p, eK, 12);
      await K.csay(p, "u_kagetsu", ["{closed,息}ふぁ……。うるせえ 槌の 音だと 思ったら、クロガネの 末っ子か。", "{?}……で、そっちが 六つ目か。思ったより 小せえな。"], eM);
      await K.say(p, "ムサシ", ["{angry}寝ぼすけ。言伝は 届けたぜ。……名前、まだ 聞いてねえ。"], eK);
      await K.csay(p, "u_kagetsu", ["{smile}カゲツだ。剣の 家の 当主で、今は ただの 寝ぼすけだ。"], eM);
      /*F25*/ await K.up(p, eK, 10);
      await K.csay(p, "u_kagetsu", ["{smile,…}そうだ、ついでに 頼む。……オルドに 伝えて くれ。§e百と 三勝§f。", "{closed}そう 言えば わかる。"], eM);
      await K.say(p, "ムサシ", ["{?}……数を 伝えるだけで いいのか？"], eK);
      await K.csay(p, "u_kagetsu", ["{smile}あいつは どうせ 数え直す。それで いい。"], eM);
      await K.ots(p, eM, eK, 10);
      await K.say(p, "ムサシ", ["{?}……勝ちの 数を 数え直すって、どういう ことだ。"], eK);
      await K.up(p, eK, 8);
      await K.csay(p, "u_kagetsu", ["{smile}勝ったり 負けたり、百と 少し。……お互い、自分の 勝ちを 多めに 数えてる。", "{closed}数え合える うちは、二人とも 生きてる って ことだ。"], eM);
      await K.ots(p, eM, eK, 8);
      await K.say(p, "ムサシ", ["{closed}……覚えた。百と 三。", "{smile}字じゃ なくて、声で 持って いく。"], eK);
      await K.up(p, eK, 8);
      await K.csay(p, "u_kagetsu", ["{smile}おう。末っ子の 耳なら、落とさねえ。"], eM);
      await K.end(p, { leave: [eM], bye: [eK], card: "§7→ カゲツが 刀を 差し出す" });
      return true;
    } },
  { id: "u02e3", t: "抱いた 者は 眠る", place: ARENA, fac: "b19ring", keys: ["k_hilt"], battles: 0,
    hint: "§fルミナの §e闘技場の 客席§f で、カゲツから 鍔を 受け取ろう",
    syn: "鍔を 受け取った ムサシは、三歩で まぶたが 下がった。カゲツ「抱いた 者が 中の ささやきを 吸う。歓声の 中でなら 浅くて すむ」。客席の 名乗りの 声で ムサシが 目を 覚ました。鍔は ムサシの 腰に 収まった。",
    async run(p, d, K) {
      stands(K, p); const eK = kagetsu(K, p);
      await K.open(p, "ルミナの 闘技場の 客席", "day");
      await toSeat(K, p);   /* 第128版(H1): 最上段の カゲツの そばへ */
      const eM = UA.mu(K, p, true);
      K.act(eK, "up"); await K.up(p, eK, 10);
      await K.csay(p, "u_kagetsu", ["{closed}三十五年、抱いて きた。……持って いけ。泣き声の 主に 会いに 行くんだろ。"], eM);
      await K.give(eK, eM, "sword");
      await K.push(p, eM, 18, 3, 1.4);
      await K.say(p, "ムサシ", ["{smile}……重てえ。いい 重さだ。"], eK);
      for (let i = 0; i < 3; i++) { await K.go(eM, K.fwd(p, 3 + i * 0.6, -1), 8); K.act(eM, i === 2 ? "kneel" : "sad"); await K.wait(6); }
      await K.say(p, "ムサシ", ["{closed,息}……あれ、なんだ……まぶたが……"], eK);
      await K.csay(p, "u_kagetsu", ["{closed}抱いた 者が、中の ささやきを 吸う。だから 眠い。", "{smile}歓声の 中でなら、浅くて すむ。……おれが ここで 寝てた わけだ。"], eM);
      crowd(K, p, 3); K.sound(p, "note.pling", 0.6);
      await K.narr(p, ["§7下の 舞台で、挑戦者が 名乗りを 上げた。§f「――三度 名乗る！ 我が 名は……！」"], eM);
      K.act(eM, "up"); await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{shock,!,jump}……っ！ 寝てねえ！", "{sweat}……寝てた。"], eK);
      await K.up(p, eK, 8);
      await K.csay(p, "u_kagetsu", ["{smile}三歩か。……おれは 最初、二歩だった。"], eM);
      await K.say(p, "ムサシ", ["{closed}……俺が 持つ。歓声の 中なら、眠りは 浅えらしい。", "{smile}寝そうに なったら、お前が 叩き起こせ。……今、うなずいたな。"], eK);
      await K.give(eM, null, "sword");
      K.pay(p, this, 800, [["c_fruit", 3]]);
      await K.csay(p, "u_kagetsu", ["{closed,息}……やっと 眠れる。浅くなく、な。", "{smile}起きたら、オルドの 顔でも 見に 行くか。"], eM);
      await K.ots(p, eM, eK, 8);
      await K.say(p, "ムサシ", ["{closed}……じいさん。三十五年、ありがとな。"], eK);
      K.act(eK, "down");
      await K.end(p, { leave: [eM], bye: [eK], card: "§d魔神の鍔 §7を 受け取った（だいじなもの）" });
      return true;
    } },
  { id: "u02e4", t: "城の 地鳴り", place: COURT, battles: 0,
    hint: "§fアルカトラス城の §e中庭§f へ 行こう §7（夜。城の 地下が 鳴って いる）",
    syn: "その 夜、アルカトラス城の 封印庫から 地鳴りが した。夜着の まま 中庭に 立つ アルカ十三世「千年、見張って きた 絵が ある」。",
    async run(p, d, K) {
      await K.open(p, "アルカトラス城の 中庭（夜）", "night", "night");
      K.shake(p, 0.3, 0.8); K.sound(p, "ambient.weather.thunder", 0.4);
      await K.narr(p, ["§7その 夜、城の 地下から 地鳴りが した。§8ムサシの 腰で、鍔が かすかに 鳴って いる。"]);
      const eA = K.cast(p, "arca"), eM = UA.mu(K, p, true);
      await K.up(p, eA, 10);
      await K.csay(p, "arca", ["{closed}……来て くれたか。地下の 封印庫が、鳴って おる。", "{up}鍔が 外へ 出た 夜から だ。"], eM);
      await K.say(p, "ムサシ", ["{?}封印庫？ 中に 何が ある。"], eA);
      await K.csay(p, "arca", ["{closed}千年、見張って きた 絵が ある。", "{sad}……余の 代で 開ける ことに なるとは、思わなんだ。"], eM);
      await K.ots(p, eM, eA, 10);
      await K.say(p, "ムサシ", ["{?}絵？ 絵が 鳴るのか。"], eA);
      await K.up(p, eA, 8);
      await K.csay(p, "arca", ["{closed}鳴るのは 絵では ない。……見れば わかる。", "{sad}余の 生涯で、あの 部屋が 鳴ったのは 初めてだ。"], eM);
      await K.narr(p, ["§7ムサシは 腰の 鍔に 手を 置いた。§8……布の 上からでも、震えて いるのが 分かる。"], eM);
      await K.ots(p, eM, eA, 8);
      await K.say(p, "ムサシ", ["{closed}……鍔が 外に 出た 夜から、か。", "{sad}こいつが 泣くと、まわりも 泣くのか。"], eA);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}行くぞ。……地下の 音は、近くで 聞かねえと わからねえ。"], p);
      await K.end(p, { leave: [eA, eM], kind: "night", card: "§7→ 封印庫へ（中庭で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u02e5", t: "小さな 槍", place: COURT, fac: "u_vault", F: ["F61"], battles: 0,
    hint: "§fアルカトラス城の §e封印庫§f へ 下りよう",
    syn: "封印庫から 影が あふれる。衛兵の 子 トトが 小さな 槍で 扉を 押さえて いた。奥の 壁画は 王の 顔だけが 削られ、台の 上で 器の 石板が 揺れて いた。",
    async run(p, d, K) {
      const V = vault(K, p), dq = facMark("u_vault", "door", p.location), vq = facMark("u_vault", "vessel", p.location);
      await K.open(p, "アルカトラス城の 封印庫", "night", "night");
      if (V) await K.at(p, V, 14, 7, 1.8);
      const eT = K.cast(p, "u_toto"); K.hold(eT, "spear"); K.act(eT, "guard");
      if (ok(eT) && dq) await K.go(eT, dq, 10);
      await K.up(p, eT, 10);
      await K.csay(p, "u_toto", ["{angry,!}こ、ここは 通さない！ 父さんの 代わりに、ぼくが 番を してるんだ！"], null);
      K.burst(p.dimension, dq || p.location, "minecraft:basic_smoke_particle", 10, 0.8, 1);
      const eM = UA.mu(K, p, true);
      await K.say(p, "ムサシ", ["{shock}……扉の 向こうから、影が 押してる。", "{smile}いい 腕だ、坊主。もう 少し 押さえとけ。"], eT);
      /*F61*/ if (vq) { await K.push(p, vq, 22, 4, 0.8); K.sound(p, "dig.stone", 0.5); K.shake(p, 0.2, 0.4); }
      await K.narr(p, ["§7奥の 台の 上で、§f器の 石板§7 が かたかた 揺れて いる。", "§8……地鳴りの たびに、石板だけが 先に 揺れる。"], vq);
      const eA = K.cast(p, "arca");
      await K.csay(p, "arca", ["{closed}あの 石板は、王冠が ゆるむと 揺れる。……千年、そう 伝わって おる。", "{sad}何が 入って おるのかは、余も 知らぬ。"], eM);
      await K.ots(p, eM, eA, 10);
      await K.say(p, "ムサシ", ["{closed}……揺れる たびに、腰の 鍔も 鳴る。", "{?}同じ 糸で つながってる みてえだ。"], eA);
      await K.up(p, eT, 8);
      await K.csay(p, "u_toto", ["{sweat,汗}お、おじさん！ 扉、まだ 押して くる！"], eM);
      await K.ots(p, eM, eT, 8);
      await K.say(p, "ムサシ", ["{angry}おじさんじゃ ねえ。ムサシだ。……お前は。"], eT);
      await K.up(p, eT, 8);
      await K.csay(p, "u_toto", ["{angry,!}トト！ 衛兵の 子の トト！"], eM);
      await K.ots(p, eM, eT, 8);
      await K.say(p, "ムサシ", ["{smile}トト。覚えた。……もう 少しだ、トト。"], eT);
      await K.end(p, { leave: [eM], bye: [eT, eA], kind: "night", card: "§7→ 奥の 壁画へ" });
      return true;
    } },
  { id: "u02e6", t: "顔の ない 王", place: COURT, fac: "u_vault", F: ["F27"], battles: 0,
    hint: "§fアルカトラス城の §e封印庫の 奥§f の 壁画を 見よう",
    syn: "古い 絵。鎖で 綴じた 帳を 抱き、髪に 折れた 筆を 挿した 王。顔だけが 削られて いる。鍔が 絵の 前で 泣き声を 強くした。人を 石に した 名の ない 神を、生き残った 者たちは「邪神」と 呼んだ。",
    async run(p, d, K) {
      vault(K, p); const mq = facMark("u_vault", "mural", p.location);
      await K.open(p, "アルカトラス城の 封印庫の 奥", "night", "night");
      if (mq) await K.push(p, mq, 26, 5, 0.4);
      /*F27*/ await K.narr(p, ["§7古い 壁画。§f鎖で 綴じた 帳§7 を 抱いた 王。髪には §f折れた 筆§7 が 一本。", "§8……顔だけが、のみで 削り取られて いる。"], mq);
      K.sound(p, "mob.ghast.moan", 0.25); K.sound(p, "note.bell", 0.3);
      await K.narr(p, ["§7ムサシの 腰で、鍔が 泣いた。§8さっきより 強く。"]);
      const eM = UA.mu(K, p, true), eA = K.cast(p, "arca");
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{shock,…}……絵の 前で、泣き声が でかく なった。", "{?}この 王、誰だ。"], eA);
      await K.csay(p, "arca", ["{closed}帳の 王、と だけ 伝わる。……千年前の 乱で、狂った 王と 呼ばれた。", "{sad}顔を 削ったのは、のちの 人だ。狂った 王の 顔は、残さぬ と。"], eM);
      await K.csay(p, "arca", ["{up}あの 乱の あと、生き残った 者は、人を 石に した 名の ない 神を §5邪神§f と 呼んだ。", "{closed}名を 呼べぬ ものは、そう 呼ぶ しか なかったのだ。"], eM);
      await K.say(p, "ムサシ", ["{angry,low}……顔を 削っても、音は 削れねえ。", "{sad}この 鍔の 泣き方と、絵の 前の 静けさが、同じ 高さだ。"], eA);
      await K.up(p, eA, 8);
      await K.csay(p, "arca", ["{?}……音の 高さで、何が 分かる。"], eM);
      await K.ots(p, eM, eA, 8);
      await K.say(p, "ムサシ", ["{closed}泣いてる 鍔と、この 絵が、つながってる って ことだ。", "{sad}……たぶんな。字じゃ ねえから、たぶんだ。"], eA);
      await K.end(p, { leave: [eM], bye: [eA], kind: "night", card: "§7→ 影が 扉を 破る！（封印庫で もう一度 立ち止まろう）" });
      return true;
    } },
  { id: "u02e7", t: "封印庫の 影", place: COURT, fac: "u_vault", battles: 1,
    hint: "§fアルカトラス城の §e封印庫§f へ（あふれた 影とは 城門の 外で 戦う）",
    syn: "封印庫の 扉が 破れ、影が 城門の 外へ あふれた。トトを 背に かばって 戦った。",
    async run(p, d, K) {
      vault(K, p); const dq = facMark("u_vault", "door", p.location);
      await K.open(p, "アルカトラス城の 封印庫", "night", "night");
      let eT = K.cast(p, "u_toto"), eM = UA.mu(K, p, true); K.hold(eT, "spear");
      K.shake(p, 0.5, 0.8); K.sound(p, "mob.wither.ambient", 0.4); if (dq) K.burst(p.dimension, dq, "minecraft:basic_smoke_particle", 16, 1, 1.2);
      await K.csay(p, "u_toto", ["{sweat,汗}と、扉が……！"], eM);
      await K.say(p, "ムサシ", ["{angry,!,up}坊主、俺の 後ろだ！ ……お前も 来い、二回！", "{sweat}……違ったな。行くぞ！"], eT);
      /* 第126版(PV): 影は 城門の 外へ あふれ出る → 城門の 外で 戦う（城の 中では 戦わない）*/
      { const GO = castleOut(0, "アルカトラス城の 城門の 外（夜）"), CQ = placeOf("court", 0);
        if (GO) { await K.narr(p, ["§7影は 中庭を 抜け、城門の 外へ あふれ出た。"], dq); if (CQ) gateSet(p, "c0gate", GO, CQ, UA.Y(K, p)); await moveG(K, p, GO, "アルカトラス城の 城門の 外（夜）", [eT, eM].filter(ok), CQ ? { x: CQ.x, y: UA.Y(K, p) + 3, z: CQ.z } : null); eT = K.cast(p, "u_toto"); K.hold(eT, "spear"); eM = UA.mu(K, p, true); } }
      const r = await K.battle(p, K.team(["nether", "nether", "dragon"], 90, 3, 46), { name: "封印庫から あふれた 影", arena: "城の 封印庫", theme: "underworld", speaker: "影", lines: { half: "……チョウ……ヲ……", low: "……ナヲ……カケ……" } });
      if (r !== "win") { await K.say(p, "ムサシ", ["{sweat,息}……数が 多すぎる。一度 下がるぞ！", K.RT(p)], eT); await K.end(p, { bye: [eT, eM] }); return false; }
      K.act(eT, "cheer");
      await K.csay(p, "u_toto", ["{smile,☆}……やった！ ぼく、ずっと 押さえてたよ！"], eM);
      await K.say(p, "ムサシ", ["{smile}知ってる。いい 音が してた。……槍の 柄が、ずっと 震えてた 音だ。"], eT);
      await K.up(p, eT, 8);
      await K.csay(p, "u_toto", ["{sad,…}……ぼく、手が 震えてた。こわかった。"], eM);
      await K.ots(p, eM, eT, 8);
      await K.say(p, "ムサシ", ["{closed}震えて いい。震えても 離さなかった。……それが 番だ。"], eT);
      await K.up(p, eT, 8);
      await K.csay(p, "u_toto", ["{smile}……うん！ 明日も 番を する！"], eM);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}……影の 声、聞いたか。『帳を』『名を』って。", "{?}帳って 何だ。……あの 絵の 王が 抱えてた やつか。"], p);
      await K.up(p, eM, 8);
      await K.say(p, "ムサシ", ["{closed}……宿で 考える。鍔の 音を、もう一度 聞きてえ。"], p);
      K.pay(p, this, 1500, [["c_fruit", 3]]);
      await K.end(p, { leave: [eM], bye: [eT], kind: "night", card: "§7→ 城下の 宿で 休もう" });
      return true;
    } },
  { id: "u02e8", t: "打った 家へ", place: INN, battles: 0,
    hint: "§f城下の §e宿§f で 休もう",
    syn: "宿で、ムサシが 鍔を じっと 聞いた。「この 鍔は、クロガネで 打たれた 音だ。打った 家に 返す」。",
    async run(p, d, K) {
      await K.open(p, "城下の 宿（夜）", "night", "night");
      const eM = UA.mu(K, p, true);
      await K.up(p, eM, 10);
      await K.say(p, "ムサシ", ["{closed}……さっきから、ずっと 聞いてた。", "{up}この 鍔は、クロガネで 打たれた 音だ。うちの 槌の 癖が ある。"], null);
      await K.push(p, eM, 16, 3, 1.4);
      await K.say(p, "ムサシ", ["{closed}打った 家に 返す。……クロガネへ 行く。", "{sad}中で 泣いてる やつの 声、うちの 工房なら 聞こえる かもしれねえ。"], null);
      await K.ots(p, eM, p, 10);
      await K.say(p, "ムサシ", ["{?}……なんで わかるか？ 槌には、打った 家の 癖が 残る。", "{closed}うちは 三つ 打って、一つ 休む。この 鍔の 縁に、その 拍子が 残ってる。"], p);
      await K.up(p, eM, 8);
      await K.narr(p, ["§7ムサシは 鍔の 縁を、指の 腹で 一つずつ なぞった。§8……一つ、二つ、三つ。休み。"], eM);
      await K.say(p, "ムサシ", ["{sad}……親父の 拍子だ。いや、もっと 古い。", "{closed}ずっと 前の うちの 誰かが、これを 打った。"], p);
      await K.ots(p, eM, p, 8);
      await K.say(p, "ムサシ", ["{closed}……寝る。鍔は 抱かねえ。抱くと、朝まで 起きられねえ。", "{sad}……中の やつも、少しは 寝られりゃ いいけどな。"], p);
      await K.night(p, eM.location, "§8ムサシは 鍔から 少し 離れて、壁に もたれて 眠った。", "§7朝。ムサシは もう 起きて、南の 火山の 方を 見て いた。", []);
      if (ok(eM)) { await K.up(p, eM, 8); await K.say(p, "ムサシ", ["{up}……火山の 匂いが する。南だ。", "{smile}クロガネは、目を つぶっても 着く。"], p); }
      await UA.zeph(K, p);
      await K.end(p, { leave: [eM], card: "§7→ ヴォルカの §eはがねの 村 クロガネ§7 へ（右上の 案内）" });
      return true;
    } },
]);

/* MQ25: 鍔を 受け取る（カゲツとは 戦わない）。終章の 後、裏1 と 2-1 を 見たら 闘技場の 客席で 始まる */
if (MQ[25]) { MQ[25].trig = (c) => !!c.s.ending; delete MQ[25].nospot; delete MQ[25].ch; MQ[25].run = async () => true; MQ[25].hint = "§fルミナの §e闘技場の 客席の 最上段§f で、カゲツの 話を 聞こう"; }
mqOver(25, async (p, d, K, c) => { for (const id of ["u02e2", "u02e3"]) if (!(await c.play(id))) return false; return true; },
  { cond: async () => true, spot: (p, d) => { const q = ARENA(); return q ? { x: q.x, y: null, z: q.z, nm: q.nm, key: "u02", np: 1 } : null; } });
/* 伝説の マスター カゲツ（裏の 後）は 鍔を 渡さない（postgame.js kengoReward の 門）*/
PG_GATE.bookCh = (c) => chActive(c);
