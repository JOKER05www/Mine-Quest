/* 第126版 本11「雪山の双子」（フロストヘイム雪山・サンダ／雷神の祠／氷の隠れ家）。作業 MC
   ・1〜3話（前19）・9話（前20）は 自由な 話。4〜8話は MQ19（氷の 隠れ家）。選択 C11（黒い 手袋）は 8話
   ・古い 話を 引きとる: r8e1 雷雲の 里 → 1話 ／ r8e2 雪崩の 救助 → 2話 ／ r8e3 ふたつの 声 → 3話 ／ r8e6 雷祭り → 9話（EP_OFF は bkAdd が 入れる）
   ・今日の 双子の 直しを 守る: 本当と嘘の 仕掛けなし／白黒の 片手袋／祠の 本物の 崖（r8cliff の 雪庇が 崩れる）／隠れ家の 本物の 薄い 氷の 池（広間の 池を 割って 終わりに もどす。広間が ない ときは r8pond）
   ・シロウは 双子の 兄（手袋を 母の 編み目で 編んだ）。仮面の 戦士の 名は 本14 まで 出さない */
import { world } from "@minecraft/server";
import { plazaOf, festSet, crowd } from "./pvplace.js";
import { bkAdd, mqOver } from "./bkeng.js";
import { castAdd, doomed } from "./cast.js";
import { fac, facMark, facState, facAt } from "./epfac.js";
import { caveInfo, groundY } from "./structures.js";
import { placeOf, farOf } from "./storyplace.js";
import { ok } from "./ui.js";
import { TW, out, memo, Y, REI, snow, hum, putN, V4 as V, has, once, walkOff } from "./bk_b09.js";

/* ---------- 場所 ---------- */
/* 第126版(PV): 雷祭りは 里の 広場（やぐらも 広場に。建物・道を 上書きしない 空き地だけ）*/
const YAGURA = memo(() => { const q = plazaOf(TW.sanda, "らいうんの 里 サンダの 広場（雷祭りの やぐら）"); return q ? { x: q.x, z: q.z, nm: q.nm } : out(TW.sanda, 0.9, "らいうんの 里 サンダの 雷祭りの やぐら"); });
const HOKORA = memo(() => farOf("r8hokora", TW.sanda, "サンダの 裏山の 雷神の 祠", 90, 300) || out(TW.sanda, -0.9, "サンダの 裏山の 雷神の 祠"));   /* 第127版(fac2): 町の 外れ 56 → 離れた 山の 上 */
const ROAD = memo(() => { try { const f = farOf("r8road", TW.sanda, "サンダへの 山道（雪崩の あと）", 90, 300); if (f) return f; const o = placeOf("road", 8); return o ? { x: o.x, z: o.z, nm: "サンダへの 山道（雪崩の あと）" } : null; } catch { return null; } });   /* 第127版(fac2): 町から 離れた 山道 */
const spark = (K, p, q, n = 8) => { if (!q) return; K.burst(p.dimension, q, "minecraft:electric_spark_particle", n, 0.8, 1); K.burst(p.dimension, q, "minecraft:endrod", 4, 0.5, 1.6); };
const thunder = (K, p, q, big = false) => { K.sound(p, "ambient.weather.thunder", big ? 1 : 0.5); if (big) { K.flash(p, true); K.shake(p, 0.6, 0.5); } spark(K, p, q, big ? 14 : 6); };
/* やぐら（前の 版と 同じ 記録 mrpg:epdeco:r8yaguraat を 使う。ワールドに 1回）*/
function yagura(K, p, y0) {
  let A = null; try { A = JSON.parse(world.getDynamicProperty("mrpg:epdeco:r8yaguraat") || "null"); } catch {}
  if (A && typeof A.x === "number" && Math.hypot(A.x - p.location.x, A.z - p.location.z) < 48) return A;
  const S = K.S(p); if (!S) return null;
  /* 5×5・高さ 8 が まるごと 空いて いて 地面が 同じ 高さの 所（町の 建物・噴水・道の 灯りを こわさない）*/
  const dim = p.dimension, clear = (x, z, y) => { for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) { let g = null; try { g = groundY(dim, x + a, z + b, y + 4); } catch {} if (g !== y) return false; for (let h = 0; h <= 7; h++) { try { const bl = dim.getBlock({ x: x + a, y: y + h, z: z + b }); if (bl && !bl.isAir) return false; } catch { return false; } } } return true; };
  let x = 0, z = 0, y = null;
  for (const [a, b] of [[8, 0], [7, 5], [7, -5], [-7, 0], [0, 8], [0, -8], [10, 0]]) { const q = S.at(a, b), qx = Math.floor(q.x), qz = Math.floor(q.z); let g = null; try { g = groundY(dim, qx, qz, y0 + 4); } catch {} if (typeof g === "number" && Math.abs(g - y0) <= 1 && clear(qx, qz, g)) { x = qx; z = qz; y = g; break; } }
  if (y === null || !once("mrpg:epdeco:mcyagura")) return null;
  for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) K.cmd(p, `fill ${x + a} ${y} ${z + b} ${x + a} ${y + 4} ${z + b} spruce_log`);
  K.cmd(p, `fill ${x - 2} ${y + 5} ${z - 2} ${x + 2} ${y + 5} ${z + 2} spruce_planks`); K.cmd(p, `fill ${x - 2} ${y + 6} ${z - 2} ${x + 2} ${y + 6} ${z + 2} spruce_fence`); K.cmd(p, `fill ${x - 1} ${y + 6} ${z - 1} ${x + 1} ${y + 6} ${z + 1} air`);
  K.cmd(p, `setblock ${x} ${y + 6} ${z} lightning_rod`); for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) K.cmd(p, `setblock ${x + a} ${y + 7} ${z + b} lantern`);
  const R = { x: x + 0.5, y: y + 6, z: z + 0.5 }; try { world.setDynamicProperty("mrpg:epdeco:r8yaguraat", JSON.stringify(R)); world.setDynamicProperty("mrpg:epdeco:r8yagura", 1); world.setDynamicProperty("mrpg:epdeco:r8yagura2", 1); } catch {}
  return R;
}
const rod = (K, p, y0) => yagura(K, p, y0) || K.fwd(p, 9, 0, 3);

/* ---------- 氷の 隠れ家（広間 か、かわりの セット）---------- */
const HALL8 = () => { try { const v = caveInfo(8); return v && v.built && v.hall ? v : null; } catch { return null; } };
function den(K, p) {
  const v = HALL8(), l = p.location;
  if (v && Math.hypot(l.x - v.hall.x, l.z - v.hall.z) <= (v.R || 12) + 1 && Math.abs(l.y - v.hall.y) <= 3) return { inH: true, v, bed: v.altar, pool: v.pool || null, entry: v.entry };
  const y0 = Y(K, p), FQ = fac(K, p, "b11den", "mc_den", 8, y0);
  const bed = facMark("b11den", "bed", p.location) || FQ || K.fwd(p, 8, 0);
  return { inH: false, v: null, bed, book: facMark("b11den", "book", p.location), map: facMark("b11den", "map", p.location), pool: null, entry: K.fwd(p, 7, 3) };
}
/* 薄い 氷（広間の 池を 本当に 割る。ほかの 人が 広間に いる ときは 割らない。場面の 終わりに 必ず もどす）*/
const BROKE = new Map();
function poolBreak(p, H) {
  try { const v = H.v; if (!v || !v.pool || BROKE.size) return false; if (world.getAllPlayers().some((q) => q.id !== p.id && Math.hypot(q.location.x - v.hall.x, q.location.z - v.hall.z) < (v.R || 12) + 2)) return false;
    const x = Math.floor(v.pool.x), y = Math.floor(v.hall.y) - 1, z = Math.floor(v.pool.z); world.getDimension("overworld").runCommand(`fill ${x - 1} ${y} ${z - 1} ${x + 1} ${y} ${z + 1} air replace ice`); BROKE.set(p.id, { x, y, z }); return true; } catch { return false; }
}
function poolFix(p) { const b = BROKE.get(p.id); if (!b) return; BROKE.delete(p.id); try { const D = world.getDimension("overworld"); for (const m of ["water", "flowing_water", "air"]) D.runCommand(`fill ${b.x - 1} ${b.y} ${b.z - 2} ${b.x + 1} ${b.y} ${b.z + 2} ice replace ${m}`); } catch {} }
const pondOf = (K, p) => { const a = facAt("r8pond", p.location, 60) || fac(K, p, "r8pond", "icepond", 8, Y(K, p)); return a ? facMark("r8pond", "ice", p.location) : null; };
const ROU = ["§9ロウ", "rou"], RUU = ["§dルウ", "ruu"], MASK = ["§7白い 仮面の 戦士", "argo"];
const tw = (K, p, w, walk = true) => K.npcNear(p, w[0], K.PJ(w[1], 10), !walk);

/* ---------- 町の 人 ---------- */
castAdd("b11_shirou", { nm: "シロウ", role: "山案内人", gobi: "だべさ", skin: "m6_eirik", town: TW.sanda, at: () => { const o = YAGURA(); return o ? { x: o.x + 3, z: o.z + 2 } : null; }, hide: (s) => !has(s, "b11e1"),
  pre: ["{smile}山の ことなら、おらに 聞くべさ！"],
  after: [
    [(s) => !!s.ending, ["{smile,tears}……双子が 帰って きたべさ。おら、手袋の 色を 見ないで 呼び分けたべさ。", "{smile}山では、帰って くるまでが 案内。……二人とも、ちゃんと 帰って きたべさ。"]],
    [doomed, ["{sad}……竜の 山で、あの 子が……聞いたべさ。", "{closed,up}泣いて いいべさ。山では、泣く 声も 道しるべに なるべさ。"]],
    [(s) => has(s, "b11e9") && s.ch && s.ch.c11 === "r", ["{smile,tears}ルウが あの 手袋を 持ってる。……それで いいべさ。あの 子の 手は、冷たく ならねえ。"]],
    [(s) => has(s, "b11e9"), ["{closed}その 手袋、あんたが 持っててけろ。……ルウの 手に 返す 日まで。"]],
    [(s) => has(s, "b11e8"), ["{sad}……顔が 雪より 白いべさ。雪山で、何か あったべさ？"]],
    [() => true, ["{smile}雷石を 取りに 行く 日は、おらが 案内するべさ！"]],
  ] });

bkAdd("b11", [
  /* ---------- 1話 雷雲の 里（r8e1 を 引きとる）---------- */
  { id: "b11e1", t: "雷雲の 里", place: YAGURA, F: ["F35"], battles: 0, set: { met8: 1 },
    hint: "§fらいうんの 里 §eサンダの 広場（雷祭りの やぐら）§f へ 行こう §7（右上の 案内）",
    syn: "雷祭りの 支度を する 里 サンダ。山案内人 シロウ「山では、帰って くるまでが 案内」。四年前の 夜、寄り合いが ルウを 遠くの 家へ やると 決め、双子が いなく なった。シロウが 母の 編み目で 編んだ、白と 黒の 手袋の 話。",
    async run(p, d, K) {
      const y0 = Y(K, p), c = p.location;
      festSet(p, "t_sanda", c, y0); const R = rod(K, p, y0);   /* 第126版(PV): 広場に 飾り（keep）*/
      await K.open(p, "らいうんの 里 サンダの 広場（雷祭りの 支度）", "day");
      thunder(K, p, R); snow(K, p, K.fwd(p, 6, 2), 10, 3);
      const eH = K.hero(p), eR = REI(K, p);
      const eS = K.cast(p, "b11_shirou"); K.act(eS, "raise");
      await K.csay(p, "b11_shirou", ["{smile,!}おーい！ そこの 旅の 人ー！ 雪の 中で 立ちんぼは、こごえるべさ！"], eH);
      K.act(eS, "hold"); K.hold(eS, "hammer");
      await K.csay(p, "b11_shirou", ["{smile}おら シロウ。この 里の 山案内人だべさ。", "{smile,♪}張り紙？ 山には 届かねえべさ。雪が ぜんぶ 隠すべさ。"]);
      if (ok(eS) && R) { await K.walkCam(p, eS, { x: R.x - 1.6, y: y0, z: R.z }, 16); K.act(eS, "work"); K.sound(p, "random.anvil_use", 0.6, 0.5); }
      await K.ots(p, eS, eH, 8);
      await K.hsay(p, V(K, ["{?}雷祭り？"], ["{?}雷祭り？"], ["{?}……雷祭り。"], ["{?}雷祭り、ですか？"]));
      await K.csay(p, "b11_shirou", ["{smile}冬の いちばん 寒い 晩に、やぐらで 雷太鼓を たたくべさ。", "{closed}裏山の 祠の 雷石を 太鼓に のせると、はじめの 雷が 鳴って、雪雲が 割れるべさ。"], eH);
      K.act(eS, "point"); await K.at(p, R, 14, 6, 0.5);
      await K.csay(p, "b11_shirou", ["{sad,…}……けど 今年は、山道が 雪崩で ふさがったべさ。"]);
      K.act(eS, 0);
      if (ok(eS) && ok(eH)) await K.approach(p, eS, eH, 1.9);
      await K.push(p, eS, 24, 4.5, 1.7);
      await K.csay(p, "b11_shirou", ["{?}……あんた、顔が 雪より 白いべさ。"], eH);
      await K.hsay(p, V(K, ["{sad,up}……町を 二つ、追い出されて きたの。"], ["{sad,up}……町を 二つ、追われて きたの。"], ["{closed,up}……町を 二つ 追われた。"], ["{sad,up}……町を 二つ、追われて まいりました。"]));
      K.act(eS, "kneel");
      await K.csay(p, "b11_shirou", ["{closed}……おらの おっとうも 山案内人 だったべさ。"], eH);
      await K.flashback(p, { label: "§7―― 十年前　サンダへの 山道", tod: "dusk", ptc: "snow",   /* 第127版: 山案内人の 最後を 絵で */
        actors: { f: { nm: "§e山案内人", job: K.PJ("m6_father", 8), at: [3.4, 0], look: [8, 0], hold: "staff" }, tr: { nm: "§7旅の 人", job: K.PJ("m6_mason", 8), at: [1.6, -1.2], look: "f" }, tr2: { nm: "§7旅の 子", job: 6, at: [1.4, 1], look: "f" } },
        beats: [
          ["narr", "§7吹雪の 山道。案内人を 先頭に、旅の 親子が 雪を 踏んで いた。", "f"],
          ["say", "f", "{closed}足もとを 見るべさ。山では、帰って くるまでが 案内だべさ。", "tr"],
          ["snd", "random.explode", 0.5], ["fx", "snow", [7, 0, 2]], ["fx", "snow", [6, 1, 3]],
          ["say", "tr", "{shock,!,up}雪崩だ……！", "f"],
          ["act", "f", "guard"],
          ["say", "f", "{angry,up}後ろへ！ 岩の 陰へ 走るべさ！", "tr"],
          ["go", "tr", [-3, -1.5], 12], ["go", "tr2", [-3, 1.2], 10],
          ["narr", "§7雪崩の 前に、両手を 広げて 立つ 山案内人の 背中。……それが、最後に 見えた 姿だった。", "f"],
        ] });
      await K.csay(p, "b11_shirou", ["{closed}……雪崩で 旅の 人を かばって、帰って こなかったべさ。", "{smile,up}口ぐせが あったべさ。『山では、帰って くるまでが 案内』。"]);
      await K.csay(p, "b11_shirou", ["{smile}……あんたの 旅も、帰って くるまでが 旅だべさ。な？"], eH);
      /* 双子と 手袋 */
      K.act(eS, "hold"); K.hold(eS, "glove");
      await K.push(p, eS, 22, 3.4, 1.2);
      /*F35*/ await K.narr(p, ["§7シロウの 手に、編みかけの 小さな 手袋。白い 毛糸と、黒い 毛糸。", "§7ひと目ごとに、同じ 結び目が 二つ ならぶ。……この 里の、母親の 編み方。"], eS);
      await K.csay(p, "b11_shirou", ["{closed,…}……おらには、弟と 妹が いたべさ。双子だべさ。白い 手袋の ロウと、黒い 手袋の ルウ。", "{sad}おっかあの 編み目で、おらが 編んで やったべさ。二人とも 片っぽずつ しか はめねえで、あいた 手で 手ぇ つないでたべさ。"]);
      K.turn(eS, K.fwd(p, 20, -8, 6));
      await K.flashback(p, { label: "§7―― 四年前　らいうんの 里の 寄り合い", tod: "night", ptc: "snow",   /* 第127版: 双子が 里を 出た 夜を 絵で */
        actors: { el: { nm: "§7里の 年寄り", job: K.PJ("m6_gramps", 8), at: [5, 0], look: [2.4, 0] }, ro: { nm: "§b八つの ロウ", job: K.PJ("rou", 6), at: [2.4, -0.6], look: "el", hold: "glove" }, ru: { nm: "§b八つの ルウ", job: K.PJ("ruu", 6), at: [2.4, 0.6], look: "el" } },
        beats: [
          ["narr", "§7四年前の 冬。寄り合いの 囲炉裏の 向こうで、年寄りが 双子を 見おろして いた。", "el"],
          ["say", "el", "{angry,low}双子は 不吉じゃ。……ルウは、遠くの 家へ やる。寄り合いで 決めた ことじゃ。", "ru"],
          ["say", "ru", "{angry,up}いやだもん！ ロウと 離されるなら、ここで 氷に なった ほうが ましだもん！", "el"],
          ["say", "ro", "{closed}……ルウ。手は、はなさないよ。", "ru"],
          ["go", "ro", [-2, -0.5], 14], ["go", "ru", [-2.2, 0.6], 8],
          ["narr", "§7その 夜、二人は 雪の 中へ 出て いった。白い 手袋と 黒い 手袋の 片方ずつで、あいた 手を つないで。", [-1, 0, 1]],
          ["fx", "snow", [0, 0, 0.3]],
          ["narr", "§7……雪の 道に、黒い 手袋が 片っぽ 落ちて いた。", [0, 0.6, 0.2]],
        ] });
      await K.csay(p, "b11_shirou", ["{sad,up}『双子は 不吉だ』って、年寄りが 騒いで……寄り合いが、ルウを 遠くの 家へ やると 決めたべさ。", "{closed}その 夜、二人とも いなく なったべさ。……雪の 中で、ルウの 右手の 黒い 手袋が 片っぽ 見つかった だけだべさ。"]);
      K.turn(eS); K.hold(eS); K.act(eS, 0);
      await K.hsay(p, V(K, ["{sad,up}……その 手袋は？"], ["{sad,up}……その 手袋は、今は？"], ["{closed,?}……その 手袋は。"], ["{sad,up}……その 手袋は、今……？"]), eS);
      await K.csay(p, "b11_shirou", ["{closed,up}裏山の 祠の 綱に 結んで あるべさ。……あの 子らが 帰り道で 見つけられる ように。"]);
      await K.say(p, "レイ", ["{closed}……帰って くるまでが 案内、か。"], eS);
      await K.csay(p, "b11_shirou", ["{smile,arms}よし！ あした、山道の 雪崩を 掘りに 行くべさ。手伝って くれるべさ？"], eH);
      await K.hsay(p, V(K, ["{smile,nod}うん！ 掘る！"], ["{smile,nod}ええ。お手伝い するわ。"], ["{closed,nod}……行く。"], ["{smile,nod}はい、お手伝い します。"]));
      if (!ok(p)) return false;
      K.pay(p, { id: "b11e1" }, 300, [["mei_frost", 1]]);
      await K.end(p, { leave: [eS, eR], card: "§7→ §eサンダへの 山道§7 で 雪崩の 救助（右上の 案内）", kind: "day" });
      return true;
    } },
  /* ---------- 2話 雪崩の 救助（r8e2 を 引きとる。ズズの 告白）---------- */
  { id: "b11e2", pv: 127, t: "雪崩の 救助", place: ROAD, fac: "r8snow", F: ["F44"], battles: 1, set: { met8: 1, zuzu8: 1 },
    hint: "§fサンダと 氷雷の 城の あいだ §eサンダへの 山道§f へ 行こう §7（雪崩に うまった 人を 助ける）",
    syn: "山道の 雪崩から 行商人を 掘りだした。雪の 主は 子どもたちを 守って いた。ズズが 告白した。「この 雪崩の 爆薬は、六影に いた ころの オレが しかけた。『雪山の 上で、えらい 人が 何かを 守ってる』と 言われて」。",
    async run(p, d, K) {
      fac(K, p, "r8snow", "snowpile", 8, Y(K, p));
      await K.open(p, "サンダへの 山道（雪崩の あと）", "day");
      const mound = facMark("r8snow", "mound", p.location) || K.fwd(p, 7, 2.5);
      snow(K, p, mound, 12, 2.5);
      const eH = K.hero(p), eS = K.cast(p, "b11_shirou");
      await K.csay(p, "b11_shirou", ["{closed}……しっ。声が するべさ。"], eH);
      K.sound(p, "mob.villager.hit", 0.7, 0.4); await K.at(p, mound, 14, 5, 0.6);
      await K.say(p, "雪の 下の 声", ["{sad}……た……すけ……て……"]);
      await K.hsay(p, V(K, ["{shock,!,up}いた！ 雪の 下！ 掘ろう、シロウさん！"], ["{shock,!,up}雪の 下よ！ 掘りましょう！"], ["{shock,!,up}……下に いる。掘る。"], ["{shock,!,up}雪の 下です！ 掘りましょう！"]));
      if (ok(eH)) await K.walkCam(p, eH, { x: mound.x - 1.6, y: mound.y, z: mound.z }, 14);
      K.act(eH, "kneel"); K.act(eS, "kneel");
      for (let k = 0; k < 3; k++) { snow(K, p, mound, 8, 1.2); K.sound(p, "dig.snow", 1); await K.wait(6); }
      await K.narr(p, ["§7手で 雪を かいた。指先の 感覚が なくなっても、かいた。", "§7……雪の 下から、手袋の 指先が 見えた。"], mound);
      K.cmd(p, "camera @s fade time 0.3 0.4 0.4 color 240 245 255"); await K.wait(8);
      const eT = K.npcNear(p, "§f旅の 行商人", K.PJ("m6_hector", 9), true); K.act(eT, "kneel"); K.act(eH, 0); K.act(eS, 0);
      await K.say(p, "旅の 行商人", ["{sad,…}……あ、ありがてえ……三日、雪の 中で……", "{sweat,汗,up}……気を つけろ。あの 主が、まだ 近くに……！"], eH);
      const big = K.fwd(p, 9, -3), eB = K.monEnt(p, big, K.wildSp("beast", "L"), "§b雪の 主");
      K.sound(p, "mob.polarbear.warning", 1); K.shake(p, 0.5, 0.5); snow(K, p, big, 10, 2);
      if (ok(eB)) await K.at(p, eB.location, 14, 6, 1.6);
      await K.csay(p, "b11_shirou", ["{shock,!,up}雪の 主だべさ！ 雪崩で 気が 立ってるべさ！"]);
      if (!K.flag(p, "b11e2w")) {
        K.rmCine(eB);
        const r = await K.battle(p, K.bossOne(["beast", "aqua"], 62, 12), { name: "雪崩で 気が 立った 雪の 主", arena: "雪崩の 救助", theme: "snow", hpk: 2, speaker: "雪の 主", lines: { half: "……グルル……", low: "……クゥン……" } });
        if (r !== "win") { await K.sayAt(p, "§e山案内人 シロウ", K.PJ("m6_eirik", 9), "シロウ", ["{sweat,汗}いったん 下がるべさ！ 雪の 主は、山の 神さまの 使いだべさ……！"]); return false; }
        K.setFlag(p, "b11e2w");
      } else K.rmCine(eB);
      const kq = K.fwd(p, 6, -2); snow(K, p, kq, 8, 1); K.sound(p, "mob.polarbear_baby.idle", 1);
      const eK1 = K.monEnt(p, kq, K.wildSp("beast"), ""), eK2 = K.monEnt(p, K.fwd(p, 6, -0.8), K.wildSp("beast"), "");
      K.burst(p.dimension, kq, "minecraft:heart_particle", 4, 0.6, 0.8);
      if (ok(eK1)) await K.push(p, eK1, 22, 4.5, 1.2);
      await K.hsay(p, V(K, ["{sad,tears,up}……守ってたんだ。この 子たちを。……ごめんね。"], ["{sad,tears,up}……この 子たちを、守って いたのね。"], ["{sad,up}……守ってたのか。……悪かった。"], ["{sad,tears,up}……この 子たちを、お守りに なって いたのですね。"]));
      const run = []; for (const e of [eK1, eK2]) if (ok(e)) run.push((async () => { const q = K.away(e, p, 10); if (q) await K.go(e, q, 22); K.rmCine(e); })());
      await K.pull(p, K.S(p) && K.S(p).Cn, 30); await Promise.all(run);
      /* ズズの 告白 */
      const eZ = K.cast(p, "b09_zuzu"); K.act(eZ, "kneel");
      await K.up(p, eZ, 12);
      await K.csay(p, "b09_zuzu", ["{cry,tears}……ずびっ。この 雪崩、オレの せいだ。", "{sad,up}六影に いた ころ、上の 命令で この 山道に 爆薬を しかけた。……今ごろ 崩れた。"], eH);
      await K.hsay(p, V(K, ["{shock,?,up}……命令って、なんて？"], ["{shock,?}……なんて 命令だったの？"], ["{closed,?}……なんの 命令だ。"], ["{shock,?}……どんな ご命令 だったのですか？"]), eZ);
      /*F44*/ await K.csay(p, "b09_zuzu", ["{closed,low}『雪山の 上で、えらい 人が 何かを 守ってる。だれも 山に 近づけるな』。", "{sad}……何を 守ってるのかは、下っぱには 教えて もらえなかった。ずびっ。"]);
      await K.say(p, "旅の 行商人", ["{closed}……あんた、正直だね。雪の 中で、わしと 同じ ように 震えてる 顔だ。"], eZ);
      await K.push(p, eS, 22, 4.2, 1.7);
      await K.csay(p, "b11_shirou", ["{angry,up}山では、敵も 味方も ねえべさ。", "{smile,arms}……なら、雪かきを 手伝うべさ。山道を 開けるまでが、つぐないだべさ！"], eZ);
      await K.csay(p, "b09_zuzu", ["{smile,tears,nod,up}……おう。……ずびっ。"]);
      if (!ok(p)) return false;
      K.pay(p, { id: "b11e2" }, 500, [["c_herbs", 2], ["mei_frost", 1]]);
      await K.end(p, { leave: [eS, eZ], bye: [eT], card: "§7→ 裏山の §e雷神の 祠§7 へ。雷祭りの 雷石を 取りに 行こう", kind: "day" });
      return true;
    } },
  /* ---------- 3話 ふたつの 声（r8e3 を 引きとる。本物の 雪庇・祠の 綱の 黒い 手袋）---------- */
  { id: "b11e3", pv: 127, t: "ふたつの 声", place: HOKORA, fac: "r8hokora", F: ["F35", "F49"], keys: ["k_glove"], battles: 0, set: { met8: 1, stone8: 1 },
    hint: "§fサンダの 裏山 §e雷神の 祠§f へ 行こう §7（雷祭りの 雷石を 取りに 行く）",
    syn: "祠の 綱に、黒い 右手の 手袋が 結ばれて いた。拾うと、姿の 見えない 声が「……そこ、雪庇だよ。止まって」。足もとが 崩れた。もう 一つの 声「帰ってって 言ってるんだもん！」。白い 仮面「……帰れ」。",
    async run(p, d, K) {
      const FQ = fac(K, p, "r8hokora", "shrine", 8, Y(K, p));
      fac(K, p, "r8cliff", "cornice", 8, Y(K, p));
      const EDGE = facMark("r8cliff", "edge", p.location), LIP = facMark("r8cliff", "lip", p.location);
      await K.open(p, "雷神の 祠（ふぶき）", "snow");
      K.mood(p, "shadow");
      if (FQ) await K.at(p, FQ, 14, 8, 1.6);
      snow(K, p, K.fwd(p, 5, 0), 14, 4);
      const eH = K.hero(p), eS = K.cast(p, "b11_shirou");
      await K.csay(p, "b11_shirou", ["{sweat,汗}……吹雪が ひどく なって きたべさ。おらの 背中から はなれるでねえべさ。"], eH);
      /* 綱の 手袋 */
      const ston = facMark("r8hokora", "stone", p.location) || K.fwd(p, 7, -3);
      await K.at(p, ston, 16, 7, 2.4);
      await K.narr(p, ["§7祠の 綱に、小さな 黒い 手袋が 一つ、結ばれて いる。右手の ほう。", "§7雪を かぶって 固く なって いても、白と 黒の 結び目が 二つずつ ならんで いた。"], ston);
      K.act(eS, "hold"); K.hold(eS, "glove");
      await K.csay(p, "b11_shirou", ["{sad,up}……ルウの 手袋だべさ。春に 雪の 中から 掘り出して、ここに 結んだべさ。", "{closed}……綱から ほどいたべさ。持って いって けろ。あんたらの 方が、あの 子らに 会える 気が するべさ。"], eH);
      if (ok(eS) && ok(eH)) await K.approach(p, eS, eH, 1.3, 10);
      await K.give(eS, eH, "glove"); K.act(eS, 0);
      K.act(eH, "hold"); await K.up(p, eH, 10);
      K.key(p, "k_glove");
      K.act(eH, 0);
      /* 崖の ふちへ。ふたつの 声 */
      if (ok(eH)) { const q = EDGE ? { x: EDGE.x - (EDGE.x - p.location.x) * 0.25, y: EDGE.y, z: EDGE.z - (EDGE.z - p.location.z) * 0.25 } : K.fwd(p, 3.5, 0.5); if (q) await K.walkCam(p, eH, q, 18); }
      K.sound(p, "note.chime", 1, 0.4);
      await K.say(p, "しずかな 声", ["{closed}……そこ、雪庇だよ。止まって。"], eH);
      await K.push(p, eH, 20, 4.2, 1.7);
      await K.hsay(p, V(K, ["{shock,?,up}……え？ だれ？ ……止まる！"], ["{shock,?,up}……だれ？ ……止まるわ。"], ["{closed,?}……だれだ。……止まる。"], ["{shock,?,up}……どなた？ ……止まります！"]));
      K.act(eH, "guard");
      const cliff = LIP || K.fwd(p, 6.5, 0.5);
      if (LIP) facState("r8cliff", 1);   /* 張り出した 雪が 本当に 崩れ落ちる */
      K.sound(p, "random.explode", 0.5); K.shake(p, 0.7, 0.7); snow(K, p, cliff, 16, 2.4);
      await K.at(p, cliff, 16, 5, 0.2);
      await K.csay(p, "b11_shirou", ["{shock,!,up}せ、雪庇が 落ちたべさ……！ あと 一歩 出てたら……！"]);
      await K.say(p, "とがった 声", ["{angry,!}帰ってって 言ってるんだもん！ ここから 先は、来ちゃ だめなんだもん！"], eH);
      K.act(eH, 0);
      await K.narr(p, ["§7返事を さがしても、吹雪の 音だけ。", "§7雪の 上に、小さな 足あとが 二つ。ぴったり ならんで、山の 上へ つづいて いる。"], cliff);
      K.act(eS, "kneel"); await K.push(p, eS, 22, 4.2, 1.7);
      await K.csay(p, "b11_shirou", ["{shock,…,tears}……今の 声……『だもん』……ルウの 口ぐせだべさ……", "{closed,up}……生きてるべさ。あの 子ら、生きてるべさ……！"]);
      K.act(eS, 0);
      /* 白い 仮面 */
      K.cmd(p, "stopsound @s");
      const eA = K.npcNear(p, MASK[0], K.PJ(MASK[1], 10)); K.act(eA, "hold");
      snow(K, p, ok(eA) ? eA.location : null, 10, 1.4);
      await K.low(p, eA, 18);
      /*F49*/ await K.say(p, "白い 仮面の 戦士", ["{closed,low}…………帰れ。"], eH);
      await K.hsay(p, V(K, ["{angry,!,up}……あなた、だれ！？ あの 声の 子たちと、どういう 関係！？"], ["{angry,!,up}……あなたは だれ？ あの 子たちと、どういう 関係なの！？"], ["{angry,up}……だれだ。あの 声と 何の 関係が ある。"], ["{angry,!,up}……どなたですか！？ あの 子たちと、どういう ご関係なのですか！"]), eA);
      K.re(eA, "closed", "…");
      await K.say(p, "白い 仮面の 戦士", ["{closed,low}……山の 上の 子らに、近づくな。"], eH);
      await K.ots(p, eA, eS, 8);
      await K.csay(p, "b11_shirou", ["{angry,…,up}……あんた、あの 子らの 何だべさ！"], eA);
      if (ok(eA)) { K.turn(eA, cliff); await K.at(p, cliff, 12, 6, 2); }
      await K.narr(p, ["§7仮面の 戦士は 答えず、足あとの つづく 山の 上を、しばらく 見て いた。", "§7それから、吹雪の 中へ 歩いて 消えた。"], eA);
      await walkOff(K, p, eA, 12);
      /* 雷石 */
      thunder(K, p, ston, true); K.act(eS, "hold"); K.hold(eS, "orb");
      await K.csay(p, "b11_shirou", ["{smile}……雷石だべさ。あんたが 持つべさ。"], eH);
      if (ok(eS) && ok(eH)) await K.approach(p, eS, eH, 1.3, 10);
      await K.give(eS, eH, "orb"); K.act(eS, 0); K.act(eH, "raise"); await K.up(p, eH, 12);
      await K.hsay(p, V(K, ["{smile,up}雷石、とれた。……あったかい。雷なのに。", "{closed,up}……行こう。足あとの 先へ。"], ["{smile,up}雷石……とれたわ。あたたかいのね。", "{closed,up}……行きましょう。足あとの 先へ。"], ["{closed}……とれた。あたたかい。", "{closed}足あとの 先へ 行く。"], ["{smile,up}雷石、お預かり しました。……あたたかい です。", "{closed,up}……参りましょう。足あとの 先へ。"]));
      K.hold(eH); K.act(eH, 0);
      await K.csay(p, "b11_shirou", ["{smile,tears,up}山では、帰って くるまでが 案内だべさ。……雷祭りの 晩には、ぜったい 帰って くるべさ。"]);
      if (!ok(p)) return false;
      K.pay(p, { id: "b11e3" }, 600, [["mei_frost", 1], ["c_herbs", 2]]);
      await K.end(p, { leave: [eS], card: "§7→ 足あとの 先、§e六影の 氷の 隠れ家§7 へ（白銀の 雪原の そば、紫の 灯の 氷の 門）", kind: "snow" });
      return true;
    } },
  /* ---------- 4話 くっつけた 寝床（MQ19 隠れ家の 入口）---------- */
  { id: "b11e4", t: "二つの 寝床", F: ["F06", "F44", "F67"], battles: 0, set: { ch9a: 1 },
    hint: "§fフロストヘイム雪山の §e六影の 氷の 隠れ家§f へ 行こう §7（白銀の 雪原の そば、紫の 灯の 氷の 門。部屋を 下りきった 大広間）",
    syn: "隠れ家の 奥に、くっつけて 置いた 寝床が 二つ。竜の 絵本。壁の 暦の「竜祭りの 夜」に 丸、横に ラグナの 地図。ロウ「セオさまは、儀式の 日に 迎えに 来るって 言ったよ」。",
    async run(p, d, K) {
      const H = den(K, p);
      await K.open(p, H.inH ? "六影の 氷の 隠れ家" : "雪山の 氷の 隠れ家", "snow");
      const eH = K.hero(p), eR = REI(K, p);
      const bed = H.bed;
      await K.at(p, bed, 18, 5, 0.6);
      await K.narr(p, ["§7氷の 部屋の 奥に、寝床が 二つ。すき間なく、くっつけて 置いて ある。", "§7青い 毛布と、桃色の 毛布。枕は、まん中で 触れ合って いた。"], bed);
      K.act(eH, "point");
      /*F06*/ await K.hsay(p, V(K, ["{sad}……台の 上に 絵本。竜が 星を さがす お話。", "{closed}ルミエで、ピピちゃんが 持ってた のと 同じ 本……。"], ["{sad}……絵本ね。竜が 星を さがす お話。", "{closed}ピピちゃんが 持って いた 本と、同じ……"], ["{closed}……絵本。竜が 星を さがす 話。", "{closed}ピピが 持ってた 本と 同じ。"], ["{sad}……絵本が あります。竜が 星を さがす お話。", "{closed}ピピさんが 持って いらした ご本と、同じ……"]), H.book || bed);
      K.act(eH, 0);
      const M = H.map || { x: bed.x + 1.5, y: bed.y + 1.4, z: bed.z + 1 };
      await K.at(p, M, 16, 2.6, 0.6);
      /*F67*/ await K.narr(p, ["§7壁に、手書きの 暦。冬の ある 一日に、赤い 丸。横に『§c竜祭りの 夜§7』。", "§7丸の 横に、北の 果ての 地図が 貼って ある。……竜の 骨の 形の 山。ラグナ。"], M);
      await K.say(p, "レイ", ["{closed,low}……ズズが 言ってた『えらい 人が 守ってる もの』。", "{sad}……守ってたのは、子どもの 寝床か。"], eH);
      /*F44*/ await K.hsay(p, V(K, ["{sad,up}……ここに、子どもが 二人で 住んでるんだ。"], ["{sad,up}……ここで、子どもが 二人 暮らして いるのね。"], ["{closed}……子どもが 二人、ここで 寝てる。"], ["{sad,up}……ここで、子どもが お二人で 暮らして いるのですね。"]), eR);
      const eO = tw(K, p, ROU); K.act(eO, "hold");
      await K.say(p, "白い 手袋の 子", ["{closed}……さわらないで。それ、ボクたちの だよ。"], eH);
      await K.up(p, eO, 12);
      await K.say(p, "白い 手袋の 子", ["{closed,up}セオさまは、儀式の 日に 迎えに 来るって 言ったよ。", "{closed}それまで、だれも 上げるなって。"]);
      await K.hsay(p, V(K, ["{shock,!}……セオさんが？ 儀式って……竜祭りの 夜の こと？"], ["{shock}……セオさんが？ 儀式って、竜祭りの 夜の こと？"], ["{shock}……セオが。儀式は 竜祭りの 夜か。"], ["{shock}……セオさんが？ 儀式とは、竜祭りの 夜の ことですか？"]), eO);
      await K.say(p, "白い 手袋の 子", ["{closed}……言わないよ。"]);
      if (!ok(p)) return false;
      await K.end(p, { bye: [eO], kind: "snow", t: 24 });
      return true;
    } },
  /* ---------- 5話 白黒の 片手袋（名乗り）---------- */
  { id: "b11e5", t: "白黒の 片手袋", F: ["F36"], battles: 0, set: { ch9b: 1 },
    hint: "§f六影の 氷の 隠れ家の §e広間§f で",
    syn: "双子が 名乗った。白い 手袋の ロウ、黒い 手袋の ルウ。つないだ 素手に、白と 黒の 指輪の 半分。ルウ「見分けられない 大人は、ボクたちを 一つにしか 見ないんだもん」。レイ「……鍵だ。二人で 一本の」。",
    async run(p, d, K) {
      const H = den(K, p);
      await K.open(p, H.inH ? "隠れ家の 氷の 広間" : "氷の 隠れ家", "snow");
      const eH = K.hero(p), eR = REI(K, p), bed = H.bed;
      const eO = await K.put(p, ROU[0], { x: bed.x - 0.7, y: bed.y, z: bed.z }, null, K.PJ(ROU[1], 10)), eU = await K.put(p, RUU[0], { x: bed.x + 0.7, y: bed.y, z: bed.z }, null, K.PJ(RUU[1], 10));
      K.act(eO, "hold"); K.act(eU, "hold");
      await K.at(p, bed, 16, 6, 1.4);
      await Promise.all([K.go(eO, K.fwd(p, 5, -0.6), 22), K.go(eU, K.fwd(p, 5, 0.6), 22)]);
      await K.sixMark(p, eO, "twins");
      await K.cut(p, "ロウ");
      await K.say(p, "ロウ", ["{closed}……ボクは、ロウだよ。祠で『止まって』って 言ったのも、ボクだよ。"], eH);
      await K.say(p, "ルウ", ["{angry}ボクは ルウだもん。……『帰って』って 言ったのに、来たんだもん。"], eH);
      if (ok(eU)) { K.camNear(p, eU, 1.6, 1.0, 0.5); await K.wait(12); }
      /*F36*/ await K.narr(p, ["§7白い 手袋は ロウの 右手に。黒い 手袋は ルウの 左手に。", "§7手袋の ない 手どうしを、素手で つないで いる。重なった 指に、白と 黒の 指輪の 半分が 光った。"], eU);
      await K.hsay(p, V(K, ["{sad,up}……シロウさんの 編み目だ。里の 人は、二人の こと 一回も 見分けて くれなかったの？"], ["{sad,up}……シロウさんの 編み目ね。里の 人は、あなたたちを 見分けて くれなかったの？"], ["{closed,up}……シロウの 編み目。里の 大人は、見分けなかったのか。"], ["{sad,up}……シロウさんの 編み目ですね。里の 方々は、お二人を 見分けて くださらなかったの？"]), eU);
      await K.say(p, "ルウ", ["{angry,up}見分けられない 大人は、ボクたちを 一つにしか 見ないんだもん。", "{angry}だから 片っぽずつ はめてるんだもん。白が ロウ、黒が ボク。"]);
      await K.say(p, "ロウ", ["{closed}……セオさまは、一回も まちがえなかったよ。だから ここに いるんだよ。"]);
      await K.ots(p, eR, eO, 10);
      await K.say(p, "レイ", ["{closed,low}……その 指輪。片方ずつじゃ 何も 開かない 形だ。", "{shock}……鍵だ。二人で 一本の。"], eO);
      await K.say(p, "ルウ", ["{angry,!,up}ロウと 離されるくらいなら、ここで 氷に なったほうが ましだもん！"]);
      await K.say(p, "ロウ", ["{closed}……ルウ。手は、はなさないよ。"]);
      if (!ok(p)) return false;
      await K.end(p, { kind: "snow", t: 20 });
      return true;
    } },
  /* ---------- 6話 双子との 戦い ---------- */
  { id: "b11e6", t: "二体が 同時に", battles: 1, set: { ch9c: 1 },
    hint: "§f六影の 氷の 隠れ家の §e広間§f で 双子と 戦う",
    syn: "双子との 戦い。二体が 同時に 動いた。",
    async run(p, d, K) {
      const H = den(K, p);
      await K.open(p, H.inH ? "隠れ家の 氷の 広間" : "氷の 隠れ家", "snow");
      const eH = K.hero(p), eR = REI(K, p);
      const eO = tw(K, p, ROU, false), eU = tw(K, p, RUU, false);
      K.act(eO, "guard"); K.act(eU, "guard");
      await K.say(p, "ロウ", ["{closed}……ここから 先へは、行かせないよ。"], eH);
      await K.say(p, "ルウ", ["{angry}ロウと ボクを、引きはなしに 来たんでしょ！"], eH);
      await K.say(p, "レイ", ["{angry}……来るぞ。二人で 一つの 動きだ。"], eH);
      if (!K.flag(p, "b11e6w")) {
        await K.duel(p, "§9§l双子", H.inH ? "§f氷の 広間で 二体が 同時に 動く！" : "§f氷の 部屋で 二体が 同時に 動く！", { fams: ["beast", "aqua"] });
        const lv = 66;
        const r = await K.battle(p, K.team(["beast", "aqua", "dragon"], lv, 4, 64), { name: "六影 四・五の座 白黒の 片手袋", arena: H.inH ? "氷の 広間" : "氷の 隠れ家", theme: "icepeak", hpk: 5, extra: 0.4, tag: "四・五の座", sboss: true, speaker: "ロウ＆ルウ", guests: K.team(["dragon", "animal"], lv, 2, 20).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "ルウ、そこは 氷が 厚いよ！ ――うん、ロウ！", low: "……手、はなさないで……！" } });
        if (r !== "win") { await K.sayAt(p, "§bレイ", 17, "レイ", ["{sweat,汗}……すまん、今のは オレの せいだ。もう一度 行こう。"]); return false; }
        K.setFlag(p, "b11e6w");
      }
      K.act(eO, "kneel"); K.act(eU, "kneel");
      await K.two(p, eO, eU, 14);
      await K.say(p, "ルウ", ["{cry,!}……負けたんだもん……ロウ、どうしよう……"]);
      await K.say(p, "ロウ", ["{closed}……だいじょうぶ。まだ、手は つないでるよ。"]);
      if (!ok(p)) return false;
      await K.end(p, { kind: "snow", t: 16 });
      return true;
    } },
  /* ---------- 7話 黒い 水（本物の 薄い 氷）---------- */
  { id: "b11e7", t: "黒い 水", F: ["F37", "F49"], battles: 0,
    hint: "§f六影の 氷の 隠れ家の §e広間§f で",
    syn: "こわく なった ルウが セオの もとへ 逃げようと 薄い 氷へ 走った。ロウは ルウを 岸へ 押し戻し、自分が 黒い 水に 落ちた。仮面の 戦士が 飛び降りて 引き上げた。ロウは 息を して いるが、目を 開けない。入口の 暗がりに セオ。仮面「……来るな、参謀。おまえが 近づくほど、この 子らは 知る」。",
    async run(p, d, K) {
      const H = den(K, p);
      try {
        await K.open(p, H.inH ? "隠れ家の 氷の 広間" : "氷の 隠れ家", "snow");
        const eH = K.hero(p), eR = REI(K, p);
        const eO = tw(K, p, ROU, false), eU = tw(K, p, RUU, false);
        K.act(eO, "kneel"); K.act(eU, "kneel");
        const IP = H.pool ? null : pondOf(K, p), ice = H.pool || IP || K.fwd(p, 8, -2);
        if (IP) await K.at(p, IP, 12, 6, 0.4);
        await K.say(p, "ルウ", ["{cry,!,up}……やだ。セオさまの ところへ 行くんだもん！ ロウ、逃げよう！"]);
        K.act(eU, 0); if (ok(eU) && ice) { const l = eU.location, n = Math.hypot(ice.x - l.x, ice.z - l.z) || 1; K.go(eU, { x: ice.x - ((ice.x - l.x) / n) * 1.4, y: l.y, z: ice.z - ((ice.z - l.z) / n) * 1.4 }, 12, true); }
        await K.cut(p, "ロウ");
        await K.say(p, "ロウ", ["{shock,!,up}……ルウ、そっちは だめだよ。氷が 薄いよ。"]);
        K.act(eO, 0); if (ok(eO) && ice) await K.go(eO, ice, 12, true);
        if (ok(eU) && ok(eO)) { K.act(eO, "give", false); const l = eU.location, o = eO.location; K.go(eU, { x: l.x + (l.x - o.x) * 1.4, y: l.y, z: l.z + (l.z - o.z) * 1.4 }, 6); }
        if (IP) facState("r8pond", 1);
        const broke = !!((H.pool && poolBreak(p, H)) || IP);
        K.sound(p, "random.glass", 1.2); K.shake(p, 0.4, 0.4); K.burst(p.dimension, ice, "minecraft:white_smoke_particle", 10, 1, 0.1);
        K.big(p, "§b§l氷が 割れる", "§fロウの 足もとが 割れて、黒い 水が 口を あけた", "random.glass");
        if (ok(eO)) { const l = eO.location; K.burst(p.dimension, l, "minecraft:white_smoke_particle", 12, 0.6, 0.2); const soft = (y) => { try { const b = p.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(y), z: Math.floor(l.z) }); return !b || b.isAir || b.isLiquid; } catch { return false; } }; if (broke && soft(l.y - 2.2) && soft(l.y - 1)) try { eO.teleport({ x: l.x, y: l.y - 2.2, z: l.z }); } catch {}   /* 第127版: 割れた 水の 中へ だけ 沈む（氷・岩の 中に 入らない）*/ await K.wait(6); if (ok(eO)) { K.burst(p.dimension, eO.location, "minecraft:white_smoke_particle", 10, 0.6, 0.2); K.rm(eO); } }
        if (ok(eH)) { const q = { x: ice.x + 2.4, y: ice.y, z: ice.z - 0.8 }; await K.go(eH, q, 8, true); }
        if (ok(eR) && ok(eH)) { const l = eH.location; await K.go(eR, { x: l.x - 0.6, y: l.y, z: l.z - 0.6 }, 6, true); K.act(eR, "hold"); K.act(eH, "recoil"); }
        await K.say(p, "レイ", ["{angry,!,up}ばか、おまえまで 落ちるぞ！"]);
        K.act(eH, 0); K.act(eR, 0);
        await K.say(p, "ルウ", ["{shock,…}……ロウ？", "{cry,tears,up}ボクが『逃げよう』って 言ったから……ロウが、ボクを 押して……"]);
        /* 仮面の 戦士 */
        const tp = (k, sd = 0) => { const l = p.location, dx = l.x - ice.x, dz = l.z - ice.z, n = Math.hypot(dx, dz) || 1; return { x: ice.x + (dx / n) * k - (dz / n) * sd, y: ice.y, z: ice.z + (dz / n) * k + (dx / n) * sd }; };
        const eX = await K.put(p, MASK[0], tp(2.2, 1), null, K.PJ(MASK[1], 10));
        if (ok(eX)) { const l = eX.location; try { eX.teleport({ x: l.x, y: l.y + 3, z: l.z }); } catch {} await K.go(eX, l, 6); K.burst(p.dimension, l, "minecraft:white_smoke_particle", 8, 1, 0.1); K.sound(p, "random.anvil_land", 1.4); K.shake(p, 0.25, 0.3); }
        K.act(eX, "kneel"); if (ok(eX)) { K.camNear(p, eX, 2.6, 0.6); K.burst(p.dimension, ice, "minecraft:white_smoke_particle", 8, 0.6, 0.1); await K.wait(14); }
        const eO2 = await K.put(p, "§9ロウ", tp(2.4, -1), null, K.PJ(ROU[1], 10)); K.act(eO2, "down"); K.act(eX, "hold");
        if (ok(eO2)) await K.at(p, eO2.location, 14, 2.4, 0.4);
        await K.narr(p, ["§7引き上げられた ロウの 唇から、白い 息が 出る。", "§7……けれど、まぶたは 閉じた まま。黒い 水の しずくが、文字の ように 頬を 流れて 消えた。"], eO2);
        await K.hsay(p, V(K, ["{sad,?}……息は してる。でも、目を 開けない……。"], ["{sad,?}……息は してるわ。でも、目を 開けないの……。"], ["{sad}……息は ある。目は 開かない。"], ["{sad,?}……息は あります。でも、目を 開けません……。"]), eO2);
        if (ok(eU) && ok(eX)) { const l = eX.location; await K.go(eU, { x: l.x - 0.7, y: l.y, z: l.z }, 8, true); K.act(eU, "hold"); }
        await K.say(p, "ルウ", ["{cry,tears,up}……ロウ。……起きてよ。……起きてって 言ってるんだもん。"]);
        /* 入口の 暗がりの セオ */
        const ent = H.entry ? { x: H.entry.x, y: H.entry.y, z: H.entry.z + 1.5 } : K.fwd(p, 11, 4);
        const eT = await K.put(p, "§5セオ", ent, null, 18);
        if (ok(eT) && ok(eX)) { K.camNear(p, eX, 2.4, 1.6); await K.wait(12); K.camNear(p, eT, 3.5, 1.4); await K.wait(16); }
        await K.hsay(p, V(K, ["{shock,!}……入口の 暗がりに、セオさん……！"], ["{shock,!}……入口の 暗がりに、セオさん……？"], ["{shock,!}……入口の 暗がり。セオ。"], ["{shock,!}……入口の 暗がりに、セオさんが……！"]), eT);
        await K.say(p, "セオ", ["{shock,!,up}ロウ……！"]);
        if (ok(eX)) await K.up(p, eX, 8);
        /*F37 F49*/ await K.say(p, "白い 仮面の 戦士", ["{angry,low}……来るな、参謀。おまえが 近づくほど、この 子らは 知る。"], eT);
        if (ok(eT)) await K.up(p, eT, 8);
        await K.say(p, "セオ", ["{sad}……僕は、迎えに 来ただけです。"]);
        await K.say(p, "白い 仮面の 戦士", ["{closed,low}……儀式の 日までは、我が 預かる。"]);
        if (ok(eT)) { K.re(eT, "sad", "…"); await K.narr(p, ["§7セオは こちらを 見て……目を そらした。外套の 肩に、雪が 積もって いた。"], eT); await walkOff(K, p, eT, 10); }
        if (!ok(p)) return false;
        await K.end(p, { kind: "snow", t: 16 });
        return true;
      } finally { poolFix(p); }
    } },
  /* ---------- 8話 手袋（選択 C11）---------- */
  { id: "b11e8", t: "黒い 手袋", F: ["F35"], battles: 0,
    hint: "§f六影の 氷の 隠れ家の §e広間の 出口§f で",
    syn: "ルウが 仮面の 外套に しがみついた。祠で 拾った 黒い 右手の 手袋を、ルウに 渡すか、持って おくか。仮面の 戦士は 双子を 連れて 吹雪へ 消えた。",
    async run(p, d, K) {
      const H = den(K, p);
      await K.open(p, H.inH ? "隠れ家の 広間の 出口" : "氷の 隠れ家の 出口", "snow");
      const eH = K.hero(p), eR = REI(K, p);
      const eX = K.npcNear(p, MASK[0], K.PJ(MASK[1], 10), true), eU = K.npcNear(p, RUU[0], K.PJ(RUU[1], 10), true), eO = K.npcNear(p, "§9ロウ", K.PJ(ROU[1], 10), true);
      K.act(eX, "hold"); K.act(eU, "hold"); K.act(eO, "down");
      if (ok(eU)) await K.up(p, eU, 12);
      await K.narr(p, ["§7ルウが、仮面の 戦士の 外套を 両手で つかんで いる。", "§7黒い 手袋の ない 方の 手が、真っ赤に かじかんで いた。"], eU);
      await K.hsay(p, V(K, ["{sad}……ルウ。手、冷たいでしょ。"], ["{sad}……ルウ。手が 冷たいでしょう。"], ["{closed}……ルウ。手、冷えてる。"], ["{sad}……ルウさん。お手が、冷たいでしょう。"]), eU);
      K.act(eH, "show"); K.hold(eH, "glove"); await K.push(p, eH, 18, 3.2, 1.2);
      await K.narr(p, ["§7祠の 綱に 結ばれて いた、黒い 右手の 手袋。", "§7この 雪山の 寒さを、ひとつだけ 防いで くれる もの。"], eH);
      const v = await K.pick(p, "c11");
      if (v === "r") {
        if (ok(eH) && ok(eU)) await K.approach(p, eH, eU, 1.2);
        await K.give(eH, eU, "glove");
        { const dd = K.load(p); if (dd) { const s = K.qs(dd); if (Array.isArray(s.keys)) s.keys = s.keys.filter((k) => k !== "k_glove"); delete s.glove; K.save(p, dd); } }
        await K.say(p, "ルウ", ["{shock,…}……これ、ボクの……", "{cry,tears,up}……兄ちゃんの 編み目だもん。"]);
        K.act(eU, "hold"); await K.up(p, eU, 10);
        /*F35*/ await K.narr(p, ["§7ルウは 手袋を はめず、胸に 抱いた。", "§7……眠る ロウの 手に、いつか 重ねる ために。"], eU);
      } else {
        await K.hsay(p, V(K, ["{closed}……これは、わたしが 持って おく。シロウさんに 見せる。", "{sad,up}……いつか 二人の 手に、ちゃんと 返すから。"], ["{closed}……これは、わたしが 預かるわ。シロウさんに 見せたいの。", "{sad,up}いつか、二人の 手に 返すから。"], ["{closed}……預かる。シロウに 見せる。", "{closed}いつか 返す。"], ["{closed}……これは、わたしが お預かり します。シロウさんに お見せ したいのです。", "{sad,up}いつか、お二人の 手に お返し しますから。"]), eU);
        K.hold(eH);
        await K.say(p, "ルウ", ["{angry,tears}……返して くれなくて いいもん。ロウの 手、ボクが あっためるもん。"]);
        /*F35*/ await K.narr(p, ["§7ルウは 素手で、ロウの 冷たい 手を 握った。"], eU);
      }
      K.act(eH, 0);
      await K.say(p, "白い 仮面の 戦士", ["{closed,low}……追うな。知りすぎるな。"], eH);
      await K.say(p, "レイ", ["{angry}……連れて いく 気か。"], eX);
      K.flash(p, true); await K.wait(4);
      K.big(p, "§8……", "§7吹雪が、仮面の 戦士と 双子を 白く 隠した", "random.orb");
      await K.wait(10);
      await K.bye(p, eX, eU, eO);
      await K.say(p, "レイ", ["{closed}……鍵ごと、持って いかれた。", "{angry,low}竜祭りの 夜。……ラグナで、追いつく。"], eH);
      await K.hsay(p, V(K, ["{sad}……ルウの『起きて』が、まだ 耳に 残ってる。", "{closed,up}サンダに 帰ろう。シロウさんに、二人が 生きてるって 言わなきゃ。"], ["{sad}……ルウちゃんの 声が、耳に 残ってるの。", "{closed,up}サンダへ 帰りましょう。シロウさんに 伝えなきゃ。"], ["{closed}……ルウの 声が 耳に 残ってる。", "{closed}サンダへ 帰る。シロウに 言う。"], ["{sad}……ルウさんの お声が、耳に 残って います。", "{closed,up}サンダへ 帰りましょう。シロウさんに お伝え しなければ。"]), eR);
      if (!ok(p)) return false;
      K.pay(p, { id: "b11e8" }, 26000, [["e_king", 1], ["SEED3", 2], ["i_awaken", 1], ["tms_insect", 1]]);
      await K.end(p, { leave: [eR], card: "§7→ §eらいうんの 里 サンダ§7 の 雷祭りへ", kind: "snow" });
      return true;
    } },
  /* ---------- 9話 雷祭り（r8e6 を 引きとる）---------- */
  { id: "b11e9", t: "雷祭り", place: YAGURA, F: ["F09", "F45"], battles: 0, set: { thunder8: 1, met8: 1 },
    skip(s) { s.epx = { ...(s.epx || {}), thunder8: 1 }; },
    hint: "§fらいうんの 里 §eサンダの 広場§f へ もどろう §7（雷祭りの 晩）",
    syn: "サンダの 雷祭り。シロウ「生きてた だけで、十分だべさ」。オルドの 手紙「わしも 行く。竜祭りの 夜に、エンドで」。",
    async run(p, d, K) {
      const y0 = Y(K, p);
      festSet(p, "t_sanda", p.location, y0); const R = rod(K, p, y0); const cw = crowd(K, p, 3, "§7里の 人");
      await K.open(p, "らいうんの 里 サンダの 広場（雷祭りの 晩）", "fest", "night");
      K.sound(p, "note.bd", 1); await K.wait(6); K.sound(p, "note.bd", 1);
      const eH = K.hero(p), eR = REI(K, p), eS = K.cast(p, "b11_shirou");
      K.act(eS, "raise");
      await K.csay(p, "b11_shirou", ["{smile,☆}来たべさ！ 山道は ぜんぶ 開いたべさ！ 今夜は 雷祭りだべさ！"], eH);
      const eZ = K.cast(p, "b09_zuzu"); K.act(eZ, "hold");
      await K.csay(p, "b09_zuzu", ["{smile,汗}……オレ、太鼓を たたく 係に なった。……ずびっ。"]);
      K.act(eZ, 0); K.act(eS, 0);
      if (ok(eH) && ok(eS)) await K.approach(p, eH, eS, 1.6);
      await K.ots(p, eS, eH, 8);
      await K.hsay(p, V(K, ["{closed}……シロウさん。会えたよ。ロウと ルウに。", "{sad,up}ロウは 黒い 水に 落ちて、目を 覚まさない。……仮面の 人が、二人を 連れて いった。"], ["{closed}……シロウさん。ロウくんと ルウちゃんに 会えたわ。", "{sad,up}ロウくんは 目を 覚まさなくて……仮面の 人が、二人を 連れて いったの。"], ["{closed}……会った。ロウと ルウに。", "{sad}ロウは 目を 覚まさない。仮面の やつが 連れて いった。"], ["{closed}……シロウさん。ロウさんと ルウさんに、お会い しました。", "{sad,up}ロウさんは 目を 覚まさず……仮面の 方が、お二人を 連れて いきました。"]), eS);
      K.act(eS, "kneel"); await K.push(p, eS, 22, 4.2, 1.7);
      const s0 = K.qs(K.load(p) || d), gave = K.chIs(s0, "c11", "r");
      if (gave) await K.hsay(p, V(K, ["{sad}……ルウの 手袋は、ルウに 渡したよ。胸に 抱いてた。"], ["{sad}……ルウちゃんの 手袋は、本人に 渡したわ。"], ["{closed}……手袋は ルウに 渡した。"], ["{sad}……ルウさんの 手袋は、ご本人に お渡し しました。"]), eS);
      else { K.act(eH, "show"); K.hold(eH, "glove"); await K.hsay(p, V(K, ["{closed}……ルウの 手袋。わたしが 持ってる。いつか 返す。"], ["{closed}……ルウちゃんの 手袋は、わたしが 預かって いるわ。"], ["{closed}……手袋は オレが 持ってる。"], ["{closed}……ルウさんの 手袋は、わたしが お預かり して います。"]), eS); K.hold(eH); K.act(eH, 0); }
      await K.csay(p, "b11_shirou", ["{cry,tears,up}……生きてた。……生きてた だけで、十分だべさ。", gave ? "{smile,tears}ルウが 持ってるなら、それで いいべさ。あの 子の 手は、冷たく ならねえべさ。" : "{smile,tears}あんたが 持ってて けろ。……ルウの 手に 返す 日まで、案内は 終わらねえべさ。"]);
      K.act(eS, 0);
      /* オルドの 手紙 */
      K.sound(p, "mob.parrot.fly", 1); K.burst(p.dimension, K.fwd(p, 2, 0, 1.5), "minecraft:white_smoke_particle", 5, 0.4, 0.5);
      K.hold(eR, "letter"); K.act(eR, "hold"); await K.push(p, eR, 18, 3.6, 1.3);
      /*F09 F45*/ await K.say(p, "オルド（手紙）", ["{closed}セオという 若者は、知りすぎて おる。……わしは、二十年前と 同じ 影を 見た。", "{closed,up}わしも 行く。竜祭りの 夜に、エンドで。"]);
      await K.say(p, "レイ", ["{sad,…}……じいちゃんが『わしも 行く』なんて 書いたの、初めてだ。", "{closed,up}あの 人、本気だ。……オレたちが 先に 行かないと。"], eH);
      K.hold(eR); K.act(eR, 0);
      /* 雷太鼓 */
      K.act(eS, "raise"); K.act(eZ, "raise");
      if (ok(eS) && R) await K.walkCam(p, eS, { x: R.x - 1.4, y: y0, z: R.z }, 16);
      if (ok(eZ) && R) K.go(eZ, { x: R.x + 1.4, y: y0, z: R.z }, 16);
      await K.csay(p, "b11_shirou", ["{angry,up}さあ、雷石を のせるべさ！ ズズ、たたけーっ！"]);
      for (let k = 0; k < 4; k++) { K.sound(p, "note.bd", 1); K.shake(p, 0.15, 0.2); spark(K, p, R, 4); await K.wait(5); }
      await K.at(p, R, 12, 6, 2); thunder(K, p, R, true);
      await K.narr(p, ["§7太鼓が 三度 鳴った とき、空から 白い 雷が 落ちて きた。", "§7ぶあつい 雪雲が、まん中から 割れて いく。……その 向こうに、星が 見えた。"], R);
      K.act(eS, 0); K.act(eZ, 0);
      await K.csay(p, "b09_zuzu", ["{smile,tears,up}……ずびっ。オレ、生まれて はじめて、えらいって 言われた。"]);
      K.ambient(p, "fest", { x: p.location.x, y: y0, z: p.location.z });
      await K.csay(p, "b11_shirou", ["{smile,up}山では、帰って くるまでが 案内だべさ。……いって らっしゃい だべさ！"], eH);
      await K.hsay(p, V(K, ["{smile,tears,up}……いって きます！"], ["{smile,tears,up}……いって きます。"], ["{smile,up}……いって きます。"], ["{smile,tears,up}……いって まいります！"]));
      if (!ok(p)) return false;
      const got = K.pay(p, { id: "b11e9" }, 900, [["mei_frost", 2], ["e_blue", 1]]);
      if (got && got.length) K.big(p, "§b§l雷祭りの おみやげ", `§e${got.join("・")}`);
      await K.end(p, { leave: [eR], bye: [eS, eZ, ...cw], card: "§f― 第11章 雪山の双子 おわり ―\n§7→ §eヘイムダル城下§7 へ（地方マスター シデンが 待つ）", kind: "fest", t: 60 });
      return true;
    } },
]);

/* MQ19: 氷の 隠れ家（4〜8話を 順に）。古い セーブで 話が 済んで いれば 何も 待たない */
mqOver(19, null, { cond: async () => true });
