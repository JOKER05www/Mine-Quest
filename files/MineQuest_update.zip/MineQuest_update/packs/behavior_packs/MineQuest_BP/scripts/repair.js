// v2.9.13: ガイドブックの「バグを 直す」。目の前で 起きた よくある こまりごとを その場で 直す
// （動けない・本が 開かない・カメラが もどらない・ずっと 無敵や 暗視・連れ歩きが 消えた／ふえた・
//   戦いの あとの モンスターが のこった・見えない まま・ブロックに うまった・数値が おかしい など）
import { world, system } from "@minecraft/server";
import { load, save } from "./store.js";
import { busy, ok, notice, confirm, choose, ICON, LINE, UI_ACT, hudSend, hudResend } from "./ui.js";
import { calcStats, fixParty, promoteBench } from "./core.js";
import { inBattle, liveBattleIds, liveEntityIds, hudClear, CAMON } from "./battle.js";
import { refreshPet } from "./field.js";
import { sagaUnlock, syncKeys, homeTp } from "./saga.js";
import { SPECIES, SKILLS, MOVES, TRAITS, ITEMS } from "./data.js";
import { backFromArena } from "./stage.js";
import { getDg, exitDungeon } from "./dungeon.js";
import { restoreMusashi } from "./majin.js";
import { RU_HOOK } from "./ruinsarea.js";
import { dgCleanBeacons } from "./dungeon.js";
import { building } from "./structures.js";
import { stageEnd } from "./stagecore.js";
import { mqFixInfo, mqSpotReset, storyWarp, cheatAdvance, storyNowHint, regAt } from "./saga.js";   /* 第124版: 物語が 進まない */
import { talkReset } from "./talk.js";
import { castleInfo, landInfo, getTown, caveInfo, CAVE_R, caveName, recheckSite } from "./structures.js";
import { WREGIONS, landSites } from "./worldmap.js";
import { regTown } from "./storyplace.js";
import { altarInfo } from "./postgame.js";

const TYPE = "mrpg:monster";
const PASS = /air|short_grass|tall_grass|tallgrass|seagrass|fern|flower|torch|snow_layer|vine|carpet|sapling|button|pressure_plate|sign|banner|rail|ladder|lily|seagrass|kelp|water|lava|light_block|structure_void|mushroom|roots|petals|bush|tulip|daisy|orchid|allium|bluet|poppy|dandelion|cornflower|lantern/;
const solid = (dim, x, y, z) => { try { const b = dim.getBlock({ x, y, z }); if (!b) return false; return !PASS.test(String(b.typeId)); } catch { return false; } };

// ひとつずつ 直して、直した ことを 返す
export function doRepair(p, unlock) {
  const fixed = [];
  const run = (c) => { try { p.runCommand(c); return true; } catch { return false; } };
  // 1. 止まった しるし（本が 開かない・物語が 進まない）
  if (unlock) {
    if (busy.has(p.id)) { busy.delete(p.id); fixed.push("ガイドブックが 開かない 状態を 直した"); }
    try { if (sagaUnlock(p)) fixed.push("止まって いた 物語の できごとを 外した（もう一度 起きる）"); } catch {}
  }
  // 1b. v3.0: エンマに 取り憑かれた ままの ムサシを もどす（戦いの 外の とき）
  try { const d0 = load(p); if (d0 && d0.story && d0.story.possess && !inBattle(p)) { restoreMusashi(p); fixed.push("ムサシを パーティに もどした"); } } catch {}
  // 2. カメラ・操作・画面
  try { CAMON.delete(p.id); } catch {}
  try { stageEnd(p, true); } catch {}   /* 第119版: 物語の 場面（舞台・ムービー）が のこって いたら 終わらせる */
  run("camera @s clear"); run("inputpermission set @s movement enabled"); run("inputpermission set @s camera enabled"); run("inputpermission set @s lateral_movement enabled"); run("inputpermission set @s jump enabled"); run("hud @s reset"); run("fog @s remove mq_shadow");
  try { hudClear(p, 3); } catch {}
  for (const ch of ["MQC", "MQD", "MQF", "MQX", "MQK", "MQV", "MQN", "MQY", "MQE"]) { try { hudResend(p.id, ch); hudSend(p, ch, ""); } catch {} }   /* 第120版: ムービーの 会話の 文字・帯・光・集中線・大きな 文字も 消す */
  run("fog @s remove mq_shadow");
  try { p.onScreenDisplay.clearTitle?.(); } catch {} try { p.onScreenDisplay.setActionBar(" "); } catch {}
  fixed.push("カメラ・操作・画面の 表示（上の 枠・左の ログ・まんなかの 文字・ムービーの せりふと 演出）を もとに もどした");
  // 3. 戦いで ついた ままの 効果（とても 長い ものだけ。薬の 効果は 消さない）
  try {
    let n = 0;
    for (const [id, amp, long] of [["resistance", 255, 0], ["fire_resistance", -1, 20 * 900], ["water_breathing", -1, 20 * 900], ["night_vision", -1, 20 * 900], ["slowness", -1, 20 * 900], ["invisibility", -1, 20 * 900]]) {
      const ef = p.getEffect(id); if (!ef) continue;
      if ((amp >= 0 && ef.amplifier >= 200) || (amp < 0 && ef.duration > long)) { p.removeEffect(id); n++; }
    }
    if (n) fixed.push(`戦いで ついた ままの 効果を ${n}つ 外した`);
  } catch {}
  // 4. 戦いの あとに のこった モンスター・見えない ままの モンスター（まわり 48ブロック）
  try {
    const live = liveBattleIds(), inUse = liveEntityIds(); let rm = 0, vis = 0;
    for (const e of p.dimension.getEntities({ type: TYPE, location: p.location, maxDistance: 48 })) {
      try {
        if (e.hasTag("mrpg_preview") || e.hasTag("mrpg_play") || inUse.has(e.id)) continue;
        const bid = e.getDynamicProperty("mrpg:bid");
        if (e.hasTag("mrpg_battle") && typeof bid === "number" && !live.has(bid) && !e.hasTag("mrpg_boss") && !e.hasTag("mrpg_pet")) { e.remove(); rm++; continue; }
        if (!e.hasTag("mrpg_battle") && e.getEffect("invisibility")) { e.removeEffect("invisibility"); vis++; }
      } catch {}
    }
    if (rm) fixed.push(`戦いの あとに のこった モンスターを ${rm}体 かたづけた`);
    if (vis) fixed.push(`見えなく なって いた モンスターを ${vis}体 見える ように した`);
  } catch {}
  // 5. データの 点検（HP・MPの おかしな 値・連れ歩き・だいじなもの）
  const d = load(p);
  if (d && Array.isArray(d.party)) {
    let bad = 0;
    for (const m of [...d.party, ...(d.bench || []), ...(d.box || [])]) {
      try {
        const st = calcStats(m);
        if (typeof m.hp !== "number" || !isFinite(m.hp) || m.hp < 0) { m.hp = m.hp < 0 ? 0 : st.hp; bad++; }   // v3.0: こわれた HPは 満タンに
        else if (m.hp > st.hp) { m.hp = st.hp; bad++; }
        if (typeof m.mp !== "number" || !isFinite(m.mp) || m.mp < 0) { m.mp = st.mp; bad++; }
        else if (m.mp > st.mp) { m.mp = st.mp; bad++; }
        if (typeof m.exp !== "number" || !isFinite(m.exp) || m.exp < 0) { m.exp = 0; bad++; }
      } catch {}
    }
    // 同じ モンスターが 2か所に いる・こわれた データ（なくなった 技・特性・スキル・装備）
    const seen = new Set(); let dup = 0, gone = 0;
    for (const key of ["party", "bench", "box"]) {
      if (!Array.isArray(d[key])) continue;
      d[key] = d[key].filter((m) => { if (!m || typeof m !== "object" || !SPECIES[m.sp]) return true; if (m.id && seen.has(m.id)) { dup++; return false; } if (m.id) seen.add(m.id); return true; });
      for (const m of d[key]) {
        if (!m || !SPECIES[m.sp]) continue;
        try {
          if (Array.isArray(m.sk)) for (let i = 0; i < m.sk.length; i++) { if (SKILLS[m.sk[i]]) continue; const alt = (SPECIES[m.sp].skills || []).find((k) => SKILLS[k] && !m.sk.includes(k)); if (alt) m.sk[i] = alt; else { m.sk.splice(i, 1); if (Array.isArray(m.pts)) m.pts.splice(i, 1); i--; } gone++; }
          if (Array.isArray(m.rtr) && !m.rtr.every((t) => TRAITS[t])) { const n0 = m.rtr.length; m.rtr = m.rtr.filter((t) => TRAITS[t]); gone += n0 - m.rtr.length; if (!m.rtr.length) delete m.rtr; }
          if (Array.isArray(m.xtr) && !m.xtr.every((t) => TRAITS[t])) { const n0 = m.xtr.length; m.xtr = m.xtr.filter((t) => TRAITS[t]); gone += n0 - m.xtr.length; }
          else if (typeof m.xtr === "string" && !TRAITS[m.xtr]) { delete m.xtr; gone++; }
          if (m.eq && typeof m.eq === "object") for (const s of ["w", "a", "x"]) { const e = m.eq[s]; const iid = typeof e === "string" ? e : e && e.id; if (iid && !ITEMS[iid]) { m.eq[s] = null; if (m.eqr && typeof m.eqr === "object") delete m.eqr[s]; gone++; } }
        } catch {}
      }
    }
    if (dup) fixed.push(`2か所に いた 同じ モンスターを ${dup}体 1つに した`);
    if (gone) fixed.push(`なくなった 技・特性・装備の しるしを ${gone}こ 外した`);
    if (typeof d.gold !== "number" || !isFinite(d.gold) || d.gold < 0) { d.gold = Math.max(0, Math.floor(Number(d.gold) || 0)); bad++; }
    for (const key of ["party", "bench", "box"]) if (Array.isArray(d[key])) { const n0 = d[key].length; d[key] = d[key].filter((m) => m && typeof m === "object"); if (d[key].length !== n0) bad += n0 - d[key].length; }
    if (d.out && !d.party.some((m) => m.id === d.out)) { d.out = null; bad++; }
    try { const back = syncKeys(p, d); if (back && back.length) fixed.push(`なくした 石板・だいじなものを もどした（${[...new Set(back)].slice(0, 4).join("・")}${back.length > 4 ? " ほか" : ""}）`); } catch {}   /* 第71版 */
    try { const mv = fixParty(d); if (mv.length) fixed.push(`枠を こえて いた ${mv.length}体を 預かり所へ うつした`); } catch {}
    try { if (!d.party.length) { const src = (d.bench || []).length ? d.bench : d.box; if (src.length) { d.party.push(src.shift()); fixed.push("パーティが 0体 だったので 1体 入れた"); } } } catch {}
    try { if (promoteBench(d)) fixed.push("表が 全員 倒れて いたので 裏と 入れかえた"); } catch {}
    try { if (typeof globalThis.__mqClearMem === "function" && globalThis.__mqClearMem(p.id)) fixed.push("一覧の ページ・しぼりこみの 記おくを 消した"); } catch {}
    save(p, d);
    if (bad) fixed.push(`おかしな 数値を ${bad}か所 直した`);
    try { refreshPet(p, d); fixed.push("連れ歩きの 見た目を 直した"); } catch {}
  }
  // 7. 空の 闘技場に 取りのこされた（戦いは 終わって いる）
  try { if (typeof p.getDynamicProperty("mrpg:ret") === "string") { backFromArena(p); fixed.push("空の 闘技場から もとの 場所へ もどした"); } } catch {}
  // 8. 石板の 外に いるのに 石板の 中の あつかいの まま
  try { const st = getDg(p); if (st && (p.dimension.id !== "minecraft:overworld" || p.location.y < 200)) { exitDungeon(p, false); fixed.push("石板の 中の あつかいが のこって いたので 外した"); } } catch {}
  // 9. 第94版: 長く ついた ままの ゆっくり落下・浮遊・ダメージ無効（戦いの 外）
  try {
    if (!inBattle(p)) { let n = 0;
      for (const id of ["slow_falling", "levitation"]) { const ef = p.getEffect(id); if (ef && ef.duration > 60) { p.removeEffect(id); n++; } }
      const rs = p.getEffect("resistance"); if (rs && rs.amplifier >= 4) { p.removeEffect("resistance"); n++; }
      if (n) fixed.push(`ついた ままの 浮く・ダメージを 受けない 効果を ${n}つ 外した`); }
  } catch {}
  // 10. 第94版: 滅びた 世界（追加ストーリー）
  try { if (RU_HOOK.repair) for (const t of RU_HOOK.repair(p)) fixed.push(t); } catch {}
  // 11. 第94版: 石板の 中: となりの 階の 階段の 光を 消す
  try { if (getDg(p) && dgCleanBeacons(p)) fixed.push("石板の 中: 残って いた 古い 階段と 光を 消して、本当の 階段だけに した"); } catch {}
  // 12. 第94版: 入る 途中で ぬけた ときの お金（再会の石板・闘技場の かけ）
  try { const d2 = load(p); if (d2) { let back = 0;
      if (d2.meetPend > 0 && !getDg(p)) { back += d2.meetPend; d2.gold += d2.meetPend; delete d2.meetPend; }
      if (d2.betPend > 0 && !d2.betGo && !inBattle(p)) { back += d2.betPend; d2.gold += d2.betPend; delete d2.betPend; }
      if (back) { save(p, d2); fixed.push(`戻って いなかった お金 ${back.toLocaleString()} タヨを 返した`); } } } catch {}
  // 13. 第94版: のこった 読みこみ範囲（だれも 使って いない もの）
  try { if (!building()) { p.runCommand("tickingarea remove mrpg_build"); } } catch {}
  // 6. ブロックに うまって いたら 上へ（石板の 中では しない）
  if (typeof p.getDynamicProperty("mrpg:dg") !== "string") try {
    const dim = p.dimension, l = p.location, x = Math.floor(l.x), z = Math.floor(l.z); let y = Math.floor(l.y);
    if (solid(dim, x, y, z) || solid(dim, x, y + 1, z)) {
      for (let k = 1; k <= 40; k++) if (!solid(dim, x, y + k, z) && !solid(dim, x, y + k + 1, z) && solid(dim, x, y + k - 1, z)) { p.teleport({ x: l.x, y: y + k, z: l.z }); fixed.push("ブロックに うまって いたので 上へ 出した"); break; }
    }
  } catch {}
  return fixed;
}

// 本当に 止まって いるか（1分半 以上 何かの 途中の まま、1分 以上 画面も 出て いない）
export function stuckLong(p) {
  const t0 = busy.since.get(p.id), ui = UI_ACT.get(p.id) || 0, now = Date.now();
  return typeof t0 === "number" && now - t0 >= 90000 && now - ui >= 60000;
}
export async function repairFlow(p, fromStuck = false) {
  if (!ok(p)) return;
  if (fromStuck && !inBattle(p) && !stuckLong(p)) {
    try { p.sendMessage("§7いまは 何かの 処理の 途中です。§f1分ほど 待っても 本が 開かない ときに、もう一度 しゃがみながら 本を 使って ください。"); } catch {}
    return;
  }
  if (inBattle(p)) {
    await notice(p, "バグを 直す", "§f今は 戦いの 中です。\n§7画面や モンスターが おかしい ときは、戦いの コマンドの 一番下「§f表示を なおす§7」を 押して ください。");
    return;
  }
  const pick = await choose(p, "バグを 直す", ["§fよく ある こまりごとを まとめて 直します。§7（データは 消えません）", LINE,
    "§f・本が 開かない／物語が 止まった", "§f・カメラや 操作が もどらない", "§f・戦いの あとも 上の 枠や 左の ログが のこる", "§f・無敵・暗視などが つきっぱなし",
    "§f・連れ歩きが 消えた／戦いの あとの モンスターが のこった", "§f・モンスターが 見えない まま", "§f・HP などの 数値が おかしい／同じ モンスターが 2体", "§f・なくした 石板・だいじなもの／パーティの 枠こえ・表が 全滅の まま", "§f・空の 闘技場や 石板から 出られない", "§f・ブロックに うまった",
    LINE, "§e物語が 進まない§7 ときは 下の ボタン（場所・人・だいじなものを 点検して、ワープ・とばす も えらべる）"].join("\n"),
    [["§l直す", ICON("i_help")], ["§e物語が 進まない", ICON("i_run")], ["§7やめる", ICON("i_back")]]);
  if (pick === 1) { busy.add(p.id); try { await storyFlow(p); } finally { if (fromStuck) busy.delete(p.id); } return; }
  if (pick !== 0) return;
  const fixed = doRepair(p, fromStuck);   // v3.0: ガイドブックから 開いた ときは 本・物語の しるしは さわらない（今 使って いる ため）   // ガイドブックからは 自分の 画面だけ・しゃがみからは 1分半 止まった ときだけ
  busy.add(p.id);   // この あとの 画面の あいだ
  try {
    const c = await choose(p, "バグを 直す", ["§a§l直しました！", LINE, ...fixed.map((t) => `§f・${t}`), LINE, "§7まだ おかしい ときは「家へ もどる」で はじまりの 町へ ワープ できます。", "§7それでも 直らない ときは、ワールドを 一度 出て 入りなおして ください。"].join("\n"),
      [["§lOK", ICON("i_back")], ["§e家へ もどる §8（はじまりの 町）", ICON("i_run")]]);
    if (c === 1 && await confirm(p, "家へ もどる", "§fはじまりの 町へ ワープ しますか？", "ワープ", "やめる")) { try { homeTp(p); } catch {} }
  } finally { if (fromStuck) busy.delete(p.id); }   // ガイドブックから 開いた ときは ガイドブックが あとで 外す
}

/* ---------- 第124版: 物語が 進まない ---------- */
/* ほかの 人が 近くで 物語・戦いの 途中か（その 人の 場面を こわさない）*/
function othersBusyNear(p, x, z, r = 100) {
  for (const q of world.getAllPlayers()) { if (q.id === p.id) continue; try { if ((busy.has(q.id) || inBattle(q)) && Math.hypot(q.location.x - x, q.location.z - z) < r) return true; } catch {} }
  return false;
}
/* 城の 地方マスター・王が 持ち場から 離れて いたら もどす（いない ときは 城に 近づくと 現れる）*/
function callPeople(p, r) {
  const out = [], ci = castleInfo(r); if (!ci || !ci.built) return out;
  const ow = world.getDimension("overworld"), k = WREGIONS[r]?.rm;
  const want = [];
  if (k >= 0 && ci.m) want.push([`mrpg_rm${k}`, ci.m, "地方マスター", () => true]);
  if (ci.k) want.push([`mrpg_castle${r}`, ci.k, "城の 王", (e) => e.getDynamicProperty("mrpg:king") === r]);
  for (const [tag, at, nm, f] of want) {
    let L = []; try { L = ow.getEntities({ type: "mrpg:npc", tags: [tag] }).filter((e) => ok(e) && f(e)); } catch {}
    const e = L[0]; if (!e) continue;
    try { if (Math.hypot(e.location.x - at.x, e.location.z - at.z) > 10 && !othersBusyNear(p, e.location.x, e.location.z, 24)) { e.teleport({ x: at.x, y: at.y, z: at.z }); out.push(`${WREGIONS[r].castle.name}の ${nm}を 持ち場に もどした`); } } catch {}
  }
  return out;
}
/* 今の 段を 点検して 直す。{ fixed, why（とばせる 理由）, info } */
export function storyFix(p) {
  const fixed = [];
  try { for (const t of doRepair(p, true)) if (!/^カメラ・操作/.test(t)) fixed.push(t); } catch {}
  try { talkReset(p); } catch {}
  fixed.unshift("止まった 印（本・物語の できごと・場面・カメラ・操作・画面・霧・無敵）を 外した");
  const d = load(p); if (!d) return { fixed, why: [], info: null };
  try { fixed.push(...mqSpotReset(p, d)); save(p, d); } catch {}
  const I = (() => { try { return mqFixInfo(p, load(p) || d); } catch { return null; } })();
  if (!I) return { fixed, why: [], info: null };
  /* 場所: 城・町・ステージ（水びたし・うまり）の 点検を もう一度・洞くつ・地方マスターと 王 */
  let r = I.st.r; if (!(r >= 0 && r < WREGIONS.length)) { try { r = regAt(p.location); } catch { r = -1; } }
  if (r >= 0 && r < WREGIONS.length) {
    const sites = [], ci = castleInfo(r);
    if (!ci || !ci.built) fixed.push(`§e${WREGIONS[r].castle.name}は まだ 建って いない §7（近づくと 建つ）`); else sites.push(["castle", r, ci]);
    try { const T = regTown(r), ti = T && getTown(T.t.id); if (ti && ti.built) sites.push(["town", T.t.id, ti]); } catch {}
    try { const L = landSites(r)[0], li = L && landInfo(L.key); if (li && li.built) sites.push(["land", L.key, { x: L.x, z: L.z }]); } catch {}
    let n = 0, held = 0;
    for (const [k, id, q] of sites) { if (othersBusyNear(p, q.x, q.z)) { held++; continue; } if (recheckSite(k, id)) n++; }
    if (n) fixed.push(`${WREGIONS[r].short}の 城・町・ステージ ${n}か所を、近づいた ときに もう一度 点検する ように した（水びたし・うまって いれば 直す）`);
    if (held) fixed.push(`§7ほかの 人が 近くで 物語や 戦いの 途中なので、${held}か所の 点検は あとに した`);
    if (CAVE_R.includes(r) && (I.st.at === "hall" || I.st.at === "cave" || I.st.hq !== undefined)) { const v = caveInfo(r); if (!v || !v.built) fixed.push(`§e${caveName(r)}は まだ できて いない §7（入口に 近づくと 作られる${I.st.hq !== undefined ? "。3分 待っても できない ときは、今までの 場所で 物語が 始まる" : ""}）`); }
    fixed.push(...callPeople(p, r));
  }
  /* クリア後: 閻魔の神殿が こわれて いたら 近づくと 建てなおす */
  if (I.post) try {
    const a = altarInfo();
    if (a && a.built && typeof a.y === "number") { const b = p.dimension.id === "minecraft:overworld" ? world.getDimension("overworld").getBlock({ x: a.x, y: a.y + 1, z: a.z }) : null;
      if (b && !/crying_obsidian/.test(b.typeId) && !othersBusyNear(p, a.x, a.z, 40)) { world.setDynamicProperty("mrpg:altar", JSON.stringify({ x: a.x, z: a.z, y: null, built: false })); fixed.push("こわれた 閻魔の神殿を、近づいた ときに 建てなおす ように した"); } }
  } catch {}
  /* とばせる 理由 */
  const why = [];
  if (I.need && (!I.sp || I.sp.wait)) why.push("物語の 場所が まだ 見つからない・できて いない");
  if (I.lose >= 3) why.push(`この 段で ${I.lose}回 負けて いる`);
  if (I.mins >= 30) why.push(`この 段から ${I.mins}分 進んで いない`);
  return { fixed, why: I.canSkip ? why : [], info: I };
}
async function storyFlow(p) {
  if (inBattle(p)) { await notice(p, "物語が 進まない", "§f今は 戦いの 中です。§7戦いが 終わってから 使って ください。"); return; }
  const R = storyFix(p), d = load(p), I = R.info;
  busy.add(p.id);   /* doRepair が 外した ぶん（この あとの 画面の あいだ）*/
  let hint = ""; try { hint = d ? String(storyNowHint(d)).replace(/§./g, "") : ""; } catch {}
  const body = ["§a§l点検して 直しました", LINE, ...R.fixed.map((t) => `§f・${t}`), LINE, hint ? `§f今の 目標: §e${hint}` : "",
    R.why.length ? `§6この 段は とばせます §7（${R.why.join("・")}）` : I && I.canSkip ? "§7（3回 負ける・30分 進まない・場所が 見つからない ときは、この 段を とばせる ように なる）" : "",
    "§7右上の 案内の 場所へ ワープも できます。"].filter(Boolean).join("\n");
  const btns = [["§lOK", ICON("i_back")], ["§e物語の 場所へ ワープ", ICON("i_run")]];
  if (R.why.length) btns.push(["§6この 段を とばして 次へ 進む", ICON("i_help")]);
  const c = await choose(p, "物語が 進まない", body, btns);
  if (!ok(p)) return;
  if (c === 1) {
    if (inBattle(p)) { await notice(p, "ワープ", "§7戦いの 中では ワープ できません。"); return; }
    if (getDg(p)) { await notice(p, "ワープ", "§7石板の 中では ワープ できません。§f本を 使うと 出る「石板の 外へ 脱出する」で 外へ 出てから 使って ください。"); return; }   /* 第124版 */
    const nm = storyWarp(p, load(p));
    if (!nm) await notice(p, "ワープ", "§7今の 目標には 決まった 場所が ありません。§f右上の 案内を 見て 進んで ください。");
    else try { p.sendMessage(`§a${nm}へ ワープ した。`); } catch {}
  } else if (c === 2 && R.why.length) {
    if (!(await confirm(p, "この 段を とばす", `§fこの 段を 見ずに 次へ 進みます。§7（この 段の 印・封印・だいじなものは そろえる。ほうびは 出ない）\n§7理由: ${R.why.join("・")}`, "とばす", "やめる"))) return;
    const r = cheatAdvance(p, 1);
    if (r && r.moved) await notice(p, "この 段を とばした", `§a次の 段へ 進んだ。\n§f次の 目標: §e${String(r.hint || "").replace(/§./g, "")}`);
    else await notice(p, "この 段を とばす", "§7この 段は とばせません。");
  }
}
