// 第108版: 物語の 会話を フォームで 止めない。せりふは チャットと 画面下の 文字に 流れる
// 第109版: 会話の あいだは「ムービー」: プレイヤーは その場で 止まり、話す 人が 身ぶり手ぶりで 話す。
//   しゃがむ（短く）= 次の せりふ ／ しゃがんだ まま 1.5秒 = スキップ（その 場面の 会話を ぜんぶ とばす。戦いは とばさない）
import { world } from "@minecraft/server";
import { notice, wait, ok, barNote } from "./ui.js";
const plain = (s) => String(s || "");
const SKIP = new Set(), LOCK = new Map();
let FIND = null;   /* (p, who) → 話す 人の エンティティ（saga.js が 決める）*/
export function setSpeakerFinder(f) { FIND = f; }
export function clearSkip(p) { try { SKIP.delete(p.id); } catch {} }
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
const HUD = ["hotbar", "health", "hunger", "armor", "status_effects", "item_text", "paperdoll", "crosshair", "air_bubbles", "progress_bar"];
function lock(p) {
  const n = (LOCK.get(p.id) || 0) + 1; LOCK.set(p.id, n); if (n > 1) return;
  try { p.addEffect("slowness", 20 * 600, { amplifier: 255, showParticles: false }); } catch {}
  cmd(p, "inputpermission set @s lateral_movement disabled"); cmd(p, "inputpermission set @s jump disabled");
  for (const h of HUD) cmd(p, `hud @s hide ${h}`);
}
function release(p) {
  try { p.removeEffect("slowness"); } catch {}
  cmd(p, "inputpermission set @s lateral_movement enabled"); cmd(p, "inputpermission set @s jump enabled"); cmd(p, "hud @s reset");
}
function unlock(p) { const n = (LOCK.get(p.id) || 1) - 1; if (n > 0) { LOCK.set(p.id, n); return; } LOCK.delete(p.id); release(p); }
/* ワールドに 入りなおした とき: 会話の とちゅうで 抜けても 動けない ままに ならない */
try { world.afterEvents.playerSpawn.subscribe((ev) => { const p = ev.player; if (!LOCK.has(p.id)) release(p); }); } catch {}
/* せりふの 中身から しぐさを えらぶ（4 話す 5 手を ふる 6 拍手 9 喜ぶ 10 おじぎ 12 しょんぼり）*/
function gesture(l) {
  const s = plain(l);
  if (/ありがと|よろしく|すまな|ごめん|申し訳/.test(s)) return 10;
  if (/……/.test(s) && !/！/.test(s)) return 12;
  if (/やった|すごい|ほっほ|あはは|おめでとう/.test(s)) return Math.random() < 0.5 ? 9 : 6;
  if (/おーい|やあ|じゃあな|またな|さらば/.test(s)) return 5;
  return 4;
}
function face(e, p) { try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
/* 1行ずつ 流す。長さに 合わせて 待つ（2〜7秒）*/
async function flow(p, text, bar, sp, act) {
  if (!ok(p) || SKIP.has(p.id)) return;
  try { p.sendMessage(text); } catch {}
  if (sp) { try { sp.setProperty("mrpg:act", act); sp.setProperty("mrpg:mv", false); } catch {} face(sp, p); }
  const len = plain(bar).replace(/§./g, "").length, T = Math.min(140, 40 + len * 2);
  let held = 0;
  for (let t = 0; t < T; t += 5) {
    if (!ok(p)) break;
    if (t % 20 === 0) try { barNote(p).setActionBar(`${bar}\n§8しゃがむ: 次へ ／ 長押し: スキップ`); } catch {}
    let sn = false; try { sn = p.isSneaking; } catch {}
    if (sn) { held += 5; if (held >= 30) { SKIP.add(p.id); try { barNote(p).setActionBar("§7会話を スキップ"); } catch {} break; } }
    else if (held > 0) { if (t >= 10) break; held = 0; }   /* 短く しゃがんで はなした → 次へ */
    await wait(5);
  }
  if (sp) try { sp.setProperty("mrpg:act", 0); } catch {}
}
export async function talk(p, who, lines, col = "§6") {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { for (const l of [].concat(lines)) await notice(p, who, /^§7→/.test(l) ? l : `${col}§l${who}§r\n\n§f「${l}」`); return; }   /* 模擬テスト用 */
  if (SKIP.has(p.id)) return;
  let sp = null; try { if (!/手紙|声|心の/.test(plain([].concat(lines)[0]))) sp = FIND ? FIND(p, who) : null; } catch {}
  lock(p);
  try {
    for (const l of [].concat(lines)) {
      if (SKIP.has(p.id)) break;
      if (/^§7→/.test(l)) { await flow(p, l, l, null, 0); continue; }
      await flow(p, `${col}§l${who}§r§f「${l}」`, `${col}${who}§f「${l}」`, sp, gesture(l));
    }
  } finally { unlock(p); }
}
export async function tell(p, title, lines) {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { await notice(p, title, [].concat(lines).join("\n")); return; }
  if (SKIP.has(p.id)) return;
  lock(p);
  try { for (const l of [].concat(lines).flatMap((x) => String(x).split("\n"))) { if (SKIP.has(p.id)) break; if (!l.replace(/§./g, "").trim()) continue; await flow(p, `§7${l}`, `§f${l}`, null, 0); } }
  finally { unlock(p); }
}
