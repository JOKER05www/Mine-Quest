/* 第126版 本1「旅立ち」（アルカトラス地方・ルミナ）— 作業 MA
   ・古い 話 r0e2〜r0e6（ep_r0.js）の 場面は そのまま 生かし（oldRun）、バイブルの 拍を 前後に 足す
   ・MQ0 = b01e1〜e3（牧場）／MQ1 = b01e6（北の 門の 外。今の 段の 場面 ＋ 帽子の 選択 C01）／MQ2 = b01e8（城の 中庭。マスター戦の あと）
   ・この ファイルの 小道具（oldRun・mqRun・H4・once など）は bk_b02〜b04 も 使う */
import { world } from "@minecraft/server";
import { bkAdd, mqOver, bkHas } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { facAdd, FAC_OPS } from "./epfac.js";
import { __ep } from "./sagaep.js";
import { MQ, HEROES, hasKey } from "./saga.js";
import { qs } from "./quest.js";
import { load, save } from "./store.js";
import { ok, choose, giveItem } from "./ui.js";
import { TOWNS, getTown, townPos, groundY } from "./structures.js";
import { placeOf, bldOf } from "./storyplace.js";
import { SPECIES, ITEMS } from "./data.js";
import { stageFor, standY, clampPath, freeAt } from "./stagecore.js";
import { r0Field } from "./ep_r0.js";
import { gateSet, moveG } from "./pvplace.js";   /* 第126版(PV): 麦畑は 町の 外れ（祭りは 広場）*/

/* ---------- 共通の 小道具（b02〜b04 も 使う）---------- */
export const H4 = (g, o, c, t) => ({ g, o, c, t });
export const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
export const OLDE = (id) => __ep.BYID.get(id) || null;
/* 古い 話の 場面を そのまま 流す（舞台の まん中を 古い 話の 場所に して、ほうびは 新しい 話の 名で）*/
export async function oldRun(p, d, K, oid, e) {
  const o = OLDE(oid); if (!o) return true;
  const dd = load(p) || d; if (!dd) return false; const S = K.S(p), bs = qs(dd).bkSpot, c = bs && bs.id === e.id ? bs : S && S.opt && S.opt.anchor ? S.opt.anchor : S ? S.P : p.location;
  qs(dd).epSpot = { id: oid, i: `ep:${oid}`, x: Math.floor(c.x), y: Number.isFinite(c.y) ? Math.floor(c.y) : null, z: Math.floor(c.z), nm: "", np: 1, r: 4 }; save(p, dd);
  const K2 = { ...K, pay: (pp, _e, g, it) => K.pay(pp, e, g, it) };
  try { return (await o.run(p, load(p) || dd, K2)) === true; }
  finally { const d2 = load(p); if (d2 && qs(d2).epSpot && qs(d2).epSpot.id === oid) { delete qs(d2).epSpot; save(p, d2); } }
}
/* 今の 段（saga.js の MQ）の 場面を そのまま 流す */
export async function mqRun(p, d, i) { const st = MQ[i]; if (!st || !st.run) return true; return (await st.run(p, load(p) || d)) === true; }
/* ワールドに 1回だけ（小道具を 置く）*/
export function once(key, fn) { const k = `mrpg:epdeco:${key}`; try { if (world.getDynamicProperty(k)) return false; } catch { return false; } try { fn(); } catch {} try { world.setDynamicProperty(k, 1); } catch {} return true; }
export const gy = (p, x, z, y0) => { try { const y = groundY(p.dimension, Math.floor(x), Math.floor(z), y0 + 6); return typeof y === "number" && Math.abs(y - y0) <= 5 ? y : null; } catch { return null; } };
/* 石に なった 人（子どもや 大人の 背たけの 石。ワールドに 1回）*/
export function stoneMan(K, p, key, q, tall = true) { once(key, () => { const y = gy(p, q.x, q.z, Math.floor(q.y)); if (y === null) return; K.cmd(p, `setblock ${Math.floor(q.x)} ${y} ${Math.floor(q.z)} cobblestone_wall`); if (tall) K.cmd(p, `setblock ${Math.floor(q.x)} ${y + 1} ${Math.floor(q.z)} stone`); }); return { x: Math.floor(q.x) + 0.5, y: q.y, z: Math.floor(q.z) + 0.5 }; }
export const at2 = (K, p, a, b, dy = 0) => { const S = K.S(p); return S ? S.at(a, b, dy) : K.fwd(p, a, b, dy); };
/* 第126版(PV): 吹っ飛ぶ（攻撃した 側から 離れる 向き。あなたと ほかの 人から 2マス 以上・立てる 地面・壁の 手前。まっすぐ 後ろが あなたなら 斜め 横へ）*/
export async function knockSafe(K, p, e, from, dist = 3) {
  if (!ok(e) || !from) return null; const l = e.location, S = stageFor(e) || K.S(p), dim = p.dimension;
  const a0 = Math.atan2(l.z - from.z, l.x - from.x), P0 = p.location; let best = null;
  for (const dd of [dist, dist + 1, dist + 2]) { for (const da of [0, 0.6, -0.6, 1.1, -1.1, 1.6, -1.6]) {
    const a = a0 + da; let to = { x: l.x + Math.cos(a) * dd, y: l.y, z: l.z + Math.sin(a) * dd };
    if (S) to = clampPath(S, l, to); if (Math.hypot(to.x - l.x, to.z - l.z) < 1.5) continue;
    const y = standY(dim, to.x, to.z, l.y, S && S.C); if (y === null) continue; to.y = y;
    if (Math.hypot(to.x - P0.x, to.z - P0.z) < 2.2) continue; if (S && !freeAt(S, to, e, 2)) continue;
    { const ux = to.x - from.x, uz = to.z - from.z, n = Math.hypot(ux, uz) || 1, hx = to.x + (ux / n) * 1.8, hz = to.z + (uz / n) * 1.8;   /* 倒れた 体（頭は 攻撃と 反対の 背中の 側へ 1.8）が だれの 足もとにも かからない */
      const who = [P0]; try { if (S) for (const o of S.ents) if (o !== e && ok(o)) who.push(o.location); } catch {}
      if (who.some((w) => { for (let t = 0; t <= 1.001; t += 0.25) if (Math.hypot(to.x + (hx - to.x) * t - w.x, to.z + (hz - to.z) * t - w.z) < 1.3) return true; return false; })) continue; }
    best = to; break; } if (best) break; }
  if (!best) { K.act(e, "down"); return null; }
  K.act(e, "knocked", false); if (S && S.dest) S.dest.set(e.id, best);
  for (let k = 1; k <= 8; k++) { if (!ok(e)) return best; const t = k / 8; try { e.teleport({ x: l.x + (best.x - l.x) * t, y: l.y + (best.y - l.y) * t + Math.sin(t * Math.PI) * 1.2, z: l.z + (best.z - l.z) * t }, { facingLocation: { x: from.x, y: best.y + 1, z: from.z } }); } catch {} await K.wait(1); }
  K.act(e, "down"); return best;
}
export const out = async (K, p, e) => { if (!ok(e)) return; const q = K.away(e, p, 12), l = e.location; if (!q || Math.hypot(q.x - l.x, q.z - l.z) < 4) return K.bye(p, e); return K.leave(e, p, 12, false); };

/* ---------- 場所 ---------- */
const lumina = () => { const q = getTown("t0"); if (q && q.built) return { x: q.x, y: q.y, z: q.z }; const t = TOWNS.find((u) => u.id === "t0"); return t ? townPos(t) : null; };
const ARENA = () => { const c = lumina(); return c ? { x: c.x + 25, y: c.y, z: c.z + 5, fx: c.x + 25, fz: c.z + 13, nm: "ルミナの 闘技場の 前" } : null; };
const ALLEY = () => bldOf("t0", ["home3", "home2", "home"], "ルミナの 裏通り") || (() => { const c = lumina(); return c ? { x: c.x - 14, z: c.z + 20, nm: "ルミナの 裏通り" } : null; })();
const FEST = (p) => { const o = OLDE("r0e2"); try { return o ? o.place(p) : null; } catch { return null; } };
const HAKU = SPECIES.hbea14 ? "hbea14" : SPECIES.hbea01 ? "hbea01" : null;

/* ---------- 施設（新しい セット）---------- */
const { F, S1 } = FAC_OPS;
/* ハクの 小屋: 板の 小屋・干し草・戸口の 横の 皮を むいた 丸太の 柱（子どもの 絵）*/
facAdd("b01hut", { D: [11, 14, 9], box: [-1, -4, 5, 4], H: 4, look: [0, -2, 1.4], marks: { pillar: [0, -2, 1.2] }, build: () => [
  F(1, -3, 0, 4, 3, 2, "oak_planks"), F(2, -2, 0, 3, 2, 2, "air"), F(1, -1, 0, 1, 1, 1, "air"),
  F(1, -3, 0, 1, -3, 2, "stripped_oak_log"), F(1, 3, 0, 1, 3, 2, "oak_log"), F(4, -3, 0, 4, -3, 2, "oak_log"), F(4, 3, 0, 4, 3, 2, "oak_log"),
  F(0, -4, 3, 5, 4, 3, "oak_slab"), S1(3, -2, 0, "hay_block"), S1(3, 2, 0, "hay_block"), S1(2, 2, 0, "hay_block"), S1(2, 0, 2, 'lantern ["hanging"=true]'),
  F(-1, -4, 0, -1, -4, 1, "oak_fence"), F(-1, 4, 0, -1, 4, 1, "oak_fence"),
] });
/* オルドの 石板蔵: 石の 小さな 蔵・鉄の 格子戸・奥に 石板を 置く 書見台・灯り */
facAdd("b01kura", { D: [11, 14, 9], box: [-1, -4, 6, 4], H: 5, look: [3, 0, 1.4], marks: { slab: [4, 0, 1.3] }, build: () => [
  F(1, -3, 0, 5, 3, 3, "stone_bricks"), F(2, -2, 0, 4, 2, 2, "air"), F(1, 0, 0, 1, 0, 1, "air"), F(1, -1, 0, 1, -1, 1, "iron_bars"),
  F(0, -4, 4, 6, 4, 4, "stone_brick_slab"), S1(4, 0, 0, "chiseled_stone_bricks"), S1(4, 0, 1, "lectern"), S1(3, -2, 2, 'lantern ["hanging"=true]'),
  S1(2, 2, 0, "barrel"), S1(3, 2, 0, "barrel"), S1(-1, -2, 0, "stone_brick_wall"), S1(-1, -2, 1, "lantern"),
] });

/* ---------- 登場人物（町の 人の その後）---------- */
castAdd("b01guide", { nm: "案内人", role: "闘技場の", gobi: "ですよ", skin: 7, town: "t0", hide: (s) => !bkHas(s, "b01e4"),
  at: () => { const q = ARENA(); return q ? { x: q.x - 3, y: q.y, z: q.z - 1 } : null; },
  pre: ["{smile}闘技場へ ようこそ ですよ。"],
  after: [
    [(s) => !!s.ending, ["{smile}この 人形ですか？ ……ずっと 前に、旅の 子に もらったんですよ。", "{closed}名前は 書いて ないんですよ。だから、毎日 なでて おくんですよ。"]],
    [() => true, ["{smile}掟は 三度の 名乗り ですよ。勝ったら、客席の みんなが 名を 呼ぶんですよ。", "{closed}……この 人形？ 古い ものですよ。手放せないんですよ。"]],
  ] });
castAdd("b01farmw", { nm: "マーサ", role: "農夫の 女房", gobi: "よ", skin: 3, town: "t0", hide: (s) => !bkHas(s, "b01e7"),
  at: () => { const c = lumina(); return c ? { x: c.x - 6, y: c.y, z: c.z + 24 } : null; },
  pre: ["{smile}いらっしゃい。"],
  after: [
    [(s) => !!s.ending, ["{smile,tears}……亭主、畑に 戻って きたのよ。『ずっと 続けば』なんて、もう 言わないって。"]],
    [() => true, ["{sad}亭主は 畑で、笑った まま 石に なったのよ。", "{closed}毎朝 水を やって、名前を 呼ぶの。……ほかに できる ことが ないからよ。"]],
  ] });

/* ---------- 1話 オルドの 牧場・ハクの 小屋（MQ0）---------- */
const E1 = { id: "b01e1", t: "ハクの 小屋", F: ["F02", "F48"], battles: 0,
  hint: "§fルミナの 外れの §eオルドの 牧場§f へ 行こう §7（幼なじみが 待って いる）",
  syn: "旅立ちの 朝。幼なじみが 自分で 組んだ コンパスを くれた。ハクの 小屋の 柱には、子どもの ころの 絵が あった。ハクと、寝て いる 子と、まわりに びっしりの 丸。……何の 絵だったかは、二人とも 思い出せない。",
  async run(p, d, K) {
    const y0 = Y(K, p);
    if (!qs(load(p) || d).hero) {
      const pick = await choose(p, "幼なじみ", "§f§lあなたの 幼なじみは だれ？\n\n§7小さい ころから いっしょに 育った 仲良しで、旅に ついて くる 仲間です。あとから かえる ことは できません。", HEROES.map((h) => [`§l${h[1]}§r\n§8${h[2]}`, `textures/ui/mrpg/h_${h[0]}`]));
      if (!(pick >= 0)) return false; const dh = load(p); if (!dh) return false; qs(dh).hero = HEROES[pick][0]; save(p, dh);
    }
    const hut = K.fac(p, "b01hut", "b01hut", 0, y0);
    await K.open(p, "オルドの 牧場・ハクの 小屋", "day");
    const eH = K.hero(p);
    K.hold(eH, "compass"); K.act(eH, "show", false);
    await K.up(p, eH, 10);
    await K.hsay(p, H4(["{rage,怒,jump}もう、遅い！ 今日が 旅立ちの 日だって、あれだけ 言ったのに！", "{smile,☆}……ま、いいけど。じゃーん！ わたしが 組んだ §eコンパス§f！"],
      ["{smile}あ、来た来た。おはよう。", "{smile,♪}これ、わたしが 組んだ §eコンパス§f よ。"],
      ["{closed}……やっと 来た。", "{blush}これ。§eコンパス§f。三日で 組んだ。"],
      ["{sweat,汗}おはよう ございます。もう、心配しました。", "{smile}これを どうぞ。わたしが 組んだ §eコンパス§f です。"]));
    await K.push(p, eH, 20, 3.6, 1.2, 1.2);   /* 手の 中の コンパスへ 寄る */
    await K.hsay(p, H4(["{smile,♪,up}行きたい 場所の 方を、ちゃんと 指すんだよ。"], ["{smile,up}行きたい 場所の 方を、ちゃんと 指すのよ。"], ["{closed,up}行きたい 場所の 方を、ちゃんと 指す。……狂ったら 言って。"], ["{smile,up}行きたい 場所の 方を、ちゃんと 指すんです。"]));
    await K.give(eH, null, "compass");
    try { p.addTag("mrpg_navi"); } catch {} if (!hasKey(p, "navi")) try { giveItem(p, "mrpg:navi", 1); } catch {}
    if (ITEMS.k_wmap && !K.replay(p)) { const dk = load(p); if (dk && !(qs(dk).keys || []).includes("k_wmap")) { try { p.addTag("mrpg_wmap"); } catch {} K.giveKey(p, dk, "k_wmap"); save(p, dk); } }
    K.sound(p, "random.levelup", 1);
    /* 小屋の 柱の 絵 /*F02 F48*/
    const pil = hut || at2(K, p, 8, -2, 1);
    if (ok(eH)) await K.walkCam(p, eH, at2(K, p, 6, -1.5), 18);
    await K.at(p, pil, 16, 2.2, 0.4);
    await K.narr(p, ["§7小屋の 柱に、子どもの 描いた 絵。ハクと、その 背中で 寝て いる 子。", "§7まわりには 小さな 丸が、すきまなく びっしり。"], pil);
    await K.up(p, eH, 8);
    await K.hsay(p, H4(["{?}……これ、何の 絵だっけ。わたしたちが 描いたんだよね？"], ["{?}……これ、何の 絵だったかしら。描いたのは、わたしたちよね。"], ["{?}……この 絵。何の 絵だっけ。"], ["{?}……この 絵、何の 絵でしたっけ。わたしたちが 描いたはず ですよね。"]));
    const hk = HAKU ? K.monEnt(p, at2(K, p, 5, 2.5), HAKU, "§fハク") : null;
    if (ok(hk)) { K.sound(p, "mob.horse.idle", 0.8); await K.push(p, hk, 18, 5, 2.2, 1.2); }
    await K.hsay(p, H4(["{smile,…}ハクの 背中で 寝て、ぜんぜん 起きなかった 冬も あったよね。わたし、朝まで 名前 呼んでたんだから。"], ["{smile,…}ハクの 背中で 眠った まま、ちっとも 起きなかった 冬も あったわね。朝まで 名前を 呼んだのよ。"], ["{closed}……ハクの 背中で 寝て、起きなかった 冬が あった。朝まで 名前を 呼んだ。"], ["{smile,…}ハクの 背中で 眠って、ぜんぜん 起きなかった 冬が ありましたね。朝まで お名前を 呼んだんですよ。"]), hk);
    await K.hsay(p, H4(["{smile,☆}……ま、いいや！ 村長が 蔵で 呼んでるよ。"], ["{smile}……さ、村長さんが 蔵で 待ってるわ。"], ["{closed}……村長が 蔵で 待ってる。"], ["{smile}……村長さまが 蔵で お待ちです。"]));
    if (ok(hk)) K.rmCine(hk);
    await K.end(p, { card: "§7― オルドの 石板蔵へ ―" });
    const d1 = load(p); if (d1) { qs(d1).introDone = 1; save(p, d1); }
    return true;
  } };

/* ---------- 2話 オルドの 石板蔵（MQ0）---------- */
const E2 = { id: "b01e2", t: "書けない 名", F: ["F01", "F02"], battles: 0,
  hint: "§fオルドの 牧場の §e石板蔵§f へ 行こう",
  syn: "蔵の 石板が 光り、表に あなたの 名が 浮かびかけて、砂のように 崩れた。オルドは「……書けんのか」と だけ 言った。王は 心を 呑む 怪物、と オルドは 昔話を した。「石に 彫って ある ことが 本当とは かぎらんがの」。",
  async run(p, d, K) {
    const y0 = Y(K, p), kq = K.fac(p, "b01kura", "b01kura", 0, y0);
    await K.open(p, "オルドの 石板蔵", "day");
    const slab = kq || at2(K, p, 8, 0, 1.3);
    const eO = K.npcNear(p, "§eオルド", K.PJ("ordo", 8)); K.act(eO, "hold");
    const eH = K.hero(p);
    await K.up(p, eO, 8);
    await K.say(p, "オルド", ["{closed}来たか。……旅に 出る 前に、見て おいて ほしい ものが ある。"]);
    if (ok(eO)) await K.walkCam(p, eO, at2(K, p, 6, 0.8), 16);
    await K.at(p, slab, 14, 3, 0.5);
    K.sound(p, "beacon.activate", 0.6); K.burst(p.dimension, slab, "minecraft:enchanting_table_particle", 14, 0.6, 0.6);
    /* 名が 浮かびかけて 崩れる /*F01 F02*/
    await K.push(p, slab, 26, 3, 1.4, 0.4);
    await K.narr(p, ["§7石板の 表に、光る 字が 浮かぶ。……あなたの 名前の、はじめの 一字。", "§7二字めを 書こうと した ところで、字は 砂のように 崩れて 落ちた。"], slab);
    K.burst(p.dimension, slab, "minecraft:falling_dust_sand_particle", 12, 0.5, 0.2);
    await K.up(p, eO, 12);
    await K.say(p, "オルド", ["{closed,…}……書けんのか。"]);
    await K.hsay(p, H4(["{shock,!,up}い、今の なに！？ 名前……消えちゃった！"], ["{shock,…}……今、名前が 消えたわ。"], ["{shock,!}……字が、崩れた。"], ["{shock,!,up}い、今……お名前が、消えました……！"]), eO);
    await K.say(p, "オルド", ["{closed}……わしにも 分からん。石板は、まれに 反応する 者を 選ぶ。昨夜、こいつは おまえさんの 名を 呼ぶように 光った。"]);
    /* 軒下の 野良が 唸りに 耳を 立てる */
    const st = K.monEnt(p, at2(K, p, 4, -2.8), K.wildSp("animal"), "§7軒下の 野良");
    if (ok(st)) { K.sound(p, "mob.wolf.growl", 0.5); await K.push(p, st, 16, 3.5, 1.4, 0.6); }
    await K.narr(p, ["§7軒下で 丸く なって いた 野良の 小さな モンスターが、石板の ほうへ 耳を 立てた。"], st);
    if (ok(st)) K.rmCine(st);
    await K.say(p, "オルド", ["{low}……この 石板が 何か、ルミナの 年寄りは みな 同じ 話を 教わる。"]);
    await K.flashback(p, { label: "§7―― 千年前（言い伝え）", tod: "dusk", ptc: "ash",   /* 第127版: 言い伝えを 絵で（石に 彫られた とおりの 話）*/
      actors: { king: { nm: "§8王と 呼ばれる もの", job: K.PJ("arca13", 8), at: [5, 0], look: [0, 0] }, pr: { nm: "§7石板を 掲げる 神官", job: K.PJ("m6_sage", 8), at: [2.4, -1.4], look: "king", hold: "tablet" }, m1: { nm: "§7都の 男", job: K.PJ("m6_mason", 8), at: [1.6, 1.6], look: "king", act: "guard" } },
      beats: [
        ["narr", "§7千年前の 都。広場の まん中に、§f王§7 と 呼ばれる ものが 立って いた。", "king"],
        ["act", "king", "raise"], ["fx", "ash", [5, 0, 1.4]],
        ["say", "m1", "{shock,!,up}王の 目を 見るな！ 心を 呑まれるぞ！", "king"],
        ["say", "pr", "{angry,up}十五枚の 石板を ここへ！ 王と、十四の 主を 封じる！", "m1"],
        ["act", "pr", "show"], ["fx", "light", [5, 0, 1]], ["snd", "beacon.activate", 0.6],
        ["narr", "§7光の 中で、王の 姿は 石板の 中へ 吸いこまれて いった。", "king"],
        ["act", "king", "kneel"],
        ["say", "m1", "{sad,up}……これで もう、だれも 呑まれない。", "pr"],
        ["narr", "§7……と、石に 彫られて いる。", [3, 0, 0.5]],
      ] });
    await K.say(p, "オルド", ["{low}大昔、§6王§f と 呼ばれる ものが おった。人と モンスターの 心を 呑む 怪物じゃ。", "人々は 王と 十四の §6主§f を、十五枚の 石板に 封じた。……その 封印が、今 ゆるみ始めて おる。"]);
    await K.up(p, eO, 10);
    await K.say(p, "オルド", ["{closed}……と、わしらは 教わった。石に 彫って ある ことが、本当とは かぎらんがの。"]);
    await K.hsay(p, H4(["{?}本当じゃ ないかも しれないの？ ……じゃあ、なんで 名前が 書けないのか、調べなきゃ！", "{smile,☆}決めた、わたしも ついて いく！ 旅の 手帳は わたしが つけるね。"],
      ["{?}……本当とは かぎらない、のね。", "{smile}じゃあ、わたしも 行くわ。旅の 手帳は わたしが つけるね。"],
      ["{closed}……書けない 理由が 分からないなら、調べる しか ない。", "{up}わたしも 行く。旅の 手帳は わたしが つける。"],
      ["{?}……本当では ないかも しれない、と。", "{smile}でしたら、わたしも お供します。旅の 手帳は わたしが つけますね。"]), eO);
    await K.up(p, eO, 8);
    await K.say(p, "オルド", ["{smile}ほっほ、頼もしい。……放牧地で、孫の §bレイ§f が 待って おる。"]);
    await K.end(p, { leave: [eO], card: "§7― 牧場の 放牧地へ ―" });
    const d1 = load(p); if (d1) { qs(d1).introDone = 1; save(p, d1); }
    return true;
  } };

/* ---------- 3話 牧場の 放牧地（MQ0。レイとの 勝負は 今の 段の 場面）---------- */
const E3 = { id: "b01e3", t: "レイとの 勝負", battles: 1,
  hint: "§fオルドの 牧場の §e放牧地§f で §bレイ§f と 勝負",
  syn: "オルドの 孫の レイが 竜を 連れて 来た。「負けたら、旅は オレが 一緒に 行く」。勝負に 勝つと、レイは「いつか 必ず 追いつく」と 言って 去った。オルドは 城の 地方マスター ミドリの ことと、六影と いう 連中の ことを 話した。",
  async run(p, d, K) {
    { const d1 = load(p) || d; if (!qs(d1).introDone) { qs(d1).introDone = 1; save(p, d1); } }
    await K.open(p, "オルドの 牧場の 放牧地", "day");
    return mqRun(p, d, 0);
  } };

/* ---------- 4話 祭りの 支度 → 闘技場の 前（古い r0e2 ＋ 畑の 農夫 ＋ 闘技場の 前）---------- */
const E4 = { id: "b01e4", t: "収穫祭の 前", F: ["F10", "F12", "F16", "F25", "F54", "F55", "F64"], battles: 1,
  place: (p) => FEST(p),
  hint: "§fルミナの §e広場§f へ 行こう §7（パン屋の §eミミ§7 が 祭りの 支度を して いる。そのあと 闘技場の 前へ）",
  syn: "パン屋の ミミと 祭りの 支度を した。畑の 農夫は「この 実りが、ずっと 続けばなあ」と 笑った。闘技場の 前の 石には「名乗りは 三度。勝った 者の 名は、客席の みんなで 呼ぶ」。人形を 抱いた 案内人、壁に もたれて 眠る 刀の 老人。ノルじいは 北の 門の 鐘の 話を した。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r0e2", E4))) return false;
    /* 畑の 農夫（7話で 石に なる 人）*/
    if (K.S(p)) {
      const FQ = r0Field(); if (FQ) { await moveG(K, p, FQ, "ルミナの 外れの 麦畑"); K.deco(p, "t0field", 0, { x: FQ.x + 0.5 - 14, z: FQ.z + 0.5 }, Y(K, p)); } else await K.open(p, "ルミナの 外れの 麦畑", "day");
      const eF = K.npcNear(p, "§e農夫 トマス", 3); K.act(eF, "work"); K.hold(eF, "basket");
      await K.up(p, eF, 10);
      await K.say(p, "トマス", ["{smile}今年の 麦は 粒が 重いんだ。……この 実りが、ずっと 続けばなあ。"]);
      const eH0 = K.hero(p);
      await K.hsay(p, H4(["{smile,♪}きっと 来年も 重いよ！"], ["{smile}来年も、きっとね。"], ["{closed}……来年も、たぶん。"], ["{smile}来年も きっと 実りますよ。"]), eF);
      await K.end(p, { leave: [eF] });
      if (ok(eH0)) K.rm(eH0);
    }
    /* 闘技場の 前 */
    const A = ARENA(); if (!A) return true;
    await K.moveTo(p, A, "ルミナの 闘技場の 前", [], { x: A.fx, y: A.y + 2, z: A.fz });
    const y0 = Y(K, p), sq = at2(K, p, 3, -2.5);
    once("b01okite", () => { const y = gy(p, sq.x, sq.z, y0); if (y === null) return; K.cmd(p, `setblock ${Math.floor(sq.x)} ${y} ${Math.floor(sq.z)} chiseled_stone_bricks`); K.cmd(p, `setblock ${Math.floor(sq.x)} ${y + 1} ${Math.floor(sq.z)} chiseled_stone_bricks`); });
    const eH = K.hero(p), eM = K.cast(p, "mimi"); K.hold(eM, "basket");
    await K.up(p, eM, 8);
    await K.csay(p, "mimi", ["{smile,♪}お祭りの 夜は ここも 灯りを つけるんだよっ。……ほら、掟の 石、読める？"], eH);
    await K.at(p, { x: sq.x, y: y0, z: sq.z }, 16, 2.2, 1.2);   /* 掟の 石の 寄り /*F12 F25*/
    await K.narr(p, ["§7石に 彫られた 字。「§f名乗りは 三度。勝った 者の 名は、客席の みんなで 呼ぶ§7」"], { x: sq.x, y: y0, z: sq.z });
    await K.hsay(p, H4(["{?}名前を、みんなで 呼ぶ……。なんで 三度なんだろ。"], ["{?}三度……。どうして 三度なのかしら。"], ["{?}三度。……理由は 書いて ない。"], ["{?}三度、ですか。理由は 書いて ありませんね。"]), eM);
    /* 壁に もたれて 眠る 老人（赤黒い 鍔の 刀）*/
    const eK = K.npcNear(p, "§7眠る 老人", 18, true); K.act(eK, "down"); K.hold(eK, "katana");
    if (ok(eK)) await K.pull(p, eK, 24);
    await K.narr(p, ["§7闘技場の 壁に もたれて、老人が 一人 眠って いる。", "§7抱えた 刀の 鍔は、赤黒い。"], eK);
    /* 人形を 抱いた 案内人 /*F54*/
    const eG = K.cast(p, "b01guide"); K.hold(eG, "box");
    await K.up(p, eG, 10);
    await K.csay(p, "b01guide", ["{smile}あの おじいさん？ 祭りの 前に なると、毎年 来て 寝て いくんですよ。", "{closed}……この 人形？ 古い ものですよ。手放せないんですよ。"]);
    if (ok(eG)) await K.at(p, eG.location, 12, 1.4, 1.1);
    /* ノルじいの 鐘の 話 /*F64 F10*/
    const eN = K.cast(p, "nol");
    await K.up(p, eN, 8);
    await K.csay(p, "nol", ["{smile}ほっほ、北の 門の 鐘を 見たかの。", "{closed}あれは 四十年 前、オルドと 星の 好きな 若いのが 吊ったんじゃよ。"], eH);
    await K.csay(p, "nol", ["{smile,…}星の 好きな 男は、生まれた ばかりの 娘に、紐を 編んで おった。"], eH);
    /* パン屋の 麦の 紋・協会の リリの 押し花 /*F55 F16*/
    await K.up(p, eM, 8);
    await K.csay(p, "mimi", ["{smile,♪}うちの パンの 麦の 紋はね、お父さんが 彫ったんだよっ。協会の リリさんは、押し花を 窓に 飾ってるの。", "{smile,…}……道化の 一座の あの子にも、パン、もう 半分こ したいんだよっ。"], eH);
    await K.hsay(p, H4(["{smile}お祭り、ぜったい 来るね！"], ["{smile}お祭りの 夜、また 来るわね。"], ["{closed}……祭りの 夜、来る。"], ["{smile}お祭りの 夜、必ず 参ります。"]), eM);
    await K.end(p, { leave: [eM, eN, eG], bye: [eK], card: "§7― 収穫祭の 夜へ ―" });
    return true;
  } };

/* ---------- 5話 ルミナの 収穫祭（夜）（古い r0e3 ＋ 裏通りの ガロ）---------- */
const E5 = { id: "b01e5", t: "祭りの 夜", F: ["F09"], battles: 1,
  place: (p) => FEST(p),
  hint: "§fルミナの §e広場§f で §6収穫祭§f が 始まる",
  syn: "収穫祭の 夜、六影の ガロが 屋台を おどし、小さな モンスターを さらって 北の 門へ 逃げた。追いかけた 裏通りで、あなたは ガロが 取り立てた 麦を 小さな 子らに 配る ところを 見た。六影の 名を 聞いた ときの オルドの 顔を、幼なじみは「牧場でも 同じ 顔 してた」と 言った。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r0e3", E5))) return false;
    const A = ALLEY(); if (!A) return true;
    await K.moveTo(p, A, "ルミナの 裏通り（夜）", [], Number.isFinite(A.fx) ? { x: A.fx, y: (A.y ?? p.location.y) + 2, z: A.fz } : null);
    const eH = K.hero(p);
    const eG = K.npcNear(p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9)); K.hold(eG, "pouch");
    const k1 = K.npcNear(p, "§7小さな 子", 6), k2 = K.npcNear(p, "§7小さな 子の 弟", 5);
    /* 台詞なし: ガロが 麦を 配る /*F09*/
    await K.pull(p, eG, 20);
    if (ok(eG) && ok(k1)) await K.give(eG, k1, "pouch");
    if (ok(eG)) await K.at(p, eG.location, 14, 3.2, 1.2);
    if (ok(eG) && ok(k2)) { K.hold(eG, "pouch"); await K.give(eG, k2, "pouch"); }
    await K.narr(p, ["§7ガロは 何も 言わずに、取り立てた 麦の 袋を 小さな 子らに 押しつけて、門の ほうへ 走って いった。"], eG);
    if (ok(eG)) await out(K, p, eG);
    await K.up(p, eH, 10);
    await K.hsay(p, H4(["{sad,…}……ねえ。村長、六影の 名前を 聞いた とき、すごい 顔してた。", "{closed}牧場でも 同じ 顔 してた。……なんでだろ。"],
      ["{sad}……村長さん、六影の 名前を 聞いた とき、こわい 顔を してたわ。", "{closed}牧場でも、同じ 顔 してた。"],
      ["{closed}……村長。六影の 名で、顔が かわった。", "{?}牧場でも 同じ 顔。……何か 知ってる。"],
      ["{sad}……村長さま、六影の 名を 聞いた とき、お顔が かわりました。", "{closed}牧場でも、同じ お顔を されて いました。"]));
    await K.end(p, { leave: [k1, k2], card: "§7― ガロは 北の 門の 外へ ―" });
    return true;
  } };

/* ---------- 6話 北の 門の 外の 道（MQ1。今の 段の 場面 ＋ 帽子の 選択）---------- */
const E6 = { id: "b01e6", t: "北の 門の 外", F: ["F07", "F08", "F18"], keys: ["k_note"], battles: 1,
  hint: "§fルミナの §e北の 門§f を 出て、ガロを 追おう",
  syn: "ガロと 手下の ピコに 追いつき、さらわれた 小さな モンスター（あなたの 相棒）を 取り戻した。空が 黒く なり、影に 呑まれた ピコは ガロの 袖を にぎった まま 眠った。転がった 小さな 帽子。学者 セオが 研究メモを くれた。表紙には 紫の インクの「ひらいた 本」の 判と、一語を 消した 跡。",
  async run(p, d, K) {
    { const S = K.S(p), c = lumina(); if (S && c) gateSet(p, "t0n", S.P, c, Y(K, p)); }   /* 第126版(PV): 門の 外の 道（土の 道・灯り・道しるべ）*/
    await K.open(p, "北の 門の 外の 道", "dusk");
    const r1 = await mqRun(p, d, 1);
    try { for (const e of p.dimension.getEntities({})) if ((e.hasTag("mrpg_cine") || e.hasTag("mrpg_saga") || e.hasTag("mrpg_actor")) && !e.hasTag("mrpg_field") && /小さな モンスター/.test(String(e.nameTag || "")) && Math.hypot(e.location.x - p.location.x, e.location.z - p.location.z) < 64) K.rm(e); } catch {}   /* 助けた 子の 姿（相棒が もう いる セーブ）*/
    if (!r1) return false;
    /* 帽子（C01）: ガロは ピコを 背負って いて 拾えない /*F18*/
    await K.open(p, "北の 門の 外の 道", "dusk");
    const eH = K.hero(p), cap = at2(K, p, 3.5, 0.6);
    K.burst(p.dimension, cap, "minecraft:white_smoke_particle", 3, 0.3, 0.1);
    await K.at(p, cap, 14, 1.6, 0.2);
    await K.narr(p, ["§7道の まん中に、小さな 帽子が 一つ 転がって いる。ピコの 帽子だ。"], cap);
    const eG = K.npcNear(p, "§c六影の 下っぱ ガロ", K.PJ("garo", 9)); K.act(eG, "hold");
    await K.pull(p, eG, 16);
    await K.narr(p, ["§7背中に 眠った ピコ。小さな 手が、ガロの 袖を にぎった まま。", "§7ガロは 帽子の 前で 止まり、かがめずに 立ちつくした。……ぐう、と 腹が 鳴る。"], eG);
    await K.up(p, eG, 8);
    await K.say(p, "ガロ", ["{angry,low}……見るな。"]);
    const v = await K.pick(p, "c01");
    if (v === "g") {
      if (ok(eH) && ok(eG)) { await K.approach(p, eH, eG, 1.4); await K.give(eH, eG, "box"); }
      await K.up(p, eG, 10);
      await K.say(p, "ガロ", ["{closed,…}……借りだ。"]);
    } else {
      await K.up(p, eG, 10);
      await K.say(p, "ガロ", ["{angry}……勝手に しろ。拾った やつの もんだ。"]);
      K.key(p, "k_cap");
    }
    if (ok(eG)) await out(K, p, eG);
    /* セオの 左手 /*F07 F08*/
    const eS = K.npcNear(p, "§7学者 セオ", 18); K.act(eS, "point");
    await K.ots(p, eH, eS, 10);
    await K.say(p, "セオ", ["{sweat,汗}……急ぎましょう。祭りの 広場へ。"]);
    if (ok(eS)) { K.camNear(p, eS, 1.0, 1.0); await K.wait(14); }
    await K.narr(p, ["§7町の 灯りを 指す セオの 左手。中指の 先だけが、紫の インクで 染まって いる。"], eS);
    await K.end(p, { leave: [eS], card: "§7― 影は 祭りの 広場へ ―" });
    return true;
  } };

/* ---------- 7話 影が 来る（古い r0e4: 広場 → 門の 外で 戦う ＋ 外れの 麦畑の 石に なった 農夫）---------- */
const E7 = { id: "b01e7", t: "影が 来る", snd: "item.book.page_turn", F: ["F03", "F45"], battles: 1,
  place: (p) => FEST(p),
  hint: "§f影が ルミナの 方へ 流れた！ §eルミナの 広場§f へ もどろう",
  syn: "影が 祭りを 襲い、門番の ゴンザが けがを した。「この 実りが、ずっと 続けばなあ」と 言った 農夫トマスは、畑で 笑った まま 石に なって いた。眠った ピコとは ちがう。オルドは「二十年前と 同じ 影じゃ」と つぶやいた。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r0e4", E7))) return false;
    { const FQ = r0Field(); if (FQ) await moveG(K, p, FQ, "ルミナの 外れの 麦畑（夜明け）"); else await K.open(p, "ルミナの 外れの 麦畑（夜明け）", "ash"); }
    const y0 = Y(K, p), fq = stoneMan(K, p, "b01stone", at2(K, p, 9, 3, 0));
    const eH = K.hero(p);
    await K.push(p, { x: fq.x, y: y0, z: fq.z }, 26, 6, 2.2, 1.2);   /* 笑った まま 石に /*F45 F03*/
    await K.narr(p, ["§7畑の まん中に、鎌を 持った まま の 石が 立って いる。", "§7……きのう「この 実りが、ずっと 続けばなあ」と 笑った 農夫の、笑った 顔の まま。"], { x: fq.x, y: y0, z: fq.z });
    await K.up(p, eH, 10);
    await K.hsay(p, H4(["{shock,…,up}……トマスさん？ ……ピコは 眠ってたのに、なんで 石なの……？"], ["{shock,…}……トマスさん。ピコくんは 眠って いただけ なのに……石に？"], ["{shock}……石。ピコは 眠り。こっちは 石。……ちがう。"], ["{shock,…}トマスさん……。ピコさんは 眠って いたのに、こちらは 石に……"]));
    const eO = K.npcNear(p, "§eオルド", K.PJ("ordo", 8)); K.act(eO, "hold");
    await K.up(p, eO, 10);
    await K.say(p, "オルド", ["{closed,low}……眠りと 石は、別の ものじゃ。", "{sad}二十年前と 同じ 影じゃ。……あの 冬も、こうじゃった。"]);
    await K.end(p, { leave: [eO], card: "§7― アルカトラス城へ ―" });
    return true;
  } };

/* ---------- 8話 アルカトラス城の 中庭（MQ2。マスター ミドリに 勝った あと）---------- */
const E8 = { id: "b01e8", t: "城の 中庭", F: ["F33"], keys: ["bslab"], battles: 0,
  hint: "§fアルカトラス城の §6地方マスター ミドリ§f に 勝とう",
  syn: "ミドリに 勝つと、王 アルカ十三世が 中庭に 来た。「父が 追い返した 男が いた。星の 冠のような 紋の」。ミドリは 中庭の 奥の、石に なった 相棒の 頭を なでた。戦う 前と あとに、いつも そう するのだと いう。",
  async run(p, d, K) {
    await K.open(p, "アルカトラス城の 中庭", "castle");
    const eH = K.hero(p), eMi = K.cast(p, "midori"), eA = K.cast(p, "arca");
    const sq = stoneMan(K, p, "b01mstone", at2(K, p, 9, -3, 0), false);
    if (ok(eMi)) await K.walkCam(p, eMi, at2(K, p, 8, -2), 16);
    await K.at(p, { x: sq.x, y: Y(K, p), z: sq.z }, 14, 2.4, 0.6);   /* 石の 相棒 /*F33*/
    K.act(eMi, "kneel");
    await K.narr(p, ["§7中庭の 奥。石に なった 小さな モンスターの 頭を、ミドリが そっと なでる。"], eMi);
    await K.up(p, eMi, 8);
    await K.csay(p, "midori", ["{closed}……戦う 前と あとに、この 子を なでるの。さっきも そう してから 行ったわ。"], eH);
    K.act(eMi, 0);
    await K.ots(p, eH, eA, 10);
    await K.csay(p, "arca", ["{closed}見事で あった。……一つ、話して おこう。", "{low}父の 代に、城の 封印庫を 見せよと 言うて 来た 男が いた。父は 追い返した。"], eH);
    await K.up(p, eA, 10);
    await K.csay(p, "arca", ["{closed}星の 冠のような 紋の、男で あった。"], eH);
    await K.hsay(p, H4(["{?}星の 冠……。手帳に 描いとく！"], ["{?}星の 冠の 紋……。手帳に 描いて おくわ。"], ["{closed}星の 冠の 紋。……書いた。"], ["{?}星の 冠の 紋……。手帳に 写して おきます。"]), eA);
    await K.end(p, { leave: [eA], bye: [eMi] });
    return true;
  } };

/* ---------- 9話 ルミナの やり直しの 収穫祭（古い r0e6）---------- */
const E9 = { id: "b01e9", t: "やり直しの 収穫祭", F: ["F47"], battles: 0,
  place: (p) => FEST(p),
  hint: "§fルミナの §e広場§f で §6やり直しの 収穫祭§f が 開かれる §7（ミミとの 約束。そのあと シルヴァの 洞くつへ）",
  syn: "一枚目の 石板を 封じて ルミナへ もどると、やり直しの 収穫祭が 開かれた。けがの 治った ゴンザは「門は いつでも 開けて 待って おるでござる」と 送り出した。",
  async run(p, d, K) {
    if (!(await oldRun(p, d, K, "r0e6", E9))) return false;   /* ゴンザ「門は いつでも 開けて 待って おる」/*F47*/
    K.key(p, "k_fest0");
    return true;
  } };

bkAdd("b01", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
/* MQ2: 場面（b01e8）の あと、今の 段（セオの 手紙）。古い セーブで b01e8 が 済みなら 手紙だけ */
mqOver(2, async (p, d, K, c) => { if (!(await c.play("b01e8"))) return false; return c.old(); });
