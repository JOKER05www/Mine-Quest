// 第106版: 物語の 山場の 演出。モンスター同士が すばやく ぶつかり合う（約3秒・カメラは 横から）
import { system } from "@minecraft/server";
import { camHold, inScene, camClear, camPut } from "./talk.js";
import { stageOf, standY, freeNear, smokeIn, smokeOut } from "./stagecore.js";
import { load } from "./store.js";
import { ok, wait, sound, showTitle, busy } from "./ui.js";
import { setLook, TYPE } from "./field.js";
import { SPECIES, ORDER } from "./data.js";

const cmd = (p, c) => { try { p.runCommand(c); } catch {} };
const f2 = (v) => v.toFixed(2);
function fx(dim, name, at) { try { dim.spawnParticle(name, at); } catch {} }
const LIVE = (globalThis.__mqCine = globalThis.__mqCine || new Set());   /* 第106版: 演出中の モンスター（これ 以外の 印つきは 片づける） */
function put(dim, sid, at, face) {
  let e; try { e = dim.spawnEntity(TYPE, at); } catch { return null; }
  try { LIVE.add(e.id); } catch {}
  try { e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); setLook(e, sid); e.teleport(at, { facingLocation: face }); } catch {}
  smokeIn(e, 6);   /* 第124版(cam): 煙の 中で あらわれる */
  return e;
}
const pickFoe = (fams) => { const L = ORDER.filter((k) => SPECIES[k] && fams.includes(SPECIES[k].fam) && !SPECIES[k].hidden); return L[Math.floor(Math.random() * L.length)] || ORDER[0]; };

/* p の 先頭の 子（または a）と 相手 b が ぶつかる。opt: { a, b, fams, title, sub } */
export async function duel(p, title, sub, opt = {}) {
  camHold(p);   /* 第113版: 会話の カメラの 片づけが 決闘カメラを 消さない */
  if (!ok(p)) return;
  const dim = p.dimension, L = p.location;
  let a = opt.a; if (!a) { try { const d = load(p); a = d && d.party && d.party[0] && d.party[0].sp; } catch {} }
  a = a || ORDER[0]; const b = opt.b || pickFoe(opt.fams || ["nether"]);
  let r = 0; try { r = (p.getRotation().y * Math.PI) / 180; } catch {}
  const S = stageOf(p), P0 = S ? S.P : L;   /* 第123版: 舞台の 向きで（見て いる 方では ない）*/
  const fw = S ? { x: S.f.x, z: S.f.z } : { x: -Math.sin(r), z: Math.cos(r) }, sd = { x: fw.z, z: -fw.x };
  const gy = (q) => { if (!S) return q; const y = standY(dim, q.x, q.z, P0.y, S.C); if (y !== null && Math.abs(y - P0.y) <= 3) q.y = y; return q; };
  let C = null, cam = null;
  for (const dd of [7, 4.5]) {   /* 第127版: 見通しの よい 絵が なければ ぶつかる 所を 手前に 寄せる（森）*/
    C = gy({ x: P0.x + fw.x * dd, y: P0.y, z: P0.z + fw.z * dd });
    const look = { x: C.x, y: C.y + 1, z: C.z }; for (const [k, h, s2] of [[9, 2.6, 0], [6, 3.2, 2], [6, 3.2, -2], [4, 4, 0], [2.5, 5, 0], [4, 2.4, 4], [4, 2.4, -4], [dd, 2.1, 0]]) { const c = { x: C.x - fw.x * k + sd.x * s2 + 0.01, y: C.y + h, z: C.z - fw.z * k + sd.z * s2 }; if (camClear(p, c, look, null)) { cam = c; break; } }   /* 見通しの よい 所から */
    if (cam) break;
  }
  if (!cam) cam = { x: P0.x + 0.01, y: P0.y + 2.1, z: P0.z };   /* どこも ふさがって いれば あなたの 頭の 上から */
  const fit = (q) => (S && freeNear(S, q, null, 1.0, 2.8)) || q;   /* 第127版: 木・壁の 中に 出さない */
  const A = fit(gy({ x: C.x - sd.x * 3.5, y: C.y, z: C.z - sd.z * 3.5 })), B = fit(gy({ x: C.x + sd.x * 3.5, y: C.y, z: C.z + sd.z * 3.5 }));
  const ea = put(dim, a, A, B), eb = put(dim, b, B, A);
  if (!inScene(p)) cmd(p, "camera @s fade time 0 0.2 0.4 color 0 0 0");   /* 第124版(fix2): 一人称から 決闘の カメラへは 暗い 所から */
  camPut(p, cam, { x: C.x, y: C.y + 1, z: C.z }, 0.35, false);   /* 第124版(cam): talk の 絵として 覚える（見通しは 上で 調べた）*/
  try { showTitle(p, title || "", { subtitle: sub || "", fadeInDuration: 2, stayDuration: 40, fadeOutDuration: 6 }); } catch {}
  const tp = (e, at, face) => { try { if (ok(e)) e.teleport(at, { facingLocation: face }); } catch {} };
  const lerp = (P, Q, k, h = 0) => ({ x: P.x + (Q.x - P.x) * k, y: P.y + (Q.y - P.y) * k + h * 4 * k * (1 - k), z: P.z + (Q.z - P.z) * k });
  try {
    await wait(10);
    /* 1) A が 一気に つっこむ → B が はじかれる */
    sound(p, "mob.ravager.roar", 1.4);
    for (let k = 1; k <= 5; k++) { tp(ea, lerp(A, B, k / 5.5), B); fx(dim, "minecraft:knockback_roar_particle", lerp(A, B, k / 5.5)); await wait(1); }
    fx(dim, "minecraft:critical_hit_emitter", { x: B.x, y: B.y + 1, z: B.z }); sound(p, "random.explode", 1.6);
    const B2 = { x: B.x + sd.x * 2.5, y: B.y, z: B.z + sd.z * 2.5 };
    for (let k = 1; k <= 4; k++) { tp(eb, lerp(B, B2, k / 4, 1.2), A); await wait(1); }
    await wait(4);
    /* 2) B が 反撃して 空中で ぶつかる */
    sound(p, "mob.enderdragon.growl", 1.5);
    for (let k = 1; k <= 5; k++) { tp(eb, lerp(B2, C, k / 5, 2.4), A); tp(ea, lerp(lerp(A, B, 1 / 1.1), C, k / 5, 2.4), B); await wait(1); }
    fx(dim, "minecraft:huge_explosion_emitter", { x: C.x, y: C.y + 1.5, z: C.z }); sound(p, "random.explode", 0.8);
    { const c2 = { x: cam.x + fw.x * 2, y: cam.y - 0.6, z: cam.z + fw.z * 2 }; camPut(p, c2, { x: C.x, y: C.y + 1.5, z: C.z }, 0.2); }   /* 第127版: 寄る 先も 見通しを 調べる */
    await wait(4);
    /* 3) はなれて 着地 → 最後に もう一度 交差 */
    for (let k = 1; k <= 4; k++) { tp(ea, lerp(C, A, k / 4, 1), B); tp(eb, lerp(C, B, k / 4, 1), A); await wait(1); }
    await wait(5);
    sound(p, "mrpg.slash_big", 1.2);
    for (let k = 1; k <= 5; k++) { tp(ea, lerp(A, B, k / 5), B); tp(eb, lerp(B, A, k / 5), A); if (k % 2) fx(dim, "minecraft:critical_hit_emitter", C); await wait(1); }   /* 第124版(cam): 1tick に 飛びすぎない */
    fx(dim, "minecraft:sonic_explosion", { x: C.x, y: C.y + 1, z: C.z }); sound(p, "mob.warden.sonic_boom", 1);
    await wait(14);
  } finally {
    for (const e of [ea, eb]) { try { if (e) LIVE.delete(e.id); } catch {} try { if (ok(e)) { if (inScene(p)) smokeOut(e, 4); else e.remove(); } } catch {} }   /* 第124版(cam): 煙の 中で 消える */
    if (!inScene(p)) { cmd(p, "camera @s fade time 0 0.3 0.4 color 0 0 0"); cmd(p, "camera @s clear"); }   /* 第123版: 場面の とちゅうなら カメラは 次の 絵へ。第124版(fix2): 一人称へは 暗い 中で */
  }
}
