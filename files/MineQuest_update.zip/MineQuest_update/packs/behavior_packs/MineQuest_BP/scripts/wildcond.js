// 第125版: 季節（ワールドの 日数で 8日ごと）・昼夜・雨で かわる 野生の 出やすさ と 地方ごとの 図鑑
import { world } from "@minecraft/server";
import { SPECIES, ORDER, FAMILIES } from "./data.js";
import { WREGIONS } from "./worldmap.js";

export const SEASONS = ["春", "夏", "秋", "冬"];
export const SEA_FAM = ["animal", "aqua", "beast", "blob"];   /* 天気予報の「出やすい 系統」（前と 同じ） */
export const SEA_DAYS = 8;
export function worldDay() { try { if (typeof world.getDay === "function") return world.getDay(); } catch {} try { return Math.floor(world.getAbsoluteTime() / 24000); } catch {} return Math.floor(Date.now() / 1200000); }
export const seasonOf = (day) => Math.floor(Math.max(0, day) / SEA_DAYS) % 4;
export const seasonIdx = () => seasonOf(worldDay());
export const seasonText = () => { const d = worldDay(); return `${SEASONS[seasonOf(d)]} ${(Math.max(0, d) % SEA_DAYS) + 1}日目`; };
export const seasonLine = () => { const i = seasonIdx(); return `§f季節: §e${seasonText()}§7（8日ごとに かわる。${FAMILIES.find((f) => f.id === SEA_FAM[i])?.name || ""}が 少し 出やすい）`; };
// 野生の ランク（レベルで きまる。field.js と 同じ）
export const ranksOf = (lv) => lv <= 4 ? ["F"] : lv <= 10 ? ["F", "E"] : lv <= 18 ? ["E", "D"] : lv <= 28 ? ["D", "C"] : lv <= 40 ? ["C", "B"] : lv <= 52 ? ["B", "A", "C", "A"] : lv <= 64 ? ["A", "A", "S", "S"] : lv <= 78 ? ["A", "S", "S", "SS"] : ["S", "S", "SS", "SS"];
// 地方 × 条件: [属性（出やすい 子）, 系統の 重み 追加]。順は 昼・夜・雨・春・夏・秋・冬
const T = {
  arca: [["wood,light"], ["dark,wind", { animal: 1 }], ["water,wood", { blob: 2 }], ["wood,wind", { animal: 2 }], ["fire,thunder", { animal: 1 }], ["earth", { beast: 2 }], ["ice,water", { blob: 1 }]],
  silva: [["wood,wind"], ["dark", { beast: 1 }], ["water,wood", { blob: 2, aqua: 1 }], ["wood,wind", { animal: 2 }], ["thunder,fire", { animal: 1 }], ["earth,wood", { beast: 2 }], ["ice", { beast: 1 }]],
  ruins: [["earth,light", { golem: 1 }], ["dark", { nether: 2 }], ["water,thunder", { blob: 1 }], ["wind,wood", { beast: 1 }], ["fire", { nether: 1 }], ["earth,wood", { beast: 2 }], ["ice,steel", { golem: 1 }]],
  volka: [["fire,earth"], ["dark,fire", { nether: 2 }], ["thunder,water", { dragon: 1 }], ["earth,wind", { beast: 1 }], ["fire,thunder", { dragon: 2 }], ["earth,steel", { golem: 1 }], ["ice", { golem: 1 }]],
  sand: [["earth,fire", { golem: 1 }], ["dark,ice", { nether: 1 }], ["water,wood", { animal: 1 }], ["wood,wind", { animal: 2 }], ["fire", { dragon: 1 }], ["earth", { golem: 1 }], ["ice,wind", { nether: 1 }]],
  crys: [["light,steel", { golem: 1 }], ["dark", { nether: 1 }], ["water", { blob: 2 }], ["light,wind", { blob: 1 }], ["thunder,fire", { dragon: 1 }], ["earth,steel", { golem: 1 }], ["ice", { golem: 1 }]],
  mari: [["water,wind", { animal: 1 }], ["dark", { aqua: 1 }], ["water,thunder", { aqua: 2, blob: 1 }], ["wind,wood", { animal: 2 }], ["fire,light", { aqua: 2 }], ["wood,earth", { blob: 1 }], ["ice", { aqua: 1 }]],
  necro: [["light,earth", { animal: 1 }], ["dark", { nether: 2 }], ["water,dark", { nether: 1 }], ["wood", { animal: 1 }], ["fire", { nether: 1 }], ["earth,dark", { animal: 1 }], ["ice,dark", { nether: 1 }]],
  frost: [["ice,light", { beast: 1 }], ["dark,ice", { aqua: 1 }], ["ice,water", { aqua: 2 }], ["wind,wood", { beast: 1 }], ["thunder,water", { dragon: 1 }], ["earth", { beast: 2 }], ["ice", { beast: 1, aqua: 1 }]],
  ragna: [["fire,light", { dragon: 1 }], ["dark", { nether: 2 }], ["thunder", { dragon: 2 }], ["wind", { sword: 1 }], ["fire", { dragon: 2 }], ["steel,earth", { sword: 2 }], ["ice,dark", { nether: 1 }]],
  celes: [["light,wind", { animal: 1 }], ["dark,light", { golem: 1 }], ["thunder,water", { dragon: 1, blob: 1 }], ["wood,wind", { animal: 2 }], ["thunder,fire", { dragon: 2 }], ["wind,earth", { golem: 1 }], ["ice,light", { blob: 1 }]],
};
export const COND_N = ["昼", "夜", "雨・雷雨", "春", "夏", "秋", "冬"];
const CT = {};
const condT = (id) => CT[id] || (CT[id] = (T[id] || T.arca).map(([e, f]) => ({ el: e.split(","), f: f || {} })));
// いまの 時間・天気（5秒だけ おぼえる。毎回 調べない）
let WW = ""; try { world.afterEvents.weatherChange.subscribe((ev) => { try { WW = String(ev.newWeather || ""); } catch {} }); } catch {}
const ST = { t: -1e9, night: false, rain: false, thunder: false, sea: 0 };
export function condState(force) {
  const now = Date.now();
  if (!force && now - ST.t < 5000) return ST;
  ST.t = now;
  let t = 6000; try { t = world.getTimeOfDay(); } catch {}
  let w = WW; try { const ow = world.getDimension("overworld"); if (typeof ow.getWeather === "function") w = String(ow.getWeather()); } catch {}
  ST.night = t > 13000 && t < 23000; ST.thunder = /thunder/i.test(w); ST.rain = ST.thunder || /rain/i.test(w); ST.sea = seasonIdx();
  return ST;
}
export const condReset = () => { ST.t = -1e9; };
// 地方の いまの 条件（系統の 追加・属性の しぼりこみ候補）
const CC = new Map();
export function condOf(reg) {
  if (!reg || !reg.id) return null;
  const s = condState(), key = `${reg.id}|${s.night ? 1 : 0}|${s.rain ? (s.thunder ? 2 : 1) : 0}|${s.sea}`;
  let c = CC.get(key);
  if (!c) {
    const tt = condT(reg.id), act = [tt[s.night ? 1 : 0], tt[3 + s.sea]];
    if (s.rain) act.push(s.thunder ? { el: [...tt[2].el, "thunder"], f: tt[2].f } : tt[2]);
    const f = {}; for (const a of act) for (const [k, v] of Object.entries(a.f)) f[k] = (f[k] || 0) + v;
    c = { key, f, els: act.map((a) => a.el) };
    if (CC.size > 200) CC.clear();
    CC.set(key, c);
  }
  return c;
}
// 候補を 属性で しぼる（同じ 候補 × 同じ 属性は おぼえる）
const FP = new WeakMap();
export function condPick(pool, el) {
  let m = FP.get(pool); if (!m) { m = new Map(); FP.set(pool, m); }
  const k = el.join(",");
  let L = m.get(k); if (!L) { L = pool.filter((s) => el.includes((SPECIES[s].aff?.ge || [])[0])); m.set(k, L); }
  return L;
}
// 地方ごとの 図鑑（いつでも・昼・夜・雨・春・夏・秋・冬）。地方ごとに 1回だけ 作る
const okWild = (S) => !S.hidden && !S.fuseonly && !S.metalmon && !S.giant && !S.sea && (S.home || "over") === "over" && S.fam !== "king" && S.fam !== "god" && (S.wild || S.rank === "A" || S.rank === "S" || S.rank === "SS");
const RD = new Map();
export function regionDex(i) {
  if (RD.has(i)) return RD.get(i);
  const R = WREGIONS[i]; if (!R) return null;
  const rk = new Set(); for (let lv = Math.max(1, R.lv[0] - 2); lv <= Math.min(100, R.lv[1] + 2); lv++) for (const r of ranksOf(lv)) rk.add(r);
  const base = ORDER.filter((s) => { const S = SPECIES[s]; return okWild(S) && rk.has(S.rank); });
  const tt = condT(R.id), used = new Set();
  const groups = tt.map((c, k) => {
    const fams = new Set([...Object.keys(R.fams), ...Object.keys(c.f), ...(k === 1 ? ["nether"] : [])]);
    const el = k === 2 ? [...c.el, "thunder"] : c.el;
    const L = base.filter((s) => fams.has(SPECIES[s].fam) && el.includes((SPECIES[s].aff?.ge || [])[0]));
    for (const s of L) used.add(s);
    return L;
  });
  const any = base.filter((s) => R.fams[SPECIES[s].fam] && !used.has(s));
  const out = { name: R.name, groups: [any, ...groups] };
  RD.set(i, out);
  return out;
}
export const DEX_N = ["いつでも", ...COND_N];
// いま 当てはまる 図鑑の 区分（0=いつでも は いつも）
export function activeGroups() { const s = condState(); const a = [0, s.night ? 2 : 1, 4 + s.sea]; if (s.rain) a.push(3); return a; }
export const timeText = () => { const s = condState(); return `${s.night ? "夜" : "昼"}${s.rain ? (s.thunder ? "・雷雨" : "・雨") : ""}`; };
