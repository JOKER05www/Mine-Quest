// 第126版(fix): 名前の ある 人物は いつも 自分の 見た目に する（さまよう モンスターマスターの 見た目 8・9・10 に しない）
// ・PJ(キー, 予備) の キーが PSKIN に ない とき（"rei"・"bandit" など）は 別名を 見る
// ・出す ときの 番号が 8〜10 なら、名札の 名前（最後の 語）から その人の 見た目を さがす
import { PSKIN } from "./skinjobs.js";
import { GRUNTS } from "./gangnames.js";
export const MASTER_JOBS = [8, 9, 10];   /* マスター・ルーキー／ベテラン／チャンピオン */
const ALIAS = { rei: 17, ray: 17, rival: 17, theo: 18, traitor: 18, musashi: 19, bandit: "noxa", smith: "m6_bolt", sam03: "m6_kaito" };
export function skinNo(k, d = 8) {
  if (typeof k === "number") return k;
  const a = ALIAS[k]; if (typeof a === "number") return a;
  const s = PSKIN[a ?? k]; return s ? s[0] : d;
}
const NAMED = { "レイ": 17, "セオ": 18, "ムサシ": 19, "ボム": "bomb", "ザジ": "noxa", "ハルカ": "haku", "リョウマ": "m6_kaito", "ザク": "m6_bolt", "トト": "m6_sota" };
const BYNM = new Map();
{
  const seen = new Map();
  for (const [k, v] of Object.entries(PSKIN)) {
    if (/^hero_|_sw$|_stone$/.test(k)) continue;
    const full = String(v[1]).replace(/\s/g, ""), m = full.match(/[ァ-ヶー・]{2,}$/);
    for (const n of new Set([full, m && m[0]].filter(Boolean))) seen.set(n, seen.has(n) && seen.get(n) !== v[0] ? -1 : v[0]);
  }
  for (const [n, j] of seen) if (j > 0) BYNM.set(n, j);
  for (const g of GRUNTS) if (PSKIN[g.sk]) BYNM.set(g.nm, PSKIN[g.sk][0]);   /* 組織の 下っぱ（名前つき 20人）*/
  for (const [n, k] of Object.entries(NAMED)) BYNM.set(n, skinNo(k));
}
/* 物語の 登場人物（castAdd）の 名前も 見る。同じ 名前で 見た目が ちがう 人が いれば 使わない */
const CN = new Map();
export function nameAdd(nm, j) { if (!nm || typeof j !== "number" || MASTER_JOBS.includes(j)) return; CN.set(nm, CN.has(nm) && CN.get(nm) !== j ? -1 : j); }
const ORG = /六影|砂ぼこり団/;   /* 組織の 人は 団員の 服 */
export function nameSkin(name) {
  const s = String(name || "").replace(/§./g, "").replace(/（[^）]*）/g, "").trim(); if (!s) return null;
  const last = s.split(/\s+/).pop();
  const c = CN.get(last) ?? CN.get(s.replace(/\s/g, ""));
  return (NAMED[last] !== undefined ? BYNM.get(last) : null) ?? (c > 0 ? c : null) ?? BYNM.get(last) ?? BYNM.get(s.replace(/\s/g, "")) ?? (ORG.test(s) ? PSKIN.noxa[0] : null);
}
export function namedJob(name, job) {
  if (typeof job === "number" && !MASTER_JOBS.includes(job)) return job;
  const j = nameSkin(name); return j ?? (typeof job === "number" ? job : 8);
}
