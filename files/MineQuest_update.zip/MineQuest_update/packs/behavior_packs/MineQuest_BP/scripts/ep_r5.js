/* 第125版: 第6地方 クリスタリア の 5話（ひかりごけの 村 グロウ・水晶宮 プリズマ）
   1話 光の 消えた 村 → 2話 いなくなった 子（外れの 古い 坑道）→ 3話 班長 ガロ（洞くつの 入口の 前）
   → 4話 今の 段「洞くつの 広間（ベリルと 影）」→ 5話 水晶宮（ゴウ）→ 今の 段「ゴウとの 勝負」→ 5話 つづき ひかりごけが もどる
   書き方は ep_r0.js の 頭の 説明の とおり */
import { epAdd } from "./sagaep.js";
import { castAdd } from "./cast.js";
import { townOut, placeOf, openSite } from "./storyplace.js";
import { caveInfo, caveSite, groundY } from "./structures.js";
import { world } from "@minecraft/server";
import { fac, facState, facSide, facFront, facMark } from "./epfac.js";
import { bldOf } from "./storyplace.js";
import { qs } from "./quest.js";
import { load } from "./store.js";
import { ok } from "./ui.js";

/* ---------- 場所 ---------- */
const MEMO = new Map();
const tOut = (k, turn, nm) => () => { if (MEMO.has(k)) return MEMO.get(k); const o = townOut("t33", turn, nm); const v = o ? { x: o.x, z: o.z, nm: o.nm } : null; if (v) MEMO.set(k, v); return v; };
const GLOW0 = tOut("gl", 0.4, "坑道前の 広場");
const GLOW = () => bldOf("t33", ["plaza", "inn"], "ひかりごけの 村 グロウの 広場") || GLOW0();   /* 第125版(pl): 村の 話は 村の 広場で（家と 店が 見える）*/
const MINE = () => { const c = townOut("t33", 0, "x"); return (c && openSite("r5mine", c, 5, 90, 450, "グロウの 先の 古い 坑道")) || tOut("mn", -1.4, "外れの 古い 坑道")(); };   /* 第127版(fac): 村から 離れた 山肌 */
const GATE = () => { let c = null; try { c = caveInfo(5) || caveSite(5); } catch {} return c ? { x: Math.floor(c.x), z: Math.floor(c.z) - 14, nm: "クリスタリアの 洞くつの 入口の 前" } : null; };
const COURT = () => { const q = placeOf("court", 5); return q ? { x: q.x, y: q.y, z: q.z, nm: q.nm || "水晶宮 プリズマの 中庭" } : null; };
const near = (f, dx, dz) => () => { const q = f(); return q ? { x: q.x + dx, y: q.y, z: q.z + dz } : null; };

/* ---------- 登場人物 ---------- */
const st = (s) => s.epx || {};
castAdd("r5gantetsu", { nm: "ガンテツ", role: "鉱夫頭", gobi: "だべ", skin: "m6_crystal", town: "t33", from: "r5e1", at: near(GLOW, 3, -3),
  pre: ["{closed}……暗い 村だべ。足もと、気を つけるだべ。"],
  after: [
    [(s) => !!s.heroBack, ["{smile,☆}おお、二人 そろって 帰って きたべか！ ……こけが、いちばん 明るく 光っとるだべ。"]],
    [(s) => !!s.ending, ["{smile}三つ 掘ったら 一つ 返す。今じゃ 子どもでも 知っとる 決まりだべ。", "{sad}……あの 娘っこの 手帳に、コロの 名前も あったべか。あったら、ええだべな。"]],
    [(s) => !!s.heroDead, ["{sad}空が 暗く なって、こけが また 弱って きたべ。", "{angry}だども、もう 掘りすぎは せん。村の みんなで、こけに 灯りを 分けとるだべ。"]],
    [(s) => !!st(s).moss5, ["{smile}こけが もどって、村が 明るく なったべ。鉱夫たちも、掘り方を 変えただべ。", "{closed}……ガロの やつにも、いつか 見せて やりてえだべ。"]],
    [(s) => !!st(s).garo5, ["{sad}ガロの おやじは、おらの 親友だったべ。……あいつが 六影なんぞに。"]],
    [() => true, ["{sad}コロが 見つかって、ほっと しただべ。……おらが、ちゃんと 見て やらにゃ。"]],
  ] });
castAdd("r5lulu", { nm: "コロ", role: "鉱夫の 子", gobi: "の", skin: "taro", town: "t33", from: "r5e2", at: near(GLOW, -3, 3),
  pre: ["{sad}……こけ、げんき ないの。"],
  after: [
    [(s) => !!s.ending, ["{smile,☆}ぼく、大きく なったら こけの 番人に なるんだ！"]],
    [(s) => !!s.heroDead, ["{sad}……あのね、こけに お話し してるの。『がんばれ』って。", "{smile}こけが 光ってたら、こわく ないの。だから、ぼくも がんばるの。"]],
    [(s) => !!st(s).moss5, ["{smile,♪}見て 見て！ ぼくの こけ、村じゅうに ひろがったの！"]],
    [() => true, ["{smile}とうちゃん、もう 掘りすぎない って やくそく したの。"]],
  ] });
castAdd("r5gou", { nm: "ゴウ", role: "地方マスター", col: "§6", gobi: "", skin: "gou" });

/* ---------- 小道具 ---------- */
const ctr = (p, d) => { const s = qs(load(p) || d); return s.epSpot ? { x: s.epSpot.x + 0.5, y: typeof s.epSpot.y === "number" ? s.epSpot.y : p.location.y, z: s.epSpot.z + 0.5 } : null; };
const Y = (K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const GARO = (K, p, w = false) => K.npcNear(p, "§c六影 班長 ガロ", K.PJ("garo", 9), w);
/* 歩いて 去る（道が ふさがって 歩けない 人は 暗転で 下げる）*/
const out = async (K, p, es, run = false) => { const L = [].concat(es).filter(ok), fade = [], go = []; for (const e of L) { const q = K.away(e, p, 10); if (!q || Math.hypot(q.x - e.location.x, q.z - e.location.z) < 4) fade.push(e); else go.push(K.leave(e, p, 10, run)); } await Promise.all(go); if (fade.length) await K.bye(p, ...fade); };
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
/* ひかりごけ（ワールドに 1回。舞台の 外側。地面の 上に 低く）*/
function moss(p, c, y0, key, R) {
  const k = `mrpg:epdeco:${key}`; try { if (world.getDynamicProperty(k)) return; world.setDynamicProperty(k, 1); } catch { return; }
  const dim = p.dimension, cx = Math.floor(c.x), cz = Math.floor(c.z);
  for (let i = 0; i < 14; i++) { const a = (i / 14) * Math.PI * 2, r = R + (i % 3), x = cx + Math.round(Math.cos(a) * r), z = cz + Math.round(Math.sin(a) * r);
    try { const y = groundY(dim, x, z, y0 + 6); if (typeof y === "number" && Math.abs(y - y0) <= 4) dim.runCommand(`setblock ${x} ${y} ${z} ${i % 4 ? "glow_lichen" : "shroomlight"} keep`); } catch {} }
}

/* ---------- 1話 光の 消えた 村 ---------- */
const E1 = { id: "r5e1", n: 1, t: "光の 消えた 村", at: 0, ord: 0, place: GLOW, fac: "r5glow",
  hint: "§fひかりごけの 村 §eグロウの 広場§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "ひかりごけの 村 グロウは、昼でも 暗かった。鉱夫頭 ガンテツは「黒い 手袋の 買い手が 水晶を 三倍の 値で 買うから、掘りすぎた」と うつむいた。こけは 水晶の 光を 食べて 光る。息子の コロは「とうちゃんが こけを 殺したんだ」と 叫んで 走り去った。",
  set: { met5: 1 },
  async run(p, d, K) {
    const FQ = fac(K, p, "r5glow", "mine", 5, Y(K, p));   /* 第125版(fac): 坑道の 入口（木の 枠・レール・トロッコ）*/
    await K.open(p, "ひかりごけの 村 グロウ", "night");
    K.sound(p, "ambient.cave", 0.6);
    const eH = K.hero(p);
    await K.hsay(p, K.V(["{shock,…}……あれ？ まだ お昼なのに、村が 真っ暗……。"], ["{sad,…}……暗いわね。お昼なのに、灯りが ほとんど ない。"], ["{closed}……暗い。昼なのに。"], ["{shock,…}……お昼なのに、暗い 村ですね……。"]));
    await K.at(p, FQ || { x: p.location.x, y: p.location.y + 2, z: p.location.z }, 14, 6, 1);
    await K.narr(p, ["§7家の 壁にも、広場の 石だたみにも、灰色に 枯れた こけが はりついて いる。", "§7この 村の 名前は、ひかりごけの 村。……光って いる こけは、一つも ない。"]);
    const eG = K.cast(p, "r5gantetsu"); K.act(eG, "hold"); K.hold(eG, "pickaxe");
    await K.csay(p, "r5gantetsu", ["{closed}……よそ者だべか。こんな 暗い 村に、よう 来ただべ。", "{smile}おらは ガンテツ。この 村の 鉱夫頭だべ。"]);
    await K.hsay(p, K.V(["{?}ガンテツさん、どうして こんなに 暗いの？"], ["{?}……ガンテツさん。こけ、どうして 枯れたの？"], ["{?}……こけ。なんで 枯れた。"], ["{?}ガンテツさん。こけは、どうして……？"]));
    K.act(eG, 0);
    await K.csay(p, "r5gantetsu", ["{sad}ひかりごけは、山の 水晶の 光を 食べて 光るだべ。", "{sad,…,up}……水晶を 掘りすぎたら、こけは 腹を すかせて 枯れちまうだべ。"], eH);
    K.act(eG, "point");
    await K.csay(p, "r5gantetsu", ["{closed}ひと月 前から、黒い 手袋の 買い手が 来るように なっただべ。", "{sweat,汗}水晶を、三倍の 値で 買うって。……村は 貧しいだべ。みんな、夢中で 掘っただべ。"], eH);
    K.act(eG, 0);
    await K.up(p, eG, 12);
    await K.csay(p, "r5gantetsu", ["{sad,up}『掘れ』って 言ったのは、おらだべ。……鉱夫頭の、おらだべ。"]);
    /* コロ */
    const eL = K.cast(p, "r5lulu"); K.act(eL, "run", false);
    await K.csay(p, "r5lulu", ["{angry,怒,up}とうちゃん！ また 山に 穴 あけたでしょ！"]);
    K.act(eL, 0);
    await K.csay(p, "r5gantetsu", ["{sweat,汗}コ、コロ……。これは 村の ためだべ……。"], eL);
    await K.csay(p, "r5lulu", ["{cry,tears,up}ちがう！ とうちゃんが こけを 殺したんだ！", "{cry,up}こけが 光らないと、夜に ひとりで 寝られないのに……！"]);
    await K.hsay(p, K.V(["{sad,up}あっ……コロくん、待って！"], ["{sad,up}……コロくん、待って。"], ["{sad,up}……待って。"], ["{sad,up}コ、コロさん、待って ください！"]));
    await out(K, p, eL, true);
    K.act(eG, "kneel");
    await K.up(p, eG, 12);
    await K.csay(p, "r5gantetsu", ["{sad,…}……あの 子の 母ちゃんも、こけが 好きだっただべ。", "{closed}夜、こけの 光で 子守唄を 歌うのが、母ちゃんの くせでな。……何年か 前、病で 逝っただべ。"]);
    K.act(eG, 0);
    const g = K.palEnt(p); if (g) { K.burst(p.dimension, g.location, "minecraft:soul_particle", 3, 0.4, 0.8); await K.up(p, g, 10); }
    await K.hsay(p, K.V(["{angry,up}……ガンテツさん。わたしたちに 手伝わせて。こけ、もう一度 光らせよう！"], ["{smile,up}……手伝わせて。こけも、コロくんの 心も。"], ["{closed,up}……手伝う。こけも、親子も。"], ["{smile,up}わたしたちに、お手伝い させて ください。"]));
    K.rmCine(g);
    await K.csay(p, "r5gantetsu", ["{smile,tears,up}……ありがてえ。ほんとに、ありがてえべ。"]);
    K.pay(p, E1, 300, [["mei_crys", 1]]);
    { const H = bldOf("t33", ["home", "inn"]); await K.night(p, H && Number.isFinite(H.fx) ? { x: H.fx, y: H.y + 1, z: H.fz } : null, "§7その 夜。コロは 光らない こけの 横で、ひとり ふとんを かぶった。", "§7……朝。コロの 寝床は、からっぽ だった。", [eG]); }   /* 第125版(pl): 夜の 家 → 朝の 寝床 */
    await K.end(p, { leave: [], card: "§7― 次の 朝、コロが いなく なった ―\n§7→ 村の 外れの 古い 坑道へ（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 2話 いなくなった 子 ---------- */
const E2 = { id: "r5e2", n: 2, t: "いなくなった 子", at: 0, ord: 1, place: MINE, fac: "r5mine",
  hint: "§fグロウの §e外れの 古い 坑道§f で コロを さがそう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "コロは 古い 坑道の 奥で、最後の ひかりごけを 守って いた。母が 子守唄を 歌った 場所だった。こけを 食べに 来た 水晶食いを 追い払うと、ガンテツは コロを 抱きしめて「ごめんな」と 言った。コロの こけが、村を 照らす たねに なる。",
  set: { lulu5: 1, met5: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), lulu5: 1 }; },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    const FQ = fac(K, p, "r5mine", "minetunnel", 5, y0);   /* 第125版(pl): 古い 坑道（丘の 入口・レール・下る 坑道・水晶の 脇坑・奥の 広間）*/
    await K.open(p, "グロウの 外れの 古い 坑道", "night");
    K.sound(p, "ambient.cave", 0.8);
    if (FQ) await K.at(p, FQ, 14, 6, 1.2);
    let eH = K.hero(p); const eG = K.cast(p, "r5gantetsu");
    K.act(eG, "run", false);
    await K.csay(p, "r5gantetsu", ["{shock,!,up}コロが、どこにも おらんだべ！ 朝から ずっと……！", "{sweat,汗}この 坑道は 崩れかけとる。子どもが 入ったら……！"]);
    K.act(eG, 0);
    await K.hsay(p, K.V(["{angry,!,up}さがそう！ 相棒、においで わかる？"], ["{sad,up}……さがしましょう。相棒、お願い。"], ["{closed,up}……さがす。相棒、においを。"], ["{angry,up}さがしましょう！ 相棒さん、お願い します！"]));
    const g = K.palEnt(p);
    if (g) { K.burst(p.dimension, g.location, "minecraft:villager_happy", 4, 0.4, 0.4); await K.up(p, g, 12); }
    const far = FQ ? { x: FQ.x, y: FQ.y, z: FQ.z } : K.fwd(p, 9, 2.5);
    if (ok(g) && far) await K.walkCam(p, g, far, 22);
    await K.narr(p, ["§7相棒が 鼻を ひくひく させて、坑道の 奥へ 走った。"], far);
    /* 第125版(pl): 坑道の 奥の こけの 庭へ 場面を 移す（暗転 → 庭の 引きの 絵 → コロは もう そこに いる → みんなが 走って 来る）*/
    const HL = facMark("r5mine", "hall", p.location), MG = HL ? facMark("r5mine", "vein") : facSide(p, K.S(p), 20, "r5moss", "mossgrotto", 5, y0), MF = HL || (MG && facFront("r5moss", 5));   /* 坑道の 奥の 広間（なければ こけの 庭）*/
    let eL;
    if (MF) {
      await K.moveTo(p, MF, HL ? "古い 坑道の 奥の 広間" : "坑道の 奥 こけの 庭", [g, eG, eH].filter(ok), MG, HL ? 4 : 10);
      eL = K.cast(p, "r5lulu", true); K.act(eL, "kneel");
      await K.narr(p, ["§7坑道の いちばん 奥。岩の すきまから、小さな 緑の 光が ぽつんと もれて いる。"], MG);
      eH = K.hero(p); K.cast(p, "r5gantetsu"); K.act(eH, "run", false); await K.wait(14); K.act(eH, 0);
    } else {
      const MM = fac(K, p, "r5moss", "mossgrotto", 5, y0) && facMark("r5moss", "moss", p.location);   /* 第125版(tp): 横に 建たない ときは 前に こけの 庭。それも だめなら 足もとに こけと 光 */
      if (!MM && far) { const fx = Math.floor(far.x), fz = Math.floor(far.z); K.cmd(p, `fill ${fx - 1} ${y0 - 1} ${fz - 1} ${fx + 1} ${y0 - 1} ${fz + 1} moss_block replace grass_block`); K.cmd(p, `fill ${fx - 1} ${y0} ${fz - 1} ${fx + 1} ${y0} ${fz + 1} moss_carpet keep`); K.cmd(p, `setblock ${fx + 2} ${y0} ${fz} shroomlight keep`); }
      await K.narr(p, ["§7暗がりの 先に……小さな 緑の 光が、ぽつんと 見える。"], MM || far);
      eL = MM ? await K.put(p, "r5lulu", MM) : K.cast(p, "r5lulu", true); K.act(eL, "kneel");
    }
    K.burst(p.dimension, ok(eL) ? eL.location : c, "minecraft:villager_happy", 6, 0.6, 0.2);
    await K.up(p, eL, 14);
    await K.csay(p, "r5lulu", ["{sad,…}……来ないで。ここの こけだけは、ぼくが 守るんだ。", "{sad,up}かあちゃんが、ここで 子守唄 歌ってたの。……ここの こけだけ、まだ 光ってるの。"]);
    await K.hsay(p, K.V(["{sad,tears,up}……コロくん。ずっと、ここで 守ってたの？"], ["{sad,up}……ひとりで、守って いたのね。"], ["{sad,up}……ひとりで。えらい。"], ["{sad,up}……おひとりで、ずっと 守って いらしたのですね。"]));
    /* 水晶食い */
    K.sound(p, "mob.silverfish.say", 1); K.shake(p, 0.3, 0.4);
    const q = K.fwd(p, 6, -2);
    const w1 = K.monEnt(p, q, K.wildSp("golem"), "");
    K.burst(p.dimension, q, "minecraft:white_smoke_particle", 10, 1.2, 0.2);
    await K.at(p, q, 14, 4, 1);
    await K.csay(p, "r5lulu", ["{shock,!,up}また 来た！ こけを 食べる やつだ！ だめ、だめぇ！"]);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{rage,怒,up}コロくんの こけに 手を 出すなー！"], ["{angry,up}……ごめんね。でも、この こけは 渡せないの。"], ["{angry,up}……どけ。その こけは、渡さない。"], ["{angry,up}その こけには、指一本 触れさせません！"]));
    K.rmCine(g);
    if (!K.flag(p, "r5e2w")) {
      K.rmCine(w1);
      const r = await K.battle(p, K.team(["golem", "beast"], 40, 2, 6), { name: "腹を すかせた 水晶食い", arena: "いなくなった 子", theme: "cave", speaker: "野生の モンスター", lines: { half: "……ガリ……ガリ……", low: "……キュウ……" } });
      if (r !== "win") return lose(K, p, "§e鉱夫頭 ガンテツ", K.PJ("m6_crystal", 8), "ガンテツ", "{sweat,汗}い、いったん 坑道の 外へ 出るだべ！ コロは、おらが 見とるだべ！");
      K.setFlag(p, "r5e2w");
    } else K.rmCine(w1);
    const eL2 = K.cast(p, "r5lulu", true), eG2 = K.cast(p, "r5gantetsu", true);
    if (ok(eG2) && ok(eL2)) { const l = eL2.location; await K.go(eG2, { x: l.x + 1.1, y: l.y, z: l.z + 0.4 }, 12, true); }
    K.act(eG2, "kneel");
    await K.two(p, eG2, eL2, 12);
    await K.csay(p, "r5gantetsu", ["{cry,tears,up}……コロ。ごめんな。ほんとに、ごめんな。", "{sad,up}こけを 殺したのは、とうちゃんだべ。……もう 掘りすぎは せん。約束するだべ。"]);
    await K.csay(p, "r5lulu", ["{cry,tears,up}……とうちゃん。", "{cry,smile,up}……やくそく、だよ。ぜったい、だよ。"]);
    K.act(eL2, "hold"); K.hold(eL2, "potion");
    await K.at(p, ok(eL2) ? eL2.location : c, 12, 2.2, 0.6);
    K.burst(p.dimension, ok(eL2) ? eL2.location : c, "minecraft:villager_happy", 8, 0.6, 0.6);
    await K.narr(p, ["§7コロの 手の 中で、小さな こけの かたまりが、ぼんやり 緑に 光った。", "§7母が 歌った 場所で、こけは まだ 生きて いた。"], eL2);
    K.act(eL2, 0);
    { const S2 = K.S(p); moss(p, S2 ? S2.P : c, S2 ? Math.floor(S2.P.y) : y0, "r5mine", 11); }   /* 第125版(pl): こけの 庭の まわり */
    await K.hsay(p, K.V(["{smile,tears,up}……この こけが あれば、村も また 光るかも！"], ["{smile,up}……この 光が、村の たねに なるわ。"], ["{smile,up}……たね。この 光が。"], ["{smile,up}この 光が、村の たねに なりますね。"]));
    await K.csay(p, "r5gantetsu", ["{closed}……だども、水晶の 洞くつの ほうで、まだ だれかが 掘っとるだべ。", "{angry}黒い 手袋の 買い手の 手下だべ。……明日、洞くつの 入口へ 行くだべ。"]);
    K.pay(p, E2, 400, [["c_herbs", 2]]);
    await K.end(p, { leave: [eG2, eL2], card: "§7→ クリスタリアの 洞くつの 入口へ（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 3話 班長 ガロ ---------- */
const E3 = { id: "r5e3", n: 3, t: "班長 ガロ", at: 0, ord: 2, place: GATE,
  hint: "§fクリスタリアの §e洞くつの 入口の 前§f へ 行こう §7（水晶を 運び出す 者たちが いる。「！」の 目印の そばで 立ち止まろう）",
  syn: "洞くつの 入口で、水晶を 運び出す 六影の 班長 ガロと 会った。ガンテツは「おめえ、鉱夫の せがれの ガロだべ」と 声を ふるわせた。ガロは「俺だって、昔は この 村の 鉱夫だった」と こぼし、手下を 止めて 洞くつの 奥へ 消えた。手下は「奥の 潜水士の 女」と 口を すべらせた。",
  set: { garo5: 1, met5: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), garo5: 1 }; },
  async run(p, d, K) {
    const FC = fac(K, p, "r5camp", "cryscamp", 5, Y(K, p));   /* 第125版(pl): 洞くつの 入口の 運び出し場（水晶の 箱・トロッコ・天幕）*/
    await K.open(p, "クリスタリアの 洞くつの 入口", "day");
    if (FC) await K.at(p, FC, 14, 6, 1.2);
    K.sound(p, "block.amethyst_block.chime", 0.8);
    const eH = K.hero(p), eG = K.cast(p, "r5gantetsu");
    const eA = K.npcNear(p, "§c六影の 下っぱ ドスコ", K.PJ("noxa", 9)), eB = K.npcNear(p, "§c六影の 下っぱ ヒョロ", K.PJ("noxb", 9));
    K.act(eA, "hold"); K.act(eB, "hold");
    await K.two(p, eA, eB, 12);
    await K.say(p, "ドスコ", ["{smile}よいしょ、よいしょ。今日も 水晶 どっさりだぜ。"]);
    await K.say(p, "ヒョロ", ["{sweat,汗}兄貴、奥の 潜水士の 女、どう します？ ずっと にらんで くるんすよ……。"]);
    K.act(eG, "point");
    await K.csay(p, "r5gantetsu", ["{rage,怒,up}その 水晶、村の 山の もんだべ！ 返すだべ！"]);
    K.act(eG, 0);
    const eGa = GARO(K, p); K.act(eGa, "hold");
    await K.low(p, eGa, 14);
    await K.say(p, "ガロ", ["{closed,low}……うるせえな。買い手が 待ってんだ。どいて くれ。", "{closed}……買い手？ 参謀の 使いさ。顔は 見た こと ねえ。"]);
    await K.hsay(p, K.V(["{shock,!,up}ガロ！？ なんで こんな 所に！"], ["{shock,…,up}……ガロさん？"], ["{shock,!,up}……ガロ。"], ["{shock,!,up}ガ、ガロさん……！？"]));
    await K.csay(p, "r5gantetsu", ["{shock,!,up}……ガロ？ おめえ……鉱夫の ドルガの せがれの、ガロだべか！？"]);
    if (ok(eGa)) { K.re(eGa, "shock", "!"); await K.up(p, eGa, 12); }
    await K.say(p, "ガロ", ["{angry,up}……その 名で 呼ぶな、おやっさん。"]);
    await K.memory(p, eGa, "§7― 十二年前 ―", ["§7ひかりごけの 光の 下で、小さな 男の 子が 父の つるはしを 運んで いた。", "§7ある 朝、坑道が 崩れた。……男の 子は、一人で 村を 出た。"]);
    await K.say(p, "ガロ", ["{sad,…,up}……オレだって、昔は この 村の 鉱夫だった。", "{closed}こけの 光の 下で 掘るのが、好きだった。……おやじが 埋まるまではな。", "{closed,low}……おやじが 埋まったのは、灰の 降った 冬だ。"]);
    await K.csay(p, "r5gantetsu", ["{cry,tears,up}……ドルガは、おらの 親友だっただべ。おめえの ことも、ずっと さがしとっただべ……！"]);
    await K.say(p, "ガロ", ["{angry,low}……今さら 遅えよ。", "{closed}三倍の 値で 買って くれる 奴が いる。村が 貧しい ままより、ずっと ましだろ。"]);
    await K.hsay(p, K.V(["{rage,怒,up}ましな わけ ない！ こけが 枯れて、コロくんは 夜 ひとりで 寝られないんだよ！"], ["{angry,up}……こけが 枯れて、子どもが 泣いてるの。それが、ましなの？"], ["{angry,up}……こけが 枯れた。子どもが 泣いた。それで まし？"], ["{angry,up}こけが 枯れて、子どもが 泣いて います！ それが、ましなのですか！"]));
    K.act(eA, "guard"); K.act(eB, "guard");
    await K.say(p, "ドスコ", ["{angry,!}班長に 説教 すんな！ やっちまうぞ、ヒョロ！"]);
    K.act(eH, "guard");
    if (!K.flag(p, "r5e3w")) {
      const r = await K.battle(p, K.team(["golem", "nether", "animal"], 41, 3, 8), { name: "六影の 下っぱ ドスコと ヒョロ", arena: "班長 ガロ", theme: "crystal", speaker: "ドスコ", lines: { half: "こ、この 水晶 重すぎて 力が 出ねえ……！", low: "は、班長ぉ〜！" } });
      if (r !== "win") return lose(K, p, "§c六影 班長 ガロ", K.PJ("garo", 9), "ガロ", "{closed}……帰れ。ここは、お前らの 来る 所じゃ ねえ。");
      K.setFlag(p, "r5e3w");
    }
    const eA2 = K.npcNear(p, "§c六影の 下っぱ ドスコ", K.PJ("noxa", 9), true), eB2 = K.npcNear(p, "§c六影の 下っぱ ヒョロ", K.PJ("noxb", 9), true);
    K.act(eA2, "down"); K.act(eB2, "kneel");
    const eGa2 = GARO(K, p, true); K.act(eGa2, "guard");
    await K.say(p, "ガロ", ["{closed,low}……もう いい。お前ら、水晶を 奥へ 運べ。"]);
    K.act(eA2, 0); K.act(eB2, 0);
    await out(K, p, [eA2, eB2], true);
    await K.up(p, eGa2, 12);
    await K.say(p, "ガロ", ["{sad,…,up}……おやっさん。こけの こと、悪かったな。", "{angry,low}だが、奥へは 来るな。……来たら、今度は オレが 相手だ。"]);
    K.act(eGa2, 0);
    await out(K, p, eGa2, false);
    await K.csay(p, "r5gantetsu", ["{sad,…}……あの 子の 目、小さい ころと 同じだべ。", "{closed,up}……頼む。ガロを、止めて やって けろ。"]);
    await K.hsay(p, K.V(["{angry,up}うん。……奥の 潜水士の 人も 気に なる。行こう！"], ["{closed,up}……ええ。奥の 潜水士さんも、助けなきゃ。"], ["{closed,up}……行く。奥に、捕まってる 人も いる。"], ["{angry,up}はい。奥の 潜水士の 方も、お助け しなければ。"]));
    K.pay(p, E3, 500, [["mei_crys", 1]]);
    await K.end(p, { leave: [eG], card: "§7→ 洞くつの 坂道を 下りきった §e奥の 大広間§7へ（右上の 案内）", kind: "day" });
    return true;
  } };

/* ---------- 5話 水晶宮（ゴウ。勝負は 中庭の ゴウに 話しかける）---------- */
const E5 = { id: "r5e5", n: 5, t: "水晶宮", at: 1, ord: 0, place: COURT,
  hint: "§f§6水晶宮 プリズマの 中庭§f へ 行こう §7（ガンテツと コロが 地方マスターに 会いに 来る。「！」の 目印の そばで 立ち止まろう）",
  syn: "水晶宮の 中庭で、地方マスター ゴウと 会った。ゴウも 昔は グロウの 鉱夫で、ガンテツの 弟分だった。「石は 光を 貯める。掘りすぎれば、山が 暗く なる」。コロが さし出した こけを 見て、ゴウは「勝てたら、こけを 村に 返す 方法を 教えよう」と 勝負を 受けた。",
  set: { gou5: 1, met5: 1 },
  async run(p, d, K) {
    await K.open(p, "水晶宮 プリズマの 中庭", "castle");
    K.sound(p, "block.amethyst_block.chime", 1);
    const eH = K.hero(p), eG = K.cast(p, "r5gantetsu"), eL = K.cast(p, "r5lulu");
    await K.csay(p, "r5lulu", ["{smile,☆,jump}すっごーい！ ぜんぶ 水晶で できてる！"]);
    const eGo = K.cast(p, "r5gou"); K.act(eGo, "hold");
    await K.low(p, eGo, 14);
    await K.csay(p, "r5gou", ["{closed}……ゴウだ。グロウの 話は、聞いて いる。"]);
    await K.csay(p, "r5gantetsu", ["{shock,!,up}……ゴウ！？ おめえ、まさか、あの 泣き虫の ゴウだべか！？"], eGo);
    await K.csay(p, "r5gou", ["{smile,息,up}……泣き虫は よけいだ、ガンテツ兄い。"], eG);
    await K.hsay(p, K.V(["{shock,!,up}えっ、知り合いなの！？"], ["{shock,…}……お知り合い？"], ["{?}……知り合い。"], ["{shock,!,up}お、お知り合いですか！？"]));
    K.act(eGo, "point");
    await K.csay(p, "r5gou", ["{closed}昔は 俺も、グロウで 石を 掘って いた。この 宮も、グロウの 水晶で できて いる。", "{sad}石は 光を 貯める。掘りすぎれば、山が 暗く なる。……俺は それを、相棒を なくして 知った。"], eH);
    K.act(eGo, 0);
    await K.up(p, eGo, 12);
    await K.csay(p, "r5gou", ["{sad,up}……岩の 子だった。ある 朝、本当の 岩に なって いた。……薬代に、石板の かけらを 売ったんだ。"]);
    K.act(eL, "show"); K.hold(eL, "potion");
    if (ok(eL)) K.burst(p.dimension, eL.location, "minecraft:villager_happy", 6, 0.5, 0.8);
    await K.csay(p, "r5lulu", ["{sad,up}……ゴウさん。これ、ぼくの こけ。かあちゃんの 場所の こけなの。", "{smile,up}村の こけ、もう一度 光らせたいの。おねがい。"]);
    K.act(eL, 0);
    await K.up(p, eGo, 10);
    await K.csay(p, "r5gou", ["{closed,…}…………。", "{smile,up}……いい 光だ。母ちゃんの 光だな。"]);
    K.act(eGo, "guard");
    await K.csay(p, "r5gou", ["{angry,up}旅の 者。お前は 力が 欲しいのか、守りたいのか。拳で 答えろ。", "{closed}俺に 勝てたら、石板を 託す。……そして、こけを 村に 返す 方法を 教えよう。"], eH);
    await K.hsay(p, K.V(["{angry,!,up}守りたい！ コロくんの こけも、村の 夜も！"], ["{closed,up}……守りたいの。コロくんの 光を。"], ["{angry,up}……守る。答えは、拳で。"], ["{angry,up}守りたいのです。コロさんの 光を！"]));
    K.act(eGo, 0);
    await K.csay(p, "r5gou", ["{smile,nod,up}準備が できたら、中庭の 俺に 話しかけろ。……待って いる。"]);
    await K.csay(p, "r5gantetsu", ["{smile,up}……ゴウ。おめえ、いい 顔に なっただべな。"]);
    K.pay(p, E5, 400, []);
    await K.end(p, { leave: [eG, eL, eGo], card: "§7→ 中庭の §6地方マスター ゴウ§7 に 話しかけて 勝負（勝つと 石板）", kind: "castle" });
    return true;
  } };

/* ---------- 5話 つづき ひかりごけが もどる ---------- */
const E6 = { id: "r5e6", n: 6, t: "ひかりごけが もどる", at: 2, ord: 0, place: GLOW, fac: "r5glow",
  hint: "§fグロウの §e広場§f へ もどろう §7（ひかりごけが もどる。そのあと マリノアへ。「！」の 目印の そばで 立ち止まろう）",
  syn: "ゴウに 勝って グロウへ もどると、ゴウが 教えた とおり、掘った 水晶を 三つに 一つ 山へ 返し、コロの こけを 広場に 植えた。夜、村じゅうの こけが 緑に 光った。鉱夫たちは 掘り方を 変え、ガンテツは コロを 肩車して 笑った。",
  set: { moss5: 1, met5: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), moss5: 1 }; },
  fx: { xp: ["t33", 160], fest: "t33" },
  async run(p, d, K) {
    const c = ctr(p, d) || p.location, y0 = Y(K, p);
    const FQ = fac(K, p, "r5glow", "mine", 5, y0);
    await K.open(p, "ひかりごけの 村 グロウ（夜）", "night");
    K.sound(p, "ambient.cave", 0.5);
    const eH = K.hero(p), eG = K.cast(p, "r5gantetsu"), eL = K.cast(p, "r5lulu");
    K.act(eG, "hold"); K.hold(eG, "pickaxe");
    await K.csay(p, "r5gantetsu", ["{smile}ゴウの 言づて、聞いただべ。掘った 水晶の 三つに 一つは、山へ 返す。", "{closed}水晶が 光を 貯めて、こけに 分ける。……昔の 鉱夫は、みんな 知っとった 決まりだべ。"]);
    K.act(eG, 0);
    K.act(eL, "kneel");
    await K.csay(p, "r5lulu", ["{smile,up}ここに 植えるの。……かあちゃんの 子守唄も、いっしょに。"]);
    await K.at(p, ok(eL) ? eL.location : c, 14, 2.4, 0.4);
    await K.narr(p, ["§7コロが 小さな 声で 歌う。母が 歌って いた、こけの 子守唄。", "§7村の 鉱夫たちが、一人、また 一人と、返す 水晶を 山の 祠に 置いて いく。"], eL);
    moss(p, c, y0, "r5glow", 11);
    K.sound(p, "block.amethyst_block.chime", 1); K.sound(p, "random.levelup", 0.6);
    for (let i = 0; i < 3; i++) { K.ambient(p, "fest", { x: c.x, y: y0, z: c.z }); K.burst(p.dimension, { x: c.x, y: y0, z: c.z }, "minecraft:villager_happy", 12, 3 + i * 2, 0.3); await K.wait(8); }
    await K.wide(p, 24);
    facState("r5mine", 1);   /* 第125版(pl): 坑道の 入口にも こけの 光 */
    await K.narr(p, ["§7足もとから、緑の 光が ひろがった。", "§7家の 壁が、広場の 石だたみが、こけの 光で ぼんやり 照らされて いく。"], FQ);
    K.act(eL, "raise");
    await K.csay(p, "r5lulu", ["{smile,☆,jump,up}光った……！ とうちゃん、光ったよ！！"]);
    await K.hsay(p, K.V(["{smile,tears,up}きれい……！ 村じゅう、緑の 星みたい！"], ["{smile,tears,up}……きれい。村が、息を してる みたい。"], ["{smile,up}……きれい。"], ["{smile,tears,up}なんて きれい……村じゅうが、光って います。"]));
    if (ok(eG) && ok(eL)) { const l = eL.location; await K.go(eG, { x: l.x + 0.9, y: l.y, z: l.z }, 10); }
    K.act(eG, "raise");
    await K.csay(p, "r5gantetsu", ["{smile,tears,up}……コロ。とうちゃん、約束 守っただべ。"]);
    await K.csay(p, "r5lulu", ["{smile,tears,up}うん。……ありがとう、とうちゃん。だいすき。"]);
    K.act(eG, 0); K.act(eL, 0);
    await K.csay(p, "r5gantetsu", ["{closed}……ガロの やつにも、この 光を 見せて やりてえだべ。", "{smile,up}あいつが 帰って くる 場所は、ちゃんと 明るく して おくだべ。"]);
    K.act(eL, "hold"); K.hold(eL, "potion");
    await K.csay(p, "r5lulu", ["{smile}これ、あげる。こけの びん なの。夜、こわく なったら 見てね。"]);
    await K.give(eL, eH, "potion");
    const got = K.pay(p, E6, 800, [["mei_crys", 2], ["gift_candle", 1]]);
    if (got.length) K.big(p, "§a§lこけの びん", `§e${got.join("・")}`);
    K.act(eL, 0);
    await K.csay(p, "r5gantetsu", ["{smile,up}いって らっしゃいだべ！ 帰りに また 寄るだべよ！"]);
    await K.hsay(p, K.V(["{smile,☆,up}いって きます！ コロくん、こけ 守ってね！"], ["{smile,up}……いって きます。コロくん、またね。"], ["{smile,up}……いって きます。"], ["{smile,up}いって まいります！ コロさん、お元気で。"]));
    await K.end(p, { bye: [eG, eL], card: "§f― 第6章 水晶の 洞くつ おわり ―\n§7→ 次は マリノア諸島の 町 コラリアへ（右上の 案内）", kind: "night", t: 60 });
    return true;
  } };

epAdd(5, [E1, E2, E3, E5, E6], { steps: { 0: [4, "ベリルと 影（洞くつの 大広間）"], 1: [5, "水晶宮（ゴウとの 勝負）"] } });
