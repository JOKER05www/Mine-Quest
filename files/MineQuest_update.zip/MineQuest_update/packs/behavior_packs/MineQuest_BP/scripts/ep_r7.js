/* 第125版: 第8地方 ネクロス（たましいの 町 ソウラ・冥王の 城 タナトス）の 5話
   1話 魂の 町（墓守の 丘）→ 2話 灯籠流し（川べり。セオが 弟の 灯籠を 流せない）→ 3話 葬列の 道（街道）
   → 4話 霊廟の 奥（今の 段: 葬列の 護衛・セオが 参謀と 名乗り直す・レイ）→ 5話 ヨミ（地方マスター・今の 段）→ 5話 つづき 灯籠流しの 夜（川べり）
   ・ソウラの きまり: 白い 灯籠（送り灯籠）を 流すと、その 人の 名は 霊廟の 帳の 写し（元は 魂の 帳）に 書かれ、もう 帰って こない。赤い 灯籠（迎え灯籠）は、遠くの 人が 帰り道を 見失わない ように 流す
   ・登場人物の キーは「r7_」を つける（ほかの 地方の イザク・ピピと ぶつからない）*/
import { epAdd } from "./sagaep.js";
import { castAdd, doomed, doomKnown } from "./cast.js";
import { townOut, placeOf, farOf, bldOf } from "./storyplace.js";
import { TOWNS, getTown, townPos, groundY } from "./structures.js";
import { world } from "@minecraft/server";
import { ok } from "./ui.js";
import { fac, facMark, facState, facAt, facSide, facFront } from "./epfac.js";
import { qs } from "./quest.js";
import { wl } from "./wqlore.js";
import { plazaOf, festSet, crowd, moveG } from "./pvplace.js";   /* 第126版(PV): 灯籠流しの 夜は 町の 広場に 集まって から 川べりへ */   /* 第125版: 世界の 依頼を 済ませた 人だけの 一言 */
const nearPt = (a, b, k) => { if (!ok(a) || !ok(b)) return null; const A = a.location, B = b.location, dx = A.x - B.x, dz = A.z - B.z, n = Math.hypot(dx, dz) || 1; return { x: B.x + (dx / n) * k, y: B.y, z: B.z + (dz / n) * k }; };   /* b の そば k マス（a の 側）*/

/* ---------- 場所 ---------- */
const SOURA = (TOWNS.find((t) => /ソウラ/.test(t.name)) || { id: "t26" }).id;
const tc = () => { const t = TOWNS.find((u) => u.id === SOURA); if (!t) return null; const q = getTown(SOURA); return q && q.built ? { x: q.x, y: q.y, z: q.z } : townPos(t); };
const memo = (f) => { let v = null; return () => v || (v = f()); };
const HILL = memo(() => { const f = farOf("r7hill", SOURA, "ソウラの 墓守の 丘", 80, 260); if (f) return f; const o = townOut(SOURA, 0.9, "墓守の 丘"); return o ? { x: o.x, z: o.z, nm: "ソウラの 外れの 墓守の 丘" } : null; });   /* 第127版(fac2): 離れた 丘の 墓地 */
const RIVER = memo(() => { const o = townOut(SOURA, -0.9, "川べり"); return o ? { x: o.x, z: o.z, nm: "ソウラの 川べり（灯籠流しの 水路）" } : null; });
const ROAD = memo(() => { const f = farOf("r7road", SOURA, "冥王の 葬列の 道", 90, 320); if (f) return f; const o = placeOf("road", 7); return o ? { x: o.x, z: o.z, nm: "冥王の 葬列の 道" } : null; });
const near = (f, dx, dz) => () => { const q = f(), c = tc(); return q ? { x: q.x + dx, y: c && typeof c.y === "number" ? c.y : undefined, z: q.z + dz } : null; };

/* ---------- 登場人物 ---------- */
const ex = (s) => s.epx || {};
const back = (s) => !!s.ending && !(s.heroDead && !s.heroBack);
castAdd("r7_yura", { nm: "ユラ", role: "墓守の", gobi: "なのです", skin: "sakura", town: SOURA, from: "r7e1", at: near(HILL, 3, 2),
  pre: ["{smile}……ようこそ なのです。お墓の そうじ中 なのです。"],
  after: [
    [back, ["{smile,☆}迎え灯籠、ちゃんと とどいたのです！ 石に なって いた 町の 人が、帰って きたのです。", "{smile}今年の 帳の 写しは、白い ページが いちばん 多いのです。……いい こと なのです。"]],
    [(s) => !!s.ending, ["{sad}……あの 人の 灯籠、毎晩 流して いるのです。", "{closed}送り灯籠じゃ ないのです。赤い 迎え灯籠 なのです。……まだ、あきらめない のです。"]],
    [doomKnown, ["{sad,…}町の 人が、空の 声を 聞いて しまったのです。", "{angry,up}でも、墓守は 逃げないのです。石に なった 人の 名前、ぜんぶ ここに 書いて おくのです。"]],
    [doomed, ["{cry}……川べりに、赤い 灯籠が 一つ ふえたのです。", "{sad}あなたの 旅の 仲間さんの 分 なのです。……わたしが 毎晩、流すのです。"]],
    [(s) => !!ex(s).lantern7, ["{smile}あの 夜から、町の 灯りが ずっと ついて いるのです。", "{smile,♪}ヨミさまの 分の 灯籠も、毎晩 流して いるのです。"]],
    [(s) => !!s.theoBetray, ["{sad}……学者さんの こと、聞いたのです。", "{closed}でも、灯籠を 流せない 人は、悪い 人じゃ ない のです。わたしは、そう 思うのです。"]],
    [() => true, ["{smile}灯籠流しの 夜は、川べりに 来て ほしい のです。", "{closed}イザクさんは、もう しばらない のです。……たぶん、なのです。"]],
  ] });
castAdd("r7_isak", { nm: "イザク", role: "老人", col: "§7", gobi: "でやんす", skin: "isak", town: SOURA, from: "r7e1", at: near(HILL, -3, 3),
  pre: ["{sweat,汗}あっしは 何も して ないでやんす。……ほんとでやんす。"],
  after: [
    [back, ["{smile,♪}ニナの 石が、ちょっと あったかく なった 気が するでやんす。", "{smile}迎え灯籠は 毎晩 流してるでやんす。……あっしは、あきらめが わるいでやんすよ。"]],
    [(s) => !!s.ending, ["{sad}……あんたの 相棒さんの 分も、赤い 灯籠を 流したでやんす。", "{smile,up}脱獄の 名人が 言うでやんす。……出口の ない 牢は、ないでやんすよ。"]],
    [doomKnown, ["{sweat,汗}町の みんなが 頭を かかえてるでやんす。", "{angry}逃げ道なら、あっしが 知ってるでやんす。こわがってる 人は、ぜんぶ 逃がすでやんす！"]],
    [doomed, ["{sad,…}……聞いたでやんす。あの 子が……。", "{closed}あの 子は、あっしの 灯籠に 火を つけて くれたでやんす。……今度は、あっしが 火を つける 番でやんす。"]],
    [(s) => !!ex(s).lantern7, ["{smile}ニナの 灯籠は、赤に したでやんす。", "{smile,♪}迎えに 行くでやんす。……七年 牢に いたんでやんす。待つのは 得意でやんすよ。"]],
    [() => true, ["{sweat,汗}墓守の 嬢ちゃんに、毎日 墓そうじを させられてるでやんす。", "{smile}……まあ、悪く ないでやんす。"]],
  ] });
castAdd("r7_pipi", { nm: "ピピ", role: "薬師見習いの", gobi: "なのだ", skin: "m6_pip", town: SOURA, from: "r7e2", at: near(RIVER, -4, 3),
  pre: ["{smile}薬の 配達 なのだ！"],
  after: [
    [back, ["{smile,☆}おかえり なのだ！ ピピの 薬、ちゃんと 効いた のだ？", "{smile}セオの 本の つづき、ピピが 自分で 読める ように なったのだ。"]],
    [(s) => !!s.ending, ["{cry}……ピピは、まだ 信じてる のだ。", "{angry,up}薬は、あきらめた 人には 作れない のだ。だから ピピは、作りつづける のだ！"]],
    [doomKnown, ["{angry,!}記録の インク、たくさん 作って くるのだ！ ルミエと ここを、行ったり 来たり なのだ！", "{sad}……石に なった 人の 名前、ピピも 書くのだ。"]],
    [doomed, ["{cry,tears}……うそ なのだ。……あの お姉さんが……", "{sad}ピピ、薬を 作るのだ。泣いてたら、手が ふるえる のだ。"]],
    [(s) => !!ex(s).lantern7, ["{smile}町の 人の 眠りの 病、ほとんど 治ったのだ！", "{sad,…}……セオに、ほめて ほしかったのだ。"]],
    [(s) => !!s.theoBetray, ["{sad}……セオは、わるい 人 なのだ？", "{angry}ちがうのだ。セオは、ピピに 本を 読んで くれたのだ。"]],
    [() => true, ["{smile}ほたる苔の 薬、町の 人に 配って いるのだ！"]],
  ] });
castAdd("r7_morte", { nm: "モルテ", role: "冥王", col: "§5", gobi: "ぞ", skin: "morte", town: SOURA, from: "r7e2", at: near(RIVER, 4, -3),
  pre: ["{closed}……冥王が 町を 歩いて 悪い ことは あるまい。"],
  after: [
    [back, ["{smile}魂の 帳の 写しに、今年は 空白が 多いで あろう。", "{closed}迎え灯籠が、ちゃんと 迎えに 行ったので あろう。"]],
    [(s) => !!s.ending, ["{closed}……送るか、迎えるか。決めるのは、残された 者で あろう。", "{sad,up}そなたは 迎える ほうを 選んだ。……わしも、妃の 灯籠を 赤に したぞ。"]],
    [doomKnown, ["{angry,up}兵は 町の 守りに 出した。冥王が 城に こもる 時では ないぞ。", "{closed}二十年前の 警告……聞いて おれば と、思わぬ 日は ない。"]],
    [doomed, ["{sad,…}……旅の 仲間を、うしなったのか。", "{closed}帳には、書いて おらぬ。……書かぬ ほうが よい 名も、あるで あろう。"]],
    [(s) => !!ex(s).lantern7, ["{smile}町の 灯りが もどった。そなたの おかげぞ。", "{closed}ヨミの 石像は、城の 中庭で 大切に して おる。"]],
    [() => true, ["{closed}灯籠流しの 夜には、冥王も 川べりに 立つぞ。"]],
  ] });

/* ---------- 小道具 ---------- */
const Y =(K, p) => { const S = K.S(p); return S ? Math.floor(S.P.y) : Math.floor(p.location.y); };
const THEO = (K, p, w = false) => K.npcNear(p, "§7学者 セオ", 18, w);
const lose = async (K, p, who, job, nm, line) => { await K.sayAt(p, who, job, nm, [line, K.RT(p)]); return false; };
const once = (k) => { try { if (world.getDynamicProperty(k)) return false; world.setDynamicProperty(k, 1); return true; } catch { return false; } };
const gy = (p, x, z, y0) => { try { const y = groundY(p.dimension, x, z, y0 + 6); return typeof y === "number" && Math.abs(y - y0) <= 3 ? y : null; } catch { return null; } };
/* 柱の 灯り（柵 2本 ＋ 灯籠）。木や 家は 削らない（keep）*/
function post(K, p, q, y0, lamp) { const x = Math.floor(q.x), z = Math.floor(q.z), y = gy(p, x, z, y0); if (y === null) return; K.cmd(p, `setblock ${x} ${y} ${z} dark_oak_fence keep`); K.cmd(p, `setblock ${x} ${y + 1} ${z} dark_oak_fence keep`); K.cmd(p, `setblock ${x} ${y + 2} ${z} ${lamp} keep`); }
/* 墓守の 丘: 墓石と 青い 灯り（ワールドに 1回）*/
function hillDeco(K, p, y0) {
  const S = K.S(p); if (!S || !once("mrpg:epdeco:r7hill")) return;
  try { const q = S.at(9, 0); world.setDynamicProperty("mrpg:epdeco:r7hillat", JSON.stringify({ x: Math.floor(q.x) + 0.5, y: y0, z: Math.floor(q.z) + 0.5 })); } catch {}   /* 第124版: 建てた 場所を 記録 */
  for (const [a, b] of [[8, -6], [8, -3], [8, 3], [8, 6], [10.5, -4.5], [10.5, 4.5]]) { const q = S.at(a, b), x = Math.floor(q.x), z = Math.floor(q.z), y = gy(p, x, z, y0); if (y !== null) { K.cmd(p, `setblock ${x} ${y} ${z} cobblestone_wall keep`); K.cmd(p, `setblock ${x} ${y + 1} ${z} skull keep`); } }
  for (const [a, b] of [[7, -8], [7, 8], [11, 0]]) post(K, p, S.at(a, b), y0, "soul_lantern");
}
/* 灯籠流しの 水路（川べり）: 平らな 所だけ 2マスの 水路を 掘る（水が あふれない 所だけ）。流れる 灯籠の 点を ワールドに 覚えて おく */
const RIV = "mrpg:epdeco:r7river";
function river(K, p, y0) {
  try { const v = JSON.parse(world.getDynamicProperty(RIV) || "null"); if (Array.isArray(v) && v.length) return v; } catch {}
  const S = K.S(p); if (!S) return null;
  let pts = null;
  for (const k of [8.5, 10.5]) {
    const cells = [], has = (x, z) => cells.some((c) => c[0] === x && c[1] === z); let good = true;
    for (let i = -6; i <= 6 && good; i++) for (const w of [0, 1]) { const q = S.at(k + w, i), x = Math.floor(q.x), z = Math.floor(q.z); if (has(x, z)) continue; if (gy(p, x, z, y0) !== y0) { good = false; break; } cells.push([x, z]); }
    if (good) for (const [x, z] of cells) for (const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { if (has(x + a, z + b)) continue; const g = gy(p, x + a, z + b, y0); if (g === null || g < y0) { good = false; break; } }
    if (!good) continue;
    for (const [x, z] of cells) { K.cmd(p, `setblock ${x} ${y0} ${z} air`); K.cmd(p, `setblock ${x} ${y0 - 1} ${z} water`); }
    pts = []; for (let i = -6; i <= 6; i++) { const q = S.at(k + 0.5, i); pts.push([q.x, y0 - 0.3, q.z]); }
    for (const b of [-7.5, 7.5]) post(K, p, S.at(k - 1, b), y0, "soul_lantern");
    break;
  }
  if (!pts) { pts = []; for (let i = -6; i <= 6; i++) { const q = S.at(9, i); pts.push([q.x, y0 + 0.1, q.z]); } }
  pts = pts.map((a) => a.map((v) => Math.round(v * 10) / 10));
  try { world.setDynamicProperty(RIV, JSON.stringify(pts)); } catch {}
  return pts;
}
/* 灯籠が 水路を 流れて いく（白い 灯籠は 青い 火・赤い 灯籠は 赤い 火）。n 個を 少し ずつ ずらして */
async function float(K, p, pts, red = false, n = 1) {
  if (!pts || !pts.length) return; const dim = p.dimension, f = red ? "minecraft:basic_flame_particle" : "minecraft:blue_flame_particle";
  for (let i = 0; i < pts.length + n * 3; i++) { for (let j = 0; j < n; j++) { const k = i - j * 3; if (k < 0 || k >= pts.length) continue; const [x, y, z] = pts[k]; try { dim.spawnParticle(f, { x, y: y + 0.5, z }); dim.spawnParticle("minecraft:endrod", { x, y: y + 0.8, z }); } catch {} } await K.wait(3); }
}
const by = (e, q, k) => { if (!ok(e) || !q) return q; const A = e.location, dx = A.x - q.x, dz = A.z - q.z, n = Math.hypot(dx, dz) || 1; return { x: q.x + (dx / n) * k, y: A.y, z: q.z + (dz / n) * k }; };   /* 第125版(rs): q の そば k マス（e の 側）*/
/* 第125版(rs): 川べりの 霊廟（暗い 聖堂・帳の 写しの 書見台）。舞台の 横に 1回 建てる */
const crypt = (K, p, y0) => facAt("r7crypt", p.location, 60) || (() => { const S = K.S(p); return S ? facSide(p, S, -17, "r7crypt", "crypt", 7, y0) || facSide(p, S, 17, "r7crypt", "crypt", 7, y0) : null; })();
const mid = (pts) => (pts && pts.length ? { x: pts[pts.length >> 1][0], y: pts[pts.length >> 1][1] + 0.6, z: pts[pts.length >> 1][2] } : null);

/* ---------- 1話 魂の 町（墓守の 丘。ユラと、また つかまった イザク）---------- */
const E1 = { id: "r7e1", pv: 127, n: 1, t: "魂の 町", at: 0, ord: 0, place: HILL,
  hint: "§fたましいの 町 §eソウラの 外れの 墓守の 丘§f へ 行こう §7（右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "死んだ 人が さいごに 来る 町 ソウラ。墓守の 少女 ユラは、墓を 荒らしたと 思って 縛って いた 男を つれて きた。サンドリアの 牢で 会った イザクだった。イザクは、石に なった 娘 ニナの 名が 霊廟の 帳に 載って いないか、たしかめに 来たのだった。霊廟の 帳は、死んだ 人の 名を 書く『魂の 帳』の 写し。白い 灯籠を 流すと その 人の 名が 書かれ、もう 帰って こない。石に なった 人は 書かれて いない。名を 呼ばれれば、帰り道を 思い出すと いう。セオは きのう この 町で、白い 灯籠を 一つ 買って いた。",
  set: { met7: 1 },
  async run(p, d, K) {
    const y0 = Y(K, p);
    const yard = fac(K, p, "r7yard", "redyard", 7, y0); if (!yard) hillDeco(K, p, y0);   /* 第125版(rs): 赤い 灯籠の 墓地と 墓守の 番小屋の 牢（建てられない 所は 今までの 墓石）*/
    const S0 = K.S(p), YM = (n, a, b) => facMark("r7yard", n, p.location) || (S0 ? S0.at(a, b) : null), GRV = YM("grave", 8, -3), CELL = YM("cell", 9, 4), FRONT = YM("front", 5.5, 3.5), LAMP = YM("lamp", 6, -6);
    await K.open(p, "たましいの 町 ソウラの 外れ（墓守の 丘）", "night");
    K.sound(p, "note.bell", 1, 0.4);
    if (yard) { K.burst(p.dimension, LAMP, "minecraft:basic_flame_particle", 3, 0.2, 0.2); await K.at(p, LAMP, 16, 3.5, 0.6); await K.at(p, yard, 18, 9, 2); }   /* 赤い 灯籠の 柱 → 墓地と 番小屋 */
    const eH = K.hero(p);
    if (ok(eH) && GRV) await K.walkCam(p, eH, by(eH, GRV, 2.6), 20);   /* 墓の 列へ 歩いて 見回す */
    await K.hsay(p, K.V(["{sad,…}……ここが ソウラ。ほんとに しずかな 町だね。", "{?}セオさんとの 待ち合わせは お城だけど……セオさんの 手紙の 消印、この 町 だったんだ。"], ["{closed}……しずかな 町ね。風の 音しか しない。", "{?}セオさんとの 待ち合わせは お城よね。……セオさんの お手紙の 消印、この 町 だったわ。"], ["{closed}……しずか すぎる 町。", "{?}セオとの 待ち合わせは 城。……セオの 手紙の 消印は、この 町。"], ["{closed}……とても 静かな 町 ですね。", "{?}セオさんとの 待ち合わせは お城ですが……セオさんの お手紙の 消印が、この 町 でした。"]));
    await K.hsay(p, K.V(["{closed,…}レイの 手紙の『消し跡』……『冥府』と『鍵』。……考えすぎ、だよね。"], ["{closed,…}レイくんの 手紙の『消し跡』……『冥府』と『鍵』。……考えすぎ、よね。"], ["{closed,…}レイの 手紙の 消し跡。『冥府』と『鍵』。……考えすぎか。"], ["{closed,…}レイさんの お手紙の『消し跡』……『冥府』と『鍵』。……考えすぎ、でしょうか。"]));
    const eY = K.cast(p, "r7_yura"); K.act(eY, "work"); K.hold(eY, "brush");   /* 墓の あいだを 掃きながら 来る */
    await K.csay(p, "r7_yura", ["{smile}……ようこそ なのです。ここは、たましいの 町 ソウラ なのです。", "{closed}死んだ 人が、さいごに 来る 町 なのです。"], eH);
    K.act(eY, 0);
    await K.csay(p, "r7_yura", ["{smile,nod}わたしは ユラ。この 丘の 墓守 なのです。"]);
    await K.ots(p, eY, eH, 8);   /* ユラの 肩ごしに あなたたち */
    await K.hsay(p, K.V(["{shock,!}墓守？ その 年で、ひとりで？"], ["{shock,…}墓守……ひとりで？"], ["{?}墓守。……ひとりで？"], ["{shock,!}墓守を、おひとりで……？"]));
    if (ok(eY) && GRV) { await K.go(eY, by(eY, GRV, 1.0), 16); K.turn(eY, GRV); K.act(eY, "kneel"); K.hold(eY); }   /* 背を 向けて おばあちゃんの 墓の 前へ */
    await K.push(p, eY, 24, 4.5, 1.9, 1.0);   /* 墓の 前で ひざを つく 背中に ゆっくり 寄る */
    await K.csay(p, "r7_yura", ["{closed}おばあちゃんが 墓守 だったのです。……去年の 冬、石に なったのです。"], eH);
    K.turn(eY); K.act(eY, "up");
    await K.csay(p, "r7_yura", ["{smile,汗}だから 今は、わたしが 墓守 なのです。……さみしく なんか、ないのです。"], eH);
    K.act(eY, 0); K.re(eY, "sad", "…");
    /* 番小屋の 牢から なさけない 声（縛られた 男が 鉄格子の 向こうに いる）*/
    K.sound(p, "mob.villager.no", 0.8);
    const eI = await K.put(p, "r7_isak", CELL, FRONT); K.act(eI, "kneel"); K.hold(eI, "rope");
    await K.at(p, CELL, 16, 3.6, 1);
    await K.csay(p, "r7_isak", ["{sweat,汗}た、たすけて でやんす〜！ 縄が 食いこんで いたいでやんす〜！"]);
    await K.csay(p, "r7_yura", ["{angry,怒}にげちゃ だめ なのです！ 夜中に 霊廟へ しのびこんだ、墓どろぼう なのです！"], eI);
    { const YU = YM("yu", 7, 2.4), AI = YM("aisle", 6, -3); if (ok(eY) && YU) (async () => { if (AI) await K.go(eY, AI, 8, true); await K.go(eY, YU, 14, true); })(); }   /* ユラが 牢へ かけて いく */
    if (ok(eH) && FRONT) await K.walkCam(p, eH, by(eH, FRONT, 2.6), 22);   /* あなたたちも 牢の 前へ */
    if (ok(eY)) { K.hold(eY, "key"); K.act(eY, "give"); K.sound(p, "random.door_open", 0.8); facState("r7yard", 1); await K.wait(10); K.act(eY, 0); K.hold(eY); }   /* 牢の 戸を 開けて 引きだす（縛った まま）*/
    if (ok(eI) && FRONT) { K.act(eI, 0); await K.walkCam(p, eI, FRONT, 18); K.act(eI, "kneel"); if (ok(eY)) await K.go(eY, by(eY, FRONT, 1.4), 10); }   /* ユラも 男の 横へ（牢の 前の 開けた 所）*/
    await K.hsay(p, K.V(["{shock,!,jump,up}……イザクさん！？ サンドリアの 牢の！"], ["{shock,!,up}……イザクさん？ サンドリアの 牢に いた……"], ["{shock,!,up}……イザク。サンドリアの 牢の。"], ["{shock,!,up}イザクさん……！？ サンドリアの 牢で ご一緒した……"]));
    await K.csay(p, "r7_isak", ["{smile,♪}おお、あんたでやんすか！ 砂王さまの おゆるしで、やっと 牢を 出られたでやんす。", "{sweat,汗}……で、出た とたん、また つかまったでやんす。"], eH);
    await K.hsay(p, K.V(["{sweat,汗}……なんで 霊廟に しのびこんだの？"], ["{sweat,汗}……どうして 霊廟に しのびこんだの？"], ["{?}……なぜ 霊廟に 入った。"], ["{sweat,汗}……どうして 霊廟に しのびこんだのですか？"]));
    K.act(eI, "hold");
    await K.up(p, eI, 12);
    await K.csay(p, "r7_isak", ["{closed}……娘の ニナが 石に なって、七年でやんす。", "{sad,up}石に なった 者は、死んだのか、生きてるのか……だれも 教えて くれねえでやんす。"]);
    await K.csay(p, "r7_isak", ["{sad}ソウラの 霊廟には、死んだ 者の 名を 書く 帳が あると 聞いたでやんす。", "{cry,up}ニナの 名が 載ってたら……もう、迎えに 行けねえ。それを、たしかめたかったでやんす。"], eH);
    await K.up(p, eY, 10);
    await K.csay(p, "r7_yura", ["{sad,…}……帳に 名前が 載るのは、白い 灯籠を 流した 人だけ なのです。", "{closed}ソウラでは、白い 灯籠は『送り灯籠』なのです。流すと、冥王さまが その 人の 名を 帳に 書いて……もう、帰って こないのです。"]);
    await K.csay(p, "r7_yura", ["{closed}霊廟の 帳は 写し なのです。元の 帳の 王さまは、ある 日、筆を 折ったと 伝わって いるのです。"]);   /* 第125版 Q15 */
    await K.csay(p, "r7_yura", ["{smile,up}でも、赤い 灯籠は『迎え灯籠』なのです。遠くの 人が、帰り道を 見失わない ように 流すのです。"]);
    K.hold(eY, "notebook"); K.act(eY, "show"); K.sound(p, "item.book.page_turn", 1);   /* 鎖で 綴じた 帳の 写しを 開いて 見せる */
    await K.up(p, eY, 10);
    await K.csay(p, "r7_yura", ["{closed}これが 写し なのです。元の 帳の 名は §e魂の 帳§f。生きて いる 人と、死んだ 人を 分けて 書く 帳 なのです。", "{sad}『死者』と 書かれた 名は、もう 戻れないのです。呼んでも、とどかないのです。"], eH);
    await K.ots(p, eY, eH, 8);   /* 帳を 持つ ユラの 肩ごしに あなたたち */
    await K.csay(p, "r7_yura", ["{closed}でも、石に なった 人は 書かれて いないのです。石の 中で 待って いるだけ。死んで いない のです。", "{smile,up}名前を 呼ばれた 石は、帰り道を 思い出して 戻る……おばあちゃんは そう 言って いたのです。"], eH);
    await K.push(p, eH, 16, 4, 1.6);
    await K.hsay(p, K.V(["{!,up}……じゃあ、石に なった 人たちは、まだ 迎えに 行けるんだ。", "{closed}手帳の 名前、ちゃんと 呼びに 行かなきゃ。"], ["{!,up}……石に なった 人は、まだ 迎えに 行けるのね。", "{closed}手帳の 名前、ひとりずつ 呼びに 行かなくちゃ。"], ["{closed,up}……石の 人は、まだ 迎えに 行ける。", "{closed}手帳の 名前、呼びに 行く。"], ["{!,up}……石に なった 方々は、まだ お迎えに 行けるのですね。", "{closed}手帳の お名前、ひとりずつ 呼びに 参ります。"]));
    await K.csay(p, "r7_yura", ["{closed}ニナさんの 名は、帳に なかったのです。……わたしが 毎朝 読んでるから、知ってるのです。"], eI);
    K.act(eY, 0); K.hold(eY);
    K.re(eI, "shock", "!");
    await K.csay(p, "r7_isak", ["{cry,tears,up}……ほ、ほんとで やんすか……！"]);
    if (wl(qs(d), "wq4b")) await K.csay(p, "r7_isak", ["{smile,tears}……ファラの 砂の ばら、ニナの 石の 前に ちゃんと 置いて きたでやんす。待つのが 得意な 花でやんす。"], eH);   /* 第125版: 世界の 依頼「砂の ばら」を 済ませた 人だけ */
    await K.csay(p, "r7_yura", ["{sweat,汗,up}……墓どろぼうじゃ ない なら、しばる 理由は ないのです。……ごめんなさい、なのです。"]);
    if (ok(eY) && ok(eI)) { await K.go(eY, by(eY, eI.location, 1.1), 12); K.act(eY, "kneel"); K.sound(p, "random.pop", 0.8); await K.wait(8); K.act(eY, 0); }   /* 縄を ほどく */
    K.hold(eI); K.act(eI, "up"); K.burst(p.dimension, ok(eI) ? eI.location : null, "minecraft:villager_happy", 5, 0.5, 0.8);
    await K.csay(p, "r7_isak", ["{smile,♪}ほどけたでやんす！ ……縄ぬけなら 三つ 数える あいだに できたんでやんすが、嬢ちゃんの 顔を 立てたでやんす。"]);
    await K.csay(p, "r7_yura", ["{angry,怒}……それなら 早く 言って ほしかったのです！"]);
    K.act(eI, 0);
    /* セオの 手がかり */
    await K.hsay(p, K.V(["{?}ユラちゃん。学者の セオさんって 人、来なかった？ 本ばっかり 読んでる 人。"], ["{?}ユラちゃん。セオさんという 学者さん、見なかった？"], ["{?}ユラ。学者の セオ、見なかったか。"], ["{?}ユラさん。セオさんという 学者さんを、お見かけ しませんでしたか？"]));
    await K.csay(p, "r7_yura", ["{closed}学者さんなら、きのう 来たのです。霊廟の 帳の 写しを、夜どおし 読んで いたのです。", "{?}……それから、白い 灯籠を 一つ 買って いったのです。だれの 分かは、言わなかったのです。"], eH);
    await K.push(p, eH, 22, 4, 1.6);   /* 白い 灯籠の 意味に 気づく 顔へ ゆっくり 寄る */
    await K.hsay(p, K.V(["{sad,…,up}（……白い 灯籠。送る ほうの……）"], ["{sad,…,up}（……白い 灯籠。送る ほう……）"], ["{closed,…,up}（……白。送る ほう）"], ["{sad,…,up}（……白い 灯籠。送る ほうの……）"]));
    await K.csay(p, "r7_yura", ["{smile}あしたの 夜は 灯籠流し なのです。学者さんも、きっと 川べりに 来るのです。", "{smile,♪}あなたも 来て ほしい のです。……町の 灯り、影の せいで 半分 消えて しまったから。一つでも 多い ほうが いいのです。"]);
    await K.csay(p, "r7_isak", ["{smile,♪}あっしも 手伝うでやんす！ 逃げ足と 縄ぬけだけは、だれにも 負けねえでやんす。"]);
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    K.pay(p, E1, 300, [["mei_necro", 1]]);
    await K.end(p, { leave: [eY, eI], card: "§7→ あしたの 夜、§eソウラの 川べり§7 で 灯籠流し（右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 2話 灯籠流し（川べり。ピピの 薬・冥王 モルテの 妃・セオが 弟の 灯籠を 流せない）---------- */
const SPLAZA = () => { const q = plazaOf(SOURA, "たましいの 町 ソウラの 広場（灯籠流しの 夜）"); return q ? { x: q.x, z: q.z, nm: q.nm } : RIVER(); };
const E2 = { id: "r7e2", n: 2, t: "灯籠流し", at: 0, ord: 1, place: SPLAZA,
  hint: "§fソウラの §e広場§f へ 行こう §7（灯籠流しの 夜。町の みんなが 広場から 川べりへ 灯籠を 運ぶ。右上の 案内。「！」の 目印の そばで 立ち止まろう）",
  syn: "灯籠流しの 夜、シルヴァの 薬師見習い ピピが、影の 眠りに 効く 薬を 届けに 来た。冥王 モルテは「十年前に 石に なった 妃の 灯籠を、まだ 流せぬ」と 話した。セオは 白い 灯籠に 小さな 名前を 書いて いた。……弟の 名だった。セオは 水ぎわに ひざを ついた まま、どうしても 手を はなせず、灯籠の 火は 風で 消えた。あなたは 手帳に 書いた 人たちの ために、赤い 迎え灯籠を 流した。",
  set: { met7: 1, lantern7a: 1 },
  async run(p, d, K) {
    /* 第126版(PV): 広場で 灯籠に 火を 入れる（町の 人・ピピ）→ 灯籠を 運んで 川べりへ */
    let eH = null, eP = null; const PZ = SPLAZA(), RV = RIVER();
    if (PZ && RV && Math.hypot(PZ.x - RV.x, PZ.z - RV.z) > 20) {
      const yp = Y(K, p); festSet(p, "r7soura", p.location, yp); const cw = crowd(K, p, 3);
      for (const e of cw) K.hold(e, "lantern");
      await K.open(p, "ソウラの 広場（灯籠流しの 夜）", "night");
      K.sound(p, "note.chime", 0.6);
      await K.narr(p, ["§7広場で、町の 人たちが 白い 灯籠に 青い 火を 入れて いく。", "§7火の 入った 灯籠から 順に、川べりへ 運ばれて いく。"], cw[0] || null);
      eH = K.hero(p);
      /* ピピが 走って くる（シルヴァの 薬師見習い）*/
      eP = K.cast(p, "r7_pipi"); K.act(eP, "raise");
      await K.csay(p, "r7_pipi", ["{smile,☆,jump}まにあった のだーっ！ ……あっ！ やっぱり あなた なのだ！"], eH);
      await K.hsay(p, K.V(["{shock,!,jump,up}ピピちゃん！？ シルヴァの！ なんで ここに！？"], ["{shock,!}ピピちゃん……！ どうして ソウラに？"], ["{shock,!}……ピピ。なんで ここに。"], ["{shock,!}ピピさん！ どうして ソウラに？"]));
      K.act(eP, "show"); K.hold(eP, "potion");
      await K.csay(p, "r7_pipi", ["{smile,♪}ほたる苔の 薬を 届けに 来たのだ！ この 町、影の せいで 眠ったまま 起きない 人が 多いのだ。", "{smile,arms}ピピが 作った のだ。まだ 見習いだけど、半分は 一人前 なのだ！"], eH);
      K.act(eP, 0);

      await K.moveTo(p, RV, "ソウラの 川べり（灯籠流しの 夜）", [...cw, eP]);
    }
    const y0 = Y(K, p), pts = river(K, p, y0), M = mid(pts), CR = crypt(K, p, y0), BOOK = facMark("r7crypt", "book", p.location);   /* 第125版(rs): 川の むこうの 霊廟（帳の 写しの 書見台）*/
    if (!eH || !K.S(p) || Math.hypot(K.S(p).P.x - (RV ? RV.x : 0), K.S(p).P.z - (RV ? RV.z : 0)) > 20) await K.open(p, "ソウラの 川べり（灯籠流しの 夜）", "night");
    K.sound(p, "note.chime", 0.6);
    if (pts) { float(K, p, pts, false, 2); await K.at(p, M, 18, 5, 0.6); }
    if (CR) await K.at(p, CR, 16, 9, 2.5);   /* 灯籠の 行く 先の 霊廟 */
    eH = K.hero(p);
    if (ok(eH) && M) await K.walkCam(p, eH, by(eH, M, 2.2), 18);   /* 水ぎわへ */
    await K.hsay(p, K.V(["{smile,…}……きれい。青い 火が、水の 上を すべって いく。"], ["{smile,…}……きれい。青い 火が、ゆっくり 流れて いくわ。"], ["{closed}……青い 火が、流れてる。"], ["{smile,…}……なんて きれい。青い 火が、水の 上を……"]));
    if (!ok(eP)) { eP = K.cast(p, "r7_pipi"); } else { const e1 = K.cast(p, "r7_pipi"); if (ok(e1)) eP = e1; }
    /* セオが 灯籠を 持って 歩いて くる */
    const eS = THEO(K, p); K.act(eS, "hold"); K.hold(eS, "lantern"); K.act(eP, 0);
    if (ok(eS) && M) await K.walkCam(p, eS, by(eS, M, 3.2), 18);   /* 白い 灯籠を 持って 川ぞいを 歩いて くる */
    await K.low(p, eS, 10);
    await K.csay(p, "r7_pipi", ["{smile,☆,jump,up}セオ！！ セオなのだ！ 森で 読んで くれた、竜が 星を さがす お話！ つづきを 読んで ほしいのだ！"]);
    await K.say(p, "セオ", ["{smile,…}……ピピさん。ここまで、薬を 届けに 来たんですね。", "{closed}本の つづきは……今夜は、すみません。読めそうに ないんです。"], eP);
    K.re(eP, "sad", "?");
    await K.hsay(p, K.V(["{?}セオさん、その 灯籠……白いんだね。"], ["{?}セオさん。その 灯籠、白いのね。"], ["{?}……白い 灯籠。"], ["{?}セオさん、その 白い 灯籠は……"]));
    await K.say(p, "セオ", ["{closed}……ええ。少し、調べものの ついでに。"], eH);
    /* 冥王 モルテ */
    const eM = K.cast(p, "r7_morte"); K.act(eM, "hold"); K.hold(eM, "staff");
    await K.low(p, eM, 12);
    await K.csay(p, "r7_morte", ["{closed,low}……今宵は 灯籠流しぞ。冥王が 川べりに 立っても、ふしぎは あるまい。", "{closed}わしは モルテ。この 冥府を 治める 者ぞ。"], eH);
    await K.csay(p, "r7_morte", ["{smile}薬師の 子よ。眠る 民への 薬、礼を 言うぞ。"], eP);
    await K.csay(p, "r7_pipi", ["{blush,汗}れ、礼なんて いいのだ……！ ピピは、見習い なのだ……！"]);
    K.act(eM, 0);
    /* 町の 人が 灯籠を 流す */
    K.sound(p, "note.harp", 0.5);
    if (pts) { float(K, p, pts, false, 3); await K.at(p, M, 14, 6, 0.8); }
    await K.narr(p, ["§7川べりの 人たちが、一人、また 一人と 白い 灯籠を 水に 置いた。", "§7だれも 何も 言わない。青い 火だけが、遠くへ 流れて いく。"], M);
    await K.hsay(p, K.V(["{?}……モルテさまは、流さないの？"], ["{?}……モルテさまは、流さないの？"], ["{?}……モルテは、流さないの。"], ["{?}……モルテさまは、お流しに ならないのですか？"]));
    if (ok(eM) && M) { await K.go(eM, by(eM, M, 2), 18); K.turn(eM, M); }   /* 背を 向け、水の 上の 灯りを 見る */
    await K.ots(p, eM, M || eH, 14);   /* 冥王の 肩ごしに 流れて いく 灯籠 */
    await K.csay(p, "r7_morte", ["{sad,…}……十年前、妃が 石に なった。", "{closed,up}わしは 冥王。死んだ 者を 送るのが つとめぞ。……なのに、妃の 灯籠だけは、まだ 流せぬ。"]);
    { const eYo = K.npcNear(p, "§6【宵闇の 地方マスター】§fヨミ", K.PJ("yomi", 8)); K.act(eYo, "hold");   /* 第124版(合議): ヨミを 先に 見せる（城で 待つ 守り手）*/
      await K.low(p, eYo, 12);
      await K.say(p, "ヨミ", ["{closed}……陛下。妃さまの 灯籠は、わたしが 預かって おきます。流す 日が 来るまで。"]);
      await K.csay(p, "r7_morte", ["{closed}宵闇の 地方マスター、ヨミぞ。この 冥府の 石板の 守り手でも ある。"], eH);
      K.act(eYo, 0); await K.up(p, eYo, 10);   /* 第124版: 気持ちの 行は 寄りで */
      await K.say(p, "ヨミ", ["{smile}あなたが 石板の 子。……相棒の 目が いい。城で 待って いるわ。"]);
      await K.leave(eYo, p, 10, false); }
    if (BOOK) await K.at(p, BOOK, 16, 2.4, 0.4);   /* 霊廟の 帳の 写し */
    await K.csay(p, "r7_morte", ["{sad,up}送れば、わしが 帳に 書く。……書けば、妃は もう 帰って こぬ。", "{closed}石の 者は 帳に 載らぬ。……載らぬ まま 十年。冥王にも、待つ ほか ないのだ。"], eH);
    K.turn(eM); await K.up(p, eM, 10);
    await K.csay(p, "r7_morte", ["{closed,up}……妃を 守って いた 若い 兵が、あの 日から 姿を 消した。", "{sad}あの 者も どこかで、灯籠を 流せずに おるやも しれぬ。"]);
    K.act(eM, 0);
    /* セオが 水ぎわに ひざを つく */
    if (ok(eS) && M) { const l = eS.location; await K.go(eS, { x: (M.x + l.x) / 2, y: l.y, z: (M.z + l.z) / 2 }, 16); }
    K.act(eS, "kneel");
    await K.push(p, eS, 28, 4.5, 1.7, 0.9);   /* ひざを つく 手もとへ ゆっくり 寄る */
    await K.narr(p, ["§7セオは 水ぎわに ひざを ついた。白い 灯籠に、小さな 字で 名前が 書いて ある。", "§7灯籠を 水に 置こうと して……指が、はなれない。"], eS);
    K.sound(p, "random.fizz", 0.6); K.burst(p.dimension, ok(eS) ? eS.location : null, "minecraft:white_smoke_particle", 4, 0.4, 0.6);
    await K.narr(p, ["§7風が 吹いた。灯籠の 火が、ふっと 消えた。"], eS);
    await K.hsay(p, K.V(["{sad,…,up}……セオさん？"], ["{sad,…,up}……セオさん？"], ["{closed,…,up}……セオ。"], ["{sad,…,up}……セオさん？"]));
    await K.say(p, "セオ", ["{sad,…,up}……弟です。", "{closed,low}流したら、帳に 載る。……載ったら、もう……"]);
    await K.say(p, "セオ", ["{smile,汗}……すみません。学者が、町の きまりを 怖がる なんて。おかしいですよね。"], eH);
    await K.hsay(p, K.V(["{sad,up}……いっしょに 持とうか？ ひとりで 持つと、重いでしょ。"], ["{sad,up}……いっしょに 持つ？ 重そうよ、その 灯籠。"], ["{closed,up}……手、貸そうか。"], ["{sad,up}……ご一緒に、お持ち しましょうか。"]));
    K.act(eS, "up");
    await K.say(p, "セオ", ["{closed}……いいえ。これは、僕が いつか 自分で。", "{sad,low}いつか……流せる 日が 来たら。"]);
    /* ピピが セオの 袖を つかむ */
    if (ok(eP) && ok(eS)) { const q = eS.location; await K.go(eP, { x: q.x - 1, y: q.y, z: q.z + 0.5 }, 12); K.act(eP, "hold"); }
    await K.csay(p, "r7_pipi", ["{sad,up}……セオは、流さなくて いいのだ。", "{smile,tears,up}ピピは、流さない セオでも、ずっと 友だち なのだ。森で 本を 読んで くれた セオ なのだ。"]);
    await K.up(p, eS, 12);
    await K.say(p, "セオ", ["{smile,…,up}……ありがとう、ピピさん。"]);
    K.act(eP, 0);
    await K.say(p, "セオ", ["{closed}……あさっては 葬列の 日です。僕は 先に、霊廟で 調べものを して います。", "{smile}モルテさまの ところで、また 会いましょう。"], eH);
    K.act(eS, 0);
    await K.leave(eS, p, 10, false);
    await K.csay(p, "r7_pipi", ["{sad,…}……セオの 手、雪みたいに つめたかった のだ。"]);
    /* 手帳に 書いた 人たちの ために 赤い 灯籠 */
    K.act(eH, "show"); K.hold(eH, "chochin");
    await K.hsay(p, K.V(["{closed}……わたしも、流して いい？ 赤い ほうを。", "{smile,up}手帳に 書いた 人たち……石に なった 人たちの 分。送るんじゃ なくて、迎えに 行く ための 灯籠。"], ["{closed}……わたしも 流して いいかしら。赤い ほうを。", "{smile,up}手帳に 書いた、石に なった 人たちの 分。……迎えに 行く ための 灯籠よ。"], ["{closed}……赤いのを 一つ。", "{closed,up}手帳に 書いた 人たちの 分。迎えに 行く。"], ["{closed}……わたしも、赤い 灯籠を 流して よろしいですか。", "{smile,up}手帳に 記した、石に なった 方々の 分です。お迎えに あがる ための 灯籠です。"]));
    K.act(eH, 0);
    await K.csay(p, "r7_morte", ["{smile,up}……迎え灯籠か。よかろう。"]);
    if (ok(eH) && M) { await K.go(eH, by(eH, M, 1.2), 12); K.act(eH, "kneel"); await K.wait(8); K.act(eH, 0); }   /* 水ぎわに ひざを ついて 置く */
    K.hold(eH); if (pts) { float(K, p, pts, true, 1); await K.at(p, M, 16, 4, 0.6); }
    await K.narr(p, ["§7青い 火の あいだを、赤い 火が 一つ、ゆっくり 流れて いった。"], M);
    /* 葬列の 道の 頼み */
    K.act(eM, "point");
    await K.csay(p, "r7_morte", ["{closed}旅の 者よ。一つ 頼みたい ことが ある。", "{angry,up}あさっての 葬列が 通る 道に、墓場の モンスターが 巣を 作った。……あの 道を、清めて くれぬか。"], eH);
    K.act(eM, 0);
    await K.hsay(p, K.V(["{angry,up}まかせて！"], ["{closed,up}……ええ。行きましょう。"], ["{closed,up}……行く。"], ["{closed,up}お引き受け します。"]));
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    K.pay(p, E2, 400, [["c_herbs", 2]]);
    await K.end(p, { leave: [eM, eP], card: "§7→ §e冥王の 葬列の 道§7 を 清めよう（ソウラと 冥王の 城の あいだ。右上の 案内）", kind: "night" });
    return true;
  } };

/* ---------- 3話 葬列の 道（街道。墓場の モンスターの 巣・ひらいた 本の 印・黒い 外套の 男）---------- */
const E3 = { id: "r7e3", pv: 127, n: 3, t: "葬列の 道", at: 0, ord: 2, place: ROAD, fac: "r7nest",
  hint: "§fソウラと 冥王の 城の あいだ §e冥王の 葬列の 道§f へ 行こう §7（墓場の モンスターの 巣を はらう。右上の 案内）",
  syn: "葬列の 道で、墓場の モンスターの 群れと 墓穴の 主を はらった。イザクは 巣の 奥で 古い 抜け道を 見つけ、紙の 切れはしを 拾った。紫の インクで、ひらいた 本の 印が ある。遠くの 丘から、黒い 外套の 男が こちらを 見て いた。モルテは「送られぬ まま、帳にも 載らぬ 者たちを、わしは 責められぬ」と 言い、ユラは「冥王さまは、やさしすぎるのです」と つぶやいた。",
  set: { met7: 1, road7: 1 },
  async run(p, d, K) {
    fac(K, p, "r7nest", "gravenest", 7, Y(K, p));   /* 第125版(fac): 掘りかえされた 墓穴（巣）と 墓石 */
    await K.open(p, "冥王の 葬列の 道", "ash");
    K.sound(p, "mob.wither.ambient", 1, 0.3);
    const eH = K.hero(p), eM = K.cast(p, "r7_morte"), eY = K.cast(p, "r7_yura");
    K.act(eY, "hold"); K.hold(eY, "box");
    const NS = facAt("r7nest", p.location);
    await K.csay(p, "r7_yura", ["{closed}この 道に、白い 石を ならべて おくのです。葬列が 迷わない ように。"], eH);
    for (const b of [-3.2, 3.2]) { const S = K.S(p); if (!S || !ok(eY)) break; const q = S.at(4.5, b); await K.walkCam(p, eY, { x: q.x - 0.9, y: q.y, z: q.z }, 14); K.act(eY, "kneel"); const g = gy(p, Math.floor(q.x), Math.floor(q.z), Y(K, p)); if (g !== null) K.cmd(p, `setblock ${Math.floor(q.x)} ${g} ${Math.floor(q.z)} calcite keep`); K.sound(p, "dig.stone", 0.8); await K.wait(8); K.act(eY, 0); }   /* 第125版(rs): 道の 両わきに 白い 石を 置いて まわる */
    K.hold(eY);
    if (ok(eM) && NS) { await K.go(eM, by(eM, NS, 4), 20); K.turn(eM, NS); }   /* 冥王は 先に 立って 巣の 方を にらむ */
    await K.ots(p, eM, NS || eH, 10);
    await K.csay(p, "r7_morte", ["{angry,low}……来るで あろう。土の 下から、棺の 匂いを かぎつけて。"]);
    K.turn(eM); K.act(eY, 0);
    const q0 = K.fwd(p, 9, -3); K.boom(p.dimension, q0); K.shake(p, 0.4, 0.5); K.sound(p, "mob.zombie.say", 0.7);
    K.burst(p.dimension, q0, "minecraft:soul_particle", 10, 1.4, 0.4);
    await K.at(p, q0, 12, 6, 1);
    K.act(eH, "guard");
    await K.hsay(p, K.V(["{angry,!,up}地面から 出て きた！ ユラちゃん、下がって！"], ["{angry,!,up}ユラちゃん、わたしの 後ろへ！"], ["{angry,!,up}……来た。ユラ、下がれ。"], ["{angry,!,up}ユラさん、お下がり ください！"]));
    if (!K.flag(p, "r7e3a")) {
      const r = await K.battle(p, K.team(["nether", "nether", "animal"], 52, 3, 10), { name: "葬列の 道の 亡者たち", arena: "葬列の 道", theme: "soulvalley", speaker: "墓場の モンスター", lines: { half: "……ミチ……ワタサヌ……", low: "……ツチヘ……カエル……" } });
      if (r !== "win") return lose(K, p, "§5冥王 モルテ", K.PJ("morte", 15), "モルテ", "{sad}……無理を させた。一度 下がれ。");
      K.setFlag(p, "r7e3a");
    }
    /* イザクが 巣の 抜け道を 見つける */
    const eI = K.cast(p, "r7_isak");
    await K.csay(p, "r7_isak", ["{smile,♪}やっぱり でやんす！ あの 墓の 下、抜け道が 掘って あるでやんす。", "{closed}七年 牢で 壁ばっかり 見てたでやんす。抜け道は、見りゃ わかるでやんすよ。"], eH);
    const nest = facMark("r7nest", "hole", p.location) || K.fwd(p, 8, 3);
    K.burst(p.dimension, nest, "minecraft:soul_particle", 12, 1.2, 0.3); K.sound(p, "mob.wither.hurt", 0.5); K.shake(p, 0.6, 0.6);
    await K.at(p, nest, 14, 6, 1.4);
    await K.csay(p, "r7_isak", ["{shock,!,up}……で、でかいのが 出て くるでやんすーっ！"]);
    if (!K.flag(p, "r7e3b")) {
      await K.duel(p, "§5墓穴の 主", "§7葬列の 道の 下に、巣を 作って いた 主", { fams: ["nether"] });
      const r = await K.battle(p, K.bossOne(["nether"], 54, 14), { name: "墓穴の 主", arena: "葬列の 道の 巣", theme: "soulvalley", hpk: 2.4, speaker: "墓穴の 主", lines: { half: "……ネムリ……ヲ……ジャマ……スルナ……", low: "……オオ……ツチガ……アタタカイ……" } });
      if (r !== "win") return lose(K, p, "§5冥王 モルテ", K.PJ("morte", 15), "モルテ", "{sad}……主は 手ごわいぞ。仕度を ととのえて 来るが よい。");
      K.setFlag(p, "r7e3b");
    }
    K.burst(p.dimension, nest, "minecraft:white_smoke_particle", 10, 1.4, 0.4);
    await K.narr(p, ["§7主が 土に 還ると、道の 上の 空気が、少し 軽く なった。"], nest);
    /* 抜け道の 奥の 紙の 切れはし（ひらいた 本の 印）*/
    if (ok(eI) && nest) { const l = p.location, n = Math.hypot(l.x - nest.x, l.z - nest.z) || 1; await K.go(eI, { x: nest.x + ((l.x - nest.x) / n) * 2.3, y: l.y, z: nest.z + ((l.z - nest.z) / n) * 2.3 }, 14); K.act(eI, "kneel"); K.sound(p, "item.book.page_turn", 1); await K.wait(8); K.act(eI, "hold"); }
    await K.csay(p, "r7_isak", ["{?}……紙の 切れはしでやんす。字は 雨で 流れてるでやんすが……印だけ 残ってるでやんす。", "{?,up}紫の インクで……ひらいた 本の 形でやんす。"]);
    await K.up(p, eH, 12);
    K.hold(eH, "notebook");
    await K.hsay(p, K.V(["{?,…,up}ひらいた 本の 印……？ ……手帳に 書いとく。"], ["{?,…,up}……ひらいた 本の 印。手帳に 書いて おくわ。"], ["{closed,…,up}……ひらいた 本。手帳に 書く。"], ["{?,…,up}ひらいた 本の 印……手帳に 記して おきます。"]));
    await K.csay(p, "r7_morte", ["{closed}……六影の 下っぱが 使う 印とは、ちがうな。もっと 上の 者の 印かも しれぬ。"], eH);
    /* 遠くの 丘の 黒い 外套の 男（今は 戦わない）*/
    const FAR = K.fwd(p, 16, -9), eA = await K.put(p, "§8黒い 外套の 男", FAR, null, K.PJ("noxa", 9)); K.act(eA, "hold");   /* 第125版(rs): 遠くの 丘に 立って いる（暗転の 中で 立たせ、ゆっくり 寄る）*/
    await K.push(p, ok(eA) ? eA : FAR, 30, 9, 4.5, 1.5);
    await K.csay(p, "r7_isak", ["{sweat,汗}……あそこ。黒い 外套の 男が、こっちを 見てるでやんす。", "{closed}あの 立ち方……牢の 看守より、いやな 感じでやんす。"]);
    K.act(eA, 0); await K.leave(eA, p, 10, false);
    await K.hsay(p, K.V(["{angry,?}……行っちゃった。"], ["{sad,?}……行っちゃったわ。"], ["{closed}……行った。"], ["{angry,?}……行って しまいました。"]));
    /* 冥王の 本音と ユラ */
    if (ok(eM) && NS) { await K.go(eM, by(eM, NS, 2.4), 14); K.turn(eM, NS); }
    K.act(eM, "kneel");
    await K.push(p, eM, 24, 4, 1.8, 1.0);   /* 墓の 前に ひざを つく 冥王 */
    await K.csay(p, "r7_morte", ["{sad}……この 道の 墓の 半分は、石に なった 者たちぞ。", "{closed,up}送る 灯籠も 流されぬ まま、帳にも 載らぬ まま。……わしは、それを 責められぬ。"]);
    if (ok(eY) && ok(eM)) { const q = eM.location; await K.go(eY, { x: q.x + 1, y: q.y, z: q.z + 0.5 }, 12); }
    K.act(eY, "hold");
    await K.csay(p, "r7_yura", ["{smile,tears,up}……冥王さまは、やさしすぎるのです。"]);
    K.turn(eM); K.act(eM, 0); K.act(eY, 0);
    await K.csay(p, "r7_morte", ["{closed}旅の 者よ。あすの 葬列、そなたらに 護衛を 頼みたい。", "{smile,up}支度が できたら、冥王の 城の 中庭へ 来るが よい。待って おるぞ。"], eH);
    await K.hsay(p, K.V(["{smile,nod}うん。セオさんにも、そこで 会えるよね。"], ["{smile,nod}ええ。セオさんにも、きっと 会えるわね。"], ["{closed,nod}……行く。セオにも 会う。"], ["{smile,nod}はい。セオさんにも、そこで お会い できますね。"]));
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    K.pay(p, E3, 500, [["c_herbs", 2], ["mei_necro", 1]]);
    await K.end(p, { leave: [eM, eY, eI], card: "§7→ §e冥王の 城 タナトスの 中庭§7 へ（葬列の 日。右上の 案内）", kind: "ash" });
    return true;
  } };

/* ---------- 5話 つづき 灯籠流しの 夜（ヨミが 石に なった あと。あなたが セオの 分の 灯籠も 流す）---------- */
const E6 = { id: "r7e6", n: 5, t: "灯籠流しの 夜", at: 2, ord: 0, place: RIVER,
  hint: "§fソウラの §e川べり§f へ もどろう §7（もう 一度の 灯籠流し。右上の 案内。そのあと フロストヘイムの 雪山へ）",
  syn: "ヨミが 石に なった 夜、ソウラで もう 一度 灯籠流しが 開かれた。ユラは 霊廟の 奥の 床で、火の 消えた 白い 灯籠を 拾って いた。セオの 弟の 名が 書かれた 灯籠だった。あなたは それを 送らず、赤い 迎え灯籠に 弟の 名を 書きうつし、もう 一つの 赤い 灯籠に セオの 名を 書いて 流した。イザクは 娘 ニナの ために、モルテは 妃の ために、はじめて 赤い 灯籠を 流した。町じゅうに 灯りが もどった。",
  set: { lantern7: 1, met7: 1 },
  skip: (s) => { s.epx = { ...(s.epx || {}), lantern7: 1 }; },
  fx: { xp: [SOURA, 160], fest: SOURA },
  async run(p, d, K) {
    const y0 = Y(K, p), pts = river(K, p, y0), M = mid(pts);
    { const S = K.S(p); if (S && once("mrpg:epdeco:r7river2")) for (const [a, b] of [[6.5, -5], [6.5, 5], [12.5, -3], [12.5, 3]]) post(K, p, S.at(a, b), y0, "lantern"); }
    const CR = facAt("r7crypt", p.location, 60), A0 = (() => { const S = K.S(p); return S ? { ...S.P } : null; })(), FL = facMark("r7crypt", "floor", p.location);
    if (CR && A0 && FL) {   /* 第125版(rs): ―― 夕方。霊廟の 奥で ユラが 灯籠を 見つける → 暗転 → 夜の 川べり */
      await K.moveTo(p, facFront("r7crypt", 3), "ソウラの 霊廟", [], CR, 10);
      await K.past(p, "§7―― その日の 夕方　霊廟の 奥");
      const eY0 = await K.put(p, "r7_yura", FL, CR); K.act(eY0, "work"); K.hold(eY0, "brush");
      await K.at(p, FL, 20, 3.2, 1.2);
      K.act(eY0, "kneel"); K.hold(eY0, "lantern"); K.sound(p, "item.book.page_turn", 0.8);
      await K.push(p, eY0, 26, 3.5, 1.5, 0.8);
      await K.narr(p, ["§7石の 床の すみに、白い 灯籠が 落ちて いた。……ユラは しばらく、それを 胸に 抱いて いた。"], eY0);
      await K.moveTo(p, A0, "ソウラの 川べり", [eY0], M, 12);
    }
    await K.open(p, "ソウラの 川べり（もう 一度の 灯籠流し）", "night");
    K.sound(p, "note.bell", 1, 0.4);
    const eH = K.hero(p);
    K.act(eH, "sad");
    await K.hsay(p, K.V(["{sad,…}…………。", "{closed}ヨミさんの 手、さいごまで あったかかった。"], ["{sad,…}…………。", "{closed}ヨミさんの 手、最後まで あたたかかったわ。"], ["{closed,…}……。", "{closed}ヨミの 手、あたたかかった。"], ["{sad,…}…………。", "{closed}ヨミさんの お手、最後まで あたたかかった。"]));
    K.act(eH, 0);
    const eY = K.cast(p, "r7_yura"); K.act(eY, "show"); K.hold(eY, "lantern");
    await K.csay(p, "r7_yura", ["{sad}……ヨミさまが 石に なったと 聞いて、町の みんなが『もう 一度 流そう』って 決めたのです。"], eH);
    await K.csay(p, "r7_yura", ["{sad}……霊廟の 奥を おそうじ してたら、石の 床に これが 落ちてたのです。"], eH);
    await K.up(p, eY, 12);
    await K.narr(p, ["§7火の 消えた、白い 灯籠。小さな 字で、名前が 一つ。", "§7すみが にじんで いる。何度も、指で なぞった あとが ある。"], eY);
    await K.give(eY, eH, "lantern");
    await K.hsay(p, K.V(["{sad,tears,up}……セオさんの、弟さんの 灯籠……。", "{cry,up}ずっと、持ってたんだ。あの 人、ずっと……"], ["{sad,tears,up}……セオさんの、弟さんの 灯籠。", "{cry,up}ずっと 持って いたのね。……ずっと。"], ["{sad,…,up}……セオの、弟の 灯籠。", "{closed,up}……ずっと、持ってたのか。"], ["{sad,tears,up}……セオさんの、弟さんの 灯籠……。", "{cry,up}ずっと、お持ちに なって いたのですね……"]));
    /* ピピ */
    const eP = K.cast(p, "r7_pipi");
    { const q = nearPt(eP, eH, 1); if (q) await K.go(eP, q, 8); }   /* かけよって 問いつめる */
    await K.csay(p, "r7_pipi", ["{cry,tears,up}……ねえ。セオは、わるい 人 なのだ？", "{cry}六影の、えらい 人だった のだ？ ……ピピに 本を 読んで くれたのも、うそ だった のだ？"], eH);
    await K.hsay(p, K.V(["{sad,up}……わからない。", "{closed,up}でも、さいごに『ごめん』って 言った。わたしの 目を、見られないで。"], ["{sad,up}……わからないわ。", "{closed,up}でも 最後に『ごめん』って。わたしの 目を、見られないで。"], ["{closed,up}……わからない。", "{closed,up}でも、『ごめん』と 言った。目を そらして。"], ["{sad,up}……わかりません。", "{closed,up}でも 最後に『ごめん』と。わたしの 目を、見られずに。"]));
    K.act(eP, "sad");
    await K.csay(p, "r7_pipi", ["{cry,no}……うそつきは、ごめんって 言わない のだ。……ピピ、知ってる のだ。"]);
    /* モルテ */
    const eM = K.cast(p, "r7_morte"); K.act(eM, "hold"); K.hold(eM, "staff");
    if (ok(eM) && M) { await K.walkCam(p, eM, by(eM, M, 2.2), 18); K.turn(eM, M); }   /* 冥王は 水ぎわに 立ち、背を 向けた まま */
    await K.csay(p, "r7_morte", ["{closed,low}……送るか、迎えるか。", "{closed,up}決めるのは、のこされた 者で あろう。"], eH);
    K.turn(eM); K.act(eM, 0);
    /* あなたが 決める */
    K.act(eH, "hold"); K.hold(eH, "chochin");
    await K.push(p, eH, 24, 4.5, 1.7);
    await K.hsay(p, K.V(["{closed,up}……送らない。", "{angry,tears,up}セオさんが 流せなかった 分、わたしが 流す。でも 白じゃ ない。赤い 迎え灯籠に、弟さんの 名前を 書きうつす。"], ["{closed,up}……送らないわ。", "{sad,tears,up}セオさんが 流せなかった 分は、わたしが 流す。でも 白じゃ なくて、赤い 迎え灯籠に 書きうつすの。"], ["{closed,up}……送らない。", "{angry,up}セオが 流せなかった 分は、わたしが 流す。赤に 書きうつして。"], ["{closed,up}……お送り しません。", "{sad,tears,up}セオさんが 流せなかった 分は、わたしが 流します。でも 白ではなく、赤い 迎え灯籠に 書きうつして。"]));
    await K.hsay(p, K.V(["{smile,tears,up}それと……もう 一つ。セオさんの 分。", "{closed,up}帰り道を、見失わない ように。……ぜったい 止めて、ぜったい 連れて 帰る。決めたんだ。"], ["{smile,tears,up}それから、もう 一つ。セオさんの 分よ。", "{closed,up}帰り道を 見失わない ように。……止めて、連れて 帰るって 決めたの。"], ["{closed,up}もう 一つ。セオの 分。", "{angry,up}帰り道は 残しておく。止めて、連れて 帰る。決めた。"], ["{smile,tears,up}それと、もう 一つ。セオさんの 分です。", "{closed,up}帰り道を 見失われない ように。……お止めして、連れて 帰ります。決めました。"]));
    K.act(eH, 0);
    await K.csay(p, "r7_yura", ["{smile,tears,up}……ヨミさまの 分は、わたしが 流すのです。赤い ほうで、なのです。"]);
    /* イザクも 決める */
    const eI = K.cast(p, "r7_isak"); K.act(eI, "hold"); K.hold(eI, "chochin");
    await K.csay(p, "r7_isak", ["{closed,up}……あっしも、決めたでやんす。", "{smile,tears,up}ニナの 灯籠は、赤でやんす。……迎えに 行くでやんすよ、ニナ。"], eH);
    await K.csay(p, "r7_morte", ["{sad,up}…………わしも、赤に しよう。十年 ぶんの、迎え灯籠ぞ。"]);
    /* レイが 来る */
    const eR = K.npcNear(p, "§bレイ", 17); K.act(eR, "hold"); K.hold(eR, "chochin");
    await K.say(p, "レイ", ["{closed}……オレの 分も、一つ いいか。", "{sad,up}あいつを 止める。……でも、帰り道は 残しとく。"], eH);
    K.act(eR, 0);
    /* 相棒が 鼻で 灯籠を 水へ */
    const g = K.palEnt(p);
    if (g && M) { await K.go(g, { x: M.x, y: y0, z: M.z }, 14); K.burst(p.dimension, g.location, "minecraft:heart_particle", 3, 0.4, 0.8); await K.up(p, g, 12); }
    K.sound(p, "note.chime", 0.8);
    if (pts) { float(K, p, pts, true, 5); await K.at(p, M, 24, 5, 0.6); }
    await K.narr(p, ["§7相棒が 鼻先で、赤い 灯籠を そっと 水へ 押しだした。", "§7赤い 火が 一つ、二つ……五つ。青い 火の あいだを、ならんで 流れて いく。"], M);
    K.rmCine(g); for (const e of [eH, eI, eR]) K.hold(e);
    /* 町の 灯りが もどる */
    K.ambient(p, "fest", { x: p.location.x, y: y0, z: p.location.z }); K.sound(p, "note.pling", 0.6);
    if (pts) float(K, p, pts, true, 4);
    await K.pull(p, M || eH, 34);   /* ゆっくり 引いて 川べり 全体と 町の 灯り */
    await K.narr(p, ["§7それを 見た 町の 人たちが、一人、また 一人と 赤い 灯籠を 持って 川べりへ 来た。", "§7消えて いた 町の 灯りが、一つ ずつ ともって いく。"]);
    await K.csay(p, "r7_morte", ["{smile,up}……迎え灯籠が こんなに 流れたのは、冥府 始まって 以来ぞ。"]);
    await K.csay(p, "r7_pipi", ["{smile,tears,up}セオにも、見えてる のだ。……ぜったい、見えてる のだ。"]);
    K.act(eY, "hold"); K.hold(eY, "torch");
    await K.csay(p, "r7_yura", ["{smile}これ、ソウラの 月夜の ろうそく なのです。旅の 夜道に、持って いって ほしいのです。"], eH);
    await K.give(eY, eH, "torch");
    if (!ok(p)) return false;   /* 抜けた: ほうびは わたさず、入りなおしたら もう一度 */

    const got = K.pay(p, E6, 800, [["mei_necro", 2], ["gift_candle", 1]]);
    if (got.length) K.big(p, "§5§l月夜の ろうそく", `§e${got.join("・")}`);
    K.act(eY, 0);
    await K.say(p, "レイ", ["{closed}……先に 雪山の 様子を 見て くる。かけらの 残りも、氷の 割れ目に 捨てて くる。", "{smile,up}……隠れ家の 前で 待ってる。今度は、一緒に 入るぞ。"], eH);
    await K.hsay(p, K.V(["{smile,tears,up}……うん。いって らっしゃい、レイ。"], ["{smile,tears,up}……ええ。いって らっしゃい。"], ["{smile,up}……ああ。あとで。"], ["{smile,tears,up}……はい。いって らっしゃいませ。"]));
    await K.end(p, { leave: [eR, eM, eI], bye: [eY, eP], card: "§f― 第8章 冥府の 霊廟 おわり ―\n§7→ 次は §9フロストヘイム雪山§7 へ（右上の 案内）", kind: "night", t: 60 });
    return true;
  } };

epAdd(7, [E1, E2, E3, E6], { steps: { 0: [4, "霊廟の 奥"], 1: [5, "ヨミ"] } });
