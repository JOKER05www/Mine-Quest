// 第124版: スキンシップブック。ガイドブックを 開かずに 遊び場・相棒と ふれあう・きずな・キャンプを えらぶ
import { world, system } from "@minecraft/server";
import { load } from "./store.js";
import { busy, choose, ICON, giveItem, BAG_KEEP, EXH, notice } from "./ui.js";
import { findPet } from "./field.js";
import { inBattle } from "./battle.js";

const ID = "mrpg:skinbook", TAG = "mrpg_skinbook";
BAG_KEEP.add("skinbook");   /* 手に 持って 使う ので 持ち物に のこす */
const B = (t, i) => [t, ICON(i)];
const H = globalThis.__mqSkin = globalThis.__mqSkin || {};   /* ほかの ファイルが 入れる: H.touch(p, e)・H.bond(p, d)・H.camp(p) */
export async function skinUse(p) {
  if (busy.has(p.id)) return;
  let ib = false; try { ib = inBattle(p); } catch {} if (ib) { try { p.sendMessage("§7戦いの あいだは 使えない。"); } catch {} return; }
  if (globalThis.__mqScene?.has(p.id)) { try { p.sendMessage("§7物語の 場面の あいだは 使えない。"); } catch {} return; }
  const d = load(p); if (!d || !d.party || !d.party.length) { try { p.sendMessage("§7先に 最初の 仲間を えらぼう。"); } catch {} return; }
  busy.add(p.id); let k = -1;
  try { k = await choose(p, "§dスキンシップブック", "§7相棒との 時間を すごそう", [B("§d§l遊び場へ 行く\n§8浮島で 相棒と 遊ぶ", "i_run"), B("§d§l相棒と ふれあう\n§8なでる・抱っこ・高い高い", "i_party"), B("§d§lきずな\n§8なつき度・思い出", "i_party"), B("§6§lキャンプ\n§8テントを はって ひと休み", "i_inn"), B("§7閉じる", "i_close")]); }
  finally { busy.delete(p.id); }
  try {
    if (k === 0) { if (EXH.isle) { busy.add(p.id); try { await EXH.isle(p); } finally { busy.delete(p.id); } } }
    else if (k === 1) { const e = findPet(p); if (!e) await notice(p, "相棒と ふれあう", "§7連れ歩いて いる 仲間が いない。§fガイドブック → 仲間 で 連れ歩きを えらぼう。"); else if (H.touch) await H.touch(p, e); }
    else if (k === 2) { if (H.bond) { busy.add(p.id); try { await H.bond(p, load(p)); } finally { busy.delete(p.id); } } }
    else if (k === 3) { if (H.camp) await H.camp(p); }
  } catch (e) { console.warn(`[MonsterRPG] skinbook: ${e}`); }
}
/* 最初の 仲間が いる 人に 1回 わたす（死んだ あとは keepitems.js が もどす）*/
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try { if (p.hasTag(TAG) || busy.has(p.id)) continue; const d = load(p); if (!d || !d.party || !d.party.length) continue; p.addTag(TAG); giveItem(p, ID, 1); p.sendMessage("§d§lスキンシップブック§r§d を もらった！ §f使うと 遊び場・相棒と ふれあう・きずな・キャンプを すぐ えらべる。"); } catch {}
  }
}, 220);
