// 第125版: 物語の ダンジョンの 中の しかけ（宝箱・踏み板の 隠し戸・中に すむ モンスター）
// 宝箱: 1人 1回（マルチでも 自分の ぶん）。中身は boon（物語の 進み rankCap・storyLootOk で しばる）＋ お金。隠し部屋の 箱は 多め
// モンスター: 中に 人が いる ときだけ。部屋の 点から 1体ずつ（1つの ダンジョンに 6体まで・重いと へらす）。人が 出ると 消える
// 軽く: 10tick ごとに プレイヤーだけ 見る。ダンジョンの 記録は 100tick ごとに 読みなおす
import { world, system } from "@minecraft/server";
import { caveInfo, DG_ALL, DG_X } from "./structures.js";
import { WREGIONS, regionLv } from "./worldmap.js";
import { dgType } from "./dglayout.js";
import { TYPE, initWild, pickWild, setLook, setSpeed, hooks } from "./field.js";
import { SPECIES } from "./data.js";
import { load, save } from "./store.js";
import { busy, heavy, isLite, sound, rankOf, gold } from "./ui.js";
import { boon } from "./boon.js";
import { qs } from "./quest.js";
import { bkDone } from "./cast.js";

const OW = () => world.getDimension("minecraft:overworld");
const OPK = "mrpg:dgo";   /* プレイヤーごとの 開けた 宝箱（"地方.番号"）*/
export const DGW = { cap: 6, gap: 60 };   /* 1つの ダンジョンの モンスターの 上限・出る 間（tick）*/
let CACHE = [], cT = -999; const CH = new Map();
export function dgs(force = false) {
  const now = system.currentTick;
  if (force || now - cT > 100) { cT = now; CACHE = []; CH.clear();
    for (const i of DG_ALL) { let v = null; try { v = caveInfo(i); } catch {} if (!v || !v.built || !v.dt || !v.box) continue; CACHE.push({ i, v, t: dgType(v.dt) }); (v.ch || []).forEach((c, k) => CH.set(`${c[0]}|${c[1]}|${c[2]}`, { i, k, rare: !!c[3] })); } }
  return CACHE;
}
const inBox = (b, l, m = 0) => l.x >= b.x1 - m && l.x <= b.x2 + m && l.z >= b.z1 - m && l.z <= b.z2 + m && l.y >= b.y1 - m && l.y <= b.y2 + m;
export function dgAt(l) { for (const D of dgs()) if (inBox(D.v.box, l)) return D; return null; }
/* ---------- 宝箱 ---------- */
function opened(p) { try { const v = JSON.parse(p.getDynamicProperty(OPK) || "[]"); return Array.isArray(v) ? v : []; } catch { return []; } }
export function dgOpened(p, i, k) { return opened(p).includes(`${i}.${k}`); }
export function openDgChest(p, i, k, rare) {
  const key = `${i}.${k}`, L = opened(p);
  if (L.includes(key)) { try { p.sendMessage("§7この 宝箱は もう 開けた §8（中身は 1人 1回。ほかの 宝箱を さがそう）"); } catch {} sound(p, "random.chestclosed", 1, 0.5); return false; }
  const d = load(p); if (!d) return false;
  L.push(key); try { p.setDynamicProperty(OPK, JSON.stringify(L.slice(-200))); } catch { return false; }
  const got = []; for (let n = 0; n < (rare ? 2 : 1); n++) { try { got.push(boon(p, d, rare ? 2 : 1)); } catch {} }
  const v = caveInfo(i), lv = (() => { try { return regionLv({ x: v.x, z: v.z }); } catch { return 10; } })(), g = Math.max(100, Math.round(lv * (rare ? 120 : 40)));
  d.gold = (d.gold || 0) + g; save(p, d);
  sound(p, rare ? "random.levelup" : "random.chestopen", 1, 0.8);
  try { p.sendMessage(`${rare ? "§6§l隠し部屋の 宝箱！ " : "§e宝箱を 開けた！ "}§r${got.join("§7、")}§7、${gold(g)}`); } catch {}
  return { got, g };
}
/* ---------- 踏み板（仕掛けの 間）---------- */
const HINT = new Set();
export function dgPlateTick() {
  const ow = OW();
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue; const l = p.location, D = dgAt(l); if (!D || !D.v.plate || !D.v.gate) continue;
    const [px, py, pz] = D.v.plate, gx = D.v.gate; let shut = false;
    try { const b = ow.getBlock({ x: gx[0], y: gx[1] + 1, z: gx[2] + 1 }); shut = !!(b && !b.isAir); } catch { continue; }
    if (!shut) continue;
    const dx = l.x - (px + 0.5), dz = l.z - (pz + 0.5), dh = Math.hypot(dx, dz);
    if (dh < 0.8 && Math.abs(l.y - py) < 1.2) {
      try { ow.runCommand(`fill ${gx[0]} ${gx[1]} ${gx[2]} ${gx[3]} ${gx[4]} ${gx[5]} air`); } catch {}
      for (const q of world.getAllPlayers()) if (dgAt(q.location) === D) { sound(q, "random.door_open", 0.6, 1); try { q.sendMessage(`§e${D.t.gim}が 沈んだ…… §f右の 壁が ゴゴゴと 開いた！ §7（隠し部屋）`); } catch {} }
    } else if (dh < 6 && Math.abs(l.y - py) < 3 && !HINT.has(`${p.id}.${D.i}`)) { HINT.add(`${p.id}.${D.i}`); try { p.sendMessage(`§7床の 模様の まん中に ${D.t.gim}が ある…… 右の 壁の 色が 少し ちがう`); } catch {} }
  }
}
/* ---------- モンスター ---------- */
const NEXT = new Map(), BOSS = new Map();
const capNow = () => Math.max(1, (isLite() ? 3 : [DGW.cap, 4, 2][heavy()] ?? 2) - (world.getAllPlayers().length >= 3 ? 1 : 0));
export function dgCount(i) { try { return OW().getEntities({ type: TYPE, tags: [`mrpg_dg${i}`] }).length; } catch { return 0; } }
function dress(e, i, t, lv, boss) {
  e.addTag("mrpg_dg"); e.addTag(`mrpg_dg${i}`);
  try { initWild(e); } catch {}
  const special = e.hasTag("mrpg_rare") || e.hasTag("mrpg_shiny");
  if (!special || boss) {
    const sid = pickWild(t.wb, lv, WREGIONS[i]); if (!SPECIES[sid]) return;
    try { setLook(e, sid); setSpeed(e, sid, 0.8); } catch {}
    try { e.setDynamicProperty("mrpg:lv", lv); if (boss) { e.addTag("mrpg_rare"); e.addTag("mrpg_dgboss"); e.setDynamicProperty("mrpg:q", 0.5); } } catch {}
    try { if (!isLite() || boss) e.nameTag = `${boss ? "§6奥の 主 " : "§f"}${SPECIES[sid].name} §7Lv${lv} ${rankOf(sid)}`; } catch {}
  } else { try { const l0 = e.getDynamicProperty("mrpg:lv"); if (typeof l0 === "number" && l0 < lv) e.setDynamicProperty("mrpg:lv", lv); } catch {} }
}
export function dgSpawnTick() {
  const ow = OW(), now = system.currentTick, all = world.getAllPlayers();
  for (const D of dgs()) {
    const P = all.filter((p) => p.dimension.id === "minecraft:overworld" && inBox(D.v.box, p.location) && !busy.has(p.id)); if (!P.length) continue;
    if (now < (NEXT.get(D.i) || 0)) continue;
    const lv0 = (() => { try { return regionLv({ x: D.v.x, z: D.v.z }); } catch { return 10; } })();
    /* 物語の 外の ダンジョンは 奥の 大広間に 主（1人が 入ると 1体・10分に 1回）
       第126版(S6): 物語の ダンジョンも、中に いる 全員が その 章の 場面（dglayout の sc）を 済ませた あとは 主が 出る（場面の じゃまを しない）*/
    if ((DG_X.includes(D.i) || D.t.sc) && D.v.hall && !(BOSS.get(D.i) > now) && P.some((p) => Math.hypot(p.location.x - D.v.hall.x, p.location.z - D.v.hall.z) < 10 && Math.abs(p.location.y - D.v.hall.y) < 4) && (DG_X.includes(D.i) || P.every((p) => { try { return bkDone(qs(load(p)), D.t.sc); } catch { return false; } }))) {
      BOSS.set(D.i, now + 12000); const a = D.v.altar || D.v.hall;
      try { const e = ow.spawnEntity(TYPE, { x: a.x, y: D.v.hall.y, z: a.z }); dress(e, D.i, D.t, Math.min(100, lv0 + 10), true); for (const p of P) { sound(p, "mob.wither.ambient", 1.4, 0.5); p.sendMessage(`§6${D.t.nm}の 奥の 主が 目を さました！`); } } catch {}
      continue;
    }
    if (dgCount(D.i) >= capNow()) continue;
    const pts = (D.v.sp || []).filter((q) => P.every((p) => Math.hypot(p.location.x - q[0] - 0.5, p.location.z - q[2] - 0.5) >= 9) && P.some((p) => Math.hypot(p.location.x - q[0], p.location.z - q[2]) <= 44));
    if (!pts.length) continue;
    const q = pts[Math.floor(Math.random() * pts.length)];
    NEXT.set(D.i, now + DGW.gap);
    try { const e = ow.spawnEntity(TYPE, { x: q[0] + 0.5, y: q[1], z: q[2] + 0.5 }); dress(e, D.i, D.t, Math.min(100, lv0 + 5), false); } catch {}
  }
}
export function dgDespawnTick() {
  let L = []; try { L = OW().getEntities({ type: TYPE, tags: ["mrpg_dg"] }); } catch { return 0; }
  const all = world.getAllPlayers(); let n = 0;
  for (const e of L) {
    try {
      if (e.hasTag("mrpg_battle") || e.hasTag("mrpg_pet")) continue;
      const i = DG_ALL.find((k) => e.hasTag(`mrpg_dg${k}`)), D = CACHE.find((c) => c.i === i);
      if (D && all.some((p) => p.dimension.id === "minecraft:overworld" && inBox(D.v.box, p.location, 16))) continue;
      e.remove(); n++;
    } catch {}
  }
  return n;
}
let tk = 0;
system.runInterval(() => {
  tk++;
  try { if (!dgs().length) return; dgPlateTick(); if (tk % (isLite() ? 8 : 4) === 0) dgSpawnTick(); if (tk % 10 === 0) dgDespawnTick(); } catch {}
}, 10);
/* 宝箱を 開ける・こわさせない（ふつうの 宝箱の しくみは 通らない）*/
try {
  world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
    try { if (ev.isFirstEvent === false) return; const b = ev.block; if (!b) return; const c = CH.get(`${b.location.x}|${b.location.y}|${b.location.z}`); if (!c || b.dimension.id !== "minecraft:overworld") return;
      ev.cancel = true; const p = ev.player; system.run(() => { try { openDgChest(p, c.i, c.k, c.rare); } catch {} }); } catch {}
  });
  world.beforeEvents.playerBreakBlock.subscribe((ev) => { try { const b = ev.block; if (b && CH.has(`${b.location.x}|${b.location.y}|${b.location.z}`) && b.dimension.id === "minecraft:overworld") ev.cancel = true; } catch {} });
} catch {}
/* ダンジョンの 中では ふつうの 野生・道ばたの 宝箱を 出さない（数を この ファイルで 決める）*/
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => { try { if (p.dimension.id === "minecraft:overworld" && dgAt(p.location)) return true; } catch {} return prev ? prev(p) : false; }; });
export const __dg = { CH, CACHE: () => CACHE, NEXT, BOSS };
