/* 第126版 裏10「鏡と 馬場」（常世・下の 区）— 幼なじみの 魂 — 作業 UB
   区2（八冠 テルグ・鏡）: 1話 前 → 2話 向かい合う → 後: 勝った 一拍（鏡の 家族が 一度だけ 手を 振る）
   区3（七冠 サイオウバ・馬場）: 3〜6話 前 → 7話 向かい合う → 後: 勝った 一拍（くじの 子が 着地）→ 8話 → 9話（野営地の 夜）*/
import { K } from "./bkeng.js";
import { U } from "./bk_u08.js";
import { act, hold, fx, fade, PJ } from "./stage2.js";
import { facAdd, facMark } from "./epfac.js";
const { F, S1, ok } = U;

facAdd("u10mirror", { D: [10, 12, 14], box: [0, -4, 4, 4], H: 4, look: [2, 0, 1.2], marks: { mirror: [3.4, 0, 1.6], table: [1.5, 0, 1], crest: [3.4, 3, 2.6] },
  build: () => [F(4, -4, 0, 4, 4, 3, "spruce_planks"), F(3, -3, 0, 3, 3, 2, "glass"), F(1, -1, 0, 2, 1, 0, "oak_fence"), F(1, -1, 1, 2, 1, 1, "oak_slab"), S1(3, 3, 0, "furnace"), S1(3, -4, 0, "barrel"), S1(3, 3, 2, "hay_block"), S1(3, -3, 3, "lantern")] });
facAdd("u10fest", { D: [11, 13, 15], box: [0, -6, 8, 6], H: 4, look: [4, 0, 1.2], marks: { booth: [1, -5, 1.2], track: [5, 0, 0.5], lamp: [8, 4, 2.5] },
  build: () => [F(2, -6, 0, 8, -6, 0, "oak_fence"), F(2, 6, 0, 8, 6, 0, "oak_fence"), F(8, -6, 0, 8, 6, 0, "oak_fence"), F(1, -6, 0, 1, -4, 1, "oak_fence"), F(1, -6, 2, 1, -4, 2, "red_wool"), S1(1, -5, 0, "barrel"),
    S1(8, -6, 1, "lantern"), S1(8, 6, 1, "lantern"), S1(8, 0, 1, "lantern"), F(4, -1, 0, 6, 1, 0, "hay_block")] });

const SOULV = (g, o, c, t) => ({ g, o, c, t });

/* ---- 区2: テルグ（鏡）---- */
const fight2 = U.fight(2, async (p, C) => {
  await K.open(p, "常世 ― 鏡の 区");
  const m = K.fac(p, "u10mirror", "u10mirror", 99, U.y0(p));
  const mu = U.mu(C); await K.up(p, mu, 8);
  const e = U.boss(p, C, 2, 11, -1); await U.bossIn(p, e, 2);
  await U.say(p, "テルグ", ["{closed,…}……映せ、映せ。", "{smile,up}この 区の 鏡には、石に なる 前の 家族が 映って いる。わたしが 映し続けて いる"], mu);
  await U.M(p, mu, ["{?}……映し続けて、どうする"], "hold", p);
  await U.say(p, "テルグ", ["{closed}……どうも しない。映って いれば、なくならない"], mu);
  await U.M(p, mu, ["{sad,…}……鏡ん中の 家族、まだ 飯の 途中だ。……皿の 音が 一つも しねえ 食卓だ。"], "hold");
  await U.say(p, "テルグ", ["{angry,!,low,roar}音など いらぬ。……おまえの 技も、そのまま 返して やろう"]);
  await U.M(p, mu, ["{angry}……返すなら 返せ。俺の 槌の 音も、返して みろ"], "guard", p);
  await U.E(p, mu, ["……鏡は 音を 映さぬ。小僧、音で 打て"]);
}, async (p, C) => {
  K.fac(p, "u10mirror", "u10mirror", 99, U.y0(p)); const mi = facMark("u10mirror", "mirror", p.location);
  const e = U.boss(p, C, 2, 7, -1); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "テルグ", ["{closed,…}……鏡が、割れる。映して いた 家族も、もう"]);
  const fam = [C.npc("", PJ("m6_father", 8), 5, 1, 0, "veil"), C.npc("", PJ("rosa", 8), 5.4, 2.2, 0, "veil")];
  for (const f of fam) act(f, "wave");
  if (mi) await K.at(p, mi, 18, 3.2, 0.4);
  await U.narr(p, ["§7鏡の 中の 家族が、こちらに §f一度だけ§7 手を 振った。", "§8そして 鏡は、空っぽに なった。"]);
  K.sound(p, "random.glass", 0.6);
  const mu = U.mu(C); await K.up(p, mu, 8);
  await U.M(p, mu, ["{sad,…}……手、振ったな"], "hold");
  await U.E(p, mu, ["……一度だけ、だ"]);
  await U.M(p, mu, ["{closed}……一度で 十分だ。さよならは、一回 鳴りゃ 届く"], "hold");
  for (const f of fam) if (ok(f)) await fade(f, "minecraft:endrod");
  if (ok(e)) await fade(e, "minecraft:endrod");
});
/* ---- 区3: サイオウバ（馬場）---- */
const fight3 = U.fight(3, async (p, C) => {
  await K.open(p, "常世 ― 馬場の 奥", "fest", "dusk");
  K.fac(p, "u10fest", "u10fest", 99, U.y0(p));
  const mu = U.mu(C); await K.up(p, mu, 8);
  const e = U.boss(p, C, 3, 11, 0); await U.bossIn(p, e, 3);
  await U.say(p, "サイオウバ", ["{smile}禍福は あざなえる 縄の ごとし。……知って いるかね", "{smile,?,up}道化が 大当たりを 引いた 日、この 区は 石に なった。福の あとには、禍が 来る"], mu);
  await U.M(p, mu, ["{angry,怒}……福だの 禍だの、決めてんのは てめえだろうが。", "{closed}あいつは 祭りの 中から 出られねえ。……どけ。"], "guard");
  await U.say(p, "サイオウバ", ["{angry,low}さあ、おまえの 運を 裏返して やろう"]);
  await U.E(p, mu, ["……小僧。くじの 目は 見るな。刃だけ 見よ"]);
  await U.M(p, mu, ["{closed}……見ねえよ。字が 読めねえからな"], "guard");
}, async (p, C) => {
  K.fac(p, "u10fest", "u10fest", 99, U.y0(p)); const tr = facMark("u10fest", "track", p.location);
  const e = U.boss(p, C, 3, 7, 0); if (ok(e)) await K.at(p, U.top(e), 12, 6, 0);
  await U.say(p, "サイオウバ", ["{closed,up}……禍の あとには、福が 来る。……そう だろう？"]);
  const kid = C.npc("", PJ("m6_pip", 8), 5, -1.5, 0, "veil"); act(kid, "up");
  if (ok(kid)) { await K.low(p, kid, 12); K.sound(p, "random.pop", 0.8); await K.wait(6); act(kid, "cheer"); }
  await U.narr(p, ["§7くじの 大当たりを 引いた 子の 石が、やっと §f着地§7 した。", "§8そして、笑って 消えた。"], kid || tr);
  if (ok(kid)) await fade(kid, "minecraft:totem_particle");
  const mu = U.mu(C); await K.up(p, mu, 8);
  await U.M(p, mu, ["{closed}……今、着いた 音が した。", "{smile}……ずいぶん 久しぶりに、地面が 鳴った。"], "hold");
  await U.E(p, mu, ["……着地は、終わりの 音だ"]);
  await U.M(p, mu, ["{sad,…}……終われて、よかったな"], "hold");
  if (ok(e)) await fade(e, "minecraft:totem_particle");
});

U.reg("u10", [
  { id: "u10e1", t: "鏡の 食卓", free: false, F: ["F55"],
    syn: "鏡の 区の 鏡の 中で、家族が まだ 食事を して いた。食卓の 上の 麦の 紋は、ルミナの パン屋 グスタフの 看板と 同じ。ここの 人は、今の 町の 人の 先祖だった。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 鏡の 区");
        const m = K.fac(p, "u10mirror", "u10mirror", 99, U.y0(p)), mi = facMark("u10mirror", "mirror", p.location) || m, cr = facMark("u10mirror", "crest", p.location) || m;
        if (mi) await K.push(p, mi, 24, 8, 3, 0.4);
        const fam = [C.npc("", PJ("m6_father", 8), 5, 1, 0, "veil"), C.npc("", PJ("rosa", 8), 5.4, 2.2, 0, "veil"), C.npc("", PJ("m6_pip", 8), 5.2, -0.2, 0, "veil")];
        for (const f of fam) act(f, "talk"); hold(fam[0], "basket");
        await U.narr(p, ["§7壁の 大きな 鏡の 中で、家族が 食卓を 囲んで いた。§8パンを ちぎる 手。笑う 口。……音は 一つも ない。"], fam[1]);
        /*F55 回: 鏡の 家族の 麦の 紋 = ルミナの パン屋の 看板 */
        if (cr) await K.at(p, cr, 14, 2.6, 0.2);
        await U.narr(p, ["§f食卓の 奥の 壁に、§e麦の 紋§f。§7……人形の 区の 門と、ルミナの パン屋の 看板と、同じ 形。"]);
        const mu = U.mu(C); await K.up(p, mu, 8);
        if (ok(mu) && mi) await K.approach(p, mu, mi, 1.4, 12);
        await U.tap(p, mu);
        await U.M(p, mu, ["{closed}……鏡を 叩いても、中の 家族は 鳴らねえ。", "{sad,…}……あれは、書かれた 家族だ。"], "hold");
        const st = await U.rec(p, C, 2, ["§7『パン屋 グスタフ。食卓の 上の パンまで 石に なった。家族の 一人だけ、扉へ 手を 伸ばして いる』", "§7『逃げろと 叫んだ。誰も 動かなかった』"], "m6_father", "hold");
        await U.E(p, mu, ["……パン屋 グスタフ、と ある。……ルミナの パン屋の 主も、同じ 名だ"]);
        await U.M(p, mu, ["{shock,…,up}……じいさんの じいさんの、もっと 前の グスタフか。", "{closed}……店の 看板の 紋だけ、ずっと 残ったのか。"], "up");
        await U.E(p, mu, ["……あの パンの 白さを 見たか。われの 世にも、あれほど 細かい 粉を 挽く 技は なかった"]);
        await U.M(p, mu, ["{closed}……答えは、まだ 鳴らねえ。……先に 進む。"], "hold");
        await U.lesson(p, C, 2, mu);
        await U.end(p, C, { card: "§7→ 鏡の 奥で、何かが こちらを 映した" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u10e2", t: "映し続ける 者", free: false, run: fight2, syn: "八冠テルグとの 戦い。鏡が 割れる とき、鏡の 中の 家族が 一度だけ 手を 振った。" },
  { id: "u10e3", t: "大当たりの 祭り", free: false,
    syn: "馬場の 区は、道化 ポポの 大当たりの 祭りの 一日を くり返して いた。空から くじが 降って くる。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 馬場の 区", "fest", "dusk");
        const f = K.fac(p, "u10fest", "u10fest", 99, U.y0(p)), bo = facMark("u10fest", "booth", p.location) || f;
        await K.wide(p, 16);
        for (let k = 0; k < 10; k++) { try { p.dimension.spawnParticle("minecraft:villager_happy", { x: p.location.x + (k - 5), y: p.location.y + 5 - (k % 3), z: p.location.z + 3 }); } catch {} }
        K.sound(p, "firework.blast", 0.5);
        await U.narr(p, ["§7祭りの 灯りの 下、空から §eくじ§7 が ひらひらと 降って きた。§8……同じ 夕暮れ、同じ 歓声、同じ くじ。"], bo);
        const mu = U.mu(C); await K.up(p, mu, 8);
        act(mu, "raise"); await U.narr(p, ["§7ムサシの 顔に、くじが 一枚 はりついた。"], mu);
        await U.M(p, mu, ["{shock,汗}……ぶっ。なんだ これ。", "{?}エンマ、読め。……当たりか？"], "hold");
        await U.E(p, mu, ["……読まずとも わかる。おまえの 顔に 当たった"]);
        await U.M(p, mu, ["{angry,怒}そういう 当たりじゃ ねえ！"], "arms");
        await U.E(p, mu, ["……『大当たり』と ある"]);
        await U.M(p, mu, ["{shock,!,jump}……マジか！", "{sad,…}……いや 待て。この 区の 大当たりは、縁起が 悪いんじゃ なかったか。"], "up");
        await U.rec(p, C, 3, ["§7『道化 ポポ。最後の 公演。くじ引きで 大当たりを 引いた 子が、跳び上がった 形の まま 止まった』"], "m6_paolo", "up");
        await U.M(p, mu, ["{closed}……跳んだ まま 止まった 子か。着く 音が、ずっと 鳴ってねえ。"], "hold");
        await U.lesson(p, C, 3, mu);
        await U.end(p, C, { card: "§7→ 祭りの 奥へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u10e4", t: "針の 向き", free: false, F: ["F48"],
    syn: "区の 境で、あなたの 首の コンパスの 針が、回るのを やめて まっすぐ 馬場の 奥を 指した。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 馬場の 区の 境", "fest", "dusk");
        K.fac(p, "u10fest", "u10fest", 99, U.y0(p));
        const mu = U.mu(C); await K.up(p, mu, 8);
        /*F48 回: 回りつづけた 針が まっすぐ 指す */
        K.sound(p, "block.lodestone.lock", 0.8);
        await U.narr(p, ["§7首から 下げた §eコンパス§7 が、かちり と 鳴った。", "§f……あの日から 回りっぱなしだった 針が、止まった。§7まっすぐ、馬場の 奥を 指して いる。"]);
        await K.ots(p, mu, p, 10);
        await U.M(p, mu, ["{shock,!}……お前の 首の それ、止まったぞ。", "{closed}回る 音が 消えた。……一本の 音に なった。"], "point");
        await U.E(p, mu, ["……迷いの ない 針だ"]);
        await U.E(p, mu, ["……指す 方へ 行け。それを 組んだ 者の 手の 跡が、そう 言って おる"]);
        await U.M(p, mu, ["{?}……組んだ 者？ 誰が 作ったんだ、それ"], "hold", p);
        await U.narr(p, ["§7首の コンパスを 握った。§8……針は、ぶれない。"]);
        await U.M(p, mu, ["{closed}……答えたくねえ 顔だな。……いい。大事な 物の 話は、あとで 聞く"], "hold", p);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……行きたい 場所の 方を、ちゃんと 指すんだったな。それ。", "{smile}行くぞ。"], "raise");
        await U.E(p, mu, ["……祭りの 灯りだ。気を つけよ。福の 顔を した 灯りは、たちが 悪い"]);
        await U.M(p, mu, ["{closed}……一つ、二つ、三つ。", "{closed}……よし。灯りの 方へ"], "raise");
        await U.end(p, C, { card: "§7→ 針の 先、祭りの 灯りの 下へ" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u10e5", t: "祭りの 灯りの 下", free: false, F: ["F30", "F03"], ans: ["qb141", "qu012", "qu071"],
    syn: "祭りの 灯りの 下に、幼なじみの 魂が いた。「名前、ちょっとずつ 忘れて いくんだ。でも、あなたの 足音だけは 聞こえてた」。魂は 帳では なく、常世の 祭りの 頁に 連れて こられて いた。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 馬場の 区の 奥（祭りの 灯り）", "fest", "night");
        const f = K.fac(p, "u10fest", "u10fest", 99, U.y0(p)), lamp = facMark("u10fest", "lamp", p.location) || f;
        if (lamp) await K.at(p, lamp, 16, 6, 0.5);
        const so = U.soul(p, C, 5, -0.6, "smoke"); act(so, "sad");
        if (ok(so)) { await K.push(p, so, 26, 6, 2, 1.4); }
        /*F03・F30 回・強: 願った 一日に いちばん 近い 頁／最後の 頁 */
        await U.narr(p, [`§7灯りの 下に、見なれた 背中が あった。§f……${U.hn(p)}だ。`, "§7体は すけて いて、祭りの 灯りが 向こうへ 抜けて いた。"], so);
        await U.H(p, SOULV(["{shock,…,up}……あれ。……なんで、こんな ところに いるの。"], ["{shock,…,up}……あら。……どうして、こんな ところに いるの。"], ["{shock,…,up}……なんで、ここに いる。"], ["{shock,…,up}……え。……どうして、こんな ところに。"]));
        await U.H(p, SOULV(["{sad}ここ、ずっと お祭り なんだ。竜祭りの 夜みたいな、きれいな 灯り。", "{sad,…}……名前、ちょっとずつ 忘れて いくんだ。"], ["{sad}ここ、ずっと お祭りなの。竜祭りの 夜みたいな、きれいな 灯り。", "{sad,…}……名前、少しずつ 忘れて いくの。"], ["{sad}ここは ずっと 祭り。竜祭りの 夜に 似てる。", "{sad,…}……名前を、少しずつ 忘れる。"], ["{sad}ここは、ずっと お祭りです。竜祭りの 夜の ような、きれいな 灯り。", "{sad,…}……名前を、少しずつ 忘れて いくんです。"]));
        if (ok(so)) await K.up(p, so, 10);
        await U.H(p, SOULV(["{smile,tears,up}でも、あなたの 足音だけは、ずっと 聞こえてた。"], ["{smile,tears,up}でも、あなたの 足音だけは、ずっと 聞こえて いたわ。"], ["{smile,tears,up}でも、あなたの 足音だけは、ずっと 聞こえてた。"], ["{smile,tears,up}でも、あなたの 足音だけは、ずっと 聞こえて いました。"]));
        const mu = U.mu(C, 3, 2); await K.up(p, mu, 8);
        await U.M(p, mu, ["{closed}……魂は、帳に 行ったんじゃ ねえ。ここに 連れて 来られてたのか。"], "hold");
        await U.E(p, mu, ["……帳には 書かれて おらぬ。だから 呼べる"]);
        await K.two(p, so, mu, 10);
        await U.H(p, SOULV(["{?}……その 人、だれ？"], ["{?}……その 人は、どなた？"], ["{?}……だれ。"], ["{?}……そちらの 方は？"]), mu);
        await U.M(p, mu, ["{closed}……ムサシだ。こいつの 隣で、お前を 迎えに 来た。"], "nod");
        await U.H(p, SOULV(["{smile}……そっか。手帳に 書いとく。……あ、書けないんだった"], ["{smile}……そう。手帳に 書いて おくわね。……あら、書けないのね"], ["{smile}……手帳に 書いとく。……書けないか"], ["{smile}……では、手帳に 書いて おきます。……あ、書けないのでした"]));
        await U.M(p, mu, ["{smile,…}……書けねえ 同士だな"], "nod", so);
        await U.H(p, SOULV(["{smile}……ふふ。そうだね"], ["{smile}……ふふ。そうね"], ["{smile}……そうだな"], ["{smile}……ふふ。そうですね"]), mu);
        await K.ots(p, mu, p, 8);
        await U.M(p, mu, ["{closed}……おい。何か 言って やれ。……いや、顔だけで 十分か"], "hold", p);
        U.flag(p, "heroSoul");
        await U.end(p, C, { leave: [mu], card: "§7→ 魂の 足もとに、紫の 字" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u10e6", t: "紫の 字", free: false, F: [],
    syn: "魂は 祭りの 頁から 出られない。足もとに 紫の 字で 彼女の 名。ムサシ「待ってろ。絶対 連れて 帰る」。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 馬場の 奥", "fest", "night");
        K.fac(p, "u10fest", "u10fest", 99, U.y0(p));
        const so = U.soul(p, C, 4.5, -0.6); act(so, "sad");
        if (ok(so)) { await K.low(p, so, 14); const l = so.location; for (let k = 0; k < 10; k++) try { p.dimension.spawnParticle("minecraft:portal_reverse_particle", { x: l.x + Math.cos(k) * 0.8, y: l.y + 0.1, z: l.z + Math.sin(k) * 0.8 }); } catch {} }
        await U.narr(p, [`§7魂の 足もとに、§5紫の 字§7 が 輪に なって いた。§f……${U.hn(p)}の 名前だ。`, "§8一歩 外へ 出ようと すると、字が 光って 足を 止める。"], so);
        await U.H(p, SOULV(["{sad}……ね。出られないの。灯りの 外に 行こうと すると、足が 戻っちゃう。"], ["{sad}……ね。出られないの。灯りの 外へ 行こうと すると、足が 戻って しまうの。"], ["{sad}……出られない。灯りの 外へ 行くと、足が 戻る。"], ["{sad}……出られないんです。灯りの 外へ 行こうと すると、足が 戻って しまって。"]));
        const mu = U.mu(C, 2.4, 1.8); await K.up(p, mu, 8);
        await U.E(p, mu, ["……あの 字は、ここで 書かれた ものでは ない。街の 真ん中の 塔から、紫の 糸の ように 届いて おる"]);
        await U.M(p, mu, ["{angry,…}……誰かが、塔の 上で こいつの 名前を 書いてるってのか。", "{?}誰が、なんの ために。"], "guard");
        await U.E(p, mu, ["……記録塔、と 呼ばれて いる。書いて いる 者の 名は、まだ 読めぬ"]);
        if (ok(mu) && ok(so)) await K.approach(p, mu, so, 1.6, 12);
        await K.two(p, mu, so, 10);
        await U.M(p, mu, ["{rage,怒,up}……待ってろ。絶対 連れて 帰る。"], "raise");
        await U.H(p, SOULV(["{smile,tears}……うん。待ってる。……名前、忘れる 前に 来てね"], ["{smile,tears}……ええ。待ってる。……名前を 忘れる 前に、来てね"], ["{smile,tears}……待ってる。忘れる 前に 来て"], ["{smile,tears}……はい。お待ちして います。……名前を 忘れる 前に"]), mu);
        await U.M(p, mu, ["{closed}……忘れても、こいつが 呼ぶ。俺も 呼ぶ"], "raise", so);
        await U.H(p, SOULV(["{smile}……うん"], ["{smile}……ええ"], ["{smile}……ん"], ["{smile}……はい"]), mu);
        await U.E(p, mu, ["……この 頁を 抱えて いるのは、馬場の 主だ。主が 倒れれば、頁は ほどける"]);
        await U.M(p, mu, ["{angry}……じゃあ、話は 早え"], "guard");
        await U.M(p, mu, ["{closed}……一つ、二つ、三つ。……よし"], "guard");
        await U.end(p, C, { card: "§7→ 祭りの 主が、馬場の 奥に いる" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u10e7", t: "禍福の 縄", free: false, run: fight3, syn: "七冠サイオウバとの 戦い。勝つと、ずっと 跳んだ まま だった くじの 子が 着地した。" },
  { id: "u10e8", t: "声に 出して", free: false,
    syn: "祭りの 頁が ほどけ、魂は 一行に ついて 来られる ように なった。足もとの 紫の 字は 消えない。ムサシに 頼まれて 看板を 声に 出して 読む。「……それなら 本物だ」。ムサシが はじめて 主人公を 名で 呼んだ。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await K.open(p, "常世 ― 馬場の 奥（祭りの 終わり）", "fest", "dusk");
        const f = K.fac(p, "u10fest", "u10fest", 99, U.y0(p)), bo = facMark("u10fest", "booth", p.location) || f;
        K.flash(p); K.sound(p, "item.book.page_turn", 1);
        await K.wide(p, 14);
        await U.narr(p, ["§7祭りの 灯りが、一つずつ ほどけて いった。§8……くり返して いた 夕暮れが、やっと 終わった。"]);
        const so = U.soul(p, C, 3.6, -1.2); act(so, "up");
        if (ok(so)) { const l = so.location; await K.walkCam(p, so, { x: l.x - 1.5, y: l.y, z: l.z + 0.5 }, 16); }
        await U.H(p, SOULV(["{shock,!,jump}……出られた！ 足、戻らない！"], ["{shock,!}……出られたわ。足が、戻らない"], ["{shock,!}……出られた。足が 戻らない"], ["{shock,!,up}……出られました！ 足が、戻りません！"]));
        await K.low(p, so, 10);
        await U.narr(p, ["§7でも 足もとの §5紫の 字§7 だけは、魂に ついて 来て 消えなかった。"], so);
        const mu = U.mu(C); await K.up(p, mu, 8);
        await U.E(p, mu, ["……塔に 名が ある かぎり、あの 字は 消えぬ"]);
        await U.M(p, mu, ["{closed}……じゃあ、塔まで 連れてく。それだけだ。"], "hold", p);
        if (bo) await K.at(p, bo, 12, 3, 0.8);
        await U.M(p, mu, ["{?}……なあ。あの くじ屋の 看板、声に 出して 読んで くれ。俺は 字が 読めねえ。"], "point");
        await U.H(p, SOULV(["{smile}……『くじ 一回 一枚。大当たりは 鐘を 三度』"], ["{smile}……『くじ 一回 一枚。大当たりは 鐘を 三度』"], ["{smile}……『くじ 一回 一枚。大当たりは 鐘を 三度』"], ["{smile}……『くじ 一回 一枚。大当たりは 鐘を 三度』、です"]), mu);
        await K.up(p, mu, 8);
        await U.M(p, mu, ["{smile}……書いて あるだけの 字は 信じねえ。けど、お前が 声に 出したなら……", "{smile,☆}それなら 本物だ。"], "nod");
        const nm = U.nm(p);
        await U.H(p, SOULV([`{smile,♪}ね、${nm}。この 人、おもしろいね`], [`{smile}ねえ、${nm}。この 人、おもしろい 人ね`], [`{smile}${nm}。この 人、変わってる`], [`{smile}${nm}さん。この 方、おもしろい 方ですね`]));
        await K.ots(p, mu, p, 10);
        await U.M(p, mu, [`{shock,…}……${nm}、か。`, `{smile}今、こいつの 口から 聞いた。……よし、${nm}。行くぞ。`], "raise", p);
        await U.H(p, SOULV(["{smile,tears}……うん。行こう"], ["{smile,tears}……ええ。行きましょう"], ["{smile,tears}……行こう"], ["{smile,tears}……はい。参りましょう"]), mu);
        await U.E(p, mu, ["……名を、口で 覚えたか。小僧らしい"]);
        await U.end(p, C, { card: "§7→ 夜。§e野営地§7 へ", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
  { id: "u10e9", t: "声の 練習", free: false,
    syn: "野営地の 夜。字の 書けない ムサシは、彼女への ことばを 声で 練習した。彼女は 笑って、その ことばを 忘れない ように 三度 くり返した。",
    async run(p, d, K) {
      const C = U.C(p);
      try {
        await U.toCamp(p);
        await K.open(p, "常世 ― 野営地の 夜", "night", "night");
        const mu = U.mu(C, 2.6, 1.4), so = U.soul(p, C, 3, -1.4, "none"); act(mu, "kneel"); act(so, "kneel");
        await K.two(p, mu, so, 14);
        await U.M(p, mu, ["{closed}……俺は 書けねえから、声で 覚える。", `{?}お前の 名前、もう 一回 言え。`], "kneel");
        await U.H(p, SOULV([`{smile}……${U.hn(p)}。`], [`{smile}……${U.hn(p)}よ。`], [`{smile}……${U.hn(p)}。`], [`{smile}……${U.hn(p)}、です。`]), mu);
        await U.M(p, mu, [`{closed}${U.hn(p)}。……${U.hn(p)}。……${U.hn(p)}。`, "{smile}……よし。三度 言った。もう 忘れねえ。"]);
        await U.M(p, mu, ["{closed}……それと、もう 一つ。", "{closed}お前が 忘れたら、俺が 何度でも 呼んで やる。……これも 声で 覚えとけ。"], "hold");
        if (ok(so)) await K.up(p, so, 10);
        await U.H(p, SOULV(["{smile,tears}……忘れたら、呼んで もらう。", "{smile,tears}忘れたら、呼んで もらう。……忘れたら、呼んで もらう。"], ["{smile,tears}……忘れたら、呼んで もらう。", "{smile,tears}忘れたら、呼んで もらう。……忘れたら、呼んで もらう。"], ["{smile,tears}……忘れたら、呼んで もらう。", "{smile,tears}忘れたら、呼んで もらう。……忘れたら、呼んで もらう。"], ["{smile,tears}……忘れたら、呼んで いただく。", "{smile,tears}忘れたら、呼んで いただく。……忘れたら、呼んで いただく。"]), mu);
        await U.H(p, SOULV(["{smile}……三度。ね、これで 忘れない"], ["{smile}……三度よ。これで 忘れないわ"], ["{smile}……三度。これで 忘れない"], ["{smile}……三度です。これで 忘れません"]));
        await U.M(p, mu, ["{smile,…}……ああ。名乗りは 三度、だったな。"], "kneel");
        await U.E(p, mu, ["……三度 呼べば、来る。……覚えて おけ"]);
        await U.M(p, mu, ["{closed}……ああ。忘れねえ。……もう 寝ろ、二人とも"], "kneel");
        await U.narr(p, ["§7たき火の 向こうで、魂が 小さく 名前を くり返して いた。"], so);
        await U.c20(p);
        await U.end(p, C, { card: "§7→ 六冠の §e花壇の 区§7 へ（右上の 案内）", kind: "night" });
        return ok(p);
      } finally { C.end(); }
    } },
]);

U.ward(2, ["u10e1", "u10e2"], []);
U.ward(3, ["u10e3", "u10e4", "u10e5", "u10e6", "u10e7"], ["u10e8", "u10e9"]);
