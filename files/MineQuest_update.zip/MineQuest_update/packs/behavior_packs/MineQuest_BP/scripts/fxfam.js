// 第126版: 技の 演出を 系統（属性など）× 形（斬る・当てる・飛ばす・範囲・強化・弱化・回復）で 決める
// 軽さ: 1つの 技で 出す 粒の 発生元（emitter）は CAP まで。毎ティックの 処理は なし（技の 演出の 中だけ）
import { MOVES } from "./data.js";

// 系統: 色・当たったときの 粒 [id, 位置(g=足もと h=体 top=頭の上 sky=空), 大きさ]・大技の 追加・飛び道具
export const FAMS = {
  fire:    { col: [1, 0.42, 0.1],    hit: [["fx_flare", "h"], ["fx_ember", "g"]],     big: ["boom", "h", 1.2],        proj: "fx_proj_flame" },
  water:   { col: [0.25, 0.55, 1],   hit: [["fx_splash", "g"], ["fx_droplets", "g"]], big: ["fx_splash", "g", 2],     proj: "fx_proj_drop" },
  ice:     { col: [0.6, 0.9, 1],     hit: [["fx_crystal", "g"], ["fx_frost", "g"]],   big: ["shards", "h", 1.2],      proj: "fx_proj_flake" },
  thunder: { col: [1, 0.95, 0.3],    hit: [["fx_skybolt", "sky"], ["fx_flash", "h"]], big: ["fx_skybolt", "sky", 1.4], proj: "fx_proj_spark4" },
  wind:    { col: [0.5, 1, 0.65],    hit: [["fx_gust", "g"], ["swirl", "h", 0.8]],    big: ["fx_gust", "g", 1.6],     proj: "fx_proj_streak" },
  earth:   { col: [0.8, 0.58, 0.32], hit: [["fx_spikes", "g"], ["fx_dust", "g"]],     big: ["fx_rocks", "g", 1.2],    proj: "fx_proj_rock" },
  light:   { col: [1, 0.92, 0.6],    hit: [["fx_rays", "h"], ["fx_halo", "top"]],     big: ["pillar", "g", 1.2],      proj: "fx_proj_mote" },
  dark:    { col: [0.55, 0.2, 0.85], hit: [["fx_wisp", "g"], ["fx_void", "h"]],       big: ["fx_wisp", "g", 1.6],     proj: "fx_proj_wisp" },
  poison:  { col: [0.6, 1, 0.25],    hit: [["fx_bubble", "g"], ["fx_mist", "g"]],     big: ["fx_mist", "g", 1.8],     proj: "fx_proj_bubble" },
  dragon:  { col: [0.85, 0.3, 1],    hit: [["fx_dflare", "h"], ["fx_ember", "g"]],    big: ["fx_dflare", "h", 1.6],   proj: "fx_proj_flame" },
  metal:   { col: [0.85, 0.88, 0.95], hit: [["fx_msparks", "h"], ["fx_blade", "h"]],  big: ["xslash", "h", 1.2],      proj: "fx_proj_blade" },
  plant:   { col: [0.35, 0.85, 0.3], hit: [["fx_leaves", "g"], ["fx_vines", "g"]],    big: ["fx_vines", "g", 1.6],    proj: "fx_proj_leaf" },
  martial: { col: [1, 0.72, 0.3],    hit: [["impact", "h"], ["fx_dust", "g"]],        big: ["shock", "g", 1.4],       proj: "fx_proj_mote" },
  arcane:  { col: [0.7, 0.6, 1],     hit: [["fx_runes", "g"], ["star", "h"]],         big: ["circle", "g", 1.4],      proj: "fx_proj_mote" },
  special: { col: [1, 0.38, 0.62],   hit: [["fx_burst", "h"], ["shock", "g", 1.3]],   big: ["boom", "h", 1.2],        proj: "fx_proj_spark4" },
  heal:    { col: [0.45, 1, 0.55],   hit: [["fx_heal", "g"], ["circle", "g", 0.8]],   big: ["fx_halo", "top", 1.2],   proj: "fx_proj_mote" },
  buff:    { col: [1, 0.85, 0.35],   hit: [["fx_buff", "g"], ["fx_halo", "top", 0.8]], big: ["fx_ring", "g", 1.4],    proj: "fx_proj_mote" },
  curse:   { col: [0.7, 0.35, 1],    hit: [["fx_debuff", "top"], ["fx_wisp", "g", 0.7]], big: ["fx_void", "h", 1.2], proj: "fx_proj_wisp" },
};
export const SHAPES = ["slash", "impact", "proj", "area", "breath", "buff", "debuff", "heal"];
const EL_FAM = { fire: "fire", water: "water", ice: "ice", thunder: "thunder", wind: "wind", earth: "earth", wood: "plant", steel: "metal", light: "light", dark: "dark" };
const TMX_FAM = { blob: "water", dragon: "dragon" };   // 闘魔技で 属性の ない もの・竜の もの
const SELF_T = new Set(["self", "ally", "allies"]);
const isHeal = (m) => !!(m.heal || m.revive || m.cure || m.regen || m.kind === "heal");
const isSup = (m) => m.kind === "support" || m.kind === "status" || m.kind === "reflect";
const poisonish = (m) => (m.inf && m.inf[0] === "poison") || m.ail === "poison" || /毒|ポイズン|ベノム/.test(m.name || "");
// 技 → 系統（決まらない ときは null。テストで 全部の 技が 決まる ことを たしかめる）
export function famOf(m) {
  if (!m) return null;
  if (m.tmx && TMX_FAM[m.tmx]) return TMX_FAM[m.tmx];
  if (isHeal(m)) return "heal";
  if (m.el && EL_FAM[m.el]) return EL_FAM[m.el];
  if (poisonish(m)) return "poison";
  if (isSup(m)) return SELF_T.has(m.target) ? "buff" : "curse";
  if (m.cat === "breath") return "dragon";
  if (m.cat === "weapon") return "metal";
  if (m.cat === "phys") return "martial";
  if (m.cat === "special") return "special";
  if (m.cat === "magic" || m.type === "spell" || m.type === "mpdrain") return "arcane";
  return null;
}
export function shapeOf(m) {
  if (!m) return null;
  if (isHeal(m)) return "heal";
  if (isSup(m)) return SELF_T.has(m.target) ? "buff" : "debuff";
  if (m.cat === "breath") return "breath";
  if (m.target === "enemies" || m.target === "all" || m.target === "rand2") return "area";
  if (m.cat === "magic" || !m.cat) return "proj";
  if (m.cat === "weapon") return "slash";
  return "impact";
}
export const isBigMove = (m) => !!(m && (m.tier >= 4 || m.tmx || m.god || m.boss));
const PLAN = new Map();
export function planOf(mid) {
  if (PLAN.has(mid)) return PLAN.get(mid);
  const m = MOVES[mid]; const fam = famOf(m), shape = shapeOf(m);
  const P = fam && shape ? { fam, shape, big: isBigMove(m) } : null;
  PLAN.set(mid, P); return P;
}
const CAT_FAM = { slash: "metal", martial: "martial", breath: "dragon", magic: "arcane", special: "special" };
const RANGED = new Set(["wp_bow", "wp_gun", "wp_tome", "wp_throw"]);
// 戦いの 中の 1回の 行動 → 演出の 予定（通常攻撃・道具は fx から 決める）
export function planFx(fx, mo, lite) {
  if (!fx) return null;
  let P = fx.mid && fx.mid !== "basic" && MOVES[fx.mid] ? planOf(fx.mid) : null;
  if (!P) {
    const fam = EL_FAM[fx.el] || (fx.el === "heal" ? "heal" : fx.down ? "curse" : CAT_FAM[fx.cat] || (fx.anim === "cast" ? "arcane" : "martial"));
    const shape = fx.el === "heal" ? "heal" : fx.anim === "breath" ? "breath" : fx.anim === "cast" ? (fx.hit && fx.hit.length > 1 ? "area" : "proj") : fx.cat === "slash" ? "slash" : "impact";
    P = { fam, shape, big: false };
  }
  P = { ...P, lite: !!lite };
  if (RANGED.has(mo) && (P.shape === "slash" || P.shape === "impact")) P.shape = "proj";   // 弓・銃・魔本・投げる 武器は 飛ばす
  return P;
}
// ---- 1つの 技の 発生元の 上限（battle.js の vfx が 数える）----
export const FX_CAP = 48, FX_CAP_LITE = 16;
let CUR = null;
export const fxStats = { max: 0, moves: 0 };
export function fxBegin(lite) { if (CUR) fxStats.max = Math.max(fxStats.max, CUR.n); CUR = { n: 0, cap: lite ? FX_CAP_LITE : FX_CAP, t: Date.now() }; fxStats.moves++; return CUR; }
export function fxEnd(c) { if (CUR && CUR === c) { fxStats.max = Math.max(fxStats.max, CUR.n); CUR = null; } }
export function fxTake() {
  if (!CUR) return true;
  if (Date.now() - CUR.t > 15000) { fxStats.max = Math.max(fxStats.max, CUR.n); CUR = null; return true; }   // 途中で 止まった 技の 予定は 古く なったら すてる
  if (CUR.n >= CUR.cap) return false;
  CUR.n++; return true;
}
// ---- 描く（V = battle.js の vfx(e, id, dy, col, sc)）----
const dyOf = (pos, h) => (pos === "g" ? 0.05 : pos === "top" ? h + 0.6 : pos === "sky" ? 3.4 : h);
function put(V, e, h, r, col, sc) { V(e, r[0], dyOf(r[1], h), col, sc * (r[2] || 1)); }
// 当たった 相手 1体ぶん（rep=何回目・idx=何体目。2回目 以降・4体目 以降は 軽く）
export function famHit(V, e, h, P, sc = 1, crit = false, rep = 0, idx = 0) {
  const F = FAMS[P.fam]; if (!F) return;
  const col = F.col, light = P.lite || rep > 0 || idx >= 3;
  if (P.shape === "heal" || P.shape === "buff") { V(e, P.shape === "heal" ? "fx_heal" : "fx_buff", 0.1, col, 1); if (!light) put(V, e, h, F.hit[0][0] === "fx_heal" || F.hit[0][0] === "fx_buff" ? F.hit[1] : F.hit[0], col, 1); return; }
  if (P.shape === "debuff") { V(e, "fx_debuff", h + 0.9, col, 1); if (!light) put(V, e, h, F.hit[0][0] === "fx_debuff" ? F.hit[1] : F.hit[0], col, 1); return; }
  if (P.shape === "slash") V(e, "slash", h, col, sc * 1.1);
  else if (P.shape === "impact" && P.fam !== "martial") V(e, "impact", h, col, sc * 0.8);
  else if (P.shape === "area" && !light) V(e, "fx_ring", 0.05, col, sc * 0.8);
  put(V, e, h, F.hit[0], col, sc);
  if (!light) put(V, e, h, F.hit[1], col, sc);
  if (crit) V(e, "star", h + 0.2, [1, 1, 0.75], 1.4);
  if (P.big && rep === 0 && idx < 2 && !P.lite) { V(e, "fx_glow", h, col, sc * 1.4); V(e, "fx_burst", h, col, sc); put(V, e, h, F.big, col, sc); }
}
// 大技の ため（使い手に 光が 集まる）
export function famCharge(V, e, h, P, sc = 1) {
  if (!P || !P.big || P.lite) return;
  const col = (FAMS[P.fam] || FAMS.special).col;
  V(e, "fx_charge", h, col, sc * 1.2); V(e, "fx_ring", 0.05, col, sc * 1.1);
}
// 範囲技の 場の 輪（1回だけ）
export function famField(V, e, P, sc = 1) { if (P && P.shape === "area") V(e, "fx_ring", 0.05, (FAMS[P.fam] || FAMS.special).col, sc * (P.big ? 2.6 : 1.8)); }
// 使われて いる 粒の 名前（テスト用）
export function famParticles() {
  const s = new Set(["fx_heal", "fx_buff", "fx_debuff", "fx_ring", "fx_glow", "fx_burst", "fx_charge", "fx_dbreath", "slash", "impact", "star", "stream"]);
  for (const F of Object.values(FAMS)) { for (const r of F.hit) s.add(r[0]); s.add(F.big[0]); s.add(F.proj); }
  return [...s];
}
