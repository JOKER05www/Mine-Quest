/* 第127版(fb): 回想の セット（昔の 場所）。K.flashback(p, { set: "fb_..." }) で 使う
   ・回想ごとに 1つ。文に 出る 昔の 場所（千年前の 都の 広場・王の 間・ジンの 家と 壁画の 中庭・鍛冶の 家の 炉・焼けた 村・火祭りの 舞台・冬の 小川・詰所・山道・寄り合い・竜の 見晴らし台・牧場・収穫祭・旅立ちの 門・乾いた 村・川辺・古い 森）
   ・形は ローカル座標（a: 奥へ・b: 横・h: 高さ。h=-1 が 地面）。原点（a=0,b=0）が カメラの 立つ 所、人は a=1〜11・b=-4〜4 で 演じる。前（a<0）は あけて おく（カメラ）
   ・場所: 今の 舞台から 36〜52 マス はなれた 開けた 地面（町・城・ステージ・ほかの 施設・人の 建てた もの の 上には 建てない）。前の 面が 今の 舞台を 向く
   ・ワールドに 1回だけ 建てる（記録 mrpg:epdeco:<key>at。faclist に 入れて ほかの 施設と 重ならない）。今の 舞台から 70 マス より 遠い ときだけ 近くに 建てなおす
   ・建ち終わる tick 数は 前と 同じ（40 本ずつ）。1 tick の 量は その tick 数で ならす（第128版。いちばん 重い tick 約 27,000 → 9,900〜15,100 ブロック）。fill は どれも 32768 以下（上の 空けは 3段ずつ）*/
import { world, system } from "@minecraft/server";
import { groundY, TOWNS, townPos, getTown, castleSpot } from "./structures.js";
import { WREGIONS, landSites } from "./worldmap.js";
import { facBig, FAC_OPS, __fac } from "./epfac.js";
const { F, S1 } = FAC_OPS;
const VER = 1;
const HL = 'lantern ["hanging"=true]', HSL = 'soul_lantern ["hanging"=true]', WCAUL = 'cauldron ["cauldron_liquid"="water","fill_level"=6]';
const LOGA = (w) => `${w} ["pillar_axis"=AXA]`, LOGB = (w) => `${w} ["pillar_axis"=AXB]`;
export const FB_BOX = [-13, -13, 18, 13];   /* 32 × 27 */
export const FB_AZ = [-5, -4, 11, 4];   /* 人が 演じる 所（h>=0 の 草・小物を 置かない）*/
const nz = (a, b, s = 0) => { let h = Math.imul(a | 0, 73856093) ^ Math.imul(b | 0, 19349663) ^ Math.imul(s | 0, 83492791); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
const inAZ = (a, b) => a >= FB_AZ[0] && a <= FB_AZ[2] && b >= FB_AZ[1] && b <= FB_AZ[3];

/* ---------- 部品 ---------- */
const col = (a, b, h0, h1, bl) => F(a, b, h0, a, b, h1, bl);
const post = (a, b, h = 2, fence = "spruce_fence", lamp = "lantern") => [col(a, b, 0, h - 1, fence), S1(a, b, h, lamp)];
const tree = (a, b, h, log = "oak_log", leaf = "oak_leaves", z = 0) => [F(a - 2, b - 2, z + h - 2, a + 2, b + 2, z + h - 1, leaf, "keep"), F(a - 1, b - 1, z + h, a + 1, b + 1, z + h, leaf, "keep"), S1(a, b, z + h + 1, leaf), col(a, b, z, z + h - 1, log)];
const pine = (a, b, h, snow = false, z = 0) => [F(a - 2, b - 2, z + 2, a + 2, b + 2, z + 3, "spruce_leaves", "keep"), F(a - 1, b - 1, z + 4, a + 1, b + 1, z + h - 1, "spruce_leaves", "keep"), S1(a, b, z + h, "spruce_leaves"), col(a, b, z, z + h - 1, "spruce_log"), ...(snow ? [F(a - 2, b - 2, z + 4, a + 2, b - 2, z + 4, "snow_layer", "keep"), F(a - 2, b + 2, z + 4, a + 2, b + 2, z + 4, "snow_layer", "keep"), F(a - 2, b - 1, z + 4, a - 2, b + 1, z + 4, "snow_layer", "keep"), F(a + 2, b - 1, z + 4, a + 2, b + 1, z + 4, "snow_layer", "keep"), S1(a, b, z + h + 1, "snow_layer")] : [])];
const big = (a, b, h, log = "dark_oak_log", leaf = "dark_oak_leaves") => [F(a - 3, b - 3, h - 1, a + 4, b + 4, h, leaf, "keep"), F(a - 2, b - 2, h + 1, a + 3, b + 3, h + 1, leaf, "keep"), F(a, b, 0, a + 1, b + 1, h - 1, log)];   /* 2×2 の 古い 大木 */
const dead = (a, b, h, log = "dark_oak_log") => [col(a, b, 0, h, log), S1(a + 1, b, h - 1, log), S1(a, b - 1, h - 2, log)];
/* 家（中は 空き・四すみの 柱・戸口・窓・平らな 屋根）。door: [a, b]。win: [[a,b]]（高さ 1）*/
function hut(a0, b0, a1, b1, h, wall, roof, o = {}) {
  const L = [F(a0, b0, 0, a1, b1, h - 1, wall), F(a0 + 1, b0 + 1, 0, a1 - 1, b1 - 1, h - 1, "air"), F(a0 - 1, b0 - 1, h, a1 + 1, b1 + 1, h, roof)];   /* 第128版: hollow を やめ 中を air で 空ける（照合と 同じ 形）*/
  if (o.log) for (const [a, b] of [[a0, b0], [a0, b1], [a1, b0], [a1, b1]]) L.push(col(a, b, 0, h - 1, o.log));
  if (o.door) L.push(F(o.door[0], o.door[1], 0, o.door[0], o.door[1], 1, "air"));
  for (const [a, b] of o.win || []) L.push(S1(a, b, 1, o.pane || "glass_pane"));
  if (o.lit) L.push(S1((a0 + a1) >> 1, (b0 + b1) >> 1, h - 1, HL));
  if (o.cap) L.push(F(a0, b0, h + 1, a1, b1, h + 1, o.cap));
  return L;
}
/* 散らす（決まった 乱数。h>=0 は 演じる 所を よける）*/
function scatter(seed, n, h, bls, r = [-12, -12, 17, 12], az = true) {
  const L = [], used = new Set();
  for (let i = 0; i < n * 4 && L.length < n; i++) {
    const a = r[0] + Math.floor(nz(i, seed, 1) * (r[2] - r[0] + 1)), b = r[1] + Math.floor(nz(seed, i, 2) * (r[3] - r[1] + 1)), k = `${a},${b}`;
    if (used.has(k) || (az && h >= 0 && inAZ(a, b))) continue; used.add(k); L.push(S1(a, b, h, bls[i % bls.length]));
  }
  return L;
}
const arc = (ca, cb, R, d0, d1, n) => { const o = [], s = new Set(); for (let i = 0; i < n; i++) { const t = ((d0 + ((d1 - d0) * i) / (n - 1)) * Math.PI) / 180, a = Math.round(ca + R * Math.cos(t)), b = Math.round(cb + R * Math.sin(t)); if (!s.has(`${a},${b}`)) { s.add(`${a},${b}`); o.push([a, b]); } } return o; };

/* ---------- セット（g: 地面・base: 土台・H: 空ける 高さ・look: 引きの 絵で 映す 所）---------- */
const SETS = {
  /* 1 千年前の 都の 広場（b01: 王と 神官と 十五枚の 石板）: 石の 広場・十五の 石碑の 弧・列柱と 梁の 灯り・宮殿の 正面と 門・かがり火 */
  fb_oldcap: { nm: "千年前の 都の 広場", g: "grass_block", base: "dirt", look: [12, 0, 3], build: () => [
    F(-6, -11, -1, 16, 11, -1, "stone_bricks"), F(-6, -11, -1, -2, -7, -1, "mossy_stone_bricks"), F(12, 6, -1, 16, 11, -1, "mossy_stone_bricks"), ...scatter(11, 10, -1, ["cracked_stone_bricks", "mossy_stone_bricks"], [-6, -11, 16, 11]),
    F(2, -3, -1, 8, 3, -1, "polished_andesite"), F(4, -1, -1, 6, 1, -1, "chiseled_stone_bricks"), F(-13, -1, -1, -7, 1, -1, "stone_bricks"),
    ...arc(5, 0, 5, -84, 84, 15).map(([a, b]) => col(a, b, 0, 1, "chiseled_stone_bricks")),   /* 十五枚の 石板 */
    ...[-4, 0, 4, 8, 12, 16].flatMap((a) => [col(a, -10, 0, 7, (a & 4) ? "mossy_stone_bricks" : "stone_bricks"), col(a, 10, 0, 7, "stone_bricks")]),
    F(-4, -10, 8, 16, -10, 8, "chiseled_stone_bricks"), F(-4, 10, 8, 16, 10, 8, "chiseled_stone_bricks"),
    ...[2, 6, 10, 14].flatMap((a) => [S1(a, -10, 7, HL), S1(a, 10, 7, HL)]),
    F(17, -13, 0, 18, 13, 10, "stone_bricks"), F(17, -13, 11, 17, 13, 11, "stone_brick_wall"), F(17, -2, 0, 17, 2, 5, "air"), F(18, -2, 0, 18, 2, 5, "polished_deepslate"), F(17, -3, 6, 17, 3, 6, "chiseled_stone_bricks"),
    F(17, -9, 4, 17, -7, 7, "glass_pane"), F(17, 7, 4, 17, 9, 7, "glass_pane"), F(16, -5, 2, 16, -5, 8, "red_wool"), F(16, 5, 2, 16, 5, 8, "red_wool"), S1(16, -5, 9, "gold_block"), S1(16, 5, 9, "gold_block"),
    ...[[1, -7], [1, 7], [10, -7], [10, 7]].flatMap(([a, b]) => [S1(a, b, 0, "chiseled_stone_bricks"), S1(a, b, 1, "campfire")]),
    ...pine(-9, -9, 8), ...pine(-9, 9, 7), ...scatter(12, 8, 0, ["poppy", "short_grass", "dandelion", "short_grass"], [-13, -12, -7, 12]),
  ] },
  /* 2 十二年前の 冬 グランディア城の 中庭（b03: ジンの 家と 壁画）: 砂岩の 城壁・壁画の 壁（削られた 影）・ジンの 家・やし・泉・灰（薄い 灰色の じゅうたん）*/
  fb_jinyard: { nm: "グランディア城の 中庭", g: "sand", base: "sandstone", look: [14, 5, 2.5], build: () => [
    F(-6, -10, -1, 14, 10, -1, "smooth_sandstone"), F(0, -1, -1, 14, 1, -1, "cut_sandstone"), ...scatter(21, 8, -1, ["sandstone", "cut_sandstone"], [-6, -10, 14, 10]),
    F(-6, -11, 0, 16, -11, 6, "sandstone"), F(-6, 11, 0, 16, 11, 6, "sandstone"), F(-6, -11, 7, 16, -11, 7, "cut_sandstone"), F(-6, 11, 7, 16, 11, 7, "cut_sandstone"),
    F(15, -11, 0, 16, 11, 7, "sandstone"), F(15, -3, 0, 16, -1, 3, "air"), F(15, -3, 4, 15, -1, 4, "chiseled_sandstone"),   /* 壁画の 番へ 出る 門 */
    F(14, 0, 0, 14, 10, 6, "chiseled_sandstone", "hollow"), F(14, 1, 1, 14, 9, 5, "white_terracotta"),   /* 壁画 */
    F(14, 2, 1, 14, 3, 4, "blue_terracotta"), F(14, 5, 1, 14, 5, 4, "red_terracotta"), S1(14, 5, 5, "red_terracotta"), F(14, 6, 1, 14, 6, 4, "sandstone"), F(14, 7, 1, 14, 8, 4, "cyan_terracotta"), F(14, 1, 5, 14, 9, 5, "light_blue_terracotta"),
    ...post(12, 1, 2, "birch_fence"), ...post(12, 9, 2, "birch_fence"),
    ...hut(1, -10, 7, -6, 4, "sandstone", "cut_sandstone", { door: [4, -6], win: [[2, -6], [6, -6]], pane: "iron_bars", lit: true, log: "birch_log" }), F(3, -5, 3, 5, -5, 3, "orange_wool"),   /* ジンと アサギの 家 */
    ...tree(10, 7, 6, "jungle_log", "jungle_leaves"), F(7, 4, 0, 9, 6, 0, "sandstone"), S1(8, 5, 0, "water"),
    ...[0, 6, 12].flatMap((a) => [S1(a, -10, 5, "sandstone"), S1(a, -10, 4, HL), S1(a, 10, 5, "sandstone"), S1(a, 10, 4, HL)]),
    ...scatter(22, 16, 0, ["light_gray_carpet"], [-6, -9, 13, 9], false),
    ...scatter(24, 6, 0, ["deadbush"], [-13, -12, -7, 12]), F(-6, -13, 0, -6, -11, 4, "sandstone"), F(-6, 11, 0, -6, 13, 4, "sandstone"),
  ] },
  /* 3 十二年前 鍛冶の 家の 炉（b04: ヴァルカの 父）: 石の 鍛冶場（三方の 壁・屋根）・金床・炉と 煙突・焼き入れの 水・道具・戸口の 外に 遠い 火 */
  fb_vforge: { nm: "鍛冶の 家の 炉", g: "coarse_dirt", base: "stone", look: [9, 0, 1.5], build: () => [
    F(0, -7, -1, 11, 7, -1, "polished_blackstone"), F(7, -1, -1, 10, 2, -1, "blackstone"),
    F(0, -8, 0, 12, -8, 4, "cobblestone"), F(0, 8, 0, 12, 8, 4, "cobblestone"), F(12, -8, 0, 12, 8, 4, "cobblestone"), F(12, -3, 0, 12, -2, 2, "air"),
    ...[[0, -8], [0, 8], [6, -8], [6, 8], [12, -8], [12, 8]].map(([a, b]) => col(a, b, 0, 4, "dark_oak_log")),
    F(2, -9, 5, 13, 9, 5, "dark_oak_planks"), F(3, -8, 6, 12, 8, 6, "dark_oak_slab"), F(4, -8, 2, 5, -8, 2, "iron_bars"), F(4, 8, 2, 5, 8, 2, "iron_bars"),
    S1(6, 0, 0, "anvil"), F(9, -1, 0, 10, 1, 1, "brick_block"), S1(9, 0, 0, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'), S1(9, 0, 1, "blast_furnace"), F(10, 0, 2, 10, 0, 8, "brick_block"), S1(10, 0, 9, "campfire"),
    S1(5, 3, 0, WCAUL), S1(3, -6, 0, "grindstone"), S1(8, -6, 0, "smithing_table"), F(10, 5, 0, 11, 7, 0, "barrel"), S1(11, 6, 1, "barrel"), S1(11, 3, 0, "coal_block"), S1(2, 6, 0, "crafting_table"),
    F(4, -7, 1, 8, -7, 1, "chain"), S1(9, -7, 0, "barrel"), S1(9, -7, 1, "raw_iron_block"),
    S1(3, -3, 4, HL), S1(3, 3, 4, HL), S1(8, -4, 4, HL), S1(8, 4, 4, HL),
    F(13, -6, -1, 18, -1, -1, "gravel"), F(17, -6, 0, 18, -1, 0, "magma"), S1(17, -4, 1, "campfire"), S1(18, -2, 1, "campfire"), F(17, -6, 1, 17, -5, 3, "dark_oak_log"),   /* 戸口の 先: 峠の 向こうの 火 */
    F(-3, -11, 0, -2, -9, 1, LOGA("spruce_log")), ...scatter(31, 14, 0, ["light_gray_carpet"], [-13, -12, -1, 12]), ...dead(-9, 8, 5), ...dead(15, 9, 5),
  ] },
  /* 4 十二年前 焼けた 鍛冶の 村（b04: ヨネが 木槌を 拾った 朝）: 黒い 柱と 崩れた 壁・残った 煙突・くすぶる 火・倒れた 梁・枯れ木・灰の 地面 */
  fb_ashvil: { nm: "焼けた 鍛冶の 村（朝）", g: "coarse_dirt", base: "dirt", look: [13, -3, 2], build: () => [
    ...scatter(41, 26, -1, ["soul_soil", "gravel", "coal_block", "tuff"]), F(-13, -1, -1, 18, 1, -1, "gravel"),
    ...[[11, -6], [11, 0], [16, -6], [16, 0]].map(([a, b], i) => col(a, b, 0, 1 + (i % 3), "stripped_dark_oak_log")), F(11, -5, 0, 11, -3, 1, "blackstone"), F(16, -6, 0, 16, -1, 2, "cobblestone"), F(12, -6, 0, 15, -6, 0, "blackstone"),
    F(12, -4, 0, 15, -4, 0, LOGA("dark_oak_log")), S1(13, -2, 0, "campfire"), S1(14, -5, 1, "coal_block"),
    F(0, -12, 0, 6, -12, 1, "cobblestone"), F(0, -12, 0, 0, -8, 0, "blackstone"), F(3, -10, 0, 3, -10, 6, "brick_block"), S1(3, -10, 7, "campfire"), F(1, -9, 0, 5, -9, 0, LOGA("dark_oak_log")),
    ...[[2, 7], [8, 7], [2, 12], [8, 12]].map(([a, b], i) => col(a, b, 0, 2 + (i & 1), "stripped_dark_oak_log")), F(2, 12, 0, 8, 12, 1, "blackstone"), S1(5, 9, 0, "anvil"), S1(4, 10, 0, "campfire"), F(3, 8, 0, 7, 8, 0, LOGA("dark_oak_log")),
    ...dead(9, 6, 5), ...dead(-6, -8, 4), ...dead(15, 9, 5), F(-8, 4, 0, -3, 4, 0, "dark_oak_fence"), S1(-5, 4, 0, "air"),
    ...scatter(42, 10, 0, ["deadbush"]), ...scatter(43, 10, 0, ["light_gray_carpet"], [-4, -4, 10, 4], false), S1(-1, 6, 0, "campfire"),
    ...[[8, -3], [9, 3], [7, 5]].map(([a, b]) => col(a, b, 0, 1, "stone")),   /* 灰を かぶった 石の 人たち（b04 の 地の 文）*/
  ] },
  /* 5 十二年前 燃える 鍛冶の 村（r3: ゲンが 子を 拾った 夜）: 板と 石の 家・屋根の 火・燃える がれき・鍛冶場の 煙突 */
  fb_smithburn: { nm: "燃える 鍛冶の 村", g: "coarse_dirt", base: "dirt", look: [13, -6, 3], build: () => [
    F(-13, -1, -1, 18, 1, -1, "gravel"), ...scatter(51, 12, -1, ["dirt", "gravel", "soul_soil"]),
    ...hut(11, -9, 16, -4, 4, "cobblestone", "spruce_planks", { door: [11, -6], win: [[13, -4]], log: "spruce_log", lit: true }), S1(12, -8, 5, "campfire"), S1(15, -5, 5, "campfire"), S1(14, -7, 5, "magma"),
    ...hut(10, 4, 15, 9, 4, "spruce_planks", "dark_oak_planks", { door: [10, 6], win: [[12, 4]], log: "spruce_log", lit: true }), S1(11, 5, 5, "campfire"), S1(14, 8, 5, "campfire"),
    ...hut(-3, -12, 3, -8, 3, "spruce_planks", "dark_oak_planks", { door: [0, -8], log: "spruce_log" }), S1(-2, -11, 4, "campfire"), S1(2, -9, 4, "campfire"),
    F(16, 0, 0, 16, 0, 7, "brick_block"), S1(16, 0, 8, "campfire"), S1(15, 1, 0, "anvil"), S1(15, -1, 0, "blast_furnace"),
    S1(6, -3, 0, "campfire"), S1(7, 3, 0, "campfire"), S1(9, -5, 0, "campfire"), F(5, 5, 0, 7, 5, 0, LOGA("spruce_log")),
    ...dead(-8, 8, 5), ...pine(-10, -9, 7), ...scatter(52, 8, 0, ["deadbush", "light_gray_carpet"]),
  ] },
  /* 6 十二年前の 火祭り（b04: カグラの 母の 最後の 舞）: 黒石の 広場・丸い 舞台・燃える 石の 輪（溶岩石と 焚き火）・朱の 鳥居と 社・提灯の 列・見物の 席・火山の 岩 */
  fb_firestage: { nm: "火祭りの 舞台", g: "blackstone", base: "basalt", look: [12, 0, 4], build: () => [
    F(-6, -10, -1, 14, 10, -1, "polished_blackstone_bricks"), F(2, -3, -1, 8, 3, -1, "polished_blackstone"), F(3, -4, -1, 7, 4, -1, "polished_blackstone"), F(1, -2, -1, 9, 2, -1, "polished_blackstone"),
    ...[[9, 0], [8, -3], [8, 3], [5, -4], [5, 4], [2, -3]].map(([a, b]) => S1(a + (a === 9 ? 1 : 0), b + (b < 0 ? -1 : b > 0 ? 1 : 0), -1, "magma")),
    ...[[9, -1], [9, 1], [7, -4], [7, 4], [3, -4], [3, 4]].map(([a, b]) => S1(a, b, 0, "campfire")),
    col(12, -4, 0, 6, "red_nether_brick"), col(12, 4, 0, 6, "red_nether_brick"), F(12, -5, 7, 12, 5, 7, "red_nether_brick"), F(12, -4, 5, 12, 4, 5, "red_nether_brick_slab"), S1(12, 0, 6, "gold_block"),
    ...hut(14, -3, 17, 3, 4, "dark_oak_planks", "dark_oak_slab", { log: "dark_oak_log" }), F(14, -1, 0, 14, 1, 2, "air"), S1(16, 0, 0, "shroomlight"), S1(16, 0, 3, HL),
    ...[-2, 2, 6, 10].flatMap((a) => [col(a, -8, 0, 2, "nether_brick_fence"), S1(a, -8, 3, "red_wool"), S1(a, -8, 4, "lantern"), col(a, 8, 0, 2, "nether_brick_fence"), S1(a, 8, 3, "red_wool"), S1(a, 8, 4, "lantern")]),
    F(0, -10, 0, 10, -10, 0, "dark_oak_slab"), F(0, 10, 0, 10, 10, 0, "dark_oak_slab"),
    F(14, -13, 0, 18, -6, 3, "basalt"), F(16, -12, 4, 18, -8, 7, "basalt"), F(17, -11, 8, 18, -9, 9, "blackstone"), F(17, -10, 4, 17, -10, 9, "magma"),
    F(14, 6, 0, 18, 13, 3, "basalt"), F(16, 8, 4, 18, 12, 6, "basalt"), F(17, 10, 4, 17, 10, 6, "magma"),
    ...scatter(61, 14, 0, ["light_gray_carpet"], [-6, -9, 13, 9]), ...scatter(62, 6, -1, ["magma", "basalt"], [-13, -12, -7, 12]),
  ] },
  /* 7 十二年前 冬の 夜 ルミエの 小川（b08: セオと ノエ）: 雪の 岸・横に 流れる 小川と 板の 橋・石灯籠・枯れ草・雪の もみの 林 */
  fb_lumiebrook: { nm: "ルミエの 小川（冬の 夜）", g: "snow", base: "dirt", look: [8, 1, 0.5], build: () => [
    F(6, -13, -3, 9, 13, -2, "stone"), F(7, -13, -2, 8, 13, -1, "water"), ...scatter(71, 10, -1, ["cobblestone", "mossy_cobblestone", "stone"], [6, -13, 6, 13]), ...scatter(72, 8, -1, ["cobblestone", "mossy_cobblestone"], [9, -13, 9, 13]),
    S1(7, 5, -1, "packed_ice"), S1(8, -8, -1, "packed_ice"), S1(7, 11, -1, "packed_ice"),
    F(6, -5, 0, 9, -4, 0, "spruce_slab"), F(6, -6, 0, 9, -6, 0, "spruce_fence"), F(6, -3, 0, 9, -3, 0, "spruce_fence"), S1(6, -6, 1, "lantern"),
    F(-13, -2, -1, 5, -1, -1, "gravel"), S1(5, 6, 0, "cobblestone_wall"), S1(5, 6, 1, "lantern"), S1(5, -8, 0, "cobblestone_wall"), S1(5, -8, 1, "lantern"),
    ...pine(12, -9, 8, true), ...pine(14, -2, 9, true), ...pine(13, 5, 8, true), ...pine(16, 10, 9, true), ...pine(17, -12, 8, true), ...pine(11, 11, 7, true),
    ...pine(-6, -10, 7, true), ...pine(-9, 9, 8, true), ...pine(2, -11, 7, true), ...pine(3, 11, 8, true),
    ...scatter(73, 12, 0, ["deadbush", "snow_layer", "fern"], [-12, -12, 5, 12]), ...scatter(74, 8, 0, ["snow_layer", "deadbush"], [10, -12, 17, 12]),
  ] },
  /* 8 十日前 六影の 詰所（b09: 伝令と ズズ）: 石の 詰所（三方の 壁・屋根）・張り紙の 板・六影の 紫の 旗・机・寝台・武器の 棚・柵の 前庭 */
  fb_post: { nm: "六影の 詰所", g: "coarse_dirt", base: "stone", look: [11, 4, 2], build: () => [
    F(0, -7, -1, 11, 7, -1, "spruce_planks"),
    F(0, -8, 0, 12, -8, 4, "deepslate_bricks"), F(0, 8, 0, 12, 8, 4, "deepslate_bricks"), F(12, -8, 0, 12, 8, 4, "deepslate_bricks"), F(12, -3, 0, 12, -2, 2, "air"),
    ...[[0, -8], [0, 8], [6, -8], [6, 8], [12, -8], [12, 8]].map(([a, b]) => col(a, b, 0, 4, "dark_oak_log")),
    F(2, -9, 5, 13, 9, 5, "dark_oak_planks"), F(3, -8, 6, 12, 8, 6, "dark_oak_slab"), F(3, -8, 2, 4, -8, 2, "iron_bars"), F(3, 8, 2, 4, 8, 2, "iron_bars"),
    F(11, 2, 1, 11, 6, 3, "spruce_planks"), S1(11, 3, 2, "white_wool"), S1(11, 5, 2, "white_wool"), S1(11, 4, 3, "white_wool"), S1(11, 2, 2, "white_wool"),   /* 張り紙の 板 */
    F(11, -7, 1, 11, -6, 4, "purple_wool"), S1(11, -7, 0, "black_wool"),
    F(5, 3, 0, 7, 5, 0, "dark_oak_planks"), S1(6, 4, 1, "lantern"), S1(5, 3, 1, "candle"), S1(9, 4, 0, "lectern"), S1(7, 3, 1, "flower_pot"),
    F(1, 6, 0, 4, 7, 0, "spruce_planks"), F(1, 6, 1, 4, 7, 1, "red_carpet"), F(3, -7, 1, 8, -7, 1, "iron_bars"), S1(9, -6, 0, "grindstone"), F(10, -7, 0, 11, -5, 0, "barrel"), S1(1, -7, 0, "chest"),
    S1(4, -3, 4, HL), S1(4, 3, 4, HL), S1(9, 0, 4, HL),
    F(-6, -12, 0, -6, -6, 0, "spruce_fence"), F(-6, 6, 0, -6, 12, 0, "spruce_fence"), ...post(-6, -5, 2), ...post(-6, 5, 2), S1(-9, 9, 0, "hay_block"), S1(-9, 9, 1, "carved_pumpkin"),
    ...scatter(81, 10, -1, ["gravel", "dirt"], [-13, -12, -1, 12]), ...pine(-10, -10, 8), ...pine(15, 11, 8),
  ] },
  /* 9 十年前 サンダへの 山道（b11: 山案内人）: 砂利の 道・両側の 雪の 崖・奥の 雪の 斜面（雪崩の 来る 所）・身を 隠す 岩・道の 柵・目印の 石積み・崖の 上の もみ */
  fb_mtpath: { nm: "サンダへの 山道", g: "snow", base: "stone", look: [15, 0, 4], build: () => [
    F(-13, -2, -1, 12, 2, -1, "gravel"),
    F(-6, -13, 0, 18, -8, 5, "stone"), F(-2, -13, 6, 18, -10, 8, "stone"), F(-6, -7, 0, 16, -6, 2, "stone"), F(-6, -9, 6, 18, -8, 6, "snow"), F(-2, -13, 9, 18, -10, 9, "snow"), F(-6, -7, 3, 16, -6, 3, "snow"),
    F(-6, 6, 0, 18, 13, 3, "stone"), F(0, 9, 4, 18, 13, 6, "stone"), F(-6, 6, 4, 18, 8, 4, "snow"), F(0, 9, 7, 18, 13, 7, "snow"), S1(4, 6, 4, "air"), S1(10, 7, 4, "air"),
    ...[0, 1, 2, 3, 4, 5, 6, 7].map((k) => F(11 + k, -5, k, 18, 5, k, "snow")),   /* 雪崩の 斜面 */
    F(-5, -4, 0, -4, -3, 1, "stone"), F(-5, 3, 0, -4, 4, 1, "stone"), S1(-5, -4, 2, "snow_layer"), S1(-4, 4, 2, "snow_layer"),
    F(0, -3, 0, 10, -3, 0, "spruce_fence"), S1(-1, 3, 0, "cobblestone"), S1(-1, 3, 1, "cobblestone_wall"), S1(-1, 3, 2, "lantern"), S1(0, -3, 1, "lantern"),
    ...pine(2, -11, 6, true, 9), ...pine(9, -12, 7, true, 9), ...pine(5, 11, 6, true, 7), ...pine(13, 10, 6, true, 7), ...pine(-9, -9, 7, true), ...pine(-10, 9, 7, true),
    ...scatter(91, 8, 0, ["snow_layer", "deadbush"], [-12, -12, -6, 12]),
  ] },
  /* 10 四年前 らいうんの 里の 寄り合い（b11: 双子が 里を 出た 夜）: 板の 間の 寄り合い所（前が 開いた 縁側・障子・切妻の 屋根）・いろり・雪の 里の 家・石灯籠・雪の もみ */
  fb_raiun: { nm: "らいうんの 里の 寄り合い", g: "snow", base: "dirt", look: [4, 0, 1.5], build: () => [
    F(0, -6, -1, 9, 6, -1, "spruce_planks"), F(1, -5, -1, 8, -2, -1, "birch_planks"), F(1, 2, -1, 8, 5, -1, "birch_planks"), F(3, -1, -1, 5, 1, -1, "cobblestone"), S1(4, 0, -1, "campfire"),
    F(9, -6, 0, 9, 6, 3, "spruce_planks"), F(9, -4, 1, 9, -2, 2, "white_wool"), F(9, 2, 1, 9, 4, 2, "white_wool"), F(0, -6, 0, 9, -6, 3, "spruce_planks"), F(0, 6, 0, 9, 6, 3, "spruce_planks"), F(3, -6, 1, 6, -6, 2, "white_wool"), F(3, 6, 1, 6, 6, 2, "white_wool"),
    ...[[0, -6], [0, 6], [9, -6], [9, 6], [0, -3], [0, 3]].map(([a, b]) => col(a, b, 0, 3, "spruce_log")),
    F(-1, -7, 4, 10, 7, 4, "dark_oak_planks"), F(-1, -5, 5, 10, 5, 5, "dark_oak_planks"), F(-1, -3, 6, 10, 3, 6, "dark_oak_planks"), F(-1, -1, 7, 10, 1, 7, "dark_oak_slab"),
    F(-1, -7, 5, 10, -6, 5, "snow_layer"), F(-1, 6, 5, 10, 7, 5, "snow_layer"), F(-1, -5, 6, 10, -4, 6, "snow_layer"), F(-1, 4, 6, 10, 5, 6, "snow_layer"),
    S1(4, 0, 3, "chain"), S1(4, 0, 2, HL), S1(2, -4, 3, HL), S1(2, 4, 3, HL), S1(8, -4, 0, "barrel"), S1(8, 4, 0, "flower_pot"), S1(8, -5, 0, "bookshelf"),
    ...hut(-10, -13, -4, -8, 3, "spruce_planks", "dark_oak_planks", { door: [-7, -8], win: [[-9, -8]], log: "spruce_log", lit: true, cap: "snow_layer" }),
    ...hut(-10, 8, -4, 13, 3, "spruce_planks", "dark_oak_planks", { door: [-7, 8], win: [[-5, 8]], log: "spruce_log", lit: true, cap: "snow_layer" }),
    S1(-2, -5, 0, "cobblestone_wall"), S1(-2, -5, 1, "lantern"), S1(-2, 5, 0, "cobblestone_wall"), S1(-2, 5, 1, "lantern"),
    ...pine(13, -9, 8, true), ...pine(14, 0, 9, true), ...pine(13, 9, 8, true), ...pine(17, -4, 8, true), ...pine(17, 6, 9, true),
    ...scatter(101, 10, 0, ["snow_layer"], [-12, -7, -2, 7]),
  ] },
  /* 11 四十年前 竜の 見晴らし台（b13: シズクが 見た 二人）: 石の 台と 手すり・下の 谷に 竜の 骨（背骨・あばら・頭）・骨の 祭壇・ベンチ・望遠の 柱 */
  fb_dragonlook: { nm: "竜の 見晴らし台", g: "grass_block", base: "stone", look: [13, 0, -2], build: () => [
    F(-5, -9, -1, 7, 9, -1, "stone_bricks"), ...scatter(111, 10, -1, ["mossy_stone_bricks", "cracked_stone_bricks"], [-5, -9, 7, 9]),
    F(8, -13, -8, 18, 13, -1, "air"), F(8, -13, -9, 18, 13, -9, "coarse_dirt"), F(8, -13, -8, 8, 13, -1, "stone_bricks"), F(9, -13, -8, 18, -13, -1, "stone"), F(9, 13, -8, 18, 13, -1, "stone"),
    F(7, -9, 0, 7, 9, 0, "stone_brick_wall"), col(7, -9, 1, 1, "lantern"), col(7, 9, 1, 1, "lantern"), col(7, -4, 1, 1, "lantern"), col(7, 4, 1, 1, "lantern"),
    F(9, 0, -8, 18, 0, -8, LOGA("bone_block")),
    ...[11, 13, 15, 17].flatMap((a) => [F(a, -3, -7, a, -1, -7, "bone_block"), F(a, -4, -6, a, -4, -3, "bone_block"), F(a, -3, -2, a, -3, -2, "bone_block"), F(a, 1, -7, a, 3, -7, "bone_block"), F(a, 4, -6, a, 4, -3, "bone_block"), F(a, 3, -2, a, 3, -2, "bone_block")]),
    F(9, -1, -8, 10, 1, -6, "bone_block"), S1(9, -1, -7, "air"), S1(9, 1, -7, "air"), S1(10, -1, -5, "bone_block"), S1(10, 1, -5, "bone_block"), S1(10, -1, -4, "bone_block"), S1(10, 1, -4, "bone_block"),
    F(14, 6, -8, 16, 8, -8, "polished_andesite"), S1(15, 7, -7, "chiseled_stone_bricks"), S1(14, 6, -7, "candle"), S1(16, 8, -7, "candle"), ...scatter(112, 10, -8, ["bone_block", "deadbush"], [9, -12, 18, 12]),
    F(-3, -7, 0, -1, -7, 0, "spruce_slab"), F(-3, 7, 0, -1, 7, 0, "spruce_slab"), S1(5, -6, 0, "cobblestone_wall"), S1(5, -6, 1, "lightning_rod"), ...post(0, -8, 2, "stone_brick_wall"), ...post(0, 8, 2, "stone_brick_wall"),
    ...pine(-10, -10, 8), ...pine(-10, 10, 7), ...scatter(113, 8, 0, ["short_grass", "fern"], [-13, -12, -6, 12]),
  ] },
  /* 12 十年前 ルミナの 牧場（夕方）（b17: 遠い 空を 見る オルド）: 牧場の 柵・放牧地・一本木・納屋・家・水おけ・干し草・荷車 */
  fb_ranchd: { nm: "ルミナの 牧場（夕方）", g: "grass_block", base: "dirt", look: [12, 0, 2], build: () => [
    F(7, -13, 0, 7, 13, 0, "oak_fence"), S1(7, -6, 1, "oak_fence"), S1(7, -6, 2, "lantern"), S1(7, 6, 1, "oak_fence"), S1(7, 6, 2, "lantern"),
    ...tree(14, -6, 6), S1(10, 4, 0, WCAUL), S1(11, 4, 0, WCAUL), F(12, 7, 0, 13, 8, 0, "hay_block"), S1(16, -1, 0, "hay_block"), F(17, -13, 0, 18, 13, 1, "grass_block"), F(18, -13, 2, 18, 13, 2, "grass_block"),
    ...hut(-4, -13, 4, -7, 5, "spruce_planks", "dark_oak_planks", { door: [0, -7], win: [[-2, -7], [2, -7]], log: "stripped_spruce_log", lit: true }), F(-1, -7, 0, 1, -7, 2, "air"), S1(0, -9, 0, "hay_block"), S1(1, -10, 0, "hay_block"),
    ...hut(-10, 7, -3, 12, 4, "oak_planks", "spruce_planks", { door: [-6, 7], win: [[-8, 7], [-4, 7]], log: "oak_log", lit: true }), F(-9, 11, 0, -9, 11, 7, "brick_block"),
    F(-13, -2, -1, 6, 0, -1, "dirt_path"), F(-1, -6, -1, 1, -3, -1, "dirt_path"), F(4, 5, 0, 6, 5, 0, "oak_planks"), S1(4, 6, 0, "oak_fence"), S1(6, 6, 0, "oak_fence"), S1(5, 5, 1, "hay_block"),
    ...scatter(121, 12, 0, ["short_grass", "dandelion", "poppy", "short_grass"]),
  ] },
  /* 13 二十年 ほど 前の 冬の 夜 オルドの 牧場の 小屋（r0: 紐を 編む 男）: 丸太の 小屋と ひさし（灯りの 下）・雪の 放牧地の 柵・干し草・薪・雪の もみ */
  fb_ranchw: { nm: "オルドの 牧場の 小屋（冬の 夜）", g: "snow", base: "dirt", look: [12, 0, 2], build: () => [
    F(9, -7, 0, 15, 7, 3, "spruce_log"), F(10, -6, 0, 14, 6, 2, "air"), F(9, 0, 0, 9, 0, 1, "air"), F(9, -4, 1, 9, -3, 1, "glass_pane"), F(9, 3, 1, 9, 4, 1, "glass_pane"), S1(12, 0, 3, HL), F(10, -6, -1, 14, 6, -1, "spruce_planks"),
    F(8, -8, 4, 16, 8, 4, "dark_oak_planks"), F(8, -6, 5, 16, 6, 5, "dark_oak_planks"), F(8, -4, 6, 16, 4, 6, "dark_oak_planks"), F(8, -2, 7, 16, 2, 7, "dark_oak_planks"), F(8, -1, 8, 16, 1, 8, "dark_oak_slab"),
    F(8, -8, 5, 16, -7, 5, "snow_layer"), F(8, 7, 5, 16, 8, 5, "snow_layer"), F(14, -5, 4, 14, -5, 9, "cobblestone"), S1(14, -5, 10, "campfire"),
    F(2, -6, -1, 8, 6, -1, "spruce_planks"), F(2, -6, 4, 8, 6, 4, "spruce_slab"), col(2, -6, 0, 3, "spruce_log"), col(2, 6, 0, 3, "spruce_log"), S1(4, 0, 3, HL), S1(7, 4, 3, HL),
    S1(2, 3, 0, "hay_block"), F(7, -8, 0, 8, -7, 1, LOGB("spruce_log")), S1(8, 5, 0, "barrel"),
    F(-6, 8, 0, 8, 8, 0, "spruce_fence"), F(-6, 8, 0, -6, 13, 0, "spruce_fence"), F(4, -12, 0, 6, -10, 1, "hay_block"), F(4, -12, 2, 6, -10, 2, "snow_layer"),
    ...post(-3, -7, 2, "spruce_fence"), ...post(-3, 7, 2, "spruce_fence"),
    ...pine(-9, -10, 8, true), ...pine(17, -11, 8, true), ...pine(17, 11, 9, true), ...pine(-10, 11, 7, true), ...pine(12, 11, 7, true),
    ...scatter(131, 12, 0, ["snow_layer"], [-12, -12, 1, 12]),
  ] },
  /* 14 千年前 グランディアの 王の 間（b20: アルディスと 王）: 黒い 石の 大広間（列柱・高い 窓・天井・シャンデリア）・赤い じゅうたん・二段の 壇と 金の 玉座・旗 */
  fb_throne: { nm: "千年前 王の 間", g: "polished_blackstone", base: "stone", look: [11, 0, 3], build: () => [
    F(-2, -9, -1, 13, 9, -1, "deepslate_tiles"), ...scatter(141, 10, -1, ["cobbled_deepslate", "polished_deepslate"], [-2, -9, 13, 9]), F(-6, -1, 0, 6, 1, 0, "red_carpet"),
    F(-2, -10, 0, 13, -10, 10, "deepslate_bricks"), F(-2, 10, 0, 13, 10, 10, "deepslate_bricks"), F(14, -10, 0, 14, 10, 10, "deepslate_bricks"), F(-2, -10, 11, 14, 10, 11, "dark_oak_planks"),
    ...[1, 5, 9].flatMap((a) => [F(a, -10, 3, a, -10, 8, "glass_pane"), F(a, 10, 3, a, 10, 8, "glass_pane")]),
    ...[-1, 3, 7, 11].flatMap((a) => [col(a, -5, 0, 7, "polished_deepslate"), S1(a, -5, 8, "chiseled_deepslate"), S1(a, -5, 9, "soul_lantern"), col(a, 5, 0, 7, "polished_deepslate"), S1(a, 5, 8, "chiseled_deepslate"), S1(a, 5, 9, "soul_lantern")]),
    F(1, 0, 8, 1, 0, 10, "chain"), S1(1, 0, 7, HL), F(9, 0, 8, 9, 0, 10, "chain"), S1(9, 0, 7, HL),
    F(7, -4, 0, 13, 4, 0, "polished_blackstone"), F(9, -3, 1, 13, 3, 1, "polished_blackstone"), S1(11, 0, 2, "gold_block"), F(12, 0, 2, 12, 0, 4, "gold_block"), S1(11, -1, 2, "polished_blackstone_wall"), S1(11, 1, 2, "polished_blackstone_wall"),
    F(13, -6, 3, 13, -5, 8, "red_wool"), F(13, 5, 3, 13, 6, 8, "red_wool"), F(13, -1, 5, 13, 1, 7, "black_wool"), S1(13, 0, 8, "gold_block"),
    ...[[-6, -6], [-6, 6]].flatMap(([a, b]) => [S1(a, b, 0, "polished_blackstone_bricks"), S1(a, b, 1, "soul_campfire")]), F(-13, -2, -1, -3, 2, -1, "polished_blackstone_bricks"),
  ] },
  /* 15 千年前 王の 書庫（r2: トキ婆の 昔話）: 本棚の 壁・月の 窓・机と ろうそく・書見台・シャンデリア・赤い じゅうたん・巻物の 樽 */
  fb_kinglib: { nm: "千年前 王の 書庫", g: "polished_andesite", base: "stone", look: [6, -1, 1.5], build: () => [
    F(-1, -8, -1, 12, 8, -1, "dark_oak_planks"),
    F(-1, -9, 0, 13, -9, 6, "stone_bricks"), F(-1, 9, 0, 13, 9, 6, "stone_bricks"), F(13, -9, 0, 13, 9, 6, "stone_bricks"), F(-1, -9, 7, 13, 9, 7, "dark_oak_planks"),
    F(0, -8, 0, 12, -8, 3, "bookshelf"), F(0, 8, 0, 12, 8, 3, "bookshelf"), F(12, -7, 0, 12, -3, 3, "bookshelf"), F(12, 3, 0, 12, 7, 3, "bookshelf"), F(13, -2, 2, 13, 2, 5, "glass_pane"),
    F(2, -3, 0, 8, 3, 0, "red_carpet"), F(6, -1, 0, 6, 0, 0, "dark_oak_planks"), S1(6, -1, 1, "candle"), S1(6, 0, 1, "flower_pot"), S1(6, 1, 0, "lectern"), S1(10, 0, 0, "lectern"),
    F(5, 0, 5, 5, 0, 6, "chain"), S1(5, 0, 4, HL), S1(9, -5, 6, HL), S1(9, 5, 6, HL), S1(2, -5, 6, HL), S1(2, 5, 6, HL),
    S1(10, 5, 0, "decorated_pot"), F(10, -6, 0, 11, -6, 0, "barrel"), S1(11, -6, 1, "barrel"), col(-1, -5, 0, 6, "quartz_pillar"), col(-1, 5, 0, 6, "quartz_pillar"),
    ...[[-5, -6], [-5, 6]].flatMap(([a, b]) => [S1(a, b, 0, "stone_brick_wall"), S1(a, b, 1, "lantern")]), ...tree(-10, -10, 6), ...tree(-10, 10, 6),
  ] },
  /* 16 四年前 収穫祭（r0: ミミと 台本の 女の子）: 板の 舞台と 赤い 幕・パンの 屋台（日よけ・パン・灯り）・かぼちゃ・干し草・祭りの 柱と 飾り布・木 */
  fb_harvest: { nm: "収穫祭の 舞台の 袖", g: "grass_block", base: "dirt", look: [7, 0, 2.5], build: () => [
    F(-6, -12, -1, 12, 12, -1, "coarse_dirt"), F(-13, -2, -1, 4, 2, -1, "dirt_path"), ...scatter(161, 10, -1, ["grass_block", "dirt_path"], [-6, -12, 12, 12]),
    F(5, -5, 0, 10, 5, 0, "spruce_planks"), F(10, -5, 1, 10, 5, 5, "red_wool"), F(6, -5, 1, 9, -5, 4, "red_wool"), F(6, 5, 1, 9, 5, 4, "red_wool"), col(5, -5, 1, 5, "oak_log"), col(5, 5, 1, 5, "oak_log"), F(5, -5, 6, 10, 5, 6, "yellow_wool"),
    S1(9, -3, 1, "lantern"), S1(9, 3, 1, "lantern"), S1(9, 0, 1, "hay_block"),
    col(-1, -11, 0, 2, "oak_fence"), col(-1, -7, 0, 2, "oak_fence"), col(3, -11, 0, 2, "oak_fence"), col(3, -7, 0, 2, "oak_fence"), F(-2, -12, 3, 4, -6, 3, "orange_wool"), F(-2, -10, 3, 4, -10, 3, "white_wool"), F(-2, -8, 3, 4, -8, 3, "white_wool"),
    F(-1, -7, 0, 3, -7, 0, "barrel"), S1(0, -7, 1, "cake"), S1(1, -7, 1, "hay_block"), S1(2, -7, 1, "decorated_pot"), S1(1, -9, 2, HL),   /* パンの 屋台 */
    ...[-4, 12].flatMap((a) => [col(a, -6, 0, 3, "oak_fence"), S1(a, -6, 4, "lantern"), col(a, 6, 0, 3, "oak_fence"), S1(a, 6, 4, "lantern")]), F(-3, -6, 3, 11, -6, 3, "red_wool"), F(-3, 6, 3, 11, 6, 3, "yellow_wool"),
    F(-6, 8, 0, -5, 9, 0, "hay_block"), S1(-5, 8, 1, "pumpkin"), S1(11, 8, 0, "pumpkin"), S1(12, -8, 0, "pumpkin"), F(13, 8, 0, 14, 9, 0, "hay_block"), S1(-7, -8, 0, "composter"),
    ...tree(-10, -10, 6), ...tree(16, 10, 6, "birch_log", "birch_leaves"), ...tree(16, -10, 7), ...scatter(162, 8, 0, ["short_grass", "dandelion"], [-13, -12, -7, 12]),
  ] },
  /* 17 四十年 ほど 前 祭りの 原っぱと 村の 門（r0: 若い オルドの 旅立ち）: 丸太の 門と 鐘・北へ のびる 道・柵・焚き火・祭りの 柱と 飾り布・花の 原っぱ・丘 */
  fb_departure: { nm: "祭りの 原っぱと 村の 門", g: "grass_block", base: "dirt", look: [11, 0, 3], build: () => [
    F(2, -2, -1, 18, 2, -1, "dirt_path"), F(-13, -1, -1, 1, 1, -1, "dirt_path"),
    col(11, -3, 0, 4, "oak_log"), col(11, 3, 0, 4, "oak_log"), F(11, -4, 5, 11, 4, 5, LOGB("oak_log")), S1(11, 0, 4, "bell"), S1(11, -2, 4, HL), S1(11, 2, 4, HL),
    F(11, -13, 0, 11, -4, 0, "oak_fence"), F(11, 4, 0, 11, 13, 0, "oak_fence"),
    S1(2, -8, 0, "campfire"), ...[[1, -9], [3, -9], [1, -7], [3, -7]].map(([a, b]) => S1(a, b, 0, "cobblestone_wall")),
    ...[-2, 8].flatMap((a) => [col(a, -6, 0, 3, "oak_fence"), S1(a, -6, 4, "lantern"), col(a, 6, 0, 3, "oak_fence"), S1(a, 6, 4, "lantern")]), F(-1, -6, 3, 7, -6, 3, "yellow_wool"), F(-1, 6, 3, 7, 6, 3, "red_wool"),
    F(-6, 8, 0, -4, 9, 0, "oak_planks"), S1(-3, 8, 0, "barrel"), F(-7, -10, 0, -6, -10, 0, "hay_block"),
    ...tree(-9, -11, 6), ...tree(15, -9, 6), ...tree(16, 9, 7, "birch_log", "birch_leaves"), F(15, -13, 0, 18, -4, 1, "grass_block"), F(16, 4, 0, 18, 13, 2, "grass_block"), S1(14, -2, 0, "cobblestone_wall"), S1(14, 2, 0, "cobblestone_wall"),
    ...scatter(171, 18, 0, ["poppy", "dandelion", "oxeye_daisy", "short_grass", "azure_bluet"]),
  ] },
  /* 18 十年前 乾いた 村の 外れ（r2: 若い ドルフと バルガ）: 砂と ひび割れた 土・砂岩の 家・涸れ井戸・水の 樽・日よけ・やし・枯れ草・サボテン・砂丘 */
  fb_dryvil: { nm: "乾いた 村の 外れ", g: "sand", base: "sandstone", look: [11, -8, 2], build: () => [
    ...scatter(181, 20, -1, ["packed_mud", "coarse_dirt", "smooth_sandstone"]), F(-13, -1, -1, 18, 1, -1, "coarse_dirt"),
    ...hut(-2, -12, 4, -7, 4, "sandstone", "cut_sandstone", { door: [1, -7], win: [[3, -7]], pane: "iron_bars", lit: true }), F(0, -6, 3, 2, -6, 3, "orange_wool"),
    ...hut(8, -11, 14, -6, 4, "sandstone", "cut_sandstone", { door: [11, -6], win: [[9, -6], [13, -6]], pane: "iron_bars", lit: true }), F(10, -5, 3, 12, -5, 3, "white_wool"), col(10, -5, 0, 2, "birch_fence"), col(12, -5, 0, 2, "birch_fence"),
    ...hut(9, 6, 15, 11, 4, "smooth_sandstone", "cut_sandstone", { door: [12, 6], win: [[10, 6]], pane: "iron_bars", lit: true }),
    F(6, -5, 0, 8, -3, 0, "sandstone"), S1(7, -4, 0, "air"), S1(7, -4, -1, "air"), col(6, -5, 1, 1, "birch_fence"), col(8, -3, 1, 1, "birch_fence"), F(6, -5, 2, 8, -3, 2, "birch_slab"),   /* 涸れ井戸 */
    F(6, 4, 0, 7, 5, 0, "barrel"), S1(7, 4, 1, "barrel"), S1(5, 6, 0, WCAUL), F(2, 7, 0, 4, 7, 0, "birch_planks"), S1(2, 8, 0, "birch_fence"), S1(4, 8, 0, "birch_fence"),
    ...tree(-8, 9, 6, "jungle_log", "jungle_leaves"), ...tree(17, -1, 7, "jungle_log", "jungle_leaves"), F(15, -13, 0, 18, -3, 1, "sand"), F(16, 2, 0, 18, 13, 1, "sand"), F(17, -13, 2, 18, -5, 3, "sand"),
    ...scatter(182, 10, 0, ["deadbush", "cactus", "deadbush"]), ...[-6, 6].flatMap((b) => post(-4, b, 2, "birch_fence")),
  ] },
  /* 19 千年前 リールの 川辺（裏5: サヤと エンマ）: 石の 岸と 石段・横に 流れる 川・すいれん・柳の 木・岸の 灯り・木の ベンチ・向こう岸の 鳥居 */
  fb_river: { nm: "千年前 リールの 川辺", g: "grass_block", base: "dirt", look: [9, 0, 0], build: () => [
    F(7, -13, -3, 11, 13, -3, "gravel"), F(7, -13, -2, 11, 13, -1, "water"), F(6, -13, -1, 6, 13, -1, "stone_bricks"), F(5, -3, -1, 6, 3, -1, "stone_bricks"), F(12, -13, -1, 12, 13, -1, "mossy_stone_bricks"),
    ...scatter(191, 8, -1, ["mossy_stone_bricks", "cracked_stone_bricks"], [5, -13, 6, 13]), S1(8, -5, 0, "waterlily"), S1(9, 4, 0, "waterlily"), S1(10, -1, 0, "waterlily"), S1(8, 9, 0, "waterlily"),
    ...tree(14, -8, 6), ...tree(15, 4, 7), ...tree(13, 11, 5), col(16, -3, 0, 4, "red_nether_brick"), col(16, 3, 0, 4, "red_nether_brick"), F(16, -4, 5, 16, 4, 5, "red_nether_brick"), S1(16, 0, 4, HL),
    ...post(5, -6, 2, "oak_fence"), ...post(5, 6, 2, "oak_fence"), F(-13, -1, -1, 4, 1, -1, "mossy_cobblestone"), F(0, -9, 0, 2, -9, 0, "oak_slab"), ...tree(-2, -11, 6), ...tree(-9, 9, 7, "birch_log", "birch_leaves"),
    ...scatter(192, 14, 0, ["short_grass", "fern", "allium", "short_grass", "lily_of_the_valley"], [-12, -12, 5, 12]), ...scatter(193, 8, 0, ["short_grass", "fern"], [13, -12, 17, 12]),
  ] },
  /* 20 千年前 こもれびの 森（裏6: 冠の 剣士と エンマ）: こけの 地面・2×2 の 古い 大木と 天井の 葉・光る キノコ灯・こけむした 石の 祠・稽古の 杭・石灯籠・しだ */
  fb_oldforest: { nm: "千年前 こもれびの 森", g: "moss_block", base: "dirt", look: [9, 0, 1.5], build: () => [
    ...scatter(201, 24, -1, ["podzol", "coarse_dirt", "rooted_dirt", "grass_block"]),
    ...big(9, -9, 10), ...big(12, 6, 10), ...big(-4, -11, 9), ...big(-5, 9, 9), ...big(16, -2, 10), S1(10, -6, 9, "shroomlight"), S1(13, 3, 9, "shroomlight"), S1(15, 0, 9, "shroomlight"),
    F(9, -1, 0, 9, 1, 0, "mossy_cobblestone"), S1(9, 0, 1, "mossy_stone_bricks"), S1(9, 0, 2, "candle"), col(7, 4, 0, 1, "stripped_oak_log"), S1(7, 4, 2, "hay_block"), col(7, -5, 0, 1, "stripped_oak_log"),
    ...[[5, -6], [5, 6]].flatMap(([a, b]) => [S1(a, b, 0, "mossy_cobblestone_wall"), S1(a, b, 1, "lantern")]),
    ...scatter(202, 16, 0, ["fern", "brown_mushroom", "short_grass", "red_mushroom", "fern"]), ...scatter(203, 10, 0, ["moss_carpet"], [-4, -4, 11, 4], false),
  ] },
  /* ---- 第127版(fb2): 別視点（そのころ）の 場所と、新しい 回想 ---- */
  /* 21 ルミナの 門の 内側（本16 そのころ）: 石の 門と 城壁・開いた 門・石畳の 通り・パンの かご台・逃げて きた 人の 荷・灯り */
  fb_lumgate: { nm: "ルミナの 門の 内側", g: "grass_block", base: "dirt", look: [10, 0, 3], build: () => [
    F(-6, -12, -1, 12, 12, -1, "cobblestone"), F(-13, -2, -1, 18, 2, -1, "stone_bricks"), ...scatter(211, 12, -1, ["mossy_cobblestone", "gravel", "andesite"], [-6, -12, 12, 12]),
    F(10, -13, 0, 11, -3, 7, "stone_bricks"), F(10, 3, 0, 11, 13, 7, "stone_bricks"), F(10, -13, 8, 10, 13, 8, "stone_brick_wall"), F(10, -3, 5, 11, 3, 7, "stone_bricks"), F(10, -2, 0, 11, 2, 4, "air"),
    col(9, -3, 0, 6, "chiseled_stone_bricks"), col(9, 3, 0, 6, "chiseled_stone_bricks"), S1(9, -2, 4, HL), S1(9, 2, 4, HL), F(10, -1, 7, 10, 1, 7, "blue_wool"),
    F(12, -2, -1, 18, 2, -1, "dirt_path"), ...tree(15, -8, 6), ...tree(16, 8, 6),
    F(4, 6, 0, 7, 6, 0, "barrel"), S1(5, 6, 1, "hay_block"), S1(6, 6, 1, "cake"), col(4, 8, 0, 2, "oak_fence"), col(7, 8, 0, 2, "oak_fence"), F(3, 6, 3, 8, 8, 3, "orange_wool"), F(3, 7, 3, 8, 7, 3, "white_wool"), S1(5, 7, 2, HL),
    F(5, -7, 0, 6, -6, 0, "white_wool"), S1(7, -7, 0, "barrel"), S1(4, -8, 0, "hay_block"), S1(8, -9, 0, "white_wool"),
    ...hut(-6, -13, 2, -8, 5, "oak_planks", "dark_oak_planks", { door: [-2, -8], win: [[-4, -8], [0, -8]], log: "oak_log", lit: true }), ...hut(-6, 9, 2, 13, 5, "spruce_planks", "dark_oak_planks", { door: [-2, 9], win: [[0, 9]], log: "spruce_log", lit: true }),
    ...post(-4, -5, 3, "oak_fence"), ...post(-4, 5, 3, "oak_fence"),
  ] },
  /* 22 ソウラの 墓地と 霊廟の 前（本16 そのころ）: 石の 霊廟（柱と 戸口）・墓石の 列・鉄の 柵・ろうそく・花・糸杉 */
  fb_soura: { nm: "ソウラの 霊廟の 前", g: "grass_block", base: "dirt", look: [13, 0, 3], build: () => [
    F(-13, -1, -1, 10, 1, -1, "gravel"), ...scatter(221, 10, -1, ["coarse_dirt", "podzol"]),
    F(11, -6, 0, 16, 6, 5, "stone_bricks"), F(12, -5, 0, 15, 5, 4, "air"), F(10, -7, 6, 17, 7, 6, "stone_brick_slab"), F(11, -5, 7, 16, 5, 7, "chiseled_stone_bricks"), F(11, -1, 0, 11, 1, 3, "air"), F(16, -1, 1, 16, 1, 3, "polished_deepslate"),
    ...[-5, -3, 3, 5].map((b) => col(10, b, 0, 5, "quartz_pillar")), S1(10, -2, 4, HL), S1(10, 2, 4, HL), S1(13, 0, 4, HSL),
    S1(5, 0, 0, "mossy_cobblestone_wall"), S1(5, 0, 1, "stone_brick_slab"), S1(4, -1, 0, "candle"), S1(4, 1, 0, "flower_pot"),
    ...[[2, -7], [5, -7], [8, -7], [2, 7], [5, 7], [8, 7], [-1, -9], [-1, 9], [7, -4], [7, 4]].flatMap(([a, b]) => [S1(a, b, 0, "cobblestone_wall"), S1(a, b, 1, "stone_brick_slab")]),
    F(-6, -12, 0, 18, -12, 1, "iron_bars"), F(-6, 12, 0, 18, 12, 1, "iron_bars"), ...[[-3, -10], [-3, 10], [12, -10], [12, 10]].map(([a, b]) => F(a - 1, b - 1, 3, a + 1, b + 1, 6, "spruce_leaves")), ...[[-3, -10], [-3, 10], [12, -10], [12, 10]].map(([a, b]) => col(a, b, 0, 6, "spruce_log")),
    ...scatter(222, 10, 0, ["poppy", "oxeye_daisy", "short_grass", "lily_of_the_valley"]), ...post(-5, -4, 2, "dark_oak_fence", "soul_lantern"), ...post(-5, 4, 2, "dark_oak_fence", "soul_lantern"),
  ] },
  /* 23 沈んだ 神殿の 前（裏1・裏8 そのころ）: 岩場の 浅瀬・水の 底の 石の 女（像）・折れた 海の 石の 柱・神殿の 石段と 門・海の 灯り */
  fb_sunken: { nm: "沈んだ 神殿の 前", g: "sand", base: "sandstone", look: [9, 0, -1], build: () => [
    F(-13, -13, -1, 5, 13, -1, "sand"), F(1, -4, -1, 5, 4, -1, "stone"), F(2, -2, 0, 3, -1, 0, "stone"), F(4, 2, 0, 5, 3, 0, "mossy_cobblestone"), ...scatter(231, 10, -1, ["gravel", "stone", "andesite"], [-13, -13, 5, 13]),
    F(6, -13, -4, 18, 13, -4, "sand"), F(6, -13, -3, 18, 13, -1, "water"), F(6, -13, -1, 6, 13, -1, "stone"), S1(6, 0, -1, "water"), S1(6, 1, -1, "water"), S1(6, -1, -1, "water"),
    F(9, 0, -3, 9, 0, -2, "stone"), S1(9, 0, -1, "stone_brick_wall"), S1(9, 1, -3, "stone"), S1(10, 0, -3, "stone"),   /* 水の 底の 石の 女 */
    ...[[10, -5, 1], [10, 5, 3], [13, -3, 4], [13, 3, 2], [16, -6, 5], [16, 6, 4]].map(([a, b, h]) => F(a, b, -3, a, b, h, "prismarine_bricks")), S1(10, 5, 4, "sea_lantern"), S1(13, -3, 5, "sea_lantern"),
    F(15, -4, -3, 18, 4, -3, "dark_prismarine"), F(16, -4, -2, 18, 4, -2, "dark_prismarine"), F(17, -4, -1, 18, 4, 4, "prismarine_bricks"), F(17, -2, -1, 17, 2, 2, "dark_prismarine"), F(18, -4, 5, 18, 4, 5, "prismarine_brick_slab"),
    S1(8, -6, -3, "sea_lantern"), S1(12, 7, -3, "sea_lantern"), S1(11, -2, -3, "sea_lantern"), ...scatter(232, 12, -3, ["seagrass", "prismarine", "gravel"], [7, -12, 15, 12], false),
    ...post(0, -6, 2, "spruce_fence"), ...post(0, 6, 2, "spruce_fence"), ...dead(-6, -9, 4, "birch_log"), ...scatter(233, 8, 0, ["deadbush", "short_grass"], [-12, -12, 0, 12]),
  ] },
  /* 24 森の さらに 奥（r1 そのころ）: 暗い 大木の 森・倒れた 木・こけの 岩・キノコ・六影の 小さな 焚き火 */
  fb_deepwood: { nm: "森の さらに 奥", g: "podzol", base: "dirt", look: [8, 0, 1.5], build: () => [
    ...scatter(241, 20, -1, ["moss_block", "coarse_dirt", "rooted_dirt"]),
    ...big(8, -9, 10), ...big(11, 5, 10), ...big(-4, -10, 9), ...big(-5, 8, 9), ...big(15, -2, 10), ...pine(1, 10, 9), ...pine(2, -12, 9),
    F(8, -5, 0, 13, -5, 0, LOGA("dark_oak_log")), F(9, 2, 0, 9, 3, 1, "mossy_cobblestone"), S1(10, 3, 0, "mossy_cobblestone"), S1(8, -2, 0, "campfire"), S1(7, -3, 0, "barrel"), S1(9, -1, 0, "purple_wool"),
    S1(6, 4, 0, "red_mushroom"), ...scatter(242, 18, 0, ["fern", "brown_mushroom", "short_grass", "fern", "red_mushroom"]), ...scatter(243, 8, 0, ["moss_carpet"], [-4, -4, 11, 4], false),
  ] },
  /* 25 十二年前の 冬 オルドの 牧場の 小屋の 中（本19: 幼なじみが 朝まで 名を 呼んだ 夜）: 板の 間・柱と 丸の 紙・寝床・いろり・窓の 雪・灯り */
  fb_ranchhut: { nm: "オルドの 牧場の 小屋の 中", g: "snow", base: "dirt", look: [4, -3, 1.2], build: () => [
    F(0, -6, -1, 10, 6, -1, "spruce_planks"), F(0, -7, 0, 10, -7, 3, "spruce_log"), F(0, 7, 0, 10, 7, 3, "spruce_log"), F(11, -7, 0, 11, 7, 3, "spruce_log"),
    F(3, -7, 1, 4, -7, 2, "glass_pane"), F(7, 7, 1, 8, 7, 2, "glass_pane"), F(11, -1, 1, 11, 1, 2, "glass_pane"),
    F(1, -8, 4, 12, 8, 4, "dark_oak_planks"), F(1, -6, 5, 12, 6, 5, "dark_oak_planks"), F(1, -4, 6, 12, 4, 6, "dark_oak_planks"), F(1, -2, 7, 12, 2, 7, "dark_oak_slab"), F(1, -8, 5, 12, -7, 5, "snow_layer"), F(1, 7, 5, 12, 8, 5, "snow_layer"),
    col(0, -7, 0, 3, "stripped_spruce_log"), col(0, 7, 0, 3, "stripped_spruce_log"), col(5, -3, 0, 3, "spruce_log"), S1(4, -3, 1, "white_wool"),   /* 柱と 丸の 紙 */
    F(4, 1, 0, 6, 2, 0, "white_carpet"), F(7, 1, 0, 7, 2, 0, "white_wool"), F(8, 2, -1, 8, 2, -1, "campfire"), F(7, 3, -1, 9, 3, -1, "cobblestone"),
    S1(5, 0, 3, HL), S1(9, -4, 3, HL), F(10, -6, 0, 10, -4, 0, "barrel"), S1(10, -6, 1, "flower_pot"), S1(10, 5, 0, "chest"), S1(9, 6, 0, "hay_block"), S1(10, 6, 0, "hay_block"),
    ...pine(-9, -10, 8, true), ...pine(-10, 10, 7, true), ...pine(15, -9, 8, true), ...pine(15, 9, 8, true), F(-4, -12, 0, -2, -10, 1, "hay_block"), F(-4, -12, 2, -2, -10, 2, "snow_layer"),
    ...scatter(251, 12, 0, ["snow_layer"], [-12, -12, -1, 12]), ...post(-2, -5, 2, "spruce_fence"), ...post(-2, 5, 2, "spruce_fence"),
  ] },
  /* 26 千年前 帳の 王の 座（裏7: エンマの 真相）: 黒い 石の 間・朱の 柱・帳の 棚と 鎖・玉座の 机・石の 妹・下へ 落ちる 穴（魂の 光が 引かれる）*/
  fb_enmaseat: { nm: "千年前 帳の 王の 座", g: "polished_blackstone", base: "blackstone", look: [7, -1, 1.5], build: () => [
    F(-2, -9, -1, 14, 9, -1, "polished_blackstone_bricks"), F(-6, -1, 0, 7, 1, 0, "red_carpet"),
    F(14, -9, 0, 14, 9, 8, "polished_blackstone_bricks"), F(13, -8, 0, 13, 8, 4, "bookshelf"), F(13, -8, 5, 13, 8, 5, "chain"), F(-2, -10, 0, 14, -10, 8, "polished_blackstone_bricks"), F(-2, 10, 0, 14, 10, 8, "polished_blackstone_bricks"), F(-2, -10, 9, 14, 10, 9, "dark_oak_planks"),
    F(1, -9, 0, 11, -9, 3, "bookshelf"), F(1, 9, 0, 11, 9, 3, "bookshelf"),
    ...[-1, 5, 11].flatMap((a) => [col(a, -6, 0, 8, "red_nether_brick"), col(a, 6, 0, 8, "red_nether_brick"), S1(a, -5, 5, HSL), S1(a, 5, 5, HSL)]), ...[-1, 5, 11].flatMap((a) => [S1(a, -5, 6, "red_nether_brick"), S1(a, 5, 6, "red_nether_brick")]),
    F(6, -2, 0, 6, 0, 0, "dark_oak_planks"), S1(6, -1, 1, "lectern"), S1(6, 0, 1, "candle"), S1(8, -1, 0, "polished_blackstone"), F(9, -1, 0, 9, -1, 2, "polished_blackstone"), S1(9, -1, 3, "gold_block"),
    F(9, 3, -4, 10, 4, -1, "air"), F(9, 3, -5, 10, 4, -5, "soul_soil"), S1(9, 3, -4, "soul_campfire"), F(8, 2, -1, 11, 2, -1, "chiseled_deepslate"), F(8, 5, -1, 11, 5, -1, "chiseled_deepslate"),
    F(3, -1, 7, 3, 1, 8, "chain"), S1(3, 0, 6, HSL), ...[[-6, -6], [-6, 6]].flatMap(([a, b]) => [S1(a, b, 0, "polished_blackstone_bricks"), S1(a, b, 1, "soul_campfire")]),
  ] },
  /* 27 二十年前 闘技場の 下へ 続く 石段（本19-9: オルドが 引き返す）: 石の 通路・重い 扉の 枠・下へ 降りる 段・魂の 灯り・灰（王冠の 間は 見せない）*/
  fb_crownstair: { nm: "闘技場の 下の 石段", g: "stone_bricks", base: "stone", look: [11, 0, 0.5], build: () => [
    F(3, -4, 0, 14, -4, 3, "stone_bricks"), F(3, 4, 0, 14, 4, 3, "stone_bricks"), F(14, -3, 0, 14, 3, 3, "stone_bricks"), F(5, -4, 1, 5, -4, 2, "cracked_stone_bricks"),
    col(9, -2, 0, 3, "polished_deepslate"), col(9, 2, 0, 3, "polished_deepslate"), F(9, -3, 0, 9, -3, 3, "polished_deepslate"), F(9, 3, 0, 9, 3, 3, "polished_deepslate"), F(9, -1, 3, 9, 1, 3, "polished_deepslate"),
    F(10, -1, -1, 13, 1, -1, "air"), F(11, -1, -2, 13, 1, -2, "air"), F(12, -1, -3, 13, 1, -3, "air"), S1(13, 0, -4, "soul_lantern"),
    F(5, -3, 4, 5, 3, 4, "stone_bricks"), F(11, -3, 4, 11, 3, 4, "stone_bricks"), S1(5, 0, 3, HSL), S1(8, -3, 0, "soul_lantern"),
    ...scatter(271, 9, 0, ["light_gray_carpet", "gray_carpet"], [3, -3, 8, 3], false),
  ] },
  /* 28 夢 向かい合う 二つの 牢（裏7-1: イザクの 頁と エンマの 頁）: 戸の 開いた 石の 牢（骨の 鍵・わらの 寝床）と、閉じた 黒い 牢（壁に 鍔の 輪）*/
  fb_dream: { nm: "夢 サンドリアの 地下牢", g: "deepslate_tiles", base: "stone", look: [6, 0, 1], build: () => [
    F(3, -5, 0, 9, -5, 3, "cobblestone"), F(3, -4, 0, 3, -2, 2, "iron_bars"), F(9, -4, 0, 9, -2, 2, "iron_bars"), F(4, -1, 0, 8, -1, 2, "iron_bars"), F(7, -1, 0, 7, -1, 1, "air"),
    S1(8, -4, 0, "hay_block"), S1(4, -5, 1, "chiseled_stone_bricks"), S1(5, -5, 2, "chiseled_stone_bricks"),
    F(3, 5, 0, 9, 5, 3, "polished_blackstone_bricks"), F(3, 2, 0, 3, 4, 2, "iron_bars"), F(9, 2, 0, 9, 4, 2, "iron_bars"), F(4, 1, 0, 8, 1, 2, "iron_bars"),
    S1(8, 4, 0, "soul_lantern"), S1(4, -4, 0, "lantern"),
    S1(11, 0, 0, "soul_lantern"), ...scatter(281, 8, 0, ["cobweb"], [-12, -12, 17, 12]),
  ] },
  /* 29 そのころ アルカトラス城の 封印庫（裏14-7: トトの 見張り・器の 石板）: 石の 部屋・鉄格子の 棚・鎖で つった 灯り・台座の 石板と 鎖・奥の 鉄の 扉 */
  fb_vault: { nm: "アルカトラス城の 封印庫", g: "polished_deepslate", base: "stone", look: [10, 0, 1.5], build: () => [
    F(-2, -7, -1, 14, 7, -1, "polished_deepslate"), F(0, -1, -1, 8, 1, -1, "deepslate_tiles"),
    F(-2, -8, 0, 14, -8, 6, "stone_bricks"), F(-2, 8, 0, 14, 8, 6, "stone_bricks"), F(15, -8, 0, 15, 8, 6, "stone_bricks"), F(-2, -8, 7, 15, 8, 7, "deepslate_bricks"),
    F(2, -7, 0, 12, -7, 2, "iron_bars"), F(2, 7, 0, 12, 7, 2, "iron_bars"), F(3, -7, 0, 11, -7, 0, "barrel"), F(3, 7, 0, 11, 7, 0, "barrel"),
    ...[1, 5, 9, 13].flatMap((a) => [col(a, -6, 0, 6, "polished_deepslate"), col(a, 6, 0, 6, "polished_deepslate")]),
    F(9, -1, 0, 11, 1, 0, "polished_blackstone"), S1(10, 0, 1, "chiseled_deepslate"), F(10, -1, 3, 10, -1, 6, "chain"), F(10, 1, 3, 10, 1, 6, "chain"),
    F(4, 0, 5, 4, 0, 6, "chain"), S1(4, 0, 4, HSL), S1(8, -4, 6, HSL), S1(8, 4, 6, HSL),
    F(14, -2, 0, 14, 2, 3, "iron_bars"), F(14, -1, 0, 14, 1, 2, "iron_block"),
    ...[[-4, -3], [-4, 3]].flatMap(([a, b]) => [S1(a, b, 0, "polished_blackstone_wall"), S1(a, b, 1, "soul_lantern")]), F(-13, -2, -1, -3, 2, -1, "stone_bricks"),
  ] },
};
export const FB_SETS = SETS;
for (const k of Object.keys(SETS)) facBig(`fbs_${k}`, { pad: 1, box: FB_BOX, H: SETS[k].H || 12, D: [36], look: SETS[k].look, build: () => SETS[k].build() });   /* 施設の 表に 登録（ほかの 施設が この 四角を よける）*/

/* ---------- 置く 場所 ---------- */
const J = (k) => { try { return JSON.parse(world.getDynamicProperty(k) || "null"); } catch { return null; } };
const P_ = (k, v) => { try { world.setDynamicProperty(k, v === undefined ? undefined : JSON.stringify(v)); } catch {} };
const card = (f) => (Math.abs(f.x) >= Math.abs(f.z) ? { x: Math.sign(f.x) || 1, z: 0 } : { x: 0, z: Math.sign(f.z) || 1 });
const W = (o, f, a, b) => ({ x: o.x + a * f.x - b * f.z, z: o.z + a * f.z + b * f.x });
const rect = (o, f, B, m = 0) => { const p0 = W(o, f, B[0], B[1]), p1 = W(o, f, B[2], B[3]); return [Math.min(p0.x, p1.x) - m, Math.min(p0.z, p1.z) - m, Math.max(p0.x, p1.x) + m, Math.max(p0.z, p1.z) + m]; };
const hit = (A, B) => !(B[0] > A[2] || B[2] < A[0] || B[1] > A[3] || B[3] < A[1]);
const MADE = /planks|brick|cobble|glass|wool|concrete|fence|door|slab|stairs|_wall$|lantern|torch|bed$|chest|barrel|path|farmland|carpet|quartz|smooth_|polished|chiseled|cut_|lamp|bookshelf|stripped|hay|anvil|furnace|crafting|lectern|campfire|bell|banner|sign|ladder|rail|chain|iron_bars|scaffold|glazed|lodestone|loom|smoker|cauldron|composter|trapdoor|pane|frame|pot$|candle|beacon|sea_lantern|wool|mrpg:|bone_block|gold_block|tiles/;
function townBad(q, rT, rC) {
  for (const t of TOWNS) { try { const g = getTown(t.id), w = g && g.built ? g : townPos(t); if (w && Math.hypot(w.x - q.x, w.z - q.z) < rT) return true; } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) { try { const c = castleSpot(i); if (c && Math.hypot(c.x - q.x, c.z - q.z) < rC) return true; } catch {} try { for (const L of landSites(i)) if (Math.hypot(L.x - q.x, L.z - q.z) < 26) return true; } catch {} }
  return false;
}
function facHit(R, key) {
  try { for (const k of J("mrpg:epdeco:faclist") || []) { if (k === key) continue; const v = J(`mrpg:epdeco:${k}at`), s = v && (__fac.SHAPES[v.k] || __fac.BIG[v.k]); if (!s || !Array.isArray(v.o) || Math.hypot(v.o[0] - R[0], v.o[2] - R[1]) > 160) continue; if (hit(R, rect({ x: v.o[0], z: v.o[2] }, { x: v.f[0], z: v.f[1] }, s.box, 1))) return true; } } catch {}
  return false;
}
/* 地面を 5×5 か所 見る: 高さが そろい、水・人の 建てた もの が ない */
function ground(dim, o, f, y0, dy) {
  const ys = []; let wet = 0;
  for (const a of [-12, -4, 3, 10, 17]) for (const b of [-12, -6, 0, 6, 12]) {
    const q = W(o, f, a, b); let g = null; try { g = groundY(dim, q.x, q.z, y0); } catch {} if (typeof g !== "number" || Math.abs(g - y0) > dy) return null;
    let d = null; try { d = dim.getBlock({ x: q.x, y: g - 1, z: q.z }); } catch {} if (!d) return null; if (d.isLiquid || /water|lava|ice/.test(d.typeId)) { if (++wet > 2) return null; } else if (MADE.test(d.typeId)) return null;
    for (let y = g; y <= g + 8; y++) { let u = null; try { u = dim.getBlock({ x: q.x, y, z: q.z }); } catch {} if (u && !u.isAir && MADE.test(u.typeId)) return null; if (u && u.isLiquid && y === g) { if (++wet > 2) return null; } }
    ys.push(g);
  }
  ys.sort((a, b) => a - b); return ys[ys.length >> 1];
}
function findSite(p, S, key) {
  const dim = p.dimension, C = S.P, y0 = Math.floor(C.y), a0 = Math.atan2(S.f.z, S.f.x);
  let PL = [], tries = 0; try { PL = world.getAllPlayers().map((q) => q.location); } catch {}
  for (const tier of [0, 1]) for (const d of [36, 44, 52]) for (let k = 0; k < 16; k++) {
    const t = a0 + (((k + 1) >> 1) * (k & 1 ? 1 : -1) * Math.PI) / 8, dir = { x: Math.cos(t), z: Math.sin(t) }, f = card(dir);
    const cc = { x: C.x + dir.x * d, z: C.z + dir.z * d }, o = { x: Math.floor(cc.x - f.x * 2.5), z: Math.floor(cc.z - f.z * 2.5) };
    const R = rect(o, f, FB_BOX, 2), cs = [W(o, f, FB_BOX[0], FB_BOX[1]), W(o, f, FB_BOX[0], FB_BOX[3]), W(o, f, FB_BOX[2], FB_BOX[1]), W(o, f, FB_BOX[2], FB_BOX[3]), cc];
    if (cs.some((q) => townBad(q, tier ? 0 : 44, tier ? 40 : 62))) continue;
    if (tier && townBad(cc, 30, 0)) continue;
    if (C.x >= R[0] - 6 && C.x <= R[2] + 6 && C.z >= R[1] - 6 && C.z <= R[3] + 6) continue;
    if (PL.some((l) => l.x >= R[0] && l.x <= R[2] + 1 && l.z >= R[1] && l.z <= R[3] + 1)) continue;
    if (facHit(R, key)) continue;
    if (++tries > 40) return null;   /* 地面を 見る のは 40 か所まで（重く しない）*/
    const y = ground(dim, o, f, y0, tier ? 9 : 6); if (y === null) continue;
    return { o: { x: o.x, y, z: o.z }, f };
  }
  return null;
}
/* ---------- 建てる（tick 数は 前と 同じ・1 tick の 量を ならす）---------- */
const FBCAP = 4096;   /* 第128版(M2): 回想セットの 1 tick に 置く ブロックは 4096 まで（暗転の 中なので tick が のびても 見えない）*/
function cmds(ops, o, f) {
  const out = [], ax = f.x ? ['"x"', '"z"'] : ['"z"', '"x"'];
  for (const op of ops) { if (!op || op[0] !== "f") continue; const [, a0, b0, h0, a1, b1, h1, bl0, m] = op; if (!bl0) continue; const bl = String(bl0).replace(/AXA/g, ax[0]).replace(/AXB/g, ax[1]);
    const da = Math.abs(a1 - a0) + 1, db = Math.abs(b1 - b0) + 1, dh = Math.abs(h1 - h0) + 1;
    if (da * db * dh > FBCAP && !/hollow|outline/.test(m || "")) { const sa = a1 >= a0 ? 1 : -1, st = Math.max(1, Math.floor(FBCAP / (db * dh))), H0 = Math.min(h0, h1), H1 = Math.max(h0, h1), hs = st * db * dh > FBCAP ? Math.max(1, Math.floor(FBCAP / db)) : dh; for (let a = a0; sa > 0 ? a <= a1 : a >= a1; a += st * sa) { const ae = sa > 0 ? Math.min(a1, a + st - 1) : Math.max(a1, a - st + 1), p0 = W(o, f, a, b0), p1 = W(o, f, ae, b1); for (let h = H0; h <= H1; h += hs) out.push(`fill ${p0.x} ${o.y + h} ${p0.z} ${p1.x} ${o.y + Math.min(H1, h + hs - 1)} ${p1.z} ${bl}${m ? ` ${m}` : ""}`); } continue; }   /* 第128版(M2): 4096 を こえる fill は 分ける */
    const p0 = W(o, f, a0, b0), p1 = W(o, f, a1, b1); out.push(`fill ${p0.x} ${o.y + h0} ${p0.z} ${p1.x} ${o.y + h1} ${p1.z} ${bl}${m ? ` ${m}` : ""}`); }
  return out;
}
/* 第128版(FIXA): 上を 空ける fill は 3段ずつに 分ける（1本 12,818 → 3,000 前後。形は 同じ）*/
const AIRS = (a0, b0, a1, b1, H) => { const L = []; for (let h = 0; h <= H; h += 3) L.push(F(a0 - 1, b0 - 1, h, a1 + 1, b1 + 1, Math.min(H, h + 2), "air")); return L; };
export function fbOps(key) {   /* 足もとを ならす（穴・水を うめ、上を 空ける）＋ セット */
  const s = SETS[key]; if (!s) return []; const [a0, b0, a1, b1] = FB_BOX, H = s.H || 12, base = s.base || "dirt";
  return [F(a0 - 1, b0 - 1, -8, a1 + 1, b1 + 1, -4, base, "replace air"), F(a0 - 1, b0 - 1, -8, a1 + 1, b1 + 1, -4, base, "replace water"), F(a0 - 1, b0 - 1, -3, a1 + 1, b1 + 1, -2, base), F(a0 - 1, b0 - 1, -1, a1 + 1, b1 + 1, -1, s.g || "grass_block")].concat(AIRS(a0, b0, a1, b1, H), s.build());
}
const Q = []; let QI = false;
/* 第128版(FIXA): 1 tick に 置く 量（ブロック数）を ならす。建ち終わる tick 数は 前と 同じ（40 本ずつ）に して、その tick 数で 建ち終わる いちばん 小さい 量を 1 tick の 上限に する（小さな fill は 1 tick 120 本まで）。上限は 建てる とき 1回だけ 計る */
const VOL = (c) => { const m = /^fill (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+)/.exec(c); return m ? (Math.abs(m[4] - m[1]) + 1) * (Math.abs(m[5] - m[2]) + 1) * (Math.abs(m[6] - m[3]) + 1) : 1; };
function capOf(V) { const T = Math.ceil(V.length / 40), fits = (C) => { let t = 0, i = 0; while (i < V.length) { if (++t > T) return false; let n = 0, s = 0; while (i < V.length && n < 120) { if (n > 0 && s + V[i] > C) break; s += V[i]; n++; i++; } } return true; }; let lo = Math.max(1, ...V), hi = V.reduce((a, b) => a + b, 0); while (lo < hi) { const m = (lo + hi) >> 1; if (fits(m)) hi = m; else lo = m + 1; } return Math.min(lo, Math.max(FBCAP, ...V)); }   /* 第128版(M2): 4096 まで */
function qTick() { QI = false; let n = 0, v = 0; while (Q.length && n < 120) { const q = Q[0], cv = q.V[q.i]; if (n > 0 && v + cv > q.cap) break; v += cv; try { q.dim.runCommand(q.L[q.i]); } catch {} q.i++; n++; if (q.i >= q.L.length) { Q.shift(); try { q.done(); } catch {} } } if (Q.length && !QI) { QI = true; system.runTimeout(qTick, 1); } }
function stream(dim, L) { return new Promise((done) => { if (!L.length) return done(); const V = L.map(VOL); Q.push({ dim, L, V, cap: capOf(V), i: 0, done }); if (!QI) { QI = true; qTick(); } }); }
export const fbBusy = () => Q.length > 0;
/* 回想の 前に 呼ぶ（重い 探しは ここ 1回）。返す: frame（V に 入れる 原点・向き・at）・build()（暗い 中で 建てる。済んで いれば すぐ）・hide/show（まわりの 町の 人・動物）・look・nm */
export function fbPrep(p, key, S) {
  const s = SETS[key]; if (!s || !S || !S.P || !S.f || !p) return null;
  const dim = p.dimension; try { if (dim.id !== "minecraft:overworld") return null; } catch { return null; }
  const kind = `fbs_${key}`; let v = J(`mrpg:epdeco:${key}at`), need = false;
  if (!(v && Array.isArray(v.o) && v.k === kind && v.v === VER && Math.hypot(v.o[0] - S.P.x, v.o[2] - S.P.z) <= 70)) {
    const R = findSite(p, S, key); if (!R) return null; need = true;
    const lk = W(R.o, R.f, s.look[0], s.look[1]);
    v = { x: lk.x + 0.5, y: R.o.y + s.look[2], z: lk.z + 0.5, o: [R.o.x, R.o.y, R.o.z], f: [R.f.x, R.f.z], k: kind, r: 0, v: VER };
  }
  const o = { x: v.o[0], y: v.o[1], z: v.o[2] }, f = { x: v.f[0], z: v.f[1] }, P = { x: o.x + 0.5, y: o.y, z: o.z + 0.5 };
  const at = (a, b = 0, dy = 0) => ({ x: P.x + f.x * a - f.z * b, y: P.y + dy, z: P.z + f.z * a + f.x * b });
  const hid = [];
  return {
    key, nm: s.nm, look: s.look, frame: { P, f: { x: f.x, z: f.z }, at }, rect: rect(o, f, FB_BOX), o, fv: f,
    async build() { if (!need) return; need = false; P_(`mrpg:epdeco:${key}at`, v); try { const L = J("mrpg:epdeco:faclist") || []; if (!L.includes(key)) { L.push(key); P_("mrpg:epdeco:faclist", L); } } catch {} await stream(dim, cmds(fbOps(key), o, f)); },
    hide() { const c = at(2.5, 0); try { for (const e of dim.getEntities({ location: c, maxDistance: 22 })) { if (e.typeId === "minecraft:player" || e.typeId === "minecraft:item" || Math.hypot(e.location.x - c.x, e.location.z - c.z) > 22) continue; try { if (e.hasTag("mrpg_saga") || e.hasTag("mrpg_cine") || e.hasTag("mrpg_offhid") || e.getEffect("invisibility")) continue; e.addEffect("invisibility", 20 * 300, { showParticles: false }); hid.push({ e, nm: e.nameTag }); e.nameTag = ""; } catch {} } } catch {} },
    show() { for (const { e, nm } of hid.splice(0)) try { e.removeEffect("invisibility"); e.nameTag = nm; } catch {} },
  };
}
