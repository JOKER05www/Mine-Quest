// 第124版: 世界地図（だいじなもの k_wmap）。11の 地方と 今いる 地方、その 地方の 町・城・ステージ・洞くつ・遺跡の 方角と きょり
// 選ぶと コンパスの 案内先に なる。物語で まだ 行けない 地方は「まだ 行けない」。幼なじみが コンパスと いっしょに くれる
import { world, system } from "@minecraft/server";
import { ITEMS } from "./data.js";
import { load, save } from "./store.js";
import { choose, notice, paged, ICON, giveItem } from "./ui.js";
import { WREGIONS, regionIdxAt } from "./worldmap.js";
import { qs } from "./quest.js";
import { places, setTarget, dirName, arrowFor } from "./navi.js";
import { openUpTo, HEROES, heroType, hasKey, heroAway } from "./saga.js";

export const WMAP = "k_wmap";
const fmt = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1)}km` : `${n}m`);
const KN = { town: "町", castle: "城", land: "ステージ", ruin: "遺跡" };
const regOfPlace = (x) => (typeof x.reg === "number" ? x.reg : regionIdxAt({ x: x.x, y: 64, z: x.z }));
export async function worldMapMenu(p, d) {
  if (p.dimension.id !== "minecraft:overworld") { await notice(p, "世界地図", "§7この 地図は 地上の ものだ。"); return; }
  for (;;) {
    const here = regionIdxAt(p.location), up = openUpTo(d || load(p) || {});
    const R0 = WREGIONS[here];
    const btn = WREGIONS.map((R, i) => [`${i > up ? "§8" : R.col || "§f"}§l${R.name}§r${i === here ? " §a（今 ここ）" : ""}\n§8Lv${R.lv[0]}〜${R.lv[1]}${i > up ? " §cまだ 行けない" : ""}`, ICON(i === here ? "i_walk" : "i_scout")]);
    const s = await choose(p, "世界地図", `§f今いる 地方: ${R0 ? `${R0.col || ""}${R0.name}` : "？"}\n§7地方を 選ぶと、町・城・ステージ・洞くつ・遺跡の 方角と きょりが わかる`, [...btn, ["§7閉じる", ICON("i_back")]]);
    if (!(s >= 0) || s >= WREGIONS.length) return;
    if (s > up) { await notice(p, "世界地図", `§f${WREGIONS[s].name}\n\n§cまだ 行けない。§7物語を 進めると 行けるように なる。`); continue; }
    const L = places(p, d || load(p)).filter((x) => x.kind !== "spawn" && x.kind !== "altar" && regOfPlace(x) === s);
    if (!L.length) { await notice(p, WREGIONS[s].name, "§7この 地方の 場所は、まだ 地図に のって いない。"); continue; }
    const k = await paged(p, WREGIONS[s].name, "§7近い 順。§a訪問ずみ §7未発見 §8選ぶと コンパスが 案内する", L.map((x) => [`§l${String(x.name).split(" §8")[0]}§r\n§8${String(x.name).includes("洞くつ") ? "洞くつ" : KN[x.kind] || ""} ${dirName(p.location, x)}へ ${fmt(x.d)}（${arrowFor(p, x)}）`, ICON(x.kind === "town" || x.kind === "castle" ? "i_walk" : "i_fight")]), 8);
    const x = L[k]; if (!x) continue;
    setTarget(p, { name: String(x.name).replace(/ §8.*$/, "").replace(/§./g, "").replace(/ (訪問ずみ|未発見)$/, ""), x: x.x, z: x.z, dim: p.dimension.id });
    await notice(p, "世界地図", `§a${String(x.name).replace(/§./g, "")} へ コンパスが 案内します。§7（${dirName(p.location, x)}へ ${fmt(x.d)}）`);
    return;
  }
}
/* 世界地図を わたす（だいじなものの 記録にも のせる → なくしても 物語の 見まわりが もどす）*/
export function giveWmap(p, d) {
  if (!ITEMS[WMAP]) return false;
  const s = qs(d); s.keys = [...new Set([...(s.keys || []), WMAP])];
  try { p.addTag("mrpg_wmap"); } catch {}
  if (!hasKey(p, WMAP)) giveItem(p, `mrpg:${WMAP}`, 1);
  return true;
}
/* 前の 版で もう 旅立った 人には、幼なじみからの 手紙と いっしょに 1回だけ */
const LETTER = {
  g: "はい、これ！ コンパスだけじゃ 迷うかもって 思って、§e世界地図§f も 描いたよ！ 11の 地方、ぜーんぶ のってるんだから！",
  o: "そうだわ。コンパスと いっしょに 渡しそびれて いた §e世界地図§f、今 渡すわね。行きたい 所を 選ぶと、コンパスが 案内して くれるわ。",
  c: "……§e世界地図§f。コンパスと 組みあわせて 使って。描くのに 一週間 かかった。……迷ったら、針より 先に 呼んで。",
  t: "あの、お渡しするのを 忘れていた §e世界地図§f です。行き先を 選ぶと、コンパスが 案内いたします。",
};
export function letterCheck(p) {
  try {
    if (p.hasTag("mrpg_wmap") || !ITEMS[WMAP]) return;
    const d = load(p); if (!d || !(d.story && d.story.introDone)) return;
    giveWmap(p, d); save(p, d);
    const h = HEROES.find((x) => x[0] === qs(d).hero), nm = h ? h[1] : "幼なじみ";
    if (!heroAway(d)) p.sendMessage(`§d${nm}§f「${LETTER[heroType(p)] || LETTER.g}」`);   /* 第127版: 一緒に いるので 手紙では なく 手わたし */
    p.sendMessage("§6だいじなもの「世界地図」を 受けとった！ §7（使うと 地方と 場所の 一覧が 開く）");
  } catch {}
}
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => { if (initialSpawn) system.runTimeout(() => letterCheck(p), 160); }); } catch {}
