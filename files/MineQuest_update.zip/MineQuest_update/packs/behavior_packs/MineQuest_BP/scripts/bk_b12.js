/* 第126版 本12「雪どけの証人」（ヘイムダル城下／北の峠／ラグナへの海峡）。作業 MC
   ・1話（前20）・3〜9話（前21）は 自由な 話。2話は MQ20（地方マスター シデンに 勝った あと、氷雷の城の 前庭）
   ・選択は ない。返って くる 選択: C10（1話 町の 扱い・2話 シデンの 理由）・C04（4話 ヴァルカの 背）・C11（5話 寒さ）・C08（1話 ユラの 使い）
   ・セット: b12cabin（峠の 小屋）・b12pass（mc_pass 吹雪の 峠）・b12port（mc_port 海峡の 港と 舟）・r9look（エンドの 見晴らし台。本13 と 同じ 記録）*/
import { bkAdd, mqOver } from "./bkeng.js";
import { castleBld, unstack } from "./pvplace.js";
import { castAdd, doomed } from "./cast.js";
import { fac, facMark } from "./epfac.js";
import { regTown, farOf } from "./storyplace.js";
import { ok } from "./ui.js";
import { TW, bld, out, castle, memo, Y, REI, snow, stoneIt, props, putN, V4 as V, has, walkOff } from "./bk_b09.js";

const HTOWN = () => { try { const T = regTown(8); return T ? T.t.id : TW.snow; } catch { return TW.snow; } };
const INN = memo(() => castleBld(8, ["inn"], "ヘイムダル城下の 宿") || bld(HTOWN(), ["inn", "tavern"], "ヘイムダル城下の 宿"));   /* 第126版(PV): 城下の 宿は 城下町の 宿 */
const COURT = memo(() => castle("court", "氷雷の城の 前庭"));
const LIB = memo(() => castle("library", "氷雷の城の 書庫"));   /* 第127版(fac3): 玉座（城が ない ときは 噴水の 横）→ 城の 丘の 本の 館の 前 */
const CABIN = memo(() => farOf("b12cabin", TW.sanda, "北の 峠の 小屋", 100, 320) || out(TW.sanda, 2.4, "北の 峠の 小屋"));   /* 第127版(fac2): 町の 外れ 55 → 離れた 峠 */
const PORT = memo(() => farOf("b12port", TW.end, "ラグナへの 海峡の 港", 90, 300) || out(TW.end, 2.4, "ラグナへの 海峡の 港"));
const DECK = memo((p) => { const m = facMark("b12port", "deck", p && p.location); if (m) return { x: m.x, z: m.z, y: m.y, nm: "海峡の 舟の 上" }; const o = PORT(); return o ? { ...o, nm: "海峡の 舟の 上" } : null; });
const LOOK = memo(() => farOf("r9look", TW.end, "さいはての 村 エンドの 竜の 見晴らし台", 90, 260) || out(TW.end, 0, "さいはての 村 エンドの 竜の 見晴らし台"));
const VALKA = ["§cヴァルカ", "valka"], BERYL = ["§fベリル", "beryl"];
const npc = (K, p, w, walk = true) => K.npcNear(p, w[0], K.PJ(w[1], 10), !walk);
const c04 = (K, p, d) => K.chGet(K.qs(K.load(p) || d), "c04");

castAdd("b12_celine", { nm: "セリーヌ", role: "回状の", gobi: "ですわ", skin: "zenia", town: HTOWN(), at: () => { const q = INN(); return q ? { x: q.x + 2, z: q.z + 2 } : null; }, hide: (s) => !has(s, "b12e1"),
  after: [
    [(s) => !!s.ending, ["{smile}回状は、写しを 百 作りましたの。いちばん 長い 名前の 列は、ルミナでしたわ。"]],
    [doomed, ["{sad}……竜の 山の 話、聞きましたわ。回状の 名前、まだ 増えて いますの。止めませんわ。"]],
    [() => true, ["{smile}名前で 囲むのですわ。張り紙の 顔より、知って いる 人の 名前の ほうが 多ければ、噂は 負けますの。"]],
  ] });

bkAdd("b12", [
  /* ---------- 1話 回状 ---------- */
  { id: "b12e1", t: "回状", place: INN, F: ["F46"], ans: ["qb101"], battles: 0,
    hint: "§eヘイムダル城下の 宿§f へ 行こう §7（右上の 案内）",
    syn: "城下の 宿の 一室で、セリーヌ、ガルム、ユラの 使い、ズズが 回状を 書いて いた。「石板の 子の 名を、知って いる 人の 名で 囲む」。",
    async run(p, d, K) {
      await K.open(p, "ヘイムダル城下の 宿", "snow");
      const eH = K.hero(p), eR = REI(K, p), s0 = K.qs(K.load(p) || d), dep = K.chIs(s0, "c10", "d"); await unstack(K, p, eR, [eH]);
      /* C10 で 町の 扱いが かわる */
      const eV = K.npcNear(p, "§7宿の 主人", K.PJ("m6_dario", 9));
      if (dep) {
        K.act(eV, "wave");
        await K.say(p, "宿の 主人", ["{smile}いらっしゃい。王さまが 石板を 預かったって 触れが 出てね。……店も 宿も、開けて いいって。"], eH);
        K.act(eV, "sad");
        await K.say(p, "宿の 主人", ["{sad,…}……ただ、ゆうべ。ヘイム王さまが、石に おなりに なった。", "{closed}箱の そばで、夜通し 見張って おられたそうだ。『この 国が、このまま』と……。"]);
        await K.push(p, eH, 20, 3.8, 1.6);
        await K.hsay(p, V(K, ["{shock,…,up}……王さまが。わたしたちが 預けた 石板の そばで……"], ["{shock,…,up}……王さまが。わたしたちの 預けた 石板の そばで……"], ["{shock,…}……王が。預けた 石板の そばで。"], ["{shock,…,up}……王さまが。わたしたちが お預け した 石板の そばで……"]));
      } else {
        K.act(eV, "arms");
        await K.say(p, "宿の 主人", ["{angry}……追放の 子だな。表は 開けられん。王の 命だ。", "{closed,low}……裏口なら、だれも 見とらん。客が 待っとる。"], eH);
        await K.at(p, K.fwd(p, 6, -3, 1.5), 14, 4, 0.8);
        await K.narr(p, ["§7通りの 店は、どこも 戸を 閉めて いる。窓の 内側から、こちらを 見る 目だけ。"]);
      }
      await walkOff(K, p, eV, 8);
      await K.moveTo(p, K.fwd(p, 3, 4), "宿の 奥の 一室", [eV], K.fwd(p, 6, 4, 1));
      const eC = await K.put(p, "b12_celine", K.fwd(p, 4, -1.2)), eG = await putN(K, p, "§6衛兵長 ガルム", "glen", K.fwd(p, 4.5, 0.6)), eZ = await K.put(p, "b09_zuzu", K.fwd(p, 3.4, 1.8)), eY = await putN(K, p, "§7ソウラの 使い", "m6_otis", K.fwd(p, 5, 2.4));
      K.act(eC, "hold"); K.hold(eC, "scroll"); K.act(eG, "hold"); K.hold(eG, "brush"); K.act(eZ, "kneel"); K.hold(eZ, "scroll");
      await K.csay(p, "b12_celine", ["{smile,!}まあ！ やっと 来ましたわね。待ちくたびれましたの。"], eH);
      await K.say(p, "ガルム", ["{closed}……サンドリアから 歩いて 来たのである。石頭は、足も 丈夫である。"], eH);
      await K.at(p, ok(eC) ? eC.location : null, 14, 1.8, 1.1);
      /*F46*/ await K.narr(p, ["§7卓の 上に、大きな 紙。まん中に 石板の 子の 名前。", "§7そのまわりを、びっしりと 人の 名前が 囲んで いる。ルミナ、ルミエ、ガレキ、ラヴィ、ミラージュ、グロウ、コラリア、ソウラ……"], eC);
      await K.csay(p, "b12_celine", ["{closed,up}回状ですわ。張り紙が 一枚 なら、こちらは 千枚。", "{smile}石板の 子の 名を、知って いる 人の 名で 囲むのですわ。"]);
      await K.say(p, "ソウラの 使い", ["{closed}ユラさまの 名も、ソウラの 墓守たちの 名も、ここに。……迎える 側の 名なのです、と。"], eH);
      await K.csay(p, "b09_zuzu", ["{smile,tears}……いちばん 下に、オレの 名前。元 六影って 書いた。ずびっ。"]);
      await K.push(p, eH, 22, 4, 1.6);
      await K.hsay(p, V(K, ["{smile,tears,up}……石板が 手に なくても、これが ある。", "{closed,up}名前を 知ってる 人が いる。わたしたちは、それで 戦える。"], ["{smile,tears,up}……石板が なくても、これが あるのね。", "{closed,up}名前を 知って いる 人たちが いる。それで 戦えるわ。"], ["{closed,up}……石板が なくても、これが ある。", "{closed}名前を 知ってる 人が いる。それで 戦う。"], ["{smile,tears,up}……石板が なくても、これが あります。", "{closed,up}名前を 知って くださる 方々が いる。それで、戦えます。"]));
      await K.say(p, "ガルム", ["{closed,up}ルミナの 門番 ゴンザに、鳥便を 頼んで ある。各地へ 写しを 運ぶのである。"]);
      K.hold(eC); K.hold(eG); K.hold(eZ);
      if (!ok(p)) return false;
      K.pay(p, { id: "b12e1" }, 1200, [["c_herbs", 2]]);
      await K.end(p, { leave: [eR], bye: [eC, eG, eZ, eY], card: "§7→ §6地方マスター シデン§7 に 勝ち、§e氷雷の城の 前庭§7 へ", kind: "snow" });
      return true;
    } },
  /* ---------- 2話 シデン（MQ20。マスター戦の あと）---------- */
  { id: "b12e2", t: "前庭の 槍", place: COURT, battles: 0,
    hint: "§fフロストヘイムの §6地方マスター シデン§f に 勝ち、§e氷雷の城の 前庭§f へ §7（勝つと 石板。負けても また 挑める）",
    syn: "氷雷の城の 前庭で、シデンは 槍を 下ろした。戦った 理由は、王の 城と 町を 守る 務め。",
    async run(p, d, K) {
      await K.open(p, "氷雷の城の 前庭", "castle");
      const eH = K.hero(p), eR = REI(K, p), s0 = K.qs(K.load(p) || d), dep = K.chIs(s0, "c10", "d");
      const eS = K.npcNear(p, "§6シデン", K.PJ("siden", 9)); K.act(eS, "hold"); K.hold(eS, "spear");
      if (dep) {
        const S = K.S(p), q = S ? S.at(6, 2) : K.fwd(p, 6, 2);
        const eK = await putN(K, p, "§7石に なった 氷王 ヘイム", "heim", q); await stoneIt(K, p, eK, null, true);
        await K.at(p, q, 16, 4, 1.4);
        await K.narr(p, ["§7前庭の まん中に、王の 石の 像。腕を 組み、北を にらんだ まま。", "§7その 前の 雪に、一本の 槍が まっすぐ 立てて あった。"], eK);
        await K.say(p, "シデン", ["{closed}……王は、この 国が このままで あれと 願われた。", "{angry,up}だから 私は、王の 前で 槍を 立てて 戦った。石の 王に、まだ 城が 立って いると 見せる ために。"], eH);
        await K.say(p, "シデン", ["{sad}……負けた。それで いい。王が 願ったのは、私が 勝つ ことでは ない。"]);
        K.rm(eK);
      } else {
        await K.say(p, "シデン", ["{closed}追放の 子を、国境まで 送るのが 私の 務めだった。", "{angry,up}だから 戦った。……押し出す ために。"], eH);
        await K.say(p, "シデン", ["{sad}……負けた。押し出せなかった。王には、私から 言う。"]);
      }
      await K.push(p, eH, 20, 3.8, 1.6);
      await K.hsay(p, V(K, ["{closed,up}……城と 町を 守るのが、シデンさんの 仕事 なんだね。"], ["{closed,up}……城と 町を 守るのが、あなたの 務め なのね。"], ["{closed}……城と 町を 守る 務め、か。"], ["{closed,up}……城と 町を お守りに なるのが、シデンさんの 務め なのですね。"]), eS);
      await K.say(p, "シデン", ["{closed}……ダル王が、書庫で 待って いる。見せたい 地図が あると。"]);
      K.big(p, "§a§l道が 開けた！", "§f終焉の地 ラグナへ 行けるように なった", "ui.toast.challenge_complete");
      K.hold(eS);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eS], card: "§7→ §e氷雷の城の 書庫§7 へ", kind: "castle" });
      return true;
    } },
  /* ---------- 3話 千年前の 地図 ---------- */
  { id: "b12e3", t: "千年前の 地図", place: LIB, F: ["F67"], battles: 0,
    hint: "§e氷雷の城の 書庫§f へ 行こう",
    syn: "千年前の 地図。ラグナの 竜骨に 鍵穴の 印、ルミナに 錠の 印。二つを 細い 線が 結んで いる。",
    async run(p, d, K) {
      props(K, p, "b12lib", [[7, -3, 0, "bookshelf"], [7, -3, 1, "bookshelf"], [7, 3, 0, "bookshelf"], [7, 3, 1, "bookshelf"], [6, 0, 0, "lectern"]]);
      await K.open(p, "氷雷の城の 書庫", "castle");
      const eH = K.hero(p), eR = REI(K, p), eD = K.npcNear(p, "§e雷王 ダル", K.PJ("dal", 8));
      K.act(eD, "hold"); K.hold(eD, "scroll");
      await K.say(p, "ダル", ["{closed}来たか。……城の 書庫の いちばん 奥に、千年前の 地図が ある。", "{closed,up}兄上が『見せるな』と 言って いた もの だ。"], eH);
      await K.give(eD, eH, "scroll"); K.act(eH, "show");
      await K.at(p, ok(eH) ? eH.location : null, 14, 1.7, 1.2);
      /* 鍵穴と錠 植 */ await K.narr(p, ["§7古い 地図。北の 果ての 竜の 骨の 山に、小さな 穴の 印。横に『§e鍵穴§7』。", "§7はるか 南の ルミナに、閉じた 輪の 印。横に『§e錠§7』。二つを、細い 線が 結んで いた。"], eH);
      /*F67*/ await K.hsay(p, V(K, ["{shock,!,up}……この 竜の 骨の 山、隠れ家の 暦の 横に 貼って あった 地図と 同じ！"], ["{shock,!}……この 山、隠れ家の 暦の 横の 地図と 同じよ。"], ["{shock}……隠れ家の 暦の 地図と 同じ 山だ。"], ["{shock,!}……この 山、隠れ家の 暦の 横に 貼って あった 地図と 同じです！"]), eD);
      await K.say(p, "レイ", ["{closed,low}……竜祭りの 夜に 丸。ラグナの 鍵穴。……双子は『二人で 一本の 鍵』だった。"], eH);
      await K.say(p, "ダル", ["{closed}鍵穴に 何本の 鍵が そろえば 何が 開くのか、地図には 書いて いない。", "{sad}ルミナの 錠と つながって いる ことだけ だ。"]);
      await K.hsay(p, V(K, ["{closed,up}……ルミナ。わたしたちの 町。"], ["{closed,up}……ルミナ。わたしたちの 町ね。"], ["{closed}……ルミナ。オレたちの 町。"], ["{closed,up}……ルミナ。わたしたちの 町です。"]));
      K.hold(eH); K.act(eH, 0); K.hold(eD);
      await K.say(p, "ダル", ["{closed}北の 峠を 越えれば、海峡の 港だ。……峠の 小屋に、赤い 髪の 女が 泊まって いると 聞く。"]);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eD], card: "§7→ §e北の 峠の 小屋§7 へ", kind: "castle" });
      return true;
    } },
  /* ---------- 4話 命令書 ---------- */
  { id: "b12e4", pv: 127, t: "命令書", place: CABIN, fac: "b12cabin", F: ["F05"], battles: 0,
    hint: "§fサンダの 北 §e北の 峠の 小屋§f へ 行こう",
    syn: "峠の 小屋に ヴァルカが いた。首領の 筆跡の 命令書「鍵を 持って 竜祭りの 夜に 来い」。「アタシは 行く」。背には 赤い 鍵。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b12cabin", "cabin2", 8, Y(K, p));
      await K.open(p, "北の 峠の 小屋", "snow");
      const eV = await putN(K, p, VALKA[0], VALKA[1], K.fwd(p, 5, 1.2)), eH = K.hero(p), eR = REI(K, p);
      K.act(eV, "arms");
      await K.say(p, "ヴァルカ", ["{smile,low}……アンタたちか。張り紙の 顔より、ましな 顔 してるね。"], eH);
      await K.hsay(p, V(K, ["{angry,!,up}ヴァルカ……！"], ["{shock,!}……ヴァルカさん。"], ["{angry}……ヴァルカ。"], ["{shock,!}……ヴァルカさん。"]), eV);
      K.act(eV, "show"); K.hold(eV, "letter");
      await K.say(p, "ヴァルカ", ["{closed}戦う 気は ないよ。……これ、見な。"], eH);
      await K.at(p, ok(eV) ? eV.location : null, 14, 1.8, 1.3);
      /*F05*/ await K.narr(p, ["§7命令書。太く、ゆっくり 書いた、王の ような 字。『§c鍵を 持って、竜祭りの 夜に 竜骨へ 来い§7』", "§7……署名は、首領の 印。"], eV);
      await K.say(p, "ヴァルカ", ["{closed}首領の 字だ。……鍵を 持って 竜祭りの 夜に 来い、だとさ。", "{smile,up}アタシは 行く。首領に 直に 聞きたい ことが ある。"]);
      await K.hsay(p, V(K, ["{?,up}……首領の 字。……ほんとに 首領が 書いたの？"], ["{?}……首領の 字。本当に 首領が 書いたの かしら。"], ["{closed,?}……首領が 書いたのか。"], ["{?}……首領の 字。本当に 首領が お書きに なったのでしょうか。"]), eV);
      await K.say(p, "ヴァルカ", ["{closed}……さあね。アタシは 首領の 顔を 知らない。字だけだ。"]);
      K.hold(eV);
      /* C04 で 背の 刀が ちがう */
      const sw = c04(K, p, d) === "p";
      if (ok(eV)) { K.turn(eV, K.fwd(p, 20, 0)); await K.at(p, eV.location, 14, 2, 1.4); }
      await K.narr(p, sw ? ["§7ヴァルカの 背に、布で 巻いた 鉄の かたまり。父の 刀が 溶けた、なれの 果て。", "§7縛った 紐の 先に、赤い 鍵が 一本 下がって いた。"] : ["§7ヴァルカの 背に、布巻きの 刀。鋳造所の 溶けた 鉄から 引き出した、父の 刀。", "§7その 柄に、赤い 鍵が 結んで あった。"], eV);
      K.turn(eV);
      await K.say(p, "レイ", ["{closed,low}……赤い 鍵。双子の 指輪と、同じ 匂いが する。"], eV);
      await K.say(p, "ヴァルカ", ["{closed}……今夜は 吹雪く。峠を 越えるなら、アタシと 一緒の ほうが 早いよ。"]);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eV], card: "§7→ §e吹雪の 峠§7 を 越えよう", kind: "snow" });
      return true;
    } },
  /* ---------- 5話 吹雪の 峠（ヴァルカと 共闘）---------- */
  { id: "b12e5", pv: 127, t: "吹雪の 峠", place: CABIN, fac: "b12pass", battles: 1,
    hint: "§f北の 峠の §e吹雪の 峠§f を 越えよう §7（ヴァルカと 共闘）",
    syn: "峠で、六影の 名を かたる 野盗が 道を ふさいだ。ヴァルカと 共に 戦った。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b12pass", "mc_pass", 8, Y(K, p)), CR = facMark("b12pass", "crest", p.location);
      await K.open(p, "吹雪の 峠", "snow");
      snow(K, p, CR || FQ || K.fwd(p, 6, 0), 16, 4);
      const eH = K.hero(p), eR = REI(K, p), eV = npc(K, p, VALKA);
      /* C11 の 寒さ */
      const s0 = K.qs(K.load(p) || d), gave = K.chIs(s0, "c11", "r");
      if (gave) { K.act(eH, "sad"); await K.up(p, eH, 10); await K.narr(p, ["§7吹雪が 指先を 噛む。あなたの 手は、もう 感覚が ない。", "§7……あの 黒い 手袋は、今ごろ ルウの 胸の 中。"], eH); K.act(eH, 0); }
      else { K.hold(eH, "glove"); await K.up(p, eH, 10); await K.narr(p, ["§7懐の 黒い 手袋に 手を 入れると、指先に 少しだけ 血が もどった。", "§7……ルウの 右手の、片っぽの 温かさ。"], eH); K.hold(eH); }
      const b1 = K.npcAt(p, "§7六影を 名乗る 野盗", K.PJ("m6_ivan", 9), CR || K.fwd(p, 7, 0)), b2 = K.npcAt(p, "§7野盗の 手下", K.PJ("m6_zack", 9), CR ? { x: CR.x, y: CR.y, z: CR.z + 1.5 } : K.fwd(p, 7, 1.5));
      K.act(b1, "point");
      await K.say(p, "六影を 名乗る 野盗", ["{angry,!}止まれ！ オレたちは 六影だ！ 荷物を 置いて いけ！"], eH);
      K.act(eV, "arms");
      await K.say(p, "ヴァルカ", ["{angry,low}……へえ。六影の 何の 座だい。言って みな。"], b1);
      await K.say(p, "六影を 名乗る 野盗", ["{sweat,汗}え、ええと……七の 座……？"]);
      await K.say(p, "ヴァルカ", ["{smile}七は ないよ。……やるよ、アンタたち。"], eH);
      if (!K.flag(p, "b12e5w")) {
        const r = await K.battle(p, K.team(["beast", "golem", "nether"], 66, 3, 18), { name: "六影を かたる 野盗", arena: "吹雪の 峠", theme: "snow", speaker: "野盗", guests: K.team(["nether"], 66, 1, 20).map((t) => ({ ...t, owner: "ヴァルカ" })), lines: { half: "……本物の 炎だ……！", low: "ひいっ、本物の 三の座だ……！" } });
        if (r !== "win") { await K.sayAt(p, VALKA[0], K.PJ(VALKA[1], 10), "ヴァルカ", ["{angry}……吹雪の せいに しときな。もう一回 だ。"]); return false; }
        K.setFlag(p, "b12e5w");
      }
      K.act(b1, "kneel"); K.act(b2, "recoil");
      await K.say(p, "ヴァルカ", ["{angry}六影の 名で 人の 荷を 取るな。……本物の 六影の 方が、まだ 筋を 通すよ。"], b1);
      await K.hsay(p, V(K, ["{smile,…}……ヴァルカ、助かった。"], ["{smile}……ありがとう、ヴァルカさん。"], ["{closed}……助かった。"], ["{smile}……ありがとう ございました、ヴァルカさん。"]), eV);
      await K.say(p, "ヴァルカ", ["{closed}礼は いい。小屋に 戻るよ。夜は 越えられない。"]);
      if (!ok(p)) return false;
      K.pay(p, { id: "b12e5" }, 2400, [["mei_frost", 1]]);
      await K.end(p, { leave: [b1, b2, eR], bye: [eV], card: "§7→ §e峠の 小屋§7 で 夜を 明かそう", kind: "snow" });
      return true;
    } },
  /* ---------- 6話 焼けた 角 ---------- */
  { id: "b12e6", pv: 127, t: "焼けた 角", place: CABIN, fac: "b12cabin", F: ["F17"], battles: 0,
    hint: "§e峠の 小屋§f で 夜を 明かそう",
    syn: "ヴァルカが 火の 番を しながら、ベリルの 話を しかけて やめた。座の 紙の 焼けた 角を、指で 押さえて いた。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b12cabin", "cabin2", 8, Y(K, p));
      await K.open(p, "峠の 小屋（夜）", "night", "night");
      const eH = K.hero(p), eV = await putN(K, p, VALKA[0], VALKA[1], K.fwd(p, 3.5, 1.4)), eR = await K.put(p, "§bレイ", K.fwd(p, 2.8, -3.4), K.fwd(p, 2.8, -7), 17);   /* 第126版(PV): うつぶせの 頭は 外へ（だれの 足もとにも かからない）*/
      K.act(eV, "kneel"); K.act(eH, "kneel"); K.act(eR, "prone");
      K.burst(p.dimension, K.fwd(p, 3, 0, 0.2), "minecraft:basic_flame_particle", 6, 0.3, 0.3); K.sound(p, "fire.ignite", 0.6);
      await K.two(p, eV, eH, 14);
      await K.say(p, "ヴァルカ", ["{closed}……寝な。火の 番は アタシが する。"], eH);
      await K.hsay(p, V(K, ["{?}……ヴァルカは、なんで 竜祭りに 行くの？"], ["{?}……ヴァルカさんは、どうして 竜祭りへ？"], ["{closed,?}……なんで 行く。"], ["{?}……ヴァルカさんは、なぜ 竜祭りへ？"]), eV);
      await K.say(p, "ヴァルカ", ["{closed}……鍵を 持って 来いって 言われたから。それと……", "{sad,…}あの 子……ベリルは、アタシが 拾った 子でね。あの 子の――"]);
      K.re(eV, "closed", "…");
      await K.say(p, "ヴァルカ", ["{closed,low}……なんでも ない。"]);
      K.hold(eV, "scroll"); await K.at(p, ok(eV) ? eV.location : null, 14, 1.5, 1);
      /*F17*/ await K.narr(p, ["§7ヴァルカの 手に、古い 紙の 切れ端。六つの 座の 名と、一番 下に 白紙の 行。", "§7その 白紙の 行の 角だけが、焼けて いる。ヴァルカは そこを、親指で ずっと 押さえて いた。"], eV);
      K.hold(eV);
      await K.say(p, "レイ", ["{closed}……寝た ふり、してるからな。"], eV);
      await K.say(p, "ヴァルカ", ["{smile,low}……ませた 坊やだよ。"]);
      await K.night(p, FQ || K.fwd(p, 4, 0, 1), "§7吹雪は、夜明け前に やんだ。", "§7……朝。小屋の 戸口に、ヴァルカの 足あとが 北へ 一つ。");
      K.act(eH, 0); K.act(eR, 0);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eV], card: "§7→ 峠を 下りて §5ラグナへの 海峡の 港§7 へ", kind: "night" });
      return true;
    } },
  /* ---------- 7話 約束（海峡の 港）---------- */
  { id: "b12e7", pv: 127, t: "約束だから", place: PORT, fac: "b12port", battles: 0,
    hint: "§5終焉の地 ラグナ§f の §eラグナへの 海峡の 港§f へ 行こう",
    syn: "港に、先に ベリルが 来て いた。「明日の 夜、門の 前で。……約束だから」。",
    async run(p, d, K) {
      const FQ = fac(K, p, "b12port", "mc_port", 9, Y(K, p)), PI = facMark("b12port", "pier", p.location);
      await K.open(p, "ラグナへの 海峡の 港", "dusk", "dusk");
      if (FQ) { await K.at(p, FQ, 14, 7, 1.4); K.sound(p, "liquid.water", 0.6); }
      const eH = K.hero(p), eR = REI(K, p);
      const eB = K.npcAt(p, BERYL[0], K.PJ(BERYL[1], 10), PI || K.fwd(p, 6, -2)); K.act(eB, "hold");
      await K.up(p, eB, 12);
      await K.say(p, "ベリル", ["{closed}……来た。", "{closed}ヴァルカは、先に 舟で 渡った。"], eH);
      await K.hsay(p, V(K, ["{smile,!}ベリル！ ……一人で 待ってたの？"], ["{smile}ベリルちゃん。……一人で 待って いたの？"], ["{closed}……ベリル。一人か。"], ["{smile}ベリルさん。……お一人で お待ちに？"]), eB);
      await K.say(p, "ベリル", ["{closed}……わたしは 座の 紙に 名前が ない。だから、門の 番を 言いつけられた。"]);
      await K.say(p, "ベリル", ["{angry,low}明日の 夜、門の 前で。……約束だから。"]);
      await K.say(p, "レイ", ["{closed}……戦う って ことか。"], eB);
      await K.say(p, "ベリル", ["{closed}……一度も 勝てないまま、終わりたく ない。"]);
      await walkOff(K, p, eB, 9);
      await K.hsay(p, V(K, ["{sad,up}……ベリル、ずっと 何かを 書きたい 顔 してる。"], ["{sad,up}……あの 子、何かを 書きたい 顔を して いたわ。"], ["{closed}……何か 書きたい 顔 だった。"], ["{sad,up}……ベリルさん、何かを 書きたい お顔を して いました。"]));
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], card: "§7→ 舟で §e海峡§7 を 渡ろう", kind: "dusk" });
      return true;
    } },
  /* ---------- 8話 二通目の 手紙（舟の 上）---------- */
  { id: "b12e8", pv: 127, t: "二通目の 手紙", place: DECK, fac: "b12port", F: ["F09", "F45"], battles: 0,
    hint: "§fラグナへの 海峡の §e舟§f に 乗ろう",
    syn: "舟の 上で、オルドの 二通目の 手紙を 読んだ。「知りすぎた 者には 影が 寄る。わしは、それを 一度 見た」。",
    async run(p, d, K) {
      fac(K, p, "b12port", "mc_port", 9, Y(K, p));
      const DKM = facMark("b12port", "deck", p.location);
      if (DKM && Math.hypot(DKM.x - p.location.x, DKM.z - p.location.z) > 4) await K.moveTo(p, DKM, "海峡の 舟の 上", [], null, 6); else await K.open(p, "海峡の 舟の 上", "dusk", "dusk");
      K.sound(p, "liquid.water", 0.8); K.burst(p.dimension, K.fwd(p, 4, 2, 0), "minecraft:water_splash_particle", 10, 1.4, 0.4);
      const eH = K.hero(p), eR = REI(K, p);
      const eF = K.npcNear(p, "§7渡し舟の 船頭", K.PJ("m6_umi", 9)); K.act(eF, "hold"); K.hold(eF, "rod");
      await K.say(p, "渡し舟の 船頭", ["{closed}ラグナへ 渡る 客は、祭りの 前だけだ。……今年は、多いね。"], eH);
      K.hold(eF);
      K.sound(p, "mob.parrot.fly", 1); K.burst(p.dimension, K.fwd(p, 2, 0, 1.5), "minecraft:white_smoke_particle", 5, 0.4, 0.5);
      K.hold(eR, "letter"); K.act(eR, "hold"); await K.push(p, eR, 18, 3.6, 1.3);
      await K.say(p, "レイ", ["{shock}……じいちゃんの 鳥だ。二通目。"], eH);
      /*F09 F45*/ await K.say(p, "オルド（手紙）", ["{closed}知りすぎた 者には、影が 寄る。わしは、それを 一度 見た。", "{closed,up}……竜祭りの 夜までに、何も 読むな。何も 欲しがるな。わしが 着くまで。"]);
      await K.say(p, "レイ", ["{closed,low}……『一度 見た』。二十年前の ことか。", "{angry,low}じいちゃん、また 何か 隠してる。"], eH);
      K.hold(eR); K.act(eR, 0);
      await K.push(p, eH, 20, 3.6, 1.6);
      await K.hsay(p, V(K, ["{closed,up}……着いたら、全部 聞こう。オルドさんの 口から。"], ["{closed,up}……会えたら、全部 聞きましょう。"], ["{closed}……着いたら 全部 聞く。"], ["{closed,up}……お会い できたら、すべて うかがいましょう。"]), eR);
      await K.at(p, K.fwd(p, 18, 0, 6), 18, 10, 3);
      await K.narr(p, ["§7霧の 向こうに、骨の ような 山の 影。", "§7終焉の地 ラグナ。"]);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], bye: [eF], card: "§7→ §eさいはての 村 エンド§7 へ", kind: "dusk" });
      return true;
    } },
  /* ---------- 9話 竜の 見晴らし台 ---------- */
  { id: "b12e9", pv: 127, t: "竜の 見晴らし台", place: LOOK, fac: "r9look", battles: 0,
    hint: "§5終焉の地 ラグナ§f の §eさいはての 村 エンド（竜の 見晴らし台）§f へ 行こう",
    syn: "さいはての 村 エンドに 着いた。竜の 見晴らし台から、骨の ような 竜の 山が 見えた。",
    async run(p, d, K) {
      const FQ = fac(K, p, "r9look", "lookout", 9, Y(K, p));
      await K.open(p, "さいはての 村 エンド（竜の 見晴らし台）", "dusk", "dusk");
      if (FQ) await K.at(p, FQ, 14, 6, 2);
      const eH = K.hero(p), eR = REI(K, p);
      if (ok(eH) && FQ) await K.walkCam(p, eH, { x: FQ.x - 1.5, y: FQ.y - 2.5, z: FQ.z }, 18);
      await K.at(p, K.fwd(p, 30, 0, 12), 24, 14, 4);
      await K.narr(p, ["§7見晴らし台の 向こうに、白い 山。尾根が 背骨の ように うねり、", "§7あばらの ような 岩が 空へ 何本も 突き出して いる。……竜の 骨の 山。"]);
      await K.hsay(p, V(K, ["{closed,up}……着いた。ここが、ラグナ。"], ["{closed,up}……着いたわね。ここが、ラグナ。"], ["{closed}……着いた。ラグナ。"], ["{closed,up}……着きました。ここが、ラグナ。"]), eR);
      await K.say(p, "レイ", ["{closed}竜祭りの 夜まで、あと 少しだ。……セオも、双子も、ここに 来る。"], eH);
      if (!ok(p)) return false;
      await K.end(p, { leave: [eR], card: "§f― 第12章 雪どけの証人 おわり ―\n§7→ §eエンド§7 の 竜祭りへ", kind: "dusk", t: 60 });
      return true;
    } },
]);

/* MQ20: シデンに 勝った あと、前庭で 2話。古い セーブで 済んで いれば 何も 待たない */
mqOver(20, null, { cond: async () => true, spot: () => { const q = COURT(); return q ? { x: q.x, z: q.z, nm: q.nm, key: "b12e2" } : null; } });
