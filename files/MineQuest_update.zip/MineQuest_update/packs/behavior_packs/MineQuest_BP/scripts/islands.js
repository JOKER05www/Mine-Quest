// 第104版: 遊び場の 浮島。ガイドブック →「遊び場へ 行く」で 島を えらぶと 転送。島の 赤い 台で もとの 場所へ 帰る
// 島は 7つ。1つずつ 空に 間を あけて 浮かぶ（壁は なし。落ちたら 入口へ もどす）。はじめて 行く ときに その 島だけ 建てる
// 遊び: どの 島でも ボールを 投げると 相棒が 取って くる・運動場の 島で かけっこ（相棒と 競争）・広場の 島で 相撲
import { world, system, BlockPermutation, ItemStack } from "@minecraft/server";
import { load } from "./store.js";
import { SPECIES } from "./data.js";
import { notice, choose, ICON, barNote, showTitle, EXH, sound, anim, busy } from "./ui.js";
import { inDungeon } from "./dungeon.js";
import { inRuins } from "./ruinsarea.js";
import { findPet, spawnPet, hooks, setLook, TYPE } from "./field.js";
import { HIT_HOOKS, inBattle } from "./battle.js";
import { PLAYMODE, CROWD, BALL, giveBall as giveBall2, takeBallItem, dropBall, spawnCrowd, clearCrowd, crowdTick, isCrowd } from "./playfun.js";
import { PARK_ST, deco, padAt, ask, cool, stop as pgStop, has as pgHas, owns as pgOwns, dig as pgDig, G as PG_G } from "./pgame.js";   /* 第124版: 遊びを 作り直した */
import { heroInfo, heroSpawn, heroDespawn, heroLine, inStory } from "./heroswim.js";   /* 第124版: 旅の 仲間も 島で いっしょに 遊ぶ */

const OWID = "minecraft:overworld", OW = () => world.getDimension(OWID);
const run = (c) => { try { OW().runCommand(c); return true; } catch { return false; } };
const bk = (...ids) => { for (const id of ids) { try { BlockPermutation.resolve(`minecraft:${id}`); return id; } catch {} } return "stone"; };
const wait = (t) => new Promise((r) => system.runTimeout(r, Math.max(1, t)));
const title = (p, t, s = "") => showTitle(p, t, { subtitle: s, fadeInDuration: 0, stayDuration: 50, fadeOutDuration: 10 });
const R = 34;   /* 島の 半径（第106版: 22 → 34 に 広く）*/

export const ISLES = [
  ["track", "運動場の 島", "トラックと 観客席"], ["pool", "プールの 島", "プールと ヤシの 木"], ["maze", "迷路の 島", "生け垣の 迷路"],
  ["park", "アスレチックの 島", "水の 上の 足場"], ["field", "原っぱの 島", "木と 草むらと 花"], ["sand", "砂浜の 島", "砂浜と 流木"], ["stage", "広場の 島", "タイルの 広場と ステージ"],
];
export function isleCenter(k) {   /* 第104版: はじめに 決めた 場所を おぼえる（スポーンを 変えても 島が ずれない）*/
  let o = null; try { const v = world.getDynamicProperty("mrpg:isleO"); if (typeof v === "string") o = JSON.parse(v); } catch {}
  if (!o) { let s = { x: 0, z: 0 }; try { const w = world.getDefaultSpawnLocation(); s = { x: w.x, z: w.z }; } catch {} o = { x: Math.floor(s.x) - 3000, z: Math.floor(s.z) + 3000 }; try { world.setDynamicProperty("mrpg:isleO", JSON.stringify(o)); } catch {} }
  return { x: o.x + k * 100, y: globalThis.__PG_Y ?? 230, z: o.z };
}
const entry = (k) => { const c = isleCenter(k); return { x: c.x + 0.5, y: c.y, z: c.z - R + 4.5 }; };
const exitPad = (k) => { const c = isleCenter(k); return { x0: c.x + 6, z0: c.z - R + 3, x1: c.x + 8, z1: c.z - R + 5, y: c.y }; };
const inBox = (l, b) => l.x >= b.x0 && l.x < b.x1 + 1 && l.z >= b.z0 && l.z < b.z1 + 1 && Math.abs(l.y - b.y) < 2.5;
const isleAt = (l) => { for (let k = 0; k < ISLES.length; k++) { const c = isleCenter(k); if (Math.abs(l.x - c.x) <= R + 16 && Math.abs(l.z - c.z) <= R + 16 && Math.abs(l.y - c.y) < 40) return k; } return -1; };

/* 島の 形: 上は 平ら（半径 R）、下へ いくほど 細く なる 土と 石（横から 見て 浮島らしく）*/
async function shape(c, top) {
  const dirt = bk("dirt"), stone = bk("stone"), y = c.y;
  for (let dy = 1; dy <= 12; dy++) {
    const r = Math.max(2, Math.round(R * Math.cos(Math.min(1.45, dy * 0.12)) - dy * 0.6)), blk = dy <= 2 ? (dy === 1 ? top : dirt) : stone;
    for (let z = -r; z <= r; z++) { const xo = Math.floor(Math.sqrt(Math.max(0, r * r - z * z))); run(`fill ${c.x - xo} ${y - dy} ${c.z + z} ${c.x + xo} ${y - dy} ${c.z + z} ${blk}`); }
    if (dy % 2 === 0) await wait(1);
  }
  for (let z = -R; z <= R; z += 11) { run(`fill ${c.x - R} ${y} ${c.z + z} ${c.x + R} ${y + 10} ${Math.min(c.z + R, c.z + z + 10)} air`); }
}
/* ふちの かざり（円の まわりに 柵・生け垣 など。入口は あける）*/
function rim(c, blk, h = 1, gap = 3) {
  for (let a = 0; a < 360; a += 3) { const r = R - 0.5, x = Math.round(c.x + Math.sin((a * Math.PI) / 180) * r), z = Math.round(c.z + Math.cos((a * Math.PI) / 180) * r); if (z < c.z - R + 6 && Math.abs(x - c.x) <= gap) continue; run(`fill ${x} ${c.y} ${z} ${x} ${c.y + h - 1} ${z} ${blk}`); }
}
function palm(x, y, z) { const log = bk("jungle_log", "log"), leaf = bk("jungle_leaves", "leaves"); run(`fill ${x} ${y} ${z} ${x} ${y + 4} ${z} ${log}`); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) run(`setblock ${x + dx} ${y + 4 - (Math.abs(dx) + Math.abs(dz) > 1 ? 1 : 0)} ${z + dz} ${leaf}`); run(`setblock ${x} ${y + 5} ${z} ${leaf}`); }
function tree(x, y, z) { const log = bk("oak_log", "log"), leaf = bk("oak_leaves", "leaves"); run(`fill ${x} ${y} ${z} ${x} ${y + 3} ${z} ${log}`); run(`fill ${x - 2} ${y + 3} ${z - 2} ${x + 2} ${y + 4} ${z + 2} ${leaf} replace air`); run(`fill ${x - 1} ${y + 5} ${z - 1} ${x + 1} ${y + 5} ${z + 1} ${leaf}`); }
async function build(k) {
  const c = isleCenter(k), y = c.y, key = ISLES[k][0];
  run(`tickingarea add ${c.x - R - 2} 0 ${c.z - R - 2} ${c.x + R + 2} 0 ${c.z + R + 2} mrpg_isle${k}`);
  const loaded = () => [[-R, -R], [R, R], [0, 0]].every(([dx, dz]) => { try { return !!OW().getBlock({ x: c.x + dx, y, z: c.z + dz }); } catch { return false; } });
  for (let t = 0; t < 80 && !loaded(); t++) await wait(5);
  const top = { track: bk("grass_block"), pool: bk("smooth_stone", "stone"), maze: bk("grass_block"), park: bk("grass_block"), field: bk("grass_block"), sand: bk("sand"), stage: bk("smooth_quartz", "quartz_block") }[key] || bk("grass_block");
  await shape(c, top);
  const fence = bk("oak_fence", "fence"), gold = bk("gold_block");
  /* 第124版: 運動場・プール・迷路・原っぱ・砂浜・広場の しかけは pgame.js（コース・かくれ場所・土俵の 屋根）*/
  if (key === "track") rim(c, fence);
  if (key === "pool") rim(c, bk("stone_brick_wall", "cobblestone_wall"));
  if (key === "maze") rim(c, bk("moss_block", "leaves"), 2);
  if (key === "field") rim(c, fence);
  if (key === "sand") { for (const [dx, dz, l] of [[-9, 6, 4], [8, -9, 3], [12, 7, 5]]) run(`fill ${c.x + dx} ${y} ${c.z + dz} ${c.x + dx + l} ${y} ${c.z + dz} ${bk("stripped_oak_log", "log")}`); for (const [dx, dz] of [[-15, -6], [14, -2], [-4, 15]]) run(`fill ${c.x + dx} ${y} ${c.z + dz} ${c.x + dx + 1} ${y + 1} ${c.z + dz + 1} ${bk("mossy_cobblestone", "cobblestone")}`); for (const [dx, dz] of [[-12, 12], [12, -13]]) palm(c.x + dx, y, c.z + dz); run(`fill ${c.x - 1} ${y - 1} ${c.z - 15} ${c.x + 1} ${y - 1} ${c.z - 14} ${bk("orange_concrete", "concrete")}`); }
  if (key === "stage") {   /* 第104版: まん中に 土俵 */
    run(`fill ${c.x - 6} ${y - 1} ${c.z - 6} ${c.x + 6} ${y - 1} ${c.z + 6} ${bk("smooth_quartz", "quartz_block")}`);
    for (let z = -5; z <= 5; z++) { const xo = Math.floor(Math.sqrt(Math.max(0, 25 - z * z))); run(`fill ${c.x - xo} ${y - 1} ${c.z + z} ${c.x + xo} ${y - 1} ${c.z + z} ${bk("sandstone", "sand")}`); }
    for (let a = 0; a < 360; a += 6) { const x = Math.round(c.x + Math.sin((a * Math.PI) / 180) * 5), z = Math.round(c.z + Math.cos((a * Math.PI) / 180) * 5); run(`setblock ${x} ${y - 1} ${z} ${bk("hay_block", "sandstone")}`); }
    rim(c, bk("white_concrete", "concrete")); }
  if (key === "park") { run(`fill ${c.x - 4} ${y - 3} ${c.z - 14} ${c.x + 4} ${y - 1} ${c.z + 16} water`); for (const [i, q] of PARK_ST.entries()) run(`setblock ${c.x + q[0]} ${y - 1 + q[2]} ${c.z + q[1]} ${bk(q[2] ? "oak_log" : "mossy_stone_bricks", "stone")}`); run(`fill ${c.x - 5} ${y} ${c.z - 14} ${c.x - 5} ${y} ${c.z + 16} ${fence}`); run(`fill ${c.x + 5} ${y} ${c.z - 14} ${c.x + 5} ${y} ${c.z + 16} ${fence}`); run(`fill ${c.x - 1} ${y - 1} ${c.z - 15} ${c.x + 1} ${y - 1} ${c.z - 15} ${gold}`); run(`fill ${c.x - 2} ${y - 1} ${c.z + 18} ${c.x + 2} ${y - 1} ${c.z + 18} ${gold}`); rim(c, fence); for (const [dx, dz] of [[-14, 0], [14, 0]]) { run(`fill ${c.x + dx} ${y} ${c.z + dz} ${c.x + dx} ${y + 3} ${c.z + dz} ${fence}`); run(`setblock ${c.x + dx} ${y + 3} ${c.z + dz + 1} ${bk("red_wool", "wool")}`); } }
  try { await deco(key, c); } catch (e) { console.warn(`[MonsterRPG] isle deco ${key}: ${e}`); }
  /* 入口の 石畳と 帰りの 赤い 台 */
  run(`fill ${c.x - 2} ${y - 1} ${c.z - R + 2} ${c.x + 2} ${y - 1} ${c.z - R + 6} ${bk("stone_bricks", "stone")}`); run(`fill ${c.x - 2} ${y} ${c.z - R + 2} ${c.x + 2} ${y + 1} ${c.z - R + 6} air`);
  const E = exitPad(k); run(`fill ${E.x0} ${y - 1} ${E.z0} ${E.x1} ${y - 1} ${E.z1} ${bk("red_concrete", "concrete")}`);
  await wait(4);
  run(`tickingarea remove mrpg_isle${k}`);
  const ok = (() => { try { const b = OW().getBlock({ x: c.x, y: y - 1, z: c.z }); return b && !b.isAir; } catch { return false; } })();
  if (ok) try { world.setDynamicProperty(`mrpg:isle${k}`, 4); } catch {}   /* 第124版: 遊びを 作り直したので 4 */   /* 第106版: 広く したので 3（前の 島は 建てなおす）*/   /* 第104版: 遊びの しかけを 足したので 2 */
  return ok;
}
let LOCK = null;
async function ready(k) {
  while (LOCK) { try { await LOCK; } catch {} }
  if (world.getDynamicProperty(`mrpg:isle${k}`) === 4) return true;
  let done; LOCK = new Promise((r) => (done = r));
  try { return (await build(k)) || (await build(k)); } finally { LOCK = null; done(); }
}

// ---------- 行く・帰る ----------
const inIsleMode = (p) => { try { return typeof p.getDynamicProperty("mrpg:pret") === "string"; } catch { return false; } };
export async function goIsle(p, k) {
  try { barNote(p).setActionBar("§e島を 準備中…（はじめての 島は 少し 待つ）"); } catch {}
  if (!(await ready(k))) { await notice(p, "遊び場", "§c島を 準備できなかった。少し たってから もう一度。"); return false; }
  try { if (!inIsleMode(p)) p.setDynamicProperty("mrpg:pret", JSON.stringify({ x: p.location.x, y: p.location.y, z: p.location.z, dim: p.dimension.id })); } catch {}
  try { const pet = findPet(p); if (pet) pet.remove(); } catch {}
  try { const n = EXH.stowAll ? EXH.stowAll(p) : 0; if (n) p.sendMessage(`§7持ち物の 道具 ${n}こを バッグに しまった（ガイドブック → バッグ から 出せる）`); } catch {}   /* 第104版: 遊び場では 道具は バッグへ */
  giveBall(p);
  try { p.addEffect("resistance", 100, { amplifier: 4, showParticles: false }); p.teleport(entry(k), { dimension: OW(), facingLocation: isleCenter(k) }); } catch {}
  title(p, `§e${ISLES[k][1]}`, "§f赤い 台で もとの 場所へ 帰る");
  return true;
}
export function leaveIsle(p) {
  let r; try { r = p.getDynamicProperty("mrpg:pret"); } catch { return; }
  if (typeof r === "string") try { const o = JSON.parse(r); p.teleport({ x: o.x, y: o.y, z: o.z }, { dimension: world.getDimension(o.dim) }); } catch {}
  try { p.setDynamicProperty("mrpg:pret", undefined); } catch {}
  endPlay(p);
  system.runTimeout(() => { try { const d = load(p); const m = d && d.out && [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out); if (m && !findPet(p)) spawnPet(p, m); } catch {} }, 10);
}
hooks.petHold = ((prev) => (p) => (prev && prev(p)) || inIsleMode(p))(hooks.petHold);
/* 島に いる 人だけ 見る（1秒に 2回）: 赤い 台・落ちた とき・島を はなれた とき */
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (!inIsleMode(p)) continue;
    try {
      const l = p.location, kk = p.dimension.id === OWID ? isleAt({ ...l, y: isleCenter(0).y }) : -1;
      if (kk < 0) { p.setDynamicProperty("mrpg:pret", undefined); endPlay(p); continue; }   /* ワープ・死んで 島を はなれた ときは 記録を 消すだけ */
      const c = isleCenter(kk);
      if (l.y < c.y - 8) { p.addEffect("slow_falling", 60, { showParticles: false }); p.teleport(entry(kk), { facingLocation: c }); continue; }
      if (inBox(l, exitPad(kk))) { leaveIsle(p); continue; }
      const E = exitPad(kk); if (Math.random() < 0.3) OW().spawnParticle("minecraft:basic_flame_particle", { x: E.x0 + 1.5, y: c.y + 0.4, z: E.z0 + 1.5 });
    } catch {}
  }
}, 10);
world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => { if (!initialSpawn) return; system.runTimeout(() => { try { if (inIsleMode(player)) leaveIsle(player); } catch {} }, 80); });

// ---------- 入口（ガイドブック → 冒険 →「遊び場へ 行く」）----------
export async function isleMenu(p) {
  if (inIsleMode(p)) { leaveIsle(p); return; }
  if (inDungeon(p) || inBattle(p) || (() => { try { return inRuins(p.location); } catch { return false; } })()) { await notice(p, "遊び場", "§7石板・遺跡の 中や 戦いの 間は 行けない。外に 出てから 行こう。"); return; }   /* 第104版 */
  try { if (p.getComponent("minecraft:riding")?.entityRidingOn) { await notice(p, "遊び場", "§7ライドから おりて から 行こう。"); return; } } catch {}
  const c = await choose(p, "遊び場へ 行く", "§f行きたい 島を えらぶと そこへ 転送。§7島の 赤い 台で もとの 場所へ 帰る", [...ISLES.map((x) => [`§l${x[1]}\n§8${x[2]}`, ICON("i_run")]), ["§7戻る", ICON("i_back")]]);
  if (c < 0 || c >= ISLES.length) return;
  await goIsle(p, c);
}
EXH.isle = isleMenu;
PLAYMODE.push((p) => { if (!inIsleMode(p)) return null; const k = isleAt({ ...p.location, y: isleCenter(0).y }); return k < 0 ? null : { ...isleCenter(k), flat: true }; });
export const __isle = { ISLES, isleCenter, entry, exitPad, ready, build, goIsle, leaveIsle, isleAt };

// ================= 第104版: 遊び（ボール）。第124版: かけっこ・相撲・かくれんぼ などは pgame.js =================
/* ボールの 遊び相手は 相棒の 写し（連れ歩きとは 別。島の 中だけ）。動きは スクリプトで（軽く: 2tickに 1回、島に いる 人だけ）*/
const BUD = new Map();   /* pid -> { e, sid, mode, ball, carry, t } */
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const outMon = (p) => { const d = load(p); if (!d || !d.out) return null; return [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out) || null; };
const spdK = (sid) => { const b = SPECIES[sid]?.base || {}; return Math.max(0.85, Math.min(1.15, 0.85 + (b.spd || 4) / 20)); };
const giveBall = (p) => giveBall2(p);
function spawnBud(p) {
  const m = outMon(p); if (!m) return null;
  let e = null; try { e = OW().spawnEntity(TYPE, { x: p.location.x + 1.5, y: p.location.y, z: p.location.z + 1 }); } catch { return null; }
  try { e.addTag("mrpg_play"); e.setDynamicProperty("mrpg:pown", p.id); setLook(e, m.sp, m); e.triggerEvent("mrpg:make_battle"); e.nameTag = `§d${m.nm}`; } catch {}
  const b = { e, sid: m.sp, nm: m.nm, mode: "follow", ball: null, carry: false, t: 0, k: spdK(m.sp) }; BUD.set(p.id, b); return b;
}
/* 第124版: 遊びの 外でも 旅の 仲間が そばに いる（ついて くる・ボールを 追いかける・相棒が とって くると よろこぶ）*/
const HB = new Map();   /* pid -> { e, t, mv } */
const HBL = { g: ["ナイスキャッチ！", "すごい すごい！"], o: ["上手ね〜", "ふふ、かわいい〜"], c: ["……やるじゃない", "いい 動きね"], t: ["お見事です！", "よく できました"] };
function heroBud(p, c, l) {
  let h = HB.get(p.id);
  if (!h || !okE(h.e)) {
    if (h && (h.cd = (h.cd || 0) - 1) > 0) return; if (!heroInfo(p) || inStory(p)) return;
    let e = null; try { e = heroSpawn(p, { x: l.x - 1.5, y: c.y, z: l.z - 1 }, { tags: ["mrpg_play", "mrpg_isleh"], face: l }); } catch {}
    if (!e) { HB.set(p.id, { cd: 100 }); return; } try { e.setDynamicProperty("mrpg:pown", p.id); } catch {} h = { e, t: 0, mv: false }; HB.set(p.id, h);
  }
  h.t++; const e = h.e, el = e.location; let to = l, sp = 0.2, near = 2.6;
  { const Bl = BALL.get(p.id); if (Bl && Bl.e) try { to = Bl.e.location; sp = 0.24; near = 1.8; } catch {} }
  const d = hv(el, to), mv = d > near; if (mv) stepTo(e, to, Math.min(sp, 0.1 + d * 0.03), c.y);
  if (mv !== h.mv) { h.mv = mv; try { e.setProperty("mrpg:mv", mv); } catch {} }
  if (!mv && h.t % 20 === 0) try { e.teleport(el, { facingLocation: { x: l.x, y: l.y + 1.5, z: l.z } }); } catch {}
}
const heroBudOff = (p) => { const h = HB.get(p.id); if (h && h.e) try { heroDespawn(p, h.e); } catch {} HB.delete(p.id); };
const budOff = (pid) => { const b = BUD.get(pid); if (b) { try { if (okE(b.e)) b.e.remove(); } catch {} BUD.delete(pid); } };
function endPlay(p) {
  budOff(p.id); heroBudOff(p); pgStop(p.id);   /* 第124版: 遊びの 片づけは pgame.js */
  takeBallItem(p); dropBall(p.id); clearCrowd(p);   /* ボールだけ 消す（持ちこんだ 雪玉は のこす）・仲間と ボールを 片づける */
}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { budOff(playerId); const h = HB.get(playerId); if (h && okE(h.e)) try { h.e.remove(); } catch {} HB.delete(playerId); }); } catch {}
/* 起動した ときに 残った 遊び相手を 片づける */
system.runTimeout(() => { try { for (const e of OW().getEntities({ type: TYPE, tags: ["mrpg_play"] })) if (!isCrowd(e.id) && ![...BUD.values()].some((x) => x.e && x.e.id === e.id) && !pgOwns(e.id)) try { e.remove(); } catch {} } catch {} }, 100);
const stepTo = (e, to, sp, y) => { const l = e.location, dx = to.x - l.x, dz = to.z - l.z, d = Math.hypot(dx, dz); if (d < 0.05) return 0; const k = Math.min(sp, d) / d; try { e.teleport({ x: l.x + dx * k, y, z: l.z + dz * k }, { facingLocation: { x: to.x, y: y, z: to.z } }); } catch {} return d; };

/* ---- ボール: 第106版から playfun.js の はねる ボール ---- */
function budTick(p, c, l) {
  let b = BUD.get(p.id); if (!b || !okE(b.e)) { if (pgHas(p.id)) return; b = spawnBud(p); if (!b) return; }
  if (pgHas(p.id)) return;
  const e = b.e, y = c.y, el = e.location; b.t++;
  if (el.y < y - 6) { try { e.teleport({ x: l.x + 1, y, z: l.z + 1 }); } catch {} return; }
  { const Bl = BALL.get(p.id); if (Bl && Bl.e && !b.carry && b.mode !== "back") { b.mode = "chase"; let bl = null; try { bl = Bl.e.location; } catch {} if (bl) { stepTo(e, bl, 0.5 * b.k, y); if (Bl.t > 4 && hv(bl, el) < 1.3 && bl.y - y < 2.6) { dropBall(p.id); b.mode = "back"; b.carry = true; b.t = 0; anim(e, Bl.rest ? "happy" : "atk_jump"); try { barNote(p).setActionBar(`§e§l${Bl.rest ? "とった！" : "ナイスキャッチ！"} §f${b.nm}が くわえた`); } catch {} sound(p, "random.pop", 1.6); } return; } } }
  if (b.mode === "chase") { b.mode = "follow"; }   /* ほかの 子が 取った */
  if (b.mode === "back") {
    const d = stepTo(e, l, 0.36 * b.k, y);
    if ((b.t & 3) === 0) try { OW().spawnParticle("minecraft:villager_happy", { x: e.location.x, y: y + 1.6, z: e.location.z }); } catch {}
    if (d < 1.8) { b.mode = "follow"; b.carry = false; b.t = 0; giveBall(p); anim(e, "happy"); try { for (let k = 0; k < 4; k++) OW().spawnParticle("minecraft:heart_particle", { x: e.location.x + (Math.random() - 0.5), y: y + 1.2, z: e.location.z + (Math.random() - 0.5) }); } catch {} b.n = (b.n || 0) + 1; try { barNote(p).setActionBar(`§d${b.nm}が ボールを もって きた！ §7（${b.n}回目）`); } catch {} sound(p, "random.orb", 1.4); if (hooks.addNkOut && b.n % 5 === 0) hooks.addNkOut(p, 2, "ボール あそび"); const h = HB.get(p.id); if (h && okE(h.e) && b.n % 3 === 1) try { heroLine(p, HBL, h.e, 6); } catch {} }
    return;
  }
  /* ついて くる */
  const d = hv(el, l); if (d > 2.6) stepTo(e, l, Math.min(0.5, 0.16 + d * 0.03) * b.k, y);   /* 第106版: 犬の ように 元気に ついて くる */
}

/* 島では 野生が 出ない・ブロックを こわせない／置けない（宝さがしの 砂は pgame.js が ほる）*/
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => inIsleMode(p) || (prev ? prev(p) : false); });
try { world.beforeEvents.playerBreakBlock.subscribe((ev) => { if (!inIsleMode(ev.player)) return; ev.cancel = true; const p = ev.player; if (!pgHas(p.id)) return; const pos = { ...ev.block.location }; system.run(() => { try { pgDig(p, pos); } catch {} }); }); } catch {}
try { world.beforeEvents.playerPlaceBlock?.subscribe((ev) => { if (inIsleMode(ev.player)) ev.cancel = true; }); } catch {}
const RACE_OFF = new Set(), PADN = new Map(), RACE_T = new Map();   /* 遊びの あと 台から いちど はなれるまで 始めない */
/* 島ごとの 見はり（2tick・島に いる 人だけ）。遊びの 中身は pgame.js（毎tick・遊んで いる 人だけ）*/
system.runInterval(() => {
  if (!BUD.size && !PG_G.size && !world.getAllPlayers().some((p) => inIsleMode(p))) return;
  for (const p of world.getAllPlayers()) {
    if (!inIsleMode(p)) continue;
    try {
      const l = p.location, k = p.dimension.id === OWID ? isleAt({ ...l, y: isleCenter(0).y }) : -1; if (k < 0) continue;
      const c = isleCenter(k), key = ISLES[k][0];
      if (inBattle(p)) { if (pgHas(p.id)) pgStop(p.id, "戦いに なった"); continue; }   /* 戦いに なったら 遊びは やめる */
      if (busy.has(p.id)) continue;   /* 画面を 開いて いる 間は 止める（やめない）*/
      if ((system.currentTick % 100) < 2) try { for (const e of OW().getEntities({ type: TYPE, tags: ["mrpg_play"], location: { x: c.x, y: c.y, z: c.z }, maxDistance: 45 })) { const mine = isCrowd(e.id) || [...BUD.values()].some((x) => x.e && x.e.id === e.id) || pgOwns(e.id); if (!mine) e.remove(); } } catch {}   /* 残った 遊び相手を 片づける */
      const pad = padAt(key, c, l); if (!pad) { RACE_OFF.delete(p.id); PADN.delete(p.id); }
      if (pgHas(p.id)) { budOff(p.id); if (HB.has(p.id)) heroBudOff(p); crowdTick(p, { ...c, flat: true }, { cheer: { x: c.x + R - 8, z: c.z + 2 } }); continue; }
      if (pad && !RACE_OFF.has(p.id) && !cool(p.id)) { const n = (PADN.get(p.id) || 0) + 1; PADN.set(p.id, n); if (n === 2) try { barNote(p).setActionBar("§eそのまま 立って いると はじまる…"); } catch {} if (n >= 10) { PADN.delete(p.id); RACE_OFF.add(p.id); ask(p, pad, c, k).catch(() => {}); } continue; }   /* 1秒 立つと はじまる（通りすぎる だけでは はじまらない）*/
      if (!CROWD.has(p.id)) spawnCrowd(p, { ...c, flat: true }, new Set([outMon(p)?.id]));
      budTick(p, c, l); heroBud(p, c, l); crowdTick(p, { ...c, flat: true });
    } catch {}
  }
}, 2);
export const __play = { BUD, PLAY: PG_G, RACE_T };
EXH.isleInfo = () => ["§fどの 島でも §eボール§f を 投げると 相棒が 取って くる", "§f運動場・プール: 緑の 台で かけっこ・水泳（門を 通って 1周）／迷路: 緑の 台で 毎回 ちがう 迷路／アスレチック: 北の 金で 足場わたり", "§f砂浜: だいだいの 台で 宝さがし／原っぱ: 緑の 台で かくれんぼ・紫の 台で おにごっこ／広場: 土俵で 相撲（2本 先取）", "§7台に 立つと 難易度を えらべる。旅の 仲間も いっしょに 遊ぶ"];
