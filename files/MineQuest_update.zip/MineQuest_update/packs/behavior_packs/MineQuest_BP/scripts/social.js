// 第110版: 町の 人と 交流する（贈り物・デート・一緒に 食事・モンスター勝負・お見合い配合・鬼ごっこ・酒場の 踊り）
// 遊びは その場で 人が 動いて 進む。画面（フォーム）は「何を するか」を えらぶ ときだけ
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, RANKS } from "./data.js";
import { WREGIONS, regionIdx, regionLv } from "./worldmap.js";
import { load, save } from "./store.js";
import { busy, choose, notice, ICON, MON_ICON, takeItem, sound, barNote, gold, ok } from "./ui.js";
import { NPC_HOOKS } from "./npchook.js";
import { relOf, setRel, chatWith, greetLine } from "./chat.js";
import { interMenu, extraOpts, isKid } from "./townlife.js";
import { GIFTS } from "./toys.js";
import { claimWalker, standY, __walk, BUSYW } from "./citylife.js";
import { makeMonster, addMon } from "./core.js";
import { careChild } from "./endgame.js";
import { rankCap } from "./quest.js";
import { team as sagaTeam } from "./saga.js";
import { fight } from "./story.js";
import { giveGold } from "./explore.js";
import { boon } from "./boon.js";   /* 第124版: お礼は お金より 道具 */
import { helperOpt } from "./fieldhelp.js";   /* 第124版: 町の 外の 役に 立つ 人 */

const OW = () => world.getDimension("overworld");
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const hv = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const day = () => Math.floor(Date.now() / 86400000);
const nmOf = (e) => String(e.nameTag || "").replace(/§./g, "").trim() || "町の 人";
const hashS = (t) => { let h = 7; for (const c of String(t)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
const act = (e, a) => { try { if (!ok(e)) return; if (a === 0) { const b = e.getDynamicProperty("mrpg:act0"); if (typeof b === "number") a = b; } e.setProperty("mrpg:act", a); } catch {} };
const faceTo = (e, p) => { try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} };
const hearts = (e) => { try { e.dimension.spawnParticle("minecraft:heart_particle", { x: e.location.x, y: e.location.y + 2.1, z: e.location.z }); } catch {} };
const line = (p, e, t) => { try { p.sendMessage(`§e${nmOf(e)}§f「${t}」`); barNote(p).setActionBar(`§e${nmOf(e)}§f「${t}」`); } catch {} };
function addAff(p, e, n) { const nm = nmOf(e), R = relOf(p, nm); R.a = Math.max(-20, Math.min(100, (R.a || 0) + n)); R.t = Date.now(); setRel(p, nm, R); return R.a; }
const heartStr = (a) => (a >= 30 ? "§d★★★" : a >= 12 ? "§d★★§7★" : a >= 4 ? "§d★§7★★" : "§7★★★");

const busyOn = (e) => { try { if (e.hasTag("mrpg_busyw")) return false; e.addTag("mrpg_busyw"); BUSYW.add(e.id); claimWalker(e.id); return true; } catch { return false; } };
const busyOff = (e) => { try { BUSYW.delete(e.id); e.removeTag("mrpg_busyw"); } catch {} };
/* 第110版: 1日に もらえる 回数（プレイヤーごと・全部の 町の 人を あわせて）*/
const CAP = { duel: 8, date: 3, omiai: 3, chat: 30 };
function daily(p, k, use = false) { let v = {}; try { v = JSON.parse(p.getDynamicProperty("mrpg:soc") || "{}"); } catch {} if (v.d !== day()) v = { d: day() }; const n = v[k] || 0; if (use) { v[k] = n + 1; try { p.setDynamicProperty("mrpg:soc", JSON.stringify(v)); } catch {} } return n; }
// ---------- 贈り物（手に 持って 話しかける）----------
const GIFT = {
  flower: /^minecraft:(poppy|dandelion|cornflower|oxeye_daisy|azure_bluet|allium|blue_orchid|lily_of_the_valley|.*_tulip|sunflower|peony|rose_bush|lilac|pink_petals|red_flower|yellow_flower)$/,
  sweet: /^minecraft:(cake|cookie|pumpkin_pie|honey_bottle|sweet_berries|glow_berries)$/,
  food: /^minecraft:(bread|apple|golden_apple|baked_potato|cooked_\w+|rabbit_stew|mushroom_stew|beetroot_soup)$/,
  gem: /^minecraft:(emerald|diamond|amethyst_shard|gold_ingot|lapis_lazuli|quartz|prismarine_crystals)$/,
  book: /^minecraft:(book|writable_book|written_book|enchanted_book|paper|map)$/,
};
const GN = { flower: "花", sweet: "あまい もの", food: "料理", gem: "宝石", book: "本", craft: "手作りの 品", toy: "おもちゃ", local: "名物" };
const favOf = (nm) => Object.keys(GIFT)[hashS(nm + "f") % 5];
/* 第113版: 2番目に 好きな もの（toys.js の 贈り物の 種類も ふくむ）*/
const KINDS2 = ["flower", "sweet", "food", "gem", "book", "craft", "toy"];
const fav2Of = (nm) => KINDS2[hashS(nm + "f2") % KINDS2.length];
const giftOf = (id) => { try { const G = GIFTS && GIFTS[id]; return G && typeof G === "object" ? G : null; } catch { return null; } };
function giftKind(id) { const G = giftOf(id); if (G) return String(G.kind || "craft"); for (const k in GIFT) if (GIFT[k].test(id)) return k; return null; }
function giveGift(p, e, it) {
  const k = giftKind(it.typeId); if (!k) return false;
  if (!takeItem(p, it.typeId, 1)) return true;
  const nm = nmOf(e), R = relOf(p, nm), fav = favOf(nm) === k, like = !fav && (fav2Of(nm) === k || k === "local"), first = R.g !== day();
  const G = giftOf(it.typeId), gname = (G && G.name) || GN[k] || "贈り物";
  const n = !first ? 0 : fav ? 8 : like ? 6 : 4;
  R.g = day(); setRel(p, nm, R);
  const a = addAff(p, e, n);
  faceTo(e, p); act(e, fav ? 9 : 10); hearts(e); if (fav) system.runTimeout(() => hearts(e), 10);
  sound(p, fav ? "random.levelup" : "random.orb", 0.8);
  line(p, e, fav ? pick([`わあ、${gname}！ いちばん 好きなの。ありがとう！`, `これ、ずっと ほしかったんだ……！`, `${p.name}さん、わかってるなあ！`]) : first && like ? pick([`${gname}？ うれしい、こういうの 好きなんだ`, k === "local" ? "遠くの 名物？ 話には 聞いてたんだ。ありがとう！" : `${gname}、大事に するね。ありがとう！`]) : first ? pick(["ありがとう、大事に するね", "うれしいな、ありがとう", "気を つかって くれて ありがとう"]) : pick(["今日は もう もらったよ。でも ありがとう", "そんなに くれなくて いいのに……ふふ"]));
  system.runTimeout(() => act(e, 0), 60);
  if (n) try { p.sendMessage(`§7（${heartStr(a)}§7 仲よし +${n}）`); } catch {}
  return true;
}

// ---------- モンスター勝負 ----------
async function duel(p, e) {
  const d = load(p); if (!d) return;
  const i = regionIdx(p.location.x - world.getDefaultSpawnLocation().x, p.location.z - world.getDefaultSpawnLocation().z), R = WREGIONS[i] || WREGIONS[0];
  const lv = Math.max(6, Math.min(100, regionLv(p.location) + 8)), nm = nmOf(e);   /* 第117版: 町の 人は 基本 強め（地方の レベル＋8・ランクも 1つ 上がりやすい） */
  const foe = sagaTeam(Object.keys(R.fams || { beast: 1 }), lv, 3, 25); if (!foe.length) return;
  line(p, e, pick(["よし、手加減 しないよ！", "勝負だね。うちの 子も 強いんだから", "いいよ、腕だめし しよう！"])); act(e, 9);
  if (daily(p, "duel") >= CAP.duel) { line(p, e, "今日は もう たくさん 勝負したでしょ？ また 明日ね"); return; }
  if (!busyOn(e)) { line(p, e, "ごめんね、今 ほかの 人と 遊んでる ところなんだ"); return; }
  daily(p, "duel", true);
  let res; try { res = await fight(p, { team: foe }, { tier: 1, fam: "", npc: null, theme: R.land?.[0] || "plains", name: nm, arena: "町の 人との 勝負", speaker: nm, scout: true }   /* 第120版: 町や 野の 人の モンスターも スカウトできる（野生より むずかしい）*/); } finally { busyOff(e); }
  const d2 = load(p); if (!d2) return; const Rl = relOf(p, nm);
  if (res === "win") { const first = Rl.b !== day(); Rl.b = day(); setRel(p, nm, Rl); const a = addAff(p, e, 3); const bw = first && daily(p, "dwb") < 3; if (bw) daily(p, "dwb", true); const g = bw ? `${boon(p, d2, 1)}§f・${giveGold(d2, 100 + lv * 5)}` : first ? giveGold(d2, 100 + lv * 5) : "§7（今日の ほうびは もう もらった）";   /* 第124版: 道具の お礼は 1日 3回まで */ save(p, d2); if (ok(e)) { act(e, 6); line(p, e, "参った！ 強いね。また 相手してよ"); } try { p.sendMessage(`§a勝った！ ${g}  ${heartStr(a)}`); } catch {} }
  else if (ok(e)) { act(e, 9); line(p, e, "ふふ、今日は 私の 勝ち。また 挑んで きてね"); addAff(p, e, 1); }
  system.runTimeout(() => act(e, 0), 60);
}

// ---------- お見合い配合（町の 人の モンスターと）----------
function npcMon(nm, i, d) {
  const R = WREGIONS[i] || WREGIONS[0], fams = Object.keys(R.fams || { beast: 1 });
  const cap = Math.min(rankCap(d), 1 + Math.floor(i / 2));
  const L = ORDER.filter((x) => { const S = SPECIES[x]; return S && !S.hidden && !S.metalmon && !S.special && !S.special4 && fams.includes(S.fam) && RANKS.indexOf(S.rank) <= cap && !["king", "god"].includes(S.fam); });
  if (!L.length) return null;
  return makeMonster(L[hashS(nm + "m") % L.length], Math.max(5, Math.min(60, R.lv[1])), false);
}
async function omiai(p, e) {
  const nm = nmOf(e), d = load(p); if (!d) return;
  const R = relOf(p, nm); if ((R.a || 0) < 20) { line(p, e, "うちの 子の お見合い？ ……もう 少し 仲よく なってからね"); return; }
  if (R.o === day()) { line(p, e, "今日は もう お見合い したよ。また 明日ね"); return; }
  if (daily(p, "omiai") >= CAP.omiai) { line(p, e, "お見合いは 1日 3回まで。また 明日ね"); return; }
  if ((d.box || []).length >= 1000) { line(p, e, "預かり所が いっぱいみたい。少し 空けてから ね"); return; }
  const i = regionIdx(p.location.x - world.getDefaultSpawnLocation().x, p.location.z - world.getDefaultSpawnLocation().z);
  const them = npcMon(nm, i, d); if (!them) return;
  const cost = 2000;
  const L = d.party.filter((m) => m && SPECIES[m.sp] && !["king", "god"].includes(SPECIES[m.sp].fam));
  if (!L.length) return;
  const c = await choose(p, "お見合い配合", `§e${nm}§fの ${SPECIES[them.sp].name} と お見合い させる 子を えらんでね\n§7（親は どちらも そのまま。生まれた 子が 仲間に なる・${cost.toLocaleString()} タヨ・1日 1回）\n§7お金: ${gold(d.gold)}`, [...L.map((m) => [`${m.nm || SPECIES[m.sp].name} Lv${m.lv}`, MON_ICON(m.sp)]), ["§7やめる", ICON("i_back")]]);
  if (c === undefined || c === null || c < 0 || c >= L.length) return;
  const d2 = load(p); if (!d2) return; if ((d2.gold || 0) < cost) { await notice(p, "お見合い配合", "§7お金が たりない。"); return; }
  const mine = d2.party.find((m) => m && m.id === L[c].id) || L[c];
  d2.gold -= cost; const child = careChild(mine, them, rankCap(d2)); addMon(d2, child); daily(p, "omiai", true);
  for (const k of ["own", "seen"]) { d2[k] = d2[k] || []; const ix = SPECIES[child.sp]?.idx; if (ix !== undefined && Array.isArray(d2[k]) && !d2[k].includes(ix)) d2[k].push(ix); }
  const R2 = relOf(p, nm); R2.o = day(); setRel(p, nm, R2); save(p, d2);
  if (ok(e)) { act(e, 9); hearts(e); line(p, e, `かわいい 子が 生まれたね！ 大事に してあげてね`); system.runTimeout(() => act(e, 0), 60); }
  sound(p, "random.levelup", 1);
  try { p.sendMessage(`§d♪ お見合いで ${child.shiny ? "§e★" : ""}${child.nm || SPECIES[child.sp].name}§d が 生まれた！ §7（${gold(cost)} 使った）`); } catch {}
  addAff(p, e, 2);
}

// ---------- デート（町を 一緒に 歩いて 3か所を めぐる）----------
const DATE = new Map();   /* pid → { e, nm, spots:[{k,x,y,z,nm}], i, t, seen } */
const SPOTN = { cafe: "カフェ", diner: "食堂", plaza: "広場の 噴水", bench: "ベンチ" };
function areaOf(loc) { for (const A of __walk.areas()) if (hv(loc, A) < A.r) return A; return null; }
function dateStart(p, e) {
  const A = areaOf(p.location); if (!A) { line(p, e, "ここじゃ 落ちつかないよ。町の 中で 誘って"); return; }
  const S = [];
  for (const q of A.p || []) S.push({ k: q[0], x: A.x + q[1] + 0.5, y: A.y + q[2], z: A.z + q[3] + 0.5 });
  S.push({ k: "plaza", x: A.x + 0.5, y: A.y + (A.id.startsWith("c") ? 5 : 0), z: A.z + 3.5 });
  if ((A.s || []).length) { const b = pick(A.s); S.push({ k: "bench", x: A.x + b[0] + 0.5, y: A.y + b[1], z: A.z + b[2] + 0.5 }); }
  const spots = S.sort(() => Math.random() - 0.5).slice(0, 3);
  if (!busyOn(e)) { line(p, e, "ごめんね、今 ほかの 人と 約束が あるんだ"); return; }
  try { e.setProperty("mrpg:mv", false); } catch {}
  DATE.set(p.id, { e, nm: nmOf(e), spots, i: 0, t: Date.now(), x: e.location.x, y: e.location.y, z: e.location.z, wait: 0 });
  act(e, 9); hearts(e); line(p, e, pick(["うん、行こう！ ……ちょっと 緊張するね", "いいよ。今日は 楽しもうね", "デート？ ……ふふ、よろこんで"]));
  try { p.sendMessage(`§d♪ デートが 始まった！ §7（${spots.map((q) => SPOTN[q.k]).join(" → ")}。相手は ついて くる）`); } catch {}
}
function dateEnd(p, D, good) {
  DATE.delete(p.id);
  const e = D.e; busyOff(e); act(e, 0);
  if (!good) { try { p.sendMessage("§7デートは おしまいに なった……"); } catch {} return; }
  const a = addAff(p, e, 6); const d = load(p);
  if (d) { const R = relOf(p, D.nm); const first = R.dd !== day() && daily(p, "date") < CAP.date; R.dd = day(); setRel(p, D.nm, R); if (first) { daily(p, "date", true); const g = boon(p, d, 1); save(p, d); try { p.sendMessage(`§d♪ 楽しい デートだった！ ${heartStr(a)}  §7おみやげ ${g}`); } catch {} } else try { p.sendMessage(`§d♪ 楽しい デートだった！ ${heartStr(a)}`); } catch {} }
  if (ok(e)) { faceTo(e, p); act(e, 10); hearts(e); line(p, e, pick([`今日は ありがとう、${p.name}さん。……また 誘ってね`, "すごく 楽しかった。……次は どこに 行こうか", "ふふ、忘れられない 一日に なったよ"])); system.runTimeout(() => act(e, 0), 80); }
}
const SCENE = {
  cafe: [2, ["ここの ケーキ、ずっと 一緒に 食べたかったんだ", "ん〜、おいしい！ ……ほら、ひと口 どうぞ"]],
  diner: [2, ["いい におい……！ おなか すいちゃった", "一緒に 食べると、いつもより おいしいね"]],
  plaza: [6, ["噴水の 音、落ちつくね", "……こうやって ゆっくり 話すの、久しぶりかも"]],
  bench: [1, ["ちょっと 座ろうか", "風が 気持ちいいね。……となり、いい？"]],
};
system.runInterval(() => {
  for (const [pid, D] of DATE) {
    const p = world.getAllPlayers().find((x) => x.id === pid);
    if (!p || !ok(D.e) || Date.now() - D.t > 6 * 60000 || hv(p.location, D.e.location) > 40) { if (p) dateEnd(p, D, false); else DATE.delete(pid); busyOff(D.e); continue; }
    if (D.wait > 0) { D.wait--; if (D.wait === 0) { act(D.e, 0); D.i++; if (D.i >= D.spots.length) dateEnd(p, D, true); } continue; }
    const S = D.spots[D.i];
    /* 相手は プレイヤーの 少し うしろを ついて くる */
    const l = p.location, yaw = (p.getRotation().y * Math.PI) / 180, tx = l.x + Math.sin(yaw) * 1.4 + Math.cos(yaw) * 0.9, tz = l.z - Math.cos(yaw) * 1.4 + Math.sin(yaw) * 0.9;
    const dx = tx - D.x, dz = tz - D.z, dd = Math.hypot(dx, dz);
    if (dd > 0.4) { const k = Math.min(1, 0.55 / dd); let nx = D.x + dx * k, nz = D.z + dz * k, ny = standY(nx, nz, D.y); if (ny === undefined) ny = l.y; if (ny !== null) { D.x = nx; D.z = nz; D.y = ny; } else if (dd > 6) { D.x = tx; D.z = tz; D.y = l.y; } try { D.e.setProperty("mrpg:mv", true); D.e.teleport({ x: D.x, y: D.y, z: D.z }, { facingLocation: { x: l.x, y: l.y + 1.5, z: l.z } }); } catch {} }
    else try { D.e.setProperty("mrpg:mv", false); } catch {}
    try { barNote(p).setActionBar(`§d♪ デート中 §f次は ${SPOTN[S.k]}へ §7（${Math.round(hv(l, S))}m）`); } catch {}
    if (hv(l, S) < 4 && hv(D.e.location, S) < 5) {
      const [a, L] = SCENE[S.k] || SCENE.plaza;
      try { D.e.setProperty("mrpg:mv", false); } catch {} faceTo(D.e, p); act(D.e, a); hearts(D.e);
      line(p, D.e, L[0]); system.runTimeout(() => { if (ok(D.e)) line(p, D.e, L[1]); }, 60);
      addAff(p, D.e, 2); D.wait = 30;
    }
  }
}, 4);

// ---------- 鬼ごっこ（近くの 町の 人 3人を つかまえる）----------
const TAG = new Map();   /* pid → { list:[{e,x,y,z,got}], t } */
function tagStart(p, e0) {
  const L = [e0];
  try { for (const e of OW().getEntities({ type: "mrpg:npc", tags: ["mrpg_walker"], location: p.location, maxDistance: 24 })) { if (L.length >= 3) break; if (e.id !== e0.id && !e.hasTag("mrpg_busyw") && !e.hasTag("mrpg_beach")) L.push(e); } } catch {}
  const list = L.filter((e) => busyOn(e)).map((e) => { const l = e.location; return { e, x: l.x, y: l.y, z: l.z, got: false }; });
  if (!list.length) { line(p, e0, "ごめんね、今は ちょっと……"); return; }
  TAG.set(p.id, { list, t: Date.now() });
  for (const r of list) { act(r.e, 9); }
  line(p, e0, `鬼ごっこ？ いいよ！ ${list.length}人 ぜんぶ つかまえられるかな？ よーい、どん！`);
  try { p.sendMessage(`§e鬼ごっこ！ §f60秒で ${list.length}人に さわろう（近づくと つかまえる）`); } catch {}
}
function tagEnd(p, T, won) {
  TAG.delete(p.id);
  for (const r of T.list) { busyOff(r.e); act(r.e, won ? 6 : 9); system.runTimeout(() => act(r.e, 0), 60); if (won) addAff(p, r.e, 2); }
  const d = load(p);
  if (won && d) { const ex = JSON.parse(p.getDynamicProperty("mrpg:tagd") || "0") === day(); let g = ""; if (!ex) { g = boon(p, d, 1); save(p, d); try { p.setDynamicProperty("mrpg:tagd", JSON.stringify(day())); } catch {} } try { p.sendMessage(`§a全員 つかまえた！ ${g}`); } catch {} sound(p, "random.levelup", 1); }
  else try { p.sendMessage("§7時間ぎれ……。みんな 楽しそうに 笑って いる"); } catch {}
}
system.runInterval(() => {
  for (const [pid, T] of TAG) {
    const p = world.getAllPlayers().find((x) => x.id === pid); if (!p) { TAG.delete(pid); for (const r of T.list) busyOff(r.e); continue; }
    const left = 60 - Math.floor((Date.now() - T.t) / 1000); if (left <= 0) { tagEnd(p, T, false); continue; }
    const l = p.location; let rest = 0;
    for (const r of T.list) {
      if (r.got || !ok(r.e)) continue;
      const d = Math.hypot(r.x - l.x, r.z - l.z);
      if (d < 1.6) { r.got = true; act(r.e, 12); sound(p, "random.pop", 1); try { p.sendMessage(`§eつかまえた！ §f${nmOf(r.e)}`); } catch {} continue; }
      rest++;
      if (d < 9) {   /* 逃げる（壁は よける）*/
        const ax = (r.x - l.x) / (d || 1), az = (r.z - l.z) / (d || 1);
        for (const [cx, cz] of [[ax, az], [ax - az * 0.8, az + ax * 0.8], [ax + az * 0.8, az - ax * 0.8], [-az, ax], [az, -ax]]) {
          const n = Math.hypot(cx, cz) || 1, nx = r.x + cx / n * 0.62, nz = r.z + cz / n * 0.62, ny = standY(nx, nz, r.y);
          if (ny === null) continue; r.x = nx; r.z = nz; if (ny !== undefined) r.y = ny; break;
        }
        try { r.e.setProperty("mrpg:mv", true); r.e.teleport({ x: r.x, y: r.y, z: r.z }, { facingLocation: { x: r.x + (r.x - l.x), y: r.y + 1.5, z: r.z + (r.z - l.z) } }); } catch {}
      } else try { r.e.setProperty("mrpg:mv", false); r.e.teleport({ x: r.x, y: r.y, z: r.z }, { facingLocation: { x: l.x, y: l.y + 1.5, z: l.z } }); } catch {}
    }
    try { barNote(p).setActionBar(`§e鬼ごっこ §fのこり ${rest}人 §7（${left}秒）`); } catch {}
    if (!rest) tagEnd(p, T, true);
  }
}, 4);

// ---------- 話しかけた とき ----------
const isTown = (e) => { try { return (e.hasTag("mrpg_walker") || e.hasTag("mrpg_patron")) && !e.hasTag("mrpg_beach") && !e.hasTag("mrpg_trouble"); } catch { return false; } };
NPC_HOOKS.unshift((p, e) => {
  if (!isTown(e)) return false;
  let sn = false; try { sn = !!p.isSneaking; } catch {} if (sn) return false;
  if (busy.has(p.id) || DATE.has(p.id) || TAG.has(p.id)) { if (DATE.has(p.id) && DATE.get(p.id).e.id === e.id) line(p, e, "うん、ちゃんと ついて いくよ"); return true; }
  let it = null; try { it = p.getComponent("minecraft:inventory")?.container?.getItem(p.selectedSlotIndex ?? 0); } catch {}
  if (it && giftKind(it.typeId)) { giveGift(p, e, it); return true; }
  let bw = false; try { bw = e.hasTag("mrpg_busyw"); } catch {}
  if (bw) { line(p, e, "ごめんね、今 ほかの 人と 遊んでる ところなんだ"); return true; }   /* マルチ: ほかの 人の デート・鬼ごっこの 相手 */
  menu(p, e);
  return true;
});
async function menu(p, e) {
  busy.add(p.id);
  try {
    const nm = nmOf(e), R = relOf(p, nm), a = R.a || 0;
    const HP = (() => { try { return helperOpt(p, e); } catch { return null; } })();   /* 第124版: 町の 外の 役に 立つ 人は 仕事を 先頭に */
    faceTo(e, p); act(e, HP ? HP.a : 5); if (HP) line(p, e, HP.hello);
    const patron = (() => { try { return e.hasTag("mrpg_patron"); } catch { return false; } })();
    const O = [["talk", "話す", "i_book"], ["duel", "モンスター勝負", "i_fight"]];
    if (HP) O.unshift(["job", HP.t, HP.ic]);
    O.push(["fun", "いっしょに 過ごす", "i_party"]);
    if (!patron) { if (!isKid(nm)) O.push(["date", a >= 12 ? "デートに 誘う" : "§8デートに 誘う（★★ から）", "i_star"]); O.push(["tag", "鬼ごっこを する", "i_run"]); }
    const EXO = (() => { try { return extraOpts(p, e); } catch { return []; } })();
    for (const x of EXO) O.push(["ex", x.t, x.ic, x.run]);
    O.push(["omiai", a >= 20 ? "お見合い配合" : "§8お見合い配合（★★ を こえたら）", "i_egg"]);
    const c = await choose(p, `${nm}  ${heartStr(a)}`, `§f好きな もの: §e${GN[favOf(nm)]}§7（手に 持って 話しかけると 贈れる）`, [...O.map(([, t, ic]) => [t, ICON(ic)]), ["§7またね", ICON("i_back")]]);
    act(e, 0);
    const k = O[c]?.[0]; if (!k) return;
    if (k === "job") { await HP.run(); return; }
    if (k === "talk") { busy.delete(p.id); chatWith(p, e, nm, "町の人", greetLine(p, nm)); return; }
    if (k === "fun") { await interMenu(p, e); return; }
    if (k === "ex") { O[c][3](); return; }
    if (k === "duel") { busy.delete(p.id); await duel(p, e); return; }
    if (k === "omiai") { await omiai(p, e); return; }
    if (k === "date") { if (isKid(nm)) return; if (a < 12) { line(p, e, "デート？ ……もう 少し 仲よく なってから、ね？"); return; } dateStart(p, e); return; }
    if (k === "tag") { tagStart(p, e); return; }
  } catch {} finally { busy.delete(p.id); }
}

// ---------- 酒場の 夜（客が 踊り、音楽が 鳴る）----------
let TT = 0;
system.runInterval(() => {
  TT++;
  let night = false; try { const t = world.getTimeOfDay(); night = t > 12500 && t < 23000; } catch {}
  for (const p of world.getAllPlayers()) {
    let L = []; try { L = p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_patron"], location: p.location, maxDistance: 14 }); } catch {}
    for (const e of L) {
      let place = ""; try { place = e.getDynamicProperty("mrpg:place") || ""; } catch {}
      if (place !== "tavern") continue;
      let a0 = 0; try { a0 = e.getDynamicProperty("mrpg:act0"); if (typeof a0 !== "number") { a0 = e.getProperty("mrpg:act") || 3; e.setDynamicProperty("mrpg:act0", a0); } } catch {}
      act(e, night && (TT + hashS(e.id)) % 3 !== 0 ? 7 : a0);
    }
    if (night && L.length && TT % 2 === 0) { const N = [0.7, 0.8, 0.9, 1.05, 1.2]; try { p.playSound("note.harp", { pitch: pick(N), volume: 0.5 }); } catch {} }
  }
}, 40);
// ---------- 第111版: 店の 人の あいさつ・大聖堂の 昼の 鐘と 歌 ----------
const GREET = new Map();
let BT2 = 0;
system.runInterval(() => {
  BT2++;
  let t = 0; try { t = world.getTimeOfDay(); } catch {}
  for (const p of world.getAllPlayers()) {
    let L = []; try { L = p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_patron"], location: p.location, maxDistance: 5 }); } catch {}
    for (const e of L) {
      let pl = ""; try { pl = e.getDynamicProperty("mrpg:place") || ""; } catch {}
      if (!["bakery", "flower", "tailor"].includes(pl)) continue;
      const k = p.id + e.id; if (Date.now() - (GREET.get(k) || 0) < 120000) continue; GREET.set(k, Date.now()); if (GREET.size > 300) GREET.clear();
      faceTo(e, p); act(e, 5); system.runTimeout(() => act(e, 0), 40);
      line(p, e, { bakery: "いらっしゃい。焼きたての パンが ありますよ", flower: "いらっしゃいませ。今日は 白い 花が きれいに 咲きました", tailor: "いらっしゃい。旅の 服、つくろって いきますか" }[pl]);
    }
    /* 昼（6000 前後）は 大聖堂の 鐘と 聖歌 */
    if (t > 5900 && t < 6400) {
      let C = []; try { C = p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_patron"], location: p.location, maxDistance: 40 }).filter((e) => e.getDynamicProperty("mrpg:place") === "choir"); } catch {}
      if (C.length) { if (BT2 % 4 === 0) try { p.playSound("block.bell.hit", { volume: 0.7, pitch: 0.9 }); } catch {} const N = [0.6, 0.7, 0.8, 0.9, 1.0]; try { p.playSound("note.flute", { volume: 0.4, pitch: pick(N) }); } catch {} for (const e of C) act(e, 4); }
    }
  }
}, 40);
export const __social = { DATE, TAG, giveGift, giftKind, favOf, fav2Of, npcMon, duel, menu };
