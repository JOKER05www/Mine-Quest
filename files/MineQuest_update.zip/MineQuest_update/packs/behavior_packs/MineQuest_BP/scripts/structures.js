// 街・遺跡（ボス）の生成。コマンドを少しずつ流して重くならないようにする
import { rollTier, lvBonus, chestCmds, BASE_OF } from "./chests.js";
import { inRuins } from "./ruinsarea.js";
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER } from "./data.js";
import { ri, pick } from "./core.js";
import { load, save } from "./store.js";
import { busy, ok, sound, rankOf, heavy, warming, showTitle, setJob } from "./ui.js";
import { TYPE, setLook, biomeAt, levelAt, pickWild, hooks, hBucket, baseBiome, SIZE_UP, sizeUp } from "./field.js";
import { dressCitizen, resetWalkCache } from "./citylife.js";
import { WREGIONS, regionIdx, townName, castlePos, landSites, HOME, fitScore, setAvoidPoints, regionLv, LAYOUT, LAYOUT2, LAYX, LAYOUT_HOOKS, ensureLayout } from "./worldmap.js";
import { genLand, DG_THEMES, LAND_V } from "./dgthemes.js";
import { dgBuild, dgType, dgL0, dgBoxL, dgProbe } from "./dglayout.js";   /* 第125版: 地方ごとの ダンジョン */
import { stageNear, inLiveBox, boxFree, areaLoaded } from "./stage.js";
import { capitalPlan, townPlan, townPlan2, setEdge } from "./city.js";
import { ruinPlan, RUIN_V } from "./ruincity.js";

// ---------- コマンドキュー ----------
const queue = [];
globalThis.__mqBuildQ = queue;   /* 第127版(RV3): 場面の 舞台が「いま 建てて いる 所」を 知る（stagecore の settle）*/
const RUIN_Q = new Map();
let running = 0;
function run(dim, c) { try { if (typeof dim.runCommand === "function") dim.runCommand(c); else dim.runCommandAsync(c); } catch {} }
const cmdVol = (c) => { const m = typeof c === "string" && c.match(/^(?:fill|clone) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+)/); return m ? (Math.abs(m[4] - m[1]) + 1) * (Math.abs(m[5] - m[2]) + 1) * (Math.abs(m[6] - m[3]) + 1) : 1; };
function enqueue(dim, cmds, done, area, fail, per) { queue.push({ dim, cmds, i: 0, done, area, fail, per, wait: area ? 60 : 0, started: false }); }
system.runInterval(() => {
  const job = queue[0];
  if (!job) return;
  if (!job.started) {
    job.started = true;
    if (job.area) { const [a, b] = job.area; run(job.dim, `tickingarea add ${a.x} ${a.y} ${a.z} ${b.x} ${b.y} ${b.z} mrpg_build`); }
  }
  if (job.wait > 0) { job.wait--; return; }
  if (job.area && !job.ready) {   // v2.9.12: 遠くの 場所を 作る ときは 読みこみが 終わるまで まつ（何も 置かれずに「できた」に ならない）
    const [a, b] = job.area, mx = Math.floor((a.x + b.x) / 2), mz = Math.floor((a.z + b.z) / 2);
    let okL = true; for (const [x, z] of [[a.x, a.z], [b.x, b.z], [a.x, b.z], [b.x, a.z], [mx, mz]]) { try { if (!job.dim.getBlock({ x: Math.floor(x), y: Math.floor(a.y), z: Math.floor(z) })) okL = false; } catch { okL = false; } }
    job.lw = (job.lw || 0) + 1;
    if (!okL && job.lw < 600) return;
    if (!okL) {   // 読みこめなかった: 何も 置かずに やめる（「できた」に しない。あとで また 作る）
      queue.shift(); run(job.dim, "tickingarea remove mrpg_build");
      try { job.fail && job.fail(); } catch {}
      console.warn("[MonsterRPG] build skipped: area not loaded"); return;
    }
    job.ready = true;
  }
  const per = Math.min(job.per || 99, [48, 20, 10][heavy()]);   // v1.7: 重いときは 1tick の コマンドを へらす
  /* 第85版: 1tick に 置きかえる ブロック数も 決める（大きな fill が 重なって 世界が 止まらない ように） */
  const budget = [24000, 12000, 6000][heavy()]; let spent = 0;
  for (let n = 0; n < per && job.i < job.cmds.length; n++, job.i++) {
    const c = job.cmds[job.i], v = cmdVol(c);
    if (n > 0 && spent + v > budget) break;
    spent += v;
    try { if (typeof job.dim.runCommand === "function") job.dim.runCommand(c); else job.dim.runCommandAsync(c); } catch {}
  }
  if (job.i >= job.cmds.length) { queue.shift(); try { job.done && job.done(); } catch (e) { console.warn(`[MonsterRPG] build done: ${e}`); } if (job.area) run(job.dim, "tickingarea remove mrpg_build"); }   /* 第77版: 置き終わってから 読みこみを 外す */
}, 1);
export const building = () => queue.length > 0;

// ---------- ブロック配置ヘルパー（絶対座標） ----------
class Plan {
  constructor(x, y, z) { this.x = Math.floor(x); this.y = Math.floor(y); this.z = Math.floor(z); this.c = []; }
  fill(x1, y1, z1, x2, y2, z2, b, mode = "") {
    // 体積上限 32768 を超えないよう分割
    const [ax, bx] = [Math.min(x1, x2), Math.max(x1, x2)], [ay, by] = [Math.min(y1, y2), Math.max(y1, y2)], [az, bz] = [Math.min(z1, z2), Math.max(z1, z2)];
    // v3.0: 薄い（厚さ 3 以下の）outline は 中まで うまるので、ふちの 輪（4本の 辺）に する（井戸・池・柵・わく）
    if (mode === "outline") {
      const ext = [bx - ax + 1, by - ay + 1, bz - az + 1], thin = ext.indexOf(Math.min(...ext));
      if (ext[thin] <= 3 && ext.filter((e, i) => i !== thin).every((e) => e >= 3)) {
        const lo = [ax, ay, az], hi = [bx, by, bz], [u, v] = [0, 1, 2].filter((i) => i !== thin);
        const edge = (iu0, iu1, iv0, iv1) => { const a0 = [...lo], a1 = [...hi]; a0[u] = iu0; a1[u] = iu1; a0[v] = iv0; a1[v] = iv1; this.fill(a0[0], a0[1], a0[2], a1[0], a1[1], a1[2], b); };
        edge(lo[u], hi[u], lo[v], lo[v]); edge(lo[u], hi[u], hi[v], hi[v]); edge(lo[u], lo[u], lo[v] + 1, hi[v] - 1); edge(hi[u], hi[u], lo[v] + 1, hi[v] - 1);
        return;
      }
    }
    const vol = (bx - ax + 1) * (by - ay + 1) * (bz - az + 1);
    if (vol > 30000) {
      const mx = Math.floor((ax + bx) / 2);
      this.fill(ax, ay, az, mx, by, bz, b, mode); this.fill(mx + 1, ay, az, bx, by, bz, b, mode); return;
    }
    this.c.push(`fill ${this.x + ax} ${this.y + ay} ${this.z + az} ${this.x + bx} ${this.y + by} ${this.z + bz} ${b}${mode ? " " + mode : ""}`);
  }
  set(x, y, z, b) { this.c.push(`setblock ${this.x + x} ${this.y + y} ${this.z + z} ${b}`); }
  // v2.6.1: 宝箱は レア度（10段階）を その場で きめる
  loot(x, y, z, table) { const X = this.x + x, Y = this.y + y, Z = this.z + z, dim = this.dim || "minecraft:overworld"; const bonus = dim === "minecraft:nether" ? 2 : dim === "minecraft:the_end" ? 3 : lvBonus({ x: X, z: Z }); this.c.push(...chestCmds(X, Y, Z, rollTier(BASE_OF[table] ?? 2, bonus), dim)); }
  at(x, y, z) { return { x: this.x + x + 0.5, y: this.y + y, z: this.z + z + 0.5 }; }
  area(r) { return [{ x: this.x - r, y: this.y - 5, z: this.z - r }, { x: this.x + r, y: this.y + 20, z: this.z + r }]; }
}

export function groundY(dim, x, z, fromY) {
  // v2.9.12: 足もとに いちばん 近い「立てる 場所」（上と 下を 交互に さがす。洞くつや ネザーで 岩の 中に ならない）
  x = Math.floor(x); z = Math.floor(z);
  const C = new Map();
  const blk = (y) => { if (C.has(y)) return C.get(y); let b = null; try { b = dim.getBlock({ x, y, z }) || null; } catch { b = undefined; } C.set(y, b); return b; };
  const open = (b) => b && (b.isAir || (!b.isLiquid && /leaves|short_grass|tall_grass|tallgrass|fern|flower|bush|snow_layer|vine|sapling|petals|_roots$|mushroom$|torch|carpet/.test(b.typeId) && !/leaves/.test(b.typeId)));
  const solid = (b) => b && !b.isAir && !b.isLiquid && !/leaves|log|grass$|tallgrass|fern|flower|bush|snow_layer|vine|sapling|petals|torch|carpet/.test(b.typeId);
  for (let d = 0; d <= 50; d++) {
    for (const y of d === 0 ? [fromY] : [fromY - d, fromY + d]) {
      if (y < -63 || y > 318 || (y > fromY + 40)) continue;
      const b = blk(y), u = blk(y + 1), dn = blk(y - 1);
      if (b === undefined || dn === undefined) return null;
      if (open(b) && (u === null || open(u)) && solid(dn)) return y;
    }
  }
  return null;
}

// v2.9.12: 本当の 地表（上から さがす。木・葉・きのこ・草は 地面に しない。洞くつの 中に 建てない）
const NOT_GROUND = /leaves|_log$|_wood$|^minecraft:log|stem$|mushroom_block|vine|bamboo|tallgrass|short_grass|tall_grass|fern|flower|bush|snow_layer|sapling|petals|cactus|sugar_cane|reeds|lily|kelp|seagrass|azalea|carpet|dripleaf|_roots$|hanging|cocoa|torch|lantern|web|pointed_dripstone/;
export function surfaceY(dim, x, z) {
  x = Math.floor(x); z = Math.floor(z);
  let top = 319;
  try { if (typeof dim.getTopmostBlock === "function") { const t = dim.getTopmostBlock({ x, z }); if (!t) return null; top = t.location.y; } } catch { return null; }
  for (let y = top; y > -60; y--) {
    let b; try { b = dim.getBlock({ x, y, z }); } catch { return null; }
    if (!b) return null;
    if (b.isAir || NOT_GROUND.test(b.typeId)) continue;
    return y + 1;
  }
  return null;
}
// 何か所か はかって まん中の 高さ（木の 穴や 崖の ふちで ずれない）
export function spotY(dim, x, z, r = 10) {
  const L = [];
  for (const [dx, dz] of [[0, 0], [r, 0], [-r, 0], [0, r], [0, -r]]) { const y = surfaceY(dim, x + dx, z + dz); if (y === null) return null; L.push(y); }
  L.sort((a, b) => a - b); return L[2];
}
// v2.9.12: まわりの 水面の 高さ（城・町・ステージを 水より 上に 作る。中が 水びたしに ならない ように）
export function waterTop(dim, x, z, r = 26, y0 = null) {
  let top = -999;   /* v2.9.12: y0 が あれば その 高さの 近くの 水だけ 数える（山の 上の 池で 宙に 浮かない ように） */
  for (let dx = -r; dx <= r; dx += Math.max(4, Math.floor(r / 4))) for (let dz = -r; dz <= r; dz += Math.max(4, Math.floor(r / 4))) {
    try { const t = dim.getTopmostBlock?.({ x: Math.floor(x + dx), z: Math.floor(z + dz) }); if (t && (t.isLiquid || /water|lava/.test(t.typeId)) && (y0 === null || (t.location.y >= y0 - 4 && t.location.y <= y0 + 3))) top = Math.max(top, t.location.y); } catch {}
  }
  return top;
}
export const dryY = (dim, x, z, y, r = 26) => { if (y === null || y === undefined) return y; const w = waterTop(dim, x, z, r, y); return w > -999 ? Math.max(y, w + 1) : y; };
const owY = (dim, x, z, fromY) => (dim.id === "minecraft:overworld" ? dryY(dim, x, z, spotY(dim, x, z), 18) : groundY(dim, x, z, fromY));

// ---------- 街 ----------
// 街: tier = 品ぞろえの グレード、el = 得意な 属性、style = 見た目、eggs = タマゴ屋の品、fams = モンスター屋の 得意系統
const T0 = [
  { id: "t0", name: "始まりの町 ルミナ", dx: 0, dz: 0, wall: "oak_planks", roof: "dark_oak_planks", tier: 0, el: "light", style: "village", eggs: ["e_white", "e_bronze"], fams: ["blob", "beast", "animal"], pm: 1.0 },
  { id: "t1", name: "みなとまち マリネア", dx: 450, dz: 0, wall: "birch_planks", roof: "prismarine_bricks", tier: 1, el: "ice", style: "port", eggs: ["e_white", "e_bronze", "e_blue"], fams: ["aqua", "blob", "animal"], pm: 1.0 },
  { id: "t2", name: "森のむら シルバ", dx: -450, dz: 0, wall: "spruce_planks", roof: "spruce_log", tier: 1, el: "earth", style: "forest", eggs: ["e_white", "e_bronze"], fams: ["animal", "animal", "beast"], pm: 0.95 },
  { id: "t3", name: "砂のまち サブラ", dx: 0, dz: 450, wall: "smooth_sandstone", roof: "cut_sandstone", tier: 1, el: "fire", style: "desert", eggs: ["e_bronze", "e_red"], fams: ["golem", "nether", "animal"], pm: 1.05 },
  { id: "t4", name: "ゆきのむら フロスト", dx: 0, dz: -450, wall: "spruce_planks", roof: "snow", tier: 1, el: "ice", style: "snow", eggs: ["e_white", "e_bronze", "e_blue"], fams: ["aqua", "beast", "blob"], pm: 1.0 },
  { id: "t5", name: "山のまち ガルド", dx: 800, dz: 800, wall: "stone_bricks", roof: "deepslate_tiles", tier: 2, el: "earth", style: "castle", eggs: ["e_bronze", "e_silver"], fams: ["golem", "dragon", "sword"], pm: 1.0 },
  { id: "t6", name: "はなのまち フローラ", dx: -800, dz: 800, wall: "white_terracotta", roof: "pink_terracotta", tier: 2, el: "wind", style: "garden", eggs: ["e_bronze", "e_silver", "e_blue"], fams: ["animal", "animal", "animal"], pm: 0.95 },
  { id: "t7", name: "星のまち ステラ", dx: 800, dz: -800, wall: "quartz_block", roof: "blue_terracotta", tier: 2, el: "light", style: "sky", eggs: ["e_silver", "e_blue"], fams: ["golem", "animal", "blob"], pm: 1.1 },
  { id: "t8", name: "闇のまち ノクス", dx: -800, dz: -800, wall: "polished_blackstone_bricks", roof: "crimson_planks", tier: 2, el: "dark", style: "dark", eggs: ["e_silver", "e_black"], fams: ["nether", "nether", "dragon"], pm: 1.05 },
];
// 追加の 30の街（3つの わ）
const NEW_TOWNS = [
  // わ1（1300ブロック・tier3）
  ["きりのまち ミスティア", "birch_planks", "gray_terracotta", "wind", "forest", ["e_silver", "e_blue"], ["animal", "animal", "nether"]],
  ["こはんのむら レイクス", "oak_planks", "cyan_terracotta", "ice", "port", ["e_silver", "e_blue"], ["aqua", "blob", "animal"]],
  ["ぶどうのさと ヴィネア", "stripped_oak_log", "purple_terracotta", "earth", "farm", ["e_bronze", "e_silver", "e_red"], ["animal", "beast", "animal"]],
  ["いしきりのまち クオリ", "polished_andesite", "stone_bricks", "earth", "castle", ["e_silver", "e_black"], ["golem", "golem", "beast"]],
  ["かじやのまち フォージ", "brick_block", "deepslate_tiles", "fire", "volcano", ["e_silver", "e_red"], ["sword", "golem", "dragon"]],
  ["ひばなのまち ヒバナ", "red_terracotta", "black_terracotta", "fire", "desert", ["e_silver", "e_red"], ["dragon", "nether", "beast"]],
  ["ほたるのむら ホタル", "jungle_planks", "moss_block", "light", "forest", ["e_silver", "e_blue"], ["animal", "animal", "animal"]],
  ["うらないのまち ルーネ", "purpur_block", "purple_terracotta", "dark", "crystal", ["e_silver", "e_black"], ["nether", "blob", "nether"]],
  // わ2（1900ブロック・tier4）
  ["氷のみやこ グラシア", "packed_ice", "blue_ice", "ice", "snow", ["e_silver", "e_blue", "e_rainbow"], ["aqua", "beast", "dragon"]],
  ["砂のおうと デザール", "cut_sandstone", "orange_terracotta", "fire", "desert", ["e_silver", "e_red", "e_rainbow"], ["golem", "nether", "animal"]],
  ["海ねこのみなと カモメラ", "spruce_planks", "light_blue_terracotta", "wind", "port", ["e_silver", "e_blue"], ["animal", "aqua", "beast"]],
  ["きのこのもり マシュリ", "mushroom_stem", "red_mushroom_block", "earth", "forest", ["e_silver", "e_black"], ["animal", "animal", "blob"]],
  ["かざんのまち ボルカ", "blackstone", "magma", "fire", "volcano", ["e_silver", "e_red", "e_rainbow"], ["dragon", "golem", "nether"]],
  ["空のはし アーチェス", "smooth_quartz", "light_blue_terracotta", "wind", "sky", ["e_silver", "e_blue"], ["animal", "golem", "dragon"]],
  ["古いとしょかん ビブリア", "dark_oak_planks", "bookshelf", "dark", "castle", ["e_silver", "e_black"], ["nether", "nether", "golem"]],
  ["闇いちの 街 ブラクマ", "deepslate_bricks", "crimson_planks", "dark", "dark", ["e_black", "e_red", "e_rainbow"], ["nether", "nether", "sword"]],
  ["きんこうのまち オーリム", "smooth_sandstone", "gold_block", "light", "castle", ["e_silver", "e_rainbow"], ["golem", "sword", "golem"]],
  ["しずくのさと ドロップ", "prismarine_bricks", "dark_prismarine", "ice", "port", ["e_blue", "e_silver"], ["aqua", "blob", "animal"]],
  // わ3（2600ブロック・tier5）
  ["りゅうのたに ドラグナ", "deepslate_bricks", "red_nether_brick", "fire", "volcano", ["e_red", "e_rainbow"], ["dragon", "beast", "golem"]],
  ["てんくうのしろ セレスタ", "quartz_bricks", "white_concrete", "light", "sky", ["e_rainbow", "e_silver"], ["animal", "golem", "blob"]],
  ["めいかいのもん ネクロス", "polished_blackstone_bricks", "black_concrete", "dark", "dark", ["e_black", "e_rainbow"], ["nether", "nether", "animal"]],
  ["せいれいのもり エルフィ", "birch_planks", "moss_block", "wind", "forest", ["e_blue", "e_rainbow"], ["animal", "animal", "blob"]],
  ["きかいのとし メカニカ", "iron_block", "gray_concrete", "thunder", "castle", ["e_silver", "e_rainbow"], ["golem", "golem", "sword"]],
  ["ほうせきのまち ジュエラ", "amethyst_block", "purple_concrete", "thunder", "crystal", ["e_rainbow", "e_silver"], ["golem", "blob", "nether"]],
  ["つきのしんでん ルナリア", "end_bricks", "purpur_block", "dark", "crystal", ["e_black", "e_rainbow"], ["nether", "nether", "animal"]],
  ["たいようのまち ソラリス", "smooth_sandstone", "yellow_concrete", "light", "desert", ["e_red", "e_rainbow"], ["golem", "animal", "dragon"]],
  ["まおうのあと ディアボ", "nether_brick", "red_nether_brick", "dark", "dark", ["e_black", "e_red", "e_rainbow"], ["nether", "dragon", "nether"]],
  ["らいうんの 街 ボルティア", "polished_deepslate", "cyan_concrete", "thunder", "castle", ["e_blue", "e_rainbow"], ["golem", "animal", "animal"]],
  ["げんそうのまち ファンタ", "pink_concrete", "light_blue_concrete", "light", "garden", ["e_rainbow", "e_blue"], ["blob", "animal", "animal"]],
  ["星降るおか スターリィ", "quartz_block", "blue_concrete", "light", "sky", ["e_rainbow", "e_silver"], ["animal", "blob", "golem"]],
  // v2.2 わ4（3400ブロック・tier6）
  ["くろがねの 砦 アイゼン", "iron_block", "deepslate_tiles", "steel", "castle", ["e_silver", "e_rainbow"], ["golem", "sword", "dragon"]],
  ["かすみの さと カスミ", "bamboo_planks", "green_terracotta", "wind", "forest", ["e_blue", "e_rainbow"], ["animal", "animal", "animal"]],
  ["さんごの みやこ コーラル", "prismarine_bricks", "light_blue_concrete", "water", "port", ["e_blue", "e_rainbow"], ["aqua", "blob", "aqua"]],
  ["こおりの 宮殿 フリギア", "packed_ice", "white_concrete", "ice", "snow", ["e_blue", "e_rainbow"], ["aqua", "beast", "dragon"]],
  ["あかつきの 城 オーロラ", "quartz_bricks", "orange_concrete", "light", "castle", ["e_rainbow", "e_silver"], ["animal", "golem", "sword"]],
  ["らいめいの 塔 トニトル", "polished_deepslate", "yellow_concrete", "thunder", "crystal", ["e_rainbow", "e_blue"], ["golem", "animal", "animal"]],
  ["こけむす 遺跡 モスカ", "mossy_stone_bricks", "moss_block", "wood", "forest", ["e_rainbow", "e_silver"], ["animal", "animal", "nether"]],
  ["ようがんの 都 マグマラ", "blackstone", "red_nether_brick", "fire", "volcano", ["e_red", "e_rainbow"], ["dragon", "nether", "golem"]],
  ["ほしくずの 浜 ステラマリ", "smooth_sandstone", "blue_concrete", "water", "port", ["e_blue", "e_rainbow"], ["aqua", "animal", "blob"]],
  ["こだいの 王墓 ファラン", "chiseled_sandstone", "gold_block", "earth", "desert", ["e_red", "e_rainbow"], ["nether", "golem", "animal"]],
  ["よいやみの 市 ノクターナ", "deepslate_bricks", "purple_concrete", "dark", "dark", ["e_black", "e_rainbow"], ["nether", "nether", "blob"]],
  ["たいじゅの 里 ユグド", "oak_log", "azalea_leaves", "wood", "garden", ["e_rainbow", "e_blue"], ["animal", "beast", "animal"]],
  ["けんせいの 道場 ツルギ", "spruce_planks", "dark_oak_planks", "steel", "village", ["e_silver", "e_rainbow"], ["sword", "sword", "beast"]],
  ["はるかぜの 丘 ハルカ", "birch_planks", "pink_concrete", "wind", "garden", ["e_rainbow", "e_blue"], ["animal", "animal", "blob"]],
  // v2.2 わ5（4300ブロック・tier7・いちばん 品ぞろえが 豊富）
  ["せかいの はて エンディア", "end_bricks", "purpur_block", "dark", "crystal", ["e_rainbow", "e_king"], ["nether", "dragon", "nether"]],
  ["りゅうおうの 都 ドラコニア", "deepslate_bricks", "red_nether_brick", "fire", "volcano", ["e_rainbow", "e_king"], ["dragon", "dragon", "beast"]],
  ["てんかいの 門 セレス", "quartz_block", "gold_block", "light", "sky", ["e_rainbow", "e_king"], ["animal", "golem", "blob"]],
  ["ふかうみの 神殿 アビッソ", "dark_prismarine", "sea_lantern", "water", "port", ["e_rainbow", "e_king"], ["aqua", "aqua", "dragon"]],
  ["ぎんがの 図書館 ガラクシア", "dark_oak_planks", "bookshelf", "thunder", "castle", ["e_rainbow", "e_king"], ["golem", "nether", "blob"]],
  ["まかいの 入口 ゲヘナ", "nether_brick", "crimson_planks", "dark", "dark", ["e_black", "e_rainbow", "e_king"], ["nether", "nether", "dragon"]],
  ["ぜっぺきの 城 アルピナ", "stone_bricks", "snow", "ice", "snow", ["e_rainbow", "e_king"], ["beast", "dragon", "golem"]],
  ["こがねの 砂城 アウルム", "cut_sandstone", "gold_block", "earth", "desert", ["e_rainbow", "e_king"], ["golem", "nether", "animal"]],
  ["らいてい 宮 ヴォルト", "polished_blackstone_bricks", "cyan_concrete", "thunder", "crystal", ["e_rainbow", "e_king"], ["golem", "animal", "dragon"]],
  ["せいじゅの 森 シルヴァナ", "jungle_planks", "moss_block", "wood", "forest", ["e_rainbow", "e_king"], ["animal", "animal", "beast"]],
  ["ほのおの 神殿 イグニス", "red_terracotta", "magma", "fire", "volcano", ["e_red", "e_rainbow", "e_king"], ["dragon", "nether", "beast"]],
  ["かぜの 神殿 ゼフィラ", "smooth_quartz", "light_blue_concrete", "wind", "sky", ["e_rainbow", "e_king"], ["animal", "animal", "dragon"]],
  ["まどうの 学府 アルカナ", "purpur_block", "purple_terracotta", "dark", "crystal", ["e_rainbow", "e_king"], ["nether", "blob", "nether"]],
  ["はがねの 都 メタリカ", "iron_block", "gray_concrete", "steel", "castle", ["e_rainbow", "e_king"], ["golem", "sword", "golem"]],
  ["ひかりの 聖都 ルクス", "quartz_bricks", "white_concrete", "light", "castle", ["e_rainbow", "e_king", "e_god"], ["golem", "animal", "sword"]],
  ["とこよの 里 トコヨ", "crimson_planks", "black_concrete", "dark", "dark", ["e_black", "e_rainbow", "e_king"], ["nether", "nether", "sword"]],
];
// v2.2: 間かくを 半分に（リスポーンの 近くに あつめた）
// v3.0: 世界を ちぢめた（となりの 町まで 300〜500 ブロック）
const RING = [[360, 8, 22.5, 3], [520, 10, 0, 4], [680, 12, 15, 5], [820, 14, 6, 6], [940, 16, 11.25, 7]];
for (const t of T0) { t.dx = Math.round(t.dx * 0.42); t.dz = Math.round(t.dz * 0.42); }   // 450 → 190・800 → 336
let ti = 0;
const T1 = [];
for (const [r, n, a0, tier] of RING) for (let k = 0; k < n; k++) {
  const [name, wall, roof, el, style, eggs, fams] = NEW_TOWNS[ti];
  const a = ((a0 + (360 / n) * k) * Math.PI) / 180;
  T1.push({ id: `t${9 + ti}`, name, dx: Math.round(Math.cos(a) * r), dz: Math.round(Math.sin(a) * r), wall, roof, tier, el, style, eggs, fams, pm: 0.9 + ((ti * 7) % 5) * 0.06 });
  ti++;
}
// v2.3: 町を 地方に あわせる（名前・見た目・すむ モンスター）
const STYLE_MAT = { village: ["oak_planks", "dark_oak_planks"], forest: ["spruce_planks", "spruce_log"], castle: ["stone_bricks", "deepslate_tiles"], volcano: ["blackstone", "red_nether_brick"], desert: ["smooth_sandstone", "cut_sandstone"],
  crystal: ["calcite", "purple_terracotta"], port: ["birch_planks", "prismarine_bricks"], dark: ["polished_blackstone_bricks", "crimson_planks"], snow: ["spruce_planks", "snow"], sky: ["quartz_block", "light_blue_terracotta"] };
const _rc = {};
for (const t of [...T0, ...T1]) {
  const i = regionIdx(t.dx, t.dz), R = WREGIONS[i];
  t.reg = i;
  if (t.id === "t0") continue;
  const k = (_rc[i] = (_rc[i] || 0) + 1) - 1;
  t.name = townName(i, k);
  t.style = R.style === "castle" && k % 2 ? "village" : R.style;
  [t.wall, t.roof] = STYLE_MAT[t.style] || STYLE_MAT.village;
  t.fams = Object.entries(R.fams).sort((a, b) => b[1] - a[1]).map((x) => x[0]).slice(0, 3);
}
export const TOWNS = [...T0, ...T1];
// v3.0: ステージは 町と 城を さけて おく（町・城の 位置を わたす）
// 城の ずらし方（スポーンからの ずれ）。castleSpot と 同じ 決まり
function castleOff(i) {
  const R = WREGIONS[i], a = R.castle.at || R.c;
  for (let k = 0; k < 8; k++) {
    const x = a[0] + [0, 80, -80, 0, 0, 120, -120, 0][k], z = a[1] + [0, 0, 0, 80, -80, 0, 0, 120][k];
    if (TOWNS.every((t) => Math.hypot(t.dx - x, t.dz - z) > 110)) return [x, z];
  }
  return [a[0], a[1]];
}
setAvoidPoints([...TOWNS.map((t) => [t.dx, t.dz]), ...WREGIONS.map((R, i) => castleOff(i))]);
/* 第99版: 寄せた 配置（LAYOUT 2）では 町の 位置を 表から */
const TBASE = TOWNS.map((t) => [t.dx, t.dz]);
function townLayout(v) { TOWNS.forEach((t, i) => { const q = v >= 2 && LAYX(v).towns[t.id]; [t.dx, t.dz] = q ? [q[0], q[1]] : TBASE[i]; }); try { TCACHE.clear(); } catch {} }
LAYOUT_HOOKS.push(townLayout); system.run(() => { if (LAYOUT.v >= 2) townLayout(LAYOUT.v); });
export const JOBS = ["武器屋", "防具屋", "宿屋", "道具屋", "タマゴ屋", "闘技場", "預かり屋", "案内人", "マスター", "マスター", "マスター", "モンスター屋", "図書館", "物知り", "釣り屋", "王", "衛兵"];
export function townPos(t) {
  if (!LAYOUT.ok) ensureLayout();
  const s = world.getDefaultSpawnLocation();
  const info = getTown(t.id);
  if (info) return info;
  return { x: s.x + t.dx, y: null, z: s.z + t.dz };
}
const LAND_Q = new Set();   // v2.9.8: いま 作って いる ステージ
// v2.9.6: 町の 情報は キャッシュ（掘る・出現の たびに JSON を 読まない）
const TCACHE = new Map(); let TC_T = 0;
export function getTown(id) {
  const now = system.currentTick;
  if (now - TC_T > 1200) { TCACHE.clear(); TC_T = now; }   /* 第99版: 書く ときに 消すので 1分ごとで 十分 */
  if (TCACHE.has(id)) return TCACHE.get(id);
  const v = world.getDynamicProperty(`mrpg:town:${id}`);
  let r = null; try { r = typeof v === "string" ? JSON.parse(v) : null; } catch {}
  TCACHE.set(id, r); return r;
}
function setTown(id, v) { world.setDynamicProperty(`mrpg:town:${id}`, JSON.stringify(v)); TCACHE.delete(id); }
export function townAt(loc, r = 40) {
  for (const t of TOWNS) { const i = getTown(t.id); if (i && i.built && Math.hypot(loc.x - i.x, loc.z - i.z) <= r) return t; }
  return null;
}

// v2.9: 家を 町の スタイルごとに 作りわける（屋根の 形・柱・窓・かざり）
const HSTY = {
  village: { floor: "oak_planks", post: "oak_log", trim: "stripped_oak_log", roof: "gable", win: "glass_pane", deco: "flowerbox", chim: true },
  farm: { floor: "oak_planks", post: "oak_log", trim: "hay_block", roof: "gable", win: "glass_pane", deco: "flowerbox", chim: true },
  forest: { floor: "spruce_planks", post: "spruce_log", trim: "stripped_spruce_log", roof: "steep", win: "glass_pane", deco: "moss", chim: true, logwall: "spruce_log" },
  port: { floor: "spruce_planks", post: "stripped_birch_log", trim: "light_blue_terracotta", roof: "hip", win: "glass_pane", deco: "barrel", stilt: true },
  desert: { floor: "smooth_sandstone", post: "chiseled_sandstone", trim: "orange_terracotta", roof: "flat", win: "air", deco: "awning", dome: true },
  snow: { floor: "spruce_planks", post: "spruce_log", trim: "white_wool", roof: "steep", win: "glass_pane", deco: "snowy", chim: true },
  castle: { floor: "dark_oak_planks", post: "dark_oak_log", trim: "stone_bricks", roof: "hip", win: "glass_pane", deco: "banner", tudor: true },
  volcano: { floor: "polished_blackstone", post: "polished_basalt", trim: "magma", roof: "flat", win: "red_stained_glass", deco: "forge", chim: true },
  crystal: { floor: "calcite", post: "amethyst_block", trim: "purple_terracotta", roof: "spire", win: "purple_stained_glass", deco: "crystal" },
  dark: { floor: "deepslate_tiles", post: "polished_blackstone_bricks", trim: "crimson_planks", roof: "spire", win: "purple_stained_glass", deco: "soul" },
  sky: { floor: "quartz_block", post: "quartz_pillar", trim: "light_blue_terracotta", roof: "dome", win: "glass", deco: "cloud" },
  garden: { floor: "birch_planks", post: "cherry_log", trim: "pink_terracotta", roof: "gable", win: "glass_pane", deco: "flowerbox" },
};
function roofOf(P, x1, x2, z1, z2, H, kind, mat, S) {
  const w = x2 - x1 + 1, d = z2 - z1 + 1;
  if (kind === "flat") { P.fill(x1 - 1, H, z1 - 1, x2 + 1, H, z2 + 1, mat); P.fill(x1 - 1, H + 1, z1 - 1, x2 + 1, H + 1, z2 + 1, S.trim, "outline"); return; }   // 第77版: 屋根を 1 ひろげて ふちの 飾りを のせる（宙に 浮いた 輪に ならない）
  if (kind === "dome") { P.fill(x1, H, z1, x2, H, z2, mat); for (let k = 0; k <= Math.min(w, d) / 2; k++) P.fill(x1 + k, H + 1 + k, z1 + k, x2 - k, H + 1 + k, z2 - k, k % 2 ? "glass" : mat); return; }
  if (kind === "hip" || kind === "spire") {
    for (let k = 0; k <= Math.min(w, d) / 2 + 1; k++) { if (x1 - 1 + k > x2 + 1 - k || z1 - 1 + k > z2 + 1 - k) break; P.fill(x1 - 1 + k, H + k, z1 - 1 + k, x2 + 1 - k, H + k, z2 + 1 - k, mat, k ? "outline" : undefined); }
    if (kind === "spire") { const cx = Math.floor((x1 + x2) / 2), cz = Math.floor((z1 + z2) / 2), top = H + Math.floor(Math.min(w, d) / 2) + 1; P.fill(cx, top, cz, cx, top + 4, cz, S.post); P.set(cx, top + 5, cz, S.deco === "soul" ? "soul_lantern" : "end_rod"); }
    return;
  }
  // gable（切妻）・steep（急な 切妻）: 棟は z の 向き
  const step = kind === "steep" ? 1 : 1, rise = kind === "steep" ? 2 : 1;
  for (let k = 0; k <= Math.ceil(w / 2); k++) {
    const a = x1 - 1 + k * step, b = x2 + 1 - k * step; if (a > b) break;
    for (let r = 0; r < rise; r++) { const y = H + k * rise + r; P.fill(a, y, z1 - 1, a, y, z2 + 1, mat); P.fill(b, y, z1 - 1, b, y, z2 + 1, mat); if (b - a > 1) { P.fill(a + 1, y, z1, b - 1, y, z1, S.trim); P.fill(a + 1, y, z2, b - 1, y, z2, S.trim); } }
  }
}
function house(P, cx, cz, w, d, face, T, job, decor) {
  // face: 扉の向き "s" | "n" | "e" | "w"
  const S = HSTY[T.style] || HSTY.village;
  const x1 = cx - Math.floor(w / 2), x2 = x1 + w - 1, z1 = cz - Math.floor(d / 2), z2 = z1 + d - 1, H = S.roof === "flat" ? 5 : 5;
  if (S.stilt) { for (const [x, z] of [[x1, z1], [x2, z1], [x1, z2], [x2, z2]]) P.fill(x, -3, z, x, -1, z, S.post); }
  // v2.9.2: hollow は 底も 埋まるので 床の 高さ（-1）から 作り、中の 床を 置きなおす（NPCが 床に 埋まる 原因だった）
  P.fill(x1, -1, z1, x2, H - 1, z2, S.logwall || T.wall, "hollow");
  P.fill(x1 + 1, -1, z1 + 1, x2 - 1, -1, z2 - 1, S.floor);
  for (const [x, z] of [[x1, z1], [x2, z1], [x1, z2], [x2, z2]]) P.fill(x, 0, z, x, H - 1, z, S.post);
  if (S.tudor) { P.fill(x1, 2, z1, x2, 2, z1, S.post); P.fill(x1, 2, z2, x2, 2, z2, S.post); P.fill(x1, 2, z1, x1, 2, z2, S.post); P.fill(x2, 2, z1, x2, 2, z2, S.post); }
  P.fill(x1, H - 1, z1, x2, H - 1, z1, S.trim); P.fill(x1, H - 1, z2, x2, H - 1, z2, S.trim);
  roofOf(P, x1, x2, z1, z2, H, S.roof, T.roof, S);
  P.set(cx, H - 1, cz, S.deco === "soul" ? "soul_lantern" : "glowstone");
  // 窓（両がわ・2つずつ）
  for (const zz of [z1 + 2, z2 - 2]) { P.set(x1, 2, zz, S.win); P.set(x2, 2, zz, S.win); if (S.win !== "air") { P.set(x1, 1, zz, S.win); P.set(x2, 1, zz, S.win); } }
  // 扉（あけておく）
  const door = { s: [cx, z2], n: [cx, z1], e: [x2, cz], w: [x1, cz] }[face];
  if (face === "s" || face === "n") P.fill(door[0], 0, door[1], door[0] + 1, 2, door[1], "air");
  else P.fill(door[0], 0, door[1], door[0], 2, door[1] + 1, "air");
  const ox = face === "e" ? 1 : face === "w" ? -1 : 0, oz = face === "s" ? 1 : face === "n" ? -1 : 0;
  const lx = face === "e" || face === "w" ? (face === "e" ? x2 + 1 : x1 - 1) : door[0] - 1, lz = face === "s" || face === "n" ? (face === "s" ? z2 + 1 : z1 - 1) : door[1] - 1;
  P.set(lx, 0, lz, "oak_fence"); P.set(lx, 1, lz, S.deco === "soul" ? "soul_lantern" : "lantern");
  // 入口の ひさし・スタイルの かざり
  const ex = face === "s" || face === "n" ? [door[0] - 1, door[0] + 2] : [door[0], door[0]], ez = face === "e" || face === "w" ? [door[1] - 1, door[1] + 2] : [door[1], door[1]];
  if (S.deco === "awning") P.fill(ex[0] + ox, 3, ez[0] + oz, ex[1] + ox, 3, ez[1] + oz, ["red_wool", "orange_wool", "yellow_wool", "blue_wool"][Math.abs(cx + cz) % 4]);
  else P.fill(ex[0] + ox, 3, ez[0] + oz, ex[1] + ox, 3, ez[1] + oz, S.trim);
  if (S.deco === "flowerbox") for (const zz of [z1 + 2, z2 - 2]) { P.set(x1 - 1, 0, zz, "grass_block"); P.set(x2 + 1, 0, zz, "flower_pot"); P.set(x1 - 1, 1, zz, "poppy"); }   // 第77版: 植木ばちの 上の 花は こわれる → 土の 上に
  if (S.deco === "moss") { P.set(x1 - 1, 0, z1, "moss_block"); P.set(x2 + 1, 0, z2, "moss_carpet"); }
  if (S.deco === "barrel") { P.set(x2 + 1, 0, z1, "barrel"); P.set(x2 + 1, 1, z1, "barrel"); P.set(x1 - 1, 0, z2, "lantern"); }
  if (S.deco === "snowy") { P.fill(x1 - 1, 0, z1 - 1, x1 - 1, 0, z1 + 1, "snow_layer"); P.set(x2 + 1, 0, z2, "snow"); }
  if (S.deco === "banner") { P.set(x1, 4, z1 - 1, "red_wool"); P.set(x1, 3, z1 - 1, "red_wool"); P.set(x2, 4, z1 - 1, "red_wool"); P.set(x2, 3, z1 - 1, "red_wool"); }
  if (S.deco === "forge") { P.set(x2 + 1, 0, cz, "blast_furnace"); P.set(x2 + 1, 1, cz, "campfire"); }
  if (S.deco === "crystal") { P.set(x1 - 1, 0, z1 - 1, "amethyst_block"); P.set(x1 - 1, 1, z1 - 1, "amethyst_cluster"); P.set(x2 + 1, 0, z2 + 1, "amethyst_cluster"); }
  if (S.deco === "soul") { P.set(x1 - 1, 0, z1 - 1, "soul_soil"); P.set(x1 - 1, 1, z1 - 1, "soul_lantern"); }
  if (S.deco === "cloud") { P.fill(x1 - 1, 0, z1 - 1, x1, 0, z1 - 1, "white_wool"); }
  if (S.chim) { P.fill(x2 - 1, H, z1 + 1, x2 - 1, H + Math.ceil(w / 2) + 2, z1 + 1, "brick_block"); P.set(x2 - 1, H + Math.ceil(w / 2) + 3, z1 + 1, "campfire"); }
  if (S.dome) { P.fill(cx - 1, H + 1, cz - 1, cx + 1, H + 2, cz + 1, "smooth_sandstone"); P.set(cx, H + 3, cz, "chiseled_sandstone"); }
  for (const [dx, dy, dz, b] of decor || []) P.set(cx + dx, dy, cz + dz, b);
  return job === null ? null : { job, pos: P.at(cx, 0, cz) };
}

// 街の スタイル（地面・道・広場・あかり・木・花・かべ）
const STY = {
  village: { ground: "grass_block", path: "polished_andesite", plaza: "stone_bricks", fence: "oak_fence", lamp: "lantern", wall: "cobblestone_wall", log: "oak_log", leaf: "oak_leaves", flowers: ["poppy", "dandelion", "cornflower", "oxeye_daisy", "azure_bluet"] },
  port: { ground: "grass_block", path: "spruce_planks", plaza: "prismarine_bricks", fence: "spruce_fence", lamp: "sea_lantern", wall: "cobblestone_wall", log: "birch_log", leaf: "birch_leaves", flowers: ["cornflower", "blue_orchid", "azure_bluet"] },
  forest: { ground: "podzol", path: "coarse_dirt", plaza: "mossy_stone_bricks", fence: "spruce_fence", lamp: "lantern", wall: "cobblestone_wall", log: "spruce_log", leaf: "spruce_leaves", flowers: ["lily_of_the_valley", "red_mushroom", "brown_mushroom"] },
  desert: { ground: "sand", path: "smooth_sandstone", plaza: "cut_sandstone", fence: "jungle_fence", lamp: "lantern", wall: "cobblestone_wall", log: "jungle_log", leaf: "jungle_leaves", flowers: ["deadbush", "cactus"] },
  snow: { ground: "snow", path: "packed_ice", plaza: "polished_diorite", fence: "spruce_fence", lamp: "sea_lantern", wall: "cobblestone_wall", log: "spruce_log", leaf: "spruce_leaves", flowers: ["snow_layer", "white_tulip"] },
  castle: { ground: "grass_block", path: "stone_bricks", plaza: "polished_andesite", fence: "dark_oak_fence", lamp: "lantern", wall: "cobbled_deepslate_wall", log: "dark_oak_log", leaf: "dark_oak_leaves", flowers: ["poppy", "red_tulip", "allium"] },
  garden: { ground: "grass_block", path: "smooth_stone", plaza: "white_terracotta", fence: "birch_fence", lamp: "lantern", wall: "cobblestone_wall", log: "cherry_log", leaf: "cherry_leaves", flowers: ["pink_tulip", "allium", "orange_tulip", "red_tulip", "oxeye_daisy", "cornflower"] },
  sky: { ground: "grass_block", path: "smooth_quartz", plaza: "quartz_bricks", fence: "birch_fence", lamp: "end_rod", wall: "polished_deepslate_wall", log: "birch_log", leaf: "azalea_leaves", flowers: ["azure_bluet", "lily_of_the_valley", "white_tulip"] },
  dark: { ground: "deepslate", path: "polished_blackstone_bricks", plaza: "polished_deepslate", fence: "crimson_fence", lamp: "soul_lantern", wall: "blackstone_wall", log: "crimson_stem", leaf: "nether_wart_block", flowers: ["wither_rose", "crimson_fungus", "crimson_roots"] },
  volcano: { ground: "basalt", path: "polished_blackstone", plaza: "polished_basalt", fence: "nether_brick_fence", lamp: "shroomlight", wall: "blackstone_wall", log: "crimson_stem", leaf: "shroomlight", flowers: ["crimson_roots"] },
  crystal: { ground: "calcite", path: "smooth_basalt", plaza: "amethyst_block", fence: "warped_fence", lamp: "end_rod", wall: "polished_deepslate_wall", log: "warped_stem", leaf: "warped_wart_block", flowers: ["amethyst_cluster", "warped_roots"] },
  farm: { ground: "grass_block", path: "coarse_dirt", plaza: "cobblestone", fence: "oak_fence", lamp: "lantern", wall: "cobblestone_wall", log: "oak_log", leaf: "oak_leaves", flowers: ["poppy", "dandelion", "oxeye_daisy"] },
};
// 第77版: 草花は 下に 合う 土が ないと こわれて アイテムに なる → 1マス 下に 土を そえる
const SOIL = { wither_rose: "soul_soil", crimson_fungus: "crimson_nylium", crimson_roots: "crimson_nylium", warped_roots: "warped_nylium", warped_fungus: "warped_nylium", deadbush: "sand", cactus: "sand", red_mushroom: "podzol", brown_mushroom: "podzol", amethyst_cluster: null, snow_layer: null };
function plant(P, x, y, z, b) { const s = b in SOIL ? SOIL[b] : "grass_block"; if (s) P.set(x, y - 1, z, s); P.set(x, y, z, b); }
function tree(P, x, z, S, h = 5) {
  P.fill(x, 0, z, x, h - 1, z, S.log);
  P.fill(x - 2, h - 2, z - 2, x + 2, h - 1, z + 2, S.leaf); P.fill(x - 1, h, z - 1, x + 1, h + 1, z + 1, S.leaf);
}
// 街ごとの 名所（東南の あき地 x14..31, z16..31）
function townFeature(P, t, S) {
  const st = t.style;
  const ax = 22, az = 24;
  if (st === "port") {
    P.fill(ax - 7, -3, az - 6, ax + 8, -1, az + 6, "water"); P.fill(ax - 7, -1, az - 1, ax + 4, -1, az + 1, "spruce_planks");
    for (const x of [ax - 6, ax - 2, ax + 2]) P.fill(x, -3, az - 2, x, 0, az - 2, "spruce_log");
    P.fill(ax + 4, 0, az, ax + 4, 3, az, "spruce_fence"); P.set(ax + 4, 4, az, "sea_lantern");
  } else if (st === "farm") {
    for (let k = 0; k < 4; k++) { P.fill(ax - 7, -1, az - 6 + k * 3, ax + 7, -1, az - 5 + k * 3, "farmland"); P.fill(ax - 7, 0, az - 6 + k * 3, ax + 7, 0, az - 5 + k * 3, pick(["wheat", "carrots", "potatoes", "beetroot"])); P.fill(ax - 7, -1, az - 4 + k * 3, ax + 7, -1, az - 4 + k * 3, "water"); }
    P.fill(ax - 8, 0, az - 7, ax + 8, 0, az + 6, "oak_fence", "outline");
    P.set(ax + 8, 0, az + 7, "hay_block"); P.set(ax + 7, 0, az + 7, "hay_block"); P.set(ax + 8, 1, az + 7, "hay_block");
  } else if (st === "desert") {
    for (const [x, z] of [[ax - 5, az - 4], [ax + 5, az + 3], [ax, az + 6]]) { P.fill(x, 0, z, x, 5, z, "jungle_log"); P.fill(x - 2, 6, z, x + 2, 6, z, "jungle_leaves"); P.fill(x, 6, z - 2, x, 6, z + 2, "jungle_leaves"); }
    P.fill(ax - 3, -1, az - 3, ax + 3, -1, az + 3, "water"); P.fill(ax - 4, -1, az - 4, ax + 4, -1, az + 4, "smooth_sandstone", "outline");
    for (const [x, z] of [[ax + 6, az - 6], [ax - 7, az + 5]]) P.fill(x, 0, z, x, 2, z, "cactus");
  } else if (st === "snow") {
    P.fill(ax - 6, -1, az - 5, ax + 6, -1, az + 5, "ice"); P.fill(ax - 7, -1, az - 6, ax + 7, -1, az + 6, "packed_ice", "outline");
    P.fill(ax + 8, 0, az - 6, ax + 8, 1, az - 6, "snow"); P.set(ax + 8, 2, az - 6, "carved_pumpkin");
    tree(P, ax - 8, az + 7, { log: "spruce_log", leaf: "spruce_leaves" }, 7);
  } else if (st === "volcano") {
    P.fill(ax - 5, -2, az - 4, ax + 5, -1, az + 4, "lava"); P.fill(ax - 6, -1, az - 5, ax + 6, 1, az + 5, "blackstone", "outline");
    P.fill(ax - 6, 2, az - 5, ax + 6, 2, az + 5, "air"); for (const [x, z] of [[ax - 6, az - 5], [ax + 6, az - 5], [ax - 6, az + 5], [ax + 6, az + 5]]) { P.fill(x, 0, z, x, 3, z, "polished_basalt"); P.set(x, 4, z, "shroomlight"); }
    P.fill(ax - 6, 0, az, ax - 6, 1, az, "air");
  } else if (st === "sky") {
    P.fill(ax - 4, 5, az - 4, ax + 4, 5, az + 4, "smooth_quartz"); for (const [x, z] of [[ax - 4, az - 4], [ax + 4, az - 4], [ax - 4, az + 4], [ax + 4, az + 4]]) P.fill(x, 0, z, x, 4, z, "quartz_block");
    P.fill(ax - 3, 6, az - 3, ax + 3, 6, az + 3, "glass"); P.set(ax, 7, az, "end_rod"); P.set(ax, 6, az, "sea_lantern");
    for (let k = 0; k < 5; k++) P.fill(ax - 6 + k, k, az, ax - 6 + k, k, az + 1, "quartz_block");
  } else if (st === "dark") {
    for (let i = 0; i < 9; i++) { const x = ax - 6 + (i % 3) * 5, z = az - 5 + Math.floor(i / 3) * 4; P.set(x, 0, z, "cobblestone_wall"); P.set(x, 1, z, "cobblestone_wall"); P.set(x, -1, z + 1, "soul_soil"); }
    P.fill(ax - 8, 0, az - 7, ax + 8, 1, az + 6, "crimson_fence", "outline"); P.fill(ax, 0, az - 7, ax + 1, 1, az - 7, "air");
    P.set(ax + 1, 0, az + 1, "soul_lantern"); tree(P, ax + 7, az + 5, { log: "crimson_stem", leaf: "nether_wart_block" }, 6);
  } else if (st === "crystal") {
    for (const [x, z, h] of [[ax - 4, az - 3, 6], [ax + 3, az - 4, 8], [ax, az + 3, 10], [ax + 6, az + 4, 5], [ax - 6, az + 5, 7]]) { P.fill(x, 0, z, x + 1, h, z + 1, "amethyst_block"); P.set(x, h + 1, z, "amethyst_cluster"); P.set(x + 2, 0, z, "budding_amethyst"); }
    P.fill(ax - 8, -1, az - 7, ax + 8, -1, az + 7, "calcite");
  } else if (st === "garden") {
    for (let x = ax - 8; x <= ax + 8; x++) for (let z = az - 7; z <= az + 7; z += 2) P.set(x, 0, z, pick(S.flowers));
    tree(P, ax, az, { log: "cherry_log", leaf: "cherry_leaves" }, 7); P.fill(ax - 2, 0, az - 7, ax + 2, 3, az - 7, "birch_fence", "hollow"); P.fill(ax - 2, 3, az - 7, ax + 2, 3, az - 7, "pink_terracotta");
  } else if (st === "castle") {
    P.fill(ax - 5, 0, az - 5, ax + 5, 13, az + 5, t.wall, "hollow"); P.fill(ax - 4, 0, az - 4, ax + 4, 0, az + 4, "air"); P.fill(ax - 6, 13, az - 6, ax + 6, 14, az + 6, t.roof);
    for (let x = ax - 6; x <= ax + 6; x += 2) { P.set(x, 15, az - 6, t.roof); P.set(x, 15, az + 6, t.roof); }
    P.fill(ax - 1, 0, az - 5, ax + 1, 3, az - 5, "air"); P.fill(ax - 5, 6, az - 1, ax - 5, 8, az + 1, "glass"); P.fill(ax + 5, 6, az - 1, ax + 5, 8, az + 1, "glass");
    P.fill(ax - 4, 0, az + 4, ax - 4, 12, az + 4, "scaffolding"); P.set(ax, 12, az, 'lantern ["hanging"=true]'); P.loot(ax + 3, 0, az + 3, "mrpg/house");
  } else if (st === "forest") {
    for (const [x, z, h] of [[ax - 5, az - 4, 8], [ax + 5, az + 4, 9], [ax - 3, az + 6, 6], [ax + 6, az - 5, 7]]) tree(P, x, z, S, h);
    P.fill(ax - 1, 0, az - 1, ax + 1, 0, az + 1, "mossy_cobblestone"); P.set(ax, 1, az, "lantern");
  } else {  // village: いど と 牧場
    P.fill(ax - 1, -3, az - 1, ax + 1, -1, az + 1, "water"); P.fill(ax - 2, -1, az - 2, ax + 2, 0, az + 2, "cobblestone", "outline");
    for (const [x, z] of [[ax - 2, az - 2], [ax + 2, az - 2], [ax - 2, az + 2], [ax + 2, az + 2]]) P.fill(x, 1, z, x, 2, z, "oak_fence");
    P.fill(ax - 2, 3, az - 2, ax + 2, 3, az + 2, "oak_planks"); P.set(ax, 2, az, 'lantern ["hanging"=true]');
    P.fill(ax + 4, 0, az - 6, ax + 9, 0, az + 6, "oak_fence", "outline"); P.set(ax + 6, 0, az, "hay_block"); P.set(ax + 7, 0, az + 2, "hay_block");
  }
}
// どの街にも: 見はりやぐら・やたい・ひろばの せきぞう・木
function townCommon(P, t, S, R) {
  for (const [x, z] of [[-R, -R], [R - 3, -R], [-R, R - 3], [R - 3, R - 3]]) {
    P.fill(x, 0, z, x + 3, 9, z + 3, t.wall, "hollow"); P.fill(x - 1, 10, z - 1, x + 4, 10, z + 4, t.roof);
    for (const [dx, dz] of [[-1, -1], [4, -1], [-1, 4], [4, 4], [1, -1], [-1, 1], [4, 2], [2, 4]]) P.set(x + dx, 11, z + dz, t.wall);
    P.set(x + 1, 11, z + 1, S.lamp === "end_rod" ? "sea_lantern" : "lantern");
    P.fill(x + 1, 1, z + 1, x + 1, 9, z + 1, "scaffolding");
  }
  for (const [x, z, c] of [[-5, -18, "red_wool"], [5, -18, "yellow_wool"], [-5, 18, "blue_wool"], [5, 18, "lime_wool"]]) {
    for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) P.fill(x + dx, 0, z + dz, x + dx, 1, z + dz, S.fence);
    P.fill(x - 1, 2, z - 1, x + 1, 2, z + 1, c); P.set(x, 0, z, "barrel");
  }
  P.fill(0, 3, 0, 0, 4, 0, t.wall); P.set(0, 5, 0, S.lamp === "soul_lantern" ? "soul_lantern" : "sea_lantern");
  for (const [x, z] of [[-30, -18], [30, -18], [-30, 18], [-16, -30], [16, -30], [-16, 30], [-30, -30]]) if (!(x > 13 && z > 15)) tree(P, x, z, S, 5 + ((x * 7 + z) & 1));
}

// ---------- 第106版: 新しい 都・町（city.js の 設計図を 2つに 分けて 置く）----------
/* 大きい ので 北半分・南半分に わけて 読みこみ（tickingarea は 100チャンク まで）*/
/* 第106版: 町の 外の 地面の 高さを 36方向で はかる（町の 高さからの ずれ）。読めない 所が 多い ときは なじませない */
function edgeOf(dim, cx, cy, cz, R) {
  const N = 36, A = [], Y = Math.floor(cy);
  for (let k = 0; k < N; k++) { const a = (k / N) * Math.PI * 2; let y = null; try { y = surfaceY(dim, cx + Math.cos(a) * (R + 3), cz + Math.sin(a) * (R + 3)); } catch {} A.push(y === null ? null : Math.max(-14, Math.min(28, y - Y))); }
  if (A.filter((v) => v !== null).length < N * 0.6) return null;
  for (let k = 0; k < N; k++) if (A[k] === null) { let j = 1; while (A[(k + j) % N] === null && A[(k - j + N) % N] === null) j++; A[k] = A[(k + j) % N] ?? A[(k - j + N) % N]; }
  return (x, z) => { const f = ((Math.atan2(z, x) / (Math.PI * 2) + 1) % 1) * N, i = Math.floor(f) % N, t = f - Math.floor(f); return A[i] * (1 - t) + A[(i + 1) % N] * t; };
}
function runPlan(dim, Bp, cx, cy, cz, R, done, fail) {
  const raw = Bp.c, X = Math.floor(cx), Y = Math.floor(cy), Z = Math.floor(cz), N = [], S = [];
  for (const q of raw) {
    if (q[0] === 3) { const t = Math.max(1, Math.min(5, q[4] + lvBonus({ x: X + q[1], z: Z + q[3] }))); (q[3] < 0 ? N : S).push(`loot insert ${X + q[1]} ${Y + q[2]} ${Z + q[3]} loot "mrpg/chest${t}"`); continue; }   /* 第111版: 家の 宝箱に 冒険の 道具 */
    if (q[0] === 2) { (q[3] < 0 ? N : S).push(q[4].replace(/\{x\}/g, X + q[1]).replace(/\{y\}/g, Y + q[2]).replace(/\{z\}/g, Z + q[3])); continue; }   /* 第110版: 宝箱の 中身など */
    if (q[0]) { (q[3] < 0 ? N : S).push(`setblock ${X + q[1]} ${Y + q[2]} ${Z + q[3]} ${q[4]}`); continue; }
    const [, ax, ay, az, bx, by, bz, b, m] = q, cmd = (z1, z2) => `fill ${X + ax} ${Y + ay} ${Z + z1} ${X + bx} ${Y + by} ${Z + z2} ${b}${m ? " " + m : ""}`;
    if (bz < 0) N.push(cmd(az, bz)); else if (az >= 0) S.push(cmd(az, bz));
    else if (m === "hollow" || m === "outline") (Math.abs(az) > bz ? N : S).push(cmd(az, bz));   /* 形が こわれる ので わけない（大きくない）*/
    else { N.push(cmd(az, -1)); S.push(cmd(0, bz)); }
  }
  let bad = false;
  const area = (z1, z2) => [{ x: X - R - 1, y: Y - 20, z: Z + z1 }, { x: X + R + 1, y: Y + 46, z: Z + z2 }];
  enqueue(dim, N, () => {}, area(-R - 1, 0), () => { bad = true; });
  enqueue(dim, S, () => { if (bad) { try { fail && fail(); } catch {} return; } try { done && done(); } catch (e) { console.warn(`[MonsterRPG] city done: ${e}`); } }, area(0, R + 1), () => { try { fail && fail(); } catch {} });
}
const tHash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
/* 第106版: 歩く 人の 道すじが ある 町の 一覧 */
function walkIndex(id) { try { const L = JSON.parse(world.getDynamicProperty("mrpg:walkids") || "[]"); if (!L.includes(id)) { L.push(id); world.setDynamicProperty("mrpg:walkids", JSON.stringify(L)); } } catch {} }
function spawnCityNpcs(dim, X, Y, Z, list, tag, townId) {
  for (const n of list) {
    try { const e = dim.spawnEntity("mrpg:npc", { x: Math.floor(X) + n.pos.x, y: Math.floor(Y) + n.pos.y, z: Math.floor(Z) + n.pos.z });
      if (n.act) { dressCitizen(e, n.act, n.patron); if (townId) e.setDynamicProperty("mrpg:town", townId); if (tag) e.addTag(tag); continue; }   /* 第109版: 店の 客（座って 食べる・飲む・読む）*/
      setJob(e, n.job); e.nameTag = n.name || `§e${JOBS[n.job] || ""}`; e.addTag("mrpg_npc"); if (tag) e.addTag(tag); if (townId) e.setDynamicProperty("mrpg:town", townId); if (n.king !== undefined) e.setDynamicProperty("mrpg:king", n.king); if (n.role) { e.setDynamicProperty("mrpg:role", n.role); e.addTag("mrpg_role_" + n.role); }   /* 第113版: コンテスト係・おもちゃ屋 など */
      system.runTimeout(() => unstuckNpc(e), 10); } catch {}
  }
}
export const CITY_V = 8;   /* 第108版: 門の 前の 段差・まわりの 地形・建物の 名前を 直した ので 近づくと 建てなおす */
export const __city = { capitalPlan, townPlan, runPlan };
const TBUILD = new Set();   /* 町を 作って いる 最中（二重に 作らない） */
export function buildTown(t, dim, cx, cy, cz, done, fail) {
  if (TBUILD.has(t.id)) return; TBUILD.add(t.id);
  { setEdge(edgeOf(dim, cx, cy, cz, 44)); const Bp = t.id === "t0" ? townPlan(t, tHash(t.id)) : townPlan2(t, tHash(t.id)), R = 44;   /* 第115版: はじまりの 町は 前の 広い 形に もどした */ setEdge(null);   /* 第112版: 町ごとに ちがう 形 */   /* 第106版: 新しい 町（外の 地面に なじませる）*/
    runPlan(dim, Bp, cx, cy, cz, R, () => { TBUILD.delete(t.id);
      try { for (const e of dim.getEntities({ type: "mrpg:npc", location: { x: cx, y: cy, z: cz }, maxDistance: R + 14 })) if (e.getDynamicProperty("mrpg:town") === t.id) e.remove(); } catch {}
      spawnCityNpcs(dim, cx, cy, cz, Bp.npc, null, t.id); try { world.setDynamicProperty(`mrpg:walk:${t.id}`, JSON.stringify({ x: Math.floor(cx), y: Math.floor(cy), z: Math.floor(cz), w: Bp.walk, s: Bp.seat, p: Bp.spots })); } catch {} walkIndex(t.id);
      done && done(); }, () => { TBUILD.delete(t.id); try { fail && fail(); } catch {} });
    return; }
  const P = new Plan(cx, cy, cz);
  const R = 34;
  const S = STY[t.style] || STY.village;
  for (const [a, b] of [[-R, -1], [0, R]]) for (const [c, e] of [[-R, -1], [0, R]]) P.fill(a, 0, c, b, 16, e, "air");
  P.fill(-R, -12, -R, R, -5, R, "dirt", "keep");   // 第77版: 坂や 崖で 土台の 下が 空かない ように（空気の 所だけ）
  P.fill(-R, -4, -R, R, -2, R, "dirt");
  P.fill(-R, -1, -R, R, -1, R, S.ground);
  // 道と広場
  P.fill(-2, -1, -R, 2, -1, R, S.path); P.fill(-R, -1, -2, R, -1, 2, S.path);
  P.fill(-7, -1, -7, 7, -1, 7, S.plaza);
  P.fill(-3, -1, -3, 3, 0, 3, S.plaza); P.fill(-2, 0, -2, 2, 0, 2, "water"); P.fill(0, 0, 0, 0, 2, 0, S.plaza); P.set(0, 3, 0, "sea_lantern");
  for (const [x, z] of [[-6, -6], [6, -6], [-6, 6], [6, 6], [-3, -16], [3, -16], [-3, 16], [3, 16], [-16, -3], [-16, 3], [16, -3], [16, 3], [-3, -28], [3, -28], [-3, 28], [3, 28], [-28, -3], [-28, 3], [28, -3], [28, 3]]) {
    P.fill(x, 0, z, x, 2, z, S.fence); P.set(x, 3, z, S.lamp);
  }
  // 外壁と門
  P.fill(-R, 0, -R, R, 1, -R, S.wall); P.fill(-R, 0, R, R, 1, R, S.wall);
  P.fill(-R, 0, -R, -R, 1, R, S.wall); P.fill(R, 0, -R, R, 1, R, S.wall);
  P.fill(-3, 0, -R, 3, 1, -R, "air"); P.fill(-3, 0, R, 3, 1, R, "air"); P.fill(-R, 0, -3, -R, 1, 3, "air"); P.fill(R, 0, -3, R, 1, 3, "air");
  for (const [x, z, ax_] of [[0, -R, 1], [0, R, 1], [-R, 0, 0], [R, 0, 0]]) {   // 門の アーチ
    if (ax_) { P.fill(x - 4, 0, z, x - 4, 5, z, t.wall); P.fill(x + 4, 0, z, x + 4, 5, z, t.wall); P.fill(x - 4, 5, z, x + 4, 6, z, t.roof); }
    else { P.fill(x, 0, z - 4, x, 5, z - 4, t.wall); P.fill(x, 0, z + 4, x, 5, z + 4, t.wall); P.fill(x, 5, z - 4, x, 6, z + 4, t.roof); }
  }
  // 花壇
  for (let i = 0; i < 30; i++) { const x = ri(-R + 2, R - 2), z = ri(-R + 2, R - 2); if (Math.abs(x) > 3 && Math.abs(z) > 3 && !(x > 13 && z > 15) && !(Math.abs(x) <= 7 && Math.abs(z) <= 7)) plant(P, x, 0, z, pick(S.flowers)); }   // 第77版: 広場の 石の 上には 置かない・土を そえる
  const npcs = [];
  const N = (r) => r && npcs.push(r);
  N(house(P, 11, -9, 9, 9, "s", t, 0, [[0, 0, -2, "anvil"], [2, 0, -2, "grindstone"], [-2, 0, -2, "smithing_table"], [0, 0, 1, "barrel"]]));
  N(house(P, 24, -9, 9, 9, "s", t, 1, [[0, 0, -2, "smithing_table"], [2, 0, -2, "anvil"], [-2, 0, -2, "blast_furnace"]]));
  N(house(P, -11, -9, 9, 9, "s", t, 3, [[0, 0, -2, "barrel"], [2, 0, -2, "brewing_stand"], [-2, 0, -2, "barrel"], [3, 0, -3, "cauldron"]]));
  N(house(P, -24, -9, 9, 9, "s", t, 4, [[0, 0, -2, "hay_block"], [2, 0, -2, "hay_block"], [-2, 0, -2, "turtle_egg"], [2, 1, -2, "turtle_egg"]]));
  N(house(P, 12, 10, 11, 9, "n", t, 2, [[-3, 0, 2, "red_carpet"], [-2, 0, 2, "red_carpet"], [3, 0, 2, "red_carpet"], [2, 0, 2, "red_carpet"], [-3, 0, 3, "red_wool"], [3, 0, 3, "red_wool"], [0, 0, 3, "bookshelf"], [4, 0, -2, "flower_pot"]]));
  N(house(P, 25, 10, 9, 9, "n", t, 5, [[0, 0, 2, "bell"], [-2, 0, 2, "target"], [2, 0, 2, "target"]]));
  N(house(P, -11, 9, 9, 9, "n", t, 6, [[-2, 0, 2, "chest"], [0, 0, 3, "barrel"], [2, 0, 2, "chest"]]));
  N(house(P, -24, 9, 9, 9, "n", t, 7, [[0, 0, 2, "lectern"], [-2, 0, 3, "bookshelf"], [2, 0, 3, "bookshelf"]]));
  // 民家（チェストつき）
  N(house(P, 22, -24, 9, 7, "s", t, 11, [[0, 0, -1, "hay_block"], [2, 0, -1, "oak_fence"], [-2, 0, -1, "oak_fence"], [0, 1, -1, "lantern"]]));
  for (const [x, z, f] of [[9, -24, "w"], [-9, -24, "e"], [9, 24, "w"], [-22, 24, "n"]]) {
    house(P, x, z, 7, 7, f, t, null, [[0, 0, 0, "crafting_table"], [1, 0, 1, "furnace"], [-1, 0, 1, "white_wool"]]);
    P.loot(x + (f === "w" ? 2 : f === "e" ? -2 : 1), 0, z + (f === "s" ? -2 : f === "n" ? 2 : -2), "mrpg/house");
  }
  // 道ばたの たる・チェスト
  for (const [x, z] of [[4, -21], [-4, 21], [20, 4], [-20, -4]]) P.loot(x, 0, z, "mrpg/roadside");
  N(house(P, -9, 24, 7, 7, "e", t, 12, [[-2, 0, -2, "bookshelf"], [-2, 1, -2, "bookshelf"], [-2, 0, 2, "bookshelf"], [-2, 1, 2, "bookshelf"], [0, 0, 0, "lectern"], [-2, 0, 0, "enchanting_table"]]));
  npcs.push({ job: 13, pos: P.at(-5, 0, 5) });
  npcs.push({ job: 14, pos: P.at(5, 0, -5) });
  townCommon(P, t, S, R);
  townFeature(P, t, S);
  // v3.0: 町の 中に 水が 入らない ように（中の 水を ぬき、まわりに 低い 防波堤）
  P.c.unshift(...drainCmds(cx, Math.floor(cy), cz, R + 2));   // 先に ぬく（噴水などの 水は あとで 置かれる）
  enqueue(dim, P.c, () => {
    TBUILD.delete(t.id);
    try { for (const e of dim.getEntities({ type: "mrpg:npc", location: { x: cx, y: cy, z: cz }, maxDistance: R + 12 })) if (e.getDynamicProperty("mrpg:town") === t.id) e.remove(); } catch {}   /* 前の 町の 人は 消してから */
    for (const n of npcs) {
      try {
        const e = dim.spawnEntity("mrpg:npc", n.pos);
        setJob(e, n.job);
        e.nameTag = `§e${JOBS[n.job]}`;
        e.addTag("mrpg_npc");
        e.setDynamicProperty("mrpg:town", t.id);
        system.runTimeout(() => unstuckNpc(e), 10);
      } catch {}
    }
    done && done();
  }, P.area(R + 1), () => { TBUILD.delete(t.id); try { fail && fail(); } catch {} });   // v3.0: 読みこめずに やめた とき
}
const TOWN_FAIL = new Map();   // v3.0: 作れなかった 町は 5分 まって やりなおす（くり返し 作りなおさない）

// ---------- 遺跡・神殿 ----------
const THEMES = {
  ruin: { floor: ["stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks"], wall: ["stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks"], accent: "chiseled_stone_bricks", light: "lantern", name: "忘れられた 遺跡" },
  desert: { floor: ["sandstone", "cut_sandstone", "smooth_sandstone"], wall: ["sandstone", "cut_sandstone"], accent: "chiseled_sandstone", light: "lantern", name: "砂の 神殿" },
  snow: { floor: ["packed_ice", "snow", "blue_ice"], wall: ["packed_ice", "snow"], accent: "blue_ice", light: "sea_lantern", name: "氷の 神殿" },
  deep: { floor: ["deepslate_bricks", "cracked_deepslate_bricks", "polished_deepslate"], wall: ["deepslate_bricks", "cracked_deepslate_bricks"], accent: "chiseled_deepslate", light: "soul_lantern", name: "ちていの 古寺" },
  water: { floor: ["prismarine_bricks", "dark_prismarine", "prismarine"], wall: ["prismarine_bricks", "prismarine"], accent: "dark_prismarine", light: "sea_lantern", name: "海の 神殿" },
  nether: { floor: ["polished_blackstone_bricks", "cracked_polished_blackstone_bricks", "blackstone"], wall: ["polished_blackstone_bricks", "cracked_polished_blackstone_bricks"], accent: "gilded_blackstone", light: "shroomlight", name: "ごうかの とりで" },
  end: { floor: ["end_bricks", "purpur_block"], wall: ["purpur_block", "end_bricks"], accent: "purpur_pillar", light: "end_rod", name: "空の せいどう" },
  moss: { floor: ["mossy_cobblestone", "mossy_stone_bricks", "moss_block"], wall: ["mossy_cobblestone", "mossy_stone_bricks", "cobblestone"], accent: "mossy_stone_bricks", light: "lantern", name: "こけむした 遺跡" },
  mesa: { floor: ["red_sandstone", "orange_terracotta", "hardened_clay"], wall: ["red_sandstone", "cut_red_sandstone", "orange_terracotta"], accent: "chiseled_red_sandstone", light: "lantern", name: "あかつちの 遺跡" },
  crystal: { floor: ["calcite", "smooth_basalt", "amethyst_block"], wall: ["calcite", "smooth_basalt"], accent: "amethyst_block", light: "end_rod", name: "すいしょうの どうくつ" },
};
const ADJ = { ruin: "忘れられた", desert: "砂の", snow: "氷の", deep: "ちていの", water: "海の", nether: "ごうかの", end: "空の", moss: "こけむした", mesa: "あかつちの", crystal: "すいしょうの" };
const LAY_NAME = { ruin: "遺跡", tower: "とう", pyramid: "ピラミッド", temple: "神殿", crypt: "ちかれいびょう", colosseum: "コロシアム", shrine: "やしろ", sky: "てんくうの さいだん" };
const THEME_OPTS = { plains: ["ruin", "moss", "crystal"], forest: ["moss", "ruin"], swamp: ["moss", "ruin"], desert: ["desert", "mesa"], snow: ["snow"], mountain: ["deep", "crystal", "ruin"],
  cave: ["deep", "crystal"], water: ["water"], nether: ["nether"], end: ["end"] };
const LAYOUTS = ["ruin", "tower", "pyramid", "temple", "crypt", "colosseum", "shrine", "sky"];
function hashStr(k) { let h = 2166136261; for (let i = 0; i < k.length; i++) { h ^= k.charCodeAt(i); h = Math.imul(h, 16777619); } return Math.abs(h); }
const BIOME_THEME = { plains: "ruin", forest: "ruin", swamp: "ruin", desert: "desert", snow: "snow", mountain: "deep", cave: "deep", water: "water", nether: "nether", end: "end" };
export const REGION = { "minecraft:overworld": 176, "minecraft:nether": 192, "minecraft:the_end": 256 };
const dimShort = (id) => id.replace("minecraft:", "");
export function siteOf(dimId, rx, rz) {
  const R = REGION[dimId];
  let h = (rx * 73856093) ^ (rz * 19349663) ^ dimId.length * 83492791;
  h = Math.abs(h);
  return { key: `mrpg:ruin:${dimShort(dimId)}:${rx}:${rz}`, x: rx * R + 60 + (h % (R - 120)), z: rz * R + 60 + (Math.floor(h / 7) % (R - 120)) };
}
/* 第99版: 何度も 読む 記録は 文字列を 覚えて おく（書く ときに 一緒に 書きかえる） */
const RAW = new Map();
const rawGet = (key) => { if (RAW.has(key)) return RAW.get(key); const v = world.getDynamicProperty(key); const s = typeof v === "string" ? v : null; RAW.set(key, s); return s; };
const rawSet = (key, str) => { world.setDynamicProperty(key, str); RAW.set(key, str); };
export function getRuin(key) { const v = rawGet(key); return v ? JSON.parse(v) : null; }
export function setRuin(key, v) { rawSet(key, JSON.stringify(v)); }

export function buildRuin(dim, site, cy, biome, done) {
  const h = hashStr(site.key);
  const opts = THEME_OPTS[biome] || THEME_OPTS[baseBiome(biome)] || ["ruin"];
  let tk = opts[h % opts.length];
  if (dim.id === "minecraft:overworld") { const s0 = world.getDefaultSpawnLocation(), R = WREGIONS[regionIdx(site.x - s0.x, site.z - s0.z)]; if (R.ruin && THEMES[R.ruin] && h % 10 < 7) tk = R.ruin; }
  const T = THEMES[tk];
  let lay = LAYOUTS[Math.floor(h / 7) % LAYOUTS.length];
  if (dim.id !== "minecraft:overworld" && (lay === "pyramid" || lay === "sky")) lay = "temple";
  if (lay === "colosseum") lay = h % 2 ? "temple" : "ruin";   /* 第127版(fac): 石の 観客席の 輪（コロシアム）は もう 作らない */
  const name = `${ADJ[tk]} ${LAY_NAME[lay]}`;
  const P = new Plan(site.x, cy, site.z); P.dim = dim.id;
  const altar = LAYOUT_FN[lay](P, T);
  enqueue(dim, P.c, () => done && done(P.at(altar[0], altar[1], altar[2]), name), P.area(lay === "colosseum" || lay === "pyramid" ? 18 : 15));
}
function layoutRuin(P, T) {
  const R = 12;
  P.fill(-R - 1, 0, -R - 1, R + 1, 12, R + 1, "air");
  P.fill(-R, -10, -R, R, -4, R, T.wall[0], "keep");   /* 坂や 崖で 土台の 下が 空かない ように（空気の 所だけ）*/
  P.fill(-R, -3, -R, R, -2, R, T.wall[0]);
  P.fill(-R, -1, -R, R, -1, R, T.floor[0]);
  for (let i = 0; i < 40; i++) P.set(ri(-R, R), -1, ri(-R, R), pick(T.floor));
  // 外壁（ところどころ崩れている）
  for (let x = -R; x <= R; x++) for (const z of [-R, R]) { const h = ri(0, 4); if (h) P.fill(x, 0, z, x, h - 1, z, pick(T.wall)); }
  for (let z = -R; z <= R; z++) for (const x of [-R, R]) { const h = ri(0, 4); if (h) P.fill(x, 0, z, x, h - 1, z, pick(T.wall)); }
  P.fill(-2, 0, R, 2, 4, R, "air");
  // 柱
  for (const [x, z] of [[-R + 2, -R + 2], [R - 3, -R + 2], [-R + 2, R - 3], [R - 3, R - 3], [-8, 0], [7, 0]]) {
    const h = ri(4, 8); P.fill(x, 0, z, x + 1, h, z + 1, T.accent); P.set(x, h + 1, z, T.light);
  }
  // 内陣
  const r = 6;
  P.fill(-r, 0, -r, r, 6, r, pick(T.wall), "hollow");
  P.fill(-r, 7, -r, r, 7, r, T.wall[0]);
  for (let i = 0; i < 8; i++) P.set(ri(-r, r), 7, ri(-r, r), "air");
  P.fill(-1, 0, r, 1, 3, r, "air");
  P.fill(-r + 1, -1, -r + 1, r - 1, -1, r - 1, T.accent);
  P.fill(-1, 0, -1, 1, 0, 1, T.accent); P.set(0, 1, -3, T.light); P.set(-4, 1, -4, T.light); P.set(4, 1, -4, T.light);
  P.set(-r + 1, 0, -r + 1, "air"); P.loot(-r + 1, 0, -r + 1, "mrpg/treasure"); P.loot(r - 1, 0, -r + 1, "mrpg/treasure");
  P.loot(-R + 3, 0, R - 5, "mrpg/roadside"); P.loot(R - 4, 0, -R + 4, "mrpg/roadside");
  return [0, 1, 0];
}
function base(P, T, R, h = 14) {
  P.fill(-R - 1, 0, -R - 1, R + 1, h, R + 1, "air");
  P.fill(-R, -10, -R, R, -4, R, T.wall[0], "keep");   /* 坂や 崖で 土台の 下が 空かない ように（空気の 所だけ）*/
  P.fill(-R, -3, -R, R, -2, R, T.wall[0]);
  P.fill(-R, -1, -R, R, -1, R, T.floor[0]);
  for (let i = 0; i < R * 3; i++) P.set(ri(-R, R), -1, ri(-R, R), pick(T.floor));
}
// とう: 4かいだて。てっぺんに ボス。足場（スキャフォールディング）で 登る
function layoutTower(P, T) {
  base(P, T, 9, 4);
  const r = 4, F = 6, N = 4;
  for (let k = 0; k < N; k++) {
    const y = k * F;
    P.fill(-r, y, -r, r, y + F - 1, r, pick(T.wall), "hollow");
    P.fill(-r + 1, y + F - 1, -r + 1, r - 1, y + F - 1, r - 1, T.floor[k % T.floor.length]);
    P.fill(-r + 1, y + F - 1, r - 2, -r + 2, y + F - 1, r - 1, "air");
    for (const [x, z] of [[-r, 0], [r, 0], [0, -r]]) P.fill(x, y + 2, z, x, y + 3, z, "air");
    P.set(0, y + 1, 0, T.light);
    if (k > 0) P.loot(r - 1, y, -r + 1, k === N - 1 ? "mrpg/treasure" : "mrpg/roadside");
  }
  P.fill(-r + 1, 0, r - 1, -r + 1, N * F - 1, r - 1, "scaffolding");
  P.fill(-1, 0, r, 1, 2, r, "air");
  const top = N * F;
  P.fill(-r - 1, top - 1, -r - 1, r + 1, top - 1, r + 1, T.accent);
  for (let x = -r - 1; x <= r + 1; x += 2) { P.set(x, top, -r - 1, pick(T.wall)); P.set(x, top, r + 1, pick(T.wall)); }
  for (let z = -r - 1; z <= r + 1; z += 2) { P.set(-r - 1, top, z, pick(T.wall)); P.set(r + 1, top, z, pick(T.wall)); }
  P.set(-r + 1, top - 1, r - 1, "scaffolding");
  for (const [x, z] of [[-r, -r], [r, -r], [-r, r], [r, r]]) P.set(x, top, z, T.light);
  return [0, top, 0];
}
// ピラミッド: なかの 玄室に ボス
function layoutPyramid(P, T) {
  base(P, T, 16, 16);
  for (let k = 0; k < 12; k++) { const r = 15 - k; P.fill(-r, k, -r, r, k, r, pick(T.wall)); }
  P.fill(-5, 0, -5, 5, 5, 5, "air"); P.fill(-5, -1, -5, 5, -1, 5, T.accent);
  P.fill(-1, 0, 5, 1, 3, 16, "air");
  for (const [x, z] of [[-4, -4], [4, -4], [-4, 4], [4, 4]]) { P.fill(x, 0, z, x, 4, z, T.accent); P.set(x, 5, z, T.light); }
  P.set(0, 12, 0, T.light);
  P.loot(-4, 0, 0, "mrpg/treasure"); P.loot(4, 0, 0, "mrpg/treasure");
  return [0, 0, -2];
}
// 神殿: 列柱と 高い さいだん
function layoutTemple(P, T) {
  base(P, T, 13, 14);
  P.fill(-9, 0, -11, 9, 1, 11, T.floor[0]); P.fill(-9, 0, 11, 9, 0, 13, T.floor[0]);
  for (let z = -9; z <= 9; z += 4) for (const x of [-8, 8]) P.fill(x, 2, z, x, 9, z, T.accent);
  P.fill(-9, 10, -11, 9, 10, 11, pick(T.wall)); P.fill(-6, 11, -11, 6, 11, 11, pick(T.wall)); P.fill(-3, 12, -11, 3, 12, 11, T.accent);
  P.fill(-3, 2, -10, 3, 3, -7, T.accent); P.set(-3, 4, -10, T.light); P.set(3, 4, -10, T.light);
  for (let z = -6; z <= 8; z += 3) { P.set(-5, 2, z, T.light); P.set(5, 2, z, T.light); }
  P.loot(-7, 2, -10, "mrpg/treasure"); P.loot(7, 2, -10, "mrpg/treasure");
  return [0, 4, -8];
}
// ちかれいびょう: 地上の 祠 から かいだんで 地下の 大広間へ
function layoutCrypt(P, T) {
  base(P, T, 8, 8);
  P.fill(-4, 0, 3, 4, 5, 8, pick(T.wall), "hollow"); P.fill(-1, 0, 8, 1, 3, 8, "air"); P.fill(-5, 6, 2, 5, 6, 9, T.accent);
  P.fill(-9, -16, -16, 9, -9, -2, pick(T.wall), "hollow");
  P.fill(-8, -15, -15, 8, -10, -3, "air");
  for (let i = 0; i < 14; i++) { P.fill(-1, -1 - i, 7 - i, 1, 2 - i, 7 - i, "air"); P.fill(-1, -2 - i, 7 - i, 1, -2 - i, 7 - i, pick(T.floor)); }
  for (const [x, z] of [[-6, -13], [6, -13], [-6, -6], [6, -6]]) { P.fill(x, -15, z, x, -10, z, T.accent); P.set(x, -11, z + 1, T.light); }
  P.fill(-2, -15, -14, 2, -15, -12, T.accent);
  for (const [x, z] of [[-7, -14], [7, -14], [-7, -4], [7, -4]]) P.loot(x, -15, z, "mrpg/treasure");
  P.set(0, 3, 5, T.light);
  return [0, -14, -11];
}
// コロシアム: まるい かんきゃくせきの まんなかで ボスが まつ
function layoutColosseum(P, T) {
  base(P, T, 17, 12);
  const ring = (r, y0, y1, b) => { for (let a = 0; a < 360; a += 4) { const x = Math.round(Math.cos(a * Math.PI / 180) * r), z = Math.round(Math.sin(a * Math.PI / 180) * r); P.fill(x, y0, z, x, y1, z, b); } };
  for (let k = 0; k < 4; k++) ring(12 + k, 0, 1 + k * 2, pick(T.wall));
  ring(16, 0, 9, pick(T.wall));
  P.fill(-11, -1, -11, 11, -1, 11, "sand"); P.fill(-3, -1, -3, 3, -1, 3, T.accent);
  P.fill(-2, 0, 11, 2, 4, 17, "air");
  for (let a = 0; a < 360; a += 45) { const x = Math.round(Math.cos(a * Math.PI / 180) * 16), z = Math.round(Math.sin(a * Math.PI / 180) * 16); P.set(x, 10, z, T.light); }
  P.loot(-12, 2, 0, "mrpg/treasure"); P.loot(12, 2, 0, "mrpg/treasure");
  return [0, 0, 0];
}
// やしろ: 赤い門の さんどうの おくに 祠
function layoutShrine(P, T) {
  base(P, T, 13, 10);
  P.fill(-1, -1, -13, 1, -1, 12, T.accent);
  for (const z of [10, 4, -2]) { P.fill(-3, 0, z, -3, 5, z, "red_concrete"); P.fill(3, 0, z, 3, 5, z, "red_concrete"); P.fill(-4, 6, z, 4, 6, z, "red_concrete"); P.fill(-3, 5, z, 3, 5, z, "black_concrete"); }
  P.fill(-6, 0, -12, 6, 1, -6, T.floor[0]); P.fill(-5, 2, -11, 5, 6, -7, pick(T.wall), "hollow"); P.fill(-6, 7, -12, 6, 7, -6, "dark_oak_planks"); P.fill(-4, 8, -11, 4, 8, -7, "dark_oak_planks");
  P.fill(-1, 2, -7, 1, 4, -7, "air");
  for (const [x, z] of [[-3, 7], [3, 7], [-3, 1], [3, 1]]) { P.fill(x, 0, z, x, 1, z, "stone_bricks"); P.set(x, 2, z, T.light); }
  P.loot(-4, 2, -10, "mrpg/treasure"); P.loot(4, 2, -10, "mrpg/treasure");
  return [0, 2, -9];
}
// てんくうの さいだん: 空に 浮かぶ しまへ らせん かいだん
function layoutSky(P, T) {
  base(P, T, 10, 24);
  const Y = 14;
  P.fill(-7, Y, -7, 7, Y, 7, T.floor[0]); P.fill(-5, Y - 1, -5, 5, Y - 1, 5, pick(T.wall)); P.fill(-3, Y - 3, -3, 3, Y - 2, 3, pick(T.wall)); P.set(0, Y - 4, 0, pick(T.wall));
  for (let i = 0; i < Y; i++) { const a = i * 0.16; const x = Math.round(Math.cos(a) * 9), z = Math.round(Math.sin(a) * 9); P.fill(x, i, z, x + 1, i, z + 1, T.accent); }
  for (const [x, z] of [[-6, -6], [6, -6], [-6, 6], [6, 6]]) { P.fill(x, Y + 1, z, x, Y + 5, z, T.accent); P.set(x, Y + 6, z, T.light); }
  P.loot(-5, Y + 1, 0, "mrpg/treasure"); P.loot(5, Y + 1, 0, "mrpg/treasure");
  return [0, Y + 1, 0];
}
const LAYOUT_FN = { ruin: layoutRuin, tower: layoutTower, pyramid: layoutPyramid, temple: layoutTemple, crypt: layoutCrypt, colosseum: layoutColosseum, shrine: layoutShrine, sky: layoutSky };

export function spawnBoss(dim, pos, biome, lvBase, key, raid = false, regLv = null) {
  const lv = Math.min(100, lvBase + (raid ? 6 : 8));
  const ranks = raid ? ["S", "SS"] : lv >= 60 ? ["A", "S"] : lv >= 25 ? ["B", "A"] : ["C", "B"];
  const famHint = pickWild(biome, Math.max(1, lv));
  let pool = ORDER.filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && ranks.includes(SPECIES[s].rank) && SPECIES[s].fam === SPECIES[famHint].fam);
  if (!pool.length) pool = ORDER.filter((s) => !SPECIES[s].hidden && !SPECIES[s].fuseonly && ranks.includes(SPECIES[s].rank) && SPECIES[s].fam !== "god");
  if (raid && Math.random() < 0.6) pool = pool.filter((s) => SPECIES[s].rank === "S").concat(pool.filter((s) => SPECIES[s].rank === "SS").slice(0, 2));
  // 第68版: 王系は フィールドの レイドボスとして だけ 出る（終盤の 地方ほど 出やすい: 序盤 8% → 終盤 50%）
  const kch = 0.08 + 0.42 * Math.max(0, Math.min(1, ((regLv ?? lv) - 20) / 70));
  if (raid && Math.random() < kch) {
    const kings = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].fam === "king" && ranks.includes(SPECIES[s].rank));
    if (kings.length) pool = kings;
  }
  const sid = pick(pool);
  const e = dim.spawnEntity(TYPE, pos);
  e.addTag("mrpg_boss"); if (raid) e.addTag("mrpg_raid");
  setLook(e, sid);
  // v1.4: レイドボスは ひと目で わかるように 大きく（ふつうの 約2.4倍）
  const bk = raid ? (SPECIES[sid].mh > 3 ? 1.5 : 2.4) : SPECIES[sid].mh > 3 ? 1.15 : 1.6;
  const bsize = Math.min(2250, Math.floor(SPECIES[sid].size * bk * sizeUp(SPECIES[sid].sz)));   /* 第81版: 1.5倍 */
  e.setProperty("mrpg:size", bsize);
  e.setDynamicProperty("mrpg:bsize", bsize);
  e.triggerEvent("mrpg:make_battle");
  e.triggerEvent(`mrpg:size_h${hBucket(SPECIES[sid].mh * bk * sizeUp(SPECIES[sid].sz))}`);
  e.setDynamicProperty("mrpg:lv", lv);
  e.setDynamicProperty("mrpg:site", key || "");
  if (raid) e.setDynamicProperty("mrpg:raidUntil", Date.now() + 10 * 60 * 1000);
  e.nameTag = `${raid ? "§d【レイドボス】" : "§4【ボス】"}§f${SPECIES[sid].name} §7Lv${lv} ${rankOf(sid)}`;
  return e;
}

// v2.9.12: 城の 中にも 野生の モンスターは 出ない（着いた とたんに 戦いに ならない）
let CST = [], CST_T = -9999;
function castlesNear(loc, r) {
  if (system.currentTick - CST_T > 200) { CST_T = system.currentTick; CST = []; for (let i = 0; i < WREGIONS.length; i++) { const c = castleInfo(i); if (c && c.built) CST.push(c); } }
  return CST.some((c) => Math.hypot(loc.x - c.x, loc.z - c.z) < r);
}
hooks.inTown = (loc, dim) => loc && (!dim || dim === "minecraft:overworld") && (!!townAt(loc, 50) || castlesNear(loc, 74));   // v2.9.12: 四すみの 塔まで（50）。城は 城下町（半径72）まで

// v3.0: 町を 置く 前に まわり ±48 の 候補から 地方に あう 地面を えらぶ（読みこまれて いる 所だけ・ほかの 町や ステージから はなれた 所）
function* fitTownSpotG(ow, pos, out) {   // 第63版: 1候補ずつ（runJob で 少しずつ しらべる）
  try {
    const sp0 = world.getDefaultSpawnLocation(), ri0 = regionIdx(pos.x - sp0.x, pos.z - sp0.z), rid = WREGIONS[ri0]?.id; if (!rid) { out.best = null; return; }
    let best = null, bv = -1e9;
    const RG = LAYOUT.v >= 2 ? 16 : 48, SG = LAYOUT.v >= 2 ? 16 : 24, CG = LAYOUT.v === 3 ? 148 : 110, TG = LAYOUT.v === 3 ? 108 : 130, LG = LAYOUT.v === 3 ? 84 : 110;   /* 第99版: 寄せた 配置では 少しだけ（となりと ぶつからない ように） */
    for (let dx = -RG; dx <= RG; dx += SG) for (let dz = -RG; dz <= RG; dz += SG) {
      const x = Math.floor(pos.x + dx), z = Math.floor(pos.z + dz);
      if (regionIdx(x - sp0.x, z - sp0.z) !== ri0 || stageNear(x, z)) continue;
      if (TOWNS.some((u) => { const q = getTown(u.id); return q && Math.hypot(q.x - x, q.z - z) < TG; })) continue;
      if (WREGIONS.some((R, ci) => { const c = castleInfo(ci) || castleSpot(ci); return Math.hypot(c.x - x, c.z - z) < CG; })) continue;   // v3.0: 城と ステージから はなす
      if (WREGIONS.some((R, li) => landSites(li).some((L) => Math.hypot(L.x - x, L.z - z) < LG))) continue;
      if (DG_ALL.some((ci) => { if (!CAVE_R.includes(ci) && !caveInfo(ci)) return false; const b = caveBox(ci); return x > b.x1 - 60 && x < b.x2 + 60 && z > b.z1 - 60 && z < b.z2 + 60; })) continue;   /* 洞くつ（入口・坂道・広間）とも はなす */
      let v = 0, n = 0, ys = [];
      for (let i = -24; i <= 24; i += 24) for (let j = -24; j <= 24; j += 24) { let b = null; try { b = ow.getTopmostBlock?.({ x: x + i, z: z + j }); } catch {} if (!b) continue; /* v3.0: 読みこまれて いない 所は その 点だけ とばす */ n++; v += fitScore(rid, b.typeId); ys.push(b.location.y); }
      if (n < 7) continue;   /* 読みこまれて いない 所は 候補に しない（町 1つに つき 1回だけ・225回まで しらべる） */
      const my = ys.reduce((a, b) => a + b, 0) / ys.length, flat = ys.reduce((a, b) => a + Math.abs(b - my), 0) / ys.length;
      const sc = v - flat * 0.6 - Math.hypot(dx, dz) / 60;
      if (sc > bv) { bv = sc; best = { x: pos.x + dx, z: pos.z + dz }; }
      out.best = best; yield;
    }
    out.best = best;
  } catch { out.best = null; }
}
function fitTownSpot(ow, pos) { const o = {}; for (const _ of fitTownSpotG(ow, pos, o)); return o.best ?? null; }
let TJOB = false, TJOB_T = 0;
function runSteps(gen) { if (typeof system.runJob === "function") { try { system.runJob(gen); return; } catch {} } for (const _ of gen); }
// ---------- 生成チェックのループ ----------
let townCheck = 0;
system.runInterval(() => {
  if (building() || warming()) return;   // v1.7: 入った 直後は 建物を 作らない
  const players = world.getAllPlayers();
  // 街
  for (const t of TOWNS) {
    const info = getTown(t.id);
    if (info && info.built && info.v === CITY_V) continue;
    if ((TOWN_FAIL.get(t.id) || 0) > Date.now()) continue;
    if (info && info.built) {   /* 第106版: 前の 町を 同じ 場所で 新しい 町に 建てかえ */
      const p0 = players.find((x) => x.dimension.id === "minecraft:overworld" && Math.hypot(x.location.x - info.x, x.location.z - info.z) < 110); if (!p0 || TBUILD.has(t.id)) continue;
      const ow0 = world.getDimension("overworld");
      buildTown(t, ow0, info.x, info.y, info.z, () => { setTown(t.id, { ...getTown(t.id), built: true, ms: true, lib: true, fish: true, v: CITY_V }); for (const q of world.getAllPlayers()) if (Math.hypot(q.location.x - info.x, q.location.z - info.z) < 160) q.sendMessage(`§e§l${t.name}§r§e が 新しく なった！`); }, () => TOWN_FAIL.set(t.id, Date.now() + 300000));
      return;
    }
    const pos = townPos(t);
    const ow = world.getDimension("overworld");
    const p = players.find((x) => x.dimension.id === "minecraft:overworld" && Math.hypot(x.location.x - pos.x, x.location.z - pos.z) < (t.id === "t0" ? 200 : 110));
    if (!p || stageNear(pos.x, pos.z)) continue;
    if (TJOB && system.currentTick - TJOB_T < 1200) return;   // 1分で 解除（ジョブが 止まっても 残らない）
    TJOB = true; TJOB_T = system.currentTick;   // 第63版: 場所えらびは runJob で 少しずつ（作り始めの 一瞬の 止まりを へらす）
    runSteps((function* () {
      try {
        if (!info && t.id !== "t0") { const o = {}; yield* fitTownSpotG(ow, pos, o); if (o.best) { pos.x = o.best.x; pos.z = o.best.z; } }   // v3.0: 地方に あう 地面へ 少し ずらす
        yield;
        const y = dryY(ow, pos.x, pos.z, spotY(ow, pos.x, pos.z, 14), 40);
        if (y === null) { TOWN_FAIL.set(t.id, Date.now() + 20000); return; }
        yield;
        if (getTown(t.id)?.built || TBUILD.has(t.id)) return;
        setTown(t.id, { x: Math.floor(pos.x) + 0.5, y, z: Math.floor(pos.z) + 0.5, built: false });
        buildTown(t, ow, pos.x, y, pos.z, () => {
          setTown(t.id, { x: Math.floor(pos.x) + 0.5, y, z: Math.floor(pos.z) + 0.5, built: true, ms: true, lib: true, fish: true, v: CITY_V });
          for (const q of world.getAllPlayers()) q.sendMessage(`§e§l${t.name}§r§e が すがたを あらわした！`);
        }, () => TOWN_FAIL.set(t.id, Date.now() + 300000));
      } catch (e) { console.warn(`[MonsterRPG] town job: ${e}`); } finally { TJOB = false; }
    })());
    return;
  }
  // 遺跡
  for (const p of players) {
    const R = REGION[p.dimension.id];
    if (!R || busy.has(p.id) || inRuins(p.location)) continue;   /* 第76版: 滅びた 世界には ふつうの 遺跡を 作らない */
    const rx0 = Math.floor(p.location.x / R), rz0 = Math.floor(p.location.z / R);
    for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
      const site = siteOf(p.dimension.id, rx0 + dx, rz0 + dz);
      if (Math.hypot(site.x - p.location.x, site.z - p.location.z) > 80) continue;
      const r0 = getRuin(site.key);
      // v2.5: マルチ: ほかの 人が 倒した 遺跡でも、まだ 越えて いない 人が 来たら ボスが また 現れる
      if (r0 && r0.built && r0.cleared && !(r0.by || []).includes(p.id) && Math.hypot(r0.x - p.location.x, r0.z - p.location.z) < 40) {
        let near = false;
        try { near = p.dimension.getEntities({ type: TYPE, tags: ["mrpg_boss"], location: { x: r0.x, y: r0.y, z: r0.z }, maxDistance: 48 }).length > 0; } catch { near = true; }
        if (!near && !(r0.re && Date.now() - r0.re < 60000)) {
          r0.re = Date.now(); setRuin(site.key, r0);
          const at = r0.ax !== undefined ? { x: r0.ax, y: r0.ay, z: r0.az } : { x: r0.x + 0.5, y: r0.y + 1, z: r0.z + 0.5 };
          try { spawnBoss(p.dimension, at, r0.biome, levelAt(p.dimension, at), site.key); p.sendMessage("§6遺跡の 奥に ボスの 気配が もどった……（あなたは まだ この 遺跡を 越えていない）"); } catch {}
        }
        continue;
      }
      if (r0 && !r0.built && !r0.skip && Date.now() - (r0.t || 0) > 180000 && !(RUIN_Q.has(site.key) && Date.now() - RUIN_Q.get(site.key) < 900000)) { try { world.setDynamicProperty(site.key, undefined); RAW.delete(site.key); } catch {} continue; }   // v2.9.12: 作りかけで 止まった 遺跡は 作りなおす
      if (r0) continue;
      if (p.dimension.id === "minecraft:overworld" && TOWNS.some((t) => { const q = townPos(t); return Math.hypot(q.x - site.x, q.z - site.z) < 80; })) { setRuin(site.key, { skip: true }); continue; }
      if (ruinBlocked(p.dimension.id, site)) { setRuin(site.key, { skip: true }); continue; }   // v2.9.12: 城・ステージ・洞くつの そばには 遺跡（ボス）を 作らない
      const y = owY(p.dimension, site.x, site.z, Math.floor(p.location.y));
      if (y === null) continue;
      const biome = biomeAt(p.dimension, { x: site.x, y, z: site.z });
      setRuin(site.key, { x: site.x, y, z: site.z, biome, built: false, t: Date.now() });
      const dim = p.dimension;
      RUIN_Q.set(site.key, Date.now());   // v2.9.12: 作る 順番を まって いる あいだは 作りなおさない（2つ できない ように）
      buildRuin(dim, site, y, biome, (altar, rname) => {
        RUIN_Q.delete(site.key);
        const lv = levelAt(dim, altar);
        spawnBoss(dim, altar, biome, lv, site.key);
        setRuin(site.key, { x: site.x, y, z: site.z, biome, built: true, cleared: false, ax: altar.x, ay: altar.y, az: altar.z });
        for (const q of world.getAllPlayers()) if (q.dimension.id === dim.id && Math.hypot(q.location.x - site.x, q.location.z - site.z) < 120)
          q.sendMessage(`§6近くに 「${rname}」を 見つけた！ おくに ボスの 気配が する…`);
      });
      return;
    }
  }
}, 40);

// 街への到着・発見
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue;
    // v2.9.12: 城に 着いたら ワープに 登録
    try {
      for (let i = 0; i < WREGIONS.length; i++) {
        const c = castleInfo(i); if (!c || !c.built) continue;
        if (Math.hypot(p.location.x - c.x, p.location.z - c.z) > 45) continue;
        const dc = load(p); if (!dc) break;
        dc.castles = dc.castles || [];
        if (!dc.castles.includes(i)) { dc.castles.push(i); save(p, dc); try { showTitle(p, `§6${WREGIONS[i].castle.name}`, { subtitle: "§fワープポイントに 登録した！", fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 10 }); } catch {} sound(p, "random.levelup"); }
        break;
      }
    } catch {}
    const t = townAt(p.location, 38);
    if (!t) continue;
    const d = load(p);
    if (!d) continue;
    if (!d.towns) d.towns = [];
    // 前の バージョンで できた 街に モンスター屋を たす
    const info = getTown(t.id);
    if (info && info.built && !info.ms) {
      try {
        const e = p.dimension.spawnEntity("mrpg:npc", { x: info.x + 5, y: info.y, z: info.z - 5 });
        setJob(e, 11); e.nameTag = `§e${JOBS[11]}`; e.addTag("mrpg_npc"); e.setDynamicProperty("mrpg:town", t.id);
      } catch {}
      info.ms = true; setTown(t.id, info);
    }
    if (info && info.built && !info.lib) {
      for (const [job, dx, dz] of [[12, 5, 5], [13, -5, 5]]) {
        try {
          const e = p.dimension.spawnEntity("mrpg:npc", { x: info.x + dx, y: info.y, z: info.z + dz });
          setJob(e, job); e.nameTag = `§e${JOBS[job]}`; e.addTag("mrpg_npc"); e.setDynamicProperty("mrpg:town", t.id);
        } catch {}
      }
      info.lib = true; setTown(t.id, info);
    }
    if (info && info.built && !info.fish) {
      try {
        const e = p.dimension.spawnEntity("mrpg:npc", { x: info.x - 5, y: info.y, z: info.z - 5 });   // v2.9.12: モンスター屋と 重ならない 場所
        setJob(e, 14); e.nameTag = `§e${JOBS[14]}`; e.addTag("mrpg_npc"); e.setDynamicProperty("mrpg:town", t.id);
      } catch {}
      info.fish = true; setTown(t.id, info);
    }
    if (!d.towns.includes(t.id)) {
      d.towns.push(t.id); save(p, d);
      try { showTitle(p, `§e${t.name}`, { subtitle: "§fワープポイントに 登録した！", fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
      sound(p, "random.levelup");
    }
  }
}, 40);

// レイドボス（約15分ごと）
let raidTick = 0;
system.runInterval(() => {
  if (warming()) return;
  raidTick++;
  for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) {
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_raid"] }); } catch {}
    for (const e of list) { const u = e.getDynamicProperty("mrpg:raidUntil"); if (typeof u === "number" && u < Date.now() && !e.hasTag("mrpg_battle")) { try { e.remove(); } catch {} } }
  }
  if (raidTick % 15 !== 0) return;
  const players = world.getAllPlayers().filter((p) => !busy.has(p.id) && load(p));
  if (!players.length) return;
  const p = pick(players);
  if ((hooks.noSpawn && hooks.noSpawn(p)) || hooks.inTown(p.location, p.dimension.id)) return;   // v2.9.12: 町・城・石板の 中には レイドを 出さない
  { let rl0 = 50; try { if (p.dimension.id === "minecraft:overworld") rl0 = regionLv(p.location); } catch {} if (Math.random() > 0.35 + 0.65 * Math.max(0, Math.min(1, (rl0 - 10) / 80))) return; }   /* 第68版: 終盤の 地方ほど レイドが 出やすい */
  const d = load(p);
  const avg = Math.max(Math.round(d.party.reduce((s, m) => s + m.lv, 0) / Math.max(1, d.party.length)), Math.max(1, ...[...d.party, ...(d.bench || []), ...(d.box || [])].map((m) => m.lv || 1)) - 5);   // v2.9.12: いちばん 強い 子に 合わせる（弱い 子だけ 連れて 低く しない）
  const a = Math.random() * Math.PI * 2;
  const pos = { x: p.location.x + Math.cos(a) * 10, y: p.location.y, z: p.location.z + Math.sin(a) * 10 };
  const y = groundY(p.dimension, pos.x, pos.z, Math.floor(p.location.y));
  if (y === null) return;
  pos.y = y;
  if (hooks.inTown(pos, p.dimension.id)) return;   // v2.9.12: 出る 場所が 町・城なら やめる
  let rl = null; try { if (p.dimension.id === "minecraft:overworld") rl = regionLv(pos); } catch {}
  const e = spawnBoss(p.dimension, pos, biomeAt(p.dimension, pos), Math.max(5, avg), "", true, rl);
  for (const q of world.getAllPlayers()) {
    q.sendMessage(`§d§l【レイド】§r§d ${p.name}の 近くに ${e.nameTag.replace(/§./g, "")} が 現れた！ みんなで 殴って さんせんしよう！（10ぷん）`);
    sound(q, "mob.enderdragon.growl", 1.2);
  }
}, 1200);

// ================= v2.3: 地方の 城・ステージ・自分の 家 =================
const ckey = (i) => `mrpg:castle:${i}`;
export function castleInfo(i) { try { const v = rawGet(ckey(i)); return v ? JSON.parse(v) : null; } catch { return null; } }
function setCastle(i, v) { try { rawSet(ckey(i), JSON.stringify(v)); } catch {} }
/* 第126版: ルインズ荒野の 城は 廃都（人の 住まない 崩れた 都）。rv が ちがう 城は 近づいた ときに 1回 建てなおす */
const RUINED = (i) => WREGIONS[i]?.id === "ruins";
const castleCur = (i, c) => !!(c && c.built && c.v === CITY_V && (!RUINED(i) || c.rv === RUIN_V || ruinClash(i, c)));
/* 第123版: 前の 都の 半径 72 が ほかの 城と 重なる 世界（配置2: シルヴァン城と 110）では 建てなおさない（シルヴァンの 城壁の 中・預かり屋を 削って いた）*/
const ruinClash = (i, c) => WREGIONS.some((_, j) => { if (j === i) return false; const k = castleInfo(j); return !!(k && k.built && Math.hypot(k.x - c.x, k.z - c.z) < 144); });
const RB = new Set();
const FULLB = (b) => !!(b && !b.isAir && !b.isLiquid && !/slab|stairs|wall|fence|door|pane|bars|carpet|snow_layer|lantern|torch|web|bush|grass|flower|fern|vine|ladder|sign|button|lever|rail|plate|chain|leaves|sapling|campfire/.test(b.typeId));
function liftOut(ow, p) {
  try { if (busy.has(p.id)) return; const l = p.location; if (![...RB].some((i) => { const c = castleSpot(i); return Math.hypot(l.x - c.x, l.z - c.z) < 78; })) return;
    const x = Math.floor(l.x), y = Math.floor(l.y), z = Math.floor(l.z); if (!FULLB(ow.getBlock({ x, y: y + 1, z })) && !FULLB(ow.getBlock({ x, y, z }))) return;
    const g = groundY(ow, x, z, y + 1); if (g !== null && g !== y) p.teleport({ x: l.x, y: g + 0.05, z: l.z }); } catch {}
}
// 町と 重なる ときは 少し ずらす
export function castleSpot(i) {
  const c = castlePos(i), s0 = world.getDefaultSpawnLocation();
  if (LAYOUT.v >= 2) return c;   /* 第99版: 寄せた 配置は 重ならない 場所を 先に 決めて ある */
  for (let k = 0; k < 8; k++) {
    const x = c.x + [0, 80, -80, 0, 0, 120, -120, 0][k], z = c.z + [0, 0, 0, 80, -80, 0, 0, 120][k];
    if (TOWNS.every((t) => Math.hypot(s0.x + t.dx - x, s0.z + t.dz - z) > 110)) return { x, z };   // v3.0: 町の 予定地から 110（castleOff と 同じ）
  }
  return c;
}
function buildCastle(i, dim, cx, cy, cz, done, fail) {
  if (RUINED(i)) { setEdge(edgeOf(dim, cx, cy, cz, 72)); const Bp = ruinPlan(i, 1000 + i), X = Math.floor(cx), Y = Math.floor(cy), Z = Math.floor(cz); setEdge(null);
    runPlan(dim, Bp, cx, cy, cz, 72, () => {
      try { for (const tg of [`mrpg_castle${i}`, `mrpg_wk_c${i}`, ...(WREGIONS[i].rm >= 0 ? [`mrpg_rm${WREGIONS[i].rm}`] : [])]) for (const e of dim.getEntities({ type: "mrpg:npc", tags: [tg], location: { x: cx, y: cy, z: cz }, maxDistance: 110 })) e.remove(); } catch {}
      try { world.setDynamicProperty(`mrpg:walk:c${i}`, undefined); world.setDynamicProperty("mrpg:walkids", JSON.stringify(JSON.parse(world.getDynamicProperty("mrpg:walkids") || "[]").filter((k) => k !== `c${i}`))); resetWalkCache(); } catch {}
      const A = (q) => ({ x: X + q.x, y: Y + q.y, z: Z + q.z }), M = Bp.mark, ru = {}; for (const k in M.ruin) ru[k] = A(M.ruin[k]);
      done && done(A(M.master), A(M.throne), ru);
    }, () => { try { fail && fail(); } catch {} });
    return; }
  { setEdge(edgeOf(dim, cx, cy, cz, 72)); const R0 = WREGIONS[i], Bp = capitalPlan(i, R0.style, 1000 + i), X = Math.floor(cx), Y = Math.floor(cy), Z = Math.floor(cz); setEdge(null);   /* 第106版: 城下町（都）・外の 地面に なじませる */
    runPlan(dim, Bp, cx, cy, cz, 72, () => {
      try { for (const tg of [`mrpg_castle${i}`, ...(R0.rm >= 0 ? [`mrpg_rm${R0.rm}`] : [])]) for (const e of dim.getEntities({ type: "mrpg:npc", tags: [tg], location: { x: cx, y: cy, z: cz }, maxDistance: 90 })) e.remove(); } catch {}
      const M = Bp.mark, T = M.throne;
      spawnCityNpcs(dim, X, Y, Z, [{ job: 15, king: i, pos: { x: T.x, y: T.y, z: T.z }, name: `§6${R0.castle.name}の 王` }, { job: 16, pos: { x: M.gate.x - 2, y: M.gate.y, z: M.gate.z - (R0.style === "port" ? 9.5 : 3.5) }, name: "§7城の 衛兵" }, { job: 16, pos: { x: M.gate.x + 2, y: M.gate.y, z: M.gate.z - (R0.style === "port" ? 9.5 : 3.5) }, name: "§7城の 衛兵" }, ...Bp.npc], `mrpg_castle${i}`, null);
      try { world.setDynamicProperty(`mrpg:walk:c${i}`, JSON.stringify({ x: X, y: Y, z: Z, w: Bp.walk, s: Bp.seat, p: Bp.spots })); } catch {} walkIndex(`c${i}`);
      done && done({ x: X + M.master.x, y: Y + M.master.y, z: Z + M.master.z }, { x: X + T.x, y: Y + T.y, z: Z + T.z });
    }, () => { try { fail && fail(); } catch {} });
    return; }
  const R = WREGIONS[i], C = R.castle, P = new Plan(cx, cy, cz), W = C.wall, RF = C.roof, AC = C.acc;
  const S = STY[R.style] || STY.castle;
  P.fill(-25, -10, -25, 25, -5, 25, "stone"); P.fill(-25, 0, -25, 25, 24, 25, "air"); P.fill(-25, -4, -25, 25, -2, 25, "dirt"); P.fill(-25, -1, -25, 25, -1, 25, S.ground);   // v2.9.12: 水の 上でも しずまない 土台
  P.fill(-19, -1, -19, 19, -1, 19, S.path);
  // 外壁（高さ 7）と 胸壁
  for (const [a, b, c, d] of [[-20, -20, 20, -20], [-20, 20, 20, 20], [-20, -20, -20, 20], [20, -20, 20, 20]]) { P.fill(a, 0, b, c, 6, d, W); for (let k = 0; k <= 40; k += 2) { const x = a === c ? a : a + k, z = a === c ? b + k : b; if (Math.abs(x) <= 20 && Math.abs(z) <= 20) P.set(x, 7, z, W); } }
  // 四すみの 塔
  for (const [x, z] of [[-20, -20], [20, -20], [-20, 20], [20, 20]]) {
    P.fill(x - 3, 0, z - 3, x + 3, 11, z + 3, W, "hollow"); P.fill(x - 3, -1, z - 3, x + 3, -1, z + 3, S.path);   // 第77版: 床だけ（y0 まで 埋めると 塔の 根もとが 道の 色に なる）
    P.fill(x - 4, 12, z - 4, x + 4, 12, z + 4, RF); P.fill(x - 3, 13, z - 3, x + 3, 13, z + 3, RF); P.fill(x - 2, 14, z - 2, x + 2, 14, z + 2, RF); P.set(x, 15, z, RF); P.set(x, 16, z, S.lamp);
    P.set(x, 10, z, "glowstone");
  }
  // 門（南）
  P.fill(-3, 0, 20, 3, 4, 20, "air"); P.fill(-4, 0, 21, -4, 8, 21, AC); P.fill(4, 0, 21, 4, 8, 21, AC); P.fill(-4, 8, 21, 4, 9, 21, RF);
  for (const x of [-6, 6]) { P.fill(x, 0, 22, x, 2, 22, S.fence); P.set(x, 3, 22, S.lamp); }
  // 中庭: 道・ふんすい・花・灯り
  P.fill(-2, -1, -1, 2, -1, 20, "polished_andesite"); P.fill(-4, -1, 4, 4, -1, 12, S.plaza);
  P.fill(-2, 0, 6, 2, 0, 10, AC); P.fill(-1, 0, 7, 1, 0, 9, "water"); P.set(0, 1, 8, AC); P.set(0, 2, 8, S.lamp);
  for (const [x, z] of [[-8, 4], [8, 4], [-8, 14], [8, 14], [-15, 0], [15, 0]]) { P.fill(x, 0, z, x, 2, z, S.fence); P.set(x, 3, z, S.lamp); }
  for (let k = 0; k < 18; k++) { const x = ri(-18, 18), z = ri(1, 18); if (Math.abs(x) > 5) plant(P, x, 0, z, pick(S.flowers)); }   // 第77版: 中庭は 石の 道なので 土を そえる
  // 本丸（王の 間）
  P.fill(-10, -1, -17, 10, 11, -1, W, "hollow"); P.fill(-9, -1, -16, 9, -1, -2, S.plaza);
  P.fill(-11, 12, -18, 11, 12, 0, RF); P.fill(-9, 13, -16, 9, 13, -2, RF); P.fill(-6, 14, -13, 6, 14, -5, RF);
  for (const [x, z] of [[-10, -1], [10, -1], [-10, -17], [10, -17]]) { P.fill(x, 0, z, x, 15, z, AC); P.set(x, 16, z, S.lamp); }
  P.fill(-2, 0, -1, 2, 4, -1, "air");
  P.fill(-1, -1, -15, 1, -1, -2, "red_wool");
  P.fill(-2, 0, -16, 2, 0, -15, "gold_block"); P.set(0, 1, -16, "gold_block"); P.set(-1, 1, -16, AC); P.set(1, 1, -16, AC);
  for (const [x, z] of [[-6, -14], [6, -14], [-6, -6], [6, -6]]) { P.fill(x, 0, z, x, 10, z, AC); P.set(x, 10, z, "glowstone"); }
  for (const z of [-4, -9, -13]) { P.fill(-10, 3, z, -10, 4, z + 1, "glass"); P.fill(10, 3, z, 10, 4, z + 1, "glass"); }
  P.loot(-8, 0, -15, "mrpg/treasure"); P.loot(8, 0, -15, "mrpg/treasure");
  P.loot(-17, 0, -17, "mrpg/house"); P.loot(17, 0, 17, "mrpg/roadside");
  const npcs = [{ job: 15, king: i, pos: P.at(0, 0, -13), name: `§6${C.name}の 王` }, { job: 5, pos: P.at(-12, 0, 8) }, { job: 2, pos: P.at(12, 0, 8) }, { job: 7, pos: P.at(0, 0, 15) }, { job: 3, pos: P.at(-12, 0, 2) },
    { job: 16, pos: P.at(-2, 0, 18), name: "§7城の 衛兵" }, { job: 16, pos: P.at(2, 0, 18), name: "§7城の 衛兵" }];
  castleFeature(P, R.style, W, RF, AC, S);
  enqueue(dim, P.c, () => {
    try { for (const tg of [`mrpg_castle${i}`, ...(R.rm >= 0 ? [`mrpg_rm${R.rm}`] : [])]) for (const e of dim.getEntities({ type: "mrpg:npc", tags: [tg], location: { x: cx, y: cy, z: cz }, maxDistance: 60 })) e.remove(); } catch {}   /* 前の 城の 人を 消してから（建てて いる 間に 読みこまれて いる） */
    for (const n of npcs) {
      try {
        const e = dim.spawnEntity("mrpg:npc", n.pos);
        setJob(e, n.job); e.nameTag = n.name || `§e${JOBS[n.job]}`; e.addTag("mrpg_npc"); e.addTag(`mrpg_castle${i}`);
        if (n.king !== undefined) e.setDynamicProperty("mrpg:king", n.king);
        system.runTimeout(() => unstuckNpc(e), 10);
      } catch {}
    }
    done && done(P.at(5, 0, -12));
  }, P.area(26));
}
// v2.9: 城ごとの 個性（地方の スタイルに あわせた 名物）
function castleFeature(P, st, W, RF, AC, S) {
  const T4 = [[-20, -20], [20, -20], [-20, 20], [20, 20]];
  if (st === "desert") {
    for (const [x, z] of T4) { P.fill(x - 3, 12, z - 3, x + 3, 15, z + 3, "air"); for (let k = 0; k < 4; k++) P.fill(x - 3 + k, 12 + k, z - 3 + k, x + 3 - k, 12 + k, z + 3 - k, k % 2 ? "smooth_sandstone" : "gold_block"); P.set(x, 16, z, "lantern"); }
    for (const [x, z] of [[-14, 8], [14, 8], [-14, 16], [14, 16]]) { P.fill(x, 0, z, x, 5, z, "jungle_log"); P.fill(x - 2, 6, z, x + 2, 6, z, "jungle_leaves"); P.fill(x, 6, z - 2, x, 6, z + 2, "jungle_leaves"); }
  } else if (st === "snow") {
    for (const [x, z] of T4) { P.fill(x - 4, 13, z - 4, x + 4, 13, z + 4, "snow_layer", "keep");   /* 第77版: 屋根の 段を 消さない */ P.fill(x + 4, 0, z + 4, x + 4, 6, z + 4, "packed_ice"); P.set(x + 4, 7, z + 4, "blue_ice"); }
    for (const [x, z, h] of [[-15, 12, 7], [15, 14, 9], [-13, 18, 5]]) { P.fill(x, 0, z, x, h, z, "packed_ice"); P.fill(x - 1, 0, z, x + 1, Math.floor(h / 2), z, "packed_ice"); }
  } else if (st === "volcano") {
    P.fill(-23, -1, -23, 23, -1, -23, "magma"); P.fill(-23, -1, 23, -6, -1, 23, "magma"); P.fill(6, -1, 23, 23, -1, 23, "magma");
    for (const [x, z] of T4) { P.set(x, 17, z, "campfire"); P.fill(x - 4, 11, z - 4, x + 4, 11, z + 4, "red_nether_brick", "outline"); }
    for (const [x, z] of [[-15, 10], [15, 10]]) { P.fill(x - 1, 0, z - 1, x + 1, 0, z + 1, "blackstone"); P.set(x, 1, z, "campfire"); }
  } else if (st === "forest") {
    for (const [x, z, h] of [[-15, 10, 9], [15, 12, 10], [-14, 17, 7], [14, 4, 8]]) { P.fill(x, 0, z, x, h, z, "spruce_log"); P.fill(x - 2, h - 2, z - 2, x + 2, h, z + 2, "spruce_leaves"); P.fill(x - 1, h + 1, z - 1, x + 1, h + 2, z + 1, "spruce_leaves"); }
    for (const [x, z] of T4) { P.fill(x - 3, 0, z + 4, x + 3, 6, z + 4, "moss_block", "outline"); }
  } else if (st === "port") {
    P.fill(-24, -2, -24, 24, -1, -22, "water"); P.fill(-24, -2, 22, -5, -1, 24, "water"); P.fill(5, -2, 22, 24, -1, 24, "water");
    P.fill(-3, -1, 21, 3, -1, 25, "spruce_planks"); for (const x of [-3, 3]) { P.fill(x, 0, 21, x, 1, 25, "spruce_fence"); }
    for (const [x, z] of T4) P.set(x, 17, z, "sea_lantern");
  } else if (st === "crystal") {
    for (const [x, z] of T4) { P.fill(x, 15, z, x, 19, z, "amethyst_block"); P.set(x, 20, z, "amethyst_cluster"); }
    for (const [x, z, h] of [[-14, 10, 5], [14, 10, 6], [0, 18, 4]]) { P.fill(x, 0, z, x + 1, h, z + 1, "amethyst_block"); P.set(x, h + 1, z, "amethyst_cluster"); }
  } else if (st === "dark") {
    for (const [x, z] of T4) { P.fill(x, 15, z, x, 21, z, "polished_blackstone_bricks"); P.set(x, 22, z, "soul_lantern"); }
    for (const [x, z] of [[-15, 8], [15, 8], [-15, 16], [15, 16]]) { P.set(x, -1, z, "soul_soil"); P.set(x, 0, z, "soul_fire"); P.fill(x - 1, 0, z - 1, x + 1, 0, z + 1, "blackstone_wall", "outline"); }
  } else if (st === "sky") {
    for (const [x, z] of T4) { P.fill(x - 3, 13, z - 3, x + 3, 13, z + 3, "glass"); P.set(x, 17, z, "end_rod"); }
    for (const [x, z] of [[-14, 12], [14, 12]]) { P.fill(x - 2, 8, z - 2, x + 2, 8, z + 2, "white_wool"); P.fill(x - 1, 9, z - 1, x + 1, 9, z + 1, "white_wool"); }
  } else {
    // ほり（水）と 旗
    P.fill(-24, -2, -24, 24, -1, -22, "water"); P.fill(-24, -2, -24, -22, -1, 24, "water"); P.fill(22, -2, -24, 24, -1, 24, "water");
    for (const [x, z] of T4) { P.fill(x, 16, z, x, 19, z, "dark_oak_fence"); P.fill(x + 1, 18, z, x + 2, 19, z, ["red_wool", "blue_wool", "yellow_wool", "lime_wool"][Math.abs(x + z) % 4]); }
  }
}
// ステージ（地方の テーマの 大地。迷わず 見つけられる 目印つき）
export function landInfo(key) { try { const v = world.getDynamicProperty(key); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
// 自分の 家（始まりの町 ルミナ）
const HOME_KEY = "mrpg:home";
export function homeInfo() { try { const v = world.getDynamicProperty(HOME_KEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
function buildHome(dim, info) {
  /* 第115版: 家は はじまりの 町の 中、広場から 西へ のびる 大通りに 面した 所（扉は 大通りの 方）。前は 町の はずれで 扉の 前を 店が ふさいで いた */
  const P = new Plan(info.x - 0.5, info.y, info.z - 0.5);
  const t = { wall: "oak_planks", roof: "dark_oak_planks" };
  P.fill(-26, 0, 2, -18, 6, 6, "air");
  house(P, -22, 4, 9, 5, "n", t, null, [[-3, 0, 1, "bookshelf"], [-3, 1, 1, "bookshelf"], [-3, 0, -1, "crafting_table"], [2, 0, 1, "furnace"], [1, 0, 1, "barrel"], [0, 0, 0, "red_carpet"], [1, 0, 0, "red_carpet"], [3, 0, -1, "white_wool"], [3, 0, 0, "red_wool"]]);
  P.loot(-24, 0, 5, "mrpg/house");
  P.fill(-23, -1, 1, -20, -1, 1, "grass_path");
  return { cmds: P.c, spawn: P.at(-22, 0, 4), v: 3 };
}

let wmTick = 0;
const lastReg = new Map();
system.runInterval(() => {
  if (warming()) return;
  wmTick++;
  const players = world.getAllPlayers().filter((p) => p.dimension.id === "minecraft:overworld");
  const ow = world.getDimension("overworld"), s0 = world.getDefaultSpawnLocation();
  // 地方に 入った とき
  for (const p of players) {
    if (inRuins(p.location)) continue;   /* 第76版 */
    const i = regionIdx(p.location.x - s0.x, p.location.z - s0.z);
    if (lastReg.get(p.id) !== i) {
      const first = lastReg.has(p.id) || wmTick > 3;
      lastReg.set(p.id, i);
      const R = WREGIONS[i];
      if (first) { try { showTitle(p, `${R.col}§l${R.name}`, { subtitle: `§7Lv${R.lv[0]}〜${R.lv[1]}  ${R.castle.name}`, fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 15 }); } catch {} }
      const d = load(p); if (d) { if (!d.regions) d.regions = []; if (!d.regions.includes(i)) { d.regions.push(i); save(p, d); try { p.sendMessage(`${R.col}§l${R.name}§r§7 ― ${R.desc}`); } catch {} } }
    }
  }
  if (RB.size) for (const p of players) liftOut(ow, p);   /* 第123版: 城（廃都）を 建てて いる 間、壁や 丘に 埋まった 人を 上へ */
  if (wmTick % 5 === 0) WREGIONS.forEach((R, i) => { if (!RUINED(i)) return; const ci = castleInfo(i); if (!ci || ci.rv !== RUIN_V || !players.some((p) => Math.hypot(p.location.x - ci.x, p.location.z - ci.z) < 90)) return;   /* 第123版: 建てなおしの 時に 読みこまれて いなかった 前の 都の 店の 人・客・歩く 人を 消す（王の 代理は のこす）*/
    try { for (const tg of [`mrpg_castle${i}`, `mrpg_wk_c${i}`]) for (const e of ow.getEntities({ type: "mrpg:npc", tags: [tg], location: { x: ci.x, y: ci.y, z: ci.z }, maxDistance: 110 })) { let k; try { k = e.getDynamicProperty("mrpg:king"); } catch {} if (k !== i) e.remove(); } } catch {} });
  if (building()) return;
  // 自分の 家（はじめて 入った 人を 家に）
  const t0 = getTown("t0");
  let home = homeInfo();
  if (home && !home.built && Date.now() - (home.t || 0) > 180000) { home = null; try { world.setDynamicProperty(HOME_KEY, undefined); } catch {} }   // v2.9.12: 作りかけの 家は 作りなおす
  if (home && home.built && home.v !== 3) { home = null; try { world.setDynamicProperty(HOME_KEY, undefined); } catch {} }   /* 第115版: 家を 大通りぞいへ 建てなおす（前の 家は 扉の 前が ふさがって いた）*/
  if (t0 && t0.built && !home) { const H = buildHome(ow, t0);  home = { x: H.spawn.x, y: H.spawn.y, z: H.spawn.z, built: false, v: H.v, t: Date.now() }; world.setDynamicProperty(HOME_KEY, JSON.stringify(home)); enqueue(ow, H.cmds, () => { home.built = true; world.setDynamicProperty(HOME_KEY, JSON.stringify(home)); }, [{ x: t0.x - 30, y: t0.y - 3, z: t0.z - 32 }, { x: t0.x - 14, y: t0.y + 10, z: t0.z - 16 }]); return; }
  if (home && home.built) for (const p of players) {
    if (!p.hasTag("mrpg_newhome") || busy.has(p.id) || globalThis.__mqScene?.has?.(p.id)) continue;   /* 第128版: 場面の とちゅう（戦いの 前の すきま など）では 家へ 飛ばさない */
    p.removeTag("mrpg_newhome");
    try { p.teleport({ x: home.x, y: home.y + 0.1, z: home.z }, { facingLocation: { x: home.x, y: home.y + 1, z: home.z + 4 } }); } catch {}
    run(ow, `spawnpoint "${p.name}" ${Math.floor(home.x)} ${Math.floor(home.y)} ${Math.floor(home.z)}`);
    try { showTitle(p, "§aアルカトラス地方", { subtitle: "§f始まりの町 ルミナ ― 自分の 家", fadeInDuration: 20, stayDuration: 60, fadeOutDuration: 20 }); } catch {}
    try { p.sendMessage("§7…朝の 光が 窓から さしこむ。ここは アルカトラス地方の 田舎町、ルミナの 自分の 家だ。\n§f母「おはよう。広場で オルドじいさんが 呼んでたわよ。ガイドブックを 忘れずにね」"); } catch {}
  }
  // 城
  for (let i = 0; i < WREGIONS.length; i++) {
    const info = castleInfo(i);
    if (castleCur(i, info) || RB.has(i)) continue;
    const c = castleSpot(i);
    const p = players.find((x) => Math.hypot(x.location.x - c.x, x.location.z - c.z) < 120);
    if (!p || (!info && stageNear(c.x, c.z))) continue;
    const y = info && info.built ? Math.floor(info.y) : dryY(ow, c.x, c.z, spotY(ow, c.x, c.z, 16), 27);   /* 第106版: 前の 城は 同じ 高さで 都に 建てかえ */
    if (y === null) continue;
    makeCastle(i, ow, c, y, false, RUINED(i) && !!(info && info.built));
    return;
  }
  // ステージ（テーマの 大地）
  for (let i = 0; i < WREGIONS.length; i++) for (const L of landSites(i)) {
    // v2.9.8: 作りかけで ワールドを 閉じた ステージは 作りなおす（物語が 進まなく なるのを ふせぐ）
    const li0 = landInfo(L.key); if ((li0 && (li0.built || li0.skip)) || LAND_Q.has(L.key)) continue;
    const p = players.find((x) => Math.hypot(x.location.x - L.x, x.location.z - L.z) < 96);
    if (!p || stageNear(L.x, L.z)) continue;
    if (TOWNS.some((t) => Math.hypot(s0.x + t.dx - L.x, s0.z + t.dz - L.z) < 70)) { world.setDynamicProperty(L.key, JSON.stringify({ skip: true })); continue; }
    const y = dryY(ow, L.x, L.z, spotY(ow, L.x, L.z, 12), 26);
    if (y === null) continue;
    makeLand(L, ow, y);
    return;
  }
}, 40);

// ---------- v2.9.12: 物語の 場所を 先に 作っておく（着いたら もう ある・洞くつの 中に 埋まらない） ----------
function makeCastle(i, ow, c, y, quiet, keep) {
  if (!keep) setCastle(i, { x: c.x + 0.5, y, z: c.z + 0.5, built: false });
  RB.add(i);
  buildCastle(i, ow, c.x, y, c.z, (mpos, kpos, ruin) => {
    RB.delete(i);
    setCastle(i, { x: c.x + 0.5, y, z: c.z + 0.5, built: true, m: mpos, k: kpos, v: CITY_V, chk: 1, chkw: 1, ...(ruin ? { ruin, rv: RUIN_V } : {}) });
    for (const q of world.getAllPlayers()) if (!quiet || Math.hypot(q.location.x - c.x, q.location.z - c.z) < 160) q.sendMessage(`${WREGIONS[i].col}§l${WREGIONS[i].castle.name}§r§e が 見えてきた！`);
  }, () => RB.delete(i));
}
/* 第124版(tr): 新しく 作る ステージは 高低差の ある 地形（tv = 地形の 版）。出来事の 入口の 向き（ed）を 先に 決めて、そこを 平らに 残す。
   はじまりの 地方（0）は なだらか。前から ある ステージ（tv なし）は さわらない */
export const LAND_HOOK = { dir: null };
export const landQ = (k) => LAND_Q.has(k);   /* 第125版: 作りなおし（landredo.js）から 使う */
export function makeLand(L, ow, y, chkw = false, redo = false) {
  world.setDynamicProperty(L.key, JSON.stringify({ x: L.x, y, z: L.z, theme: L.theme, built: false }));
  const m = /:(\d+):(\d+)$/.exec(L.key), ri = m ? +m[1] : -1;
  let ed = -1; try { if (m && LAND_HOOK.dir) ed = LAND_HOOK.dir(ri, +m[2], L.x, L.z); } catch {}
  const G = genLand(L.x, y, L.z, L.theme, 24, hashStr(L.key), { ed, gentle: ri === 0, nochest: redo });
  LAND_Q.add(L.key);
  enqueue(ow, G.cmds, () => {
    LAND_Q.delete(L.key);
    world.setDynamicProperty(L.key, JSON.stringify({ x: L.x, y, z: L.z, theme: L.theme, built: true, name: G.name, tv: LAND_V, pv: G.pv, ed, hi: G.hi, sm: [L.x + G.geo.top[0], y + G.geo.top[2] + 1, L.z + G.geo.top[1]], chk: 1, chkw: 1 }));
    for (const q of world.getAllPlayers()) if (Math.hypot(q.location.x - L.x, q.location.z - L.z) < 140) q.sendMessage(`§b近くに「${G.name}」が 広がっている……`);
  }, [{ x: L.x - 26, y: y - 4, z: L.z - 26 }, { x: L.x + 26, y: y + 40, z: L.z + 26 }], () => { LAND_Q.delete(L.key); try { world.setDynamicProperty(L.key, undefined); } catch {} });
}
// 物語の 洞くつ（シルヴァ・クリスタリア）: 岩の 口 → 曲がった 広い 坂道（とちゅうに 休む 小部屋）→ 奥の 丸い 大広間
// 第128版（cv 2）: 広間は 直径 25・天井 12。まん中に 直径 14 の 平らな 舞台、奥に 祭壇、柱・地底の 池・鍾乳石
export const CAVE_R = [1, 3, 4, 5, 7, 8, 9];   /* 第124版: 六影の アジト（3 鋳造所・7 霊廟・8 氷の 隠れ家・9 本拠地）と 王墓（4）*/
export const CAVE_NM = { 3: "六影の 鋳造所", 4: "砂の 王墓", 7: "冥府の 霊廟", 8: "六影の 氷の 隠れ家", 9: "六影 本拠地" };
export const DG_X = [0, 2, 6, 10];   /* 第125版: 物語の 外の ダンジョン（地下水路・城の 地下・灯台と 海蝕洞・天空の 浮島）。宝箱と モンスターだけ */
export const DG_ALL = [...CAVE_R, ...DG_X];
export const caveName = (i) => { if (CAVE_NM[i]) return CAVE_NM[i]; const v = CAVE_R.includes(i) ? caveInfo(i) : null; return v && v.built && !v.dt ? `${WREGIONS[i]?.short || ""}の 洞くつ` : dgType(WREGIONS[i]?.id).nm; };   /* 第125版: 作りなおす 前の 洞くつは 前の 名前 */
export const CAVE_NO = new Set();   /* 場所が 取れなかった 地方（町・城・ステージに かかる。物語は 今までの 場所で 始める）*/
const CAVE_OLD = [1, 5];   /* 前から ある 洞くつ（場所の 決め方を 変えない）*/
export const CAVE_V = 3;   /* 第125版: 地方ごとの ダンジョン（広い 部屋・宝箱・モンスター）*/
const CHR = 12, CHH = 12;   /* 広間の 半径・天井の 高さ */
export function caveSite(i) { const L = landSites(i)[0]; return { key: `mrpg:cave:${i}`, x: L.x + 48, z: L.z }; }
export function caveInfo(i) { try { const v = world.getDynamicProperty(`mrpg:cave:${i}`); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
/* 洞くつ 全体の 四角（入口〜広間）。できて いない ときは 見こみ */
export function caveBox(i) {
  const v = caveInfo(i), c = v || caveSite(i), R = (v && v.R) || CHR;
  if (v && v.box) return { x1: v.box.x1, x2: v.box.x2, z1: v.box.z1, z2: v.box.z2, y1: v.box.y1, y2: v.box.y2, hall: v.hall, R };
  if (!v || !v.hall) { const t = dgType(WREGIONS[i]?.id), B = dgBoxL(t.dir < 0 ? 14 : t.L0 || 0); return { x1: c.x + B.x1, x2: c.x + B.x2, z1: c.z + B.z1, z2: c.z + B.z2, hall: { x: c.x, z: c.z + (t.dir < 0 ? 14 : t.L0 || 0) + 79 }, R }; }   /* 第125版: できる 前の 見こみ */
  const h = v.hall; return { x1: Math.min(c.x, h.x) - R - 3, x2: Math.max(c.x, h.x) + R + 3, z1: c.z - 6, z2: h.z + R + 3, hall: h, R };
}
/* 第125版: ダンジョンの 中に いるか（地下は 入口より 下・大樹と 浮島は 入口より 奥）*/
export function inCaveBox(i, l) {
  try { const v = caveInfo(i); if (!v || !v.built) return false; const b = caveBox(i); if (l.x < b.x1 || l.x > b.x2 || l.z < b.z1 || l.z > b.z2) return false;
    if (b.y1 !== undefined && (l.y < b.y1 || l.y > b.y2)) return false; return v.dir > 0 ? l.z > v.z + 0.5 && l.y >= v.y - 1 : l.y < v.y - 3; } catch { return false; }
}
/* 地方ごとの 見た目 */
const CAVE_T = {
  silva: { sh: ["rooted_dirt", "dark_oak_log"], fl: ["moss_block", "coarse_dirt"], lt: "shroomlight", lo: "moss_block", up: "rooted_dirt", col: "dark_oak_log", drip: "dark_oak_log", dais: "mossy_stone_bricks", hang: "hanging_roots", rug: "moss_carpet" },   /* 第125版: 大樹の 根の 広間 */
  arca: { sh: ["stone_bricks", "mossy_stone_bricks"], fl: ["stone_bricks", "mossy_stone_bricks"], lt: "sea_lantern", lo: "mossy_stone_bricks", up: "stone_bricks", col: "chiseled_stone_bricks", drip: "mossy_cobblestone", dais: "stone_bricks", hang: null, rug: null },
  ruins: { sh: ["stone_bricks", "cracked_stone_bricks"], fl: ["polished_andesite", "cobblestone"], lt: "ochre_froglight", lo: "cracked_stone_bricks", up: "stone_bricks", col: "chiseled_stone_bricks", drip: "cobblestone", dais: "polished_andesite", hang: null, rug: null, pool: "none" },
  mari: { sh: ["prismarine", "dark_prismarine"], fl: ["prismarine_bricks", "smooth_sandstone"], lt: "sea_lantern", lo: "prismarine_bricks", up: "dark_prismarine", col: "dark_prismarine", drip: "prismarine", dais: "prismarine_bricks", hang: null, rug: null },
  celes: { sh: ["smooth_quartz", "quartz_bricks"], fl: ["quartz_bricks", "smooth_quartz"], lt: "sea_lantern", lo: "quartz_bricks", up: "smooth_quartz", col: "quartz_pillar", drip: "quartz_pillar", dais: "gold_block", hang: null, rug: null, pool: "none" },
  crys: { sh: ["tuff", "calcite"], fl: ["calcite", "smooth_basalt"], lt: "sea_lantern", lo: "calcite", up: "tuff", col: "calcite", drip: "amethyst_block", dais: "smooth_basalt", hang: null, rug: null },
  /* 第124版: 六影の アジト。色は 戦いの ドーム（volcano・soulvalley・icepeak・endcity）と 同じ。mark = 入口に 六影の 印（紫の 柱と 青い 灯）*/
  volka: { sh: ["blackstone", "basalt"], fl: ["polished_blackstone", "smooth_basalt"], lt: "shroomlight", lo: "blackstone", up: "basalt", col: "polished_blackstone_bricks", drip: "basalt", dais: "polished_blackstone_bricks", hang: null, rug: null, pool: "none", mark: 1, props: propsForge },
  sand: { sh: ["sandstone", "smooth_sandstone"], fl: ["cut_sandstone", "sandstone"], lt: "ochre_froglight", lo: "cut_sandstone", up: "sandstone", col: "chiseled_sandstone", drip: "sandstone", dais: "cut_sandstone", hang: null, rug: null, pool: "none" },
  necro: { sh: ["polished_blackstone_bricks", "deepslate_bricks"], fl: ["deepslate_tiles", "soul_soil"], lt: "pearlescent_froglight", lo: "polished_blackstone_bricks", up: "deepslate_tiles", col: "bone_block", drip: "deepslate", dais: "polished_blackstone_bricks", hang: null, rug: null, pool: "water", mark: 1, props: propsTomb },
  frost: { sh: ["packed_ice", "snow"], fl: ["snow", "stone"], lt: "sea_lantern", lo: "packed_ice", up: "blue_ice", col: "packed_ice", drip: "packed_ice", dais: "polished_andesite", hang: null, rug: null, pool: "ice", mark: 1, props: propsIce },
  ragna: { sh: ["purpur_block", "end_stone_bricks"], fl: ["end_stone_bricks", "purpur_block"], lt: "pearlescent_froglight", lo: "purpur_block", up: "obsidian", col: "bone_block", drip: "bone_block", dais: "obsidian", hang: null, rug: null, pool: "none", mark: 1, props: propsAltar },
  def: { sh: ["stone", "cobblestone"], fl: ["stone", "andesite"], lt: "glowstone", lo: "stone", up: "stone", col: "cobblestone", drip: "dripstone_block", dais: "stone_bricks", hang: null, rug: null },
};
/* 第124版: アジトの 小道具。B/S は 広間の 中心からの 相対（dy 0 = 足もと・-1 = 床・+z = 奥）。まん中の 半径 7 は 床より 上に 置かない */
function propsForge({ B, S }) {   /* 鋳造所: ガラスの 下の 溶岩・石板を 円く 並べる 台座・炉・金床・火薬だる */
  B(-3, -3, -3, 3, -2, 3, "blackstone"); B(-2, -2, -2, 2, -2, 2, "lava"); B(-2, -1, -2, 2, -1, 2, "orange_stained_glass");
  for (const [a, b] of [[4, 0], [3, 3], [0, 4], [-3, 3], [-4, 0], [-3, -3], [0, -4], [3, -3]]) S(a, -1, b, "gilded_blackstone");
  B(-2, 1, 11, 2, 4, 12, "blackstone"); B(-1, 2, 11, 1, 3, 11, "lava"); B(-1, 2, 10, 1, 3, 10, "orange_stained_glass"); B(-1, 1, 10, 1, 1, 10, "blast_furnace");
  S(-6, 0, 8, "anvil"); S(6, 0, 8, "anvil"); S(5, 0, 9, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'); S(9, 0, -3, "barrel"); S(9, 0, -2, "barrel"); S(9, 1, -3, "barrel");
}
function propsTomb({ B, S }) {   /* 霊廟: 棺の 列・冥王家の 大きな 棺・流されなかった 灯籠 */
  for (const z of [-2, 0, 2]) { B(9, 0, z, 10, 0, z, "deepslate_tile_slab"); S(8, 0, z, "soul_torch"); }   /* 人の 出て くる 陰（±4）は ふさがない */
  B(5, 0, 8, 6, 0, 8, "deepslate_tile_slab"); S(4, 0, 8, "soul_torch"); B(-6, 0, 8, -5, 0, 8, "deepslate_tile_slab"); S(-4, 0, 8, "soul_torch");
  B(-1, 1, 10, 1, 1, 10, "chiseled_deepslate"); B(-1, 2, 10, 1, 2, 10, "deepslate_tile_slab");   /* 壇の 奥（柱の あいだ）。壇の 前（祭壇の 点）は 立てる まま */
  S(-7, 0, 1, "lantern");   /* 池の ふち（舞台の 半径 7 の 外）*/
}
function propsIce({ S }) {   /* 氷の 隠れ家: たき火と 腰かけ・荷・地図の 机・双子の 寝床（青と 桃色）*/
  S(6, 0, -8, "campfire"); S(4, 0, -8, "spruce_stairs"); S(6, 0, -6, "spruce_stairs");
  S(9, 0, 3, "barrel"); S(9, 0, 4, "barrel"); S(9, 1, 3, "barrel");
  S(-6, 0, 8, "cartography_table"); S(-5, 0, 8, "lectern");
  S(-1, 1, 9, "blue_carpet"); S(1, 1, 9, "pink_carpet"); S(0, 1, 8, "lantern");   /* 祭壇の 点（0,1,9）は 立てる まま */
}
function propsAltar({ B, S, fill, x, y, z, mx1, mx2 }) {   /* 本拠地: 地上の 竜骨の 門・十四の 石板の 円・六本の 鍵の くぼみ */
  fill(mx1 - 1, y - 3, z - 4, mx1 - 1, y + 4, z - 4, "bone_block"); fill(mx2 + 1, y - 3, z - 4, mx2 + 1, y + 4, z - 4, "bone_block");
  fill(mx1 - 1, y + 5, z - 4, mx2 + 1, y + 5, z - 4, "bone_block"); fill(mx1 - 2, y + 6, z - 4, mx1 - 2, y + 6, z - 4, "bone_block"); fill(mx2 + 2, y + 6, z - 4, mx2 + 2, y + 6, z - 4, "bone_block");
  for (let k = 0; k < 14; k++) { const t = (k * Math.PI * 2) / 14; S(Math.round(5 * Math.cos(t)), -1, Math.round(5 * Math.sin(t)), "crying_obsidian"); }
  for (const a of [-5, -3, -1, 1, 3, 5]) S(a, -1, 7, "lodestone");
}
const cvRng = (s) => { s = s >>> 0 || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; };
/* 坂道の 形（入口から +z へ）: ox 中心の ずれ・f 床（入口から）・hl/hr 左右の 半幅・h 天井・room 小部屋 */
export function caveTunnel(D, seed) {
  const r = cvRng(seed), S = [], ph = r() * 6, PAT = [1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0];
  let f = 0, ox = 0, hl = 2, hr = 2, h = 5, pat = 0, rm = -1, rmDone = false;
  for (let k = 0; k < 300; k++) {
    let drop = 0, room = false, wide = 0;
    if (k >= 4) {
      if (rm < 0 && !rmDone && f <= -Math.ceil(D / 2)) rm = k;
      if (rm >= 0 && !rmDone) { const j = k - rm; if (j >= 13) rmDone = true; else { wide = 1; room = j >= 3 && j < 10; } }
      if (!wide && f > -D) { drop = PAT[pat % PAT.length]; pat++; }
      if (!wide && f <= -D && S.filter((q) => q.f === -D).length >= 3) break;
    }
    if (drop) f--;
    const o2 = wide ? ox : Math.round(2.4 * Math.sin(k * 0.09 + ph)), Re = ox + hr, Le = ox - hl;
    ox = Math.max(ox - 1, Math.min(ox + 1, o2));
    const tl = wide ? 5 : 2 + (r() < 0.35 ? 1 : 0), tr = wide ? 5 : 2 + (r() < 0.35 ? 1 : 0);
    hr = Math.max(2, Math.min(Re + 1 - ox, Math.max(Re - 1 - ox, tr)));
    hl = Math.max(2, Math.min(ox - Le + 1, Math.max(ox - Le - 1, tl)));
    const th = wide ? 5 : 4 + (r() < 0.4 ? 1 : 0);
    h = k < 4 ? 5 : drop ? Math.max(h, th) : Math.max(h - 1, Math.min(h + 1, th));
    S.push({ ox, f, hl, hr, h, room });
  }
  return S;
}
/* 洞くつの 全部の コマンドと 記録する 座標（x,y,z = 入口の 床の 高さ、F = 広間の 床）*/
export function cavePlan(i, x, y, z, F, old) {
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  const T = CAVE_T[WREGIONS[i]?.id] || CAVE_T.def, r = cvRng(hashStr(`cave${i}`)), C = [], R = CHR, H = CHH, D = y - F;
  const fill = (a, b, c, d, e, f, blk, m) => C.push(`fill ${Math.min(a, d)} ${Math.min(b, e)} ${Math.min(c, f)} ${Math.max(a, d)} ${Math.max(b, e)} ${Math.max(c, f)} ${blk}${m ? " " + m : ""}`);
  const L = dgBuild(WREGIONS[i]?.id, x, y, z, F), hx = L.hx, hz = L.hz, UP = L.t.dir > 0, OP = !!L.t.open, S = L.corr;   /* 第125版: 地方ごとの ダンジョン（dglayout.js）*/
  const NAT = ["stone", "andesite", "diorite", "granite", "dirt", "deepslate", "cobblestone"];
  /* 0. 前の 版の 洞くつ（門・階段・11×11 の 広間）を うめる */
  if (old && old.hall) {
    const ox0 = Math.floor(old.x), oy = Math.floor(old.y), oz = Math.floor(old.z), od = Math.max(0, oy - Math.floor(old.hall.y));
    fill(ox0 - 3, oy, oz - 3, ox0 + 3, oy + 7, oz + 3, "air");
    for (let k = 0; k <= od; k++) fill(ox0 - 2, oy - k - 1, oz + k, ox0 + 2, Math.min(oy - 1, oy - k + 4), oz + k, T.sh[0]);
    const H0 = old.hall; fill(Math.floor(H0.x) - 7, Math.floor(H0.y) - 1, Math.floor(H0.z) - 7, Math.floor(H0.x) + 7, Math.floor(H0.y) + 6, Math.floor(H0.z) + 7, T.sh[0]);
  }
  /* 0b. 第128版の 曲がった 坂道と 丸い 広間を うめる（作りなおしの とき）*/
  if (old && old.hall && old.R && old.cv !== CAVE_V && !old.dt) { const ox0 = Math.floor(old.x), oy = Math.floor(old.y), oz = Math.floor(old.z), H0 = old.hall, OS = caveTunnel(oy - Math.floor(H0.y), hashStr(`cave${i}t`));
    for (let k = 0; k < OS.length; k += 3) { const q = OS[k]; fill(ox0 + q.ox - q.hl, oy + q.f - 1, oz + k, ox0 + q.ox + q.hr, oy + q.f + q.h, oz + Math.min(OS.length - 1, k + 2), T.sh[0]); }
    fill(ox0 - 4, oy, oz - 3, ox0 + 4, oy + 6, oz + 2, "air"); fill(ox0 - 4, oy - 1, oz - 3, ox0 + 4, oy - 1, oz + 2, "grass_block");
    const hx0 = Math.floor(H0.x), hy0 = Math.floor(H0.y), hz0 = Math.floor(H0.z), r0 = old.R + 1; for (const a of [10, 45, 80]) { const t = (a * Math.PI) / 180, A = Math.round(r0 * Math.cos(t)), B = Math.round(r0 * Math.sin(t)); fill(hx0 - A, hy0, hz0 - B, hx0 + A, hy0 + (old.H || 12), hz0 + B, T.sh[0]); } }
  const disc = (cx, cz, rr, y1, y2, blk) => { for (const a of [10, 28, 45, 62, 80]) { const t = (a * Math.PI) / 180, A = Math.round(rr * Math.cos(t)), B = Math.round(rr * Math.sin(t)); fill(cx - A, y1, cz - B, cx + A, y2, cz + B, blk); } };
  /* 1. 外側を 固める（部屋・坂・入口の 目印、広間の 円柱）。地上の ダンジョン（大樹）は 広間の 下に 幹 */
  C.push(...L.shell);
  if (OP) { disc(hx, hz, R + 1, F - 2, F - 1, T.fl[0]); disc(hx, hz, R - 3, F - 4, F - 3, T.sh[1]); disc(hx, hz, R - 7, F - 6, F - 5, "stone"); disc(hx, hz, R + 2, F, F + H + 2, "air"); }
  else { disc(hx, hz, R + 3, F - 2, F + H + 1, T.sh[0]); if (UP) { fill(hx - 5, y - 4, hz - 5, hx + 5, F - 3, hz + 5, T.sh[0]); fill(hx - R - 2, F + H + 2, hz - R - 2, hx + R + 2, F + H + 3, hz + R + 2, "oak_leaves", "keep"); for (const [a, b] of [[-15, 0], [15, 0], [0, 15]]) fill(hx + a - 2, F + 6, hz + b - 2, hx + a + 2, F + 9, hz + b + 2, "oak_leaves", "keep"); } }
  /* 2. くりぬく */
  C.push(...L.carve);
  const mx1 = x - 2, mx2 = x + 2;
  if (T.mark) for (const q of [mx1 - 3, mx2 + 3]) { fill(q, y, z - 4, q, y + 1, z - 4, "purple_concrete"); C.push(`setblock ${q} ${y + 2} ${z - 4} soul_lantern`); }
  /* 4. 大広間（下 4段は 円柱、上は 丸天井。角度を かえた 四角を 重ねて 円に する）*/
  const rho = (dy) => (dy < 4 ? R : R * Math.sqrt(Math.max(0, 1 - ((dy - 3) / (H - 3)) ** 2)));
  disc(hx, hz, R, F, F + 3, "air");
  for (let dy = 4; dy < H; dy++) { const j = dy < H - 1 ? Math.round((r() - 0.5) * 1.6) : 0; disc(hx + j, hz - j, Math.max(2, rho(dy) + (r() - 0.5) * 1.2), F + dy, F + dy, "air"); }
  /* 壁の 色（下・まん中・上）*/
  if (!OP) for (const [y1, y2, b] of [[F - 1, F + 3, T.lo], [F + 4, F + 7, T.sh[0]], [F + 8, F + H + 1, T.up]]) for (const nb of NAT) if (nb !== b) fill(hx - R - 2, y1, hz - R - 2, hx + R + 2, y2, hz + R + 2, b, `replace ${nb}`);
  disc(hx, hz, R, F - 1, F - 1, T.fl[0]);
  for (const a of [30, 150, 205, 330]) { const t = (a * Math.PI) / 180, px = hx + Math.round(10 * Math.cos(t)), pz = hz + Math.round(10 * Math.sin(t)); fill(px - 1, F - 1, pz - 1, px + 1, F - 1, pz + 1, T.fl[1]); }
  /* 柱（4本・2×2。根もとと 天井で 太く）*/
  const PIL = [40, 140, 220, 320].map((a) => { const t = (a * Math.PI) / 180; return { a, x: hx + Math.round(10 * Math.cos(t)) - (Math.cos(t) < 0 ? 1 : 0), z: hz + Math.round(10 * Math.sin(t)) - (Math.sin(t) < 0 ? 1 : 0) }; });   /* ふちに 寄せる（2×2 の 内側の 角が 半径 8.5 より 外）*/
  for (const p of PIL) { fill(p.x, F, p.z, p.x + 1, F + H, p.z + 1, T.col); fill(p.x - 1, F, p.z - 1, p.x + 2, F, p.z + 2, T.col); fill(p.x - 1, F + 7, p.z - 1, p.x + 2, F + H, p.z + 2, T.col); }
  /* 鍾乳石（天井から）・石筍（ふち）。第125版: 入口の 側（引きの カメラの 上）には 下げない */
  const ceilAt = (d) => F + 3 + Math.floor((H - 3) * Math.sqrt(Math.max(0, 1 - (d / R) ** 2)));
  if (!OP) for (let k = 0; k < 9; k++) { const a = r() * Math.PI * 2, d = 3 + r() * 7, sx = hx + Math.round(d * Math.cos(a)), sz = hz + Math.round(d * Math.sin(a)), top = ceilAt(d), low = Math.max(top - 1 - Math.floor(r() * 3), d < 8 ? F + 8 : F + 6); if (low <= top && Math.sin(a) > -0.35) fill(sx, low, sz, sx, top + 1, sz, T.drip); }
  for (const a of [15, 165, 195, 345]) { const t = (a * Math.PI) / 180, sx = hx + Math.round(10.6 * Math.cos(t)), sz = hz + Math.round(10.6 * Math.sin(t)); fill(sx, F, sz, sx, F + 1 + (a % 2), sz, T.drip); }
  /* 地底の 池（西の ふち・浅い）*/
  if (T.pool === "ice") { fill(hx - 11, F - 3, hz - 3, hx - 7, F - 2, hz + 3, "packed_ice"); fill(hx - 10, F - 2, hz - 2, hx - 8, F - 2, hz + 2, "water"); fill(hx - 10, F - 1, hz - 2, hx - 8, F - 1, hz + 2, "ice"); }   /* 第124版: 薄い 氷の 池（下は 水）*/
  else if (T.pool !== "none") { fill(hx - 10, F - 2, hz - 3, hx - 7, F - 2, hz + 3, T.sh[0]); fill(hx - 10, F - 1, hz - 2, hx - 8, F - 1, hz + 2, "water"); }
  /* 光る もの（ふちの 4か所）: 森は 光る きのこ、水晶は 水晶の 群れ */
  for (const a of [5, 110, 250, 290]) {
    const t = (a * Math.PI) / 180, sx = hx + Math.round(10.4 * Math.cos(t)), sz = hz + Math.round(10.4 * Math.sin(t));
    if (T === CAVE_T.silva) { fill(sx, F, sz, sx, F + 1, sz, "mushroom_stem"); fill(sx - 1, F + 2, sz - 1, sx + 1, F + 2, sz + 1, "shroomlight"); }
    else if (T === CAVE_T.crys) { fill(sx, F, sz, sx, F + 1, sz, "sea_lantern"); fill(sx, F + 2, sz, sx, F + 3, sz, "amethyst_block"); C.push(`setblock ${sx} ${F + 4} ${sz} amethyst_cluster`, `setblock ${sx + 1} ${F} ${sz} amethyst_block`, `setblock ${sx - 1} ${F} ${sz} calcite`); }
    else fill(sx, F, sz, sx, F + 1, sz, T.lt);
  }
  /* 天井の 灯り */
  if (!OP) { fill(hx - 1, F + H, hz - 1, hx, F + H, hz, T.lt); for (const [a, b] of [[6, 0], [-6, 0], [0, -6]]) C.push(`setblock ${hx + a} ${ceilAt(6) + 1} ${hz + b} ${T.lt}`); }
  else for (let a = 0; a < 360; a += 10) { if (a > 250 && a < 290) continue; const t = (a * Math.PI) / 180; C.push(`setblock ${hx + Math.round((R + 1) * Math.cos(t))} ${F} ${hz + Math.round((R + 1) * Math.sin(t))} ${L.t.fence || "oak_fence"}`); }   /* 浮島の ふちの 柵（入口の 側は あける）*/
  /* 祭壇（奥 = +z）: 精霊の 石・曇った 水晶 */
  fill(hx - 2, F, hz + 8, hx + 2, F, hz + 10, T.dais);
  if (T === CAVE_T.crys) { fill(hx - 1, F + 1, hz + 10, hx + 1, F + 2, hz + 10, "tinted_glass"); fill(hx, F + 3, hz + 10, hx, F + 5, hz + 10, "amethyst_block"); C.push(`setblock ${hx - 2} ${F + 1} ${hz + 10} amethyst_cluster`, `setblock ${hx + 2} ${F + 1} ${hz + 10} amethyst_cluster`); }
  else { fill(hx - 2, F + 1, hz + 10, hx - 2, F + 3, hz + 10, T.col); fill(hx + 2, F + 1, hz + 10, hx + 2, F + 3, hz + 10, T.col); fill(hx - 2, F + 4, hz + 10, hx + 2, F + 4, hz + 10, T.lo); C.push(`setblock ${hx} ${F + 1} ${hz + 10} ${T === CAVE_T.silva ? "verdant_froglight" : T.lt}`); if (T.hang) C.push(`setblock ${hx - 1} ${F + 3} ${hz + 10} ${T.hang}`, `setblock ${hx + 1} ${F + 3} ${hz + 10} ${T.hang}`); if (T.rug) C.push(`setblock ${hx - 1} ${F + 1} ${hz + 9} ${T.rug}`, `setblock ${hx + 1} ${F + 1} ${hz + 9} ${T.rug}`); }
  /* 記録する 座標 */
  const P = (a, b, c) => ({ x: a + 0.5, y: b, z: c + 0.5 });
  const shade = [];
  for (const a of [75, 57, 123, 23, 157, 203, 337]) { const t = (a * Math.PI) / 180; shade.push(P(hx + Math.round(10.6 * Math.cos(t)), F, hz + Math.round(10.6 * Math.sin(t)))); }   /* 祭壇の 横の 暗がり・柱の 陰 */
  /* 第124版: 六影の 印（広間の 入口の 内側）と 小道具 */
  if (T.mark) for (const q of [-3, 3]) { fill(hx + q, F, hz - 10, hx + q, F + 1, hz - 10, "purple_concrete"); C.push(`setblock ${hx + q} ${F + 2} ${hz - 10} soul_lantern`); }
  if (T.props) T.props({ fill, C, hx, F, hz, x, y, z, mx1, mx2, B: (a, b, c, d, e, f, blk) => fill(hx + a, F + b, hz + c, hx + d, F + e, hz + f, blk), S: (a, b, c, blk) => C.push(`setblock ${hx + a} ${F + b} ${hz + c} ${blk}`) });
  C.push(...L.deco);   /* 第125版: 部屋の 飾り・名所・宝箱・踏み板 */
  const info = { x: x + 0.5, y, z: z + 0.5, cv: CAVE_V, R, H, hall: P(hx, F, hz), entry: P(hx, F, hz - R + 1), altar: P(hx, F + 1, hz + 9), shade, len: L.L0, ...(T.pool === "ice" ? { pool: P(hx - 9, F, hz) } : {}), ...L.info };
  return { cmds: C, info, area: L.area, tun: S };
}
/* 水・空気・草木を とばした 地面の 高さ（海の 底も）。null = 読みこまれて いない */
function solidTop(ow, x, z) {
  x = Math.floor(x); z = Math.floor(z); let t; try { t = ow.getTopmostBlock?.({ x, z }); } catch { return null; } if (!t) return null;
  for (let y = t.location.y; y > -60; y--) { let b; try { b = ow.getBlock({ x, y, z }); } catch { return null; } if (!b) return null; if (b.isAir || b.isLiquid || NOT_GROUND.test(b.typeId)) continue; return y; }
  return null;
}
/* 広間の 床の 高さ: 入口から 18 以上 下・広間の 上の 地面（海の 底）より 天井が 4 以上 下 */
export function caveFloor(ow, i, x, y, z) {
  const t = dgType(WREGIONS[i]?.id); if (t.dir > 0) return y + 16 + (t.L0 || 0);   /* 第125版: 大樹・浮島は 上へ */
  let F = y - 28;   /* 地下: 部屋の 天井が 地面（海の 底）より 4 以上 下 */
  for (let it = 0; it < 3; it++) {
    let m = 1e9, unk = false;
    for (const [a, b, top] of dgProbe(y - F - 16)) { const s = solidTop(ow, x + a, z + b); if (s === null) unk = true; else m = Math.min(m, s - 4 - top); }
    const F2 = Math.max(y - 70, -40, Math.min(y - 28, unk ? 30 : 999, m));
    if (F2 >= F) break; F = F2;
  }
  return F;
}
/* ダンジョンの 四角（入口 x,y,z と 広間の 床 F から）*/
export function caveRect(i, x, y, z, F) { const B = dgBoxL(dgL0(dgType(WREGIONS[i]?.id), y, F)); return { x1: x + B.x1, x2: x + B.x2, z1: z + B.z1, z2: z + B.z2 }; }
/* ダンジョンが ほかの 建物（町・城・ステージ・家・遺跡・出来事・深海）に かからないか（B = 四角）*/
function caveClear(i, x, z, B) {
  const up = dgType(WREGIONS[i]?.id).dir > 0, S = { x1: x - 10, x2: x + 10, z1: z - 8, z2: z + 12 };   /* 地上に 出る 所（入口の 目印）は 広く よける。地下の 部屋は 地面より 4 以上 下なので 町・城の 下は 少し 寄って よい */
  const dR = (q, b) => Math.hypot(Math.max(b.x1 - q.x, 0, q.x - b.x2), Math.max(b.z1 - q.z, 0, q.z - b.z2)), near = (q, r) => dR(q, B) < r;
  const both = (q, rs, rb) => dR(q, S) < rs || dR(q, B) < rb;
  if (TOWNS.some((t) => both(getTown(t.id) || townPos(t), 50, 46))) return false;   /* 町（半径 44）の 下にも 入らない */
  if (WREGIONS.some((R, ci) => both(castleInfo(ci) || castleSpot(ci), 70, 70))) return false;   /* 城は 地下（牢・土台）も あるので 広く よける */
  if (WREGIONS.some((R, li) => landSites(li).some((L) => both(L, 30, 28)))) return false;   /* ステージは 半径 26 の 地上。部屋は その 下 */
  for (const j of DG_ALL) { if (j === i) continue; const v = caveInfo(j); if (!v || !v.hall) continue; const b = caveBox(j); if (B.x1 < b.x2 + 12 && B.x2 > b.x1 - 12 && B.z1 < b.z2 + 12 && B.z2 > b.z1 - 12) return false; }   /* ほかの ダンジョンと 12 あける */
  try { const h = homeInfo(); if (h && near(h, 40)) return false; } catch {}
  try { const Rg = REGION["minecraft:overworld"]; for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { const st = siteOf("minecraft:overworld", Math.floor(x / Rg) + a, Math.floor(((B.z1 + B.z2) / 2) / Rg) + b), ru = getRuin(st.key); if (ru && !ru.skip && near(st, 44)) return false; } } catch {}
  try { for (let r = 0; r < WREGIONS.length; r++) { const b = hooks.sevBox && hooks.sevBox(r); if (b && B.x2 + 6 > b.x1 && B.x1 - 6 < b.x2 && B.z2 + 4 > b.z1 && B.z1 - 4 < b.z2) return false; } } catch {}
  try { const d = JSON.parse(world.getDynamicProperty("mrpg:dsea") || "null"); if (d && near(d, 120)) return false; } catch {}
  return true;
}
const CVB = new Set();
/* 作りなおす あいだ 洞くつの 中で 埋まった 人を 入口の 前へ */
function caveOut(ow, i, force) {
  const b = caveBox(i), v = caveInfo(i) || caveSite(i);
  for (const p of world.getAllPlayers()) {
    try { if (p.dimension.id !== "minecraft:overworld") continue; const l = p.location; if (l.x < b.x1 || l.x > b.x2 || l.z < b.z1 || l.z > b.z2 || (!(v.dir > 0) && l.y > (v.y ?? 320) - 1)) continue;
      const x = Math.floor(l.x), y = Math.floor(l.y), z = Math.floor(l.z);
      if (!force && !FULLB(ow.getBlock({ x, y: y + 1, z })) && !FULLB(ow.getBlock({ x, y, z }))) continue;
      if (force) { let roof = false; for (let k = 2; k <= 9 && !roof; k++) roof = FULLB(ow.getBlock({ x, y: y + k, z })); if (!roof) continue; }   /* 地上（屋根の ない 所）に いる 人は そのまま */
      const fz = Math.floor(v.z) - 5, gy = groundY(ow, Math.floor(v.x), fz, Math.floor(v.y ?? 64) + 2);
      p.teleport({ x: Math.floor(v.x) + 0.5, y: (gy ?? Math.floor(v.y ?? 64)) + 0.05, z: fz + 0.5 }); } catch {}
  }
}
system.runInterval(() => { if (!CVB.size) return; const ow = world.getDimension("overworld"); for (const i of CVB) caveOut(ow, i, false); }, 10);
let CANDS = null;
function caveCands() { if (LAYOUT.v < 2) return [0, 24, 48, 72, 96, 120].map((d) => [d, 0]); if (!CANDS) { CANDS = []; for (let dz = -96; dz <= 96; dz += 24) for (let dx = -96; dx <= 96; dx += 12) CANDS.push([dx, dz]); CANDS.sort((a, b) => Math.hypot(a[0], a[1] * 0.8) - Math.hypot(b[0], b[1] * 0.8)); } return CANDS; }   /* 第125版: 近い 順（東西を 少し 先に）*/
function makeCave(i, ow, y0, old) {
  const c0 = caveSite(i);
  let c = { ...c0 }, y = y0, hit = false; const neo = !CAVE_OLD.includes(i);   /* 第124版: 新しい アジトは どの 候補も 町・城・ステージよけを 通す。取れなければ 作らない */
  if (old) { c = { ...c0, x: Math.floor(old.x), z: Math.floor(old.z) }; y = Math.floor(old.y); const F1 = caveFloor(ow, i, c.x, y, c.z); if (!caveClear(i, c.x, c.z, caveRect(i, c.x, y, c.z, F1))) old.far = 1; }   /* 作りなおしは 同じ 入口（第125版: 広く なって ぶつかる ときは 近くを さがす）*/
  if (!old || old.far) for (const [dx, dz] of caveCands()) {   /* 水の 上は さける（第125版: 東西に 加えて 南北にも ずらす。町・城・ステージよけは caveClear）*/
    const X = c0.x + dx, Z = c0.z + dz;
    if (!caveClear(i, X, Z, caveRect(i, X, 64, Z, 24))) continue;   /* 先に 地面を 見ない 見こみで ふるう（軽く）*/
    const yy = dryY(ow, X, Z, spotY(ow, X, Z, 4), 12); if (yy === null) continue;
    let wet = false; try { const b = ow.getBlock({ x: X, y: yy - 1, z: Z }); wet = !b || b.isLiquid || /water|lava/.test(b.typeId); } catch { wet = true; }
    if (wet) continue;
    const F0 = caveFloor(ow, i, X, yy, Z); if (!caveClear(i, X, Z, caveRect(i, X, yy, Z, F0))) continue;
    c = { ...c0, x: X, z: Z }; y = yy; hit = true; break;
  }
  if (old && old.far && !hit) { delete old.far; try { world.setDynamicProperty(c.key, JSON.stringify({ ...old, cv: CAVE_V, keep: 1 })); } catch {} return true; }   /* 置き場が ない: 前の 洞くつの まま（物語は そのまま 進む）*/
  if (old) delete old.far;
  if (neo && !old && !hit) { CAVE_NO.add(i); return false; }
  if (!neo && !old && !hit) { const yy = dryY(ow, c0.x, c0.z, spotY(ow, c0.x, c0.z, 4), 12); if (yy !== null) y = yy; }   /* 前から ある 物語の 場所は 今までの 入口で 作る */
  CAVE_NO.delete(i);
  const F = caveFloor(ow, i, c.x, y, c.z), G = cavePlan(i, c.x, y, c.z, F, old);
  if (old) { CVB.add(i); caveOut(ow, i, true); }
  world.setDynamicProperty(c.key, JSON.stringify({ ...G.info, built: false }));
  enqueue(ow, G.cmds, () => { CVB.delete(i); world.setDynamicProperty(c.key, JSON.stringify({ ...G.info, built: true })); }, G.area, () => { CVB.delete(i); try { world.setDynamicProperty(c.key, old ? JSON.stringify(old) : undefined); } catch {} });
}
export const __caveTest = { makeCave, caveClear };   /* 点検用 */
// 遺跡（ボス）を 作らない 場所: 城・ステージ・洞くつの そば
export function ruinBlocked(dimId, site) {
  if (dimId !== "minecraft:overworld") return false;
  for (let i = 0; i < WREGIONS.length; i++) {
    const c = castleInfo(i) || castleSpot(i); if (Math.hypot(c.x - site.x, c.z - site.z) < 120) return true;   /* 第108版: 城下町（半径72）と はなす */
    for (const L of landSites(i)) if (Math.hypot(L.x - site.x, L.z - site.z) < 60) return true;
    if (CAVE_R.includes(i) || (DG_ALL.includes(i) && caveInfo(i))) { const b = caveBox(i); const m = b.y1 !== undefined ? 28 : 40; if (site.x > b.x1 - m && site.x < b.x2 + m && site.z > b.z1 - m && site.z < b.z2 + m) return true; }   /* 第128版: 坂道と 広間の 上も（第125版: できた ダンジョンは 四角が 正確なので 28）*/
  }
  try { for (const t of TOWNS) { const q = getTown(t.id) || townPos(t); if (q && Math.hypot(q.x - site.x, q.z - site.z) < 140) return true; } } catch {}   /* 第108版: 町（半径44）とも はなす（第127版: 140）*/
  try { const os = JSON.parse(world.getDynamicProperty("mrpg:osite") || "{}") || {}; for (const v of Object.values(os)) if (v && Math.hypot(v.x - site.x, v.z - site.z) < 70) return true; } catch {}   /* 第127版(fac): 物語の 施設の 場所とも はなす */
  return false;
}
// 前の 版で 地面の 下に 埋まって できた 城・ステージを 見つけたら 地表に 作りなおす
function buried(ow, info, pts) {
  const L = [];
  for (const [dx, dz] of pts) { const y = surfaceY(ow, info.x + dx, info.z + dz); if (y === null) return null; L.push(y); }
  L.sort((a, b) => a - b); return L[Math.floor(L.length / 2)] > info.y + 10;
}
const PRE = { job: null, fail: new Map(), checked: new Set() };
// v2.9.12: 建物の 床の 高さに 水が あるか（null = まだ 読みこまれて いない）
function wetAt(ow, cx, y, cz, pts) { let wet = 0; for (const [dx, dz] of pts) for (const dy of [0, 1]) { try { const b = ow.getBlock({ x: Math.floor(cx + dx), y: y + dy, z: Math.floor(cz + dz) }); if (!b) return null; if (b.isLiquid || /water/.test(b.typeId)) wet++; } catch { return null; } } return wet; }
// 水を ぬいて まわりに 低い 防波堤（町など 作りなおせない 場所）
function drainCmds(cx, y, cz, r) { cx = Math.floor(cx); cz = Math.floor(cz); const C = []; for (let x = cx - r; x < cx + r; x += 16) for (let z = cz - r; z < cz + r; z += 16) { const x2 = Math.min(cx + r - 1, x + 15), z2 = Math.min(cz + r - 1, z + 15); C.push(`fill ${x} ${y} ${z} ${x2} ${y + 12} ${z2} air replace water`); C.push(`fill ${x} ${y} ${z} ${x2} ${y + 12} ${z2} air replace flowing_water`); }
  for (const [a, b, c, d] of [[cx - r - 1, cz - r - 1, cx + r, cz - r - 1], [cx - r - 1, cz + r, cx + r, cz + r], [cx - r - 1, cz - r - 1, cx - r - 1, cz + r], [cx + r, cz - r - 1, cx + r, cz + r]]) { C.push(`fill ${a} ${y - 1} ${b} ${c} ${y + 2} ${d} stone_bricks replace water`); C.push(`fill ${a} ${y - 1} ${b} ${c} ${y + 2} ${d} stone_bricks replace flowing_water`); }
  return C; }
function preTargets(maxR) {
  const out = [];
  for (let i = 0; i <= maxR; i++) {
    const ci = castleInfo(i);
    if (ci && ci.built && ci.v !== CITY_V) { const c = castleSpot(i); out.push({ key: `castle${i}`, x: c.x, z: c.z, go: (ow) => { if (castleInfo(i)?.v === CITY_V) return true; makeCastle(i, ow, c, Math.floor(ci.y), true); return true; } }); }   /* 第106版: 都に 建てかえ */
    else if (!ci || !ci.built) { const c = castleSpot(i); out.push({ key: `castle${i}`, x: c.x, z: c.z, go: (ow) => { if (castleInfo(i)?.built) return true; const y = dryY(ow, c.x, c.z, spotY(ow, c.x, c.z, 16), 27); if (y === null) return false; makeCastle(i, ow, c, y, true); return true; } }); }
    else if (!ci.chkw && !PRE.checked.has(`castlew${i}`)) out.push({ key: `castlew${i}`, x: ci.x, z: ci.z, check: true, go: (ow) => {
      // v2.9.12: 水びたしの 城を 直す（水より 低く できた 城は 水の 上に 作りなおす・そうで なければ 水を ぬく）
      PRE.checked.add(`castlew${i}`);
      let wet = 0, seen = 0;
      for (const [dx, dz] of [[0, 4], [0, 14], [-10, 8], [10, 8], [-14, -6], [14, -6], [0, -10]]) for (const dy of [0, 1]) { try { const b = ow.getBlock({ x: Math.floor(ci.x + dx), y: ci.y + dy, z: Math.floor(ci.z + dz) }); if (!b) { PRE.checked.delete(`castlew${i}`); return false; } seen++; if (b.isLiquid || /water/.test(b.typeId)) wet++; } catch { PRE.checked.delete(`castlew${i}`); return false; } }
      if (wet < 2) { setCastle(i, { ...castleInfo(i), chkw: 1 }); return true; }
      const c = castleSpot(i), y = dryY(ow, c.x, c.z, spotY(ow, c.x, c.z, 16), 27);
      if (y !== null && y > ci.y) {
        try { for (const tg of [`mrpg_castle${i}`, ...(WREGIONS[i].rm >= 0 ? [`mrpg_rm${WREGIONS[i].rm}`] : [])]) for (const e of ow.getEntities({ type: "mrpg:npc", tags: [tg] })) e.remove(); } catch {}
        makeCastle(i, ow, c, y, true); return true;
      }
      for (const [z1, z2] of [[-25, -9], [-8, 8], [9, 25]]) { try { ow.runCommand(`fill ${Math.floor(ci.x) - 25} ${ci.y} ${Math.floor(ci.z) + z1} ${Math.floor(ci.x) + 25} ${ci.y + 12} ${Math.floor(ci.z) + z2} air replace water`); } catch {} }
      try { ow.runCommand(`fill ${Math.floor(ci.x) - 1} ${ci.y} ${Math.floor(ci.z) + 7} ${Math.floor(ci.x) + 1} ${ci.y} ${Math.floor(ci.z) + 9} water`); } catch {}   /* 中庭の 噴水は もどす */
      setCastle(i, { ...castleInfo(i), chkw: 1 }); return true;
    } });
    else if (!ci.chk && !PRE.checked.has(`castle${i}`)) out.push({ key: `castle${i}`, x: ci.x, z: ci.z, check: true, go: (ow) => {
      PRE.checked.add(`castle${i}`);
      const bu = buried(ow, ci, [[-12, 12], [12, 12], [-16, 6], [16, 6], [0, 17]]); if (bu === null) { PRE.checked.delete(`castle${i}`); return false; }
      if (!bu) { setCastle(i, { ...ci, chk: 1 }); return true; }
      const c = castleSpot(i), y = dryY(ow, c.x, c.z, spotY(ow, c.x, c.z, 16), 27); if (y === null || y <= ci.y + 10) return true;
      try { for (const tg of [`mrpg_castle${i}`, ...(WREGIONS[i].rm >= 0 ? [`mrpg_rm${WREGIONS[i].rm}`] : [])]) for (const e of ow.getEntities({ type: "mrpg:npc", tags: [tg] })) e.remove(); } catch {}   // 地方マスターも 新しい 城へ
      makeCastle(i, ow, c, y, true); return true;
    } });
    for (const L of landSites(i)) {
      const li = landInfo(L.key); if (li && li.skip) continue;
      if (!li || (!li.built && !LAND_Q.has(L.key))) out.push({ key: L.key, x: L.x, z: L.z, go: (ow) => {
        const l2 = landInfo(L.key); if (l2 && (l2.built || l2.skip)) return true;
        const s0 = world.getDefaultSpawnLocation();
        if (TOWNS.some((t) => Math.hypot(s0.x + t.dx - L.x, s0.z + t.dz - L.z) < 70)) { world.setDynamicProperty(L.key, JSON.stringify({ skip: true })); return true; }
        const y = dryY(ow, L.x, L.z, spotY(ow, L.x, L.z, 12), 26); if (y === null) return false; makeLand(L, ow, y); return true; } });
      else if (li.built && !li.chkw && !PRE.checked.has(L.key + "w")) out.push({ key: L.key + "w", x: L.x, z: L.z, check: true, go: (ow) => {
        PRE.checked.add(L.key + "w");
        if (li.tv || DG_THEMES[li.theme]?.water || DG_THEMES[L.theme]?.water) { world.setDynamicProperty(L.key, JSON.stringify({ ...landInfo(L.key), chkw: 1 })); return true; }   /* v2.9.12: 海の ステージは わざと 水が ある */
        const w = wetAt(ow, L.x, li.y, L.z, [[0, 0], [10, 0], [-10, 0], [0, 10], [0, -10], [14, 14], [-14, -14]]); if (w === null) { PRE.checked.delete(L.key + "w"); return false; }
        if (w < 2) { world.setDynamicProperty(L.key, JSON.stringify({ ...landInfo(L.key), chkw: 1 })); return true; }
        const y = dryY(ow, L.x, L.z, spotY(ow, L.x, L.z, 12), 26); if (y === null) return false;
        if (y > li.y) { makeLand(L, ow, y, true); return true; }   // v2.9.12: 水びたしの ステージは 水の 上に 作りなおす
        enqueue(ow, drainCmds(L.x, li.y + 1, L.z, 28), () => { try { world.setDynamicProperty(L.key, JSON.stringify({ ...landInfo(L.key), chkw: 1 })); } catch {} }, [{ x: L.x - 30, y: li.y - 2, z: L.z - 30 }, { x: L.x + 30, y: li.y + 14, z: L.z + 30 }]);
        return true; } });
      else if (li.built && !li.chk && !PRE.checked.has(L.key)) out.push({ key: L.key, x: L.x, z: L.z, check: true, go: (ow) => {
        PRE.checked.add(L.key);
        if (li.tv) { world.setDynamicProperty(L.key, JSON.stringify({ ...li, chk: 1 })); return true; }   /* 第124版(tr): 山の ある 地形は「埋まった」と まちがえない */
        const bu = buried(ow, li, [[12, 0], [-12, 0], [0, 12], [0, -12], [8, 8]]); if (bu === null) { PRE.checked.delete(L.key); return false; }
        if (!bu) { world.setDynamicProperty(L.key, JSON.stringify({ ...li, chk: 1 })); return true; }
        const y = dryY(ow, L.x, L.z, spotY(ow, L.x, L.z, 12), 26); if (y === null || y <= li.y + 10) return true;
        makeLand(L, ow, y); return true; } });
    }
    if (DG_ALL.includes(i)) { const v = caveInfo(i); if (!v || !v.built) { const c = caveSite(i); out.push({ key: c.key, x: c.x, z: c.z + 40, go: (ow) => { if (caveInfo(i)?.built) return true; const y = dryY(ow, c.x, c.z, spotY(ow, c.x, c.z, 4), 12); if (y === null) return false; return makeCave(i, ow, y) !== false; } }); }
      else if (v.cv !== CAVE_V && !CVB.has(i) && world.getAllPlayers().some((p) => Math.hypot(p.location.x - v.x, p.location.z - v.z) < 160)) out.push({ key: `mrpg:cave:${i}v`, x: v.x, z: v.z + 40, go: (ow) => {   /* 第128版: 前の 版の せまい 洞くつを 近づいた ときに 1回だけ 作りなおす */
        const o = caveInfo(i); if (!o || !o.built || o.cv === CAVE_V) return true;
        if (world.getAllPlayers().some((p) => busy.has(p.id) && Math.hypot(p.location.x - o.x, p.location.z - o.z) < 160)) return false;   /* 物語や 戦いの とちゅうは 待つ */
        makeCave(i, ow, null, o); return true; } }); }
  }
  // 行ける 地方の 町も
  const s0 = world.getDefaultSpawnLocation();
  for (const t of TOWNS) { const info = getTown(t.id);
    if (info && info.built && !info.chkw && !PRE.checked.has(`townw${t.id}`)) { const pos0 = townPos(t); if (regionIdx(pos0.x - s0.x, pos0.z - s0.z) <= maxR - 1) out.push({ key: `townw${t.id}`, x: info.x, z: info.z, check: true, go: (ow) => {
      PRE.checked.add(`townw${t.id}`);
      const w = wetAt(ow, info.x, info.y, info.z, [[0, 0], [12, 0], [-12, 0], [0, 12], [0, -12], [24, 24], [-24, -24], [24, -24], [-24, 24]]); if (w === null) { PRE.checked.delete(`townw${t.id}`); return false; }
      if (w >= 2) enqueue(ow, [...drainCmds(info.x, info.y, info.z, 52), `fill ${Math.floor(info.x) - 2} ${info.y} ${Math.floor(info.z) - 2} ${Math.floor(info.x) + 2} ${info.y} ${Math.floor(info.z) + 2} water`], () => {},   /* 広場の 噴水は もどす */ [{ x: info.x - 54, y: info.y - 2, z: info.z - 54 }, { x: info.x + 54, y: info.y + 14, z: info.z + 54 }]);   // v2.9.12: 水びたしの 町は 水を ぬいて 防波堤
      setTown(t.id, { ...getTown(t.id), chkw: 1 }); return true; } }); }
    if (info && info.built && info.v !== CITY_V) { out.push({ key: `town${t.id}`, x: info.x, z: info.z, go: (ow) => { if (getTown(t.id)?.v === CITY_V || TBUILD.has(t.id) || TJOB) return true; buildTown(t, ow, info.x, info.y, info.z, () => setTown(t.id, { ...getTown(t.id), built: true, ms: true, lib: true, fish: true, v: CITY_V })); return true; } }); continue; }
    if (info && info.built) continue; const pos = townPos(t); if (regionIdx(pos.x - s0.x, pos.z - s0.z) > maxR - 1) continue;
    out.push({ key: `town${t.id}`, x: pos.x, z: pos.z, go: (ow) => { if (getTown(t.id)?.built || TBUILD.has(t.id) || TJOB) return true; const y = dryY(ow, pos.x, pos.z, spotY(ow, pos.x, pos.z, 14), 40); if (y === null) return false;
      setTown(t.id, { x: Math.floor(pos.x) + 0.5, y, z: Math.floor(pos.z) + 0.5, built: false });
      buildTown(t, ow, pos.x, y, pos.z, () => setTown(t.id, { x: Math.floor(pos.x) + 0.5, y, z: Math.floor(pos.z) + 0.5, built: true, ms: true, lib: true, fish: true, v: CITY_V })); return true; } }); }
  return out;
}
system.runInterval(() => {
  if (warming()) return;
  const ow = world.getDimension("overworld");
  const J = PRE.job;
  if (J) {
    J.wait += building() ? 0.1 : 1;   /* 第99版: ほかの 建物を 作って いる 間は ほとんど 数えない（待つだけで あきらめない） */
    let loaded = true;
    for (const [dx, dz] of [[0, 0], [16, 16], [-16, -16], [16, -16], [-16, 16]]) { try { if (!ow.getBlock({ x: J.x + dx, y: 0, z: J.z + dz })) loaded = false; } catch { loaded = false; } }
    const freeArea = (() => { try { return boxFree({ dim: "minecraft:overworld", x1: Math.floor(J.x) - 60, x2: Math.floor(J.x) + 60, z1: Math.floor(J.z) - 60, z2: Math.floor(J.z) + 60, y1: -64, y2: 320 }); } catch { return true; } })();   // v2.9.13: ほかの 人の 戦いの 場所では 作業しない
    if (loaded && !building() && freeArea) {
      let ok2 = false; try { ok2 = J.go(ow); } catch (e) { console.warn(`[MonsterRPG] prebuild ${J.key}: ${e}`); }
      if (!ok2) PRE.fail.set(J.key, Date.now());
      run(ow, "tickingarea remove mrpg_pre"); PRE.job = null;
    } else if (J.wait > 45) { PRE.fail.set(J.key, Date.now()); run(ow, "tickingarea remove mrpg_pre"); PRE.job = null; }
    return;
  }
  if (building()) return;
  const players = world.getAllPlayers();
  if (!players.length) return;
  let maxR = 1;
  for (const p of players) { try { const d = load(p); if (d && hooks.openUpTo) maxR = Math.max(maxR, hooks.openUpTo(d) + 1); } catch {} }
  maxR = Math.min(WREGIONS.length - 1, maxR);
  const T = preTargets(maxR).find((t) => Date.now() - (PRE.fail.get(t.key) || 0) > 300000);
  if (!T) return;
  PRE.job = { ...T, wait: 0 };
  run(ow, `tickingarea add circle ${Math.floor(T.x)} 64 ${Math.floor(T.z)} 4 mrpg_pre`);
}, 40);

// v2.9.13: 前回 とちゅうで 終わった 作業の 読みこみ範囲を 消す／「開くときに 先に 読みこむ」を 外す（ワールドを 開くのが 遅くなる 原因）
system.runTimeout(() => {
  const ow = world.getDimension("overworld");
  if (!PRE.job) for (let k = 0; k < 3; k++) run(ow, "tickingarea remove mrpg_pre");
  if (!queue.length || !queue[0].started) for (let k = 0; k < 3; k++) run(ow, "tickingarea remove mrpg_build");
  run(ow, "tickingarea remove mrpg_rdet"); run(ow, "tickingarea remove mrpg_cbp"); run(ow, "tickingarea remove mrpg_sky"); run(ow, "tickingarea remove mrpg_void");   /* 第77版: 滅びた 世界を しらべる 途中で 閉じた とき */
  for (const n of ["mrpg_sky", "mrpg_void"]) run(ow, `tickingarea preload ${n} false`);
}, 5);
// v2.9.3: 掘り進む ライドは 町・家の 近くでは 掘らない
hooks.noDig = (loc, dim) => { try { if (dim && inLiveBox(dim.id, loc)) return true; if (dim && dim.id !== "minecraft:overworld") return false; if (townAt(loc, 70) || castlesNear(loc, 80)) return true; for (const i of DG_ALL) { const v = caveInfo(i); if (v && v.built && (Math.hypot(loc.x - v.x, loc.z - v.z) < 40 || (v.hall && Math.hypot(loc.x - v.hall.x, loc.z - v.hall.z) < 30) || (() => { const b = caveBox(i); return loc.x >= b.x1 && loc.x <= b.x2 && loc.z >= b.z1 && loc.z <= b.z2; })())) return true; } /* v2.9.12: 階段と 地下の 広間も */ const h = homeInfo(); if (h && h.built && Math.hypot(loc.x - h.x, loc.z - h.z) < 40) return true; } catch {} return false; };
// v2.9: NPCが 床に 埋まらないように（足もとか 頭が ブロックの 中なら 上へ もどす）
const PASS_ID = new Set(["air", "short_grass", "tall_grass", "grass", "fern", "large_fern", "deadbush", "dead_bush", "snow_layer", "torch", "soul_torch", "lantern", "soul_lantern", "vine", "glow_lichen",
  "red_mushroom", "brown_mushroom", "crimson_roots", "warped_roots", "crimson_fungus", "warped_fungus", "hanging_roots", "lily_pad", "sugar_cane", "sweet_berry_bush", "seagrass", "kelp", "light_block", "structure_void",
  "poppy", "dandelion", "cornflower", "oxeye_daisy", "azure_bluet", "allium", "blue_orchid", "lily_of_the_valley", "wither_rose", "pink_petals", "red_flower", "yellow_flower", "rail", "ladder", "scaffolding", "redstone_wire"]);
const PASS_RE = /(_carpet|_tulip|_sapling|_button|_pressure_plate|_sign|_banner|_torch|_rail)$/;
const solidAt = (dim, x, y, z) => { try { const b = dim.getBlock({ x, y, z }); if (!b || b.isAir || b.isLiquid) return false; const id = b.typeId.replace("minecraft:", ""); return !(PASS_ID.has(id) || PASS_RE.test(id)); } catch { return false; } };
// v2.9.12: NPCの 仕事を 決める（プロパティが 初期値（案内人）に もどって いても 記録・名前から 直す）
export function npcJob(e) {
  try { const v = e.getDynamicProperty("mrpg:jobd"); if (typeof v === "number") return v; } catch {}
  let pj; try { pj = e.getProperty("mrpg:job"); } catch {}
  if (typeof pj === "number" && pj !== 7) return pj;
  try {
    const mi = e.getDynamicProperty("mrpg:master"); if (typeof mi === "string") { const t = JSON.parse(mi).tier; if (typeof t === "number") return Math.min(10, 8 + t); }
    const nm = String(e.nameTag || "").replace(/§./g, "").trim();
    if (/衛兵/.test(nm)) return 16;
    if (/の 王$|^王$/.test(nm)) return 15;
    const j = JOBS.indexOf(nm); if (j >= 0) return j;
  } catch {}
  return typeof pj === "number" ? pj : 7;
}
function fixNpcJob(e) {
  const j = npcJob(e);
  try { if (e.getProperty("mrpg:job") !== j) e.setProperty("mrpg:job", j); } catch {}
  try { if (e.getDynamicProperty("mrpg:jobd") !== j) e.setDynamicProperty("mrpg:jobd", j); } catch {}
}
export function unstuckNpc(e) {
  try { if (e.hasTag("mrpg_patron") || e.hasTag("mrpg_walker")) return false; } catch {}   /* 第109版: 椅子に 座る 人は そのまま */
  try {
    const l = e.location, x = Math.floor(l.x), z = Math.floor(l.z); let y = Math.floor(l.y + 0.05);
    if (!solidAt(e.dimension, x, y, z) && !solidAt(e.dimension, x, y + 1, z)) return false;
    for (let k = 1; k <= 5; k++) if (!solidAt(e.dimension, x, y + k, z) && !solidAt(e.dimension, x, y + k + 1, z) && solidAt(e.dimension, x, y + k - 1, z)) { e.teleport({ x: l.x, y: y + k, z: l.z }); return true; }
  } catch {}
  return false;
}
system.runInterval(() => {
  const seen = new Set();
  for (const p of world.getAllPlayers()) {
    let L = []; try { L = p.dimension.getEntities({ type: "mrpg:npc", location: p.location, maxDistance: 48 }); } catch {}
    const spots = [];
    for (const e of L) {
      if (seen.has(e.id)) continue; seen.add(e.id); if (e.hasTag("mrpg_walker")) continue; unstuckNpc(e); fixNpcJob(e);
      // v2.9.12: 前の 版で 同じ 場所に 重なった NPCは すこし ずらす（話しかけられない ことが ある）
      try { const l = e.location; const tw = (x) => { try { const o = x.getDynamicProperty("mrpg:town") ?? x.getTags().find((g) => /^mrpg_castle\d/.test(g)); return o ? `${o}:${npcJob(x)}` : null; } catch { return null; } };
      const k = tw(e), dup = k && spots.find((q) => q.k === k && Math.hypot(q.x - l.x, q.z - l.z) < 3 && Math.abs(q.y - l.y) < 2);   /* 同じ 町・同じ 仕事の 人が 重なって いたら 1人に */
      if (dup && !e.getDynamicProperty("mrpg:saga") && !e.hasTag("mrpg_xnpc") && !e.hasTag("mrpg_master") && !globalThis.__mqScene?.has(p.id)) { e.remove(); continue; }   /* 第127版(RV3): 物語の 場面中は 目の 前で 消さない（終わってから）*/
      if (spots.some((q) => Math.abs(q.x - l.x) < 0.7 && Math.abs(q.z - l.z) < 0.7 && Math.abs(q.y - l.y) < 1.5) && !e.getDynamicProperty("mrpg:saga")) { e.teleport({ x: l.x - 2, y: l.y, z: l.z }); system.runTimeout(() => unstuckNpc(e), 2); } else spots.push({ x: l.x, y: l.y, z: l.z, k }); } catch {}
    }
  }
}, 100);

// ================= v2.9.12: 地名に あわせた 地面（町・城・ステージの まわりを その 地方らしく ぬりかえる） =================
// 建物の 外側の 輪（建物は さわらない）だけを、地表の 近くの 土・草だけ 入れかえる。海・空・森・はじまりの 地方は そのまま
const SKIN = {
  desert: { r: [["grass_block", "sand"], ["dirt", "sandstone"], ["podzol", "sand"], ["coarse_dirt", "sand"], ["mud", "sand"], ["short_grass", "deadbush"], ["tallgrass", "deadbush"], ["tall_grass", "air"], ["fern", "deadbush"], ["large_fern", "air"]] },
  castle: { r: [["grass_block", "coarse_dirt"], ["podzol", "coarse_dirt"], ["short_grass", "deadbush"], ["tallgrass", "deadbush"], ["tall_grass", "air"], ["fern", "air"], ["large_fern", "air"]] },
  volcano: { r: [["grass_block", "blackstone"], ["dirt", "basalt"], ["podzol", "blackstone"], ["coarse_dirt", "magma"], ["sand", "red_sand"], ["short_grass", "air"], ["tallgrass", "air"], ["tall_grass", "air"], ["fern", "air"], ["large_fern", "air"]] },
  crystal: { r: [["grass_block", "calcite"], ["dirt", "tuff"], ["podzol", "calcite"], ["coarse_dirt", "smooth_basalt"], ["short_grass", "air"], ["tallgrass", "air"], ["tall_grass", "air"], ["fern", "air"], ["large_fern", "air"]] },
  dark: { r: [["grass_block", "soul_soil"], ["dirt", "soul_soil"], ["podzol", "soul_soil"], ["coarse_dirt", "deepslate"], ["sand", "soul_sand"], ["short_grass", "air"], ["tallgrass", "air"], ["tall_grass", "air"], ["fern", "air"], ["large_fern", "air"]] },
  snow: { r: [["grass_block", "snow"], ["podzol", "snow"], ["coarse_dirt", "packed_ice"], ["short_grass", "snow_layer"], ["tallgrass", "snow_layer"], ["tall_grass", "air"], ["fern", "snow_layer"], ["large_fern", "air"]] },
  /* 第125版: 海の 地方（港町・岬・入り江の まわり）は 砂浜と 砂利の 浜。草と 花は 消す */
  port: { r: [["short_grass", "air"], ["tallgrass", "air"], ["tall_grass", "air"], ["fern", "air"], ["poppy", "air"], ["dandelion", "air"], ["grass_block", "sand"], ["dirt", "sandstone"], ["podzol", "sand"], ["coarse_dirt", "gravel"]] },
};
const SKIN_KEY = "mrpg:skinned";
const skinned = () => { try { return new Set(JSON.parse(world.getDynamicProperty(SKIN_KEY) || "[]")); } catch { return new Set(); } };
function markSkin(k) { const s = skinned(); s.add(k); try { world.setDynamicProperty(SKIN_KEY, JSON.stringify([...s].slice(-300))); } catch {} }
export function skinCmds(style, cx, cy, cz, inner, outer, keep = []) {
  const S = SKIN[style]; if (!S) return [];
  cx = Math.floor(cx); cz = Math.floor(cz); cy = Math.floor(cy);
  const C = [], T = 16, y1 = cy - 8, y2 = cy + 16;
  // v2.9.12: 建物の 四角を のぞいた 輪（北・南・西・東の 4つの 帯）を 16×16 いかに 切って ぬりかえる
  const strips = [[cx - outer, cz - outer, cx + outer - 1, cz - inner - 1], [cx - outer, cz + inner + 1, cx + outer - 1, cz + outer - 1],
    [cx - outer, cz - inner, cx - inner - 1, cz + inner], [cx + inner + 1, cz - inner, cx + outer - 1, cz + inner]];
  for (const [ax, az, bx, bz] of strips) {
    if (bx < ax || bz < az) continue;
    for (let x = ax; x <= bx; x += T) for (let z = az; z <= bz; z += T) {
      const x2 = Math.min(bx, x + T - 1), z2 = Math.min(bz, z + T - 1);
      if (keep.some(([a, b, c, d]) => x2 >= a && x <= c && z2 >= b && z <= d)) continue;   // ほかの 建物・ステージ・洞くつ
      for (const [from, to] of S.r) C.push(`fill ${x} ${y1} ${z} ${x2} ${y2} ${z2} ${to} replace ${from}`);
    }
  }
  return C;
}
const SKIN_FAIL = new Map();
// v2.9.12: ほかの 建物・ステージ・洞くつの 四角（その 16×16は ぬりかえない）
function skinKeepOut() {
  const K = [];
  try {
    for (let i = 0; i < WREGIONS.length; i++) {
      const ci = castleInfo(i); if (ci && ci.built) K.push([ci.x - 74, ci.z - 74, ci.x + 74, ci.z + 74]);   /* 城下町（半径72）ごと */
      for (const S of landSites(i)) { const li = landInfo(S.key); if (li && li.built) K.push([li.x - 30, li.z - 30, li.x + 30, li.z + 30]); }
      if (DG_ALL.includes(i) && caveInfo(i)) { const b = caveBox(i); K.push([b.x1, b.z1 - 2, b.x2, b.z2]); }
    }
    for (const t of TOWNS) { const ti = getTown(t.id); if (ti && ti.built) K.push([ti.x - 54, ti.z - 54, ti.x + 54, ti.z + 54]); }
  } catch {}
  return K;
}
function skinSite(i, key, x, y, z, inner, outer) {
  const R = WREGIONS[i]; if (!R || !SKIN[R.style]) { markSkin(key); return false; }
  if ((SKIN_FAIL.get(key) || 0) > Date.now()) return false;
  const ow = world.getDimension("overworld");
  const box = { dim: "minecraft:overworld", x1: Math.floor(x - outer), x2: Math.floor(x + outer), z1: Math.floor(z - outer), z2: Math.floor(z + outer), y1: Math.floor(y - 8), y2: Math.floor(y + 16) };
  if (!boxFree(box) || !areaLoaded(ow, box)) return false;   /* 戦いの 最中の 場所・読みこまれて いない 場所は あとで */
  const K = skinKeepOut().filter(([a, b, c, d]) => !(Math.abs((a + c) / 2 - x) < 1 && Math.abs((b + d) / 2 - z) < 1));   // 自分の 四角は のぞく
  const C = skinCmds(R.style, x, y, z, inner, outer, K); if (!C.length) { markSkin(key); return false; }
  markSkin(key);
  enqueue(ow, C, () => {}, [{ x: x - outer, y: y - 8, z: z - outer }, { x: x + outer, y: y + 16, z: z + outer }], () => { SKIN_FAIL.set(key, Date.now() + 300000); try { const s = skinned(); s.delete(key); world.setDynamicProperty(SKIN_KEY, JSON.stringify([...s])); } catch {} });
  return true;
}
/* 第126版: 廃都の まわりの 輪（城下 72 の 外〜100）。読みこみが 100チャンクを こえない ように 北・南・西・東の 帯ごとに 流す */
function skinRing(i, key, ci, inner, outer) {
  if ((SKIN_FAIL.get(key) || 0) > Date.now()) return false;
  const x = Math.floor(ci.x), y = Math.floor(ci.y), z = Math.floor(ci.z), ow = world.getDimension("overworld");
  if (!boxFree({ dim: "minecraft:overworld", x1: x - outer, x2: x + outer, z1: z - outer, z2: z + outer, y1: y - 8, y2: y + 16 })) return false;
  const K = skinKeepOut().filter(([a, b, c, d]) => !(Math.abs((a + c) / 2 - ci.x) < 1 && Math.abs((b + d) / 2 - ci.z) < 1));
  const C = skinCmds(WREGIONS[i].style, x, y, z, inner, outer, K); markSkin(key); if (!C.length) return false;
  const G = [[], [], [], []];
  for (const c of C) { const m = c.match(/^fill (-?\d+) \S+ (-?\d+) (-?\d+) \S+ (-?\d+)/); if (!m) continue; const [x1, z1, x2, z2] = m.slice(1, 5).map(Number); G[z2 < z - inner ? 0 : z1 > z + inner ? 1 : x2 < x ? 2 : 3].push(c); }
  const bad = () => { SKIN_FAIL.set(key, Date.now() + 300000); try { const s = skinned(); s.delete(key); world.setDynamicProperty(SKIN_KEY, JSON.stringify([...s])); } catch {} };
  const box = [[x - outer, z - outer, x + outer, z - inner], [x - outer, z + inner, x + outer, z + outer], [x - outer, z - inner, x - inner, z + inner], [x + inner, z - inner, x + outer, z + inner]];
  G.forEach((L, k) => { if (L.length) { const [a, b, c, d] = box[k]; enqueue(ow, L, () => {}, [{ x: a, y: y - 8, z: b }, { x: c, y: y + 16, z: d }], bad); } });
  return true;
}
system.runInterval(() => {
  if (building() || warming()) return;
  const sk = skinned(), ow = world.getDimension("overworld");
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld" || inRuins(p.location)) continue;
    const L = p.location;
    for (let i = 0; i < WREGIONS.length; i++) {
      if (!SKIN[WREGIONS[i].style]) continue;
      const cands = [];
      for (const S of landSites(i)) { const li = landInfo(S.key); if (li && li.built) cands.push([`l${S.key}`, li, 28, 64]); }
      for (const t of TOWNS) { const ti = getTown(t.id); if (!ti || !ti.built) continue; const q = townPos(t); if (regionIdx(q.x - world.getDefaultSpawnLocation().x, q.z - world.getDefaultSpawnLocation().z) !== i) continue; cands.push([`t${t.id}`, ti, 52, 64]); }   /* 読みこみ範囲（100チャンク）に おさまる 大きさ */
      for (const [k, info, inner, outer] of cands) {
        if (sk.has(k) || Math.hypot(info.x - L.x, info.z - L.z) > 80) continue;
        if (skinSite(i, k, info.x, info.y, info.z, inner, outer)) return;   // 1回に 1つ
      }
      if (RUINED(i)) { const ci = castleInfo(i), k = `c${i}r${RUIN_V}`; if (castleCur(i, ci) && ci.rv === RUIN_V && !sk.has(k) && Math.hypot(ci.x - L.x, ci.z - L.z) < 80 && skinRing(i, k, ci, 73, 100)) return; }
    }
  }
}, 100);
export { enqueue, Plan };   /* 第76版: 追加ストーリーの 建物づくりでも 使う */
/* 第124版: 「バグを 直す」: 城・町・ステージの 水びたし・うまりの 点検を もう一度（近づくと 点検して、だめなら 建てなおす）*/
export function recheckSite(kind, id) {
  try {
    if (kind === "castle") { const c = castleInfo(id); if (!c || !c.built) return false; PRE.checked.delete(`castle${id}`); PRE.checked.delete(`castlew${id}`); setCastle(id, { ...c, chk: 0, chkw: 0 }); return true; }
    if (kind === "town") { const t = getTown(id); if (!t || !t.built) return false; PRE.checked.delete(`townw${id}`); setTown(id, { ...t, chkw: 0 }); return true; }
    if (kind === "land") { const l = landInfo(id); if (!l || !l.built) return false; PRE.checked.delete(id); PRE.checked.delete(id + "w"); world.setDynamicProperty(id, JSON.stringify({ ...l, chk: 0, chkw: 0 })); return true; }
  } catch {}
  return false;
}
