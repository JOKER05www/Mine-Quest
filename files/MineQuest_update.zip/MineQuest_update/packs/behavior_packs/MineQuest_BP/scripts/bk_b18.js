/* 第126版 本18「ルミナの門」（アルカトラス地方・ルミナ）— 迫害の 回収 — 作業 ME
   分かる: 大勢で 名を 三度 呼ぶと 影が 退く。ゴンザは 牧場と 子らを 暴徒から 守る ために 門を 閉めて いた。ハクが 人々を かばって 石に なる。
   問い: 影が 降りた 闘技場の 下に、何が あるのか（→本19・20 qb181）。前の 章の 問い qb171 に 答える（b18e1）
   引きとった 古い 話: r10c2（ルミナの 鐘）→ b18e2、r10c3（旅立ちの 道）→ b18e8（collapse.js。鐘まで 走る 追いかけは やめ、鐘は b18e6）
   場所: 南の 入口（b18south: 閉じた 門）／大通り（広場・張り紙の 板）／オルドの 牧場（ハクの 小屋 b18hut）／北の 門（b18north: 門・外の 鐘）*/
import { bkAdd } from "./bkeng.js";
import { castAdd } from "./cast.js";
import { spotOf, ranchSpot } from "./storyplace.js";
import { ok } from "./ui.js";
import { J, MK, setB, sOf, REI, ORDO, NP, HAKU_SP, fade, Yof, afterAdd, fin, again, face, toP, LUM, SOUTH } from "./bk_b17.js";

/* ---------- 場所 ---------- */
const AVE = () => { const q = spotOf("t0", "plaza"), c = LUM(); return q ? { x: Math.floor(q.x), z: Math.floor(q.z) + 6, nm: "ルミナの 大通り" } : c ? { x: Math.floor(c.x), z: Math.floor(c.z) + 18, nm: "ルミナの 大通り" } : null; };
const RANCH = () => { const q = ranchSpot(); return q ? { x: q.x, z: q.z, nm: "オルドの 牧場" } : null; };
const NV = () => J("mrpg:epdeco:b18northat");
const NPT = (n, nm, dz) => () => { const v = NV(), m = v && MK(v, n); if (m) return { x: Math.floor(m.x), z: Math.floor(m.z), nm }; const c = LUM(); return c ? { x: Math.floor(c.x), z: Math.floor(c.z) + dz, nm } : null; };
const NBELL = NPT("bell", "ルミナの 北の 門の 外の 鐘", -52), NIN2 = NPT("inside", "ルミナの 北の 門の 内側", -44), NOUT = NPT("outside", "ルミナの 北の 門の 外", -54);
/* 閉じた 南の 門（石の 柱・柵・上の 板。約 40 ブロック）*/
const southSet = (K, p) => setB(K, p, "b18south", [[4, -3, 0, 4, -3, 3, "stone_bricks"], [4, 3, 0, 4, 3, 3, "stone_bricks"], [4, -3, 4, 4, 3, 4, "spruce_slab"], [4, -2, 0, 4, 2, 1, "spruce_fence"], [4, -3, 2, 4, -3, 2, "lantern"], [4, 3, 2, 4, 3, 2, "lantern"]],
  { D: 1, look: [4, 0], marks: { gonza: [5.5, 0.5, 0], gate: [4, 0, 1], out: [2, 0, 0] } });
/* 北の 門（柱と 上の 板）と 門の 外の 鐘（柱に 吊る）。約 45 ブロック */
const northSet = (K, p) => setB(K, p, "b18north", [[4, -3, 0, 4, -3, 4, "stone_bricks"], [4, 3, 0, 4, 3, 4, "stone_bricks"], [4, -3, 5, 4, 3, 5, "stone_brick_slab"], [9, 3, 0, 9, 3, 2, "cobblestone_wall"], [9, 3, 3, 9, 3, 3, "oak_planks"], [9, 2, 3, 9, 2, 3, "oak_planks"], [9, 2, 2, 9, 2, 2, "bell"], [3, -4, 0, 3, -4, 0, "barrel"], [3, -4, 1, 3, -4, 1, "barrel"]],
  { D: 2, look: [4, 0], marks: { gate: [4, 0, 1.5], inside: [1, 0, 0], bell: [9, 2, 2], outside: [11, -2, 0], cart: [3, -4, 1] } });
/* 大通りの 張り紙の 板 */
const boardSet = (K, p) => setB(K, p, "b18board", [[4, -1, 0, 4, -1, 1, "oak_fence"], [4, 1, 0, 4, 1, 1, "oak_fence"], [4, -1, 2, 4, 1, 2, "oak_planks"], [4, 0, 2, 4, 0, 2, "white_wool"]], { D: 2, look: [4, 0], marks: { board: [4, 0, 2] } });

/* ---------- 町の 人 ---------- */
castAdd("b18heinz", { nm: "ハインツ", role: "パン屋の 親方", gobi: "", skin: "m6_paolo", town: "t0", from: "b18e2", at: () => { const c = LUM(); return c ? { x: c.x + 6, z: c.z + 14 } : null; },
  pre: ["{smile}焼きたてだ。……持って いきな。"],
  after: [[(s) => !!s.ending, ["{smile}足は もう 何とも ない。……名前を 呼ばれた 晩の ことは、ミミが 毎朝 話すんだ。", "{closed}あの 晩の パンが、いちばん うまかった 気が するよ。"]],
    [() => true, ["{closed}……足の 先が、まだ 少し 冷たい。でも、粉は こねられる。"]]] });
afterAdd("gonza", [[(s) => !!(s.epx && s.epx.lbell), ["{smile}門は もう 開いて おるでござる。……槍の 柄は、割れた まま 使って おるでござる。", "{closed}閉めた 門の 内側で、一晩 だれも 通さなかった。……あれは、拙者の いちばんの 自慢でござる。"]]]);
afterAdd("nol", [[(s) => !!(s.epx && s.epx.lbell), ["{closed}あの 鐘は、四十年前に 若い ふたりが 吊ったんじゃよ。……やっと、鳴らすべき 日に 鳴ったんじゃよ。"]]]);
afterAdd("mimi", [[(s) => !!s.ending, ["{smile,up}ベリルちゃんと、毎週 パンを 半分こ してるんだよっ！", "{smile}名前、会う たびに 呼ぶって 決めたんだよっ。"]],
  [(s) => !!(s.epx && s.epx.lbell), ["{smile,tears}お父さん、足が 動くように なったんだよっ。……みんなで 名前を 呼んだからだよっ。"]]]);

/* ---------- 話 ---------- */
const E1 = { id: "b18e1", t: "閉じた 門", place: SOUTH, F: ["F47"], ans: ["qb171"],
  hint: "§fルミナの §e南の 入口§f へ 行こう §7（門が 閉まって いる）",
  syn: "ルミナの 南の 入口の 門は 閉まって いた。門番 ゴンザは 槍を 町の 内側に 向けて、門を 開けなかった。",
  async run(p, d, K) {
    const V = southSet(K, p);
    await K.open(p, "ルミナの 南の 入口", "ash");
    if (V) await K.at(p, MK(V, "gate"), 14, 5, 1.4);
    const eR = REI(K, p);
    const eG = await K.put(p, "gonza", MK(V, "gonza") || K.fwd(p, 6), null); K.act(eG, "guard"); K.hold(eG, "spear");
    if (ok(eG)) K.turn(eG, K.fwd(p, 14));   /* 槍は 町の 内側へ */
    await K.narr(p, ["§7柵で ふさがれた 門の 向こうに、ゴンザが 立って いた。", "§7槍の 穂先は、外では なく……§f町の 内側§7 を 向いて いる。"], eG);   /*F47*/
    face(K, eR, eG);
    await K.say(p, "レイ", ["{angry,!,up}ゴンザ！ 開けろ！ ……なんで 門を 閉めてんだよ！"], eG);
    await K.ots(p, eR, eG, 12);
    K.turn(eG, p.location);
    await K.csay(p, "gonza", ["{sweat,汗}……今は、通せぬでござる。", "{closed}わけは 言えぬ。……言えば、門の 内が 崩れるでござる。"]);
    K.turn(eG, K.fwd(p, 14));
    await K.say(p, "レイ", ["{angry,up}……裏切ったのかよ。町の 門番が、町の 側に 槍を 向けて。"], eG);
    { const g = K.palEnt(p); if (g) await K.up(p, g, 10); await K.pal(p, ["……ゴンザ、こわい においじゃ ない。……なにかを、まもる におい。"]); K.rmCine(g); }
    toP(K, p, eR);
    await K.say(p, "レイ", ["{?}……守る？ ……何をだよ。"]);
    await K.narr(p, ["§7門の 横の 生け垣の すき間から、だれかが 手を 振って いる。……ミミだ。"]);
    K.pay(p, E1, 1000, []);
    await fin(K, p, { bye: [eG], leave: [eR], card: "§7→ 生け垣の すき間から 町へ（そのまま）", kind: "ash" });
    return true;
  } };

const E2 = { id: "b18e2", t: "パン屋の 親方", place: SOUTH,
  hint: "§fルミナの §e南の 入口§f の 生け垣の そばへ §7（ミミが 呼んで いる）",
  syn: "ミミの 父さんが 足から 石に なりかけて いた。ミミが 名を 呼び、あなたは 幼なじみの 旅の 手帳の 頁を 開いて、いっしょに 名を 呼んだ。石は 膝の 下で 止まった。",
  async run(p, d, K) {
    southSet(K, p);
    await K.open(p, "ルミナの 南の 入口", "ash"); K.mood(p, "shadow");
    const eM = K.cast(p, "mimi"); K.act(eM, "hold");
    await K.csay(p, "mimi", ["{cry,!,up}来て くれたっ……！ お父さんが、お父さんが 変なんだよっ……！"]);
    const eF = await K.put(p, "b18heinz", K.fwd(p, 5, 1.5), null); K.act(eF, "kneel");
    for (let i = 0; i < 4 && ok(eF); i++) { K.burst(p.dimension, eF.location, "minecraft:white_smoke_particle", 5, 0.5, 0.2 + i * 0.2); await K.wait(4); }
    await K.low(p, eF, 14);
    await K.narr(p, ["§7親方の 足が、靴の 先から 灰色に 変わって いく。……石に なりかけて いる。"], eF);
    await K.csay(p, "b18heinz", ["{sad,low}……ミミ……はなれて ろ……。", "{closed}……このまま……店を 守れたら……"]);
    await K.csay(p, "mimi", ["{cry,tears,up}だめっ！ 『このまま』なんて 言っちゃ だめだよっ！"], eF);
    await K.narr(p, ["§7あなたは かばんから、あの 子の §f旅の 手帳§7 を 出した。", "§7名前の 頁に、あの 子の 字。§f『パン屋の 親方 ハインツさん（ミミの お父さん。はちみつパン）』"]);
    K.sound(p, "item.book.page_turn", 1);
    await K.csay(p, "mimi", ["{cry,up}いっしょに 呼んでっ……！ せーのっ！"]);   /* 決まり四（強める）*/
    for (let i = 0; i < 3; i++) { await K.narr(p, [`§f「ハインツ${"！".repeat(i + 1)}」`], i % 2 ? eM : eF); K.burst(p.dimension, ok(eF) ? eF.location : p.location, "minecraft:totem_particle", 6, 0.6, 0.6); }
    K.flash(p, true); K.sound(p, "random.levelup", 0.6);
    await K.narr(p, ["§7灰色は、膝の 下で 止まった。……それ以上、のぼって こない。"], eF);
    K.act(eF, "up");
    await K.csay(p, "b18heinz", ["{shock,…,up}……ミミ。……呼んだ、のか。", "{closed}……頭の 中の 声が、遠く なった。"]);
    await K.two(p, eM, eF, 12);
    await K.csay(p, "mimi", ["{cry,smile,tears,up}止まったよっ……！ 名前、届いたんだよっ……！"], eF);
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{shock,…}……名前で、止まった。", "{closed}……ミミ。町は どう なってる。ゴンザは 何を してる。"], eM);
    await K.csay(p, "mimi", ["{sad}大通りの みんな、目が 紫に 光って、張り紙を 持って 歩いてるんだよっ。……北の 門の 方へ。"]);
    K.pay(p, E2, 2000, [["gift_bread", 2]]);
    await fin(K, p, { leave: [eR], bye: [eM, eF], card: "§7→ ルミナの §e大通り§7 へ", kind: "ash" });
    return true;
  } };

const E3 = { id: "b18e3", t: "紫の 目", place: AVE,
  hint: "§fルミナの §e大通り§f へ 行こう §7（町の 人の ようすが おかしい）",
  syn: "大通りの 人々の 目に、紫の 文字が 流れて いた。みんな「石板の 子が 通った 町は 石に なる」の 張り紙を 握って いた。だれも、あなたの 名前を 思い出せなかった。",
  async run(p, d, K) {
    const B = boardSet(K, p);
    await K.open(p, "ルミナの 大通り", "ash"); K.mood(p, "shadow");
    if (B) await K.at(p, MK(B, "board"), 14, 3, 1.2);
    await K.narr(p, ["§7板に、すすけた 張り紙。§f『石板の 子が 通った 町は、石に なる』"], MK(B, "board"));
    const t1 = NP(K, p, "§7大通りの 男", "m6_bram"), t2 = NP(K, p, "§7大通りの 女", "rosa");
    for (const e of [t1, t2]) { K.act(e, "hold"); K.hold(e, "scroll"); }
    if (ok(t1)) { K.burst(p.dimension, t1.location, "minecraft:portal_reverse_particle", 4, 0.3, 1.6); await K.up(p, t1, 12); }
    await K.say(p, "大通りの 男", ["{angry,low}……石板の 子だ。……出て いけ。町が 石に なる。"]);
    const eR = REI(K, p);
    if (ok(eR)) { await K.approach(p, eR, t1, 1.6); K.act(eR, "guard"); }
    await K.say(p, "レイ", ["{angry,up}……おい。こいつの 名前、言って みろ。", "{closed}牧場の 隣で 育った やつだ。ひよっこカップに 出て、毎朝 パンを 買ってた。"], t1);
    await K.say(p, "大通りの 男", ["{sad,…}……名前……。……知って いる はずだ。……出て こない。"]);
    await K.say(p, "大通りの 女", ["{sad,…}……張り紙の 字は、はっきり 読めるのに……"], t1);
    { const g = K.palEnt(p); if (g) { K.sound(p, "mob.wolf.growl", 1.1); await K.up(p, g, 10); } await K.pal(p, ["……めの もじ、ゆれた。なまえ、きこえると ゆれる。"]); K.rmCine(g); }
    await K.say(p, "レイ", ["{?}……名前で ゆれる。……さっきの 親方と 同じだ。"]);
    const eN = K.cast(p, "nol"); K.act(eN, "hold");
    await K.csay(p, "nol", ["{closed}……こっちじゃ。ここに 立って おっても、張り紙が 増える だけじゃよ。", "{sad}牧場へ 来い。オルドが 待っとる。……ピコと ハクもな。"], eR);
    K.pay(p, E3, 1500, []);
    await fin(K, p, { leave: [eN, eR], bye: [t1, t2], card: "§7→ §eオルドの 牧場§7 へ（右上の 案内）", kind: "ash" });
    return true;
  } };

const E4 = { id: "b18e4", t: "柱の 絵", place: RANCH, fac: "b18hut", F: ["F02", "F18"],
  hint: "§f§eオルドの 牧場§f へ 行こう §7（ノルじいが 呼んで いる）",
  syn: "牧場の 小屋で、ピコが ハクの となりに 眠って いた。小屋の 柱には、子どもが 描いた 丸だらけの 絵。オルドは「……昔、ちょっとな」と 言って、北の 門へ 向かった。",
  async run(p, d, K) {
    const H = K.fac(p, "b18hut", "hut", 0, Yof(K, p));
    await K.open(p, "オルドの 牧場", "ash");
    if (H) await K.at(p, H, 14, 9, 3);
    const hk = K.monEnt(p, K.fwd(p, 5, -1.5), HAKU_SP(), "§fハク"), pk = await K.put(p, "§7ピコ", K.fwd(p, 4.5, 0.4), null, 9); K.act(pk, "prone");
    if (hk) await K.up(p, hk, 12);
    await K.narr(p, ["§7小屋の 中。白くて 大きな §fハク§7 の 腹に もたれて、§fピコ§7 が 眠って いた。", "§7小さな 手が、ハクの 毛を 握って いる。"], pk);   /*F18*/
    const eO = ORDO(K, p); K.act(eO, "hold");
    await K.say(p, "オルド", ["{closed}……来たか。ピコは 竜祭りの 夜から、ずっと ここじゃ。ハクが はなれん。"], pk);
    const col = ok(pk) ? { x: pk.location.x, y: pk.location.y + 1.2, z: pk.location.z } : K.fwd(p, 5, 1.2, 1);
    await K.at(p, col, 16, 2.6, 0.6);
    await K.narr(p, ["§7小屋の 柱に、古い 紙。……子どもの 手で 描いた、§f丸、丸、丸§7。紙の すみまで 丸だらけ。"], col);   /*F02*/
    await K.say(p, "レイ", ["{?}……じいちゃん。この 絵、昔から あるよな。なんの 絵だ。"], eO);
    await K.say(p, "オルド", ["{sweat,汗}……ほっほ。……昔、ちょっとな。"]);
    await K.up(p, eO, 10);
    await K.say(p, "オルド", ["{closed}今は 北の 門じゃ。影が 波に なって 寄せて きとる。", "{angry,up}ハク。……行くぞ。"]);
    K.act(eO, 0);
    if (hk) { K.sound(p, "mob.wolf.bark", 0.8); await K.up(p, hk, 10); }
    await K.pal(p, ["……ハク、ピコの においを、おいて いきたく ないって。"]);
    face(K, eO, hk);
    await K.say(p, "オルド", ["{sad,…}……わかっとる。すぐ 戻る。"], hk);
    K.pay(p, E4, 2000, [["fd_milk", 2]]);
    await fin(K, p, { leave: [eO], bye: [hk, pk], card: "§7→ ルミナの §e北の 門§7 へ（右上の 案内）", kind: "ash" });
    return true;
  } };

const E5 = { id: "b18e5", t: "白い 盾", place: NOUT, battles: 1,   /* 戦いは 門の 外 */
  hint: "§fルミナの §e北の 門の 外§f へ 行こう §7（影の 波が 寄せて いる）",
  syn: "北の 門に 影の 波が 寄せた。ハクが 前に 出て 人々を かばい、白い 体は 足もとから 石に なった。",
  async run(p, d, K) {
    const V = northSet(K, p);
    await K.open(p, "ルミナの 北の 門の 外", "ash"); K.mood(p, "shadow");
    if (V) await K.at(p, MK(V, "gate"), 12, 6, 2);
    let eO = ORDO(K, p), eR = REI(K, p);
    let c1 = NP(K, p, "§7逃げて きた 子", "taro", false, 9), c2 = NP(K, p, "§7逃げて きた 母さん", "rosa");
    await K.shadowFlow(p, K.fwd(p, 14, 0), K.fwd(p, 5, 0), 14);
    K.act(eO, "point");
    await K.say(p, "オルド", ["{angry,up}……来るぞ！ 門の 前を 空けい！"]);
    await K.say(p, "レイ", ["{angry,up}じいちゃん、下がってろ！ ……おまえ、行くぞ！"]);
    const r = await K.battle(p, K.team(["nether", "nether", "dragon"], 86, 3, 40), { name: "影の 波", arena: "ルミナの 北の 門", theme: "underworld", speaker: "影", guests: K.team(["beast"], 82, 1).map((t) => ({ ...t, owner: "レイ" })), lines: { half: "……イシニ……ナレ……", low: "……ナマエ……キライ……" } });
    if (r !== "win") { await K.say(p, "オルド", ["{angry}……引け！ 門の 内へ！"]); return false; }
    eO = again(K, p, eO, "§eオルド", K.PJ("ordo", 8)); eR = again(K, p, eR, "§bレイ", 17); c1 = again(K, p, c1, "§7逃げて きた 子", K.PJ("taro", 9)); c2 = again(K, p, c2, "§7逃げて きた 母さん", K.PJ("rosa", 8));
    await K.narr(p, ["§7影の 波は 一度 引いた。……そして、もう 一度、いちばん 大きく 寄せた。"]);
    const hk = K.monEnt(p, K.fwd(p, 4, -1), "" + HAKU_SP(), "§fハク");
    await K.shadowFlow(p, K.fwd(p, 14, 0), ok(c1) ? c1.location : K.fwd(p, 3), 12);
    if (hk) { K.sound(p, "mob.wolf.bark", 1); await K.up(p, hk, 10); }
    await K.narr(p, ["§fハク§7 が 子と 母親の 前に 出た。大きな 白い 体を、壁の ように 広げて。"], hk);
    for (let i = 0; i < 6 && hk; i++) { K.burst(p.dimension, hk.location, i % 2 ? "minecraft:white_smoke_particle" : "minecraft:basic_smoke_particle", 6, 0.8, i * 0.3); await K.wait(4); }
    K.sound(p, "dig.stone", 0.8); try { if (hk) hk.nameTag = "§7ハクの 石像"; } catch {}
    await K.narr(p, ["§7影が 通り過ぎた あと、ハクは 動かなかった。……足もとから、白い 毛の 先まで、石に なって いた。"], hk);
    K.act(eO, "kneel");
    if (ok(eO) && hk) await K.approach(p, eO, hk, 1.2);
    await K.low(p, eO, 16);
    await K.say(p, "オルド", ["{sad,…,low}……ハク。", "{closed,low}……また、わしを 置いて いく 気か。……二十年前は、わしが おまえを 選んだと いうのに。"]);
    await K.say(p, "レイ", ["{sad,…}……じいちゃん。"], eO);
    if (ok(c1) && hk) K.turn(c1, hk.location);
    await K.say(p, "逃げて きた 子", ["{cry,tears,up}……白い 子が、まもって くれたの。"], hk);
    K.act(eO, 0);
    await K.say(p, "オルド", ["{closed,up}……門の 外の 鐘じゃ。ノルが 知っとる。……鳴らせ。"]);
    K.pay(p, E5, 5000, [["i_awaken", 1]]);
    await fin(K, p, { leave: [eR], bye: [c1, c2, eO, hk], card: "§7→ 北の 門の 外の §e鐘§7 へ（右上の 案内）", kind: "ash" });
    return true;
  } };

const E6 = { id: "b18e6", t: "二人が 吊った 鐘", place: NBELL, F: ["F64"],
  hint: "§fルミナの §e北の 門の 外の 鐘§f へ 行こう §7（ノルじいが 待って いる）",
  syn: "北の 門の 外の 鐘は、四十年前、オルドと 星の 好きな 若者が 吊った もの だった。「名を 呼べん ときは 鳴らせ」。鐘を 鳴らすと、影が 一瞬 止まった。",
  async run(p, d, K) {
    const V = northSet(K, p), bq = MK(V, "bell") || K.fwd(p, 4, 2, 1);
    await K.open(p, "ルミナの 北の 門の 外", "ash");
    await K.at(p, bq, 14, 3.5, 0.6);
    const eN = K.cast(p, "nol"); K.act(eN, "hold");
    await K.csay(p, "nol", ["{closed}……この 鐘はな、四十年前に 二人の 若いのが 吊ったんじゃよ。オルドと、星の 好きな 若いのがな。", "{closed,up}『名を 呼べん ときは、鳴らせ』と 言うてな。"]);   /*F64*/
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{?}……じいちゃんと、もう 一人？ ……だれだよ、その 星の 好きな やつ。"], eN);
    await K.csay(p, "nol", ["{sweat,汗}……名前を 残すのを、いちばん いやがる 男じゃったよ。……さあ、鳴らすんじゃよ。"]);
    await K.narr(p, ["§7あなたは 綱を 握った。"], bq);
    for (let i = 0; i < 3; i++) { K.sound(p, "block.bell.hit", 1 - i * 0.1); K.burst(p.dimension, bq, "minecraft:totem_particle", 10, 1 + i, 1); K.shake(p, 0.2, 0.3); await K.wait(12); }
    K.big(p, "§e§l鐘", "§f鐘の 音が、灰の 空に 広がって いく", "random.levelup");
    const q = K.fwd(p, 12, 0, 2); K.burst(p.dimension, q, "minecraft:portal_reverse_particle", 10, 3, 0);
    await K.pull(p, q, 28);
    await K.narr(p, ["§7寄せて いた 影が、一瞬だけ、ぴたりと 止まった。……そして また、ゆっくり うごめき 始めた。"], q);
    await K.say(p, "レイ", ["{angry}……止まった。でも、引かねえ。", "{closed}鐘だけじゃ 足りねえんだ。"]);
    await K.csay(p, "nol", ["{closed}鐘は、呼べん ときの 代わりじゃよ。……呼べる 者が おるなら、呼ぶ ほうが 強いんじゃよ。", "{sad}……門の 内側で、ゴンザが 一晩じゅう 何を して おったか、見て くるんじゃよ。"], eR);
    K.pay(p, E6, 1500, [["dm_bell", 1]]);
    await fin(K, p, { leave: [eR], bye: [eN], card: "§7→ 北の §e門の 内側§7 へ", kind: "ash" });
    return true;
  } };

const E7 = { id: "b18e7", t: "割れた 柄", place: NIN2, F: ["F47"],
  hint: "§fルミナの §e北の 門の 内側§f へ 行こう §7（ゴンザが いる）",
  syn: "ゴンザは 一晩じゅう、門の 内で 暴徒を 押さえて いた。牧場と、眠る 子らを 守る ために、門を 閉めたのだった。槍の 柄は 割れて いた。",
  async run(p, d, K) {
    const V = northSet(K, p);
    await K.open(p, "ルミナの 北の 門の 内側", "ash");
    const eG = K.cast(p, "gonza"); K.act(eG, "stagger"); K.hold(eG, "spear");
    if (ok(eG)) await K.low(p, eG, 14);
    await K.narr(p, ["§7門の 内側の 石畳に、張り紙が 何十枚も 踏まれて いた。", "§7その まん中に、ゴンザが 座りこんで いた。槍の 柄が、まん中から §f割れて いる§7。"], eG);   /*F47*/
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{?,…}……ゴンザ。……ゆうべ、ここで 何が あった。"], eG);
    await K.csay(p, "gonza", ["{closed}……張り紙を 持った 人たちが、牧場へ 行こうと したでござる。『石板の 子の 家を 焼け』と。", "{sad}牧場には、眠る ピコ殿と、ハク殿が おった。……だから、門を 閉めたでござる。"]);
    if (V) await K.at(p, MK(V, "cart"), 12, 3, 1);
    await K.csay(p, "gonza", ["{closed,up}外の 影から では ない。内の 人から 守る ための 門でござった。", "{sweat,汗}……一晩、だれも 傷つけずに 押し返すのは、ちと 骨が 折れたでござる。……柄が、先に 折れたでござる。"]);
    await K.push(p, eR, 22, 4.2, 1.7);
    await K.say(p, "レイ", ["{sad,…}……裏切ったって 言った。……悪かった。"], eG);
    await K.csay(p, "gonza", ["{smile,up}よいでござる。……門番は、門の 外からは 悪者に 見えるもの でござる。"], eR);
    K.act(eG, 0);
    await K.csay(p, "gonza", ["{closed}門の 外に、人が 集まって おる。……証人の 方々が、回状を 持って 呼んだ 人たちでござる。"]);
    K.pay(p, E7, 2000, [["gift_bread", 2]]);
    await fin(K, p, { leave: [eR], bye: [eG], card: "§7→ 北の §e門の 外§7 へ", kind: "ash" });
    return true;
  } };

/* 各地から 来た 人（選択で 顔ぶれが 変わる）*/
function crowd(K, p) {
  const s = sOf(p), c = (id) => K.chGet(s, id);
  const L = [];
  L.push(c("c03") === "h" ? ["r2dolf", null, ["{closed}……ガレキから 来た。ザジと 弟子どもも 一緒だ。水筒の 礼だと よ。"]] : ["r2dolf", null, ["{smile}ガレキの 坊主が、どうしても 来るって 聞かなくてな。……ほら、元気だろ。"]]);
  L.push(c("c04") === "s" ? ["r3tombo", null, ["{smile,!}ゲン親方と 来たッス！ 鈴を 鳴らしたら、おれたちの 声だと 思って ほしいッス！"]] : ["r3tombo", null, ["{closed,up}おれ だけで 来たッス。……親方は 炉の 番ッス。名前、大声で 呼ぶッス！"]]);
  if (c("c06") === "t") L.push(["r5gantetsu", null, ["{closed}……グロウから 来た。あいつが 帰る 場所は、明るく して ある。……おまえの 帰る 場所もだ。"]]);
  L.push(["r6nagisa", null, [c("c07") === "n" ? "{smile}……包帯の 手でも、手は 振れるの。" : "{smile}……あなたの 相棒の 前足、もう 痛く ない？", "{closed,up}百 数えて 来たの。……あと 三回、呼べば いい。"]]);
  L.push(c("c08") === "y" ? ["r7_yura", null, ["{closed}ヨミの 家の 人たちも 来たのです。……灯籠に 名前を 書いた 人の、名前を 呼びに。"]] : ["r7_yura", null, ["{closed}わたし 一人で 来たのです。……敵の 名を 書いた 人の 名を、呼びに。"]]);
  L.push(["§bダル", "dal", c("c10") === "d" ? ["{closed,up}……ヘイムダルから 来た。預かって いた 石板を 返しに。", "{sad}兄上は 石の まま だが……この 名を 呼ぶ ことは、兄上も 望む はずだ。"] : ["{closed}……ヘイムダルから 来た。兄上は 来ぬ。……だが、わたしは 来た。"]]);
  L.push(["r4celine", null, ["{smile,up}回状の 名前、三百を 超えましたわ。……あなたの 名前を 知る 人の 名前ですのよ。"]]);
  return L;
}
const E8 = { id: "b18e8", t: "三度 呼ぶ", place: NOUT, F: ["F12", "F46"],
  hint: "§fルミナの §e北の 門の 外§f へ 行こう §7（人が 集まって いる）",
  syn: "北の 門の 外に、回状で 集まった 各地の 人々が いた。みんなで あなたの 名前を 三度 呼ぶと、影は 退き、闘技場の 方へ 沈んで いった。",
  async run(p, d, K) {
    northSet(K, p);
    await K.open(p, "ルミナの 北の 門の 外", "ash");
    await K.wide(p, 18);
    await K.narr(p, ["§7門の 外の 道に、たくさんの 人が 立って いた。", "§7手に 手に、名前が びっしり 書かれた §f回状§7 を 持って。"]);   /*F46*/
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{shock,…,up}……なんだ、この 数。……みんな、おまえの 名前を 知ってる 人か。"]);
    let i = 0, prev = [];
    for (const [id, skin, L] of crowd(K, p)) {
      if (i % 3 === 0) { await fade(K, p); await K.bye(p, ...prev); prev = []; }
      const e = skin ? NP(K, p, id, skin) : K.cast(p, id); K.act(e, i % 2 ? "raise" : "hold");
      if (skin) await K.say(p, id.replace(/§./g, ""), L); else await K.csay(p, id, L);
      if (id === "§bダル" && K.chIs(sOf(p), "c10", "d")) { K.hold(e, "box"); await K.give(e, null, "box"); await K.narr(p, ["§7ダルは 鉛の 箱を 開け、預けて いた §d封じた 石板§7 を あなたに 返した。"], e); }
      prev.push(e); i++;
    }
    await fade(K, p); await K.bye(p, ...prev);
    await K.shadowFlow(p, K.fwd(p, 14, 0), K.fwd(p, 6, 0), 14);
    const eM = K.cast(p, "mimi"), eG = K.cast(p, "gonza"); K.act(eM, "hold");
    await K.csay(p, "mimi", ["{angry,tears,up}……来たよっ、影っ！ みんな、せーので 呼ぶよっ！"]);
    await K.narr(p, [`§f「${p.name}！」`], eM);
    await K.narr(p, [`§f「${p.name}！！」`], eG);
    await K.wide(p, 10);
    await K.narr(p, [`§f「${p.name}――！！」`, "§7門の 外の みんなの 声が、三度、あなたの 名前を 呼んだ。"]);   /*F12*/   /* 決まり四（回収）*/
    const q = K.fwd(p, 10, 0, 1); for (let k = 0; k < 4; k++) { K.burst(p.dimension, q, "minecraft:portal_reverse_particle", 10, 3 - k * 0.5, -k * 0.5); await K.wait(5); }
    await K.pull(p, q, 26);
    await K.narr(p, ["§7影が、声に 押される ように 退いた。……地面に しみこむ ように、§e闘技場§7 の 方へ 沈んで いく。"], q);
    await K.say(p, "レイ", ["{shock,…}……沈んだ。……闘技場の、下へ。", "{closed}……名前を 呼ぶ 声は、影を 退かせる。じいちゃんが 闘技場で 毎日 聞いてた あれも、そうなのか。"]);
    await K.csay(p, "gonza", ["{smile,tears,up}……門は、開けて おくでござる。"], eR);
    K.pay(p, E8, 5000, [["gift_bread", 3], ["dm_ink", 2]]);
    await fin(K, p, { leave: [eR], bye: [eM, eG], card: "§7影は 闘技場の 下へ 沈んだ", kind: "ash" });
    return true;
  } };

const E9 = { id: "b18e9", t: "半分この パン", place: NIN2, F: ["F16"], ans: [],   /* 再会は 町の 中（門の 内側）*/
  hint: "§fルミナの §e北の 門の 内側§f へ もどろう §7（ミミが だれかを 見つけた）",
  syn: "門の 外で、ミミと ベリルが 再会した。四年前の 収穫祭で 半分こ した パン。二人は 互いの 本当の 名前を、初めて 聞いた。",
  async run(p, d, K) {
    await K.open(p, "ルミナの 北の 門の 内側", "day");
    const eB = NP(K, p, "§7ベリル", "beryl"); K.act(eB, "hold"); K.hold(eB, "notebook");
    await K.low(p, eB, 12);
    await K.say(p, "ベリル", ["{closed}……わたしも、来たの。回状に、名前を 書いたから。"]);
    const eM = K.cast(p, "mimi"); K.re(eM, "shock", "!");
    await K.push(p, eM, 22, 4.2, 1.7);
    await K.csay(p, "mimi", ["{shock,…,up}……その 台本の 表紙……。四年前の 収穫祭の、袖の 子……？"], eB);
    await K.say(p, "ベリル", ["{shock,…,up}……パンを、半分こ した……。", "{sad}……あのとき、名前、聞かなかった。"], eM);
    await K.csay(p, "mimi", ["{sad,…}……あたしも 聞いて なかったんだよっ。友だちに なろうって 言ったのに。"], eB);
    K.act(eM, "hold"); K.hold(eM, "basket");
    await K.give(eM, eB, "basket");
    await K.two(p, eM, eB, 12);
    await K.narr(p, ["§7ミミは はちみつパンを 二つに 割って、半分を 差し出した。"]);   /*F16*/
    await K.csay(p, "mimi", ["{smile,tears,up}……ミミ、だよっ。パン屋の ミミ。"], eB);
    await K.say(p, "ベリル", ["{smile,tears,up}……ベリル。……一座の、台本係。"], eM);
    K.sound(p, "item.book.page_turn", 1);
    await K.narr(p, ["§7ベリルは 台本を 開き、自分の 名前の 下に 小さく §fミミ§7 と 書いた。"], eB);
    await K.csay(p, "mimi", ["{smile,up}今度は 忘れない ように、会う たびに 名前を 呼ぶんだよっ。……ベリルちゃん！"], eB);
    await K.say(p, "ベリル", ["{smile,tears}……ミミ。"], eM);
    const eR = REI(K, p);
    await K.say(p, "レイ", ["{closed}……闘技場へ 行こう。影が 沈んだ 下に、何か ある。", "{?}じいちゃんは 先に 行った。……受付で、待ってるって。"]);
    K.pay(p, E9, 3000, [["gift_bread", 2]]);
    await fin(K, p, { leave: [eR], bye: [eM, eB], card: "§f― 第18章 ルミナの門 おわり ―\n§7→ ルミナの §e闘技場の 受付§7（右上の 案内）", kind: "day", t: 56 });
    return true;
  } };

bkAdd("b18", [E1, E2, E3, E4, E5, E6, E7, E8, E9]);
