// 第124版: 町の 頼みごと・事件・遊びの お礼（お金の かわりに 喜ばれる 道具）
// 戦いの 強化の 薬・能力の 実・タマゴ・スキル書・スキルの メモ・料理・宝の地図・まれに 特性の秘薬／継承の秘石
// どれも 物語の 進み（rankCap・storyLootOk・タマゴの ranks）を 通した ものだけ
import { ITEMS, EGGS } from "./data.js";
import { giveItem } from "./ui.js";
import { rankCap, storyLootOk, wtCap } from "./quest.js";

const pick = (L) => L[Math.floor(Math.random() * L.length)];
const IDS = Object.keys(ITEMS);
const of = (f) => IDS.filter((id) => { try { return f(ITEMS[id], id); } catch { return false; } });
/* 種類ごとの 候補（読みこみの とき 1回だけ 作る）*/
const POOL = {
  buff: of((it) => it.kind === "bbuff"),
  seed: of((it, id) => it.kind === "seed" && /^s_[a-z]+2?$/.test(id)),
  egg: of((it, id) => it.kind === "egg" && EGGS[id] && (EGGS[id].price || 0) > 0),
  book: of((it) => it.kind === "skillbook" && !it.spec && (it.tier ?? 1) <= 3),
  sp: of((it, id) => it.kind === "sp" && /^g_sp2?$/.test(id)),
  food: of((it, id) => it.kind === "food" || id === "i_tmap" || /^f_exp(1k|3k)?$/.test(id)),
  rare: of((it, id) => id === "i_trpick" || id === "i_inherit"),
};
/* 種類の 重み（rare は まれ）*/
const W = [["buff", 30], ["seed", 18], ["egg", 16], ["book", 12], ["sp", 8], ["food", 13], ["rare", 3]];
export function boonList(cap, k, size = 1) {
  const T = Math.min(3, wtCap(cap) + 1);
  let L = (POOL[k] || []).filter((id) => storyLootOk(ITEMS[id], EGGS[id]?.ranks, cap) && (ITEMS[id].tier ?? 0) <= T);
  if (k === "i_tmap" || k === "food") L = L.filter((id) => id !== "i_tmap" || cap >= 3);
  if (k === "buff") { const hi = L.filter((id) => (ITEMS[id].tier ?? 0) >= T - (size >= 2 ? 0 : 1)); if (hi.length) L = hi; }
  if (k === "seed" && !(size >= 2 && Math.random() < 0.25)) L = L.filter((id) => !/2$/.test(id));
  if (k === "book") { const lo = L.filter((id) => (ITEMS[id].tier ?? 1) <= Math.max(1, T - 1 + (size >= 2 ? 1 : 0))); if (lo.length) L = lo; }
  if (k === "egg") { L = L.sort((a, b) => EGGS[a].price - EGGS[b].price); L = L.slice(0, Math.max(1, Math.ceil(L.length * (0.45 + 0.25 * size)))); }
  return L;
}
/* 1つ わたす。size: 0=小さな お礼 1=ふつう 2=大きな お礼。もどり値は 表示用の 名前 */
export function boon(p, d, size = 1) {
  const cap = d ? rankCap(d) : 2, rw = size >= 2 ? 3 : 1;
  for (let k = 0; k < 6; k++) {
    let tot = 0; for (const [, w] of W) tot += w;
    let r = Math.random() * (tot + (rw - 1) * 3), kind = "rare";
    for (const [n, w] of W) { r -= n === "rare" ? w * rw : w; if (r <= 0) { kind = n; break; } }
    const L = boonList(cap, kind, size); if (!L.length) continue;
    const id = pick(L), n = kind === "buff" && size >= 1 ? 2 : 1;
    try { giveItem(p, `mrpg:${id}`, n); } catch { continue; }
    return `§b${ITEMS[id].name}${n > 1 ? ` ×${n}` : ""}`;
  }
  try { giveItem(p, "mrpg:c_herb2", 2); } catch {}
  return `§b${ITEMS.c_herb2?.name || "いやしの葉"} ×2`;
}
export const __boon = { POOL, W };
