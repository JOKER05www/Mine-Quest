/* 第125版(fac): 物語の 場面に 出て くる 施設（水門・配給所・鉱山の 入口・運び道・祠・舟小屋・小屋・小川・天幕・見晴らし台・焚き火）
   ・ワールドに 1回だけ 建てる。場所は mrpg:epdeco:<key>at（見る 点 x,y,z ＋ 原点 o ＋ 向き f）に 記録し、あとの 場面・ほかの 人も ここを 見る
   ・場所: 舞台の 奥（前へ 7〜22 マス）の 平らで 乾いた 地面。町・城・大地の そば・水・宙には 建てない（見つからなければ 建てない）
   ・形は ローカル座標（a: 奥へ・b: 横・h: 高さ。h=0 は 立つ 高さ）の 箱の 並び。どの 形も 小さい（400 ブロック 前後まで）
   ・状態（水門を 半分 開けて 水を 少し 流す・全部 開ける）は 小さな fill で かえる（mrpg:epdeco:<key>st。下がらない）
     遠くて 読みこまれて いない ときは あとで（だれかが 48マス 以内に 来た とき）かえる */
import { world, system } from "@minecraft/server";
import { groundY, TOWNS, townPos, getTown, castleSpot } from "./structures.js";
import { WREGIONS, landSites } from "./worldmap.js";

const J = (k) => { try { return JSON.parse(world.getDynamicProperty(k) || "null"); } catch { return null; } };
const P_ = (k, v) => { try { world.setDynamicProperty(k, v === undefined ? undefined : JSON.stringify(v)); } catch {} };
/* 記録した 施設の 見る 点（near から R マス 以内の ときだけ）*/
export function facAt(key, near = null, R = 72) {
  const v = J(`mrpg:epdeco:${key}at`); if (!v || typeof v.x !== "number" || typeof v.z !== "number") return null;
  if (near && Number.isFinite(near.x) && Math.hypot(v.x - near.x, v.z - near.z) > R) return null;
  return { x: v.x, y: v.y, z: v.z };
}

/* 施設の 中の 点（網 など）*/
export function facMark(key, n, near = null) { const v = J(`mrpg:epdeco:${key}at`); const m = v && v.m && v.m[n]; if (!m) return null; if (near && Math.hypot(m[0] - near.x, m[2] - near.z) > 72) return null; return { x: m[0], y: m[1], z: m[2] }; }

/* ---------- 地方の 色 ---------- */
const PAL0 = { wall: "stone_bricks", trim: "cracked_stone_bricks", rock: "stone", base: "dirt", ground: "coarse_dirt", bed: "gravel", plank: "spruce_planks", log: "spruce_log", fence: "spruce_fence", slab: "spruce_slab", lamp: "lantern", plant: "short_grass", cloth: "white_wool", cloth2: "red_wool", ore: "raw_iron_block" };
const PAL = {
  village: { wall: "cobblestone", trim: "mossy_cobblestone", plank: "oak_planks", log: "oak_log", fence: "oak_fence", slab: "oak_slab", ground: "grass_block" },
  forest: { wall: "mossy_cobblestone", trim: "mossy_stone_bricks", plank: "oak_planks", log: "oak_log", fence: "oak_fence", slab: "oak_slab", ground: "grass_block", cloth2: "green_wool" },
  castle: { wall: "stone_bricks", trim: "cracked_stone_bricks", bed: "sand", plank: "dark_oak_planks", log: "dark_oak_log", fence: "dark_oak_fence", slab: "dark_oak_slab", plant: "deadbush" },
  volcano: { wall: "polished_blackstone_bricks", trim: "blackstone", rock: "blackstone", base: "basalt", ground: "blackstone", bed: "gravel", plank: "dark_oak_planks", log: "dark_oak_log", fence: "nether_brick_fence", slab: "dark_oak_slab", plant: "air", ore: "raw_iron_block" },
  desert: { wall: "sandstone", trim: "cut_sandstone", rock: "sandstone", base: "sandstone", ground: "sand", bed: "sand", plank: "birch_planks", log: "birch_log", fence: "birch_fence", slab: "birch_slab", plant: "deadbush", cloth2: "orange_wool" },
  crystal: { wall: "calcite", trim: "amethyst_block", rock: "calcite", base: "tuff", ground: "calcite", plank: "spruce_planks", log: "spruce_log", plant: "air", ore: "amethyst_block", lamp: "lantern" },
  port: { wall: "stone_bricks", trim: "prismarine_bricks", plank: "birch_planks", log: "spruce_log", fence: "spruce_fence", slab: "spruce_slab", lamp: "sea_lantern", cloth2: "blue_wool" },
  dark: { wall: "deepslate_bricks", trim: "polished_deepslate", rock: "deepslate", base: "soul_soil", ground: "soul_soil", plank: "dark_oak_planks", log: "dark_oak_log", fence: "dark_oak_fence", slab: "dark_oak_slab", lamp: "soul_lantern", plant: "air", cloth2: "purple_wool" },
  snow: { wall: "stone_bricks", trim: "mossy_stone_bricks", ground: "snow", plank: "spruce_planks", log: "spruce_log", fence: "spruce_fence", slab: "spruce_slab", plant: "air" },
  sky: { wall: "quartz_block", trim: "smooth_quartz", rock: "calcite", plank: "birch_planks", log: "birch_log", fence: "birch_fence", slab: "birch_slab", ground: "grass_block", plant: "air" },
  end: { wall: "end_stone_bricks", trim: "purpur_block", rock: "end_stone", base: "end_stone", ground: "end_stone", plank: "dark_oak_planks", log: "dark_oak_log", fence: "dark_oak_fence", slab: "dark_oak_slab", lamp: "end_rod", plant: "air" },
};
export function palOf(r) { const st = r === 9 ? "end" : (WREGIONS[r] && WREGIONS[r].style) || "village"; return { ...PAL0, ...(PAL[st] || {}), st }; }

/* ---------- 形（ops: ["f", a0,b0,h0, a1,b1,h1, ブロック, モード?] / ["e", a,b,h, エンティティ]）。RA/RB = 奥向き・横向きの レール ---------- */
const F = (a0, b0, h0, a1, b1, h1, bl, m) => ["f", a0, b0, h0, a1, b1, h1, bl, m];
const S1 = (a, b, h, bl) => ["f", a, b, h, a, b, h, bl];
const WCAUL = 'cauldron ["cauldron_liquid"="water","fill_level"=6]';
const HANG = (P) => (P.lamp === "lantern" || P.lamp === "soul_lantern" ? `${P.lamp} ["hanging"=true]` : P.lamp);
const SHAPES = {
  /* 涸れ谷の 水門: 石の 塔 2本・あいだに 木と 鉄の 門（下りて いる）・手前に 乾いた 水路（砂と 枯れ草）・門の 奥は 水 */
  sluice: { D: [19, 21, 17], box: [-9, -4, 7, 4], H: 6, look: [0, 0, 1], build: (P) => [
    F(-8, -2, -3, 6, 2, -1, P.trim), F(-8, -1, -2, 6, 1, -1, "air"), F(-8, -1, -3, 6, 1, -3, P.bed), F(-9, -2, -3, -9, 2, -1, P.trim), F(7, -2, -3, 7, 2, -1, P.trim),
    F(1, -1, -2, 6, 1, -1, "water"),
    F(-1, 2, -3, 0, 3, 5, P.wall), F(-1, -3, -3, 0, -2, 5, P.wall), F(-1, -3, 5, 0, 3, 5, P.wall),
    S1(-1, 3, 6, P.lamp), S1(-1, -3, 6, P.lamp), S1(0, 1, 4, "chain"), S1(0, -1, 4, "chain"), S1(0, 1, 3, "chain"), S1(0, -1, 3, "chain"),
    F(0, -1, -2, 0, 1, 1, P.plank), F(0, -1, 2, 0, 1, 2, "iron_bars"),
    S1(-6, 0, -2, P.plant), S1(-3, 1, -2, P.plant), S1(-7, -1, -2, P.plant),
    F(-8, 3, -1, -2, 3, -1, P.bed), F(-8, -3, -1, -2, -3, -1, P.bed), S1(-7, 3, 0, P.plant), S1(-4, -3, 0, P.plant), S1(-2, 4, 0, P.plant), S1(-6, -4, 0, P.plant),
  ], st: {
    1: (P) => [F(-8, -1, -2, -1, 1, -2, "air", "replace deadbush"), F(0, -1, -2, 0, 1, -1, "air"), F(0, -1, 2, 0, 1, 2, P.plank), F(0, -1, 3, 0, 0, 3, "iron_bars"), F(-3, -1, -2, -1, 1, -2, "water")],   /* 半分 開ける（門が 1段 上がり、手前に 水が 少し）*/
    2: (P) => [F(0, -1, -2, 0, 1, 0, "air"), F(0, -1, 1, 0, 1, 3, P.plank), F(-8, -1, -2, -1, 1, -2, "water")],   /* 全部 開ける（水路に 水）*/
  } },
  /* 水の 配給所: 屋根の ある 屋台・樽・水の 大がま・並ぶ ための 柵の 列 */
  stall: { D: [18, 20, 17], box: [-8, -5, 3, 5], H: 4, look: [0, 0, 1], build: (P) => [
    F(-1, -3, 0, -1, -3, 2, P.log), F(-1, 3, 0, -1, 3, 2, P.log), F(1, -3, 0, 1, -3, 2, P.log), F(1, 3, 0, 1, 3, 2, P.log),
    F(-2, -4, 3, 2, -3, 3, P.cloth), F(-2, -2, 3, 2, -1, 3, P.cloth2), F(-2, 0, 3, 2, 0, 3, P.cloth), F(-2, 1, 3, 2, 2, 3, P.cloth2), F(-2, 3, 3, 2, 4, 3, P.cloth),
    F(-1, -2, 0, -1, 2, 0, P.plank), S1(-1, 0, 0, WCAUL), S1(-1, -2, 1, WCAUL),
    F(1, -2, 0, 1, 2, 0, "barrel"), S1(1, -2, 1, "barrel"), S1(1, 2, 1, "barrel"), S1(0, 0, 2, HANG(P)),
    F(-7, -2, 0, -3, -2, 0, P.fence), F(-7, 2, 0, -3, 2, 0, P.fence), S1(-5, 3, 0, "cauldron"), S1(-6, -3, 0, "cauldron"),
  ] },
  /* 鉱山の 入口: 岩の 小山に 木の 枠・中へ つづく レール・トロッコ・灯り */
  mine: { D: [15, 17, 16], box: [-6, -4, 6, 4], H: 5, look: [0, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 3, P.rock), F(2, -2, 4, 4, 2, 4, P.rock), F(3, -3, 1, 4, -3, 2, P.trim), F(2, 3, 2, 3, 3, 3, P.trim), S1(4, 1, 4, P.ore),
    F(0, -1, 0, 4, 1, 2, "air"), F(0, -2, 0, 0, -2, 3, P.log), F(0, 2, 0, 0, 2, 3, P.log), F(0, -1, 3, 0, 1, 3, P.plank), F(2, -1, 3, 4, 1, 3, P.plank),
    F(-5, 0, 0, 4, 0, 0, "RA"), S1(1, 0, 2, HANG(P)), S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp),
    S1(-2, 2, 0, P.ore), S1(-3, 2, 0, "gravel"), S1(-2, -2, 0, "barrel"),
    ["e", -2, 0, 0, "chest_minecart"],
  ], st: { 1: (P) => [S1(-1, -3, 1, "shroomlight"), S1(-1, 3, 1, "shroomlight"), S1(0, -2, 4, "shroomlight"), S1(0, 2, 4, "shroomlight")] } },   /* こけの 光が もどる（入口が 光る）*/
  /* 鉄の 運び道: 砂利の 上の レール（横に 長い）・鉱石を 積んだ トロッコ・積み場の 鉱石 */
  haul: { D: [12, 14, 10], box: [-1, -11, 2, 11], H: 3, look: [0, 0, 1], build: (P) => [
    F(0, -10, -1, 0, 10, -1, "gravel"), F(0, -10, 0, 0, 10, 0, "RB"), S1(0, -11, 0, P.log), S1(0, 11, 0, P.log),
    S1(1, 10, 0, P.ore), S1(1, 9, 0, P.ore), S1(1, 10, 1, P.ore), S1(1, 8, 0, "coal_block"), S1(1, -6, 0, "barrel"), S1(1, -7, 0, P.ore),
    S1(-1, -9, 0, P.fence), S1(-1, -9, 1, P.lamp), S1(-1, 6, 0, P.fence), S1(-1, 6, 1, P.lamp),
    ["e", 0, -4, 0, "chest_minecart"], ["e", 0, 3, 0, "minecart"],
  ] },
  /* 雷神の 祠: 石の 台・木の 社（奥に 青白く 光る 雷石）・避雷針・鳥居・供え物・石の 灯籠 */
  shrine: { D: [14, 16, 12], box: [-3, -3, 4, 3], H: 6, look: [1, 0, 1.5], marks: { stone: [2, 0, 1.5] }, build: (P) => [
    F(-1, -2, 0, 3, 2, 0, P.wall), F(-2, -1, 0, -2, 1, 0, "stone_brick_slab"),
    F(1, -1, 1, 3, 1, 2, P.plank), F(1, 0, 1, 1, 0, 2, "air"), S1(2, 0, 1, "sea_lantern"),
    F(0, -2, 3, 4, 2, 3, P.slab), F(1, -1, 4, 3, 1, 4, P.slab), S1(2, 0, 5, "lightning_rod"),
    S1(0, -1, 1, "candle"), S1(0, 1, 1, "cake"),
    F(-3, -2, 0, -3, -2, 3, "red_nether_brick"), F(-3, 2, 0, -3, 2, 3, "red_nether_brick"), F(-3, -3, 4, -3, 3, 4, "red_nether_brick"),
    S1(0, -3, 0, "cobblestone_wall"), S1(0, -3, 1, P.lamp), S1(0, 3, 0, "cobblestone_wall"), S1(0, 3, 1, P.lamp),
  ] },
  /* 網元の 舟小屋: 板の 小屋・干した 網・舟・樽 */
  boathut: { D: [14, 16, 12], box: [-2, -7, 5, 4], H: 4, look: [1, 0, 1.5], marks: { net: [-1, -5.5, 1.5] }, build: (P) => [
    F(1, -3, 0, 1, -3, 2, P.log), F(1, 3, 0, 1, 3, 2, P.log), F(4, -3, 0, 4, -3, 2, P.log), F(4, 3, 0, 4, 3, 2, P.log),
    F(4, -2, 0, 4, 2, 2, P.plank), F(2, -3, 0, 3, -3, 2, P.plank), F(2, 3, 0, 3, 3, 2, P.plank), F(0, -4, 3, 5, 4, 3, P.slab),
    S1(3, -2, 0, "barrel"), S1(3, -1, 0, "barrel"), S1(3, 2, 0, "chest"), S1(1, 0, 2, HANG(P)),
    F(-1, -7, 0, -1, -7, 2, P.fence), F(-1, -4, 0, -1, -4, 2, P.fence), F(-1, -6, 1, -1, -5, 2, "web"),
    ["e", -1, 2, 0, "boat"],
  ] },
  /* 小屋（雲の 島）: 板の 壁・戸口・窓・屋根・灯り */
  cabin: { D: [13, 15, 11], box: [-1, -4, 5, 4], H: 4, look: [0, 0, 1.5], build: (P) => [
    F(0, -3, 0, 4, 3, 2, P.plank), F(1, -2, 0, 3, 2, 2, "air"), F(0, 0, 0, 0, 0, 1, "air"), S1(0, -2, 1, "glass_pane"), S1(0, 2, 1, "glass_pane"),
    F(0, -3, 0, 0, -3, 2, P.log), F(0, 3, 0, 0, 3, 2, P.log), F(4, -3, 0, 4, -3, 2, P.log), F(4, 3, 0, 4, 3, 2, P.log),
    F(-1, -4, 3, 5, 4, 3, P.slab), S1(2, 0, 2, HANG(P)), S1(-1, 1, 0, P.fence), S1(-1, 1, 1, P.lamp),
  ] },
  /* 小川: 横に 流れる 2マスの 水（両岸は 石）・小さな 板の 橋・すいれん */
  brook: { D: [11, 13, 9], box: [-2, -9, 3, 9], H: 2, look: [0.5, 0, 0.5], build: (P) => [
    F(-1, -9, -2, 2, 9, -1, P.trim), F(0, -8, -1, 1, 8, -1, "water"), F(0, -8, 0, 1, 8, 1, "air"),
    F(-1, 0, 0, 2, 0, 0, P.slab), S1(0, -5, 0, "waterlily"), S1(1, 4, 0, "waterlily"), S1(-1, -7, 0, P.trim), S1(2, 6, 0, P.trim),
  ] },
  /* 森の 天幕: 布の 三角の 天幕・寝床・焚き火 */
  tent: { D: [12, 14, 10], box: [-3, -3, 4, 4], H: 3, look: [1, 0, 1], build: (P) => [
    F(0, -2, 0, 3, -2, 0, P.cloth), F(0, 2, 0, 3, 2, 0, P.cloth), F(0, -1, 1, 3, -1, 1, P.cloth), F(0, 1, 1, 3, 1, 1, P.cloth), F(0, 0, 2, 3, 0, 2, P.cloth2),
    F(3, -1, 0, 3, 1, 0, P.cloth), F(1, 0, 0, 2, 0, 0, "white_carpet"), S1(-2, 3, 0, "campfire"), S1(-2, 2, 0, P.log),
  ] },
  /* 見晴らし台: 石の 台・手すり・灯り */
  lookout: { D: [13, 15, 11], box: [-1, -4, 5, 4], H: 3, look: [2, 0, 2.5], build: (P) => [
    F(1, -3, 0, 4, 3, 1, P.wall), F(0, -1, 0, 0, 1, 0, P.slab), F(4, -3, 2, 4, 3, 2, P.fence), F(1, -3, 2, 3, -3, 2, P.fence), F(1, 3, 2, 3, 3, 2, P.fence),
    S1(4, -3, 3, P.lamp), S1(4, 3, 3, P.lamp),
  ] },
  /* 葬列の 道の 墓穴（モンスターの 巣）: 掘りかえされた 穴・墓石・青い 灯り */
  gravenest: { D: [12, 13, 14], box: [-3, -5, 3, 5], H: 3, side: [3, -3, 6, -6], look: [0, 0, 0.5], marks: { hole: [0, 0, 0] }, build: (P) => [
    F(-1, -1, -3, 1, 1, -3, "soul_sand"), F(-1, -1, -2, 1, 1, -1, "air"), S1(-2, 0, 0, "coarse_dirt"), S1(2, 1, 0, "coarse_dirt"), S1(0, -2, 0, "coarse_dirt"),
    S1(-2, -4, 0, "cobblestone_wall"), S1(-2, -4, 1, "skull"), S1(2, -4, 0, "cobblestone_wall"), S1(2, 4, 0, "cobblestone_wall"), S1(2, 4, 1, "skull"), S1(-2, 4, 0, "cobblestone_wall"),
    S1(0, -5, 0, P.fence), S1(0, -5, 1, P.lamp), S1(0, 5, 0, P.fence), S1(0, 5, 1, P.lamp),
  ] },
  /* 雪崩の あと: 道を ふさぐ 雪の 山・折れた 木 */
  snowpile: { D: [13, 14, 12], box: [-3, -4, 3, 4], H: 3, side: [3, -3, 6, -6], look: [0, 0, 0.8], marks: { mound: [0, 0, 1] }, build: (P) => [
    F(-2, -3, 0, 2, 3, 0, "snow"), F(-1, -2, 1, 1, 2, 1, "snow"), S1(0, 0, 2, "snow_layer"), F(-3, -4, 0, 3, 4, 0, "snow_layer", "keep"),
    F(2, -4, 1, 2, -2, 1, "spruce_log"), S1(-3, 3, 1, "spruce_log"), S1(-2, 3, 2, "spruce_leaves"),
  ] },
  /* 第125版(pl): 刀鍛冶の 鍛冶場（前が 開いた 作業場。奥の 屋根だけ。炉・檻の 中の 溶岩・金床・砥石・焼き入れの 水・刀かけ・煙突）*/
  smithy: { D: [8, 9, 11, 13], near: 3.5, box: [-1, -5, 7, 5], H: 9, look: [3, 0, 1.4], marks: { anvil: [3, 0, 1], forge: [5, -2, 1] }, build: (P) => [
    F(0, -4, -1, 6, 4, -1, "stone_bricks"), F(6, -4, 0, 6, 4, 3, P.wall), F(1, -4, 0, 6, -4, 1, P.wall), F(1, 4, 0, 6, 4, 1, P.wall),
    F(0, -4, 0, 0, -4, 3, P.log), F(0, 4, 0, 0, 4, 3, P.log), F(3, -4, 0, 3, -4, 3, P.log), F(3, 4, 0, 3, 4, 3, P.log), F(3, -4, 4, 6, 4, 4, P.slab),
    S1(5, -3, 0, "blast_furnace"), S1(5, -1, 0, "blast_furnace"), S1(5, -2, 0, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'), S1(4, -2, 0, "iron_bars"), S1(5, -2, 1, "iron_bars"),
    F(5, -3, 2, 5, -1, 3, "brick_block"), F(5, -2, 4, 5, -2, 7, "brick_block"), S1(5, -2, 8, "campfire"),
    S1(3, 0, 0, "anvil"), S1(3, 2, 0, "grindstone"), S1(5, 2, 0, "smithing_table"), S1(2, -3, 0, WCAUL), S1(1, -3, 0, "barrel"),
    F(5, 3, 0, 5, 3, 2, "iron_bars"), S1(4, 3, 0, "barrel"), S1(5, 1, 1, "chain"), S1(5, 3, 3, "chain"),
    S1(2, -3, 3, HANG(P)), S1(2, 3, 3, HANG(P)), S1(0, -4, 4, P.lamp), S1(0, 4, 4, P.lamp), F(-1, -5, 0, -1, -5, 1, P.fence), F(-1, -5, 2, -1, -5, 2, "red_wool"),
  ], st: { 1: (P) => [F(3, -4, 4, 6, 0, 4, "air"), F(0, -4, -1, 6, 4, -1, "blackstone", "replace stone_bricks"), F(1, 4, 0, 2, 4, 1, "air"), S1(1, 2, 0, "coal_block"), S1(4, -4, 2, "air")] } },   /* 焼けた（屋根の 半分が 落ち・床が 黒こげ）*/
  /* 第125版(pl): 商家の 店先（縞の 日よけ・帳場・棚・看板・灯り）*/
  shopfront: { D: [8, 9, 11, 13], near: 3.5, box: [-2, -5, 6, 5], H: 6, look: [3, 0, 1.6], marks: { counter: [2, 0, 1] }, build: (P) => [
    F(0, -4, -1, 5, 4, -1, P.plank), F(5, -4, 0, 5, 4, 3, P.wall), F(1, -4, 0, 5, -4, 2, P.wall), F(1, 4, 0, 5, 4, 2, P.wall),
    F(4, -3, 0, 4, 3, 0, "barrel"), F(4, -3, 1, 4, 3, 1, "bookshelf"), S1(4, 0, 2, "chest"), F(2, -2, 0, 2, 2, 0, P.plank), S1(2, -1, 1, "flower_pot"), S1(2, 1, 1, "candle"), S1(2, 0, 1, "bell"),
    F(0, -4, 0, 0, -4, 3, P.log), F(0, 4, 0, 0, 4, 3, P.log), F(2, -4, 3, 5, 4, 3, P.slab),
    F(-1, -4, 3, 1, -3, 3, P.cloth2), F(-1, -2, 3, 1, -1, 3, P.cloth), F(-1, 0, 3, 1, 0, 3, P.cloth2), F(-1, 1, 3, 1, 2, 3, P.cloth), F(-1, 3, 3, 1, 4, 3, P.cloth2),
    F(1, -1, 4, 1, 1, 4, "yellow_wool"), S1(0, -3, 2, HANG(P)), S1(0, 3, 2, HANG(P)), S1(-1, -5, 0, "barrel"), S1(-1, 5, 0, "barrel"), S1(-1, 5, 1, "flower_pot"), S1(-2, -5, 0, "hay_block"),
  ] },
  /* 第125版(pl): 世界の 依頼の 場所（町の 外れの 地名に 合わせた 小さな 建物・目印）*/
  windmill: { D: [12, 14, 11], box: [-1, -4, 4, 4], H: 10, look: [1, 0, 4], build: (P) => [
    F(1, -1, 0, 3, 1, 5, P.wall), F(1, 0, 0, 1, 0, 1, "air"), F(1, -1, 6, 3, 1, 6, P.slab), S1(0, 0, 4, P.log),
    F(0, 0, 5, 0, 0, 8, P.cloth), F(0, 0, 1, 0, 0, 3, P.cloth), F(0, 1, 4, 0, 3, 4, P.cloth), F(0, -3, 4, 0, -1, 4, P.cloth), S1(-1, -3, 0, "hay_block"), S1(-1, 3, 0, "barrel"), S1(1, 0, 2, HANG(P)),
  ] },
  hut: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 5, look: [1, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.plank), F(2, -2, 0, 4, 2, 2, "air"), F(1, -1, 0, 1, 1, 1, "air"), S1(1, -2, 1, "glass_pane"), F(1, -3, 3, 3, 3, 3, P.slab), S1(4, 3, 2, "air"), S1(5, 2, 2, "air"),
    S1(4, -2, 0, "bookshelf"), S1(4, 2, 0, "barrel"), S1(3, 2, 0, "crafting_table"), S1(4, 0, 2, "web"), S1(2, 0, 2, HANG(P)), S1(0, 2, 0, P.fence), S1(0, 2, 1, P.lamp),
  ] },
  library: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 5, look: [2, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.wall), F(2, -2, 0, 4, 2, 2, "air"), F(1, -1, 0, 1, 1, 1, "air"), F(1, -3, 3, 5, 3, 3, P.slab), F(3, -3, 3, 5, -1, 3, "air"),
    F(4, -2, 0, 4, 2, 1, "bookshelf"), F(2, -2, 0, 3, -2, 1, "bookshelf"), S1(3, 1, 0, "lectern"), S1(2, 2, 0, "web"), S1(2, 0, 2, HANG(P)), S1(0, -2, 0, P.fence), S1(0, -2, 1, P.lamp),
  ] },
  bellows: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 6, look: [2, 0, 1.2], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.plank), F(2, -2, 0, 4, 2, 2, "air"), F(1, -2, 0, 1, 2, 2, "air"), F(1, -3, 3, 5, 3, 3, P.slab), S1(2, 3, 3, "air"),
    S1(4, -1, 0, "blast_furnace"), S1(4, 0, 0, "furnace"), S1(4, 1, 0, "smoker"), F(5, 0, 3, 5, 0, 5, "brick_block"), S1(3, 2, 0, "anvil"), S1(3, -2, 0, "barrel"), S1(2, 0, 2, HANG(P)),
  ] },
  cabin2: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 7, look: [1, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 2, P.log), F(2, -2, 0, 4, 2, 2, "air"), F(1, 0, 0, 1, 0, 1, "air"), S1(1, -2, 1, "glass_pane"), S1(1, 2, 1, "glass_pane"),
    F(0, -4, 3, 6, 4, 3, P.slab), F(1, -3, 4, 5, 3, 4, P.slab), S1(3, 0, 5, P.log), S1(3, 0, 6, "bell"), S1(4, 2, 0, "campfire"), S1(4, -2, 0, "barrel"), S1(0, -2, 0, P.fence), S1(0, -2, 1, P.lamp),
  ] },
  pond: { D: [11, 13, 10], box: [-1, -5, 5, 5], H: 2, look: [2, 0, 0.3], build: (P) => [
    F(0, -4, -2, 4, 4, -1, P.trim), F(1, -3, -1, 3, 3, -1, "water"), F(1, -3, 0, 3, 3, 1, "air"), S1(2, -2, 0, "waterlily"), S1(1, 2, 0, "waterlily"), S1(3, 1, -2, "sea_lantern"),
    S1(-1, -4, 0, "allium"), S1(-1, 4, 0, "blue_orchid"), S1(5, 0, 0, "oxeye_daisy"), S1(-1, 0, 0, P.fence), S1(-1, 0, 1, P.lamp),
  ] },
  hokora: { D: [11, 13, 10], box: [-3, -3, 3, 3], H: 5, look: [1, 0, 1.2], build: (P) => [
    F(0, -1, 0, 2, 1, 0, P.wall), F(1, -1, 1, 2, 1, 2, P.plank), F(1, 0, 1, 1, 0, 1, "air"), S1(2, 0, 1, P.lamp), F(0, -2, 3, 3, 2, 3, P.slab),
    S1(-1, -1, 0, "candle"), S1(-1, 1, 0, "flower_pot"), F(-3, -2, 0, -3, -2, 2, "red_nether_brick"), F(-3, 2, 0, -3, 2, 2, "red_nether_brick"), F(-3, -3, 3, -3, 3, 3, "red_nether_brick"),
  ] },
  altar: { D: [11, 13, 10], box: [-1, -4, 6, 4], H: 5, look: [3, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 0, P.wall), F(2, -2, 1, 4, 2, 1, P.trim), S1(3, 0, 2, "chiseled_stone_bricks"), S1(3, 0, 3, P.lamp), F(0, -1, 0, 0, 1, 0, "stone_brick_slab"),
    F(1, -3, 1, 1, -3, 3, P.wall), F(1, 3, 1, 1, 3, 3, P.wall), F(5, -3, 1, 5, -3, 3, P.wall), F(5, 3, 1, 5, 3, 3, P.wall), S1(2, -2, 2, "candle"), S1(4, 2, 2, "candle"),
  ] },
  graves: { D: [11, 13, 10], box: [-1, -5, 6, 5], H: 3, look: [2, 0, 0.8], build: (P) => [
    F(-1, -5, 0, 6, -5, 0, P.fence), F(-1, 5, 0, 6, 5, 0, P.fence), F(6, -5, 0, 6, 5, 0, P.fence), S1(-1, -5, 1, P.lamp), S1(-1, 5, 1, P.lamp),
    S1(2, -3, 0, "cobblestone_wall"), S1(2, 0, 0, "cobblestone_wall"), S1(2, 3, 0, "cobblestone_wall"), S1(4, -3, 0, "cobblestone_wall"), S1(4, 0, 0, "mossy_cobblestone_wall"), S1(4, 3, 0, "cobblestone_wall"), S1(4, 0, 1, "skull"),
    F(1, -3, -1, 1, 3, -1, "coarse_dirt"), F(3, -3, -1, 3, 3, -1, "coarse_dirt"), S1(1, 2, 0, "flower_pot"),
  ] },
  cave: { D: [13, 15, 12], box: [-2, -4, 6, 4], H: 6, look: [0, 0, 1.5], build: (P) => [
    F(1, -3, 0, 5, 3, 3, P.rock), F(2, -2, 4, 4, 2, 4, P.rock), F(0, -1, 0, 5, 1, 2, "air"), F(5, -1, -1, 5, 1, -1, "black_concrete"), S1(4, 2, 4, P.ore), S1(2, -3, 3, P.trim),
    S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp), S1(-2, 2, 0, "gravel"), S1(-1, -2, 0, "cobblestone"),
  ] },
  tower: { D: [12, 14, 11], box: [-1, -3, 4, 3], H: 8, look: [2, 0, 3], build: (P) => [
    F(1, -2, 0, 1, -2, 4, P.log), F(1, 2, 0, 1, 2, 4, P.log), F(4, -2, 0, 4, -2, 4, P.log), F(4, 2, 0, 4, 2, 4, P.log), F(1, -2, 5, 4, 2, 5, P.plank),
    F(1, -2, 6, 4, -2, 6, P.fence), F(1, 2, 6, 4, 2, 6, P.fence), F(4, -1, 6, 4, 1, 6, P.fence), S1(1, -2, 7, P.lamp), S1(4, 2, 7, P.lamp), F(0, 0, 0, 0, 0, 4, "ladder"), S1(3, 0, 6, "lightning_rod"),
  ] },
  lighthouse: { D: [13, 15, 12], box: [-1, -3, 4, 3], H: 12, look: [2, 0, 4], build: (P) => [
    F(1, -1, 0, 3, 1, 2, "white_concrete"), F(1, -1, 3, 3, 1, 4, "red_concrete"), F(1, -1, 5, 3, 1, 6, "white_concrete"), F(1, -1, 7, 3, 1, 7, "red_concrete"),
    F(1, -1, 8, 3, 1, 8, "glass"), S1(2, 0, 8, "sea_lantern"), F(1, -1, 9, 3, 1, 9, "dark_oak_slab"), F(1, 0, 0, 1, 0, 1, "air"), S1(0, -2, 0, "barrel"), S1(0, 2, 0, P.fence), S1(0, 2, 1, P.lamp),
  ] },
  well: { D: [11, 13, 10], box: [-2, -3, 3, 3], H: 5, look: [1, 0, 1], build: (P) => [
    F(0, -1, 0, 2, 1, 0, P.wall), S1(1, 0, 0, "water"), F(0, -1, 1, 0, -1, 2, P.fence), F(2, 1, 1, 2, 1, 2, P.fence), F(0, -1, 3, 2, 1, 3, P.slab), S1(1, 0, 2, "chain"), S1(-1, 2, 0, "cauldron"), S1(-1, -2, 0, P.lamp),
  ] },
  field: { D: [11, 13, 10], box: [-1, -5, 6, 5], H: 3, look: [2, 0, 0.8], build: (P) => [
    F(0, -4, -1, 5, 4, -1, "farmland"), F(0, -4, 0, 5, 4, 0, "wheat"), F(0, 0, -1, 5, 0, -1, "water"), S1(0, 0, 0, "air"), F(1, 0, 0, 5, 0, 0, "air"),
    F(-1, -5, 0, 6, -5, 0, P.fence), F(6, -5, 0, 6, 5, 0, P.fence), S1(3, 3, 1, "hay_block"), S1(3, 3, 2, "carved_pumpkin"), S1(-1, 4, 0, "hay_block"), S1(-1, 3, 0, "hay_block"),
  ] },
  roses: { D: [11, 13, 10], box: [-1, -5, 6, 5], H: 3, look: [2, 0, 0.8], build: (P) => [
    F(0, -4, -1, 5, 4, -1, "coarse_dirt"), F(0, -4, -1, 5, 4, -1, "podzol", "replace coarse_dirt"), F(0, -4, 0, 5, -3, 0, "poppy"), F(0, -1, 0, 5, 1, 0, "red_tulip"), F(0, 3, 0, 5, 4, 0, "poppy"),
    F(-1, -5, 0, 6, -5, 0, P.fence), F(6, -5, 0, 6, 5, 0, P.fence), S1(-1, 5, 0, "barrel"), S1(-1, 0, 0, P.fence), S1(-1, 0, 1, P.lamp), S1(2, 2, 0, "cauldron"),
  ] },
  arena: { D: [12, 14, 11], box: [-1, -5, 8, 5], H: 5, look: [3, 0, 1], build: (P) => [
    F(0, -4, -1, 7, 4, -1, P.wall), F(1, -3, -1, 6, 3, -1, P.trim), F(0, -4, 0, 0, -4, 2, P.wall), F(0, 4, 0, 0, 4, 2, P.wall), F(7, -4, 0, 7, -4, 2, P.wall), F(7, 4, 0, 7, 4, 2, P.wall),
    S1(0, -4, 3, P.lamp), S1(0, 4, 3, P.lamp), S1(7, -4, 3, P.lamp), S1(7, 4, 3, P.lamp), S1(3, 0, -1, "chiseled_stone_bricks"),
  ] },
  burnt: { D: [12, 14, 11], box: [-1, -5, 6, 5], H: 4, look: [2, 0, 1], build: (P) => [
    F(1, -4, -1, 5, 4, -1, "coarse_dirt"), F(1, -4, 0, 1, -4, 2, "blackstone"), F(5, -4, 0, 5, -1, 1, "blackstone"), F(5, 2, 0, 5, 4, 2, "dark_oak_log"), S1(1, 3, 0, "dark_oak_log"),
    S1(3, -2, 0, "coal_block"), S1(3, 1, 0, "campfire"), S1(4, 3, 0, "coal_block"), S1(2, 0, 0, "dark_oak_slab"), S1(-1, -5, 0, P.fence), S1(-1, -5, 1, P.lamp),
  ] },
  channel: { D: [11, 13, 10], box: [-1, -4, 6, 4], H: 3, look: [2, 0, 0.5], build: (P) => [
    F(0, -2, -2, 5, 2, -1, P.wall), F(0, -1, -1, 5, 1, -1, "water"), F(0, -1, 0, 5, 1, 1, "air"), F(5, -2, 0, 5, 2, 1, P.wall), F(5, -1, 0, 5, 1, 0, "iron_bars"),
    S1(0, -3, 0, P.fence), S1(0, -3, 1, P.lamp), S1(0, 3, 0, P.fence), S1(0, 3, 1, P.lamp), S1(-1, 2, 0, "barrel"),
  ] },
  /* 第125版(pl): 坑道の 奥の こけの 庭（岩の 洞・光る こけ・水晶・小さな 泉）。コロが 守る 場所 */
  mossgrotto: { D: [9, 10, 12], box: [-1, -5, 6, 5], H: 6, look: [3, 0, 1], marks: { moss: [3, 0, 0.2] }, build: (P) => [
    F(1, -4, 0, 6, 4, 4, P.rock), F(1, -3, 0, 5, 3, 3, "air"), F(0, -2, 0, 0, 2, 2, "air"), F(1, -3, -1, 5, 3, -1, "moss_block"), F(2, -2, 0, 4, 2, 0, "moss_carpet"),
    S1(5, 0, -1, "water"), S1(5, 0, 0, "air"), S1(5, -2, 1, "shroomlight"), S1(5, 2, 1, "shroomlight"), S1(3, -3, 2, "glow_lichen"), S1(3, 3, 2, "glow_lichen"), S1(4, 0, 3, "glow_lichen"),
    S1(2, -3, 0, "amethyst_cluster"), S1(4, 3, 0, "amethyst_cluster"), S1(1, 3, 1, P.ore), S1(3, 0, 4, "shroomlight"), S1(-1, -3, 0, "rail"), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp),
  ] },
  /* 第125版(pl): 洞くつの 入口の 運び出し場（水晶の 箱・トロッコ・天幕・灯り）*/
  cryscamp: { D: [10, 12, 9], box: [-2, -5, 3, 5], H: 4, look: [0, 0, 1], build: (P) => [
    F(0, -4, 0, 0, -3, 0, "barrel"), S1(0, -4, 1, "barrel"), F(1, 2, 0, 1, 4, 0, P.ore), S1(1, 3, 1, P.ore), S1(0, 3, 0, "amethyst_cluster"), F(-1, -1, -1, -1, 1, -1, P.bed),
    F(2, -2, 0, 2, -2, 2, P.log), F(2, 2, 0, 2, 2, 2, P.log), F(2, -2, 3, 2, 2, 3, P.cloth2), S1(-2, -5, 0, P.fence), S1(-2, -5, 1, P.lamp), S1(-2, 5, 0, P.fence), S1(-2, 5, 1, P.lamp),
    ["e", 0, 0, 0, "chest_minecart"],
  ] },
  /* 道しるべ（旅の 場所: 街道・林・岩場・浜・雪原 など）: 道の 札・灯りの 柱・腰かけ・荷 */
  waypost: { D: [10, 12, 9], box: [-2, -5, 2, 5], H: 3, look: [0, 0, 1.3], build: (P) => [
    F(-1, -5, -1, -1, 5, -1, P.bed), F(0, 0, 0, 0, 0, 1, P.fence), F(0, -1, 2, 0, 1, 2, P.plank), S1(0, -4, 0, P.fence), S1(0, -4, 1, P.lamp), S1(0, 4, 0, P.fence), S1(0, 4, 1, P.lamp),
    S1(1, 2, 0, "barrel"), S1(1, 3, 0, "hay_block"), S1(-2, -2, 0, P.log), S1(-2, -3, 0, P.log), S1(1, -3, 0, "campfire"),
  ] },
  beachcamp: { D: [10, 12, 9], box: [-2, -5, 3, 5], H: 3, look: [0, 0, 1], build: (P) => [
    F(0, -4, 0, 0, -4, 2, P.fence), F(0, -1, 0, 0, -1, 2, P.fence), F(0, -3, 1, 0, -2, 2, "web"), S1(1, 2, 0, "barrel"), S1(1, 3, 0, "barrel"), S1(-1, 0, 0, "campfire"), S1(2, -3, 0, P.fence), S1(2, -3, 1, P.lamp),
    ["e", 1, 0, 0, "boat"],
  ] },
  deadwood: { D: [10, 12, 9], box: [-2, -5, 3, 5], H: 5, look: [0, 0, 1.2], build: (P) => [
    F(1, -3, 0, 1, -3, 3, "stripped_dark_oak_log"), F(2, 3, 0, 2, 3, 4, "stripped_dark_oak_log"), S1(2, 2, 3, "dark_oak_fence"), S1(1, -2, 2, "dark_oak_fence"), F(-1, 1, 0, -1, 3, 0, "dark_oak_log"),
    S1(0, -1, 0, "brown_mushroom"), S1(1, 1, 0, "red_mushroom"), S1(2, -4, 0, "web"), F(-2, -5, -1, 3, 5, -1, "podzol", "replace grass_block"), S1(0, 4, 0, P.fence), S1(0, 4, 1, "soul_lantern"),
  ] },
  /* 第125版(rs): 墓守の 丘（赤い 灯籠の 墓地・墓守の 番小屋の 牢。st1 = 牢の 戸を 開ける）*/
  redyard: { D: [11, 12, 14], box: [-1, -6, 8, 6], H: 5, look: [3, 0, 1], marks: { cell: [5.5, 4, 0], door: [3, 4, 0], yu: [1.6, 2.4, 0], aisle: [0.5, -3, 0], front: [-2, 4, 0], grave: [4, -3, 0], lamp: [-1, -6, 2] }, build: (P) => [
    F(1, -5, -1, 5, -1, -1, "podzol"), F(0, -1, -1, 8, 1, -1, "coarse_dirt"),
    S1(2, -5, 0, "cobblestone_wall"), S1(2, -5, 1, "skull"), S1(4, -5, 0, "cobblestone_wall"), S1(4, -3, 0, "cobblestone_wall"), S1(4, -3, 1, "skull"), S1(4, -1, 0, "mossy_cobblestone_wall"), S1(6, -4, 0, "cobblestone_wall"), S1(6, -2, 0, "cobblestone_wall"),
    S1(4, -2, 0, 'red_candle ["candles"=2,"lit"=true]'), S1(5, -4, 0, 'red_candle ["candles"=1,"lit"=true]'), S1(3, -4, 0, "poppy"),
    F(3, 2, 0, 7, 6, 3, P.wall), F(4, 3, 0, 6, 5, 2, "air"), F(3, 3, 0, 3, 5, 2, "iron_bars"), S1(3, 4, 0, "dark_oak_fence_gate"), S1(3, 4, 1, "air"), F(2, 1, 4, 8, 7, 4, P.slab),
    S1(6, 5, 0, "hay_block"), S1(5, 3, 2, "chain"), S1(5, 4, 2, `${P.lamp} ["hanging"=true]`), S1(8, 3, 0, "barrel"), S1(2, 6, 0, P.fence), S1(2, 6, 1, P.lamp),
    F(-1, -6, 0, -1, -6, 1, "nether_brick_fence"), S1(-1, -6, 2, 'red_candle ["candles"=3,"lit"=true]'), F(-1, 6, 0, -1, 6, 1, "nether_brick_fence"), S1(-1, 6, 2, 'red_candle ["candles"=3,"lit"=true]'),
    F(7, -6, 0, 7, -6, 1, "nether_brick_fence"), S1(7, -6, 2, 'red_candle ["candles"=3,"lit"=true]'), F(8, 0, 0, 8, 0, 1, "nether_brick_fence"), S1(8, 0, 2, 'red_candle ["candles"=3,"lit"=true]'),
  ], st: { 1: (P) => [S1(3, 4, 0, "air")] } },
  /* 第125版(rs): 霊廟（暗い 聖堂の 正面・とがった 戸口・紫の 窓・中に 帳の 写しの 書見台と 石の 棺・赤い 灯籠の 柱）*/
  crypt: { D: [12, 14, 11], box: [-1, -5, 7, 5], H: 9, look: [1, 0, 2.5], marks: { book: [5, 0, 1.2], floor: [4, 0, 0], door: [1, 0, 0], front: [-1.5, 0, 0] }, build: (P) => [
    F(0, -2, -1, 6, 2, -1, "polished_deepslate"), F(0, -2, 0, 0, 2, 0, "deepslate_brick_slab"),
    F(1, -4, 0, 6, 4, 6, P.wall), F(2, -3, 0, 5, 3, 5, "air"), F(1, -1, 0, 1, 1, 3, "air"), S1(1, 0, 4, "air"), S1(1, 0, 5, "purple_stained_glass"), S1(6, 0, 3, "purple_stained_glass"),
    F(1, -4, 7, 6, 4, 7, P.trim), S1(1, 0, 8, "deepslate_brick_wall"), S1(1, 0, 9, P.lamp),
    F(0, -3, 0, 0, -3, 5, P.trim), F(0, 3, 0, 0, 3, 5, P.trim), S1(0, -3, 6, P.lamp), S1(0, 3, 6, P.lamp),
    S1(5, 0, 0, "lectern"), S1(5, -1, 0, 'candle ["candles"=3,"lit"=true]'), S1(5, 1, 0, 'candle ["candles"=3,"lit"=true]'), F(3, -3, 0, 4, -3, 0, "polished_deepslate_slab"), F(3, 3, 0, 4, 3, 0, "polished_deepslate_slab"), S1(4, 0, 5, `${P.lamp} ["hanging"=true]`),
    F(-1, -5, 0, -1, -5, 1, "nether_brick_fence"), S1(-1, -5, 2, 'red_candle ["candles"=3,"lit"=true]'), F(-1, 5, 0, -1, 5, 1, "nether_brick_fence"), S1(-1, 5, 2, 'red_candle ["candles"=3,"lit"=true]'),
  ] },
  /* 第125版(rs): 六影の 卓の 間（「そのころ」の 切りかえ用。手前が 開いた 暗い 部屋・六つの 席の 卓・空いた「二の座」の 紫の 席・雪あかりの 窓）*/
  sixroom: { D: [12, 14, 11], box: [-1, -5, 9, 5], H: 6, look: [4, 0, 1.2], marks: { table: [4, 0, 1.1], seat2: [4, 3, 0], snow: [6, -3.5, 0], mask: [7, 3, 0], rep: [2, -1, 0] }, build: (P) => [
    F(0, -5, -1, 8, 5, -1, "polished_blackstone_bricks"), F(1, -5, 0, 8, -5, 4, "polished_blackstone_bricks"), F(1, 5, 0, 8, 5, 4, "polished_blackstone_bricks"), F(8, -5, 0, 8, 5, 4, "polished_blackstone_bricks"), F(0, -5, 5, 8, 5, 5, "blackstone"),
    F(3, -1, 0, 5, 1, 0, "dark_oak_fence"), F(3, -1, 1, 5, 1, 1, "dark_oak_slab"), S1(4, 0, 2, 'candle ["candles"=1,"lit"=true]'),
    S1(2, -2, 0, "polished_blackstone_stairs"), S1(2, 2, 0, "polished_blackstone_stairs"), S1(6, -2, 0, "polished_blackstone_stairs"), S1(6, 2, 0, "polished_blackstone_stairs"), S1(4, -3, 0, "polished_blackstone_stairs"), S1(4, 3, 0, "purple_wool"),
    F(8, -4, 1, 8, -3, 2, "white_stained_glass"), F(9, -4, 1, 9, -3, 2, "sea_lantern"), S1(4, 0, 4, `${P.lamp} ["hanging"=true]`), S1(1, -4, 0, P.fence), S1(1, -4, 1, P.lamp), S1(1, 4, 0, P.fence), S1(1, 4, 1, P.lamp),
  ] },
  /* 第125版(ce): 風の 塔（根もとの 星見の 間: 前が 開いた 戸口・星図の 机・窓・吊りランプ。上に 塔の 柱・鐘・灯り）。遠めがねは ep_r10 が 海の 方角の 窓ぎわに 置く */
  windroom: { D: [10, 12, 14], box: [0, -4, 8, 4], H: 16, side: [6, -6, 10, -10], look: [3, 0, 1.6], marks: { desk: [5, -1, 0], chart: [6, -1, 1.1], in: [3, 1, 0], side: [3, -1, 0], door: [1, 0, 0], front: [-1.5, 0, 0], bell: [4, 0, 15] }, build: (P) => [
    F(1, -3, 0, 7, 3, 6, "stone_bricks"), F(2, -2, 0, 6, 2, 5, "air"), F(1, -2, 0, 1, 2, 3, "air"), F(2, -2, -1, 6, 2, -1, "spruce_planks"), F(0, -4, 7, 8, 4, 7, "spruce_slab"),
    F(4, -3, 1, 4, -3, 2, "glass_pane"), F(4, 3, 1, 4, 3, 2, "glass_pane"), F(7, 0, 1, 7, 0, 2, "glass_pane"), S1(1, 0, 5, "glass_pane"),
    S1(6, -1, 0, "cartography_table"), S1(6, -2, 0, "bookshelf"), S1(6, -2, 1, "bookshelf"), S1(6, 2, 0, "barrel"), S1(4, 0, 5, "chain"), S1(4, 0, 4, HANG(P)),
    F(3, -1, 8, 5, 1, 13, "stone_bricks"), F(3, -1, 14, 5, 1, 14, "spruce_slab"), S1(4, 0, 15, "bell"), S1(3, -1, 15, "lantern"), S1(5, 1, 15, "lantern"),
    F(0, -3, 0, 0, -3, 2, "birch_fence"), S1(0, -3, 3, "white_wool"), F(0, 3, 0, 0, 3, 2, "birch_fence"), S1(0, 3, 3, "white_wool"),
  ] },
  /* 第125版(ce): 雲の 島の 端（竜の 石像の 台座・崩れかけた 端の 手すり・風の 旗・石の 腰かけ・向こうに 雲）*/
  cloudedge: { D: [8, 10, 12], box: [-1, -6, 7, 6], H: 4, look: [3, 0, 1.2], marks: { dragon: [3, -3, 0.5], ray: [3, -1, 0], rail: [5, 0, 0], bench: [1, 4, 0] }, build: (P) => [
    F(0, -5, -1, 5, 5, -1, "quartz_bricks"), F(2, -4, 0, 4, -2, 0, "smooth_quartz_slab"), S1(4, -5, 0, "chiseled_quartz_block"), S1(4, -5, 1, "lantern"),
    F(6, -5, 0, 6, 5, 0, "birch_fence"), F(6, -1, 0, 6, 0, 0, "air"), S1(6, 3, 0, "cobblestone_wall"),
    F(6, -6, 0, 6, -6, 2, "birch_fence"), S1(6, -6, 3, "white_wool"), F(6, 6, 0, 6, 6, 2, "birch_fence"), S1(6, 6, 3, "white_wool"),
    F(1, 4, 0, 1, 5, 0, "birch_slab"), F(8, -5, -1, 10, 5, -1, "white_wool", "keep"), F(9, -3, 0, 10, 2, 0, "white_wool", "keep"),
  ] },
  /* 第125版(ce): ステラの 古い 星見台（白い 石の 部屋・ガラスの 屋根・星図の 机・空を 向く 筒）*/
  observatory: { D: [12, 14, 11], box: [-1, -4, 6, 4], H: 6, look: [3, 0, 1.6], marks: { chart: [3, 0, 1.1] }, build: (P) => [
    F(1, -3, 0, 5, 3, 3, "quartz_block"), F(2, -2, 0, 4, 2, 3, "air"), F(1, -1, 0, 1, 1, 2, "air"), F(1, -3, 4, 5, 3, 4, "glass"), F(2, -2, 5, 4, 2, 5, "glass"),
    S1(3, 0, 0, "cartography_table"), S1(4, 2, 0, P.fence), S1(4, 2, 1, "lightning_rod"), S1(4, -2, 0, "bookshelf"), S1(3, 0, 3, HANG(P)), S1(0, -3, 0, P.fence), S1(0, -3, 1, P.lamp),
  ] },
  /* 浜の 焚き火: 焚き火と 腰かけの 丸太 */
  fire: { D: [10, 11, 9], box: [-2, -2, 2, 2], H: 2, small: 1, side: [6, -6, 7, -7], look: [0, 0, 0.5], build: (P) => [
    S1(0, 0, 0, "campfire"), S1(-2, 0, 0, P.log), S1(2, 0, 0, P.log), S1(0, 2, 0, P.log), S1(0, -2, 0, "cobblestone"),
  ] },
  /* 第125版(tp): 文に 出る 地形（場面の 文と 場所を 合わせる）。marks は 人が 立つ・カメラが 映す 点 */
  /* 雪庇: 足もとの 先が 4マス 下へ 落ちる 雪の 崖。st1 = 張り出した 雪が 崩れ落ちる */
  cornice: { D: [6, 7, 9], near: 3, gap: 8, box: [-1, -4, 9, 4], H: 3, side: [8, -8, 11, -11], look: [5, 0, 0], marks: { edge: [3.5, 0, 0], lip: [5.5, 0, -1], drop: [6.5, 0, -4] }, build: (P) => [
    F(5, -3, -4, 8, 3, -1, "air"), F(5, -3, -5, 8, 3, -5, "snow"), F(9, -4, -4, 9, 4, 1, "snow"), F(5, -4, -4, 8, -4, 0, "snow"), F(5, 4, -4, 8, 4, 0, "snow"),
    F(5, -2, -1, 6, 2, -1, "snow"), F(3, -3, 0, 6, 3, 0, "snow_layer"), S1(4, -3, 0, P.fence), S1(4, 3, 0, P.fence), S1(9, 0, 2, "snow_layer"),
  ], st: { 1: (P) => [F(5, -2, -1, 6, 2, 0, "air")] } },
  /* 薄い 氷の 池（氷の 下は 水）。st1 = まん中が 割れる */
  icepond: { D: [9, 10, 12], gap: 8, box: [-1, -4, 6, 4], H: 2, look: [3, 0, 0], marks: { ice: [3, 0, 0], rim: [0.5, 0, 0] }, build: (P) => [
    F(1, -3, -3, 5, 3, -1, "packed_ice"), F(2, -2, -3, 4, 2, -2, "water"), F(2, -2, -1, 4, 2, -1, "ice"), S1(0, -3, 0, "snow_layer"), S1(6, 2, 0, "snow_layer"), S1(1, 4, 0, P.fence), S1(1, 4, 1, P.lamp),
  ], st: { 1: (P) => [F(3, -1, -1, 3, 1, -1, "water")] } },
  /* 崖道の 崖（高さ 5 の 岩壁。上に 立てる）*/
  cliffwall: { D: [9, 10, 12], gap: 8, box: [-1, -6, 5, 6], H: 7, look: [3, 0, 3], marks: { top: [3.5, 0, 5], foot: [0.5, 0, 0] }, build: (P) => [
    F(2, -6, 0, 5, 6, 3, P.rock), F(3, -5, 4, 5, 5, 4, P.rock), F(2, -6, 2, 2, -3, 3, "air"), F(2, 4, 3, 2, 6, 3, "air"), F(1, -6, 0, 1, -5, 1, P.rock), S1(1, 5, 0, P.trim), S1(0, -4, 0, "gravel"), S1(4, 3, 5, P.plant), S1(4, -2, 5, P.plant),
  ] },
  /* 水晶の 祭壇（晶洞の 広間: 方解石の 床・玄武岩の 壇・曇った 水晶・紫水晶の 群れ）*/
  crysaltar: { D: [9, 10, 12], gap: 8, box: [-1, -5, 6, 5], H: 6, look: [4, 0, 1.2], marks: { altar: [4, 0, 1] }, build: (P) => [
    F(0, -4, -1, 6, 4, -1, "calcite"), F(3, -2, 0, 5, 2, 0, "smooth_basalt"), F(5, -1, 1, 5, 1, 2, "tinted_glass"), S1(5, 0, 3, "amethyst_block"), S1(5, 0, 4, "amethyst_cluster"),
    F(6, -4, 0, 6, -4, 2, "amethyst_block"), F(6, 4, 0, 6, 4, 2, "amethyst_block"), S1(6, -4, 3, "amethyst_cluster"), S1(6, 4, 3, "amethyst_cluster"), S1(2, -4, 0, "amethyst_block"), S1(2, -4, 1, "amethyst_cluster"), S1(2, 4, 0, "amethyst_block"), S1(2, 4, 1, "amethyst_cluster"),
    F(1, -5, 0, 1, -5, 2, "calcite"), F(1, 5, 0, 1, 5, 2, "calcite"), S1(4, -3, 0, "sea_lantern"), S1(4, 3, 0, "sea_lantern"), S1(3, -2, 1, "amethyst_cluster"), S1(3, 2, 1, "amethyst_cluster"),
  ] },
  /* 小さな 墓（土の 盛り・石の 墓標・野の 花）*/
  grave: { D: [5, 6, 8], near: 3, box: [-1, -3, 3, 3], H: 3, small: 1, side: [4, -4, 7, -7], look: [2, 0, 0.6], marks: { stone: [2, 0, 0.6], front: [0, 0, 0] }, build: (P) => [
    F(1, -1, 0, 2, 1, 0, "moss_carpet"), S1(2, 0, 0, "mossy_stone_brick_wall"), S1(2, 0, 1, "stone_brick_slab"), S1(1, -1, 0, "dandelion"), S1(1, 1, 0, "poppy"), S1(2, -1, 0, "cornflower"), S1(2, 1, 0, "oxeye_daisy"), S1(3, 2, 0, "azure_bluet"),
  ] },
  /* 岩場・岩山・峰（岩の 塊と まわりの 岩）*/
  rocks: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 6, look: [3, 0, 2], marks: { top: [3.5, 0, 4] }, build: (P) => [
    F(2, -2, 0, 4, 2, 2, P.rock), F(3, -1, 3, 4, 1, 3, P.rock), F(2, -2, 2, 2, -2, 2, P.trim), F(1, -5, 0, 2, -4, 1, P.rock), F(5, 3, 0, 6, 5, 1, P.rock), S1(0, 4, 0, P.rock), S1(5, -3, 0, "cobblestone"), S1(1, 3, 0, "gravel"), S1(6, -1, 0, P.trim), S1(4, 0, 4, P.trim),
  ] },
  /* 岩棚と 木 */
  ledge: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 9, look: [3, 0, 3], marks: { tree: [4, 0, 4] }, build: (P) => [
    F(2, -3, 0, 5, 3, 3, P.rock), F(1, -3, 0, 1, -2, 1, P.rock), F(1, 2, 0, 1, 3, 2, P.rock), F(4, 0, 4, 4, 0, 6, P.log), F(3, -1, 6, 5, 1, 7, "dark_oak_leaves"), S1(4, 0, 8, "dark_oak_leaves"), S1(3, 2, 4, P.plant), S1(6, -4, 0, P.rock),
  ] },
  /* 溶岩の 崖（赤く 光る 黒い 崖・崖の 下の 溶岩だまり）*/
  lavacliff: { D: [11, 12, 10], box: [-1, -5, 6, 5], H: 7, look: [3, 0, 3], marks: { top: [4.5, 0, 5] }, build: (P) => [
    F(3, -5, 0, 6, 5, 4, "blackstone"), F(3, -4, 1, 3, 4, 1, "magma"), F(3, -3, 3, 3, 3, 3, "magma"), F(3, -1, 0, 3, 1, 0, "basalt"), F(1, -2, -2, 2, 2, -2, "blackstone"), F(1, -2, -1, 2, 2, -1, "lava"),
    F(0, -3, -1, 0, 3, -1, "blackstone"), F(5, -5, 5, 5, -4, 6, "basalt"), F(5, 4, 5, 5, 5, 5, "basalt"), S1(4, 0, 5, "magma"),
  ] },
  /* 竜骨の 原（大きな 骨の 肋の アーチ・鱗）*/
  bones: { D: [11, 12, 10], box: [-1, -5, 7, 5], H: 6, look: [3, 0, 2], marks: { root: [2, -3, 0] }, build: (P) => [
    F(2, -3, 0, 2, -3, 3, "bone_block"), F(2, 3, 0, 2, 3, 3, "bone_block"), F(2, -2, 4, 2, 2, 4, "bone_block"), F(4, -3, 0, 4, -3, 3, "bone_block"), F(4, 3, 0, 4, 3, 3, "bone_block"), F(4, -2, 4, 4, 2, 4, "bone_block"),
    F(6, -2, 0, 6, -2, 2, "bone_block"), F(6, 2, 0, 6, 2, 2, "bone_block"), F(6, -1, 3, 6, 1, 3, "bone_block"), F(1, 0, 0, 7, 0, 0, "bone_block"), S1(0, 0, 0, "skull"), S1(3, -2, 0, "light_blue_carpet"), S1(5, 1, 0, "light_blue_carpet"), S1(2, -4, 0, "light_blue_carpet"),
  ] },
  bonepeak: { D: [11, 12, 10], box: [-1, -5, 6, 5], H: 9, look: [3, 0, 4], marks: { top: [3.5, 0, 3] }, build: (P) => [
    F(1, -4, 0, 5, 4, 1, P.rock), F(2, -3, 2, 4, 3, 2, P.rock), F(2, -3, 3, 2, -3, 5, "bone_block"), F(2, 3, 3, 2, 3, 5, "bone_block"), F(2, -2, 6, 2, 2, 6, "bone_block"), F(4, -2, 3, 4, -2, 5, "bone_block"), F(4, 2, 3, 4, 2, 5, "bone_block"), F(4, -1, 6, 4, 1, 6, "bone_block"), S1(0, 4, 0, P.rock),
  ] },
  /* 鏡石の 原（光る 石が 原に 散らばる）*/
  mirrors: { D: [10, 12, 9], box: [-1, -6, 6, 6], H: 3, look: [3, 0, 0.6], build: (P) => [
    F(0, -5, -1, 6, 5, -1, "calcite"), S1(1, -4, 0, "white_stained_glass"), S1(2, 2, 0, "tinted_glass"), F(3, -2, 0, 3, -2, 1, "white_stained_glass"), S1(4, 4, 0, "glass"), S1(5, -5, 0, "amethyst_block"), F(5, 1, 0, 5, 1, 1, "glass"),
    S1(2, -1, 0, "amethyst_cluster"), S1(6, 3, 0, "white_stained_glass"), S1(1, 5, 0, "glass"), S1(6, -2, 0, "tinted_glass"), S1(3, 5, 0, "amethyst_cluster"), S1(0, 0, 0, "sea_lantern"),
  ] },
  /* 花の 丘（赤い 花・白い 花）*/
  redhill: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 2, look: [3, 0, 0.5], build: (P) => [
    F(0, -5, -1, 6, 5, -1, "grass_block"), F(1, -4, 0, 5, 4, 0, "poppy"), F(2, -3, 0, 4, 3, 0, "red_tulip"), F(3, -1, 0, 3, 1, 0, "poppy"), S1(0, -5, 0, 'red_candle ["candles"=3,"lit"=true]'), S1(0, 5, 0, 'red_candle ["candles"=3,"lit"=true]'), S1(6, 0, 0, 'red_candle ["candles"=2,"lit"=true]'),
  ] },
  whitehill: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 2, look: [3, 0, 0.5], build: (P) => [
    F(0, -5, -1, 6, 5, -1, "grass_block"), F(1, -4, 0, 5, 4, 0, "lily_of_the_valley"), F(2, -3, 0, 4, 3, 0, "oxeye_daisy"), F(3, -1, 0, 3, 1, 0, "white_tulip"), S1(0, 0, 0, P.fence), S1(0, 0, 1, P.lamp),
  ] },
  /* 庭の 跡（枯れた 花壇・石の ベンチ）*/
  garden: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 2, look: [3, 0, 0.5], marks: { bench: [1, 3.5, 0] }, build: (P) => [
    F(2, -4, 0, 5, -4, 0, P.trim), F(2, 4, 0, 5, 4, 0, P.trim), F(5, -3, 0, 5, 3, 0, P.trim), F(2, -3, -1, 4, 3, -1, "coarse_dirt"), F(2, -3, 0, 4, 3, 0, "deadbush"), F(3, -1, 0, 3, 1, 0, "air"),
    S1(1, 3, 0, 'stone_brick_stairs ["weirdo_direction"=2]'), S1(1, 4, 0, 'stone_brick_stairs ["weirdo_direction"=2]'), S1(0, -4, 0, P.fence), S1(0, -4, 1, P.lamp),
  ] },
  /* 丘の 古い 木 */
  oldtree: { D: [10, 12, 9], box: [-2, -4, 4, 4], H: 9, look: [1, 0, 2], marks: { root: [0, 0, 0] }, build: (P) => [
    F(0, -2, 0, 2, 2, 0, "grass_block"), F(1, 0, 1, 1, 0, 5, "oak_log"), F(-1, -2, 5, 3, 2, 6, "oak_leaves"), F(0, -1, 7, 2, 1, 7, "oak_leaves"), S1(0, 1, 1, "oak_log"), S1(2, -1, 1, "oak_log"), S1(-1, 2, 0, "dandelion"),
  ] },
  /* 砂の 窪地（2マス 下がった 底に 布の 束）*/
  hollow: { D: [10, 12, 9], box: [-1, -4, 6, 4], H: 2, look: [3, 0, -1.4], marks: { pit: [3, 0, -2] }, build: (P) => [
    F(1, -3, -2, 5, 3, -1, "air"), F(1, -3, -3, 5, 3, -3, P.bed), F(0, -1, -1, 0, 1, -1, P.slab), S1(3, 0, -2, "white_wool"), S1(3, 1, -2, P.cloth2), S1(4, -1, -2, "white_carpet"), S1(2, 2, -2, "deadbush"),
  ] },
  /* 氷の 洞（洞くつの 形を 氷で）*/
  icecave: { D: [13, 15, 12], box: [-2, -4, 6, 4], H: 6, look: [0, 0, 1.5], build: (P) => SHAPES.cave.build({ ...P, rock: "packed_ice", trim: "blue_ice", ore: "raw_gold_block" }) },
  /* 岩礁・入り江（浅い 水・岩・流れ着いた 舟板）*/
  reef: { D: [10, 12, 9], box: [-1, -5, 6, 5], H: 3, look: [3, 0, 0.5], build: (P) => [
    F(1, -4, -2, 5, 4, -1, "sand"), F(1, -4, -1, 5, 4, -1, "water"), F(2, -3, -1, 3, -2, 1, P.rock), F(4, 2, -1, 5, 3, 0, P.rock), S1(3, 1, -1, P.rock), S1(3, 1, 0, P.rock), S1(2, 1, 0, P.slab), S1(4, -1, -1, "sea_pickle"), S1(0, -4, 0, P.fence), S1(0, -4, 1, P.lamp),
  ] },
  /* 雲の 井戸（井戸と 小さな 風車）*/
  cloudwell: { D: [11, 13, 10], box: [-2, -3, 3, 7], H: 8, look: [1, 0, 1], build: (P) => SHAPES.well.build(P).concat([F(2, 5, 0, 2, 5, 5, P.log), F(1, 5, 3, 1, 5, 7, P.cloth), F(1, 3, 5, 1, 7, 5, P.cloth)]) },
  /* 川上の 灯り台（石の 台の 上の 火・そばを 流れる 川）*/
  lamptower: { D: [11, 13, 10], box: [-1, -6, 6, 3], H: 7, look: [2, 0, 4], marks: { fire: [2, 0, 5] }, build: (P) => [
    F(1, -1, 0, 3, 1, 3, P.wall), F(1, -1, 4, 3, 1, 4, P.slab), S1(2, 0, 4, P.wall), S1(2, 0, 5, "soul_campfire"), F(-1, -6, -2, 6, -4, -2, P.trim), F(-1, -5, -1, 6, -5, -1, "water"), S1(0, 0, 0, "ladder"),
  ] },
};

/* 第125版(pl): 大きな 施設（形の 点検の 450 ブロックの 外。fill の 数は 少ない）。建てられない ときは fb の 小さな 形 */
/* 坑道: 丘の 斜面の 入口（木の 枠・看板・灯り）→ レールと トロッコ・鉱石の 山 → 下って いく 坑道（支柱と 灯り）→ 水晶の 脇坑 2本 → 奥の 広間（場面の 場所: m.hall）*/
const MBEAM = (P, a, h) => [F(a, -2, h, a, -2, h + 2, P.log), F(a, 2, h, a, 2, h + 2, P.log), F(a, -2, h + 3, a, 2, h + 3, P.plank), S1(a, 0, h + 2, HANG(P))];
/* 第127版(fac): 縦の 輪（水車・歯車・滑車）。a-h の 面の 円（b は 一定）*/
const RAH = (a0, b, h0, r, bl) => { const o = [], seen = new Set(); for (let k = 0; k < 16; k++) { const t = (k * Math.PI) / 8, a = a0 + Math.round(Math.cos(t) * r), h = h0 + Math.round(Math.sin(t) * r), id = `${a},${h}`; if (seen.has(id)) continue; seen.add(id); o.push(S1(a, b, h, bl)); } return o; };
const BIG = {
  minetunnel: { fb: "mine", D: [12, 14, 16], box: [-2, -8, 25, 8], H: 1, look: [0, 0, 1.6], marks: { hall: [21, 0, -3], vein: [24, 0, -1.5], mouth: [0, 0, 0] }, build: (P) => [
    F(0, -7, 0, 24, 7, 5, P.rock), F(3, -6, 6, 21, 6, 6, P.rock), F(7, -4, 7, 17, 4, 7, P.rock), F(0, -7, 5, 24, 7, 5, P.ground, "replace " + P.rock),
    F(-1, -6, -5, 25, 6, -1, P.rock, "keep"),
    F(0, -2, 0, 6, 2, 3, "air"), F(0, -2, -1, 6, 2, -1, P.bed), F(7, -2, -1, 12, 2, 2, "air"), F(7, -2, -2, 12, 2, -2, P.bed), F(13, -2, -2, 17, 2, 1, "air"), F(13, -2, -3, 17, 2, -3, P.bed),
    F(18, -5, -3, 25, 5, 2, "air"), F(18, -5, -4, 25, 5, -4, P.bed),
    F(8, 3, -1, 10, 7, 1, "air"), F(8, 3, -2, 10, 7, -2, P.bed), F(11, 3, -1, 11, 7, 1, "amethyst_block"), F(8, 8, -1, 10, 8, 1, "calcite"), S1(9, 7, -1, "amethyst_cluster"), S1(10, 5, 1, "amethyst_block"), S1(9, 6, 0, "lantern"),
    F(14, -7, -2, 16, -3, 0, "air"), F(14, -7, -3, 16, -3, -3, P.bed), F(14, -8, -2, 16, -8, 0, "calcite"), F(17, -7, -2, 17, -3, 0, "amethyst_block"), S1(15, -7, -2, "amethyst_cluster"), S1(14, -6, -1, P.ore), S1(15, -4, -2, "lantern"),
    ...MBEAM(P, 0, 0), ...MBEAM(P, 3, 0), ...MBEAM(P, 6, 0), ...MBEAM(P, 9, -1), ...MBEAM(P, 12, -1), ...MBEAM(P, 15, -2),
    F(-1, -2, 4, -1, 2, 4, P.plank), S1(-1, 0, 5, "red_wool"), S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 3, 0, P.fence), S1(-1, 3, 1, P.lamp),
    F(-4, 0, -1, 6, 0, -1, "gravel"), F(-4, 0, 0, 6, 0, 0, "RA"), F(18, -2, -3, 23, -2, -3, "RA"), S1(-3, 2, 0, P.ore), S1(-3, 3, 0, P.ore), S1(-2, 3, 0, "coal_block"), S1(-2, -3, 0, "barrel"), S1(5, 2, 0, P.ore), S1(5, -2, 0, "barrel"),
    F(25, -5, -3, 25, 5, 1, "calcite"), F(25, -3, -2, 25, 3, 0, "amethyst_block"), S1(24, -4, -3, "amethyst_cluster"), S1(24, 4, -3, "amethyst_cluster"), S1(24, 0, -3, "chest"),
    S1(19, -5, 0, "shroomlight"), S1(19, 5, 0, "shroomlight"), S1(24, -5, 0, "shroomlight"), S1(24, 5, 0, "shroomlight"), S1(21, 0, 2, "shroomlight"),
    F(20, -3, -3, 22, 3, -3, "moss_carpet"), S1(22, -4, -3, "glow_lichen"), S1(20, 4, -3, "glow_lichen"),
    ["e", -2, 0, 0, "chest_minecart"], ["e", 3, 0, 0, "minecart"], ["e", 20, -2, -3, "minecart"],
  ] },
  /* 第127版(fac): 物語の 大きな 施設（20〜36 マス。pad = 足もとを 平らに ならして から 建てる。fill は 1回 32768 以下・数十本）*/
  /* 涸れ谷の 水門: 両側の 岩の 谷・石積みの 岸の 水路（手前は 乾いた 砂の 川床・鉄柵の 手すり）・高い 石の 塔 2本と 上の 渡り橋・巻き上げの 胴と 鎖・下りた 木の 門・塔の 横の 歯車・奥は 水を ためた 池・池の 端の 水車と 水車小屋 */
  sluicegate: { pad: 1, fb: "sluice", D: [12, 14, 16], box: [-1, -15, 36, 15], H: 16, look: [15, 0, 4], marks: { gate: [15, 0, 1], deck: [16, 0, 10], wheel: [22, 8, 1], front: [-2, 0, 0], bed: [8, 0, -4] }, build: (P) => [
    F(0, -15, 0, 36, -12, 5, P.rock), F(6, -15, 6, 36, -13, 8, P.rock), F(0, 13, 0, 36, 15, 5, P.rock), F(6, 13, 6, 36, 15, 8, P.rock), S1(2, -12, 6, P.trim), S1(9, -12, 9, P.trim), S1(4, 12, 6, P.trim), S1(11, 12, 9, P.trim),
    F(0, -5, -6, 36, 5, -1, P.wall), F(0, -4, -5, 36, 4, -1, "air"), F(0, -4, -5, 15, 4, -5, P.bed),
    S1(3, -2, -4, P.plant), S1(6, 3, -4, P.plant), S1(10, -3, -4, P.plant), S1(12, 1, -4, P.plant), S1(5, 0, -4, P.trim), S1(9, 2, -4, "gravel"), S1(13, -1, -4, P.trim),
    F(0, -5, 0, 13, -5, 0, "iron_bars"), F(0, 5, 0, 13, 5, 0, "iron_bars"),
    F(18, -9, -6, 36, 7, -1, P.wall), F(18, -8, -5, 36, 6, -1, "water"), F(17, -4, -5, 17, 4, -1, "water"), F(18, -9, 0, 36, -9, 0, P.trim), F(18, 7, 0, 21, 7, 0, P.trim),
    F(14, -9, -6, 18, -5, 12, P.wall), F(14, 5, -6, 18, 9, 12, P.wall), F(14, -9, 4, 18, -5, 4, P.trim), F(14, 5, 4, 18, 9, 4, P.trim), F(14, -9, 13, 18, -5, 13, "stone_brick_wall"), F(14, 5, 13, 18, 9, 13, "stone_brick_wall"),
    S1(14, -7, 8, "iron_bars"), S1(14, 7, 8, "iron_bars"), S1(14, -7, 2, "iron_bars"), S1(14, 7, 2, "iron_bars"), S1(13, -9, 6, P.lamp), S1(13, 9, 6, P.lamp),
    F(14, -4, 9, 18, 4, 9, P.wall), F(14, -4, 10, 14, 4, 10, P.fence), F(18, -4, 10, 18, 4, 10, P.fence), F(16, -3, 10, 16, 3, 10, P.log), S1(16, -4, 11, P.lamp), S1(16, 4, 11, P.lamp),
    F(16, -2, 1, 16, -2, 8, "chain"), F(16, 2, 1, 16, 2, 8, "chain"),
    F(16, -4, -5, 16, 4, 0, P.plank), F(15, -4, -4, 15, 4, -4, "iron_bars"), F(15, -4, -1, 15, 4, -1, "iron_bars"),
    ...RAH(16, -10, 6, 3, P.log), ...RAH(16, -10, 6, 1, "polished_blackstone"), S1(16, -10, 6, "iron_block"), ...RAH(13, -10, 9, 2, P.log), S1(13, -10, 9, "polished_blackstone"),
    F(19, 9, 0, 25, 12, 5, P.plank), F(20, 10, 0, 24, 11, 4, "air"), F(19, 9, 0, 19, 9, 5, P.log), F(25, 9, 0, 25, 9, 5, P.log), F(19, 12, 0, 19, 12, 5, P.log), F(25, 12, 0, 25, 12, 5, P.log),
    F(18, 8, 6, 26, 13, 6, P.slab), F(20, 10, 7, 24, 11, 7, P.slab), S1(19, 10, 0, "air"), S1(19, 10, 1, "air"), S1(19, 11, 2, "glass_pane"), S1(22, 10, 3, HANG(P)), S1(23, 11, 0, "grindstone"), S1(21, 11, 0, "barrel"),
    ...RAH(22, 7, 1, 3, P.plank), S1(22, 7, 1, P.log), F(22, 8, 1, 22, 8, 1, P.log),
    F(3, -11, 0, 7, -11, 0, P.cloth), F(3, -7, 0, 7, -7, 0, P.cloth), F(3, -10, 1, 7, -10, 1, P.cloth), F(3, -8, 1, 7, -8, 1, P.cloth), F(3, -9, 2, 7, -9, 2, P.cloth2),
    S1(9, -10, 0, "barrel"), S1(9, -9, 0, "barrel"), S1(10, -10, 0, "barrel"), S1(1, -8, 0, "campfire"), S1(-1, -6, 0, P.fence), S1(-1, -6, 1, P.lamp), S1(-1, 6, 0, P.fence), S1(-1, 6, 1, P.lamp),
  ], st: {
    1: (P) => [F(16, -4, -5, 16, 4, -4, "air"), F(15, -4, -4, 15, 4, -4, "air"), F(16, -4, 1, 16, 4, 2, P.plank), S1(14, -3, -4, "water")],   /* 半分 開ける（門の 下が あいて、手前の 川床に 水が 少し 流れ出る）*/
    2: (P) => [F(16, -4, -5, 16, 4, 2, "air"), F(15, -4, -1, 15, 4, -1, "air"), F(16, -4, 3, 16, 4, 8, P.plank), F(0, -4, -5, 15, 4, -3, "water")],   /* 全部 開ける（川床が 水で 満ちる）*/
  } },
  /* 鉱山（炭鉱）: 段に なった 岩山・山肌の 坑口（太い 木の 枠・看板・灯り）・中へ 続く レールの 坑道（支柱）→ 奥の 広間（鉱脈）・山の 上の 立坑の やぐら（滑車と 鎖）・手前の 積み場（板の 台・樽・鉱石・小さな 起重機）・脇の 線の トロッコ・左右の ずり山 */
  minehead: { pad: 1, fb: "minetunnel", D: [12, 14, 16], box: [-1, -15, 34, 15], H: 24, look: [11, 0, 3], marks: { hall: [30, 0, 0], vein: [33, 0, 1.5], mouth: [11, 0, 0], head: [29, 0, 20], yard: [4, 0, 0], cart: [3, -6, 0] }, build: (P) => [
    F(12, -15, 0, 34, 15, 3, P.rock), F(12, -15, 3, 34, 15, 3, P.ground), F(15, -13, 4, 34, 13, 7, P.rock), F(15, -13, 7, 34, 13, 7, P.ground), F(19, -10, 8, 34, 10, 10, P.rock), F(19, -10, 10, 34, 10, 10, P.ground), F(24, -7, 11, 34, 7, 12, P.rock), F(24, -7, 12, 34, 7, 12, P.ground),
    S1(12, -11, 2, P.ore), S1(12, 9, 1, "coal_ore"), S1(12, -7, 1, "coal_ore"), S1(15, 10, 5, P.ore), S1(19, -6, 9, "coal_ore"), S1(12, 13, 2, P.trim), S1(15, -11, 6, P.trim),
    F(12, -2, 0, 27, 2, 4, "air"), F(12, -2, -1, 27, 2, -1, P.bed), F(27, -7, 0, 33, 7, 6, "air"), F(27, -7, -1, 33, 7, -1, P.bed),
    F(11, -3, 0, 11, -3, 5, P.log), F(11, 3, 0, 11, 3, 5, P.log), F(11, -4, 6, 11, 4, 6, P.log), F(9, -4, 7, 12, 4, 7, P.slab), F(10, -1, 5, 10, 1, 5, P.plank), S1(10, -2, 4, HANG(P)), S1(10, 2, 4, HANG(P)),
    ...MBEAM(P, 14, 0), ...MBEAM(P, 18, 0), ...MBEAM(P, 22, 0), ...MBEAM(P, 26, 0),
    F(30, -4, 0, 30, -4, 5, P.log), F(30, 4, 0, 30, 4, 5, P.log), F(30, -4, 6, 30, 4, 6, P.plank), F(34, -3, 1, 34, 3, 3, P.ore), S1(33, -5, 0, "chest"), S1(33, 5, 0, "barrel"), S1(28, -6, 3, HANG(P)), S1(28, 6, 3, HANG(P)), S1(32, 0, 5, "shroomlight"),
    F(-1, 0, -1, 11, 0, -1, P.bed), F(-1, 0, 0, 31, 0, 0, "RA"), F(1, -6, -1, 9, -6, -1, P.bed), F(1, -6, 0, 9, -6, 0, "RA"),
    F(2, 3, 0, 8, 6, 0, P.plank), S1(3, 5, 1, "barrel"), S1(4, 5, 1, "barrel"), S1(6, 5, 1, P.ore), S1(7, 5, 1, P.ore), S1(7, 4, 1, "coal_block"), S1(6, 4, 1, P.ore), F(8, 6, 1, 8, 6, 5, P.log), F(5, 6, 5, 7, 6, 5, P.plank), S1(5, 6, 4, "chain"), S1(5, 6, 3, HANG(P)),
    F(1, -14, 0, 9, -9, 1, "gravel"), F(3, -13, 2, 7, -10, 3, "gravel"), S1(5, -12, 4, "gravel"), S1(2, -9, 0, "cobblestone"), S1(8, -13, 1, "cobblestone"),
    F(1, 9, 0, 9, 14, 1, "cobblestone"), F(3, 10, 2, 7, 13, 3, "gravel"), S1(5, 11, 4, "coal_ore"), S1(8, 9, 0, "gravel"),
    F(27, -3, 13, 27, -3, 23, P.log), F(27, 3, 13, 27, 3, 23, P.log), F(31, -3, 13, 31, -3, 23, P.log), F(31, 3, 13, 31, 3, 23, P.log),
    F(27, -3, 18, 31, -3, 18, P.fence), F(27, 3, 18, 31, 3, 18, P.fence), F(27, -3, 18, 27, 3, 18, P.fence), F(31, -3, 18, 31, 3, 18, P.fence), F(27, -3, 24, 31, 3, 24, P.slab),
    ...RAH(29, 0, 27, 2, P.log), S1(29, 0, 27, "polished_blackstone"), F(29, 0, 6, 29, 0, 12, "air"), F(29, 0, 7, 29, 0, 23, "chain"), S1(27, 0, 25, P.lamp), S1(31, 0, 25, P.lamp),
    S1(-1, -4, 0, P.fence), S1(-1, -4, 1, P.lamp), S1(-1, 4, 0, P.fence), S1(-1, 4, 1, P.lamp),
    ["e", 3, -6, 0, "chest_minecart"], ["e", 6, -6, 0, "minecart"], ["e", 5, 0, 0, "minecart"], ["e", 29, 0, 0, "minecart"],
  ], st: { 1: (P) => [S1(10, -2, 4, "shroomlight"), S1(10, 2, 4, "shroomlight"), S1(11, -3, 6, "shroomlight"), S1(11, 3, 6, "shroomlight")] } },   /* こけの 光が もどる（坑口が 光る）*/
  /* 鉄の 運び道: 乾いた 溝を 渡る 木の 架け橋（脚と 筋かい）の 上の レール・両側の 砂利の 土手・鉱石の 積み込み塔（落とし口）・トロッコ・合図の 灯り・樽 */
  haulyard: { pad: 1, fb: "haul", D: [10, 12, 14], box: [-1, -17, 14, 17], H: 10, look: [6, 0, 1.6], marks: { track: [6, 0, 1], bin: [10, 11.5, 3] }, build: (P) => [
    F(2, -7, -4, 10, 7, -1, "air"), F(2, -7, -5, 10, 7, -5, P.bed), S1(4, -3, -4, P.plant), S1(8, 4, -4, P.plant), S1(6, 2, -4, P.trim),
    F(5, -17, 0, 7, -8, 0, "gravel"), F(5, 8, 0, 7, 17, 0, "gravel"), F(5, -7, 0, 7, 7, 0, P.plank),
    F(5, -6, -4, 5, -6, -1, P.log), F(5, -3, -4, 5, -3, -1, P.log), F(5, 0, -4, 5, 0, -1, P.log), F(5, 3, -4, 5, 3, -1, P.log), F(5, 6, -4, 5, 6, -1, P.log),
    F(7, -6, -4, 7, -6, -1, P.log), F(7, -3, -4, 7, -3, -1, P.log), F(7, 0, -4, 7, 0, -1, P.log), F(7, 3, -4, 7, 3, -1, P.log), F(7, 6, -4, 7, 6, -1, P.log),
    F(5, -6, -2, 5, 6, -2, P.fence), F(7, -6, -2, 7, 6, -2, P.fence), F(5, -7, 1, 5, 7, 1, P.fence), F(7, -7, 1, 7, 7, 1, P.fence),
    F(6, -16, 1, 6, 16, 1, "RB"), S1(6, -17, 1, P.log), S1(6, 17, 1, P.log),
    F(8, 10, 1, 12, 13, 6, P.plank, "hollow"), F(8, 10, 1, 8, 10, 7, P.log), F(12, 10, 1, 12, 10, 7, P.log), F(8, 13, 1, 8, 13, 7, P.log), F(12, 13, 1, 12, 13, 7, P.log), F(7, 9, 8, 13, 14, 8, P.slab),
    F(7, 11, 4, 7, 12, 4, P.slab), S1(7, 11, 3, "hopper"), S1(9, 9, 1, P.ore), S1(10, 9, 1, P.ore), S1(9, 9, 2, P.ore), S1(11, 9, 1, "coal_block"), S1(8, 11, 4, HANG(P)),
    S1(3, -9, 1, "barrel"), S1(3, -10, 1, "barrel"), S1(2, -9, 1, "barrel"), S1(3, -9, 2, "barrel"), F(1, -12, 0, 3, -12, 0, P.log),
    F(9, -14, 1, 9, -14, 3, P.fence), S1(9, -14, 4, P.lamp), F(9, 15, 1, 9, 15, 3, P.fence), S1(9, 15, 4, P.lamp), F(3, -15, 1, 3, -15, 2, P.fence), S1(3, -15, 3, "redstone_lamp"),
    ["e", 6, -12, 1, "chest_minecart"], ["e", 6, -10, 1, "minecart"], ["e", 6, 13, 1, "minecart"],
  ] },
  /* 六影の 鋳造所（火山の 洞くつ）: 黒い 岩山・六影の 印の ある 坑口 → 大きな 洞（梁・鎖・灯り）。床を 横切る 溶けた 鉄の 流れ（ガラスの 下の 溶岩）・奥の 炉の 列と 煙道・溶けた 鉄の るつぼ・金床・半分の 台座・刀かけ */
  forgecave: { pad: 1, D: [12, 14, 16], box: [-1, -14, 30, 14], H: 16, look: [3, 0, 2], marks: { floor: [14, 0, 0], forge: [26, 0, 1.6], ped: [22, -5, 1.1], sword: [18, 5, 0.4], beam: [20, 0, 1], flow: [16.5, 0, 0], door: [3, 0, 0] }, build: (P) => [
    F(4, -14, 0, 30, 14, 12, P.rock), F(4, -14, 10, 30, -12, 12, "air"), F(4, 12, 10, 30, 14, 12, "air"), F(6, -11, 13, 28, 11, 14, P.rock), F(10, -7, 15, 25, 7, 16, P.rock), F(14, -3, 17, 21, 3, 17, P.rock),
    S1(4, -9, 3, "magma"), S1(4, 8, 6, "magma"), S1(4, -5, 9, "magma"), S1(4, 11, 2, "magma"), F(4, -13, 4, 4, -10, 4, "basalt"), F(4, 9, 8, 4, 12, 8, "basalt"),
    F(3, -2, 0, 9, 2, 4, "air"), F(3, -2, -1, 9, 2, -1, "polished_blackstone"), F(3, -3, 0, 3, -3, 5, "polished_blackstone_bricks"), F(3, 3, 0, 3, 3, 5, "polished_blackstone_bricks"), F(3, -3, 5, 3, 3, 5, "polished_blackstone_bricks"),
    F(2, -4, 0, 2, -4, 3, "purpur_pillar"), S1(2, -4, 4, "soul_lantern"), F(2, 4, 0, 2, 4, 3, "purpur_pillar"), S1(2, 4, 4, "soul_lantern"),
    F(10, -11, 0, 28, 11, 9, "air"), F(10, -11, -1, 28, 11, -1, "polished_blackstone"), F(10, -11, 9, 28, -10, 9, P.rock), F(10, 10, 9, 28, 11, 9, P.rock), S1(14, -6, 8, "basalt"), S1(23, 7, 8, "basalt"), S1(18, -9, 8, "pointed_dripstone"),
    F(16, -11, -2, 17, 11, -2, "lava"), F(16, -11, -1, 17, 11, -1, "orange_stained_glass"), F(15, -11, -1, 15, 11, -1, "blackstone"), F(18, -11, -1, 18, 11, -1, "blackstone"),
    F(28, -10, 0, 28, 10, 8, "polished_blackstone_bricks"), F(27, -9, 0, 27, -4, 0, "blast_furnace"), F(27, 4, 0, 27, 9, 0, "blast_furnace"), F(27, -9, 1, 27, -4, 2, "brick_block"), F(27, 4, 1, 27, 9, 2, "brick_block"),
    F(27, -7, 3, 27, -6, 8, "brick_block"), F(27, 6, 3, 27, 7, 8, "brick_block"), S1(27, -6, 1, "magma"), S1(27, 6, 1, "magma"),
    F(25, 6, 0, 26, 9, 1, "polished_blackstone_bricks"), S1(25, 7, 2, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'), S1(25, 8, 2, 'cauldron ["cauldron_liquid"="lava","fill_level"=6]'), F(25, 7, 3, 25, 7, 8, "chain"),
    S1(23, 2, 0, "anvil"), S1(23, 4, 0, "grindstone"), S1(24, -2, 0, "smithing_table"),
    F(21, -6, 0, 23, -4, 0, "polished_blackstone"), S1(22, -5, 1, "iron_bars"), S1(21, -6, 1, "chain"), S1(23, -4, 1, "stone_button"),
    F(11, 11, 1, 15, 11, 3, "iron_bars"), S1(12, 10, 0, "barrel"), S1(13, 10, 0, "barrel"), S1(11, -10, 0, "barrel"), S1(11, -9, 0, "barrel"), S1(12, -10, 0, "coal_block"),
    F(12, -11, 8, 12, 11, 8, "dark_oak_log"), F(20, -11, 8, 20, 11, 8, "dark_oak_log"), F(24, -11, 7, 24, 11, 7, "dark_oak_log"), F(12, 0, 4, 12, 0, 7, "chain"), F(20, -5, 5, 20, -5, 7, "chain"), F(20, 5, 5, 20, 5, 7, "chain"),
    S1(12, 0, 3, 'lantern ["hanging"=true]'), S1(20, -5, 4, 'lantern ["hanging"=true]'), S1(20, 5, 4, 'lantern ["hanging"=true]'), S1(14, -10, 2, "shroomlight"), S1(14, 10, 2, "shroomlight"), S1(24, -10, 3, "shroomlight"), S1(24, 10, 3, "shroomlight"), S1(10, 0, 8, "shroomlight"),
  ] },
  /* 薬草の 森の 野営地（ピピの 天幕）: 布の 天幕 2張り（寝床・薬の 本）・石で 囲んだ 焚き火と 丸太の 腰かけ・薬草を 干す 棚・荷車・木箱・灯りの 柱 */
  campsite: { pad: 1, fb: "tent", D: [10, 12, 14], box: [-1, -11, 14, 11], H: 6, look: [5, -6, 1], marks: { tent: [5, -6, 0.3], fire: [4, 1, 0], rack: [11, 0, 1] }, build: (P) => [
    F(0, -11, -1, 14, 11, -1, "coarse_dirt", "replace grass_block"), F(1, -2, -1, 7, 4, -1, "dirt_path", "replace coarse_dirt"),
    F(2, -10, 0, 8, -10, 0, P.cloth), F(2, -4, 0, 8, -4, 0, P.cloth), F(2, -9, 1, 8, -9, 1, P.cloth), F(2, -5, 1, 8, -5, 1, P.cloth), F(2, -8, 2, 8, -8, 2, P.cloth), F(2, -6, 2, 8, -6, 2, P.cloth), F(2, -7, 3, 8, -7, 3, P.cloth2),
    F(8, -9, 0, 8, -5, 2, P.cloth), F(9, -7, 0, 9, -7, 3, P.log), F(1, -7, 0, 1, -7, 3, P.log), S1(5, -7, 0, "white_carpet"), S1(6, -6, 0, "white_carpet"), S1(7, -8, 0, "lectern"), S1(6, -8, 0, 'lantern'),
    F(9, 5, 0, 13, 5, 0, P.cloth), F(9, 9, 0, 13, 9, 0, P.cloth), F(9, 6, 1, 13, 6, 1, P.cloth), F(9, 8, 1, 13, 8, 1, P.cloth), F(9, 7, 2, 13, 7, 2, P.cloth2), F(13, 6, 0, 13, 8, 1, P.cloth), S1(11, 7, 0, "white_carpet"),
    S1(4, 1, 0, "campfire"), S1(3, 1, -1, "cobblestone"), F(3, -1, 0, 5, -1, 0, P.log), F(6, 0, 0, 6, 2, 0, P.log), S1(2, 3, 0, P.log),
    F(11, -3, 0, 11, -3, 2, P.fence), F(11, 3, 0, 11, 3, 2, P.fence), F(11, -2, 2, 11, 2, 2, P.fence), S1(11, -1, 1, "hay_block"), S1(11, 1, 1, "hay_block"), S1(10, 0, 0, "composter"),
    F(1, 8, 0, 3, 10, 0, P.plank), S1(1, 8, 1, "barrel"), S1(2, 10, 1, "barrel"), S1(3, 8, 1, "flower_pot"), S1(0, 7, 0, "chest"), S1(0, 10, 0, "crafting_table"),
    S1(-1, -3, 0, P.fence), S1(-1, -3, 1, P.lamp), S1(-1, 4, 0, P.fence), S1(-1, 4, 1, P.lamp), S1(13, 0, 0, P.fence), S1(13, 0, 1, P.lamp),
  ] },
  /* セプルクの 古い 芝居小屋: 崩れかけた 石の 囲い・客席の 長いす・2段の 板の 舞台・木の 額縁と 上がった 赤い 幕・舞台の 奥の 壁と 屋根・石に なった 道化の 一座（まん中が 一人ぶん 空く）・灯り */
  theatre: { pad: 1, fb: "b03stage", D: [10, 12, 14], box: [-1, -12, 24, 12], H: 12, look: [16, 0, 3], marks: { gap: [18, 0, 3.2], stage: [18, 0, 2], seats: [6, 0, 0], door: [0, 0, 0] }, build: (P) => [
    F(0, -11, -1, 23, 11, -1, "stone_bricks"), F(1, -10, -1, 12, 10, -1, "cracked_stone_bricks", "replace stone_bricks"),
    F(0, -12, 0, 13, -12, 4, P.wall), F(0, 12, 0, 13, 12, 4, P.wall), F(3, -12, 3, 6, -12, 4, "air"), F(8, 12, 2, 10, 12, 4, "air"), F(0, -12, 0, 0, -3, 2, P.wall), F(0, 3, 0, 0, 12, 2, P.wall), F(0, -12, 3, 0, -9, 3, P.wall), F(0, 9, 3, 0, 12, 3, P.wall),
    F(2, -9, 0, 2, -2, 0, "spruce_slab"), F(2, 2, 0, 2, 9, 0, "spruce_slab"), F(4, -9, 0, 4, -2, 0, "spruce_slab"), F(4, 2, 0, 4, 9, 0, "spruce_slab"), F(6, -9, 0, 6, -2, 0, "spruce_slab"), F(6, 2, 0, 6, 9, 0, "spruce_slab"),
    F(8, -9, 0, 8, -2, 0, "spruce_slab"), F(8, 2, 0, 8, 9, 0, "spruce_slab"), F(10, -9, 0, 10, -2, 0, "spruce_slab"), F(10, 2, 0, 10, 9, 0, "spruce_slab"), S1(6, 5, 0, "air"), S1(8, -6, 0, "air"),
    F(14, -10, 0, 23, 10, 1, "spruce_planks"), F(13, -9, 0, 13, 9, 0, "spruce_slab"),
    F(14, -11, 0, 14, -11, 10, "dark_oak_log"), F(14, 11, 0, 14, 11, 10, "dark_oak_log"), F(14, -11, 11, 14, 11, 11, "dark_oak_log"),
    F(14, -10, 4, 14, -7, 10, "red_wool"), F(14, 7, 4, 14, 10, 10, "red_wool"), F(14, -6, 10, 14, 6, 10, "red_wool"), S1(14, -6, 9, "red_wool"), S1(14, 6, 9, "red_wool"),
    F(24, -12, 0, 24, 12, 11, P.wall), F(15, -12, 0, 23, -12, 10, P.wall), F(15, 12, 0, 23, 12, 10, P.wall), F(14, -12, 12, 24, 12, 12, "dark_oak_slab"), F(19, -12, 5, 21, -12, 7, "air"),
    F(23, -8, 2, 23, 8, 8, "dark_oak_planks"), F(22, -7, 2, 22, -5, 6, "light_gray_wool"), F(22, 5, 2, 22, 7, 6, "light_gray_wool"),
    S1(17, -4, 2, "cobblestone_wall"), S1(17, -4, 3, "stone"), S1(18, -2, 2, "cobblestone_wall"), S1(18, -2, 3, "stone"), S1(18, 2, 2, "cobblestone_wall"), S1(18, 2, 3, "stone"), S1(17, 4, 2, "cobblestone_wall"), S1(17, 4, 3, "stone"),
    S1(20, -6, 2, "cobblestone_wall"), S1(20, -6, 3, "stone"), S1(20, 6, 2, "cobblestone_wall"), S1(20, 6, 3, "stone"), S1(19, -3, 4, "stone_button"), S1(17, 4, 4, "stone_button"),
    S1(18, 0, 2, "white_carpet"), S1(21, 0, 2, "lectern"), S1(16, -9, 2, "barrel"), S1(16, 9, 2, "chest"),
    S1(19, -5, 10, 'lantern ["hanging"=true]'), S1(19, 5, 10, 'lantern ["hanging"=true]'), S1(19, 0, 10, 'lantern ["hanging"=true]'),
    F(-1, -4, 0, -1, -4, 2, P.fence), S1(-1, -4, 3, P.lamp), F(-1, 4, 0, -1, 4, 2, P.fence), S1(-1, 4, 3, P.lamp), S1(12, -11, 0, P.fence), S1(12, -11, 1, P.lamp), S1(12, 11, 0, P.fence), S1(12, 11, 1, P.lamp),
  ] },
};
/* 第127版(fac): 小さすぎた 形の 置きかえ（前の 版で 建てた ものは、近くに 人が 来た ときに 片づけて 新しい 形を 建てなおす）*/
const UPK = { sluice: "sluicegate", minetunnel: "minehead", haul: "haulyard", tent: "campsite", b03stage: "theatre" };   /* 村の 広場の 小さな 坑道の 入口（mine）は そのまま */
/* 第127版(fac2): 場所（キー）ごとの 置きかえ（facsets.js が 登録。key → 新しい 大きな 形。前の 形は その 形の fb）*/
const KUP = {};
export function facUp(key, kind) { if (BIG[kind] || SHAPES[kind]) KUP[key] = kind; }
export function facBig(kind, def) { if (!kind || !def || typeof def.build !== "function" || BIG[kind] || SHAPES[kind]) return false; BIG[kind] = { pad: 1, D: [12, 14, 16], H: 6, look: [0, 0, 1], ...def }; return true; }
/* 大きな 形が 町・城・ステージに かかる（すみの どこかが 近い）ときは 建てない */
function padBad(pts) {
  for (const q of pts) {
    for (const t of TOWNS) { try { const g = getTown(t.id), w = g && g.built ? g : townPos(t); if (Math.hypot(w.x - q.x, w.z - q.z) < 52) return true; } catch {} }
    for (let i = 0; i < WREGIONS.length; i++) { try { const c = castleSpot(i); if (c && Math.hypot(c.x - q.x, c.z - q.z) < 82) return true; } catch {} try { for (const L of landSites(i)) if (Math.hypot(L.x - q.x, L.z - q.z) < 36) return true; } catch {} }
  }
  return false;
}
/* ---------- 置く 場所 ---------- */
const card = (f) => (Math.abs(f.x) >= Math.abs(f.z) ? { x: Math.sign(f.x) || 1, z: 0 } : { x: 0, z: Math.sign(f.z) || 1 });
const W = (o, fa, a, b) => ({ x: o.x + a * fa.x - b * fa.z, z: o.z + a * fa.z + b * fa.x });
const blk = (dim, x, y, z) => { try { return dim.getBlock({ x, y, z }) || null; } catch { return null; } };
function tooNear(x, z, small = false, gap = 14) {
  for (const t of TOWNS) { try { const g = getTown(t.id), q = g && g.built ? g : townPos(t); if (Math.hypot(q.x - x, q.z - z) < 42) return true; } catch {} }
  for (let i = 0; i < WREGIONS.length; i++) { try { const c = castleSpot(i); if (c && Math.hypot(c.x - x, c.z - z) < 60) return true; } catch {} try { for (const L of landSites(i)) if (Math.hypot(L.x + 14 - x, L.z + 6 - z) < 26) return true; } catch {} }
  if (!small) try { const L = J("mrpg:epdeco:faclist") || []; for (const k of L) { const v = facAt(k); if (v && Math.hypot(v.x - x, v.z - z) < gap) return true; } } catch {}   /* 焚き火（small）は 小屋の そばでも よい */
  return false;
}
/* 舞台の 奥で 平らで 乾いた 所（原点・向き・高さ）。見つからなければ null */
function site(dim, S, sh, y0) {
  const fa = card(S.f), [a0, b0, a1, b1] = sh.box, sides = [0, ...(sh.side || [5, -5, 9, -9])];
  let PL = []; try { PL = dim.getPlayers().map((q) => q.location); } catch {}
  for (const D of sh.D) for (const sb of sides) {
    const c = S.at(D, sb), o = { x: Math.floor(c.x), z: Math.floor(c.z) };
    const pts = []; for (const a of [a0, (a0 + a1) >> 1, a1]) for (const b of [b0, (b0 + b1) >> 1, b1]) pts.push(W(o, fa, a, b));
    { const nr = sh.near || 6.5; if (pts.some((q) => Math.hypot(q.x - S.Cn.x, q.z - S.Cn.z) < nr || Math.hypot(q.x - S.P.x, q.z - S.P.z) < nr - 0.5)) continue; }   /* 第125版(pl): 鍛冶場・店先は 人の すぐ 後ろ（near）*/
    const ctr = W(o, fa, (a0 + a1) / 2, (b0 + b1) / 2); if (tooNear(ctr.x, ctr.z, !!sh.small, sh.gap || 14)) continue;
    if (sh.pad && padBad(pts)) continue;   /* 第127版(fac): 大きな 形は すみまで 町・城・ステージから 離す */
    if (overFac(o, fa, sh)) continue;   /* 第127版(fac2): ほかの 施設の 四角に かからない（ならす・空ける とき 削らない）*/
    if (PL.some((l) => { const dx = l.x - o.x, dz = l.z - o.z, a = dx * fa.x + dz * fa.z, b = -dx * fa.z + dz * fa.x; return a >= a0 - 2 && a <= a1 + 2 && b >= b0 - 2 && b <= b1 + 2; })) continue;   /* マルチ: ほかの 人が 立って いる 所には 建てない */
    let bad = false; const ys = [];
    for (const q of pts) { let g = null; try { g = groundY(dim, q.x, q.z, y0 + (sh.pad ? 10 : 6)); } catch {} if (typeof g !== "number" || Math.abs(g - y0) > (sh.pad ? 9 : 3)) { bad = true; break; } if (sh.pad) { ys.push(y0); continue; } const d = blk(dim, q.x, g - 1, q.z), u = blk(dim, q.x, g, q.z); if (!d || d.isLiquid || /water|lava|ice/.test(d.typeId) || (u && u.isLiquid)) { bad = true; break; } ys.push(g); }   /* 第127版(fac): pad の 形は 段差 9 まで（足もとを ならす。高さは 舞台に そろえる）*/
    if (bad) continue;
    if (sh.pad && sh.core) {   /* 第127版(fac2): 前の 形（核）の 所は 前と 同じ 決まり（段差 3 まで・水の 上や そばに 建てない）。核の 置き場所を 前と そろえる */
      const [c0, d0, c1, d1] = sh.core;
      for (const a of [c0, (c0 + c1) >> 1, c1]) { for (const b of [d0, (d0 + d1) >> 1, d1]) { const q = W(o, fa, a, b); let g = null; try { g = groundY(dim, q.x, q.z, y0 + 6); } catch {} if (typeof g !== "number" || Math.abs(g - y0) > 3) { bad = true; break; } const d = blk(dim, q.x, g - 1, q.z), u = blk(dim, q.x, g, q.z); if (!d || d.isLiquid || /water|lava|ice/.test(d.typeId) || (u && u.isLiquid)) { bad = true; break; } } if (bad) break; }
      if (!bad) for (const [a, b] of [[c0 - 2, d0 - 2], [c0 - 2, d1 + 2], [c1 + 2, d0 - 2], [c1 + 2, d1 + 2]]) { const q = W(o, fa, a, b), w = blk(dim, q.x, y0 - 1, q.z), w2 = blk(dim, q.x, y0, q.z); if ((w && w.isLiquid) || (w2 && w2.isLiquid)) { bad = true; break; } }
      if (bad) continue;
    }
    if (!sh.pad) for (const [a, b] of [[a0 - 2, b0 - 2], [a0 - 2, b1 + 2], [a1 + 2, b0 - 2], [a1 + 2, b1 + 2]]) { const q = W(o, fa, a, b), w = blk(dim, q.x, y0 - 1, q.z), w2 = blk(dim, q.x, y0, q.z); if ((w && w.isLiquid) || (w2 && w2.isLiquid)) { bad = true; break; } }   /* そばに 水が ない */
    if (bad) continue;
    ys.sort((a, b) => a - b);
    return { o: { x: o.x, y: ys[ys.length >> 1], z: o.z }, f: fa };
  }
  return null;
}
/* ops を ワールドの コマンドに */
function cmds(ops, R) {
  const { o, f } = R, out = [], ents = [], ra = f.x ? 1 : 0, rb = f.x ? 0 : 1;
  for (const op of ops) {
    if (op[0] === "e") { const q = W(o, f, op[1], op[2]); ents.push(`summon ${op[4]} ${q.x + 0.5} ${o.y + op[3]} ${q.z + 0.5}`); continue; }
    const [, a0, b0, h0, a1, b1, h1, bl0, m] = op; if (!bl0) continue;
    const bl = bl0 === "RA" ? `rail ["rail_direction"=${ra}]` : bl0 === "RB" ? `rail ["rail_direction"=${rb}]` : bl0;
    const p0 = W(o, f, a0, b0), p1 = W(o, f, a1, b1);
    out.push(`fill ${p0.x} ${o.y + h0} ${p0.z} ${p1.x} ${o.y + h1} ${p1.z} ${bl}${m ? ` ${m}` : ""}`);
  }
  return out.concat(ents);
}
const run = (dim, L) => { let n = 0; for (const c of L) { try { dim.runCommand(c); n++; } catch {} } return n; };
/* 第127版(fac2): 建てる コマンドは 1 tick に 40 本まで 流す（大きな 施設で 一度に 重く ならない。順番は 守る）*/
const SQ = []; let SQI = false;
function sqTick() { SQI = false; let n = 0; while (SQ.length && n < 40) { const q = SQ[0]; try { q.dim.runCommand(q.L[q.i]); } catch {} q.i++; n++; if (q.i >= q.L.length) SQ.shift(); } if (SQ.length && !SQI) { SQI = true; system.runTimeout(sqTick, 1); } }
function stream(dim, L) { let i = 0; if (!SQ.length) for (; i < L.length && i < 40; i++) { try { dim.runCommand(L[i]); } catch {} } if (i < L.length) { SQ.push({ dim, L, i }); if (!SQI) { SQI = true; system.runTimeout(sqTick, 1); } } }
export const facBusy = () => SQ.length > 0;
export const __fac = { SHAPES, BIG, cmds, site, palOf, card, W, UPK, KUP, sqTick };
/* 第126版: 章ファイルが 自分の 施設の 形を 足す（facBuild・facSide・fac で 使える）。def = { D: [奥], box: [a0,b0,a1,b1], H, look: [a,b,h], build: (P) => ops, st?, marks?, side?, near?, small? }
   ops は FAC_OPS.F(a0,b0,h0, a1,b1,h1, ブロック, モード?)・FAC_OPS.S1(a,b,h, ブロック)。大きさは 400 ブロック まで（こえると 警告）。同じ 名前は 上書きしない */
export const FAC_OPS = { F, S1, HANG, WCAUL };
export function facAdd(key, def) {
  if (!key || !def || typeof def.build !== "function" || !Array.isArray(def.box)) { console.warn(`[MonsterRPG] facAdd: 形が ちがう ${key}`); return false; }
  if (SHAPES[key] || BIG[key]) { console.warn(`[MonsterRPG] facAdd: ${key} は もう ある`); return false; }
  const sh = { D: [16, 19], H: 4, look: [0, 0, 1], ...def };
  try { let n = 0; for (const o of sh.build(palOf(0))) if (o && o[0] === "f" && o[7] !== "air") n += (Math.abs(o[4] - o[1]) + 1) * (Math.abs(o[5] - o[2]) + 1) * (Math.abs(o[6] - o[3]) + 1); if (n > 400) console.warn(`[MonsterRPG] facAdd: ${key} が 大きい（${n} ブロック）`); } catch {}
  SHAPES[key] = sh; return true;
}
/* 第125版(pl): 世界の 依頼の 場所の 名前 → 建てる 形（名前の ない 野の 場所は 道しるべ）*/
const WQK = [[/川上の灯り台/, "lamptower"], [/溶岩の崖/, "lavacliff"], [/竜骨の峰/, "bonepeak"], [/竜骨/, "bones"], [/岩棚/, "ledge"], [/鏡石/, "mirrors"], [/赤い花/, "redhill"], [/祈りの丘/, "whitehill"], [/庭/, "garden"], [/星見の丘/, "oldtree"], [/窪地/, "hollow"],
  [/氷の洞/, "icecave"], [/雲の井戸/, "cloudwell"], [/岩礁|入り江/, "reef"], [/川/, "brook"], [/ばら/, "roses"], [/岩場|岩山|峰/, "rocks"],   /* 第125版(tp): 文に 出る 地形（崖・川・岩・骨・花）*/
  [/かざぐるま/, "windmill"], [/書庫/, "library"], [/ふいご/, "bellows"], [/山小屋/, "cabin2"], [/家|小屋/, "hut"], [/焼けた/, "burnt"], [/麦畑|畑の?$/, "field"], [/ばら/, "roses"],
  [/池/, "pond"], [/ほこら|祠/, "hokora"], [/祭壇/, "altar"], [/墓/, "graves"], [/坑道/, "minetunnel"], [/洞|割れ目|心臓/, "cave"], [/灯台/, "lighthouse"], [/星見台/, "observatory"], [/見張り台|灯り台/, "tower"], [/井戸/, "well"],
  [/試し/, "arena"], [/水路/, "channel"], [/野営/, "tent"], [/浜|入り江|岩礁/, "beachcamp"], [/枯れ|林/, "deadwood"]];
export function wqKind(nm) { const t = String(nm || "").replace(/\s/g, "").replace(/^.*の外れの/, ""); for (const [re, k] of WQK) if (re.test(t)) return k; return "waypost"; }
export const facKind = (key) => { const v = J(`mrpg:epdeco:${key}at`); return v && v.k ? v.k : null; };   /* 第125版(tp): 記録した 形 */
/* 第125版(tp): 同じ 場所（原点・向き）で 形を かえる（前の 形を 空けて から 建てる。遠くて 読まれて いない ときは しない）*/
export function facSwap(key, kind, r) {
  const v = J(`mrpg:epdeco:${key}at`), old = v && (SHAPES[v.k] || BIG[v.k]), sh = SHAPES[kind] || BIG[kind]; if (!v || !Array.isArray(v.o) || !old || !sh || !near48(v)) return false;
  const dim = world.getDimension("overworld"), R = { o: { x: v.o[0], y: v.o[1], z: v.o[2] }, f: { x: v.f[0], z: v.f[1] } }, P = palOf(r), [a0, b0, a1, b1] = sh.box, [c0, d0, c1, d1] = old.box;
  stream(dim, cmds([F(c0, d0, 0, c1, d1, old.H || 4, "air"), F(a0, b0, -5, a1, b1, -1, P.base, "keep"), F(a0, b0, -1, a1, b1, -1, P.ground), F(a0, b0, 0, a1, b1, sh.H || 4, "air")].concat(sh.build(P)), R));
  const lk = W(R.o, R.f, sh.look[0], sh.look[1]), at = { x: lk.x + 0.5, y: R.o.y + sh.look[2], z: lk.z + 0.5, o: v.o, f: v.f, k: kind, r };
  if (sh.marks) { at.m = {}; for (const [n, [a, b, h]] of Object.entries(sh.marks)) { const q = W(R.o, R.f, a, b); at.m[n] = [q.x + 0.5, R.o.y + h, q.z + 0.5]; } }
  P_(`mrpg:epdeco:${key}at`, at); return true;
}

/* 建てる（ワールドに 1回）。返す 値は 見る 点。r: 地方（色）*/
export function facBuild(p, S, key, kind, r, y0) {
  kind = KUP[key] || UPK[kind] || kind;
  const had = facAt(key); if (had) { if (!stale(key)) return had; retire(key); }   /* 第127版(fac): 前の 小さな 形は 片づけて 建てなおす */
  let sh = SHAPES[kind] || BIG[kind]; if (!sh || !S || !S.f || !p) return null;
  const dim = p.dimension; try { if (dim.id !== "minecraft:overworld") return null; } catch { return null; }
  let R = site(dim, S, sh, Math.floor(y0)), fbk = 0; for (let n = 0; !R && sh.fb && n < 2; n++) { kind = sh.fb; sh = SHAPES[kind] || BIG[kind]; fbk = 1; if (!sh) return null; R = site(dim, S, sh, Math.floor(y0)); } if (!R) return null;   /* 第125版(pl): 大きな 坑道が 入らない 所は 小さな 入口（第127版: 2段まで）*/
  const P = palOf(r), [a0, b0, a1, b1] = sh.box, H = sh.H || 4;
  const pre = sh.pad ? [F(a0 - 1, b0 - 1, -8, a1 + 1, b1 + 1, -4, P.base, "replace air"), F(a0 - 1, b0 - 1, -8, a1 + 1, b1 + 1, -4, P.base, "replace water"), F(a0 - 1, b0 - 1, -3, a1 + 1, b1 + 1, -2, P.base), F(a0 - 1, b0 - 1, -1, a1 + 1, b1 + 1, -1, P.ground), F(a0 - 1, b0 - 1, 0, a1 + 1, b1 + 1, H, "air")]   /* 第127版(fac): 足もとを ならす（穴・水を うめ、上を 空ける）*/
    : [F(a0, b0, -5, a1, b1, -1, P.base, "keep"), F(a0, b0, -1, a1, b1, -1, P.ground), F(a0, b0, 0, a1, b1, H, "air")];   /* 土台（穴だけ うめる）・地面・上を 空ける */
  let L = cmds(pre.concat(sh.build(P)), R);
  if (sh.st) { const cur = facStage(key); for (let s = 1; s <= cur; s++) if (sh.st[s]) L = L.concat(cmds(sh.st[s](P), R)); }
  stream(dim, L);   /* 第127版(fac): 建てなおした ときは 話の 進み（門を 開けた など）を そのまま */
  const lk = W(R.o, R.f, sh.look[0], sh.look[1]), at = { x: lk.x + 0.5, y: R.o.y + sh.look[2], z: lk.z + 0.5, o: [R.o.x, R.o.y, R.o.z], f: [R.f.x, R.f.z], k: kind, r, ...(fbk ? { fb: 1 } : {}) };
  if (sh.marks) { at.m = {}; for (const [n, [a, b, h]] of Object.entries(sh.marks)) { const q = W(R.o, R.f, a, b); at.m[n] = [q.x + 0.5, R.o.y + h, q.z + 0.5]; } }   /* 網など 場面で 映す 点 */
  P_(`mrpg:epdeco:${key}at`, at);
  try { const L = J("mrpg:epdeco:faclist") || []; if (!L.includes(key)) { L.push(key); P_("mrpg:epdeco:faclist", L); } } catch {}
  return { x: at.x, y: at.y, z: at.z };
}
/* 第125版(pl): 舞台の 横（side マス）に 建てる（場面の とちゅうで 移る 先: 坑道の 奥 など）。front は 施設の 前（舞台を 置く 点）*/
export function facSide(p, S, side, key, kind, r, y0) {
  const had = facAt(key, p.location, 90); if (had && !stale(key)) return had;
  if (!S || !S.f) return null; const f = S.f, P = S.at(0, side), at = (a, b, dy = 0) => ({ x: P.x + f.x * a - f.z * b, y: P.y + dy, z: P.z + f.z * a + f.x * b });
  return facBuild(p, { P, f, at, Cn: at(2.5, 0) }, key, kind, r, y0);
}
export function facFront(key, k = 5) { const v = J(`mrpg:epdeco:${key}at`); if (!v || !Array.isArray(v.o)) return null; return { x: v.o[0] - v.f[0] * k + 0.5, y: v.o[1], z: v.o[2] - v.f[1] * k + 0.5 }; }
/* 場面から 呼ぶ: 記録が あれば それ、なければ 舞台の 奥に 建てる */
export function fac(K, p, key, kind, r, y0) { try { const near = facAt(key, p.location, 72); if (near && !stale(key)) return near; const S = K.S(p); return S ? facBuild(p, S, key, kind, r, y0) : null; } catch { return null; } }

/* ---------- 状態（段階は 下がらない）---------- */
function applySt(key, want) {
  const v = J(`mrpg:epdeco:${key}at`); if (!v || !Array.isArray(v.o)) return false;
  const sh = SHAPES[v.k] || BIG[v.k]; if (!sh || !sh.st) return true;
  const dim = world.getDimension("overworld"); let cur = 0; try { cur = Number(world.getDynamicProperty(`mrpg:epdeco:${key}st`) || 0); } catch {}
  const R = { o: { x: v.o[0], y: v.o[1], z: v.o[2] }, f: { x: v.f[0], z: v.f[1] } }, P = palOf(v.r);
  for (let s = cur + 1; s <= want; s++) if (sh.st[s]) stream(dim, cmds(sh.st[s](P), R));
  try { world.setDynamicProperty(`mrpg:epdeco:${key}st`, Math.max(cur, want)); } catch {}
  return true;
}
const near48 = (v) => { try { return world.getAllPlayers().some((q) => q.dimension.id === "minecraft:overworld" && Math.hypot(q.location.x - v.x, q.location.z - v.z) < 48); } catch { return false; } };
export function facStage(key) { try { return Number(world.getDynamicProperty(`mrpg:epdeco:${key}st`) || 0); } catch { return 0; } }
export function facState(key, want) {
  if (facStage(key) >= want) return;
  const v = facAt(key);
  if (v && near48(v)) { applySt(key, want); return; }
  const pend = J("mrpg:epdeco:facpend") || {}; pend[key] = Math.max(pend[key] || 0, want); P_("mrpg:epdeco:facpend", pend);   /* まだ 建って いない・遠い: あとで */
}
/* 第127版(fac): 前の 版の 小さな 形（UPK）を 片づける。記録を 消して、片づける 場所の 表（facold）に 入れる。だれかが 48マス 以内に 来た ときに 1つずつ 消す */
function stale(key) { const v = J(`mrpg:epdeco:${key}at`); if (!v || !v.k || v.fb) return false; return KUP[key] ? v.k !== KUP[key] : !!UPK[v.k]; }   /* 大きな 形が 入らず 小さな 形に した 所（fb）は そのまま */
/* 第127版(fac2): 記録が あって 新しい 形の ときだけ（前の 小さな 形なら null。呼んだ 側が 建てなおす）*/
export function facRec(key) { const v = J(`mrpg:epdeco:${key}at`); return v && !stale(key) ? v : null; }   /* 記録（前の 小さな 形なら null）*/
export function facCur(key, near = null, R = 72) { const v = facAt(key, near, R); return v && !stale(key) ? v : null; }
function retire(key) {
  const v = J(`mrpg:epdeco:${key}at`); if (!v || !Array.isArray(v.o)) return;
  const L = J("mrpg:epdeco:facold") || []; if (L.length < 40) L.push({ k: v.k, o: v.o, f: v.f, r: v.r, x: v.x, z: v.z }); P_("mrpg:epdeco:facold", L);
  P_(`mrpg:epdeco:${key}at`, undefined);
}
/* 施設の 四角（ワールドの x0,z0,x1,z1）と、四角から 四角を 引いた 残り（0〜4 個）*/
function overFac(o, f, sh) {
  if (!sh.pad) return false;   /* 小さな 形は 前と 同じ（間の あき gap だけ）*/
  const A = wrect(o, f, sh.box, sh.pad ? 2 : 1);
  try { for (const k of J("mrpg:epdeco:faclist") || []) { const v = J(`mrpg:epdeco:${k}at`), s2 = v && (SHAPES[v.k] || BIG[v.k]); if (!s2 || !Array.isArray(v.o) || Math.hypot(v.o[0] - o.x, v.o[2] - o.z) > 120) continue; const B = wrect({ x: v.o[0], z: v.o[2] }, { x: v.f[0], z: v.f[1] }, s2.box, s2.pad ? 1 : 0); if (!(B[0] > A[2] || B[2] < A[0] || B[1] > A[3] || B[3] < A[1])) return true; } } catch {}
  return false;
}
const wrect = (o, f, b, m = 0) => { const p0 = W(o, f, b[0], b[1]), p1 = W(o, f, b[2], b[3]); return [Math.min(p0.x, p1.x) - m, Math.min(p0.z, p1.z) - m, Math.max(p0.x, p1.x) + m, Math.max(p0.z, p1.z) + m]; };
const rsub = (A, B) => { if (B[0] > A[2] || B[2] < A[0] || B[1] > A[3] || B[3] < A[1]) return [A]; const o = []; if (A[1] < B[1]) o.push([A[0], A[1], A[2], B[1] - 1]); if (A[3] > B[3]) o.push([A[0], B[3] + 1, A[2], A[3]]); const z0 = Math.max(A[1], B[1]), z1 = Math.min(A[3], B[3]); if (A[0] < B[0]) o.push([A[0], z0, B[0] - 1, z1]); if (A[2] > B[2]) o.push([B[2] + 1, z0, A[2], z1]); return o; };
function clearOld(q) {
  const sh = SHAPES[q.k] || BIG[q.k]; if (!sh) return true; const dim = world.getDimension("overworld"), o = { x: q.o[0], y: q.o[1], z: q.o[2] }, f = { x: q.f[0], z: q.f[1] }, P = palOf(q.r), y = q.o[1];
  try { if (!dim.getBlock({ x: q.o[0], y: q.o[1], z: q.o[2] })) return false; } catch { return false; }
  /* 第127版(fac2): 新しい 施設が 重なる ときは、重なる 所を よけて 残りだけ 消す（前は 44マス 以内なら 何も 消さなかった）*/
  let rs = [wrect(o, f, sh.box)];
  try { for (const k of J("mrpg:epdeco:faclist") || []) { const v = J(`mrpg:epdeco:${k}at`), s2 = v && (SHAPES[v.k] || BIG[v.k]); if (!s2 || !Array.isArray(v.o) || Math.hypot(v.o[0] - q.o[0], v.o[2] - q.o[2]) > 90) continue; const B = wrect({ x: v.o[0], z: v.o[2] }, { x: v.f[0], z: v.f[1] }, s2.box, s2.pad ? 2 : 1); rs = rs.flatMap((r) => rsub(r, B)); } } catch {}
  const L = []; for (const [x0, z0, x1, z1] of rs) L.push(`fill ${x0} ${y - 5} ${z0} ${x1} ${y - 2} ${z1} ${P.base} replace air`, `fill ${x0} ${y - 5} ${z0} ${x1} ${y - 2} ${z1} ${P.base} replace water`, `fill ${x0} ${y - 1} ${z0} ${x1} ${y - 1} ${z1} ${P.ground}`, `fill ${x0} ${y} ${z0} ${x1} ${y + Math.max(sh.H || 4, 8)} ${z1} air`);
  stream(dim, L);
  const inR = (l) => rs.some(([x0, z0, x1, z1]) => l.x >= x0 && l.x <= x1 + 1 && l.z >= z0 && l.z <= z1 + 1);
  try { for (const e of dim.getEntities({ location: { x: q.o[0] + 0.5, y: q.o[1], z: q.o[2] + 0.5 }, maxDistance: 16 })) if (/minecart|boat/.test(e.typeId) && inR(e.location)) e.remove(); } catch {}
  return true;
}
/* あとで かえる 分（5秒に 1回。ふだんは 記録を 1つ 読む だけ）*/
system.runInterval(() => {
  try { const L = J("mrpg:epdeco:facold"); if (L && L.length) { const i = L.findIndex((q) => q && Array.isArray(q.o) && near48(q)); if (i >= 0 && clearOld(L[i])) { L.splice(i, 1); P_("mrpg:epdeco:facold", L.length ? L : undefined); } } } catch {}
  let pend = null; try { const s = world.getDynamicProperty("mrpg:epdeco:facpend"); if (!s) return; pend = JSON.parse(s); } catch { return; }
  let left = 0;
  for (const k of Object.keys(pend)) { const v = facAt(k); if (facStage(k) >= pend[k]) { delete pend[k]; continue; } if (v && near48(v)) { applySt(k, pend[k]); delete pend[k]; } else left++; }
  P_("mrpg:epdeco:facpend", left ? pend : undefined);
}, 100);
