【マインクエスト 軽量版（Switch・スマホ向け）サーバー用パック】

1. サーバーの behavior_packs と resource_packs に、この zip の 中の 4つの フォルダを 入れる（同じ 名前の 古い フォルダは 消す）
2. ワールドの world_behavior_packs.json と world_resource_packs.json の "version" を [22, 101, 1] に かえる（4つの パック すべて）
3. サーバーを 起動しなおす。参加者には 軽量版が 自動で 送られます

もとの 版に もどす ときは 通常版の パックに 入れかえ、"version" を [22, 101, 0] に もどしてください。
