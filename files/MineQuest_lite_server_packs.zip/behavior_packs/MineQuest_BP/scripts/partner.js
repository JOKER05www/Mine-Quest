// v1.7: カスタム相棒（体・頭・顔・ツノ・つばさ・しっぽ・色・性格・初期スキルを 自分で きめる）
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, SKILLS, FAMILIES, NATURES, MOVES } from "./data.js";
import { autoSP } from "./menu.js";
import { makeMonster, calcStats, addMon, natureText, SKILL_N, sizeOf, ensureSkills, rankIdx } from "./core.js";
import { save, mark, allMons } from "./store.js";
import { TYPE, setLook, CUST_KEYS } from "./field.js";
import { choose, notice, confirm, modal, ICON, MON_ICON, LINE, sound, particle, ok, paged } from "./ui.js";
import { CNAMES } from "./cnames.js";

const B = (t, i) => [t, i];
const PART = [["cb", "体"], ["cs", "頭の形"], ["cf", "顔"], ["ch", "ツノ・かざり"], ["cw", "つばさ"], ["ct", "しっぽ"], ["cm", "マント"], ["cwp", "武器（見た目・装備すると その武器に）"], ["cc", "色"]];
const FAM_OK = () => FAMILIES.filter((f) => !["king", "god"].includes(f.id) && ORDER.some((x) => SPECIES[x].fam === f.id));
// 系統の もとになる モンスター（能力・耐性・技の もと）: いちばん 低い ランクの Mサイズ
export function baseOf(fam) {
  const pool = ORDER.filter((x) => { const s = SPECIES[x]; return !s.hidden && s.fam === fam && !s.special && !s.special4 && !s.metalmon && !s.giant; });
  pool.sort((a, b) => rankIdx(a) - rankIdx(b) || ((SPECIES[a].sz === "M" ? 0 : 1) - (SPECIES[b].sz === "M" ? 0 : 1)));
  return pool[0];
}
// その 系統の モンスターが よく 持っている スキル（初期スキルの 候補）
function skillPool(fam) {
  const c = {};
  for (const x of ORDER) { const s = SPECIES[x]; if (s.fam !== fam) continue; for (const k of [...s.skills, ...(s.skx || [])]) if (SKILLS[k]) c[k] = (c[k] || 0) + 1; }
  return Object.keys(c).sort((a, b) => c[b] - c[a]).slice(0, 16);
}
const lookText = (lk) => PART.map(([k, n]) => `§7${n}: §f${(CNAMES[k] || [])[lk[k] || 0] || "-"}`).join("  ");
const rand = (n) => Math.floor(Math.random() * n);
export const randomLook = () => Object.fromEntries(CUST_KEYS.map((k) => [k, rand(CNAMES[k].length)]));
// v2.9.5: はじめの 見た目は すっきり（かざりは 多くても 1つ・武器と マントは なし）
export function simpleLook() {
  const lk = { cb: rand(5), cs: rand(5), cf: rand(4), ch: 0, cw: 0, ct: rand(3), cc: rand(CNAMES.cc.length), cwp: 0, cm: 0 };
  const extra = ["ch", "cw", "ct"][rand(3)];
  if (Math.random() < 0.5) lk[extra] = 1 + rand(Math.min(4, CNAMES[extra].length - 1));
  return lk;
}

// 目の前に 見本を 出す
function preview(p, sid, m, old) {
  let e = old;
  if (!ok(e)) {
    const yaw = (p.getRotation().y * Math.PI) / 180;
    const pos = { x: p.location.x - Math.sin(yaw) * 3, y: p.location.y, z: p.location.z + Math.cos(yaw) * 3 };
    try { e = p.dimension.spawnEntity(TYPE, pos); } catch { return null; }
    e.addTag("mrpg_temp"); e.addTag("mrpg_battle"); e.addTag("mrpg_preview");
    try { e.triggerEvent("mrpg:make_battle"); } catch {}
    try { e.teleport(pos, { facingLocation: p.location }); } catch {}
  }
  try { setLook(e, sid, m); e.nameTag = `§b${m.nm}`; particle(e, "minecraft:villager_happy"); } catch {}
  return e;
}
// ワールドを 開いた とき 残った 見本を 消す
system.runTimeout(() => { for (const id of ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"]) { try { for (const e of world.getDimension(id).getEntities({ type: TYPE, tags: ["mrpg_preview"] })) e.remove(); } catch {} } }, 90);

async function pickPart(p, k, title, cur) {
  const list = CNAMES[k];
  const s = await choose(p, title, "§7えらぶと 見本に すぐ 反映されます", [...list.map((n, i) => B(`${i === cur ? "§a● " : ""}${n}`, ICON("i_skill"))), B("§7戻る", ICON("i_back"))]);
  return s >= 0 && s < list.length ? s : cur;
}

// 作る（create=true）か、見た目と 名前を かえる（create=false）
export async function partnerEditor(p, d, existing = null) {
  const create = !existing;
  let fam = existing ? SPECIES[existing.sp].fam : null;
  if (create) {
    const fams = FAM_OK();
    const f = await paged(p, "相棒を つくる", "§f自分だけの 相棒モンスターを 作ろう！\n§7まず タイプ（系統）を 選んでください。能力・耐性・覚える 技の もとに なります。", fams.map((x) => B(`§l${x.name}\n§8もと: ${SPECIES[baseOf(x.id)]?.name || ""}`, MON_ICON(baseOf(x.id)))), 8);
    if (f < 0) return null;
    fam = fams[f].id;
  }
  const sid = existing ? existing.sp : baseOf(fam);
  const m = existing ? JSON.parse(JSON.stringify(existing)) : { ...makeMonster(sid, 1, false), look: randomLook() };
  if (create) { m.nm = "あいぼう"; m.look.cc = rand(CNAMES.cc.length); }
  let skills = create ? [...SPECIES[sid].skills].slice(0, SKILL_N.M) : m.sk;
  let e = preview(p, sid, m, null);
  try {
    for (;;) {
      const st = calcStats({ ...m, sk: skills, pts: skills.map(() => 0) });
      const body = [`§l§b${m.nm}§r  §7タイプ: ${FAMILIES.find((x) => x.id === fam)?.name || ""}（もと: ${SPECIES[sid].name}）`, lookText(m.look),
        create ? `§7性格: §f${natureText(m.nat)}` : "", create ? `§7初期スキル: §f${skills.map((k) => SKILLS[k]?.name).join(" / ")}` : "",
        create ? `§7Lv1の 能力: HP${st.hp} MP${st.mp} 物${st.atk} 硬${st.def} 魔${st.mat} 魔硬${st.mdf} 走${st.spd} 武${st.wpn} 吹${st.brt}  §e相棒ボーナス 全能力+10%・なんでも 装備できる` : "", LINE, "§7目の前に 見本が 出ています。"].filter(Boolean).join("\n");
      const btns = [...PART.map(([k, n]) => B(`${n}  §8${(CNAMES[k] || [])[m.look[k] || 0] || "-"}`, ICON("i_skill"))), B("§dおまかせ（ランダム）", ICON("i_fuse")), B("名前を つける", ICON("i_help"))];
      if (create) btns.push(B("性格", ICON("i_party")), B("初期スキル", ICON("i_spell")));
      btns.push(B(create ? "§a§lこの 相棒で きめる！" : "§a§lこの 見た目に する", ICON("i_party")), B("§7やめる", ICON("i_back")));
      // v3.0: 「きめる」を いちばん 上にも（上の ボタンを 押しつづけても 先へ 進める）
      const s0 = await choose(p, create ? "相棒を つくる" : "相棒の 見た目", body, [btns[btns.length - 2], ...btns]);
      const s = s0 === 0 ? btns.length - 2 : s0 < 0 ? -1 : s0 - 1;
      if (s < 0 || s === btns.length - 1) return null;
      if (s < PART.length) { const [k, n] = PART[s]; m.look[k] = await pickPart(p, k, n, m.look[k] || 0); }
      else if (s === PART.length) m.look = { ...randomLook(), cc: m.look.cc };
      else if (s === PART.length + 1) { const v = await modal(p, "名前", (f) => f.textField("相棒の 名前（10文字まで）", "あいぼう", m.nm)); if (v && String(v[0]).replace(/§/g, "").trim()) m.nm = Array.from(String(v[0]).replace(/§/g, "").trim()).slice(0, 10).join(""); }
      else if (create && s === PART.length + 2) {
        const n = await paged(p, "性格", "§7能力が ±10% かわります", NATURES.map((x, i) => B(`${i === m.nat ? "§a● " : ""}${natureText(i)}`, ICON("i_party"))), 9);
        if (n >= 0) m.nat = n;
      } else if (create && s === PART.length + 3) {
        const seen = new Set();
        const pool = [...new Set([...SPECIES[sid].skills, ...skillPool(fam)])].filter((k) => SKILLS[k]).sort((x, y) => (SKILLS[x].tier || 0) - (SKILLS[y].tier || 0)).filter((k) => { const l = SKILLS[k].line || k; if (seen.has(l)) return false; seen.add(l); return true; });
        const N = SKILL_N[sizeOf(m)] || 4;
        const v = await modal(p, `初期スキル（${N}つ まで）`, (f) => pool.forEach((k) => f.toggle(`${SKILLS[k].name} §7${SKILLS[k].list.filter((x) => x.move && MOVES[x.move]).slice(0, 2).map((x) => MOVES[x.move].name).join("・")}`, skills.includes(k))));
        if (v) {
          const pick = pool.filter((k, i) => v[i]);
          if (!pick.length) await notice(p, "初期スキル", "§c1つ 以上 えらんでください。");
          else { skills = pick.slice(0, N); if (pick.length > N) await notice(p, "初期スキル", `§e${N}つまでなので、上から ${N}つに しました。`); }
        }
      } else {
        // 決定
        if (create) {
          m.sk = skills; m.pts = skills.map(() => 0); ensureSkills(m);
          m.spl = Math.max(m.spl || 0, 10); m.partner = true; try { autoSP({ party: [m] }, "near", [m]); } catch {}   // v2.9.12: 最初の 子と 同じ 10（v3.0: 自動で 振って おく）
          const st2 = calcStats(m); m.hp = st2.hp; m.mp = st2.mp;
          const where = addMon(d, m);
          d.partnerId = d.partnerId || m.id;
          mark(d.own, m.sp); mark(d.seen, m.sp);
          save(p, d);
          sound(p, "random.levelup", 1.2); if (ok(e)) particle(e, "minecraft:totem_particle", 1);
          await notice(p, "相棒", `§e${m.nm}§f が 相棒に なった！ §7（${where === "party" ? "表の パーティ" : where === "bench" ? "控え" : "預かり所"}）\n§7見た目と 名前は 仲間 →「相棒」で いつでも かえられます。`);
          return m;
        }
        Object.assign(existing, { look: m.look, nm: m.nm });
        save(p, d);
        sound(p, "random.levelup", 1.4);
        return existing;
      }
      e = preview(p, sid, m, e);
    }
  } finally { if (ok(e)) try { e.remove(); } catch {} }
}
export function findPartner(d) { return allMons(d).find((m) => m.id === d.partnerId) || allMons(d).find((m) => m.look); }
