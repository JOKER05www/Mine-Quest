// 第115版: 相棒の おもちゃで ほんとうに 遊ぶ（24しゅるい・1回 6〜10秒）
// 動きは スクリプト（2tickごと・遊んで いる 人だけ）。物は mrpg:ball と 光の 粒（mrpg:orb など）で 見せる。相棒は teleport で 動かす
// 止まる とき: 人か 相棒が いなくなる・別の 次元・戦い・物語の 会話や 画面（あとから busy）・死んだ・はなれすぎ
import { world, system, MolangVariableMap } from "@minecraft/server";
import { busy, anim, barNote, isLite } from "./ui.js";
import { inBattle } from "./battle.js";

export const PLAYS = new Map();   /* pid -> S */
const TAG = "mrpg_toyb";
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const H = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const rnd = (a, b) => a + Math.random() * (b - a);
const C = { white: [1, 1, 1], sky: [0.7, 0.9, 1], gold: [1, 0.85, 0.3], red: [1, 0.35, 0.3], pink: [1, 0.6, 0.8], green: [0.5, 1, 0.5], brown: [0.6, 0.4, 0.2], tan: [0.85, 0.7, 0.45], cyan: [0.4, 1, 1], warm: [1, 0.6, 0.2], blue: [0.4, 0.6, 1], yellow: [1, 1, 0.4], purple: [0.8, 0.5, 1] };

// ---------- 小さな 道具 ----------
function fx(S, id, at, c = C.white, sc = 1) { try { const m = new MolangVariableMap(); m.setColorRGB("variable.color", { red: c[0], green: c[1], blue: c[2] }); m.setFloat("variable.scale", sc); S.dim.spawnParticle(`mrpg:${id}`, at, m); } catch {} }
const dot = (S, at, c, sc = 0.4) => fx(S, "orb", at, c, sc);
const lite = (S) => isLite() && (S.t & 2);   /* 軽量モードは 粒を 半分に */
function snd(S, id, pitch = 1, vol = 0.7, at) { try { S.dim.playSound(id, at || S.pet.location, { pitch, volume: vol }); } catch { try { S.p.playSound(id, { pitch, volume: vol }); } catch {} } }
const say = (S, t) => { try { barNote(S.p).setActionBar(t); } catch {} };
const vp = (S, f, r, y) => ({ x: S.o0.x + S.F.x * f + S.R.x * r, y: S.o0.y + y, z: S.o0.z + S.F.z * f + S.R.z * r });
const hand = (S) => { const l = S.p.location; return { x: l.x + S.F.x * 0.6 + S.R.x * 0.35, y: l.y + 1.2, z: l.z + S.F.z * 0.6 + S.R.z * 0.35 }; };
/* 0 = 空気・1 = かたい・2 = 水など */
function blk(S, x, y, z) { try { const b = S.dim.getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }); if (!b || b.isAir) return 0; if (b.isLiquid) return 2; return b.isSolid === false ? 0 : 1; } catch { return 0; } }
/* 地面の 高さ（水なら NaN・S.lqY に 水面）*/
function gy(S, x, z, y0) {
  S.lqY = NaN; const b0 = Math.floor(y0);
  for (let y = b0 + 2; y >= b0 - 4; y--) { const k = blk(S, x, y, z); if (k === 2) { S.lqY = y + 1; return NaN; } if (k === 1) return y + 1; }
  return NaN;
}
/* 相棒を (x,z) へ 少し 動かす。look を 見る。のこりの きょりを 返す */
function petAt(S, x, z, look, spd = 0.4, water = false) {
  const e = S.pet, l = e.location, dx = x - l.x, dz = z - l.z, d = Math.hypot(dx, dz);
  let nx = l.x, nz = l.z;
  if (d > 0.05) { const k = Math.min(spd, d) / d; nx += dx * k; nz += dz * k; }
  const cd = H({ x: nx, z: nz }, S.o0); if (cd > 12) { nx = S.o0.x + (nx - S.o0.x) * 12 / cd; nz = S.o0.z + (nz - S.o0.z) * 12 / cd; }   /* 遠くへは 行かない */
  let g = gy(S, nx, nz, S.gy);
  if (Number.isNaN(g)) { if (water && !Number.isNaN(S.lqY)) g = S.lqY - 0.5; else { nx = l.x; nz = l.z; g = S.gy; } }
  else if (Math.abs(g - S.gy) > 1.3) { nx = l.x; nz = l.z; g = S.gy; }   /* 段差が 大きい 所へは 行かない */
  S.gy = g;
  let y = g + (S.lift || 0);
  if (S.hop > 0) { S.hop -= 2; y += Math.sin(Math.PI * (1 - S.hop / S.hopN)) * S.hopH; }
  if (look) S.lk = look; else if (d > 0.1) S.lk = { x: x + dx, y: g + 0.6, z: z + dz };
  try { e.teleport({ x: nx, y, z: nz }, { facingLocation: S.lk || S.p.location }); } catch {}
  return Math.max(0, d - spd);
}
const stay = (S, look) => { const l = S.pet.location; return petAt(S, l.x, l.z, look, 0); };
function hop(S, h = 0.8, n = 8, a = "atk_jump") { if (S.hop > 0) return false; S.hop = n; S.hopN = n; S.hopH = h; if (a) anim(S.pet, a); return true; }
const air = (S) => (S.hop > 0 ? Math.sin(Math.PI * (1 - S.hop / S.hopN)) * S.hopH : 0);
function mouth(S) { const l = S.pet.location, lk = S.lk || S.p.location, dx = lk.x - l.x, dz = lk.z - l.z, d = Math.hypot(dx, dz) || 1; return { x: l.x + (dx / d) * 0.6, y: l.y + 0.7, z: l.z + (dz / d) * 0.6 }; }
function toyEnt(S, at) { let e = null; try { e = S.dim.spawnEntity("mrpg:ball", at); e.addTag(TAG); e.setDynamicProperty("mrpg:bown", S.p.id); } catch { return null; } S.ents.push(e); return e; }
const roll = (e, on) => { try { e.setProperty("mrpg:roll", on); } catch {} };
const tp = (e, at) => { if (okE(e)) try { e.teleport(at); } catch {} };
const hearts = (S, n = 1) => fx(S, "hearts", { x: S.pet.location.x, y: S.pet.location.y + 1, z: S.pet.location.z }, C.pink, n);
/* 投げた 物の 動き（2回に 分けて）。はねたら 1 */
function phys(S, o, g = 0.045, bo = 0.55, fr = 0.85) {
  let L = o.pos, v = o.v, ev = 0;
  for (let s = 0; s < 2; s++) {
    v.y -= g; v.x *= 0.985; v.z *= 0.985;
    let nx = L.x + v.x, ny = L.y + v.y, nz = L.z + v.z;
    if (blk(S, nx, L.y + 0.2, L.z) === 1) { v.x = -v.x * 0.5; nx = L.x; }
    if (blk(S, nx, L.y + 0.2, nz) === 1) { v.z = -v.z * 0.5; nz = L.z; }
    const k = v.y < 0 ? blk(S, nx, ny, nz) : 0;
    if (k === 2) { ny = Math.floor(ny) + 0.85; v.y = 0; v.x *= 0.8; v.z *= 0.8; }   /* 水に うく */
    else if (k === 1) { ny = Math.floor(ny) + 1; if (v.y < -0.12 && bo > 0) { v.y = -v.y * bo; ev = 1; } else { v.y = 0; v.x *= fr; v.z *= fr; } }
    else if (v.y > 0 && blk(S, nx, ny + 0.45, nz) === 1) v.y = -v.y * 0.4;
    L = { x: nx, y: ny, z: nz };
  }
  if (L.y < S.o0.y - 20) { L = { ...S.p.location }; v.x = v.y = v.z = 0; }   /* 落ちたら 手元へ */
  o.pos = L; o.rest = v.y === 0 && Math.hypot(v.x, v.z) < 0.02;
  if (o.e) tp(o.e, L);
  return ev;
}
function viewF(p) { let d = { x: 0, z: 1 }; try { d = p.getViewDirection(); } catch {} const h = Math.hypot(d.x, d.z) || 1; return { x: d.x / h, y: 0, z: d.z / h }; }

// ---------- 取って くる 遊び（ボール・ゴムまり・枝・円ばん）----------
function fetchPlay(cfg) {
  return {
    dur: cfg.dur || 200,
    init(S) { S.o = { st: "wait", w: 12, n: 0, t: 0 }; if (cfg.ent) { S.o.e = toyEnt(S, mouth(S)); } },
    step(S) {
      const o = S.o; o.t += 2;
      if (o.st === "wait") {
        if (o.e) tp(o.e, { ...S.p.location, y: S.p.location.y + 0.1 });
        stay(S, S.p.location); if (S.t % 20 === 0) anim(S.pet, "happy");
        if ((o.w -= 2) <= 0 && S.t < S.dur - 80) {
          const F = viewF(S.p), l = S.p.location; o.pos = { x: l.x + F.x * 0.8, y: l.y + 1.4, z: l.z + F.z * 0.8 }; o.v = cfg.vel(F); o.st = "fly"; o.t = 0; o.lap = 0;
          if (o.e) roll(o.e, true); snd(S, "random.bow", 1.3); say(S, `§e${cfg.th}`);
        }
        return;
      }
      if (o.st === "fly") {
        const ev = cfg.glide ? cfg.glide(S, o) : phys(S, o, cfg.g ?? 0.045, cfg.bo ?? 0.55);
        if (H(o.pos, S.o0) > 9) { o.v.x *= 0.5; o.v.z *= 0.5; }   /* 遠くへ 行きすぎない */
        if (ev) { snd(S, "random.pop", 0.7 + Math.random() * 0.4, 0.4, o.pos); if (cfg.onBounce) cfg.onBounce(S, o); }
        if (cfg.draw && !lite(S)) cfg.draw(S, o, true);
        const d = petAt(S, o.pos.x, o.pos.z, o.pos, 0.45), up = o.pos.y - S.gy;
        if (cfg.air && d < 1.6 && up > 1.2 && up < 3.2) hop(S, Math.min(1.6, up - 0.5), 10);
        if (d < 1.2 && o.t > 6 && up - air(S) < 1.3) {
          o.st = "back"; o.t = 0; if (o.e) roll(o.e, false); snd(S, "random.pop", 1.6);
          say(S, `§e§l${up > 0.9 ? "ジャンプキャッチ！" : "とった！"} §f${S.m.nm}が くわえた`); if (up > 0.9) fx(S, "star", o.pos, C.gold, 0.8);
        } else if (o.t > 140) { o.st = "back"; o.t = 0; }   /* 取りに いけない 所は あきらめる */
        return;
      }
      if (o.st === "back") {
        o.pos = mouth(S); if (o.e) tp(o.e, o.pos); else if (cfg.draw && !lite(S)) cfg.draw(S, o, false);
        if (cfg.lap && o.lap < 36) { o.lap += 2; const a = o.lap * 0.18, l = S.p.location; petAt(S, l.x + Math.cos(a) * 3, l.z + Math.sin(a) * 3, null, 0.5); if (o.lap % 12 === 0) hop(S, 0.5, 6, "happy"); return; }   /* 自まんの ひとまわり */
        if (S.t % 4 === 0) fx(S, "orb", { x: o.pos.x, y: o.pos.y + 0.8, z: o.pos.z }, C.yellow, 0.2);
        const d = petAt(S, S.p.location.x, S.p.location.z, S.p.location, 0.4);
        if (d < 1.8 || o.t > 160) { o.st = "wait"; o.w = 16; o.n++; anim(S.pet, "happy"); hearts(S); snd(S, "random.orb", 1.4); say(S, `§d${S.m.nm}が ${cfg.nm}を もって きた！ §7（${o.n}回目）`); }
      }
    },
  };
}

// ---------- 24の 遊び ----------
const P = {};
P.pt_ball = fetchPlay({ ent: true, nm: "ボール", th: "ボールを ぽーんと 投げた！", vel: (F) => ({ x: F.x * 0.42, y: 0.34, z: F.z * 0.42 }) });
P.pt_gomu = fetchPlay({ ent: true, nm: "ゴムまり", th: "ゴムまりが ぽよーんと はねる！", air: true, bo: 0.82, vel: (F) => ({ x: F.x * 0.2, y: 0.42, z: F.z * 0.2 }),
  onBounce(S, o) { o.v.x += rnd(-0.08, 0.08); o.v.z += rnd(-0.08, 0.08); if (H(S.pet.location, o.pos) < 4) hop(S, 0.6, 6); } });
P.pt_stick = fetchPlay({ nm: "枝", th: "枝を 遠くへ 投げた！", lap: true, bo: 0, vel: (F) => ({ x: F.x * 0.34, y: 0.36, z: F.z * 0.34 }),
  draw(S, o, fly) { const a = fly && !o.rest ? S.t * 0.6 : 0, c = Math.cos(a) * 0.4, s = Math.sin(a) * 0.4, ax = fly ? S.F : S.R;
    for (const k of [-1, 0, 1]) dot(S, { x: o.pos.x + ax.x * c * k, y: o.pos.y + 0.1 + s * k, z: o.pos.z + ax.z * c * k }, C.brown, 0.28); } });
P.pt_disc = fetchPlay({ nm: "円ばん", th: "円ばんが すーっと 飛んで いく！", air: true, vel: (F) => ({ x: F.x * 0.5, y: 0.2, z: F.z * 0.5 }),
  glide(S, o) { const a = 0.05, c = Math.cos(a), s = Math.sin(a), v = o.v; [v.x, v.z] = [v.x * c - v.z * s, v.x * s + v.z * c]; v.y -= 0.024;
    if (blk(S, o.pos.x + v.x, o.pos.y + v.y, o.pos.z + v.z) === 1) { v.x *= 0.3; v.z *= 0.3; v.y = 0; }
    o.pos = { x: o.pos.x + v.x, y: o.pos.y + v.y, z: o.pos.z + v.z }; const g = gy(S, o.pos.x, o.pos.z, o.pos.y); if (!Number.isNaN(g) && o.pos.y < g) { o.pos.y = g; v.x *= 0.5; v.z *= 0.5; }
    if (o.pos.y < S.o0.y - 20) o.pos = { ...S.p.location }; return 0; },
  draw(S, o) { for (let k = 0; k < 5; k++) { const a = (k / 5) * Math.PI * 2 + S.t * 0.3; dot(S, { x: o.pos.x + Math.cos(a) * 0.35, y: o.pos.y + 0.1, z: o.pos.z + Math.sin(a) * 0.35 }, C.cyan, 0.25); } } });

/* ころころ 鈴: 鳴りながら ころがる → 耳を すまして とびつく */
P.pt_bell = { dur: 180,
  init(S) { const at = vp(S, 1.5, 0, 0.2); S.o = { e: toyEnt(S, at), pos: at, v: { x: S.F.x * 0.25, y: 0.05, z: S.F.z * 0.25 }, n: 0, cd: 20 }; roll(S.o.e, true); },
  step(S) { const o = S.o; phys(S, o, 0.045, 0.3, 0.97);
    if (S.t % 10 === 0 && Math.hypot(o.v.x, o.v.z) > 0.03) { snd(S, "note.bell", rnd(1.4, 2), 0.5, o.pos); fx(S, "notes", o.pos, C.gold, 0.4); }
    if (!lite(S)) dot(S, { x: o.pos.x, y: o.pos.y + 0.5, z: o.pos.z }, C.gold, 0.25);
    const d = petAt(S, o.pos.x, o.pos.z, o.pos, d0(S, o) > 3 ? 0.3 : 0.18);
    if ((S.o.cd -= 2) < 0 && d < 2.2 && hop(S, 0.7, 10, "atk_claw")) { o.cd = 24; const a = Math.atan2(o.pos.z - S.pet.location.z, o.pos.x - S.pet.location.x) + rnd(-0.8, 0.8); o.v = { x: Math.cos(a) * 0.3, y: 0.15, z: Math.sin(a) * 0.3 }; o.n++; snd(S, "note.bell", 2, 0.8, o.pos); say(S, `§e${S.m.nm}が 鈴に とびついた！ §7ちりん（${o.n}）`); }
    if (H(o.pos, S.o0) > 8) { const a = Math.atan2(S.o0.z - o.pos.z, S.o0.x - o.pos.x); o.v.x = Math.cos(a) * 0.2; o.v.z = Math.sin(a) * 0.2; } } };
const d0 = (S, o) => H(S.pet.location, o.pos);

/* 毛糸だま: ころがすと 糸が のびる・そっと ねらって とびつく・最後は 糸に からまる */
P.pt_yarn = { dur: 200,
  init(S) { const at = vp(S, 1, 0, 0.3); S.o = { e: toyEnt(S, at), pos: at, v: { x: S.F.x * 0.3, y: 0.1, z: S.F.z * 0.3 }, tr: [], st: "stalk", n: 0 }; roll(S.o.e, true); snd(S, "random.bow", 1.5); },
  step(S) { const o = S.o; phys(S, o, 0.045, 0.2, 0.95); roll(o.e, Math.hypot(o.v.x, o.v.z) > 0.03);
    if (S.t % 6 === 0) { o.tr.push({ ...o.pos }); if (o.tr.length > (isLite() ? 8 : 16)) o.tr.shift(); for (const q of o.tr) dot(S, { x: q.x, y: q.y + 0.08, z: q.z }, C.pink, 0.22); }
    if (S.t > S.dur - 40) { /* からまる */ if (o.st !== "tangle") { o.st = "tangle"; anim(S.pet, "atk_spin"); say(S, `§d${S.m.nm}は 毛糸に からまって ころころ…`); } const l = S.pet.location; for (let k = 0; k < 3; k++) { const a = S.t * 0.5 + k * 2.1; dot(S, { x: l.x + Math.cos(a) * 0.7, y: l.y + 0.4 + k * 0.25, z: l.z + Math.sin(a) * 0.7 }, C.pink, 0.25); } stay(S, S.p.location); if (S.t % 12 === 0) anim(S.pet, "happy"); return; }
    const d = d0(S, o);
    if (o.st === "stalk") { petAt(S, o.pos.x, o.pos.z, o.pos, 0.12); if (d < 3.2 && (o.cd = (o.cd || 0) - 2) < 0) { o.st = "pounce"; hop(S, 1, 10); snd(S, "mob.cat.purreow", 1.3, 0.4); } }
    else { petAt(S, o.pos.x, o.pos.z, o.pos, 0.55); if (d < 1.2) { const a = Math.atan2(o.pos.z - S.o0.z, o.pos.x - S.o0.x) + rnd(-1.5, 1.5); o.v = { x: Math.cos(a) * 0.32, y: 0.12, z: Math.sin(a) * 0.32 }; o.st = "stalk"; o.cd = 26; o.n++; anim(S.pet, "atk_claw"); say(S, `§e${S.m.nm}が 毛糸だまを ころがした！ §7（${o.n}）`); } }
    if (H(o.pos, S.o0) > 7) { const a = Math.atan2(S.o0.z - o.pos.z, S.o0.x - o.pos.x); o.v.x = Math.cos(a) * 0.2; o.v.z = Math.sin(a) * 0.2; } } };

/* じゃらし: 先っぽが ゆらゆら → ねこぱんち・ジャンプ・最後に つかまえる */
P.pt_jara = { dur: 170,
  init(S) { S.o = { n: 0 }; },
  step(S) { const t = S.t, l = S.p.location, sw = Math.sin(t * 0.22), hi = Math.abs(Math.sin(t * 0.37));
    const tip = { x: l.x + S.F.x * 2.2 + S.R.x * sw * 1.6, y: l.y + 0.3 + hi * 1.5, z: l.z + S.F.z * 2.2 + S.R.z * sw * 1.6 };
    if (!lite(S)) { const h = hand(S); for (let k = 1; k <= 3; k++) dot(S, { x: h.x + (tip.x - h.x) * k / 4, y: h.y + (tip.y - h.y) * k / 4 + 0.3 * Math.sin(Math.PI * k / 4), z: h.z + (tip.z - h.z) * k / 4 }, C.tan, 0.15); }
    dot(S, tip, C.green, 0.45); dot(S, { x: tip.x, y: tip.y + 0.15, z: tip.z }, C.yellow, 0.3);
    if (t > S.dur - 30) { const d = petAt(S, tip.x, tip.z, tip, 0.4); if (!S.o.got && d < 1) { S.o.got = 1; anim(S.pet, "atk_bite"); snd(S, "random.pop", 1.8); say(S, `§e§l つかまえた！ §f${S.m.nm}は とくいげだ`); } return; }
    const d = petAt(S, tip.x - S.F.x * 0.6, tip.z - S.F.z * 0.6, tip, 0.35);
    if (d < 1.2 && tip.y - S.gy < 0.9 && S.t % 6 === 0) { anim(S.pet, "atk_claw"); S.o.n++; snd(S, "random.click", 1.6, 0.5); }
    else if (d < 1.5 && tip.y - S.gy > 1.3) hop(S, 0.9, 8); } };

/* つみ木: 1だんずつ つむ → 相棒が どーん！ → がらがら */
const BCOL = [C.red, C.yellow, C.blue, C.green, C.purple, C.warm];
P.pt_block = { dur: 170,
  init(S) { S.o = { c: vp(S, 2.6, 0, 0), n: 0, fall: null }; const g = gy(S, S.o.c.x, S.o.c.z, S.o0.y); if (!Number.isNaN(g)) S.o.c.y = g; },
  step(S) { const o = S.o, c = o.c;
    if (!o.fall) {
      if (S.t % 16 === 0 && o.n < 6) { o.n++; snd(S, "note.xylophone", 0.8 + o.n * 0.15, 0.6, c); say(S, `§eつみ木を つんだ §7（${o.n}だん）`); }
      if (S.t % 6 === 0) for (let k = 0; k < o.n; k++) dot(S, { x: c.x, y: c.y + 0.3 + k * 0.45, z: c.z }, BCOL[k], 0.55);
      const side = Math.sin(S.t * 0.15) * 0.5;   /* 首を かしげて 見て いる */
      if (o.n < 6) petAt(S, c.x - S.F.x * 2 + S.R.x * side, c.z - S.F.z * 2 + S.R.z * side, { x: c.x, y: c.y + o.n * 0.45, z: c.z }, 0.25);
      else { const d = petAt(S, c.x, c.z, c, 0.45); if (d < 1) { anim(S.pet, "atk_headbutt"); o.fall = []; for (let k = 0; k < o.n; k++) { const a = rnd(0, 6.28); o.fall.push({ pos: { x: c.x, y: c.y + 0.3 + k * 0.45, z: c.z }, v: { x: Math.cos(a) * 0.12, y: 0.15, z: Math.sin(a) * 0.12 }, k }); } fx(S, "sparks", c, C.gold, 0.5); snd(S, "mob.zombie.wood", 1.6, 0.6, c); say(S, `§e§lどーん！ §fがらがら〜 §7${S.m.nm}は 大よろこび`); } }
      return;
    }
    for (const b of o.fall) { phys(S, b, 0.04, 0.35); if (S.t % 4 === 0) dot(S, b.pos, BCOL[b.k], 0.5); }
    stay(S, c); if (S.t % 12 === 0) hop(S, 0.6, 8, "happy"); } };

/* ひっぱり ロープ: ぐいぐい 引いて 引かれて・最後は 相棒の 勝ち */
P.pt_rope = { dur: 170,
  init(S) { S.o = { w: 0 }; },
  step(S) { const t = S.t, end = t > S.dur - 36, l = S.p.location;
    const dist = end ? 2.6 + Math.min(2, (t - (S.dur - 36)) * 0.12) : 2.6 + Math.sin(t * 0.18) * 0.9;
    petAt(S, l.x + S.F.x * dist, l.z + S.F.z * dist, { x: l.x, y: l.y + 1, z: l.z }, 0.5);
    const h = hand(S), m = mouth(S), sag = Math.max(0, 0.5 - (dist - 2.6) * 0.4);
    if (!lite(S)) for (let k = 1; k < 6; k++) { const f = k / 6; dot(S, { x: h.x + (m.x - h.x) * f, y: h.y + (m.y - h.y) * f - Math.sin(Math.PI * f) * sag, z: h.z + (m.z - h.z) * f }, C.tan, 0.2); }
    if (!end && t % 22 === 0) { anim(S.pet, "atk_bite"); snd(S, "mob.wolf.growl", 1.8, 0.35); say(S, `§eぐいっ ぐいっ！ §f${S.m.nm}が ロープを ひっぱる`); }
    if (end && !S.o.w) { S.o.w = 1; anim(S.pet, "atk_charge"); snd(S, "random.bow", 0.8); }
    if (t === S.dur - 10) { anim(S.pet, "happy"); fx(S, "sparks", m, C.gold, 0.4); say(S, `§e§lひっぱりっこ ${S.m.nm}の 勝ち！`); } } };

/* かじり ほね: くわえて 見せびらかし（とれそうで とれない）→ 足元で かじかじ */
P.pt_bone = { dur: 180,
  init(S) { S.o = { tgt: null, w: 0 }; },
  step(S) { const o = S.o, l = S.p.location, m = mouth(S);
    if (S.t > S.dur - 50) { stay(S, l); dot(S, { x: m.x, y: m.y - 0.5, z: m.z }, C.white, 0.35); if (S.t % 8 === 0) { anim(S.pet, "atk_bite"); fx(S, "sparks", { x: m.x, y: m.y - 0.4, z: m.z }, C.white, 0.2); snd(S, "random.eat", 1.4, 0.4); } if (S.t === S.dur - 48) say(S, `§d${S.m.nm}は 足元で ほねを かじかじ…`); return; }
    if (!lite(S)) dot(S, m, C.white, 0.35);
    if (!o.tgt || (o.w -= 2) <= 0) {   /* ちかづいて きて、さっと にげる */
      const away = o.tgt && o.tgt.near; const a = rnd(0, 6.28), r = away ? 1.4 : rnd(3.5, 5);
      o.tgt = { x: l.x + Math.cos(a) * r, z: l.z + Math.sin(a) * r, near: !away }; o.w = 26;
      if (!away) { hop(S, 0.6, 8, "happy"); say(S, `§e${S.m.nm}は ほねを くわえて にげた！ §7とれるかな？`); }
    }
    const d = petAt(S, o.tgt.x, o.tgt.z, o.tgt.near ? null : l, o.tgt.near ? 0.5 : 0.3);
    if (d < 0.3 && S.t % 10 === 0) anim(S.pet, "atk_tail"); } };

/* ぬいぐるみ: だっこして ゆらゆら → いっしょに くるくる → ぎゅっ */
P.pt_doll = { dur: 170,
  init(S) { S.o = {}; },
  step(S) { const t = S.t, l = S.o0;
    if (t < 70) { const s = Math.sin(t * 0.2) * 0.3; petAt(S, l.x + S.F.x * 1.8 + S.R.x * s, l.z + S.F.z * 1.8 + S.R.z * s, { x: S.p.location.x + S.R.x * s * 3, y: l.y + 1, z: S.p.location.z + S.R.z * s * 3 }, 0.3); dot(S, mouth(S), C.pink, 0.5); if (t % 16 === 0) hearts(S, 0.6); if (t === 2) say(S, `§d${S.m.nm}は ぬいぐるみを だいて ゆらゆら…`); return; }
    if (t < S.dur - 30) { const a = (t - 70) * 0.09, c = vp(S, 2, 0, 0); petAt(S, c.x + Math.cos(a) * 1.6, c.z + Math.sin(a) * 1.6, null, 0.4); const pl = S.pet.location; dot(S, { x: pl.x + Math.cos(-a * 2) * 0.8, y: pl.y + 0.6, z: pl.z + Math.sin(-a * 2) * 0.8 }, C.pink, 0.5); if (t === 70) say(S, `§dぬいぐるみと いっしょに くるくる おどる`); if (t % 24 === 0) hop(S, 0.4, 6, "happy"); return; }
    stay(S, S.p.location); dot(S, mouth(S), C.pink, 0.5); if (t === S.dur - 30) { anim(S.pet, "happy"); hearts(S, 1.4); say(S, `§d${S.m.nm}は ぬいぐるみを ぎゅっ！`); snd(S, "random.orb", 1.2); } } };

/* ぷかぷか 水鳥: 水が あれば うかべて 泳いで 追いかける・なければ よちよち 行進 */
function findWater(S) {
  const c = S.o0;
  for (let r = 2; r <= 8; r += 2) for (let k = 0; k < 12; k++) {
    const a = (k / 12) * Math.PI * 2, x = c.x + Math.cos(a) * r, z = c.z + Math.sin(a) * r;
    for (let y = Math.floor(c.y) + 1; y >= Math.floor(c.y) - 4; y--) { const b = blk(S, x, y, z); if (b === 2) return { x: Math.floor(x) + 0.5, y: y + 0.85, z: Math.floor(z) + 0.5 }; if (b === 1) break; }
  }
  return null;
}
P.pt_duck = { dur: 200,
  init(S) { const w = findWater(S); S.o = { w, n: 0 }; S.o.pos = w ? { ...w } : vp(S, 2, 0, 0.1); S.o.v = { x: 0, z: 0 }; S.o.e = toyEnt(S, S.o.pos);
    say(S, w ? `§b水鳥を 水に うかべた！ §fぷかぷか…` : `§b水鳥が よちよち 歩きだした §7（水の そばで 使うと 水に うかべられる）`); },
  step(S) { const o = S.o, t = S.t;
    if (o.w) {
      o.v.x = o.v.x * 0.96 + rnd(-0.01, 0.01); o.v.z = o.v.z * 0.96 + rnd(-0.01, 0.01);
      const nx = o.pos.x + o.v.x, nz = o.pos.z + o.v.z;
      if (blk(S, nx, o.w.y - 0.3, nz) === 2 && H({ x: nx, z: nz }, o.w) < 4) { o.pos.x = nx; o.pos.z = nz; } else { o.v.x = -o.v.x; o.v.z = -o.v.z; }
      o.pos.y = o.w.y - 0.25 + Math.sin(t * 0.3) * 0.06; tp(o.e, o.pos);
      dot(S, { x: o.pos.x, y: o.pos.y + 0.45, z: o.pos.z }, C.yellow, 0.3); if (t % 12 === 0) fx(S, "circle", { x: o.pos.x, y: o.w.y - 0.05, z: o.pos.z }, C.sky, 0.5);
      const d = petAt(S, o.pos.x, o.pos.z, o.pos, 0.25, true);
      if (!Number.isNaN(S.lqY) && t % 6 === 0) try { S.dim.spawnParticle("minecraft:water_splash_particle", { x: S.pet.location.x, y: S.lqY, z: S.pet.location.z }); } catch {}
      if (d < 1.2 && t % 4 === 0) { const a = Math.atan2(o.pos.z - S.pet.location.z, o.pos.x - S.pet.location.x); o.v = { x: Math.cos(a) * 0.14, z: Math.sin(a) * 0.14 }; o.n++; snd(S, "note.pling", 1.9, 0.5, o.pos); snd(S, "random.splash", 1.4, 0.4); say(S, `§b${S.m.nm}が 水鳥を ちょんと おした！ §7ぷかっ（${o.n}）`); }
      return;
    }
    const a = t * 0.06, c = vp(S, 2.5, 0, 0), x = c.x + Math.cos(a) * 2.5, z = c.z + Math.sin(a) * 2.5, g = gy(S, x, z, o.pos.y);
    o.pos = { x, y: (Number.isNaN(g) ? o.pos.y : g) + Math.abs(Math.sin(t * 0.4)) * 0.25, z }; tp(o.e, o.pos); dot(S, { x, y: o.pos.y + 0.45, z }, C.yellow, 0.3);
    const b = a - 0.6; petAt(S, c.x + Math.cos(b) * 2.5, c.z + Math.sin(b) * 2.5, o.pos, 0.35);
    if (t % 16 === 0) { hop(S, 0.35, 6, null); snd(S, "note.pling", 1.6, 0.3, o.pos); } } };

/* くるくる こま: まわる こまの まわりを 回って 見て、止まったら 自分も くるっ */
P.pt_top = { dur: 170,
  init(S) { const c = vp(S, 2, 0, 0), g = gy(S, c.x, c.z, S.o0.y); if (!Number.isNaN(g)) c.y = g; S.o = { c, w: 1, e: toyEnt(S, c) }; roll(S.o.e, true); snd(S, "random.bow", 1.8); say(S, "§eこまを まわした！ くるくる…"); },
  step(S) { const o = S.o, c = o.c; o.w = Math.max(0, 1 - S.t / (S.dur - 40));
    const r = 0.5 * (1 - o.w), ang = S.t * 0.4, pos = { x: c.x + Math.cos(ang) * r, y: c.y, z: c.z + Math.sin(ang) * r }; tp(o.e, pos);
    if (o.w > 0) { if (!lite(S)) for (let k = 0; k < 2; k++) { const a = S.t * (0.3 + o.w) + k * Math.PI; dot(S, { x: pos.x + Math.cos(a) * 0.45, y: pos.y + 0.25, z: pos.z + Math.sin(a) * 0.45 }, k ? C.red : C.gold, 0.22); } if (S.t % 8 === 0) snd(S, "note.hat", 1.5 + o.w * 0.5, 0.3, pos); const b = S.t * 0.07; petAt(S, c.x + Math.cos(b) * 2, c.z + Math.sin(b) * 2, pos, 0.3); return; }
    roll(o.e, false); stay(S, pos);
    if (!o.done) { o.done = 1; anim(S.pet, "atk_spin"); snd(S, "random.click", 1.2); say(S, `§e${S.m.nm}も まねして くるっと まわった！`); fx(S, "swirl", S.pet.location, C.gold, 0.6); } } };

/* かざぐるま: 風で くるくる。強い 風の ときは 風と いっしょに 走りまわる */
P.pt_wind = { dur: 180,
  init(S) { S.o = { a: 0 }; },
  step(S) { const o = S.o, g = 0.25 + 0.75 * Math.abs(Math.sin(S.t * 0.045)); o.a += g * 0.9;
    const h = hand(S), cx = h.x + S.F.x * 0.5, cz = h.z + S.F.z * 0.5, cy = h.y + 0.5;
    if (!lite(S) || g > 0.6) for (let k = 0; k < 4; k++) { const a = o.a + (k * Math.PI) / 2; dot(S, { x: cx + S.R.x * Math.cos(a) * 0.45, y: cy + Math.sin(a) * 0.45, z: cz + S.R.z * Math.cos(a) * 0.45 }, [C.red, C.yellow, C.blue, C.green][k], 0.28); }
    if (g > 0.7 && S.t % 6 === 0) { const s = rnd(-3, 3); dot(S, vp(S, rnd(1, 5), s, rnd(0.5, 2.5)), C.white, 0.15); }
    if (g > 0.6) { const b = S.t * 0.12; petAt(S, S.o0.x + Math.cos(b) * 3.5, S.o0.z + Math.sin(b) * 3.5, null, 0.5); if (S.t % 14 === 0) hop(S, 0.4, 6, "happy"); if (!o.fast) { o.fast = 1; snd(S, "note.chime", 1.4, 0.5); say(S, `§a風が ふいた！ §f${S.m.nm}が 風と いっしょに かけまわる`); } }
    else { o.fast = 0; petAt(S, cx + S.F.x * 1, cz + S.F.z * 1, { x: cx, y: cy, z: cz }, 0.3); if (S.t % 20 === 0) hop(S, 0.5, 8); } } };

/* しゃぼん玉: ふわふわ ただよう 玉を 追いかけて ジャンプで わる */
P.pt_bubble = { dur: 190,
  init(S) { S.o = { bs: [], n: 0, made: 0 }; say(S, "§bしゃぼん玉を ふいた！ ふわ ふわ…"); },
  step(S) { const o = S.o;
    if (S.t % 10 === 0 && o.made < 7 && S.t < S.dur - 60) { const h = hand(S); o.made++; o.bs.push({ pos: { x: h.x, y: h.y + 0.3, z: h.z }, v: { x: S.F.x * 0.08 + S.R.x * rnd(-0.05, 0.05), y: rnd(0.015, 0.035), z: S.F.z * 0.08 + S.R.z * rnd(-0.05, 0.05) }, life: rnd(70, 120), ph: rnd(0, 6), age: 0 }); snd(S, "random.pop", 2, 0.15); }
    let best = null, bd = 99;
    for (const b of o.bs) {
      if (b.dead) continue; b.life -= 2; b.age += 2;
      b.pos.x += b.v.x + Math.sin(S.t * 0.1 + b.ph) * 0.03; b.pos.z += b.v.z + Math.cos(S.t * 0.08 + b.ph) * 0.03; b.pos.y += b.v.y; b.v.y *= 0.99;
      if (b.life <= 0 || blk(S, b.pos.x, b.pos.y, b.pos.z) === 1) { b.dead = 1; fx(S, "sparks", b.pos, C.sky, 0.12); continue; }
      if (!lite(S)) { dot(S, b.pos, C.sky, 0.5); dot(S, { x: b.pos.x + 0.1, y: b.pos.y + 0.12, z: b.pos.z }, C.white, 0.12); }
      const d = H(b.pos, S.pet.location); if (b.age > 20 && d < bd) { bd = d; best = b; }
    }
    if (!best) { stay(S, o.bs.find((b) => !b.dead)?.pos || S.p.location); if (o.made >= 7 && !o.bs.some((b) => !b.dead) && !o.end) { o.end = 1; anim(S.pet, "happy"); hearts(S); say(S, `§b§lぜんぶ わった！ §f${S.m.nm}は ${o.n}こ わった`); } return; }
    petAt(S, best.pos.x, best.pos.z, best.pos, 0.38);
    const up = best.pos.y - S.gy;
    if (bd < 1.2 && up < 3.4) hop(S, Math.max(0.5, Math.min(1.8, up - 0.9)), 10);
    if (bd < 1.2 && Math.abs(best.pos.y - (S.pet.location.y + 0.9)) < 0.9) { best.dead = 1; o.n++; fx(S, "sparks", best.pos, C.white, 0.2); snd(S, "random.pop", 1.9, 0.6, best.pos); say(S, `§bぱちん！ §f${S.m.nm}が しゃぼん玉を わった §7（${o.n}こ）`); } } };

/* たこ: 糸を のばして 空へ。相棒は 見上げて その下を 走りまわる */
P.pt_kite = { dur: 200,
  init(S) { S.o = { tail: [] }; say(S, "§e風に のせて たこを あげた！"); },
  step(S) { const t = S.t, h0 = Math.min(1, t / 50), down = Math.max(0, (t - (S.dur - 40)) / 40), hh = h0 * (1 - down), l = S.p.location;
    const k = { x: l.x + S.F.x * (2 + 7 * hh) + S.R.x * Math.sin(t * 0.06) * 2.5 * hh, y: l.y + 1.5 + 10 * hh + Math.sin(t * 0.11) * 0.8 * hh, z: l.z + S.F.z * (2 + 7 * hh) + S.R.z * Math.sin(t * 0.06) * 2.5 * hh };
    for (const [f, r, c] of [[0, 0.5, C.red], [0, -0.5, C.red], [0.5, 0, C.yellow], [-0.5, 0, C.yellow]]) dot(S, { x: k.x + S.R.x * r, y: k.y + f, z: k.z + S.R.z * r }, c, 0.45);
    if (t % 4 === 0) { S.o.tail.unshift({ ...k }); S.o.tail.length = Math.min(S.o.tail.length, 3); for (let i = 0; i < S.o.tail.length; i++) { const q = S.o.tail[i]; dot(S, { x: q.x, y: q.y - 0.7 - i * 0.35, z: q.z }, i % 2 ? C.blue : C.white, 0.25); } }
    if (t % 4 === 0) { const h = hand(S), n = isLite() ? 5 : 9; for (let i = 1; i < n; i++) { const f = i / n; dot(S, { x: h.x + (k.x - h.x) * f, y: h.y + (k.y - h.y) * f - Math.sin(Math.PI * f) * 0.8, z: h.z + (k.z - h.z) * f }, C.white, 0.12); } }
    const r = Math.sin(t * 0.13) * 2; petAt(S, k.x - S.F.x * 1.5 + S.R.x * r, k.z - S.F.z * 1.5 + S.R.z * r, k, 0.42);
    if (t % 30 === 10) { hop(S, 0.6, 8, "happy"); if (hh > 0.8) snd(S, "mob.enderdragon.flap", 1.9, 0.25, k); }
    if (t === 60) say(S, `§eたこが 高く あがった！ §f${S.m.nm}は 空を 見上げて 走りまわる`); } };

/* ぴかぴか 手鏡: お日さまの 光が 地面を ちょろちょろ → とびつく。最後は 鏡の 自分に びっくり */
P.pt_mirror = { dur: 180,
  init(S) { S.o = { s: vp(S, 2, 0, 0), to: null, w: 0, n: 0 }; say(S, "§e手鏡で 光を 地面に うつした！"); },
  step(S) { const o = S.o;
    if (S.t < S.dur - 50) {
      if (!o.to || (o.w -= 2) <= 0) { o.to = vp(S, rnd(1.5, 5.5), rnd(-3.5, 3.5), 0); o.w = rnd(14, 26); }
      const dx = o.to.x - o.s.x, dz = o.to.z - o.s.z, d = Math.hypot(dx, dz), k = d > 0.01 ? Math.min(0.45, d) / d : 0; o.s.x += dx * k; o.s.z += dz * k;
      const g = gy(S, o.s.x, o.s.z, S.o0.y); if (!Number.isNaN(g)) o.s.y = g;
      dot(S, { x: o.s.x, y: o.s.y + 0.08, z: o.s.z }, C.yellow, 0.55); if (S.t % 6 === 0) fx(S, "star", { x: o.s.x, y: o.s.y + 0.2, z: o.s.z }, C.white, 0.3);
      const pd = petAt(S, o.s.x, o.s.z, o.s, 0.42);
      if ((o.cd = (o.cd || 0) - 2) < 0 && pd < 1.4 && hop(S, 0.8, 10, "atk_jump")) { o.cd = 20; o.n++; o.to = vp(S, rnd(1.5, 5.5), rnd(-3.5, 3.5), 0); o.w = 20; say(S, `§e${S.m.nm}が 光に とびついた！ §7…にげられた（${o.n}）`); }
      return;
    }
    const m = vp(S, 1.2, 0, 1); petAt(S, S.o0.x + S.F.x * 2.4, S.o0.z + S.F.z * 2.4, m, 0.4);
    if (S.t % 4 === 0) dot(S, m, C.white, 0.6);
    if (S.t === S.dur - 44) { anim(S.pet, "guard"); snd(S, "random.click", 0.8); say(S, `§e${S.m.nm}は 鏡の 中の 自分に びっくり！`); }
    if (S.t === S.dur - 20) { anim(S.pet, "power"); fx(S, "star", m, C.gold, 1); say(S, `§e…そして きめポーズ！`); } } };

/* たいこ: どん・とん の リズムで おどる。だんだん はやく → どどん！ */
P.pt_drum = { dur: 180,
  init(S) { S.o = { b: 0, nx: 4 }; },
  step(S) { const o = S.o, c = vp(S, 2.2, 0, 0);
    if (S.t >= o.nx && S.t < S.dur - 24) { o.b++; o.nx = S.t + (S.t < 70 ? 10 : S.t < 120 ? 8 : 6); const big = o.b % 2 === 1;
      snd(S, big ? "note.bd" : "note.snare", 1, 0.8, S.p.location); fx(S, "notes", { x: S.p.location.x, y: S.p.location.y + 1.4, z: S.p.location.z }, big ? C.red : C.gold, 0.4);
      if (big) hop(S, 0.4, 6, o.b % 8 === 1 ? "atk_dance" : null); }
    const side = ((Math.floor(o.b / 2) % 2) ? 1 : -1) * 0.8; petAt(S, c.x + S.R.x * side, c.z + S.R.z * side, { x: c.x + Math.cos(S.t * 0.15) * 3, y: c.y + 1, z: c.z + Math.sin(S.t * 0.15) * 3 }, 0.3);
    if (S.t === 2) say(S, `§eどん・とん！ §f${S.m.nm}が リズムに のって おどりだした`);
    if (S.t === 120) say(S, "§eテンポ アップ！");
    if (S.t === S.dur - 20) { snd(S, "note.bd", 0.8, 1, S.p.location); snd(S, "note.bd", 1, 1, S.p.location); anim(S.pet, "power"); fx(S, "sparks", S.pet.location, C.gold, 0.6); say(S, `§e§lどどん！ §f${S.m.nm}は きめポーズ`); } } };

/* くさぶえ: ぴーひょろ メロディーに あわせて ゆらゆら・高い 音で ぴょん・最後に くるり */
const FLUTE = [0, 2, 4, 7, 4, 2, 4, 9, 7, 4, 2, 0, 2, 4, 2, 0, 7, 12, 7, 4];
P.pt_flute = { dur: 170,
  init(S) { S.o = { i: 0, sp: 0 }; },
  step(S) { const o = S.o;
    if (S.t % 6 === 0 && o.i < FLUTE.length) { const n = FLUTE[o.i++]; snd(S, "note.flute", 0.7 * Math.pow(2, n / 12), 0.7, S.p.location); fx(S, "notes", hand(S), C.green, 0.3); if (n >= 9) hop(S, 0.6, 8); }
    const c = vp(S, 2.2, 0, 0);
    if (o.i >= FLUTE.length) { o.sp += 0.35; stay(S, { x: S.pet.location.x + Math.cos(o.sp) * 2, y: S.pet.location.y + 0.5, z: S.pet.location.z + Math.sin(o.sp) * 2 }); if (!o.end) { o.end = 1; anim(S.pet, "happy"); hearts(S); say(S, `§a${S.m.nm}は くるりと まわって おじぎした`); } return; }
    const s = Math.sin(S.t * 0.12) * 0.9; petAt(S, c.x + S.R.x * s, c.z + S.R.z * s, S.p.location, 0.25);
    if (S.t === 2) say(S, `§aぴーひょろ〜 §f${S.m.nm}が 音に あわせて ゆれて いる`); } };

/* 木の 剣: ちゃんばらごっこ。ふる → ふせぐ・よける・はんげき。最後は 参った */
const SW = ["guard", "dodge", "counter", "guard", "counter"];
P.pt_sword = { dur: 190,
  init(S) { S.o = { r: 0, side: 1 }; say(S, `§eちゃんばら ごっこ！ §f${S.m.nm}が かまえた`); },
  step(S) { const o = S.o, l = S.p.location, ph = S.t % 34, r = Math.floor(S.t / 34), F = viewF(S.p), R = { x: -F.z, z: F.x };
    if (r >= SW.length) { petAt(S, l.x + F.x * 2.2, l.z + F.z * 2.2, l, 0.3); if (!o.end) { o.end = 1; anim(S.pet, "happy"); hearts(S); say(S, `§e${S.m.nm}「まいった〜」 §7たのしかった みたい`); } return; }
    const mode = SW[r]; let f = 2.2, s = 0;
    if (ph === 8) { snd(S, "game.player.attack.sweep", 1.2, 0.6); fx(S, "sparks", { x: l.x + F.x * 1.2, y: l.y + 1.1, z: l.z + F.z * 1.2 }, C.tan, 0.3); }
    if (ph >= 8 && ph < 22) {
      if (mode === "guard") { f = 2.8; if (ph === 8) { anim(S.pet, "guard"); snd(S, "mob.zombie.wood", 1.8, 0.4); say(S, "§eカン！ §fふせいだ"); } }
      else if (mode === "dodge") { s = 1.3 * o.side; if (ph === 8) { hop(S, 0.5, 8, null); say(S, "§eひらり！ §fよけた"); o.side = -o.side; } }
      else { f = ph < 14 ? 1.1 : 2.2; if (ph === 8) { anim(S.pet, "atk_charge"); say(S, `§eえいっ！ §f${S.m.nm}の はんげき`); snd(S, "random.pop", 1.2); } }
    }
    petAt(S, l.x + F.x * f + R.x * s, l.z + F.z * f + R.z * s, l, 0.5); } };

/* おもちゃの 王冠: かぶって ファンファーレ → まわりを ぐるっと 行進 */
const FAN = [0, 4, 7, 12, 7, 12];
P.pt_crown = { dur: 180,
  init(S) { S.o = { i: 0 }; anim(S.pet, "power"); say(S, `§6${S.m.nm}が 王冠を かぶった！ §fパッパカパーン♪`); },
  step(S) { const o = S.o, hl = (() => { try { return S.pet.getHeadLocation(); } catch { return { ...S.pet.location, y: S.pet.location.y + 1.2 }; } })();
    if (!lite(S)) for (let k = 0; k < 5; k++) { const a = (k / 5) * Math.PI * 2 + S.t * 0.05; dot(S, { x: hl.x + Math.cos(a) * 0.3, y: hl.y + 0.45 + (k % 2) * 0.12, z: hl.z + Math.sin(a) * 0.3 }, C.gold, 0.22); }
    if (S.t % 6 === 0 && o.i < FAN.length) { snd(S, "note.pling", Math.pow(2, FAN[o.i++] / 12) * 0.8, 0.8, S.p.location); if (o.i === FAN.length) snd(S, "random.levelup", 1.4, 0.6); }
    if (S.t < 40) { stay(S, S.p.location); return; }
    if (S.t < S.dur - 30) { const a = (S.t - 40) * 0.05, l = S.o0; petAt(S, l.x + Math.cos(a) * 2.6, l.z + Math.sin(a) * 2.6, null, 0.25); if (S.t % 8 === 0) fx(S, "rise", S.pet.location, C.gold, 0.4); if (S.t === 42) say(S, `§6${S.m.nm}は いばって 行進 して いる`); return; }
    stay(S, S.p.location); if (!o.end) { o.end = 1; anim(S.pet, "power"); fx(S, "star", hl, C.gold, 1); say(S, `§6§l${S.m.nm}王 ばんざい！`); } } };

/* ゆらゆら ちょうちん: ゆれる 明かりを 目で 追う → 明かりの あとを ついて 歩く */
P.pt_lamp = { dur: 190,
  init(S) { S.o = {}; say(S, "§6ちょうちんに 明かりを ともした…"); },
  step(S) { const t = S.t; let L;
    if (t < 100) { const a = Math.sin(t * 0.12) * 0.9, h = hand(S); L = { x: h.x + S.F.x * 1 + S.R.x * Math.sin(a) * 1.3, y: h.y + 0.6 - (1 - Math.cos(a)) * 0.6, z: h.z + S.F.z * 1 + S.R.z * Math.sin(a) * 1.3 };
      petAt(S, L.x + S.F.x * 1.2, L.z + S.F.z * 1.2, L, 0.22); if (t % 20 === 0) snd(S, "note.chime", 1.2, 0.3, L); }
    else { const a = (t - 100) * 0.07, c = S.o0; L = { x: c.x + Math.cos(a) * 3, y: c.y + 1.3 + Math.sin(t * 0.2) * 0.15, z: c.z + Math.sin(a) * 3 }; const b = a - 0.5; petAt(S, c.x + Math.cos(b) * 3, c.z + Math.sin(b) * 3, L, 0.3); if (t === 100) say(S, `§6明かりが ふわりと 進む… §f${S.m.nm}が あとを ついて いく`); }
    dot(S, L, C.warm, 0.55); if (t % 6 === 0) try { S.dim.spawnParticle("minecraft:basic_flame_particle", L); } catch {}
    if (t % 30 === 0) anim(S.pet, "happy"); } };

/* きらきら 貝がら: 耳に あてて 波の 音 → かくした 貝がらを においで さがす（3か所目で 見つかる）*/
P.pt_shell = { dur: 200,
  init(S) { S.o = { sp: [vp(S, 3, -2.5, 0), vp(S, 4.5, 2, 0), vp(S, 2.5, 3, 0)], i: 0, dig: 0 }; snd(S, "random.splash", 0.6, 0.3, S.p.location); say(S, "§b貝がらを 耳に あてると… ざざーん 波の 音"); },
  step(S) { const o = S.o;
    if (S.t < 30) { const s = Math.sin(S.t * 0.3) * 0.25; petAt(S, S.o0.x + S.F.x * 1.5 + S.R.x * s, S.o0.z + S.F.z * 1.5 + S.R.z * s, hand(S), 0.2); if (S.t === 20) snd(S, "random.splash", 0.5, 0.25, S.p.location); if (S.t === 28) say(S, `§bこっそり 貝がらを かくした！ §f${S.m.nm}、さがして！`); return; }
    if (o.i >= o.sp.length) { stay(S, S.p.location); return; }
    const s = o.sp[o.i];
    if (o.dig > 0) { o.dig -= 2; stay(S, s); if (o.dig % 6 === 0) { anim(S.pet, "atk_claw"); fx(S, "smoke", s, C.brown, 0.3); snd(S, "dig.sand", 1.2, 0.5, s); }
      if (o.dig <= 0) { o.i++; if (o.i < o.sp.length) { say(S, `§7ここじゃ ない みたい… §f${S.m.nm}は また においを かぐ`); anim(S.pet, "hurt"); } else { const at = { x: s.x, y: S.gy + 0.6, z: s.z }; dot(S, at, C.pink, 0.7); fx(S, "star", at, C.gold, 1); snd(S, "random.levelup", 1.6, 0.6); anim(S.pet, "happy"); hearts(S); say(S, `§b§l見つけた！ §f${S.m.nm}が 貝がらを 見つけた`); } }
      return; }
    const z = Math.sin(S.t * 0.4) * 0.6, d = petAt(S, s.x + S.R.x * z, s.z + S.R.z * z, null, 0.22);   /* くんくん ジグザグ */
    if (S.t % 6 === 0) fx(S, "smoke", mouth(S), C.white, 0.15);
    if (d < 0.6) o.dig = 18; } };

/* ほしの 音の 小箱: きらきら メロディー・星の 粒が うずまき、相棒は ふわっと うかんで まわる */
const STAR = [12, 12, 19, 19, 21, 21, 19, 17, 17, 16, 16, 14, 14, 12, 7, 12, 16, 19, 24];
P.pt_star = { dur: 200,
  init(S) { S.o = { i: 0, base: null }; say(S, "§d小箱を あけると… きらきら 星の 音が ながれだした"); },
  step(S) { const o = S.o;
    if (S.t % 8 === 0 && o.i < STAR.length) { const n = STAR[o.i++]; snd(S, o.i % 2 ? "note.bell" : "note.chime", 0.5 * Math.pow(2, n / 12), 0.7, S.p.location); }
    const up = S.t < 40 ? S.t / 40 : S.t > S.dur - 40 ? Math.max(0, (S.dur - S.t) / 40) : 1; S.lift = up * 1.1;
    const c = vp(S, 2, 0, 0), a = S.t * 0.12; petAt(S, c.x, c.z, { x: c.x + Math.cos(a) * 3, y: S.gy + 1, z: c.z + Math.sin(a) * 3 }, 0.3);
    const l = S.pet.location; if (!lite(S)) for (let k = 0; k < 3; k++) { const b = S.t * 0.2 + (k * Math.PI * 2) / 3; dot(S, { x: l.x + Math.cos(b) * 1.2, y: l.y + 0.3 + ((S.t * 0.04 + k * 0.6) % 2), z: l.z + Math.sin(b) * 1.2 }, [C.gold, C.purple, C.sky][k], 0.3); }
    if (S.t % 12 === 0) fx(S, "star", { x: l.x + rnd(-1, 1), y: l.y + rnd(0.5, 2), z: l.z + rnd(-1, 1) }, C.gold, 0.5);
    if (S.t === 60) say(S, `§d${S.m.nm}は 星の 光に つつまれて ふわりと うかんだ…`);
    if (S.t === S.dur - 6) { fx(S, "rise", l, C.gold, 1); anim(S.pet, "happy"); } } };

export const TOY_PLAYS = P;

// ---------- 動かす ----------
let RUN = null;
function alive(S) {
  const p = S.p; if (!okE(p) || !okE(S.pet)) return false;
  try { if (p.dimension.id !== S.dimId || S.pet.dimension.id !== S.dimId) return false; } catch { return false; }
  if (H(p.location, S.pet.location) > 20) return false;
  try { const h = p.getComponent("minecraft:health"); if (h && typeof h.currentValue === "number" && h.currentValue <= 0) return false; } catch {}
  if (busy.has(p.id) && (busy.since.get(p.id) || 0) > S.ms) return false;   /* あとから 物語・画面が はじまった */
  if (globalThis.__MQ_CAMON && globalThis.__MQ_CAMON.has(p.id)) return false;
  try { if (S.pet.hasTag("mrpg_battle") || inBattle(p)) return false; } catch {}
  return true;
}
export function stopPlay(pid, done = false) {
  const S = PLAYS.get(pid); if (!S) return; PLAYS.delete(pid);
  for (const e of S.ents) if (okE(e)) try { e.remove(); } catch {}
  S.ents.length = 0;
  if (okE(S.pet)) { if (S.lift) try { const l = S.pet.location; S.pet.teleport({ x: l.x, y: S.gy, z: l.z }); } catch {} if (done) { anim(S.pet, "happy"); hearts(S, 1.2); } }
  if (done && S.msg) say(S, S.msg);
  if (!PLAYS.size && RUN !== null) { try { system.clearRun(RUN); } catch {} RUN = null; }
}
function tick() {
  for (const [pid, S] of [...PLAYS]) {
    if (!alive(S)) { stopPlay(pid, false); continue; }
    S.t += 2;
    try { S.play.step(S); } catch (err) { console.warn(`[MonsterRPG] toyplay ${S.id}: ${err}`); stopPlay(pid, false); continue; }
    if (S.t >= S.dur) stopPlay(pid, true);
  }
}
/* 遊びを はじめる。できたら true（できない ときは toys.js が ふつうの きらきらに する）*/
export function startPlay(p, pet, id, m, msg = "") {
  const play = P[id]; if (!play || !okE(p) || !okE(pet)) return false;
  try { if (pet.getComponent("minecraft:rideable")?.getRiders()?.length) return false; } catch {}
  stopPlay(p.id, false);
  const F = viewF(p), l = p.location;
  const S = { p, pet, m, id, play, t: 0, dur: play.dur, dim: p.dimension, dimId: p.dimension.id, ms: Date.now(), ents: [], F, R: { x: -F.z, y: 0, z: F.x }, o0: { x: l.x, y: l.y, z: l.z }, gy: pet.location.y, hop: 0, hopN: 1, hopH: 0, lift: 0, msg, lqY: NaN };
  const g = gy(S, pet.location.x, pet.location.z, pet.location.y); if (!Number.isNaN(g)) S.gy = g;
  PLAYS.set(p.id, S);
  try { play.init(S); } catch (err) { console.warn(`[MonsterRPG] toyplay init ${id}: ${err}`); stopPlay(p.id, false); return false; }
  if (RUN === null) RUN = system.runInterval(tick, 2);
  return true;
}
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => stopPlay(playerId, false)); } catch {}
/* 入りなおした ときに 残った おもちゃを 片づける */
system.runTimeout(() => { const live = new Set(); for (const S of PLAYS.values()) for (const e of S.ents) try { live.add(e.id); } catch {} for (const d of ["overworld", "nether", "the_end"]) try { for (const e of world.getDimension(d).getEntities({ type: "mrpg:ball", tags: [TAG] })) if (!live.has(e.id)) try { e.remove(); } catch {} } catch {} }, 120);
export const __tp = { PLAYS, tick, alive, findWater, TAG };
