// 第102版: 探索の 追加（地形の 場所・空と 天気の できごと・野生の しぐさ・採集）
// 軽く: explore.js の 2秒ごとの 見はりに 乗る（XT.tick）。新しい 場所は 近づいた ときに 1回だけ 作る
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES, ORDER, EGGS } from "./data.js";
import { WREGIONS, regionLv } from "./worldmap.js";
import { surfaceY } from "./structures.js";
import { load, save } from "./store.js";
import { busy, notice, confirm, giveItem, takeItem, countItem, sound, barNote, showTitle } from "./ui.js";
import { hooks, TYPE, setLook, spawnWildNear } from "./field.js";
import { battleHooks, HIT_HOOKS } from "./battle.js";
import { FISH_HOOK } from "./fishing.js";
import { chestCmds } from "./chests.js";
import { makeMonster, addMon } from "./core.js";
import { rankCap, rIdx, storyLootOk, endingDone } from "./quest.js";
import { openUpTo } from "./saga.js";
import { award, TITLES } from "./endgame.js";
import {
  exOf, exSave, addPt, prize, giveGold, XT, addKind, KINDS, spotsOf, spotInfo, EVT, NODES, startEvt, groundNear, naviPush, regAtLoc, hash, dayNo, dirTo, hd, run, fx, nowT, pickA,
  ENVR, envSid, EXR, wxOf, xRank, findWater, MATS,
} from "./explore.js";

const OW = "minecraft:overworld";
const rnd = () => Math.random();
const say = (p, m) => { try { p.sendMessage(m); } catch {} };
const bar = (p, m) => { try { barNote(p).setActionBar(m); } catch {} };
const timeOf = () => { try { return world.getTimeOfDay(); } catch { return 6000; } };
const isNight = () => { const t = timeOf(); return t > 13000 && t < 23000; };
const isDawn = () => { const t = timeOf(); return t >= 22800 || t < 1000; };
let WW = ""; try { world.afterEvents.weatherChange.subscribe((ev) => { try { WW = String(ev.newWeather || ""); } catch {} }); } catch {}
const weather = (dim) => { let w = WW; try { if (typeof dim.getWeather === "function") w = String(dim.getWeather()); } catch {} return w; };
const style = (i) => WREGIONS[i]?.style;
const okSp = (s) => { const S = SPECIES[s]; return S && !S.hidden && !S.fuseonly && !S.metalmon && S.fam !== "king" && S.fam !== "god"; };
// 物語の 進みまでの ランクで 種族を えらぶ（rk: 0〜8）
function pickSp(d, filt, rkMax) {
  const cap = Math.min(rankCap(d), rkMax);
  for (let rk = cap; rk >= 0; rk--) { const L = ORDER.filter((s) => okSp(s) && SPECIES[s].wild && rIdx(s) === rk && filt(SPECIES[s])); if (L.length) return pickA(L); }
  return null;
}
const rkForLv = (lv) => (lv < 15 ? 2 : lv < 30 ? 3 : lv < 45 ? 4 : lv < 60 ? 5 : 6);
// 仲間に なりたがる 子（迷子と 同じ しくみ）: なぐると 話せる
export function spawnJoiner(p, sid, lv, label, at, ttl = 180000) {
  const g = at || groundNear(p, 8, 16); if (!g || !SPECIES[sid]) return null;
  let e; try { e = p.dimension.spawnEntity(TYPE, { x: g.x + 0.5, y: g.y, z: g.z + 0.5 }); } catch { return null; }
  setLook(e, sid); e.addTag("mrpg_lost"); e.addTag("mrpg_keep");
  try { e.setDynamicProperty("mrpg:lv", lv); e.setDynamicProperty("mrpg:lost", p.id); e.setDynamicProperty("mrpg:rt", Date.now() - 300000 + ttl); e.triggerEvent("mrpg:keep"); } catch {}
  e.nameTag = `§b${label}${SPECIES[sid].name} §7Lv${lv}`;
  return e;
}
// 強い 野生（ボス）を 出す: 倒すと battleHooks で ほうび（tag で 見わける）
export function spawnBoss(p, sid, lv, tag, name, at) {
  const g = at || groundNear(p, 10, 18); if (!g || !SPECIES[sid]) return null;
  let e; try { e = p.dimension.spawnEntity(TYPE, { x: g.x + 0.5, y: g.y, z: g.z + 0.5 }); } catch { return null; }
  setLook(e, sid); e.addTag("mrpg_boss"); e.addTag(tag); e.addTag("mrpg_bounty"); e.addTag("mrpg_xboss");   /* 賞金首と 同じ あつかい（お供なし・スカウト不可・6分で 片づけ） */
  try { e.setDynamicProperty("mrpg:lv", Math.min(100, lv)); e.setDynamicProperty("mrpg:q", 0.85); e.setDynamicProperty("mrpg:rt", Date.now()); e.setDynamicProperty("mrpg:bri", regAtLoc(g)); e.setDynamicProperty("mrpg:xowner", p.id); e.triggerEvent("mrpg:keep"); } catch {}
  e.nameTag = `§6§l${name}§r §f${SPECIES[sid].name} §7Lv${Math.min(100, lv)}`;
  return e;
}
export function scrap(e, t) { e.sc = Array.isArray(e.sc) ? e.sc : []; e.sc.unshift(`${new Date(Date.now() + 9 * 3600000).toISOString().slice(5, 10)} ${t}`); if (e.sc.length > 30) e.sc.length = 30; }   // 158) 手帳の スクラップ
const egg = (d) => { const L = Object.keys(EGGS).filter((id) => ITEMS[id] && storyLootOk(ITEMS[id], EGGS[id]?.ranks, rankCap(d)) && !/king|god|rainbow/.test(id)); return L.length ? pickA(L) : null; };
const chestAt = (k, i, x, y, z, t, ch) => ch(x, y, z, t(4, Math.floor(i / 3)), OW);

// ================= 新しい 場所（XT.kinds）=================
const ALL = () => true, NOT_SKY = (i, s) => s !== "sky";
// 1) 地底湖（洞くつの 奥の 光る 湖・ここで 釣ると 1段 上）
addKind("lake", { sz: 5, uy: 25, n: "地底湖", h: "地面の 25ブロック 下の 光る 湖。ここ（8m 以内）で 釣ると 1段 上の 竿と 同じ", at: NOT_SKY,
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const y = Math.max(-48, gy - 25); return { cmds: [`fill ${x - 5} ${y - 2} ${z - 5} ${x + 5} ${y + 5} ${z + 5} stone hollow`, `fill ${x - 4} ${y - 1} ${z - 4} ${x + 4} ${y + 4} ${z + 4} air`, `fill ${x - 4} ${y - 2} ${z - 4} ${x + 4} ${y - 2} ${z + 4} stone`, `fill ${x - 2} ${y - 1} ${z - 2} ${x + 2} ${y - 1} ${z + 2} water`, `setblock ${x} ${y + 5} ${z} glowstone`, `setblock ${x + 3} ${y + 5} ${z + 3} glowstone`, `setblock ${x - 3} ${y + 5} ${z - 3} glowstone`, ...chestCmds(x + 3, y - 1, z - 3, rollTier(3, Math.floor(i / 3)), OW)], info: { x, y, z } }; },
  near: (L, I, dh) => dh < 6 && Math.abs(L.y - I.y) < 5 });
// 2) 崖の 割れ目の 隠し部屋
addKind("crack", { sz: 4, n: "割れ目の 隠し部屋", h: "岩の 割れ目の 奥", at: ALL,
  build: ({ x, z, gy, i, rock, chestCmds, rollTier }) => ({ cmds: [`fill ${x - 3} ${gy - 1} ${z - 3} ${x + 3} ${gy + 6} ${z + 3} ${rock}`, `fill ${x} ${gy} ${z - 3} ${x} ${gy + 1} ${z + 1} air`, `fill ${x - 1} ${gy} ${z} ${x + 1} ${gy + 2} ${z + 2} air`, `setblock ${x} ${gy + 2} ${z + 1} lantern`, ...chestCmds(x, gy, z + 2, rollTier(4, Math.floor(i / 3)), OW)], info: { x, y: gy, z: z + 1 } }) });
// 3) 崩れる 橋（のると 少しずつ くずれる・1分で もどる）
addKind("bridge", { sz: 9, n: "崩れる 橋", h: "高い 柱の あいだの 古い 橋。立ち止まると 落ちる", at: NOT_SKY,
  build: ({ x, z, gy, i, rock, chestCmds, rollTier }) => ({ cmds: [`fill ${x - 7} ${gy - 1} ${z - 1} ${x - 5} ${gy + 7} ${z + 1} ${rock}`, `fill ${x + 5} ${gy - 1} ${z - 1} ${x + 7} ${gy + 7} ${z + 1} ${rock}`, `fill ${x - 4} ${gy + 7} ${z} ${x + 4} ${gy + 7} ${z} spruce_planks`,
    `fill ${x - 8} ${gy} ${z} ${x - 8} ${gy + 7} ${z} ladder ["facing_direction"=4]`, ...chestCmds(x + 6, gy + 8, z, rollTier(4, Math.floor(i / 3)), OW)], info: { x: x + 6, y: gy + 8, z, bx: x, by: gy + 7 } }),
  near: (L, I, dh) => dh < 2.5 && Math.abs(L.y - I.y) < 2 });
// 4) 霧の 迷路（生け垣・中心に 宝）
const MAZE = ["###########", "#.....#...#", "#.###.#.#.#", "#.#...#.#.#", "#.#.###.#.#", "#.#.#...#.#", "#.#.#.###.#", "#...#.....#", "#####.###.#", "#.........#", "#####.#####"];
addKind("maze", { sz: 6, n: "霧の 迷路", h: "生け垣の 迷路。まん中に 宝", at: (i, s) => ["forest", "village", "castle", "dark"].includes(s),
  build: ({ x, z, gy, i, chestCmds, rollTier, findWater }) => {
    const leaf = style(i) === "dark" ? "nether_wart_block" : "oak_leaves", C = [`fill ${x - 5} ${gy} ${z - 5} ${x + 5} ${gy + 3} ${z + 5} air`, `fill ${x - 5} ${gy - 1} ${z - 5} ${x + 5} ${gy - 1} ${z + 5} moss_block`];
    MAZE.forEach((row, r) => { let a = -1; for (let c = 0; c <= row.length; c++) { const w = row[c] === "#"; if (w && a < 0) a = c; if (!w && a >= 0) { C.push(`fill ${x - 5 + a} ${gy} ${z - 5 + r} ${x - 5 + c - 1} ${gy + 2} ${z - 5 + r} ${leaf} ["persistent_bit"=true]`); a = -1; } } });
    C.push(...chestCmds(x, gy, z, rollTier(4, Math.floor(i / 3)), OW)); return { cmds: C, info: { x, y: gy, z } };
  }, near: (L, I, dh) => dh < 1.8 && Math.abs(L.y - I.y) < 3 });
// 8) 沈没船（深い 水の 底）
addKind("wreck", { sz: 5, n: "沈没船", h: "深い 水の 底の 船。もぐって 探す", at: (i, s) => ["port", "village", "forest", "snow", "dark"].includes(s),
  build: ({ x, z, i, findWater, playerBuilt, chestCmds, rollTier, skip, dim }) => {
    const w = findWater(dim, x, z, 40); if (w === "wait") return false; if (!w || hooks.inTown(w, OW) || playerBuilt(dim, w.x, w.y, w.z, 4) === true) return skip();
    let by = w.y; for (let k = 1; k < 30; k++) { let b; try { b = dim.getBlock({ x: w.x, y: w.y - k, z: w.z }); } catch { return false; } if (!b) return false; if (!/water|seagrass|kelp/.test(b.typeId)) { by = w.y - k; break; } }
    if (w.y - by < 5) return skip();
    const X = w.x, Y = by + 1, Z = w.z;
    return { cmds: [`fill ${X - 4} ${Y} ${Z - 1} ${X + 4} ${Y} ${Z + 1} dark_oak_planks`, `fill ${X - 4} ${Y + 1} ${Z - 2} ${X + 4} ${Y + 1} ${Z + 2} dark_oak_planks hollow`, `fill ${X} ${Y + 1} ${Z} ${X} ${Y + 5} ${Z} dark_oak_fence`, `fill ${X - 3} ${Y + 1} ${Z - 1} ${X + 3} ${Y + 1} ${Z + 1} water`, ...chestCmds(X + 2, Y + 1, Z, rollTier(5, Math.floor(i / 3)), OW)], info: { x: X, y: Y + 1, z: Z } };
  }, near: (L, I, dh) => dh < 5 && Math.abs(L.y - I.y) < 4 });
// 9) 雲の 道（天空郷）
addKind("cloud", { sz: 14, n: "雲の 道", h: "空に つづく 雲の 足場。いちばん 先に 宝", at: (i, s) => s === "sky",
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const C = []; for (let k = 0; k < 9; k++) C.push(`fill ${x - 8 + k * 2} ${gy + 2 + k * 2} ${z - 1} ${x - 7 + k * 2} ${gy + 2 + k * 2} ${z} white_wool`); C.push(`fill ${x + 9} ${gy + 19} ${z - 2} ${x + 13} ${gy + 19} ${z + 2} white_wool`, ...chestCmds(x + 11, gy + 20, z, rollTier(5, Math.floor(i / 3)), OW)); return { cmds: C, info: { x: x + 11, y: gy + 20, z } }; } });
// 60) 失われた 村（こわれた 家と 古い 手紙）
addKind("ruinvil", { sz: 9, n: "失われた 村", h: "人が いなく なった 村。古い 手紙が 残る", at: (i, s) => s !== "sky",
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const C = []; for (const [dx, dz] of [[-6, 0], [5, -4], [3, 6]]) C.push(`fill ${x + dx - 2} ${gy} ${z + dz - 2} ${x + dx + 2} ${gy + 3} ${z + dz + 2} mossy_cobblestone hollow`, `fill ${x + dx - 2} ${gy + 2} ${z + dz} ${x + dx + 2} ${gy + 3} ${z + dz} air`, `setblock ${x + dx} ${gy} ${z + dz - 2} air`); C.push(...chestCmds(x + 3, gy, z + 6, rollTier(3, Math.floor(i / 3)), OW)); return { cmds: C, info: { x: x + 3, y: gy, z: z + 6 } }; },
  found: (p, d, e, q) => { addPt(p, e, 8); const n = (e.lt = e.lt || {}); const k = q.i % LETTERS.length; n[k] = 1; scrap(e, "失われた 村"); return [`§6§l失われた 村`, `§f古い 手紙: 「${LETTERS[k]}」`]; } });
// 62) 伝説の 7つの 秘宝（地方 1〜7）と 最後の 秘境（天空郷）
addKind("relic", { sz: 2, n: "伝説の 秘宝", h: "金の 台に まつられた 秘宝（7つ）", at: (i) => i >= 1 && i <= 7,
  build: ({ x, z, gy }) => ({ cmds: [`fill ${x - 1} ${gy - 1} ${z - 1} ${x + 1} ${gy - 1} ${z + 1} chiseled_quartz_block`, `setblock ${x} ${gy} ${z} gold_block`, `setblock ${x} ${gy + 1} ${z} end_rod`], info: { x, y: gy, z } }),
  found: (p, d, e, q) => { e.rl = e.rl || {}; e.rl[q.i] = 1; addPt(p, e, 15); const n = Object.keys(e.rl).length; scrap(e, `秘宝 ${n}/7`); return [`§6§l伝説の 秘宝を 見つけた！ §r§6（${n}/7）`, n >= 7 ? "§d§l7つ そろった！ セレスティア天空郷の どこかに 最後の 秘境が ひらいた" : ""]; } });
addKind("final", { sz: 4, n: "最後の 秘境", h: "7つの 秘宝が そろうと 入れる", at: (i) => i === 10,
  build: ({ x, z, gy, chestCmds }) => ({ cmds: [`fill ${x - 3} ${gy - 1} ${z - 3} ${x + 3} ${gy - 1} ${z + 3} gold_block`, `fill ${x - 3} ${gy} ${z - 3} ${x + 3} ${gy} ${z + 3} end_rod outline`, `fill ${x - 2} ${gy} ${z - 2} ${x + 2} ${gy + 3} ${z + 2} air`, ...chestCmds(x, gy, z, 9, OW)], info: { x, y: gy, z } }),
  found: (p, d, e, q) => { const need = [1, 2, 3, 4, 5, 6, 7].filter((k) => !spotInfo(k, "relic")?.skip).length; if (Object.keys(e.rl || {}).length < need) { delete e.f[`${q.i}.final`]; if (nowT() - (e.fh || 0) > 60000) { e.fh = nowT(); return ["§7金の 台が ある。7つの 秘宝が そろえば 何かが 起きそうだ……"]; } return []; } addPt(p, e, 60); award(p, d, "ex_relic", null); const g = giveGold(d, 200000); save(p, d); scrap(e, "最後の 秘境"); return [`§d§l最後の 秘境に たどりついた！ §r§e${g}`, ...prize(p, d, 10, 3, 3)]; } });
// 63) 隠された 島（地図の 切れ端 4つで 場所が わかる・マリノア諸島）
addKind("hidisle", { sz: 4, n: "隠された 島", h: "地図の 切れ端を 4つ 集めると 場所が わかる", at: (i) => i === 6,
  build: ({ x, z, i, dim, findWater, playerBuilt, chestCmds, skip }) => { const w = findWater(dim, x, z, 40); if (w === "wait") return false; if (!w || hooks.inTown(w, OW) || playerBuilt(dim, w.x, w.y, w.z, 4) === true) return skip(); return { cmds: [`fill ${w.x - 3} ${w.y - 5} ${w.z - 3} ${w.x + 3} ${w.y} ${w.z + 3} sand`, `fill ${w.x - 2} ${w.y + 1} ${w.z - 2} ${w.x + 2} ${w.y + 1} ${w.z + 2} grass_block`, `fill ${w.x - 3} ${w.y + 2} ${w.z - 3} ${w.x + 3} ${w.y + 6} ${w.z + 3} air`, `fill ${w.x + 2} ${w.y + 2} ${w.z + 2} ${w.x + 2} ${w.y + 6} ${w.z + 2} jungle_log`, ...chestCmds(w.x, w.y + 2, w.z, 8, OW)], info: { x: w.x, y: w.y + 2, z: w.z } }; },
  found: (p, d, e, q) => { if (Object.keys(e.mp || {}).length < 4) { delete e.f[`${q.i}.hidisle`]; return []; } addPt(p, e, 25); scrap(e, "隠された 島"); const g = giveGold(d, 30000); save(p, d); return [`§b§l隠された 島を 見つけた！ §r§e${g}`, ...prize(p, d, 6, 2, 2)]; } });
// 131) 滝つぼの 宝（滝の うらの くぼみ）
addKind("falls", { sz: 4, n: "滝の うら", h: "滝の うらの くぼみに 宝", at: NOT_SKY,
  build: ({ x, z, gy, i, rock, chestCmds, rollTier }) => ({ cmds: [`fill ${x - 3} ${gy - 1} ${z} ${x + 3} ${gy + 7} ${z + 3} ${rock}`, `fill ${x - 1} ${gy} ${z + 1} ${x + 1} ${gy + 2} ${z + 2} air`, `fill ${x - 2} ${gy + 7} ${z - 1} ${x + 2} ${gy + 7} ${z - 1} ${rock}`, `fill ${x - 2} ${gy + 8} ${z - 1} ${x + 2} ${gy + 8} ${z - 1} water`, `fill ${x - 3} ${gy - 1} ${z - 4} ${x + 3} ${gy - 1} ${z - 2} ${rock}`, ...chestCmds(x, gy, z + 2, rollTier(4, Math.floor(i / 3)), OW)], info: { x, y: gy, z: z + 2 } }) });
// 134) 古い 井戸（はしごで 下の 部屋へ）
addKind("well", { sz: 3, uy: 14, n: "古い 井戸", h: "のぞくと 下に 部屋が ある", at: NOT_SKY,
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const y = Math.max(-48, gy - 14); return { cmds: [`fill ${x - 1} ${gy} ${z - 1} ${x + 1} ${gy} ${z + 1} cobblestone`, `fill ${x} ${y} ${z} ${x} ${gy} ${z} air`, `fill ${x} ${y + 1} ${z - 1} ${x} ${gy - 1} ${z - 1} cobblestone`, `fill ${x} ${y + 1} ${z} ${x} ${gy} ${z} ladder ["facing_direction"=3]`, `fill ${x - 2} ${y - 1} ${z + 1} ${x + 2} ${y + 2} ${z + 5} air`, `fill ${x - 2} ${y - 2} ${z + 1} ${x + 2} ${y - 2} ${z + 5} cobblestone`, `setblock ${x} ${y + 3} ${z + 3} glowstone`, ...chestCmds(x, y - 1, z + 4, rollTier(4, Math.floor(i / 3)), OW)], info: { x, y: y - 1, z: z + 3 } }; } });
// 163) 火山の 地下の 溶岩洞 / 164) 雪山の 氷の 洞くつ
addKind("lavacave", { sz: 6, uy: 18, n: "溶岩洞", h: "火山の 地下の 赤い 洞くつ", at: (i, s) => s === "volcano",
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const y = Math.max(-48, gy - 18); return { cmds: [`fill ${x - 6} ${y - 1} ${z - 6} ${x + 6} ${y + 5} ${z + 6} blackstone hollow`, `fill ${x - 5} ${y} ${z - 5} ${x + 5} ${y + 4} ${z + 5} air`, `fill ${x - 5} ${y - 1} ${z - 5} ${x + 5} ${y - 1} ${z + 5} blackstone`, `fill ${x + 3} ${y - 1} ${z + 3} ${x + 4} ${y - 1} ${z + 4} lava`, `setblock ${x} ${y + 5} ${z} shroomlight`, ...chestCmds(x - 3, y, z - 3, rollTier(5, Math.floor(i / 3)), OW)], info: { x, y, z } }; } });
addKind("icecave", { sz: 6, uy: 16, n: "氷の 洞くつ", h: "雪山の 地下の 青い 洞くつ", at: (i, s) => s === "snow",
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const y = Math.max(-48, gy - 16); return { cmds: [`fill ${x - 5} ${y - 1} ${z - 5} ${x + 5} ${y + 5} ${z + 5} packed_ice hollow`, `fill ${x - 4} ${y} ${z - 4} ${x + 4} ${y + 4} ${z + 4} air`, `setblock ${x} ${y + 4} ${z} sea_lantern`, ...chestCmds(x + 2, y, z + 2, rollTier(5, Math.floor(i / 3)), OW)], info: { x, y, z } }; } });
// 165) 竜の 背骨の 化石（ルインズ荒野の 目印）
addKind("dbone", { sz: 11, n: "竜の 背骨", h: "荒野に のこる 大きな 骨。化石が とれる", at: (i, s) => s === "castle" || s === "desert",
  build: ({ x, z, gy }) => { const C = []; for (let k = -8; k <= 8; k += 4) C.push(`fill ${x + k} ${gy} ${z - 3} ${x + k} ${gy + 4} ${z - 3} bone_block`, `fill ${x + k} ${gy} ${z + 3} ${x + k} ${gy + 4} ${z + 3} bone_block`, `fill ${x + k} ${gy + 5} ${z - 3} ${x + k} ${gy + 5} ${z + 3} bone_block`); C.push(`fill ${x - 10} ${gy + 5} ${z} ${x + 10} ${gy + 5} ${z} bone_block`); return { cmds: C, info: { x, y: gy, z } }; },
  found: (p, d, e, q) => { addPt(p, e, 8); giveItem(p, "mrpg:x_fossil", 2); scrap(e, "竜の 背骨"); return ["§6§l竜の 背骨の 化石", "§f化石の かけら ×2 を ひろった"]; }, near: (L, I, dh) => dh < 8 });
// 166) 天空郷の 空への 階段
addKind("stairs", { sz: 13, n: "空への 階段", h: "雲の 上まで つづく 白い 階段", at: (i, s) => s === "sky",
  build: ({ x, z, gy, i, chestCmds, rollTier }) => { const C = []; for (let k = 0; k < 16; k++) C.push(`setblock ${x - 8 + k} ${gy + k} ${z} quartz_block`); C.push(`fill ${x + 8} ${gy + 16} ${z - 2} ${x + 12} ${gy + 16} ${z + 2} quartz_block`, ...chestCmds(x + 10, gy + 17, z, rollTier(5, Math.floor(i / 3)), OW)); return { cmds: C, info: { x: x + 10, y: gy + 17, z } }; } });
// 161) 地方の ことわざの 碑
const PROV = ["急がば まわれ、草原は ひろい", "古木の 下では 声を ひそめよ", "城あとの 石は 人の 名を おぼえている", "火の 山に 水は いらぬ、勇気が いる", "砂の 下に 時が ねむる", "光る 石は 夜に 歌う", "潮の 満ち干きを 読む 者は 迷わない", "灯を 消すな、魂が 迷う", "吹雪の 夜は 足あとを 信じよ", "灰の 中にも 芽は ある", "羽の ない 者は 階段を のぼれ"];
addKind("proverb", { sz: 1, n: "ことわざの 碑", h: "地方の ことわざが きざまれた 小さな 碑", at: ALL,
  build: ({ x, z, gy }) => ({ cmds: [`setblock ${x} ${gy} ${z} stone_brick_wall`, `setblock ${x} ${gy + 1} ${z} chiseled_stone_bricks`, `setblock ${x} ${gy + 2} ${z} lantern`], info: { x, y: gy, z } }),
  found: (p, d, e, q) => { addPt(p, e, 4); e.pv = e.pv || {}; e.pv[q.i] = 1; scrap(e, "ことわざの 碑"); return [`§6ことわざの 碑: §f「${PROV[q.i] || ""}」 §7（${Object.keys(e.pv).length}/${WREGIONS.length}）`]; } });
// 143) 砂漠の 蜃気楼（遠くに 町が 見える… 着くと 宝）
addKind("mirage", { sz: 2, n: "蜃気楼", h: "砂漠の 遠くに ゆらめく 町。たどりつくと…", at: (i, s) => s === "desert",
  build: ({ x, z, gy }) => ({ cmds: [], info: { x, y: gy, z } }),
  found: (p, d, e, q) => { addPt(p, e, 10); const I = q.info || q; for (const c of chestAtCmds(I.x, I.y, I.z, q.i)) run(p.dimension, c); scrap(e, "蜃気楼"); return ["§e§l蜃気楼の 町は 消えた…… 足もとに 宝箱が 残って いる！"]; } });
const chestAtCmds = (x, y, z, i) => chestCmds(x, y, z, 5 + Math.floor(i / 4), OW);
// 152) 初心者の 森（はじまりの 地方の ヒント）
addKind("beginner", { sz: 4, n: "初心者の 森の 看板", h: "冒険の ヒント", at: (i) => i === 0,
  build: ({ x, z, gy }) => ({ cmds: [`fill ${x} ${gy} ${z} ${x} ${gy + 1} ${z} oak_fence`, `setblock ${x} ${gy + 2} ${z} lantern`, `fill ${x + 3} ${gy} ${z} ${x + 3} ${gy + 1} ${z} oak_fence`, `setblock ${x + 3} ${gy + 2} ${z} lantern`], info: { x, y: gy, z } }),
  found: (p, d, e, q) => { addPt(p, e, 3); return ["§a§l初心者の 森の ヒント", "§f・ガイドブック → 冒険 →「探索手帳」で 地方の 記録", "§f・展望台に 登ると 秘境が わかる", "§f・光る 結晶を こわすと 素材", "§f・ライドの 種類で 行ける 場所が ふえる"]; } });
// 153) 海の 渦潮 / 154) 夜光虫の 浜
addKind("whirl", { sz: 2, n: "渦潮", h: "水が うずまく 所。宝が 流れて くる", at: (i, s) => ["port", "village", "forest"].includes(s),
  build: ({ x, z, dim, findWater, skip }) => { const w = findWater(dim, x, z, 40); if (w === "wait") return false; if (!w) return skip(); return { cmds: [], info: { x: w.x, y: w.y + 1, z: w.z, wt: 1 } }; },
  found: (p, d, e, q) => { addPt(p, e, 6); return ["§b§l渦潮から 宝が 流れて きた！", ...prize(p, d, q.i, 0, 1)]; }, near: (L, I, dh) => dh < 6 });
addKind("glowbeach", { sz: 2, n: "夜光虫の 浜", h: "夜に 水が 青く 光る 浜", at: (i, s) => s === "port",
  build: ({ x, z, dim, findWater, skip }) => { const w = findWater(dim, x, z, 40); if (w === "wait") return false; if (!w) return skip(); return { cmds: [], info: { x: w.x, y: w.y + 1, z: w.z, wt: 1 } }; },
  found: (p, d, e, q) => { if (!isNight()) { delete e.f[`${q.i}.glowbeach`]; return []; } addPt(p, e, 8); giveItem(p, "mrpg:x_mari", 2); return ["§b§l夜光虫の 浜", "§f青い 光の 中で 潮の 真珠 ×2 を ひろった"]; }, near: (L, I, dh) => dh < 10 });
// 133) キノコの 輪（夜に 妖精の 子）
addKind("mushring", { sz: 4, n: "キノコの 輪", h: "夜に 妖精の 子が 来る と いう", at: (i, s) => ["forest", "village", "garden"].includes(s),
  build: ({ x, z, gy }) => { const C = []; for (let a = 0; a < 8; a++) { const X = Math.round(x + Math.cos((a * Math.PI) / 4) * 3), Z = Math.round(z + Math.sin((a * Math.PI) / 4) * 3); C.push(`setblock ${X} ${gy - 1} ${Z} podzol`, `setblock ${X} ${gy} ${Z} ${a % 2 ? "red_mushroom" : "brown_mushroom"}`); } return { cmds: C, info: { x, y: gy, z } }; },
  found: (p, d, e, q) => { if (!isNight()) { delete e.f[`${q.i}.mushring`]; return []; } addPt(p, e, 10); const s = pickSp(d, (S) => (S.aff?.ge || [])[0] === "light", 5); if (s) spawnJoiner(p, s, Math.max(5, regionLv(p.location)), "妖精の 子 "); return ["§d§lキノコの 輪に 妖精の 子が あらわれた！ §r§7（なぐると 話せる）"]; }, near: (L, I, dh) => dh < 3 });
// 132) 木の 上の 鳥の 巣 / 21) 野生の 巣（地上）
addKind("treenest", { sz: 4, n: "木の 上の 巣", h: "大きな 木の 上に 巣。タマゴが ある", at: (i, s) => ["forest", "village", "garden", "castle"].includes(s),
  build: ({ x, z, gy }) => ({ cmds: [`fill ${x} ${gy} ${z} ${x} ${gy + 8} ${z} oak_log`, `fill ${x - 3} ${gy + 7} ${z - 3} ${x + 3} ${gy + 8} ${z + 3} oak_leaves ["persistent_bit"=true]`, `setblock ${x} ${gy + 9} ${z} hay_block`], info: { x, y: gy + 10, z } }),
  found: (p, d, e, q) => { addPt(p, e, 8); const id = egg(d); if (id) giveItem(p, `mrpg:${id}`, 1); return ["§a§l木の 上の 巣", id ? `§f${ITEMS[id].name} を 見つけた！` : "§7巣は からっぽだった"]; } });
addKind("gnest", { sz: 3, n: "野生の 巣", h: "草で 作った 大きな 巣。親が 近くに いる", at: (i, s) => ["village", "forest", "castle", "desert"].includes(s),
  build: ({ x, z, gy }) => ({ cmds: [`fill ${x - 2} ${gy - 1} ${z - 2} ${x + 2} ${gy - 1} ${z + 2} hay_block`, `fill ${x - 2} ${gy} ${z - 2} ${x + 2} ${gy} ${z + 2} hay_block outline`, `fill ${x - 1} ${gy} ${z - 1} ${x + 1} ${gy} ${z + 1} air`], info: { x, y: gy, z } }),
  found: (p, d, e, q) => { addPt(p, e, 8); const id = egg(d); if (id) giveItem(p, `mrpg:${id}`, 1); try { spawnWildNear(p, 1, 6, 10); } catch {} return ["§a§l野生の 巣", id ? `§f${ITEMS[id].name} を 見つけた！ §c親が おこって いる！` : "§7巣は からっぽだった"]; }, near: (L, I, dh) => dh < 3 });

// ================= 7つの 秘宝・地図の 切れ端・手紙 =================
const LETTERS = ["この 草原で 最初の 仲間に 出会った。あの 日の 空を わすれない", "森の 奥で 声を 聞いた。木が 話す とは 思わなかった", "城が くずれた 日、歯車の 音が 止まった", "鍛冶の 火は 消して は ならない と 祖父は 言った", "砂の 中から 骨が 出た。竜の ものらしい", "満月の 夜、結晶が 歌って いた", "嵐の あとの 海は 宝を 運んで くる", "冥府の 灯を たどれば 迷わない", "吹雪の 夜、白い 子が 道を 教えて くれた", "灰の 降る 地で 芽を 見つけた", "空の 島へ 行く 階段が ある と いう"];
TITLES.ex_relic = ["秘宝の 守り手", "7つの 秘宝を 集め 最後の 秘境へ"];
function mapPiece(p, e, k, why) { e.mp = e.mp || {}; if (e.mp[k]) return; e.mp[k] = 1; const n = Object.keys(e.mp).length; say(p, `§6§l古い 地図の 切れ端を 手に入れた！ §r§6（${n}/4・${why}）${n >= 4 ? " §b地図が つながった！ マリノア諸島に 隠された 島が ある" : ""}`); exSave(p, true); }

// ================= 空と 天気の できごと（XT.evt）=================
XT.evt.rainbow = { n: "虹の 根もと", title: "§d§l虹が 出た！", pt: "minecraft:villager_happy", got: (p, d, e, v) => { addPt(p, e, 8); const i = regAtLoc(v); const g = giveGold(d, 400 * (i + 1)); save(p, d); scrap(e, "虹の 根もと"); return [`§d虹の 根もとに 宝が あった！ §f${g}`, ...prize(p, d, i, 0, 1)]; } };
XT.evt.bolt = { n: "雷の 落ちた 所", title: "§e§l近くに 雷が 落ちた！", pt: "minecraft:electric_spark_particle", got: (p, d, e) => { addPt(p, e, 5); giveItem(p, "mrpg:x_thunder", 1); return ["§e雷の 結晶 を ひろった！"]; } };
XT.evt.meteor = { n: "隕石", title: "§c§l隕石が 落ちた！", pt: "minecraft:basic_flame_particle", got: (p, d, e, v) => { addPt(p, e, 20); run(p.dimension, `fill ${v.x - 2} ${v.y - 2} ${v.z - 2} ${v.x + 2} ${v.y - 1} ${v.z + 2} magma`); giveItem(p, "mrpg:x_gem", 3); giveItem(p, "mrpg:x_fossil", 1); mapPiece(p, e, "meteor", "隕石"); scrap(e, "隕石"); return ["§c§l隕石の あと！ §r§f原石 ×3・化石の かけら"]; } };
XT.evt.balloon = { n: "風船", title: "§b§l宝の 風船が 飛んで いる！", pt: "minecraft:totem_particle", got: (p, d, e, v) => { addPt(p, e, 8); return ["§b風船を つかまえた！", ...prize(p, d, regAtLoc(v), 1, 1)]; } };
XT.evt.wisp = { n: "鬼火", title: "§5§l鬼火が ゆれて いる…", pt: "minecraft:soul_particle", got: (p, d, e) => { addPt(p, e, 8); giveItem(p, "mrpg:x_necro", 2); return ["§5鬼火を つかまえた！ §f魂の 灯 ×2"]; } };
XT.evt.lantern = { n: "灯籠", title: "§6§l水に 灯籠が 流れて いる", pt: "minecraft:basic_flame_particle", got: (p, d, e, v) => { addPt(p, e, 5); return ["§6灯籠に 願いを こめた", ...prize(p, d, regAtLoc(v), 0, 1)]; } };

// ================= 環境の レア（第2弾・53）=================
ENVR.push(
  { id: "dusk", n: "黄昏の 子", c: "夕焼けの 時間（地上）", el: "fire", dusk: 1 },
  { id: "eclipse", n: "日食の 子", c: "日食の とき", el: "dark", ecl: 1 },
  { id: "shower", n: "流星群の 子", c: "流星群の 夜", el: "light", shower: 1 },
  { id: "rainbow2", n: "虹の 子", c: "雨上がりの 昼", el: "water", rbow: 1 },
  { id: "ash", n: "灰の 雨の 子", c: "終焉の地の 冥府の 霧", el: "dark", reg: 9, wxe: 1 },
  { id: "storm2", n: "嵐の 海の 子", c: "マリノア諸島の 海の 嵐", el: "thunder", reg: 6, wxe: 1 },
  { id: "dune", n: "砂嵐の 子", c: "サンドリア砂漠の 砂嵐", el: "earth", reg: 4, wxe: 1 },
  { id: "blizz", n: "吹雪の 子", c: "フロストヘイム雪山の 吹雪", el: "ice", reg: 8, wxe: 1 },
  { id: "legend1", n: "伝説: 天を 舞う 竜", c: "物語の あと・天空郷の 雷雨の 夜", el: "thunder", reg: 10, w: "thunder", night: 1, leg: 1 },
  { id: "legend2", n: "伝説: 海の 王", c: "物語の あと・満月の 夜の 海", el: "water", sea: 1, night: 1, moon: 0, leg: 1 },
);
const ECL = { t: 0 }; const SHOWER = () => dayNo() % 7 === 3;   // 15) 週に 1回の 流星群
const AFTER = { rain: 0 }; try { world.afterEvents.weatherChange.subscribe((ev) => { try { if (/rain|thunder/i.test(String(ev.previousWeather || "")) && !/rain|thunder/i.test(String(ev.newWeather || ""))) AFTER.rain = nowT(); } catch {} }); } catch {}
function env2Ok(r, e) {
  const t = timeOf();
  if (r.dusk) return t >= 11500 && t < 13000;
  if (r.ecl) return ECL.t > nowT();
  if (r.shower) return SHOWER() && isNight();
  if (r.rbow) return nowT() - AFTER.rain < 300000 && t < 12000;
  if (r.wxe) return !!wxOf(r.reg) && regAtLoc(e.location) === r.reg;
  return null;   // 第1弾と 同じ 判定（explore.js）
}
// 11) 季節・14) 日食・16〜53) 第2弾の 判定（explore の override の あとに 足す）
const SEASON = () => { const m = new Date(Date.now() + 9 * 3600000).getUTCMonth() + 1; return m <= 2 || m === 12 ? ["冬", "blob"] : m <= 5 ? ["春", "animal"] : m <= 8 ? ["夏", "aqua"] : ["秋", "beast"]; };
system.run(() => system.run(() => {
  const prev = hooks.override;
  hooks.override = (e, lv, sid) => {
    const r0 = prev ? prev(e, lv, sid) : null; if (r0) return r0;
    if (e.dimension.id !== OW) return null;
    // 第2弾の 環境の レア
    const L = ENVR.slice(10).filter((r) => { const v = env2Ok(r, e); if (v !== null) return v && rnd() < 1 / 30; if (r.leg) { const q = world.getAllPlayers().find((p) => hd(p.location, e.location) < 64); try { if (!q || !endingDone(load(q))) return false; } catch { return false; } } if (r.reg !== undefined && regAtLoc(e.location) !== r.reg) return false; if (r.sea && !e.hasTag("mrpg_sea")) return false; if (r.night && !isNight()) return false; if (r.moon !== undefined) { let m = -1; try { m = world.getMoonPhase(); } catch {} if (m !== r.moon) return false; } if (r.w && !new RegExp(r.w, "i").test(weather(e.dimension))) return false; return rnd() < (r.leg ? 1 / 200 : 1 / 30); });
    if (L.length) {
      const r = pickA(L), s = r.leg ? legendSid(r) : envSid(r, lv); if (s) { try { e.setDynamicProperty("mrpg:envr", r.id); } catch {} return { sid: s, lv: Math.min(100, lv + (r.leg ? 15 : 3)), q: r.leg ? 1 : 0.7, tags: ["mrpg_rare", "mrpg_envr"], msg: `§b§l${r.c}… §r§b${r.n}「§f${SPECIES[s].name}§b」の 気配が する！` }; }
    }
    // 日食: 闇の 子が 多い
    if (ECL.t > nowT() && rnd() < 0.3) { const L2 = ORDER.filter((s) => okSp(s) && SPECIES[s].wild && (SPECIES[s].aff?.ge || [])[0] === "dark" && SPECIES[s].rank === SPECIES[sid]?.rank); if (L2.length) return { sid: pickA(L2), plain: 1 }; }
    // 季節の 系統が 出やすい（1割）
    if (rnd() < 0.1) { const fam = SEASON()[1]; const L3 = ORDER.filter((s) => okSp(s) && SPECIES[s].wild && SPECIES[s].fam === fam && SPECIES[s].rank === SPECIES[sid]?.rank); if (L3.length) return { sid: pickA(L3), plain: 1 }; }
    // 25) 変わり種（2%）・20) 眠って いる 子（4%）
    const u = rnd(); if (u < 0.02) return { sid, tags: ["mrpg_odd"], plain: 1 }; if (u < 0.06) return { sid, tags: ["mrpg_sleep"], plain: 1 };
    return null;
  };
}));
const LEG = new Map();
function legendSid(r) { if (LEG.has(r.id)) return LEG.get(r.id); const L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && S.fam !== "god" && S.fam !== "king" && S.rank === "SS" && (S.aff?.ge || [])[0] === r.el; }); const s = L.length ? L[hash(r.id) % L.length] : null; LEG.set(r.id, s); return s; }
// override で 返した タグを つける（変わり種・眠り）: field.js が ov.tags を つける。名前の 印だけ ここで
system.runInterval(() => {
  for (const e of world.getDimension("overworld").getEntities({ type: TYPE, tags: ["mrpg_odd"], excludeTags: ["mrpg_oddn", "mrpg_battle"] })) { try { e.addTag("mrpg_oddn"); e.setProperty("mrpg:size", 140); e.nameTag = `§d変わり種の ${e.nameTag.replace(/§./g, "")}`; } catch {} }
  for (const e of world.getDimension("overworld").getEntities({ type: TYPE, tags: ["mrpg_sleep"], excludeTags: ["mrpg_battle"] })) { try { fx(e.dimension, "minecraft:white_smoke_particle", { x: e.location.x, y: e.location.y + 1.8, z: e.location.z }); } catch {} }
}, 100);

// ================= 見はり（2秒ごと・プレイヤーごと）=================
const GROUP = new Map();   // 18) 群れ: id -> { n, left, pid }
let gid = 1;
const FOLLOW = new Map();  // 23) ついてくる 野生
XT.tick.push((p, d, e, i, L, tk) => {
  const ph = (tk + (hash(p.id) % 30)) % 30, st = style(i);
  // 50) 最高・最低地点 / 51) 歩いた きょり（乗って いない とき）
  e.ymax = Math.max(e.ymax ?? -999, Math.floor(L.y)); e.ymin = Math.min(e.ymin ?? 999, Math.floor(L.y));
  const last = WALK.get(p.id); WALK.set(p.id, { x: L.x, z: L.z });
  let riding = null; try { riding = p.getComponent("minecraft:riding")?.entityRidingOn; } catch {}
  if (last) { const dd = hd(L, last); if (dd > 0.5 && dd < 30) { if (riding) e.rdm = Math.round((e.rdm || 0) + dd); else { const inW = inWater(p); if (inW) e.swim = Math.round((e.swim || 0) + dd); else e.walk = Math.round((e.walk || 0) + dd); } walkPrize(p, d, e); } }
  // 5) 溶岩ボート（浮遊ライドは 火山で 火に 強い）・155) ライドの 技
  if (riding && riding.hasTag?.("mrpg_pet")) {
    let mid; try { mid = riding.getDynamicProperty("mrpg:mid"); } catch {}
    const rl = mid ? Math.min(5, [500, 1500, 3500, 7000, 12000].filter((n) => (e.rd?.[mid] || 0) >= n).length) : 0;
    try { if (st === "volcano") p.addEffect("fire_resistance", 60, { showParticles: false }); if (rl >= 3) riding.addEffect("jump_boost", 60, { amplifier: 1, showParticles: false }); if (rl >= 5) riding.addEffect("speed", 60, { amplifier: 0, showParticles: false }); } catch {}
  }
  // 129) 泳ぎの 熟練度
  if (!riding && (e.swim || 0) >= 2000 && inWater(p)) try { p.addEffect("water_breathing", 80, { showParticles: false }); if ((e.swim || 0) >= 8000) p.addEffect("dolphins_grace", 60, { showParticles: false }); } catch {}
  // 6) 雪崩（雪山を いきおいよく 下る と）
  if (st === "snow" && last && LASTY.has(p.id) && LASTY.get(p.id) - L.y > 6 && rnd() < 0.05 && !e.av && nowT() - (e.avt || 0) > 600000) { e.avt = nowT(); e.av = { t: nowT(), x: L.x, z: L.z }; showTitle(p, "§f§l雪崩だ！", { subtitle: "§7にげろ！", fadeInDuration: 2, stayDuration: 30, fadeOutDuration: 6 }); for (let k = 0; k < 12; k++) fx(p.dimension, "minecraft:snowflake_particle", { x: L.x + (rnd() - 0.5) * 8, y: L.y + 3 + rnd() * 4, z: L.z + (rnd() - 0.5) * 8 }); }
  if (e.av && nowT() - e.av.t > 6000) { const ok = hd(L, e.av) > 18; delete e.av; if (ok) { addPt(p, e, 6); say(p, "§a雪崩から にげきった！"); prize(p, d, i, 0, 1); } else try { p.addEffect("slowness", 100, { amplifier: 1 }); say(p, "§7雪に うもれた……"); } catch {} }
  LASTY.set(p.id, L.y);
  // 69) 暗い 所の 明かり（連れ歩き中・地下）
  if (d.out && L.y < 50 && !isSky(p)) lightTick(p); else lightOff(p);
  // 147) 結晶の 共鳴音
  if (st === "crystal" && ph % 3 === 0) { const q = spotsOf(i).find((s) => s.info && s.info.ok && !e.f[`${i}.${s.k}`] && hd(L, s.info) < 40); if (q) try { p.playSound("block.amethyst_block.chime", { pitch: 0.6 + (40 - hd(L, q.info)) / 40, volume: 0.6 }); } catch {} }
  // 68) 素材の 自動回収（探索ランク 6）
  if (xRank(e.pt) >= 6) for (const [k, v] of NODES) if (v.pid === p.id && hd(L, v) < 6 && Math.abs(L.y - v.y) < 4) { NODES.delete(k); run(p.dimension, `setblock ${v.x} ${v.y} ${v.z} air`); const id = MATS[v.i]; if (id) { giveItem(p, `mrpg:${id}`, 1); bar(p, `§d${ITEMS[id].name} §fを 自動で ひろった`); } }
  // 157) 秘境の 宝箱が 週1回 復活
  if (ph === 5) { const wk = Math.floor(dayNo() / 7); for (const q of spotsOf(i)) { if (!["nest", "isle", "hollow", "sky"].includes(q.k) || !q.info?.ok || !e.f[`${i}.${q.k}`] || hd(L, q.info) > 8) continue; const key = `mrpg:exr:${i}:${q.k}`; let w; try { w = world.getDynamicProperty(key); } catch {} if (w === wk) continue; try { const b = p.dimension.getBlock(q.info); if (!b || !b.isAir) continue; world.setDynamicProperty(key, wk); } catch { continue; } for (const c of chestCmds(q.info.x, q.info.y, q.info.z, 3 + Math.floor(i / 3), OW)) run(p.dimension, c); say(p, "§d秘境の 宝箱が また 現れた（週に 1回）"); } }
  // 渦潮・夜光虫・蜃気楼の 見た目
  if (ph % 2 === 0) for (const q of spotsOf(i)) { if (!q.info?.ok || hd(L, q.info) > 50) continue; const I = q.info;
    if (q.k === "whirl") for (let a = 0; a < 6; a++) fx(p.dimension, "minecraft:water_splash_particle", { x: I.x + Math.cos(tk + a) * 3, y: I.y, z: I.z + Math.sin(tk + a) * 3 });
    if (q.k === "glowbeach" && isNight()) for (let a = 0; a < 5; a++) fx(p.dimension, "minecraft:electric_spark_particle", { x: I.x + (rnd() - 0.5) * 10, y: I.y, z: I.z + (rnd() - 0.5) * 10 });
    if (q.k === "mirage" && !e.f[`${i}.mirage`] && hd(L, I) > 20) for (let a = 0; a < 6; a++) fx(p.dimension, "minecraft:white_smoke_particle", { x: I.x + (a - 3) * 2, y: I.y + 3 + (a % 3) * 2, z: I.z });
    if (q.k === "relic" && !e.f[`${i}.relic`]) fx(p.dimension, "minecraft:totem_particle", { x: I.x + 0.5, y: I.y + 2, z: I.z + 0.5 }); }
  // 3) 崩れる 橋
  bridgeTick(p, i, L);
  // 少しずつ 起きる こと
  if (ph === 3 && !EVT.has(p.id)) {
    const w = weather(p.dimension), night = isNight();
    if (/thunder/i.test(w) && rnd() < 0.1) startEvt(p, "bolt");   // 17) 雷の 結晶
    else if (nowT() - AFTER.rain < 300000 && !night && rnd() < 0.15) startEvt(p, "rainbow");   // 13) 虹
    else if (night && SHOWER() && rnd() < 0.25) startEvt(p, "star");   // 15) 流星群
    else if (night && rnd() < 0.004) startEvt(p, "meteor");   // 135) 隕石（まれ）
    else if (st === "sky" && rnd() < 0.06) startEvt(p, "balloon");   // 148) 風船
    else if (night && (i === 7 || i === 9) && rnd() < 0.08) startEvt(p, "wisp");   // 146) 鬼火
    else if (night && [0, 1, 6].includes(i) && inNearWater(p) && rnd() < 0.08) startEvt(p, "lantern");   // 130) 灯籠流し
  }
  if (ph === 13) {
    // 14) 日食（とても まれ・昼・ワールドで 1つ）
    if (ECL.t < nowT() && timeOf() < 12000 && rnd() < 0.002) { ECL.t = nowT() + 180000; for (const q of world.getAllPlayers()) try { showTitle(q, "§8§l日食", { subtitle: "§7空が 暗く なった… 闇の 子が さわぎだす", fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 10 }); } catch {} }
    // 18) 群れ（3%）・19) 縄張り争い（2%）
    const u = rnd();
    if (u < 0.03) herd(p, d, i); else if (u < 0.05) rivals(p, d, i);
  }
  if (ph === 23 && d.out) petTick(p, d, e, i);
});
const WALK = new Map(), LASTY = new Map(), LIGHT = new Map();
const inWater = (p) => { try { const l = p.location; return (p.dimension.getBlock({ x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z) })?.typeId || "").includes("water"); } catch { return false; } };
const inNearWater = (p) => { try { const l = p.location; for (const [dx, dz] of [[3, 0], [-3, 0], [0, 3], [0, -3]]) if ((p.dimension.getBlock({ x: Math.floor(l.x + dx), y: Math.floor(l.y - 1), z: Math.floor(l.z + dz) })?.typeId || "").includes("water")) return true; } catch {} return false; };
const isSky = (p) => { try { const t = p.dimension.getTopmostBlock({ x: Math.floor(p.location.x), z: Math.floor(p.location.z) }); return !t || t.location.y < p.location.y + 1; } catch { return true; } };
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { WALK.delete(playerId); LASTY.delete(playerId); const o = LIGHT.get(playerId); LIGHT.delete(playerId); if (o) try { const b = world.getDimension("overworld").getBlock(o); if (b && /light_block/.test(b.typeId)) run(world.getDimension("overworld"), `setblock ${o.x} ${o.y} ${o.z} air`); } catch {} }); } catch {}
function lightTick(p) {
  const l = p.location, x = Math.floor(l.x), y = Math.floor(l.y) + 1, z = Math.floor(l.z), old = LIGHT.get(p.id);
  if (old && old.x === x && old.y === y && old.z === z) return;
  let b; try { b = p.dimension.getBlock({ x, y, z }); } catch { return; }
  if (!b || !b.isAir) return;
  lightOff(p); run(p.dimension, `setblock ${x} ${y} ${z} light_block_12`); LIGHT.set(p.id, { x, y, z });
}
function lightOff(p) { const o = LIGHT.get(p.id); if (!o) return; LIGHT.delete(p.id); try { const b = p.dimension.getBlock(o); if (b && /light_block/.test(b.typeId)) run(p.dimension, `setblock ${o.x} ${o.y} ${o.z} air`); } catch {} }
// 3) 崩れる 橋
const BRIDGE = new Map();   // "i" -> { t, cut: [] }
function bridgeTick(p, i, L) {
  const I = spotInfo(i, "bridge"); if (!I || !I.ok || I.bx === undefined) return;
  const B = BRIDGE.get(i) || { t: 0, cut: [] };
  if (B.cut.length && nowT() - B.t > 60000) { run(p.dimension, `fill ${I.bx - 4} ${I.by} ${I.z} ${I.bx + 4} ${I.by} ${I.z} spruce_planks`); B.cut = []; }
  if (Math.abs(L.y - (I.by + 1)) < 0.6 && Math.abs(L.z - I.z - 0.5) < 1.2 && L.x >= I.bx - 4 && L.x <= I.bx + 5) {
    const x = Math.floor(L.x) - 1; if (x >= I.bx - 4 && x <= I.bx + 4 && !B.cut.includes(x)) { system.runTimeout(() => run(p.dimension, `setblock ${x} ${I.by} ${I.z} air`), 12); B.cut.push(x); B.t = nowT(); fx(p.dimension, "minecraft:basic_smoke_particle", { x: x + 0.5, y: I.by + 0.5, z: I.z + 0.5 }); }
  }
  BRIDGE.set(i, B);
}
// 18) 群れ・19) 縄張り争い
function herd(p, d, i) {
  const lv = Math.max(1, regionLv(p.location)), s = pickSp(d, () => true, rkForLv(lv) - 1); if (!s) return;
  const g = groundNear(p, 18, 26); if (!g) return; const id = gid++;
  for (let k = 0; k < 5; k++) { let e; try { e = p.dimension.spawnEntity(TYPE, { x: g.x + k * 1.5, y: g.y, z: g.z + (k % 2) }); } catch { continue; } setLook(e, s); e.addTag("mrpg_herd"); e.addTag(`mrpg_hd${id}`); try { e.setDynamicProperty("mrpg:lv", lv); e.setDynamicProperty("mrpg:q", 0.3); } catch {} e.nameTag = `§a群れの ${SPECIES[s].name} §7Lv${lv}`; }
  GROUP.set(id, { n: 5, left: 5, pid: p.id, t: nowT(), i });
  say(p, `§a${SPECIES[s].name}の 群れが 移動して いる！ §7（${dirTo(p.location, g)}・ぜんぶ 倒すと ボーナス）`);
}
function rivals(p, d, i) {
  const lv = Math.max(1, regionLv(p.location)), s1 = pickSp(d, () => true, rkForLv(lv)), s2 = pickSp(d, () => true, rkForLv(lv)); if (!s1 || !s2) return;
  const g = groundNear(p, 14, 22); if (!g) return;
  const E = []; for (const [s, dx] of [[s1, -1.5], [s2, 1.5]]) { try { const e = p.dimension.spawnEntity(TYPE, { x: g.x + dx, y: g.y, z: g.z }); setLook(e, s); e.setDynamicProperty("mrpg:lv", lv); E.push(e); } catch {} }
  say(p, `§6野生の ${SPECIES[s1].name}と ${SPECIES[s2].name}が 縄張り争いを して いる！ §7（${dirTo(p.location, g)}）`);
  for (let k = 0; k < 6; k++) system.runTimeout(() => fx(p.dimension, "minecraft:basic_crit_particle", { x: g.x, y: g.y + 1, z: g.z }), k * 20);
  system.runTimeout(() => { if (E.length < 2) return; const [w, l] = rnd() < 0.5 ? E : [E[1], E[0]]; try { if (l.isValid() && !l.hasTag("mrpg_battle")) l.remove(); if (w.isValid() && !w.hasTag("mrpg_battle")) { w.setDynamicProperty("mrpg:lv", Math.min(100, lv + 5)); w.addTag("mrpg_rare"); w.nameTag = `§6縄張りの 主 §f${w.nameTag.replace(/§./g, "")}`; } } catch {} }, 200);
}
// 27) 相棒の 寄り道・28) 相棒の ひとこと・156) 行きたい 場所
const TALK = ["草の においが 気持ちいいね", "森の 奥から 何か 聞こえる", "古い 石が いっぱい", "あつい… でも わくわくする", "砂が 目に 入る〜", "キラキラが きれい", "海の 風だ！", "ちょっと こわいかも", "さむい！ くっついて いい？", "ここは しずかすぎる", "空が 近いね"];
function petTick(p, d, e, i) {
  const m = [...d.party, ...(d.bench || []), ...d.box].find((x) => x.id === d.out); if (!m) return;
  e.pk = e.pk || {}; if (!e.pk[i]) { e.pk[i] = 1; say(p, `§b${m.nm}「${TALK[i] || "どこへ 行こう？"}」`); }
  // 26) なつき度（いっしょに 歩くと 上がる）
  e.nk = e.nk || {}; e.nk[m.id] = Math.min(1000, (e.nk[m.id] || 0) + 1);
  if (rnd() < 0.08) { const id = pickA(["c_herb", "c_fruit", "c_water", "x_acorn"]); if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, 1); say(p, `§b${m.nm}が ${ITEMS[id].name} を 拾って きた！`); } }
  if (rnd() < 0.05) { const q = spotsOf(i).find((s) => s.info?.ok && !s.info.skip && !e.f[`${i}.${s.k}`] && (e.t[i] || !KINDS[s.k]?.secret)); if (q) { say(p, `§b${m.nm}が ${dirTo(p.location, q.info)}の ほうを じっと 見て いる…（${KINDS[q.k]?.n}？）`); naviPush(p, { name: `${m.nm}の 行きたい 所`, x: q.info.x, z: q.info.z, dim: OW }); } }
}
export const nkLv = (n) => (n >= 600 ? 3 : n >= 250 ? 2 : n >= 80 ? 1 : 0);
// 169) 歩いた きょりの ごほうび
const WALK_P = [[10000, "c_fruit"], [50000, "f_exp3k"], [100000, "rf_1"], [300000, "i_tal1"], [1000000, "rf_4"]];
function walkPrize(p, d, e) { const tot = (e.walk || 0) + (e.rdm || 0) + (e.swim || 0); e.wk = e.wk || 0; while (e.wk < WALK_P.length && tot >= WALK_P[e.wk][0]) { const [n, id] = WALK_P[e.wk]; e.wk++; if (ITEMS[id]) giveItem(p, `mrpg:${id}`, 1); say(p, `§a§l合計 ${n / 1000}km 旅した！ §r§aごほうび: ${ITEMS[id]?.name || ""}`); exSave(p, true); } }

// ================= 採集の 追加 =================
// 45) 鉱石掘り（石・深層岩から 原石）・145) どんぐり（森の 葉）・126) 洞くつの 鉱脈・150) 埋もれた 遺物
const VEIN = new Map();
try {
  world.afterEvents.playerBreakBlock.subscribe((ev) => {
    const p = ev.player, b = ev.block; if (!p || !b || b.dimension.id !== OW) return;
    const id0 = ev.brokenBlockPermutation?.type?.id || "", L = b.location, key = `${L.x},${L.y},${L.z}`;
    const e = exOf(p), dn = dayNo(); if (!e.gd || e.gd[0] !== dn) e.gd = [dn, 0, 0];
    if (VEIN.has(key)) { const v = VEIN.get(key); VEIN.delete(key); giveItem(p, `mrpg:${v.item}`, v.n); addPt(p, e, 3); bar(p, `§6${ITEMS[v.item]?.name} ×${v.n} を 掘りだした！`); if (v.item === "x_ruins" && rnd() < 0.15) mapPiece(p, e, "bury", "埋もれた 遺物"); exSave(p); return; }
    if (/^minecraft:(stone|deepslate|andesite|diorite|granite|tuff)$/.test(id0) && e.gd[1] < 15 && rnd() < 1 / 150) { e.gd[1]++; giveItem(p, "mrpg:x_gem", 1); bar(p, "§6原石を 掘りあてた！"); exSave(p); }
    else if (/leaves/.test(id0) && regAtLoc(L) === 1 && e.gd[2] < 30 && rnd() < 1 / 12) { e.gd[2]++; giveItem(p, "mrpg:x_acorn", 1); bar(p, "§6どんぐりが 落ちて きた"); exSave(p); }
  });
} catch {}
XT.tick.push((p, d, e, i, L, tk) => {
  const ph = (tk + (hash(p.id) % 30)) % 30; if (ph !== 17 || VEIN.size > 40) return;
  // 126) 洞くつの 鉱脈（地下で ときどき・コウモリの けむり）
  if (L.y < 40 && !isSky(p) && rnd() < 0.35) { const x = Math.floor(L.x + (rnd() - 0.5) * 16), z = Math.floor(L.z + (rnd() - 0.5) * 16), y = Math.floor(L.y); let b; try { b = p.dimension.getBlock({ x, y, z }); } catch {} if (b && /^minecraft:(stone|deepslate|tuff)$/.test(b.typeId) && !hooks.inTown({ x, z }, OW)) { run(p.dimension, `setblock ${x} ${y} ${z} raw_iron_block`); VEIN.set(`${x},${y},${z}`, { item: "x_gem", n: 2, t: nowT() }); for (let k = 0; k < 4; k++) fx(p.dimension, "minecraft:white_smoke_particle", { x: x + 0.5, y: y + 1.5, z: z + 0.5 }); bar(p, "§6近くの 壁に 鉱脈が 見える…"); } }
  // 150) 荒野の 突風・砂嵐で 埋もれた 遺物
  if ((i === 2 || i === 4) && wxOf(i) && rnd() < 0.5) { const g = groundNear(p, 8, 16); if (g) { try { const under = p.dimension.getBlock({ x: g.x, y: g.y - 1, z: g.z }); if (under && /sand|dirt|grass/.test(under.typeId)) { run(p.dimension, `setblock ${g.x} ${g.y - 1} ${g.z} suspicious_sand`); VEIN.set(`${g.x},${g.y - 1},${g.z}`, { item: "x_ruins", n: 2, t: nowT() }); bar(p, "§6風で 何かが 地面から 出て きた…"); } } catch {} } }
});
system.runInterval(() => { const n = nowT(); for (const [k, v] of VEIN) if (n - v.t > 10 * 60000) VEIN.delete(k); }, 1200);
// 142) 雪だるま（雪山で 作ると 雪の 子）
try { world.afterEvents.entitySpawn.subscribe(({ entity }) => { try { if (entity.typeId !== "minecraft:snow_golem" || entity.dimension.id !== OW || regAtLoc(entity.location) !== 8) return; const L = entity.location; const p = world.getAllPlayers().find((q) => hd(q.location, L) < 12); if (!p) return; const d = load(p); if (!d) return; const ex = exOf(p); if (ex.snd === dayNo()) return; ex.snd = dayNo(); exSave(p, true);   /* 1日 1回 */ const s = pickSp(d, (S) => (S.aff?.ge || [])[0] === "ice", 5); entity.remove(); if (s) { spawnJoiner(p, s, Math.max(5, regionLv(L)), "雪の 子 ", { x: Math.floor(L.x), y: Math.floor(L.y), z: Math.floor(L.z) }); say(p, "§b雪だるまが 動きだした…！ §7（なぐると 話せる）"); addPt(p, exOf(p), 5); } } catch {} }); } catch {}
// 144) 温泉卵（秘湯で 1日 1こ）
XT.tick.push((p, d, e, i, L) => { if (!["snow", "volcano", "crystal"].includes(style(i)) || e.egd === dayNo()) return; const I = spotInfo(i, "spring"); if (!I?.ok || hd(L, I) > 3.5 || !inWater(p)) return; e.egd = dayNo(); giveItem(p, "mrpg:fd_egg", 1); say(p, "§e湯に つけて おいた 卵が ゆで あがった！ §f温泉卵"); exSave(p); });
// 1) 地底湖で 釣ると 1段 上（釣りの 名所と 同じ）
system.run(() => { const prev = FISH_HOOK.bonus; FISH_HOOK.bonus = (p) => { let b = 0; try { b = prev ? prev(p) : 0; } catch {} if (b) return b; const i = regAtLoc(p.location), I = spotInfo(i, "lake"); return I?.ok && hd(p.location, I) < 8 && Math.abs(p.location.y - I.y) < 6 ? 1 : 0; }; });
// 46) 魚の 大きさ比べ
FISH_HOOK.after = (p, id) => { const e = exOf(p), cm = Math.round(10 + rnd() * rnd() * 140); e.fb = Math.max(e.fb || 0, cm); exSave(p); say(p, `§7（大きさ ${cm}cm${cm >= e.fb ? " §e自己ベスト！" : ""}§7）`); try { const r = JSON.parse(world.getDynamicProperty("mrpg:fishrank") || "[]").filter((x) => x[0] !== p.name); r.push([p.name, e.fb]); r.sort((a, b) => b[1] - a[1]); world.setDynamicProperty("mrpg:fishrank", JSON.stringify(r.slice(0, 10))); } catch {} };

// ================= 戦いの あと（群れ・変わり種・番人・名人・守り神 など）=================
TITLES.ex_odd = ["変わり者 好き", "変わり種を 5体 記録"]; TITLES.ex_herd = ["群れを 制す", "群れを 1つ 全部 倒す"]; TITLES.ex_dist = ["大陸 横断", "合計 100km 旅する"];
battleHooks.push((B, x) => {
  const { p, d } = x; try { if (!p.isValid()) return; } catch { return; }
  const log = (x.plog = x.plog || []), e = exOf(p), T = B.wtags || [], won = B.result === "win" || B.result === "scout" || B.scouted;
  if (!won) return;
  const i = regAtLoc(B.center || p.location);
  // 52) 初めて 会った 地方・168) 初めて 仲間に した 日
  e.fs = e.fs || {}; for (const f of B.enemies || []) { const ix = SPECIES[f.m?.sp]?.idx; if (ix !== undefined && e.fs[ix] === undefined) e.fs[ix] = dayNo() * 16 + Math.max(0, i); }
  // 18) 群れ
  const hd2 = T.find((t) => /^mrpg_hd\d+$/.test(t)); if (hd2) { const g = GROUP.get(+hd2.slice(7)); if (g) { g.left--; if (g.left <= 0) { GROUP.delete(+hd2.slice(7)); log.push("§a§l群れを ぜんぶ 倒した！ ボーナス", ...prize(p, d, i, 1, 1)); addPt(p, e, 12, log); award(p, d, "ex_herd", log); } } }
  // 25) 変わり種
  if (T.includes("mrpg_odd")) { e.odd = (e.odd || 0) + 1; log.push(`§d変わり種を 記録した（${e.odd}体）`); if (e.odd >= 5) award(p, d, "ex_odd", log); }
  // 30) 仲間の 日記（はじめて 勝った 相手）
  if (B.result === "win") { e.dy = e.dy || {}; for (const a of B.allies || []) { const mid = a.m?.id; if (mid && !e.dy[mid] && !a.guest && (!a.owner || a.owner === p.id)) { const foe = (B.enemies || [])[0]; if (foe) e.dy[mid] = `${WREGIONS[Math.max(0, i)]?.short || ""}で ${foe.m?.nm || foe.name}に 勝った`; } } }
  // 139) 秘境の 番人・159) 地方の 名人・61) 守り神・137/138) 旅人・盗賊
  const rw = T.includes("mrpg_sentinel") ? ["秘境の 番人", 1, 3000, 10] : T.includes("mrpg_meijin") ? ["地方の 名人", 2, 8000, 20] : T.includes("mrpg_guardian") ? ["守り神", 3, 30000, 40] : null;
  if (rw && B.result === "win") { const k = `${rw[0]}:${i}:${dayNo()}`; e.bw = e.bw || {}; for (const kk of Object.keys(e.bw)) if (!kk.endsWith(`:${dayNo()}`)) delete e.bw[kk]; if (!e.bw[k]) { e.bw[k] = 1; log.push(`§6§l${rw[0]}に 勝った！ §r§e${giveGold(d, rw[2] * (1 + Math.floor(i / 3)))}`, ...prize(p, d, i, rw[1], 1)); addPt(p, e, rw[3], log); if (rw[0] === "守り神") { e.gu = e.gu || {}; e.gu[i] = 1; } scrap(e, `${rw[0]}に 勝った`); } }
  // 54) 協力の 賞金首（2人 以上で ボーナス）
  if (B.bountyPaid?.has?.(p.id) && !rw && (B.players || []).length >= 2 && B.result === "win") log.push(`§c協力ボーナス §e${giveGold(d, 1500 * (i + 1))}`);
  if (B.bountyPaid?.has?.(p.id) && !rw && B.result === "win" && !e.mp?.bounty) mapPiece(p, e, "bounty", "賞金首");
  exSave(p, true);
});
// 番人（秘境を 見つけた とき 3割）・地図の 切れ端
XT.after = XT.after || [];
XT.after.push((p, d, e, q) => {
  if (["nest", "isle", "hollow", "sky"].includes(q.k) && rnd() < 0.3) { const lv = Math.min(100, regionLv(p.location) + 6), s = pickSp(d, (S) => S.fam === "golem", rkForLv(lv)); if (s) { spawnBoss(p, s, lv, "mrpg_sentinel", "【秘境の 番人】"); say(p, "§c§l秘境の 番人が 目を さました！"); } }
  if (q.k === "nest" && !e.mp?.nest) mapPiece(p, e, "nest", "崖の上の巣");
  if (q.k === "wreck" && !e.mp?.wreck) mapPiece(p, e, "wreck", "沈没船");
  scrap(e, `${KINDS[q.k]?.n || q.k}`);
});
// 23) ついてくる 野生（勝った あと まれに）
battleHooks.push((B, x) => { const { p, d } = x; if (B.result !== "win" || B.master || B.boss || rnd() > 0.03) return; const f = (B.enemies || [])[0]; if (!f || !SPECIES[f.m?.sp] || SPECIES[f.m.sp].metalmon || SPECIES[f.m.sp].hidden || rIdx(f.m.sp) > rankCap(d)) return; system.runTimeout(() => { if (spawnJoiner(p, f.m.sp, f.lv || 5, "ついてきた ")) say(p, `§b倒した ${SPECIES[f.m.sp].name}が こちらを 見て いる…… §7（なぐると 話せる）`); }, 60); });

export const __ex2 = { GROUP, BRIDGE, VEIN, ECL, herd, rivals, petTick, legendSid, env2Ok, walkPrize, lightTick, lightOff, LETTERS, PROV, mapPiece, nkLv, SEASON };
