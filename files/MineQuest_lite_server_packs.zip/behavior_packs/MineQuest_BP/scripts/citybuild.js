// 第77版: 灰都の 街が ない ワールド（前から 遊んで いる ワールド・自分の ワールド）で、配布マップと 同じ 街を その場で 建てる
// 1区画（128×128）ずつ、プレイヤーの 近くから。計算は 少しずつ（runJob）、置くのは ストラクチャー（まとめて 置く）
import { world, system, BlockPermutation } from "@minecraft/server";
import { generateDistrict } from "./citygen.js";
import { RU } from "./ruinsarea.js";
import { isLite } from "./ui.js";

const SEED = 777, L0 = 5, LN = 14;          // 区画 di,dj = 5〜18（中心 ±896）
const GY = RU.dy - 41;                       // 街の y=0（地面）が 世界の y=71
const KEY = "mrpg:rlots";
const OW = () => world.getDimension("overworld");
let bits = null;
function load() { if (bits) return bits; let s = ""; try { const v = world.getDynamicProperty(KEY); if (typeof v === "string") s = v; } catch {} bits = new Uint8Array(LN * LN); for (let i = 0; i < s.length && i < bits.length; i++) bits[i] = s.charCodeAt(i) === 49 ? 1 : 0; return bits; }
function saveBits() { try { world.setDynamicProperty(KEY, Array.from(load(), (b) => (b ? "1" : "0")).join("")); } catch {} }
export function lotIdx(x, z) { const di = Math.floor((x - RU.x + 1536) / 128), dj = Math.floor((z - RU.z + 1536) / 128); return di >= L0 && di < L0 + LN && dj >= L0 && dj < L0 + LN ? { di, dj, i: (di - L0) * LN + (dj - L0) } : null; }
export const CB = { busy: false, cur: null, fail: {} };
/* 見張り: 5分 たっても 終わらない 区画は あきらめて 次へ（例外で 止まった とき） */
system.runInterval(() => { if (CB.busy && CB.cur && Date.now() - CB.cur.t > 300000) { console.warn("[MineQuest] 灰都の 区画が 終わらないので やめた"); CB.busy = false; CB.cur = null; } }, 200);
export function lotReady(x, z) { if (RU.pre) return true; const L = lotIdx(x, z); return !!L && load()[L.i] === 1; }
export const lotsDone = () => load().reduce((a, b) => a + b, 0);

// ブロックの 名前 "vine|vine_direction_bits=8" → BlockPermutation（名前ごとに 1回）
function perm(name) {
  const [b, st] = name.split("|"); const id = b.includes(":") ? b : `minecraft:${b}`; const states = {};
  if (st) for (const kv of st.split(",")) { const [k, v] = kv.split("="); const boolKey = /_bit$/.test(k) || k === "hanging" || k === "extinguished"; states[k] = v === "true" ? true : v === "false" ? false : boolKey && (v === "0" || v === "1") ? v === "1" : /^-?\d+$/.test(v) ? Number(v) : v; }
  try { return BlockPermutation.resolve(id, states); } catch { try { return BlockPermutation.resolve(id); } catch { return null; } }
}
function* buildJob(di, dj, done, fail) {
  try { yield* buildJob0(di, dj, done); } catch (e) { console.warn(`[MineQuest] 灰都の 計算に 失敗 ${di},${dj}: ${e}`); fail(); }
}
function* buildJob0(di, dj, done) {
  const t0 = Date.now();
  const gen = generateDistrict(SEED, di, dj); let r;
  while (!(r = gen.next()).done) yield;
  const g = r.value;
  const X0 = RU.x + di * 128 - 1536, Z0 = RU.z + dj * 128 - 1536;
  const P = g.palette.map((n) => (n.startsWith("frame") ? null : perm(n)));
  const AIR = BlockPermutation.resolve("minecraft:air");
  // 64×64 の 4つに 分けて ストラクチャーへ（地面より 下の 空気は 置く。上の 空気は 先に fill で 空ける）
  const parts = [];
  for (const [ox, oz] of [[0, 0], [64, 0], [0, 64], [64, 64]]) {
    const id = `mrpg:rlot_${di}_${dj}_${ox}_${oz}_${(CB.fail[`${di},${dj}`] || 0)}`;
    try { world.structureManager.delete(id); } catch {}
    /* 第91版: 何も ない 上の 空は 置かない（置く 量が へって 軽い） */
    let hy = g.y0;
    for (let y = g.y0 + g.sy - 1; y > g.y0; y--) { const base = (y - g.y0) * g.sz * g.sx; let any = false; for (let z = 0; z < 64 && !any; z++) for (let x = 0; x < 64; x++) if (g.d[base + (oz + z) * g.sx + ox + x]) { any = true; break; } if (any) { hy = y; break; } if (y % 8 === 0) yield; }
    const sy = hy - g.y0 + 1;
    const st = world.structureManager.createEmpty(id, { x: 64, y: sy, z: 64 });
    for (let y = g.y0; y <= hy; y++) {
      const base = (y - g.y0) * g.sz * g.sx;
      for (let z = 0; z < 64; z++) for (let x = 0; x < 64; x++) {
        const v = g.d[base + (oz + z) * g.sx + ox + x];
        if (v) { const pm = P[v]; if (pm) st.setBlockPermutation({ x, y: y - g.y0, z }, pm); }
        else if (y <= 0) st.setBlockPermutation({ x, y: y - g.y0, z }, AIR);
      }
      yield;
    }
    parts.push({ st, x: X0 + ox, z: Z0 + oz, hy });
  }
  done(parts, g, X0, Z0, Date.now() - t0);
}
// 区画を 1つ 建てる（地上の 木や 山を 空けてから 置く）
export function buildLot(di, dj, enqueue, onDone) {
  if (CB.busy) return false;
  CB.busy = true; CB.cur = { di, dj, t: Date.now() };
  const fin = (ok) => { if (CB.cur && (CB.cur.di !== di || CB.cur.dj !== dj)) return; CB.busy = false; CB.cur = null; const fk = `${di},${dj}`; if (!ok) CB.fail[fk] = (CB.fail[fk] || 0) + 1; if (ok) { const i = (di - L0) * LN + (dj - L0); load()[i] = 1; saveBits(); } try { onDone && onDone(ok); } catch {} };
  const run = (parts, g, X0, Z0) => { try {
    const ow = OW(), C = [];
    const ytop = GY + 129;   /* y200 まで 空ける（高い 山も のこさない） */
    /* 第89版: 空ける 前に 区画の 中の 人を ゆっくり 落ちる ように（足場が 消えて 落ちて しなない） */
    for (const p of world.getAllPlayers()) { try { const l = p.location; if (p.dimension.id === "minecraft:overworld" && l.x >= X0 - 2 && l.x < X0 + 130 && l.z >= Z0 - 2 && l.z < Z0 + 130) { p.addEffect("slow_falling", 1200, { showParticles: false }); p.addEffect("resistance", 1200, { amplifier: 4, showParticles: false }); } } catch {} }
    /* 第91版: 地面より 上を 全部 空けるのを やめ、16×16 ごとに 実際の 高さまで だけ 空ける（置きかえる 量が 何分の1に）。高さは 読みこんで から しらべる */
    const AREA = [{ x: X0, y: GY - 24, z: Z0 }, { x: X0 + 127, y: GY + 40, z: Z0 + 127 }];
    enqueue(ow, [], () => { try {
    for (let cx = 0; cx < 128; cx += 16) for (let cz = 0; cz < 128; cz += 16) {
      let top = GY; for (const [a, b] of [[2, 2], [13, 2], [2, 13], [13, 13], [8, 8]]) { try { const t = ow.getTopmostBlock({ x: X0 + cx + a, z: Z0 + cz + b }); if (t) top = Math.max(top, t.location.y); } catch { top = ytop; } }
      const hi = Math.min(ytop, top + 2); if (hi <= GY) continue;
      for (let y = GY + 1; y <= hi; y += 8) C.push(`fill ${X0 + cx} ${y} ${Z0 + cz} ${X0 + cx + 15} ${Math.min(y + 7, hi)} ${Z0 + cz + 15} air`);
    }
    C.push(`kill @e[type=item,x=${X0},y=${GY - 30},z=${Z0},dx=128,dy=120,dz=128]`);
    enqueue(ow, C, () => {
      let okAll = true;
      /* 第85版: 4つを 一度に 置くと 世界が 止まるので 10tick ずつ ずらして 置く */
      const placeOne = (k) => {
        if (k >= parts.length) { try { ow.runCommand("tickingarea remove mrpg_cbp"); } catch {} system.runTimeout(() => { for (const p of parts) try { world.structureManager.delete(p.st); } catch {} }, 200); fin(okAll); afterPlace(); return; }
        const p = parts[k]; try { world.structureManager.place(p.st, ow, { x: p.x, y: GY + g.y0, z: p.z }); } catch (e) { okAll = false; console.warn(`[MineQuest] 灰都の 区画を 置けなかった ${di},${dj}: ${e}`); }
        afterPlace(); system.runTimeout(() => placeOne(k + 1), isLite() ? 40 : 20);
      };
      try { ow.runCommand(`tickingarea add ${X0} ${GY - 24} ${Z0} ${X0 + 127} ${GY + 40} ${Z0 + 127} mrpg_cbp`); } catch {}
      placeOne(0);
    }, AREA, () => fin(false), isLite() ? 3 : 6);
    } catch (e) { console.warn(`[MineQuest] 灰都の 区画: ${e}`); fin(false); } }, AREA, () => fin(false));
    const afterPlace = () => {
      // 区画の 中に いた 人は 街の 上へ（うまって 息が できなく ならない ように）
      for (const p of world.getAllPlayers()) { try { const l = p.location; if (l.x >= X0 && l.x < X0 + 128 && l.z >= Z0 && l.z < Z0 + 128 && p.dimension.id === "minecraft:overworld") { const t = ow.getTopmostBlock({ x: Math.floor(l.x), z: Math.floor(l.z) }); p.addEffect("resistance", 100, { amplifier: 4, showParticles: false }); if (t && t.location.y > l.y - 1) p.teleport({ x: l.x, y: t.location.y + 1.1, z: l.z }); } } catch {} }
    };
  } catch (e) { console.warn(`[MineQuest] 灰都の 区画を 置けなかった ${e}`); fin(false); } };
  const X0 = RU.x + di * 128 - 1536, Z0 = RU.z + dj * 128 - 1536;
  // まず 読みこんで、街が もう ある（配布マップ・更新ツールで 入れた）区画なら 建てない（いちばん 下が 岩盤）
  enqueue(OW(), [], () => {
    let pre = false; try { const b = OW().getBlock({ x: X0 + 64, y: GY - 23, z: Z0 + 64 }); pre = !!b && b.typeId === "minecraft:bedrock"; } catch {}
    if (pre) { fin(true); return; }
    const job = buildJob(di, dj, run, () => fin(false));
    try { if (typeof system.runJob === "function") system.runJob(job); else { const step = () => { for (let k = 0; k < 4; k++) if (job.next().done) return; system.run(step); }; step(); } }
    catch (e) { console.warn(`[MineQuest] 灰都の 計算に 失敗 ${e}`); fin(false); }
  }, [{ x: X0 + 60, y: GY - 24, z: Z0 + 60 }, { x: X0 + 67, y: GY - 20, z: Z0 + 67 }], () => fin(false));
  return true;
}
// プレイヤーの 近くで まだ ない 区画（近い 順）
export function nextLot(players) {
  const B = load(); let best = null;
  for (const p of players) {
    const L = lotIdx(p.location.x, p.location.z); if (!L) continue;
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) {
      const di = L.di + a, dj = L.dj + b; if (di < L0 || dj < L0 || di >= L0 + LN || dj >= L0 + LN) continue;
      if (B[(di - L0) * LN + (dj - L0)] || (CB.fail[`${di},${dj}`] || 0) >= 3) continue;   /* 3回 失敗した 区画は あきらめる */
      const cx = RU.x + di * 128 - 1536 + 64, cz = RU.z + dj * 128 - 1536 + 64, d = Math.hypot(cx - p.location.x, cz - p.location.z);
      if (!best || d < best.d) best = { di, dj, d };
    }
  }
  return best;
}
