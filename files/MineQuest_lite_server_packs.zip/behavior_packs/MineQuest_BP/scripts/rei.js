// 第106版: ライバル レイ。対戦中の ひとこと
// 第113版: 物語の 進みで 言うことが かわる（0: ライバル／1: かけらに 呑まれかけ／2: 裏切りの あと／3: 竜が 石に なった あと）
import { load } from "./store.js";
const pick = (L) => L[Math.floor(Math.random() * L.length)];
const PH = [
  { start: ["手加減は なしだ。……確かめさせて もらう", "今日こそ 勝つ。竜と 毎日 鍛えて きたんだ"],
    good: ["……やるな", "くっ、今のは 効いた……", "その 読み、どこで 覚えたんだ"], mine: ["よし……いける", "いいぞ、相棒！"],
    lose1: ["まだだ……まだ 終わって ない", "一体 やられた くらいで……！"], pinch: ["ここで 負けたら、オレは……！", "まだ…… まだ 届く……！"],
    win: ["……勝った。少しは 追いつけたかな", "オレの 勝ちだ。……次も 勝つ"], loss: ["……また 負けた。何が 足りないんだ", "強いな。……覚えて おけよ。次は 負けない"] },
  { start: ["かけらが 熱い……今日は 負ける 気が しない", "見せて やるよ。選ばれる 側の 力を"],
    good: ["……ちっ", "なんでだ……力は あふれてるのに"], mine: ["ハハ……そうだ、もっとだ！", "いいぞ……もっと 壊せ！"],
    lose1: ["……まだだ。かけらは もっと よこせって 言ってる", "倒れたなら、次を 出すだけだ"], pinch: ["……もっと 力を……もっと……！", "なんで……なんで 届かないんだ……！"],
    win: ["ハハ……勝った。これが オレの 力だ", "見たか。……オレだって、選ばれる 側に なれる"], loss: ["……くそっ。まだ 足りない……", "かけらが……冷たく なった……"] },
  { start: ["……頼む。本気で 来て くれ", "かけらなしの オレを、確かめさせて くれ"],
    good: ["……うん、やっぱり 強い", "今の 一撃、じいちゃんが 見たら 喜んだだろうな"], mine: ["よし……自分の 力で 届いた", "ありがとな、相棒"],
    lose1: ["大丈夫、まだ 立てる", "……もう 逃げない"], pinch: ["ここで 折れたら、セオは 止められない……！", "最後まで、自分の 足で 立つ……！"],
    win: ["……勝った。かけらなしで", "ごめん、今日は オレの 勝ちだ"], loss: ["負けた。……でも、前より ずっと 気分が いい", "やっぱり 君だ。……もう 迷わない"] },
  { start: ["よっしゃ、勝負だ！ 手加減なしで いこうぜ！", "待ってたよ！ 今日も 楽しもうな！", "お互い ベスト 出しきろうぜ！"],
    good: ["おおー、いいじゃん！ マジで 強いな！", "うわ、今の すげえ！ やるなあ！", "いい 連携だな……！ 見とれちゃったよ", "マジか、そこ 狙うんだ！ さすが！"], mine: ["よし、いけるいける！", "ナイス、相棒！", "ふふん、こっちも 負けてないぜ！"],
    lose1: ["くーっ、やられた！ でも まだまだ！", "大丈夫、まだ 終わってないからな！"], pinch: ["やばい やばい……！ でも 最後まで 楽しむぞ！", "ここから 逆転、見せてやる……！"],
    win: ["へへ、今回は オレの 勝ち！ でも ほんと ギリギリだった！", "楽しかった！ また やろうな！"], loss: ["あー、負けた！ でも すっげえ 楽しかった！", "完敗！ ……次は 負けないからな、約束だぞ！"] },
];
PH.push({ ...PH[3], start: ["こいつ、石の あいだ 寝てた ぶん 暴れたいってさ。……いくぞ、相棒！", "竜と オレ、二人そろって 本気だ。手加減 なしで いこうぜ！"], mine: ["いいぞ、相棒！ 寝坊の ぶんまで 飛べ！", ...PH[3].mine] });   /* 第122版: 竜が 石から 戻った あと */
/* 前の 版の 名前（ほかの ファイルが 使って いても こわれない ように 残す） */
export const R_START = PH[3].start, R_GOOD = PH[3].good, R_MINE = PH[3].mine, R_LOSE1 = PH[3].lose1, R_PINCH = PH[3].pinch, R_WIN = PH[3].win, R_LOSS = PH[3].loss;
const isRei = (B) => B && B.master && /レイ/.test(String(B.master.name || "")) && !/レイド|ノクス団/.test(String(B.master.name || ""));   /* 第106版: 闇落ちの レイは 明るい ことを 言わない */
function phaseOf(B) {
  try { for (const x of B.players || []) { const s = (load(x.p) || {}).story || {}; return s.reiFinal ? (s.stoneBack ? 4 : 3) : s.theoBetray ? 2 : s.jailDone ? 1 : 0; } } catch {}
  return 0;
}
const say = (B, k) => { const l = pick(PH[B.rPh ?? 0][k]); for (const x of B.players || []) try { x.p.sendMessage(`§b§lレイ§r§f「${l}」`); } catch {} };
const ratio = (L) => { let h = 0, m = 0; for (const f of L || []) { m += f.mx.hp || 1; h += Math.max(0, f.hp); } return m ? h / m : 0; };
export function reiStart(B) { try { if (isRei(B)) { B.rSaid = { t: 0 }; B.rPh = phaseOf(B); say(B, "start"); } } catch {} }
export function reiAct(B, a, fx) {
  try {
    if (!isRei(B) || !fx) return;
    const s = B.rSaid || (B.rSaid = { t: 0 }); s.t++;
    if (s.t - (s.last || -9) < 2) return;   /* 言いすぎない */
    const ko = fx.ko || [], dmg = fx.dmg || [];
    const mine = B.allies.includes(a.actor);
    let L = null;
    if (mine && ko.some((t) => t.side === "e")) L = ratio(B.enemies) < 0.35 && !s.pinch ? (s.pinch = 1, "pinch") : "lose1";
    else if (mine && (dmg.some((x) => x.crit) || ratio(B.allies) > ratio(B.enemies) + 0.2) && Math.random() < 0.45) L = "good";
    else if (!mine && ko.some((t) => t.side === "a") && Math.random() < 0.6) L = "mine";
    if (L) { s.last = s.t; say(B, L); }
  } catch {}
}
export function reiEnd(B, won) { try { if (isRei(B)) say(B, won ? "loss" : "win"); } catch {} }
