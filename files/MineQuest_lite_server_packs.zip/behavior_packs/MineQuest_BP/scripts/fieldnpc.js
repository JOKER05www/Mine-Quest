// 第117版: 町の 外の 人たち。道や 草原を 旅する 人、モンスターと 戦って いる 冒険者（軽く: 1人の プレイヤーに 2組まで）
import { world, system } from "@minecraft/server";
import { ok, setJob, busy, sound } from "./ui.js";
import { PSKIN } from "./skinjobs.js";
import { SPECIES, ORDER } from "./data.js";
import { setLook, TYPE, hooks } from "./field.js";
import { groundY } from "./structures.js";
import { inBattle } from "./battle.js";
import { personName } from "./names.js";

const WALKERS = ["m6_kaito", "m6_ruben", "m6_grant", "m6_sid", "m6_bram", "m6_zack", "m6_ivan", "m6_noah", "m6_aldo", "m6_takeru", "m6_riku", "m6_aero", "m6_samir", "m6_tomas", "m6_pip", "m6_eirik", "m6_lugh", "allen", "leaf", "erika", "aoi", "kaede", "fio", "wolf", "jack"];
const G = new Map();   /* プレイヤー id → 組の 一覧 */
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const fx = (dim, id, at) => { try { dim.spawnParticle(id, at); } catch {} };
const rm = (e) => { if (ok(e)) try { globalThis.__mqCine?.delete(e.id); e.remove(); } catch {} };
function spot(p, rmin, rmax) {
  const l = p.location;
  for (let k = 0; k < 6; k++) {
    const a = Math.random() * Math.PI * 2, r = rmin + Math.random() * (rmax - rmin), x = l.x + Math.cos(a) * r, z = l.z + Math.sin(a) * r;
    const y = groundY(p.dimension, x, z, Math.floor(l.y)); if (typeof y !== "number" || Math.abs(y - l.y) > 8) continue;
    if (hooks.inTown({ x, y, z }, p.dimension.id)) continue;
    try { const t = p.dimension.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) }); if (t && t.location.y > y + 1) continue; } catch {}   /* 上が 空いて いる 所だけ（家・遺跡の 中や 木の 下・洞くつに 出ない）*/
    return { x: Math.floor(x) + 0.5, y, z: Math.floor(z) + 0.5 };
  }
  return null;
}
function person(p, at) {
  const keys = WALKERS.filter((k) => PSKIN[k]); if (!keys.length) return null;
  const key = pick(keys), S = PSKIN[key];
  let e; try { e = p.dimension.spawnEntity("mrpg:npc", at); } catch { return null; }
  try { setJob(e, S[0]); e.addTag("mrpg_npc"); e.addTag("mrpg_temp"); e.addTag("mrpg_field"); e.addTag("mrpg_walker"); e.setDynamicProperty("mrpg:wr", 25); e.nameTag = `§f${personName(S[1], S[2], [])}`; } catch {}
  return e;
}
function mon(dim, sid, at, face) {
  let e; try { e = dim.spawnEntity(TYPE, at); } catch { return null; }
  try { (globalThis.__mqCine = globalThis.__mqCine || new Set()).add(e.id); e.addTag("mrpg_temp"); e.addTag("mrpg_cine"); e.addTag("mrpg_field"); setLook(e, sid); e.teleport(at, { facingLocation: face }); } catch {}
  return e;
}
const randSp = (fams) => { const L = ORDER.filter((k) => SPECIES[k] && !SPECIES[k].hidden && !SPECIES[k].giant && (!fams || fams.includes(SPECIES[k].fam)) && /^[FEDC]$/.test(SPECIES[k].rank || "")); return L.length ? pick(L) : ORDER[0]; };
function spawnGroup(p) {
  const at = spot(p, 22, 38); if (!at) return null;
  const fight = Math.random() < 0.5;
  const e = person(p, at); if (!e) return null;
  const g = { kind: fight ? "fight" : "walk", e, x: at.x, y: at.y, z: at.z, t: 0, tg: null, ents: [e], sp: 0.16 + Math.random() * 0.06 };
  if (fight) {
    const a = Math.random() * Math.PI * 2, A = { x: at.x + Math.cos(a) * 1.6, y: at.y, z: at.z + Math.sin(a) * 1.6 }, B = { x: at.x + Math.cos(a) * 4.6, y: at.y, z: at.z + Math.sin(a) * 4.6 };
    const ya = groundY(p.dimension, A.x, A.z, Math.floor(at.y)), yb = groundY(p.dimension, B.x, B.z, Math.floor(at.y));
    if (typeof ya === "number") A.y = ya; if (typeof yb === "number") B.y = yb;
    g.ma = mon(p.dimension, randSp(), A, B); g.mb = mon(p.dimension, randSp(), B, A); g.A = A; g.B = B; g.hp = 4 + Math.floor(Math.random() * 4);
    for (const m of [g.ma, g.mb]) if (m) g.ents.push(m);
    try { e.teleport(at, { facingLocation: B }); e.setProperty("mrpg:act", 17); } catch {}
  }
  return g;
}
function newTarget(p, g) { const q = spot(p, 14, 40); g.tg = q || { x: g.x + (Math.random() - 0.5) * 20, y: g.y, z: g.z + (Math.random() - 0.5) * 20 }; }
function stepWalk(p, g) {
  if (!g.tg) newTarget(p, g);
  const dx = g.tg.x - g.x, dz = g.tg.z - g.z, d = Math.hypot(dx, dz);
  if (d < 0.6) { g.tg = null; try { g.e.setProperty("mrpg:mv", false); } catch {} g.t = -20 - Math.floor(Math.random() * 40); return; }
  if (g.t < 0) { g.t++; return; }
  const nx = g.x + (dx / d) * g.sp, nz = g.z + (dz / d) * g.sp, ny = groundY(p.dimension, nx, nz, Math.floor(g.y));
  if (typeof ny !== "number" || Math.abs(ny - g.y) > 1) { g.tg = null; return; }
  g.x = nx; g.z = nz; g.y = ny;
  try { g.e.teleport({ x: g.x, y: g.y, z: g.z }, { facingLocation: { x: g.tg.x, y: g.y + 1.5, z: g.tg.z } }); if (g.e.getProperty("mrpg:mv") !== true) g.e.setProperty("mrpg:mv", true); } catch {}
}
function stepFight(p, g) {
  g.t++;
  const { ma, mb, A, B } = g, dim = p.dimension, near = Math.hypot(p.location.x - g.x, p.location.z - g.z) < 40;
  if (!ok(ma) || !ok(mb)) { g.kind = "walk"; return; }
  const k = g.t % 16, mid = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 + 0.8, z: (A.z + B.z) / 2 };
  const lunge = (m, P, Q, s) => { try { m.teleport({ x: P.x + (Q.x - P.x) * s, y: P.y + Math.sin(s * Math.PI) * 0.4, z: P.z + (Q.z - P.z) * s }, { facingLocation: Q }); } catch {} };
  const atkA = Math.floor(g.t / 16) % 2 === 0;
  if (k < 5) lunge(atkA ? ma : mb, atkA ? A : B, atkA ? B : A, k * 0.14);
  else if (k === 5) { fx(dim, "minecraft:critical_hit_emitter", mid); if (near) sound(p, atkA ? "mob.player.attack.strong" : "mob.wolf.growl", 0.6); try { g.e.setProperty("mrpg:act", atkA ? 18 : 22); } catch {} if (atkA) g.hp--; }
  else if (k < 10) lunge(atkA ? ma : mb, atkA ? A : B, atkA ? B : A, (10 - k) * 0.14);
  else if (k === 10) { try { g.e.setProperty("mrpg:act", 17); } catch {} }
  if (g.hp <= 0) {   /* 勝った: 相手は 逃げて いき、冒険者は 喜んで 旅に もどる */
    fx(dim, "minecraft:large_explosion", { x: B.x, y: B.y + 0.5, z: B.z }); rm(mb); g.mb = null;
    try { g.e.setProperty("mrpg:act", 9); } catch {} if (near) sound(p, "random.levelup", 0.5);
    system.runTimeout(() => { rm(ma); if (g.ents) g.ents = g.ents.filter(ok); try { if (ok(g.e)) g.e.setProperty("mrpg:act", 0); } catch {} }, 50);
    g.kind = "walk"; g.t = -50; g.tg = null;
  }
}
function clear(pid) { const L = G.get(pid) || []; for (const g of L) for (const e of g.ents || []) rm(e); G.delete(pid); }
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    let L = G.get(p.id) || [];
    const quiet = p.dimension.id !== "minecraft:overworld" || busy.has(p.id) || !!globalThis.__mqStageZ?.has(p.id) || (() => { try { return inBattle(p); } catch { return false; } })() || hooks.inTown(p.location, p.dimension.id);
    L = L.filter((g) => { let bw = false; try { bw = g.e.hasTag("mrpg_busyw"); } catch {} const far = (!bw && Math.hypot(p.location.x - g.x, p.location.z - g.z) > 72) || p.dimension.id !== "minecraft:overworld"; if (far || !ok(g.e)) { for (const e of g.ents || []) rm(e); return false; } return true; });
    if (!quiet && L.length < 2 && Math.random() < 0.35) { const g = spawnGroup(p); if (g) L.push(g); }
    G.set(p.id, L);
  }
}, 100);
system.runInterval(() => {
  const FZ = globalThis.__mqFrz;
  for (const p of world.getAllPlayers()) for (const g of (p.dimension.id === "minecraft:overworld" && G.get(p.id)) || []) { if (!ok(g.e) || (FZ && FZ.size && FZ.has(g.e.id))) continue; try { if (g.e.hasTag("mrpg_busyw")) continue;   /* 勝負・デート・鬼ごっこの あいだは 歩かせない */   /* 第124版: ムービーの あいだ 止まる */ if (g.kind === "fight") stepFight(p, g); else stepWalk(p, g); } catch {} }
}, 2);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => clear(playerId)); } catch {}
/* 組の 記録が ない 野の 人と モンスター（遠くへ ワープした・チャンクの 外で 消せなかった）を 30秒ごとに 片づける */
function sweepF() {
  const own = new Set(); for (const L of G.values()) for (const g of L) for (const e of g.ents || []) try { own.add(e.id); } catch {}
  let L = []; try { L = world.getDimension("overworld").getEntities({ tags: ["mrpg_field"] }); } catch {}
  for (const e of L) try { if (!own.has(e.id) && !e.hasTag("mrpg_busyw")) rm(e); } catch {}
}
system.runInterval(sweepF, 600);
/* ワールドを 開いた とき 残った 人と モンスターを 消す */
system.runTimeout(() => { try { for (const e of world.getDimension("overworld").getEntities({ tags: ["mrpg_field"] })) e.remove(); } catch {} }, 80);
