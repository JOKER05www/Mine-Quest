// v2.2.2: 三つの 試練の あと（伝説の マスター カゲツ・邪刀・閻魔・閻魔の神殿・裏ボス エンマ・終の遺跡）
import { world, system } from "@minecraft/server";
import { SPECIES, ITEMS, DEITY } from "./data.js";
import { makeMonster, addMon, calcStats, TAL_MAX, STATS } from "./core.js";
import { load, save, mark, allMons } from "./store.js";
import { busy, notice, confirm, sound, particle, giveItem, countItem, gold, seedId, barNote, showTitle } from "./ui.js";
import { rollGear, giveGear, gearSlots, takeSlot, ENMA_BLADE } from "./gear.js";
import { groundY, spotY } from "./structures.js";
import { RUIN_FINAL } from "./data.js";
import { WREGIONS, LAYOUT } from "./worldmap.js";
import { stageNear } from "./stage.js";
import { qs, partyPower, endingDone } from "./quest.js";
import { possessionFlow } from "./majin.js";

export const KENGO = { name: "伝説の マスター カゲツ", need: 10 };
const ALTAR_KEY = "mrpg:altar";
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const SLOT = { S: 1, M: 2, L: 3, G: 4 };

// 勝つほど 強くなる（Lv100・プラス値・仲間の ランク）
export function kengoTeam(wins) {
  const plus = Math.min(99, 30 + wins * 5);
  const ranks = wins >= 10 ? ["SS", "X"] : wins >= 4 ? ["S", "SS"] : ["S"];
  // v2.9.14: カゲツの 先頭は 剣の 達人（ムサシは 魔神編で 出会う）
  const lead = Object.keys(SPECIES).filter((x) => { const S = SPECIES[x]; return !S.hidden && !S.metalmon && S.fam === "sword" && ["SS", "X"].includes(S.rank) && (SLOT[S.sz] || 2) <= 3; });
  const team = [{ sid: lead.length ? lead[wins % lead.length] : "nswo093", lv: 100, q: 1, plus }];
  let used = SLOT[SPECIES[team[0].sid]?.sz] || 2;
  const fams = ["sword", "dragon", "nether", "beast", "golem", "animal"];
  for (let k = 0; k < 3 && used < 4; k++) {
    const f = k === 0 ? "sword" : pick(fams);
    const c = Object.keys(SPECIES).filter((x) => { const S = SPECIES[x]; return !S.hidden && !S.metalmon && S.fam === f && ranks.includes(S.rank) && used + (SLOT[S.sz] || 2) <= 4 && !team.some((t) => t.sid === x); });
    if (!c.length) continue;
    const x = pick(c); used += SLOT[SPECIES[x].sz] || 2;
    team.push({ sid: x, lv: 100, q: 1, plus: Math.floor(plus * 0.85) });
  }
  return team;
}
export const kengoName = (s) => (s && s.kagetsuDead ? "カゲツの 夢（釣り竿の 記憶）" : KENGO.name);   /* 第106版: 魔7で カゲツは 眠った */
export const kengoText = (s) => [
  ...(s && s.kagetsuDead ? ["§b§lカゲツの 夢§r§7 釣り竿を 握った まま 眠る カゲツの そばに 立つと、夢の 中の カゲツが 刀を 抜いた。", "§f「……寝かせて くれと 言ったろう。まあ いい、一太刀 だけだ」"] : ["§b§l伝説の マスター カゲツ§r§f「三つの 試練を 越えた 者か。……座れ。いや、立て。刀で 語ろう。」",
  "§7始まりの町に 住む 最強の モンスターマスター。釣りと 昼寝が 好き。剣の 家の 当主でも ある。"]),
  `§f勝利 §e${s.kg || 0}かい  §7あと ${KENGO.need - ((s.kg || 0) % KENGO.need)}勝で §4${(s.kg || 0) < 30 ? "神の石板" : (s.kg || 0) < 40 ? "厄神の 石板" : "SSランクの モンスター"} §7（10勝ごと）`,
  (s.kg || 0) ? "§7勝つたびに 豪華な ほうび。" : "§7はじめて 勝つと 何かを くれる らしい。勝つたびに 豪華な ほうび。",
].join("\n");

// 1勝ごとの 豪華な ほうび（順番に めぐる）
const KG_ROT = [[["e_king", 1]], [["i_tal9", 1], ["f_exp100k", 1]], [["i_awaken", 2]], [["e_rainbow", 2], ["i_dream", 1]], [["f_exp100k", 2], ["lv_10", 2]], [["e_king", 1], ["i_awaken", 1]], [["i_tal9", 2]], [["e_rainbow", 3], ["i_dream", 2]]];
export function kengoGifts(n) {
  const L = [["sl3", 1], ["e_rainbow", 1], ...KG_ROT[(n - 1) % KG_ROT.length]];
  if (n > KENGO.need && n % 10 === 0) L.push(["e_god", 1]);
  L.push(["sx_king", 1]); if (n % 3 === 0) L.push(["sx_god", 1]);   // v2.4: 覇王・神域の 石板
  L.push(["SEED4", 1]); if (n % 5 === 0) L.push(["s_all4", 1]);   // v2.4.4: +100 の 神果
  return { gold: Math.min(400000, 100000 + n * 20000), items: L };   // v2.9.14: 上限 40万
}
// 勝った あと（story.js から よばれる）
export async function kengoReward(p, d, s) {
  s.kg = (s.kg || 0) + 1;
  const got = [];
  const G = kengoGifts(s.kg);
  d.gold += G.gold; got.push(gold(G.gold));
  for (let [id, n] of G.items) { if (id === "SEED4") id = seedId(4); if (!ITEMS[id]) continue; giveItem(p, `mrpg:${id}`, n); got.push(`${id === "e_god" ? "§6§l" : ""}${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); }
  if (s.kg === 1 || (s.kg >= 1 && countItem(p, "mrpg:k_hilt") <= 0 && !s.hiltGot)) {
    // v2.9.14: 魔神編の はじまり。カゲツが 拾った 鍔を くれる（ムサシは もう カゲツの 仲間では ない）
    s.hiltGot = true; s.keys = [...new Set([...(s.keys || []), "k_hilt"])];
    giveItem(p, "mrpg:k_hilt", 1); got.push("§4§l魔神の鍔 §r§7（だいじなもの）");
    s.tsubaGive = 1;
  }
  let sword = false, dslab = null;
  s.dgs = s.dgs || [];
  for (let gi = 11; gi <= 14; gi++) {   // 第68版: 10・20・30勝で 神の石板、40勝で 厄神ゲゼラの 石板（前の 版で もう 勝って いた 人にも 渡す）
    const G = DEITY[gi]; if (!G || !ITEMS[G.slab] || s.dgs.includes(gi) || s.kg < (gi - 10) * KENGO.need) continue;
    s.dgs.push(gi); giveItem(p, `mrpg:${G.slab}`, 1); if (!dslab || gi === 14) dslab = G; got.push(`§d§l${ITEMS[G.slab].name}§r §7（神の石板。中の 神は ${G.name}）`);
  }
  if (s.kg % KENGO.need === 0 && s.kg > 40) {   // 50勝から: 10勝ごとに SSランクの モンスター
    const pool = Object.keys(SPECIES).filter((k) => SPECIES[k].rank === "SS" && !SPECIES[k].hidden && !SPECIES[k].metalmon && k !== "musashi");
    const sid = pool[Math.floor(Math.random() * pool.length)];
    if (sid && SPECIES[sid]) {
      if (sid === "haken") s.kgHaken = true;
      sword = true; s.kgLast = sid;
      const m = makeMonster(sid, 50, true); const where = addMon(d, m); mark(d.own, sid); mark(d.seen, sid);
      got.push(`§4§l${SPECIES[sid].name}§r §7（SS）が 仲間に なった（${where === "party" ? "パーティ" : "預かり所"}へ）`);
    }
  }
  save(p, d);
  sound(p, "ui.toast.challenge_complete", 1); particle(p, "minecraft:totem_particle", 1.5);
  const KN = s.kagetsuDead ? "§b§lカゲツの 夢§r" : "§b§lカゲツ§r";
  const lines = [`${KN}§f「${sword ? (s.kgLast === "haken" && s.kg === KENGO.need ? "見事。……こいつは 千年前に エンマが 斬った 王だ。おまえなら 使いこなせる。連れて いけ。" : "見事。……10本 取られたか。こいつを 連れて いけ。") : pick(["まだまだ……もう 一本！", "いい 読みだ。次は 読まれた 先を 読め。", "仲間が おまえの 迷いを 埋めているな。", "その 刀、どこまで のびる？"])}」`, "", ...got.map((x) => "§e" + x)];
  if (s.tsubaGive === 1) { s.tsubaGive = 2; try { save(p, d); } catch {} lines.push("", "§b§lカゲツ§r§f「……待て。おまえに 渡す ものが ある。」", "§b§lカゲツ§r§f「おれの 家が 千年 守ってきた 刀の 鍔だ。石板の王――厄王が 倒れて から、赤黒く 光りだした。」", "§b§lカゲツ§r§f「鍔が 持ち主を 呼んでいる。……おれでは もう 抑えきれん。」", "§b§lカゲツ§r§f「クロガネに おれの 弟子 §cムサシ§f が いる。あいつを たずねろ。」", "§d§l― 魔神編 はじまり ―"); }
  if (sword) lines.push("", `§4${SPECIES[s.kgLast]?.name || "SSランクの モンスター"}が 仲間に なった！`, "§7パーティや 預かり所を 確かめよう。")
  if (dslab) lines.push("", `${KN}§f「……${dslab.id === "dz14" ? "これは 厄王が 神に なった 姿を 封じた 石板だ。……覚悟が あるなら 触れろ。" : "神の 名を 得た 主が 眠る 石板だ。おまえなら 鎮められる。"}」`, `§d${ITEMS[dslab.slab]?.name}を 受けとった！ §7（道具 →【特別な石板】）`);
  await notice(p, "伝説の マスターに 勝利！", lines.join("\n"));
}

// ---- 閻魔の神殿 ----
function altarBase() { const s = world.getDefaultSpawnLocation(); return { x: Math.floor(s.x) + 72, z: Math.floor(s.z) - 72 }; }
export function altarInfo() { try { const v = world.getDynamicProperty(ALTAR_KEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
function setAltar(v) { try { world.setDynamicProperty(ALTAR_KEY, JSON.stringify(v)); } catch {} }
export function altarOn() { const a = altarInfo(); if (!a) { const b = altarBase(); setAltar({ x: b.x, z: b.z, y: null, built: false }); } }
export function altarText() { const a = altarInfo() || altarBase(); return `X ${a.x}・Z ${a.z}`; }
export function nearAltar(p, r = 7) {
  const a = altarInfo();
  if (!a || !a.built || p.dimension.id !== "minecraft:overworld") return false;
  return Math.hypot(p.location.x - a.x - 0.5, p.location.z - a.z - 0.5) <= r && Math.abs(p.location.y - a.y) < 6;
}
function run(dim, c) { try { dim.runCommand(c); } catch {} }
function buildAltar(dim, a, y) {
  const { x, z } = a;
  const C = [
    `fill ${x - 6} ${y} ${z - 6} ${x + 6} ${y + 8} ${z + 6} air`,
    `fill ${x - 6} ${y - 1} ${z - 6} ${x + 6} ${y - 1} ${z + 6} polished_blackstone_bricks`,
    `fill ${x - 6} ${y - 2} ${z - 6} ${x + 6} ${y - 2} ${z + 6} blackstone`,
    `fill ${x - 3} ${y - 1} ${z - 3} ${x + 3} ${y - 1} ${z + 3} crying_obsidian`,
    `fill ${x - 2} ${y - 1} ${z - 2} ${x + 2} ${y - 1} ${z + 2} red_nether_brick`,
    `fill ${x - 1} ${y} ${z - 1} ${x + 1} ${y} ${z + 1} polished_blackstone_bricks`,
    `setblock ${x} ${y + 1} ${z} crying_obsidian`,
    `setblock ${x} ${y + 2} ${z} soul_lantern`,
  ];
  for (const [dx, dz] of [[-5, -5], [5, -5], [-5, 5], [5, 5]]) {
    C.push(`fill ${x + dx} ${y} ${z + dz} ${x + dx} ${y + 4} ${z + dz} crying_obsidian`);
    C.push(`setblock ${x + dx} ${y + 5} ${z + dz} soul_lantern`);
  }
  for (const [dx, dz] of [[0, -6], [0, 6], [-6, 0], [6, 0]]) { C.push(`fill ${x + dx} ${y} ${z + dz} ${x + dx} ${y + 2} ${z + dz} red_nether_brick`); C.push(`setblock ${x + dx} ${y + 3} ${z + dz} soul_torch`); }
  for (const c of C) run(dim, c);
}
system.runInterval(() => {
  const a = altarInfo();
  if (!a) return;
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue;
    const dist = Math.hypot(p.location.x - a.x, p.location.z - a.z);
    if (!a.built && dist < 56) {
      if (stageNear(a.x, a.z)) continue;   // 戦いの ステージが 近い あいだは まつ
      const y = spotY(p.dimension, a.x, a.z, 8); if (y === null) continue;   // v2.9.12: 本当の 地表に（宙に 浮いたり 埋まったり しない）
      buildAltar(p.dimension, a, y);
      a.y = y; a.built = true; setAltar(a);
      try { { const d0 = load(p); p.sendMessage(`§5§l${d0 && d0.story && d0.story.ending ? "閻魔の神殿" : "？？？の 神殿"}§r§d が 地の底から あらわれた……`); }   /* 第69版 */ } catch {}
      sound(p, "mob.wither.spawn", 0.7);
      return;
    }
    if (a.built && dist < 9) {
      try { p.dimension.spawnParticle("minecraft:soul_particle", { x: a.x + 0.5, y: a.y + 2.5, z: a.z + 0.5 }); } catch {}
      if (dist < 6) { let msg = "§5？？？の 神殿 §7― 嫌な 予感が する……"; try { const d = load(p), s = d && d.story; if (s && !s.ending) msg = "§5？？？の 神殿 §7― 嫌な 予感が する……"; else if (s) msg = s.enmaJoin ? "§5閻魔の神殿 §7― 主の いない 玉座が 静かに 光っている" : countItem(p, "mrpg:k_hilt") > 0 && s.ending ? "§5閻魔の神殿 §d― 魔神の鍔が 震えている……（鍔を 使う／ガイドブックを 開く）" : s.enmaDream ? "§5閻魔の神殿 §7― あの 悪夢が 頭を よぎる……（ガイドブックで 奥へ）" : "§5閻魔の神殿 §7― 嫌な 予感が する……"; } catch {} try { barNote(p).setActionBar(msg); } catch {} }
    }
  }
}, 40);

export function hasTokoyo(p, d) {
  if (countItem(p, "mrpg:wp_tokoyo") > 0) return true;
  return !!(d && allMons(d).some((m) => m.eq && m.eq.w === "wp_tokoyo"));
}
// v2.8: 神殿 → "go"（柄を 捧げて 戦う）／"dream"（悪夢の 強制戦闘）／"cancel"／false（ふつうに ブックを 開く）
export const hasHilt = (p) => { if (countItem(p, "mrpg:k_hilt") <= 0) return false; try { const d = load(p); return !!(d && d.story && d.story.hiltGot); } catch { return false; } };   // v2.9.13: 自分で カゲツに 勝った 人だけ（拾った 柄は 使えない）
export async function altarAsk(p, d) {
  if (!nearAltar(p) || !d) return false;
  const s = d.story || {};
  if (!s.enmaJoin && (s.enma || 0) >= 1 && (d.own || []).includes(SPECIES.enma?.idx)) s.enmaJoin = true;   // 前の バージョンで 仲間に した 人
  if (hasHilt(p) && s.ending && !s.musashiJoin && !s.enmaClear) { await notice(p, "閻魔の神殿", "§4魔神の鍔が 震えている……。\n§7カゲツの 言葉が よみがえる。§fはがねの 村 クロガネ§7 の 弟子 §cムサシ§7 を たずねよう。"); return "done"; }
  if (s.enmaJoin && !(s.musashiJoin && !s.enmaClear) && !hasHilt(p)) return false;
  if (hasHilt(p) && s.ending && s.musashiJoin && !s.enmaClear) {
    const ok = await confirm(p, "閻魔の神殿", ["§5§l閻魔の神殿§r", "§4魔神の鍔が 燃えるように 熱い。", "§f玉座の 前に、鍔の ない 刀が 浮かんでいる……", "", "§c魔神の鍔を 捧げますか？", "§7ムサシ「……待ってろ、エンマ。今 行く。」", "§4魔神 エンマ（Xランク・Lv100）と 戦う。§7（負けても また 挑める）"].join("\n"), "捧げる", "やめる");
    return ok ? "go" : "cancel";
  }
  if (s.enmaJoin && !hasHilt(p)) return false;
  if (hasHilt(p) && s.ending) {
    const ok = await confirm(p, "閻魔の神殿", [
      "§5§l閻魔の神殿§r", "§d魔神の鍔が 震えている。", "§fエンマ「……刀を 交えたいか。よかろう。」", "",
      "§c魔神の鍔を 捧げて、もう一度 エンマと 戦いますか？ §7（鍔は なくならない）", `§4魔神 エンマ（Xランク・Lv100）${s.enma ? `§7（勝利 ${s.enma}かい）` : ""}`, "§7勝つと 豪華な ほうび",
    ].join("\n"), "捧げる", "やめる");
    return ok ? "go" : "cancel";
  }
  if (!s.enmaDream) return "dream";
  const nmT = s.ending ? "閻魔の神殿" : "？？？の 神殿";   /* 第69版: クリア前は 名前を かくす */
  const ok = await confirm(p, nmT, [`§5§l${nmT}§r`, "§7あの 悪夢が 頭を よぎる。鍔の ない 刀……手も 足も 出なかった。", s.ending ? "§8（あの 刀に 鍔が あれば……。伝説の マスターが 何か 知っているかも しれない）" : "§8（いまは まだ 何も できない 気が する）", "", "§c奥へ 進みますか？"].join("\n"), "進む", "やめる");
  return ok ? "dream" : "cancel";
}
// v2.8: 悪夢。こちらは 何も できず、先手で 斬られる 強制戦闘（かならず 負ける）→ 自分の 家で 目が さめる
export async function dreamFlow(p, fight, homeTp) {
  busy.add(p.id);
  try { return await dreamInner(p, fight, homeTp); } finally { busy.delete(p.id); }
}
async function dreamInner(p, fight, homeTp) {
  for (const q of [p]) { sound(q, "mob.warden.heartbeat", 1); sound(q, "ambient.cave", 0.6); }
  try { showTitle(p, "§7嫌な 予感が する……", { subtitle: "§8空気が 凍りついた", fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  await new Promise((r) => system.runTimeout(r, 50));
  try { p.runCommand("camera @s fade time 0.3 0.6 0.4 color 40 0 0"); } catch {}
  sound(p, "mob.wither.spawn", 0.5);
  await notice(p, "？？？", "§4§l？？？§r\n\n§f「……」\n\n§7玉座の 奥から、鍔の ない 抜き身の 刀を 下げた 男が 現れた。");
  busy.delete(p.id);
  const res = await fight(p, { team: [{ sid: "enma", lv: 100, q: 1, plus: 99 }] }, { tier: 2, name: "？？？", fam: "", npc: null, arena: "？？？の 神殿", theme: "hell", dream: true, speaker: "？？？" });
  busy.add(p.id);
  if (res === null || res === undefined || (typeof res === "string" && res.startsWith("_"))) return false;   // v3.0: 戦いが はじまらなかった ときは 悪夢を 見た ことに しない（また 起きる）
  const d = load(p);
  if (d) { const s = d.story || (d.story = {}); s.enmaDream = (s.enmaDream || 0) + 1; for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d); }
  try { p.runCommand("camera @s fade time 0.5 2.5 1.5 color 0 0 0"); } catch {}
  await new Promise((r) => system.runTimeout(r, 18));
  try { homeTp && homeTp(p); } catch {}
  await new Promise((r) => system.runTimeout(r, 50));
  sound(p, "mob.warden.heartbeat", 1.4);
  try { showTitle(p, "§f……はっ！", { subtitle: "§7悪夢を 見ていた ようだ……", fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 20 }); } catch {}
  await new Promise((r) => system.runTimeout(r, 40));
  await notice(p, "悪夢", ["§7気がつくと、自分の 家の ベッドの 上だった。", "§7汗で びっしょりだ。仲間たちが 心配そうに こちらを 見ている。", "", "§f鍔の ない 刀……。何も できなかった。あれは、ただの 夢だったのか……？", `§8（${(load(p)?.story?.ending) ? "閻魔の神殿" : "？？？の 神殿"}には、まだ 近づかない ほうが よさそうだ）`].join("\n"));
  return true;
}
// 真の 裏ボス エンマ。fight は story.js から 受けとる（循環 import を さけるため）
export async function altarFlow(p, d, fight) {
  if (!d) return false;
  if (!hasHilt(p)) { await notice(p, "閻魔の神殿", "§7魔神の鍔が 見つからない……"); return true; }
  const s = d.story || (d.story = {});
  if (s.musashiJoin && !s.enmaClear) {   // v2.9.14: 魔神編
    try { const SG = await import("./saga.js"); if (!SG.majinReady(d)) { await notice(p, "閻魔の神殿", "§7鍔は 静かな ままだ……。§f（まだ やる ことが ある。ガイドブック → ストーリーの 目標を 見よう）"); return true; } } catch {}
    return possessionFlow(p, d, fight);
  }
  for (const q of world.getAllPlayers()) if (q.dimension.id === p.dimension.id && Math.hypot(q.location.x - p.location.x, q.location.z - p.location.z) < 64) { sound(q, "mob.wither.spawn", 0.6); sound(q, "ambient.weather.thunder", 0.8); }
  try { showTitle(p, "§4§l閻 魔", { subtitle: "§7地の底の 裁きの 座より", fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 15 }); } catch {}
  await notice(p, "魔神の鍔", "§d魔神の鍔が 光り、エンマが 姿を 現した……");
  await notice(p, "エンマ", "§4§lエンマ§r\n\n§f「……腕は 鈍って おらぬか。見せて みよ。」");
  const n = s.enma || 0;   // v3.0: 勝つたびに 能力 +500・HP +1000・技と かしこさも ふえる（battle.js）
  const res = await fight(p, { team: [{ sid: "enma", lv: 100, q: 1, plus: 99 }] }, { tier: 2, name: "エンマ", fam: "", npc: null, arena: "閻魔の 裁き場", theme: "hell", enma: true, enmaN: n, speaker: "エンマ", lines: { win: "……", lose: "……" } });
  d = load(p); if (!d) return true;
  const st = d.story || (d.story = {});
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  if (res !== "win") { save(p, d); await notice(p, "閻魔の神殿", "§4§lエンマ§r§f「……まだ 足りぬ。出直せ。」\n§7エンマは 鍔へ 還っていった。§d魔神の鍔が 手元に 戻った。§7仲間は 回復した。"); return true; }
  st.enma = (st.enma || 0) + 1;
  const got = [];
  d.gold += 500000; got.push(gold(500000));
  giveItem(p, "mrpg:i_tal9", 1); got.push(ITEMS.i_tal9.name);
  giveItem(p, "mrpg:s_all4", 1); got.push(ITEMS.s_all4.name);
  if (st.enma % 3 === 0) { giveItem(p, "mrpg:sx_god", 1); got.push("§6神域の石板"); }
  const pct = 0, join = false;   // v2.9.14: エンマは 魔神編で かならず 仲間に なる（再戦では ほうびだけ）
  if (join) {
    st.enmaJoin = true;
    const m = makeMonster("enma", 60, true);
    m.tal = Object.fromEntries(STATS.map((k) => [k, TAL_MAX]));
    const c = calcStats(m); m.hp = c.hp; m.mp = c.mp;
    addMon(d, m); mark(d.own, "enma"); mark(d.seen, "enma");
    got.push("§4§lエンマが 起きあがり、こちらを 見ている……仲間に なった！");
  } else got.push("§4エンマは 静かに うなずき、魔神の鍔へ もどった。", "§d魔神の鍔が 手元に 戻った", `§7（つぎの エンマは もっと 強い：能力 +500・HP +1000・技が ふえる）`);
  save(p, d);
  for (const q of [p]) { q.sendMessage(join ? `§4§l★ ${p.name}の もとに 真の 裏ボス エンマが 下った！ ★` : `§4★ ${p.name}が エンマに 勝った！（${st.enma}かいめ）`); sound(q, "ui.toast.challenge_complete", 1); }
  await notice(p, join ? "エンマが 仲間に！" : "エンマ 撃破！", [`§4§lエンマ§r§f「魅せてくれたな…」`, "", ...got.map((x) => "§e" + x)].join("\n"));
  return true;
}

// ---- v2.2.2: 終の遺跡（遺跡を 8つ 越えると 開く・墓守の 竜）----
const RF_KEY = "mrpg:rfin";
function rfBase() { const s = world.getDefaultSpawnLocation(), R = WREGIONS.find((r) => r.id === "necro"); const o = Math.round(140 * LAYOUT.k); return R ? { x: Math.floor(s.x + R.c[0] + o), z: Math.floor(s.z + R.c[1] + o) } : { x: Math.floor(s.x) - 96, z: Math.floor(s.z) + 96 }; }
export function rfInfo() { try { const v = world.getDynamicProperty(RF_KEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } }
function setRf(v) { try { world.setDynamicProperty(RF_KEY, JSON.stringify(v)); } catch {} }
export function rfOn() { if (!rfInfo()) { const b = rfBase(); setRf({ x: b.x, z: b.z, y: null, built: false }); } return rfInfo(); }
export function nearRf(p, r = 8) {
  const a = rfInfo();
  if (!a || !a.built || p.dimension.id !== "minecraft:overworld") return false;
  return Math.hypot(p.location.x - a.x - 0.5, p.location.z - a.z - 0.5) <= r && Math.abs(p.location.y - a.y) < 6;
}
function buildRf(dim, a, y) {
  const { x, z } = a;
  const C = [`fill ${x - 9} ${y} ${z - 9} ${x + 9} ${y + 10} ${z + 9} air`, `fill ${x - 9} ${y - 1} ${z - 9} ${x + 9} ${y - 1} ${z + 9} mossy_stone_bricks`, `fill ${x - 9} ${y - 2} ${z - 9} ${x + 9} ${y - 2} ${z + 9} cobblestone`,
    `fill ${x - 6} ${y - 1} ${z - 6} ${x + 6} ${y - 1} ${z + 6} chiseled_stone_bricks`, `fill ${x - 4} ${y - 1} ${z - 4} ${x + 4} ${y - 1} ${z + 4} cracked_stone_bricks`,
    `fill ${x - 1} ${y} ${z - 2} ${x + 1} ${y} ${z + 2} deepslate_tiles`, `fill ${x - 1} ${y + 1} ${z - 2} ${x + 1} ${y + 1} ${z + 2} polished_deepslate`, `setblock ${x} ${y + 2} ${z} soul_lantern`];
  for (const [dx, dz] of [[-7, -7], [7, -7], [-7, 7], [7, 7], [0, -8], [0, 8], [-8, 0], [8, 0]]) { const h = 3 + ((dx * 7 + dz * 3) & 3); C.push(`fill ${x + dx} ${y} ${z + dz} ${x + dx} ${y + h} ${z + dz} mossy_stone_bricks`); if (h > 4) C.push(`setblock ${x + dx} ${y + h + 1} ${z + dz} soul_lantern`); }
  for (const c of C) run(dim, c);
}
system.runInterval(() => {
  const a = rfInfo();
  if (!a) return;
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue;
    const dist = Math.hypot(p.location.x - a.x, p.location.z - a.z);
    if (!a.built && dist < 56) {
      if (stageNear(a.x, a.z)) continue;   // 戦いの ステージが 近い あいだは まつ
      const y = spotY(p.dimension, a.x, a.z, 8); if (y === null) continue;   // v2.9.12: 本当の 地表に（宙に 浮いたり 埋まったり しない）
      buildRf(p.dimension, a, y);
      a.y = y; a.built = true; setRf(a);
      try { p.sendMessage("§6§l終の遺跡§r§6 が 土の 下から せり上がった……"); } catch {}
      sound(p, "ambient.cave", 0.7);
      return;
    }
    if (a.built && dist < 10) {
      try { p.dimension.spawnParticle("minecraft:soul_particle", { x: a.x + 0.5, y: a.y + 2.5, z: a.z + 0.5 }); } catch {}
      if (dist < 7) try { barNote(p).setActionBar("§6終の遺跡 §7― 棺の 前で ガイドブックを 開くと 墓守が 目を さます"); } catch {}
    }
  }
}, 40);
export async function rfAsk(p, d) {
  const s = qs(d);
  if (!nearRf(p) || s.ruins < 8) return false;
  const P = partyPower(d);
  const ok = await confirm(p, RUIN_FINAL.name, [`§6§l${RUIN_FINAL.name}`, "§f苔むした 棺の 奥から、冷たい 風と 古い 竜の 気配が する……", "", `§c墓守 ${SPECIES[RUIN_FINAL.sid].name}（${SPECIES[RUIN_FINAL.sid].rank}）  Lv${Math.min(100, Math.max(90, P.lv + 4))}`, s.ruinFinal ? "§7（墓守には 何度でも 挑める）" : "§7逃げる・スカウトは できない"].join("\n"), "目覚めさせる", "やめる");
  return ok ? "go" : "cancel";
}
export async function rfFlow(p, d, fight) {
  const s0 = qs(d);
  for (const l of RUIN_FINAL.pre) await notice(p, "墓守", `§6§l墓守§r\n\n§f「${l}」`);
  const P = partyPower(d);
  const lv = Math.min(100, Math.max(90, P.lv + 4)), plus = Math.min(99, 35 + Math.max(0, Math.round((P.rank - 7) * 15)) + (s0.rf || 0) * 6);
  const res = await fight(p, { team: [{ sid: RUIN_FINAL.sid, lv, q: 1, plus }] }, { tier: 2, name: "墓守", fam: "", npc: null, arena: RUIN_FINAL.name, ruinFinal: true, rematch: (s0.rf || 0) > 0, theme: "ruins" });
  d = load(p); if (!d) return true;
  const s = qs(d);
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  if (res !== "win") { save(p, d); await notice(p, RUIN_FINAL.name, "§6§l墓守§r§f「……まだ 墓の 重さを 背負えぬか。」\n§7仲間は 回復した。"); return true; }
  const first = !s.ruinFinal;
  s.ruinFinal = true; s.rf = (s.rf || 0) + 1;
  const got = [], give = (id, n = 1) => { if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); } };
  const g = first ? 150000 : 40000; d.gold += g; got.unshift(gold(g));
  if (first) { give("e_king"); give("e_rainbow", 2); give("i_awaken"); give("f_exp50k"); } else { give(endingDone(d) ? "sl3" : "e_rainbow"); if (Math.random() < 0.3) give("e_king"); if (endingDone(d)) give("sx_god"); }
  save(p, d);
  for (const q of world.getAllPlayers()) q.sendMessage(`§6§l＊ ${p.name}が ${RUIN_FINAL.name}の 墓守を 越えた！`);
  await notice(p, RUIN_FINAL.name, [`§6§l墓守§r§f「${RUIN_FINAL.win}」`, "", ...got.map((x) => "§e" + x)].join("\n"));
  return true;
}

// v2.4: 閻魔の神殿は はじめから ある（クリア前は 何も 起きない）
system.runTimeout(() => { try { altarOn(); } catch {} }, 200);

// v2.9.7: 神殿の 戦いでは 刀を あずからないので、返す 処理は 不要（使われて いなかった 処理を 消した）
