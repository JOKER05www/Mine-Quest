// 第76版: NPC に 話しかけた ときの 追加の 受け口（追加ストーリーの 神官・キャンプ）。(p, e) => true なら そちらで 話す
export const NPC_HOOKS = [];
