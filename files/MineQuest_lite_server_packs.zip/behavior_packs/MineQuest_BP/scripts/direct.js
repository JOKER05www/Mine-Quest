// 第120版: 演出の 道具（NPC の 表情・頭の 上の 感情マーク・涙・びっくりジャンプ）
// face(e, "shock", 40) / emote(e, "bang") / tears(e, 40) / shockJump(e)
import { system } from "@minecraft/server";

export const FACE = { none: 0, shock: 1, cry: 2, rage: 3, blush: 4, closed: 5, sweat: 6, angry: 7, sad: 8, smile: 9 };
const EMOTES = new Set(["bang", "q", "dots", "sweat", "anger", "heart", "sigh", "note", "spark"]);
const ok = (e) => { try { return !!e && (typeof e.isValid === "function" ? e.isValid() : e.isValid !== false && e.valid !== false); } catch { return false; } };
const wait = (t) => new Promise((r) => system.runTimeout(r, t));
const faceTimer = new Map();   // entity.id → runTimeout の 番号（新しい 表情で 前の もどしを 止める）
const jumping = new Set();

/** 表情を かえる。kind = 名前 か 0〜9。ticks > 0 なら その あと 0 に もどす */
export function face(e, kind, ticks = 0) {
  if (!ok(e)) return false;
  const n = typeof kind === "number" ? kind | 0 : FACE[kind] ?? 0;
  const v = Math.max(0, Math.min(9, n));
  let id; try { id = e.id; e.setProperty("mrpg:face", v); } catch { return false; }
  const old = faceTimer.get(id);
  if (old !== undefined) { try { system.clearRun(old); } catch {} faceTimer.delete(id); }
  if (ticks > 0 && v) {
    const h = system.runTimeout(() => {
      if (faceTimer.get(id) === h) faceTimer.delete(id);
      if (ok(e)) try { if (e.getProperty("mrpg:face") === v) e.setProperty("mrpg:face", 0); } catch {}
    }, ticks | 0);
    if (h !== undefined) faceTimer.set(id, h);
  }
  return true;
}

/** 頭の 上に 感情マーク（! ? … 汗 怒り ハート ため息 音符 きらり） */
export function emote(e, kind) {
  if (!ok(e) || !EMOTES.has(kind)) return false;
  try { const l = e.location; e.dimension.spawnParticle(`mrpg:emote_${kind}`, { x: l.x, y: l.y + 2.3, z: l.z }); return true; } catch { return false; }
}

/** 両目から 涙を こぼす（3 tick ごと・ticks の 間） */
export async function tears(e, ticks = 40) {
  for (let t = 0; t < ticks; t += 3) {
    if (!ok(e)) return;
    try {
      const h = e.getHeadLocation(); let f = { x: 0, z: 1 };
      try { const v = e.getViewDirection(); const m = Math.hypot(v.x, v.z); if (m > 0.01) f = { x: v.x / m, z: v.z / m }; } catch {}
      for (const s of [-1, 1]) e.dimension.spawnParticle("mrpg:tear_drop", { x: h.x + f.x * 0.3 - f.z * 0.12 * s, y: h.y - 0.05, z: h.z + f.z * 0.3 + f.x * 0.12 * s });
    } catch { return; }
    await wait(3);
  }
}

/** びっくりして ぴょんっと（0.4 上へ → 4 tick で もとの 高さへ）。"shock" と いっしょに */
export function shockJump(e) {
  if (!ok(e)) return false;
  let id, y0; try { id = e.id; y0 = e.location.y; } catch { return false; }
  if (jumping.has(id)) return false;
  jumping.add(id);
  const H = [0.4, 0.3, 0.15, 0];
  let k = 0, last = y0;
  const step = () => {
    if (!ok(e)) { jumping.delete(id); return; }
    try { const l = e.location, b = k && Math.abs(l.y - last) < 0.001 ? last - H[k - 1] : l.y; last = b + H[k]; e.teleport({ x: l.x, y: last, z: l.z }); } catch { k = H.length; }   /* 第127版: 歩いて いる とちゅうに 動かされたら その 高さを 基準に（宙に のこらない）*/
    if (++k < H.length) system.runTimeout(step, 1); else jumping.delete(id);
  };
  step();
  return true;
}
