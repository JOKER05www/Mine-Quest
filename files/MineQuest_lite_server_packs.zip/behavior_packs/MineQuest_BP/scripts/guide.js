// 第90版: 目的地の 光（物語の 次の 目標に 空まで 届く 光の 柱を 立てる）
// 遠い ときは 目標の 方向 64m 先に 柱を 立てて 向きを 教える。近く（72m 以内）では 目標の 場所に 立つ。
// 設定 →「目的地の 光」で 消せる（1人ずつ）
import { world, system, MolangVariableMap } from "@minecraft/server";
import { load } from "./store.js";
import { storyTarget } from "./saga.js";
import { busy } from "./ui.js";

const NEAR = 72, PROXY = 64;
const GOLD = { red: 1, green: 0.85, blue: 0.35 }, PALE = { red: 0.75, green: 0.9, blue: 1 };
const LAST = new Map();   // 人 → { t, g }（目標は 2秒ごとに 読みなおす）
function vm(col, sc) { const m = new MolangVariableMap(); try { m.setColorRGB("variable.color", col); m.setFloat("variable.scale", sc); } catch {} return m; }
function groundAt(dim, x, z, fallback) { try { const t = dim.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) }); if (t) return t.location.y + 1; } catch {} return fallback; }
system.runInterval(() => {
  const now = system.currentTick || 0;
  for (const p of world.getAllPlayers()) {
    try {
      if (p.getDynamicProperty("mrpg:nobeam") === true || busy.has(p.id) || p.dimension.id !== "minecraft:overworld") continue;
      let c = LAST.get(p.id);
      if (!c || now - c.t >= 40) { let g = null; try { const d = load(p); if (d) g = storyTarget(p, d); } catch {} c = { t: now, g }; LAST.set(p.id, c); }
      const g = c.g; if (!g || typeof g.x !== "number" || typeof g.z !== "number") continue;
      const l = p.location, dx = g.x - l.x, dz = g.z - l.z, dist = Math.hypot(dx, dz);
      if (dist < 6) continue;   // 着いた
      const near = dist <= NEAR, f = near ? 1 : PROXY / dist, bx = l.x + dx * f, bz = l.z + dz * f;
      const by = groundAt(p.dimension, bx, bz, near && typeof g.y === "number" ? g.y : l.y);
      p.dimension.spawnParticle("mrpg:beacon", { x: bx, y: by + 28, z: bz }, vm(near ? GOLD : PALE, near ? 1.4 : 0.9));
      if (near) p.dimension.spawnParticle("mrpg:rise", { x: bx, y: by + 0.2, z: bz }, vm(GOLD, 1));
    } catch {}
  }
}, 20);
world.afterEvents.playerLeave.subscribe(({ playerId }) => LAST.delete(playerId));
