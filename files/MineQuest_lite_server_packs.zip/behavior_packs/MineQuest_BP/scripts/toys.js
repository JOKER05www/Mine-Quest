// 第113版: 相棒の おもちゃ・ごはん・町の 人への 贈り物・地方の 名物・おもちゃ屋
// 道具の データは data.js の ITEMS（pt = toy / food / gift）。使うと menu → EXH.use → ここ（相棒の 近くで）
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES, FAMILIES } from "./data.js";
import { load, save, allMons } from "./store.js";
import { busy, choose, notice, paged, ICON, ITEM_ICON, gold, giveItem, takeItem, sound, anim, barNote, EXH, BAG_KEEP } from "./ui.js";
import { hooks, findPet } from "./field.js";
import { exOf, exSave, dayNo, regAtLoc } from "./explore.js";
import { NPC_HOOKS } from "./npchook.js";
import { TOWNS } from "./structures.js";
import { WREGIONS } from "./worldmap.js";
import { rankCap, wtCap } from "./quest.js";

const B = (t, i) => [t, i];
const IDS = Object.keys(ITEMS).filter((id) => ITEMS[id].pt);
export const PET_ITEMS = IDS.filter((id) => ITEMS[id].pt !== "gift");
/* GIFTS: "mrpg:アイテムID" → { kind, name }（social.js の 贈り物）。おもちゃも 子どもへの 贈り物に なる */
export const GIFTS = {};
for (const id of IDS) { const it = ITEMS[id]; if (it.pt === "gift") GIFTS[`mrpg:${id}`] = { kind: it.gk, name: it.name, mei: !!it.mei }; else if (it.pt === "toy") GIFTS[`mrpg:${id}`] = { kind: "toy", name: it.name }; }
for (const id of IDS) BAG_KEEP.add(id);   /* 手に 持って 使う・わたす ので 持ち物に のこす */
export const GK_NAME = { flower: "花", sweet: "あまい もの", food: "食べ物", gem: "宝石", book: "本", craft: "手作りの 小物", toy: "おもちゃ" };
const FAM_N = Object.fromEntries(FAMILIES.map((f) => [f.id, f.name]));
export const favText = (it) => ((it.pf || []).includes("all") ? "どの 系統も 大好き" : (it.pf || []).map((f) => FAM_N[f] || f).join("・"));

// ---------- 1日の きろく（なつき度の 上限・おもちゃの 待ち時間）----------
export const DAY_CAP = 30;   /* 1体が 1日に 道具で 上がる なつき度の 上限 */
const TOY_CD = 600;   /* おもちゃは 30秒に 1回 */
const TK = "mrpg:toyd", CD = new Map();
function stOf(p) { let s = null; try { const v = p.getDynamicProperty(TK); if (typeof v === "string") s = JSON.parse(v); } catch {} if (!s || s.d !== dayNo() || typeof s.g !== "object") s = { d: dayNo(), g: {}, c: (s && s.c) || 0 }; return s; }   /* c は 日を またいでも 数え続ける（なつき度の 記録の 印が かぶらない）*/
function stSave(p, s) { try { p.setDynamicProperty(TK, JSON.stringify(s)); } catch {} }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { for (const k of CD.keys()) if (k.startsWith(playerId)) CD.delete(k); }); } catch {}

const bar = (p, m) => { try { barNote(p).setActionBar(m); } catch {} };
const hearts = (e, n) => { for (let k = 0; k < n; k++) try { const l = e.location; e.dimension.spawnParticle("minecraft:heart_particle", { x: l.x + (Math.random() - 0.5) * 0.9, y: l.y + 0.8 + Math.random() * 0.9, z: l.z + (Math.random() - 0.5) * 0.9 }); } catch {} };
const happy = (e) => { try { const l = e.location; e.dimension.spawnParticle("minecraft:villager_happy", { x: l.x, y: l.y + 1.2, z: l.z }); } catch {} };
const FAV_LINE = { blob: "ぷるるん！ と とびはねた", animal: "しっぽを ぶんぶん ふって いる", beast: "ごろんと おなかを 見せた", aqua: "ぱしゃっと ひれで 水を はねた", dragon: "うれしそうに 小さく ほえた",
  golem: "ごとごと からだを ゆらして いる", sword: "ぴしっと 背すじを のばした", king: "まんぞくそうに うなずいた", god: "やさしい 光に つつまれた", nether: "目を きらきら させて いる" };
const LIKE_LINE = ["うれしそうだ", "なかなか 気に入った みたい", "ちょっと たのしそう"];

function gainNk(p, m, n, why, k) {
  if (n <= 0) return;
  if (hooks.addNkOut) { hooks.addNkOut(p, n, `${why}${"§r".repeat(k)}`); return; }   /* bond.js の なつき度（段が 上がると お知らせ）。1日 1回の 記録は 見えない 印で 分ける */
  const e = exOf(p); e.nk = e.nk || {}; e.nk[m.id] = Math.min(1000, (e.nk[m.id] || 0) + n); exSave(p);
}

async function usePet(p, d, id) {
  const it = ITEMS[id];
  const m = d && d.out ? allMons(d).find((x) => x.id === d.out) : null, pet = m ? findPet(p) : null;
  let far = true; try { far = !pet || pet.dimension.id !== p.dimension.id || Math.hypot(pet.location.x - p.location.x, pet.location.z - p.location.z) > 10; } catch {}
  if (!m || far) { await notice(p, it.name, `§7相棒を 連れて いる ときに、そばで 使おう。\n§f${it.pt === "food" ? "ごはん" : "おもちゃ"}を あげると なつき度が 上がる §7（1日 ${DAY_CAP}まで）\n§7好きな 系統: §e${favText(it)}`); return; }
  const key = `${p.id}|${id}`, now = system.currentTick;
  if (it.pt === "toy" && (CD.get(key) || 0) > now) { bar(p, `§7${m.nm}は さっき ${it.name}で 遊んだ ばかり。すこし 休もう`); return; }
  const fam = SPECIES[m.sp]?.fam, fav = (it.pf || []).includes("all") || (it.pf || []).includes(fam);
  const s = stOf(p), left = DAY_CAP - (s.g[m.id] || 0);
  if (it.pt === "food" && left <= 0) { bar(p, `§7${m.nm}は もう おなかが いっぱいみたい（また あした）`); return; }
  if (it.pt === "food") { if (!takeItem(p, `mrpg:${id}`)) return; } else CD.set(key, now + TOY_CD);   /* ごはんは 先に へらす（おもちゃは へらない）*/
  const n = Math.max(0, Math.min(left, (it.pt === "food" ? (fav ? 10 : 4) : (fav ? 8 : 3)) + ((it.tier || 0) >= 2 ? 6 : (it.tier || 0) >= 1 ? 2 : 0)));
  s.g[m.id] = (s.g[m.id] || 0) + n; s.c = (s.c || 0) + 1; stSave(p, s);
  gainNk(p, m, n, it.pt === "food" ? `${it.name}を 食べた` : `${it.name}で 遊んだ`, s.c);
  try { pet.teleport(pet.location, { facingLocation: p.location }); } catch {}
  anim(pet, "happy"); hearts(pet, fav ? 7 : 3);
  sound(p, it.pt === "food" ? "random.eat" : "random.pop", fav ? 1.5 : 1.15);
  if (fav) { happy(pet); system.runTimeout(() => { try { if (pet.isValid()) { hearts(pet, 5); happy(pet); } } catch {} sound(p, "random.levelup", 1.8); }, 12); }
  const line = fav ? FAV_LINE[fam] || "大よろこびだ！" : LIKE_LINE[Math.floor(Math.random() * LIKE_LINE.length)];
  bar(p, `§d${m.nm}は ${line}${fav ? " §6★大好き！" : ""} ${n ? `§7（なつき度 +${n}）` : "§7（きょうは もう 十分 なかよく なった）"}`);
}

async function useGift(p, it) {
  await notice(p, it.name, [it.mei ? `§6${WREGIONS[it.reg]?.short || ""}の 名物§r` : "§d贈り物§r", "§f手に 持って 町の 人に 話しかけると わたせる。", `§7（${GK_NAME[it.gk] || "贈り物"}が 好きな 人は とても よろこぶ）`].join("\n"));
}

/* 道具を 使った とき（menu.js の useItemFlow → EXH.use）。ほかの 道具は 前の 受け口へ */
function hookUse() {
  if (EXH.use && EXH.use.__toy) return;
  const prev = EXH.use;
  const f = async (p, d, id) => { const it = ITEMS[id]; if (it && it.pt) return it.pt === "gift" ? useGift(p, it) : usePet(p, d, id); if (prev) return prev(p, d, id); };
  f.__toy = true; EXH.use = f;
}
hookUse(); system.run(hookUse);

// ---------- おもちゃ屋（mrpg:role = "toy"）----------
export const isRole = (e, r) => { try { return e.getDynamicProperty("mrpg:role") === r || e.hasTag(`mrpg_role_${r}`); } catch { return false; } };
export function townReg(e) {
  let t = null; try { t = e.getDynamicProperty("mrpg:town"); } catch {}
  const T = typeof t === "string" ? TOWNS.find((x) => x.id === t) : null;
  if (T && typeof T.reg === "number") return T.reg;
  try { return Math.max(0, regAtLoc(e.location)); } catch { return 0; }
}
export const shopPrice = (id) => ITEMS[id]?.shop || 0;
export function shopList(cat, reg, c) {
  const tmax = wtCap(c) + 1;
  if (cat === "mei") return IDS.filter((id) => ITEMS[id].mei && ITEMS[id].reg === reg);
  return IDS.filter((id) => { const it = ITEMS[id]; return it.pt === cat && !it.mei && (it.tier || 0) <= tmax; });
}
const CATS = [["toy", "相棒の おもちゃ", "i_party"], ["food", "相棒の ごはん・おやつ", "i_shop"], ["gift", "町の 人への 贈り物", "i_star"], ["mei", "この 地方の 名物", "i_book"]];
export async function toyShop(p, e) {
  if (busy.has(p.id)) return;
  busy.add(p.id);
  try {
    const reg = townReg(e), R = WREGIONS[reg];
    for (;;) {
      const d = load(p); if (!d) { await notice(p, "おもちゃ屋", "§7まず ガイドブックで 最初の 仲間を えらぼう。"); return; }
      const c = await choose(p, "おもちゃ屋", `§fおもちゃ屋「相棒が よろこぶ ものも、町の 人への 贈り物も あるよ！」\n§7所持金: ${gold(d.gold)}\n§7相棒の そばで 使うと なつき度が 上がる（好きな 系統だと 大よろこび）`,
        [...CATS.map(([k, t, ic]) => B(k === "mei" ? `§6${R?.short || ""}の 名物` : t, ICON(ic))), B("§7やめる", ICON("i_back"))]);
      if (c < 0 || c >= CATS.length) return;
      const cat = CATS[c][0], L = shopList(cat, reg, rankCap(d));
      if (!L.length) { await notice(p, "おもちゃ屋", "§7いまは 品切れだよ。"); continue; }
      for (;;) {
        const d2 = load(p); if (!d2) return;
        const k = await paged(p, CATS[c][1], `§7所持金: ${gold(d2.gold)}`, L.map((id) => B(`${ITEMS[id].name}\n§e${shopPrice(id)} §8${ITEMS[id].pt === "gift" ? GK_NAME[ITEMS[id].gk] || "" : favText(ITEMS[id])}`, ITEM_ICON(id))), 8);
        if (k < 0 || !L[k]) break;
        const id = L[k], it = ITEMS[id], pr = shopPrice(id);
        const body = [`§l§e${it.name}§r  §e${pr}`, it.pt === "gift" ? `§f町の 人への 贈り物（${GK_NAME[it.gk] || ""}）${it.mei ? `\n§6${R?.short || ""}でしか 買えない 名物` : ""}` : it.pt === "food" ? `§f相棒の ごはん（食べると なくなる）\n§7好き: §e${favText(it)}` : `§f相棒の おもちゃ（なくならない・30秒ごとに 遊べる）\n§7好き: §e${favText(it)}`, `§7所持金: ${gold(d2.gold)}`].join("\n");
        const Q = [1, 5, 10];
        const q = await choose(p, it.name, body, [...Q.map((n) => B(`${n}こ 買う §e${pr * n}`, ICON("i_shop"))), B("§7やめる", ICON("i_back"))]);
        if (q < 0 || q >= Q.length) continue;
        const n = Q[q], cost = pr * n, d3 = load(p);   /* 待った あとに 読みなおして すぐ 払う（とちゅうで ぬけても 二重に ならない）*/
        if (!d3 || d3.gold < cost) { await notice(p, "おもちゃ屋", `§cお金が たりない。§7（${gold(cost)} いる）`); continue; }
        d3.gold -= cost; save(p, d3); giveItem(p, `mrpg:${id}`, n); sound(p, "random.orb", 1.2);
        bar(p, `§a${it.name} ×${n} を 買った！ §7（のこり ${gold(d3.gold)}§7）`);
      }
    }
  } catch (err) { console.warn(`[MonsterRPG] toyshop: ${err}`); } finally { busy.delete(p.id); }
}
NPC_HOOKS.unshift((p, e) => {
  if (!isRole(e, "toy")) return false;
  let sn = false; try { sn = !!p.isSneaking; } catch {} if (sn) return false;   /* しゃがむと ふつうに 話せる */
  if (busy.has(p.id)) return true;
  system.run(() => toyShop(p, e));
  return true;
});
export const __toys = { usePet, stOf, CD, IDS };
