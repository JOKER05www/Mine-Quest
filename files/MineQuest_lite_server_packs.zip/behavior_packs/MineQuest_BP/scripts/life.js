// 第102版: 旅の くらし（記録・実績・相棒・料理と 畑・挑戦・便利な 機能・行商人と 旅人）
// 軽く: 画面（探索手帳の ボタン）と、explore.js の 2秒ごとの 見はり（XT.tick）に 乗る
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES } from "./data.js";
import { WREGIONS, regionLv } from "./worldmap.js";
import { TOWNS, getTown } from "./structures.js";
import { load, save } from "./store.js";
import { busy, choose, notice, confirm, paged, ICON, MON_ICON, giveItem, takeItem, countItem, sound, barNote, showTitle, gold, setJob, EXH } from "./ui.js";
import { hooks, findPet, spawnPet, recallPet } from "./field.js";
import { battleHooks, START_HOOKS } from "./battle.js";
import { calcStats, BUF_KEYS, BUF_MAX } from "./core.js";
import { rankCap, storyLootOk, endingDone } from "./quest.js";
import { openUpTo, team as sagaTeam } from "./saga.js";
import { fight } from "./story.js";
import { award, TITLES } from "./endgame.js";
import {
  exOf, exSave, addPt, prize, giveGold, XT, KINDS, spotsOf, spotInfo, EVT, NODES, groundNear, naviPush, regAtLoc, hash, dayNo, dirTo, hd, run, fx, nowT, pickA,
  ENVR, MATS, WXS, WXN, wxOf, wxName, xRank, explored, regionDone, cellOk, bitGet, rideLv, LOST,
} from "./explore.js";
import { spawnBoss, spawnJoiner, scrap, nkLv, __ex2 } from "./explore2.js";

const OW = "minecraft:overworld";
const B = (t, icon) => [t, icon];
const rnd = () => Math.random();
const say = (p, m) => { try { p.sendMessage(m); } catch {} };
const bar = (p, m) => { try { barNote(p).setActionBar(m); } catch {} };
const timeOf = () => { try { return world.getTimeOfDay(); } catch { return 6000; } };
const allMons = (d) => [...d.party, ...(d.bench || []), ...d.box];
const km = (m) => (m >= 1000 ? `${(m / 1000).toFixed(1)}km` : `${m}m`);
const dstr = (dn) => new Date(dn * 86400000).toISOString().slice(0, 10);
const owner = (f, p) => !f.guest && (!f.owner || f.owner === p.id);

// ================= 戦いの はじめ（26 なつき度・29 得意な 地形・43 料理）=================
const FOOD = { fd_stew: ["atk", "wpn"], fd_soup: ["mat", "brt"], fd_curry: BUF_KEYS, fd_cake: ["spd"], fd_tea: ["def"], fd_bento: ["atk", "spd"], fd_egg: ["mdf"], fd_onigiri: ["def", "mdf"] };
const TERR = { port: "aqua", forest: "animal", volcano: "dragon", desert: "golem", snow: "blob", dark: "nether", crystal: "golem", castle: "sword", sky: "dragon", village: "animal" };
START_HOOKS.push((B0, p, d) => {
  if (!p || B0.pvp) return;
  const e = exOf(p), mine = (B0.allies || []).filter((f) => owner(f, p));
  e.nk = e.nk || {};
  for (const f of mine) { const lv = nkLv(e.nk[f.m?.id] || 0); if (lv) f.nkEndure = [0, 0.1, 0.2, 0.3][lv]; }
  if (e.food && e.food.n > 0 && FOOD[e.food.k]) { for (const f of mine) for (const k of FOOD[e.food.k]) f.buf[k] = Math.min(BUF_MAX, (f.buf[k] || 0) + 1); e.food.n--; say(p, `§e${ITEMS[e.food.k]?.name}の 力！ §7（あと ${e.food.n}回）`); if (e.food.n <= 0) delete e.food; exSave(p); }
  const fam = TERR[WREGIONS[regAtLoc(p.location)]?.style]; const lead = mine[0];
  if (lead && fam && SPECIES[lead.m?.sp]?.fam === fam) { lead.buf.spd = Math.min(BUF_MAX, (lead.buf.spd || 0) + 1); say(p, `§a${lead.name}は 得意な 地形で 走力が 上がった！`); }
});

// ================= 道具を 使う（料理・おやつ・帰りの羽・パラシュート）=================
EXH.use = async (p, d, id) => {
  const it = ITEMS[id]; if (!it) return;
  if (it.kind === "food") {
    if (!(await confirm(p, it.name, `§f${it.name}を 食べますか？\n§7次の 野生との 戦い 3回、${FOOD[id].map((k) => ({ atk: "物力", def: "硬力", mat: "魔力", mdf: "魔硬力", spd: "走力", wpn: "武力", brt: "吹力" })[k]).join("・")} +1段階（いま 食べて いる 料理と 入れかわる）`, "食べる", "やめる"))) return;
    if (!takeItem(p, `mrpg:${id}`)) return; const e = exOf(p); e.food = { k: id, n: 3 }; e.ck2 = (e.ck2 || 0) + 1; exSave(p, true); sound(p, "random.burp"); return;
  }
  if (it.kind === "snack") {
    const L = allMons(d); const k = await paged(p, "おやつ", "§fだれに あげる？ §7（なつき度 +60）", L.map((m) => B(`${m.nm} §7Lv${m.lv}\n§8なつき ${exOf(p).nk?.[m.id] || 0}`, MON_ICON(m.sp))), 8); if (k < 0 || !L[k]) return;
    if (!takeItem(p, "mrpg:x_snack")) return; const e = exOf(p); e.nk = e.nk || {}; e.nk[L[k].id] = Math.min(1000, (e.nk[L[k].id] || 0) + 60); exSave(p, true); sound(p, "random.eat"); await notice(p, "おやつ", `§d${L[k].nm}は うれしそうだ！ §7（なつき度 ${e.nk[L[k].id]}・段階 ${nkLv(e.nk[L[k].id])}）`); return;
  }
  if (it.kind === "homewing") {
    if (p.dimension.id !== OW || (hooks.noSpawn && hooks.noSpawn(p))) { await notice(p, it.name, "§7ここでは 使えない。"); return; }
    let best = null, bd = 1e9; for (const t of TOWNS) { const g = getTown(t.id); if (!g || !g.built || !(d.towns || []).includes(t.id)) continue; const dd = hd(g, p.location); if (dd < bd) { bd = dd; best = g; } }
    if (!best) { await notice(p, it.name, "§7まだ おとずれた 町が ない。"); return; }
    if (!takeItem(p, "mrpg:x_wing2")) return; try { p.teleport({ x: best.x, y: best.y + 0.2, z: best.z + 5 }, { dimension: world.getDimension("overworld") }); const pet = findPet(p); if (pet) pet.teleport(p.location, { dimension: p.dimension }); } catch {} sound(p, "mob.endermen.portal"); return;
  }
  if (it.kind === "chute") { if (!takeItem(p, "mrpg:x_chute")) return; try { p.addEffect("slow_falling", 600, { showParticles: false }); } catch {} await notice(p, it.name, "§fパラシュートを ひらいた！ §7（30秒 ゆっくり 落ちる）"); }
};

// ================= 見はり（XT.tick）=================
const RACE = new Map(), HUNT = { t: null };
TITLES.ex_spots = ["名所めぐり", "10種類の 名所を 見つける"]; TITLES.ex_sun = ["ご来光", "展望台で 夜明けを 見る"]; TITLES.ex_moji = ["古代文字の 解読者", "11の 石碑を 読む"]; TITLES.ex_ach = ["探索の 達人", "探索の 実績 20こ"];
XT.tick.push((p, d, e, i, L, tk) => {
  // 49) 最速踏破（はじめて 入った 時刻 → 踏破した 時刻）
  e.fe = e.fe || {}; if (!e.fe[i]) e.fe[i] = Math.floor(nowT() / 1000);
  e.ftd = e.ftd || {}; if (!e.ftd[i] && regionDone(e, i)) e.ftd[i] = Math.floor(nowT() / 1000) - e.fe[i];
  // 10) 名所スタンプ（見つけた 種類）
  const kinds = new Set(Object.keys(e.f).map((k) => k.split(".")[1])); if (kinds.size >= 10 && !e.st10) { e.st10 = 1; const d2 = load(p); if (d2) { award(p, d2, "ex_spots", null); save(p, d2); } }
  // 59) 古代文字（石碑 11）
  if (!e.mj && WREGIONS.every((_, k) => e.f[`${k}.stele`])) { e.mj = 1; say(p, "§6§l11の 石碑の 文字が つながった……！ §r§f「はじまりの 魔物使いは 世界の 果てで 最初の 友と 眠る」"); const d2 = load(p); if (d2) { award(p, d2, "ex_moji", null); save(p, d2); } addPt(p, e, 30); }
  const ph = (tk + (hash(p.id) % 30)) % 30;
  // 167) ご来光・57) 協力の 展望台
  const T = spotInfo(i, "tower");
  if (T?.ok && hd(L, T) < 4 && L.y >= T.y - 1.5) {
    if (!e.sun && (timeOf() >= 22800 || timeOf() < 600)) { e.sun = 1; showTitle(p, "§6§lご来光", { subtitle: `§f${WREGIONS[i].name}の 展望台から`, fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10 }); const d2 = load(p); if (d2) { award(p, d2, "ex_sun", null); save(p, d2); } addPt(p, e, 10); }
    e.ct = e.ct || {}; if (!e.ct[i]) { const q = world.getAllPlayers().find((x) => x.id !== p.id && hd(x.location, T) < 4 && x.location.y >= T.y - 1.5); if (q) { e.ct[i] = 1; say(p, `§a§l${q.name}と いっしょに 展望台に 登った！ 協力の ごほうび`); prize(p, d, i, 1, 1); addPt(p, e, 10); } }
  }
  // 40) レース
  raceTick(p, d, e, L);
  // 41) 宝探し競争
  if (HUNT.t && HUNT.t.ps.includes(p.id)) { const H = HUNT.t; if (nowT() - H.t > 5 * 60000) HUNT.t = null; else if (hd(L, H) < 3) { HUNT.t = null; say(p, "§6§l宝探し競争に 勝った！"); prize(p, d, regAtLoc(H), 1, 2); addPt(p, e, 10); for (const q of world.getAllPlayers()) if (q.id !== p.id) say(q, `§6${p.name}が 宝探し競争に 勝った！`); } else if (ph % 5 === 0) fx(p.dimension, "minecraft:totem_particle", { x: H.x + 0.5, y: L.y + 3, z: H.z + 0.5 }); }
  // 170) レーダーの 常時表示（10秒ごと）
  if (e.rdo && ph % 5 === 2) { const r = radar(p, e, i)[0]; if (r) bar(p, `§bレーダー: ${r}`); }
  // 34/137/138) 行商人・旅人・盗賊（まれに 近くに 出る）
  if (ph === 27 && !XN.has(p.id) && !(hooks.inTown && hooks.inTown(L, OW)) && rnd() < 0.03) spawnXnpc(p, d, i);
  const xn = XN.get(p.id); if (xn && nowT() - xn.t > 5 * 60000) { try { const x = world.getEntity(xn.id); if (x) x.remove(); } catch {} XN.delete(p.id); }
  if (ph === 13) { try { for (const x of p.dimension.getEntities({ type: "mrpg:npc", tags: ["mrpg_xnpc"], location: L, maxDistance: 64 })) if (![...XN.values()].some((v) => v.id === x.id)) x.remove(); } catch {} }   /* 記録に ない 人（遠くで 消せなかった・前に 遊んだ ときの）を 片づける */
  // 58) マルチ限定の 迷子（2人 以上で）
  if (ph === 29 && rnd() < 0.01 && world.getAllPlayers().some((q) => q.id !== p.id && hd(q.location, L) < 30)) { const lv = Math.max(5, regionLv(L)); const cap = rankCap(d), L2 = Object.keys(SPECIES).filter((s) => { const S = SPECIES[s]; return S.wild && !S.hidden && !S.fuseonly && !S.metalmon && ["B", "A"].includes(S.rank) && ["F", "E", "D", "C", "B", "A"].indexOf(S.rank) <= cap; }); const sid = L2.length ? pickA(L2) : null; if (sid) { const x = spawnJoiner(p, sid, lv, "ふたりの 迷子 "); if (x) { x.removeTag("mrpg_lost"); x.addTag("mrpg_lost2"); for (const q of world.getAllPlayers()) if (hd(q.location, L) < 40) say(q, "§b§l2人で 話しかけると 仲間に なる 迷子が いる！"); } } }
});
// 58) 2人の 迷子: そばに もう1人 いると 仲間に
import { HIT_HOOKS } from "./battle.js";
import { makeMonster, addMon } from "./core.js";
HIT_HOOKS.push((p, e) => {
  if (!e.hasTag("mrpg_lost2")) return false;
  const other = world.getAllPlayers().some((q) => q.id !== p.id && q.dimension.id === e.dimension.id && hd(q.location, e.location) < 16);
  if (!other) { say(p, "§7この 子は もう1人 そばに いないと 心を ひらかない みたいだ"); return true; }
  if (e.hasTag("mrpg_done")) return true; e.addTag("mrpg_done");
  const d = load(p); if (!d) return true; let sid; try { sid = e.getDynamicProperty("mrpg:sid"); } catch {} const lv = e.getDynamicProperty("mrpg:lv") || 5; if (!SPECIES[sid]) return true;
  const where = addMon(d, makeMonster(sid, lv, true)); save(p, d); try { e.remove(); } catch {} say(p, `§a${SPECIES[sid].name}が 仲間に なった！ §7（${where === "party" ? "パーティ" : "預かり所"}へ）`); addPt(p, exOf(p), 10); return true;
});
// 40) レース: 5つの 光の 輪を 順に くぐる
function raceTick(p, d, e, L) {
  const R = RACE.get(p.id); if (!R) return;
  if (nowT() - R.t > 180000) { RACE.delete(p.id); say(p, "§7レースは 時間切れ"); return; }
  const c = R.cp[R.k]; for (let a = 0; a < 8; a++) fx(p.dimension, "minecraft:villager_happy", { x: c.x + Math.cos(a) * 2, y: c.y + 1 + Math.sin(a) * 2, z: c.z });
  if (hd(L, c) > 4) return;
  R.k++; sound(p, "random.orb", 1 + R.k * 0.1);
  if (R.k < R.cp.length) { naviPush(p, { name: `レース ${R.k + 1}/${R.cp.length}`, x: R.cp[R.k].x, z: R.cp[R.k].z, dim: OW }); bar(p, `§eチェックポイント ${R.k}/${R.cp.length}`); return; }
  const sec = Math.round((nowT() - R.t) / 100) / 10; RACE.delete(p.id);
  const best = !e.rc || sec < e.rc; if (best) e.rc = sec; e.rcn = (e.rcn || 0) + 1;
  showTitle(p, `§e§lゴール！ ${sec}秒`, { subtitle: best ? "§6自己ベスト！" : `§7ベスト ${e.rc}秒`, fadeInDuration: 4, stayDuration: 40, fadeOutDuration: 8 });
  if (e.rcd !== dayNo()) { e.rcd = dayNo(); prize(p, d, regAtLoc(L), 0, 1); addPt(p, e, 6); }
  exSave(p, true);
}
// 34/137/138) フィールドの NPC
const XN = new Map();
const XK = { peddler: ["行商人", 3], traveler: ["旅の マスター", 7], bandit: ["盗賊", 16] };
function spawnXnpc(p, d, i) {
  const g = groundNear(p, 12, 20); if (!g) return;
  const k = pickA(["peddler", "traveler", "traveler", "bandit"]);
  let e; try { e = p.dimension.spawnEntity("mrpg:npc", { x: g.x + 0.5, y: g.y, z: g.z + 0.5 }); } catch { return; }
  try { setJob(e, XK[k][1]); e.addTag("mrpg_xnpc"); e.setDynamicProperty("mrpg:xk", k); e.setDynamicProperty("mrpg:xr", i); e.nameTag = `§e${XK[k][0]}`; } catch {}
  XN.set(p.id, { id: e.id, t: nowT() });
  say(p, `§e${XK[k][0]}が 近くを 歩いて いる §7（${dirTo(p.location, g)}・話しかけられる）`);
}
EXH.npc = async (p, ent) => {
  if (![...XN.values()].some((v) => v.id === ent.id)) { try { ent.remove(); } catch {} await notice(p, "旅の 人", "§7もう 旅に 出て しまった… §8（前に 遊んだ ときの 人）"); return; }   /* 第103版: ワールドを 閉じて 残った 人は 使えない */
  let k, i; try { k = ent.getDynamicProperty("mrpg:xk"); i = ent.getDynamicProperty("mrpg:xr") || 0; } catch {}
  const d = load(p); if (!d) return;
  if (k === "peddler") {
    const cap = rankCap(d), L = [["x_rmap", 20000], ["x_wing2", 3000], ["x_chute", 2000], ["x_snack", 1500], ["x_bread", 300], ["rf_1", 1200], ["c_revive", 1000]].filter(([id]) => ITEMS[id] && storyLootOk(ITEMS[id], null, cap));
    for (;;) { const c = await choose(p, "行商人", `§f「めずらしい 品が あるよ」\n§7お金: ${gold(d.gold)}`, [...L.map(([id, pr]) => B(`${ITEMS[id].name}\n§8${pr.toLocaleString()} タヨ`, ICON("i_shop"))), B("§7じゃあね", ICON("i_back"))]); const x = L[c]; if (!x) return;
      const d2 = load(p); if (!d2) return; if ((d2.gold || 0) < x[1]) { await notice(p, "行商人", "§7お金が たりない。"); continue; } d2.gold -= x[1]; save(p, d2); giveItem(p, `mrpg:${x[0]}`, 1); sound(p, "random.orb"); }
  }
  const strong = k === "bandit";
  if (!(await confirm(p, XK[k]?.[0] || "旅人", strong ? "§c「その お金、おいて いきな！」\n§7勝つと お金を とりかえせる" : "§f「腕だめし しないか？」\n§7勝つと ほうび（1日 3回まで）", "戦う", "やめる"))) return;
  const R = WREGIONS[i] || WREGIONS[0], lv = Math.min(100, R.lv[1] + (strong ? 6 : 2));
  const foe = sagaTeam(Object.keys(R.fams || { beast: 1 }), lv, 3, strong ? 30 : 15);
  if (!foe.length) return;
  try { ent.remove(); } catch {} for (const [pid, v] of XN) if (v.id === ent.id) XN.delete(pid);   /* 第103版: その 人を 出した プレイヤーの 記録を 消す */
  return async () => {
    const res = await fight(p, { team: foe }, { tier: 1, fam: "", npc: null, theme: R.land?.[0] || "plains", name: XK[k]?.[0] || "旅の マスター", arena: strong ? "盗賊との 戦い" : "旅の マスターの 腕だめし", speaker: XK[k]?.[0] || "旅の マスター", easy: false });
    if (res !== "win") return;
    const e = exOf(p), d2 = load(p); if (!d2) return; e.xw = e.xw || [dayNo(), 0]; if (e.xw[0] !== dayNo()) e.xw = [dayNo(), 0];
    if (e.xw[1] >= 3) { say(p, "§7（今日の ほうびは もう もらった）"); return; } e.xw[1]++;
    say(p, `§e${XK[k][0]}に 勝った！ ${giveGold(d2, (strong ? 3000 : 1500) * (1 + Math.floor(i / 2)))}`); prize(p, d2, i, strong ? 1 : 0, 1); save(p, d2); addPt(p, e, strong ? 10 : 6); exSave(p, true);
  };
};

// ================= 探索手帳の ボタン =================
// 64) レーダー
function radar(p, e, i) {
  const L = p.location, out = [];
  for (const q of spotsOf(i)) if (q.info?.ok && !q.info.skip && !e.f[`${i}.${q.k}`] && (e.t[i] || !KINDS[q.k]?.secret)) out.push([hd(L, q.info), `${KINDS[q.k]?.n} ${dirTo(L, q.info)} ${Math.round(hd(L, q.info))}m`]);
  for (const v of NODES.values()) if (v.pid === p.id) out.push([hd(L, v), `採集ポイント ${dirTo(L, v)} ${Math.round(hd(L, v))}m`]);
  const ev = EVT.get(p.id); if (ev) out.push([hd(L, ev), `${XT.evt[ev.kind]?.n || (ev.kind === "star" ? "流れ星" : "光の柱")} ${dirTo(L, ev)} ${Math.round(hd(L, ev))}m`]);
  return out.sort((a, b) => a[0] - b[0]).map((x) => x[1]).slice(0, 8);
}
const ACH = [
  ["歩いて 10km", (e) => (e.walk || 0) >= 10000], ["歩いて 50km", (e) => (e.walk || 0) >= 50000], ["泳いで 1km", (e) => (e.swim || 0) >= 1000], ["ライドで 20km", (e) => (e.rdm || 0) >= 20000],
  ["展望台 3つ", (e) => Object.keys(e.t).length >= 3], ["展望台 ぜんぶ", (e) => Object.keys(e.t).length >= WREGIONS.length], ["秘境 4つ", (e) => secretN(e) >= 4], ["秘境 20", (e) => secretN(e) >= 20],
  ["化石 5回", (e) => (e.fo || 0) >= 5], ["賞金首 1回", (e) => (e.bn || 0) >= 1], ["賞金首 10回", (e) => (e.bn || 0) >= 10], ["環境の レア 5種", (e) => Object.keys(e.r).length >= 5],
  ["環境の レア 15種", (e) => Object.keys(e.r).length >= 15], ["流れ星 5回", (e) => (e.st || 0) >= 5], ["なぞの 宝 3回", (e) => (e.rmn || 0) >= 3], ["迷子 3体", (e) => (e.lo || 0) >= 3],
  ["秘宝 7つ", (e) => Object.keys(e.rl || {}).length >= 7], ["地図の 切れ端 4つ", (e) => Object.keys(e.mp || {}).length >= 4], ["ことわざ 11", (e) => Object.keys(e.pv || {}).length >= 11], ["変わり種 1体", (e) => (e.odd || 0) >= 1],
  ["魚 100cm", (e) => (e.fb || 0) >= 100], ["標高 200", (e) => (e.ymax ?? 0) >= 200], ["地下 Y-50", (e) => (e.ymin ?? 99) <= -50], ["探索ランク 4", (e) => xRank(e.pt) >= 4],
  ["探索ランク 8", (e) => xRank(e.pt) >= 8], ["地方を 1つ 踏破", (e) => Object.keys(e.cl).length >= 1], ["地方を 5つ 踏破", (e) => Object.keys(e.cl).length >= 5], ["写真 5枚", (e) => (e.ph || []).length >= 5],
  ["料理 5回", (e) => (e.ck2 || 0) >= 5], ["レースで 60秒 以内", (e) => (e.rc || 999) <= 60],
];
const secretN = (e) => Object.keys(e.f).filter((k) => KINDS[k.split(".")[1]]?.secret).length;
async function records(p, d) {
  for (;;) {
    const e = exOf(p);
    const c = await choose(p, "旅の 記録", "", [B("§l旅の 数字\n§8きょり・高さ・魚・最速踏破", ICON("i_run")), B("§l踏破メダルと 地図\n§8地方ごと", ICON("i_zukan")), B("§l図鑑メモ\n§8はじめて 会った 地方と 日", ICON("i_zukan")),
      B("§l仲間の 日記\n§8はじめて 勝った 相手", ICON("i_party")), B("§l手帳の スクラップ・手紙\n§8見つけた ものの メモ", ICON("i_help")), B("§l名産図鑑\n§8地方の 素材", ICON("i_shop")), B("§l秘境の 旗\n§8さいしょに 見つけた 人", ICON("i_zukan")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) { const fr = (WREGIONS.map((R, k) => e.ftd?.[k] ? `§f${R.short} §e${Math.floor(e.ftd[k] / 60)}分` : null).filter(Boolean).join("§7・")) || "§7まだ なし";
      let fr2 = []; try { fr2 = JSON.parse(world.getDynamicProperty("mrpg:fishrank") || "[]"); } catch {}
      await notice(p, "旅の 数字", [`§f歩いた §e${km(e.walk || 0)}§f・泳いだ §e${km(e.swim || 0)}§f・ライド §e${km(e.rdm || 0)}`, `§f最高地点 §eY${e.ymax ?? "-"}§f・最低地点 §eY${e.ymin ?? "-"}`, `§f釣った 魚の 自己ベスト §e${e.fb || 0}cm`, `§f魚の 大きさ ランキング: ${fr2.slice(0, 5).map((x, k) => `${k + 1}.${x[0]} ${x[1]}cm`).join(" ") || "なし"}`, `§fレースの ベスト §e${e.rc ? e.rc + "秒" : "-"}`, `§f最速踏破: ${fr}`].join("\n")); }
    else if (c === 1) { const top = Math.min(openUpTo(d), WREGIONS.length - 1); const k = await paged(p, "踏破メダルと 地図", "", WREGIONS.slice(0, top + 1).map((R, j) => { const x = explored(e, j); return B(`${R.name}\n§8${x >= 100 ? "§6金" : x >= 80 ? "§f銀" : x >= 50 ? "§c銅" : "§7なし"}§8 メダル・${x}%`, ICON("i_zukan")); }), 8); if (k >= 0) await notice(p, WREGIONS[k].name, mapArt(e, k)); }
    else if (c === 2) { const L = Object.entries(e.fs || {}).map(([ix, v]) => { const sp = Object.keys(SPECIES).find((s) => SPECIES[s].idx === +ix); return sp ? `§f${SPECIES[sp].name} §7${WREGIONS[v % 16]?.short || ""}・${dstr(Math.floor(v / 16))}` : null; }).filter(Boolean); await notice(p, "図鑑メモ", L.slice(-40).reverse().join("\n") || "§7まだ なし（戦うと 記録される）"); }
    else if (c === 3) { const L = allMons(d).filter((m) => e.dy?.[m.id]).map((m) => `§f${m.nm}: §7${e.dy[m.id]}・なつき ${e.nk?.[m.id] || 0}`); await notice(p, "仲間の 日記", L.join("\n") || "§7まだ なし"); }
    else if (c === 4) await notice(p, "スクラップ", [...(e.sc || []).map((x) => `§7${x}`), "", ...Object.keys(e.lt || {}).map((k) => `§6手紙: §f「${__ex2.LETTERS[k]}」`)].join("\n") || "§7まだ なし");
    else if (c === 5) await notice(p, "名産図鑑", MATS.map((id, k) => `§f${WREGIONS[k]?.short}: §e${ITEMS[id]?.name} §7（持って いる ${countItem(p, `mrpg:${id}`)}）`).join("\n"));
    else if (c === 6) { const i = regAtLoc(p.location); const L = spotsOf(i).map((q) => { let w; try { w = world.getDynamicProperty(`mrpg:exw:${i}.${q.k}`); } catch {} return w ? `§f${KINDS[q.k]?.n}: §e${w}` : null; }).filter(Boolean); await notice(p, "秘境の 旗", `§7${WREGIONS[i].name}\n${L.join("\n") || "§7まだ だれも 見つけて いない"}`); }
    else return;
  }
}
// 7) 地図の 絵（歩いた マス）
function mapArt(e, i) {
  const R = WREGIONS[i], N = Math.ceil((2 * R.r) / 32), a = e.v[i] || [], rows = [];
  for (let z = 0; z < N; z++) { let s = ""; for (let x = 0; x < N; x++) { const c = z * N + x; s += !cellOk(i, c) ? "§0■" : bitGet(a, c) ? "§a■" : "§8■"; } rows.push(s); }
  return `§f踏破 ${explored(e, i)}%\n${rows.join("\n")}`;
}
async function partner(p, d) {
  for (;;) {
    const e = exOf(p), m = allMons(d).find((x) => x.id === d.out);
    const c = await choose(p, "相棒", m ? `§f連れ歩き: §b${m.nm}\n§7なつき度 ${e.nk?.[m.id] || 0}（段階 ${nkLv(e.nk?.[m.id] || 0)}: 戦いで ${[0, 10, 20, 30][nkLv(e.nk?.[m.id] || 0)]}% 踏みとどまる）` : "§7連れ歩きの 仲間が いない", [B("§l記念撮影\n§8写真を 手帳に のこす", ICON("i_zukan")), B("§lアルバム", ICON("i_zukan")), B("§lライドの 乗りかえ", ICON("i_run")), B("§lなつき度の 一覧", ICON("i_party")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) { if (!m) { await notice(p, "記念撮影", "§7連れ歩きの 仲間と いっしょに 撮ろう"); continue; } e.ph = Array.isArray(e.ph) ? e.ph : []; e.ph.unshift(`${dstr(dayNo())} ${WREGIONS[regAtLoc(p.location)]?.short}で ${m.nm}と`); if (e.ph.length > 20) e.ph.length = 20; exSave(p, true); for (let k = 0; k < 10; k++) fx(p.dimension, "minecraft:totem_particle", { x: p.location.x, y: p.location.y + 1, z: p.location.z }); sound(p, "random.click"); await notice(p, "記念撮影", "§fパシャ！ アルバムに のこした"); }
    else if (c === 1) await notice(p, "アルバム", (e.ph || []).map((x) => `§f・${x}`).join("\n") || "§7まだ 写真が ない");
    else if (c === 2) { const L = allMons(d).filter((x) => x.hp > 0 && x.id !== d.out); const k = await paged(p, "ライドの 乗りかえ", "§7だれに 乗る？（連れ歩きが かわる）", L.map((x) => B(`${x.nm} §7Lv${x.lv}\n§8熟練度 ${rideLv(e.rd?.[x.id] || 0)}`, MON_ICON(x.sp))), 8); if (k < 0 || !L[k]) continue; const d2 = load(p); recallPet(p, d2); d2.out = L[k].id; save(p, d2); try { spawnPet(p, L[k]); } catch {} return; }
    else if (c === 3) await notice(p, "なつき度", allMons(d).filter((x) => e.nk?.[x.id]).map((x) => `§f${x.nm} §e${e.nk[x.id]} §7段階 ${nkLv(e.nk[x.id])}`).join("\n") || "§7まだ なし（連れ歩くと 上がる）");
    else return;
  }
}
// 43) 料理・136) 地方の 珍味・44) 畑
const COOK = [["fd_stew", [["x_arca", 3], ["x_bread", 1]]], ["fd_soup", [["x_crys", 3]]], ["fd_curry", [["x_volka", 3], ["x_bread", 1]]], ["fd_cake", [["x_celes", 3], ["x_bread", 1]]], ["fd_tea", [["x_frost", 3]]],
  ["fd_bento", [["x_bread", 2], ["x_acorn", 3]]], ["fd_onigiri", [["x_mari", 2], ["x_acorn", 2]]], ["x_snack", [["x_acorn", 4]]], ["fd_egg", [["x_sand", 2], ["x_silva", 2]]]];
async function kitchen(p, d) {
  for (;;) {
    const e = exOf(p);
    const c = await choose(p, "料理と 畑", `§7料理は 地方の 素材と 町の パンで 作る（次の 野生との 戦い 3回 強く なる）`, [...COOK.map(([id, need]) => B(`${ITEMS[id]?.name}\n§8${need.map(([m, n]) => `${ITEMS[m]?.name}×${n}`).join(" ")}`, ICON("i_shop"))), B("§a§l畑\n§8たねを まいて 育てる", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
    if (c === COOK.length) { await farm(p, d); continue; }
    const r = COOK[c]; if (!r) return;
    if (!r[1].every(([m, n]) => countItem(p, `mrpg:${m}`) >= n)) { await notice(p, "料理", "§7材料が たりない。"); continue; }
    if (!r[1].every(([m, n]) => takeItem(p, `mrpg:${m}`, n))) continue;
    giveItem(p, `mrpg:${r[0]}`, 1); sound(p, "random.anvil_use", 1.6); await notice(p, "料理", `§a${ITEMS[r[0]]?.name}が できた！`);
  }
}
async function farm(p, d) {
  const e = exOf(p); e.fm = Array.isArray(e.fm) ? e.fm : [];
  const now = nowT(), ripe = e.fm.filter((t) => now - t >= 30 * 60000).length;
  const c = await choose(p, "畑", `§f畑（3つまで）: ${e.fm.map((t) => (now - t >= 30 * 60000 ? "§a実った" : `§7あと ${Math.ceil((30 * 60000 - (now - t)) / 60000)}分`)).join("・") || "§7なにも ない"}\n§7花の たね 1こ（町の 花屋）で 30分後に 能力の 実が とれる`, [B(`§lたねを まく §8（持って いる ${countItem(p, "mrpg:x_flower")}）`, ICON("i_skill")), B(`§l収穫する §8（${ripe}）`, ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
  if (c === 0) { if (e.fm.length >= 3) { await notice(p, "畑", "§7畑は いっぱい"); return; } if (!takeItem(p, "mrpg:x_flower")) { await notice(p, "畑", "§7花の たねが ない（町の 花屋で 買える）"); return; } e.fm.push(now); exSave(p, true); await notice(p, "畑", "§aたねを まいた！ 30分後に 実る"); }
  if (c === 1 && ripe) { const left = e.fm.filter((t) => now - t < 30 * 60000); e.fm = left; e.fh2 = (e.fh2 || 0) + ripe; exSave(p, true); const L = []; for (let k = 0; k < ripe; k++) { const id = `s_${pickA(["hp", "mp", "atk", "def", "mat", "mdf", "spd", "wpn", "brt"])}`; if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, 1); L.push(ITEMS[id].name); } } await notice(p, "畑", `§a収穫！ §f${L.join("・")}`); }
}
// 40/41/159/61) 挑戦
async function challenge(p, d) {
  const e = exOf(p), i = regAtLoc(p.location), R = WREGIONS[i];
  const c = await choose(p, "挑戦", `§7いま: ${R.name}`, [B("§lレース\n§8光の 輪を 5つ くぐる", ICON("i_run")), B("§l宝探し競争（マルチ）\n§8近くの 人と 同じ 宝を 探す", ICON("i_shop")), B(`§l${R.short}の 名人に 挑む\n§81日 1回 ほうび`, ICON("i_fight")), B(`§6§l${R.short}の 守り神\n§8踏破した 地方だけ`, ICON("i_fight")), B("§7戻る", ICON("i_back"))]);
  if (p.dimension.id !== OW || (hooks.noSpawn && hooks.noSpawn(p))) { if (c >= 0 && c <= 3) await notice(p, "挑戦", "§7ここでは できない"); return; }
  if (c === 0) { const cp = []; for (let k = 0; k < 5; k++) { const g = groundNear(p, 25 + k * 6, 35 + k * 6); if (g) cp.push(g); } if (cp.length < 5) { await notice(p, "レース", "§7コースが 作れない（ひらけた 場所で）"); return; } RACE.set(p.id, { t: nowT(), k: 0, cp }); naviPush(p, { name: "レース 1/5", x: cp[0].x, z: cp[0].z, dim: OW }); showTitle(p, "§e§lスタート！", { subtitle: "§f光の 輪を じゅんに くぐれ（3分）", fadeInDuration: 2, stayDuration: 30, fadeOutDuration: 6 }); return; }
  if (c === 1) { if (HUNT.t || nowT() - (e.hnt || 0) < 1800000) { await notice(p, "宝探し競争", "§7いまは できない（30分に 1回）"); return; } const ps = world.getAllPlayers().filter((q) => q.dimension.id === OW && hd(q.location, p.location) < 64); if (ps.length < 2) { await notice(p, "宝探し競争", "§7近くに もう1人 いると できる"); return; } const g = groundNear(p, 120, 180); if (!g) return; HUNT.t = { ...g, t: nowT(), ps: ps.map((q) => q.id) }; e.hnt = nowT(); exSave(p, true); for (const q of ps) { naviPush(q, { name: "宝探し競争", x: g.x, z: g.z, dim: OW }); try { showTitle(q, "§6§l宝探し競争！", { subtitle: `§f${dirTo(q.location, g)}・約${Math.round(hd(q.location, g))}m　先に 着いた 人の 勝ち`, fadeInDuration: 4, stayDuration: 50, fadeOutDuration: 8 }); } catch {} } return; }
  if (c === 2 || c === 3) {
    if (c === 3 && !e.cl[i]) { await notice(p, "守り神", "§7この 地方を 踏破すると 守り神が あらわれる"); return; }
    const k = `${c === 2 ? "地方の 名人" : "守り神"}:${i}:${dayNo()}`; if (e.bw?.[k]) { await notice(p, "挑戦", "§7今日は もう 勝った。また 明日"); return; }
    const lv = Math.min(100, R.lv[1] + (c === 3 ? 20 : 8)); const fams = Object.keys(R.fams || { beast: 1 });
    const T = sagaTeam(fams, lv, 1, c === 3 ? 60 : 30); const sid = c === 3 ? (Object.keys(SPECIES).filter((s) => SPECIES[s].rank === "SS" && fams.includes(SPECIES[s].fam) && !SPECIES[s].hidden && !SPECIES[s].fuseonly)[hash(`g${i}`) % 5] || T[0]?.sid) : T[0]?.sid;
    if (!sid) return;
    e.sm = e.sm && typeof e.sm === "object" ? e.sm : {}; if (Date.now() - (e.sm[k] || 0) < 360000) { await notice(p, "挑戦", "§7もう 近くに 来て いる（6分で 帰る）"); return; }   /* 第103版: ほうびの 前に 何体も 呼べない */
    for (const kk of Object.keys(e.sm)) if (Date.now() - e.sm[kk] > 360000) delete e.sm[kk];
    const x = spawnBoss(p, sid, lv, c === 3 ? "mrpg_guardian" : "mrpg_meijin", c === 3 ? `【${R.short}の 守り神】` : `【${R.short}の 名人の 相棒】`, null, i);
    if (x) { e.sm[k] = Date.now(); exSave(p, true); }
    await notice(p, "挑戦", x ? "§6近くに あらわれた！ なぐると 戦い（6分で 帰る）" : "§7場所が ない（ひらけた 場所で）");
  }
}
// 便利: 64 レーダー・170 常時表示・65 キャンプ・140 ワープ石・160 応援旗・70 天気予報・12 月・56 交換所
const MOON = ["満月", "欠けていく月", "下弦の月", "細い月", "新月", "細い月", "上弦の月", "満ちていく月"];
async function tools(p, d) {
  for (;;) {
    const e = exOf(p), i = regAtLoc(p.location);
    const c = await choose(p, "便利な 道具", "", [B("§lレーダー\n§8近くの 物の 方向", ICON("i_run")), B(`§lレーダーの 常時表示 §8${e.rdo ? "オン" : "オフ"}`, ICON("i_skill")), B("§lキャンプ\n§8ここを リスポーン地点に して 回復", ICON("i_inn")),
      B("§lワープ石\n§8踏破した 地方へ", ICON("i_run")), B("§l応援旗\n§8仲間が ワープして こられる", ICON("i_run")), B("§l天気予報と 月\n§8異常気象・月の 満ち欠け", ICON("i_help")), B("§l交換所\n§8ほかの 人と 素材を 交換", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) await notice(p, "レーダー", radar(p, e, i).join("\n") || "§7近くには 何も ない");
    else if (c === 1) { e.rdo = e.rdo ? 0 : 1; exSave(p, true); }
    else if (c === 2) { if (p.dimension.id !== OW || (hooks.noSpawn && hooks.noSpawn(p)) || hooks.inTown(p.location, OW)) { await notice(p, "キャンプ", "§7ここでは できない（町の 外の 地上で）"); continue; } if (nowT() - (e.cp || 0) < 600000) { await notice(p, "キャンプ", `§7つかれて いない（あと ${Math.ceil((600000 - (nowT() - e.cp)) / 60000)}分）`); continue; }
      const l = p.location, x = Math.floor(l.x) + 1, y = Math.floor(l.y), z = Math.floor(l.z); let b; try { b = p.dimension.getBlock({ x, y, z }); } catch {} if (!b || !b.isAir) { await notice(p, "キャンプ", "§7たき火を おく 場所が ない"); continue; }
      run(p.dimension, `setblock ${x} ${y} ${z} campfire`); try { p.setSpawnPoint({ x: Math.floor(l.x), y, z: Math.floor(l.z), dimension: p.dimension }); } catch {} e.cp = nowT(); exSave(p, true); const d2 = load(p); for (const m of d2.party) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } save(p, d2); await notice(p, "キャンプ", "§aキャンプを はった！ 仲間が 元気に なり、ここが リスポーン地点に なった"); }
    else if (c === 3) { const L = Object.keys(e.cl).map(Number).filter((k) => spotInfo(k, "stele")?.ok); if (!L.length) { await notice(p, "ワープ石", "§7踏破した 地方が ない（踏破の ごほうびを 受けとると 使える）"); continue; } const k = await paged(p, "ワープ石", "", L.map((j) => B(WREGIONS[j].name, ICON("i_run"))), 8); if (k < 0) continue; const I = spotInfo(L[k], "stele"); try { p.teleport({ x: I.x + 2.5, y: I.y + 0.2, z: I.z + 0.5 }, { dimension: world.getDimension("overworld") }); const pet = findPet(p); if (pet) pet.teleport(p.location, { dimension: p.dimension }); } catch {} sound(p, "mob.endermen.portal"); return; }
    else if (c === 4) await flags(p);
    else if (c === 5) { let m = -1; try { m = world.getMoonPhase(); } catch {} const top = Math.min(openUpTo(d), WREGIONS.length - 1); const L = WREGIONS.slice(0, top + 1).map((R, k) => { const a = wxOf(k), n = WXN.get(k); return a ? `§e${R.short}: ${a.name}（あと ${Math.ceil((a.end - nowT()) / 60000)}分）` : n && wxName(k) ? `§f${R.short}: §7${Math.max(1, Math.ceil((n - nowT()) / 60000))}分後に ${wxName(k)}` : null; }).filter(Boolean);
      await notice(p, "天気予報と 月", [`§f今夜の 月: §e${MOON[m] || "?"}§f（満月まで あと ${m < 0 ? "?" : (8 - m) % 8}日）`, `§f季節: §e${__ex2.SEASON()[0]}§7（${__ex2.SEASON()[1] === "aqua" ? "水" : ""}${__ex2.SEASON()[1]}系が 出やすい）`, `§f流星群: §e${dayNo() % 7 === 3 ? "今夜！" : `${(3 - (dayNo() % 7) + 7) % 7}日後`}`, "", ...(L.length ? L : ["§7いまは 異常気象の 予定は ない"])].join("\n")); }
    else if (c === 6) await market(p);
    else return;
  }
}
// 160) 応援旗
async function flags(p) {
  const k = await choose(p, "応援旗", "§7旗を 立てると、ほかの 人が 手帳から ここへ ワープできる（30分）", [B("§lここに 旗を 立てる", ICON("i_run")), B("§l仲間の 旗へ ワープ", ICON("i_run")), B("§7戻る", ICON("i_back"))]);
  if (k === 0) { if (p.dimension.id !== OW || (hooks.noSpawn && hooks.noSpawn(p))) return; const l = p.location; try { world.setDynamicProperty(`mrpg:flag:${p.id}`, JSON.stringify({ x: l.x, y: l.y, z: l.z, n: p.name, t: nowT() })); } catch {} for (const q of world.getAllPlayers()) if (q.id !== p.id) say(q, `§a${p.name}が 応援旗を 立てた！ §7（探索手帳 → 便利な 道具 → 応援旗）`); }
  if (k === 1) { const L = []; for (const q of world.getAllPlayers()) { if (q.id === p.id) continue; let v; try { v = JSON.parse(world.getDynamicProperty(`mrpg:flag:${q.id}`) || "null"); } catch {} if (v && nowT() - v.t < 1800000) L.push(v); } const top = openUpTo(load(p) || {}); const L2 = L.filter((v) => regAtLoc(v) <= top); if (!L2.length) { await notice(p, "応援旗", "§7行ける 旗が ない"); return; } L.length = 0; L.push(...L2); const c = await paged(p, "応援旗", "", L.map((v) => B(`${v.n}の 旗`, ICON("i_run"))), 8); if (c < 0) return; const v = L[c]; try { p.teleport({ x: v.x, y: v.y + 0.2, z: v.z }, { dimension: world.getDimension("overworld") }); const pet = findPet(p); if (pet) pet.teleport(p.location, { dimension: p.dimension }); } catch {} }
}
// 56) 交換所（素材 5こ ⇔ 素材 5こ・あずけた 素材は 交換が 成立 したら 相手へ）・107) 郵便（町）でも 使う
export function mailTo(name, item, n) { let L = []; try { L = JSON.parse(world.getDynamicProperty(`mrpg:mail:${name}`) || "[]"); } catch {} L.push([item, n]); try { world.setDynamicProperty(`mrpg:mail:${name}`, JSON.stringify(L.slice(-30))); } catch {} }
function mailGet(p) { let L = []; try { L = JSON.parse(world.getDynamicProperty(`mrpg:mail:${p.name}`) || "[]"); } catch {} if (!L.length) return; try { world.setDynamicProperty(`mrpg:mail:${p.name}`, undefined); } catch {} for (const [id, n] of L) if (ITEMS[id]) giveItem(p, `mrpg:${id}`, n); say(p, `§a郵便が とどいた！ §f${L.map(([id, n]) => `${ITEMS[id]?.name}×${n}`).join("・")}`); }
XT.tick.push((p, d, e, i, L, tk) => { if (tk % 15 === 7) mailGet(p); });
async function market(p) {
  let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:market") || "[]"); } catch {}
  L = L.filter((o) => nowT() - o.t < 3 * 86400000);
  const k = await paged(p, "交換所", "§7素材 5こ と 素材 5こ を 交換する（3日で 消える）", [B("§a§l交換を 出す", ICON("i_shop")), ...L.map((o) => B(`${o.n}: ${ITEMS[o.g]?.name}×5 ⇔ ${ITEMS[o.w]?.name}×5`, ICON("i_shop")))], 8);
  if (k === 0) {
    const have = MATS.filter((id) => countItem(p, `mrpg:${id}`) >= 5); if (!have.length) { await notice(p, "交換所", "§75こ ある 素材が ない"); return; }
    const a = await paged(p, "わたす 素材", "", have.map((id) => B(ITEMS[id].name, ICON("i_shop"))), 8); if (a < 0) return;
    const b = await paged(p, "ほしい 素材", "", MATS.filter((id) => id !== have[a]).map((id) => B(ITEMS[id].name, ICON("i_shop"))), 8); if (b < 0) return;
    const want = MATS.filter((id) => id !== have[a])[b]; if (!takeItem(p, `mrpg:${have[a]}`, 5)) return;
    let L4 = []; try { L4 = JSON.parse(world.getDynamicProperty("mrpg:market") || "[]"); } catch {} L4.push({ n: p.name, g: have[a], w: want, t: nowT() }); try { world.setDynamicProperty("mrpg:market", JSON.stringify(L4.slice(-20))); } catch {}   /* 書く 直前に 読みなおす */ await notice(p, "交換所", "§a出した！"); return;
  }
  const o = L[k - 1]; if (!o) return;
  if (o.n === p.name) { if (await confirm(p, "交換所", "§f自分の 交換を とりけす？（素材は もどる）", "とりけす", "やめる")) { let L3 = []; try { L3 = JSON.parse(world.getDynamicProperty("mrpg:market") || "[]"); } catch {} const j = L3.findIndex((x) => x.n === o.n && x.t === o.t); if (j < 0) { await notice(p, "交換所", "§7もう 交換が 成立して いた"); return; } L3.splice(j, 1); try { world.setDynamicProperty("mrpg:market", JSON.stringify(L3)); } catch {} giveItem(p, `mrpg:${o.g}`, 5); } return; }   /* 第102版: 書く 直前に 読みなおす */
  if (countItem(p, `mrpg:${o.w}`) < 5) { await notice(p, "交換所", `§7${ITEMS[o.w]?.name}が 5こ ない`); return; }
  let L2 = []; try { L2 = JSON.parse(world.getDynamicProperty("mrpg:market") || "[]"); } catch {} const j = L2.findIndex((x) => x.n === o.n && x.t === o.t); if (j < 0) { await notice(p, "交換所", "§7もう ない"); return; }
  if (!takeItem(p, `mrpg:${o.w}`, 5)) return; L2.splice(j, 1); try { world.setDynamicProperty("mrpg:market", JSON.stringify(L2)); } catch {}
  giveItem(p, `mrpg:${o.g}`, 5); mailTo(o.n, o.w, 5); await notice(p, "交換所", "§a交換した！");
}
async function achievements(p, d) {
  const e = exOf(p); e.ach = e.ach || {};
  const got = ACH.map(([n, f]) => { let ok2 = false; try { ok2 = f(e); } catch {} return [n, ok2]; });
  const fresh = got.map(([n, ok2], k) => (ok2 && !e.ach[k] ? k : -1)).filter((k) => k >= 0);
  const c = await choose(p, "探索の 実績", `${got.map(([n, ok2], k) => `${e.ach[k] ? "§a○" : ok2 ? "§e★" : "§7・"} ${n}`).join("\n")}`, [B(fresh.length ? `§e§lごほうびを 受けとる（${fresh.length}）` : "§7受けとれる ものは ない", ICON("i_shop")), B("§7戻る", ICON("i_back"))]);
  if (c !== 0 || !fresh.length) return;
  const d2 = load(p); if (!d2) return; for (const k of fresh) { e.ach[k] = 1; prize(p, d2, Math.min(10, k / 3), 0, 1); addPt(p, e, 5); }
  if (Object.keys(e.ach).length >= 20) award(p, d2, "ex_ach", null); save(p, d2); exSave(p, true); sound(p, "random.levelup");
}
XT.menu.push(["§l旅の 記録\n§8きょり・メダル・図鑑メモ・日記", records, "i_zukan"], ["§l相棒\n§8写真・乗りかえ・なつき度", partner, "i_party"], ["§l料理と 畑", kitchen, "i_shop"], ["§c§l挑戦\n§8レース・名人・守り神", challenge, "i_fight"], ["§l便利な 道具\n§8レーダー・キャンプ・天気予報", tools, "i_run"], ["§e§l探索の 実績", achievements, "i_star"]);
// 38) 宿屋の 夢（町の 宿で 泊まると ヒント）は town.js
export const __life = { RACE, HUNT, XN, radar, ACH, COOK, mapArt, spawnXnpc, mailGet, market, FOOD };
