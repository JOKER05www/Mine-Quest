// v2.2.3: 石板の 中の 世界（だだっ広い テーマ別エリア）。コマンドの 列を 作るだけ（マイクラに 依存しない）
import { rollTier, lvBonus, chestCmds, BASE_OF } from "./chests.js";
import { bk } from "./stage.js";
import { BOSS_SLAB } from "./data.js";

// fl=床 fl2=まだら base=床下 wall=外周 ceil=天井(閉じた 場所) light=床の 明かり feats=[[種類, 100ブロック²あたり の 数]]
export const DG_THEMES = {
  forest: { name: "深き森", fl: "grass_block", fl2: ["moss_block", "podzol", "coarse_dirt"], base: "dirt", wall: "oak_log", light: "ochre_froglight",
    feats: [["tree_oak", 0.55], ["tree_dark", 0.2], ["grass", 1.6], ["flower", 0.7], ["pond", 0.05], ["rock", 0.12], ["hill", 0.05]], fams: ["animal", "animal", "beast", "animal"] },
  cherry: { name: "桜の園", fl: "grass_block", fl2: ["moss_block", "pink_wool"], base: "dirt", wall: "cherry_log", light: "pearlescent_froglight",
    feats: [["tree_cherry", 0.45], ["grass", 1.2], ["flower", 1.0], ["pond", 0.06], ["lantern", 0.1]], fams: ["animal", "animal", "beast", "blob"] },
  snow: { name: "白銀の 雪原", fl: "snow", fl2: ["packed_ice", "powder_snow_safe", "blue_ice"], base: "packed_ice", wall: "packed_ice", light: "sea_lantern",
    feats: [["tree_spruce", 0.3], ["spike", 0.12], ["hill", 0.08], ["rock_ice", 0.15]], fams: ["aqua", "beast", "dragon", "golem"] },
  sea: { name: "浅き 海", fl: "sand", fl2: ["gravel", "prismarine", "clay"], base: "stone", wall: "prismarine_bricks", light: "sea_lantern", water: true,
    feats: [["island", 0.07], ["reef", 0.25], ["pillar_sea", 0.06]], fams: ["aqua", "aqua", "blob", "animal"] },
  desert: { name: "灼熱の 砂漠", fl: "sand", fl2: ["sandstone", "red_sand", "smooth_sandstone"], base: "sandstone", wall: "smooth_sandstone", light: "glowstone",
    feats: [["dune", 0.12], ["cactus", 0.35], ["deadbush", 0.5], ["ruin_pillar", 0.08], ["bones", 0.05]], fams: ["golem", "nether", "animal", "dragon"] },
  volcano: { name: "火の 山", fl: "blackstone", fl2: ["basalt", "smooth_basalt", "magma"], base: "blackstone", wall: "basalt", light: "shroomlight",
    feats: [["lavapool", 0.06], ["hill_basalt", 0.08], ["pillar_basalt", 0.14], ["rock_obs", 0.1]], fams: ["dragon", "nether", "golem"] },
  cave: { name: "地底の 洞窟", fl: "stone", fl2: ["deepslate", "tuff", "gravel", "andesite"], base: "stone", wall: "deepslate", ceil: "stone", light: "glowstone",
    feats: [["stalag", 0.3], ["pond", 0.04], ["rock", 0.2], ["ore", 0.15]], fams: ["golem", "nether", "animal", "nether"] },
  crystal: { name: "水晶の 洞", fl: "calcite", fl2: ["amethyst_block", "tuff", "smooth_basalt"], base: "calcite", wall: "amethyst_block", ceil: "calcite", light: "sea_lantern",
    feats: [["crystal", 0.25], ["stalag_am", 0.15], ["pond", 0.04]], fams: ["golem", "blob", "nether", "dragon"] },
  ruins: { name: "古の 都", fl: "stone_bricks", fl2: ["mossy_stone_bricks", "cracked_stone_bricks", "cobblestone", "mossy_cobblestone"], base: "stone", wall: "stone_bricks", light: "lantern_post",
    feats: [["ruin_room", 0.06], ["ruin_pillar", 0.12], ["grass", 0.5], ["rock", 0.08]], fams: ["nether", "sword", "golem", "beast"] },
  sky: { name: "空の 浮島", fl: "grass_block", fl2: ["moss_block", "quartz_block"], base: "dirt", wall: "barrier", light: "glowstone", sky: true,
    feats: [["tree_oak", 0.25], ["flower", 0.8], ["grass", 1.0]], fams: ["animal", "dragon", "blob", "animal"] },
  swamp: { name: "霧の 沼地", fl: "mud", fl2: ["moss_block", "grass_block", "packed_mud"], base: "dirt", wall: "mangrove_log", light: "verdant_froglight",
    feats: [["pond", 0.18], ["tree_mangrove", 0.3], ["grass", 1.0], ["stump", 0.1]], fams: ["animal", "aqua", "nether", "blob"] },
  mushroom: { name: "きのこの 森", fl: "mycelium", fl2: ["podzol", "moss_block"], base: "dirt", wall: "mushroom_stem", light: "shroomlight",
    feats: [["mushroom_big", 0.28], ["mushroom_small", 0.6], ["hill", 0.04]], fams: ["animal", "blob", "animal"] },
  underworld: { name: "冥府の 谷", fl: "soul_soil", fl2: ["soul_sand", "bone_block", "blackstone"], base: "blackstone", wall: "polished_blackstone_bricks", ceil: "blackstone", light: "shroomlight",
    feats: [["bones", 0.15], ["pillar_bone", 0.12], ["lavapool", 0.03], ["soul_lantern", 0.12]], fams: ["nether", "nether", "dragon"] },
  void: { name: "虚空の 島々", fl: "end_stone", fl2: ["end_stone_bricks", "purpur_block", "obsidian"], base: "end_stone", wall: "barrier", light: "end_rod_post", sky: true,
    feats: [["pillar_purpur", 0.12], ["rock_obs", 0.1], ["crystal", 0.05]], fams: ["nether", "dragon", "nether", "golem"] },
  palace: { name: "王冠の 宮殿", fl: "polished_blackstone_bricks", fl2: ["gold_block", "gilded_blackstone", "chiseled_polished_blackstone"], base: "blackstone", wall: "polished_blackstone_bricks", ceil: "polished_blackstone_bricks", light: "glowstone",
    feats: [["palace_pillar", 0.12], ["carpet", 0.1], ["ruin_room", 0.03]], fams: ["dragon", "sword", "nether", "golem"] },
};
// 石板ごとの テーマ（主・副）
export const SLAB_THEMES = [["forest", "swamp"], ["sea", "cave"], ["forest", "mushroom"], ["forest", "sky"], ["volcano", "ruins"], ["sky", "cherry"], ["ruins", "cave"], ["cave", "sea"], ["void", "cherry"], ["volcano", "cave"],
  ["desert", "underworld"], ["crystal", "snow"], ["sky", "sea"], ["volcano", "underworld"], ["sea", "void"], ["swamp", "mushroom"], ["forest", "cherry"], ["underworld", "ruins"], ["crystal", "mushroom"], ["void", "crystal"],
  ["ruins", "desert"], ["sky", "cave"], ["void", "underworld"], ["snow", "crystal"], ["desert", "ruins"], ["underworld", "cave"], ["ruins", "sky"], ["mushroom", "void"], ["volcano", "void"], ["palace", "palace"]];
const ALL = Object.keys(DG_THEMES).filter((k) => k !== "palace");
export const ALL_THEMES = ALL;
export function themeFor(i, f, r) {
  const o = BOSS_SLAB[i] ? BOSS_SLAB[i].old : i;
  const [a, b] = SLAB_THEMES[o] || ["forest", "cave"];
  if (o === SLAB_THEMES.length - 1) return f === 0 ? "palace" : ALL[Math.floor(r() * ALL.length)];   // 王冠: いろいろな 世界を 越えて いく
  const x = r();
  return x < 0.45 ? a : x < 0.8 ? b : ALL[Math.floor(r() * ALL.length)];
}
// 進むほど 広く
export const areaSize = (i) => Math.round(40 + (56 * i) / Math.max(1, BOSS_SLAB.length - 1));

const B = (id) => (id === "powder_snow_safe" ? bk("snow") : bk(id));
const ri = (r, a, b) => a + Math.floor(r() * (b - a + 1));
const pk = (r, a) => a[Math.floor(r() * a.length)];

export function genFloor(st, r) {
  const T = DG_THEMES[st.theme] || DG_THEMES.forest;
  const { x0, y0, z0 } = st, S = st.S;
  const C = [];
  const F = (a, b, c, d, e, f, blk, mode) => C.push(`fill ${a} ${b} ${c} ${d} ${e} ${f} ${blk}${mode ? " " + mode : ""}`);
  const SB = (x, y, z, blk) => C.push(`setblock ${x} ${y} ${z} ${blk}`);
  const X1 = x0 + S - 1, Z1 = z0 + S - 1;
  // 1) まっさらに（戦いの 間・雲の 下まで）
  /* 第89版: 前の 階が 大きかった ときの 階段や 壁が 外に 残らない ように、いつも 80マスぶん 空ける */
  const SM = Math.max(S, 80), cx0 = x0 - 36, cx1 = x0 + SM + 2, cy0 = y0 - 10, cy1 = y0 + 22, rows = Math.max(1, Math.floor(32000 / ((cx1 - cx0 + 1) * (cy1 - cy0 + 1)))), ZC = z0 + SM - 1;
  for (let z = z0 - 3; z <= ZC + 3; z += rows) F(cx0, cy0, z, cx1, cy1, Math.min(ZC + 3, z + rows - 1), "air");
  const sky = !!T.sky;
  // 2) 地面
  if (!sky) { F(x0, y0 - 1, z0, X1, y0 - 1, Z1, B(T.base)); F(x0, y0, z0, X1, y0, Z1, B(T.fl)); }
  else { const rows2 = Math.max(1, Math.floor(32000 / S)); for (let z = z0 - 2; z <= Z1 + 2; z += rows2) F(x0 - 2, y0 - 8, z, X1 + 2, y0 - 8, Math.min(Z1 + 2, z + rows2 - 1), B(st.theme === "void" ? "obsidian" : "white_wool")); }
  // 3) 外周の 壁・見えない 壁・天井
  const wallH = T.ceil ? 9 : sky ? 0 : 4;
  for (const [a, c, d, f] of [[x0 - 1, z0 - 1, X1 + 1, z0 - 1], [x0 - 1, Z1 + 1, X1 + 1, Z1 + 1], [x0 - 1, z0, x0 - 1, Z1], [X1 + 1, z0, X1 + 1, Z1]]) {
    if (wallH) F(a, y0 - 1, c, d, y0 + wallH, f, B(T.wall === "barrier" ? T.fl : T.wall));
    F(a, y0 + wallH + 1, c, d, y0 + 18, f, "barrier");
    if (sky) F(a, y0 - 7, c, d, y0, f, "barrier");
  }
  if (T.ceil) { const rows3 = Math.max(1, Math.floor(32000 / S)); for (let z = z0; z <= Z1; z += rows3) F(x0, y0 + 10, z, X1, y0 + 10, Math.min(Z1, z + rows3 - 1), B(T.ceil)); }
  // 4) 特別な 場所（入口・階段・宝箱・泉・猛者の 印）を 先に 決める
  const start = { x: x0 + 4, z: z0 + 4 };
  const far = () => { for (let k = 0; k < 40; k++) { const x = ri(r, x0 + Math.floor(S * 0.45), X1 - 5), z = ri(r, z0 + Math.floor(S * 0.45), Z1 - 5); if (Math.hypot(x - start.x, z - start.z) > S * 0.7) return { x, z }; } return { x: X1 - 5, z: Z1 - 5 }; };
  const stairs = st.boss ? null : far();
  const spots = [];
  const randSpot = (minD = 8) => { for (let k = 0; k < 40; k++) { const x = ri(r, x0 + 5, X1 - 5), z = ri(r, z0 + 5, Z1 - 5); if ([start, stairs, ...spots].every((q) => !q || Math.hypot(q.x - x, q.z - z) > minD)) return { x, z }; } return { x: ri(r, x0 + 5, X1 - 5), z: ri(r, z0 + 5, Z1 - 5) }; };
  const chests = []; const nch = 2 + Math.floor(S / 40) + (r() < 0.4 ? 1 : 0);
  for (let k = 0; k < nch; k++) { const q = randSpot(); spots.push(q); chests.push(q); }
  const spring = !st.boss && r() < 0.55 ? (() => { const q = randSpot(12); spots.push(q); return q; })() : null;
  const elite = !st.boss && st.f >= 1 && st.kind !== "meet" && r() < 0.45 ? (() => { const q = randSpot(12); spots.push(q); return q; })() : null;
  // 浮島: 入口→階段の 道に そって 島を つなぐ
  if (sky) {
    const isl = [start];
    const goal = stairs || { x: x0 + Math.floor(S / 2), z: z0 + Math.floor(S / 2) };
    const n = 3 + Math.floor(S / 16);
    for (let k = 1; k < n; k++) { const t = k / n; isl.push({ x: Math.round(start.x + (goal.x - start.x) * t + ri(r, -S / 6, S / 6)), z: Math.round(start.z + (goal.z - start.z) * t + ri(r, -S / 6, S / 6)) }); }
    isl.push(goal); for (const q of spots) isl.push(q);
    for (let k = 0; k < Math.floor(S / 20); k++) isl.push({ x: ri(r, x0 + 6, X1 - 6), z: ri(r, z0 + 6, Z1 - 6) });
    const clampX = (v) => Math.max(x0 + 1, Math.min(X1 - 1, v)), clampZ = (v) => Math.max(z0 + 1, Math.min(Z1 - 1, v));
    isl.forEach((q, k) => {
      q.x = clampX(q.x); q.z = clampZ(q.z);
      const rad = k === 0 || q === goal ? 6 : ri(r, 4, 8);
      for (let dz = -rad; dz <= rad; dz++) { const w = Math.floor(Math.sqrt(rad * rad - dz * dz)); F(clampX(q.x - w), y0, clampZ(q.z + dz), clampX(q.x + w), y0, clampZ(q.z + dz), B(T.fl)); if (Math.abs(dz) < rad - 1) F(clampX(q.x - w + 1), y0 - 1, clampZ(q.z + dz), clampX(q.x + w - 1), y0 - 1, clampZ(q.z + dz), B(T.base)); }
      F(clampX(q.x - 2), y0 - 3, clampZ(q.z - 2), clampX(q.x + 2), y0 - 2, clampZ(q.z + 2), B(T.base));
    });
    // 橋（つぎの 島へ・のこりは 近い 島へ）
    const bridge = (a, b) => { const bb = st.theme === "void" ? B("purpur_block") : B("oak_planks"); const steps = Math.max(Math.abs(b.x - a.x), Math.abs(b.z - a.z)); for (let s = 0; s <= steps; s += 3) { const x = Math.round(a.x + (b.x - a.x) * s / steps), z = Math.round(a.z + (b.z - a.z) * s / steps); F(clampX(x - 1), y0, clampZ(z - 1), clampX(x + 1), y0, clampZ(z + 1), bb); } };
    for (let k = 0; k + 1 < n + 1; k++) bridge(isl[k], isl[k + 1]);
    for (let k = n + 1; k < isl.length; k++) { let best = isl[0], bd = 1e9; for (let j = 0; j <= n; j++) { const dd = Math.hypot(isl[j].x - isl[k].x, isl[j].z - isl[k].z); if (dd < bd) { bd = dd; best = isl[j]; } } bridge(isl[k], best); }
  }
  // 5) まだら模様
  const area = S * S;
  if (!sky) for (let k = 0; k < Math.floor(area / 90); k++) { const x = ri(r, x0, X1), z = ri(r, z0, Z1), w = ri(r, 1, 4), h = ri(r, 1, 4); F(Math.max(x0, x - w), y0, Math.max(z0, z - h), Math.min(X1, x + w), y0, Math.min(Z1, z + h), B(pk(r, T.fl2))); }
  // 海: ひざ下の 水を はる
  if (T.water) { const rows4 = Math.max(1, Math.floor(32000 / S)); for (let z = z0; z <= Z1; z += rows4) F(x0, y0 + 1, z, X1, y0 + 1, Math.min(Z1, z + rows4 - 1), "water"); }
  // 6) 飾り
  const top = T.ceil ? y0 + 9 : y0 + 16;
  for (const [kind, dens] of T.feats) {
    const n = Math.round((area / 100) * dens * (sky ? 0.45 : 1));
    for (let k = 0; k < n; k++) {
      const x = ri(r, x0 + 2, X1 - 2), z = ri(r, z0 + 2, Z1 - 2);
      feature(kind, x, z, y0, r, F, SB, T, top, { x0, z0, X1, Z1 });
    }
  }
  // 7) 明かり（床に うめる・柱の 上）
  const step = T.ceil ? 7 : 9;
  for (let x = x0 + 3; x <= X1 - 2; x += step) for (let z = z0 + 3 + ((x / step) % 2 ? 4 : 0); z <= Z1 - 2; z += step) {
    if (T.light === "lantern_post") { F(x, y0 + 1, z, x, y0 + 2, z, B("oak_fence")); SB(x, y0 + 3, z, B("lantern")); }
    else if (T.light === "end_rod_post") { if (!sky) SB(x, y0 + 1, z, B("end_rod")); }
    else if (!sky) SB(x, y0, z, B(T.light));
    if (T.ceil && (x + z) % 2 === 0) SB(x, y0 + 10, z, B(T.light === "lantern_post" || /^(soul_)?lantern$/.test(T.light) ? "glowstone" : T.light));   /* v3.0: 天井に ランタンを 置かない（落ちて アイテムに なる） */
  }
  // 8) 特別な 場所を ととのえる（上を あけて 床を しく）
  const pad = (q, rad, blk) => { F(q.x - rad, y0 + 1, q.z - rad, q.x + rad, top, q.z + rad, "air"); F(q.x - rad, y0, q.z - rad, q.x + rad, y0, q.z + rad, blk || B(T.fl)); F(q.x - rad, y0 - 1, q.z - rad, q.x + rad, y0 - 1, q.z + rad, B(T.base)); };
  pad(start, 2, B(T.fl2[0] || T.fl));
  if (stairs) {
    pad(stairs, 2);
    F(stairs.x - 1, y0, stairs.z - 1, stairs.x + 1, y0, stairs.z + 1, B("crying_obsidian")); SB(stairs.x, y0, stairs.z, B("amethyst_block"));   /* 第92版: ビーコンの 光が となりの 階から 見えて「外に ポータルが ある」ように 見えた */
    for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) F(stairs.x + a, y0 + 1, stairs.z + b, stairs.x + a, y0 + 3, stairs.z + b, B("end_rod"));
  }
  // v2.6.1: 石板の 中の 宝箱（物語 3〜5・最後の 階 +1・再戦 7・覇王 7・神域 8・再会 4。再戦・覇王・神域は 神箱も）
  const tb = st.kind === "god" ? 8 : st.kind === "king" ? 7 : st.kind === "meet" ? 4 : st.re ? 7 : 3 + Math.floor((st.i || 0) / 5), tg = st.kind === "god" || st.kind === "king" || !!st.re;
  for (const q of chests) { pad(q, 1); const [c1, c2] = chestCmds(q.x, y0 + 1, q.z, rollTier(tb, st.f >= (st.F || 1) - 1 ? 1 : 0, tg)); C.push(c1); }
  if (spring) { pad(spring, 2, B("prismarine_bricks")); F(spring.x - 1, y0, spring.z - 1, spring.x + 1, y0, spring.z + 1, "water"); SB(spring.x, y0 - 1, spring.z, B("sea_lantern")); for (const [a, b] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) SB(spring.x + a, y0 + 1, spring.z + b, B("sea_lantern")); }
  if (elite) { pad(elite, 2, B("gold_block")); F(elite.x - 1, y0, elite.z - 1, elite.x + 1, y0, elite.z + 1, B("red_nether_brick")); SB(elite.x, y0, elite.z, B("crying_obsidian")); for (const [a, b] of [[-2, 0], [2, 0], [0, -2], [0, 2]]) { SB(elite.x + a, y0 + 1, elite.z + b, B("blackstone_wall") === "stone" ? B("blackstone") : B("blackstone_wall")); SB(elite.x + a, y0 + 2, elite.z + b, B("soul_lantern")); } }
  // 9) 戦いの 間（西どなり・閉じた 部屋・テーマの 床）
  const rx = x0 - 34;
  F(rx, y0 - 1, z0, rx + 22, y0 + 12, z0 + 22, B(T.wall === "barrier" ? "smooth_quartz" : T.wall));
  F(rx + 1, y0 + 1, z0 + 1, rx + 21, y0 + 11, z0 + 21, "air");
  F(rx + 1, y0, z0 + 1, rx + 21, y0, z0 + 21, B(T.fl === "mud" || T.fl === "sand" ? T.fl2[0] : T.fl));
  for (let a = 3; a <= 19; a += 8) for (let b = 3; b <= 19; b += 8) SB(rx + a, y0 + 12, z0 + b, B("glowstone"));
  return {
    cmds: C,
    info: { start: { x: start.x + 0.5, y: y0 + 1, z: start.z + 0.5 }, bx: rx + 11, bz: z0 + 11, by: y0 + 1, bd: 4.5, sx: stairs ? stairs.x : null, sz: stairs ? stairs.z : null, chests, spring, elite, theme: st.theme },
  };
}

function feature(kind, x, z, y0, r, F, SB, T, top, R) {
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const X = (v) => cl(v, R.x0, R.X1), Zc = (v) => cl(v, R.z0, R.Z1);
  const tree = (log, leaves, h) => { F(x, y0 + 1, z, x, y0 + h, z, B(log)); F(X(x - 2), y0 + h - 1, Zc(z - 2), X(x + 2), y0 + h, Zc(z + 2), B(leaves), "keep"); F(X(x - 1), y0 + h + 1, Zc(z - 1), X(x + 1), y0 + h + 1, Zc(z + 1), B(leaves), "keep"); SB(x, Math.min(top, y0 + h + 2), z, B(leaves)); };
  switch (kind) {
    case "tree_oak": return tree("oak_log", "oak_leaves", ri(r, 4, 6));
    case "tree_dark": return tree("dark_oak_log", "dark_oak_leaves", ri(r, 5, 7));
    case "tree_cherry": return tree("cherry_log", "cherry_leaves", ri(r, 4, 6));
    case "tree_spruce": { const h = ri(r, 6, 9); F(x, y0 + 1, z, x, y0 + h, z, B("spruce_log")); for (let k = 0; k < 3; k++) { const w = 2 - k, y = y0 + 3 + k * 2; F(X(x - w), y, Zc(z - w), X(x + w), y + 1, Zc(z + w), B("spruce_leaves"), "keep"); } SB(x, y0 + h + 1, z, B("spruce_leaves")); return; }
    case "tree_mangrove": { const h = ri(r, 4, 6); for (const [a, b] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) SB(X(x + a), y0 + 1, Zc(z + b), B("mangrove_roots")); return tree("mangrove_log", "mangrove_leaves", h); }
    case "grass": return SB(x, y0 + 1, z, B(r() < 0.7 ? "short_grass" : "fern"));
    case "flower": return SB(x, y0 + 1, z, B(pk(r, ["poppy", "dandelion", "cornflower", "oxeye_daisy"])));
    case "deadbush": return SB(x, y0 + 1, z, B("deadbush"));
    case "cactus": { const h = ri(r, 1, 3); return F(x, y0 + 1, z, x, y0 + h, z, B("cactus")); }
    case "rock": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + ri(r, 1, 2), Zc(z + ri(r, 0, 1)), B(pk(r, ["cobblestone", "mossy_cobblestone", "andesite"])));
    case "rock_ice": return F(x, y0 + 1, z, X(x + 1), y0 + ri(r, 1, 2), Zc(z + 1), B(pk(r, ["packed_ice", "blue_ice"])));
    case "rock_obs": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + ri(r, 1, 3), Zc(z + ri(r, 0, 1)), B(pk(r, ["obsidian", "crying_obsidian", "blackstone"])));
    case "ore": return F(x, y0 + 1, z, X(x + 1), y0 + 2, Zc(z + 1), B(pk(r, ["iron_ore", "gold_ore", "diamond_ore", "emerald_ore", "lapis_ore", "redstone_ore", "copper_ore"])));
    case "hill": case "dune": case "hill_basalt": {
      const blk = kind === "dune" ? "sand" : kind === "hill_basalt" ? "basalt" : T.fl;
      const rad = ri(r, 3, 6), h = ri(r, 1, 3);
      for (let k = 0; k < h; k++) { const w = rad - k * 2; if (w < 1) break; F(X(x - w), y0 + 1 + k, Zc(z - w), X(x + w), y0 + 1 + k, Zc(z + w), B(blk)); }
      return;
    }
    case "pond": { const w = ri(r, 2, 4), h = ri(r, 2, 4); F(X(x - w - 1), y0, Zc(z - h - 1), X(x + w + 1), y0, Zc(z + h + 1), B(T.fl2[0] || "sand")); return F(X(x - w), y0, Zc(z - h), X(x + w), y0, Zc(z + h), "water"); }
    case "lavapool": { const w = ri(r, 1, 3); F(X(x - w - 1), y0 + 1, Zc(z - w - 1), X(x + w + 1), y0 + 1, Zc(z + w + 1), B("blackstone")); F(X(x - w), y0 + 1, Zc(z - w), X(x + w), y0 + 1, Zc(z + w), "air"); return F(X(x - w), y0, Zc(z - w), X(x + w), y0, Zc(z + w), "lava"); }
    case "island": { const rad = ri(r, 3, 6); for (let k = 0; k < 2; k++) { const w = rad - k * 2; F(X(x - w), y0 + 1 + k, Zc(z - w), X(x + w), y0 + 1 + k, Zc(z + w), B("sand")); } if (r() < 0.7) { F(x, y0 + 3, z, x, y0 + 7, z, B("jungle_log")); F(X(x - 2), y0 + 8, z, X(x + 2), y0 + 8, z, B("jungle_leaves"), "keep"); F(x, y0 + 8, Zc(z - 2), x, y0 + 8, Zc(z + 2), B("jungle_leaves"), "keep"); } return; }
    case "reef": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + 1, Zc(z + ri(r, 0, 1)), B(pk(r, ["prismarine", "dark_prismarine", "sea_lantern", "prismarine_bricks"])));
    case "pillar_sea": { const h = ri(r, 3, 7); return F(x, y0 + 1, z, X(x + 1), y0 + h, Zc(z + 1), B("prismarine_bricks")); }
    case "spike": { const h = ri(r, 5, 11); F(x, y0 + 1, z, X(x + 1), y0 + Math.floor(h / 2), Zc(z + 1), B("packed_ice")); return F(x, y0 + 1, z, x, y0 + h, z, B("packed_ice")); }
    case "stalag": { const h = ri(r, 2, 9); F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + h, Zc(z + ri(r, 0, 1)), B(pk(r, ["stone", "dripstone_block", "tuff"]))); if (h > 6) F(x, y0 + h, z, x, top, z, B("stone")); return; }
    case "stalag_am": { const h = ri(r, 2, 8); return F(x, y0 + 1, z, x, y0 + h, z, B(pk(r, ["amethyst_block", "calcite"]))); }
    case "crystal": { F(x, y0 + 1, z, x, y0 + ri(r, 2, 5), z, B("amethyst_block")); for (const [a, b] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) if (r() < 0.7) SB(X(x + a), y0 + 1, Zc(z + b), B("amethyst_cluster")); return; }
    case "ruin_pillar": { const h = ri(r, 2, 7); F(x, y0 + 1, z, x, y0 + h, z, B(pk(r, ["stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks", "chiseled_sandstone"]))); return; }
    case "ruin_room": {
      const w = ri(r, 4, 7), h = ri(r, 2, 4), blk = B(pk(r, ["stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks"]));
      const gx = ri(r, -w + 1, w - 1), gz = ri(r, -w + 1, w - 1);
      F(X(x - w), y0 + 1, Zc(z - w), X(x + w), y0 + h, Zc(z - w), blk); F(X(x - w), y0 + 1, Zc(z + w), X(x + w), y0 + h, Zc(z + w), blk);
      F(X(x - w), y0 + 1, Zc(z - w), X(x - w), y0 + h, Zc(z + w), blk); F(X(x + w), y0 + 1, Zc(z - w), X(x + w), y0 + h, Zc(z + w), blk);
      F(X(x + gx - 1), y0 + 1, Zc(z - w), X(x + gx + 1), y0 + h, Zc(z - w), "air"); F(X(x - w), y0 + 1, Zc(z + gz - 1), X(x - w), y0 + h, Zc(z + gz + 1), "air");
      if (r() < 0.5) F(X(x + w), y0 + 1, Zc(z - 1), X(x + w), y0 + h, Zc(z + 1), "air");
      return;
    }
    case "bones": { F(x, y0 + 1, z, x, y0 + 3, z, B("bone_block")); F(X(x + 3), y0 + 1, z, X(x + 3), y0 + 3, z, B("bone_block")); return F(x, y0 + 4, z, X(x + 3), y0 + 4, z, B("bone_block")); }
    case "pillar_bone": return F(x, y0 + 1, z, x, y0 + ri(r, 3, 8), z, B("bone_block"));
    case "pillar_basalt": return F(x, y0 + 1, z, X(x + ri(r, 0, 1)), y0 + ri(r, 2, 7), Zc(z + ri(r, 0, 1)), B("basalt"));
    case "pillar_purpur": { const h = ri(r, 3, 9); F(x, y0 + 1, z, x, y0 + h, z, B("purpur_pillar")); return SB(x, y0 + h + 1, z, B("end_rod")); }
    case "palace_pillar": { F(x, y0 + 1, z, x, y0 + 9, z, B("quartz_pillar")); SB(x, y0 + 1, z, B("gold_block")); return SB(x, y0 + 9, z, B("gold_block")); }
    case "carpet": return F(x, y0 + 1, z, X(x + ri(r, 1, 3)), y0 + 1, Zc(z + ri(r, 1, 3)), B("red_carpet"));
    case "soul_lantern": { F(x, y0 + 1, z, x, y0 + 2, z, B("polished_blackstone_wall") === "stone" ? B("blackstone") : B("polished_blackstone_wall")); return SB(x, y0 + 3, z, B("soul_lantern")); }
    case "lantern": { F(x, y0 + 1, z, x, y0 + 2, z, B("cherry_fence") === "stone" ? B("oak_fence") : B("cherry_fence")); return SB(x, y0 + 3, z, B("lantern")); }
    case "mushroom_big": { const h = ri(r, 4, 7), red = r() < 0.5; F(x, y0 + 1, z, x, y0 + h, z, B("mushroom_stem")); return F(X(x - 2), y0 + h + 1, Zc(z - 2), X(x + 2), y0 + h + 1, Zc(z + 2), B(red ? "red_mushroom_block" : "brown_mushroom_block")); }
    case "mushroom_small": return SB(x, y0 + 1, z, B(r() < 0.5 ? "red_mushroom" : "brown_mushroom"));
    case "stump": return F(x, y0 + 1, z, x, y0 + ri(r, 1, 2), z, B("mangrove_log"));
  }
}

// ---- v2.3: 地上の ステージ（地方の テーマの 大地。半径 r の 円）----
const LAND_NAME = { forest: "こもれびの 森", cherry: "さくらの 丘", snow: "しろがねの 雪原", sea: "あさせの 入り江", desert: "すなかぜの 砂丘", volcano: "ようがんの 原", cave: "いわやの 谷", crystal: "すいしょうの 野",
  ruins: "くずれた 都", sky: "うかぶ 浮島", swamp: "きりの 沼", mushroom: "おおきのこの 森", underworld: "めいふの 谷", void: "こくうの 野", palace: "おうきゅうの 庭" };
export function genLand(cx, y, cz, theme, r, seed) {
  const T = DG_THEMES[theme] || DG_THEMES.forest;
  let a = seed >>> 0; const rnd = () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const C = [];
  const F = (a1, b1, c1, d1, e1, f1, blk, mode) => C.push(`fill ${a1} ${b1} ${c1} ${d1} ${e1} ${f1} ${blk}${mode ? " " + mode : ""}`);
  const SB = (x, yy, z, blk) => C.push(`setblock ${x} ${yy} ${z} ${blk}`);
  const inC = (x, z, rr = r) => Math.hypot(x - cx, z - cz) <= rr;
  const sky = !!T.sky, gy = sky ? y + 12 : y;
  // 円の 大地（空の テーマは 浮島＋らせん階段）
  for (let dz = -r; dz <= r; dz++) {
    const w = Math.floor(Math.sqrt(r * r - dz * dz));
    if (!sky) { F(cx - w, y + 1, cz + dz, cx + w, y + 14, cz + dz, "air"); F(cx - w, y - 3, cz + dz, cx + w, y - 1, cz + dz, B(T.base)); F(cx - w, y, cz + dz, cx + w, y, cz + dz, B(T.fl)); }
  }
  if (sky) {
    const isl = [[0, 0, 11], [16, 6, 6], [-14, 10, 6], [4, -17, 6], [-12, -12, 5]];
    for (const [ox, oz, rr] of isl) for (let dz = -rr; dz <= rr; dz++) { const w = Math.floor(Math.sqrt(rr * rr - dz * dz)); F(cx + ox - w, gy + 1, cz + oz + dz, cx + ox + w, gy + 14, cz + oz + dz, "air"); F(cx + ox - w, gy, cz + oz + dz, cx + ox + w, gy, cz + oz + dz, B(T.fl)); if (Math.abs(dz) < rr - 1) F(cx + ox - w + 1, gy - 1, cz + oz + dz, cx + ox + w - 1, gy - 2, cz + oz + dz, B(T.base)); }
    for (const [ox, oz] of isl.slice(1)) { const n = Math.max(Math.abs(ox), Math.abs(oz)); for (let s = 0; s <= n; s += 2) F(cx + Math.round(ox * s / n) - 1, gy, cz + Math.round(oz * s / n) - 1, cx + Math.round(ox * s / n) + 1, gy, cz + Math.round(oz * s / n) + 1, B("oak_planks")); }
    for (let k = 0; k <= 12; k++) { const ang = k * 0.55, x = cx + Math.round(Math.cos(ang) * 13), z = cz + Math.round(Math.sin(ang) * 13); F(x, y + 1, z, x + 1, y + k, z + 1, B("quartz_block")); }
  } else {
    // まだら・海の 水
    for (let k = 0; k < Math.floor(r * r / 22); k++) { const x = cx + Math.floor((rnd() * 2 - 1) * r), z = cz + Math.floor((rnd() * 2 - 1) * r); if (!inC(x, z, r - 2)) continue; const w = 1 + Math.floor(rnd() * 3); F(x - w, y, z - w, x + w, y, z + w, B(pk(rnd, T.fl2))); }
    if (T.water) { for (let dz = -r + 1; dz <= r - 1; dz++) { const w = Math.floor(Math.sqrt((r - 1) * (r - 1) - dz * dz)); F(cx - w, y + 1, cz + dz, cx + w, y + 1, cz + dz, "water"); } for (let k = 0; k < 360; k += 1.5) { const x = cx + Math.round(Math.cos(k * Math.PI / 180) * r), z = cz + Math.round(Math.sin(k * Math.PI / 180) * r); SB(x, y + 1, z, B(T.fl2[0] || "sand")); } }
  }
  // 飾り
  const R0 = { x0: cx - r + 2, z0: cz - r + 2, X1: cx + r - 2, Z1: cz + r - 2 };
  for (const [kind, dens] of T.feats) {
    const n = Math.round(((Math.PI * r * r) / 100) * dens * (sky ? 0.3 : 1));
    for (let k = 0; k < n; k++) { const x = cx + Math.floor((rnd() * 2 - 1) * (r - 3)), z = cz + Math.floor((rnd() * 2 - 1) * (r - 3)); if (!inC(x, z, r - 3)) continue; if (sky && Math.hypot(x - cx, z - cz) > 9) continue; feature(kind, x, z, gy, rnd, F, SB, T, gy + 14, R0); }
  }
  // 目印の 柱・宝箱・明かり
  F(cx, gy + 1, cz, cx, gy + 5, cz, B(T.wall === "barrier" ? "quartz_pillar" : T.wall)); SB(cx, gy + 6, cz, B(T.light === "lantern_post" || T.light === "end_rod_post" ? "glowstone" : T.light));
  const nch = 3 + Math.floor(rnd() * 2);
  for (let k = 0; k < nch; k++) { const ang = rnd() * Math.PI * 2, rr = sky ? 4 + rnd() * 4 : 6 + rnd() * (r - 9); const x = cx + Math.round(Math.cos(ang) * rr), z = cz + Math.round(Math.sin(ang) * rr); F(x, gy + 1, z, x, gy + 3, z, "air"); { const [c1, c2] = chestCmds(x, gy + 1, z, rollTier(k === 0 ? 4 : 2, lvBonus({ x: cx, z: cz }))); C.push(c1); } }
  if (!sky) for (let k = 0; k < 8; k++) { const ang = (k / 8) * Math.PI * 2, x = cx + Math.round(Math.cos(ang) * (r - 4)), z = cz + Math.round(Math.sin(ang) * (r - 4)); F(x, y + 1, z, x, y + 2, z, B("oak_fence")); SB(x, y + 3, z, B(T.light === "lantern_post" || T.light === "end_rod_post" ? "lantern" : T.light)); }
  return { cmds: C, name: LAND_NAME[theme] || T.name };
}
