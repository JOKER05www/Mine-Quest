// v2.2.2: 石板の 物語（ボス石板 30枚・封印・遺跡・エンディング）の 進み具合
import { SPECIES, ITEMS, BOSS_SLAB, BS_OLD2NEW, DEITY } from "./data.js";
import { giveItem, countItem } from "./ui.js";
import { WREGIONS } from "./worldmap.js";
import { save } from "./store.js";

export const RI = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
export const rIdx = (sid) => { const i = RI.indexOf(SPECIES[sid]?.rank); return i < 0 ? 8 : i; };
export const BS_N = BOSS_SLAB.length;          // 15
export const CROWN = BS_N - 1;                 // 王冠の石板（最後）
export const RUIN_NEED = 8;

export function qs(d) {
  if (!d.story) d.story = { cup: 0, final: false, met: false, rematch: 0 };
  const s = d.story;
  if (!Array.isArray(s.bs)) s.bs = [];
  if (typeof s.cup !== "number") s.cup = Number(s.cup) || 0;   /* 第69版 */
  for (const k of ["kgw", "dg", "dgw"]) if (s[k] !== undefined && (typeof s[k] !== "object" || s[k] === null || Array.isArray(s[k]))) s[k] = {};   /* 第68版 */
  if (s.dgs !== undefined && !Array.isArray(s.dgs)) s.dgs = [];
  if (!Array.isArray(s.bsg)) {
    // v2.2.4: 30枚 → 15枚。古い 番号を 新しい 番号へ
    const old = typeof s.bsGot === "number" ? s.bsGot : 0;
    const m = (k) => (BS_OLD2NEW && BS_OLD2NEW[k] !== undefined ? BS_OLD2NEW[k] : null);
    s.bs = [...new Set((s.bs || []).map(m).filter((x) => x !== null))];
    s.bsg = [...new Set([...Array.from({ length: old }, (_, k) => m(k)).filter((x) => x !== null), ...s.bs, ...(s.crown ? [BS_N - 1] : [])])];
    if (s.bsT) { const t = {}; for (const [k, v] of Object.entries(s.bsT)) { const n = m(Number(k)); if (n !== null) t[n] = v; } s.bsT = t; }
    delete s.bsGot;
  }
  if (!Array.isArray(s.rm)) s.rm = [];
  if (typeof s.ruins !== "number") s.ruins = 0;
  if (typeof s.pm !== "number") s.pm = 0;      // 裏ボス マスターに 勝った かず
  return s;
}
export const sealedN = (d) => qs(d).bs.length;
export const isSealed = (d, i) => qs(d).bs.includes(i);
export const endingDone = (d) => !!qs(d).ending;
// クリア前は 銀の石板まで
export const slabTierOk = (d, t) => t < 2 || endingDone(d);
export const postOpen = (d) => { const s = qs(d); return !!(s.final && s.bsFinal && s.ruinFinal); };
// 物語の 進み（0〜1）: 封印した 石板・越えた 遺跡・カップ
// v2.7: 物語の 進みで 解放される ランク（装備の レア度・タマゴから 生まれる ランク）。0=F … 8=X
export const RANK_LBL = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
export function rankCap(d) {
  const s = qs(d);
  if (postOpen(d)) return 8;
  if (s.ending) return 7;
  const g = progress(d);
  return g < 0.15 ? 2 : g < 0.3 ? 3 : g < 0.45 ? 4 : g < 0.62 ? 5 : 6;   // v2.9.12: 序盤は F〜D
}
// v2.9.12: 物語の 進みで 店・クラフトに 出る 品を 解禁（武器・防具の 段・タマゴ）
export const wtCap = (c) => (c <= 2 ? 0 : c <= 4 ? 1 : c <= 6 ? 2 : 3);
export function storyItemOk(it, eggRanks, c) {
  if (!it) return false;
  if (it.kind === "weapon" || it.kind === "armor") return (it.wt ?? 0) <= wtCap(c);
  if (it.kind === "acc") return (it.tier ?? 0) <= wtCap(c) + 1;
  if (it.kind === "egg" && eggRanks) { const rs = Object.keys(eggRanks).map((r) => RANK_LBL.indexOf(r)).filter((x) => x >= 0); return !rs.length || Math.max(...rs) <= c; }   // v2.9.12: 生まれる ランクが ぜんぶ 上限 いかの タマゴだけ（かえすと 本来の ランク）
  if (it.kind === "evostone") return c >= 3;
  if (it.kind === "matbox" && typeof it.mt === "number") return it.mt <= wtCap(c);   // 素材の 袋も
  if (it.kind === "material") return (it.tier ?? 0) <= wtCap(c);   // 素材の 段も（1段目の 装備の 素材は C解放から）   // 進化の 石は C解放から
  return true;
}
// v2.9.12: 宝箱・落とし物も 物語で しばる（育成の 道具は 段が 上限＋1まで）
const GROW_K = new Set(["lvup", "lvmax", "awaken", "talent", "seed", "seedall", "sp", "exp", "plusup", "inherit", "limit", "traitpick", "nature_pick", "dream", "resize"]);
export function storyLootOk(it, eggRanks, c) {
  if (!storyItemOk(it, eggRanks, c)) return false;
  if (it && GROW_K.has(it.kind)) return (it.tier ?? 0) <= wtCap(c) + 1;
  return true;
}
export const capText = (d) => { const c = rankCap(d); return `§e装備・タマゴの 上限ランク: ${RANK_LBL[c]}${c < 8 ? `§7（物語を 進めると ${RANK_LBL[c + 1]}が 解放）` : "§7（すべて 解放）"}`; };
export function progress(d) { const s = qs(d); return Math.min(1, (s.bs.length * 2 + Math.min(RUIN_NEED, s.ruins) + Math.min(8, s.cup || 0)) / (BS_N * 2 + RUIN_NEED + 8)); }

// 手持ちの 強さ（上位 3体の 平均 Lv と ランク）
export function partyPower(d) {
  const L = [...(d.party || []), ...(d.bench || [])].filter(Boolean).sort((a, b) => b.lv - a.lv).slice(0, 3);   /* 第69版: 裏も 数える */
  if (!L.length) return { lv: 1, rank: 0 };
  return { lv: Math.round(L.reduce((a, m) => a + m.lv, 0) / L.length), rank: L.reduce((a, m) => a + rIdx(m.sp), 0) / L.length };
}
// 石板ボスの レベル: 物語の 順に 固定（苔むしの石板 Lv8 → 王冠の石板 Lv70）。中の モンスターは その 約86%
export function bossLv(d, i) { return Math.round(8 + (62 * Math.max(0, Math.min(CROWN, i))) / CROWN); }
export const slabBossLv = (i) => Math.min(100, bossLv(null, i) + 9);   // v3.0: 石板の 主（地方マスターの 主力 +5）
export const mobLv = (i) => Math.max(3, Math.round(bossLv(null, i) * 60 / 70));
// 手持ちの ランクが 上なら プラス値で おぎなう
export function bossPlus(d, sid, i) {
  const P = partyPower(d);
  const gap = Math.max(0, P.rank - rIdx(sid));
  return Math.min(80, Math.round(gap * 9 + i * 1.2 + (i === CROWN ? 30 : 0)));
}
// 遺跡の ボスも 物語が 進むほど 強く
export function ruinLv(d, lv0) {
  const s = qs(d), P = partyPower(d);
  const prog = Math.round(10 + (s.bs.length + s.ruins) * 2.4);
  return Math.max(lv0, Math.min(100, Math.max(prog, Math.min(P.lv + 4, prog + 12))));
}

// v2.2.4: どの 石板が どこで 手に入るか（地方マスター 8・カップ 4・遺跡 2・星冠王 1）
export const RM_SLAB = [0, 2, 4, 6, 8, 10, 12, 13];          // 地方マスター ★1〜★8
export const CUP_SLAB = { 1: 1, 3: 3, 5: 7, 6: 9 };          // カップ番号 → 石板
export const RUIN_SLAB = { 2: 5, 5: 11 };                    // 遺跡を 越えた かず → 石板
export const slabSource = (i) => { const r = RM_SLAB.indexOf(i); if (r >= 0) { const R = WREGIONS.find((x) => x.rm === r); return R ? `${R.castle.name}の 地方マスター` : "地方マスター"; } for (const [c, k] of Object.entries(CUP_SLAB)) if (k === i) return ["ひよっこ", "そよかぜ", "いわくだき", "炎", "雷", "はがね", "てんくう", "せいかん"][c] + "カップ 優勝"; for (const [n, k] of Object.entries(RUIN_SLAB)) if (k === i) return `遺跡の ボスを ${n}体`; return "星冠王 ゼファード"; };
export function giveSlab(p, d, i) {
  const s = qs(d);
  if (i === null || i === undefined || !BOSS_SLAB[i] || s.bsg.includes(i)) return null;
  s.bsg.push(i);
  try { giveItem(p, `mrpg:${BOSS_SLAB[i].id}`, 1); } catch {}
  if (i === CROWN) s.crown = true;
  return BOSS_SLAB[i];
}
export const giveCrown = (p, d) => giveSlab(p, d, CROWN);
export const hasSlab = (d, i) => qs(d).bsg.includes(i);
// 取りこぼしの つじつま あわせ
export function syncQuest(p, d) {
  const s = qs(d), got = [];
  const g = (i) => { const b = giveSlab(p, d, i); if (b) got.push(b.name); };
  for (const [c, k] of Object.entries(CUP_SLAB)) if ((s.cup || 0) > Number(c)) g(k);
  for (const [n, k] of Object.entries(RUIN_SLAB)) if (s.ruins >= Number(n)) g(k);
  s.rm.forEach((r) => g(RM_SLAB[r]));
  if (s.final) g(CROWN);
  if (s.ending && !s.meetGot) { s.meetGot = true; try { giveItem(p, "mrpg:sx_meet", 1); } catch {} got.push("再会の石板"); }
  // v2.8: 特別な 石板は なくならない。受けとった はずの 石板が 手元に ない ときは もう一度 わたす（地方マスターの 石板が 届かなかった 問題の 救済）
  for (const i of s.bsg) { const b = BOSS_SLAB[i]; if (b && !hasSlabItem(p, i)) { try { giveItem(p, `mrpg:${b.id}`, 1); got.push(b.name); } catch {} } }
  // 第69版: カゲツの 勝ち数に 応じた 神の石板（前の 版で 勝って いた 人にも）
  const newG = [], newN = [];
  if (s.ending) { s.dgs = Array.isArray(s.dgs) ? s.dgs : []; for (const gi of [11, 12, 13, 14]) { const need = gi === 14 ? 40 : (gi - 10) * 10; if ((s.kg || 0) >= need && !s.dgs.includes(gi) && DEITY[gi]) { s.dgs.push(gi); newG.push(gi); } } }
  // 第68版: 受けとった 神の石板も（仲間に した 神の 石板は のぞく）
  for (const gi of Array.isArray(s.dgs) ? s.dgs : []) { const G = DEITY[gi]; if (G && ITEMS[G.slab] && !(s.dg || {})[gi]) { let n = 0; try { n = countItem(p, `mrpg:${G.slab}`); } catch {} if (n <= 0) { try { giveItem(p, `mrpg:${G.slab}`, 1); if (newG.includes(gi)) newN.push(ITEMS[G.slab].name); else got.push(ITEMS[G.slab].name); } catch {} } } }
  if (newN.length) try { save(p, d); } catch {}   /* 第69版: すぐ 保存（二重に わたさない） */
  if (newN.length) try { p.sendMessage(`§dカゲツとの 勝負の ほうびを 受けとった: §f${newN.join("、")} §7（バッグ → 神の石板）`); } catch {}   /* 第69版: 前の 版で 勝って いた 人へ */
  return got;
}
export const slabOf = (id) => (ITEMS[id] && ITEMS[id].kind === "bslab" ? BOSS_SLAB[ITEMS[id].bs] : null);
export function hasSlabItem(p, i) { try { return countItem(p, `mrpg:${BOSS_SLAB[i].id}`) > 0; } catch { return false; } }
export const progressText = (d) => { const s = qs(d); return `§d封印 ${s.bs.length}/${BS_N}  §6遺跡 ${Math.min(s.ruins, RUIN_NEED)}/${RUIN_NEED}${s.ruinFinal ? "★" : ""}  §eカップ ${Math.min(8, s.cup || 0)}/8${s.final ? "★" : ""}`; };
