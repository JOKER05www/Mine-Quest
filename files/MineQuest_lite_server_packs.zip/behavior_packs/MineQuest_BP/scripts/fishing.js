// v2.0: 釣り（街の 釣り屋で 釣竿を 買って、水に 向かって 使う）
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES, ORDER, FISH, FISH_FAMS, RANKS, EGGS } from "./data.js";
import { load, save, mark } from "./store.js";
import { busy, ok, sound, giveItem, rankOf, wait, barNote, showTitle } from "./ui.js";
import { TYPE, setLook, levelAt } from "./field.js";
import { startBattle } from "./battle.js";
import { pick, ri } from "./core.js";
import { rankCap, storyLootOk } from "./quest.js";

const fishing = new Set();
const isWater = (b) => { try { return !!b && (b.typeId.includes("water") || b.isLiquid === true); } catch { return false; } };
function waterTarget(p) {
  try {
    const hit = p.getBlockFromViewDirection({ maxDistance: 14, includeLiquidBlocks: true, includePassableBlocks: true });
    if (hit && isWater(hit.block)) return hit.block.location;
  } catch {}
  // 見ている 方向の 先を 少しずつ 調べる（古い バージョン用）
  try {
    const v = p.getViewDirection(), h = p.getHeadLocation();
    for (let t = 1.5; t <= 12; t += 0.75) {
      const x = Math.floor(h.x + v.x * t), y = Math.floor(h.y + v.y * t), z = Math.floor(h.z + v.z * t);
      const b = p.dimension.getBlock({ x, y, z });
      if (isWater(b)) return { x, y, z };
      if (b && b.typeId !== "minecraft:air" && !b.typeId.includes("grass") && !b.typeId.includes("flower")) break;
    }
  } catch {}
  return null;
}
function splash(dim, pos, n = 4) {
  for (let i = 0; i < n; i++) try { dim.spawnParticle("minecraft:water_splash_particle", { x: pos.x + (Math.random() - 0.5), y: pos.y + 0.1, z: pos.z + (Math.random() - 0.5) }); } catch {}
}
function rollCatch(tier) {
  const list = FISH[tier] || FISH[0];
  const tot = list.reduce((a, x) => a + x[2], 0);
  let r = Math.random() * tot;
  for (const x of list) { r -= x[2]; if (r <= 0) return x; }
  return list[0];
}
function ranksOf(s) {
  const [a, b] = s.split("-");
  const i = RANKS.indexOf(a), j = RANKS.indexOf(b || a);
  return RANKS.slice(i, j + 1);
}
export function fishMonster(tier, rankStr, cap = 8) {
  let rs = ranksOf(rankStr).filter((r) => RANKS.indexOf(r) <= cap);   // v2.9.6: 物語の 進みより 上の ランクは 釣れない
  if (!rs.length) rs = [RANKS[Math.max(0, Math.min(cap, RANKS.indexOf(ranksOf(rankStr)[0])))]];
  const fams = Math.random() < 0.75 ? ["aqua"] : FISH_FAMS;
  let pool = ORDER.filter((s) => !SPECIES[s].hidden && fams.includes(SPECIES[s].fam) && rs.includes(SPECIES[s].rank) && !SPECIES[s].metalmon && !SPECIES[s].special4);
  if (!pool.length) pool = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].fam === "aqua" && rs.includes(SPECIES[s].rank));
  return pool.length ? pick(pool) : null;
}
export async function fish(p, rodId) {
  const it = ITEMS[rodId]; if (!it) return;
  const tier = it.rod || 0;
  if (fishing.has(p.id) || busy.has(p.id)) return;
  const d = load(p);
  if (!d) { p.sendMessage("§eまず ガイドブックで 最初の 仲間を 選ぼう！"); return; }
  const w = waterTarget(p);
  if (!w) { try { barNote(p).setActionBar("§7水に 向かって 使おう（海・川・池）"); } catch {} return; }
  fishing.add(p.id);
  try {
    const pos = { x: w.x + 0.5, y: w.y + 1, z: w.z + 0.5 };
    const start = { ...p.location };
    sound(p, "random.bow", 0.8);
    splash(p.dimension, pos, 6);
    try { barNote(p).setActionBar(`§b${it.name}§fで 釣り糸を たらした… §7（動くと 逃げられる）`); } catch {}
    const T = Math.max(30, ri(50, 150) - tier * 12);
    for (let t = 0; t < T; t += 10) {
      await wait(10);
      if (!ok(p)) return;
      if (Math.hypot(p.location.x - start.x, p.location.z - start.z) > 1.2) { try { barNote(p).setActionBar("§7…動いたので 逃げられた。"); } catch {} return; }
      if (Math.random() < 0.3) splash(p.dimension, pos, 1);
    }
    // ヒット！
    sound(p, "random.splash", 1.2); splash(p.dimension, pos, 12);
    try { showTitle(p, "§e§l！", { subtitle: "§fヒット！", fadeInDuration: 0, stayDuration: 14, fadeOutDuration: 4 }); } catch {}
    await wait(12);
    const c = rollCatch(tier);
    if (c[0] === "item") {
      let id = c[1];
      if (!ITEMS[id]) return;
      try { const dd = load(p); if (dd && !storyLootOk(ITEMS[id], EGGS[id]?.ranks, rankCap(dd))) id = "m_coin"; } catch {}   // v2.9.12: 物語より 先の 品は お金の 袋に
      giveItem(p, `mrpg:${id}`, 1);
      const big = ITEMS[id].kind === "treasure" && ITEMS[id].val >= 4000;
      p.sendMessage(`${big ? "§6§l＊ " : "§b"}${ITEMS[id].name}を 釣りあげた！${ITEMS[id].kind === "treasure" ? ` §7（お宝: ${ITEMS[id].val} タヨ）` : ""}`);
      sound(p, big ? "random.levelup" : "random.pop", big ? 1 : 1.2);
      if (big) for (const q of world.getAllPlayers()) if (q.id !== p.id) q.sendMessage(`§6§l＊ ${p.name}が ${ITEMS[id].name}を 釣りあげた！`);
      return;
    }
    // モンスターが 釣れた → そのまま バトル
    let cap = 8; try { cap = rankCap(load(p)); } catch {}
    const sid = fishMonster(tier, c[1], cap);
    if (!sid) { p.sendMessage("§7…なにも かからなかった。"); return; }
    const lv = Math.max(1, levelAt(p.dimension, p.location) + tier * 3 + ri(-1, 2));
    let e;
    try { e = p.dimension.spawnEntity(TYPE, pos); } catch { return; }
    setLook(e, sid);
    e.setDynamicProperty("mrpg:lv", lv);
    e.setDynamicProperty("mrpg:q", Math.min(0.9, 0.2 + tier * 0.2));
    e.addTag("mrpg_sea");
    if (Math.random() < 1 / 200) e.addTag("mrpg_shiny");
    try { e.triggerEvent("mrpg:float_on"); } catch {}
    e.nameTag = `§b${SPECIES[sid].name} §7Lv${lv} ${rankOf(sid)}`;
    mark(d.seen, sid); save(p, d);
    p.sendMessage(`§b§l${SPECIES[sid].name}§r§b（ランク${SPECIES[sid].rank}）が 釣れた！ §fおそいかかって きた！`);
    sound(p, "mob.guardian.attack", 1.2);
    fishing.delete(p.id);
    await wait(10);
    if (ok(e)) await startBattle(p, e);
  } finally { fishing.delete(p.id); }
}
