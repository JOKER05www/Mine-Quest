// v2.9.3: モンスター闘技場（賭け）
// 1対1。能力値は その種族の まま（同じ レベル・才能は ふつう）。技・特性・性格・スキルは 毎回 ランダム。
// 出場する モンスターは 物語の 進み具合で ふえ、クリア後は 全ランク・全モンスター。
import { system, world } from "@minecraft/server";
import { SPECIES, ORDER, SKILLS, TRAITS, NATURES, RANKS } from "./data.js";
import { makeMonster, fighter, calcStats, skillPool, slotN, rollTraits, uniqOf, aiDecide, expandActions, actionOrder, runAction, endOfTurn, battleStart, alive, STATS } from "./core.js";
import { load, save } from "./store.js";
import { busy, ok, choose, notice, confirm, gold, ICON, MON_ICON, barNote } from "./ui.js";
import { startSpar } from "./battle.js";
import { toSkyArena, backFromArena, skyArenaPos } from "./stage.js";
import { qs } from "./quest.js";
import { openUpTo } from "./saga.js";

const B_ = (t, i) => [t, i];
const wait = (t) => new Promise((r) => system.runTimeout(r, t));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
// 物語の 進み具合（0〜10・クリア後 11）
export function betStage(d) { const s = qs(d); return s.ending ? 11 : Math.max(0, Math.min(10, openUpTo(d))); }
const MAXR = [1, 2, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8];          // 出られる いちばん 上の ランク（F=0 … X=8）
const LV = [10, 18, 26, 34, 42, 50, 58, 66, 74, 82, 90, 100];
const CAP = [500, 1000, 2000, 4000, 7000, 10000, 15000, 25000, 40000, 60000, 100000, 1000000];
export function betPool(st, majin = true) {
  const mr = MAXR[st];
  return ORDER.filter((s) => {
    const S = SPECIES[s];
    if (!S || s.startsWith("book_")) return false;
    if (RANKS.indexOf(S.rank) > mr) return false;
    if (st < 11 && (S.hidden || S.fam === "god")) return false;   // 神・かくれた 子は クリア後
    if (!majin && (s === "enma" || s === "musashi")) return false;   /* 第69版: 魔神編の 前は 出さない */
    if (st < 7 && S.fam === "king") return false;                  // 王は 終盤から
    return true;
  });
}
// 出場者: 能力は そのまま、技・特性・性格・スキルは ランダム
export function entrant(sid, lv) {
  const m = makeMonster(sid, lv, false);
  m.tal = Object.fromEntries(STATS.map((k) => [k, 16])); m.plus = 0; m.ht = Math.random() < 0.3;
  m.nat = Math.floor(Math.random() * NATURES.length);
  const rt = rollTraits(sid); if (rt) m.rtr = rt; else delete m.rtr;
  const u = uniqOf(sid);
  const pool = skillPool(sid).filter((k) => !SKILLS[k]?.uniq);
  const n = slotN(m) - (u ? 1 : 0), sk = [];
  const P = [...pool]; while (sk.length < n && P.length) sk.push(P.splice(Math.floor(Math.random() * P.length), 1)[0]);
  m.sk = u ? [u, ...sk] : sk;
  m.pts = m.sk.map(() => 20 + Math.floor(Math.random() * 9) * 10);
  m.spl = 0; m.eq = { w: null, a: null, x: null };
  const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  return m;
}
// 第68版: 1回だけ 裏で 戦わせる（結果だけ 見る ときにも 使う）。"A"・"B"・null（引き分け）
export function simOne(mA, mB, turns = 30) {
  const A = fighter(JSON.parse(JSON.stringify(mA)), "a"), E = fighter(JSON.parse(JSON.stringify(mB)), "e");
  A.smart = 1; E.smart = 1;
  const B = { allies: [A], enemies: [E], turn: 1, pvp: true, spar: true, players: [], wbase: "sun", wbaseT: 8, wonce: true }; const log = [];
  try {
    battleStart(B, log);
    for (let t = 0; t < turns && A.hp > 0 && E.hp > 0; t++) {
      B.turn = t + 1;
      const acts = expandActions([aiDecide(A, B), aiDecide(E, B)], B);
      for (const x of actionOrder(acts, B)) { if (x.actor.hp <= 0 || A.hp <= 0 || E.hp <= 0) continue; runAction(B, x, log); }
      if (A.hp > 0 && E.hp > 0) endOfTurn(B, log);
      log.length = 0;
    }
  } catch {}
  return E.hp <= 0 ? "A" : A.hp <= 0 ? "B" : null;
}
// オッズ: その 組み合わせで こっそり 何回か 戦わせて 決める
export async function oddsOf(mA, mB, n = 20) {
  let a = 0, b = 0;
  for (let i = 0; i < n; i++) {
    const A = fighter(JSON.parse(JSON.stringify(mA)), "a"), E = fighter(JSON.parse(JSON.stringify(mB)), "e");
    A.smart = 1; E.smart = 1;
    const B = { allies: [A], enemies: [E], turn: 1, pvp: true, spar: true, players: [], wbase: "sun", wbaseT: 8, wonce: true }; const log = [];   // v2.9.12: 本番と 同じ 晴れから
    try {
      battleStart(B, log);
      for (let t = 0; t < 30 && A.hp > 0 && E.hp > 0; t++) {
        B.turn = t + 1;
        const acts = expandActions([aiDecide(A, B), aiDecide(E, B)], B);
        for (const x of actionOrder(acts, B)) { if (x.actor.hp <= 0 || A.hp <= 0 || E.hp <= 0) continue; runAction(B, x, log); }
        if (A.hp > 0 && E.hp > 0) endOfTurn(B, log);
        log.length = 0;
      }
    } catch {}
    if (E.hp <= 0) a++; else if (A.hp <= 0) b++;   // 相打ちは 本番と 同じく 赤の 勝ち
    if (i === 5 && (a === 6 || b === 6)) break;   /* 第69版: 片方が 6連勝なら 早めに 打ち切り */
    if (i % 2 === 1) await wait(1);
  }
  const pa = (a + 1) / (a + b + 2), pb = 1 - pa;
  const od = (p) => Math.max(1.05, Math.min(30, Math.floor((0.9 / p) * 10) / 10));   // v2.9.6: 胴元の 取りぶん 10%（かならず もうかる 賭けは なし）
  return { a: od(pa), b: od(pb), pa, pb };
}
const cardText = (m, tag, od) => {
  const S = SPECIES[m.sp];
  const sk = m.sk.map((k) => (SKILLS[k]?.name || k).split("・")[0]).join("・");
  const tr = (m.rtr || S.traits || []).map((t) => TRAITS[t]?.name).filter(Boolean).join("・");
  return [`${tag} §l${S.name}§r §7${S.famName} ランク${S.rank} サイズ${S.sz} Lv${m.lv}`, `§f性格: §b${NATURES[m.nat]?.name}§f  オッズ: §e§l${od.toFixed(1)}倍`, `§fスキル: §a${sk}`, `§f特性: §d${tr}`].join("\n");
};
export async function betMenu(p) {   // v2.9.12: 受付（話しかけ中は busy）から 呼ぶので busy では 止めない（前は 押しても 何も 起きなかった）
  const d = load(p); if (!d) return null;
  const st = betStage(d), pool = betPool(st, !!(d.story && d.story.enmaClear)), lv = LV[st];
  if (pool.length < 2) { await notice(p, "モンスター闘技場", "§7まだ 出場できる モンスターが いない。"); return null; }
  for (let loop = 0; loop < 30; loop++) {   /* 第69版: 1回の 計算を 軽く（12戦・6連勝で 打ち切り） */
  const sA = pick(pool), rA = RANKS.indexOf(SPECIES[sA].rank);
  const near = pool.filter((s) => s !== sA && Math.abs(RANKS.indexOf(SPECIES[s].rank) - rA) <= 1);
  const sB = pick(near.length ? near : pool.filter((s) => s !== sA));
  const mA = entrant(sA, lv), mB = entrant(sB, lv);
  try { barNote(p).setActionBar("§eオッズを 計算中…"); } catch {}
  const od = await oddsOf(mA, mB, 12);
  if (od.pa > 0.8 || od.pb > 0.8) { if (loop >= 29) { await notice(p, "モンスター闘技場", "§7いい 組み合わせが 決まらなかった。また 来てね。"); return null; } continue; }   // v2.9.12: 勝ちが 見えて いる 組み合わせは ぜったい 出さない
  const cap = Math.min(CAP[st], d.gold);
  const body = [`§6§lモンスター闘技場§r §7（${st >= 11 ? "全ランク 全モンスター" : `${RANKS[MAXR[st]]}ランクまで`}・物語が 進むと 出場者が ふえる）`,
    "§7能力は その モンスターの まま。技・特性・性格・スキルは 毎回 ランダム！", "", cardText(mA, "§c赤コーナー", od.a), "", cardText(mB, "§9青コーナー", od.b), "",
    `§fかけられる 上限: ${gold(Math.min(CAP[st], 999999999))}  §fもちがね: ${gold(d.gold)}`].join("\n");
  const s = await choose(p, "モンスター闘技場", body, [B_(`§c§l赤に かける §r§8×${od.a.toFixed(1)}`, MON_ICON(sA)), B_(`§9§l青に かける §r§8×${od.b.toFixed(1)}`, MON_ICON(sB)), B_("§7別の 組み合わせ", ICON("i_run")), B_("§7やめる", ICON("i_back"))]);
  if (s === 2) continue;
  if (s !== 0 && s !== 1) return null;
  if (cap < 10) { await notice(p, "モンスター闘技場", "§cお金が たりない！"); return null; }
  const amounts = [10, 50, 100, 500, 1000, 5000, 10000, 50000, 100000, 500000, 1000000].filter((x) => x <= cap);
  if (!amounts.includes(cap)) amounts.push(cap);
  const k = await choose(p, "いくら かける？", `§f${s === 0 ? "§c赤" : "§9青"}§fの ${SPECIES[s === 0 ? sA : sB].name}に かける。当たれば ×${(s === 0 ? od.a : od.b).toFixed(1)}\n§fもちがね: ${gold(d.gold)}`, [...amounts.map((x) => B_(`${gold(x)}${x === cap ? " §8（上限）" : ""}`, ICON("i_item"))), B_("§7やめる", ICON("i_back"))]);
  if (k < 0 || k >= amounts.length) return null;
  const bet = amounts[k];
  const how = await choose(p, "モンスター闘技場", `§f${gold(bet)} を ${s === 0 ? "§c赤" : "§9青"}§fに かけます。\n§7戦いを 見ますか？ 結果だけ すぐ 見る ことも できます。`, [B_("§l観戦する", ICON("i_fight")), B_("§e結果だけ 見る §8（スキップ）", ICON("i_run")), B_("§7やめる", ICON("i_back"))]);   // 第68版
  if (how !== 0 && how !== 1) return null;
  const d3 = load(p); if (!d3 || d3.gold < bet) { await notice(p, "モンスター闘技場", "§cお金が たりない！"); return null; }
  d3.gold -= bet; d3.betPend = bet; save(p, d3);   // v2.9.12: とちゅうで 閉じたら 次に 入った とき 返す
  return () => betWatch(p, mA, mB, s === 0 ? "A" : "B", bet, s === 0 ? od.a : od.b, how === 1);
  }
  return null;
}
async function betWatch(p, mA, mB, side, bet, odds, skip = false) {
  const opt = { bet: true };
  const markGo = () => { try { const d0 = load(p); if (d0 && d0.betPend) { d0.betGo = 1; save(p, d0); } } catch {} };
  if (skip) markGo();   /* 第89版: 印は 試合を 始める 直前に（闘技場を 作る 間に ぬけた ときは 返す） */
  /* v2.9.12: 戦いが 始まったら とちゅうで ぬけても 返さない（負けそうな ときだけ ぬける ズルを ふせぐ） */
  if (skip) { opt.result = { winner: simOne(mA, mB, 60) }; try { p.playSound("random.click", { volume: 1 }); } catch {} }
  else {
  const r = await toSkyArena(p);
  try {
    const C = skyArenaPos();
    let pos;
    if (r && r.ok) {
      pos = { player: { x: C.x + 0.5, y: C.y, z: C.z - 11 }, a: { x: C.x + 0.5, y: C.y, z: C.z - 5 }, b: { x: C.x + 0.5, y: C.y, z: C.z + 6 } };
      try { p.teleport({ x: pos.player.x, y: C.y + 0.2, z: pos.player.z }, { facingLocation: { x: C.x + 0.5, y: C.y + 1, z: C.z } }); } catch {}
    }
    if (!ok(p)) return;
    markGo();
    await startSpar(p, [mA], [mB], "watch", pos, opt);
  } finally { try { backFromArena(p); } catch {} }
  }
  const w = opt.result ? opt.result.winner : null;
  if (!ok(p)) return;
  const d = load(p); if (!d) return;
  delete d.betPend; delete d.betGo;
  d.betStats = d.betStats || { n: 0, win: 0, best: 0, gain: 0 };
  d.betStats.n++;
  let msg;
  if (w === side) {
    const pay = Math.floor(bet * odds); d.gold += pay; d.betStats.win++; d.betStats.gain += pay - bet; d.betStats.best = Math.max(d.betStats.best, pay);
    msg = `§e§l当たり！§r §f${gold(pay)} を 受けとった！（かけた ${gold(bet)} × ${odds.toFixed(1)}）`;
    try { p.playSound("random.levelup", { volume: 1 }); } catch {}
  } else if (w === "A" || w === "B") { d.betStats.gain -= bet; msg = `§7はずれ…… ${gold(bet)} は 闘技場の ものに なった。`; try { p.playSound("mob.villager.no", { volume: 1 }); } catch {} }
  else { d.gold += bet; msg = `§7引き分け（時間切れ）。かけた ${gold(bet)} は もどってきた。`; }
  save(p, d);
  await notice(p, "モンスター闘技場", [`${w === "A" ? "§c赤コーナー" : w === "B" ? "§9青コーナー" : "§7どちらも"} §fの ${w === "A" ? SPECIES[mA.sp].name : w === "B" ? SPECIES[mB.sp].name : ""}${w === "A" || w === "B" ? " の 勝ち！" : " 決着が つかなかった"}`, "", msg, "",
    `§7これまで: ${d.betStats.n}戦 ${d.betStats.win}勝・いちばんの 当たり ${gold(d.betStats.best)}・トータル ${d.betStats.gain >= 0 ? "+" : ""}${d.betStats.gain}`].join("\n"));
}

// v2.9.12: かけの とちゅうで ワールドを 閉じた・ぬけた ときは 次に 入った とき かけ金を 返す
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => { if (!initialSpawn) return; system.runTimeout(() => { try { const d = load(p); if (d && typeof d.betPend === "number" && d.betPend > 0) { const b = d.betPend, go = !!d.betGo; delete d.betPend; delete d.betGo; if (!go) d.gold += b; else { d.betStats = d.betStats || { n: 0, win: 0, best: 0, gain: 0 }; d.betStats.n++; d.betStats.gain -= b; } save(p, d); p.sendMessage(go ? `§7闘技場の 試合の とちゅうで ぬけたので、かけた ${b} は もどらなかった。` : `§7闘技場の かけが 始まる 前に 終わったので ${b} を 返した。`); } } catch {} }, 60); }); } catch {}
