// v1.7: 戦闘の ステージ（まわりを 一時的に 闘技場や フィールドの 背景に 変えて、終わったら もとに 戻す）
import { barNote } from "./ui.js";
import { world, system, BlockPermutation } from "@minecraft/server";

const wait = (t) => new Promise((r) => system.runTimeout(r, t));
function run(dim, c) { try { if (typeof dim.runCommand === "function") dim.runCommand(c); else dim.runCommandAsync(c); } catch {} }
// v1.7: ブロックの 名前を バージョンに あわせて 選ぶ（使えない 名前だと 何も 置かれないため）
const ALIAS = {
  stone_bricks: ["stone_bricks", "stonebrick"], smooth_stone: ["smooth_stone", "stone"], smooth_sandstone: ["smooth_sandstone", "sandstone"],
  red_sandstone: ["red_sandstone", "sandstone"], chiseled_red_sandstone: ["chiseled_red_sandstone", "red_sandstone", "sandstone"], cut_red_sandstone: ["cut_red_sandstone", "red_sandstone", "sandstone"],
  cut_sandstone: ["cut_sandstone", "sandstone"], chiseled_sandstone: ["chiseled_sandstone", "sandstone"], quartz_bricks: ["quartz_bricks", "quartz_block"],
  moss_block: ["moss_block", "grass_block", "grass"], grass_block: ["grass_block", "grass"], coarse_dirt: ["coarse_dirt", "dirt"], podzol: ["podzol", "dirt"],
  oak_fence: ["oak_fence", "fence"], oak_leaves: ["oak_leaves", "leaves"], spruce_leaves: ["spruce_leaves", "leaves"], jungle_leaves: ["jungle_leaves", "leaves"],
  oak_log: ["oak_log", "log"], spruce_log: ["spruce_log", "log"], jungle_log: ["jungle_log", "log"], stripped_oak_log: ["stripped_oak_log", "oak_log", "log"], stripped_birch_log: ["stripped_birch_log", "birch_log", "log"],
  andesite: ["andesite", "stone"], polished_andesite: ["polished_andesite", "andesite", "stone"], cobblestone_wall: ["cobblestone_wall", "cobblestone"], sandstone_wall: ["sandstone_wall", "sandstone"],
  mossy_cobblestone: ["mossy_cobblestone", "cobblestone"], end_stone_bricks: ["end_stone_bricks", "end_bricks", "end_stone"], end_stone_brick_wall: ["end_stone_brick_wall", "end_stone"],
  purpur_pillar: ["purpur_pillar", "purpur_block"], cobbled_deepslate_wall: ["cobbled_deepslate_wall", "cobbled_deepslate"], snow: ["snow", "snow_block"], snow_layer: ["snow_layer"],
  red_wool: ["red_wool", "wool"], yellow_wool: ["yellow_wool", "wool"], blue_wool: ["blue_wool", "wool"], white_wool: ["white_wool", "wool"],
  poppy: ["poppy", "red_flower"], dandelion: ["dandelion", "yellow_flower"], cornflower: ["cornflower", "red_flower"], oxeye_daisy: ["oxeye_daisy", "red_flower"], fern: ["fern", "short_grass", "tallgrass"],
  deadbush: ["deadbush", "dead_bush"], melon_block: ["melon_block"], bamboo_fence: ["bamboo_fence", "oak_fence", "fence"], mangrove_fence: ["mangrove_fence", "oak_fence", "fence"],
};
const BCACHE = {};
export function bk(id) {
  if (BCACHE[id]) return BCACHE[id];
  for (const c of ALIAS[id] || [id]) { try { BlockPermutation.resolve(`minecraft:${c}`); return (BCACHE[id] = c); } catch {} }
  return (BCACHE[id] = id === "air" ? "air" : "stone");
}
// コマンドの 最後の ブロック名を 置きかえる（fill ... <block> [replace air] / setblock ... <block>）
function fixCmd(c) {
  const t = c.split(" ");
  const i = t[t.length - 2] === "replace" ? t.length - 3 : t.length - 1;
  if (t[0] === "fill" || t[0] === "setblock") t[i] = bk(t[i]);
  return t.join(" ");
}

// ---- 落ちても 戻せるように、作った ステージを 記録 ----
const PKEY = "mrpg:stages";
function pending() { try { return JSON.parse(world.getDynamicProperty(PKEY) || "[]"); } catch { return []; } }
function setPending(l) { try { world.setDynamicProperty(PKEY, JSON.stringify(l)); } catch {} }
// v2.9.12: 戦いの ステージが 近くに ある あいだは 建物を 作らない（戦いの あとで 元の 地面に もどされて 建物が 欠ける）
export function stageNear(x, z, r = 140) { try { return pending().some((q) => q.dim === "minecraft:overworld" && Math.hypot((q.x1 + q.x2) / 2 - x, (q.z1 + q.z2) / 2 - z) < r); } catch { return false; } }
export function addPending(st) { const l = pending().filter((x) => x.name !== st.name); l.push({ name: st.name, dim: st.dim.id, x1: st.x1, y1: st.y1, z1: st.z1, x2: st.x2, z2: st.z2 }); setPending(l); }
export function dropPending(name) { setPending(pending().filter((x) => x.name !== name)); }
// v2.9.12: いま 戦いで 使って いる 場所（名前 → 箱）。ここに ない 記録は 読みこまれたら もとに もどす
export const LIVE = new Map();
export function liveAdd(st) { try { LIVE.set(st.name, { dim: typeof st.dim === "string" ? st.dim : st.dim.id, x1: st.x1, x2: st.x2, z1: st.z1, z2: st.z2, y1: st.y1, y2: st.y2 ?? st.y1 + 40 }); } catch {} }
const hit = (a, b, m = 2) => a.dim === b.dim && a.x1 <= b.x2 + m && a.x2 >= b.x1 - m && a.z1 <= b.z2 + m && a.z2 >= b.z1 - m;
// 箱が ほかの 戦いの 箱（記録・予約）と 重ならないか
export function boxFree(box, extra = []) { try { for (const q of pending()) if (hit(box, q)) return false; for (const q of LIVE.values()) if (hit(box, q)) return false; for (const q of extra) if (q && hit(box, q)) return false; } catch {} return true; }
export function inLiveBox(dimId, loc) { for (const q of LIVE.values()) if (q.dim === dimId && loc.x >= q.x1 && loc.x <= q.x2 + 1 && loc.z >= q.z1 && loc.z <= q.z2 + 1 && loc.y >= (q.y1 ?? -64) - 1 && loc.y <= (q.y2 ?? 320) + 1) return true; return false; }
export function areaLoaded(dim, s) { for (const [x, z] of [[s.x1, s.z1], [s.x2, s.z1], [s.x1, s.z2], [s.x2, s.z2]]) { try { if (!dim.getBlock({ x, y: s.y1, z })) return false; } catch { return false; } } return true; }
// 戦いが 終わった あと 読みこまれて いなかった 場所も、読みこまれたら もどす
system.runInterval(() => {
  for (const s0 of pending()) {
    if (LIVE.has(s0.name) || (BOOT && BOOT.includes(s0.name))) continue;
    try { const dim = world.getDimension(s0.dim); if (typeof s0.x2 !== "number" || !areaLoaded(dim, s0)) continue;
      run(dim, `structure load ${s0.name} ${s0.x1} ${s0.y1} ${s0.z1} 0_degrees none false true`); run(dim, `structure delete ${s0.name}`); dropPending(s0.name); } catch {}
  }
}, 200);
// 戦いの 場所では ブロックを こわす・置く・箱を 開ける・爆発を させない（終わると もとに もどるので ふえたり 消えたり する）
try {
  world.beforeEvents.playerBreakBlock.subscribe((ev) => { try { if (inLiveBox(ev.block.dimension.id, ev.block.location)) ev.cancel = true; } catch {} });
  world.beforeEvents.playerPlaceBlock?.subscribe((ev) => { try { if (inLiveBox(ev.block.dimension.id, ev.block.location)) ev.cancel = true; } catch {} });
  world.beforeEvents.playerInteractWithBlock.subscribe((ev) => { try { const b = ev.block; if (b && /chest|barrel|shulker|hopper|dropper|dispenser|furnace|smoker/.test(String(b.typeId)) && inLiveBox(b.dimension.id, b.location)) ev.cancel = true; } catch {} });
  world.beforeEvents.explosion?.subscribe((ev) => { try { const bl = ev.getImpactedBlocks(); if (bl.some((b) => inLiveBox(ev.dimension.id, b.location))) ev.cancel = true; } catch {} });
} catch {}
// ワールドを 開いたとき: 前回 戻せなかった ステージを 戻す
// v2.9.9: その 場所が 読みこまれて いる ときだけ 戻す（読みこまれて いないと 戻せずに 記録だけ 消えて いた）
let BOOT = null;
system.runTimeout(() => { BOOT = pending().map((x) => x.name); }, 100);
system.runInterval(() => {
  if (!BOOT || !BOOT.length) return;
  for (const s of pending()) {
    if (!BOOT.includes(s.name)) continue;
    try {
      const dim = world.getDimension(s.dim);
      // 4すみ ぜんぶが 読みこまれて いる ときだけ（古い 記録は 1すみ ＋ 64ブロック先まで 見る）
      const X2 = typeof s.x2 === "number" ? s.x2 : s.x1 + 64, Z2 = typeof s.z2 === "number" ? s.z2 : s.z1 + 64;
      let here = true;
      for (const [x, z] of [[s.x1, s.z1], [X2, s.z1], [s.x1, Z2], [X2, Z2]]) { try { if (!dim.getBlock({ x, y: s.y1, z })) here = false; } catch { here = false; } }
      if (!here) continue;
      run(dim, `structure load ${s.name} ${s.x1} ${s.y1} ${s.z1} 0_degrees none false true`);
      run(dim, `structure delete ${s.name}`);
      dropPending(s.name); BOOT = BOOT.filter((n) => n !== s.name);
    } catch {}
  }
}, 100);

// ---- テーマ（フィールドごとの 背景）----
export const THEMES = {
  arena: { floor: "smooth_sandstone", acc: "red_sandstone", ring: "chiseled_red_sandstone", wall: "cut_red_sandstone", pillar: "quartz_bricks", top: "lantern", flag: ["red_wool", "yellow_wool", "blue_wool", "white_wool"], stands: "smooth_stone_slab", name: "闘技場" },
  plains: { floor: "grass_block", acc: "moss_block", ring: "coarse_dirt", wall: "oak_fence", pillar: "stripped_oak_log", top: "lantern", deco: ["poppy", "dandelion", "cornflower", "oxeye_daisy"], name: "草原" },
  forest: { floor: "moss_block", acc: "grass_block", ring: "podzol", wall: "oak_leaves", pillar: "oak_log", top: "oak_leaves", deco: ["fern", "brown_mushroom", "red_mushroom"], name: "森" },
  taiga: { floor: "podzol", acc: "moss_block", ring: "coarse_dirt", wall: "spruce_leaves", pillar: "spruce_log", top: "spruce_leaves", deco: ["fern", "fern", "brown_mushroom"], name: "針葉樹の 森" },
  jungle: { floor: "moss_block", acc: "grass_block", ring: "mud", wall: "jungle_leaves", pillar: "jungle_log", top: "jungle_leaves", deco: ["fern", "melon_block"], name: "ジャングル" },
  desert: { floor: "sand", acc: "smooth_sandstone", ring: "cut_sandstone", wall: "sandstone_wall", pillar: "chiseled_sandstone", top: "lantern", deco: ["deadbush"], name: "砂漠" },
  snow: { floor: "snow", acc: "packed_ice", ring: "blue_ice", wall: "packed_ice", pillar: "packed_ice", top: "sea_lantern", deco: ["snow_layer"], name: "雪原" },
  mountain: { floor: "stone", acc: "andesite", ring: "polished_andesite", wall: "cobblestone_wall", pillar: "stone_bricks", top: "lantern", deco: ["mossy_cobblestone"], name: "山" },
  swamp: { floor: "mud", acc: "moss_block", ring: "mud_bricks", wall: "mangrove_fence", pillar: "mangrove_log", top: "ochre_froglight", deco: ["lily_pad"], name: "沼地" },
  cave: { floor: "deepslate_tiles", acc: "tuff", ring: "polished_deepslate", wall: "cobbled_deepslate_wall", pillar: "deepslate_bricks", top: "glowstone", deco: ["amethyst_cluster"], name: "洞くつ" },
  beach: { floor: "sand", acc: "sandstone", ring: "smooth_sandstone", wall: "bamboo_fence", pillar: "stripped_birch_log", top: "sea_lantern", deco: ["sea_pickle"], name: "砂浜" },
  nether: { floor: "blackstone", acc: "crimson_nylium", ring: "polished_blackstone_bricks", wall: "nether_brick_fence", pillar: "basalt", top: "shroomlight", deco: ["crimson_roots"], name: "ネザー" },
  end: { floor: "end_stone", acc: "end_stone_bricks", ring: "purpur_block", wall: "end_stone_brick_wall", pillar: "purpur_pillar", top: "end_rod", deco: ["chorus_flower"], name: "エンド" },
  // v2.2: ステージ 20種＋閻魔の 裁き場
  cherry: {"floor": "grass_block", "acc": "moss_block", "ring": "cherry_planks", "wall": "cherry_fence", "pillar": "cherry_log", "top": "cherry_leaves", "deco": ["pink_petals", "pink_tulip"], "name": "桜の 森"},
  savanna: {"floor": "grass_block", "acc": "coarse_dirt", "ring": "acacia_planks", "wall": "acacia_fence", "pillar": "acacia_log", "top": "lantern", "deco": ["short_grass", "dandelion"], "name": "サバンナ"},
  badlands: {"floor": "red_sand", "acc": "hardened_clay", "ring": "orange_terracotta", "wall": "red_sandstone_wall", "pillar": "red_sandstone", "top": "lantern", "deco": ["deadbush"], "name": "荒野"},
  birch: {"floor": "grass_block", "acc": "moss_block", "ring": "birch_planks", "wall": "birch_fence", "pillar": "birch_log", "top": "birch_leaves", "deco": ["lily_of_the_valley", "allium"], "name": "白樺の 森"},
  darkforest: {"floor": "podzol", "acc": "moss_block", "ring": "dark_oak_planks", "wall": "dark_oak_leaves", "pillar": "dark_oak_log", "top": "dark_oak_leaves", "deco": ["brown_mushroom", "red_mushroom"], "name": "暗い 森"},
  meadow: {"floor": "grass_block", "acc": "moss_block", "ring": "coarse_dirt", "wall": "spruce_fence", "pillar": "stripped_spruce_log", "top": "lantern", "deco": ["allium", "azure_bluet", "cornflower", "oxeye_daisy"], "name": "花畑"},
  icepeak: {"floor": "packed_ice", "acc": "blue_ice", "ring": "snow", "wall": "packed_ice", "pillar": "blue_ice", "top": "sea_lantern", "name": "氷の 峰"},
  dripstone: {"floor": "dripstone_block", "acc": "tuff", "ring": "calcite", "wall": "cobbled_deepslate_wall", "pillar": "dripstone_block", "top": "glowstone", "name": "鍾乳洞"},
  lush: {"floor": "moss_block", "acc": "moss_block", "ring": "clay", "wall": "azalea_leaves", "pillar": "oak_log", "top": "ochre_froglight", "deco": ["azalea", "flowering_azalea"], "name": "緑の 洞くつ"},
  deepdark: {"floor": "sculk", "acc": "deepslate_tiles", "ring": "polished_deepslate", "wall": "cobbled_deepslate_wall", "pillar": "deepslate_bricks", "top": "soul_lantern", "name": "深淵の 洞"},
  ruins: {"floor": "prismarine", "acc": "dark_prismarine", "ring": "prismarine_bricks", "wall": "prismarine_wall", "pillar": "prismarine_bricks", "top": "sea_lantern", "name": "海底遺跡"},
  mushroom: {"floor": "mycelium", "acc": "brown_mushroom_block", "ring": "red_mushroom_block", "wall": "mushroom_stem", "pillar": "mushroom_stem", "top": "red_mushroom_block", "deco": ["red_mushroom", "brown_mushroom"], "name": "キノコ島"},
  soulvalley: {"floor": "soul_soil", "acc": "soul_sand", "ring": "polished_basalt", "wall": "nether_brick_fence", "pillar": "bone_block", "top": "soul_lantern", "name": "魂の 谷"},
  warped: {"floor": "warped_nylium", "acc": "warped_wart_block", "ring": "warped_planks", "wall": "warped_fence", "pillar": "warped_stem", "top": "shroomlight", "deco": ["warped_roots", "warped_fungus"], "name": "歪んだ 森"},
  crimson: {"floor": "crimson_nylium", "acc": "nether_wart_block", "ring": "crimson_planks", "wall": "crimson_fence", "pillar": "crimson_stem", "top": "shroomlight", "deco": ["crimson_roots", "crimson_fungus"], "name": "真紅の 森"},
  basalt: {"floor": "blackstone", "acc": "basalt", "ring": "smooth_basalt", "wall": "blackstone_wall", "pillar": "polished_basalt", "top": "shroomlight", "name": "玄武岩の 三角州"},
  endcity: {"floor": "purpur_block", "acc": "end_stone_bricks", "ring": "purpur_pillar", "wall": "end_stone_brick_wall", "pillar": "purpur_pillar", "top": "end_rod", "name": "エンドの 都"},
  shrine: {"floor": "spruce_planks", "acc": "dark_oak_planks", "ring": "stripped_spruce_log", "wall": "spruce_fence", "pillar": "red_concrete", "top": "lantern", "flag": ["red_wool", "white_wool"], "name": "神社"},
  sky: {"floor": "white_concrete", "acc": "quartz_block", "ring": "light_blue_concrete", "wall": "glass", "pillar": "quartz_pillar", "top": "end_rod", "name": "雲の上"},
  volcano: {"floor": "smooth_basalt", "acc": "obsidian", "ring": "crying_obsidian", "wall": "blackstone_wall", "pillar": "basalt", "top": "shroomlight", "name": "火山"},
  hell: {"floor": "polished_blackstone_bricks", "acc": "crying_obsidian", "ring": "red_nether_brick", "wall": "red_nether_brick_wall", "pillar": "crying_obsidian", "top": "soul_lantern", "deco": ["soul_torch"], "flag": ["red_wool", "black_wool"], "name": "閻魔の 裁き場"},
};
// v3.0: 地上の 戦いの 背景は 地方に あわせる（火山帯なら 火山、雪山なら 雪原 など）。洞くつの 中は バイオームの まま
const REGION_THEME = { arca: ["plains", "meadow", "forest", "cherry", "plains"], silva: ["forest", "darkforest", "swamp", "mushroom", "jungle"], ruins: ["badlands", "mountain", "badlands"],
  volka: ["volcano", "volcano", "basalt"], sand: ["desert", "desert", "badlands"], crys: ["dripstone", "icepeak", "cave"], mari: ["beach", "beach", "jungle"],
  necro: ["soulvalley", "deepdark", "soulvalley"], frost: ["snow", "icepeak", "taiga"], ragna: ["crimson", "warped", "basalt", "volcano"], celes: ["sky", "sky", "cherry", "meadow"] };
export function themeOf(biome, dimId, regionId = null) {
  const b = String(biome || "plains");
  const r = (l) => l[Math.floor(Math.random() * l.length)];
  if (regionId && REGION_THEME[regionId] && (!dimId || dimId === "minecraft:overworld") && !/cave|deep_dark|dripstone|lush/.test(b)) return r(REGION_THEME[regionId]);
  if (dimId === "minecraft:nether") return /soul/.test(b) ? "soulvalley" : /warped/.test(b) ? "warped" : /crimson/.test(b) ? "crimson" : /basalt/.test(b) ? "basalt" : r(["nether", "nether", "volcano"]);
  if (dimId === "minecraft:the_end") return r(["end", "endcity"]);
  if (/cherry/.test(b)) return "cherry";
  if (/mushroom/.test(b)) return "mushroom";
  if (/deep_dark/.test(b)) return "deepdark";
  if (/dripstone/.test(b)) return "dripstone";
  if (/lush/.test(b)) return "lush";
  if (/badland|mesa/.test(b)) return "badlands";
  if (/savanna/.test(b)) return "savanna";
  if (/desert/.test(b)) return "desert";
  if (/ice_spikes|frozen_peaks|jagged/.test(b)) return "icepeak";
  if (/snow|ice|frozen|cold/.test(b)) return "snow";
  if (/jungle|bamboo/.test(b)) return "jungle";
  if (/taiga|spruce|pine/.test(b)) return "taiga";
  if (/birch/.test(b)) return "birch";
  if (/dark_forest|roofed/.test(b)) return "darkforest";
  if (/meadow/.test(b)) return "meadow";
  if (/forest|grove/.test(b)) return "forest";
  if (/swamp|mangrove/.test(b)) return "swamp";
  if (/mountain|peak|hill|stony|slope/.test(b)) return r(["mountain", "mountain", "volcano"]);
  if (/cave|deep/.test(b)) return "cave";
  if (/ocean/.test(b)) return "ruins";
  if (/beach|shore|river/.test(b)) return "beach";
  return r(["plains", "plains", "plains", "meadow", "shrine", "sky"]);
}

// ---- ステージを 作る ----
// opts: { lite, stands, keep(=記録しない・常設) }
let seq = 1;
export async function buildStage(dim, cx, fy, cz, R, theme, opts = {}) {
  const T = THEMES[theme] || THEMES.plains;
  cx = Math.floor(cx); cz = Math.floor(cz); fy = Math.floor(fy);
  const stands = opts.stands && !opts.lite;
  const H = opts.H || 9;
  // v2.9: ドーム（その ステージ固有の 大きな 背景）。巨大モンスターの カメラでも かべに めりこまない 広さ
  const dome = !!opts.dome && fy + (opts.lite ? 13 : 17) + 2 <= 318 && fy - 2 >= -62;   // v2.9.2: 高さの 範囲を こえる ときは ドームなし
  const Rw = dome ? R + (opts.lite ? 7 : 10) : 0, Hc = dome ? (opts.lite ? 13 : 17) : 0;
  const out = dome ? Rw + 1 : R + (stands ? 6 : 3);
  const x1 = cx - out, x2 = cx + out, z1 = cz - out, z2 = cz + out, y1 = fy - 2, y2 = Math.min(318, fy + (dome ? Hc + 2 : H + 3));
  { let hr = null; try { hr = dim.heightRange; } catch {} const lo = hr ? hr.min : dim.id === "minecraft:nether" ? 0 : -64, hi = hr ? hr.max - 1 : dim.id === "minecraft:nether" ? 127 : 319;
    if (y1 <= lo || y2 >= hi) return null; }   // v2.9.12: 世界の 高さの 範囲を こえる ときは ステージを 作らない（岩盤を こわさない）
  const st = { name: `mrpg_stage_${Date.now() % 100000}_${seq++}`, dim, x1, y1, z1, x2, z2, y2, theme, cx, cz, fy, R };
  if (!opts.keep) { run(dim, `structure save ${st.name} ${x1} ${y1} ${z1} ${x2} ${y2} ${z2} false disk true`); addPending(st); liveAdd(st); }
  const C = [];
  const rowX = (z, r) => Math.floor(Math.sqrt(Math.max(0, r * r - z * z)));
  // 1) 中を からっぽに（木や 草を どける）
  for (let z = -out; z <= out; z++) { const xo = rowX(z, out); if (xo) C.push(`fill ${cx - xo} ${fy} ${cz + z} ${cx + xo} ${y2 - 1} ${cz + z} air`); }
  // 2) たいらな 床（ふち・中央の もよう）
  for (let z = -out; z <= out; z++) {
    const xo = rowX(z, out); if (!xo) continue;
    C.push(`fill ${cx - xo} ${fy - 1} ${cz + z} ${cx + xo} ${fy - 1} ${cz + z} ${T.floor}`);
    C.push(`fill ${cx - xo} ${fy - 2} ${cz + z} ${cx + xo} ${fy - 2} ${cz + z} ${["nether", "soulvalley", "warped", "crimson", "basalt", "hell", "volcano"].includes(theme) ? "netherrack" : ["end", "endcity"].includes(theme) ? "end_stone" : theme === "sky" ? "white_concrete" : "dirt"} replace air`);
  }
  for (const r of [R - 0.5, 3.5]) for (let a = 0; a < 72; a++) { const x = Math.round(cx + Math.cos(a * Math.PI / 36) * r), z = Math.round(cz + Math.sin(a * Math.PI / 36) * r); C.push(`setblock ${x} ${fy - 1} ${z} ${T.ring}`); }
  for (let z = -2; z <= 2; z++) { const xo = rowX(z, 2.5); C.push(`fill ${cx - xo} ${fy - 1} ${cz + z} ${cx + xo} ${fy - 1} ${cz + z} ${T.acc}`); }
  // 3) かべ と 柱
  const wallR = R + 1.5, n = Math.max(48, Math.round(wallR * 6.3));
  const done = new Set();
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2, x = Math.round(cx + Math.cos(a) * wallR), z = Math.round(cz + Math.sin(a) * wallR);
    if (done.has(`${x},${z}`)) continue; done.add(`${x},${z}`);
    C.push(`fill ${x} ${fy} ${z} ${x} ${fy + (theme === "arena" ? 2 : 1)} ${z} ${T.wall}`);
  }
  const np = opts.lite ? 6 : 10;
  for (let i = 0; i < np; i++) {
    const a = (i / np) * Math.PI * 2, x = Math.round(cx + Math.cos(a) * (wallR + 0.5)), z = Math.round(cz + Math.sin(a) * (wallR + 0.5));
    const ph = theme === "arena" ? 6 : 4;
    C.push(`fill ${x} ${fy} ${z} ${x} ${fy + ph} ${z} ${T.pillar}`);
    C.push(`setblock ${x} ${fy + ph + 1} ${z} ${T.top}`);
    if (T.flag) { C.push(`setblock ${x} ${fy + ph - 1} ${z + (z > cz ? -1 : 1)} ${T.flag[i % T.flag.length]}`); C.push(`setblock ${x} ${fy + ph - 2} ${z + (z > cz ? -1 : 1)} ${T.flag[i % T.flag.length]}`); }
  }
  // 4) 観客席（闘技場）
  if (stands) {
    for (let k = 0; k < 4; k++) {
      const r = wallR + 1.5 + k, m = Math.round(r * 6.3);
      for (let i = 0; i < m; i++) { const a = (i / m) * Math.PI * 2, x = Math.round(cx + Math.cos(a) * r), z = Math.round(cz + Math.sin(a) * r); C.push(`fill ${x} ${fy} ${z} ${x} ${fy + k} ${z} ${k % 2 ? "stone_bricks" : "smooth_stone"}`); }
    }
  }
  // 5) かざり（草花など）
  if (T.deco && !opts.lite) for (let i = 0; i < 18; i++) {
    const a = Math.random() * Math.PI * 2, r = R - 1.5 + Math.random() * 1.2, x = Math.round(cx + Math.cos(a) * r), z = Math.round(cz + Math.sin(a) * r);
    const b = T.deco[i % T.deco.length];
    if (b === "lily_pad" || b === "sea_pickle") continue;
    C.push(`setblock ${x} ${fy} ${z} ${b}`);
  }
  if (dome) { const D = domeCmds(theme, T, cx, fy, cz, R, Rw, Hc, !!opts.lite); C.push(...D); st.dome = { r: Rw - 1.5, top: fy + Hc - 1 }; }
  st.cmds = C; st.T = T;
  const per = dome ? 140 : 80;
  for (let i = 0; i < C.length; i++) { run(dim, fixCmd(C[i])); if (i % per === per - 1) await wait(1); }
  // v2.6: できたか 確かめて、だめなら もう一度（読みこみ前・重い ときに 背景が 変わらない ことが あった）
  await wait(1);
  if (!stageOk(st)) { await waitLoaded(dim, [{ x: x1, z: z1 }, { x: x2, z: z2 }, { x: x1, z: z2 }, { x: x2, z: z1 }], 30); for (let i = 0; i < C.length; i++) { run(dim, fixCmd(C[i])); if (i % 140 === 139) await wait(1); } }
  return st;
}
// ---- v2.9: ドーム ----
// open: 空が 見える（あばら骨のような 骨組み）／ closed: 天井まで おおう。props: かべぎわの 景色
const OPEN = new Set(["plains", "meadow", "savanna", "desert", "badlands", "beach", "arena", "shrine", "cherry", "sky"]);
export const DOME = {
  arena: { shell: "cut_red_sandstone", rib: "quartz_bricks", light: "lantern", props: ["banner", "banner", "pillarq"] },
  plains: { shell: "stripped_oak_log", rib: "oak_log", light: "lantern", props: ["tree:oak_log:oak_leaves", "boulder:mossy_cobblestone", "hay"] },
  meadow: { shell: "stripped_spruce_log", rib: "spruce_log", light: "lantern", props: ["tree:spruce_log:spruce_leaves", "flowers", "boulder:mossy_cobblestone"] },
  savanna: { shell: "acacia_log", rib: "acacia_log", light: "lantern", props: ["flat:acacia_log:acacia_leaves", "boulder:coarse_dirt", "flat:acacia_log:acacia_leaves"] },
  desert: { shell: "cut_sandstone", rib: "chiseled_sandstone", light: "lantern", props: ["cactus", "dune", "pillar:sandstone_wall"] },
  badlands: { shell: "red_sandstone", rib: "orange_terracotta", light: "lantern", props: ["mesa:orange_terracotta:white_terracotta", "mesa:red_terracotta:yellow_terracotta", "deadbush"] },
  beach: { shell: "stripped_birch_log", rib: "birch_log", light: "sea_lantern", props: ["palm", "boulder:sandstone", "palm"] },
  shrine: { shell: "spruce_planks", rib: "red_concrete", light: "lantern", props: ["torii", "stonelantern", "tree:cherry_log:cherry_leaves"] },
  cherry: { shell: "cherry_planks", rib: "cherry_log", light: "lantern", props: ["tree:cherry_log:cherry_leaves", "tree:cherry_log:cherry_leaves", "flowers"] },
  sky: { shell: "glass", rib: "quartz_pillar", light: "end_rod", props: ["cloud", "cloud", "pillarq"] },
  forest: { shell: "oak_log", cap: "oak_leaves", light: "ochre_froglight", props: ["tree:oak_log:oak_leaves", "tree:birch_log:birch_leaves", "mushroom"] },
  taiga: { shell: "spruce_log", cap: "spruce_leaves", light: "lantern", props: ["tree:spruce_log:spruce_leaves", "boulder:mossy_cobblestone", "tree:spruce_log:spruce_leaves"] },
  jungle: { shell: "jungle_log", cap: "jungle_leaves", light: "ochre_froglight", props: ["tree:jungle_log:jungle_leaves", "vine", "tree:jungle_log:jungle_leaves"] },
  birch: { shell: "birch_log", cap: "birch_leaves", light: "lantern", props: ["tree:birch_log:birch_leaves", "flowers", "tree:birch_log:birch_leaves"] },
  darkforest: { shell: "dark_oak_log", cap: "dark_oak_leaves", light: "shroomlight", props: ["tree:dark_oak_log:dark_oak_leaves", "bigshroom", "tree:dark_oak_log:dark_oak_leaves"] },
  swamp: { shell: "mangrove_log", cap: "mangrove_leaves", light: "ochre_froglight", props: ["tree:mangrove_log:mangrove_leaves", "pond", "tree:mangrove_log:mangrove_leaves"] },
  lush: { shell: "moss_block", cap: "azalea_leaves", light: "ochre_froglight", props: ["tree:oak_log:flowering_azalea_leaves", "crystal:amethyst_block", "pond"] },
  mushroom: { shell: "mushroom_stem", cap: "red_mushroom_block", light: "shroomlight", props: ["bigshroom", "bigshroom", "boulder:mycelium"] },
  snow: { shell: "packed_ice", cap: "packed_ice", win: "blue_ice", light: "sea_lantern", props: ["spike:packed_ice", "tree:spruce_log:snow", "spike:blue_ice"] },
  icepeak: { shell: "blue_ice", cap: "packed_ice", win: "glass", light: "sea_lantern", props: ["spike:blue_ice", "spike:packed_ice", "spike:packed_ice"] },
  mountain: { shell: "stone", cap: "stone", win: "glass", light: "lantern", props: ["spike:stone", "boulder:andesite", "tree:spruce_log:spruce_leaves"] },
  cave: { shell: "deepslate", cap: "deepslate", light: "glowstone", props: ["spike:tuff", "crystal:amethyst_block", "spike:deepslate"] },
  dripstone: { shell: "dripstone_block", cap: "dripstone_block", light: "glowstone", props: ["spike:dripstone_block", "spike:calcite", "crystal:amethyst_block"] },
  deepdark: { shell: "deepslate_tiles", cap: "sculk", light: "soul_lantern", props: ["spike:sculk", "spike:deepslate_bricks", "crystal:sculk_catalyst"] },
  ruins: { shell: "prismarine_bricks", cap: "dark_prismarine", win: "glass", light: "sea_lantern", props: ["pillar:prismarine_bricks", "kelp", "pillar:dark_prismarine"] },
  nether: { shell: "netherrack", cap: "netherrack", light: "shroomlight", props: ["fungus:crimson_stem:nether_wart_block", "spike:magma", "spike:basalt"] },
  crimson: { shell: "crimson_nylium", cap: "nether_wart_block", light: "shroomlight", props: ["fungus:crimson_stem:nether_wart_block", "fungus:crimson_stem:nether_wart_block", "spike:magma"] },
  warped: { shell: "warped_nylium", cap: "warped_wart_block", light: "shroomlight", props: ["fungus:warped_stem:warped_wart_block", "fungus:warped_stem:warped_wart_block", "spike:basalt"] },
  soulvalley: { shell: "soul_soil", cap: "basalt", light: "soul_lantern", props: ["spike:bone_block", "soulfire", "spike:bone_block"] },
  basalt: { shell: "blackstone", cap: "basalt", light: "shroomlight", props: ["spike:basalt", "spike:polished_basalt", "spike:magma"] },
  volcano: { shell: "blackstone", cap: "basalt", light: "shroomlight", props: ["spike:magma", "spike:obsidian", "spike:basalt"] },
  hell: { shell: "red_nether_brick", cap: "crying_obsidian", light: "soul_lantern", props: ["spike:crying_obsidian", "soulfire", "spike:red_nether_brick"] },
  end: { shell: "end_stone", cap: "end_stone_bricks", win: "purple_stained_glass", light: "end_rod", props: ["spike:obsidian", "chorus", "spike:obsidian"] },
  endcity: { shell: "purpur_block", cap: "purpur_block", win: "magenta_stained_glass", light: "end_rod", props: ["pillar:purpur_pillar", "chorus", "pillar:end_stone_bricks"] },
};
function domeCmds(theme, T, cx, fy, cz, R, Rw, Hc, lite) {
  const S = DOME[theme] || { shell: T.pillar || "stone", cap: T.acc || "stone", light: T.top || "lantern", props: ["boulder:" + (T.acc || "stone")] };
  const open = OPEN.has(theme) || !S.cap;
  const C = [];
  const Hw = open ? 6 : 9;
  const rAt = (dy) => dy <= Hw ? Rw : Rw * Math.sqrt(Math.max(0, 1 - ((dy - Hw) / (Hc - Hw + 0.6)) ** 2));
  const rowX = (z, r) => (Math.abs(z) > r ? -1 : Math.floor(Math.sqrt(Math.max(0, r * r - z * z))));
  // 外側の 床（ふちの 帯）
  for (let z = -Rw; z <= Rw; z++) { const xo = rowX(z, Rw), xi = rowX(z, R + 2); if (xo < 0) continue; if (xi < 0) C.push(`fill ${cx - xo} ${fy - 1} ${cz + z} ${cx + xo} ${fy - 1} ${cz + z} ${T.acc}`); else { C.push(`fill ${cx - xo} ${fy - 1} ${cz + z} ${cx - xi - 1} ${fy - 1} ${cz + z} ${T.acc}`); C.push(`fill ${cx + xi + 1} ${fy - 1} ${cz + z} ${cx + xo} ${fy - 1} ${cz + z} ${T.acc}`); } }
  if (open) {
    // かべ（低め）＋ 骨組み（8本の あばら）＋ てっぺんの 輪
    const n = Math.round(Rw * 7.5), seen = new Set();
    for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2, x = Math.round(cx + Math.cos(a) * Rw), z = Math.round(cz + Math.sin(a) * Rw); if (seen.has(x * 9999 + z)) continue; seen.add(x * 9999 + z); C.push(`fill ${x} ${fy} ${z} ${x} ${fy + Hw - 1} ${z} ${S.shell}`); }
    const ribs = lite ? 6 : 10;
    for (let k = 0; k < ribs; k++) {
      const a = (k / ribs) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
      for (let dy = Hw; dy <= Hc; dy++) { const r0 = rAt(dy + 1), r1 = rAt(dy); for (let r = Math.floor(r0); r <= Math.ceil(r1); r++) C.push(`setblock ${Math.round(cx + ca * r)} ${fy + dy} ${Math.round(cz + sa * r)} ${S.rib}`); }
      C.push(`setblock ${Math.round(cx + ca * (Rw - 1))} ${fy + Hw} ${Math.round(cz + sa * (Rw - 1))} ${ceilLight(S.light)}`);   // v3.0: 下に 支えが ない（ランタンは 落ちる）
    }
    for (let a = 0; a < 48; a++) C.push(`setblock ${Math.round(cx + Math.cos(a * Math.PI / 24) * 3)} ${fy + Hc} ${Math.round(cz + Math.sin(a * Math.PI / 24) * 3)} ${S.rib}`);
  } else {
    // かべ（円筒）＋ 丸天井（1段ずつ 輪を かさねる）。ところどころ 窓と 明かり
    for (let dy = 0; dy <= Hc; dy++) {
      const ro = dy <= Hw ? Rw : rAt(dy), ri = dy < Hw ? Rw - 1 : rAt(dy + 1) - 1;
      const blk = S.win && dy >= Hw - 3 && dy <= Hw - 1 ? S.win : dy > Hw ? S.cap : S.shell;
      if (dy < Hw && dy > 0 && dy !== Hw - 1 && !(S.win && dy >= Hw - 3)) continue;   // 円筒の かべは あとで 柱ごとに
      for (let z = -Math.ceil(ro); z <= Math.ceil(ro); z++) {
        const xo = rowX(z, ro); if (xo < 0) continue; const xi = rowX(z, Math.max(0, ri));
        if (xi < 0 || ri <= 0) C.push(`fill ${cx - xo} ${fy + dy} ${cz + z} ${cx + xo} ${fy + dy} ${cz + z} ${blk}`);
        else { C.push(`fill ${cx - xo} ${fy + dy} ${cz + z} ${cx - xi} ${fy + dy} ${cz + z} ${blk}`); C.push(`fill ${cx + xi} ${fy + dy} ${cz + z} ${cx + xo} ${fy + dy} ${cz + z} ${blk}`); }
      }
    }
    const n = Math.round(Rw * 7.5), seen = new Set();
    for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; for (const rr of [Rw, Rw - 0.5]) { const x = Math.round(cx + Math.cos(a) * rr), z = Math.round(cz + Math.sin(a) * rr); if (seen.has(x * 9999 + z)) continue; seen.add(x * 9999 + z); C.push(`fill ${x} ${fy} ${z} ${x} ${fy + Hw - (S.win ? 4 : 1)} ${z} ${S.shell}`); } }
    // 天井の 明かり
    for (let k = 0; k < (lite ? 6 : 14); k++) { const a = (k / (lite ? 6 : 14)) * Math.PI * 2, rr = k % 2 ? Rw * 0.45 : Rw * 0.75, dy = Math.floor(Hw + (Hc - Hw) * Math.sqrt(Math.max(0, 1 - (rr / Rw) ** 2))); C.push(`setblock ${Math.round(cx + Math.cos(a) * rr)} ${fy + dy} ${Math.round(cz + Math.sin(a) * rr)} ${ceilLight(S.light)}`); }
    C.push(`setblock ${cx} ${fy + Hc} ${cz} ${ceilLight(S.light)}`);
  }
  // かべぎわの 景色（バトルの じゃまに ならない 外がわの 帯に）
  if (!lite) {
    const np = 14;
    for (let k = 0; k < np; k++) {
      const a = (k / np) * Math.PI * 2 + 0.2, rr = R + 3.5 + ((k * 7) % 5);
      const x = Math.round(cx + Math.cos(a) * rr), z = Math.round(cz + Math.sin(a) * rr);
      C.push(...prop(S.props[k % S.props.length], x, fy, z, k));
    }
  }
  return C;
}
function prop(spec, x, y, z, k) {
  const [kind, a, b] = String(spec).split(":"), C = [];
  const blob = (bx, by, bz, r, blk) => { for (let dy = -r; dy <= r; dy++) { const rr = Math.max(0, r - Math.abs(dy)); C.push(`fill ${bx - rr} ${by + dy} ${bz - rr} ${bx + rr} ${by + dy} ${bz + rr} ${blk} replace air`); } };
  const h = 3 + (k % 3);
  switch (kind) {
    case "tree": C.push(`fill ${x} ${y} ${z} ${x} ${y + h + 1} ${z} ${a}`); blob(x, y + h + 2, z, 2, b); break;
    case "flat": C.push(`fill ${x} ${y} ${z} ${x} ${y + h} ${z} ${a}`); C.push(`fill ${x - 2} ${y + h + 1} ${z - 2} ${x + 2} ${y + h + 1} ${z + 2} ${b} replace air`); break;
    case "palm": C.push(`fill ${x} ${y} ${z} ${x} ${y + h + 2} ${z} jungle_log`); C.push(`fill ${x - 2} ${y + h + 3} ${z} ${x + 2} ${y + h + 3} ${z} jungle_leaves replace air`); C.push(`fill ${x} ${y + h + 3} ${z - 2} ${x} ${y + h + 3} ${z + 2} jungle_leaves replace air`); break;
    case "fungus": C.push(`fill ${x} ${y} ${z} ${x} ${y + h + 1} ${z} ${a}`); C.push(`fill ${x - 2} ${y + h + 2} ${z - 2} ${x + 2} ${y + h + 2} ${z + 2} ${b} replace air`); C.push(`fill ${x - 1} ${y + h + 3} ${z - 1} ${x + 1} ${y + h + 3} ${z + 1} ${b} replace air`); C.push(`setblock ${x} ${y + h + 1} ${z + 1} shroomlight`); break;
    case "spike": C.push(`fill ${x - 1} ${y} ${z - 1} ${x + 1} ${y + 1} ${z + 1} ${a}`); C.push(`fill ${x} ${y + 2} ${z} ${x} ${y + h + 2} ${z} ${a}`); break;
    case "pillar": C.push(`fill ${x} ${y} ${z} ${x} ${y + h + 2} ${z} ${a}`); C.push(`setblock ${x} ${y + h + 3} ${z} lantern`); break;
    case "pillarq": C.push(`fill ${x} ${y} ${z} ${x} ${y + h + 2} ${z} quartz_pillar`); C.push(`setblock ${x} ${y + h + 3} ${z} end_rod`); break;
    case "boulder": blob(x, y, z, 1, a); break;
    case "crystal": C.push(`fill ${x} ${y} ${z} ${x} ${y + 2} ${z} ${a}`); C.push(`setblock ${x + 1} ${y} ${z} ${a}`); C.push(`setblock ${x} ${y + 3} ${z} amethyst_cluster`); break;
    case "cactus": C.push(`fill ${x} ${y} ${z} ${x} ${y + 2} ${z} cactus`); C.push(`setblock ${x} ${y - 1} ${z} sand`); break;
    case "dune": blob(x, y, z, 2, "sand"); break;
    case "mesa": C.push(`fill ${x - 1} ${y} ${z - 1} ${x + 1} ${y + h} ${z + 1} ${a}`); C.push(`fill ${x - 1} ${y + 2} ${z - 1} ${x + 1} ${y + 2} ${z + 1} ${b}`); break;
    case "deadbush": C.push(`setblock ${x} ${y} ${z} deadbush`); break;
    case "torii": C.push(`fill ${x - 2} ${y} ${z} ${x - 2} ${y + 4} ${z} red_concrete`); C.push(`fill ${x + 2} ${y} ${z} ${x + 2} ${y + 4} ${z} red_concrete`); C.push(`fill ${x - 3} ${y + 5} ${z} ${x + 3} ${y + 5} ${z} red_concrete`); C.push(`fill ${x - 2} ${y + 4} ${z} ${x + 2} ${y + 4} ${z} black_concrete replace air`); break;
    case "stonelantern": C.push(`setblock ${x} ${y} ${z} stone_bricks`); C.push(`setblock ${x} ${y + 1} ${z} cobblestone_wall`); C.push(`setblock ${x} ${y + 2} ${z} lantern`); break;
    case "banner": C.push(`fill ${x} ${y} ${z} ${x} ${y + 5} ${z} quartz_bricks`); C.push(`fill ${x} ${y + 2} ${z + 1} ${x} ${y + 4} ${z + 1} ${["red_wool", "yellow_wool", "blue_wool"][k % 3]}`); C.push(`setblock ${x} ${y + 6} ${z} lantern`); break;
    case "cloud": blob(x, y + 4 + (k % 3), z, 2, "white_wool"); break;
    case "mushroom": C.push(`setblock ${x} ${y} ${z} red_mushroom`); C.push(`setblock ${x + 1} ${y} ${z} brown_mushroom`); break;
    case "bigshroom": C.push(`fill ${x} ${y} ${z} ${x} ${y + h} ${z} mushroom_stem`); C.push(`fill ${x - 2} ${y + h + 1} ${z - 2} ${x + 2} ${y + h + 1} ${z + 2} ${k % 2 ? "red_mushroom_block" : "brown_mushroom_block"} replace air`); break;
    case "flowers": for (const [dx, dz, f] of [[0, 0, "poppy"], [1, 0, "dandelion"], [0, 1, "cornflower"], [-1, 0, "oxeye_daisy"]]) C.push(`setblock ${x + dx} ${y} ${z + dz} ${f}`); break;
    case "hay": C.push(`fill ${x} ${y} ${z} ${x + 1} ${y + 1} ${z} hay_block`); break;
    case "pond": C.push(`fill ${x - 1} ${y - 1} ${z - 1} ${x + 1} ${y - 1} ${z + 1} water`); C.push(`setblock ${x} ${y} ${z} waterlily`); break;
    case "vine": C.push(`fill ${x} ${y} ${z} ${x} ${y + h + 3} ${z} jungle_log`); C.push(`fill ${x} ${y + h + 4} ${z} ${x} ${y + h + 4} ${z} jungle_leaves`); break;
    case "kelp": C.push(`fill ${x} ${y} ${z} ${x} ${y + 2} ${z} sea_lantern`); C.push(`setblock ${x} ${y + 3} ${z} prismarine_wall`); break;
    case "soulfire": C.push(`setblock ${x} ${y - 1} ${z} soul_sand`); C.push(`setblock ${x} ${y} ${z} soul_fire`); C.push(`setblock ${x + 1} ${y} ${z} bone_block`); break;
    case "chorus": C.push(`fill ${x} ${y} ${z} ${x} ${y + h} ${z} purpur_pillar`); C.push(`setblock ${x} ${y + h + 1} ${z} end_rod`); break;
    default: break;
  }
  return C;
}
// v2.6: 読みこまれるまで 待つ（最大 maxT tick）
const loadedAt = (dim, q) => { try { return !!dim.getBlock({ x: Math.floor(q.x), y: Math.floor(q.y ?? 64), z: Math.floor(q.z) }); } catch { return false; } };
export async function waitLoaded(dim, pts, maxT = 40) {
  await wait(2);
  for (let t = 0; t < maxT && !pts.every((q) => loadedAt(dim, q)); t += 2) await wait(2);
}
// 床の 5か所を 見て 7割 できていれば OK
function stageOk(st) {
  const { dim, cx, cz, fy, R, T } = st;
  let want = [];
  try { want = [T.floor, T.acc, T.ring].map((b) => BlockPermutation.resolve(`minecraft:${bk(b)}`).type.id); } catch { return true; }
  const pts = [[0, 0], [R - 3, 0], [-(R - 3), 0], [0, R - 3], [0, -(R - 3)]];
  let good = 0;
  for (const [dx, dz] of pts) { try { const b = dim.getBlock({ x: cx + dx, y: fy - 1, z: cz + dz }); if (b && want.includes(b.typeId)) good++; } catch {} }
  return good >= 4;
}
export async function recheckStage(st) {
  if (!st || !st.cmds || stageOk(st)) return;
  for (let i = 0; i < st.cmds.length; i++) { run(st.dim, fixCmd(st.cmds[i])); if (i % 80 === 79) await wait(1); }
}
const ceilLight = (l) => (/^(soul_)?lantern$/.test(String(l)) ? (String(l).startsWith("soul") ? "shroomlight" : "glowstone") : l);   // v3.0: 天井に ランタンを 置くと 支えが なく 落ちて アイテムに なる
export async function removeStage(st) {
  if (!st || st.keep) return;
  await wait(6);
  LIVE.delete(st.name);
  if (!areaLoaded(st.dim, st)) return;   // v2.9.12: 読みこまれて いない ときは 記録を のこして あとで もどす
  run(st.dim, `structure load ${st.name} ${st.x1} ${st.y1} ${st.z1} 0_degrees none false true`);
  run(st.dim, `structure delete ${st.name}`);
  dropPending(st.name);
}

// ---- 空の 闘技場（街の 闘技場・模擬戦）----
const SKY_KEY = "mrpg:skyarena";
export function skyArenaPos() {
  let sp = { x: 0, z: 0 };
  try { const w = world.getDefaultSpawnLocation(); sp = { x: w.x, z: w.z }; } catch {}
  return { x: Math.floor(sp.x) + 640, y: 262, z: Math.floor(sp.z) + 640 };
}
const isAir = (dim, x, y, z) => { try { const b = dim.getBlock({ x, y, z }); return !b || b.isAir; } catch { return true; } };
const loaded = (dim, x, y, z) => { try { return !!dim.getBlock({ x, y, z }); } catch { return false; } };
// 闘技場が ちゃんと できているか（床の 中心と はし）
function arenaOk(dim, A) { return [[0, 0], [10, 0], [-10, 0], [0, 10], [0, -10]].every(([dx, dz]) => !isAir(dim, A.x + dx, A.y - 1, A.z + dz)); }
async function buildSky(ow, A) {
  // 遠くの チャンクも 読みこむ（読みこまれて いないと fill が 失敗する）
  run(ow, `tickingarea add ${A.x - 26} 0 ${A.z - 26} ${A.x + 26} 0 ${A.z + 26} mrpg_sky`);
  for (let t = 0; t < 60 && ![[-22, -22], [22, 22], [-22, 22], [22, -22], [0, 0]].every(([dx, dz]) => loaded(ow, A.x + dx, A.y, A.z + dz)); t++) await wait(5);
  for (let z = -22; z <= 22; z++) { const xo = Math.floor(Math.sqrt(Math.max(0, 22 * 22 - z * z))); run(ow, `fill ${A.x - xo} ${A.y - 2} ${A.z + z} ${A.x + xo} ${A.y - 2} ${A.z + z} ${bk("stone_bricks")}`); if (z % 8 === 0) await wait(1); }
  await buildStage(ow, A.x, A.y, A.z, 14, "arena", { stands: true, keep: true, H: 12 });
  await wait(4);
  const ok = arenaOk(ow, A);
  if (ok) world.setDynamicProperty(SKY_KEY, 3);
  return ok;
}
// プレイヤーを 空の 闘技場へ（もどる 場所を 記録）。闘技場が できてから 移動する
let SKY_LOCK = null;   // v2.9.8: 2人が 同時に 作らない
export async function toSkyArena(p) {
  const A = skyArenaPos();
  const ow = world.getDimension("minecraft:overworld");
  // v2.9.8: ほかの 人が 使って いる ときは その場で 戦う（同じ 場所で 戦いが 重ならない ように）
  const other = world.getAllPlayers().find((q) => q.id !== p.id && typeof q.getDynamicProperty("mrpg:ret") === "string");
  if (other) { try { p.sendMessage(`§e空の 闘技場は ${other.name}が 使って いるので、この場所で 戦います。`); } catch {} return { ok: false }; }
  while (SKY_LOCK) { try { await SKY_LOCK; } catch {} }
  if (p.getDynamicProperty("mrpg:ret") === undefined) {
    p.setDynamicProperty("mrpg:ret", JSON.stringify({ x: p.location.x, y: p.location.y, z: p.location.z, dim: p.dimension.id }));
  }
  let ok = world.getDynamicProperty(SKY_KEY) === 3 && loaded(ow, A.x, A.y, A.z) && arenaOk(ow, A);
  if (!ok) {
    try { barNote(p).setActionBar("§e空の 闘技場を 準備中…"); } catch {}
    let done; SKY_LOCK = new Promise((r) => (done = r));
    try { ok = await buildSky(ow, A); if (!ok) ok = await buildSky(ow, A); } finally { SKY_LOCK = null; done(); }   // もう1回
  }
  if (!ok) {
    // 作れなかった ときは 移動しないで その場で 戦う
    run(ow, "tickingarea remove mrpg_sky");
    p.setDynamicProperty("mrpg:ret", undefined);
    try { p.sendMessage("§e空の 闘技場を 準備できなかったので、この場所で 戦います。"); } catch {}
    return { ok: false };
  }
  // 念のため 足もとに 足場
  run(ow, `fill ${A.x - 1} ${A.y - 1} ${A.z - 7} ${A.x + 1} ${A.y - 1} ${A.z - 5} ${bk("smooth_sandstone")} replace air`);
  try { p.addEffect("slow_falling", 200, { showParticles: false }); p.addEffect("resistance", 200, { amplifier: 4, showParticles: false }); } catch {}
  try { p.teleport({ x: A.x + 0.5, y: A.y + 0.2, z: A.z - 6 + 0.5 }, { dimension: ow, facingLocation: { x: A.x, y: A.y + 1, z: A.z + 6 } }); } catch {}
  run(ow, "tickingarea remove mrpg_sky");
  return { center: A, playerPos: { x: A.x + 0.5, y: A.y, z: A.z - 6 + 0.5 }, foePos: { x: A.x + 0.5, y: A.y, z: A.z + 6.5 }, ok };
}
// 闘技場から 落ちたら 闘技場の 上に 戻す
system.runInterval(() => {
  const A = skyArenaPos();
  for (const p of world.getAllPlayers()) {
    try {
      if (typeof p.getDynamicProperty("mrpg:ret") !== "string" || p.dimension.id !== "minecraft:overworld") continue;
      const l = p.location;
      if (Math.abs(l.x - A.x) < 64 && Math.abs(l.z - A.z) < 64 && l.y < A.y - 6) {
        p.addEffect("slow_falling", 100, { showParticles: false });
        p.teleport({ x: A.x + 0.5, y: A.y + 1, z: A.z - 6 + 0.5 });
      }
    } catch {}
  }
}, 10);
export function backFromArena(p) {
  let r; try { r = p.getDynamicProperty("mrpg:ret"); } catch { return; }   /* 第69版: 抜けた プレイヤー */
  if (typeof r !== "string") return;
  try { const o = JSON.parse(r); p.teleport({ x: o.x, y: o.y, z: o.z }, { dimension: world.getDimension(o.dim) }); } catch {}
  p.setDynamicProperty("mrpg:ret", undefined);
}
// 落ちて 闘技場に 取りのこされたら もどす
world.afterEvents.playerSpawn.subscribe(({ player }) => { system.runTimeout(() => { try { if (typeof player.getDynamicProperty("mrpg:ret") === "string") backFromArena(player); } catch {} }, 60); });
