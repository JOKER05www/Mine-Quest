// v1.7: テスト用メニュー（/scriptevent mrpg:test）。ライドの 挙動・ボス・ハガネ・マスター・闘技場を すぐ ためせる
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, ITEMS } from "./data.js";
import { makeMonster, calcStats, addMon, MAXLV, levelUp } from "./core.js";
import { load, save, allMons } from "./store.js";
import { TYPE, setLook, setSpeed, spawnPet, recallPet, findPet, rideInfo } from "./field.js";
import { spawnBoss, groundY } from "./structures.js";
import { spawnSlabBoss, spawnMaster } from "./master.js";
import { toSkyArena, backFromArena } from "./stage.js";
import { busy, choose, notice, ICON, MON_ICON, giveItem, sound, rankOf } from "./ui.js";

const B = (t, i) => [t, ICON(i)];
const front = (p, r = 6) => {
  const yaw = (p.getRotation().y * Math.PI) / 180;
  const x = p.location.x - Math.sin(yaw) * r, z = p.location.z + Math.cos(yaw) * r;
  const y = groundY(p.dimension, x, z, Math.floor(p.location.y)) ?? Math.floor(p.location.y);
  return { x, y, z };
};
function spawnWildAs(p, sid, lv, tags = []) {
  const e = p.dimension.spawnEntity(TYPE, front(p));
  setLook(e, sid);
  for (const t of tags) e.addTag(t);
  e.setDynamicProperty("mrpg:lv", lv);
  e.setDynamicProperty("mrpg:q", 0.3);
  setSpeed(e, sid, 0.8);
  e.nameTag = `§d[テスト]§f${SPECIES[sid].name} §7Lv${lv} ${rankOf(sid)}`;
  return e;
}
const avgLv = (d) => Math.round(d.party.reduce((s, m) => s + m.lv, 0) / Math.max(1, d.party.length)) || 10;

async function rideTest(p, d) {
  const SZ = ["S", "M", "L", "G"], RD = ["walk", "float", "fly"], RN = { walk: "あるく", float: "ふゆう", fly: "ひこう" };
  const opts = [];
  for (const z of SZ) for (const r of RD) opts.push([z, r]);
  const i = await choose(p, "ライド テスト", "§fサイズと 乗り方を 選ぶと、テスト用の モンスター（Lv50）を 仲間に して 連れ歩きます。\n§7乗るには しゃがまずに 右クリック（スマホは 長押し）。\n§7終わったら 預かり所で 手放してね（名前に「テスト」）。",
    [...opts.map(([z, r]) => B(`サイズ${z}・${RN[r]}`, r === "fly" ? "i_run" : r === "float" ? "i_spell" : "i_walk")), B("§7戻る", "i_back")]);
  if (i < 0 || i >= opts.length) return;
  const [z, r] = opts[i];
  const pool = ORDER.filter((s) => SPECIES[s].ride === r && (SPECIES[s].sz || "M") === z);
  const sid = pool.length ? pool[Math.floor(Math.random() * pool.length)] : ORDER.find((s) => SPECIES[s].ride === r);
  const m = makeMonster(sid, 50, true);
  if ((SPECIES[sid].sz || "M") !== z) m.sz = z;
  m.nm = `テスト${SPECIES[sid].name}`.slice(0, 12);
  const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
  const where = addMon(d, m);
  recallPet(p, d);
  if (where === "party") { d.out = m.id; spawnPet(p, m); }
  save(p, d);
  await notice(p, "ライド テスト", `§a${m.nm}（${z}・${RN[r]}）を ${where === "party" ? "表の パーティ" : where === "bench" ? "控え" : "預かり所"}に くわえた。\n§f${rideInfo(sid)}\n${where === "party" ? "§7連れ歩き中。右クリックで 乗れます。" : "§7表の パーティに 空きが ないので 連れ歩きは しません。入れ替えで 表に 出してね。"}`);
}

async function spawnMenu(p, d) {
  const s = await choose(p, "テスト: 出現", "§7目の前に 出します。", [
    B("野生（ランダム S〜G）", "i_walk"), B("ハガネ族", "i_guard"), B("遺跡ボス", "i_fight"), B("レイドボス", "i_fight"),
    B("石板ボス（どう/ぎん/きん/にじ）", "i_fight"), B("モンスターマスター", "i_scout"), B("§7戻る", "i_back")]);
  const lv = avgLv(d);
  if (s === 0) {
    const z = await choose(p, "サイズ", "", [B("S", "i_walk"), B("M", "i_walk"), B("L", "i_walk"), B("G", "i_walk")]);
    if (z < 0) return;
    const pool = ORDER.filter((x) => (SPECIES[x].sz || "M") === "SMLG"[z] && SPECIES[x].fam !== "god");
    spawnWildAs(p, pool[Math.floor(Math.random() * pool.length)], lv);
  } else if (s === 1) {
    const pool = ORDER.filter((x) => SPECIES[x].metalmon);
    spawnWildAs(p, pool[Math.floor(Math.random() * pool.length)], lv, ["mrpg_rare", "mrpg_metal"]);
  } else if (s === 2 || s === 3) {
    spawnBoss(p.dimension, front(p, 8), "plains", lv, "", s === 3);
  } else if (s === 4) {
    const t = await choose(p, "石板ボス", "", ["どう", "ぎん", "きん", "にじ"].map((n) => B(n, "i_fight")));
    if (t < 0) return;
    spawnSlabBoss(p, d, t, "");
  } else if (s === 5) {
    if (!spawnMaster(p, d)) await notice(p, "マスター", "§7置ける 場所が 見つかりませんでした（街の 近く・地面が ない 場所では 出ません）。");
  }
}

export async function testMenu(p) {
  if (busy.has(p.id)) return;
  busy.add(p.id);
  let after = null;
  try { after = await testInner(p); } finally { busy.delete(p.id); }
  if (after) await after();
}
// メニューの 中から よぶ とき（移動は メニューを 閉じてから）
export async function testInner(p) {
  let after = null;
  {
    for (;;) {
      const d = load(p);
      if (!d) { await notice(p, "テスト", "§7先に ガイドブックで 最初の 仲間を 選んでください。"); return; }
      const s = await choose(p, "§cテスト メニュー", "§7ためし用です。データが 変わるものは ★ つき（心配なら 先に 設定→セーブデータで 保存）", [
        B("ライド テスト（サイズ×乗り方）★", "i_walk"), B("モンスターを 出す", "i_fight"), B("全回復", "i_inn"),
        B("表の パーティを Lv100に ★", "i_skill"), B("お金 +100000 ★", "i_shop"), B("成長の飴・大飴・秘宝 各10個 ★", "i_item"),
        B("空の 闘技場へ 行く／戻る", "i_scout"), B("連れ歩きを しまう", "i_back"), B("§7閉じる", "i_close")]);
      if (s === 0) await rideTest(p, d);
      else if (s === 1) await spawnMenu(p, d);
      else if (s === 2) { for (const m of allMons(d)) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } save(p, d); sound(p, "random.levelup"); }
      else if (s === 3) {
        const log = [];
        for (const m of [...d.party, ...(d.bench || [])]) while (m.lv < MAXLV) { m.exp = 0; levelUp(m, log); }
        for (const m of [...d.party, ...(d.bench || [])]) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; }
        save(p, d); sound(p, "random.levelup");
      } else if (s === 4) { d.gold += 100000; save(p, d); sound(p, "random.orb"); }
      else if (s === 5) { for (const k of ["lv_1", "lv_5", "lv_10"]) if (ITEMS[k]) giveItem(p, `mrpg:${k}`, 10); sound(p, "random.pop"); }
      else if (s === 6) { after = typeof p.getDynamicProperty("mrpg:ret") === "string" ? () => backFromArena(p) : () => toSkyArena(p); break; }
      else if (s === 7) { recallPet(p, d); save(p, d); }
      else break;
    }
  }
  return after;
}
