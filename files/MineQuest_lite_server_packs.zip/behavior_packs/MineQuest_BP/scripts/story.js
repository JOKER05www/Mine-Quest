// ストーリー: マスターリーグ（闘技場 F〜SS カップ）と 星冠王
import { KENGO, kengoTeam, kengoText, kengoReward } from "./postgame.js";
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, ITEMS } from "./data.js";
import { ri, pick, calcStats } from "./core.js";
import { load, save } from "./store.js";
import { busy, ok, sound, particle, choose, notice, confirm, ICON, MON_ICON, LINE, gold, giveItem, showTitle } from "./ui.js";
import { TYPE, setLook } from "./field.js";
import { groundY } from "./structures.js";
import { startBattle } from "./battle.js";
import { addMasterRank } from "./master.js";
import { toSkyArena, backFromArena, skyArenaPos } from "./stage.js";
import { BOSS_SLAB } from "./data.js";
import { townAt } from "./structures.js";
import { sagaHint, chapterOf, synopsisText, mqHeld, mqRetry } from "./saga.js";
import { canTalkMusashi, musashiTalkMenu } from "./majin.js";
import { REGIONS as RMR, masterType, regionTown } from "./rmaster.js";
import { RM_SLAB } from "./quest.js";
import { capText, bossLv as bossLvQ, slabBossLv, qs, giveSlab, CUP_SLAB, slabSource, giveCrown, syncQuest, partyPower, progressText, endingDone, postOpen, BS_N, CROWN, RUIN_NEED, slabTierOk } from "./quest.js";

const RI = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
const rankIdx = (sid) => { const i = RI.indexOf(SPECIES[sid].rank); return i < 0 ? 8 : i; };
const NOFAM = new Set(["king", "god"]);

export const WORLD_TEXT = [
  "§l§eアストラ大陸と 十五の 石板", LINE,
  "§fアストラ大陸には いくつもの 地方が ある。豊かな 大自然の §aアルカトラス地方§f、大森林、廃墟の 荒野、火山、砂漠、水晶の 地、海の 諸島、冥府、雪山、終焉の地、そして 天空郷。地方ごとに 城が あり、すむ モンスターも ちがう。",
  "§fむかし、§6「王」§fを 名のる 一体の モンスターが いた。王は 十四の 眷属を したがえ、心ある ものを ひとつずつ 呑みこんでいった。",
  "§f人と モンスターは 手を とりあい、王と 眷属を §d十五枚の 石板§f に 封じた。石板は 二度と 揃わぬよう、各地へ 散らされた。",
  "§fそれから 長い 時が すぎ、石板は 寂れ、ひびが 入りはじめた。封じられた ものたちは 待っている。自分たちを §c呼べる 人間§f を。",
  "§fあなたは アルカトラス地方の 田舎町 §eルミナ§f で 育った。生まれつき §bモンスターに 好かれる§f。それは 同時に §c悪しき ものに 魅入られる 体質§f でもある。石板に 触れれば、その 内側へ 引きこまれてしまうだろう。",
  "§fいっぽう マスターリーグでは §c§l星冠王 ゼファード§r§f が 20年 王座を 守っている。彼は 石板の ことを 何か 知っているらしい……",
].join("\n");

const RIVAL = { name: "レイ", fam: "dragon" };
export const CUPS = [
  { r: 0, name: "ひよっこカップ", need: 0, lv: 8, gold: 500, items: ["e_bronze"], foes: [["みならい", "トト", "がんばって 育てた 仲間だよ！"], ["みならい", "ポム", "負けないもん！"], ["カップ王者", "むしとりの ケン", "ここを とおすわけには いかないな！"]],
    story: ["§fルミナの 長老 §eオルド§f「ほう、ひよっこカップを 勝ちぬいたか。」", "§f「ルミナに 戻った §bレイ§f も、闘技場で 腕を みがいて おるぞ。」"] },
  { r: 1, name: "そよかぜカップ", need: 2, lv: 14, gold: 1000, items: ["e_bronze", "n_mirror"], foes: [["かぜつかい", "フウ", "かぜの ように かるやかに いくよ！"], ["とりつかい", "ピピ", "空を 飛ぶ 仲間は 強いんだ！"], ["カップ王者", "そよかぜの ミント", "かぜが あなたを みとめるかしら？"]],
    story: ["§bレイ§f「よう、そよかぜカップ 勝ったんだってな？」", "§b「町の 見回りの あいまに 鍛えなおした。次の いわくだきカップで 待ってるぜ！」"] },
  { r: 2, name: "いわくだきカップ", need: 5, lv: 22, gold: 2000, items: ["e_silver", "sl0"], foes: [["いわおとこ", "ガンジ", "かたい 守備を くずせるか？"], ["こうざんの", "ドリル", "ほりすすめー！"], ["ライバル", "レイ", "やっと 来たか！ 闘技場で 勝負だ！ 旅の 決着の つづきを しようぜ！"]], rival: 2,
    story: ["§bレイ§f「……チッ、負けたか。だが 悪くねえ 勝負だった。」", "§b「知ってるか？ 星冠王 ゼファードは 20年前、オレ様の じいさん……オルドの 弟子だったんだ。」", "§fいつか 星冠の 王座で…… ふたりは そう やくそくした。"] },
  { r: 3, name: "炎カップ", need: 9, lv: 30, gold: 4000, items: ["e_red", "s_all"], foes: [["ひけし", "カエン", "あつく いこうぜ！"], ["かざん の", "マグナ", "もえつきるまで 戦う！"], ["カップ王者", "ほむらの ジーク", "炎より あつい ハートを 見せてみろ！"]],
    story: ["§fオルド「炎カップか。りっぱに なったのう。」", "§f「…ゼファードは 強さだけを もとめ、仲間との 絆を 忘れて しまった。わしは それを とめられなかった。」", "§f「おまえさんなら、あやつに 何かを とどけられるかもしれん。」"] },
  { r: 4, name: "雷カップ", need: 14, lv: 40, gold: 8000, items: ["e_silver", "sl1"], foes: [["らいめい の", "ボルト", "しびれさせて やるぜ！"], ["マシン使い", "ギア", "けいさんずみの 勝利だ。"], ["カップ王者", "雷の セイラ", "光より はやく、神なりより 強く！"]],
    story: ["§fマスターたちの あいだで 噂が ひろがっている。", "§f「石板を 封じた マスターが 闘技場を 勝ちあがって いるらしい。ゼファードは 20年まえ、石板の 中へ 入ったことが あるらしい…」"] },
  { r: 5, name: "はがねカップ", need: 20, lv: 52, gold: 15000, items: ["e_rainbow"], foes: [["けんし", "ムラマサ", "いざ じんじょうに！"], ["てっぺき の", "ガルド", "この かべは こえられん。"], ["ライバル", "レイ", "もう 負けねえ。オレ様も ずっと 鍛えてきたんだ！"]], rival: 5,
    story: ["§bレイ§f「また 負けた……！ くそっ。……お前が いるから、オレ様も 強く なれる。」", "§b「次は てんくうカップ。そのつぎの せいかんカップで ケリを つけるぞ！」"] },
  { r: 6, name: "てんくうカップ", need: 28, lv: 65, gold: 30000, items: ["sl1", "e_rainbow"], foes: [["くもの うえの", "ソラネ", "空の はてまで つれていくよ。"], ["王家の", "レオンハルト", "王の なを もつ 仲間の 力、見せよう。"], ["カップ王者", "てんくうの アスカ", "ここまで きた マスターは ひさしぶり。"]],
    story: ["§fてんくうの アスカ「ゼファードさまは いつも ひとり。神の モンスターと だけ はなしている…」", "§f「あの人を とめられるのは、きっと 絆で 戦う マスターだけ。」"] },
  { r: 7, name: "せいかんカップ", need: 38, lv: 80, gold: 60000, items: ["e_rainbow", "e_king"], foes: [["してんのう", "ヴァイス", "ここからは 本物の 最強 だ。"], ["してんのう", "ミラージュ", "まぼろしに まどわされないでね。"], ["ライバル", "レイ", "闘技場での 最後の 勝負だ！ 全部 出しきって こい！"]], rival: 7,
    story: ["§bレイ§f「……やっぱり お前が 一番だ。行ってこい、星冠の 王座へ！」", "§f闘技場の おくで、おもい とびらが 開いた。", "§c§lゼファード§r§f「…待っていたぞ。石板が 選んだ マスターよ。」"] },
];
const FINAL = { name: "星冠王 ゼファード", lv: 95,
  pre: ["§c§lゼファード§r§f「よく ここまで 来た。……おまえの まわりには、いつも モンスターが 集まるな。」", "§f「わたしも そうだった。そして 20年まえ、その 体質の せいで §6王冠の石板§f に 呼ばれた。」",
    "§f「封じきれなかった。仲間を うしない、わたしは 力だけを 信じる ように なった。」", "§f「……おまえに あれを 託せるか。この 王座で 見せてもらう！」"],
  end: ["§c§lゼファード§r§f「……負けた、のか。この わたしが。」", "§f「おまえの 仲間たちは おまえを 信じて 戦っていた。わたしが 20年まえに 手ばなした ものだ。」",
    "§f「これを 持っていけ。§6王冠の石板§f――石板の 王が 眠る 最後の 一枚だ。」", "§f「ほかの 十四枚を すべて 封じた とき、王は 目を さます。……わたしに できなかった ことを。」",
    "", "§eオルド§f「ゼファードの かおが、むかしの ように わらっておったわい。」", "§bレイ§f「やりやがったな！ ……次は オレ様が 挑戦者だ、首を 洗って 待ってろ！」"] };
const ENDING = [
  "§6§l― エンディング ―", "",
  "§f王冠の石板が 砕け、光の 粒に なって 空へ のぼっていく。",
  "§f十五の 封印は ひとつの 輪に つながり、アストラ大陸の 石板は 静かに 眠りについた。",
  "§c§lゼファード§r§f「……やり遂げたか。20年 待った 甲斐が あった。」",
  "§eオルド§f「魅入られながら、呑まれなかった。それが おまえさんの ほんとうの 才能じゃよ。」",
  "§bレイ§f「おい 見ろよ！ 石板屋の おっさんが、§6金の石板§f と §d虹の石板§f を 作れるように なったってよ！」",
  "", "§7― 石板屋で §6金・虹の石板§7 が 製造できるように なった",
  "§7― 世界の 奥に まだ 試練が のこっている：§6終の遺跡§7、そして 始まりの町の §b伝説の マスター§7……",
  "§7― 各地方の §6城の 王§7 が 手合わせを 望んでいる（勝つと §d神の石板§7）。§8くわしくは ガイドブック → 用語説明 →「クリア後に できること」",
];

export function storyOf(d) {
  const s = qs(d);
  if (typeof d.mpt !== "number") d.mpt = 0;
  return s;
}
export function chapterText(d) {
  const s = storyOf(d);
  if (s.ending) return postOpen(d) ? `§b★ 伝説の 先へ §f（${KENGO.name} ${s.kg || 0}勝）` : "§6★ エンディング後 §f― 終の遺跡と 伝説の マスター";
  const ch = chapterOf(d) || "第1章 旅立ち";   // v2.9.13: 物語の 章は 1つに まとめた
  return `§f${ch}  §7${progressText(d).replace(/§./g, "")}`;
}
export function nextGoal(d) {
  const s = storyOf(d), L = [];
  try { const h = sagaHint(d); if (h) L.push(h); } catch {}
  const held = s.bsg.filter((i) => !s.bs.includes(i) && (i !== CROWN || s.bs.length >= CROWN)).length;
  if (!s.final) {
    if (s.cup >= CUPS.length) L.push("§f闘技場で §c星冠王 ゼファード§f に 挑もう");
    else { const c = CUPS[s.cup]; L.push(d.mpt < c.need ? `§fフィールドの §bモンスターマスター§f に 勝って ポイントを 集めよう（§e${d.mpt}§7/${c.need}§f）` : `§f街の §e闘技場§f で §e${c.name}§f に 挑める！`); }
  }
  if (!s.bsFinal) {
    if (held > 0) L.push(`§d未封印の 石板が ${held}枚。§fバッグ（特別な石板）から 使って 中の 主を 封印しよう`);
    else if (s.bsg.length < BS_N) L.push("§7石板は 各地方の §6地方マスター§7・闘技場の カップ・遺跡の ボスが 持っている（ストーリー →「石板の 記録」）");
    if (s.bs.length >= CROWN && !s.crown) L.push("§6王冠の石板は 星冠王 ゼファードが 持っている");
  }
  if (s.ruins < RUIN_NEED) L.push(`§6遺跡の ボスを 倒して §e星の かけら§6 を 集めよう（${s.ruins}/${RUIN_NEED}）§7…2つ目と 5つ目で 石板。8つで 終の遺跡が 開く`);
  else if (!s.ruinFinal) L.push("§6§l終の遺跡§r§6 が 開いた！§7（コンパスで 案内できる）");
  if (s.ending && postOpen(d)) L.push((s.kg || 0) >= 40 ? `§7伝説の マスター カゲツ: ${s.kg}勝（10勝ごとに SSランクの モンスター）` : `§b始まりの町 ルミナの 闘技場で §l${KENGO.name}§r§b が 待っている §7（あと ${10 - ((s.kg || 0) % 10)}勝で 神の石板）`);
  if (s.ending) { const kw = s.kgw || {}, dg = s.dg || {}, un = (Array.isArray(s.dgs) ? s.dgs : []).filter((gi) => !dg[gi]).length; L.push(`§6城の 王 ${Object.keys(kw).filter((k) => kw[k] > 0).length}/11 §7・§d神の石板 まだ 仲間に して いない 神 ${un}柱 §7・仲間にした 神 ${Object.keys(dg).length}/15`); }
  else if (s.ending) L.push("§7終の遺跡・星冠王・王冠の石板… 三つの 試練を 越えると 伝説の マスターが 現れる");
  return L.join("\n");
}

const bossLvOf = (i) => slabBossLv(i);
function slabListText(d) {
  const s = storyOf(d), L = ["§l§d石板の 記録", LINE];
  BOSS_SLAB.forEach((b, i) => {
    const done = s.bs.includes(i), got = s.bsg.includes(i);
    L.push(done ? `§a◆ ${b.name} §7― ${b.title}（${b.rank}）封印ずみ${s.bsT && s.bsT[i] ? `・最速 ${s.bsT[i]}分` : ""}` : got ? `§d◇ ${b.name} §7― 未封印（${b.floors}階・主 Lv${bossLvOf(i)}）` : `§8・？？？の石板 §7― ${slabSource(i)}`);
  });
  return L.join("\n");
}

// v2.9.13: 石板の 守り手（地方マスター）の 記録
function guardianText(d) {
  const s = storyOf(d), L = ["§l§6石板の 守り手の 記録", "§7地方マスターは それぞれの 地方の 石板を 守っている。勝って 認められると 石板を 託される。", LINE];
  RMR.forEach((R, k) => {
    const won = (s.rm || []).includes(k), si = RM_SLAB[k], b = BOSS_SLAB[si], t = regionTown(k);
    const sealed = s.bs.includes(si);
    L.push(`${won ? "§a◆" : "§8◇"} §f${R.title} §l${R.name}§r §7― ${masterType(k)}${t ? `・${t.name}` : ""}`);
    L.push(won ? `   §7認められた → §d${b.name}§7 ${sealed ? "§a封印ずみ" : "§e未封印（【特別な石板】から 使う）"}` : "   §8まだ 認められて いない");
  });
  L.push(LINE, `§f認められた 守り手: §e${(s.rm || []).length}§7/${RMR.length}`);
  return L.join("\n");
}
export async function storyMenu(p, d) {
  const s = storyOf(d);
  const got = syncQuest(p, d);
  if (got.length) { save(p, d); await notice(p, "石板", `§d石板を 受けとった: §f${got.join("・")}`); }
  for (;;) {
    const body = [`§l§fモンスターマスター ${p.name}`, LINE, chapterText(d), progressText(d), capText(d), `§fマスターポイント §e${d.mpt}`, `§fカップ 制覇 §e${Math.min(s.cup, 8)}§7/8 ${CUPS.map((c, i) => (i < s.cup ? "§6" : "§8") + RI[c.r]).join(" ")}${s.final ? " §6★" : ""}`, LINE, "§f次の 目標:", nextGoal(d)].join("\n");
    const held = mqHeld(d);   // v2.9.13: 止まって いる 物語の 戦いに 再挑戦
    let sel = await choose(p, "ストーリー", held ? body + "\n§c§l物語の 戦いが 止まって いる。§r§f「物語の 戦いに 再挑戦」を えらぶまで 先へ 進めない" : body, [...(held ? [["§c§l物語の 戦いに 再挑戦", ICON("i_fight")]] : []), ["§lこれまでの あらすじ", ICON("i_zukan")], ["§6石板の 守り手の 記録", ICON("i_fight")], ["§d石板の 記録", ICON("i_zukan")], ...(canTalkMusashi(d) ? [["§c§lムサシと 話す", ICON("i_party")]] : []), ["アストラ地方の 伝説", ICON("i_help")], ["マスターリーグの しくみ", ICON("i_fight")], ["§7戻る", ICON("i_back")]]);
    if (held) {
      if (sel === 0) {
        if (await confirm(p, "物語の 戦いに 再挑戦", "§f止まって いる 物語の 戦いに もう一度 挑みますか？\n§7（仲間は 戦いの 前に 全回復する）", "挑む", "やめる")) { const dd = load(p); if (dd) { await notice(p, "再挑戦", mqRetry(p, dd)); return; } }
        continue;
      }
      if (sel > 0) sel--;
    }
    if (sel === 0) {   // v2.9.13: 章の あらすじ ＋ 闘技場・石板の 思い出
      const extra = [];
      for (let i = 0; i < Math.min(s.cup, CUPS.length); i++) extra.push("", `§e§l${CUPS[i].name} 制覇`, ...CUPS[i].story);
      if (s.final) extra.push("", "§6§l星冠の 王座", ...FINAL.end.slice(0, 4));
      if (s.ending) extra.push("", ...ENDING);
      await notice(p, "これまでの あらすじ", synopsisText(d) + (extra.length ? "\n§l§e闘技場と 石板の 思い出" + extra.join("\n") : ""));
      continue;
    }
    if (sel === 1) { await notice(p, "石板の 守り手", guardianText(d)); continue; }
    if (canTalkMusashi(d) && sel === 3) { await musashiTalkMenu(p, d); continue; }
    if (canTalkMusashi(d) && sel > 3) sel--;   // ムサシの ボタンの ぶん ずらす
    if (sel === -99) {
      const lines = ["§e§lプロローグ", "§f始まりの町 ルミナで 最初の 仲間と であった。長老 オルドは あなたの 体質に 気づいていた。"];
      for (let i = 0; i < Math.min(s.cup, CUPS.length); i++) lines.push("", `§e§l${CUPS[i].name} 制覇`, ...CUPS[i].story);
      if (s.bs.length) lines.push("", "§d§l封じた 石板", ...s.bs.slice(-6).map((i) => `§d${BOSS_SLAB[i].name}§7 ― ${BOSS_SLAB[i].title}「${BOSS_SLAB[i].win}」`));
      if (s.final) lines.push("", "§6§l星冠の 王座", ...FINAL.end.slice(0, 4));
      if (s.ending) lines.push("", ...ENDING);
      await notice(p, "これまでの おはなし", lines.join("\n"));
    } else if (sel === 2) await notice(p, "石板の 記録", slabListText(d));
    else if (sel === 3) await notice(p, "伝説", WORLD_TEXT);
    else if (sel === 4) await notice(p, "マスターリーグ", leagueHelp());
    else return;
  }
}
// 星冠王と 王冠の石板、両方を 越えたら いちどだけ
export async function maybeEnding(p, d) {
  const s = storyOf(d);
  if (s.ending || !s.final || !s.bsFinal) return false;
  s.ending = true;
  if (!s.meetGot) { s.meetGot = true; giveItem(p, "mrpg:sx_meet", 1); }
  save(p, d);
  try { showTitle(p, "§6§lマインクエスト", { subtitle: "§f― 十五の 石板 ―", fadeInDuration: 20, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
  for (const q of world.getAllPlayers()) { q.sendMessage(`§6§l★ ${p.name}が すべての 石板を 封印し、物語を 見届けた！ ★`); sound(q, "ui.toast.challenge_complete", 1); }
  sound(p, "music.game.end", 1);
  await notice(p, "エンディング", [...ENDING, "", "§b§l再会の石板§r§b を 手に入れた！ §7（これまで 仲間に した モンスターと また 会える）", "§6覇王の石板・神域の石板§7 は 地方マスターの 再戦・伝説の マスター・終の遺跡・エンマ・石板こうぼうで"].join("\n"));
  return true;
}
function leagueHelp() {
  return ["§l§eマスターリーグの しくみ", LINE,
    "§f・フィールドの モンスターマスターに 勝つと §eマスターポイント§f（ルーキー1・ベテラン2・チャンピオン4、リベンジ+1）",
    "§f・ポイントが たまると 街の §e闘技場§f で 次の カップに 挑戦できる。§d優勝すると 石板が もらえる",
    "§f・カップは §e3れんせん§f。しあいの 前に HP・MPは ぜんかいふく。逃げる・スカウトは できない。負けても お金は へらない",
    "§f・相手の レベルは あなたの 手持ちに あわせて 上がる",
    "", ...CUPS.map((c) => `§f${RI[c.r]}  §e${c.name}§7  必要 ${c.need}pt  敵 Lv${c.lv}〜`),
    "§c最後  星冠王 ゼファード§7  （SSカップ 制覇で 挑戦・相手は Sランクまで）",
  ].join("\n");
}

// ---------- 闘技場 ----------
function avgLv(list) { return Math.round(list.reduce((s, m) => s + m.lv, 0) / Math.max(1, list.length)); }
function arenaTeam(d, ci, round) {
  const c = CUPS[ci];
  const top = c.r;
  const lv = Math.min(100, Math.max(c.lv, avgLv(d.party) - 2) + round * 2);
  const foe = c.foes[round];
  const isRival = c.rival !== undefined && round === 2;
  const n = round === 0 ? ri(2, 3) : round === 1 ? 3 : Math.min(4, 3 + (ci >= 4 ? 1 : 0));
  const fav = isRival ? RIVAL.fam : null;
  const team = [];
  for (let i = 0; i < n; i++) {
    let r = Math.max(0, top - (round === 2 && i === 0 ? 0 : ri(0, round === 0 ? 2 : 1)));
    let pool = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].rank === RI[r] && !NOFAM.has(SPECIES[s].fam) && (!fav || SPECIES[s].fam === fav));
    if (!pool.length) pool = ORDER.filter((s) => !SPECIES[s].hidden && SPECIES[s].rank === RI[r] && !NOFAM.has(SPECIES[s].fam));
    team.push({ sid: pick(pool), lv: Math.min(100, lv + (i === 0 ? 1 : 0)), q: Math.min(1, 0.3 + ci * 0.08 + round * 0.1 + (isRival ? 0.1 : 0)) });
  }
  return { team, title: foe[0], name: foe[1], line: foe[2], rival: isRival };
}
// v2.2.2: 星冠王は Sランクまで（王系・神系なし）。手持ちの 強さに あわせて 調整
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
export function finalTeam(s, d) {
  const P = d ? partyPower(d) : { lv: 90, rank: 6 };
  const rm = s.rematch || 0;
  const lv = Math.min(100, Math.max(70, P.lv + 3) + rm * 2);
  const plus = Math.min(99, 15 + Math.max(0, Math.round((P.rank - 6) * 12)) + rm * 5);
  const pool = ORDER.filter((x) => { const S = SPECIES[x]; return !S.hidden && !S.metalmon && S.rank === "S" && !NOFAM.has(S.fam); });
  const team = []; let used = 0;
  const fams = new Set();
  // エース（大きめ）→ 残りの 枠を 役割の ちがう 仲間で
  // v3.0: Sランクには Sサイズが いないため、L の エースだと 1体だけに なる。エースは M に して 2体以上に
  const ace = pick(pool.filter((x) => SPECIES[x].sz === "M"));
  team.push({ sid: ace, lv: Math.min(100, lv + 2), q: 1, plus: plus + 10 }); used += SLOT[SPECIES[ace].sz]; fams.add(SPECIES[ace].fam);
  for (let k = 0; k < 6 && used < 4; k++) {
    const c = pool.filter((x) => used + SLOT[SPECIES[x].sz] <= 4 && !fams.has(SPECIES[x].fam) && !team.some((t) => t.sid === x));
    const c2 = c;
    if (!c2.length) break;
    const x = pick(c2); team.push({ sid: x, lv, q: 1, plus }); used += SLOT[SPECIES[x].sz]; fams.add(SPECIES[x].fam);
  }
  return team;
}

function healAll(d) { for (const m of [...d.party, ...(d.bench || [])]) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } }
function eligible(d, top) { return d.party.filter((m) => rankIdx(m.sp) > top); }

// v3.0: 連戦・会話の 流れの あいだは いそがしい まま（戦いの 間だけ 外す）
const HOLD = new Map();   // id → その 流れを 始めた プレイヤー（入りなおした 別の オブジェクトと 区別）
export async function holdBusy(p, fn) { if (HOLD.get(p.id) === p) return fn(); HOLD.set(p.id, p); busy.add(p.id); try { return await fn(); } finally { if (HOLD.get(p.id) === p) { HOLD.delete(p.id); busy.delete(p.id); } } }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => HOLD.delete(playerId)); } catch {}
export async function fight(p, foe, info) {
  const yaw = (p.getRotation().y * Math.PI) / 180;
  let x = p.location.x - Math.sin(yaw) * 5, z = p.location.z + Math.cos(yaw) * 5;
  let y = groundY(p.dimension, x, z, Math.floor(p.location.y)) ?? Math.floor(p.location.y);
  // v1.7: 空の 闘技場に いるときは 決まった 位置で 向かいあう（約12ブロック）
  if (typeof p.getDynamicProperty("mrpg:ret") === "string") {
    const A = skyArenaPos();
    try { p.teleport({ x: A.x + 0.5, y: A.y + 0.2, z: A.z - 6 + 0.5 }, { facingLocation: { x: A.x + 0.5, y: A.y + 1, z: A.z + 6.5 } }); } catch {}
    x = A.x + 0.5; y = A.y; z = A.z + 6.5;
  }
  let e;
  try { e = p.dimension.spawnEntity(TYPE, { x, y, z }); } catch { return null; }
  setLook(e, foe.team[0].sid, foe.team[0].sz ? { sz: foe.team[0].sz } : undefined);   // 第65版: 再戦の 主は Gサイズ
  e.triggerEvent("mrpg:make_battle");
  e.addTag("mrpg_masterteam");
  e.setDynamicProperty("mrpg:lv", foe.team[0].lv);
  e.setDynamicProperty("mrpg:team", JSON.stringify(foe.team));
  e.setDynamicProperty("mrpg:mref", JSON.stringify(info));
  if (info && info.dream) try { e.addTag("mrpg_nightmare"); e.setProperty("mrpg:form", 2); } catch {}   // v3.0: 悪夢の 姿（鍔の ない 抜き身を ずっと 手に）
  particle(e, "minecraft:knockback_roar_particle", 1);
  let res = null;
  const h = HOLD.get(p.id) === p; if (h) busy.delete(p.id);
  try { res = await startBattle(p, e); } finally { if (ok(e)) try { e.remove(); } catch {} if (h && HOLD.get(p.id) === p) busy.add(p.id); }
  return res;
}

// npcMenu（闘技場）から よばれる。戦う ときは 関数を かえす
export async function arenaMenu(p, d) {
  const s = storyOf(d);
  const opts = CUPS.map((c, i) => {
    const open = i <= s.cup && d.mpt >= c.need;
    return [`${i < s.cup ? "§6○ " : open ? "§l" : "§8× "}${RI[c.r]} ${c.name}\n§7${i < s.cup ? "制覇 ずみ（再戦 OK）" : `必要 ${c.need}pt`}`, ICON("i_fight")];
  });
  const finalOpen = s.cup >= CUPS.length;
  opts.push([`${finalOpen ? "§c§l" : "§8× "}星冠の 王座\n§7${finalOpen ? (s.final ? `再戦（${(s.rematch || 0) + 1}かいめ）` : "星冠王 ゼファード") : "SSカップ 制覇で 開く"}`, ICON("i_scout")]);
  const t0 = (() => { try { return townAt(p.location, 60)?.id === "t0"; } catch { return false; } })();
  const po = postOpen(d);
  opts.push([`${po && t0 ? "§b§l" : "§8× "}${po ? KENGO.name : "？？？"}\n§7${po ? (t0 ? `勝利 ${s.kg || 0}かい${s.kgHaken ? ` §4${SPECIES.haken?.name || "厄王"}` : ""}` : "始まりの町 ルミナの 闘技場に いる") : "三つの 試練を 越えると 現れる"}`, ICON("i_fight")]);
  opts.push(["§7戻る", ICON("i_back")]);
  const sel = await choose(p, "マスターリーグ", `§fマスターポイント §e${d.mpt}\n${chapterText(d)}\n§7${nextGoal(d).replace(/§./g, "")}`, opts);
  if (sel === CUPS.length + 1) {
    if (!po) { await notice(p, "？？？", ["§7まだ 姿を あらわさない……", "", `${s.final ? "§a○" : "§c×"} §f星冠王 ゼファードに 勝つ`, `${s.bsFinal ? "§a○" : "§c×"} §f王冠の石板を 封印する（${s.bs.length}/${BS_N}）`, `${s.ruinFinal ? "§a○" : "§c×"} §f終の遺跡の 墓守に 勝つ（遺跡 ${Math.min(s.ruins, RUIN_NEED)}/${RUIN_NEED}）`].join("\n")); return null; }
    if (!t0) { await notice(p, KENGO.name, "§b伝説の マスターは §f始まりの町 ルミナ§b の 闘技場で 待っている。"); return null; }
    if (!(await confirm(p, KENGO.name, kengoText(s) + "\n\n§7勝つほど 強くなる・勝つたびに 豪華な ほうび\n§7パーティの 制限は なし", "挑む！", "やめる"))) return null;
    return () => runKengo(p);
  }
  if (sel < 0 || sel > CUPS.length) return null;
  if (sel === CUPS.length) {
    if (!finalOpen) { await notice(p, "星冠の 王座", "§7とびらは かたく とざされている……\n§fSSランクの せいかんカップを 制覇しよう。"); return null; }
    if (!(await confirm(p, FINAL.name, [...(s.final ? ["§c§lゼファード§r§f「また きたか。こんどは わたしも ほんきだ。」"] : FINAL.pre), "", `§7敵: Sランクの 精鋭（Lv${finalTeam(s, d)[0].lv - 2}前後・あなたの 手持ちに あわせる）`, "§7パーティの 制限は なし"].join("\n"), "挑む！", "やめる"))) return null;
    return () => runFinal(p);
  }
  const c = CUPS[sel];
  if (sel > s.cup) { await notice(p, c.name, "§7前の カップを さきに 制覇しよう。"); return null; }
  if (d.mpt < c.need) { await notice(p, c.name, `§cマスターポイントが たりない（${d.mpt}/${c.need}）\n§7フィールドの モンスターマスターを たおそう。`); return null; }
  if (!d.party.length) return null;
  if (!(await confirm(p, c.name, [`§l§e${c.name}§r §7（相手は ${RI[c.r]}ランク 以下の モンスター）`, `§f敵 Lv${Math.max(c.lv, avgLv(d.party) - 2)}〜 の 3れんせん`, `§f優勝: ${gold(c.gold)}${sel >= s.cup ? " ＋ " + c.items.map((i) => ITEMS[i]?.name).filter(Boolean).join("・") : "（再戦は はんぶん）"}`, "§7しあいの 前に 回復。逃げる・スカウトは できない。"].join("\n"), "エントリー！", "やめる"))) return null;
  return () => runCup(p, sel);
}

export async function runCup(p, ci) {
  await toSkyArena(p);
  try { await holdBusy(p, () => runCup0(p, ci)); } finally { backFromArena(p); }
}
async function runCup0(p, ci) {
  const c = CUPS[ci];
  for (let round = 0; round < 3; round++) {
    let d = load(p);
    if (!d) return;
    healAll(d); save(p, d);
    const foe = arenaTeam(d, ci, round);
    try { showTitle(p, `§e${c.name}`, { subtitle: `§f${["1かいせん", "じゅんけっしょう", "けっしょう"][round]}  vs ${foe.title} ${foe.name}`, fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
    sound(p, "raid.horn", 1);
    await notice(p, `${c.name} ${["1かいせん", "じゅんけっしょう", "けっしょう"][round]}`, [`§b${foe.title} ${foe.name}§f「${foe.line}」`, "", `§7相手: ${foe.team.map((t) => `${SPECIES[t.sid].name}(${SPECIES[t.sid].rank})`).join("・")}`].join("\n"));
    const res = await fight(p, foe, { tier: Math.min(2, Math.floor(ci / 3)), name: foe.name, fam: "", npc: null, arena: c.name, cupRe: ci < storyOf(d).cup });   // 第63版: 再戦は 賞金の 倍率なし
    if (res !== "win" && res !== "scout") {
      d = load(p); if (d) { healAll(d); save(p, d); }
      await notice(p, c.name, `§c${c.name}で 負けてしまった……\n§7仲間は 闘技場で 回復して もらった。強く なって また 挑もう！`);
      return;
    }
  }
  const d = load(p); if (!d) return;   /* 第69版 */
  const s = storyOf(d);
  const first = ci >= s.cup;
  healAll(d);
  const g = first ? c.gold : Math.floor(c.gold / 5);   // v3.0 第63版: 再戦は 5分の1
  d.gold += g;
  const got = [];
  if (first) {
    for (const id of c.items) if (ITEMS[id] && slabTierOk(d, ITEMS[id].slab || 0)) { giveItem(p, `mrpg:${id}`); got.push(ITEMS[id].name); }
    s.cup = Math.max(s.cup, ci + 1);
    const b = giveSlab(p, d, CUP_SLAB[ci]); if (b) got.push(`§d§l${b.name}§r`);
  }
  save(p, d); addMasterRank(p.name, d);
  sound(p, "ui.toast.challenge_complete", 1); particle(p, "minecraft:totem_particle", 1.5);
  try { showTitle(p, `§6§l${c.name} 優勝！`, { subtitle: `§f${RI[c.r]}ランク 制覇`, fadeInDuration: 5, stayDuration: 60, fadeOutDuration: 10 }); } catch {}
  if (first) for (const q of world.getAllPlayers()) if (q.id !== p.id) q.sendMessage(`§6★${p.name}が ${c.name}（${RI[c.r]}）を 制覇した！`);
  await notice(p, `${c.name} 優勝！`, [`§6§l★${c.name} 優勝！`, `§e${gold(g)}${got.length ? " ＋ " + got.join("・") : ""}`, "", ...(first ? c.story : ["§7（再戦 優勝）"]), "", "§f次の 目標:", nextGoal(d)].join("\n"));
}

export async function runFinal(p) {
  await toSkyArena(p);
  try { await holdBusy(p, () => runFinal0(p)); } finally { backFromArena(p); }
}
async function runFinal0(p) {
  let d = load(p);
  if (!d) return;
  const s = storyOf(d);
  healAll(d); save(p, d);
  try { showTitle(p, "§c§l星冠の 王座", { subtitle: `§f${FINAL.name}`, fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
  sound(p, "mob.enderdragon.growl", 0.8);
  const res = await fight(p, { team: finalTeam(s, d) }, { tier: 2, name: FINAL.name, fam: "", npc: null, arena: "星冠の 王座", final: true, rematch: !!s.final });
  d = load(p);
  if (!d) return;
  healAll(d);
  if (res !== "win" && res !== "scout") { save(p, d); await notice(p, "星冠の 王座", "§c§lゼファード§r§f「その ていどか。…また こい。」\n§7仲間は 回復して もらった。"); return; }
  const first = !s.final;
  s.final = true; s.rematch = (s.rematch || 0) + (first ? 0 : 1);
  const g = first ? 200000 : 50000;
  d.gold += g;
  const got = [];
  const give = (id, n = 1) => { if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); } };
  if (first) { const cr = giveCrown(p, d); if (cr) got.push(`§6§l${cr.name}§r`); give("e_king"); give("e_rainbow", 2); give("i_awaken"); }
  else { give(endingDone(d) ? "sl3" : "e_rainbow"); if (Math.random() < 0.25) give("e_king"); if (Math.random() < 0.05) give("e_god"); }
  save(p, d); addMasterRank(p.name, d);
  try { showTitle(p, first ? "§6§l星冠王 たんじょう！" : "§6§l星冠の 王座", { subtitle: `§f${p.name}`, fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
  for (const q of world.getAllPlayers()) { q.sendMessage(first ? `§6§l★ ${p.name}が 星冠王 ゼファードを 倒し、新しい 星冠王に なった！ ★` : `§6★ ${p.name}が 星冠王 ゼファードに ふたたび かった！`); sound(q, "ui.toast.challenge_complete", 1); }
  await notice(p, first ? "星冠王 たんじょう" : "星冠の 王座", [...(first ? FINAL.end : ["§c§lゼファード§r§f「みごとだ。だが わたしも まだ 強くなる。」"]), "", `§e${gold(g)} ＋ ${got.join("・")}`].join("\n"));
  const d2 = load(p); if (d2) await maybeEnding(p, d2);
}

// v2.2: 剣聖 カゲツ（ラスボスの あと・10勝で 厄王ヴァルグレイド）
export async function runKengo(p) {
  await toSkyArena(p);
  try { await holdBusy(p, () => runKengo0(p)); } finally { backFromArena(p); }
}
async function runKengo0(p) {
  let d = load(p);
  if (!d) return;
  const s = storyOf(d);
  healAll(d); save(p, d);
  try { showTitle(p, `§b§l${KENGO.name}`, { subtitle: `§f勝利 ${s.kg || 0}/${KENGO.need}`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
  sound(p, "raid.horn", 0.8);
  const res = await fight(p, { team: kengoTeam(s.kg || 0) }, { tier: 2, name: KENGO.name, fam: "", npc: null, arena: "伝説の 間", kengo: true, rematch: (s.kg || 0) > 0 });
  d = load(p);
  if (!d || !ok(p)) return;   /* 第68版: 勝った 直後に ぬけた ときは ごほうびを 書かない */
  healAll(d);
  if (res !== "win") { save(p, d); await notice(p, KENGO.name, `§b§lカゲツ§r§f「${pick(["刀が 泣いて いるぞ。また こい。", "読みが 浅い。おまえの 仲間は もっと 考えて 動ける はずだ。", "力で 押すだけでは 届かん。"])}」\n§7仲間は 回復して もらった。`); return; }
  await kengoReward(p, d, storyOf(d));
}

// 初めて ブックを 開いた とき
export async function prologue(p, d) {
  const s = storyOf(d);
  if (s.met) return;
  s.met = true; save(p, d);
  await notice(p, "プロローグ", [WORLD_TEXT, "",
    "§eオルド§f「わしは ルミナの 長老 オルド。……ふむ、おまえさん、モンスターに よう 好かれるのう。」",
    "§f「それは 才能じゃ。だが 好いてくるのは 良き ものだけでは ない。§c古い 石板§f には 気を つけい。」",
    "§f「寂れた 石板は、各地方の §6城§f に いる §6地方マスター§f たちが 守っておる。まずは 北の §aアルカトラス城§f を たずねるとよい。§e闘技場§f の 優勝者や §6遺跡§f の 主が 持つ ことも ある。」",
    "§f「触れれば 石板の 中へ 引きこまれる。奥に 潜む 主を たおし、ふたたび 封じるのじゃ。魅入られながらも 呑まれぬ 者に しか できん。」",
    "", "§7ブック →「ストーリー」で いつでも 確認 できます。"].join("\n"));
}
