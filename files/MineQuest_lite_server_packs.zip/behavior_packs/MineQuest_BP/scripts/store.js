// プレイヤーごとのセーブデータ（分割保存・キャッシュつき）
import { world } from "@minecraft/server";
import { SPECIES } from "./data.js";
import { migrate, calcStats } from "./core.js";

const KEY = "mrpg";
const CHUNK = 10000;   // v2.9.9: 日本語は 1文字 3バイト。3万字だと 上限（約32KB）を こえる ことが あるので 1万字ずつ
const cache = new Map();
const lastW = new Map();   // 最後に 書いた 中身（同じなら 書かない）

export function mark(list, sp) { const i = SPECIES[sp].idx; if (!list.includes(i)) list.push(i); }
export const allMons = (d) => [...d.party, ...(d.bench || []), ...d.box];
// v2.9.12: 牧場・育て屋に いる 子も ふくめる（バックアップの 装備・読みこみ直しに 使う）
export const allMonsDeep = (d) => { const e = d.eg || {}; return [...allMons(d), ...((e.ranch && e.ranch.mons) || []), ...(e.care ? [e.care.a, e.care.b].filter(Boolean) : [])]; };

function readRaw(p) {
  const n = p.getDynamicProperty(`${KEY}#n`);
  if (typeof n === "number") {
    let s = "";
    for (let i = 0; i < n; i++) s += p.getDynamicProperty(`${KEY}#${i}`) || "";
    return s;
  }
  const old = p.getDynamicProperty(KEY);
  return typeof old === "string" ? old : null;
}

// v2.9.12: 読めない データは 消さずに とって おく（最初の 仲間えらびで 上書き しない）
export function isBroken(p) { try { return typeof p.getDynamicProperty("mrpg:broken") === "string"; } catch { return false; } }
function markBroken(p, s) { try { if (!isBroken(p)) p.setDynamicProperty("mrpg:broken", String(s).slice(0, 10000)); } catch {} }
export function clearBroken(p) { try { p.setDynamicProperty("mrpg:broken", undefined); } catch {} }
export function load(p) {
  try { if (!p || !p.isValid()) return null; } catch { return null; }   /* 第69版: 抜けた プレイヤーで キャッシュを こわさない */
  if (cache.has(p.id)) return cache.get(p.id);
  const s = readRaw(p);
  if (!s) return null;
  let d;
  try { d = JSON.parse(s); } catch { markBroken(p, s); return null; }
  if (!d || typeof d !== "object") { markBroken(p, s); return null; }
  if (!Array.isArray(d.party)) d.party = [];   // v2.9.12: こわれた データでも 入れなく ならない
  for (const k of ["box", "bench", "own", "seen"]) if (d[k] !== undefined && !Array.isArray(d[k])) d[k] = [];
  if (typeof d.gold === "string" && isFinite(Number(d.gold))) d.gold = Number(d.gold);
  if (d.eg && d.eg.ranch && !Array.isArray(d.eg.ranch.mons)) d.eg.ranch.mons = [];
  if (!d.box) d.box = [];
  if (!d.bench) d.bench = [];
  if (!d.seen) d.seen = [];
  if (!d.own) d.own = [];
  if (d.out === undefined) d.out = null;
  if (typeof d.gold !== "number") d.gold = 0; capGold(d);
  if (!d.stats) d.stats = { wins: 0, pvp: 0, fused: 0 };
  if (!d.stats || typeof d.stats !== "object") d.stats = { wins: 0, pvp: 0, fused: 0 };
  if (d.eg !== undefined && (typeof d.eg !== "object" || d.eg === null || Array.isArray(d.eg))) d.eg = {};   /* 第69版: 型ちがいの 項目 */
  for (const m of allMonsDeep(d)) { if (!m || !SPECIES[m.sp]) continue; try { migrate(m); } catch {} if (m.eqr !== undefined && (typeof m.eqr !== "object" || m.eqr === null)) m.eqr = {}; mark(d.own, m.sp); mark(d.seen, m.sp); if (!Number.isFinite(m.hp) || !Number.isFinite(m.mp)) { try { const c = calcStats(m); if (!Number.isFinite(m.hp)) m.hp = c.hp; if (!Number.isFinite(m.mp)) m.mp = c.mp; } catch {} } }   /* 第68版: HPが ない 子 */
  { // v2.9.12: 知らない 種族の 子は 消さずに しまって おく（アドオンを もどせば 帰ってくる）
    const bad = [...d.party, ...d.box, ...d.bench].filter((m) => !m || !SPECIES[m.sp]);
    if (bad.length) d.lost = [...(d.lost || []), ...bad.filter(Boolean)].slice(-60);
    if (Array.isArray(d.lost) && d.lost.length) { const back = d.lost.filter((m) => SPECIES[m.sp]); if (back.length) { d.box.push(...back); d.lost = d.lost.filter((m) => !SPECIES[m.sp]); for (const m of back) migrate(m); } }
  }
  d.party = d.party.filter((m) => m && SPECIES[m.sp]);
  d.box = d.box.filter((m) => m && SPECIES[m.sp]);
  d.bench = d.bench.filter((m) => m && SPECIES[m.sp]);
  // 旧バージョン: 5体目以降は 控えへ
  // v2.1: パーティは 枠（S1・M2・L3・G4）の 合計 4まで
  const slot = (m) => ({ S: 1, M: 2, L: 3, G: 4 }[m.sz || SPECIES[m.sp]?.sz] || 2);
  while (d.party.length > 1 && d.party.reduce((s, m) => s + slot(m), 0) > 4) d.box.push(d.party.pop());
  // 第68版: 裏（スタンバイ）は 4枠まで（こえた 子は 預かり所へ）
  while (d.bench.length && d.bench.reduce((s, m) => s + slot(m), 0) > 4) d.box.unshift(d.bench.pop());
  if (!d.party.length) { const src = d.bench.length ? d.bench : d.box; if (src.length) d.party.push(src.shift()); }   /* 第69版: 手持ち 0体を ふせぐ（裏を 先に） */
  { const seenId = new Set(); for (const m of [...d.party, ...d.bench, ...d.box]) { if (!m) continue; if (m.id && seenId.has(m.id)) m.id = `${m.id}_${Math.floor(Math.random() * 1e6)}`; if (m.id) seenId.add(m.id); } }
  cache.set(p.id, d);
  return d;
}

export const GOLD_MAX = 99999999;   // v3.0: お金の 上限
const capGold = (d) => { if (d && typeof d.gold === "number") d.gold = Number.isFinite(d.gold) ? Math.max(0, Math.min(GOLD_MAX, Math.floor(d.gold))) : 0; };
export function save(p, d) {
  capGold(d);
  try { if (!p.isValid()) return false; } catch { return false; }   // v3.0: 抜けた 人の 古い オブジェクトでは 書かない（データが 二つに 分かれない）
  cache.set(p.id, d);
  const s = JSON.stringify(d);
  const n = Math.ceil(s.length / CHUNK);
  const oldN = p.getDynamicProperty(`${KEY}#n`);
  // v2.9.4: 変わった 部分だけ 書きこむ（セーブの たびの カクつきを へらす）
  let prev = lastW.get(p.id);
  if (!prev || prev.n !== oldN) prev = { n: oldN, c: [] };
  const c = [];
  for (let i = 0; i < n; i++) { const part = s.slice(i * CHUNK, (i + 1) * CHUNK); c.push(part); if (prev.c[i] !== part) p.setDynamicProperty(`${KEY}#${i}`, part); }
  lastW.set(p.id, { n, c });
  if (typeof oldN === "number") for (let i = n; i < oldN; i++) p.setDynamicProperty(`${KEY}#${i}`, undefined);
  p.setDynamicProperty(`${KEY}#n`, n);
  if (p.getDynamicProperty(KEY) !== undefined) p.setDynamicProperty(KEY, undefined);
}

export function wipe(p) {
  cache.delete(p.id); lastW.delete(p.id);
  const n = p.getDynamicProperty(`${KEY}#n`);
  if (typeof n === "number") for (let i = 0; i < n; i++) p.setDynamicProperty(`${KEY}#${i}`, undefined);
  p.setDynamicProperty(`${KEY}#n`, undefined);
  p.setDynamicProperty(KEY, undefined);
}

export function forget(pid) { cache.delete(pid); lastW.delete(pid); }
world.afterEvents.playerLeave.subscribe(({ playerId }) => forget(playerId));

// ---- ワールド共通データ（共有の預かり所・ランキング） ----
function readWorld(key) {
  const n = world.getDynamicProperty(`${key}#n`);
  if (typeof n !== "number") return null;
  let s = "";
  for (let i = 0; i < n; i++) s += world.getDynamicProperty(`${key}#${i}`) || "";
  try { return JSON.parse(s); } catch { return null; }
}
function writeWorld(key, v) {
  const s = JSON.stringify(v);
  const n = Math.max(1, Math.ceil(s.length / CHUNK));
  const old = world.getDynamicProperty(`${key}#n`);
  for (let i = 0; i < n; i++) world.setDynamicProperty(`${key}#${i}`, s.slice(i * CHUNK, (i + 1) * CHUNK));
  if (typeof old === "number") for (let i = n; i < old; i++) world.setDynamicProperty(`${key}#${i}`, undefined);
  world.setDynamicProperty(`${key}#n`, n);
}
// v2.6: やりこみの ランキング・ゴースト など
export const loadW = (k, def) => { const v = readWorld(k); return v === null || v === undefined ? def : v; };
export const saveW = (k, v) => writeWorld(k, v);
export const loadShared = () => readWorld("mrpg_shared") || [];
export const saveShared = (list) => writeWorld("mrpg_shared", list);
export const loadRank = () => readWorld("mrpg_rank") || {};
export const saveRank = (r) => writeWorld("mrpg_rank", r);
export function addRank(name, win) {
  const r = loadRank();
  const e = r[name] || (r[name] = { w: 0, l: 0 });
  if (win) e.w++; else e.l++;
  saveRank(r);
}

// ---- v1.7: セーブの バックアップ（3スロット ＋ 自動）----
// プレイヤーの 動的プロパティに 分けて しまう。データが 壊れたり 間違えて 手放した ときに 戻せる
export const BK_SLOTS = ["a", "1", "2", "3"]; // a = 自動
const bkKey = (s) => `mrpg_bk${s}`;
export function backupInfo(p, slot) {
  const m = p.getDynamicProperty(`${bkKey(slot)}:meta`);
  if (typeof m !== "string") return null;
  try { return JSON.parse(m); } catch { return null; }
}
export function backupSave(p, slot, d, ver, raw) {
  const s = raw || JSON.stringify(d), key = bkKey(slot);
  const n = Math.max(1, Math.ceil(s.length / CHUNK));
  const old = p.getDynamicProperty(`${key}#n`);
  for (let i = 0; i < n; i++) p.setDynamicProperty(`${key}#${i}`, s.slice(i * CHUNK, (i + 1) * CHUNK));
  if (typeof old === "number") for (let i = n; i < old; i++) p.setDynamicProperty(`${key}#${i}`, undefined);
  p.setDynamicProperty(`${key}#n`, n);
  const now = new Date();
  const meta = { t: now.getTime(), day: now.toISOString().slice(0, 10), ver, mons: allMons(d).length, gold: d.gold || 0, lv: Math.max(0, ...allMons(d).map((m) => m.lv || 0)) };
  p.setDynamicProperty(`${key}:meta`, JSON.stringify(meta));
  return meta;
}
export function backupLoad(p, slot) {
  const key = bkKey(slot);
  const n = p.getDynamicProperty(`${key}#n`);
  if (typeof n !== "number") return null;
  let s = "";
  for (let i = 0; i < n; i++) s += p.getDynamicProperty(`${key}#${i}`) || "";
  let d;
  try { d = JSON.parse(s); } catch { return null; }
  if (!d || !Array.isArray(d.party)) return null;
  const held = cache.get(p.id);
  cache.delete(p.id); lastW.delete(p.id);
  save(p, d);
  cache.delete(p.id);
  const fresh = load(p);
  // v2.9.6: ひらいて いる 画面が もって いる 古い データも 中身を 入れかえる（あとの セーブで もとに もどらない よう）
  if (held && fresh && held !== fresh) { for (const k of Object.keys(held)) delete held[k]; Object.assign(held, fresh); cache.set(p.id, held); return held; }
  return fresh;
}
export function backupDelete(p, slot) {
  const key = bkKey(slot);
  const n = p.getDynamicProperty(`${key}#n`);
  if (typeof n === "number") for (let i = 0; i < n; i++) p.setDynamicProperty(`${key}#${i}`, undefined);
  p.setDynamicProperty(`${key}#n`, undefined);
  p.setDynamicProperty(`${key}:meta`, undefined);
}
// 自動: バージョンが かわった とき・1日1回
export function autoBackup(p, ver) {
  const d = load(p);
  if (!d || !allMons(d).length) return false;
  const m = backupInfo(p, "a"), today = new Date().toISOString().slice(0, 10);
  if (m && m.ver === ver && m.day === today) return false;
  // 読み込み前の そのままの データを 写す（新しい バージョンで 変わる 前の 状態）
  backupSave(p, "a", d, ver, readRaw(p));
  return true;
}

// v2.9.5: ホスト（この ワールドに いちばん 最初に 入った ひと）。テスト メニューと チートは ホストだけ（ホストが 許可すれば みんな）
export function noteHost(p) { try { if (typeof world.getDynamicProperty("mrpg:host") !== "string") world.setDynamicProperty("mrpg:host", p.id); } catch {} }
export function isHost(p) { try { const h = world.getDynamicProperty("mrpg:host"); return typeof h !== "string" || h === p.id || world.getDynamicProperty("mrpg:cheatall") === true; } catch { return true; } }
export function isRealHost(p) { try { const h = world.getDynamicProperty("mrpg:host"); return typeof h !== "string" || h === p.id; } catch { return true; } }
