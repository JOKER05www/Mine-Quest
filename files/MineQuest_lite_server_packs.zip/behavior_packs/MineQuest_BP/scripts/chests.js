// v2.6.1: 宝箱の レア度（10段階: 小さな宝箱 〜 神箱）
// 宝箱そのものは ふつうの チェスト。レア度ごとに 中身（ルートテーブル）が ちがい、開けると 名前が 出る。レア度4以上は 光の 粒が 出る
import { showTitle } from "./ui.js";
import { world, system, ItemStack } from "@minecraft/server";
import { regionLv } from "./worldmap.js";
import { ITEMS } from "./data.js";
import { inLiveBox } from "./stage.js";

export const CHEST_TIERS = [
  { n: "小さな宝箱", c: "§f", b: "barrel" },
  { n: "木の宝箱", c: "§6", b: "chest" },
  { n: "鉄の宝箱", c: "§7", b: "light_gray_shulker_box" },
  { n: "銀の宝箱", c: "§b", b: "white_shulker_box", p: "minecraft:villager_happy" },
  { n: "金の宝箱", c: "§e", b: "yellow_shulker_box", p: "minecraft:villager_happy" },
  { n: "宝石の宝箱", c: "§a", b: "lime_shulker_box", p: "minecraft:totem_particle" },
  { n: "魔法の宝箱", c: "§d", b: "magenta_shulker_box", p: "minecraft:enchanting_table_particle" },
  { n: "王家の宝箱", c: "§6§l", b: "red_shulker_box", p: "minecraft:totem_particle" },
  { n: "伝説の宝箱", c: "§c§l", b: "black_shulker_box", p: "minecraft:endrod" },
  { n: "神箱", c: "§5§l", b: "purple_shulker_box", p: "minecraft:endrod" },
];
export const tierName = (t) => { const T = CHEST_TIERS[Math.max(1, Math.min(10, t)) - 1]; return `${T.c}${T.n}§r`; };
export const chestTable = (t) => `mrpg/chest${Math.max(1, Math.min(10, t))}`;
// 土地の 強さで 上がる ぶん（Lv40で +1・Lv70で +2）
export function lvBonus(loc) { try { const lv = regionLv(loc); return lv >= 70 ? 2 : lv >= 40 ? 1 : 0; } catch { return 0; } }
// ときどき 上の 段に（+1: 22%・+2: 6%・+3: 1.5%・+4: 0.3%）。神箱は god=true の ときだけ
export function rollTier(base, bonus = 0, god = false) {
  const r = Math.random();
  const up = r < 0.003 ? 4 : r < 0.018 ? 3 : r < 0.078 ? 2 : r < 0.298 ? 1 : 0;
  return Math.max(1, Math.min(god ? 10 : 9, base + bonus + up));
}
// 古い テーブル名 → 段
export const BASE_OF = { "mrpg/roadside": 2, "mrpg/house": 3, "mrpg/treasure": 5 };

// ---- 置いた 宝箱を おぼえる（開けた ときに 名前を 出す・光らせる）----
const KEY = "mrpg:chests", MAX = 600;   /* 第84版: 400 → 600（滅びた 世界の 宝箱の ぶん） */
let LIST = null;
function list() { if (!LIST) { try { LIST = JSON.parse(world.getDynamicProperty(KEY) || "[]"); } catch { LIST = []; } } return LIST; }
let dirty = false;
function flush() { if (!dirty) return; dirty = false; try { world.setDynamicProperty(KEY, JSON.stringify(list().slice(-MAX))); } catch {} }
/* 第84版: 近くの 登録ずみの 宝箱（滅びた 世界の 破壊で 箱を 元に もどす ため） */
export function chestsNear(dim, x, y, z, r) { const out = []; for (const [k, t] of list()) { const [d, xs, ys, zs] = k.split("|"); if (d !== dim) continue; const X = +xs, Y = +ys, Z = +zs; if (Math.abs(X - x) <= r && Math.abs(Y - y) <= r && Math.abs(Z - z) <= r) out.push({ x: X, y: Y, z: Z, t }); } return out; }
export function registerChest(x, y, z, t, dim = "minecraft:overworld", empty = false) {
  const L = list(); const k = `${dim}|${x}|${y}|${z}`;
  const i = L.findIndex((c) => c[0] === k); if (i >= 0) L.splice(i, 1);
  L.push(empty ? [k, t, 1] : [k, t]); if (L.length > MAX) L.splice(0, L.length - MAX); dirty = true;
}
// 宝箱を 置く コマンド（setblock ＋ loot insert）。置いた 場所も おぼえる
// 段ごとに 見た目が ちがう（たる・チェスト・色つきの シュルカーボックス）
export const BOX_RE = /chest|barrel|shulker_box/;
// v2.9.12: 中身は 開けた ときに 入れる（ホッパーや 爆発で 先に 取り出せない ように）
export function chestCmds(x, y, z, t, dim) { t = Math.max(1, Math.min(10, t)); registerChest(x, y, z, t, dim, true); return [`setblock ${x} ${y} ${z} ${CHEST_TIERS[t - 1].b}`]; }

let tick = 0;
export function initChests() {
  system.runInterval(() => {
    tick++; if (tick % 5 === 0) flush();
    const L = list(); if (!L.length) return;
    for (const p of world.getAllPlayers()) {
      const dim = p.dimension, loc = p.location;
      for (const [k, t] of [...L]) {
        const [d, xs, ys, zs] = k.split("|"); if (d !== dim.id) continue;
        const x = +xs, y = +ys, z = +zs;
        if (Math.abs(x - loc.x) > 14 || Math.abs(z - loc.z) > 14 || Math.abs(y - loc.y) > 8) continue;
        try { const b = dim.getBlock({ x, y, z }); if (b && !BOX_RE.test(String(b.typeId)) && !FIGHTING.has(k) && !CHEST_PEND.has(k) && !inLiveBox(d, { x, y, z })) {   /* v2.9.13: 戦いの 場所では 箱が 一時的に 消えるので 記録は のこす */ const i = L.findIndex((c) => c[0] === k); if (i >= 0) { L.splice(i, 1); dirty = true; } continue; } } catch {}
        if (t >= 4) try { dim.spawnParticle(CHEST_TIERS[t - 1].p, { x: x + 0.5, y: y + 1.1, z: z + 0.5 }); } catch {}
      }
    }
  }, 30);
  // v2.9.9: こわした 宝箱は 記録から 消す（あとで 同じ 場所に 自分の 箱を 置いても 中身が 吸いこまれない）
  try {
    world.afterEvents.playerBreakBlock.subscribe((ev) => {
      try {
        const b = ev.block, k = `${b.dimension.id}|${b.location.x}|${b.location.y}|${b.location.z}`;
        const L = list(), i = L.findIndex((c) => c[0] === k); if (i >= 0) { L.splice(i, 1); dirty = true; }
      } catch {}
    });
  } catch {}
  // v2.9.12: 宝箱を こわした ときも 開けた ときと 同じ（中身は 物語の 進みで しらべて バッグへ）
  try {
    world.beforeEvents.playerBreakBlock.subscribe((ev) => {
      try {
        const b = ev.block; if (!b || !BOX_RE.test(String(b.typeId))) return;
        const k = `${b.dimension.id}|${b.location.x}|${b.location.y}|${b.location.z}`;
        if (!list().some((c) => c[0] === k)) return;
        ev.cancel = true;
        if (FIGHTING.has(k) || inLiveBox(b.dimension.id, b.location)) return;   // v2.9.13: 戦いの 最中の 箱は こわせない
        const p = ev.player, loc = { ...b.location }, dimId = b.dimension.id;
        system.run(() => collectChest(p, dimId, loc, k));
      } catch {}
    });
  } catch {}
  // v2.9.5: 宝箱（たる・チェスト）を 開けると 中身を 一括で バッグへ。取りおわった 箱は 消える
  try {
    world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
      try {
        if (ev.isFirstEvent === false) return;
        const b = ev.block; if (!b || !BOX_RE.test(String(b.typeId))) return;
        const k = `${b.dimension.id}|${b.location.x}|${b.location.y}|${b.location.z}`;
        if (!list().some((c) => c[0] === k)) return;   // じぶんで 置いた 箱や ふつうの 箱は そのまま
        ev.cancel = true;
        if (inLiveBox(b.dimension.id, b.location)) return;   // v2.9.13: 戦いの 場所の 箱は 開けない（中身が 2倍に なるのを ふせぐ）
        const p = ev.player, loc = { ...b.location }, dimId = b.dimension.id;
        system.run(() => { openChest(p, dimId, loc, k).catch(() => {}); });
      } catch {}
    });
  } catch {}
}
// v2.9.13: ハコダマシ（宝箱に 化けた モンスター）。開けると まれに 戦いに なる。勝つと 中身が 1段 よくなる
export const MIMIC_RATE = 0.06;
const FIGHTING = new Map();   // 箱 → 戦って いる 人の 名前
export const CHEST_PEND = new Set();   /* 第85版: 滅びた 世界で 壊されて 戻る 途中の 箱（記録を 消さない） */
async function openChest(p, dimId, loc, k) {
  if (FIGHTING.has(k)) { try { p.sendMessage(`§7${FIGHTING.get(k)} が この 宝箱の ハコダマシと 戦って いる……`); } catch {} return; }
  const L = list(), i = L.findIndex((c) => c[0] === k); if (i < 0) return;
  const t = L[i][1];
  const rolled = L[i][3] === 1;
  if (!rolled) { L[i] = [L[i][0], L[i][1], L[i][2] || 0, 1]; dirty = true; }
  let go = false;
  try { go = !rolled && t >= 2 && Math.random() < MIMIC_RATE && typeof CHEST_GATE.mimic === "function" && CHEST_GATE.mimicOk && CHEST_GATE.mimicOk(p); } catch { go = false; }
  if (!go) { collectChest(p, dimId, loc, k); return; }
  FIGHTING.set(k, p.name);
  let res = null;
  try {
    try { showTitle(p, "§c§l！", { subtitle: "§f宝箱が 動いた！ §cハコダマシ§f だ！", fadeInDuration: 2, stayDuration: 30, fadeOutDuration: 8 }); } catch {}
    try { p.playSound("random.chestopen", { pitch: 0.6, volume: 1 }); p.playSound("mob.zombie.wood", { pitch: 0.8, volume: 0.8 }); } catch {}
    try { world.getDimension(dimId).spawnParticle("minecraft:knockback_roar_particle", { x: loc.x + 0.5, y: loc.y + 0.8, z: loc.z + 0.5 }); } catch {}
    res = await CHEST_GATE.mimic(p, t, loc);
  } catch {}
  // 戦いの 場所が もとに もどる（箱が もどる）まで 少し まつ
  for (let w = 0; w < 30; w++) {
    let back = false; try { const b = world.getDimension(dimId).getBlock(loc); back = !!(b && BOX_RE.test(String(b.typeId))) && !inLiveBox(dimId, loc); } catch {}
    if (back) break;
    await new Promise((r) => system.runTimeout(r, 10));
  }
  FIGHTING.delete(k);
  if (res === "win" || res === "scout") {
    const L2 = list(), j = L2.findIndex((c) => c[0] === k);
    if (j >= 0) { L2[j][1] = Math.max(L2[j][1], Math.min(9, L2[j][1] + 1)); dirty = true; }
    try { p.sendMessage("§eハコダマシを たおした！ §f宝箱の 中身が 1段 よくなった"); } catch {}
    try { if (p.isValid()) collectChest(p, dimId, loc, k); } catch {}
  } else {
    try { p.sendMessage("§7ハコダマシは 宝箱の ふりに もどった……（もう 一度 開ければ 中身を 取れる）"); } catch {}
  }
}
// v2.9.12: 物語より 先の 品は お金（コイン袋）に かえる（main.js で 判定を わたす）
export const CHEST_GATE = { fn: null, mimic: null, mimicOk: null, bonus: null };
const BUSY = new Set();
export function collectChest(p, dimId, loc, k) {
  if (BUSY.has(k)) return; BUSY.add(k);
  try {
    const L = list(); const i = L.findIndex((c) => c[0] === k); if (i < 0) return;
    const t = L[i][1];
    const dim = world.getDimension(dimId); const b = dim.getBlock(loc);
    if (!b || !BOX_RE.test(String(b.typeId))) { if (!FIGHTING.has(k) && !CHEST_PEND.has(k) && !inLiveBox(dimId, loc)) { L.splice(i, 1); dirty = true; } return; }
    if (L[i][2] === 1) { try { dim.runCommand(`loot insert ${loc.x} ${loc.y} ${loc.z} loot "${chestTable(t)}"`); } catch {} L[i] = [k, t]; dirty = true; }
    const box = b.getComponent("minecraft:inventory")?.container;
    const pinv = p.getComponent("minecraft:inventory")?.container;
    const got = new Map(); let n = 0, dropped = 0, swapped = 0;
    if (box) {
      for (let s = 0; s < box.size; s++) {
        let it = box.getItem(s); if (!it) continue;
        let id = it.typeId.startsWith("mrpg:") ? it.typeId.slice(5) : null;
        let gated = false;
        try { if (id && ITEMS[id] && CHEST_GATE.fn && !CHEST_GATE.fn(p, id)) gated = true; } catch {}
        if (gated) {
          const v = Math.max(60, Math.floor((ITEMS[id].price || 600 * (ITEMS[id].tier || 1)) / 2)) * it.amount;
          box.setItem(s, undefined); swapped++;
          const cid = v >= 600 ? "m_bag" : "m_coin", cn = Math.max(1, Math.min(64, Math.round(v / ITEMS[cid].val)));
          let st = null; try { st = new ItemStack(`mrpg:${cid}`, cn); } catch {}
          if (!st) continue;
          it = st; id = cid;
        }
        const nm = it.nameTag || (id && ITEMS[id]?.name) || it.typeId.replace(/^minecraft:/, "").replace(/_/g, " ");
        got.set(nm, (got.get(nm) || 0) + it.amount); n += it.amount;
        box.setItem(s, undefined);
        let left = it;
        try { left = pinv ? pinv.addItem(it) : it; } catch {}
        if (left) { dropped += left.amount; try { dim.spawnItem(left, p.location); } catch {} }
      }
    }
    /* 第76版: 上位の 宝箱（★8〜）と 滅びた 世界の 宝箱は 神果・秘果などの ごほうびが 出やすい */
    try {
      const extra = CHEST_GATE.bonus ? CHEST_GATE.bonus(p, t, loc, dimId) || [] : [];
      for (const id of extra) {
        if (!ITEMS[id] || (CHEST_GATE.fn && !CHEST_GATE.fn(p, id))) continue;
        let st = null; try { st = new ItemStack(`mrpg:${id}`, 1); } catch {} if (!st) continue;
        let left = st; try { left = pinv ? pinv.addItem(st) : st; } catch {}
        if (left) { dropped += left.amount; try { dim.spawnItem(left, p.location); } catch {} }
        const nm = `§d${ITEMS[id].name}`; got.set(nm, (got.get(nm) || 0) + 1); n++;
      }
    } catch {}
    try { b.setType("minecraft:air"); } catch { try { dim.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} air`); } catch {} }
    L.splice(i, 1); dirty = true;
    try { dim.spawnParticle("minecraft:villager_happy", { x: loc.x + 0.5, y: loc.y + 0.6, z: loc.z + 0.5 }); } catch {}
    try { showTitle(p, " ", { subtitle: `${tierName(t)} を あけた！`, fadeInDuration: 2, stayDuration: 30, fadeOutDuration: 8 }); } catch {}
    try { p.playSound(t >= 8 ? "ui.toast.challenge_complete" : t >= 5 ? "random.levelup" : "random.pop", { pitch: 1, volume: 0.8 }); } catch {}
    const lines = [...got].map(([nm, c]) => `§f${nm}§7×${c}`);
    try { p.sendMessage(n ? `§e${tierName(t)}§e の 中身を 手に入れた（${n}個）: ${lines.join("§7、")}${dropped ? `\n§c持ち物が いっぱいで ${dropped}個 足もとに 落ちた` : ""}${swapped ? `\n§7（物語より 先の 品 ${swapped}つは お金に かわった）` : ""}` : `§7${tierName(t)}§7 は からっぽ だった。`); } catch {}
    if (t >= 8) for (const q of world.getAllPlayers()) try { q.sendMessage(`§6＊ ${p.name}が ${tierName(t)}§6 を 見つけた！`); } catch {}
  } catch {} finally { BUSY.delete(k); }
}
