// 第123版: 物語の 場面の「舞台」
// ・場面ごとに 平らで 開けた 場所（9×9・木や 屋根の 下では ない）を さがし、プレイヤーを 立ち位置へ 移す
// ・役者は 舞台の 決まった 立ち位置（話す 人は 正面の 弧・旅の 仲間は となり・敵は 向こう側）に 立つ。重ならない・葉や 柵の 上に 立たない
// ・まわりの 町の 人や 動物は 場面の あいだ 見えなく して、終わったら もどす（ぬけても 次に 読みこんだ とき もどる）
// ・カメラの 見通し（壁・屋台・木に さえぎられないか）を 調べる 道具
import { world, system } from "@minecraft/server";

const PASS = /^minecraft:(air|cave_air|short_grass|tallgrass|tall_grass|fern|large_fern|deadbush|snow_layer|torch|soul_torch|vine|glow_lichen|red_flower|yellow_flower|poppy|dandelion|cornflower|oxeye_daisy|azure_bluet|allium|blue_orchid|lily_of_the_valley|pink_petals|wildflowers|rail|redstone_wire|light_block|structure_void|seagrass)$|_carpet$|^minecraft:carpet$|_tulip$|_sapling$|_button$|_pressure_plate$/;
const BADG = /leaves|_log$|^minecraft:log2?$|_wood$|_stem$|hyphae|fence|_wall$|cobblestone_wall|pane|iron_bars|cactus|campfire|magma|water|lava|_bed$|^minecraft:bed$|_door$|trapdoor|scaffolding|_sign$|banner|chest|barrel|lectern|anvil|cauldron|brewing_stand|bell$|lantern|_slab$|hopper/;
const VIEW = /glass|pane$|iron_bars|chain$/;
export const passB = (b) => !b || b.isAir || (!b.isLiquid && PASS.test(b.typeId));
export const groundB = (b) => !!b && !b.isAir && !b.isLiquid && !PASS.test(b.typeId) && !BADG.test(b.typeId);
const viewB = (b) => b !== undefined && (passB(b) || VIEW.test(b.typeId));
/* ブロックを 読む（同じ 場面では 覚えておく）。読みこまれて いない 所は undefined */
export function blk(dim, x, y, z, C) {
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  const k = `${x},${y},${z}`; if (C && C.has(k)) return C.get(k);
  let b; try { b = dim.getBlock({ x, y, z }) || null; } catch { b = undefined; }
  if (C) C.set(k, b); return b;
}
/* (x,z) で 立てる 高さ（足の ブロック）。y0 に いちばん 近い 所。葉・丸太・柵・水の 上は だめ */
export function standY(dim, x, z, y0, C) {
  y0 = Math.floor(y0);
  for (const d of [0, 1, -1, 2, -2, 3, -3, -4]) {
    const y = y0 + d, g = blk(dim, x, y - 1, z, C); if (g === undefined) continue;
    if (groundB(g) && passB(blk(dim, x, y, z, C)) && passB(blk(dim, x, y + 1, z, C))) return y;
  }
  return null;
}
/* 頭の 上（2〜3マス上）に 葉・屋根が ある */
export function overhead(dim, x, y, z, C) { for (const k of [2, 3]) { const b = blk(dim, x, y + k, z, C); if (b && !passB(b)) return true; } return false; }
/* a から b が 見えるか（b の 手前 skip マスは 見ない）*/
export function los(dim, a, b, C, skip = 0.45) {
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, L = Math.hypot(dx, dy, dz); if (!(L > 0.01)) return true;
  const n = Math.ceil(L / 0.12);
  for (let i = 0; i <= n; i++) { const t = i / n; if (L * (1 - t) < skip) break; if (!viewB(blk(dim, a.x + dx * t, a.y + dy * t, a.z + dz * t, C))) return false; }
  return true;
}
const polar = (r, D) => D.map((d) => [r * Math.cos((d * Math.PI) / 180), r * Math.sin((d * Math.PI) / 180)]);
/* 立ち位置（前へ, 右へ）。プレイヤーは (0,0) で 前を 向く */
export const SLOTS = {
  hero: [[0.4, -1.6], [0.4, 1.6], [-0.7, -1.8], [-0.7, 1.8], [1.4, -2.4], [1.4, 2.4]],
  ally: [...polar(3.5, [0, -32, 32, -62, 62]), ...polar(4.8, [-16, 16, -44, 44])],
  foe: [...polar(5.4, [0, -26, 26, -50, 50]), ...polar(6.8, [-13, 13])],
};
const EVAL = [[0, 0], SLOTS.hero[0], SLOTS.hero[1], SLOTS.ally[0], SLOTS.ally[1], SLOTS.ally[2], SLOTS.foe[0], SLOTS.foe[1], SLOTS.foe[2], [2.4, 0], [1.2, -0.6], [1.2, 0.6]];
const DIRS = [...Array(8).keys()].map((i) => ({ x: -Math.sin((i * Math.PI) / 4), z: Math.cos((i * Math.PI) / 4), yaw: i * 45 }));
const yawOf = (f) => (Math.atan2(-f.x, f.z) * 180) / Math.PI;
const toW = (P, f, a, b, dy = 0) => ({ x: P.x + f.x * a - f.z * b, y: P.y + dy, z: P.z + f.z * a + f.x * b });
/* 舞台の 良さ（P に 立って f を 向く）*/
function frameScore(dim, P, f, C) {
  let good = 0, must = 0;
  for (let i = 0; i < EVAL.length; i++) {
    const q = toW(P, f, EVAL[i][0], EVAL[i][1]), y = standY(dim, q.x, q.z, P.y, C);
    const okp = y !== null && Math.abs(y - P.y) <= 1 && !overhead(dim, q.x, y, q.z, C);
    if (okp) good++; else if (i === 0 || i === 3) must++;
  }
  if (must) return null;
  let cam = 0; for (const s of [1, -1]) { const q = toW(P, f, -2.0, 0.9 * s); if (passB(blk(dim, q.x, P.y + 1, q.z, C)) && passB(blk(dim, q.x, P.y + 2, q.z, C))) cam++; }
  const eye = { x: P.x, y: P.y + 1.6, z: P.z }, h = toW(P, f, 3.5, 0, 1.6), h2 = toW(P, f, 5.4, 0, 1.6);
  const see = (los(dim, eye, h, C) ? 1 : 0) + (los(dim, eye, h2, C) ? 1 : 0);
  return { good, cam, see, perfect: good === EVAL.length && cam > 0 && see === 2, v: good * 10 + cam * 4 + see * 8 };
}
/* 開けた 平らな 場所を さがす（anchor の まわり R マス）。ジェネレーター: 何マスか 調べるごとに 一息つく */
function* search(dim, A, prefYaw, R, C) {
  const ay = Math.floor(A.y), offs = [];
  for (let dx = -R; dx <= R; dx++) for (let dz = -R; dz <= R; dz++) { const d = Math.hypot(dx, dz); if (d > R) continue; const st = d <= 12 ? 2 : 3; if (dx % st || dz % st) continue; offs.push([dx, dz, d]); }
  offs.sort((a, b) => a[2] - b[2]);
  const dirs = DIRS.map((D) => ({ D, o: Math.abs((((D.yaw - prefYaw) % 360) + 540) % 360 - 180) })).sort((a, b) => a.o - b.o);
  let best = null, n = 0;
  for (const [dx, dz, d] of offs) {
    const x = Math.floor(A.x) + dx, z = Math.floor(A.z) + dz, y = standY(dim, x, z, ay, C);
    if (y === null || Math.abs(y - ay) > 6) { if (++n % 10 === 0) yield best; continue; }
    const P = { x: x + 0.5, y, z: z + 0.5 };
    for (const { D, o } of dirs) {
      const s = frameScore(dim, P, D, C); if (!s) continue;
      const v = s.v - d * 0.7 - o / 45 * 2;
      if (!best || v > best.v) best = { P, f: { x: D.x, z: D.z }, v, perfect: s.perfect };
      if (s.perfect) break;
    }
    if (best && best.perfect) return best;
    if (++n % 10 === 0) yield best;
  }
  return best;
}
const run = (g) => { let r; do r = g.next(); while (!r.done); return r.value; };
export const findStage = (dim, A, prefYaw = 0, R = 24, C = new Map()) => run(search(dim, A, prefYaw, R, C));

/* ---------- 舞台 ---------- */
const ST = new Map();   /* プレイヤーの id → 舞台 */
const HID = (globalThis.__mqHid = globalThis.__mqHid || new Set());   /* かくした 人の id（町歩きが 止まる）*/
const ZONE = (globalThis.__mqStageZ = globalThis.__mqStageZ || new Map());   /* 舞台の 円（町歩きが 入って こない）*/
const HOOK = { on() {}, off() {}, idle: () => 1e9, shot() {}, paused: () => false };
export function setStageHooks(h) { Object.assign(HOOK, h); }
const ok = (e) => { try { return !!e && (typeof e.isValid === "function" ? e.isValid() : e.isValid !== false); } catch { return false; } };
const wait = (t) => new Promise((r) => system.runTimeout(r, t));
export const stageOf = (p) => { try { const S = ST.get(p.id); return S && S.on ? S : null; } catch { return null; } };
export const inStage = (p) => !!stageOf(p);
const SKIP_TAG = ["mrpg_saga", "mrpg_cine", "mrpg_temp", "mrpg_preview", "mrpg_autospk", "mrpg_stghid", "mrpg_actor"];
const SKIP_TYPE = /^minecraft:(player|item|xp_orb|arrow|thrown_trident|fireball|small_fireball|painting|leash_knot|armor_stand|minecart|boat|chest_boat|chest_minecart|falling_block|tnt|lightning_bolt|area_effect_cloud|fishing_hook|ender_crystal)$|^mrpg:(popup|ball|tent)$/;
const R_HIDE = 14;
/* ほかの 人の 仲間・だれかが 乗って いる もの（マルチで ほかの 人が 動けなく ならない）*/
const foreign = (S, e) => { try { if (e.hasTag("mrpg_pet") && e.getDynamicProperty("mrpg:owner") !== S.pid) return true; if (e.hasTag("mrpg_busyw")) return true; return !!e.getComponent("minecraft:rideable")?.getRiders()?.length; } catch { return false; } };
function hideOne(S, e) {
  try {
    if (e.addEffect) e.addEffect("invisibility", 20 * 1200, { showParticles: false });
    const nm = String(e.nameTag || ""); e.setDynamicProperty("mrpg:stgnm", nm); e.setDynamicProperty("mrpg:stgown", S.pid);
    e.nameTag = ""; e.addTag("mrpg_stghid"); HID.add(e.id); S.hid.push(e);
  } catch {}
}
export function unhide(e) {
  try { HID.delete(e.id); } catch {}   /* 消えた ものの 印も のこさない */
  if (!ok(e)) return;
  try { e.removeEffect("invisibility"); } catch {}
  try { const nm = e.getDynamicProperty("mrpg:stgnm"); if (typeof nm === "string") e.nameTag = nm; e.setDynamicProperty("mrpg:stgnm", undefined); e.setDynamicProperty("mrpg:stgown", undefined); e.removeTag("mrpg_stghid"); } catch {}
  try { HID.delete(e.id); } catch {}
}
function hideAround(S) {
  const c = S.Cn; let L = []; try { L = S.dim.getEntities({ location: { x: c.x, y: c.y, z: c.z }, maxDistance: R_HIDE + 2 }); } catch {}
  let mount = null; try { mount = S.p.getComponent("minecraft:riding")?.entityRidingOn?.id; } catch {}
  for (const e of L) {
    try {
      if (!ok(e) || SKIP_TYPE.test(e.typeId) || e.id === mount || S.ents.includes(e)) continue;
      if (SKIP_TAG.some((t) => e.hasTag(t)) && !e.hasTag("mrpg_field") && !e.hasTag("mrpg_tlev")) continue;   /* 第127版: 野の 人・その モンスター・町の 事件の ものも かくす */
      if (e.hasTag("mrpg_battle") || foreign(S, e) || e.getEffect?.("invisibility")) continue;   /* 戦いの 子・もともと 透明な ものは さわらない */
      const l = e.location; if (Math.hypot(l.x - c.x, l.z - c.z) > R_HIDE || Math.abs(l.y - c.y) > 10) continue;
      hideOne(S, e);
    } catch {}
  }
  ZONE.set(S.pid, { x: c.x, z: c.z, r: R_HIDE + 2 });
}
const head = (e, dy = 1.6) => { try { const l = e.location; return { x: l.x, y: l.y + dy, z: l.z }; } catch { return null; } };
/* ---------- 第124版: ムービーの あいだ まわりの 生きものを その場で 止める（役者は のぞく）----------
   足を 止める（移動の 遅さ 255）＋ 4tick ごとに 0.3 マス 以上 動いた ものだけ 元の 場所へ もどす（軽い）*/
const FRZ = (globalThis.__mqFrz = globalThis.__mqFrz || new Set());   /* 止めた もの の id（町歩き・野の 人が 動かない）*/
const R_FRZ = 40, FRZ_MAX = 90;
const ACT_TAG = ["mrpg_actor", "mrpg_saga", "mrpg_autospk", "mrpg_preview"];
function freezeOne(S, e) {
  try {
    let r = null; try { r = e.getRotation(); } catch {}
    let had = false; try { had = !!e.getEffect("slowness"); } catch {}
    if (!had) try { e.addEffect("slowness", 20 * 1200, { amplifier: 255, showParticles: false }); } catch {}
    e.addTag("mrpg_frz"); e.setDynamicProperty("mrpg:frzown", S.pid); if (!had) e.setDynamicProperty("mrpg:frzslow", true);
    FRZ.add(e.id); S.frz.push({ e, at: { ...e.location }, r, dim: e.dimension });
  } catch {}
}
export function unfreeze(e) {
  try { FRZ.delete(e.id); } catch {}
  if (!ok(e)) return;
  try { if (e.getDynamicProperty("mrpg:frzslow")) e.removeEffect("slowness"); } catch {}
  try { e.setDynamicProperty("mrpg:frzslow", undefined); e.setDynamicProperty("mrpg:frzown", undefined); e.removeTag("mrpg_frz"); } catch {}
  try { FRZ.delete(e.id); } catch {}
  for (const S of ST.values()) if (S.frz) S.frz = S.frz.filter((x) => x.e !== e);
}
function freezeAround(S) {
  const c = S.Cn; let L = []; try { L = S.dim.getEntities({ location: { x: c.x, y: c.y, z: c.z }, maxDistance: R_FRZ }); } catch {}
  let mount = null; try { mount = S.p.getComponent("minecraft:riding")?.entityRidingOn?.id; } catch {}
  let n = 0;
  for (const e of L) {
    if (n >= FRZ_MAX) break;
    try {
      if (!ok(e) || SKIP_TYPE.test(e.typeId) || e.id === mount || S.ents.includes(e) || FRZ.has(e.id)) continue;
      if (ACT_TAG.some((t) => e.hasTag(t))) continue;
      if ((e.hasTag("mrpg_cine") || e.hasTag("mrpg_temp")) && !e.hasTag("mrpg_field") && !e.hasTag("mrpg_tlev")) continue;   /* 演出の もの（野の 人は 止める）*/
      if (e.hasTag("mrpg_battle") || foreign(S, e)) continue;
      const l = e.location; if (Math.hypot(l.x - c.x, l.z - c.z) > R_FRZ) continue;
      freezeOne(S, e); n++;
    } catch {}
  }
}
function thaw(S) { for (const x of S.frz || []) unfreeze(x.e); S.frz = []; }
function freezeTick() {
  for (const S of ST.values()) {
    if (!S.on || !S.frz || !S.frz.length || HOOK.paused(S.p)) continue;
    for (const x of S.frz) {
      const e = x.e; if (!ok(e)) continue;
      try { const l = e.location; if (Math.abs(l.x - x.at.x) + Math.abs(l.z - x.at.z) + Math.abs(l.y - x.at.y) > 0.3) { if (e.hasTag("mrpg_pet") || e.hasTag("mrpg_battle")) { unfreeze(e); continue; } e.teleport(x.at, x.r ? { dimension: x.dim, rotation: x.r } : { dimension: x.dim }); } } catch {}
    }
  }
}
system.runInterval(freezeTick, 4);
/* 舞台を 決める（move: プレイヤーを 立ち位置へ 移して よいか）*/
function frameFor(S, A, move) {
  const p = S.p; let yaw = 0; try { yaw = p.getRotation().y; } catch {}
  if (S.opt.face) { const L = p.location; yaw = yawOf({ x: S.opt.face.x - L.x, z: S.opt.face.z - L.z }); }
  if (!move) {   /* その場で 向きだけ えらぶ */
    const L = p.location, P = { x: L.x, y: Math.floor(L.y + 0.01), z: L.z };
    const dirs = DIRS.map((D) => ({ D, o: Math.abs((((D.yaw - yaw) % 360) + 540) % 360 - 180) })).sort((a, b) => a.o - b.o);
    let best = null; for (const { D, o } of dirs) { const s = frameScore(S.dim, P, D, S.C); if (!s) continue; const v = s.v - o / 45 * 2; if (!best || v > best.v) best = { P, f: { x: D.x, z: D.z }, v }; }
    return best || { P, f: { x: -Math.sin((yaw * Math.PI) / 180), z: Math.cos((yaw * Math.PI) / 180) } };
  }
  return null;
}
function setFrame(S, P, f) {
  const n = Math.hypot(f.x, f.z) || 1; S.P = { x: P.x, y: P.y, z: P.z }; S.f = { x: f.x / n, z: f.z / n }; S.r = { x: -S.f.z, z: S.f.x };
  S.Cn = S.at(2.5, 0); S.side = 1;
  /* カメラを 置く 側（肩ごしが 通る 方）*/
  const eye = S.at(0, 0, 1.6), h = S.at(3.5, 0, 1.6);
  for (const s of [1, -1]) { const c = S.at(-1.9, 0.85 * s, 1.95); if (los(S.dim, c, h, S.C) && los(S.dim, c, eye, S.C, 0.2)) { S.side = s; break; } }
}
async function activate(S, async) {
  const p = S.p, o = S.opt, L = p.location, A = o.anchor && typeof o.anchor.y === "number" ? o.anchor : o.anchor ? { ...o.anchor, y: L.y } : L;
  const move = o.move !== false;
  let fr = null;
  if (move) {
    let yaw = 0; try { yaw = p.getRotation().y; } catch {}
    if (o.face) yaw = yawOf({ x: o.face.x - A.x, z: o.face.z - A.z });
    const g = search(S.dim, A, yaw, o.R || 24, S.C); let r, k = 0;
    do { r = g.next(); if (!r.done && async && ++k % 3 === 0) { await wait(1); if (ST.get(S.pid) !== S) return; } } while (!r.done);
    fr = r.value;
  }
  if (!fr) fr = frameFor(S, A, false);
  let near = false;
  if (!move && fr.v === undefined && !blk(S.dim, L.x, L.y + 1, L.z, S.C)?.isLiquid) { let y0 = 0; try { y0 = p.getRotation().y; } catch {} const g2 = run(search(S.dim, L, y0, 6, S.C)); if (g2) { fr = g2; near = true; } }   /* 第127版: その場が 木の 下・屋台の 上など なら 6マス 以内の 開けた 所へ */
  setFrame(S, fr.P, fr.f);
  const far = Math.hypot(L.x - S.P.x, L.z - S.P.z) > 0.7 || Math.abs(L.y - S.P.y) > 1.2;
  if (far && (move || near)) {
    try { p.runCommand("camera @s fade time 0 0.35 0.45 color 0 0 0"); } catch {}
    try { p.teleport({ x: S.P.x, y: S.P.y + 0.02, z: S.P.z }, { dimension: S.dim, facingLocation: S.at(3.5, 0, 1.6) }); } catch {}
    if (async) { await wait(2); if (ST.get(S.pid) !== S) return; }   /* とちゅうで ぬけた */
  } else faceP(S, S.at(3.5, 0, 1.6));
  hideAround(S);
  freezeAround(S);
  S.on = true; S.t1 = Date.now();
  try { if (!p.getEffect("resistance")) { p.addEffect("resistance", 20 * 1200, { amplifier: 255, showParticles: false }); p.setDynamicProperty("mrpg:stgres", true); } } catch {}   /* 第127版: 動けない あいだに 矢・爆発で たおれない */
  HOOK.on(p, S);
  if (async && move && !o.noEst) await wait(28);   /* 第124版: 始めの 引きの 絵を 少し 見せる */
}
/* 場面を 始める。lazy: 最初の 役者が 出た ときに 舞台を 決める（その場で・移動なし）*/
export async function stageBegin(p, opt = {}) {
  if (!ok(p)) return null;   /* 第127版: ぬけた 人の 舞台は 作らない（まわりを かくした まま に しない）*/
  let S = ST.get(p.id);
  if (S) { S.depth++; if (!S.on && !opt.lazy) { S.opt = { ...S.opt, ...opt }; S.lazy = false; await activate(S, true); } return S; }
  S = newStage(p, opt);
  if (!opt.lazy) await activate(S, true);
  return S;
}
function newStage(p, opt) {
  const S = { pid: p.id, p, depth: 1, dim: p.dimension, opt, on: false, ents: [], mem: new Map(), dest: new Map(), hid: [], frz: [], last: null, side: 1, C: new Map(), t0: Date.now(), lazy: !!opt.lazy, auto: !!opt.auto };
  S.at = (a, b, dy = 0) => toW(S.P, S.f, a, b, dy);
  ST.set(p.id, S); return S;
}
/* 役者を 出す 前に 呼ぶ: 舞台が なければ その場に 作る（移動なし）*/
export function stageNow(p) {
  if (!ok(p)) return null;
  let S = ST.get(p.id);
  if (!S) S = newStage(p, { lazy: true, move: false, auto: true });
  if (!S.on) { S.opt = { ...S.opt, move: false }; activate(S, false); }
  return S;
}
export function stageEnd(p, all = false) {
  const S = ST.get(p.id); if (!S) return;
  if (!all && --S.depth > 0) return;
  ST.delete(p.id); closeStage(S);
}
function closeStage(S) {
  for (const e of S.hid) unhide(e); S.hid.length = 0; thaw(S);
  ZONE.delete(S.pid);
  noRes(S.p);
  if (S.on) { S.on = false; try { HOOK.off(S.p, S); } catch {} }
}
export function noRes(p) { try { if (ok(p) && p.getDynamicProperty("mrpg:stgres")) { p.removeEffect("resistance"); p.setDynamicProperty("mrpg:stgres", undefined); } } catch {} }
/* 舞台を 別の 場所へ 移す（場面の とちゅうで 城などへ 行く）*/
export async function stageMove(p, anchor, opt = {}) {
  const S = ST.get(p.id); if (!S) return null;
  for (const e of S.hid) unhide(e); S.hid.length = 0; ZONE.delete(S.pid); thaw(S);
  S.C = new Map(); S.mem.clear(); S.dest.clear(); S.ents = S.ents.filter(ok); S.last = null;
  S.opt = { ...S.opt, ...opt, anchor, move: true }; S.dim = p.dimension;
  S.on = false; await activate(S, true);
  return S;
}
/* ---------- 立ち位置 ---------- */
const distXZ = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
function others(S, self) {
  const L = [];
  try { L.push(S.p.location); } catch {}
  for (const e of S.ents) if (ok(e) && e !== self) try { L.push(e.location); const d = S.dest.get(e.id); if (d) L.push(d); } catch {}
  return L;
}
function crowd(S, q) {
  const L = []; let E = [];
  try { E = S.dim.getEntities({ location: q, maxDistance: 3 }); } catch {}
  for (const e of E) { try { if (!ok(e) || SKIP_TYPE.test(e.typeId) || HID.has(e.id)) continue; const l = e.location; if (distXZ(l, q) < 3 && Math.abs(l.y - q.y) < 3) L.push({ id: e.id, l }); } catch {} }
  return L;
}
export function freeAt(S, q, self, min = 1.5) {
  for (const l of others(S, self)) if (distXZ(l, q) < min && Math.abs(l.y - q.y) < 2.5) return false;
  for (const o of crowd(S, q)) if ((!self || o.id !== self.id) && distXZ(o.l, q) < min) return false;
  for (const r of S.res || []) if (r !== q && distXZ(r, q) < min) return false;
  return true;
}
const okSpot = (S, q, y0, lim = 1.5) => { const y = standY(S.dim, q.x, q.z, y0, S.C); return y !== null && Math.abs(y - y0) <= lim ? y : null; };
/* q の 近くで 立てて 空いて いる 所 */
export function freeNear(S, q, self, min = 1.5, maxR = 2.8) {
  if (!S || !q) return q;
  const y0 = typeof q.y === "number" ? q.y : S.P.y;
  for (const r of [0, 0.7, 1.4, 2.1, 2.8]) {
    if (r > maxR) break;
    for (let i = 0; i < (r ? 8 : 1); i++) {
      const a = (i * Math.PI) / 4, c = { x: q.x + Math.cos(a) * r, y: y0, z: q.z + Math.sin(a) * r }, y = okSpot(S, c, y0);
      if (y === null) continue; c.y = y;
      if (freeAt(S, c, self, min)) return c;
    }
  }
  return null;
}
/* プレイヤーから 見て ほかの 人の 真後ろ・真ん前（顔が かくれる）*/
function hidden(S, q, self) {
  const P = S.P, aq = Math.atan2(q.z - P.z, q.x - P.x);
  for (const e of S.ents) { if (!ok(e) || e === self) continue; const d = S.dest.get(e.id) || e.location; let x = Math.abs(Math.atan2(d.z - P.z, d.x - P.x) - aq); if (x > Math.PI) x = 2 * Math.PI - x; if (x < 0.24) return true; }
  return false;
}
/* 役の 立ち位置 */
export function slotOf(S, role, name, self) {
  const L = SLOTS[role] || SLOTS.ally, eye = S.at(0, 0, 1.6);
  const m = name && S.mem.get(name);
  if (m && freeAt(S, m, self)) return { ...m };
  for (const pass of [0, 1]) {
    for (const [a, b] of L) {
      const q = S.at(a, b), y = okSpot(S, q, S.P.y, pass ? 1.5 : 1); if (y === null) continue; q.y = y;
      if (!pass && overhead(S.dim, q.x, y, q.z, S.C)) continue;
      if (role !== "hero" && !los(S.dim, eye, { x: q.x, y: y + 1.5, z: q.z }, S.C)) continue;
      if (!freeAt(S, q, self)) continue;
      if (!pass && hidden(S, q, self)) continue;
      return q;
    }
  }
  return freeNear(S, S.at(role === "foe" ? 5 : 3.2, 0), self, 1.5, 2.8) || freeNear(S, S.at(2.5, 0), self, 1.2, 2.8) || S.at(3, 0);
}
/* その 役者が いる 舞台 */
export function stageFor(e) { if (!e) return null; for (const S of ST.values()) if (S.on && S.ents.includes(e)) return S; return null; }
export function addActor(S, e, name, q) {
  if (!S || !e) return;
  S.ents = S.ents.filter(ok); if (!S.ents.includes(e)) S.ents.push(e);
  if (FRZ.has(e.id)) unfreeze(e);
  try { e.addTag("mrpg_actor"); } catch {}
  try { if (e.typeId === "mrpg:npc") e.triggerEvent("mrpg:still"); else if (e.typeId === "mrpg:monster" && !e.hasTag("mrpg_pet") && !e.hasTag("mrpg_battle")) e.triggerEvent("mrpg:make_battle"); } catch {}   /* 第127版: 演出の モンスターが 歩き回らない・消えない */
  if (name && q) S.mem.set(name, { x: q.x, y: q.y, z: q.z });
  if (q) S.dest.set(e.id, { x: q.x, y: q.y, z: q.z });
}
/* 役者の 行き先を 覚える（歩いて いる とちゅうでも ほかの 人が その 場所に 立たない）*/
export function setDest(e, q) { const S = stageFor(e); if (S && q) S.dest.set(e.id, { x: q.x, y: q.y, z: q.z }); }
/* 歩きはじめる 所（立ち位置から 外へ 5マス・道が ふさがって いれば 近く）*/
const segD = (a, b, c) => { const vx = b.x - a.x, vz = b.z - a.z, L2 = vx * vx + vz * vz || 1, t = Math.max(0, Math.min(1, ((c.x - a.x) * vx + (c.z - a.z) * vz) / L2)); return Math.hypot(a.x + vx * t - c.x, a.z + vz * t - c.z); };
export function walkFrom(S, to, self) {
  const dx = to.x - S.P.x, dz = to.z - S.P.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L, O = others(S, self);
  for (const d of [0, 50, -50, 90, -90]) {
    const a = (d * Math.PI) / 180, vx = ux * Math.cos(a) - uz * Math.sin(a), vz = ux * Math.sin(a) + uz * Math.cos(a);
    for (const k of [5, 3.5, 2]) {
      const q = { x: to.x + vx * k, y: to.y, z: to.z + vz * k }, y = okSpot(S, q, to.y, 1); if (y === null) continue; q.y = y;
      if (O.some((o) => segD(q, to, o) < 1.3)) continue;   /* ほかの 人を 通りぬけない */
      if (clearPath(S, q, to)) return q;
    }
  }
  return null;
}
/* 2点の あいだを 歩けるか（とちゅうの 足もとが あるか）*/
export function clearPath(S, a, b) {
  const L = distXZ(a, b), n = Math.max(1, Math.ceil(L / 0.5));
  let y = a.y; for (let i = 1; i <= n; i++) { const t = i / n, q = { x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t }, yy = okSpot(S, q, y, 1); if (yy === null) return false; y = yy; }
  return true;
}
/* a から b へ 進める ところまで（壁の 手前で 止まる）*/
export function clampPath(S, a, b) {
  if (!S) return b;
  const L = distXZ(a, b), n = Math.max(1, Math.ceil(L / 0.5)); let last = { ...a }, y = a.y;
  for (let i = 1; i <= n; i++) { const t = i / n, q = { x: a.x + (b.x - a.x) * t, y, z: a.z + (b.z - a.z) * t }, yy = okSpot(S, q, y, 1); if (yy === null) break; q.y = yy; y = yy; last = q; }
  return last;
}
/* 舞台の 向きで 前へ k・右へ sd（地面に 合わせる）*/
export function stagePt(S, k, sd = 0, dy = 0) {
  const q = S.at(k, sd); let y = okSpot(S, q, S.P.y, 1);
  if (y === null) {   /* 屋台や 壁の 上に ならない: 近くの 立てる 地面へ */
    let c = null; for (const r of [0.8, 1.6, 2.4]) { for (let i = 0; i < 8 && !c; i++) { const a = (i * Math.PI) / 4, w = { x: q.x + Math.cos(a) * r, z: q.z + Math.sin(a) * r }, yy = okSpot(S, w, S.P.y, 1); if (yy !== null) c = { ...w, y: yy }; } if (c) break; }
    if (c) { q.x = c.x; q.z = c.z; y = c.y; } else { const yy = standY(S.dim, q.x, q.z, S.P.y, S.C); y = yy !== null ? yy : S.P.y; }   /* 第127版: 坂では その場の 地面の 高さ */
  }
  q.y = y + dy; return q;
}
/* 戦いの あとなど: 立ち位置から はなれて いたら もどす */
export function stageReturn(p) {
  const S = stageOf(p); if (!S) return;
  try { if (p.getDynamicProperty("mrpg:stgres") && !p.getEffect("resistance")) p.addEffect("resistance", 20 * 1200, { amplifier: 255, showParticles: false }); } catch {}   /* 第127版: 戦いの あと・生きかえった あとも 守る */
  try { const l = p.location; if (p.dimension.id !== S.dim.id || distXZ(l, S.P) > 2 || Math.abs(l.y - S.P.y) > 2) p.teleport({ x: S.P.x, y: S.P.y + 0.02, z: S.P.z }, { dimension: S.dim, facingLocation: S.at(3.5, 0, 1.6) }); } catch {}
}
/* ---------- 向き ---------- */
function faceP(S, at) { const p = S.p; try { const l = p.location; if (distXZ(l, S.P) > 3) return; p.teleport(l, { facingLocation: at }); } catch {} }
const DOWN = new Set([8, 15, 20]);
/* 話す 人が 話す 相手を 向き、まわりの 人は 話す 人を 見る。話す 相手を かえす（カメラが 使う）*/
export function speakTurn(p, sp) {
  const S = stageOf(p); if (!S || !ok(sp)) return null;
  S.ents = S.ents.filter(ok); if (!S.ents.includes(sp)) return null;
  let hero = false; try { hero = sp.hasTag("mrpg_hero"); } catch {}
  let lis = null;
  if (hero && ok(S.last) && S.last !== sp && distXZ(S.last.location, sp.location) < 9) lis = S.last;
  const H = head(sp, 1.5);
  const tg = lis ? head(lis, 1.5) : head(p, 1.5);   /* 第127版: 聞く 人が いない ときの 旅の 仲間は 前の 空き地ではなく あなたを 向く */
  try { sp.teleport(sp.location, { facingLocation: tg }); } catch {}
  for (const e of S.ents) {
    if (e === sp) continue; let a = 0; try { a = e.getProperty("mrpg:act"); } catch {}
    if (DOWN.has(a)) continue;
    try { e.teleport(e.location, { facingLocation: H }); } catch {}
  }
  faceP(S, H);
  if (!hero) S.last = sp;
  return lis || p;
}
/* ---------- 片づけ（ぬけた・ワールドを 閉じた とき）---------- */
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { const S = ST.get(playerId); if (S) { ST.delete(playerId); for (const e of S.hid) unhide(e); S.hid.length = 0; ZONE.delete(playerId); thaw(S); } }); } catch {}
/* 第127版: 入りなおし → 場面の 守りを 外す ／ 場面の とちゅうで たおれて 生きかえった → 舞台へ もどす */
try { world.afterEvents.playerSpawn.subscribe(({ player: p }) => { if (!ST.has(p.id)) noRes(p); else system.runTimeout(() => stageReturn(p), 2); }); } catch {}
let sweepN = 0;
system.runInterval(() => {
  sweepN++;
  /* 自動で 作った 舞台は 会話が 5秒 止まったら おわり。どの 舞台も 20分で おわり */
  for (const [id, S] of ST) {
    if (!ok(S.p)) { ST.delete(id); closeStage(S); continue; }
    if ((S.auto && S.on && HOOK.idle(S.p) > 5000) || Date.now() - S.t0 > 1200000) { ST.delete(id); closeStage(S); continue; }
    if (S.on && S.Cn && !HOOK.paused(S.p)) { hideAround(S); freezeAround(S); }   /* 第127版: 場面の とちゅうで 来た・わいた ものも かくす（2秒ごと）*/
  }
  if (sweepN % 5 !== 1) return;
  sweepOrphans();
}, 40);
/* 持ち主の 舞台が ない（ぬけた・ワールドを 閉じた）印を もどす */
function sweepOrphans() {
  for (const d of ["overworld", "nether", "the_end"]) {
    let L = []; try { L = world.getDimension(d).getEntities({ tags: ["mrpg_stghid"] }); } catch {}
    for (const e of L) { let o; try { o = e.getDynamicProperty("mrpg:stgown"); } catch {} if (!o || !ST.has(o)) unhide(e); }
    let F = []; try { F = world.getDimension(d).getEntities({ tags: ["mrpg_frz"] }); } catch {}
    for (const e of F) { let o; try { o = e.getDynamicProperty("mrpg:frzown"); } catch {} if (!o || !ST.has(o)) unfreeze(e); }
  }
}
export const __stage = { freezeTick, sweepOrphans, ST, HID, FRZ, ZONE, SLOTS, EVAL, frameScore, toW, wait };
