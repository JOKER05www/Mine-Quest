// v1.7: チートブック（好きな モンスターを 仲間に する／敵として 出す。レベル・サイズ・かがやき なども 自由）
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, FAMILIES, ITEMS, RANKS, SKILLS, LINE_INFO, MOVES } from "./data.js";
import { makeMonster, calcStats, addMon, MAXLV, levelUp, giveHidden, tuneMonster, slotN, getMoves, CHEAT_DMG } from "./core.js";
import { load, save, mark, allMons } from "./store.js";
import { TYPE, setLook, setSpeed, hBucket, SIZE_UP, sizeUp } from "./field.js";
import { groundY } from "./structures.js";
import { busy, choose, notice, confirm, modal, ICON, MON_ICON, LINE, sound, particle, paged, giveItem, rankOf, showTitle } from "./ui.js";
import { testInner } from "./test.js";
import { partnerEditor } from "./partner.js";
import { qs, BS_N, RUIN_NEED, RM_SLAB } from "./quest.js";
import { rfOn } from "./postgame.js";
import { WREGIONS, castlePos, landSites } from "./worldmap.js";
import { TOWNS, townPos, castleInfo, landInfo, homeInfo, castleSpot } from "./structures.js";
import { openUpTo, regAt, setGateFree, cheatAdvance, storyNowHint } from "./saga.js";
import { findPet } from "./field.js";
import { RU_GATE, RU_HOOK } from "./ruinsarea.js";

// v2.8: どこへでも ワープ（全地方の 城・全部の 町・全部の ステージ・自分の 家）
// 物語は 1本道で 進むので、先の 地方へ 行っても 手順は くずれない。関所だけ 一時的に 外す（あとで 戻せる）
async function warpMenu(p, d) {
  const k = await choose(p, "§dワープ", ["§fどこへ ワープしますか？", "§7まだ 作られて いない 町・城・ステージは 近づくと 現れます（上空から ゆっくり 降ります）。",
    d && qs(d).gateFree ? "§e地方の 関所: §c外している §7（下の ボタンで もどせる）" : "§e地方の 関所: §aふつう"].join("\n"),
    [B("§l地方の 城 §8全11", ICON("i_walk")), B("町 §8全部", ICON("i_shop")), B("ステージ（大地）§8全部", ICON("i_zukan")), B("自分の 家", ICON("i_inn")), B(d && qs(d).gateFree ? "§a地方の 関所を もとに もどす" : "§7地方の 関所を 外す", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
  let to = null, r = -1, label = "";
  if (k === 0) { const i = await paged(p, "地方の 城", "", WREGIONS.map((R, i) => B(`${R.col}${R.castle.name}\n§8${R.name}・Lv${R.lv[0]}〜${R.lv[1]}${d && i > openUpTo(d) ? " §c（関所の 先）" : ""}`, ICON("i_walk"))), 8); if (i < 0) return; const info = castleInfo(i), c = info && info.built ? info : castleSpot(i); to = { x: c.x, y: info && info.built ? info.y + 1 : null, z: c.z + (info && info.built ? 6 : 0) }; r = i; label = WREGIONS[i].castle.name; }
  else if (k === 1) { const i = await paged(p, "町", "", TOWNS.map((t) => { const q = townPos(t); return B(`${t.name}\n§8${WREGIONS[regAt(q)]?.name || ""}${d && regAt(q) > openUpTo(d) ? " §c（関所の 先）" : ""}`, ICON("i_shop")); }), 8); if (i < 0) return; const q = townPos(TOWNS[i]); to = { x: q.x, y: q.y !== null && q.y !== undefined ? q.y + 1 : null, z: q.z + 5 }; r = regAt(q); label = TOWNS[i].name; }
  else if (k === 2) { const L = WREGIONS.flatMap((R, i) => landSites(i).map((x) => ({ ...x, i }))); const j = await paged(p, "ステージ", "", L.map((x) => { const I = landInfo(x.key); return B(`${I && I.name ? I.name : x.theme}\n§8${WREGIONS[x.i].name}${d && x.i > openUpTo(d) ? " §c（関所の 先）" : ""}`, ICON("i_zukan")); }), 8); if (j < 0) return; const I = landInfo(L[j].key); to = { x: L[j].x, y: I && I.built ? I.y + 2 : null, z: L[j].z }; r = L[j].i; label = I && I.name ? I.name : L[j].theme; }
  else if (k === 3) { const h = homeInfo(); const s0 = world.getDefaultSpawnLocation(); to = h && h.built ? { x: h.x, y: h.y + 0.2, z: h.z } : { x: s0.x, y: s0.y + 1, z: s0.z }; r = 0; label = "自分の 家"; }
  else if (k === 4 && d) { setGateFree(d, !qs(d).gateFree); save(p, d); await notice(p, "地方の 関所", qs(d).gateFree ? "§e関所を 外しました。§7どの 地方へも 行けます。物語の 手順は そのままです。" : "§a関所を もとに もどしました。§7まだ 行けない 地方へ 入ると 引き返します。"); return; }
  else return;
  if (d && r > openUpTo(d) && !qs(d).gateFree) {
    if (!(await confirm(p, "地方の 関所", [`§f${WREGIONS[r]?.name}は まだ 関所の 先です。`, "§7関所を 外して ワープしますか？（物語の 手順は くずれません。その 地方の できごとは 物語が そこまで 進んだ ときに 起きます）", "§8あとで チートブック → ワープ から もとに もどせます"].join("\n"), "外して ワープ", "やめる"))) return;
    setGateFree(d, true); save(p, d);
  }
  try { const m = p.getComponent("minecraft:riding")?.entityRidingOn; if (m) m.getComponent("minecraft:rideable")?.ejectRider(p); } catch {}
  const dest = { x: to.x + 0.5, y: to.y ?? 200, z: to.z + 0.5 };
  try { p.teleport(dest, { dimension: world.getDimension("overworld") }); } catch {}
  if (to.y === null || to.y === undefined) { try { p.addEffect("slow_falling", 600, { showParticles: false }); p.addEffect("resistance", 600, { amplifier: 4, showParticles: false }); } catch {} }
  const pet = findPet(p); if (pet) try { pet.teleport(dest, { dimension: world.getDimension("overworld") }); } catch {}
  sound(p, "mob.endermen.portal", 1); particle(p, "minecraft:totem_particle", 1);
  try { showTitle(p, "§dワープ", { subtitle: `§f${label}`, fadeInDuration: 5, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
}

// v2.5: クリア後の 世界を ためす（自分の 物語だけ。ほかの プレイヤーには 影響しない。もとに 戻せる）
async function postgameTry(p, d) {
  const s = qs(d);
  if (s.cheatPre) {
    const k = await choose(p, "クリア後の 世界", "§fいまは チートで §dクリア後§f の 状態です。\n§7もとの 物語の 進みに 戻せます（石板・カップ・遺跡などの 進み。仲間や 道具は そのまま）", [B("§eもとの 物語に 戻す", ICON("i_back")), B("§7このまま", ICON("i_close"))]);
    if (k === 0) { const pre = JSON.parse(s.cheatPre); if (s.ru) pre.ru = s.ru; d.story = pre;   /* 第89版: 滅びた 世界の 進みは のこす */ save(p, d); sound(p, "random.pop"); await notice(p, "クリア後の 世界", "§aもとの 物語の 進みに 戻しました。"); }
    return;
  }
  if (!(await confirm(p, "クリア後の 世界を ためす", ["§fあなたの 物語だけを §dクリア後§f の 状態に します。", "§7・十五の 石板を すべて 封印・カップ 全制覇・星冠王 撃破・遺跡 8つ・地方マスター 8人 撃破 あつかい", "§7・再会の石板・覇王の石板・神域の石板を 1枚ずつ もらえる", "§7・閻魔の神殿・終の遺跡・伝説の マスターなど クリア後の 要素が 動く", "§b・マルチでも ほかの プレイヤーの 物語は そのまま（フラグは 一人ずつ）", "§a・今の 進みは 保存され、もう一度 この ボタンで もとに 戻せます"].join("\n"), "クリア後へ", "やめる"))) return;
  const pre = JSON.stringify(s);
  const all = Array.from({ length: BS_N }, (_, i) => i);
  Object.assign(s, { cheatPre: pre, bs: all, bsg: all, ruins: Math.max(RUIN_NEED, s.ruins || 0), ruinFinal: true, cup: 8, final: true, bsFinal: true, crown: true, ending: true, met: true, meetGot: true, rm: RM_SLAB.map((_, i) => i) });
  save(p, d);
  for (const id of ["sx_meet", "sx_king", "sx_god"]) giveItem(p, `mrpg:${id}`, 1);
  try { rfOn(); } catch {}
  sound(p, "ui.toast.challenge_complete", 1);
  await notice(p, "クリア後の 世界", "§d§lクリア後の 状態に なりました！§r\n§7再会の石板・覇王の石板・神域の石板を 受けとりました。\n§7閻魔の神殿で 魔神の鍔を 使う・地方マスターと 再戦する・伝説の マスター カゲツ・終の遺跡 なども 遊べます。\n§8（もとに 戻すときは もう一度 チートブックから）");
}

const B = (t, i) => [t, i];
const kata = (t) => (t || "").replace(/[ぁ-ゖ]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 0x60)).replace(/\s/g, "");
const SZ = ["そのまま", "S", "M", "L", "G"];
function front(p, r = 6) {
  const yaw = (p.getRotation().y * Math.PI) / 180;
  const x = p.location.x - Math.sin(yaw) * r, z = p.location.z + Math.cos(yaw) * r;
  const y = groundY(p.dimension, x, z, Math.floor(p.location.y)) ?? Math.floor(p.location.y);
  return { x, y, z };
}
// モンスターを 選ぶ（名前で さがす／系統 → ランク）
async function pickSpecies(p) {
  const s = await choose(p, "モンスターを 選ぶ", "§7さがし方を 選んでください", [B("§l名前で さがす", ICON("i_scout")), B("系統 → ランクで 選ぶ", ICON("i_zukan")), B("§7戻る", ICON("i_back"))]);
  if (s === 0) {
    const v = await modal(p, "名前で さがす", (f) => f.textField("名前の 一部（ひらがな OK）", "例: ぷる", ""));
    const q = kata(v && v[0]);
    if (!q) return null;
    const hit = ORDER.filter((x) => x !== "enma" && kata(SPECIES[x].name).includes(q)).slice(0, 120);
    if (!hit.length) { await notice(p, "さがす", "§7見つかりませんでした。"); return null; }
    const k = await paged(p, `「${v[0]}」 ${hit.length}体`, "", hit.map((x) => B(`${SPECIES[x].name} §8${SPECIES[x].rank}・${SPECIES[x].famName || ""}・${SPECIES[x].sz}`, MON_ICON(x))), 10);
    return k >= 0 ? hit[k] : null;
  }
  if (s === 1) {
    const fams = FAMILIES.filter((f) => ORDER.some((x) => SPECIES[x].fam === f.id));
    const f = await paged(p, "系統", "", fams.map((x) => B(x.name, ICON("i_zukan"))), 9);
    if (f < 0) return null;
    const l = ORDER.filter((x) => x !== "enma" && SPECIES[x].fam === fams[f].id);
    const ranks = RANKS.filter((r) => l.some((x) => SPECIES[x].rank === r));
    const r = await choose(p, fams[f].name, "§7ランク", [...ranks.map((rk) => B(`ランク ${rk} §8${l.filter((x) => SPECIES[x].rank === rk).length}体`, ICON("i_zukan"))), B("§7戻る", ICON("i_back"))]);
    if (r < 0 || r >= ranks.length) return null;
    const ll = l.filter((x) => SPECIES[x].rank === ranks[r]);
    const k = await paged(p, `${fams[f].name} ${ranks[r]}`, "", ll.map((x) => B(`${SPECIES[x].name} §8${SPECIES[x].sz}`, MON_ICON(x))), 10);
    return k >= 0 ? ll[k] : null;
  }
  return null;
}
async function spawnMenu(p) {
  const sid = await pickSpecies(p);
  if (!sid) return;
  const sp = SPECIES[sid];
  const v = await modal(p, `${sp.name}（${sp.rank}）を 出す`, (f) => {
    f.dropdown("出し方", ["仲間に する", "敵として 出す（野生）", "ボスとして 出す", "レイドボスとして 出す"], 0);
    f.slider("レベル", 1, MAXLV, 1, 30);
    f.dropdown("サイズ", SZ, 0);
    f.toggle("★かがやく 個体", false);
    f.toggle("固有特性つき", false);
    f.slider("厳選度（性格・プラス値）", 0, 100, 10, 50);
    f.slider("数（敵のとき）", 1, 5, 1, 1);
    f.toggle("プラス値を +99に する", false);
  });
  if (!v) return;
  const [how, lv0, szi, shiny, ht, q0, n0, p99] = v;
  const lv = Math.max(1, Math.min(MAXLV, Math.round(lv0))), q = q0 / 100, n = Math.max(1, Math.round(n0));
  if (how === 0) {
    const d = load(p);
    if (!d) { await notice(p, "チートブック", "§7先に ガイドブックで 最初の 仲間を 選んでください。"); return; }
    const m = makeMonster(sid, lv, true);
    if (szi > 0) m.sz = SZ[szi];
    if (shiny) { m.shiny = true; m.plus = (m.plus || 0) + 5; }
    if (ht) giveHidden(m, 1);
    if (q > 0) tuneMonster(m, q);
    if (p99) m.plus = Math.max(99, m.plus || 0);
    const st = calcStats(m); m.hp = st.hp; m.mp = st.mp;
    const where = addMon(d, m); mark(d.own, sid); mark(d.seen, sid); save(p, d);
    sound(p, "random.levelup", 1.2);
    await notice(p, "チートブック", `§a${m.nm}（Lv${lv}）を ${where === "party" ? "表の パーティ" : where === "bench" ? "控え" : "預かり所"}に くわえた！`);
    return;
  }
  for (let i = 0; i < n; i++) {
    const pos = front(p, 6 + i * 2);
    const e = p.dimension.spawnEntity(TYPE, pos);
    setLook(e, sid, szi > 0 ? { sp: sid, sz: SZ[szi] } : undefined);
    if (shiny) e.addTag("mrpg_shiny");
    e.setDynamicProperty("mrpg:lv", lv);
    e.setDynamicProperty("mrpg:q", shiny ? 1 : q);
    if (how >= 2) {
      e.addTag("mrpg_boss"); if (how === 3) e.addTag("mrpg_raid");
      const bk = how === 3 ? (sp.mh > 3 ? 1.5 : 2.4) : sp.mh > 3 ? 1.15 : 1.6;
      const bs = Math.min(2250, Math.floor(sp.size * bk * sizeUp(sp.sz)));
      e.setProperty("mrpg:size", bs); e.setDynamicProperty("mrpg:bsize", bs);
      e.triggerEvent("mrpg:make_battle"); e.triggerEvent(`mrpg:size_h${hBucket(sp.mh * bk * sizeUp(sp.sz))}`);
      if (how === 3) e.setDynamicProperty("mrpg:raidUntil", Date.now() + 10 * 60 * 1000);
    } else setSpeed(e, sid, 0.8);
    e.nameTag = `${how === 3 ? "§d【レイドボス】" : how === 2 ? "§4【ボス】" : shiny ? "§e★" : "§f"}§f${sp.name} §7Lv${lv} ${rankOf(sid)}`;
    particle(e, "minecraft:knockback_roar_particle", 1);
  }
  sound(p, "mob.evocation_illager.prepare_summon", 1);
}

/* 第76版: スキルを 好きに 選ぶ（ほかの 種族の 固有スキルは 入らない・SPは 使わない） */
const skMax = (sk) => Math.max(0, ...((SKILLS[sk] && SKILLS[sk].list) || []).map((e) => e.pt || 0));
function lineList(m) {
  const L = new Map();
  for (const k of Object.keys(SKILLS)) { const x = SKILLS[k]; if (x.uniq && x.uniq !== m.sp) continue; const l = x.line || k; if (!L.has(l)) L.set(l, []); L.get(l).push(k); }
  for (const v of L.values()) v.sort((a, b) => (SKILLS[a].tier || 0) - (SKILLS[b].tier || 0));
  return [...L.entries()];
}
function setSkill(m, i, sk) {
  if (!SKILLS[sk]) return "§cその スキルは ありません。";
  const ln = SKILLS[sk].line;
  const j = m.sk.findIndex((x, n) => n !== i && ln && SKILLS[x] && SKILLS[x].line === ln);
  if (j >= 0) return `§7同じ 系列の「${SKILLS[m.sk[j]].name}」を もう 持っています（枠${j + 1}）。`;
  if (!Array.isArray(m.pts)) m.pts = m.sk.map(() => 0);
  if (i >= m.sk.length) { m.sk.push(sk); m.pts.push(0); } else { m.sk[i] = sk; m.pts[i] = 0; }   /* チートでは 振った pt は もどらない（最大pt ボタンで ただで 増やせるため） */
  const mv = getMoves(m);
  if (Array.isArray(m.mset)) { m.mset = m.mset.filter((x) => mv.includes(x)); if (m.msetFix && !m.mset.length) delete m.msetFix; }
  const st = calcStats(m); if (typeof m.hp === "number") m.hp = Math.min(m.hp, st.hp); if (typeof m.mp === "number") m.mp = Math.min(m.mp, st.mp);
  return null;
}
async function pickSkill(p, m) {
  const L = lineList(m);
  const how = await choose(p, "スキルを 選ぶ", "§7さがし方を 選んでください", [B("§l名前で さがす", ICON("i_scout")), B("一覧から 選ぶ §8" + L.length + "系列", ICON("i_skill")), B("§7戻る", ICON("i_back"))]);
  let cand = L;
  if (how === 0) {
    const v = await modal(p, "スキルを さがす", (f) => f.textField("名前の 一部（ひらがな OK）", "例: ほむら", ""));
    const q = kata(v && v[0]); if (!q) return null;
    cand = L.filter(([l, ks]) => ks.some((k) => kata(SKILLS[k].name).includes(q)) || kata((LINE_INFO[l] && LINE_INFO[l].title) || "").includes(q));
    if (!cand.length) { await notice(p, "さがす", "§7見つかりませんでした。"); return null; }
  } else if (how !== 1) return null;
  const k = await paged(p, `スキルの 系列 ${cand.length}`, "", cand.map(([l, ks]) => B(`${(LINE_INFO[l] && LINE_INFO[l].title) || SKILLS[ks[0]].name}${SKILLS[ks[0]].uniq ? " §d固有" : ""} §8${ks.length}段`, ICON("i_skill"))), 10);
  if (k < 0) return null;
  const ks = cand[k][1];
  if (ks.length === 1) return ks[0];
  const t = await choose(p, "どの 段に する？", "§7上の 段ほど 強い 技を 覚えます", [...ks.map((x) => B(`${SKILLS[x].name} §8最大 ${skMax(x)}pt`, ICON("i_skill"))), B("§7戻る", ICON("i_back"))]);
  return t >= 0 && t < ks.length ? ks[t] : null;
}
async function skillCheat(p) {
  for (;;) {
    const d = load(p); if (!d) { await notice(p, "チートブック", "§7先に ガイドブックで 最初の 仲間を 選んでください。"); return; }
    const L = [...d.party, ...(d.bench || [])];
    if (!L.length) return;
    const a = await choose(p, "スキルを 好きに 選ぶ", "§7スキルを かえる 仲間を 選んでください（表・裏）", [...L.map((m) => B(`${m.nm} §8Lv${m.lv}・枠 ${slotN(m)}`, MON_ICON(m.sp))), B("§7戻る", ICON("i_back"))]);
    if (a < 0 || a >= L.length) return;
    for (;;) {
      const d2 = load(p); if (!d2) return;
      const m = [...d2.party, ...(d2.bench || [])][a]; if (!m) break;
      if (!Array.isArray(m.sk)) m.sk = []; if (!Array.isArray(m.pts)) m.pts = m.sk.map(() => 0);
      const n = slotN(m);
      const rows = [];
      for (let i = 0; i < n; i++) rows.push(i < m.sk.length ? B(`枠${i + 1}: ${SKILLS[m.sk[i]] ? SKILLS[m.sk[i]].name : m.sk[i]} §8${m.pts[i] || 0}/${skMax(m.sk[i])}pt`, ICON("i_skill")) : B(`§7枠${i + 1}: （空き）`, ICON("i_skill")));
      rows.push(B("§6ぜんぶの スキルを 最大ptに", ICON("i_star")), B("§7戻る", ICON("i_back")));
      const s = await choose(p, `${m.nm}の スキル`, "§7かえたい 枠を 選んでください（SPは 使いません・はずした スキルの ptは もどりません・固有スキルの 枠は かえられません）", rows);
      if (s === n) {
        const d3 = load(p); const m3 = d3 && [...d3.party, ...(d3.bench || [])][a]; if (!m3 || m3.id !== m.id) break;
        m3.pts = m3.sk.map((x) => skMax(x)); const st = calcStats(m3); if (m3.hp > 0) { m3.hp = st.hp; m3.mp = st.mp; } save(p, d3); sound(p, "random.levelup");
        continue;
      }
      if (s < 0 || s > n) break;
      if (s < m.sk.length && SKILLS[m.sk[s]] && SKILLS[m.sk[s]].uniq) { await notice(p, "スキル", "§7固有スキルの 枠は かえられません。"); continue; }
      const sk = await pickSkill(p, m);
      if (!sk) continue;
      const d3 = load(p); const m3 = d3 && [...d3.party, ...(d3.bench || [])][a]; if (!m3 || m3.id !== m.id) break;
      if (!Array.isArray(m3.sk)) m3.sk = [];
      const err = setSkill(m3, Math.min(s, m3.sk.length), sk);
      if (err) { await notice(p, "スキル", err); continue; }
      save(p, d3); sound(p, "random.orb");
    }
  }
}

export async function cheatMenu(p) {
  if (busy.has(p.id)) return;
  busy.add(p.id);
  let after = null;
  try {
    for (;;) {
      const d = load(p);
      const ruI = !!(RU_GATE.on && RU_HOOK.cheatGo);
      const s = await choose(p, "§dチートブック", ["§fためし用・あそび用の 本です。", "§7好きな モンスターを 仲間に したり、敵や ボスとして 出したり できます。", "§7（ふつうに 遊ぶ ときは 使わない ほうが たのしめます）"].join("\n"), [
        B("§lモンスターを 出す\n§8仲間・敵・ボスとして 出す", ICON("i_fight")), B("相棒を もう1体 つくる", ICON("i_egg")),
        B("仲間を 全回復", ICON("i_inn")), B("表・裏の 仲間を Lv100に", ICON("i_skill")), B("お金 +100000", ICON("i_shop")),
        B("道具を 1つずつ ぜんぶ もらう", ICON("i_bag")), B("テスト メニュー\n§8ライドテスト・空の 闘技場 など", ICON("i_help")), B("§6表・裏の 仲間の プラス値を +99に", ICON("i_star")), B("§bワープ §8全地方・全町・全ステージ・家", ICON("i_walk")), B(qs(d || {}).cheatPre ? "§dクリア後の 世界 §7（もとに 戻す）" : "§dクリア後の 世界を ためす\n§8自分の 物語だけ・あとで 戻せる・追加ストーリーは ふくまない", ICON("i_zukan")), B(`§c味方 無敵モード: ${d && d.cheat && d.cheat.inv ? "§aON" : "§7OFF"}\n§8戦いで 味方が ダメージを 受けない`, ICON("i_inn")), B(`§c一撃 ${CHEAT_DMG} ダメージ: ${d && d.cheat && d.cheat.hit ? "§aON" : "§7OFF"}\n§8当たれば 倒せる（大会などでは 無効）`, ICON("i_fight")), B("§bスキルを 好きに 選ぶ\n§8表・裏の 仲間・SPを 使わない", ICON("i_skill")), ...(ruI ? [B("§5§l滅びた世界へ すぐ 行く\n§8本編の 進みは そのまま", ICON("i_walk"))] : []), B("§e§l物語を 先へ 進める\n§8今の 段を とばして 次へ", ICON("i_book")), B("§7閉じる", ICON("i_close"))]);
      const advI = ruI ? 14 : 13;
      if (s === 0) await spawnMenu(p);
      else if (s === 1) { if (d) await partnerEditor(p, d, null); else await notice(p, "相棒", "§7先に ガイドブックで 最初の 仲間を 選んでください。"); }
      else if (s === 2 && d) { for (const m of allMons(d)) { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } save(p, d); sound(p, "random.levelup"); }
      else if (s === 3 && d) { const log = []; for (const m of [...d.party, ...(d.bench || [])]) { while (m.lv < MAXLV) { m.exp = 0; levelUp(m, log); } const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; } save(p, d); sound(p, "random.levelup"); }
      else if (s === 4 && d) { d.gold += 100000; save(p, d); sound(p, "random.orb"); }
      else if (s === 5) { if (await confirm(p, "道具", "§7道具を 1つずつ もらいます（インベントリが いっぱいだと 足もとに 落ちます）", "もらう", "やめる")) for (const k of Object.keys(ITEMS)) if (!["weapon", "armor", "acc", "material", "key", "bslab"].includes(ITEMS[k].kind)) giveItem(p, `mrpg:${k}`, 1); }
      else if (s === 7 && d) {
        let n = 0;
        for (const m of [...d.party, ...(d.bench || [])]) { if ((m.plus || 0) < 99) { m.plus = 99; n++; } const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; }
        save(p, d); sound(p, "random.levelup");
        await notice(p, "チートブック", n ? `§a${n}体の プラス値を +99に した！§7（もともと +99 以上の 子は そのまま）` : "§7表と 裏の 仲間は みんな もう +99 以上です。");
      }
      else if (s === 8) { await warpMenu(p, d); }
      else if (s === 9) { if (d) await postgameTry(p, d); else await notice(p, "チートブック", "§7先に ガイドブックで 最初の 仲間を 選んでください。"); }
      else if ((s === 10 || s === 11) && d) { const c = d.cheat || {}; const k = s === 10 ? "inv" : "hit"; c[k] = !c[k]; d.cheat = c; save(p, d); sound(p, c[k] ? "random.orb" : "random.click"); }
      else if (s === 12) await skillCheat(p);
      else if (s === 13 && ruI) { if (await confirm(p, "滅びた世界", "§fエンマを 倒して いなくても、追加ストーリー「滅びた世界」を すぐ 遊べる ように します。\n§7本編の 物語の 進みは かわりません。\n§c滅びた 世界の 魔物は Lv80〜100 です。", "行く", "やめる")) { after = () => RU_HOOK.cheatGo(p); break; } }
      else if (s === advI) await advanceMenu(p);
      else if (s === 6) { busy.delete(p.id); try { after = await testInner(p); } finally { busy.add(p.id); } if (after) break; }
      else break;
    }
  } finally { busy.delete(p.id); }
  if (after) await after();
}

/* 第121版: 物語を 先へ 進める（ためし用。今の 段を とばす。とばした 段の 印・だいじなもの・封印は そろえる）*/
async function advanceMenu(p) {
  for (;;) {
    const d = load(p); if (!d) { await notice(p, "物語を 先へ 進める", "§7先に ガイドブックで 最初の 仲間を 選んでください。"); return; }
    const s = qs(d), now = storyNowHint(d) || "§7（物語は もう 最後まで 来て います）";
    const c = await choose(p, "§e物語を 先へ 進める", [`§7いまの 目標（${(s.mq ?? 0) + 1}段目）:`, now, "", "§7とばした 段の 会話や 戦いは 起きません。石板の 封印・だいじなもの・物語の 印は そろえます。", "§7エンディングは 自分で 見て ください（最後の 段の 手前まで 進めます）。"].join("\n"), [B("1つ 進める", ICON("i_book")), B("5つ 進める", ICON("i_book")), B("§7戻る", ICON("i_back"))]);
    if (c !== 0 && c !== 1) return;
    const r = cheatAdvance(p, c === 0 ? 1 : 5);
    if (!r || !r.moved) { await notice(p, "物語を 先へ 進める", "§7これ以上は 進められません（最後の 段は 自分で 遊んで ください）。"); return; }
    sound(p, "random.orb");
    try { p.sendMessage(`§e物語を ${r.moved}つ 進めた。§f次の 目標: ${r.hint}`); } catch {}
  }
}
