// v2.6: やりこみ（エンドコンテンツ）
// 無限の塔・ボスラッシュ・縛り・今日の挑戦状・週替わりの強敵・期間限定の色違い・完全個体「極」・特性の継承・技の極め・図鑑の報酬・
// 限界突破・伝説の装備・ランクマッチ・大会・ルール対戦・ゴースト・虚空の島・地方の主・幻・宝の地図・牧場・育て屋・研究所・称号・記録帳
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, ITEMS, FAMILIES, EL_NAME, ELS, BOSS_SLAB, MOVES, TRAITS, LEGEND, LEG_PRE } from "./data.js";
import { makeMonster, calcStats, gainExp, addMon, TAL_MAX, STATS, sizeOf, isKiwami, MK_NEED, baseTraits, promoteBench } from "./core.js";
import { load, save, mark, allMons, loadW, saveW } from "./store.js";
import { busy, ok, choose, notice, confirm, paged, ICON, MON_ICON, ITEM_ICON, LINE, gold, giveItem, countItem, takeItem, sound, particle, monLabel, monLabel2, bagLoad, bagSave, seedId, rankTag, wait, inv, barNote, clipT, showTitle } from "./ui.js";
import { fight, finalTeam } from "./story.js";
import { qs, endingDone, postOpen, partyPower, BS_N, RI, rIdx, rankCap, RANK_LBL } from "./quest.js";
import { bossTeam } from "./dungeon.js";
import { toSkyArena, backFromArena, bk } from "./stage.js";
import { CH_PARTY, battleHooks, applyRules } from "./battle.js";
import { hooks, TYPE, setLook, spawnWildNear } from "./field.js";
import { WREGIONS, regionIdxAt } from "./worldmap.js";
import { giveGear, rollGear, capRoll } from "./gear.js";
import { getDg } from "./dungeon.js";
import { rollTier, chestCmds, tierName } from "./chests.js";

const B_ = (t, icon) => [t, icon];
const BOX_MAX = Infinity;   // v3.0: 預かり所は いくらでも
const cl = (m) => JSON.parse(JSON.stringify(m));
const full = (m) => { const st = calcStats(m); m.hp = st.hp; m.mp = st.mp; return m; };
const FNAME = Object.fromEntries(FAMILIES.map((f) => [f.id, f.name]));
const NORMAL_FAMS = FAMILIES.map((f) => f.id).filter((f) => f !== "king" && f !== "god");
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
function run(dim, c) { try { dim.runCommand(c); } catch {} }

// ---------- 日付（日本時間）----------
export const DAY = () => Math.floor((Date.now() + 9 * 3600e3) / 86400e3);
export const WEEK = () => Math.floor((DAY() + 3) / 7);           // 月曜はじまり
export const SEASON = () => { const t = new Date(Date.now() + 9 * 3600e3); return t.getUTCFullYear() * 12 + t.getUTCMonth(); };
const seasonName = (n) => `${Math.floor(n / 12)}年${(n % 12) + 1}月`;
function rngOf(seed) { let a = (seed * 2654435761) >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const pickR = (r, L) => L[Math.floor(r() * L.length)];

// ---------- データ ----------
export function eg(d) {
  d.eg = d.eg || {};
  const e = d.eg;
  if (e.care) { for (const m of [e.care.a, e.care.b]) if (m) (d.box = d.box || []).push(m); e.care = null; }   // v3.0: 育て屋は ない → あずけた 子は 預かり所へ
  for (const k of ["titles", "sh", "htd", "kw", "walk", "ride", "ph", "claim"]) if (!Array.isArray(e[k])) e[k] = [];
  e.rec = e.rec || {}; e.nushi = e.nushi || {}; e.lab = e.lab || { pt: 0 };
  return e;
}
const addIdx = (L, sp) => { const i = SPECIES[sp]?.idx; if (i !== undefined && !L.includes(i)) { L.push(i); return true; } return false; };

// ---------- 称号 ----------
export const TITLES = {
  tower10: ["塔の 挑戦者", "無限の塔 10階"], tower50: ["塔の 覇者", "無限の塔 50階"], tower100: ["天塔の 王", "無限の塔 100階"],
  rush: ["石板を 統べる者", "ボスラッシュ 制覇"], rushfast: ["疾風の 封印師", "ボスラッシュを 60分 以内"],
  shibari1: ["縛りの 求道者", "縛りの石板 1回 達成"], shibari10: ["縛りの 達人", "縛りの石板 10回"], shibari30: ["縛りの 極み", "縛りの石板 30回"],
  daily7: ["七日の 挑戦者", "今日の挑戦状 7日 連続"], daily30: ["月の 挑戦者", "今日の挑戦状 30日 連続"],
  weekly10: ["週の 討伐者", "週替わりの強敵を 1週間に 10回"],
  kiwami1: ["極を 知る者", "完全個体「極」を 1体"], kiwami10: ["極の 収集家", "「極」を 10種"],
  shiny10: ["かがやきの 収集家", "かがやく モンスター 10種"], shiny50: ["光の 王", "かがやく モンスター 50種"], ht30: ["固有の 探求者", "固有特性もち 30種"],
  dex100: ["図鑑 100", "図鑑 100種"], dex500: ["図鑑 500", "図鑑 500種"], dex1000: ["図鑑 800", "図鑑 800種"], dexall: ["図鑑 完成", "図鑑 すべて"],
  walk30: ["散歩の 達人", "30種と 散歩"], walk100: ["散歩の 王", "100種と 散歩"], ride30: ["騎乗の 達人", "30種に ライド"], ride100: ["騎乗の 王", "100種に ライド"],
  legend: ["伝説の 継承者", "伝説の 装備を 3つ そろえる"], mk10: ["技を 極めし者", "技を 10個 極める"], limit5: ["限界の 先へ", "限界突破を 5段"],
  rate1: ["ブロンズ", "ランクマッチ ブロンズ"], rate2: ["シルバー", "ランクマッチ シルバー"], rate3: ["ゴールド", "ランクマッチ ゴールド"], rate4: ["プラチナ", "ランクマッチ プラチナ"], rate5: ["マスター", "ランクマッチ マスター"],
  cup: ["大会 優勝者", "大会で 優勝"], cup10: ["大会の 常勝者", "大会で 10回 優勝"], ghost10: ["ゴースト狩り", "ゴースト対戦 10勝"],
  void: ["虚空の 旅人", "虚空の島に 行く"], void30: ["虚空の 狩人", "虚空の島で 30勝"], phantom: ["幻を 見た者", "幻の モンスター 4種 すべて"],
  nushiall: ["大陸の 覇者", "11の 地方の 主 すべて"], tmap5: ["宝さがしの 名人", "宝の地図 5回"], ranch: ["牧場主", "牧場に あずける"],
  lab: ["研究者", "研究所の レシピ すべて"], dmg9999: ["一撃 9999", "9999 ダメージ"], streak100: ["百連勝", "100連勝"],
};
for (const f of FAMILIES) TITLES[`fam_${f.id}`] = [`${f.name.replace("系", "")}の 博士`, `${f.name}を 図鑑で すべて`];
for (const r of RI) TITLES[`rank_${r}`] = [`${r}ランク 制覇`, `${r}ランクを 図鑑で すべて`];
WREGIONS.forEach((R, i) => { TITLES[`nushi_${i}`] = [`${R.short}の 主を 討つ者`, `${R.name}の 主に 勝つ`]; });
export function award(p, d, id, log) {
  const e = eg(d); if (!TITLES[id] || e.titles.includes(id)) return false;
  e.titles.push(id);
  const msg = `§6§l称号「${TITLES[id][0]}」§r§6を 手に入れた！ §7（やりこみ →「称号と 記録」で つけられる）`;
  if (log) log.push(msg); else try { p.sendMessage(msg); } catch {}
  return true;
}
export function applyTitle(p, d) {
  try { const e = d && d.eg; const t = e && e.title && TITLES[e.title]; p.nameTag = t ? `§6《${t[0]}》§r\n${p.name}` : p.name; } catch {}
}

// ---------- ランキング ----------
const BOARD = "mrpg_eg_board";
function board() { return loadW(BOARD, {}); }
function setBoard(cat, name, val, better) {
  const b = board(); b[cat] = b[cat] || {};
  const old = b[cat][name];
  if (old === undefined || better(val, old)) { b[cat][name] = val; saveW(BOARD, b); }
}
function boardText(cat, title, fmt, asc) {
  const b = board()[cat] || {};
  const L = Object.entries(b).sort((x, y) => (asc ? x[1] - y[1] : y[1] - x[1])).slice(0, 10);
  return [`§l§e${title}`, ...(L.length ? L.map(([n, v], i) => `§f${i + 1}. §b${n} §7― §e${fmt(v)}`) : ["§7まだ だれも いない"])].join("\n");
}

// ---------- チームを つくる ----------
function genTeam(r, o) {
  const ok2 = (s) => { const S = SPECIES[s]; return S && !S.hidden && !S.metalmon && !s.startsWith("book_") && (o.kg || (S.fam !== "king" && S.fam !== "god")) && (!o.fam || S.fam === o.fam) && o.ranks.includes(S.rank) && (!o.noTop || !["SS", "X"].includes(S.rank)); };
  let pool = ORDER.filter(ok2);
  if (o.el) { const pe = pool.filter((s) => (SPECIES[s].aff?.ge || []).includes(o.el)); if (pe.length >= 2) pool = pe; }
  if (!pool.length) pool = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.fam !== "king" && S.fam !== "god" && ["A", "S"].includes(S.rank); });
  const team = []; let used = 0;
  if (o.lead && SPECIES[o.lead]) { team.push({ sid: o.lead, lv: o.lv, q: 1, plus: (o.plus || 0) + 10 }); used += SLOT[SPECIES[o.lead].sz] || 2; }
  for (let k = 0; k < 16 && used < 4 && team.length < (o.n || 4); k++) {
    const c = pool.filter((s) => used + (SLOT[SPECIES[s].sz] || 2) <= 4 && !team.some((t) => t.sid === s));
    if (!c.length) break;
    const s = pickR(r, c); team.push({ sid: s, lv: o.lv, q: o.q ?? 1, plus: o.plus || 0 }); used += SLOT[SPECIES[s].sz] || 2;
  }
  return team;
}
const teamText = (team) => team.map((t) => `${SPECIES[t.sid].name}${rankTag(SPECIES[t.sid].rank)}§7Lv${t.lv}${t.plus ? ` +${t.plus}` : ""}`).join("§f・");
function bestOf(fam, ranks, sz) { return ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.fam === fam && ranks.includes(S.rank) && (!sz || sz.includes(S.sz)); }); }

// ---------- 伝説の 装備 ----------
export function giveLegend(p, fam, log) {
  const L = (LEGEND && LEGEND[fam]) || []; if (!L.length) return null;
  const id = L[Math.floor(Math.random() * L.length)];
  try { giveGear(p, id, capRoll(p, id, rollGear(id, "boss"))); } catch { giveItem(p, `mrpg:${id}`); }
  const msg = `§6§l◆ 伝説の 装備「${ITEMS[id].name}」を 手に入れた！ ◆`;
  if (log) log.push(msg); else try { p.sendMessage(msg); } catch {}
  for (const q of world.getAllPlayers()) if (q.id !== p.id) q.sendMessage(`§6◆ ${p.name}が ${ITEMS[id].name}を 手に入れた！`);
  return id;
}
function giveR(p, id, n, got) { if (!ITEMS[id]) return; giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? `×${n}` : ""}`); }

// ---------- 挑戦の 共通（空の 闘技場・コピーの パーティ・回復なし）----------
async function series(p, opt) {
  // opt: { title, team(コピー), rounds: [{ foe, info, intro }], heal, onRound(i, d, res) }
  let res = null, cleared = 0;
  await toSkyArena(p);
  try {
    for (let i = 0; i < opt.rounds.length; i++) {
      if (!ok(p)) break;   /* 第69版: 抜けた */
      let R = null; try { R = typeof opt.rounds[i] === "function" ? opt.rounds[i]() : opt.rounds[i]; } catch { R = null; }
      if (!R) break;
      if (opt.heal) for (const m of opt.team) full(m);
      if (!opt.team.some((m) => m.hp > 0)) { res = "lose"; break; }
      if (R.intro) await notice(p, opt.title, R.intro);
      try { showTitle(p, `§e${opt.title}`, { subtitle: `§f${R.sub || ""}`, fadeInDuration: 5, stayDuration: 35, fadeOutDuration: 10 }); } catch {}
      CH_PARTY.set(p.id, opt.team);
      try { res = await fight(p, R.foe, { tier: 2, fam: "", npc: null, name: R.name || opt.title, arena: opt.title, ch: true, theme: "sky", ...(R.info || {}) }); }
      finally { CH_PARTY.delete(p.id); }
      if (res !== "win" && res !== "scout") { res = "lose"; break; }
      cleared = i + 1;
      if (opt.onRound) { const goOn = await opt.onRound(i, res); if (goOn === false) break; }
    }
  } finally { CH_PARTY.delete(p.id); backFromArena(p); }
  return { res, cleared };
}
const partyCopy = (d, rules) => (rules ? applyRules(d.party, rules) : d.party.map((m) => full(cl(m))));

// ---------- 1. 無限の塔 ----------
function towerFloor(fl) {
  const r = rngOf(fl * 7919 + WEEK() * 31);
  const boss = fl % 10 === 0;
  const ranks = fl <= 10 ? ["B", "A"] : fl <= 20 ? ["A", "S"] : fl <= 40 ? ["S", "SS"] : ["SS"];
  const lv = Math.min(100, 46 + fl * 2), plus = Math.min(250, fl * 3);
  let lead = null;
  if (boss) { const L = bestOf(pickR(r, NORMAL_FAMS), ["SS"]); lead = L.length ? pickR(r, L) : null; }   // v3.0: Xランクは 神だけ（ふつうの 系統は SSまで）
  const team = genTeam(r, { ranks, lv, plus, lead, n: boss ? 3 : 4 });
  return { team, boss, info: boss ? { hpk: 1.6 + Math.min(1.6, fl / 40), tag: "塔の 番人", extra: 0.4 } : {} };
}
async function runTower(p, start) {
  let d = load(p); if (!d) return;
  const team = partyCopy(d);
  let fl = start;
  const e0 = eg(d), best0 = e0.rec.tower || 0;
  const rounds = Array.from({ length: 400 }, (_, k) => () => {
    const f = start + k, T = towerFloor(f);
    return { foe: { team: T.team }, name: `${f}階`, sub: `${f}階${T.boss ? " §c【番人】" : ""}  ${clipT(teamText(T.team), 60)}`, info: T.info };
  });
  const { cleared } = await series(p, {
    title: "無限の塔", team, rounds,
    onRound: async (i) => {
      fl = start + i; d = load(p); if (!d) return false; const e = eg(d);
      const got = [];
      if (fl > (e.rec.tower || 0)) e.rec.tower = fl;
      if (fl % 10 === 0) {
        const first = fl > best0;
        const fk = Math.min(fl, 150);   /* 第69版: 敵が 強くならない 高い 階では お金も 増やさない */
        d.gold += 10000 * (fk / 10) * (first ? 2 : 1); got.push(gold(10000 * (fk / 10) * (first ? 2 : 1)));
        if (first && fl <= 300) {
          giveR(p, seedId(fl >= 40 ? 3 : 2), 1, got);
          if (fl % 20 === 0) giveR(p, "i_tmap", 1, got);
          if (fl % 30 === 0) giveR(p, "i_inherit", 1, got);
          if (fl % 50 === 0) { giveR(p, "i_limit", 1, got); giveLegend(p, pickR(Math.random, NORMAL_FAMS), got); }
          if (fl % 100 === 0) giveR(p, "i_trpick", 1, got);
        }
        if (fl >= 10) award(p, d, "tower10", got); if (fl >= 50) award(p, d, "tower50", got); if (fl >= 100) { if (award(p, d, "tower100", got)) for (const q of world.getAllPlayers()) q.sendMessage(`§6§l★ ${p.name}が 無限の塔 100階に 到達した！`); }
      }
      save(p, d); setBoard("tower", p.name, e.rec.tower, (a, b) => a > b);
      const hp = team.map((m) => `${m.nm} §a${m.hp}`).join(" ");
      const c = await choose(p, `無限の塔 ${fl}階 突破！`, [`§e§l${fl}階 突破！`, ...(got.length ? [`§6ほうび: §f${got.join("・")}`] : []), `§7のこりHP: ${hp}`, "§7回復は できない（道具は 使える）", `§f最高 §e${e.rec.tower}階`].join("\n"),
        [B_(`§l${fl + 1}階へ すすむ${(fl + 1) % 10 === 0 ? " §c（番人）" : ""}`, ICON("i_fight")), B_("§7ここで やめる", ICON("i_back"))]);
      return c === 0;
    },
  });
  d = load(p); if (!d) return;
  await notice(p, "無限の塔", `§f今回: §e${start}階 → ${start + Math.max(0, cleared - 1)}階${cleared ? " 突破" : "で 力つきた"}\n§f最高記録: §e${eg(d).rec.tower || 0}階\n§7パーティは コピーで 戦ったので 本物は 減っていない。`);
}

// ---------- 2. ボスラッシュの石板 ----------
async function runRush(p) {
  let d = load(p); if (!d) return;
  const team = partyCopy(d);
  const t0 = Date.now();
  const rounds = [];
  for (let i = 0; i < BS_N; i++) rounds.push(() => load(p) && ({ foe: { team: bossTeam(load(p), i, true) }, name: BOSS_SLAB[i].title, sub: `${i + 1}/${BS_N + 1}  ${BOSS_SLAB[i].title}`, info: { bslab: 20 } }));   // v3.0 第63版: 連戦は 強さを そろえる（後半で 全滅して いた）
  rounds.push(() => load(p) && ({ foe: { team: finalTeam(qs(load(p)), load(p)) }, name: "星冠王 ゼファード", sub: `${BS_N + 1}/${BS_N + 1}  星冠王`, info: { final: true } }));
  const { res, cleared } = await series(p, { title: "ボスラッシュ", team, rounds,
    onRound: async (i) => { for (const m of team) { if (m.hp > 0) { const c = calcStats(m); m.hp = Math.min(c.hp, m.hp + Math.floor(c.hp * 0.3)); m.mp = Math.min(c.mp, m.mp + Math.floor(c.mp * 0.3)); } }   // v3.0 第63版: 1戦ごとに 3割 回復
      const hp = team.map((m) => `${m.nm} §a${m.hp}`).join(" "); if (i < rounds.length - 1) await notice(p, "ボスラッシュ", `§e${i + 1}体目 撃破！ §7（${Math.round((Date.now() - t0) / 60000)}分）\n§7のこりHP: ${hp}\n§c次: ${i + 1 < BS_N ? BOSS_SLAB[i + 1].title : "星冠王"}`); return true; } });
  d = load(p); if (!d) return; const e = eg(d); const got = [];
  e.rec.rushTry = (e.rec.rushTry || 0) + 1;
  if (cleared >= rounds.length) {
    const ms = Date.now() - t0;
    e.rec.rush = (e.rec.rush || 0) + 1;
    if (!e.rec.rushBest || ms < e.rec.rushBest) e.rec.rushBest = ms;
    d.gold += 500000; got.push(gold(500000));
    giveR(p, "i_trpick", 1, got); giveR(p, "i_limit", 1, got);
    if (e.rec.rush === 1) giveLegend(p, "king", got);
    award(p, d, "rush", got); if (ms <= 3600e3) award(p, d, "rushfast", got);
    setBoard("rush", p.name, Math.round(ms / 1000), (a, b) => a < b);
    for (const q of world.getAllPlayers()) q.sendMessage(`§5§l★ ${p.name}が ボスラッシュの石板を 制覇した！（${Math.round(ms / 60000)}分）`);
  }
  save(p, d);
  await notice(p, "ボスラッシュの石板", cleared >= rounds.length ? `§6§l全 ${rounds.length}体 撃破！ §r§f（${Math.round((Date.now() - t0) / 60000)}分）\n§6${got.join("・")}` : `§c${cleared}体 撃破で 力つきた……§7（全 ${rounds.length}体）`);
}

// ---------- 3. 縛りの石板 ----------
export const SHIBARI = [
  { id: "rankB", n: "Bランク 以下だけ", ok: (m) => rIdx(m.sp) <= 4 },
  { id: "one", n: "1体だけで 戦う" },
  { id: "nomagic", n: "魔法系の 攻撃技 禁止" },
  { id: "lv50", n: "Lv50に そろえる" },
  { id: "noitem", n: "道具 禁止" },
  { id: "small", n: "S・Mサイズだけ", ok: (m) => ["S", "M"].includes(sizeOf(m)) },
];
async function runShibari(p, picks) {
  let d = load(p); if (!d) return;
  const rules = Object.fromEntries(picks.map((x) => [x.id, true]));
  let list = d.party.filter((m) => picks.every((x) => !x.ok || x.ok(m)));
  if (!list.length) { await notice(p, "縛りの石板", "§cこの 縛りに あう 仲間が パーティに いない。"); return; }
  if (rules.one) {
    const k = await choose(p, "縛りの石板", "§7戦う 1体を えらんでください", [...list.map((m) => B_(monLabel2(m), MON_ICON(m.sp))), B_("§7やめる", ICON("i_back"))]);
    if (k < 0 || k >= list.length) return; list = [list[k]];
  }
  const team = applyRules(list, { lv50: rules.lv50 });
  const r = rngOf(Date.now() % 100000);
  const lv = rules.lv50 ? 50 : rules.rankB ? 62 : 80, ranks = rules.rankB || rules.lv50 ? ["B", "A"] : ["A", "S"];
  const rounds = [0, 1, 2].map((i) => () => ({ foe: { team: genTeam(r, { ranks, lv: lv + i * 2, plus: 20 + i * 15, n: rules.one ? 2 : 4 }) }, name: `縛り ${i + 1}戦目`, sub: `${i + 1}/3`, info: { rules, hpk: i === 2 ? 1.5 : undefined, tag: i === 2 ? "縛りの 番人" : undefined } }));
  const { cleared } = await series(p, { title: "縛りの石板", team, rounds });
  d = load(p); if (!d) return; const e = eg(d); const got = [];
  if (cleared >= 3) {
    e.rec.shibari = (e.rec.shibari || 0) + 1;
    const g = 30000 * picks.length; d.gold += g; got.push(gold(g));
    giveR(p, seedId(3), 1, got);
    if (Math.random() < 0.35) giveR(p, "i_tmap", 1, got);
    if (Math.random() < 0.12) giveR(p, "i_inherit", 1, got);
    if (Math.random() < 0.03) giveR(p, "i_trpick", 1, got);
    award(p, d, "shibari1", got); if (e.rec.shibari >= 10) award(p, d, "shibari10", got); if (e.rec.shibari >= 30) award(p, d, "shibari30", got);
  }
  save(p, d);
  await notice(p, "縛りの石板", cleared >= 3 ? `§6§l達成！ §r§f（${picks.map((x) => x.n).join("・")}）\n§6${got.join("・")}\n§7達成 ${e.rec.shibari}回` : `§c${cleared}/3で 力つきた……`);
}

// ---------- 4. 今日の挑戦状 ----------
export function dailyTeam(day = DAY()) { return genTeam(rngOf(day * 101 + 7), { ranks: ["S", "SS"], lv: 95, plus: 60, n: 4 }); }
async function runDaily(p) {
  let d = load(p); if (!d) return;
  const e = eg(d), today = DAY();
  e.daily = e.daily || {};
  if (e.daily.try === today) { await notice(p, "今日の挑戦状", "§7今日は もう 挑戦した。明日 また 来よう。"); return; }
  e.daily.try = today; save(p, d);
  const team = partyCopy(d);
  const { cleared } = await series(p, { title: "今日の挑戦状", team, rounds: [{ foe: { team: dailyTeam(today) }, name: "今日の 挑戦者", sub: "今日の挑戦状", info: { hpk: 1.4, tag: "挑戦状" } }] });
  d = load(p); if (!d) return; const e2 = eg(d); const got = [];
  if (cleared >= 1) {
    const dl = e2.daily; dl.streak = dl.last === today - 1 ? (dl.streak || 0) + 1 : 1; dl.last = today;
    e2.rec.dailyBest = Math.max(e2.rec.dailyBest || 0, dl.streak);
    const g = Math.floor(50000 * (1 + 0.1 * Math.min(10, dl.streak))); d.gold += g; got.push(gold(g));
    giveR(p, seedId(3), 1, got);
    if (dl.streak % 7 === 0) giveR(p, "i_limit", 1, got);
    if (dl.streak % 3 === 0) giveR(p, "i_tmap", 1, got);
    if (dl.streak >= 7) award(p, d, "daily7", got); if (dl.streak >= 30) award(p, d, "daily30", got);
  }
  save(p, d);
  await notice(p, "今日の挑戦状", cleared ? `§6§l勝利！ §r§f連続 §e${e2.daily.streak}日\n§6${got.join("・")}` : "§c負けてしまった……§7（今日の 挑戦は おわり。連続記録は 明日 勝てば つながらない）");
}

// ---------- 5. 週替わりの強敵 ／ 6. 期間限定の 色違い ----------
export function weeklyInfo(wk = WEEK()) {
  const fam = NORMAL_FAMS[wk % NORMAL_FAMS.length], el = ELS[(wk * 3) % ELS.length];
  const lead = bestOf(fam, ["X"]).concat(bestOf(fam, ["SS"]))[0] || null;
  const team = genTeam(rngOf(wk * 13 + 5), { ranks: ["SS", "S"], lv: 100, plus: 120, fam, el, lead, n: 3 });
  return { fam, el, team };
}
export const shinyFam = (wk = WEEK()) => NORMAL_FAMS[(wk * 5 + 2) % NORMAL_FAMS.length];
async function runWeekly(p) {
  let d = load(p); if (!d) return;
  const W = weeklyInfo(), team = partyCopy(d);
  const { cleared } = await series(p, { title: "週替わりの強敵", team, rounds: [{ foe: { team: W.team }, name: "週替わりの 強敵", sub: `${FNAME[W.fam]}・${EL_NAME[W.el]}`, info: { hpk: 3, tag: "週替わりの 強敵", extra: 0.5 } }] });
  d = load(p); if (!d) return; const e = eg(d); const got = [];
  if (cleared) {
    if (!e.weekly || e.weekly.wk !== WEEK()) e.weekly = { wk: WEEK(), n: 0 };
    const n = ++e.weekly.n;
    if (n <= 10) { d.gold += 40000; got.push(gold(40000)); }   // v2.9.12: お金は 1週 10回まで
    if (n === 1) giveR(p, seedId(3), 1, got);
    if (n === 3) giveR(p, "e_rainbow", 1, got);
    if (n === 5) giveLegend(p, W.fam, got);
    if (n === 10) { giveR(p, "i_limit", 1, got); award(p, d, "weekly10", got); }
    e.rec.weekly = (e.rec.weekly || 0) + 1;
  }
  save(p, d);
  await notice(p, "週替わりの強敵", cleared ? `§6§l撃破！ §r§f今週 §e${e.weekly.n}回目\n§6${got.join("・")}\n§7（1・3・5・10回目に とくべつな ほうび）` : "§c負けてしまった……");
}

// ---------- 15〜18. ゴースト・ランクマッチ・大会・ルール ----------
const GKEY = "mrpg_eg_ghost";
export const RULES = [{ id: "free", n: "自由", r: null }, { id: "lv50", n: "Lv50 統一", r: { lv50: true } }, { id: "nodup", n: "同じ 種族なし", r: { nodup: true } }, { id: "notop", n: "SS・X 禁止", r: { notop: true } }, { id: "std", n: "スタンダード（Lv50・同種なし・SS/X禁止）", r: { lv50: true, nodup: true, notop: true } }];
export async function pickRule(p) {
  const k = await choose(p, "ルール", "§7対戦の ルールを えらんでください", [...RULES.map((x) => B_(x.n, ICON("i_fight"))), B_("§7やめる", ICON("i_back"))]);
  return k < 0 || k >= RULES.length ? null : RULES[k];
}
function ghosts() { return loadW(GKEY, []); }
const strip = (m) => { const c = cl(m); delete c.mu; return c; };
async function registerGhost(p, d) {
  if (!d.party.length) return;
  const L = ghosts().filter((g) => g.name !== p.name);
  L.unshift({ name: p.name, t: Date.now(), team: d.party.map(strip), r: eg(d).rate?.r || 1000 });
  saveW(GKEY, L.slice(0, 24));
  await notice(p, "ゴースト", `§aいまの パーティを ゴーストとして 登録した！\n§7ほかの 人が あなたの チームと 戦える（AIが 動かす）。\n§f${d.party.map((m) => m.nm).join("・")}`);
}
const ghostTeam = (g, rules) => applyRules(g.team, rules).map((m) => ({ sid: m.sp, lv: m.lv, m }));
function aiByRate(r, rules) {
  const rr = rngOf(Date.now() % 99991);
  const o = r < 1100 ? { ranks: ["B", "A"], lv: 70, plus: 10 } : r < 1250 ? { ranks: ["A", "S"], lv: 85, plus: 30 } : r < 1400 ? { ranks: ["S"], lv: 95, plus: 50 } : r < 1600 ? { ranks: ["S", "SS"], lv: 100, plus: 80 } : { ranks: ["SS"], lv: 100, plus: 120 };
  if (rules && rules.lv50) o.lv = 50; if (rules && rules.notop) o.ranks = o.ranks.filter((x) => !["SS", "X"].includes(x)).concat(["A", "S"]);
  return genTeam(rr, { ...o, n: 4 });
}
const rateTier = (r) => (r >= 1600 ? 5 : r >= 1400 ? 4 : r >= 1250 ? 3 : r >= 1100 ? 2 : 1);
const TIER_N = ["", "ブロンズ", "シルバー", "ゴールド", "プラチナ", "マスター"];
function rateOf(d) {
  const e = eg(d), s = SEASON(), out = [];
  if (!e.rate) e.rate = { s, r: 1000, best: 1000, g: 0, w: 0 };
  if (e.rate.s !== s) {
    const t = rateTier(e.rate.best || 1000);
    out.push(`§6シーズン ${seasonName(e.rate.s)} の 結果: §l${TIER_N[t]}§r §7（最高 ${e.rate.best}）`);
    const played = (e.rate.g || 0) > 0;   // v2.9.6: 対戦して いない シーズンは ほうび なし
    e.rate = { s, r: Math.round(1000 + ((e.rate.r || 1000) - 1000) / 2), best: 1000, g: 0, w: 0, prize: played ? t : 0 };
  }
  return out;
}
async function runRanked(p) {
  let d = load(p); if (!d) return;
  rateOf(d); const e = eg(d), my = e.rate.r;
  const gl = ghosts().filter((g) => g.name !== p.name).sort((a, b) => Math.abs((a.r || 1000) - my) - Math.abs((b.r || 1000) - my));
  const g = gl.length && Math.random() < 0.7 ? gl[Math.floor(Math.random() * Math.min(3, gl.length))] : null;
  const oppR = g ? g.r || 1000 : my + Math.round((Math.random() - 0.5) * 120);
  const foe = g ? ghostTeam(g, null) : aiByRate(oppR, null);
  if (!foe.length) return;
  const team = partyCopy(d);
  const { cleared } = await series(p, { title: "ランクマッチ", team, rounds: [{ foe: { team: foe }, name: g ? `${g.name}の ゴースト` : "ランクの 挑戦者", sub: `${g ? g.name + "の ゴースト" : "AI"}（${oppR}）`, info: g ? { ghost: true } : {} }] });
  d = load(p); if (!d) return; const e2 = eg(d); rateOf(d);
  const exp = 1 / (1 + Math.pow(10, (oppR - e2.rate.r) / 400)), delta = Math.round(32 * ((cleared ? 1 : 0) - exp));
  e2.rate.r = Math.max(0, e2.rate.r + delta); e2.rate.g++; if (cleared) e2.rate.w++;
  e2.rate.best = Math.max(e2.rate.best || 0, e2.rate.r); e2.rec.rateBest = Math.max(e2.rec.rateBest || 0, e2.rate.r);
  const got = [];
  for (let t = 1; t <= rateTier(e2.rate.r); t++) award(p, d, `rate${t}`, got);
  if (cleared && g) e2.rec.ghostWins = (e2.rec.ghostWins || 0) + 1;
  save(p, d); setBoard("rate", p.name, e2.rate.r, () => true);
  await notice(p, "ランクマッチ", `${cleared ? "§6§l勝利！" : "§c敗北……"}\n§fレート §e${e2.rate.r} §7（${delta >= 0 ? "+" : ""}${delta}）  §f${TIER_N[rateTier(e2.rate.r)]}\n§7シーズン ${seasonName(e2.rate.s)}  ${e2.rate.w}勝 ${e2.rate.g - e2.rate.w}敗${got.length ? "\n" + got.join("\n") : ""}`);
}
async function seasonPrize(p, d) {
  const L = rateOf(d), e = eg(d);
  if (e.rate && e.rate.prize) {
    const t = e.rate.prize, got = []; e.rate.prize = 0;
    d.gold += 50000 * t; got.push(gold(50000 * t));
    if (t >= 3) giveR(p, "i_inherit", 1, got); if (t >= 4) giveR(p, "i_limit", 1, got); if (t >= 5) giveR(p, "i_trpick", 1, got);
    save(p, d); await notice(p, "シーズン報酬", [...L, `§6${got.join("・")}`].join("\n"));
  }
}
const teamPow = (team) => team.reduce((s, t) => s + (rIdx(t.sid) + 2) * (t.lv || 50) * (1 + ((t.m ? t.m.plus : t.plus) || 0) / 100), 0);
async function runCup(p, rule) {
  let d = load(p); if (!d) return;
  const rules = rule.r;
  const mine = partyCopy(d, rules);
  if (!mine.length) { await notice(p, "大会", "§cルールに あう 仲間が いない。"); return; }
  const gl = ghosts().filter((g) => g.name !== p.name).sort(() => Math.random() - 0.5).slice(0, 7);
  const ents = gl.map((g) => ({ n: `${g.name}の ゴースト`, team: ghostTeam(g, rules) })).filter((x) => x.team.length);
  const AI_N = ["流浪の ジン", "双剣の ミオ", "砂の ガラム", "氷の セツナ", "嵐の フレイ", "古城の ノア", "月の ルナリア", "鉄の ボルグ"];
  for (let i = 0; ents.length < 7; i++) ents.push({ n: AI_N[i % AI_N.length], team: aiByRate(1100 + i * 60, rules) });
  // 1回戦: 自分 vs ents[0]、ほかは 自動
  const sim = (a, b) => (Math.random() * teamPow(a.team) > Math.random() * teamPow(b.team) ? a : b);
  const qf = [sim(ents[1], ents[2]), sim(ents[3], ents[4]), sim(ents[5], ents[6])];
  const sf2 = sim(qf[1], qf[2]);
  const foes = [ents[0], qf[0], sf2];
  await notice(p, `大会（${rule.n}）`, ["§l§e8人 トーナメント", LINE, `§f1回戦: §bあなた §fvs §c${ents[0].n}`, `§7${ents[1].n} vs ${ents[2].n} → ${qf[0].n}`, `§7${ents[3].n} vs ${ents[4].n} → ${qf[1].n}`, `§7${ents[5].n} vs ${ents[6].n} → ${qf[2].n}`, `§7準決勝（もう 一方）: ${qf[1].n} vs ${qf[2].n} → ${sf2.n}`, "§7試合の 前に 回復する。"].join("\n"));
  const names = ["1回戦", "準決勝", "決勝"];
  const { cleared } = await series(p, { title: `大会（${rule.n}）`, team: mine, heal: true, rounds: foes.map((f, i) => ({ foe: { team: f.team }, name: f.n, sub: `${names[i]}  vs ${f.n}`, info: { ghost: !!f.team[0]?.m } })) });
  d = load(p); if (!d) return; const e = eg(d); const got = [];
  if (cleared >= 3) {
    e.rec.cup = (e.rec.cup || 0) + 1; d.gold += 100000; got.push(gold(100000)); giveR(p, seedId(3), 1, got); if (Math.random() < 0.3) giveR(p, "i_inherit", 1, got);
    award(p, d, "cup", got); if (e.rec.cup >= 10) award(p, d, "cup10", got);
    for (const q of world.getAllPlayers()) q.sendMessage(`§6§l★ 大会（${rule.n}）優勝: ${p.name}！`);
  } else for (const q of world.getAllPlayers()) q.sendMessage(`§7大会（${rule.n}）優勝: ${cleared === 2 ? foes[2].n : sim(foes[Math.min(2, cleared)], foes[2]).n}`);
  save(p, d);
  await notice(p, "大会", cleared >= 3 ? `§6§l優勝！ §r§6${got.join("・")}` : `§c${names[cleared]}で 敗退……`);
}
async function runGhost(p, g) {
  let d = load(p); if (!d) return;
  const team = partyCopy(d);
  const { cleared } = await series(p, { title: "ゴースト対戦", team, rounds: [{ foe: { team: ghostTeam(g, null) }, name: `${g.name}の ゴースト`, sub: `vs ${g.name}の ゴースト`, info: { ghost: true } }] });
  d = load(p); if (!d) return; const e = eg(d); const got = [];
  if (cleared) { e.rec.ghostWins = (e.rec.ghostWins || 0) + 1; d.gold += 20000; got.push(gold(20000)); if (e.rec.ghostWins >= 10) award(p, d, "ghost10", got); }
  save(p, d);
  await notice(p, "ゴースト対戦", cleared ? `§6§l勝利！ §r§6${got.join("・")}` : "§c負けてしまった……");
}

// ---------- 19. 虚空の島 ----------
const VKEY = "mrpg:voidisle";
export function voidPos() { let sp = { x: 0, z: 0 }; try { const w = world.getDefaultSpawnLocation(); sp = { x: w.x, z: w.z }; } catch {} return { x: Math.floor(sp.x) + 3000, y: 210, z: Math.floor(sp.z) - 3000 }; }
const onVoid = (loc) => { const A = voidPos(); return Math.abs(loc.x - A.x) < 80 && Math.abs(loc.z - A.z) < 80 && loc.y > A.y - 30; };
const loadedAt = (dim, x, y, z) => { try { return !!dim.getBlock({ x, y, z }); } catch { return false; } };
async function buildVoid(ow, A) {
  run(ow, `tickingarea add ${A.x - 44} 0 ${A.z - 44} ${A.x + 44} 0 ${A.z + 44} mrpg_void`);
  for (let t = 0; t < 60 && ![[-40, -40], [40, 40], [-40, 40], [40, -40], [0, 0]].every(([dx, dz]) => loadedAt(ow, A.x + dx, A.y, A.z + dz)); t++) await wait(5);
  const R = 38;
  for (let z = -R; z <= R; z++) {
    const xo = Math.floor(Math.sqrt(Math.max(0, R * R - z * z))); if (!xo) continue;
    run(ow, `fill ${A.x - xo} ${A.y - 1} ${A.z + z} ${A.x + xo} ${A.y - 1} ${A.z + z} ${bk("grass_block")}`);
    run(ow, `fill ${A.x - xo} ${A.y - 3} ${A.z + z} ${A.x + xo} ${A.y - 2} ${A.z + z} ${bk("end_stone")}`);
    const x2 = Math.floor(xo * 0.7); if (x2) run(ow, `fill ${A.x - x2} ${A.y - 7} ${A.z + z} ${A.x + x2} ${A.y - 4} ${A.z + z} ${bk("obsidian")}`);
    if (z % 6 === 0) await wait(1);
  }
  for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2, x = Math.round(A.x + Math.cos(a) * (R - 3)), z = Math.round(A.z + Math.sin(a) * (R - 3)); run(ow, `fill ${x} ${A.y} ${z} ${x} ${A.y + 6} ${z} ${bk("crying_obsidian")}`); run(ow, `setblock ${x} ${A.y + 7} ${z} ${bk("end_rod")}`); }
  for (let i = 0; i < 30; i++) { const a = Math.random() * Math.PI * 2, r = 5 + Math.random() * (R - 9), x = Math.round(A.x + Math.cos(a) * r), z = Math.round(A.z + Math.sin(a) * r); run(ow, `setblock ${x} ${A.y} ${z} ${bk(["amethyst_cluster", "chorus_flower", "short_grass", "end_rod"][i % 4])}`); }
  run(ow, `fill ${A.x - 2} ${A.y - 1} ${A.z - 2} ${A.x + 2} ${A.y - 1} ${A.z + 2} ${bk("purpur_block")}`);
  await wait(4);
  const okk = [[0, 0], [20, 0], [-20, 0], [0, 20]].every(([dx, dz]) => { try { const b = ow.getBlock({ x: A.x + dx, y: A.y - 1, z: A.z + dz }); return b && !b.isAir; } catch { return false; } });
  if (okk) world.setDynamicProperty(VKEY, 1);
  return okk;
}
async function toVoid(p) {
  const A = voidPos(), ow = world.getDimension("minecraft:overworld");
  let okk = world.getDynamicProperty(VKEY) === 1;
  if (!okk) { try { barNote(p).setActionBar("§5虚空の島を さがしている…"); } catch {} okk = await buildVoid(ow, A); if (!okk) okk = await buildVoid(ow, A); }
  run(ow, "tickingarea remove mrpg_void");
  if (!okk) { await notice(p, "虚空の島", "§7島へ の 道が ひらけなかった……（しばらく してから もう一度）"); return; }
  try { p.setDynamicProperty("mrpg:vret", JSON.stringify({ x: p.location.x, y: p.location.y, z: p.location.z, dim: p.dimension.id })); } catch {}
  try { p.addEffect("slow_falling", 200, { showParticles: false }); } catch {}
  try { p.teleport({ x: A.x + 0.5, y: A.y + 0.5, z: A.z + 0.5 }, { dimension: ow }); } catch {}
  const d = load(p); if (d) { award(p, d, "void"); save(p, d); }
  try { showTitle(p, "§5§l虚空の島", { subtitle: "§fSSランクと 神が すむ 天の 果て", fadeInDuration: 10, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
}
function backVoid(p) {
  const r = p.getDynamicProperty("mrpg:vret"); if (typeof r !== "string") return;
  try { const o = JSON.parse(r); p.teleport({ x: o.x, y: o.y, z: o.z }, { dimension: world.getDimension(o.dim) }); } catch {}
  p.setDynamicProperty("mrpg:vret", undefined);
}
const X_POOL = () => { const god = Math.random() < 0.15; return ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && s !== "enma" && s !== "musashi" && (god ? S.rank === "X" : S.rank === "SS" && S.fam !== "king"); }); };

// ---------- 21. 幻の モンスター ----------
const PH_EL = [["moon", "満月の 夜", "dark"], ["thunder", "雷雨", "thunder"], ["rain", "雨", "water"], ["dawn", "夜明け", "light"]];
export const PHANTOMS = PH_EL.map(([id, cond, el]) => {
  const L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && S.rank === "SS" && S.fam !== "king" && S.fam !== "god" && (S.aff?.ge || [])[0] === el; });
  return { id, cond, el, sid: L.length ? L[L.length - 1] : null };
}).filter((x) => x.sid);
let WEATHER = "";   // 天気が 変わった ときに おぼえる（1.16 には 天気を 直接 聞く 関数が ないため）
try { world.afterEvents.weatherChange.subscribe((ev) => { try { WEATHER = String(ev.newWeather || ""); } catch {} }); } catch {}
function phantomNow(dim) {
  let t = 0; try { t = world.getTimeOfDay(); } catch {}
  const night = t > 13000 && t < 23000;
  let w = WEATHER; try { if (typeof dim.getWeather === "function") w = String(dim.getWeather()); } catch {}
  let moon = -1; try { moon = world.getMoonPhase(); } catch {}
  if (/thunder/i.test(w)) return "thunder";
  if (/rain/i.test(w)) return "rain";
  if (night && moon === 0) return "moon";
  if (t >= 22800 && t < 23600) return "dawn";
  return null;
}

// ---------- 20. 地方の 主 ----------
const NUSHI = new Map();
export function nushiSid(i) {   // v3.0: 地方ごとに ちがう 主（前の 地方と かぶらない）
  if (NUSHI.has(i)) return NUSHI.get(i);
  const used = new Set(); for (let k = 0; k < i; k++) { const u = nushiSid(k); if (u) used.add(u); }
  const r = nushiPick(i, used); NUSHI.set(i, r); return r;
}
function nushiPick(i, used) {
  const R = WREGIONS[i]; if (!R) return null;
  const fams = Object.entries(R.fams || {}).sort((a, b) => b[1] - a[1]).map(([f]) => f);
  for (const [rk, sz] of [[["SS"], ["G"]], [["SS"], ["G", "L"]], [["S"], ["G", "L"]]])   // v3.0: Xランクは 神だけ → 主は SSの G
    for (const f of fams) { const L = bestOf(f, rk, sz).filter((x) => !used.has(x)); if (L.length) return L[i % L.length]; }
  return null;
}
export function spawnNushi(p, i) {
  const sid = nushiSid(i); if (!sid) return false;
  const a = Math.random() * Math.PI * 2, x = p.location.x + Math.cos(a) * 18, z = p.location.z + Math.sin(a) * 18;
  let e; try { e = p.dimension.spawnEntity(TYPE, { x, y: p.location.y + 1, z }); } catch { return false; }
  setLook(e, sid); e.addTag("mrpg_boss"); e.setDynamicProperty("mrpg:nushi", i); e.setDynamicProperty("mrpg:lv", 100); e.setDynamicProperty("mrpg:q", 1);
  e.nameTag = `§4§l【主】§r§c${SPECIES[sid].name} Lv100 ${rankTag(SPECIES[sid].rank)}`;
  try { p.setDynamicProperty("mrpg:navi", JSON.stringify({ name: `${WREGIONS[i].short}の 主`, x: Math.floor(x), z: Math.floor(z), dim: p.dimension.id })); } catch {}
  for (const q of world.getAllPlayers()) if (q.dimension.id === p.dimension.id && Math.hypot(q.location.x - x, q.location.z - z) < 80) { q.sendMessage(`§4§l地の 底が ふるえる… ${WREGIONS[i].name}の 主 §f${SPECIES[sid].name}§4 が 現れた！`); sound(q, "mob.enderdragon.growl", 0.7); }
  return true;
}

// ---------- 22. 宝の地図 ----------
export async function useTmap(p, d) {
  const e = eg(d);
  if (e.tmap) {
    const dx = e.tmap.x - p.location.x, dz = e.tmap.z - p.location.z;
    try { p.setDynamicProperty("mrpg:navi", JSON.stringify({ name: "宝の しるし", x: e.tmap.x, z: e.tmap.z, dim: "minecraft:overworld" })); } catch {}
    // v2.9.9: まだ 行けない 地方に しるしが ついた ときなどに あきらめられる
    const k = await choose(p, "宝の地図", `§fしるしの 場所まで §e${Math.round(Math.hypot(dx, dz))}m§f（コンパスが 案内する）\n§7着くと 宝の 番人が 現れる。倒すと 宝箱が 出る。`,
      [["わかった", ICON("i_back")], ["§cしるしを 消す §8（地図は もどらない）", ICON("i_close")]]);
    if (k === 1 && (await confirm(p, "宝の地図", "§fしるしを 消しますか？\n§7消すと この 宝は もう 探せません。", "消す", "やめる"))) {
      const d2 = load(p); const e2 = d2 && eg(d2);
      if (e2 && e2.tmap) { e2.tmap = null; save(p, d2); try { p.setDynamicProperty("mrpg:navi", undefined); } catch {} p.sendMessage("§7宝の しるしを 消した。"); }
    }
    return;
  }
  if (p.dimension.id !== "minecraft:overworld") { await notice(p, "宝の地図", "§7この 地図は 地上の ものだ。"); return; }
  if (!(await confirm(p, "宝の地図", "§f地図を ひらきますか？\n§7どこかに しるしが うかびあがる（300〜700m 先）。", "ひらく", "やめる"))) return;
  if (!takeItem(p, "mrpg:i_tmap")) return;
  const a = Math.random() * Math.PI * 2, r = 300 + Math.random() * 400;
  e.tmap = { x: Math.floor(p.location.x + Math.cos(a) * r), z: Math.floor(p.location.z + Math.sin(a) * r) };
  save(p, d);
  try { p.setDynamicProperty("mrpg:navi", JSON.stringify({ name: "宝の しるし", x: e.tmap.x, z: e.tmap.z, dim: "minecraft:overworld" })); } catch {}
  await notice(p, "宝の地図", `§6地図に しるしが うかびあがった！ §f（${Math.round(r)}m 先）\n§7コンパスが 案内する。`);
}
export function spawnTmapBoss(p, d) {
  const e = eg(d), P = partyPower(d);
  const ranks = P.lv >= 80 ? ["SS"] : P.lv >= 50 ? ["S"] : ["A"];
  const L = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.fuseonly && !S.metalmon && ranks.includes(S.rank) && S.fam !== "king" && S.fam !== "god"; });
  const sid = L[Math.floor(Math.random() * L.length)];
  let ent; try { ent = p.dimension.spawnEntity(TYPE, { x: e.tmap.x + 0.5, y: p.location.y + 1, z: e.tmap.z + 4.5 }); } catch { return; }
  setLook(ent, sid); ent.addTag("mrpg_boss"); ent.addTag("mrpg_tmap"); try { ent.setDynamicProperty("mrpg:towner", p.id); } catch {} ent.setDynamicProperty("mrpg:lv", Math.min(100, P.lv + 5)); ent.setDynamicProperty("mrpg:q", 1);
  ent.nameTag = `§6【宝の 番人】§f${SPECIES[sid].name} Lv${Math.min(100, P.lv + 5)}`;
  e.tmap.spawned = Date.now(); save(p, d);
  p.sendMessage("§6§l宝の しるしの 場所だ！ §r§6宝の 番人が 立ちはだかる！"); sound(p, "mob.wither.spawn", 1.2);
}

// ---------- 23. 牧場 ／ 24. 育て屋 ----------
const H = 3600e3;
function ranchGain(e, now = Date.now()) {
  const R = e.ranch; if (!R || !R.mons.length) return null;
  const hrs = Math.min(24, (now - (R.t || now)) / H);
  return { hrs, exp: R.mons.map((m) => Math.floor(hrs * 4000 * (1 + rIdx(m.sp) / 4))), gold: Math.floor(hrs * 200 * R.mons.length), eggs: Math.floor(hrs / 2) };
}
const CARE_MIN = 15;
function careEggs(e, now = Date.now()) { const C = e.care; if (!C || !C.a || !C.b) return 0; return Math.min(3, Math.floor((now - C.t) / (CARE_MIN * 60e3))); }
export function careChild(a, b) {
  const okP = (x) => x && SPECIES[x.sp] && !SPECIES[x.sp].hidden && !String(x.sp).startsWith("book_") && !["king", "god"].includes(SPECIES[x.sp].fam);
  const cands = [a, b].filter(okP); const pa = cands.length ? cands[Math.floor(Math.random() * cands.length)] : a; let sp = pa.sp;
  if (["musashi", "enma"].includes(sp)) { const alt = ORDER.filter((x) => { const S = SPECIES[x]; return !S.hidden && !S.metalmon && S.fam === "sword" && S.rank === "A"; }); sp = alt.length ? alt[Math.floor(Math.random() * alt.length)] : "hswo12"; }   // v2.9.14: ムサシ・エンマは 生まれない
  const m = makeMonster(sp, 1, false);
  m.tal = {}; for (const k of STATS) m.tal[k] = Math.random() < 0.6 ? Math.max(a.tal?.[k] ?? 0, b.tal?.[k] ?? 0) : Math.floor(Math.random() * (TAL_MAX + 1));
  const pool = (SPECIES[sp].tpool || []).map(([t]) => t);
  const fromP = [...baseTraits(a), ...baseTraits(b)].filter((t) => pool.includes(t));
  if (fromP.length) { const base = SPECIES[sp].traits || []; const r = Array.isArray(m.rtr) ? [...m.rtr] : [...base]; const slots = r.map((t, i) => (["act2", "act23", "act34", "famking", "metal"].includes(t) ? -1 : i)).filter((i) => i >= 0); if (slots.length) { const t = fromP[Math.floor(Math.random() * fromP.length)]; if (!r.includes(t)) { r[slots[Math.floor(Math.random() * slots.length)]] = t; m.rtr = r; } } }
  m.plus = 5; m.bred = 1; if (Math.random() < 1 / 64) m.shiny = true;   // v2.9.12: 育て屋の 子（売値は 低め）
  if (Math.random() < 0.08 && SPECIES[sp].ht) m.ht = true;
  return full(m);
}

// ---------- 25. 研究所 ----------
export const LAB = [
  { id: "tmap", n: "宝の地図", need: 30, cost: 20000, give: () => "i_tmap" },
  { id: "inherit", n: "継承の秘石", need: 120, cost: 150000, give: () => "i_inherit" },
  { id: "seed3", n: "能力の 秘果（ランダム）", need: 200, cost: 300000, give: () => seedId(3) },
  { id: "limit", n: "限界突破の石", need: 300, cost: 500000, give: () => "i_limit" },
  { id: "plus10", n: "転生の秘薬（+10）", need: 400, cost: 600000, give: () => "i_plus10" },
  { id: "trpick", n: "特性の秘薬", need: 600, cost: 1500000, give: () => "i_trpick" },
];
function matCount(p) {
  const out = {}; const c = inv(p);
  if (c) for (let i = 0; i < c.size; i++) { const it = c.getItem(i); if (!it) continue; const id = it.typeId.replace("mrpg:", ""); if (ITEMS[id]?.kind === "material") out[id] = (out[id] || 0) + it.amount; }
  const b = bagLoad(p); for (const [id, n] of Object.entries(b.i || {})) if (ITEMS[id]?.kind === "material" && n > 0) out[id] = (out[id] || 0) + n;
  return out;
}
function donateAll(p, d) {
  const mats = matCount(p); let pt = 0;
  for (const [id, n] of Object.entries(mats)) { const inInv = countItem(p, `mrpg:${id}`); if (inInv) takeItem(p, `mrpg:${id}`, inInv); pt += n * ((ITEMS[id].mtier ?? 0) + 1); }
  const b = bagLoad(p); let ch = false; for (const id of Object.keys(b.i || {})) if (ITEMS[id]?.kind === "material") { delete b.i[id]; ch = true; } if (ch) bagSave(p, b);
  eg(d).lab.pt += pt; return pt;
}

// ---------- 8. 特性の 継承（配合で）----------
const FIXED = new Set(["act2", "act23", "act34", "famking", "metal"]);
export async function inheritFlow(p, d, parents, child) {
  const free = !!((child.plus || 0) > 99 && endingDone(d));   /* 第68版: クリア後、+99を こえた 子は 秘石なしで 1つ 受けつげる */
  if (!free && countItem(p, "mrpg:i_inherit") <= 0) return;
  const cand = [...new Set(parents.flatMap((m) => [...baseTraits(m), ...(m.xtr ? [m.xtr] : [])]))].filter((t) => TRAITS[t] && !FIXED.has(t) && !TRAITS[t].rare && !baseTraits(child).includes(t));
  if (!cand.length) return;
  if (!(await confirm(p, free ? "特性の 継承" : "継承の秘石", free ? `§d${child.nm}は +${child.plus}（+99 こえ）！§f\n親の 特性を 1つ 受けつがせますか？ §7（秘石は いらない）` : `§f継承の秘石を 使って、親の 特性を 1つ ${child.nm}に 受けつがせますか？\n§7（秘石は 1つ なくなる）`, "受けつぐ", "やめる"))) return;
  const k = await paged(p, "受けつぐ 特性", "§7親の 特性から えらぶ（いまの 特性の どれかと 入れかわる）", cand.map((t) => B_(`${TRAITS[t].name}\n§8${clipT(String(TRAITS[t].desc), 34)}`, ICON("i_skill"))), 8);
  if (k < 0 || k >= cand.length) return;
  const t = cand[k], base = baseTraits(child);
  if (base.includes(t)) { await notice(p, "継承の秘石", "§7その 特性は もう もっている。"); return; }
  const slots = base.map((x, i) => (FIXED.has(x) ? -1 : i)).filter((i) => i >= 0);
  if (!slots.length) { if (child.xtr) { await notice(p, "継承の秘石", "§7この 子は もう 特性を 受けつげない（固定の 特性だけ・追加の 特性も ある）。"); return; } child.xtr = t; }
  else {
    const j = await choose(p, "入れかえる 特性", `§f${TRAITS[t].name} と 入れかえる 特性を えらんでください`, [...slots.map((i) => B_(`${TRAITS[base[i]]?.name || base[i]}`, ICON("i_skill"))), B_("§7やめる", ICON("i_back"))]);
    if (j < 0 || j >= slots.length) return;
    if (!free && countItem(p, "mrpg:i_inherit") <= 0) return;
    base[slots[j]] = t; child.rtr = base;
  }
  if (!free && !takeItem(p, "mrpg:i_inherit")) return;
  try { if (isKiwami(child)) { child.kw = true; addIdx(eg(d).kw, child.sp); } } catch {}
  sound(p, "random.levelup");
  return `\n§a特性【${TRAITS[t].name}】を 受けついだ！（${free ? "+99 こえの 力" : "継承の秘石"}）`;   // disconnect: セーブは 配合の 誕生と いっしょに（ここで 閉じても 秘石だけ きえない）
}
// ---------- 11. 限界突破 ----------
export async function useLimit(p, d, pickMon) {
  const m = await pickMon(p, d, "限界突破の石を 誰に 使う？", "§7Lv100の 仲間の 能力が +4%（5段まで・合計 +20%）");
  if (!m) return;
  if (m.lv < 100) { await notice(p, "限界突破", "§cLv100に なってから 使える。"); return; }
  if ((m.lim || 0) >= 5) { await notice(p, "限界突破", "§7もう 限界まで 突破している（5段）。"); return; }
  if (!takeItem(p, "mrpg:i_limit")) return; m.lim = (m.lim || 0) + 1; if (m.hp > 0) full(m);   /* v3.0 第63版: 倒れた 子は 生きかえらない */
  if (m.lim >= 5) award(p, d, "limit5");
  save(p, d); sound(p, "random.levelup"); particle(p, "minecraft:totem_particle", 1.5);
  await notice(p, "限界突破", `§6§l${m.nm}は 限界を 突破した！ §r§6★${m.lim}（能力 +${m.lim * 4}%）`);
}

// ---------- 図鑑の 達成報酬・コレクション ----------
const nonHidden = ORDER.filter((s) => !SPECIES[s].hidden);
function claims(d) {
  const e = eg(d), own = new Set(d.own || []), L = [];
  const n = nonHidden.filter((x) => own.has(SPECIES[x].idx)).length;   /* 第68版: 神々は 数えない */
  for (let k = 100; k <= nonHidden.length + 99; k += 100) if (n >= Math.min(k, nonHidden.length)) L.push({ key: `own${k}`, n: `図鑑 ${Math.min(k, nonHidden.length)}種`, give: (p, got) => { d.gold += 30000 * (k / 100); got.push(gold(30000 * (k / 100))); giveR(p, k % 300 === 0 ? "e_rainbow" : "e_silver", 1, got); for (const [t, v] of [["dex100", 100], ["dex500", 500], ["dex1000", 800]]) if (k >= v) award(p, d, t, got); if (k >= nonHidden.length) award(p, d, "dexall", got); } });
  for (const f of FAMILIES) { const all = nonHidden.filter((s) => SPECIES[s].fam === f.id); if (all.length && all.every((s) => own.has(SPECIES[s].idx))) L.push({ key: `fam_${f.id}`, n: `${f.name} 完成`, give: (p, got) => { award(p, d, `fam_${f.id}`, got); giveLegend(p, f.id, got); } }); }
  for (const r of RI) { const all = nonHidden.filter((s) => SPECIES[s].rank === r); if (all.length && all.every((s) => own.has(SPECIES[s].idx))) L.push({ key: `rank_${r}`, n: `${r}ランク 完成`, give: (p, got) => { award(p, d, `rank_${r}`, got); d.gold += 20000 * (RI.indexOf(r) + 1); got.push(gold(20000 * (RI.indexOf(r) + 1))); if (RI.indexOf(r) >= 6) giveR(p, "i_trpick", 1, got); } }); }
  const ms = (key, list, steps, nm, tit) => { for (const [k, t] of steps) if (list.length >= k) L.push({ key: `${key}${k}`, n: `${nm} ${k}種`, give: (p, got) => { d.gold += 10000 * k; got.push(gold(10000 * k)); if (t) award(p, d, t, got); if (k >= 50) giveR(p, "i_inherit", 1, got); } }); };
  ms("sh", e.sh, [[5, null], [10, "shiny10"], [25, null], [50, "shiny50"], [100, null]], "かがやき図鑑", null);
  ms("ht", e.htd, [[10, null], [30, "ht30"], [60, null], [100, null]], "固有特性図鑑", null);
  ms("walk", e.walk, [[10, null], [30, "walk30"], [100, "walk100"], [300, null]], "散歩", null);
  ms("ride", e.ride, [[10, null], [30, "ride30"], [100, "ride100"]], "ライド", null);
  ms("kw", e.kw, [[1, "kiwami1"], [5, null], [10, "kiwami10"], [30, null]], "完全個体「極」", null);
  return L.filter((x) => !e.claim.includes(x.key));
}
function scanAll(d) {
  const e = eg(d); let n = 0;
  for (const m of allMons(d)) { if (m.shiny) addIdx(e.sh, m.sp); if (m.ht) addIdx(e.htd, m.sp); if (isKiwami(m)) { m.kw = true; if (addIdx(e.kw, m.sp)) n++; } }
  let mk = 0; for (const m of allMons(d)) for (const v of Object.values(m.mk || {})) if (v >= MK_NEED) mk++;
  e.rec.mk = mk;
  return n;
}

// ---------- 記録帳 ----------
function recText(d) {
  const e = eg(d), R = e.rec, f = (n) => (n || 0).toLocaleString ? (n || 0).toLocaleString() : n || 0;
  return ["§l§e記録帳", LINE,
    `§f最大 ダメージ §e${f(R.maxDmg)}${R.maxBy ? ` §7（${R.maxBy}）` : ""}`, `§f勝利 §e${f(R.wins)}§f  連勝 §e${R.streak || 0}§7（最高 ${R.bestStreak || 0}）`,
    `§f倒した 数 §e${f(R.kills)}§f  スカウト 成功 §e${f(R.scouts)}`, `§fボス戦の 最短 §e${R.fast ? R.fast + "ターン" : "-"}`,
    `§f無限の塔 §e${R.tower || 0}階§f  ボスラッシュ §e${R.rush || 0}回${R.rushBest ? `§7（最速 ${Math.round(R.rushBest / 60000)}分）` : ""}`,
    `§f縛りの石板 §e${R.shibari || 0}回§f  今日の挑戦状 連続 §e${R.dailyBest || 0}日`, `§f週替わりの強敵 §e${R.weekly || 0}回§f  大会 優勝 §e${R.cup || 0}回`,
    `§fランクマッチ 最高 §e${R.rateBest || "-"}§f  ゴースト 勝利 §e${R.ghostWins || 0}`, `§f宝の地図 §e${R.tmaps || 0}回`,
    `§f虚空の島で 勝利 §e${R.void || 0}§f  地方の 主 §e${Object.keys(e.nushi).length}/${WREGIONS.length}`, `§f極めた 技 §e${R.mk || 0}§f  「極」 §e${e.kw.length}種`,
    `§fかがやき図鑑 §e${e.sh.length}§f  固有特性図鑑 §e${e.htd.length}§f  幻 §e${e.ph.length}/${PHANTOMS.length}`, `§f散歩 §e${e.walk.length}種§f  ライド §e${e.ride.length}種`,
  ].join("\n");
}

// ---------- 戦いの あとの 通知 ----------
function onEnd(B, x) {
  const { p, d } = x; const e = eg(d), R = e.rec;
  const won = B.result === "win" || B.result === "scout";
  const log = (x.plog = x.plog || []);
  if (B.recDmg > (R.maxDmg || 0)) { R.maxDmg = B.recDmg; R.maxBy = B.recBy; if (B.recDmg >= 9999) award(p, d, "dmg9999", log); }
  if (won) {
    R.wins = (R.wins || 0) + 1; R.streak = (R.streak || 0) + 1; R.bestStreak = Math.max(R.bestStreak || 0, R.streak); if (R.streak >= 100) award(p, d, "streak100", log);
    R.kills = (R.kills || 0) + B.enemies.filter((f) => f.hp <= 0 && !f.scouted).length;
    if (B.boss || B.master) R.fast = Math.min(R.fast || 999, B.turn || 1);
  } else if (B.result === "lose") R.streak = 0;
  if (B.result === "scout" || B.scouted) { R.scouts = (R.scouts || 0) + 1; }
  const meX = (B.players || []).find((x) => x.p && x.p.id === p.id);
  const fairN = !meX || (meX.joinTurn || 1) <= 1 || (B.turn || 1) - (meX.joinTurn || 1) >= 2;   // v2.9.12: 終わりかけに 入った 人は 主の ごほうびなし
  if (won && fairN && B.nushi !== null && B.nushi !== undefined) {
    const i = B.nushi, first = !e.nushi[i]; e.nushi[i] = (e.nushi[i] || 0) + 1;
    d.gold += first ? 150000 : 30000; log.push(`§4§l${WREGIONS[i]?.name}の 主を 倒した！ §r§e${gold(first ? 150000 : 30000)}`);
    if (first || Math.random() < 0.25) giveLegend(p, SPECIES[B.enemies[0].m.sp].fam, log);
    award(p, d, `nushi_${i}`, log); if (WREGIONS.every((_, k) => e.nushi[k])) award(p, d, "nushiall", log);
  }
  if (won && B.tmap && e.tmap && (!B.tmapOwner || B.tmapOwner === p.id)) {   // v2.9.6: じぶんの 地図の 番人だけ
    const T = e.tmap; e.tmap = null; R.tmaps = (R.tmaps || 0) + 1;
    const fin = endingDone(d);
    const ct = fin ? (Math.random() < 0.03 ? 10 : rollTier(7, 0)) : rollTier(4, 0);   // 宝の地図: クリア後は 魔法の宝箱 以上（v2.9.6: クリア前は 金の宝箱 前後）
    try { const y = Math.floor(p.location.y); for (const c of chestCmds(T.x, y, T.z, ct, p.dimension.id)) p.runCommand(c); } catch {}
    const g = 6000 + Math.floor(Math.random() * 10000); d.gold += g; log.push(`§6§l${tierName(ct)}§6§lを 見つけた！ §r§e${gold(g)}`);   // v2.9.6: 地図の ねだんより 少なく（お金かせぎに ならない）
    const got = []; if (fin) { giveR(p, seedId(3), 1, got); if (Math.random() < 0.3) giveR(p, "i_inherit", 1, got); if (Math.random() < 0.05) giveR(p, "i_limit", 1, got); } if (got.length) log.push(`§6${got.join("・")}`);
    if (fin && Math.random() < 0.1) giveLegend(p, pickR(Math.random, NORMAL_FAMS), log);
    if (R.tmaps >= 5) award(p, d, "tmap5", log);
    try { p.setDynamicProperty("mrpg:navi", undefined); } catch {}
  }
  if (won && B.phantom) { if (addIdx(e.ph, B.enemies[0].m.sp)) log.push(`§d§l幻の モンスターを 図鑑に 記録した！ §r§d（${e.ph.length}/${PHANTOMS.length}）`); if (PHANTOMS.every((x) => e.ph.includes(SPECIES[x.sid].idx))) award(p, d, "phantom", log); }
  if (won && B.voidIsle) { R.void = (R.void || 0) + 1; if (R.void >= 30) award(p, d, "void30", log); }
  if (won && !(B.master && B.master.ch) && (B.boss || B.master || B.enemies.some((f) => rIdx(f.m.sp) >= 5)) && Math.random() < 0.04) { giveItem(p, "mrpg:i_tmap"); log.push("§6宝の地図を ひろった！"); }
  // 伝説の 装備 3つ
  for (const m of d.party) { const n = ["w", "a", "x"].filter((k) => m.eq && m.eq[k] && ITEMS[m.eq[k]]?.lfam === SPECIES[m.sp].fam).length; if (n >= 3) award(p, d, "legend", log); }
  let mk = 0; for (const m of d.party) for (const v of Object.values(m.mk || {})) if (v >= MK_NEED) mk++;
  if (mk >= 10) award(p, d, "mk10", log);
}

// ---------- 見はり（主・宝・虚空の島・称号）----------
let tick = 0;
export function initEndgame() {
  battleHooks.push(onEnd);
  hooks.shinyRate = (sid) => (SPECIES[sid]?.fam === shinyFam() ? 1 / 50 : 1 / 250);
  hooks.override = (e, lv, sid) => {
    if (e.dimension.id === "minecraft:overworld" && onVoid(e.location)) {
      const L = X_POOL(); if (!L.length) return null;
      const s = L[Math.floor(Math.random() * L.length)];
      return { sid: s, lv: 90 + Math.floor(Math.random() * 11), q: 0.8, tags: ["mrpg_void", "mrpg_rare"], msg: `§5虚空の 気配… §f${SPECIES[s].name}§5（ランク${SPECIES[s].rank}）が 近くに いる` };
    }
    if (e.dimension.id === "minecraft:overworld" && lv >= 40 && Math.random() < 1 / 120 && (() => {   // v2.9.7: 幻は 物語を 見届けた 人の 近くだけ
      try { const L = e.location; const q = world.getAllPlayers().find((p) => p.dimension.id === e.dimension.id && Math.hypot(p.location.x - L.x, p.location.z - L.z) < 64); return q && endingDone(load(q)); } catch { return false; } })()) {
      const c = phantomNow(e.dimension); const P = c && PHANTOMS.find((x) => x.id === c);
      if (P) return { sid: P.sid, lv: Math.min(100, lv + 10), q: 1, tags: ["mrpg_rare", "mrpg_phantom"], msg: `§d§l幻の 気配… ${P.cond}に だけ 現れる §f${SPECIES[P.sid].name}§d が 近くに いる！` };
    }
    return null;
  };
  hooks.onRide = (p, sp) => { const d = load(p); if (!d || !SPECIES[sp]) return; if (addIdx(eg(d).ride, sp)) save(p, d); };
  world.afterEvents.playerSpawn.subscribe(({ player }) => { system.runTimeout(() => { try { applyTitle(player, load(player)); if (typeof player.getDynamicProperty("mrpg:vret") === "string" && !onVoid(player.location)) player.setDynamicProperty("mrpg:vret", undefined); } catch {} }, 50); });
  system.runInterval(() => {
    tick++;
    const A = voidPos();
    for (const p of world.getAllPlayers()) {
      try {
        // 虚空の島から 落ちたら 島の 上へ
        if (p.dimension.id === "minecraft:overworld" && world.getDynamicProperty(VKEY) === 1 && typeof p.getDynamicProperty("mrpg:vret") === "string" && Math.abs(p.location.x - A.x) < 90 && Math.abs(p.location.z - A.z) < 90 && p.location.y < A.y - 25 && p.location.y > A.y - 120) { p.addEffect("slow_falling", 100, { showParticles: false }); p.teleport({ x: A.x + 0.5, y: A.y + 1, z: A.z + 0.5 }); }
        if (busy.has(p.id) || p.dimension.id !== "minecraft:overworld") continue;
        const d = load(p); if (!d) continue;
        const e = eg(d);
        // 宝の しるし
        if (e.tmap && Math.hypot(p.location.x - e.tmap.x, p.location.z - e.tmap.z) < 8) {
          let near = false; try { near = p.dimension.getEntities({ type: TYPE, location: p.location, maxDistance: 30, tags: ["mrpg_tmap"] }).length > 0; } catch {}
          if (!near) spawnTmapBoss(p, d);
        }
        // 地方の 主（クリア後・30秒ごとに 1/45）
        if (tick % 15 === 0 && endingDone(d) && !onVoid(p.location) && !getDg(p) && Math.random() < 1 / 45) {
          const i = regionIdxAt(p.location);
          let near = false; try { near = p.dimension.getEntities({ type: TYPE, location: p.location, maxDistance: 64, tags: ["mrpg_boss"] }).length > 0; } catch {}
          if (i >= 0 && !near && (!e.nushi[i] || Math.random() < 0.35)) spawnNushi(p, i);
        }
      } catch {}
    }
  }, 40);
}

// ---------- メニュー ----------
const lockMsg = "§7エンディングの あとで 開放";
export async function endgameMenu(p, d) {
  await seasonPrize(p, d);
  scanAll(d); save(p, d);
  for (;;) {
    const e = eg(d), end = endingDone(d);
    const W = weeklyInfo();
    const body = [`§l§dやりこみ`, LINE, `§f今週の 色違い: §e${FNAME[shinyFam()]}§f（出やすい）`, `§f週替わりの強敵: §c${FNAME[W.fam]}・${EL_NAME[W.el]}`, `§f称号: §6${e.title ? TITLES[e.title]?.[0] : "なし"}`, end ? "" : "§7※ 挑戦の 多くは エンディング後に 開放"].join("\n");
    const s = await choose(p, "やりこみ", body, [B_("§l§c挑戦する\n§8塔・ボスラッシュ・縛り・挑戦状・強敵", ICON("i_fight")), B_("§l§9対戦する\n§8ランクマッチ・大会・ゴースト", ICON("i_scout")),
      B_("§l§6集める\n§8図鑑の 報酬・かがやき・極・散歩・幻・主", ICON("i_zukan")), B_("§l§2施設\n§8牧場・研究所・虚空の島", ICON("i_box")), B_("§l称号と 記録\n§8称号・記録帳・ランキング", ICON("i_help")), B_("§eやりこみの しくみ", ICON("i_help")), B_("§7戻る", ICON("i_back"))]);
    let r = null;
    if (s === 0) r = await challengeMenu(p, d);
    else if (s === 1) r = await versusMenu(p, d);
    else if (s === 2) await collectMenu(p, d);
    else if (s === 3) r = await facilityMenu(p, d);
    else if (s === 4) await titleMenu(p, d);
    else if (s === 5) await notice(p, "やりこみの しくみ", HELP_TEXT());
    else return null;
    if (typeof r === "function") return r;
  }
}
async function challengeMenu(p, d) {
  const e = eg(d), s0 = qs(d), end = endingDone(d);
  const rushOk = end && s0.bs.length >= BS_N && s0.final;
  const today = DAY(), dl = e.daily || {};
  const W = weeklyInfo();
  const k = await choose(p, "挑戦する", `§7パーティの コピーで 戦う（本物は 減らない）。回復は なし（ボスラッシュの 3割と 大会を のぞく）。\n§7空の 闘技場で 戦う。`, [
    B_(`${end ? "§l" : "§8"}無限の塔\n§7最高 ${e.rec.tower || 0}階・10階ごとに 番人`, ICON("i_fight")),
    B_(`${rushOk ? "§l" : "§8"}ボスラッシュの石板\n§7${rushOk ? `石板の 主15＋星冠王（${e.rec.rush || 0}回 制覇）` : "15枚 封印＋星冠王で 開放"}`, ICON("i_zukan")),
    B_(`${end ? "§l" : "§8"}縛りの石板\n§7ランダムな 縛りで 3連戦（${e.rec.shibari || 0}回）`, ICON("i_skill")),
    B_(`${end ? "§l" : "§8"}今日の挑戦状\n§7${dl.try === today ? "今日は 挑戦ずみ" : "1日1回"}・連続 ${dl.last === today || dl.last === today - 1 ? dl.streak || 0 : 0}日`, ICON("i_help")),
    B_(`${end ? "§l" : "§8"}週替わりの強敵\n§7${FNAME[W.fam]}・${EL_NAME[W.el]}（今週 ${e.weekly && e.weekly.wk === WEEK() ? e.weekly.n : 0}回）`, ICON("i_fight")),
    B_("§7戻る", ICON("i_back"))]);
  if (k < 0 || k > 4) return null;
  if (!end || (k === 1 && !rushOk)) { await notice(p, "挑戦", k === 1 ? "§7物語の 石板 15枚を すべて 封印し、星冠王に 勝つと 開放。" : lockMsg); return null; }
  if (promoteBench(d)) save(p, d);   /* 第69版 */
  if (!d.party.some((m) => m.hp > 0)) { await notice(p, "挑戦", "§c戦える 仲間が いない！ 宿屋で 回復 しよう。"); return null; }
  if (k === 0) {
    const top = Math.floor((e.rec.tower || 0) / 10) * 10;
    const starts = [1]; for (let f = 11; f <= top + 1; f += 10) starts.push(f);
    const j = await choose(p, "無限の塔", `§f最高 §e${e.rec.tower || 0}階\n§7どこから のぼる？（10階ごとの 番人を 越えた 階から えらべる）\n§7番人の 階: お金・実・宝の地図・継承の秘石・限界突破の石・伝説の 装備（はじめて 越えた とき）`, [...starts.slice(-6).map((f) => B_(`§l${f}階から`, ICON("i_fight"))), B_("§7やめる", ICON("i_back"))]);
    const L = starts.slice(-6); if (j < 0 || j >= L.length) return null;
    return () => runTower(p, L[j]);
  }
  if (k === 1) { if (!(await confirm(p, "ボスラッシュの石板", `§f物語の 石板の 主 ${BS_N}体 → 星冠王 の ${BS_N + 1}連戦。\n§c回復は 1戦ごとに 3割だけ§7（道具は 使える）。主たちは クリア後の 強さ（Lv90〜100）。\n§6制覇: 50万G・特性の秘薬・限界突破の石・称号（はじめては 覇王の 伝説装備も）`, "挑む！", "やめる"))) return null; return () => runRush(p); }
  if (k === 2) {
    const r = rngOf(Date.now() % 77777); const L = [...SHIBARI].sort(() => r() - 0.5).slice(0, 2);
    if (!(await confirm(p, "縛りの石板", `§f今回の 縛り:\n§c・${L.map((x) => x.n).join("\n・")}\n§73連戦（回復なし）。3戦目は 番人。\n§6達成: お金・秘果・ときどき 宝の地図／継承の秘石／特性の秘薬`, "挑む！", "べつの 縛りに"))) return null;
    return () => runShibari(p, L);
  }
  if (k === 3) {
    if (dl.try === today) { await notice(p, "今日の挑戦状", "§7今日は もう 挑戦した。明日 また 来よう。"); return null; }
    if (!(await confirm(p, "今日の挑戦状", `§f今日の 相手（みんな 同じ）:\n§c${teamText(dailyTeam(today))}\n§71日 1回だけ。勝つと 連続日数で ほうびが 増える（7日ごとに 限界突破の石）`, "挑む！", "やめる"))) return null;
    return () => runDaily(p);
  }
  if (k === 4) {
    if (!(await confirm(p, "週替わりの強敵", `§f今週の 強敵: §c${FNAME[W.fam]}・${EL_NAME[W.el]}\n§c${teamText(W.team)}\n§7何度でも 挑める。今週 1・3・5・10回目に とくべつな ほうび（5回目は ${FNAME[W.fam]}の 伝説の 装備）`, "挑む！", "やめる"))) return null;
    return () => runWeekly(p);
  }
  return null;
}
async function versusMenu(p, d) {
  if (!endingDone(d)) { await notice(p, "対戦する", "§7ランクマッチ・大会・ゴースト対戦は 物語を 見届けると 遊べる。"); return; }   // v2.9.6
  rateOf(d); const e = eg(d);
  const k = await choose(p, "対戦する", `§fレート §e${e.rate.r} §7（${TIER_N[rateTier(e.rate.r)]}・シーズン ${seasonName(e.rate.s)}）\n§7ゴースト＝ 登録された だれかの パーティ（AIが 動かす）`, [
    B_("§lランクマッチ\n§7ゴーストか AIと 1戦・レートが 変わる", ICON("i_fight")), B_("§l大会\n§78人 トーナメント・ルールを えらぶ", ICON("i_zukan")),
    B_("ゴースト対戦\n§7登録された チームと 戦う", ICON("i_scout")), B_("§aゴーストを 登録\n§7いまの パーティを 登録", ICON("i_party")), B_("§7戻る", ICON("i_back"))]);
  if (k === 0) return () => runRanked(p);
  if (k === 1) { const r = await pickRule(p); if (!r) return null; return () => runCup(p, r); }
  if (k === 2) {
    const L = ghosts().filter((g) => g.name !== p.name);
    if (!L.length) { await notice(p, "ゴースト対戦", "§7まだ だれも 登録していない。（マルチの 友だちに 登録して もらおう）"); return null; }
    const j = await paged(p, "ゴースト対戦", "§7戦う ゴーストを えらぶ", L.map((g) => B_(`§l${g.name}§r §7レート${g.r || 1000}\n§8${g.team.map((m) => m.nm).join("・").slice(0, 30)}`, MON_ICON(g.team[0].sp))), 8);
    if (j < 0 || j >= L.length) return null;
    return () => runGhost(p, L[j]);
  }
  if (k === 3) await registerGhost(p, d);
  return null;
}
async function collectMenu(p, d) {
  for (;;) { if (!ok(p)) return null;   /* 第69版 */
    scanAll(d);
    if ((d.own || []).filter((i) => i < ORDER.length).length >= 800 && award(p, d, "dex1000", [])) save(p, d);   /* 第67版: 図鑑800の 称号を あとから でも */
    const e = eg(d), C = claims(d);
    const k = await choose(p, "集める", [`§f図鑑 §e${nonHidden.filter((x) => (d.own || []).includes(SPECIES[x].idx)).length}§7/${nonHidden.length}`, `§fかがやき §e${e.sh.length}§f  固有特性 §e${e.htd.length}§f  極 §e${e.kw.length}`, `§f散歩 §e${e.walk.length}§f  ライド §e${e.ride.length}§f  幻 §e${e.ph.length}/${PHANTOMS.length}§f  主 §e${Object.keys(e.nushi).length}/${WREGIONS.length}`, C.length ? `§6§lもらえる ほうびが ${C.length}こ ある！` : "§7いまは もらえる ほうびは ない"].join("\n"),
      [B_(`${C.length ? "§6§l" : ""}達成報酬を うけとる${C.length ? ` (${C.length})` : ""}`, ICON("i_shop")), B_("完全個体「極」\n§7条件と 見つけた 極", ICON("i_zukan")), B_("幻と 地方の 主", ICON("i_zukan")), B_("技の 極め\n§7100回 使った 技", ICON("i_skill")), B_("§7戻る", ICON("i_back"))]);
    if (k === 0) {
      if (!C.length) { await notice(p, "達成報酬", "§7いまは ない。\n§f図鑑 100種ごと・系統の 完成・ランクの 完成・かがやき図鑑・固有特性図鑑・散歩・ライド・極 で もらえる。"); continue; }
      const got = []; for (const c of C) { eg(d).claim.push(c.key); got.push(`§e◆ ${c.n}`); c.give(p, got); }
      save(p, d); sound(p, "ui.toast.challenge_complete", 1);
      await notice(p, "達成報酬", got.join("\n"));
    } else if (k === 1) {
      const L = e.kw.map((i) => SPECIES[ORDER[i]]?.name).filter(Boolean);
      await notice(p, "完全個体「極」", ["§6§l完全個体「極」の 条件", "§f・才能（9つの 能力の 才能）が すべて 最大（31）", "§f・固有特性を もっている", "§f・個体の 特性（◇）が すべて 相性◎（その 種族の おすすめ）", "§7見つけると 名前に §6極§7 が つく。配合・スカウトで 見つかる。", LINE, L.length ? `§f見つけた: §6${L.join("・")}` : "§7まだ 見つけていない"].join("\n"));
    } else if (k === 2) {
      await notice(p, "幻と 地方の 主", ["§d§l幻の モンスター §r§7（その 時だけ フィールドに まれに 現れる・Lv40以上の 土地）", ...PHANTOMS.map((x) => `${e.ph.includes(SPECIES[x.sid].idx) ? "§a○" : "§8・"} §f${x.cond}: §d${e.ph.includes(SPECIES[x.sid].idx) ? SPECIES[x.sid].name : "？？？"}`),
        "", "§4§l地方の 主 §r§7（クリア後、地方を 歩いていると まれに 現れる Gサイズの ボス）", ...WREGIONS.map((R, i) => `${e.nushi[i] ? "§a○" : "§8・"} §f${R.name}: ${e.nushi[i] ? `§c${SPECIES[nushiSid(i)]?.name || ""}§7（${e.nushi[i]}回）` : "§8？？？"}`)].join("\n"));
    } else if (k === 3) {
      const L = []; for (const m of allMons(d)) for (const [id, v] of Object.entries(m.mk || {})) if (MOVES[id]) L.push([m.nm, MOVES[id].name, v]);
      L.sort((a, b) => b[2] - a[2]);
      await notice(p, "技の 極め", ["§f同じ 技を §e100回§f 使うと「極めた」技に なる（威力 +10%・消費MP -20%）", LINE, ...(L.length ? L.slice(0, 30).map(([n, mv, v]) => `${v >= MK_NEED ? "§6★" : "§7"}${n} §f${mv} §7${Math.min(v, MK_NEED)}/${MK_NEED}`) : ["§7まだ 記録が ない"])].join("\n"));
    } else return;
  }
}
async function facilityMenu(p, d) {
  for (;;) { if (!ok(p)) return null;   /* 第69版 */
    const e = eg(d), rg = ranchGain(e), ce = careEggs(e), end = endingDone(d), vOk = end && postOpen(d);
    const onV = typeof p.getDynamicProperty("mrpg:vret") === "string";
    const k0 = await choose(p, "施設", "§7牧場・研究所は いつでも 使える。", [
      B_(`§l牧場 §8${e.ranch ? e.ranch.mons.length : 0}/5体\n§7${rg ? `たまった 時間 ${rg.hrs.toFixed(1)}時間` : "あずけると 時間で 経験値・お金・タマゴ"}`, ICON("i_box")),
      B_(`§l研究所 §8${e.lab.pt}pt\n§7素材を 寄付して レシピを 開放`, ICON("i_equip")),
      B_(onV ? "§5§l虚空の島から 戻る" : `${vOk ? "§5§l" : "§8"}虚空の島\n§7${vOk ? "SSランクと 神が すむ 天の 島" : "三つの 試練（星冠王・王冠・終の遺跡）の あと"}`, ICON("i_walk")),
      B_("§7戻る", ICON("i_back"))]);
    const k = k0 >= 1 ? k0 + 1 : k0;   // v3.0: 育て屋は なくした（番号を ずらす）
    if (k === 0) await ranchMenu(p, d);
    else if (k === 2) await labMenu(p, d);
    else if (k === 3) {
      if (onV) { return () => backVoid(p); }
      if (!vOk) { await notice(p, "虚空の島", "§7星冠王・王冠の石板・終の遺跡を 越えると、島への 道が ひらく。"); continue; }
      if (!(await confirm(p, "虚空の島", "§5天の 果ての 島へ 行きますか？\n§7SSランクと、まれに 神（Xランク）が 出る（Lv90〜100・スカウトは むずかしい）。\n§7もどる ときは やりこみ → 施設 → 戻る", "行く", "やめる"))) continue;
      return () => toVoid(p);
    } else return null;
  }
}
async function ranchMenu(p, d) {
  for (;;) { if (!ok(p)) return null;   /* 第69版 */
    const e = eg(d); e.ranch = e.ranch || { mons: [], t: Date.now() };
    const R = e.ranch, g = ranchGain(e);
    const k = await choose(p, "牧場", [`§fあずけた 仲間 §e${R.mons.length}/5`, ...R.mons.map((m) => `§7・${m.nm} Lv${m.lv}`), g ? `§fいまの ぶん: §e${g.hrs.toFixed(1)}時間§f → 経験値・${gold(g.gold)}・タマゴの チャンス ${g.eggs}回` : "", "§7（最大 24時間ぶん たまる。うけとると リセット）"].join("\n"),
      [B_("§lうけとる", ICON("i_shop")), B_("預かり所から あずける", ICON("i_box")), B_("つれて かえる", ICON("i_party")), B_("§7戻る", ICON("i_back"))]);
    if (k === 0) {
      if (!g) { await notice(p, "牧場", "§7だれも いない。"); continue; }
      const log = []; R.mons.forEach((m, i) => { for (const ev of gainExp(m, g.exp[i], log)) { mark(d.own, ev.sp); mark(d.seen, ev.sp); } });
      d.gold += g.gold; const got = [gold(g.gold)];
      for (let i = 0; i < g.eggs; i++) if (Math.random() < 0.12) { const r = Math.random(); giveR(p, r < 0.1 ? "e_rainbow" : r < 0.6 ? "e_silver" : "e_bronze", 1, got); }
      R.t = Date.now(); save(p, d);
      await notice(p, "牧場", [`§a${got.join("・")}`, ...log.slice(0, 14)].join("\n"));
    } else if (k === 1) {
      if (R.mons.length >= 5) { await notice(p, "牧場", "§7もう いっぱい（5体）。"); continue; }
      if (!d.box.length) { await notice(p, "牧場", "§7預かり所に モンスターが いない。"); continue; }
      const j = await paged(p, "牧場に あずける", "§7預かり所から えらぶ", d.box.map((m) => B_(monLabel2(m), MON_ICON(m.sp))), 8);
      if (j < 0 || j >= d.box.length) continue;
      if (g && g.hrs > 0.05) { await notice(p, "牧場", "§7先に いまの ぶんを うけとってね。"); continue; }
      if (["musashi", "enma"].includes(d.box[j].sp)) { await notice(p, "牧場", "§cムサシは 牧場に あずけられません。"); continue; }   // v2.9.14
      const [m] = d.box.splice(j, 1); R.mons.push(m); R.t = Date.now(); award(p, d, "ranch"); save(p, d);
    } else if (k === 2) {
      if (!R.mons.length) { await notice(p, "牧場", "§7だれも いない。"); continue; }
      if (d.box.length >= BOX_MAX) { await notice(p, "牧場", "§c預かり所が いっぱい。"); continue; }
      const j = await choose(p, "つれて かえる", "§7（たまった ぶんは 先に うけとろう）", [...R.mons.map((m) => B_(monLabel2(m), MON_ICON(m.sp))), B_("§7戻る", ICON("i_back"))]);
      if (j < 0 || j >= R.mons.length) continue;
      const [m] = R.mons.splice(j, 1); d.box.push(m); save(p, d);
    } else return;
  }
}
async function careMenu(p, d) {
  for (;;) { if (!ok(p)) return null;   /* 第69版 */
    const e = eg(d), C = e.care || {}, n = careEggs(e);
    const k = await choose(p, "育て屋", [`§fあずけた 2体: §e${C.a ? C.a.nm : "-"} §f＆ §e${C.b ? C.b.nm : "-"}`, `§fタマゴ §e${n}/3 §7（${CARE_MIN}分に 1こ）`, "§7生まれる 子: 親の どちらかの 種族の Lv1。才能を 受けつぎやすく、親の 特性を 1つ 受けつぐ ことが ある。まれに かがやく 子・固有特性もちも。", "§7王系・神系は あずけられない。"].join("\n"),
      [B_(`§lタマゴを うけとる (${n})`, ICON("i_egg")), B_("2体 あずける", ICON("i_box")), B_("2体を つれて かえる", ICON("i_party")), B_("§7戻る", ICON("i_back"))]);
    if (k === 0) {
      if (!n) { await notice(p, "育て屋", "§7まだ タマゴは ない。"); continue; }
      if (d.box.length + n > BOX_MAX) { await notice(p, "育て屋", "§c預かり所が いっぱい。"); continue; }
      const out = []; for (let i = 0; i < n; i++) { const c = careChild(C.a, C.b); addMon(d, c); mark(d.own, c.sp); mark(d.seen, c.sp); out.push(`${c.shiny ? "§e★" : ""}${c.ht ? "§6◆" : ""}${c.nm}`); }
      e.rec.eggs = (e.rec.eggs || 0) + n; if (e.rec.eggs >= 10) award(p, d, "care10");
      C.t = Date.now(); save(p, d); sound(p, "random.levelup");
      await notice(p, "育て屋", `§aタマゴが かえった！\n§f${out.join("・")}`);
    } else if (k === 1) {
      if (C.a) { await notice(p, "育て屋", "§7もう あずかっている。"); continue; }
      const capC = rankCap(d);
      const list = d.box.filter((m) => !["king", "god"].includes(SPECIES[m.sp].fam) && !SPECIES[m.sp].hidden && !String(m.sp).startsWith("book_") && RANK_LBL.indexOf(SPECIES[m.sp].rank) <= capC);   // v2.9.12: 物語の 上限ランクまで・特別な 子は のぞく
      if (list.length < 2) { await notice(p, "育て屋", `§7預かり所に 2体 以上 必要（王系・神系・特別な 子 いがい、${RANK_LBL[capC]}ランクまで）。`); continue; }
      const a = await paged(p, "1体目", "§7預かり所から えらぶ", list.map((m) => B_(monLabel2(m), MON_ICON(m.sp))), 8); if (a < 0 || a >= list.length) continue;
      const l2 = list.filter((_, i) => i !== a);
      const b = await paged(p, "2体目", "§7預かり所から えらぶ", l2.map((m) => B_(monLabel2(m), MON_ICON(m.sp))), 8); if (b < 0 || b >= l2.length) continue;
      for (const m of [list[a], l2[b]]) d.box.splice(d.box.indexOf(m), 1);
      e.care = { a: list[a], b: l2[b], t: Date.now() }; save(p, d);
      await notice(p, "育て屋", "§aあずかりました。タマゴが できたら うけとりに 来てね。");
    } else if (k === 2) {
      if (!C.a) { await notice(p, "育て屋", "§7だれも あずけて いない。"); continue; }
      if (d.box.length + 2 > BOX_MAX) { await notice(p, "育て屋", "§c預かり所が いっぱい。"); continue; }
      d.box.push(C.a, C.b); e.care = null; save(p, d);
    } else return;
  }
}
async function labMenu(p, d) {
  for (;;) { if (!ok(p)) return null;   /* 第69版 */
    const e = eg(d), L = e.lab;
    const mats = matCount(p), mp = Object.entries(mats).reduce((s, [id, n]) => s + n * ((ITEMS[id].mtier ?? 0) + 1), 0);
    const opts = LAB.map((r) => B_(`${L.pt >= r.need ? "§l" : "§8"}${r.n}\n§7${L.pt >= r.need ? `作る: ${r.cost.toLocaleString()}G` : `研究 ${r.need}ptで 開放`}`, ICON("i_equip")));
    const k = await choose(p, "研究所", [`§f研究ポイント §e${L.pt}pt`, `§7持っている 素材を 寄付すると +${mp}pt（素材の 段階で 1〜3pt）`, `§fお金 ${gold(d.gold)}`].join("\n"), [B_(`§a素材を ぜんぶ 寄付する §8(+${mp}pt)`, ICON("i_bag")), ...opts, B_("§7戻る", ICON("i_back"))]);
    if (k === 0) { if (!mp) { await notice(p, "研究所", "§7素材を 持っていない。"); continue; } if (!(await confirm(p, "研究所", `§f持っている 素材（バッグの 中も）を ぜんぶ 寄付しますか？ §e+${mp}pt`, "寄付する", "やめる"))) continue; const n = donateAll(p, d); if (LAB.every((r) => e.lab.pt >= r.need)) award(p, d, "lab"); save(p, d); await notice(p, "研究所", `§a研究が すすんだ！ +${n}pt`); continue; }
    if (k > 0 && k <= LAB.length) {
      const r = LAB[k - 1];
      if (L.pt < r.need) { await notice(p, r.n, `§7研究ポイント ${r.need}ptで 開放（いま ${L.pt}pt）`); continue; }
      if (d.gold < r.cost) { await notice(p, r.n, "§cお金が たりない。"); continue; }
      if (!(await confirm(p, r.n, `§f${r.n}を 作りますか？ §e${r.cost.toLocaleString()}G`, "作る", "やめる"))) continue;
      d.gold -= r.cost; const id = r.give(); giveItem(p, `mrpg:${id}`); save(p, d); sound(p, "random.anvil_use");
      await notice(p, "研究所", `§a${ITEMS[id]?.name || r.n}を 作った！`);
      continue;
    }
    return;
  }
}
async function titleMenu(p, d) {
  for (;;) { if (!ok(p)) return null;   /* 第69版 */
    const e = eg(d);
    const k = await choose(p, "称号と 記録", `§f称号 §e${e.titles.length}§7/${Object.keys(TITLES).length}  §fいま: §6${e.title ? TITLES[e.title]?.[0] : "なし"}`, [B_("§l称号を つける", ICON("i_zukan")), B_("称号の 一覧", ICON("i_help")), B_("§l記録帳", ICON("i_help")), B_("ランキング", ICON("i_zukan")), B_("§7戻る", ICON("i_back"))]);
    if (k === 0) {
      const L = e.titles.filter((t) => TITLES[t]);
      const j = await paged(p, "称号を つける", "§7名前の 上に 出る", [B_("§7称号を はずす", ICON("i_close")), ...L.map((t) => B_(`§6${TITLES[t][0]}\n§8${TITLES[t][1]}`, ICON("i_zukan")))], 8);
      if (j < 0) continue; e.title = j === 0 ? null : L[j - 1]; save(p, d); applyTitle(p, d);
    } else if (k === 1) await notice(p, "称号の 一覧", Object.entries(TITLES).map(([id, [n, how]]) => `${e.titles.includes(id) ? "§6○ " + n : "§8・ ？？？"} §7― ${how}`).join("\n"));
    else if (k === 2) await notice(p, "記録帳", recText(d));
    else if (k === 3) await notice(p, "ランキング", [boardText("tower", "無限の塔（最高階）", (v) => `${v}階`), "", boardText("rush", "ボスラッシュ（最速）", (v) => `${Math.round(v / 60)}分`, true), "", boardText("rate", "ランクマッチ（レート）", (v) => v)].join("\n"));
    else return;
  }
}
// 散歩の 記録（menu.js から）
export function noteWalk(d, m) { if (m && SPECIES[m.sp]) addIdx(eg(d).walk, m.sp); }

export const HELP_TEXT = () => ["§l§dやりこみの しくみ", LINE,
  "§c§l挑戦（エンディング後）", "§f・無限の塔: 1階ずつ のぼる。回復なし。10階ごとに 番人。はじめて 越えた 番人の 階で 豪華な ほうび。最高記録は ランキングに。番人を 越えた 階から 再開できる",
  "§f・ボスラッシュの石板: 物語の 石板の 主15体＋星冠王の 16連戦（1戦ごとに 3割 回復）。時間も 記録", "§f・縛りの石板: ランダムな 縛り2つ（Bランク以下・1体だけ・魔法系の 攻撃技 禁止・Lv50・道具 禁止・S/Mサイズだけ）で 3連戦",
  "§f・今日の挑戦状: 毎日 かわる 相手（みんな 同じ）に 1日1回。連続日数で ほうびアップ・7日ごとに 限界突破の石", "§f・週替わりの強敵: 毎週 かわる 系統・属性の 強敵。何度でも。1・3・5・10回目に ほうび（5回目は その 系統の 伝説の 装備）",
  "§7挑戦は パーティの コピーで 戦う（本物の HPは 減らない・経験値も 入らない）。空の 闘技場で 戦う",
  "", "§9§l対戦", "§f・ランクマッチ: ゴーストか AIと 戦って レートを 上げる。毎月 シーズンが かわり、最高レートで ほうびと 称号", "§f・大会: 8人 トーナメント（ゴースト＋AI）。ルール: 自由・Lv50統一・同じ種族なし・SS/X禁止・スタンダード。優勝は 全員に お知らせ",
  "§f・ゴースト: いまの パーティを 登録すると、ほかの 人が AIの あなたと 戦える", "§f・ルール対戦: マルチの「対戦」でも ルールを えらべる",
  "", "§6§l集める", "§f・期間限定の 色違い: 毎週 1つの 系統が かがやきやすい（1/50）", "§f・完全個体「極」: 才能が すべて 最大＋固有特性＋特性が すべて 相性◎", "§f・技の 極め: 同じ 技を 100回 使うと 威力 +10%・消費MP -20%",
  "§f・図鑑の 達成報酬: 100種ごと・系統の 完成（伝説の 装備）・ランクの 完成・かがやき図鑑・固有特性図鑑・散歩・ライド・極", "§f・幻の モンスター: 満月の夜・雷雨・雨・夜明けに だけ まれに 現れる", "§f・地方の 主: クリア後、地方を 歩いていると まれに 現れる 巨大な ボス。倒すと 称号と 伝説の 装備",
  "§f・宝の地図: 使うと しるしが うかぶ。着くと 番人。倒すと 宝箱", "§f・伝説の 装備: 系統ごとの 刃・鎧・紋章。その 系統なら だれでも 装備できる。2つで 威力+10%・3つで 威力+20%・被ダメ-12%・会心+5%",
  "", "§2§l施設", "§f・牧場: 5体まで。時間で 経験値・お金・タマゴ（24時間ぶんまで）", "§f・研究所: 素材を 寄付して レシピ（宝の地図・継承の秘石・秘果・限界突破の石・転生の秘薬・特性の秘薬）",
  "§f・天の 島: 三つの 試練の あと。SSランクと まれに 神が 出る",
  "", "§e§l道具", "§f・継承の秘石: 配合の とき、親の 特性を 1つ 子に 受けつがせる", "§f・限界突破の石: Lv100の 仲間の 能力 +4%（5段まで）",
  "", "§l称号と 記録", "§f・称号は 名前の 上に 出る。記録帳には 最大ダメージ・連勝・塔・ラッシュ など"].join("\n");
