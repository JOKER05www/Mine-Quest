// 第113版: コンテスト（かっこよさ・かわいさ・つよさ・かしこさ）。mrpg:role = "contest" の 係に 話しかけると 開く
// 点 = 能力・レベル・特性・なつき度 × アピール 3回。ライバル 3人は 物語の 進みで 強くなる。1日 3回まで
import { system } from "@minecraft/server";
import { ITEMS, SPECIES, ORDER, EGGS, RANKS } from "./data.js";
import { load, save, allMons } from "./store.js";
import { busy, choose, notice, confirm, paged, ICON, MON_ICON, gold, giveItem, sound, particle, ok, seedId, monLabel } from "./ui.js";
import { calcStats, makeMonster, sizeOf } from "./core.js";
import { exOf, dayNo } from "./explore.js";
import { NPC_HOOKS } from "./npchook.js";
import { rankCap, storyLootOk, slabTierOk, progress, RANK_LBL } from "./quest.js";
import { isRole } from "./toys.js";

const B = (t, i) => [t, i];
const rnd = (n) => Math.floor(Math.random() * n);
export const CN = ["かっこよさ", "かわいさ", "つよさ", "かしこさ"];
export const RN = ["見習い", "一人前", "名人", "伝説"];   /* 第113版: 段の 名前 */
const CCOL = ["§c", "§d", "§6", "§b"];
export const DAILY = 3;
const CAT_FAM = [["dragon", "sword", "king", "nether"], ["blob", "animal", "aqua"], ["golem", "beast", "dragon"], ["god", "nether", "aqua", "king"]];
const APPEAL = [["きりっと ポーズ", "すばやい みのこなし", "力づよい おたけび"], ["にっこり えがお", "くるっと 一回転", "ちょこんと おすわり"],
  ["大岩を もちあげる", "どっしり かまえる", "板わりを 見せる"], ["なぞなぞに こたえる", "地面に 絵を かく", "数を かぞえて みせる"]];
const MOOD = [["ポーズを 待って いる", "動きを 見たがって いる", "迫力を ほしがって いる"], ["笑顔を 見たがって いる", "かわいい 動きを 待って いる", "おとなしい しぐさに うっとり"],
  ["力くらべを 見たがって いる", "どっしりした 姿に 注目", "わざを 見たがって いる"], ["かしこい 答えを 待って いる", "ひらめきを 見たがって いる", "ていねいな ところを 見たい みたい"]];
const RLV = [10, 25, 45, 70], RLIM = [2, 4, 5, 7], RNK = [80, 250, 450, 700], GOLD = [200, 800, 3000, 10000];
const PRIZE = [["e_white", "c_fruit", "SEED"], ["e_bronze", "EGGC", "sl0", "SEED"], ["e_silver", "sl1", "SEED", "s_all"], ["e_rainbow", "sl2", "SEED2", "s_all2"]];
const RIVAL = ["ソウタ", "レン", "ユイ", "タクミ", "サキ", "リク", "コハル", "ゲンタ", "アヤネ", "トモヤ", "マドカ", "ケイスケ"];
const SZ_CUTE = { S: 1.3, M: 1.0, L: 0.85, G: 0.75 };

// ---------- きろく（プレイヤーごと）----------
const CK = "mrpg:contest";
export function cst(p) {
  let s = null; try { const v = p.getDynamicProperty(CK); if (typeof v === "string") s = JSON.parse(v); } catch {}
  s = s && typeof s === "object" ? s : {}; if (!Array.isArray(s.u) || s.u.length !== 4) s.u = [0, 0, 0, 0]; s.w = s.w || 0;
  if (s.d !== dayNo()) { s.d = dayNo(); s.n = 0; }
  return s;
}
const cSave = (p, s) => { try { p.setDynamicProperty(CK, JSON.stringify(s)); } catch {} };
const nkOf = (p, m) => { try { return exOf(p).nk?.[m.id] || 0; } catch { return 0; } };
const rbOf = (m) => (Array.isArray(m.rb) && m.rb.length === 4 ? m.rb : [0, 0, 0, 0]);

// ---------- 点数 ----------
export function baseScore(m, ci, nk) {
  const st = calcStats(m), sp = SPECIES[m.sp] || {};
  let v = [st.atk + st.wpn + st.brt * 0.5 + st.spd * 0.5, (st.mdf + st.spd + st.hp * 0.25) * (SZ_CUTE[sizeOf(m)] || 1), st.hp * 0.4 + st.def + st.atk * 0.5, st.mat + st.mdf * 0.6 + st.mp * 0.6][ci];
  if (CAT_FAM[ci].includes(sp.fam)) v *= 1.15;
  v *= 1 + Math.min(6, (sp.traits || []).length + (m.rtr || []).length) * 0.02;
  if (m.shiny && ci < 2) v *= 1.08;
  if (m.ht) v *= 1.05;
  v *= 1 + Math.min(50, m.plus || 0) * 0.004;
  v *= 1 + Math.min(1000, nk || 0) / 1000 * 0.3;
  return Math.max(1, v);
}
const POOL = new Map();
function poolFor(lim) {
  if (!POOL.has(lim)) POOL.set(lim, ORDER.filter((k) => { const s = SPECIES[k]; return s && !s.hidden && !s.special && !s.special4 && !s.metalmon && !s.giant && s.fam !== "god" && RANKS.indexOf(s.rank) <= lim; }));
  return POOL.get(lim);
}
export function makeRivals(d, ci, r) {
  const g = Math.max(progress(d), (rankCap(d) - 2) / 6), lim = Math.min(rankCap(d), RLIM[r]), L = poolFor(lim), fav = L.filter((k) => CAT_FAM[ci].includes(SPECIES[k].fam));
  const names = RIVAL.slice().sort(() => Math.random() - 0.5);
  const out = [];
  for (let i = 0; i < 3; i++) {
    const src = fav.length && Math.random() < 0.5 ? fav : L; const sp = src[rnd(src.length)] || ORDER[0];
    const lv = Math.max(1, Math.min(100, Math.round(RLV[r] * (0.8 + 0.4 * g) * (0.9 + Math.random() * 0.2))));
    const m = makeMonster(sp, lv, true);
    let ap = 0; for (let k = 0; k < 3; k++) ap += (Math.random() < 0.45 ? 1.25 : 1) * (0.92 + Math.random() * 0.16);
    out.push({ who: names[i], nm: m.nm, lv, sc: Math.round(baseScore(m, ci, RNK[r] * (0.6 + Math.random() * 0.6)) * ap / 3) });
  }
  return out;
}
export function prizeOf(d, r) {
  const c = rankCap(d);
  const okId = (id) => { const it = ITEMS[id]; if (!it || !storyLootOk(it, EGGS[id]?.ranks, c)) return false; if (it.kind === "slab") return slabTierOk(d, it.slab) && RANK_LBL.indexOf(it.srank) <= c + 1; return true; };
  for (let k = r; k >= 0; k--) {
    const L = PRIZE[k].map((x) => (x === "SEED" ? seedId(1) : x === "SEED2" ? seedId(2) : x === "EGGC" ? ["e_red", "e_blue", "e_black", "e_green"][rnd(4)] : x)).filter(okId);
    if (L.length) return L[rnd(L.length)];
  }
  return "c_fruit";
}

// ---------- 会場 ----------
const RULES = ["§e§lコンテストの きまり", "§f・部門は かっこよさ・かわいさ・つよさ・かしこさ", "§f・手持ちの 仲間 1体で 出る。能力・レベル・特性・なつき度で 点が きまる",
  "§f・アピールは 3回。観客の ようすを 見て えらぼう（同じ アピールを つづけると あきられる）", "§f・優勝すると リボンと ごほうび。見習い→一人前→名人→伝説の 順に 出られる",
  `§7・エントリーは 1日 ${DAILY}回まで`].join("\n");
export async function contestHall(p) {
  if (busy.has(p.id)) return;
  busy.add(p.id);
  try {
    for (;;) {
      const d = load(p); if (!d) { await notice(p, "コンテスト会場", "§7まず ガイドブックで 最初の 仲間を えらぼう。"); return; }
      const S = cst(p);
      const c = await choose(p, "コンテスト会場", `§f受付「ようこそ！ 仲間の みりょくを みんなに 見せて あげて！」\n§7きょうの エントリー: ${S.n}/${DAILY}\n${CN.map((n, i) => `${CCOL[i]}${n}§7: ${S.u[i] >= 4 ? "マスター 優勝ずみ" : `${RN[S.u[i]]}ランクに 挑戦中`}`).join("\n")}`,
        [B("§lエントリー する", ICON("i_star")), B("リボンを 見る", ICON("i_party")), B("コンテストの きまり", ICON("i_book")), B("§7やめる", ICON("i_back"))]);
      if (c === 0) await entry(p); else if (c === 1) await ribbons(p); else if (c === 2) await notice(p, "コンテスト", RULES); else return;
      if (!ok(p)) return;
    }
  } catch (err) { console.warn(`[MonsterRPG] contest: ${err}`); } finally { busy.delete(p.id); }
}
async function ribbons(p) {
  const d = load(p); if (!d) return;
  const L = allMons(d).filter((m) => rbOf(m).some((x) => x > 0));
  const body = L.length ? L.map((m) => `§f${m.nm} §8Lv${m.lv}\n  ${rbOf(m).map((x, i) => (x ? `${CCOL[i]}${RN[x - 1]}${CN[i]}` : "")).filter(Boolean).join(" ")}`).join("\n") : "§7まだ リボンを もって いる 仲間は いない。";
  await notice(p, "リボン", `${body}\n\n§7優勝の 数: ${cst(p).w}`);
}
async function entry(p) {
  const S = cst(p);
  if (S.n >= DAILY) { await notice(p, "コンテスト", "§7きょうの エントリーは おしまい。また あした 来てね！"); return; }
  const ci = await choose(p, "部門を えらぶ", "§fどの 部門に 出る？", [...CN.map((n, i) => B(`${CCOL[i]}§l${n}§r\n§8${RN[Math.min(3, S.u[i])]}ランクまで`, ICON("i_star"))), B("§7やめる", ICON("i_back"))]);
  if (ci < 0 || ci >= 4) return;
  const top = Math.min(3, S.u[ci]);
  let r = top;
  if (top > 0) { const k = await choose(p, CN[ci], "§fどの ランクに 出る？", [...RN.slice(0, top + 1).map((n, i) => B(`${n}ランク${i === top && S.u[ci] < 4 ? " §6（挑戦）" : ""}`, ICON("i_fight"))), B("§7やめる", ICON("i_back"))]); if (k < 0 || k > top) return; r = k; }
  const d = load(p); if (!d) return;
  const L = [...d.party, ...(d.bench || [])].filter(Boolean);
  if (!L.length) return;
  const k = await paged(p, "出場する 仲間", `§f${CCOL[ci]}${CN[ci]}§f ${RN[r]}ランク §7に だれが 出る？`, L.map((m) => B(`${monLabel(m)}`, MON_ICON(m.sp))), 8);
  if (k < 0 || !L[k]) return;
  const mid = L[k].id;
  if (!(await confirm(p, "エントリー", `§f${L[k].nm}§7（Lv${L[k].lv}）§fで ${CCOL[ci]}${CN[ci]}§f ${RN[r]}ランクに 出ますか？\n§7きょうの のこり: ${DAILY - cst(p).n}回`, "出る", "やめる"))) return;
  const S2 = cst(p); if (S2.n >= DAILY) return;
  S2.n++; cSave(p, S2);   /* 先に 回数を へらす（とちゅうで ぬけても やりなおして かせげない）*/
  const d0 = load(p), m0 = d0 && allMons(d0).find((x) => x.id === mid); if (!m0) return;
  const base = baseScore(m0, ci, nkOf(p, m0)), riv = makeRivals(d0, ci, r);
  sound(p, "random.levelup", 1.2);
  let sum = 0, prev = -1; const log = [];
  for (let n = 0; n < 3; n++) {
    const want = rnd(3), hint = Math.random() < 0.7 ? want : rnd(3);
    const a = await choose(p, `${RN[r]} ${CN[ci]}  ${n + 1}/3`, `${log.join("\n")}${log.length ? "\n" : ""}§7観客の ようす: §f${MOOD[ci][hint]}\n§f${m0.nm}の アピールは？`, APPEAL[ci].map((t) => B(t, ICON("i_star"))));
    if (a < 0 || a > 2 || !ok(p)) { if (ok(p)) await notice(p, "コンテスト", "§7アピールを やめて 会場を 出た……（エントリーは 1回 つかった）"); return; }
    const mul = (a === want ? 1.25 : 1) * (a === prev ? 0.85 : 1) * (0.92 + Math.random() * 0.16);
    sum += mul; prev = a;
    log.push(`§8${n + 1}. ${APPEAL[ci][a]} → ${a === want ? "§a大かっさい！" : mul < 0.95 ? "§7観客は ちょっと あきた みたい" : "§fはくしゅ"}`);
    sound(p, a === want ? "random.orb" : "random.pop", a === want ? 1.4 : 1);
  }
  if (!ok(p)) return;
  /* ここから 先は 待たずに 結果と ごほうびを 書く（二重に もらえない）*/
  const my = Math.round((base * sum) / 3);
  const all = [{ who: "あなた", nm: m0.nm, sc: my, me: true }, ...riv].sort((x, y) => y.sc - x.sc), place = all.findIndex((x) => x.me);
  const d1 = load(p); if (!d1) return;
  const m1 = allMons(d1).find((x) => x.id === mid), S3 = cst(p), got = [];
  if (place === 0) {
    if (m1) { const rb = rbOf(m1).slice(); rb[ci] = Math.max(rb[ci], r + 1); m1.rb = rb; got.push(`§6${RN[r]}${CN[ci]}リボン§f（${m1.nm}）`); }
    S3.u[ci] = Math.max(S3.u[ci], r + 1); S3.w = (S3.w || 0) + 1;
    const pid = prizeOf(d1, r); giveItem(p, `mrpg:${pid}`, 1); got.push(`§b${ITEMS[pid]?.name || pid}`);
    d1.gold = Math.min(99999999, (d1.gold || 0) + GOLD[r]); got.push(gold(GOLD[r]));
  } else if (place === 1) { const g = Math.floor(GOLD[r] / 4); d1.gold = Math.min(99999999, (d1.gold || 0) + g); got.push(gold(g)); }
  save(p, d1); cSave(p, S3);
  if (place === 0) { particle(p, "minecraft:totem_particle", 1.5); sound(p, "random.levelup", 1); }
  const res = all.map((x, i) => `${i === 0 ? "§6" : "§f"}${i + 1}位 ${x.me ? "§a" : "§7"}${x.who}と ${x.nm} §f${x.sc}点`).join("\n");
  await notice(p, place === 0 ? "優勝！" : "結果", `${log.join("\n")}\n\n${res}\n\n${place === 0 ? `§e§l優勝！§r\n§fもらった もの: ${got.join("・")}${S3.u[ci] === r + 1 && r < 3 ? `\n§a${CN[ci]}の ${RN[r + 1]}ランクに 出られる ように なった！` : ""}` : place === 1 ? `§f2位！ §7賞金 ${got.join("")}` : "§7おしい！ アピールの えらび方や なつき度で 点が 上がるよ"}`);
}
NPC_HOOKS.unshift((p, e) => {
  if (!isRole(e, "contest")) return false;
  let sn = false; try { sn = !!p.isSneaking; } catch {} if (sn) return false;
  if (busy.has(p.id)) return true;
  system.run(() => contestHall(p));
  return true;
});
export const __contest = { entry, cst, baseScore, makeRivals, prizeOf };
