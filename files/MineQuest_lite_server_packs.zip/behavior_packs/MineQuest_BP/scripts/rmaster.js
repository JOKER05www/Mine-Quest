// v2.2.4: 地方マスター（各地方の 町に 1人ずつ いて、その 地方の 石板を 守っている）
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, BOSS_SLAB, FAMILIES, DEITY, ITEMS } from "./data.js";
import { load, save } from "./store.js";
import { busy, ok, notice, confirm, choose, ICON, EXH, sound, particle, gold, LINE, giveItem, setJob, seedId } from "./ui.js";
import { castleInfo, castleSpot, groundY } from "./structures.js";
import { WREGIONS } from "./worldmap.js";
import { fight } from "./story.js";
import { sealReady, storyNowHint } from "./saga.js";
import { calcStats, canFight } from "./core.js";
import { qs, RM_SLAB, giveSlab, bossLv, slabBossLv, bossPlus, rIdx, RI, endingDone } from "./quest.js";
import { PSKIN } from "./skinjobs.js";
/* 第106版: マスターと 王の 顔（スキン）・物語で 亡くなった 人の 跡つぎ */
const PJ = (k, d) => (PSKIN[k] ? PSKIN[k][0] : d);
const MSKIN = ["midori", "jin", "kagura", "gou", "nagisa", "yomi", "siden", "sora"];
export const KSKIN = ["arca13", "elze", "sebas", "bald", "rashid", "lux", "mare", "morte", "heim", "fav", null];
export const KNAME = ["アルカ十三世", "女王 エルゼ", "執事 セバス（王の 代理）", "鍛冶王 バルド", "砂王 ラシード", "美王 ルークス", "海王 マーレ", "冥王 モルテ", "双王 ヘイム＆ダル", "竜女王 ファーヴ", null];
/* 第106版: 城に 立たせる 見た目は、遊んで いる 人の うち いちばん 物語が 進んだ 人に 合わせる（何人でも ぱたぱた 変わらない） */
export function rmViewWorld(k) {
  /* 第106版: みんなが その 場面を 見た あとだけ 変える（まだの 人への ネタバレを 防ぐ） */
  let V0 = null;
  for (const q of world.getAllPlayers()) { let V; try { V = rmView(k, load(q)); } catch { continue; } if (V.name === REGIONS[k].name) return rmView(k, null); V0 = V0 || V; }
  return V0 || rmView(k, null);
}
export function rmView(k, d) {
  const R = REGIONS[k], s = d ? qs(d) : {};
  if (k === 4 && s.nagiDead) return { ...R, name: "マリン", title: "潮風の 地方マスター", job: PJ("marin", 8),
    pre: ["姉さんの 腕は、もう 治らない。潮の 時刻は、今は 姉さんが 港で 口で 教えて くれてる。……わたしは まだ 半分しか 覚えて ない。", "でも、この 石板は わたしが 守る。陸でも ちゃんと 話すって 決めたから。……勝負、して。"],
    win: "……姉さん、見てた？ 潮目、変わったよ。" };   /* 第113版: ナギサは 生きて いる（もう 潜れない） */
  if (k === 5 && s.yomiStone) return { ...R, name: "ヨミの 石像", title: "宵闇の 地方マスター", job: PJ("yomi_stone", 8), statue: true };
  return { ...R, job: PJ(MSKIN[k], 8) };
}

export const REGIONS = [
  { name: "ミドリ", title: "若葉の 地方マスター", fams: ["animal", "beast", "animal"], theme: "forest",
    pre: ["あなたが 長老の 言っていた 子ね。わたしは ミドリ。この アルカトラス城で、石板を 預かって 十年に なる。", "子どもの ころ、城の 庭で 石板に 触った ことが あるの。一緒に いた 子犬の モンスターが、中に 呑まれて 戻らなかった。……あの子は 最後まで、わたしの 名前を 呼んでた。", "石板は さびしい 子の 声で 呼ぶの。返事を しては だめ。……私の 仲間に 勝てたら、この 一枚を あずけるわ。"],
    win: "迷いが ない。……託すわ。石板が 呼んでも、返事を するのは 仲間の 声に だけ。" },
  { name: "ジン", title: "鋼刃の 地方マスター", fams: ["sword", "beast", "golem"], theme: "shrine",
    pre: ["……ジンだ。この 廃都が まだ 都だった ころ、門を 守って いた。", "石に なった 朝、俺は 壁の 外で 剣を 振って いた。戻ると、妻も 弟子も 皆 石だった。……その 夜、壁画の 影が 一つ、自分で 自分を 削って 消えるのを 見た。", "誰も 信じなかった。だから 俺は この 城で 石板を 守る。あの 影が 取りに 来る 日まで。……お前に 預けて いいか、刃で 確かめる。"],
    win: "守れなかった 者の 剣は、二度と 鞘に 戻らん。……お前は 鞘を 持って いけ。この 一枚と 一緒に。" },
  { name: "カグラ", title: "炎舞の 地方マスター", fams: ["nether", "dragon", "beast"], theme: "volcano",
    pre: ["私は カグラ。火口の 社で、毎晩 封じの 舞を 舞って いる。", "母も 舞い手だった。石板の ささやきを 燃やす ために 舞い 続けて、最後は 足が 炭に なった。……それでも 母は、笑って 舞って いたわ。", "迷いは 燃やせる。でも、思い出は 燃やしちゃ だめ。……あなたは ささやきを どう 黙らせる？ 見せて ちょうだい。"],
    win: "燃やすんじゃ なく、聞いた うえで 選ぶ……そういう 戦い方も あるのね。母にも 見せたかった。持っていきなさい。" },
  { name: "ゴウ", title: "岩鉄の 地方マスター", fams: ["golem", "animal", "beast"], theme: "mountain",
    pre: ["ゴウだ。昔は 水晶の 洞くつで 石を 掘って いた。", "若い ころ、石板の かけらを 拾って 売った。いい 金に なった。……次の 朝、相棒の 岩の 子が、本当の 岩に なって いた。", "だから 俺は 動かん。山のように、この 城で 石板を 抱えて いる。……お前は 力が 欲しいのか、守りたいのか。拳で 答えろ。"],
    win: "重いぞ。軽く 感じたら、それは もう 石板に 喰われてる。……忘れるな。" },
  { name: "ナギサ", title: "潮風の 地方マスター", fams: ["aqua", "animal", "blob"], theme: "beach", /* 第106版: マリンの 姉 */
    pre: ["……あ、干潮。ごめんなさい、潮の 時刻を 数えて いたの。", "海は 沈んだ ものを 返さない。石板も 同じ。半端な 覚悟の 人には 渡せないわ。……妹の マリンが お世話に なったのね。"],
    win: "……潮目が 変わったわ。持って いって。戻って きたら、中で 何を 見たか 聞かせてね。" },
  { name: "ヨミ", title: "宵闇の 地方マスター", fams: ["nether", "nether", "animal"], theme: "soulvalley",
    pre: ["わたしも あなたと 同じ。悪しき ものに 好かれる 体質。……だから 分かるの。石板の ささやきは やさしい ふりを する。", "呑まれた 友だちを、わたしは 何人も 見送った。あなたまで 見送りたくない。だから、ここで 試させて。"],
    win: "……大丈夫そうね。あなたの 仲間は、あなたを ちゃんと 引き戻せる。石板を、どうか。" },
  { name: "シデン", title: "雷光の 地方マスター", fams: ["animal", "golem", "dragon"], theme: "sky",
    pre: ["シデン。雪山の 救助隊の 隊長…… だった。", "雪崩の 日、俺は 一瞬 迷った。右か 左か。その 一瞬で、隊の 五人が 雪の 下だ。……あの 日から、石板の ささやきが『もっと 迷え』と 言う。", "迷ってる 間に、雪は 落ちる。……ついて これなきゃ、石板の 中でも 同じ ことに なるぜ。"],
    win: "……読まれてた、か。速さだけじゃ 足りねえ ってことだな。迷わず 行け。持ってけ。" },
  { name: "ソラ", title: "天穹の 地方マスター", fams: ["dragon", "animal", "nether"], theme: "endcity",
    pre: ["ソラ。この ラグナの 城で、竜骨の 祭壇を 見張って きた。……見張りきれなかったけどね。", "子どもの ころ、王冠の ささやきに 一度だけ 返事を した。その 夜、相棒の 竜の 翼が 石に なった。今も 城の 屋根で、動けない まま 空を 見上げて いる。", "呼ばれても、自分の 名前で 返事を して。……最後の 試験だよ。全力で 来て。"],
    win: "ありがとう。……王は きっと、あなたを 器に しようと する。でも あなたは もう、自分の 名前で 呼ばれる マスターだ。" },
];
export const famName = (f) => (FAMILIES.find((x) => x.id === f)?.name || f);
export const masterType = (k) => `${famName(REGIONS[k].fams[0])}の 使い手`;   // v2.9.13: 得意な 系統
export const masterRegion = (k) => WREGIONS.findIndex((R) => R.rm === k);
export const regionTown = (k) => { const i = masterRegion(k); return i >= 0 ? { name: WREGIONS[i].castle.name, reg: i } : null; };
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
const pick = (a) => a[Math.floor(Math.random() * a.length)];

// 地方マスターの チーム（石板の 主と 同じくらい・少し 上）
export function rmTeam(d, k, wins = 0) {
  const R = REGIONS[k], si = RM_SLAB[k], b = BOSS_SLAB[si];
  const lv = Math.min(100, bossLv(d, si) + 2 + wins * 3), plus = Math.min(99, bossPlus(d, b.sid, si) + wins * 4);
  const r0 = Math.max(0, Math.min(6, rIdx(b.sid)));
  const team = []; let used = 0;
  for (let n = 0; n < 4 && used < 4; n++) {
    const rr = Math.max(0, r0 - (n === 0 ? 0 : n === 1 ? 0 : 1));
    const want = n < 3 ? [R.fams[0]] : R.fams;
    const roomOk = (S) => n > 0 || (SLOT[S.sz] || 2) <= 2;   // v2.9.13: 1体目は M まで（のこりの 枠が うまる ように）   // v2.9.13: 得意な 系統（はじめの 3体は 得意な 系統から）
    let c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && want.includes(S.fam) && roomOk(S) && used + (SLOT[S.sz] || 2) <= 4 && !team.some((t) => t.sid === s); });
    if (!c.length) c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && R.fams.includes(S.fam) && used + (SLOT[S.sz] || 2) <= 4 && !team.some((t) => t.sid === s); });
    if (!c.length) c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && !["king", "god"].includes(S.fam) && used + (SLOT[S.sz] || 2) <= 4; });
    if (!c.length) break;
    if (n > 0) { let cs = c.filter((x) => SPECIES[x].sz === "S"); if (!cs.length && rr > 0) cs = ORDER.filter((x) => { const S = SPECIES[x]; return !S.hidden && !S.metalmon && S.sz === "S" && S.rank === RI[rr - 1] && !["king", "god"].includes(S.fam) && used + 1 <= 4 && !team.some((t) => t.sid === x); }); if (cs.length) c = cs; }   /* S が いなければ 1つ 下の ランクの S */   /* 第103版: 2体目 からは 小さい 子を 優先（2体だけ だと 手数で いつも 負けて いた）*/
    const s = pick(c); used += SLOT[SPECIES[s].sz] || 2;
    team.push({ sid: s, lv: Math.min(100, lv + (n === 0 ? 2 : 0)), q: Math.min(1, 0.6 + k * 0.05), plus: n === 0 ? plus + 5 : plus });
  }
  return team;
}

export async function rmTalk(p, k) {
  const d = load(p); if (!d) return null;
  const R = rmView(k, d), s = qs(d), si = RM_SLAB[k], b = BOSS_SLAB[si];
  const won = s.rm.includes(k), wins = (s.rmw && s.rmw[k]) || 0;
  if (R.statue) { await notice(p, R.name, "§7§l宵闇の 地方マスター ヨミ§r §8（石像）\n\n§7足もとから 石に なった ヨミが、何かを 伝えようと 口を 開いた まま 立って いる。\n§8石の 指先は、冥王の 城の 奥を 指して いた。\n\n§7「……き、こ……」"); return null; }
  if (!canFight(d)) { await notice(p, R.title, "§c戦える 仲間が いない！"); return null; }
  if (!won && !sealReady(d, si)) { await notice(p, `${R.title} ${R.name}`, `§6§l${R.title} ${R.name}§r\n\n§f「……あなたには まだ やるべき ことが あるようね。それを 果たしてから また いらっしゃい。」\n\n§7いまの 目標: §f${String(storyNowHint(d)).replace(/§./g, "")}`); return null; }   // v2.9.13: 物語の 順番を 守る
  for (const l of won ? ["また 来たのね。腕が なまって いないか 見てあげる。"] : R.pre) await notice(p, `${R.title} ${R.name}`, `§6§l${R.title} ${R.name}§r §7（${masterType(k)}）\n\n§f「${l}」`);
  const team = rmTeam(d, k, won ? wins : 0);
  if (won && EXH.omiaiM) {   /* 第104版: 勝った マスターとは お見合い配合も できる */
    const c = await choose(p, `${R.title} ${R.name}`, "§f「なにか 用かしら？」", [["§c§l勝負する", ICON("i_fight")], ["§d§lお見合い配合\n§8マスターの 仲間と 配合（1日 3回）", ICON("i_party")], ["§7やめる", ICON("i_back")]]);
    if (c === 1) { busy.add(p.id); try { await EXH.omiaiM(p, d, R.name, rmTeam(d, k, 0)); save(p, d); } finally { busy.delete(p.id); } return null; }
    if (c !== 0) return null;
  }
  if (!(await confirm(p, `${R.name}に 挑む`, [`§6§l${R.title} ${R.name}`, LINE, `§7石板の 守り手・§e${masterType(k)}§7（${R.fams.slice(1).map(famName).join("・")}も 使う）`, won ? "§7（再戦・勝つほど 強くなる。ごほうびは お金と 経験）" : `§d認められると「${b.name}」を 託される§7（中の 主 ${b.title}・Lv${slabBossLv(si)}）`, `§f相手: ${team.map((t) => `${SPECIES[t.sid].name}(${SPECIES[t.sid].rank})`).join("・")}  §7Lv${team[0].lv}前後`, "§7戦いの 前に 回復。スカウトは できない・負けても お金は へらない"].join("\n"), "挑む！", "やめる"))) return null;
  return async () => {
    let d2 = load(p); if (!d2) return;
    for (const m of [...d2.party, ...(d2.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d2);
    sound(p, "raid.horn", 1.1);
    let res = await fight(p, { team }, { tier: 2, name: `${R.title} ${R.name}`, fam: "", npc: null, arena: `${R.title}戦`, theme: R.theme, rmaster: true });
    // v2.9.13: 負けたら その場で もう一度
    for (let k2 = 0; k2 < 5 && res === "lose" && ok(p); k2++) {
      busy.add(p.id);
      let again = false; try { again = await confirm(p, "負けて しまった……", `§6§l${R.name}§r§f「${won ? "まだまだ ね。" : "……まだ 渡せない。"}」\n\n§fもう一度 挑みますか？ §7（仲間は 全回復する）`, "もう一度 挑む", "やめる"); } catch {}
      if (!again) break;
      const d3 = load(p); if (!d3) break;
      for (const m of [...d3.party, ...(d3.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d3);
      busy.delete(p.id);
      res = await fight(p, { team }, { tier: 2, name: `${R.title} ${R.name}`, fam: "", npc: null, arena: `${R.title}戦`, theme: R.theme, rmaster: true });
    }
    busy.delete(p.id);
    d2 = load(p); if (!d2) return;
    for (const m of [...d2.party, ...(d2.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
    const s2 = qs(d2);
    if (res !== "win") { save(p, d2); await notice(p, R.title, `§6§l${R.name}§r§f「${won ? "まだまだ ね。" : "……まだ 渡せない。仲間と 話して、また おいで。"}」\n§7仲間は 回復した。`); return; }
    const got = [];
    if (!s2.rmw) s2.rmw = {};
    s2.rmw[k] = (s2.rmw[k] || 0) + 1;
    const g = won ? Math.floor((1000 + k * 1500) / Math.min(4, s2.rmw[k])) : 5000 + k * 8000; d2.gold += g;   /* v3.0 第63版: 再戦の ほうびは 少なく・勝つほど へる */ got.push(gold(g));
    if (!s2.rm.includes(k)) s2.rm.push(k);
    const bs = giveSlab(p, d2, si); if (bs) got.push(`§d§l${bs.name}§r §7（道具から 触れると 石板の 中へ）`);
    if (won && s2.ending && k >= 4 && s2.rmw[k] % 3 === 0) { giveItem(p, "mrpg:sx_king", 1); got.push("§6覇王の石板"); }   // v2.9.6: 強い マスター（★5〜）に 3回 勝つごと
    save(p, d2);
    sound(p, "ui.toast.challenge_complete", 1); particle(p, "minecraft:totem_particle", 1.4);
    if (!won) for (const q of world.getAllPlayers()) q.sendMessage(`§6＊ ${p.name}が ${R.title} ${R.name}に 認められた！`);
    await notice(p, `${R.name}に 勝利！`, [`§6§l${R.name}§r§f「${won ? "腕を あげたね。" : R.win}」`, "", ...got.map((x) => "§e" + x)].join("\n"));
  };
}

// 城に 地方マスターを 立たせる（城が できて いて、近くに プレイヤーが いる とき）
system.runInterval(() => {
  const ow = world.getDimension("minecraft:overworld");
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld" || busy.has(p.id)) continue;
    for (let k = 0; k < REGIONS.length; k++) {
      const ri_ = masterRegion(k); if (ri_ < 0) continue;
      const info = castleInfo(ri_); if (!info || !info.built) continue;
      if (Math.hypot(p.location.x - info.x, p.location.z - info.z) > 70) continue;
      let have = [];
      try { have = ow.getEntities({ type: "mrpg:npc", tags: [`mrpg_rm${k}`] }); } catch {}
      have = have.filter((e) => ok(e)); for (const e of have.slice(1)) try { e.remove(); } catch {}
      const V = rmViewWorld(k);
      if (have.length) { const e0 = have[0]; try { if (e0.getProperty("mrpg:job") !== V.job) { setJob(e0, V.job); e0.nameTag = `§6【${V.title}】§f${V.name}`; } } catch {} continue; }
      const pos = info.m || { x: info.x + 5, y: info.y, z: info.z - 12 };
      try {
        const e = ow.spawnEntity("mrpg:npc", pos);
        setJob(e, V.job); e.addTag("mrpg_npc"); e.addTag(`mrpg_rm${k}`); e.setDynamicProperty("mrpg:rm", k);
        e.nameTag = `§6【${V.title}】§f${V.name}`;
        particle(e, "minecraft:totem_particle", 1);
      } catch {}
    }
    // 第68版: 城の 王が いなく なって いたら もどす（近くに いる ときだけ）
    for (let i = 0; i < WREGIONS.length; i++) {
      const info = castleInfo(i); if (!info || !info.built) continue;
      if (Math.hypot(p.location.x - info.x, p.location.z - info.z) > 40) continue;
      let have = []; try { have = ow.getEntities({ type: "mrpg:npc", tags: [`mrpg_castle${i}`] }); } catch {}
      const kg = have.filter((e) => { try { return ok(e) && e.getDynamicProperty("mrpg:king") === i; } catch { return false; } }); for (const e of kg.slice(1)) try { e.remove(); } catch {}
      if (kg.length) continue;
      try {
        const e = ow.spawnEntity("mrpg:npc", info.k || { x: info.x + 0.5, y: info.y, z: info.z - 12.5 });
        setJob(e, KSKIN[i] ? PJ(KSKIN[i], 15) : 15); e.addTag("mrpg_npc"); e.addTag(`mrpg_castle${i}`); e.setDynamicProperty("mrpg:king", i);
        e.nameTag = KNAME[i] ? `§6${KNAME[i]}` : `§6${WREGIONS[i].castle.name}の 王`;
      } catch {}
    }
  }
}, 100);

// 城の 王（地方の 話・見どころ）
export async function kingTalk(p, i) {
  const R = WREGIONS[i]; if (!R) return;
  const d = load(p);
  const k = R.rm, M = k >= 0 ? rmView(k, d) : null;
  const L = [`${R.col}§l${KNAME[i] || R.castle.name + "の 王"}§r §7（${R.castle.name}）`, LINE, `§f「ようこそ、${R.name}へ。」`, `§7${R.desc}`, "", `§f強さの めやす: §eLv${R.lv[0]}〜${R.lv[1]}`, `§fよく 見かける モンスター: §e${Object.keys(R.fams).map((f) => ({ beast: "獣", animal: "動物", blob: "粘液", nether: "ネザー", sword: "武者", golem: "無機物", dragon: "竜", aqua: "海", king: "王", god: "神" })[f] || f).join("・")}系`];
  if (M && M.statue) L.push(`§f地方マスター: §6${M.title} §7（ヨミは 石に なった。城には 石像が 立って いる）`);
  else if (M) L.push(`§f地方マスター: §6${M.title} ${M.name}§7（この 城に いる。勝つと 石板を 託される）`);
  if (d && i === 0 && !(d.story && d.story.ordoDead)) L.push("", "§f「ルミナの 子よ。そなたの 体質の ことは オルドから 聞いておる。石板には 気を つけるのだぞ。」");
  if (R.id === "necro") L.push("", "§f「この 地の どこかに §6終の遺跡§f が 眠っている。遺跡を 八つ 越えた 者にしか 開かぬそうだ。」");
  if (R.id === "celes") L.push("", "§f「ここは 大陸で もっとも 空に 近い 郷。強者だけが 来られる 場所だ。」");
  if (!(d && endingDone(d))) { await notice(p, R.castle.name, L.join("\n")); return null; }
  // 第68版: クリア後は 王が 直々に 戦ってくれる（何度でも・勝つほど 強く）
  const s = qs(d); s.kgw = s.kgw || {}; const wins = s.kgw[i] || 0;
  L.push("", `§6§l「……世界を 救った 者よ。余と 手合わせ 願えるか。」`, `§7王の 本気の チーム（全員 SSランク・王系 入り）。勝った 回数: §e${wins}`, wins === 0 ? `§d初めて 勝つと ${ITEMS[DEITY[i]?.slab]?.name || "神の石板"}（神が 眠る 特別な 石板）を もらえる` : "§7何度でも 挑める（勝つほど 強くなる）");
  const c = await confirm(p, R.castle.name, L.join("\n"), "王に 挑む", "話を おえる");
  if (!c) return null;
  const team = kingTeam(i, wins);
  const rw = wins === 0 ? `§d初めて 勝つと: ${ITEMS[DEITY[i]?.slab]?.name || "神の石板"}・万能の秘果・闘魔覚醒の秘玉` : "§d勝つと: 万能の秘果か 神果・闘魔覚醒の秘玉 ＋ 豪華な ごほうび（王・にじいろの タマゴ・神果・まれに 神の タマゴ など）";
  if (!(await confirm(p, `${R.castle.name}の 王に 挑む`, [`${R.col}§l${R.castle.name}の 王`, LINE, ...team.map((t) => `§f・${SPECIES[t.sid].name} §8${SPECIES[t.sid].rank} ${t.sz || SPECIES[t.sid].sz}${SPECIES[t.sid].fam === "king" ? " §6(王系)" : ""}`), "", "§c全員 HP 1万5千 以上・能力 1200 以上（手持ちに 合わせて 強く、勝つほど さらに 強く）", rw, "", "§7仲間は 戦う 前に 全回復する"].join("\n"), "挑む", "やめる"))) return null;
  return async () => {
    let d2 = load(p); if (!d2) return;
    for (const m of [...d2.party, ...(d2.bench || [])]) { const cs = calcStats(m); m.hp = cs.hp; m.mp = cs.mp; } save(p, d2);
    sound(p, "raid.horn", 1.2);
    const res = await fight(p, { team }, { tier: 2, name: `${R.castle.name}の 王`, fam: "", npc: null, arena: `${R.castle.name}の 王座`, theme: "palace", kingK: { i, wins } });
    d2 = load(p); if (!d2 || !ok(p)) return;   /* 勝った 直後に ぬけた ときは ごほうびを 書かない（石板が 消えない ように） */
    for (const m of [...d2.party, ...(d2.bench || [])]) { const cs = calcStats(m); m.hp = cs.hp; m.mp = cs.mp; }
    if (res !== "win") { save(p, d2); await notice(p, R.castle.name, `${R.col}§l${R.castle.name}の 王§r§f「まだまだ。また 来るが よい。」\n§7仲間は 回復した。`); return; }
    const s2 = qs(d2); s2.kgw = s2.kgw || {}; s2.kgw[i] = (s2.kgw[i] || 0) + 1;
    const got = [], give = (id, n = 1) => { if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); } };
    if (s2.kgw[i] === 1) {
      const G = DEITY[i]; s2.dgs = s2.dgs || [];
      if (G && !s2.dgs.includes(i)) { s2.dgs.push(i); give(G.slab); got[got.length - 1] = `§d§l${ITEMS[G.slab].name}§r §7（神の石板。中の 神は ${G.name}）`; }
      give("s_all3"); give("i_awaken");
    } else {
      give(Math.random() < 0.3 ? "s_all4" : "s_all3"); give("i_awaken");
      const lux = [["e_king", 1], ["e_rainbow", 2], ["i_awaken", 1], [seedId(4), 1], [seedId(4), 1], ["f_exp100k", 1], ["i_tal9", 1], ["i_trpick", 1], ["i_plus10", 1], ["e_god", 1]];
      for (let k = 0; k < 3; k++) { const [id, n] = lux[Math.floor(Math.random() * (k === 2 && Math.random() < 0.15 ? lux.length : lux.length - 1))]; give(id, n); }
    }
    const g = 100000 + 20000 * Math.min(10, s2.kgw[i]); d2.gold += g; got.unshift(gold(g));
    save(p, d2);
    sound(p, "ui.toast.challenge_complete", 1); particle(p, "minecraft:totem_particle", 1.4);
    for (const q of world.getAllPlayers()) { try { const dq = q.id === p.id ? d2 : load(q); if (dq && dq.story && dq.story.ending) q.sendMessage(`§6＊ ${p.name}が ${R.castle.name}の 王に 勝った！（${s2.kgw[i]}回目）`); } catch {} }   /* 第69版 */
    await notice(p, `${R.castle.name}の 王に 勝利！`, [`${R.col}§l${R.castle.name}の 王§r§f「見事……！ 王の 名に かけて、褒美を 取らせよう。」`, "", ...got.map((x) => "§e" + x)].join("\n"));
  };
}
// 第68版: 王の チーム（4枠・全員 SS・王系を 1体 以上・大きさ いろいろ）
const SLOT2 = { S: 1, M: 2, L: 3, G: 4 };
export function kingTeam(i, wins = 0) {
  const ok2 = (s) => { const S = SPECIES[s]; return S && !S.hidden && !S.metalmon && S.rank === "SS" && S.fam !== "god"; };
  const kings = ORDER.filter((s) => ok2(s) && SPECIES[s].fam === "king");
  const others = ORDER.filter((s) => ok2(s) && SPECIES[s].fam !== "king");
  // 第68版: 地方ごとに 決まった 主の 王・形は いろいろ（G・L+S・M+M・M+S+S・S×4）。王は 形に 合わせて 大きさを かえる
  const FORMS = [[["G"], 2], [["L", "S"], 2], [["M", "M"], 3], [["M", "S", "S"], 2], [["S", "S", "S", "S"], 1]];
  let r = Math.random() * FORMS.reduce((a, f) => a + f[1], 0), form = FORMS[0][0];
  for (const [f, w] of FORMS) { if ((r -= w) < 0) { form = f; break; } }
  const k0 = kings.length ? kings[(i * 11 + 3) % kings.length] : pick(others);
  const plus = Math.min(99, 60 + wins * 5);
  const team = [{ sid: k0, lv: 100, q: 1, plus, sz: form[0] }];
  for (const sz of form.slice(1)) {
    const c0 = others.filter((s) => SPECIES[s].sz === sz && !team.some((t) => t.sid === s)), c = c0.length >= 3 ? c0 : others.filter((s) => !team.some((t) => t.sid === s));
    if (!c.length) continue;
    team.push({ sid: pick(c), lv: 100, q: 1, plus: Math.min(99, 50 + wins * 5), sz });   /* 大きさは 形に 合わせる */
  }
  return team;
}

