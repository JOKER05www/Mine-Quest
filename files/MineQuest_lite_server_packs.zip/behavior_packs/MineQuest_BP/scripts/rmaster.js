// v2.2.4: 地方マスター（各地方の 町に 1人ずつ いて、その 地方の 石板を 守っている）
import { world, system } from "@minecraft/server";
import { SPECIES, ORDER, BOSS_SLAB, FAMILIES, DEITY, ITEMS } from "./data.js";
import { load, save } from "./store.js";
import { busy, ok, notice, confirm, sound, particle, gold, LINE, giveItem, setJob, seedId } from "./ui.js";
import { castleInfo, castleSpot, groundY } from "./structures.js";
import { WREGIONS } from "./worldmap.js";
import { fight } from "./story.js";
import { sealReady, storyNowHint } from "./saga.js";
import { calcStats, canFight } from "./core.js";
import { qs, RM_SLAB, giveSlab, bossLv, slabBossLv, bossPlus, rIdx, RI, endingDone } from "./quest.js";

export const REGIONS = [
  { name: "ミドリ", title: "若葉の 地方マスター", fams: ["animal", "beast", "animal"], theme: "forest",
    pre: ["あなたが 長老の 言っていた 子ね。モンスターが 自分から 寄ってくる なんて、うらやましい 体質。", "でも 石板は 甘くない。触れた 人の 心の すきまに 入りこむの。……私の 仲間に 勝てたら、この 地方の 石板を あずけるわ。"],
    win: "うん、迷いが ない。この 石板は あなたに 託す。中で 何を 言われても、仲間の 声を 先に 聞いてね。" },
  { name: "ジン", title: "鋼刃の 地方マスター", fams: ["sword", "beast", "golem"], theme: "shrine",
    pre: ["剣は 主を 選ぶ。石板も 主を 選ぶ。選ばれた つもりで いる やつほど、斬られる。", "お前が 石板を 選ぶのか、石板が お前を 選ぶのか。……その 違いを、刃で 確かめる。"],
    win: "選んだのは お前の ほう だったか。ならば 迷うな。この 一枚、斬り開いて こい。" },
  { name: "カグラ", title: "炎舞の 地方マスター", fams: ["nether", "dragon", "beast"], theme: "volcano",
    pre: ["炎は 何でも 燃やす。迷いも、恐れも、仲間への 甘えも。", "私は 石板の 声を 燃やして 黙らせてきた。あなたは どうやって 黙らせる つもり？ 見せて ちょうだい。"],
    win: "燃やすんじゃ なく、聞いた うえで 選ぶ……そういう 戦い方も あるのね。持っていきなさい。" },
  { name: "ゴウ", title: "岩鉄の 地方マスター", fams: ["golem", "animal", "beast"], theme: "mountain",
    pre: ["山は 動かん。だから 俺も 動かん。それが この 地方を 守る やり方だ。", "石板を 欲しがる 者は 多い。力を 欲しがる 者は もっと 多い。……お前は どっちだ。拳で 答えろ。"],
    win: "動かされた のは 久しぶりだ。いいだろう、石板は お前の ものだ。重いぞ。" },
  { name: "ナギサ", title: "潮風の 地方マスター", fams: ["aqua", "animal", "blob"], theme: "beach",
    pre: ["海は 沈んだ ものを 返さない。石板も 同じさ。一度 呼ばれたら、戻れるかは 自分しだい。", "俺は この 港を 守る ために 石板を 預かってる。半端な 覚悟の やつに 渡して、港ごと 沈められちゃ たまらないんでね。"],
    win: "……潮目が 変わったな。持っていけ。戻って きたら、中で 何を 見たか 聞かせてくれ。" },
  { name: "ヨミ", title: "宵闇の 地方マスター", fams: ["nether", "nether", "animal"], theme: "soulvalley",
    pre: ["わたしも あなたと 同じ。悪しき ものに 好かれる 体質。……だから 分かるの。石板の 声は やさしい ふりを する。", "呑まれた 友だちを、わたしは 何人も 見送った。あなたまで 見送りたくない。だから、ここで 試させて。"],
    win: "……大丈夫そうね。あなたの 仲間は、あなたを ちゃんと 引き戻せる。石板を、どうか。" },
  { name: "シデン", title: "雷光の 地方マスター", fams: ["animal", "golem", "dragon"], theme: "sky",
    pre: ["遅い。判断が 遅い やつは 石板に 呑まれる。一瞬で 決める 力が 要る。", "俺の 仲間は 雷より 速く 動く。ついて これなきゃ、石板の 中でも 同じ ことに なるぜ。"],
    win: "……読まれてた、か。速さだけじゃ 足りねえ ってことだな。いい、持ってけ。" },
  { name: "ソラ", title: "天穹の 地方マスター", fams: ["dragon", "animal", "nether"], theme: "endcity",
    pre: ["ここは 地方の いちばん はて。王冠の 光が いちばん よく 見える 場所。", "私は ずっと 待っていた。王の 声に 呼ばれながら、それでも 自分の 足で ここまで 来る 人を。最後の 試験だよ。全力で 来て。"],
    win: "ありがとう。……王は きっと、あなたを 器に しようと する。でも あなたは もう、自分の 名前で 呼ばれる マスターだ。" },
];
export const famName = (f) => (FAMILIES.find((x) => x.id === f)?.name || f);
export const masterType = (k) => `${famName(REGIONS[k].fams[0])}の 使い手`;   // v2.9.13: 得意な 系統
export const masterRegion = (k) => WREGIONS.findIndex((R) => R.rm === k);
export const regionTown = (k) => { const i = masterRegion(k); return i >= 0 ? { name: WREGIONS[i].castle.name, reg: i } : null; };
const SLOT = { S: 1, M: 2, L: 3, G: 4 };
const pick = (a) => a[Math.floor(Math.random() * a.length)];

// 地方マスターの チーム（石板の 主と 同じくらい・少し 上）
export function rmTeam(d, k, wins = 0) {
  const R = REGIONS[k], si = RM_SLAB[k], b = BOSS_SLAB[si];
  const lv = Math.min(100, bossLv(d, si) + 2 + wins * 3), plus = Math.min(99, bossPlus(d, b.sid, si) + wins * 4);
  const r0 = Math.max(0, Math.min(6, rIdx(b.sid)));
  const team = []; let used = 0;
  for (let n = 0; n < 4 && used < 4; n++) {
    const rr = Math.max(0, r0 - (n === 0 ? 0 : n === 1 ? 0 : 1));
    const want = n < 3 ? [R.fams[0]] : R.fams;
    const roomOk = (S) => n > 0 || (SLOT[S.sz] || 2) <= 2;   // v2.9.13: 1体目は M まで（のこりの 枠が うまる ように）   // v2.9.13: 得意な 系統（はじめの 3体は 得意な 系統から）
    let c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && want.includes(S.fam) && roomOk(S) && used + (SLOT[S.sz] || 2) <= 4 && !team.some((t) => t.sid === s); });
    if (!c.length) c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && R.fams.includes(S.fam) && used + (SLOT[S.sz] || 2) <= 4 && !team.some((t) => t.sid === s); });
    if (!c.length) c = ORDER.filter((s) => { const S = SPECIES[s]; return !S.hidden && !S.metalmon && S.rank === RI[rr] && !["king", "god"].includes(S.fam) && used + (SLOT[S.sz] || 2) <= 4; });
    if (!c.length) break;
    const s = pick(c); used += SLOT[SPECIES[s].sz] || 2;
    team.push({ sid: s, lv: Math.min(100, lv + (n === 0 ? 2 : 0)), q: Math.min(1, 0.6 + k * 0.05), plus: n === 0 ? plus + 5 : plus });
  }
  return team;
}

export async function rmTalk(p, k) {
  const d = load(p); if (!d) return null;
  const R = REGIONS[k], s = qs(d), si = RM_SLAB[k], b = BOSS_SLAB[si];
  const won = s.rm.includes(k), wins = (s.rmw && s.rmw[k]) || 0;
  if (!canFight(d)) { await notice(p, R.title, "§c戦える 仲間が いない！"); return null; }
  if (!won && !sealReady(d, si)) { await notice(p, `${R.title} ${R.name}`, `§6§l${R.title} ${R.name}§r\n\n§f「……あなたには まだ やるべき ことが あるようね。それを 果たしてから また いらっしゃい。」\n\n§7いまの 目標: §f${String(storyNowHint(d)).replace(/§./g, "")}`); return null; }   // v2.9.13: 物語の 順番を 守る
  for (const l of won ? ["また 来たのね。腕が なまって いないか 見てあげる。"] : R.pre) await notice(p, `${R.title} ${R.name}`, `§6§l${R.title} ${R.name}§r §7（${masterType(k)}）\n\n§f「${l}」`);
  const team = rmTeam(d, k, won ? wins : 0);
  if (!(await confirm(p, `${R.name}に 挑む`, [`§6§l${R.title} ${R.name}`, LINE, `§7石板の 守り手・§e${masterType(k)}§7（${R.fams.slice(1).map(famName).join("・")}も 使う）`, won ? "§7（再戦・勝つほど 強くなる。ごほうびは お金と 経験）" : `§d認められると「${b.name}」を 託される§7（中の 主 ${b.title}・Lv${slabBossLv(si)}）`, `§f相手: ${team.map((t) => `${SPECIES[t.sid].name}(${SPECIES[t.sid].rank})`).join("・")}  §7Lv${team[0].lv}前後`, "§7戦いの 前に 回復。スカウトは できない・負けても お金は へらない"].join("\n"), "挑む！", "やめる"))) return null;
  return async () => {
    let d2 = load(p); if (!d2) return;
    for (const m of [...d2.party, ...(d2.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d2);
    sound(p, "raid.horn", 1.1);
    let res = await fight(p, { team }, { tier: 2, name: `${R.title} ${R.name}`, fam: "", npc: null, arena: `${R.title}戦`, theme: R.theme, rmaster: true });
    // v2.9.13: 負けたら その場で もう一度
    for (let k2 = 0; k2 < 5 && res === "lose" && ok(p); k2++) {
      busy.add(p.id);
      let again = false; try { again = await confirm(p, "負けて しまった……", `§6§l${R.name}§r§f「${won ? "まだまだ ね。" : "……まだ 渡せない。"}」\n\n§fもう一度 挑みますか？ §7（仲間は 全回復する）`, "もう一度 挑む", "やめる"); } catch {}
      if (!again) break;
      const d3 = load(p); if (!d3) break;
      for (const m of [...d3.party, ...(d3.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d3);
      busy.delete(p.id);
      res = await fight(p, { team }, { tier: 2, name: `${R.title} ${R.name}`, fam: "", npc: null, arena: `${R.title}戦`, theme: R.theme, rmaster: true });
    }
    busy.delete(p.id);
    d2 = load(p); if (!d2) return;
    for (const m of [...d2.party, ...(d2.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
    const s2 = qs(d2);
    if (res !== "win") { save(p, d2); await notice(p, R.title, `§6§l${R.name}§r§f「${won ? "まだまだ ね。" : "……まだ 渡せない。仲間と 話して、また おいで。"}」\n§7仲間は 回復した。`); return; }
    const got = [];
    if (!s2.rmw) s2.rmw = {};
    s2.rmw[k] = (s2.rmw[k] || 0) + 1;
    const g = won ? Math.floor((1000 + k * 1500) / Math.min(4, s2.rmw[k])) : 5000 + k * 8000; d2.gold += g;   /* v3.0 第63版: 再戦の ほうびは 少なく・勝つほど へる */ got.push(gold(g));
    if (!s2.rm.includes(k)) s2.rm.push(k);
    const bs = giveSlab(p, d2, si); if (bs) got.push(`§d§l${bs.name}§r §7（道具から 触れると 石板の 中へ）`);
    if (won && s2.ending && k >= 4 && s2.rmw[k] % 3 === 0) { giveItem(p, "mrpg:sx_king", 1); got.push("§6覇王の石板"); }   // v2.9.6: 強い マスター（★5〜）に 3回 勝つごと
    save(p, d2);
    sound(p, "ui.toast.challenge_complete", 1); particle(p, "minecraft:totem_particle", 1.4);
    if (!won) for (const q of world.getAllPlayers()) q.sendMessage(`§6◆ ${p.name}が ${R.title} ${R.name}に 認められた！`);
    await notice(p, `${R.name}に 勝利！`, [`§6§l${R.name}§r§f「${won ? "腕を あげたね。" : R.win}」`, "", ...got.map((x) => "§e" + x)].join("\n"));
  };
}

// 城に 地方マスターを 立たせる（城が できて いて、近くに プレイヤーが いる とき）
system.runInterval(() => {
  const ow = world.getDimension("minecraft:overworld");
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld" || busy.has(p.id)) continue;
    for (let k = 0; k < REGIONS.length; k++) {
      const ri_ = masterRegion(k); if (ri_ < 0) continue;
      const info = castleInfo(ri_); if (!info || !info.built) continue;
      if (Math.hypot(p.location.x - info.x, p.location.z - info.z) > 70) continue;
      let have = [];
      try { have = ow.getEntities({ type: "mrpg:npc", tags: [`mrpg_rm${k}`] }); } catch {}
      if (have.some((e) => ok(e))) continue;
      const pos = info.m || { x: info.x + 5, y: info.y, z: info.z - 12 };
      try {
        const e = ow.spawnEntity("mrpg:npc", pos);
        setJob(e, 8); e.addTag("mrpg_npc"); e.addTag(`mrpg_rm${k}`); e.setDynamicProperty("mrpg:rm", k);
        e.nameTag = `§6【${REGIONS[k].title}】§f${REGIONS[k].name}`;
        particle(e, "minecraft:totem_particle", 1);
      } catch {}
    }
    // 第68版: 城の 王が いなく なって いたら もどす（近くに いる ときだけ）
    for (let i = 0; i < WREGIONS.length; i++) {
      const info = castleInfo(i); if (!info || !info.built) continue;
      if (Math.hypot(p.location.x - info.x, p.location.z - info.z) > 40) continue;
      let have = []; try { have = ow.getEntities({ type: "mrpg:npc", tags: [`mrpg_castle${i}`] }); } catch {}
      if (have.some((e) => { try { return ok(e) && e.getDynamicProperty("mrpg:king") === i; } catch { return false; } })) continue;
      try {
        const e = ow.spawnEntity("mrpg:npc", { x: info.x + 0.5, y: info.y, z: info.z - 12.5 });
        setJob(e, 15); e.addTag("mrpg_npc"); e.addTag(`mrpg_castle${i}`); e.setDynamicProperty("mrpg:king", i);
        e.nameTag = `§6${WREGIONS[i].castle.name}の 王`;
      } catch {}
    }
  }
}, 100);

// 城の 王（地方の 話・見どころ）
export async function kingTalk(p, i) {
  const R = WREGIONS[i]; if (!R) return;
  const d = load(p);
  const k = R.rm, M = k >= 0 ? REGIONS[k] : null;
  const L = [`${R.col}§l${R.castle.name}の 王§r`, LINE, `§f「ようこそ、${R.name}へ。」`, `§7${R.desc}`, "", `§f強さの めやす: §eLv${R.lv[0]}〜${R.lv[1]}`, `§fよく 見かける モンスター: §e${Object.keys(R.fams).map((f) => ({ beast: "獣", animal: "動物", blob: "粘液", nether: "ネザー", sword: "武者", golem: "無機物", dragon: "竜", aqua: "海", king: "王", god: "神" })[f] || f).join("・")}系`];
  if (M) L.push(`§f地方マスター: §6${M.title} ${M.name}§7（この 城に いる。勝つと 石板を 託される）`);
  if (d && i === 0) L.push("", "§f「ルミナの 子よ。そなたの 体質の ことは オルドから 聞いておる。石板には 気を つけるのだぞ。」");
  if (R.id === "necro") L.push("", "§f「この 地の どこかに §6終の遺跡§f が 眠っている。遺跡を 八つ 越えた 者にしか 開かぬそうだ。」");
  if (R.id === "celes") L.push("", "§f「ここは 大陸で もっとも 空に 近い 郷。強者だけが 来られる 場所だ。」");
  if (!(d && endingDone(d))) { await notice(p, R.castle.name, L.join("\n")); return null; }
  // 第68版: クリア後は 王が 直々に 戦ってくれる（何度でも・勝つほど 強く）
  const s = qs(d); s.kgw = s.kgw || {}; const wins = s.kgw[i] || 0;
  L.push("", `§6§l「……世界を 救った 者よ。余と 手合わせ 願えるか。」`, `§7王の 本気の チーム（全員 SSランク・王系 入り）。勝った 回数: §e${wins}`, wins === 0 ? `§d初めて 勝つと ${ITEMS[DEITY[i]?.slab]?.name || "神の石板"}（神が 眠る 特別な 石板）を もらえる` : "§7何度でも 挑める（勝つほど 強くなる）");
  const c = await confirm(p, R.castle.name, L.join("\n"), "王に 挑む", "話を おえる");
  if (!c) return null;
  const team = kingTeam(i, wins);
  const rw = wins === 0 ? `§d初めて 勝つと: ${ITEMS[DEITY[i]?.slab]?.name || "神の石板"}・万能の秘果・闘魔覚醒の秘玉` : "§d勝つと: 万能の秘果か 神果・闘魔覚醒の秘玉 ＋ 豪華な ごほうび（王・にじいろの タマゴ・神果・まれに 神の タマゴ など）";
  if (!(await confirm(p, `${R.castle.name}の 王に 挑む`, [`${R.col}§l${R.castle.name}の 王`, LINE, ...team.map((t) => `§f・${SPECIES[t.sid].name} §8${SPECIES[t.sid].rank} ${t.sz || SPECIES[t.sid].sz}${SPECIES[t.sid].fam === "king" ? " §6(王系)" : ""}`), "", "§c全員 HP 1万5千 以上・能力 1200 以上（手持ちに 合わせて 強く、勝つほど さらに 強く）", rw, "", "§7仲間は 戦う 前に 全回復する"].join("\n"), "挑む", "やめる"))) return null;
  return async () => {
    let d2 = load(p); if (!d2) return;
    for (const m of [...d2.party, ...(d2.bench || [])]) { const cs = calcStats(m); m.hp = cs.hp; m.mp = cs.mp; } save(p, d2);
    sound(p, "raid.horn", 1.2);
    const res = await fight(p, { team }, { tier: 2, name: `${R.castle.name}の 王`, fam: "", npc: null, arena: `${R.castle.name}の 王座`, theme: "palace", kingK: { i, wins } });
    d2 = load(p); if (!d2 || !ok(p)) return;   /* 勝った 直後に ぬけた ときは ごほうびを 書かない（石板が 消えない ように） */
    for (const m of [...d2.party, ...(d2.bench || [])]) { const cs = calcStats(m); m.hp = cs.hp; m.mp = cs.mp; }
    if (res !== "win") { save(p, d2); await notice(p, R.castle.name, `${R.col}§l${R.castle.name}の 王§r§f「まだまだ。また 来るが よい。」\n§7仲間は 回復した。`); return; }
    const s2 = qs(d2); s2.kgw = s2.kgw || {}; s2.kgw[i] = (s2.kgw[i] || 0) + 1;
    const got = [], give = (id, n = 1) => { if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, n); got.push(`${ITEMS[id].name}${n > 1 ? "×" + n : ""}`); } };
    if (s2.kgw[i] === 1) {
      const G = DEITY[i]; s2.dgs = s2.dgs || [];
      if (G && !s2.dgs.includes(i)) { s2.dgs.push(i); give(G.slab); got[got.length - 1] = `§d§l${ITEMS[G.slab].name}§r §7（神の石板。中の 神は ${G.name}）`; }
      give("s_all3"); give("i_awaken");
    } else {
      give(Math.random() < 0.3 ? "s_all4" : "s_all3"); give("i_awaken");
      const lux = [["e_king", 1], ["e_rainbow", 2], ["i_awaken", 1], [seedId(4), 1], [seedId(4), 1], ["f_exp100k", 1], ["i_tal9", 1], ["i_trpick", 1], ["i_plus10", 1], ["e_god", 1]];
      for (let k = 0; k < 3; k++) { const [id, n] = lux[Math.floor(Math.random() * (k === 2 && Math.random() < 0.15 ? lux.length : lux.length - 1))]; give(id, n); }
    }
    const g = 100000 + 20000 * Math.min(10, s2.kgw[i]); d2.gold += g; got.unshift(gold(g));
    save(p, d2);
    sound(p, "ui.toast.challenge_complete", 1); particle(p, "minecraft:totem_particle", 1.4);
    for (const q of world.getAllPlayers()) { try { const dq = q.id === p.id ? d2 : load(q); if (dq && dq.story && dq.story.ending) q.sendMessage(`§6◆ ${p.name}が ${R.castle.name}の 王に 勝った！（${s2.kgw[i]}回目）`); } catch {} }   /* 第69版 */
    await notice(p, `${R.castle.name}の 王に 勝利！`, [`${R.col}§l${R.castle.name}の 王§r§f「見事……！ 王の 名に かけて、褒美を 取らせよう。」`, "", ...got.map((x) => "§e" + x)].join("\n"));
  };
}
// 第68版: 王の チーム（4枠・全員 SS・王系を 1体 以上・大きさ いろいろ）
const SLOT2 = { S: 1, M: 2, L: 3, G: 4 };
export function kingTeam(i, wins = 0) {
  const ok2 = (s) => { const S = SPECIES[s]; return S && !S.hidden && !S.metalmon && S.rank === "SS" && S.fam !== "god"; };
  const kings = ORDER.filter((s) => ok2(s) && SPECIES[s].fam === "king");
  const others = ORDER.filter((s) => ok2(s) && SPECIES[s].fam !== "king");
  // 第68版: 地方ごとに 決まった 主の 王・形は いろいろ（G・L+S・M+M・M+S+S・S×4）。王は 形に 合わせて 大きさを かえる
  const FORMS = [[["G"], 2], [["L", "S"], 2], [["M", "M"], 3], [["M", "S", "S"], 2], [["S", "S", "S", "S"], 1]];
  let r = Math.random() * FORMS.reduce((a, f) => a + f[1], 0), form = FORMS[0][0];
  for (const [f, w] of FORMS) { if ((r -= w) < 0) { form = f; break; } }
  const k0 = kings.length ? kings[(i * 11 + 3) % kings.length] : pick(others);
  const plus = Math.min(99, 60 + wins * 5);
  const team = [{ sid: k0, lv: 100, q: 1, plus, sz: form[0] }];
  for (const sz of form.slice(1)) {
    const c0 = others.filter((s) => SPECIES[s].sz === sz && !team.some((t) => t.sid === s)), c = c0.length >= 3 ? c0 : others.filter((s) => !team.some((t) => t.sid === s));
    if (!c.length) continue;
    team.push({ sid: pick(c), lv: 100, q: 1, plus: Math.min(99, 50 + wins * 5), sz });   /* 大きさは 形に 合わせる */
  }
  return team;
}

