// 第102版: モンスターに 愛着が わく（なつき度を 土台に 50の 要素）
// 1体ごとの 記録は "mrpg:bond"（プレイヤーごと・小さな JSON・60体まで）。2秒ごとの 見はりに 乗る（軽く）
import { world, system } from "@minecraft/server";
import { ITEMS, SPECIES } from "./data.js";
import { WREGIONS } from "./worldmap.js";
import { load, save, allMonsDeep } from "./store.js";
import { busy, choose, notice, confirm, paged, modal, ICON, MON_ICON, giveItem, takeItem, countItem, sound, barNote, showTitle, rankOf, anim, EXH } from "./ui.js";
import { hooks, findPet } from "./field.js";
import { battleHooks, START_HOOKS } from "./battle.js";
import { calcStats, BUF_MAX } from "./core.js";
import { award, TITLES } from "./endgame.js";
import { FISH_HOOK } from "./fishing.js";
import { exOf, exSave, XT, regAtLoc, hash, dayNo, hd, fx, nowT, pickA, spotsOf, NODES, dirTo } from "./explore.js";

const B = (t, icon) => [t, icon];
let WW = ""; try { world.afterEvents.weatherChange.subscribe((ev) => { try { WW = String(ev.newWeather || ""); } catch {} }); } catch {}
const rnd = () => Math.random();
const say = (p, m) => { try { p.sendMessage(m); } catch {} };
const bar = (p, m) => { try { barNote(p).setActionBar(m); } catch {} };
const allMons = (d) => [...d.party, ...(d.bench || []), ...d.box];
const dstr = (dn) => new Date(dn * 86400000).toISOString().slice(0, 10);

// ---------- 1体ごとの 記録 ----------
const BK = "mrpg:bond", BC = new Map(), BD = new Set();
function bondAll(p) { if (BC.has(p.id)) return BC.get(p.id); let v = null, okR = true; try { const s = p.getDynamicProperty(BK); if (typeof s === "string") v = JSON.parse(s); } catch { okR = false; } v = v && typeof v === "object" && !Array.isArray(v) ? v : {}; if (okR) BC.set(p.id, v); return v; }
export function bondOf(p, m) { const A = bondAll(p); let r = A[m.id]; if (!r) { r = A[m.id] = { bd: dayNo(), met: Math.max(0, regAtLoc(p.location)), lv0: m.lv, nm: m.nm, sp: m.sp }; BD.add(p.id); } return r; }
function bondSave(p, now = false) { BD.add(p.id); if (!now) return; const A = BC.get(p.id); if (!A) return; const ids = Object.keys(A); if (ids.length > 35) { const e = exOf(p); const d = load(p), keep = new Set([...(d?.party || []), ...(d?.bench || [])].map((m) => m.id).concat(d?.out || [])); ids.filter((k) => !keep.has(k)).sort((a, b) => (e.nk?.[a] || 0) - (e.nk?.[b] || 0)).slice(0, Math.max(0, ids.length - 35)).forEach((k) => { delete A[k]; });   /* パーティと 連れ歩きは 消さない */ } try { p.setDynamicProperty(BK, JSON.stringify(A)); BD.delete(p.id); } catch {} }
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { BC.delete(playerId); BD.delete(playerId); KNOWN.delete(playerId); }); } catch {}

// 8) なつき度の 段階（5つ）
export const TIER = [[0, "知り合い"], [80, "なかよし"], [250, "相棒"], [600, "親友"], [900, "家族"]];
export const tierOf = (n) => { let k = 0; TIER.forEach(([v], i) => { if ((n || 0) >= v) k = i; }); return k; };
const nkOf = (p, m) => exOf(p).nk?.[m.id] || 0;
function addNk(p, m, n, why) {
  const e = exOf(p); e.nk = e.nk || {}; const a = e.nk[m.id] || 0, b = Math.max(0, Math.min(1000, a + n)); e.nk[m.id] = b; exSave(p);
  if (tierOf(b) > tierOf(a)) { say(p, `§d§l${m.nm}との きずなが 深まった！ 「${TIER[tierOf(b)][1]}」${why ? ` §7（${why}）` : ""}`); sound(p, "random.levelup", 1.6); const pet = findPet(p); if (pet) { anim(pet, "happy"); for (let k = 0; k < 8; k++) fx(pet.dimension, "minecraft:heart_particle", { x: pet.location.x + (rnd() - 0.5), y: pet.location.y + 1.5, z: pet.location.z + (rnd() - 0.5) }); }   // 12) 喜ぶ 演出
    const r = bondOf(p, m); (r.ms = r.ms || []).push(`${dstr(dayNo())} 「${TIER[tierOf(b)][1]}」に なった`); bondSave(p);
    if (tierOf(b) >= 3) { const d = load(p); if (d) { award(p, d, tierOf(b) >= 4 ? "bd_family" : "bd_best", null); save(p, d); } }   // 26) バッジ（称号）
  }
}
TITLES.bd_best = ["親友の いる マスター", "なつき度「親友」の 仲間が できる"]; TITLES.bd_family = ["家族の きずな", "なつき度「家族」の 仲間が できる"]; TITLES.bd_party = ["きずなの パーティ", "パーティ 全員が「相棒」以上"];
// 2・3) 好物と 苦手（1体ごとに きまる）・41) 好きな 場所・42/43) 好きな 天気と 苦手な 天気
const FOODS = ["fd_stew", "fd_soup", "fd_curry", "fd_cake", "fd_tea", "fd_bento", "fd_egg", "fd_onigiri"];
const WX = [["rain", "雨"], ["thunder", "雷雨"], ["clear", "晴れ"]];
export const likes = (m) => { const h = hash(String(m.id)); return { fav: FOODS[h % 8], bad: FOODS[(h >>> 3) % 8] === FOODS[h % 8] ? FOODS[((h >>> 3) + 1) % 8] : FOODS[(h >>> 3) % 8], reg: (h >>> 6) % WREGIONS.length, wx: WX[(h >>> 9) % 3], nwx: WX[((h >>> 9) + 1) % 3], gem: ["ガーネット", "アメジスト", "アクアマリン", "ダイヤ", "エメラルド", "パール", "ルビー", "ペリドット", "サファイア", "オパール", "トパーズ", "ラピス"][(h >>> 12) % 12] }; };
// 20・21) なでた ときの ことば（系統・性格）
const PET_LINE = { blob: "ぷるぷる…♪", animal: "しっぽを ふって いる", beast: "のどを ならして いる", aqua: "ひれを ぱたぱた", dragon: "うれしそうに 小さく ほえた", golem: "ごとん… と すりよって きた", sword: "刃を そっと ふせた", nether: "あやしく わらった（うれしいらしい）", king: "どうどうと うなずいた", god: "やさしく 光った" };
const NAT_LINE = ["げんきいっぱいだ", "てれて いる", "まんぞくそうだ", "もっと なでて と いう 顔だ", "目を ほそめて いる"];

// ---------- 道具を あげる（24 ごはん・2 好物）----------
const prevUse = EXH.use;
EXH.feed = async (p, d, m) => {
  const L = FOODS.filter((id) => countItem(p, `mrpg:${id}`) > 0); if (!L.length) { await notice(p, "ごはん", "§7料理を 持って いない（探索手帳 → 料理と 畑・町の レストラン）"); return; }
  const k = await paged(p, `${m.nm}に ごはん`, `§7好物を あげると よろこぶ（なつき度 2倍）`, L.map((id) => B(`${ITEMS[id].name} §8×${countItem(p, `mrpg:${id}`)}`, ICON("i_shop"))), 8); if (k < 0 || !L[k]) return;
  if (!takeItem(p, `mrpg:${L[k]}`)) return; const lk = likes(m), r = bondOf(p, m);
  const n = L[k] === lk.fav ? 40 : L[k] === lk.bad ? 5 : 20; addNk(p, m, n, "ごはん"); r.fd = (r.fd || 0) + 1; if (L[k] === lk.fav) r.favKnown = 1; bondSave(p, true);
  await notice(p, "ごはん", L[k] === lk.fav ? `§d${m.nm}は 大よろこび！ ${ITEMS[L[k]].name}が 好物らしい` : L[k] === lk.bad ? `§7${m.nm}は ちょっと いやそうだ… ${ITEMS[L[k]].name}は 苦手かも` : `§a${m.nm}は おいしそうに 食べた`);
};

// ---------- 見はり（XT.tick・2秒ごと）----------
const LAST = new Map();
XT.tick.push((p, d, e, i, L, tk) => {
  const ph = (tk + (hash(p.id) % 30)) % 30;
  const m = d.out ? allMons(d).find((x) => x.id === d.out) : null;
  // 32・33) お別れした 仲間（配合・売却で いなく なった）を 思い出に・配合の 子に きずなを 半分 つぐ
  if (ph === 9) memorial(p, d, e);
  // 1・27) 誕生日（仲間に なった 日）
  if (ph === 19) for (const x of d.party) { const r = bondOf(p, x); const bd = new Date(r.bd * 86400000), td = new Date(dayNo() * 86400000); if (r.bd !== dayNo() && bd.getUTCMonth() === td.getUTCMonth() && bd.getUTCDate() === td.getUTCDate() && r.bdy !== dayNo()) { r.bdy = dayNo(); bondSave(p, true); say(p, `§d§l今日は ${x.nm}が 仲間に なった 記念日！ §r§d（${td.getUTCFullYear() - bd.getUTCFullYear()}年目・なつき度 +30）`); addNk(p, x, 30, "記念日"); giveItem(p, "mrpg:x_snack", 1); } }
  if (!m) { LAST.delete(p.id); return; }
  const r = bondOf(p, m), lk = likes(m);
  // 13) いっしょに 歩いた きょり・25) お散歩ボーナス
  const last = LAST.get(p.id); LAST.set(p.id, { x: L.x, z: L.z, mid: m.id });
  if (last && last.mid === m.id) { const dd = hd(L, last); if (dd > 0.5 && dd < 30) { r.wk = Math.round((r.wk || 0) + dd); if (Math.floor(r.wk / 1000) > (r.wkm || 0)) { r.wkm = Math.floor(r.wk / 1000); addNk(p, m, 20, "お散歩"); say(p, `§b${m.nm}と ${r.wkm}km 歩いた！`); if (rnd() < 0.5) giveItem(p, "mrpg:x_acorn", 1); } BD.add(p.id); } }
  // 38) いっしょに いた 日数
  if (r.dl !== dayNo()) { r.dl = dayNo(); r.days = (r.days || 0) + 1; BD.add(p.id); }
  // 41) 好きな 場所
  if (i === lk.reg && r.rg !== dayNo()) { r.rg = dayNo(); addNk(p, m, 10, "好きな 場所"); bar(p, `§b${m.nm}は ${WREGIONS[i].short}が 好きみたいだ`); }
  // 11) なつき度の ハート（連れ歩きの 名前）
  if (ph % 5 === 0) { const pet = findPet(p); if (pet) { const h = "♪".repeat(tierOf(nkOf(p, m))); const nt = `§b★${m.nm} §fLv${m.lv} ${rankOf(m.sp)}${h ? ` §d${h}` : ""}`; if (pet.nameTag !== nt) pet.nameTag = nt; } }
  // 24) ごはんタイム（昼）
  let t = 6000; try { t = world.getTimeOfDay(); } catch {}
  if (t >= 6000 && t < 6400 && r.hg !== dayNo()) { r.hg = dayNo(); BD.add(p.id); say(p, `§e${m.nm}が おなかを すかせて いる…（料理を あげると よろこぶ・探索手帳 → きずな）`); }
  // 44) 寝顔（夜・じっと している）
  if (t > 13000 && t < 23000 && last && hd(L, last) < 0.2) { r.sl = (r.sl || 0) + 1; if (r.sl === 5 && r.sld !== dayNo()) { r.sld = dayNo(); say(p, `§7${m.nm}は すやすや 眠って いる…`); addNk(p, m, 3); } } else r.sl = 0;
  // 45) 見守り（HPが へったら 少し 回復）
  if (ph % 10 === 4 && tierOf(nkOf(p, m)) >= 1) { try { const h = p.getComponent("minecraft:health"); if (h && h.currentValue < h.effectiveMax * 0.3) { p.addEffect("regeneration", 100, { amplifier: 0 }); bar(p, `§d${m.nm}が 心配そうに よりそって いる`); } } catch {} }
  // 47) 守る（あぶない 生き物を 知らせる）
  if (ph % 3 === 1 && tierOf(nkOf(p, m)) >= 2) { let n = []; try { n = p.dimension.getEntities({ location: L, maxDistance: 8, families: ["monster"] }); } catch {} if (n.length) bar(p, `§c${m.nm}が ${dirTo(L, n[0].location)}に むかって うなって いる！`); }
  // 46) 宝の におい（親友 以上）
  if (ph === 21 && tierOf(nkOf(p, m)) >= 3 && rnd() < 0.3) { let best = null, bd2 = 60; for (const v of NODES.values()) if (v.pid === p.id && hd(L, v) < bd2) { bd2 = hd(L, v); best = v; } if (best) bar(p, `§d${m.nm}が ${dirTo(L, best)}の においを かいで いる…`); }
  // 28) 親友からの プレゼント
  if (ph === 26 && tierOf(nkOf(p, m)) >= 3 && rnd() < 0.04) { const id = pickA(["c_drop", "f_exp1k", "x_snack", "c_revive"]); if (ITEMS[id]) { giveItem(p, `mrpg:${id}`, 1); say(p, `§d${m.nm}が 大事そうに ${ITEMS[id].name} を くれた`); } }
  // 22・23) おかえり（5分 以上 はなれて いた あと）
  if (r.away === 1 && nowT() - (r.ls || 0) > 300000 && r.ls) { say(p, `§b${m.nm}「おかえり！」 §7とびついて きた`); addNk(p, m, 2); try { p.playSound("mob.cat.purr", { volume: 0.6 }); } catch {} } delete r.away; if (nowT() - (r.ls || 0) > 60000) { r.ls = nowT(); BD.add(p.id); }
  if (BD.has(p.id) && tk % 15 === 3) bondSave(p, true);
});
try { world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => { if (!initialSpawn) return; system.runTimeout(() => { try { const d = load(player); const m = d?.out && allMons(d).find((x) => x.id === d.out); if (m) { const r = bondOf(player, m); r.away = 1; } } catch {} }, 60); }); } catch {}
// 32・33) 思い出の 仲間・きずなの 受けつぎ
const KNOWN = new Map();   // pid -> 前に 見た 仲間の id（新しく 来た 子を 見わける）
function memorial(p, d, e) {
  const A = bondAll(p), ids = allMonsDeep(d).map((m) => m && m.id).filter(Boolean), have = new Set(ids), prev = KNOWN.get(p.id); KNOWN.set(p.id, have);   /* 牧場・育て屋の 子も 見る */
  for (const id of ids) if (A[id]?.gone) delete A[id].gone;
  let gone = null, goneNk = 0;
  for (const [id, r] of Object.entries(A)) if (!have.has(id) && !r.gone && (e.nk?.[id] || 0) >= 80) { r.gone = dayNo(); if ((e.nk[id] || 0) > goneNk) { gone = r; goneNk = e.nk[id]; } e.mem = Array.isArray(e.mem) ? e.mem : []; e.mem.unshift(`${r.nm}（${SPECIES[r.sp]?.name || ""}）・なつき ${e.nk[id]}・${dstr(r.bd)}〜${dstr(dayNo())}`); if (e.mem.length > 20) e.mem.length = 20; say(p, `§7${r.nm}との 思い出を 手帳に のこした…（きずな → 思い出の 仲間）`); }
  if (gone && prev) { const kid = allMons(d).find((m) => !prev.has(m.id)); if (kid) { addNk(p, kid, Math.floor(goneNk / 2), "親の きずなを 受けついだ"); bondOf(p, kid).par = gone.nm; } }
  if (gone) { for (const [id, r] of Object.entries(A)) if (r.gone) delete A[id]; bondSave(p, true); exSave(p, true); }   /* 思い出に 書いたら 記録は 消す（大きく しない） */
  for (const m of d.party) if (!A[m.id]) bondOf(p, m);
}

// ---------- 戦い（9 かけ声・10 親友の 力・42 好きな 天気・50 家族の きずな・14/15 いっしょに 戦った 記録）----------
START_HOOKS.push((B0, p) => {
  if (!p || B0.pvp) return;
  const d = load(p); if (!d) return; const mine = (B0.allies || []).filter((f) => !f.guest && (!f.owner || f.owner === p.id) && f.m);
  const w = WW;
  let all = mine.length >= 2;
  for (const f of mine) { const n = nkOf(p, f.m), tr = tierOf(n), lk = likes(f.m);
    if (tr >= 3) f.buf.eva = Math.min(BUF_MAX, (f.buf.eva || 0) + 1); if (tr >= 4) f.buf.acc = Math.min(BUF_MAX, (f.buf.acc || 0) + 1);
    if (w && (new RegExp(lk.wx[0], "i").test(w) || (lk.wx[0] === "clear" && !/rain|thunder/i.test(w)))) f.buf.spd = Math.min(BUF_MAX, (f.buf.spd || 0) + 1);
    if (tr < 2) all = false; }
  const lead = mine.slice().sort((a, b) => nkOf(p, b.m) - nkOf(p, a.m))[0];
  if (lead && tierOf(nkOf(p, lead.m)) >= 2) say(p, `§d${lead.name}「まかせて！」 §7（${TIER[tierOf(nkOf(p, lead.m))][1]}）`);
  if (all) { for (const f of mine) f.buf.def = Math.min(BUF_MAX, (f.buf.def || 0) + 1); say(p, "§d§lきずなの 力！ §r§dみんなの 硬力 +1"); award(p, d, "bd_party", null); save(p, d); }
});
battleHooks.push((B0, x) => {
  const { p, d } = x; try { if (!p.isValid()) return; } catch { return; }
  const mine = (B0.allies || []).filter((f) => !f.guest && (!f.owner || f.owner === p.id) && f.m); if (!mine.length) return;
  const foe = (B0.enemies || [])[0], big = B0.boss || B0.master;
  for (const f of mine) { const m = allMons(d).find((y) => y.id === f.m.id); if (!m) continue; const r = bondOf(p, m); r.bt = (r.bt || 0) + 1;
    if (B0.result === "win") { r.bw = (r.bw || 0) + 1; addNk(p, m, big ? 3 : 1); if (big && foe) { r.big = Array.isArray(r.big) ? r.big : []; const nm = foe.name.replace(/§./g, ""); if (!r.big.includes(nm)) { r.big.unshift(nm); if (r.big.length > 6) r.big.length = 6; } } }
    // 7) 成長の 記録（Lv 10・30・50・100）
    for (const lv of [10, 30, 50, 100]) if (m.lv >= lv && !(r.lg || {})[lv]) { r.lg = r.lg || {}; r.lg[lv] = dayNo(); (r.ms = r.ms || []).push(`${dstr(dayNo())} Lv${lv}に なった`); }
    if (r.ms && r.ms.length > 8) r.ms = r.ms.slice(-8); }
  bondSave(p, true);
});
// 48) いっしょに 釣り（なかよし 以上が 連れ歩きで 1割 おまけ）
const prevAfter = FISH_HOOK.after;
FISH_HOOK.after = (p, id) => { try { prevAfter && prevAfter(p, id); } catch {} try { const d = load(p); const m = d?.out && allMons(d).find((x) => x.id === d.out); if (m && tierOf(nkOf(p, m)) >= 1 && rnd() < 0.1 && ITEMS[id]) { giveItem(p, `mrpg:${id}`, 1); say(p, `§b${m.nm}も 1ぴき 取って きた！`); } } catch {} };
// 29) なつき度で ライドが 少し 速い（相棒 2%・親友 4%・家族 6%）
system.run(() => { const prev = hooks.rideMul; hooks.rideMul = (e, m) => { let r = 1; try { r = prev ? prev(e, m) : 1; } catch {} let pid; try { pid = e.getDynamicProperty("mrpg:owner"); } catch {} const p = pid && world.getAllPlayers().find((q) => q.id === pid); if (!p || !m) return r; return r * (1 + [0, 0, 0.02, 0.04, 0.06][tierOf(nkOf(p, m))]); }; });
// 5・17・18) 宿屋（いっしょに 寝る・手紙・夢）
const prevInn = EXH.inn;
EXH.inn = async (p) => {
  if (prevInn) await prevInn(p);
  const d = load(p); if (!d) return; const m = d.party[0]; if (!m) return;
  { const r = bondOf(p, m); if (r.inn !== dayNo()) { r.inn = dayNo(); addNk(p, m, 10, "いっしょに 休んだ"); bondSave(p, true); } }   /* 1日 1回 */
  if (tierOf(nkOf(p, m)) >= 2 && rnd() < 0.5) await notice(p, `${m.nm}からの 手紙`, `§f「${pickA(["いつも ありがとう。また いっしょに 冒険しよう", "きのうの 戦い、かっこよかった", "つぎは どこへ 行くの？ たのしみ！", "ずっと いっしょに いてね"])}」\n§7${m.nm}より`);
};

// ---------- きずなの 画面（探索手帳 → きずな）----------
async function bondMenu(p, d) {
  for (;;) {
    const e = exOf(p), L = [...d.party, ...(d.bench || [])], mem = e.mem || [];
    const k = await paged(p, "きずな", "§7仲間を えらぶと くわしく 見られる", [...L.map((m) => B(`${m.nm} §7Lv${m.lv}\n§d${"♪".repeat(tierOf(nkOf(p, m)))}§8 ${TIER[tierOf(nkOf(p, m))][1]}・${nkOf(p, m)}`, MON_ICON(m.sp))), B("§l預かり所の 仲間", ICON("i_party")), B(`§l思い出の 仲間 §8（${mem.length}）`, ICON("i_zukan")), B("§lきずなランキング", ICON("i_star"))], 8);
    if (k < 0) return;
    if (k === L.length) { const L2 = d.box.slice(0, 120); const j = await paged(p, "預かり所の 仲間", "", L2.map((m) => B(`${m.nm} §7Lv${m.lv} §d${"♪".repeat(tierOf(nkOf(p, m)))}`, MON_ICON(m.sp))), 8); if (j >= 0 && L2[j]) await monPage(p, load(p), L2[j].id); continue; }
    if (k === L.length + 1) { await notice(p, "思い出の 仲間", mem.map((x) => `§7・${x}`).join("\n") || "§7まだ いない"); continue; }
    if (k === L.length + 2) { await ranking(p, d); continue; }
    if (L[k]) await monPage(p, load(p), L[k].id);
  }
}
async function monPage(p, d, id) {
  for (;;) {
    const m = allMons(d).find((x) => x.id === id); if (!m) return;
    const e = exOf(p), r = bondOf(p, m), lk = likes(m), n = nkOf(p, m), st = calcStats(m), base = r.st0 || (r.st0 = { hp: st.hp, atk: st.atk, def: st.def, spd: st.spd });
    const body = [`§d${"♪".repeat(tierOf(n)) || "・"} §f${TIER[tierOf(n)][1]} §7（${n}/1000）`, `§f仲間に なった 日 §e${dstr(r.bd)}§f（${WREGIONS[r.met]?.short || ""}で）・誕生石 §e${lk.gem}`,
      `§fいっしょに いた 日 §e${r.days || 1}日§f・歩いた §e${r.wk >= 1000 ? (r.wk / 1000).toFixed(1) + "km" : (r.wk || 0) + "m"}`, `§fいっしょに 戦った §e${r.bt || 0}回§f（勝ち ${r.bw || 0}）`,
      `§f好物 §e${r.favKnown ? ITEMS[lk.fav]?.name : "？？？（ごはんを あげると わかる）"}§f・好きな 場所 §e${WREGIONS[lk.reg]?.short}§f・好きな 天気 §e${lk.wx[1]}§f・苦手な 天気 §7${lk.nwx[1]}`,
      `§f成長: Lv${r.lv0 || m.lv} → Lv${m.lv}  §7HP ${base.hp}→${st.hp}・物力 ${base.atk}→${st.atk}・走力 ${base.spd}→${st.spd}`,
      r.big?.length ? `§f勝った 強敵: §e${r.big.join("・")}` : "", r.par ? `§f親: §e${r.par}§7（きずなを 受けついだ）` : "", r.note ? `§fメモ: §e${r.note}` : "", r.fv ? "§6★ お気に入り" : "",
      ...(r.ms || []).slice(-5).map((x) => `§7・${x}`)].filter(Boolean).join("\n");
    bondSave(p);
    const c = await choose(p, m.nm, body, [B("§d§lなでる §8（1日 1回）", ICON("i_party")), B("§lごはんを あげる", ICON("i_shop")), B("§lひとことメモを 書く", ICON("i_help")), B(r.fv ? "§7お気に入りを はずす" : "§6§lお気に入りに する", ICON("i_star")), B("§l今日の ようす", ICON("i_zukan")), B("§lきずなを 自慢する §8（ワールドの 掲示板）", ICON("i_star")), B("§7戻る", ICON("i_back"))]);
    if (c === 0) { if (r.pt === dayNo()) { await notice(p, "なでる", `§7${m.nm}は もう まんぞくそうだ（また 明日）`); continue; } r.pt = dayNo(); addNk(p, m, 5, "なでた"); bondSave(p, true); const pet = findPet(p); if (pet && d.out === m.id) { anim(pet, "happy"); for (let k = 0; k < 6; k++) fx(pet.dimension, "minecraft:heart_particle", { x: pet.location.x, y: pet.location.y + 1.5, z: pet.location.z }); } await notice(p, "なでる", `§d${m.nm}は ${PET_LINE[SPECIES[m.sp]?.fam] || "うれしそうだ"}。${NAT_LINE[(m.nat || 0) % NAT_LINE.length]}`); }
    else if (c === 1) await EXH.feed(p, d, m);
    else if (c === 2) { const v = await modal(p, `${m.nm}の メモ`, (f) => f.textField("ひとこと（24文字まで）", "例: はじめての 相棒", r.note || "")); if (v && typeof v[0] === "string") { r.note = v[0].slice(0, 24); bondSave(p, true); } }
    else if (c === 3) { r.fv = r.fv ? 0 : 1; bondSave(p, true); }
    else if (c === 4) await notice(p, "今日の ようす", `§f${m.nm}は ${["うきうき して いる", "ちょっと ねむそう", "おなかが すいて いる", "冒険に 行きたそう", "あなたを じっと 見て いる"][(hash(m.id) + dayNo()) % 5]}。\n§7${lk.wx[1]}の 日は 調子が いい（戦いで 走力 +1）`);
    else if (c === 5) { let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:bondboard") || "[]"); } catch {} L = L.filter((x) => x[0] !== p.name); L.push([p.name, m.nm, SPECIES[m.sp]?.name || "", n]); L.sort((a, b) => b[3] - a[3]); try { world.setDynamicProperty("mrpg:bondboard", JSON.stringify(L.slice(0, 10))); } catch {} await notice(p, "自慢", "§a掲示板に のせた！（きずな → きずなランキング）"); }
    else return;
  }
}
// 39・40) きずなランキング（ワールド）
async function ranking(p, d) { let L = []; try { L = JSON.parse(world.getDynamicProperty("mrpg:bondboard") || "[]"); } catch {} await notice(p, "きずなランキング", L.map((x, k) => `§e${k + 1}. §f${x[0]}と ${x[1]}（${x[2]}）§d ${x[3]}`).join("\n") || "§7まだ だれも のせて いない（仲間の 画面 →「きずなを 自慢する」）"); }
XT.menu.push(["§d§lきずな\n§8なでる・ごはん・思い出", bondMenu, "i_party"]);
// 49) 呼んだら 来る（連れ歩きが 遠い とき）
XT.tick.push((p, d, e, i, L, tk) => { if (!d.out || (tk + (hash(p.id) % 30)) % 30 !== 15) return; const pet = findPet(p); if (pet && hd(pet.location, L) > 40) { try { pet.teleport(p.location, { dimension: p.dimension }); bar(p, "§b連れ歩きの 仲間が かけつけて きた"); } catch {} } });
export const __bond = { bondAll, bondOf, addNk, likes, tierOf, memorial, monPage, bondMenu };
