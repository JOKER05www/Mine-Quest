// 第122版: 物語の 場面の 場所（目印）。町の 噴水の 広場は 使わない
// 城の 中庭・玉座の 間・城の 門の 前・町の 外れ・鍛冶場・オルドの 牧場・洞くつの 広間・港の 桟橋・宿・大聖堂の 前・廃都（大通り・壁画の 広間）
// 返す 形: { x, y, z, nm, r?, wait? }。y が null の ときは 現地で 地面を さがす。wait は「まだ できて いない（待つ）」
import { world } from "@minecraft/server";
import { WREGIONS, landSites, regionIdx } from "./worldmap.js";
import { castleInfo, castleSpot, caveInfo, caveSite, landInfo, TOWNS, getTown, townPos } from "./structures.js";

export const SPOT_V = 122;
export const PLACES = new Set(["ranch", "court", "throne", "gate", "out", "forge", "harbor", "beach", "inn", "church", "hall", "street", "mural", "stage", "road"]);
const F = (q) => ({ x: Math.floor(q.x), y: typeof q.y === "number" ? Math.floor(q.y) : null, z: Math.floor(q.z) });
export function spotOf(id, k) { try { const w = JSON.parse(world.getDynamicProperty(`mrpg:walk:${id}`) || "null"); const q = w && Array.isArray(w.p) && w.p.find((x) => x[0] === k); return q ? { x: w.x + q[1], y: w.y + q[2], z: w.z + q[3] } : null; } catch { return null; } }
const built = (id) => { try { const q = getTown(id); return !!(q && q.built); } catch { return false; } };
/* その 地方の 町（城に いちばん 近い。右上の 案内と 同じ 決まり）。ルミナの 地方は ルミナ */
export function regTown(r) {
  if (r === 0) { const t = TOWNS.find((u) => u.id === "t0"); if (t) return { t, q: townPos(t) }; }
  let c = null; try { c = castleInfo(r) || castleSpot(r); } catch {}
  let best = null, bd = 1e18;
  for (const t of TOWNS) { if (t.reg !== r) continue; const q = townPos(t); const dd = c ? (q.x - c.x) ** 2 + (q.z - c.z) ** 2 : 0; if (dd < bd) { bd = dd; best = { t, q }; } }
  return best;
}
/* 町の 中心から 城と 反対の 方へ 56マス（turn だけ 回す）*/
function outOf(r, turn, nm, t0 = null) {
  const T = t0 ? { t: t0, q: townPos(t0) } : regTown(r); if (!T) return null;
  let c = null; try { c = castleInfo(r) || castleSpot(r); } catch {}
  const q = T.q, a0 = (c && Math.hypot(q.x - c.x, q.z - c.z) > 1 ? Math.atan2(q.z - c.z, q.x - c.x) : Math.PI / 2) + turn;
  let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
  /* 同じ 地方の 中で、ほかの 城・町に 近すぎない 向き（決まった 順に 試す）*/
  for (const da of [0, 0.8, -0.8, 1.6, -1.6, 2.4, -2.4, Math.PI]) {
    const a = a0 + da, x = Math.floor(q.x + Math.cos(a) * 56), z = Math.floor(q.z + Math.sin(a) * 56);
    let bad = regionIdx(x - s0.x, z - s0.z) !== r;
    if (!bad) for (let i = 0; i < WREGIONS.length && !bad; i++) { if (i === r) continue; try { const k = castleInfo(i) || castleSpot(i); if (k && Math.hypot(k.x - x, k.z - z) < 90) bad = true; } catch {} }
    if (!bad) for (const u of TOWNS) { if (u.id === T.t.id) continue; const w = townPos(u); if (Math.hypot(w.x - x, w.z - z) < 50) { bad = true; break; } }
    if (!bad) return { x, y: null, z, nm: `${T.t.name}の ${nm}`, tid: T.t.id };
  }
  return { x: Math.floor(q.x + Math.cos(a0) * 56), y: null, z: Math.floor(q.z + Math.sin(a0) * 56), nm: `${T.t.name}の ${nm}`, tid: T.t.id };
}
/* 名前の 町の 外れ（城と 反対・その 町の 地方の 中）*/
export function townOut(tid, turn, nm) { const t = TOWNS.find((u) => u.id === tid); if (!t) return null; const o = outOf(t.reg, turn, nm, t); return o; }
/* オルドの 牧場（ルミナの 外の 放牧地）。一度 場面が 起きたら その 場所を 記録する */
export function ranchSpot() {
  try { const v = JSON.parse(world.getDynamicProperty("mrpg:ranch") || "null"); if (v && typeof v.y === "number") return { x: v.x, y: v.y, z: v.z, nm: "オルドの 牧場", rec: 1 }; } catch {}
  const o = outOf(0, 0.9, "外れ"); return o ? { ...o, nm: "オルドの 牧場" } : null;
}
export function ranchSave(q) { try { if (q && typeof q.y === "number") world.setDynamicProperty("mrpg:ranch", JSON.stringify({ x: Math.floor(q.x), y: Math.floor(q.y), z: Math.floor(q.z) })); } catch {} }
/* 場所を 決める。need: 場面の とちゅうで 移る とき（できて いない 所へは 移らない）*/
export function placeOf(kind, r, need = false) {
  try {
    const R = WREGIONS[r]; if (!R) return null;
    const ci = castleInfo(r), cb = !!(ci && ci.built && ci.m);
    const cs = () => { if (need) return null; const c = castleSpot(r); return c ? { x: Math.floor(c.x), y: null, z: Math.floor(c.z), nm: R.castle.name } : null; };
    const land = (n, nm) => { const L = landSites(r)[n] || landSites(r)[0]; if (!L) return null; const I = landInfo(L.key); if (need && !(I && I.built)) return null; return { x: Math.floor(L.x) + 14, y: null, z: Math.floor(L.z) + 6, nm }; };
    switch (kind) {
      case "ranch": { const q = ranchSpot(); return q && (!need || q.rec || built("t0")) ? q : null; }
      case "court": return cb ? { ...F(ci.m), nm: `${R.castle.name}の 中庭` } : cs();
      case "throne": return cb && ci.k ? { ...F(ci.k), nm: `${R.castle.name} 玉座の 間` } : cs();
      case "gate": return cb ? { ...F({ x: ci.m.x, y: ci.m.y, z: ci.m.z + 5 }), nm: `${R.castle.name}の 城門の 内側` } : cs();   /* 門の 外は 城下の 像に 近い（9マス）ので、くぐった 内側 */
      case "out": case "forge": { const o = outOf(r, kind === "forge" ? 0.9 : 0, kind === "forge" ? "外れの 鍛冶場" : "外れの 丘"); return o && (!need || built(o.tid)) ? o : null; }
      case "harbor": case "beach": {
        const T = regTown(r), h = T && spotOf(T.t.id, "harbor");
        if (h) return kind === "harbor" ? { ...F(h), nm: `${T.t.name}の 港の 桟橋` } : { x: Math.floor(h.x) + 26, y: null, z: Math.floor(h.z) - 6, nm: `${T.t.name}の 夜の 浜` };
        const o = outOf(r, kind === "beach" ? -0.9 : 0, kind === "beach" ? "夜の 浜" : "港"); return o && (!need || built(o.tid)) ? o : null;
      }
      case "stage": return land(0, `${R.short}の 大地`);
      case "road": {   /* 町と 城を 結ぶ 街道の とちゅう（城の 外、城から 95マス 町の 方へ）*/
        const T = regTown(r), c = (() => { try { return castleInfo(r) || castleSpot(r); } catch { return null; } })(); if (!T || !c) return null;
        let s0 = { x: 0, z: 0 }; try { s0 = world.getDefaultSpawnLocation(); } catch {}
        const L = Math.hypot(T.q.x - c.x, T.q.z - c.z) || 1, ux = (T.q.x - c.x) / L, uz = (T.q.z - c.z) / L;
        for (const k of [95, 85, 110, 75]) { if (k > L - 50) continue; const x = Math.floor(c.x + ux * k), z = Math.floor(c.z + uz * k); if (regionIdx(x - s0.x, z - s0.z) === r) return { x, y: null, z, nm: r === 2 ? "廃都の 手前の 崖道" : `${R.short}の 街道`, tid: T.t.id }; }
        const o = outOf(r, 0, "街道"); return o ? { ...o, nm: r === 2 ? "廃都の 手前の 崖道" : `${R.short}の 街道` } : null;
      }
      case "inn": { const T = regTown(r), q = T && spotOf(T.t.id, "inn"); return q ? { ...F(q), nm: `${T.t.name}の 宿` } : null; }
      case "church": { const q = spotOf(`c${r}`, "church"); return q ? { ...F(q), nm: `${R.castle.name} 大聖堂の 前` } : null; }
      case "hall": { const v = caveInfo(r); if (v && v.built && v.hall) return { ...F(v.hall), nm: `${R.short}の 洞くつの 広間`, r: 7 }; if (need) return null; const c = caveSite(r); return { x: Math.floor(c.x), y: null, z: Math.floor(c.z), nm: `${R.short}の 洞くつの 広間`, wait: 1 }; }
      case "street": case "mural": {
        const ru = ci && ci.ruin && ci.ruin[kind];
        if (ru) return { ...F(ru), nm: kind === "street" ? "廃都の 崩れた 大通り" : "廃都 壁画の 広間" };
        return land(kind === "street" ? 0 : 1, kind === "street" ? "廃都の 跡（崩れた 大通り）" : "廃都の 跡（壁画の 広間）");
      }
    }
  } catch {}
  return null;
}
/* 第123版: 牧場と 鍛冶場は 何も ない 野原に ならない ように、場面の まわりに 小道具を 1回だけ 置く（舞台の 外側。立ち位置と カメラを ふさがない）*/
import { groundY as _gy } from "./structures.js";
export function decorPlace(dim, kind, P) {
  if (!P || (kind !== "ranch" && kind !== "forge")) return false;
  const key = `mrpg:decor:${kind}`;
  try { const v = JSON.parse(world.getDynamicProperty(key) || "null"); if (v && Math.hypot(v.x - P.x, v.z - P.z) < 30) return false; } catch {}
  const cx = Math.floor(P.x), cz = Math.floor(P.z), y0 = Math.floor(P.y);
  const gy = (x, z) => { try { const y = _gy(dim, x, z, y0); return typeof y === "number" && Math.abs(y - y0) <= 4 ? y : null; } catch { return null; } };
  const put = (x, y, z, b) => { try { dim.runCommand(`setblock ${x} ${y} ${z} ${b} keep`); } catch {} };
  const at = (dx, dz, b, up = 0) => { const y = gy(cx + dx, cz + dz); if (y !== null) put(cx + dx, y + up, cz + dz, b); };
  if (kind === "ranch") {
    const R = 12;   /* 放牧地の 柵（四方に 3マスの 入口）*/
    for (let i = -R; i <= R; i++) for (const [dx, dz] of [[i, -R], [i, R], [-R, i], [R, i]]) { if (Math.abs(i) <= 1) continue; at(dx, dz, "oak_fence"); }
    for (const [dx, dz] of [[-15, -6], [-15, -5], [-16, -6], [15, 8], [16, 8], [15, 9]]) at(dx, dz, "hay_block");
    for (const [dx, dz] of [[-15, 4], [-15, 5]]) at(dx, dz, "cauldron");
    /* 小さな 納屋（柵の 外・北東）*/
    const bx = 17, bz = -14, by = gy(cx + bx, cz + bz);
    if (by !== null) {
      for (let x = 0; x < 5; x++) for (let z = 0; z < 4; z++) { const edge = x === 0 || x === 4 || z === 0 || z === 3; for (let h = 0; h < 3; h++) if (edge && !(z === 3 && x === 2 && h < 2)) put(cx + bx + x, by + h, cz + bz + z, x === 0 || x === 4 ? "spruce_log" : "spruce_planks"); put(cx + bx + x, by + 3, cz + bz + z, "spruce_slab"); }
      put(cx + bx + 2, by, cz + bz + 1, "hay_block");
    }
    { const y = gy(cx, cz + R + 2); if (y !== null) { put(cx + 2, y, cz + R + 2, "oak_fence"); put(cx + 2, y + 1, cz + R + 2, "lantern"); } }
  } else {
    /* 鍛冶場: 屋根だけの 作業場（舞台の 西 10マス）と 炉・金床・煙突 */
    const fx = -12, fz = -3, fy = gy(cx + fx, cz + fz);
    if (fy !== null) {
      try { dim.runCommand(`fill ${cx + fx} ${fy - 1} ${cz + fz} ${cx + fx + 6} ${fy - 1} ${cz + fz + 6} stone_bricks`); } catch {}
      for (const [x, z] of [[0, 0], [6, 0], [0, 6], [6, 6]]) for (let h = 0; h < 3; h++) put(cx + fx + x, fy + h, cz + fz + z, "dark_oak_log");
      for (let x = 0; x <= 6; x++) for (let z = 0; z <= 6; z++) put(cx + fx + x, fy + 3, cz + fz + z, "dark_oak_slab");
      put(cx + fx + 1, fy, cz + fz + 1, "blast_furnace"); put(cx + fx + 2, fy, cz + fz + 1, "blast_furnace");
      put(cx + fx + 3, fy, cz + fz + 3, "anvil"); put(cx + fx + 4, fy, cz + fz + 1, "smithing_table");
      put(cx + fx + 1, fy, cz + fz + 4, "lava_cauldron"); put(cx + fx + 5, fy, cz + fz + 5, "barrel");
      for (let h = 0; h < 6; h++) put(cx + fx + 1, fy + 1 + h, cz + fz + 1, h < 2 ? "air" : "cobblestone_wall");
      put(cx + fx + 1, fy + 1, cz + fz + 2, "campfire");
    }
  }
  try { world.setDynamicProperty(key, JSON.stringify({ x: cx, z: cz })); } catch {}
  return true;
}
