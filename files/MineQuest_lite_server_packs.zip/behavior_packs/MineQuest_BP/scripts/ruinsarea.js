// 第76版: 追加ストーリー「滅びた世界 ルインヘイム」の 場所（ほかの 仕組みが この 中では 町・遺跡・ふつうの 野生を 出さない ための 目印）
// 第77版: 配布マップには 灰都の 街（1792×1792）が 焼きこまれて いる（RU.city）。ないワールドでは 今までの 簡易版
import { world, system } from "@minecraft/server";
export const RU = { x: 100000, z: 100000, r: 1100, city: true, pre: null, dy: 112 };   /* pre: 街が はじめから ある（配布マップ）か。ない ときは citybuild が その場で 建てる */
export const RU_X = 100000, RU_Z = 100000, RU_R = 1100;
export const CITY_R = 896;   /* 街の 広さ（中心から ±896） */
export function setRuCity(v) { RU.pre = !!v; try { world.setDynamicProperty("mrpg:ruCity", v ? 1 : 0); } catch {} }
const readCity = () => { try { const v = world.getDynamicProperty("mrpg:ruCity"); if (typeof v === "number") RU.pre = v === 1; } catch {} };
readCity(); system.run(readCity);
export const inRuins = (loc) => !!loc && Math.abs(loc.x - RU.x) < RU.r && Math.abs(loc.z - RU.z) < RU.r;
export const RU_GATE = { on: false };   /* 追加ストーリーの パックが 入って いる とき true（mq:ext ruins を 受けとる） */
export const RU_INN = { tp: null };   /* 滅びた 世界で 負けた ときの もどり先（ruins.js が 入れる） */
export const RU_HOOK = { cheatGo: null };   /* 第85版: チートブックから 滅びた 世界へ すぐ 行く（追加ストーリーの パックが ある とき） */
