// 第106版: 常世編（ルインヘイム）。十の 区を 十魔将が 一人ずつ 治める。石の 人の 記録・魔将の 会話・区が とける 場面・
// エンマの 妹・リリの 姉妹・カメリオの 正体・セイルの 告白・王妃セレネ・邪神が 相棒に 取りつく 最終戦
import { world, system } from "@minecraft/server";
import { talk, tell, establish } from "./talk.js";   /* 第108版: 会話は フォームで 止めない */
import { load, save } from "./store.js";
import { notice, choose, ICON, sound, showTitle, ok } from "./ui.js";
import { qs } from "./quest.js";
import { exOf } from "./explore.js";
import { SPECIES } from "./data.js";
import { PSKIN } from "./skinjobs.js";
import { setJob } from "./ui.js";
import { scene, act, go, knock, knockP, shake, flash, fx, wave, shadowFlow, fade, pause, spot, lookUp, lookAt, camAt, emote, PJ, HAKU_SP, REI_DRAGON_SP, stoneFx } from "./stage2.js";
/* 第121版: 場面の 人物は stage2 の cast で 立たせて、場面の 終わりに 消す（抜けても 海辺の 片づけ mrpg_cine で 消える） */
const TK_SK = ["argo", "pierina", "doros", "camelio", "glutton", "chrono", "freesia", "boltos", "yoru", "selene"];

/* 第106版: 物語の 場面の あいだは 魔物が 襲って こない（ruins.js が 見る） */
export const TK_CALM = new Set();
const CALMN = new Map();   /* 第106版: 場面が 続いても 前の 予約で 消さない（人ごとの 数） */
const calm = async (p, fn) => { const id = p.id; CALMN.set(id, (CALMN.get(id) || 0) + 1); TK_CALM.add(id); try { return await fn(); } finally { system.runTimeout(() => { const n = (CALMN.get(id) || 1) - 1; if (n > 0) CALMN.set(id, n); else { CALMN.delete(id); TK_CALM.delete(id); } }, 100); } };
const say = (p, who, lines, col = "§f") => talk(p, who, lines, col);
const narr = (p, t, L) => tell(p, t, L);
const big = (p, a, b, snd) => { try { showTitle(p, a, { subtitle: b || "", fadeInDuration: 6, stayDuration: 50, fadeOutDuration: 12 }); } catch {} if (snd) sound(p, snd, 1); };
const ruOf = (d) => { const s = qs(d); s.ru = s.ru || {}; return s.ru; };

/* 区の 名前（0〜9 魔将・10〜14 番兵） */
export const TK_EPI = ["静寂の区", "歓喜の区", "花壇の区", "千面の区", "暴食の区", "時計の区", "氷葬の区", "雷鳴の区", "遊び場の区", "王宮の区", "東の 石門", "西の 石門", "南の 石門", "北の 石門", "記録塔の 門"];
export const TK_NAME = ["第一魔将 静寂の アルゴ", "第二魔将 歓喜の ピエリナ", "第三魔将 腐花の ドロス", "第四魔将 千面の カメリオ", "第五魔将 暴食の グラトン", "第六魔将 時計仕掛けの クロノ", "第七魔将 氷葬の フリージア", "第八魔将 雷鳴の ボルトス", "第九魔将 影縫いの ヨル", "第十魔将 虚ろの 王妃 セレネ"];
export const tkBossName = (i, monName) => (i < 10 ? `${TK_NAME[i]}（${monName}）` : `区の 番兵「${TK_EPI[i]}」${monName ? "（" + monName + "）" : ""}`);

/* 石の 人の 記録（区の 入口で 拾う 本）*/
const RECORD = [
  "§7『書記 マルタ。最後に 書いた 字は「静かに」。……子どもが 泣き止まなかった』",
  "§7『道化 ポポ。三千年前の 今日、最後の 公演。客は 全員、拍手の 形の まま 止まった』",
  "§7『花売り エラ。妹たちに 花冠を 編んで いた。三つ 目を 編み終える 前に』",
  "§7『案内人 トマ。旅人を 町へ 案内して いた。……この 名前を、どこかで 聞いた 気が する』",
  "§7『パン屋 グスタフ。食卓の 上の パンまで 石に なった。家族の 一人だけ、扉へ 手を 伸ばして いる。記録「逃げろと 叫んだ。誰も 動かなかった」』\n§7『隣の 家の 少女 §fサヤ§7。千年 前から、兄の 帰りを 待って いる』",
  "§7『時計番 オットー。塔の 時計は 23時59分で 止まって いる。あと 一分で 明日 だった』",
  "§7『詩人 ユキノ。辞世の 句「とけたなら / 春と 呼んでね / 名を 呼んで」』",
  "§7『兵士 ガイ。最後まで 門を 守った。剣を 抜いた 形の まま』",
  "§7『子ども ミナ、リク、ソラ、ハル。ボールを 追いかけて いた。四人とも 笑って いる』",
  "§7『王妃の 侍女 ミラ。王妃さまは 祈って いた。「この 一日が、永遠に 続きますように」と』",
];
/* 魔将の 会話（戦う 前）。頭の {…} は 表情・マーク・カメラ */
const PRE = [
  ["{closed,…}（札に 書いて 見せた）『静かに』", "{…,up}（札）『雪山で 会ったな』", "{closed,wide}（札）『ここの 者は 皆、静かに なった』", "{angry,!,up}（札）『おまえも』"],
  ["{smile,♪,jump}さあさあ お立ち会い！ 本日の 演目は『石の 街の 最後の 一日』！", "{smile,☆,wide}拍手の 形の まま 三千年！ ねえ、すてきでしょう？ 拍手 拍手〜！"],
  ["{smile,♪}ようこそ、ぼくの 花壇へ。", "{smile,♥,up}ほら、見て。みんな、きれいに 咲いたよ。"],
  ["{smile}……やあ。久しぶり。", "{smile,?,up}覚えて ない？ ルミナで 最初に 会ったじゃ ないか。§e案内人§f だよ。", "{smile,…,low}ワープ、ストーリー、遊び方。全部 教えて あげたよね。……ずっと、きみの 後ろに いたんだ"],
  ["{rage,怒,jump}ガハハ！ 腹が 減った！ 三千年 ぶんの 腹ぺこだ！", "{smile,♥,up}その 腕輪、うまそうだな。その 鍔も。その 相棒も！"],
  ["{closed}（懐中時計を 見て）……予定より 4秒 遅い。", "{angry,low}わたしは 時刻ちょうどにしか 現れない。今が その時刻だ。", "{angry,!,up}残り 3秒。……2。……1。"],
  ["{closed,…}とけたなら / 春と 呼んでと / 言われても", "{angry,low}わたしは 冬 / 名前は 呼ばない / 凍らせる"],
  ["{rage,!,jump}ガッハッハ！ 来たか、声の…… いや、ささやきの 届かぬ 者よ！", "{smile,?}ムサシは おるか！ あの 若造の 太刀筋、気に入って おる！", "{rage,怒,low}正々堂々、一騎打ちだ！"],
  ["{smile,♪,up}みーつけた。", "{smile,♪}ねえ、かくれんぼ しよう。三千年 ずっと、鬼が 来なかったの。", "{smile,…,low}……次は、きみが 鬼ね"],
  ["{sad,…}……あの人は、まだ 来ないの。", "{closed,up}わたしは 祈ったの。この 一日が 永遠に 続きますようにって。", "{cry,tears,up}あの人と 過ごした、なんでも ない 一日。……それが、こんな ことに なるなんて"],
];
/* 勝った あと（a: 魔将の ひとこと / b: 目に 見える こと / fx: 起きる こと）*/
const POST = [
  null,
  ["{smile,tears,up}……拍手、もう 止めて いいのね。", "§7観客席の 石が とけ、人々が 一度だけ 手を 叩いて、消えた", "clap"],
  null, null,
  ["{closed,息}ガハ…… 腹が…… いっぱいだ……", "§7グラトンの 腹から、三千年分の 食卓の パンが 転がり出て、灰に なった", "bread"],
  ["{closed,up}……時刻ちょうど。おわりの 時刻だ", "§7塔の 時計の 針が 動いた。0時00分。§f三千年ぶりに、明日が 来た", "clock"],
  ["{smile,tears,up}春と 呼ぶ / 名前は ユキノ / わたしの 名", "§7フリージアは 自分の 名を 呼んで、とけた", "snow"],
  ["{smile,☆,low}見事！ ……ムサシに 伝えろ。いい 太刀筋 だったと", "§7ボルトスは 胸を 張った まま、雷の 粒に なった", "bolt"],
  null,
  null,
];
const STONE = ["stoneknight", "ruinguard", "guy", "otto", "toma", "mira"];
/* 区の 石が とける: 石の 人々が 一度だけ 動いて、光に なって 消える */
async function melt(p, C, n = 3, pose = "hold", move = "cheer") {
  const E = []; for (let k = 0; k < n; k++) { const e = C.npc("", PJ(STONE[(k * 2 + n) % STONE.length], 8), 5 + (k % 2), (k - (n - 1) / 2) * 1.8); if (e) { act(e, pose); E.push(e); } }
  if (!E.length) return; camAt(p, spot(p, -1, 0, 2.2) || p.location, E[0].location);
  await pause(16); flash(p); sound(p, "block.amethyst_block.chime", 1);
  for (const e of E) { act(e, move); emote(e, "spark"); } await pause(24);
  for (const e of E) await fade(e, "minecraft:endrod");
}
/* 魔将が 遠くから 歩いて くる */
async function entrance(p, C, i, run = false) {
  const e = C.npc("§4" + TK_NAME[i], PJ(TK_SK[i], 8), 9); if (!e) return null;
  lookAt(p, e); await go(e, spot(p, 3.5, 0), run ? 10 : 20, run); return e;
}
const hsay = async (p, C, L) => { if (C.hn) await talk(p, C.hn, L, "§d"); };

/* 戦う 前 */
export function tkPre(p, i) { return calm(p, () => scene(p, (C) => _tkPre(p, i, C))); }
async function _tkPre(p, i, C) {
  const d = load(p); if (!d) return;
  const r = ruOf(d); r.rec = r.rec || [];
  if (i < 10) {
    if (!r.rec.includes(i)) {   /* 石の 人が 本を 抱いて いる → カメラが 寄る → 本を 読む */
      const st = C.npc("", PJ(STONE[i % STONE.length], 8), 3, -2); act(st, i === 7 ? "guard" : i === 8 ? "run" : "hold");
      if (st) { camAt(p, spot(p, 1.4, -1.2, 1.6) || p.location, { x: st.location.x, y: st.location.y + 1.2, z: st.location.z }); await pause(20); }
      await narr(p, `石の 人の 記録（${TK_EPI[i]}）`, ["§7区の 入口に、石に なった 人が 一冊の 本を 抱いて いた。", "", RECORD[i]]); r.rec.push(i); save(p, d);
      try { if (st) st.remove(); } catch {}
    }
    const H = C.hero();
    if (i === 3) {   /* カメリオ: いつの まにか 真後ろに */
      const e = C.npc("§4" + TK_NAME[i], PJ(TK_SK[i], 8), -2.2, 0); act(H, 0);
      await say(p, TK_NAME[i], [PRE[i][0]], "§4");
      await hsay(p, C, ["{shock,!,jump}ひゃっ！？ い、いつから 後ろに いたの！？"]);
      flash(p, "0 0 0"); if (e) await go(e, spot(p, 3.5, 0), 3);
      await say(p, TK_NAME[i], PRE[i].slice(1), "§4");
      return;
    }
    if (i === 8) {   /* ヨル: 声だけ → 足もとの 影から 出る */
      sound(p, "mob.vex.ambient", 1); await shadowFlow(p, spot(p, 8, -3), spot(p, 3.5, 0), 12);
      const e = C.npc("§4" + TK_NAME[i], PJ(TK_SK[i], 8), 3.5); flash(p, "0 0 0");
      await say(p, TK_NAME[i], PRE[i], "§4");
      act(H, "guard"); await hsay(p, C, ["{angry,怒}鬼ごっこ なら 負けないよ。……絶対 つかまえて あげる！"]);
      return;
    }
    const e = await entrance(p, C, i, i === 4 || i === 7);
    if (i === 0) { act(e, "kneel"); await pause(10); act(e, 0); }   /* 白い 仮面を 外して 足もとに 置く */
    if (i === 4 || i === 7) { shake(p, 0.6, 0.5); if (e) await wave(p, e.location); }
    if (i === 6) fx(p.dimension, "minecraft:snowflake_particle", p.location, 20, 4);
    await say(p, TK_NAME[i], PRE[i], "§4");
    if (i === 2) {   /* 花は 人の 形の 土から 生えて いた */
      const q = spot(p, 4.5, 2); if (q) { camAt(p, { x: q.x - 1, y: q.y + 1.2, z: q.z - 1 }, q); fx(p.dimension, "minecraft:spore_blossom_ambient_particle", q, 10, 0.8); await pause(16); }
      await narr(p, TK_EPI[i], ["§7（花は 人の 形の 土から 生えて いた）"]);
      act(H, "guard"); await hsay(p, C, ["{rage,怒,jump}……ちょっと。これの どこが『きれい』なの！"]);
    }
    if (i === 4) { act(H, "recoil"); await hsay(p, C, ["{shock,汗,jump}た、食べ物 扱い！？ わたしは おいしくないからね！？"]); }
    if (i === 5) { for (let k = 0; k < 3; k++) { sound(p, "random.click", 1); await pause(10); } flash(p); shake(p, 0.4, 0.3); }
    if (i === 7) { sound(p, "ambient.weather.thunder", 1); flash(p); }
    if (i === 0) { shake(p, 0.4, 0.4); }
  } else {   /* 石門: 地面が ゆれて 番兵が 立ち上がる */
    sound(p, "mob.ravager.roar", 0.7); shake(p, 0.7, 0.8); await wave(p, spot(p, 6, 0) || p.location);
    lookUp(p, spot(p, 7, 0, 5) || p.location);
    await narr(p, TK_EPI[i], ["§7石の 門の 前に、門を 守る 魔物が 立って いる。", "§8門の 柱には、三千年前の 落書きが 残って いた。§7「明日 また 遊ぼうね」"]);
  }
}

/* 勝った あと（その 区の 石が とける） */
export function tkPost(p, i, n) { return calm(p, () => scene(p, (C) => _tkPost(p, i, n, C))); }
async function _tkPost(p, i, n, C) {
  const d = load(p); if (!d) return;
  const r = ruOf(d), s = qs(d);
  big(p, "§b§l石が とける", `§f${TK_EPI[i]}の 人々が 一瞬だけ 動いて、消えて いく`, "block.amethyst_block.chime");
  const H = C.hero();
  const boss = (pose = "kneel") => { const e = i < 10 ? C.npc("§4" + TK_NAME[i], PJ(TK_SK[i], 8), 3.5) : null; act(e, pose); return e; };
  if (i === 0) {   /* 第113版: 仮面の 戦士の 正体（雪山の 双子を 返す） */
    const e = boss("kneel");
    await say(p, TK_NAME[0], ["{closed,…}（札）『……やっと 声を 出しても いいか』"], "§4");
    act(e, 0); flash(p);   /* 初めて 口を 開く */
    await say(p, TK_NAME[0], ["{sad,up}……雪山で、器を 探せと 命じられた。記録の 神の 器を。", "{closed}あの 双子は、互いの 名前しか 呼ばなかった。……器には ならぬ。区の はずれで 眠らせて ある。", "{smile,tears,up}連れて 帰れ。……ありがとう"], "§4");
    await narr(p, "双子", ["§7アルゴは 仮面を 残して、消えた。"]); await fade(e, "minecraft:endrod");
    const ru = C.npc("§dルウ", PJ("ruu", 9), 4, -0.7), ro = C.npc("§9ロウ", PJ("rou", 9), 4, 0.7); act(ru, "down"); act(ro, "down");
    if (ru) { camAt(p, spot(p, 2.5, -1.5, 1.4) || p.location, ru.location); await pause(20); }
    act(ru, 0); await talk(p, "ルウ", ["{closed}……ロウ。おはよう"], "§d");
    act(ro, 0); await talk(p, "ロウ", ["{blush,…}……ルウが 言うなら、本当だ"], "§9");
    await hsay(p, C, ["{smile,♪}……よかった。ほら、早く 帰ろ！ 二人とも！"]);
    const out = spot(p, 12, 0); if (out) await Promise.all([go(ru, out, 30), go(ro, { x: out.x + 1, y: out.y, z: out.z }, 30)]);
    s.twinsBack = 1;
  } else if (i === 2) {   /* ドロスの 花壇・リリの 姉妹 */
    const e = boss("sad"); shake(p, 0.6, 0.6); sound(p, "random.explode", 0.4); await wave(p, spot(p, 5, 2) || p.location, "minecraft:basic_smoke_particle");
    const L = [C.npc("", PJ("lili2", 9), 5, 1), C.npc("", PJ("lili3", 9), 5.5, 2.2), C.npc("", PJ("lili4", 9), 5, 3.4)]; for (const x of L) act(x, "down");
    if (L[0]) { camAt(p, spot(p, 3, 2.2, 1.5) || p.location, L[1] ? L[1].location : L[0].location); await pause(24); }
    await narr(p, "花壇", ["§7花壇の 土が 崩れた。中から、§9紺色の、協会の 制服§7 の 切れはしが 三つ。"]);
    await hsay(p, C, ["{shock,!,jump}……この 顔、受付の リリさんと 同じ……！？"]);
    await say(p, TK_NAME[2], ["{sad,?}みんな、きれいに 咲いたのに。……どうして 枯らすの"], "§4");
    act(H, "guard"); await hsay(p, C, ["{rage,怒,low}……あんたが 言うな！"]);
    for (const x of L) await fade(x, "minecraft:cherry_leaves_particle"); await fade(e, "minecraft:basic_smoke_particle");
    await narr(p, "リリの 姉妹", ["§7（五つ子の うち 三人は、ここで 花の 養分に されて いた）", "§7受付で 何度も 聞いた『姉が 帰って こないの』の 答えが、これだった。", "§8……残った 二人に、何と 伝えれば いいのだろう。"]);
    s.liliSis = 1;
  } else if (i === 3) {   /* カメリオの 正体: 顔が 案内人に かわり、最後に 崩れる */
    const e = boss("kneel");
    await say(p, TK_NAME[3], ["{smile}負けちゃった。……ねえ、レイくんが 言ってたでしょ。『後ろに 誰か 立ってなかったか』って。", "{smile,…,up}ぼくだよ。ずっと 見てた。きみには ささやきが 届かない。だから 器には ならない。……でも、きみの §e相棒§f は ちがうかもね", "{smile,♪,low}ヴォルナグさまは、もう 決めてる。§c相棒を もらう§f って"], "§4");
    act(H, "guard"); await hsay(p, C, ["{rage,怒,jump}ふざけないで！ あの 子は 誰にも あげない！"]);
    if (e) { lookAt(p, e); flash(p); try { setJob(e, PJ("toma", 8)); e.nameTag = "§e案内人"; } catch {} await pause(20); flash(p, "0 0 0"); try { setJob(e, 0); e.nameTag = ""; } catch {} await pause(14); await knock(e, p.location, 0.5); await fade(e, "minecraft:basic_smoke_particle"); }
    await narr(p, "案内人", ["§7案内人の 顔が、§8最後に 誰でも ない 顔に なって 崩れた。"]);
    s.camelio = 1;
  } else if (i === 8) {   /* 遊び場: 子どもたちが 一度 笑って 消える・相棒が ボールを くわえて 戻る */
    await melt(p, C, 4, "run", "cheer");
    const m = palOf(d); const pm = m ? C.mon(m.sp, 7, 2) : null;
    if (pm) { lookAt(p, pm); await go(pm, spot(p, 1.5, 0.6), 24); emote(pm, "q"); }
    await narr(p, "遊び場", ["§fあなたの 相棒が、転がって きた ボールを くわえて 戻って きた。", "§8……渡す 相手は、もう いなかった。"]);
    await hsay(p, C, ["{sad,…}……うん。いい子。……持って 帰ろっか、それ。"]);
  } else if (i === 9) {   /* 王妃セレネ */
    const e = boss(0);
    await say(p, "王妃 セレネ", ["{sad,?,up}……あの人。あなた、まだ そこに いるの？"], "§d");
    flash(p, "255 200 80"); sound(p, "beacon.power", 0.8); fx(p.dimension, "minecraft:totem_particle", p.location, 12, 0.6); await pause(10);
    await narr(p, "厄王の ささやき", ["§6石板の 奥から、一度だけ 返事が あった。", "§6「§fもういい。一日は 終わるから、楽しかった§6」"]);
    await say(p, "王妃 セレネ", ["{smile,tears,up}……そう。楽しかった、のね。", "{smile,closed}わたしも。"], "§d");
    await fade(e, "minecraft:white_smoke_particle");
    const mi = C.npc("", PJ("mira", 8), 4, 1.5); act(mi, "bow"); if (mi) { lookAt(p, mi); await pause(24); await fade(mi, "minecraft:endrod"); }
    await narr(p, "王宮の区", ["§7王妃は 笑って、灰に なった。侍女 ミラの 石像が とけて、王妃の 灰に 頭を 下げて、消えた。"]);
  } else if (POST[i]) {
    const [a, b, kind] = POST[i]; const e = boss(kind === "bolt" ? "raise" : "kneel");
    await say(p, i < 10 ? TK_NAME[i] : TK_EPI[i], [a], "§4");
    if (kind === "clap") await melt(p, C, 3, "hold", 6);
    else if (kind === "bread" && e) { fx(p.dimension, "minecraft:villager_happy", e.location, 10, 1); await knock(e, p.location, 1); }
    else if (kind === "clock") { sound(p, "block.bell.hit", 1); await pause(10); sound(p, "block.bell.hit", 1); flash(p); }
    else if (kind === "snow" && e) fx(p.dimension, "minecraft:snowflake_particle", e.location, 20, 1);
    else if (kind === "bolt") { sound(p, "ambient.weather.thunder", 1); flash(p); shake(p, 0.6, 0.4); if (e) fx(p.dimension, "minecraft:electric_spark_particle", e.location, 16, 0.8); }
    if (e) await fade(e, kind === "snow" ? "minecraft:snowflake_particle" : "minecraft:white_smoke_particle");
    await narr(p, TK_EPI[i], [b]);
  } else { shake(p, 0.4, 0.4); await melt(p, C, 2, "guard", "bow"); await narr(p, TK_EPI[i], ["§7門の 石が とけ、門番の 魔物は 静かに 崩れた。"]); }
  /* 5区め: エンマの 妹 */
  if (n >= 5 && !s.sisterDone) {
    big(p, "§4§lエンマの 妹", "§f石の 少女が 立って いる", "mob.wither.ambient");
    const g = C.npc("§dエンマの 妹", PJ("sayo", 9), 4.5, 0); act(g, "hold");
    if (g) { lookAt(p, g); await pause(20); }
    /* 鍔から 赤い 火が 立ちのぼり、エンマが 姿を 見せる */
    flash(p, "120 0 0"); shake(p, 0.5, 0.5); sound(p, "mob.wither.spawn", 0.4);
    const en = C.mon("enma", 2.5, -1.8); if (en) { fx(p.dimension, "minecraft:basic_flame_particle", en.location, 14, 0.7); lookAt(p, en); }
    await hsay(p, C, ["{shock,!,jump}エ、エンマ！？ 鍔から 出て きた……！"]);
    await say(p, "エンマ", ["……§eサヤ§f。"], "§4");
    if (g) { fx(p.dimension, "minecraft:endrod", g.location, 10, 0.5); act(g, 0); }   /* 名前を 呼ぶと 石が とけはじめる */
    await say(p, "エンマの 妹", ["{closed}……兄さま。", "{smile,tears,up}鍔、つけて もらえたのね。"], "§d");
    await fade(g, "minecraft:white_smoke_particle");
    await narr(p, "灰", ["§8少女は 一言だけ 言って、§7灰に なった。§8……千年前に、もう 死んで いた。", "§c「あの ささやきは、妹が 生きて いると 嘘を ついた」"]);
    if (en) { emote(en, "dots"); fx(p.dimension, "minecraft:white_smoke_particle", en.location, 8, 0.5); await pause(16); }
    await say(p, "エンマ", ["……償う。生きて。"], "§4");
    await fade(en, "minecraft:basic_flame_particle");   /* 妹の 灰を 鍔に 抱いて 刀へ もどる */
    s.enmaAlly = 1; s.sisterDone = 1; save(p, d);
  }
  /* 全部 とけた: セイルの 告白・セオ */
  if (n >= 15 && !s.seilDone) {
    big(p, "§5§lセイルの 告白", "", "ambient.cave");
    const eS = C.npc("§5神官 セイル", PJ("seil", 13), 4); act(eS, "sad");
    await say(p, "神官 セイル", ["{closed,…}……全部、とけたのか。数えて いたよ。あと 何人、石の まま か。……ゼロだ。", "{sad,up}あなたに 言わなければ いけない ことが ある。", "{cry,up}王妃に『§d永遠を 願う 祈り§f』を 教えたのは、§c私§f だ。", "{closed,low}あの 祈りが、ヴォルナグを 呼んだ。……私が、最初に 祈った"], "§5");
    await hsay(p, C, ["{shock,!,jump}……え。今、なんて……？"]);
    const seo = C.npc("§aセオ", 18, 11, 1.5); if (seo) { lookAt(p, seo); await go(seo, spot(p, 3.5, 1.5), 12, true); }
    await say(p, "セオ", ["{sweat,息,jump}セイル……さん。僕は、あなたの 子孫です。", "{cry,up}あなたの メモを 読んで、僕も 同じ ことを した。……ごめんなさい。僕たちは 二人とも"], "§a");
    act(eS, 0); await say(p, "神官 セイル", ["{smile,up}……そうか。ならば 最後の 祈りを 教えよう。", "{closed}記録塔の 扉は、記録でしか 開かない。§e私を 一頁に する§f。", "{smile,tears,up}セオ。嘘を 書かない 歴史を 書きなさい。それが、私たちの 罰だ"], "§5");
    s.seilDone = 1; save(p, d);
    flash(p); sound(p, "item.book.page_turn", 1); await fade(eS, "minecraft:endrod");   /* 一枚の 紙に なって 扉へ */
    act(seo, "kneel");
    await narr(p, "最後の 頁", ["§7セイルの 体が、一枚の 紙に なって、記録塔の 扉に 吸いこまれた。§f扉が 開いた。", "§7セオは 扉の 前で、紙の 切れはしを 拾って、長い あいだ 動かなかった。"]);
  }
  save(p, d);
}

/* 最終戦の 前: 邪神が 相棒に 取りつく。きずなで 有利・不利 */
const TIERS = [0, 80, 250, 600, 900];
export function palOf(d) { return [...(d.party || []), ...(d.bench || []), ...(d.box || [])].find((m) => m && (m.id === d.partnerId || m.partner || m.look)) || null; }
export function tkFinalPre(p) { return calm(p, () => scene(p, (C) => _tkFinalPre(p, C))); }
async function _tkFinalPre(p, C) {
  const d = load(p); if (!d) return { wk: 0, add: [] };
  const m = palOf(d);
  const H = C.hero();
  const pm = m ? C.mon(m.sp, 2, 1.5) : null;
  /* 玉座の 上の 影を 見上げる */
  sound(p, "mob.wither.ambient", 0.8); fx(p.dimension, "minecraft:soul_particle", spot(p, 7, 0, 3) || p.location, 20, 2);
  lookUp(p, spot(p, 8, 0, 6) || p.location);
  await say(p, "邪神 ヴォルナグ", ["……よく 来ました。覚えて おいて あげましょう。", "わたしは §5記録の 神§f。すべてを 書き留め、何ひとつ 忘れない 神。", "三千年前、ほかの 神々に 名前を 消される 前に、自分で 頁を 破りました。荒野の 壁画の 影も、わたしが 削った。……消えて しまえば、だれも 追って こられない", "王に、エンマに、セイルに、セオに ささやいたのも わたし。失くした ものを 返すと 言えば、皆 わたしの 頁を 書いて くれる", "あなたには、わたしの ささやきが 届かない。……さびしい ことです", m ? `だから、その 子を いただきます。§e${m.nm || SPECIES[m.sp]?.name}§f。……ほら、あなたを 呼んで いますよ` : "……おや、ひとりですか。"], "§5");
  if (!m) return { wk: 0, add: [] };
  let nk = 0; try { nk = Number((exOf(p).nk || {})[m.id]) || 0; } catch {}
  const t = TIERS.filter((v) => nk >= v).length - 1;
  const nm = m.nm || SPECIES[m.sp]?.name;
  /* 黒い 霧が 相棒を 包む → 相棒が 牙を むき、衝撃で はじかれる */
  if (pm) { await shadowFlow(p, spot(p, 8, 0) || p.location, pm.location, 12); lookAt(p, pm); for (let k = 0; k < 10; k++) { const l = pm.location; fx(p.dimension, k % 2 ? "minecraft:soul_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(k) * 1.2, y: l.y + 0.3 + k * 0.1, z: l.z + Math.sin(k) * 1.2 }, 3, 0.2); await pause(2); } }
  sound(p, "mob.wolf.growl", 1); flash(p, "40 0 60"); shake(p, 0.7, 0.6); if (pm) { knockP(p, pm.location); await knock(H, pm.location, 2); }
  await narr(p, "取りつかれた 相棒", [`§5黒い 霧が §e${nm}§5 を 包んだ。`, `§e${nm}§f が こちらを 向いて、§c${p.name}§f の 名前を 呼びながら 牙を むく――`]);
  if (H) { act(H, "guard"); await talk(p, C.hn, [`{rage,怒,jump}${nm}！ しっかり して！ ……その 子を 返しなさいよ！`], "§d"); }
  let wk = 0, line;
  if (t >= 3) { wk = 3; line = `§a${nm}は 霧の 中で もがいて いる。§f中から 何度も、あなたを 呼び返して いる！ §7（きずなが 強い: 邪神の HP −30%）`; }
  else if (t >= 2) { wk = 1; line = `§e${nm}は 霧に 抵抗して いる。§7（きずな「相棒」: 邪神の HP −10%）`; }
  else { wk = -2; line = `§c${nm}は 霧に 呑まれかけて いる……！ §7（きずなが 弱い: 邪神の HP +20%。ガイドブックの きずなを 深めて 来ると 有利に なる）`; }
  /* 第113版: 森の 精霊の「守り手の 印」――二人で 一つ。ささやきは 片方（相棒）にしか 届かない。届かない あなたが 呼び戻す */
  const s0 = qs(d), mark = !!((s0.gate || {})[1] || (s0.keys || []).includes("k_spirit"));
  if (mark) {
    flash(p, "255 220 120"); sound(p, "beacon.activate", 1); fx(p.dimension, "minecraft:totem_particle", p.location, 12, 0.5); if (pm) fx(p.dimension, "minecraft:totem_particle", pm.location, 12, 0.5);
    await narr(p, "守り手の 印", [`§6あなたの 手の甲と、§e${nm}§6 の 額に、同じ 形の 光が 浮かんだ。`, "§7森の 精霊の 声が よみがえる。§a『この 子と あなた、二人で 一つの 印。片方が 呑まれても、もう 片方が 呼べば 戻れる』", `§f……${nm} の 名前を、呼んだ。`]);
    if (pm) emote(pm, "heart");
    await say(p, `${nm}（相棒）`, [`……${p.name}。`, "……きこえる。ここ、だよ。"], "§e");
    if (wk < 0) { wk = 0; line = `§6守り手の 印が 霧を おさえた。§7（きずなが 弱くても、邪神の HP は ふえない）`; }
  }
  await narr(p, "きずな", [line]);
  return { wk, add: [{ sid: m.sp, lv: m.lv, q: 1, plus: Math.min(99, (m.plus || 0) + 10) }], pal: nm, t, sp: m.sp };
}
export function tkFinalPost(p, info) { return calm(p, () => scene(p, (C) => _tkFinalPost(p, info, C))); }
/* エピローグの 一場面ずつ（人を 1人 立たせて カメラを 寄せる）*/
const EPI = [
  ["§cムサシ", 19, "raise", "§cムサシ§f は クロガネで、§e封じる ためでは ない 鍔§f を 打った。エンマの 墓に 供える ために。", "block.anvil.use"],
  ["§4エンマ", null, null, "§4エンマ§f は 妹の 灰を 鍔に 抱いて、ムサシの 隣を 歩いて いる。"],
  ["§aセオ", 18, "hold", "§aセオ§f は 嘘を 書かない 歴史書を 書きはじめた。最初の 頁には、セイルと 家族の 名前。", "item.book.page_turn"],
  ["§bレイ", 17, "point", "§bレイ§f は しくじり帳の 最後の 頁に、竜の 石像の 絵を 描いた。§7その 朝、本物の 石像に、小さな ひびが 入った。"],
  ["", null, null, "§a森の 精霊§f は 精霊石の 中で 目を さまし、シルヴァの 森へ 帰った。"],
  ["§6ナギサ", "nagisa", "point", "§6ナギサ§f は 港で、マリンに 潮の 時刻を 教えて いる。§9ロウ§f と §dルウ§f は、同じ 家で 暮らしはじめた。"],
  ["§7カゲツ", "kagetsu", "down", "§7そして カゲツは、ようやく ぐっすり 眠って いる。"],
];
async function _tkFinalPost(p, info, C) {
  if (!info || !info.pal) return;
  const H = C.hero();
  const pm = info.sp ? C.mon(info.sp, 5, 0) : null;
  flash(p); if (pm) { lookAt(p, pm); await go(pm, spot(p, 1.4, 0), 14); emote(pm, info.t >= 2 ? "heart" : "q"); }
  await narr(p, "霧が 晴れる", [`§f黒い 霧が ほどけ、§e${info.pal}§f が 足もとに 転がって きた。`, info.t >= 2 ? "§a……しっぽを 振って、あなたの 手を なめた。" : "§7……しばらく ぼんやりして いたが、やがて あなたの 匂いを かいで、そばに 座った。"]);
  await say(p, `${info.pal}（相棒）`, ["……ただいま。"], "§e");
  if (H) await talk(p, C.hn, ["{cry,tears,jump}……もう！ 心配 させないでよ、ばか！ ……おかえり！"], "§d");
  shake(p, 0.4, 1.2); fx(p.dimension, "minecraft:soul_particle", spot(p, 7, 0, 3) || p.location, 20, 2); lookUp(p, spot(p, 8, 0, 6) || p.location);
  await say(p, "邪神 ヴォルナグ", ["……ああ。消える。忘れられて しまう。", "わたしは、ただ…… 誰の ことも、忘れたく なかった"], "§5");
  flash(p); sound(p, "item.book.page_turn", 1); fx(p.dimension, "minecraft:endrod", p.location, 24, 4);
  await narr(p, "白紙", ["§f世界じゅうの 石板の 文字が、すうっと 消えて いった。", "§7すべての 石板が §f白紙§7 に なった。", "§e記録は 封じる ものでは なく、終わらせる ものだった。"]);
  for (const [nm, job, pose, line, snd, after] of EPI) {   /* 場面を 切りかえて 一人ずつ */
    let e = null;
    if (nm === "§4エンマ") e = C.mon("enma", 3.5, 0); else if (job !== null) e = C.npc(nm, typeof job === "string" ? PJ(job, 8) : job, 3.5, 0);
    flash(p, "0 0 0"); if (e) { act(e, pose); camAt(p, spot(p, 1.5, 1.2, 1.5) || p.location, { x: e.location.x, y: e.location.y + 1.3, z: e.location.z }); } else fx(p.dimension, "minecraft:villager_happy", spot(p, 4, 0) || p.location, 10, 2);
    if (snd) sound(p, snd, 1);
    await narr(p, "エピローグ", [line]);
    if (e && after !== undefined) { act(e, after); emote(e, "bang"); await pause(14); }
    if (e) { try { e.remove(); } catch {} }
  }
}
/* 第116版: 常世から 戻った 朝。ルミナの 牧場で 石に なった 者たちが 戻る（1回だけ・印 stoneBack） */
export async function tkStoneBack(p) {
  const d = load(p); if (!d) return false; const s = qs(d); if (s.stoneBack) return false;
  s.stoneBack = 1; save(p, d);
  await calm(p, () => scene(p, (C) => _tkStoneBack(p, C)));
  return true;
}
async function _tkStoneBack(p, C) {
  try { p.runCommand("camera @s fade time 0.5 1.0 0.8 color 255 255 255"); } catch {}
  big(p, " ", "§7― 常世から 戻った 朝 ルミナの 牧場 ―");
  const Hk = C.mon(HAKU_SP, 5, 0.6), Dr = C.mon(REI_DRAGON_SP, 6.5, 3.2), Pc = C.npc("§dピコ", PJ("pico", 8), 4.2, -0.6), G = C.npc("§7ガロ", PJ("garo", 9), 3.2, -2.2), O = C.npc("§eオルド", PJ("ordo", 8), 3.4, 2), R = C.npc("§bレイ", 17, 4.6, 3.6), H = C.hero();
  const hs = async (L) => { if (C.hn) await talk(p, C.hn, L, "§d"); };
  for (const [e, n] of [[Hk, "§7ハク（石）"], [Dr, "§7竜の 石像"]]) if (e) try { e.nameTag = n; } catch {}
  act(Pc, "down"); act(G, "sad"); act(O, "hold"); act(R, "hold"); stoneFx(p, Hk, 8); stoneFx(p, Dr, 8);
  if (Hk) camAt(p, spot(p, 1.4, -1.6, 1.8) || p.location, { x: Hk.location.x, y: Hk.location.y + 1, z: Hk.location.z });
  await pause(20);
  await narr(p, "ルミナの 牧場", ["§7牧場の すみに、石の §fハク§7 と、§fレイの 竜§7 の 石像。", "§7ハクの 背中に もたれて、§dピコ§7 が 眠って いる。§8（ガロが 『ここが いちばん あったかい』と 座らせた 場所だ）"]);
  /* ぴしっ。石が 割れる */
  sound(p, "random.break", 1); shake(p, 0.25, 0.4); if (Hk) emote(Hk, "bang"); await pause(14);
  await hs(["{shock,!,jump}……今、ぴしって 鳴った！？"]);
  sound(p, "dig.stone", 1); stoneFx(p, Hk, 14); shake(p, 0.35, 0.6); await pause(10);
  flash(p); sound(p, "random.levelup", 0.8); if (Hk) { fx(p.dimension, "minecraft:totem_particle", Hk.location, 16, 1); try { Hk.nameTag = "§fハク"; } catch {} }
  await narr(p, "白い 毛", ["§fハクの 背中の 灰色が、ひびの ように 割れて 落ちて いく。", "§fその 下から、§l白い 毛§r§f が のぞいて いた。"]);
  if (O) { await go(O, spot(p, 4.4, 1.2), 10, true); act(O, "kneel"); }
  if (Hk) emote(Hk, "heart");
  await talk(p, "オルド", ["{shock,…,up}……ハク。", "{smile,tears,up}ほっほ……ほっほっほ！ ……遅いわい、この 寝ぼすけ が！"], "§e");
  await narr(p, "二十年分", ["§7オルドは ハクの 首に しがみついて、二十年分の 「ほっほ」を、一度に 笑った。"]);
  /* 竜の あくび */
  if (Dr) { lookAt(p, Dr); stoneFx(p, Dr, 14); sound(p, "mob.enderdragon.growl", 0.35); try { Dr.nameTag = "§bレイの 竜"; } catch {} emote(Dr, "q"); }
  await narr(p, "竜", ["§f隣では、レイの 竜が 大きな §eあくび§f を した。"]);
  if (R) { act(R, "up"); await talk(p, "レイ", ["{shock,!,jump}……おまえ……！", "{cry,tears,up}……寝坊 しすぎだ、ばか。"], "§b"); }
  /* ピコが 目を さます */
  if (Pc) { lookAt(p, Pc); act(Pc, 0); emote(Pc, "q"); }
  await talk(p, "ピコ", ["{closed,…}……兄ちゃん？", "{shock,?}……ここ、どこ？ 屋根、ある ね"], "§d");
  if (G && Pc) { await go(G, spot(p, 3.6, -1.4), 10, true); act(G, "hold"); }
  await narr(p, "帽子", ["§7ガロは 何も 言わずに、腰から 帽子を 外して、ピコの 頭に 深く かぶせた。", "§8ガロが 顔を 上げた ときには、もう いつもの 仏頂面に 戻って いた。"]);
  if (Pc) emote(Pc, "heart");
  if (H) { act(H, "cheer"); await hs(["{cry,tears,jump}ハク……！ ピコくん……！ ……もう、みんな 寝坊 しすぎ！"]); }
  /* 各地でも */
  flash(p, "0 0 0"); lookUp(p, spot(p, 8, 0, 8) || p.location); sound(p, "beacon.activate", 0.8);
  for (let k = 0; k < 5; k++) { fx(p.dimension, "minecraft:endrod", spot(p, 4, 0, 3 + k) || p.location, 6, 5); await pause(4); }
  await narr(p, "各地で", ["§f石に なって いた 人たちも、各地で 目を さました。", "§aベリルの 村§f も、§aセオの 町§f も、宵闇の §aヨミ§f も。", "§7ベリルからは 手紙が 届いた。§f『ただいまって 言えた』§7 とだけ、書いて あった。"]);
  /* 手帳の 名簿に おかえり */
  if (H) {
    if (C.hn) { lookAt(p, H); act(H, "hold"); sound(p, "item.book.page_turn", 1); }
    await narr(p, "手帳の 名簿", [`§d${C.hn}§f は 手帳の 名簿を 最初の 頁から 一人ずつ たどった。`, "§fそして、一人ずつの 名前の 横に、小さく 書きこんで いった。", "§e『おかえり』"]);
    act(H, "talk"); await hs(["{smile,☆}……最後の 頁は、まだ 白紙。", "{smile,♪,jump}次は どこ 行く？ コンパスの 作り主は、まだ ついて いく つもり だからね！"]);
  } else await narr(p, "手帳の 名簿", ["§f旅の 名簿の 一人ずつの 名前の 横に、小さく 書きこんだ。§e『おかえり』"]);
  big(p, "§b§lおかえり", "§f石に なった 者たちが 帰って きた", "random.levelup");
  await pause(30);
}
