// v2.9.11: 作戦と 技の 好み（◎よく使う・○使う・×使わない）
import { MOVES } from "./data.js";
import { TACTICS, TAC_DESC, tacOf, getMoves, moveDesc, battleMoves, MSET_MAX } from "./core.js";
import { choose, paged, ICON, MON_ICON, notice, LINE } from "./ui.js";
const MARK = { 2: "§a◎", 1: "§f○", 0: "§c×" };
const NEXT = { 1: 2, 2: 0, 0: 1 };
export const prefOf = (m, id) => (m.mpref && m.mpref[id] !== undefined ? m.mpref[id] : 1);
function setPref(m, id, v) { m.mpref = m.mpref || {}; if (v === 1) delete m.mpref[id]; else m.mpref[id] = v; if (!Object.keys(m.mpref).length) delete m.mpref; }
export function prefSummary(m) {
  const p = m.mpref || {}; const fav = Object.entries(p).filter(([, v]) => v === 2).length, no = Object.entries(p).filter(([, v]) => v === 0).length;
  return fav || no ? `§a◎${fav} §c×${no}` : "§7好み なし";
}
// 技ごとの 好み
export async function movePrefMenu(p, m, save) {
  for (;;) {
    const ids = ["_atk", ...battleMoves(m)];   // 第65版: 戦いで 使う 6つだけ
    const name = (id) => (id === "_atk" ? "ふつうの 攻撃" : MOVES[id]?.name || id);
    const body = [`§l${m.nm}§r の 技の 好み`, "§7（戦いで 使う 6つの 技だけ。入れかえは「戦いで 使う 技」）", "§fオートで 戦う ときに 使われます。押すたびに §a◎よく使う §f→ §c×使わない §f→ ○使う", "§7◎は 役に 立つ 場面で 優先して 使う。×は ぜったいに 使わない（ふつうの 攻撃も ×に できる）", LINE].join("\n");
    const btn = ids.map((id) => [`${MARK[prefOf(m, id)]} §r§l${name(id)}${id !== "_atk" && MOVES[id] ? ` §8MP${MOVES[id].mp || 0}` : ""}\n§8${id === "_atk" ? "武器や 体で なぐる" : String(moveDesc(id, true) || "").replace(/§./g, "").replace(/^【[^】]*】(【[^】]*】)?/, "").trim().slice(0, 26)}`, ICON(id === "_atk" ? "i_fight" : "i_spell")]);
    btn.push(["§7ぜんぶ ○に もどす", ICON("i_close")], ["§7戻る", ICON("i_back")]);
    const s = await paged(p, "技の 好み", body, btn, 16);
    if (s < 0 || s === ids.length + 1) return;
    if (s === ids.length) { delete m.mpref; save(); continue; }
    if (s >= 0 && s < ids.length) { setPref(m, ids[s], NEXT[prefOf(m, ids[s])]); save(); }
  }
}
// v3.0: 戦いで 使う 技（6つまで）。覚えた 技の 中から えらぶ。えらばない 枠は おまかせ（強い 技・回復・補助を 自動で）
export function moveSetSummary(m) { const n = getMoves(m).length; return Array.isArray(m.mset) ? `${m.msetFix ? "§b自分で" : "§aおまかせ＋"} ${Math.min(MSET_MAX, battleMoves(m).length)}/${MSET_MAX}` : n > MSET_MAX ? `§7おまかせ ${MSET_MAX}/${n}` : `§7${n}/${MSET_MAX}`; }
export async function moveSetMenu(p, m, save) {
  for (;;) {
    const all = getMoves(m), use = battleMoves(m), mine = Array.isArray(m.mset) ? m.mset.filter((id) => all.includes(id)) : [];
    const name = (id) => MOVES[id]?.name || id;
    const body = [`§l${m.nm}§r の 戦いで 使う 技 §7（${use.length}/${MSET_MAX}・覚えた 技 ${all.length}）`,
      "§f押すと 入れる／はずす。§a●§f=自分で 入れた　§e◆§f=おまかせで 入って いる　§8○§f=使わない",
      `§7空いた 枠は ${m.msetFix ? "§b空けた まま（おまかせ なし）" : "§aおまかせで うめる"}§7。戦いでは この ${MSET_MAX}つ（と ふつうの 攻撃）だけ 使える`].join("\n");
    const mark = (id) => (mine.includes(id) ? "§a● " : use.includes(id) ? "§e◆ " : "§8○ ");
    const btn = all.map((id) => [`${mark(id)}§r§l${name(id)} §8MP${MOVES[id]?.mp || 0}\n§8${String(moveDesc(id, true) || "").replace(/§./g, "").slice(0, 40)}`, ICON(MOVES[id]?.kind === "attack" ? "i_fight" : "i_spell")]);
    btn.push([m.msetFix ? "§a空いた 枠を おまかせで うめる" : "§b空いた 枠は 空けて おく", ICON("i_skill")], ["§7ぜんぶ おまかせに もどす", ICON("i_close")], ["§b技の くわしい 効果を 見る", ICON("i_spell")], ["§7戻る", ICON("i_back")]);
    const s0 = await paged(p, "戦いで 使う 技", body, btn, 16);
    if (s0 < 0 || s0 === all.length + 3) return;
    if (s0 === all.length + 2) {   // 第67版
      for (;;) { const q = await paged(p, "技の 効果", "§7見たい 技を えらぶ", all.map((id) => [`${mark(id)}§r§l${name(id)} §8MP${MOVES[id]?.mp || 0}`, ICON(MOVES[id]?.kind === "attack" ? "i_fight" : "i_spell")]), 16);
        if (q < 0 || q >= all.length) break; await notice(p, name(all[q]), `§l§e${name(all[q])}§r\n${moveDesc(all[q])}`); }   // UX案: 続けて 見られる
      continue;
    }
    if (s0 === all.length) { if (!m.msetFix) { m.mset = battleMoves(m); m.msetFix = 1; } else delete m.msetFix; save(); continue; }   // 空けて おく ときは いまの ${MSET_MAX}つで 固定（技が 0に ならない）
    if (s0 === all.length + 1) { delete m.mset; delete m.msetFix; save(); continue; }
    const id = all[s0]; if (!id) continue;
    const cur = Array.isArray(m.mset) ? m.mset.filter((x) => all.includes(x)) : [];
    if (cur.includes(id)) { if (m.msetFix && cur.length <= 1) { await notice(p, "戦いで 使う 技", "§c最後の 1つは はずせません。§7（技が 0に なる ため）"); continue; } m.mset = cur.filter((x) => x !== id); }   // v3.0
    else if (cur.length >= MSET_MAX) { await notice(p, "戦いで 使う 技", `§c${MSET_MAX}つ まで です。§f先に ほかの 技を はずしてください。`); continue; }
    else m.mset = [...cur, id];
    save();
  }
}
// 1体の 作戦（方針と 技の 好み）
export async function tacticOne(p, m, save) {
  for (;;) {
    const cur = tacOf(m);
    const s = await choose(p, `${m.nm}の 作戦`, [`§fいまの 方針: §e${TACTICS[cur]}§r`, `§7${TAC_DESC[cur] || ""}`, `§f技の 好み: ${prefSummary(m)}`].join("\n"),
      [[`§l戦いで 使う 技（${MSET_MAX}つ）\n§8${moveSetSummary(m).replace(/§./g, "")}`, ICON("i_fight")], ["§l方針を かえる", ICON("i_skill")], ["§l技の 好み（◎○×）", ICON("i_spell")], ["§7戻る", ICON("i_back")]]);
    if (s === 0) { await moveSetMenu(p, m, save); continue; }   // 第65版: いちばん 上に
    if (s === 1) {
      const keys = Object.keys(TACTICS);
      const t = await paged(p, "方針を えらぶ", "§7オートで 戦う ときの 動き方", keys.map((k) => [`${k === cur ? "§a● " : ""}§l${TACTICS[k]}\n§8${TAC_DESC[k] || ""}`, ICON("i_skill")]), 8);
      if (t >= 0 && t < keys.length) { m.tac = keys[t]; save(); }
    } else if (s === 2) await movePrefMenu(p, m, save);
    else return;
  }
}
// 何体も まとめて
export async function tacticsAll(p, mons, save, title = "作戦") {
  for (;;) {
    const s = await choose(p, title, `§e戦闘で 使える 技は 1体 ${MSET_MAX}つまで！§f モンスターを えらんで「戦いで 使う 技」で 決めよう。\n§7方針と 技の 好み（◎○×）は オートで 戦う ときの 動き方。`, [
      ["§l全員の 方針を まとめて かえる", ICON("i_party")], ...mons.map((m) => [`${m.nm}\n§8技 ${moveSetSummary(m).replace(/§./g, "")} ・ ${TACTICS[tacOf(m)]}`, MON_ICON(m.sp)]), ["§7戻る", ICON("i_back")]]);
    if (s < 0 || s > mons.length) return;
    if (s === 0) {
      const keys = Object.keys(TACTICS);
      const t = await paged(p, "全員の 方針", "", keys.map((k) => [`§l${TACTICS[k]}\n§8${TAC_DESC[k] || ""}`, ICON("i_skill")]), 8);
      if (t >= 0 && t < keys.length) { for (const m of mons) m.tac = keys[t]; save(); }
      continue;
    }
    await tacticOne(p, mons[s - 1], save);
  }
}
