// v3.0: 軽量モード（ガイドブックの 設定で オン・オフ）。もとは 別の 軽量化パック
// ・モンスターに しるし（mrpg:lite）を つけ、遠くは かんたんな 形で えがく（リソースパックの 側）
// ・10秒ごとに 遠い 野生モンスター・落ちた アイテムなどを かたづける（オフの ときは 何も しない）
import { world, system } from "@minecraft/server";
import { isLite } from "./ui.js";
const DIMS = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];
const TYPE = "mrpg:monster";
// 設定を かえた ときに、いま いる モンスターの しるしを まとめて かえる
export function applyLiteMark() {
  const on = isLite();
  for (const id of DIMS) {
    let list = [];
    try { list = world.getDimension(id).getEntities({ type: TYPE }); } catch { continue; }
    for (const e of list) try { if (e.isValid() && e.getProperty("mrpg:lite") !== on) e.setProperty("mrpg:lite", on); } catch {}
  }
}
// 読みこまれた とき（遠くの 家・牧場の 子など）にも しるしを あわせる（読みこみの ときだけ 動く）
try { world.afterEvents.entityLoad.subscribe(({ entity: e }) => { try { if (e && e.isValid() && e.typeId === TYPE && e.getProperty("mrpg:lite") !== isLite()) e.setProperty("mrpg:lite", isLite()); } catch {} }); } catch {}
const near = (ps, l, r) => ps.some((p) => Math.abs(p.location.x - l.x) < r && Math.abs(p.location.z - l.z) < r);
const dist = (ps, l) => Math.min(1e9, ...ps.map((p) => Math.hypot(p.location.x - l.x, p.location.z - l.z)));
function clean() {
  if (!isLite()) return;
  const players = world.getAllPlayers().filter((p) => { try { return p.isValid(); } catch { return false; } });
  const np = players.length, CAP = Math.max(8, 16 - Math.max(0, np - 1) * 2), ICAP = Math.max(24, 40 - Math.max(0, np - 1) * 4);
  const ALLI = new Set();   // 第63版: ディメンションを ぜんぶ 見てから まとめて 整理
  for (const id of DIMS) {
    let dim; try { dim = world.getDimension(id); } catch { continue; }
    const ps = players.filter((p) => p.dimension.id === id);
    if (!ps.length) continue;
    let mons = [];
    try { mons = dim.getEntities({ type: TYPE, excludeTags: ["mrpg_pet", "mrpg_battle", "mrpg_boss", "mrpg_npc", "mrpg_masterteam", "mrpg_dg", "mrpg_rare", "mrpg_keep"] }); } catch {}
    for (const e of mons) if (!near(ps, e.location, 28)) try { e.remove(); } catch {}
    try {
      const rest = mons.filter((e) => { try { return e.isValid(); } catch { return false; } });
      if (rest.length > CAP) { rest.sort((a, b) => dist(ps, b.location) - dist(ps, a.location)); for (const e of rest.slice(0, rest.length - CAP)) if (dist(ps, e.location) > 20) try { e.remove(); } catch {} }
    } catch {}
    let items = []; try { items = dim.getEntities({ type: "minecraft:item" }); } catch {}
    // v3.0: 落ちた 物は「みんなから 64 以上 はなれて いて 3分 以上 たった」ものだけ 消す（死んで 落とした 持ち物を すぐ 消さない）
    const now = system.currentTick;
    if (items.length > ICAP) { const old = items.filter((e) => { try { const k = e.id; if (!ISEEN.has(k)) ISEEN.set(k, now); return now - ISEEN.get(k) >= 3600 && dist(ps, e.location) > 64; } catch { return false; } }); old.sort((a, b) => dist(ps, b.location) - dist(ps, a.location)); for (const e of old.slice(0, items.length - ICAP)) try { ISEEN.delete(e.id); e.remove(); } catch {} }
    else for (const e of items) try { if (!ISEEN.has(e.id)) ISEEN.set(e.id, now); } catch {}
    for (const e of items) try { ALLI.add(e.id); } catch {}
    let orbs = []; try { orbs = dim.getEntities({ type: "minecraft:xp_orb" }); } catch {}
    if (orbs.length > 20) for (const e of orbs.slice(20)) try { e.remove(); } catch {}
    let pops = []; try { pops = dim.getEntities({ type: "mrpg:popup" }); } catch {}
    for (const e of pops) if (!near(ps, e.location, 32) || pops.length > 24) try { e.remove(); } catch {}
  }
  if (ISEEN.size > 2000) for (const k of [...ISEEN.keys()]) if (!ALLI.has(k)) ISEEN.delete(k);
}
const ISEEN = new Map();
system.runInterval(clean, 200);   // 10秒に 1回（オフの ときは すぐ もどる）
