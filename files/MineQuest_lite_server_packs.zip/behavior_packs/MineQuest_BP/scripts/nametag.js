// 第117版: 名札は 物語の 人物と 大事な 人（宿屋・店・協会など）だけ いつも 出す。町の 人は 見つめた ときだけ
import { world, system } from "@minecraft/server";
const BIG = /^§[eacd6b4]/;
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    let L = []; try { L = p.dimension.getEntities({ type: "mrpg:npc", location: p.location, maxDistance: 48 }); } catch { continue; }
    for (const e of L) {
      try {
        const want = e.hasTag("mrpg_saga") || BIG.test(String(e.nameTag || "")), on = e.hasTag("mrpg_nmon");
        if (want && !on) { e.triggerEvent("mrpg:name_on"); e.addTag("mrpg_nmon"); }
        else if (!want && on) { e.triggerEvent("mrpg:name_off"); e.removeTag("mrpg_nmon"); }
      } catch {}
    }
  }
}, 40);
