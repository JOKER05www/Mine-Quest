// 第106版: 図鑑の 番号（idx）→ 種族。ORDER の 並びと idx が ずれる 種族（ビャッコマル など）が あるので、番号から 引く ときは これを 使う
import { SPECIES, ORDER } from "./data.js";
const BY = {}; for (const k of Object.keys(SPECIES)) BY[SPECIES[k].idx] = k;
export const sidOf = (i) => BY[i] ?? ORDER[i];
