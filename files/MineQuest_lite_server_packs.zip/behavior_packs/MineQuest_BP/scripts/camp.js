// 第106版: キャンプ（ガイドブック → 冒険 → キャンプ）。その場に テントを はって、パーティと スタンバイの 子 みんなと すごす
// テントは エンティティ（ブロックを 置かない）。はなれる・戦い・次元を まちがえる と 自動で 片づける
import { world, system } from "@minecraft/server";
import { load, save } from "./store.js";
import { ITEMS } from "./data.js";
import { notice, choose, ICON, barNote, showTitle, sound, EXH, gold } from "./ui.js";
import { inDungeon } from "./dungeon.js";
import { inRuins } from "./ruinsarea.js";
import { findPet, spawnPet, hooks } from "./field.js";
import { inBattle } from "./battle.js";
import { exOf, exSave } from "./explore.js";
import { __bond } from "./bond.js";
import { PLAYMODE, giveBall, takeBallItem, dropBall, spawnCrowd, clearCrowd, crowdTick, runnersOf, gather, isCrowd, __pf } from "./playfun.js";

const OWID = "minecraft:overworld", OW = () => world.getDimension(OWID);
const KEY = "mrpg:camp";
const B = (t, icon) => [t, icon];
const okE = (e) => { try { return !!e && e.isValid(); } catch { return false; } };
const CAMP = new Map();   /* pid -> { tent, c } */
export const inCamp = (p) => { try { return typeof p.getDynamicProperty(KEY) === "string"; } catch { return false; } };
const campOf = (p) => { try { const v = p.getDynamicProperty(KEY); return typeof v === "string" ? JSON.parse(v) : null; } catch { return null; } };
PLAYMODE.push((p) => { const c = campOf(p); return c ? { ...c, flat: false } : null; });
hooks.petHold = ((prev) => (p) => (prev && prev(p)) || inCamp(p))(hooks.petHold);
system.run(() => { const prev = hooks.noSpawn; hooks.noSpawn = (p) => inCamp(p) || (prev ? prev(p) : false); });

const DISH = [["fd_curry", "キャンプカレー", 600], ["fd_stew", "ぐつぐつ シチュー", 400], ["fd_bento", "みんなの おにぎり弁当", 450], ["fd_cake", "たき火の パンケーキ", 500], ["fd_tea", "あったか 薬草茶", 200]];

export async function startCamp(p) {
  if (p.dimension.id !== OWID) { await notice(p, "キャンプ", "§7キャンプは 地上（オーバーワールド）だけ"); return false; }
  let bad = null; try { bad = typeof p.getDynamicProperty("mrpg:pret") === "string" ? "遊び場の 中" : inDungeon(p) ? "石板の 中" : inRuins && inRuins(p) ? "遺跡の 中" : inBattle(p) ? "戦いの 間" : null; } catch {}
  if (bad) { await notice(p, "キャンプ", `§7${bad}では キャンプできない`); return false; }
  if (inCamp(p)) { await campMenu(p); return true; }
  const d = load(p); if (!d || !(d.party || []).length) { await notice(p, "キャンプ", "§7仲間が いない"); return false; }
  let v = { x: 0, z: 1 }; try { const w = p.getViewDirection(); const h = Math.hypot(w.x, w.z) || 1; v = { x: w.x / h, z: w.z / h }; } catch {}
  const tx = p.location.x + v.x * 4, tz = p.location.z + v.z * 4, ty = __pf.groundY(tx, tz, Math.floor(p.location.y), false);
  if (Number.isNaN(ty) || Math.abs(ty - p.location.y) > 3) { await notice(p, "キャンプ", "§7ここは でこぼこか 水の 上で テントを はれない。平らな 所で もう一度"); return false; }
  let tent = null; try { tent = OW().spawnEntity("mrpg:tent", { x: Math.floor(tx) + 0.5, y: ty, z: Math.floor(tz) + 0.5 }); tent.nameTag = "§6キャンプ §7（たたくと メニュー）"; tent.setDynamicProperty("mrpg:cown", p.id); } catch { await notice(p, "キャンプ", "§7テントを はれなかった"); return false; }
  const c = { x: Math.floor(tx) + 0.5, y: ty, z: Math.floor(tz) + 0.5 };
  try { p.setDynamicProperty(KEY, JSON.stringify(c)); } catch {}
  try { const pet = findPet(p); if (pet) pet.remove(); } catch {}
  CAMP.set(p.id, { tent, c });
  spawnCrowd(p, { ...c, flat: false });
  giveBall(p);
  sound(p, "random.levelup", 0.9);
  try { showTitle(p, "§6§lキャンプ！", { subtitle: "§fボールを 投げる・なでる・テントで ごはん", fadeInDuration: 0, stayDuration: 50, fadeOutDuration: 10 }); } catch {}
  return true;
}
export function endCamp(p, why) {
  const C = CAMP.get(p.id); CAMP.delete(p.id);
  if (C && okE(C.tent)) try { C.tent.remove(); } catch {}
  try { for (const e of OW().getEntities({ type: "mrpg:tent" })) if (e.getDynamicProperty("mrpg:cown") === p.id) e.remove(); } catch {}
  clearCrowd(p); dropBall(p.id); takeBallItem(p);
  try { p.setDynamicProperty(KEY, undefined); } catch {}
  if (why) try { barNote(p).setActionBar(`§7キャンプを 片づけた（${why}）`); } catch {}
  system.runTimeout(() => { try { const d = load(p); const m = d && d.out && [...d.party, ...(d.bench || []), ...(d.box || [])].find((x) => x.id === d.out); if (m && !findPet(p)) spawnPet(p, m); } catch {} }, 10);
}
const COOK = new Map();
async function cook(p) {
  const d = load(p); if (!d) return;
  const L = DISH.filter(([id]) => ITEMS[id]);
  const k = await choose(p, "キャンプの 料理", `§fみんなで 食べると きずなが 深まる\n§7次の 戦い 3回 強く なる §8（お金 ${gold(d.gold || 0)}）`, [...L.map(([id, n, pr]) => B(`§l${n}\n§8材料代 ${pr} タヨ`, ICON("i_shop"))), B("§7戻る", ICON("i_back"))]);
  const it = L[k]; if (!it || !inCamp(p)) return;
  const d2 = load(p); if (!d2 || (d2.gold || 0) < it[2]) { await notice(p, "キャンプ", "§7お金が たりない"); return; }
  d2.gold -= it[2]; save(p, d2);
  const e = exOf(p); e.food = { k: it[0], n: 3 }; e.ck2 = (e.ck2 || 0) + 1; exSave(p, true);
  const c = campOf(p); if (c) gather(p, { x: c.x + 1.8, z: c.z - 0.2 });
  try { for (let n = 0; n < 6; n++) system.runTimeout(() => { try { OW().spawnParticle("minecraft:campfire_smoke_particle", { x: c.x + 1.8, y: c.y + 1.2, z: c.z }); } catch {} }, n * 6); } catch {}
  sound(p, "random.burp");
  const day = Math.floor(Date.now() / 1800000); let up = 0;
  if (COOK.get(p.id) !== day) { COOK.set(p.id, day); for (const r of runnersOf(p)) try { __bond.addNk(p, r.m, 3, "キャンプの ごはん"); up++; } catch {} }
  await notice(p, "キャンプの 料理", `§a${it[1]}が できた！ §fみんなで いっしょに 食べた。${up ? `\n§dみんなの きずなが 深まった（+3）` : "\n§7（きずなは 30分に 1回まで）"}\n§f次の 戦い 3回 強く なる`);
}
export async function campMenu(p) {
  for (;;) {
    if (!inCamp(p)) return;
    const n = runnersOf(p).length;
    const c = await choose(p, "キャンプ", `§f仲間 ${n}匹と キャンプ中\n§7ボールを 投げると みんなで 取りあう。なでると よろこぶ`, [B("§6§l料理を つくる\n§8みんなで ごはん", ICON("i_shop")), B("§lみんなを 集める", ICON("i_run")), B("§lボールを もらう", ICON("i_skill")), B("§cキャンプを 片づける", ICON("i_back")), B("§7閉じる", ICON("i_back"))]);
    if (c === 0) await cook(p);
    else if (c === 1) { const cc = campOf(p); for (const r of runnersOf(p)) { r.st = "follow"; r.tt = -40; } try { barNote(p).setActionBar("§fみんな 集まって きた！"); } catch {} return; }
    else if (c === 2) { giveBall(p); return; }
    else if (c === 3) { endCamp(p, "片づけた"); return; }
    else return;
  }
}
EXH.camp = startCamp;
/* テントを たたく・さわる → メニュー */
const tentHit = (p, e) => { if (e?.typeId !== "mrpg:tent") return false; let own = null; try { own = e.getDynamicProperty("mrpg:cown"); } catch {} if (own !== p.id) { try { barNote(p).setActionBar("§7ほかの 人の テント"); } catch {} return true; } system.run(() => campMenu(p).catch(() => {})); return true; };
world.afterEvents.entityHitEntity.subscribe(({ damagingEntity: p, hitEntity: e }) => { if (p?.typeId === "minecraft:player") tentHit(p, e); });
try { world.afterEvents.playerInteractWithEntity?.subscribe(({ player: p, target: e }) => tentHit(p, e)); } catch {}
/* 見はり（2tick）: 動き・自動で 片づけ */
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (!inCamp(p)) continue;
    try {
      const c = campOf(p); if (!c) continue;
      const C = CAMP.get(p.id);
      if (!C) { endCamp(p, "もう一度 はってね"); continue; }   /* ワールドを 開きなおした */
      if (p.dimension.id !== OWID) { endCamp(p, "ちがう 世界へ 行った"); continue; }
      if (Math.hypot(p.location.x - c.x, p.location.z - c.z) > 32) { endCamp(p, "はなれた"); continue; }
      if (inBattle(p)) { endCamp(p, "戦いに なった"); continue; }
      if (!okE(C.tent)) { endCamp(p, "テントが なくなった"); continue; }
      crowdTick(p, { ...c, flat: false });
    } catch {}
  }
}, 2);
try { world.afterEvents.playerLeave.subscribe(({ playerId }) => { const C = CAMP.get(playerId); CAMP.delete(playerId); if (C && okE(C.tent)) try { C.tent.remove(); } catch {} }); } catch {}
/* 起動した とき: 残った テントと 仲間を 片づける */
system.runTimeout(() => { try { const live = new Set([...CAMP.values()].map((C) => C.tent?.id)); for (const e of OW().getEntities({ type: "mrpg:tent" })) if (!live.has(e.id)) try { e.remove(); } catch {} for (const e of OW().getEntities({ tags: ["mrpg_crowd"] })) if (!isCrowd(e.id)) try { e.remove(); } catch {} } catch {} }, 100);   /* いま 使って いる ものは のこす */
export const __camp = { CAMP, startCamp, endCamp, campMenu, cook, inCamp };
