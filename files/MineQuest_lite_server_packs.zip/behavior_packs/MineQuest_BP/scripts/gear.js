// 装備の 厳選（レア度 F〜SS・数値の はば・特殊パッシブ・デメリット）
import { ItemStack } from "@minecraft/server";
import { ITEMS } from "./data.js";
import { bagLoad, bagSave, autoBag } from "./ui.js";

export const RAR = ["F", "E", "D", "C", "B", "A", "S", "SS", "X"];
export const RAR_COL = ["§f", "§7", "§e", "§a", "§9", "§c", "§d", "§6", "§5"];
export const RAR_NAME = ["粗悪", "並", "良品", "上物", "業物", "逸品", "秘宝", "神器", "創世"];
// 入手の しかたごとの 出やすさ（%）
export const RW = {
  find: [22, 22, 20, 15, 10, 6, 3.5, 1.5, 0.5], // チェスト・ドロップ・拾う
  shop: [35, 30, 20, 10, 5, 0, 0, 0, 0],
  craft: [0, 0, 10, 25, 27, 20, 11, 5, 2],   /* 第103版: クラフト品は 低い レア度（呪い）が 出ない */
  boss: [0, 0, 10, 20, 28, 24, 12, 6, 2.5],
  high: [0, 0, 0, 0, 30, 40, 20, 10, 5],
};
export const FACT_LO = (r) => 0.5 + 0.12 * r;
export const FACT_HI = (r) => 0.95 + 0.143 * r; // SS で 1.95倍
export const NPASS = [0, 0, 1, 1, 2, 2, 3, 3, 4];
export const CURSE = [0.45, 0.25, 0.1, 0, 0, 0, 0, 0, 0];
const STK = ["atk", "def", "mat", "mdf", "spd", "wpn", "brt", "hp", "mp"];
const STC = { atk: "a", def: "d", mat: "i", mdf: "r", spd: "s", wpn: "b", brt: "k", hp: "h", mp: "m" };
const CST = Object.fromEntries(Object.entries(STC).map(([k, v]) => [v, k]));
const STJ = { atk: "物力", def: "硬力", mat: "魔力", mdf: "魔硬力", spd: "走力", wpn: "武力", brt: "吹力", hp: "HP", mp: "MP" };
const ELJ = { fire: "炎", water: "水", ice: "氷", thunder: "雷", wind: "風", earth: "地", wood: "木", steel: "鉄", light: "光", dark: "闇" };
const ELS = Object.keys(ELJ);
const AILJ = { poison: "毒", burn: "火傷", bleed: "出血", para: "麻痺", sleep: "睡眠", slow: "鈍足", conf: "混乱", fear: "恐怖" };
// パッシブ: [種類, キー, 名前, 基本値(%), 対応する 装備]
export const PASS = [
  ["n", "crit", "会心", 2, "wx"], ["n", "evade", "回避", 2, "ax"], ["n", "regen", "毎ターンHP回復", 1, "ax"], ["n", "mpregen", "毎ターンMP回復", 1, "ax"],
  ["n", "lifesteal", "HP吸収", [3, 4, 5, 7, 9, 11, 14, 17, 21], "wx"], ["n", "counter", "反撃", 3, "ax"],
  ["dealt", "phys", "物理系威力", 4, "wx"], ["dealt", "weapon", "武系威力", 4, "wx"], ["dealt", "breath", "息系威力", 4, "wx"], ["dealt", "magic", "魔法系威力", 4, "wx"],
  ...ELS.map((e) => ["dealt", e, `${ELJ[e]}属性威力`, 5, "wx"]),
  ...ELS.map((e) => ["taken", e, `${ELJ[e]}被ダメ減`, 6, "ax"]),
  ["taken", "phys", "物理系被ダメ減", 4, "ax"], ["taken", "weapon", "武系被ダメ減", 4, "ax"], ["taken", "breath", "息系被ダメ減", 4, "ax"], ["taken", "magic", "魔法系被ダメ減", 4, "ax"],
  ...Object.keys(AILJ).map((a) => ["onhit", a, `攻撃で${AILJ[a]}`, 2, "wx"]),
  ["field", "exp", "経験値", 5, "wax"], ["field", "gold", "お金", 5, "wax"], ["field", "drop", "ドロップ", 4, "wax"],
  ...STK.map((k) => ["st", k, STJ[k], 0, k === "def" || k === "mdf" ? "ax" : "wax"]),
  ["flat", "metalkill", "ハガネ特効", 0, "wx"],
  // v2.7: 反射・吸収など（レア度 F〜X で 効果が 大きく なる）。※ 番号は 保存に 使うので うしろに 足すだけ
  ["refl", "phys", "物理反射", [3, 4, 6, 8, 10, 13, 16, 20, 25], "ax"], ["refl", "magic", "魔法反射", [3, 4, 6, 8, 10, 13, 16, 20, 25], "ax"],
  ["refl", "weapon", "武系反射", [3, 4, 6, 8, 10, 13, 16, 20, 25], "ax"], ["refl", "breath", "息反射", [3, 4, 6, 8, 10, 13, 16, 20, 25], "ax"],
  ["n", "mphit", "MP吸収", [2, 3, 4, 5, 6, 8, 10, 12, 15], "wx"], ["n", "critdmg", "会心ダメージ", [6, 8, 10, 13, 16, 20, 25, 30, 38], "wx"],
  ["n", "first_ch", "先制", [3, 4, 5, 7, 9, 11, 13, 16, 20], "wax"], ["n", "multi", "連撃", [3, 4, 6, 8, 10, 12, 15, 18, 22], "w"],
  ["n", "pierce", "守り貫通", [4, 5, 7, 9, 11, 14, 17, 21, 26], "w"], ["tall", "all", "全ダメージ軽減", [1, 2, 3, 4, 5, 6, 8, 10, 12], "ax"],
  ["n", "halfmp_ch", "MP消費なし", [3, 4, 5, 7, 9, 11, 13, 16, 20], "x"], ["n", "healboost", "回復量", [5, 6, 8, 10, 13, 16, 20, 24, 30], "x"],
];
// デメリット（低レア度に つくことが ある）
export const CURSES = [["st", "spd", "走力", 0], ["st", "def", "硬力", 0], ["taken", "magic", "魔法系被ダメ増", 6], ["taken", "weapon", "武系被ダメ増", 6], ["st", "atk", "物力", 0]];
const slotOf = (kind) => ({ weapon: "w", armor: "a", acc: "x" })[kind];
export const isGear = (id) => { const it = ITEMS[id]; return !!it && (it.kind === "weapon" || it.kind === "armor" || it.kind === "acc"); };
const U = (a, b) => a + Math.random() * (b - a);

function pickRar(table) {
  const w = RW[table] || RW.find, tot = w.reduce((a, b) => a + b, 0);
  let x = Math.random() * tot;
  for (let i = 0; i < w.length; i++) { x -= w[i]; if (x < 0) return i; }
  return 0;
}
const gradeOf = (it) => Math.max(0, it.grade ?? (it.tier || 0) * 3);
function passVal(def, r, g) {
  if (def[0] === "flat") return Math.max(1, Math.min(4, 1 + Math.floor(r / 2)));
  if (def[0] === "st") return Math.max(1, Math.round((2 + g * 2.5) * (0.5 + 0.15 * r) * U(0.7, 1)));
  if (Array.isArray(def[3])) return Math.max(1, Math.round(def[3][Math.max(0, Math.min(8, r))] * U(0.75, 1)));
  return Math.max(1, Math.round(def[3] * (1 + 0.4 * r) * U(0.7, 1)));
}
export function rollGear(id, table = "find", fixR = -1) {
  const it = ITEMS[id]; if (!it) return null;
  if (id === "wp_tokoyo") return ENMA_BLADE();   // v2.4.3: 邪刀・閻魔は どこで 手に入れても 神器（SS）の 理論値
  const r = fixR >= 0 ? fixR : pickRar(table), g = gradeOf(it), s = {}, p = [];
  for (const k of STK) if (it[k] > 0) s[k] = Math.max(1, Math.round(it[k] * U(FACT_LO(r), FACT_HI(r))));
  const sl = slotOf(it.kind);
  const pool = PASS.map((d, i) => [d, i]).filter(([d]) => d[4].includes(sl));
  for (let n = 0; n < NPASS[r] && pool.length; n++) {
    const k = Math.floor(Math.random() * pool.length), [d, i] = pool.splice(k, 1)[0];
    p.push([i, passVal(d, r, g)]);
  }
  if (Math.random() < CURSE[r]) { const have = new Set(p.filter(([j]) => j < 100 && PASS[j]).map(([j]) => PASS[j][0] + ":" + PASS[j][1])); const ok4 = CURSES.map((c, k) => k).filter((k) => !have.has(CURSES[k][0] + ":" + CURSES[k][1])); if (ok4.length) { const i = ok4[Math.floor(Math.random() * ok4.length)]; p.push([100 + i, passVal(CURSES[i], 1, g)]); } }   // 第63版: 同じ 能力の プラスと 呪いを 同時に つけない
  return { r, s, p };
}
export function maxStat(id, k) { const v = ITEMS[id]?.[k] || 0; return v > 0 ? Math.round(v * FACT_HI(8)) : v; }
export function minStat(id, k) { const v = ITEMS[id]?.[k] || 0; return v > 0 ? Math.max(1, Math.round(v * FACT_LO(0))) : v; }

// ---- 合成した 装備（バトル・能力計算用）----
export function mergeGear(id, roll) {
  if (id === "wp_tokoyo") roll = ENMA_BLADE();
  const it = ITEMS[id]; if (!it) return null;
  if (!roll) return it;
  const o = { ...it, fx: JSON.parse(JSON.stringify(it.fx || {})) };
  for (const k of STK) if (it[k] > 0) o[k] = roll.s?.[k] ?? it[k];
  for (const [i, v] of roll.p || []) {
    const curse = i >= 100, d = curse ? CURSES[i - 100] : PASS[i]; if (!d) continue;
    const sign = curse ? -1 : 1;
    if (d[0] === "st") o[d[1]] = (o[d[1]] || 0) + sign * v;
    else if (d[0] === "n") o.fx[d[1]] = (o.fx[d[1]] || 0) + v / 100;
    else if (d[0] === "flat") o.fx[d[1]] = (o.fx[d[1]] || 0) + v;
    else if (d[0] === "refl") { o.fx.barrierp = o.fx.barrierp || {}; o.fx.barrierp[d[1]] = (o.fx.barrierp[d[1]] || 0) + v / 100; }
    else if (d[0] === "tall") o.fx.taken_all = (o.fx.taken_all || 0) - v / 100;
    else if (d[0] === "taken") { o.fx.taken = o.fx.taken || {}; o.fx.taken[d[1]] = (o.fx.taken[d[1]] || 0) - sign * v / 100; }
    else { o.fx[d[0]] = o.fx[d[0]] || {}; o.fx[d[0]][d[1]] = (o.fx[d[0]][d[1]] || 0) + v / 100; }
  }
  return o;
}
export function passText(i, v) {
  const curse = i >= 100, d = curse ? CURSES[i - 100] : PASS[i]; if (!d) return "";
  if (d[0] === "st" || d[0] === "flat") return `${curse ? "§c" : "§b"}${d[2]}${curse ? "-" : "+"}${v}`;
  return `${curse ? "§c" : "§b"}${d[2]}${curse && d[0] !== "taken" ? "-" : "+"}${v}%`;
}
// 0〜100: 理論値に どれだけ 近いか（能力値）
export function quality(id, roll) {
  if (id === "wp_tokoyo") roll = ENMA_BLADE();
  if (!roll) return 0;
  const ks = STK.filter((k) => ITEMS[id]?.[k] > 0);
  if (!ks.length) return Math.round((Math.min(7, roll.r) / 7) * 100);
  return Math.round((ks.reduce((a, k) => a + ((roll.s || {})[k] || 0) / maxStat(id, k), 0) / ks.length) * 100);
}
export function gearName(id, roll) {
  if (id === "wp_tokoyo") roll = ENMA_BLADE();
  const it = ITEMS[id]; if (!it) return "？";
  return roll ? `${RAR_COL[roll.r]}[${RAR[roll.r]}]${it.name}§r` : it.name;
}
export function gearLines(id, roll) {
  if (id === "wp_tokoyo") roll = ENMA_BLADE();
  const it = ITEMS[id]; if (!it) return [];
  const L = [];
  if (roll) L.push(`${RAR_COL[roll.r]}レア度 ${RAR[roll.r]}（${RAR_NAME[roll.r]}）§7 理論値の ${quality(id, roll)}%`);
  const st = STK.filter((k) => it[k]).map((k) => { const v = roll ? (roll.s[k] ?? it[k]) : it[k]; return `§f${STJ[k]}${v >= 0 ? "+" : ""}${v}${it[k] > 0 ? ` §8(${minStat(id, k)}〜${maxStat(id, k)})` : ""}`; });
  if (st.length) L.push(st.join(" "));
  if (roll) for (const [i, v] of roll.p || []) L.push(passText(i, v));
  return L;
}
// ---- ロア（アイテムの 説明文）に 保存 ----
const enc = (roll) => `${roll.r};${Object.entries(roll.s).map(([k, v]) => STC[k] + v).join(",")};${(roll.p || []).map(([i, v]) => `${i}.${v}`).join(",")}`;
export function decodeLore(lore) {
  const line = (lore || []).find((l) => l.startsWith("§0#"));
  if (!line) return null;
  try {
    const [r, s, p] = line.slice(3).split(";");
    const roll = { r: Math.max(0, Math.min(8, +r)), s: {}, p: [] };
    for (const t of (s || "").split(",").filter(Boolean)) roll.s[CST[t[0]]] = +t.slice(1);
    for (const t of (p || "").split(",").filter(Boolean)) { const [i, v] = t.split("."); roll.p.push([+i, +v]); }
    return roll;
  } catch { return null; }
}
const cut = (s) => (s.length > 48 ? s.slice(0, 48) : s);
export function makeStack(id, roll) {
  if (id === "wp_tokoyo") roll = ENMA_BLADE();
  const st = new ItemStack(`mrpg:${id}`, 1);
  if (!roll) return st;
  try { st.nameTag = `${RAR_COL[roll.r]}[${RAR[roll.r]}] ${ITEMS[id].name}`; } catch {}
  const lines = gearLines(id, roll).slice(0, 1).concat(STK.filter((k) => ITEMS[id][k]).map((k) => `§f${STJ[k]}${(roll.s[k] ?? ITEMS[id][k]) >= 0 ? "+" : ""}${roll.s[k] ?? ITEMS[id][k]}`).join(" ") || [], (roll.p || []).map(([i, v]) => passText(i, v)));
  try { st.setLore([...lines.filter(Boolean).map(cut).slice(0, 8), cut(`§0#${enc(roll)}`)]); } catch {}
  return st;
}
// v2.7: 物語の 進みで 出る レア度の 上限（main.js で 設定）
export const GEAR_CAP = { f: null };
export const capOf = (p) => { try { return GEAR_CAP.f ? GEAR_CAP.f(p) : 8; } catch { return 8; } };
export function capRoll(p, id, roll) { const c = capOf(p); return roll && id !== "wp_tokoyo" && roll.r > c ? rollGear(id, "find", c) : roll; }
export function giveGear(p, id, roll) {
  try { p.setDynamicProperty("mrpg:gotT", Date.now()); } catch {}
  if (autoBag(p)) { const b = bagLoad(p); b.g.push([id, roll || null]); bagSave(p, b); return; }   // v2.2: バッグへ
  const c = p.getComponent("minecraft:inventory")?.container;
  const st = makeStack(id, roll);
  let rest;
  try { rest = c?.addItem(st); } catch { return; }
  if (rest) try { p.dimension.spawnItem(rest, p.location); } catch {}
}
// インベントリの 装備（1つずつ）
export function gearSlots(p, kind) {
  const c = p.getComponent("minecraft:inventory")?.container, out = [];
  if (!c) return out;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it?.typeId?.startsWith("mrpg:")) continue;
    const id = it.typeId.slice(5);
    if (!isGear(id) || (kind && ITEMS[id].kind !== kind)) continue;
    let lore = []; try { lore = it.getLore(); } catch {}
    out.push({ slot: i, id, roll: decodeLore(lore) });
  }
  // v2.2: バッグの 装備も（slot は "b番号"）
  bagLoad(p).g.forEach(([id, roll], i) => { if (ITEMS[id] && isGear(id) && (!kind || ITEMS[id].kind === kind)) out.push({ slot: `b${i}`, id, roll, bag: true }); });
  return out;
}
export function takeSlot(p, slot, id) {
  if (typeof slot === "string" && slot[0] === "b") { const b = bagLoad(p), i = +slot.slice(1); if (!b.g[i] || b.g[i][0] !== id) return false; b.g.splice(i, 1); bagSave(p, b); return true; }
  const c = p.getComponent("minecraft:inventory")?.container;
  const it = c?.getItem(slot);
  if (!it || it.typeId !== `mrpg:${id}`) return false;
  if (it.amount > 1) { it.amount -= 1; c.setItem(slot, it); } else c.setItem(slot, undefined);
  return true;
}
export function replaceSlot(p, slot, id, roll) {
  if (typeof slot === "string" && slot[0] === "b") { const b = bagLoad(p), i = +slot.slice(1); b.g[i] = [id, roll || null]; bagSave(p, b); return; }
  const c = p.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  c.setItem(slot, makeStack(id, roll));
}
// まだ 鑑定されていない 装備（チェスト・ドロップ・作業台）に レア度を つける
export function appraiseInventory(p) {
  const c = p.getComponent("minecraft:inventory")?.container;
  if (!c) return 0;
  let n = 0;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it?.typeId?.startsWith("mrpg:")) continue;
    const id = it.typeId.slice(5);
    if (!isGear(id)) continue;
    let lore = []; try { lore = it.getLore(); } catch {}
    const old = decodeLore(lore);
    if (old && !(id === "wp_tokoyo" && old.r !== 7)) continue;   // 前に F〜S に なってしまった 邪刀・閻魔も 直す
    const amt = it.amount || 1;
    const roll = capRoll(p, id, rollGear(id, "find"));
    c.setItem(i, makeStack(id, roll));
    n++;
    if (roll.r >= 5) try { p.sendMessage(`${RAR_COL[roll.r]}§l★ ${RAR[roll.r]}ランクの 装備！§r ${gearName(id, roll)}`); } catch {}
    for (let k = 1; k < amt; k++) giveGear(p, id, capRoll(p, id, rollGear(id, "find")));
  }
  // バッグの 邪刀・閻魔も 理論値に
  try { const b = bagLoad(p); let ch = false; for (const g of b.g) if (g[0] === "wp_tokoyo" && (!g[1] || g[1].r !== 7)) { g[1] = ENMA_BLADE(); ch = true; } if (ch) bagSave(p, b); } catch {}
  return n;
}
export const gearPower = (id, roll) => { const o = mergeGear(id, roll); return STK.reduce((a, k) => a + Math.max(0, o[k] || 0) * (k === "hp" ? 0.5 : 1), 0) + (roll ? roll.r * 3 + (roll.p || []).length * 4 : 0); };
// v2.4: 理論値（SSランク・能力は 最大・特殊効果も 最大）
export function perfectGear(id, keys) {
  const it = ITEMS[id]; if (!it) return null;
  const s = {}, p = [];
  for (const k of STK) if (it[k] > 0) s[k] = maxStat(id, k);
  const sl = slotOf(it.kind);
  for (const [t, k] of keys) { const i = PASS.findIndex((d) => d[0] === t && d[1] === k && d[4].includes(sl)); if (i < 0) continue; const d = PASS[i]; p.push([i, d[0] === "flat" ? 4 : d[0] === "st" ? Math.round((2 + gradeOf(it) * 2.5) * (0.5 + 0.15 * 7)) : (Array.isArray(d[3]) ? d[3][d[3].length - 1] : Math.round(d[3] * (1 + 0.4 * 7)))]); }   // v2.9.12: 段ごとの 値は いちばん 上（前は NaN）
  return { r: 7, s, p };
}
export const ENMA_BLADE = () => perfectGear("wp_tokoyo", [["dealt", "weapon"], ["n", "crit"], ["n", "lifesteal"]]);
