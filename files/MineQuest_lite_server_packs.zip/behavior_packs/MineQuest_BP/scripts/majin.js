// v2.9.14: 魔神編（カゲツに 勝った あと）。ムサシと 魔神の鍔と エンマ
import { world, system } from "@minecraft/server";
import { SPECIES, ITEMS, MOVES } from "./data.js";
const MOVES_OK = (id) => !!MOVES[id];
import { makeMonster, addMon, calcStats, STATS, TAL_MAX, canJoin, fixParty, hpBack, canBench, benchUse } from "./core.js";
import { load, save, mark, allMons, allMonsDeep } from "./store.js";
import { busy, ok, notice, confirm, sound, particle, setJob, showTitle, countItem, choose, ICON } from "./ui.js";
import { TOWNS, townPos, getTown } from "./structures.js";
import { M_START, M_ATTACK, M_CRIT, M_KILL, M_HURT, M_PINCH, M_FAINT, M_WIN, M_MAJIN, M_FIELD } from "./musashi_lines.js";

export const MUSASHI_TOWN = "t42";   /* 第69版: はがねの 村 クロガネ（刀鍛冶の 村）。名前で さがし直す */
const musashiTownId = () => { try { return (TOWNS.find((t) => /クロガネ/.test(t.name)) || { id: MUSASHI_TOWN }).id; } catch { return MUSASHI_TOWN; } };
export const MUSASHI_JOB = 19;
const COL = "§c§l";
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const qs = (d) => d.story || (d.story = {});
export const hasTsuba = (p) => countItem(p, "mrpg:k_hilt") > 0;
export function musashiTownInfo() { const t = TOWNS.find((x) => x.id === musashiTownId()); if (!t) return null; const i = getTown(t.id); return { t, pos: i && i.built ? i : townPos(t), built: !!(i && i.built) }; }
async function say(p, who, lines, c = COL) { for (const l of [].concat(lines)) await notice(p, who, `${c}${who}§r\n\n§f「${l}」`); }
const story_mon = (d) => allMons(d).find((m) => m.sp === "musashi" && m.storyMusashi) || allMons(d).find((m) => m.sp === "musashi");
const anyMusashi = (d) => allMonsDeep(d).some((m) => m && m.sp === "musashi");

// ---- 町の ムサシ（仲間に なる 前の プレイヤーが 近くに いる ときだけ 立っている）----
system.runInterval(() => {
  const M = musashiTownInfo(); if (!M || !M.built || typeof M.pos.y !== "number") return;
  const ow = world.getDimension("minecraft:overworld");
  let want = false;
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue;
    if (Math.hypot(p.location.x - M.pos.x, p.location.z - M.pos.z) > 72) continue;
    let d = null; try { d = load(p); } catch {}
    if (d && !qs(d).musashiJoin) want = true;
  }
  let have = []; try { have = ow.getEntities({ type: "mrpg:npc", tags: ["mrpg_musashi"] }); } catch {}
  if (!want) { for (const e of have) try { e.remove(); } catch {} return; }
  have = have.filter((e) => ok(e)); for (const e of have.slice(1)) try { e.remove(); } catch {}
  if (have.length) return;
  try {
    // v3.0: 建物の 中や 屋根に ならない 場所（地面の 高さが 町と ほぼ 同じ 所）を さがして 立つ
    let pos = null;
    for (const [dx, dz] of [[7.5, 6.5], [-6.5, 6.5], [6.5, -7.5], [-7.5, -6.5], [0.5, 9.5], [9.5, 0.5], [0.5, -9.5], [-9.5, 0.5], [3.5, 3.5]]) {
      let top = null; try { top = ow.getTopmostBlock({ x: Math.floor(M.pos.x + dx), z: Math.floor(M.pos.z + dz) }); } catch {}
      const ty = top ? top.location.y + 1 : null;
      if (ty === null || M.pos.y === null || M.pos.y === undefined) continue;
      if (Math.abs(ty - M.pos.y) <= 2 && !/water|lava/.test(String(top.typeId))) { pos = { x: M.pos.x + dx, y: ty, z: M.pos.z + dz }; break; }
    }
    if (!pos) pos = { x: M.pos.x + 0.5, y: (M.pos.y ?? 64) + 1, z: M.pos.z + 0.5 };
    const e = ow.spawnEntity("mrpg:npc", pos);
    setJob(e, MUSASHI_JOB); e.addTag("mrpg_npc"); e.addTag("mrpg_musashi");
    e.nameTag = "§7さすらいの 武士";
  } catch {}
}, 100);

// ---- 話しかける ----
export async function musashiTalk(p, ent) {
  let d = load(p); if (!d) return;
  const s = qs(d);
  if (s.musashiJoin) { await notice(p, "ムサシ", "§7（ムサシは もう 仲間だ。ガイドブックの「ストーリー」→「ムサシと 話す」で 話せる）"); return; }
  if (!(s.ending && s.hiltGot && hasTsuba(p))) {
    await say(p, "さすらいの 武士", [pick(["鍔さえ あれば……。この 村の 鍛冶でも 打てねえのか……", "師匠は「まだ 早い」の 一点張りだ。くそっ……。", "……ん？ なんだ、見せもんじゃねえぞ。", "急がねえと……あいつは もう 千年も ひとりなんだ。"])], "§7§l");
    return;
  }
  if (s.musashiMet) { await say(p, "ムサシ", ["よう、来たか。……準備は いいか？ 腕だめしだ！"]); return "spar"; }   // v3.0 第63版: 2回目からは 1行
  // 鍔を 見つける
  await say(p, "さすらいの 武士", ["……おい、待て！ その 鍔……師匠の 家の 鍔じゃねえか！"], "§7§l");
  await notice(p, "あなた", "§7（カゲツに 託された ことを 話した）");
  await say(p, "ムサシ", ["師匠が……お前に 託したのか。", "……悪い、名乗ってなかった。俺は §cムサシ§f。カゲツ師匠の 弟子だ。"]);
  await say(p, "ムサシ", ["その 鍔は、千年前の 剣士 §4エンマ§f の 刀に はまってた ものだ。", "エンマは 石板の王――厄王を 斬って、その 悪意を 自分の 体に 封じた。……そして 魔神に なった。", "鍔は 悪意を 抑える 栓だ。鍔を なくした エンマは、悪意に のまれた まま なんだ。"]);
  if (s.enmaDream) await say(p, "ムサシ", ["……お前、神殿で 夢を 見なかったか？ 鍔の ない 刀を 下げた 男の。", "それが エンマだ。厄王の 残りの 悪意が 鍔に 集まって、あいつを 呼んでる。"]);
  await say(p, "ムサシ", ["神殿で 鍔を 捧げれば、刀に 鍔が もどる。悪意から あいつを 引きはがせる かもしれねえ。", "みんな 斬れって 言う。でも 俺は、エンマを 救いたいんだ。", "……師匠が 認めた 腕、見せてくれ。本気で 行くぞ！"]);
  { const d1 = load(p); if (d1) { qs(d1).musashiMet = 1; save(p, d1); } }   // v3.0 第63版: 出会いの 場面は 1回だけ
  return "spar";
}
// 腕だめし（story.js の fight を もらう）→ 仲間に
export async function musashiSpar(p, fight) {
  try { return await musashiSpar0(p, fight); } finally { busy.delete(p.id); }   // v3.0: とちゅうで 終わっても 印を のこさない
}
async function musashiSpar0(p, fight) {
  let res = null;
  for (let k = 0; k < 6; k++) {
    const d0 = load(p); if (!d0) return;
    for (const m of d0.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d0);
    busy.delete(p.id);
    res = await fight(p, { team: [{ sid: "musashi", lv: 90, q: 1, plus: 15 }] }, { tier: 2, name: "ムサシ", fam: "", npc: null, arena: "ムサシの 腕だめし", theme: "shrine", speaker: "ムサシ", lines: { half: "やるじゃねえか……まだまだ！", low: "へへ……強えな、お前。" } });
    busy.add(p.id);
    if (res === "win") break;
    let again = false; try { again = await confirm(p, "負けて しまった……", "§c§lムサシ§r§f「どうした、そんな もんか？ もう 一回 来い！」\n\n§fもう一度 挑みますか？ §7（仲間は 全回復する）", "もう一度 挑む", "あとで"); } catch {}
    if (!again) { await say(p, "ムサシ", ["準備が できたら また 来い。鍔は お前が 持ってろ。師匠が 選んだのは お前だ。"]); return; }
  }
  if (res !== "win") { try { await say(p, "ムサシ", ["今日は ここまでだ。仲間を 鍛えて また 来い。……待ってるぜ。"]); } catch {} return; }
  const d = load(p); if (!d) return;
  const s = qs(d);
  if (s.musashiJoin) return;   // 2回 仲間に ならない
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  await say(p, "ムサシ", ["……ははっ、すげえな お前。師匠が 託す わけだ。", "決めた、俺も 行く。エンマを 斬りに じゃねえ、救いに だ。", "鍔は お前が 持っててくれ。……頼んだぜ。"]);
  const m = makeMonster("musashi", 60, true);
  m.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(m.tal[k], 20)])); m.storyMusashi = 1;
  const c = calcStats(m); m.hp = c.hp; m.mp = c.mp;
  addMon(d, m); mark(d.own, "musashi"); mark(d.seen, "musashi");
  s.musashiJoin = 1; s.musashiMet = 1;
  save(p, d);
  try { showTitle(p, "§c§lムサシが 仲間に なった！", { subtitle: "§f次は §5閻魔の神殿§f へ", fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {}
  sound(p, "random.levelup", 1.2); particle(p, "minecraft:totem_particle", 1.3);
  await notice(p, "魔神編", ["§c§lムサシが 仲間に なった！", "", "§fムサシと §5閻魔の神殿§f へ 行き、§4魔神の鍔§f を 捧げよう。", "§7（神殿の 前で ガイドブックを 使う。場所は 右上の 案内）", "§7（ガイドブック → ストーリー →「ムサシと 話す」）"].join("\n"));
}

// ---- ムサシと 話す（ガイドブック）----
const TOPICS = [
  ["家の こと", (s) => ["俺は クロガネの 刀鍛冶の 家の 生まれだ。親父は 鍔ばかり 打ってた。", "ガキの ころ、師匠の 家で 鍔の ない 刀を 見たんだ。", "なんでか、その 刀が 泣いてる 気が した。……それから ずっと 頭から 離れねえ。"]],
  ["鍔の こと", (s) => ["赤黒く 光ってるだろ。厄王の 残りの 悪意が、こいつに 流れこんでるんだ。", "この 鍔は 千年前、エンマの 刀に はまってた。悪意を 抑える 栓みたいな もんだ。", s.enmaClear ? "今は 鍔を 通して、エンマの 力を 少し 借りられる。いざって ときは 掲げてくれ。" : "鍔が 刀に もどれば、エンマは 正気に もどれる……はずだ。"]],
  ["エンマの こと", (s) => s.enmaClear ? ["魔神なんて 呼ばれてたが、話してみりゃ 無口な 剣士だ。", "千年 ひとりで 悪意を 抱えてたんだぜ。……文句 ひとつ 言わずに な。", "あいつが 言ってた §5常世§f……。悪意の 出どころ、か。"] : ["エンマは 魔神なんて 呼ばれてるが、もとは 人間の 剣士だ。", "千年前、厄王を 斬って……その 悪意を 自分の 体に 封じこめた。", s.enmaDream ? "お前が 夢で 見た 男。あれが 鍔を なくした エンマだ。" : "世界を 救った やつが、千年 ひとりで 悪意と 戦ってる。放って おけるかよ。"]],
  ["厄王の こと", (s) => ["厄王が 倒れて、世界は 静かに なった。……表向きは な。", "悪意って やつは 倒しても 消えねえ。行き場を なくして、鍔に 集まって きた。", "だから 鍔が 光りだした。……エンマを 呼んでるんだ。"]],
  ["カゲツの こと", (s) => ["師匠の 家は、千年 エンマの 刀を 守ってきた 家だ。", "普段は 釣りして 昼寝してる くせに、刀を 持つと 別人だ。", "師匠は 俺に 鍔を 預けなかった。お前に 託した。……悔しいけど、わかる 気が する。"]],
  ["刀の こと", (s) => ["この 金の 柄の 刀は、親父が 打って くれた。銘は ない。", "「名前を つけると 刀が 驕る」ってのが 親父の 口ぐせだ。", "エンマの 刀を 受け止める ために、毎日 振ってきた。"]],
  ["これから", (s) => s.enmaClear ? ["……変な 気分だぜ。千年前の 英雄と 旅を するなんてな。", "鍔を 掲げれば、俺の 体に エンマの 力が 宿る。いざって ときは 使ってくれ。", "§5常世§f に、§6終の遺跡§f の 墓守か……。いつか その時が 来たら 付き合うぜ。"] : ["閻魔の神殿で 鍔を 捧げれば、刀に 鍔が もどる。", "……何が 起きても、エンマを 斬るなよ。救うんだ。", "お前と 一緒なら、きっと 届く。"]],
];
export function canTalkMusashi(d) { const s = qs(d); return !!s.musashiJoin; }
export async function musashiTalkMenu(p, d) {
  const s = qs(d);
  for (;;) {
    const i = await choose(p, "ムサシと 話す", `§c§lムサシ§r\n§7${s.enmaClear ? "カゲツの 弟子。今は 鍔を 通して エンマと 旅を している" : "カゲツの 弟子。エンマを 救う ため 仲間に なった"}`, [...TOPICS.map(([t]) => [`§l${t}`, ICON("i_help")]), ["§7戻る", ICON("i_back")]]);
    if (i < 0 || i >= TOPICS.length) return;
    s.mtalk = [...new Set([...(s.mtalk || []), i])]; save(p, d);
    await say(p, "ムサシ", TOPICS[i][1](s));
  }
}
// ときどき チャットで ひとこと（ムサシが パーティに いる とき）
const CHAT = M_FIELD.map((l) => ["ムサシ", l]);
const CHAT_E = [["エンマ", "……人の 世は、騒がしいな。だが 嫌いでは ない。"], ["ムサシ", "おい エンマ、勝手に 鍔から 話しかけるな。びっくりするだろ。"], ["エンマ", "……刀が 鍔を 取り戻した。今は それで 足りる。"]];
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try {
      if (busy.has(p.id) || Math.random() > 0.4) continue;
      const d = load(p); if (!d) continue; const s = qs(d);
      if (!s.musashiJoin || !d.party.some((m) => m.sp === "musashi")) continue;
      const pool = s.enmaClear ? CHAT : CHAT.filter(([, l]) => !/エンマ|魔神|鍔|冥府/.test(l));   // v3.0: 先の 話は しない
      const [who, line] = pick(s.enmaClear && d.party.some((m) => m.sp === "enma") ? [...pool, ...CHAT_E] : pool);
      p.sendMessage(`§${who === "エンマ" ? "4" : "c"}${who}§f「${line}」`);
    } catch {}
  }
}, 20 * 60 * 3);

// ---- 神殿: 鍔を 捧げる → ムサシに 取り憑く → 倒すと ムサシに もどる ----
export async function possessionFlow(p, d, fight) {
  const s = qs(d);
  let mus = story_mon(d);
  if (!mus && anyMusashi(d)) { await notice(p, "閻魔の神殿", "§7ムサシは 牧場に いるようだ。§fパーティか 預かり所に もどしてから 来よう。"); return true; }
  if (!mus && s.musashiBack) { await notice(p, "閻魔の神殿", "§7ムサシが いない……。§f（ムサシは 一度だけ 戻って くる。配合の 材料には しないで おこう）"); return true; }
  if (!mus) {   // v2.9.14: ムサシが いない（前の 版で わかれた など）→ 1度だけ 物語の ムサシを もどす
    s.musashiBack = 1;
    mus = makeMonster("musashi", 60, true); mus.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(mus.tal[k], 20)])); mus.storyMusashi = 1;
    const c0 = calcStats(mus); mus.hp = c0.hp; mus.mp = c0.mp; addMon(d, mus); mark(d.own, "musashi"); save(p, d);
    await notice(p, "閻魔の神殿", "§c§lムサシ§r§f「おーい！ 置いてくなよ！ ……神殿だろ？ 俺も 行く！」");
  }
  if (!d.party.some((m) => m !== mus && m.hp > 0)) { await notice(p, "閻魔の神殿", "§cムサシ§f「待て。何が 起きるか わからねえ。ほかの 仲間も 連れて こい！」\n§7ムサシ 以外に 戦える 仲間を 表（パーティ）に 入れてから 来よう。§8（裏の 子は 仲間メニューで 表へ・倒れた 子は 宿屋で）"); return true; }
  await notice(p, "魔神の鍔", ["§4魔神の鍔が 赤黒く 燃え上がった……！", "§f玉座の 前の 鍔の ない 刀が、鍔を 求めて 震える。"].join("\n"));
  await say(p, "ムサシ", ["……千年 待たせたな、エンマ。お前の 鍔だ。", "来るぞ……！ 構えろ！"]);
  for (const q of world.getAllPlayers()) if (q.dimension.id === p.dimension.id && Math.hypot(q.location.x - p.location.x, q.location.z - p.location.z) < 64) { sound(q, "mob.wither.spawn", 0.6); sound(q, "ambient.weather.thunder", 0.8); }
  try { p.runCommand("camera @s fade time 0.3 0.8 0.5 color 60 0 0"); } catch {}
  await notice(p, "？？？", ["§7刀が 鍔を 呑みこんだ 瞬間、赤黒い 霧が あふれ、ムサシを 包んだ――", "", "§c§lムサシ§r§f「ぐっ……！ これが……千年分の 悪意か……！」"].join("\n"));
  try { showTitle(p, "§4§l魔神 エンマ", { subtitle: "§7千年の 悪意が ムサシを 呑みこむ", fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 15 }); } catch {}
  await say(p, "エンマ", ["……"], "§4§l");   // v3.0: エンマは 何も 語らない
  // ムサシは この 戦いの あいだ 仲間から はずす（取り憑かれて いる）
  const inParty = d.party.indexOf(mus);
  if (inParty >= 0) { d.party.splice(inParty, 1); d.box.push(mus); }
  const inBench = (d.bench || []).indexOf(mus); if (inBench >= 0) { d.bench.splice(inBench, 1); d.box.push(mus); }   // 第69版: 裏の ムサシも はずす
  // v3.0: あいた 枠には 預かり所の 強い 子が 一時的に 入る（戦いの あとで もどる）
  const subs = [];
  if (inParty >= 0) {
    const pool = d.box.filter((m) => m && m !== mus && m.sp !== "musashi" && m.sp !== "enma" && !m.storyMusashi).sort((a, b) => (b.lv || 0) - (a.lv || 0) || (b.plus || 0) - (a.plus || 0));
    for (const m of pool) { if (subs.length >= 3) break; if (canJoin(d, m)) { d.box.splice(d.box.indexOf(m), 1); d.party.push(m); subs.push(m); } }
    if (subs.length) await notice(p, "閻魔の神殿", `§7ムサシの かわりに、預かり所から §f${subs.map((m) => m.nm || SPECIES[m.sp]?.name).join("・")}§7 が かけつけた！\n（戦いの あとで 預かり所に もどる）`);
  }
  s.possess = { id: mus.id, idx: inParty, bidx: inBench, subs: subs.map((m) => m.id) }; save(p, d);
  let res = null;
  try {
    res = await fight(p, { team: [{ sid: "enma", lv: 100, q: 1, plus: 99 }] }, { tier: 2, name: "エンマ（ムサシの 体）", fam: "", npc: null, arena: "閻魔の 裁き場", theme: "hell", enma: true, enmaN: 0, speaker: "エンマ", lines: { win: "……", lose: "……" } });
  } finally { restoreMusashi(p); }
  d = load(p); if (!d) return true;
  const st = qs(d);
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  if (res !== "win") { save(p, d); await notice(p, "閻魔の神殿", ["§4§lエンマ§r§f「……」", "", "§7赤黒い 霧は ムサシの 体から 抜け、鍔の 中へ 戻っていった。§d魔神の鍔が 手元に 戻った。", "§c§lムサシ§r§f「はぁ、はぁ……あいつ、泣いてた 気が する。もう一度 行こう。」", "§7（神殿の 前で もう一度 ガイドブックを 使う）"].join("\n")); return true; }
  // 勝った: ムサシに もどる・エンマが 仲間に
  try { p.runCommand("camera @s fade time 0.4 1.0 0.8 color 255 255 255"); } catch {}
  await notice(p, "決着", ["§f赤黒い 霧が ほどけ、鍔へ 吸いこまれていく……", "§f鍔の ない 刀に、千年ぶりに 鍔が おさまった。", "", "§c§lムサシ§r§f「……っ、はぁ……戻った、のか……？」"].join("\n"));
  await say(p, "ムサシ", ["……ははっ。やったな、お前。", "……おい、見ろ。刀の 前に 誰か 立ってる。"]);
  const first = !st.enmaClear;
  await say(p, "エンマ", ["……魅せてくれたな。", "千年前、私は 厄王を 斬り、その 悪意を この 身に 封じた。", "鍔を 失ってから、私は 私で なくなった。……ようやく 目が 覚めた。", "小僧。霧の 中でも、お前の 声だけは 聞こえていた。"], "§4§l");   // v3.0: エンマが 口を ひらくのは 負けた ときだけ
  await notice(p, "魔神の鍔", "§4エンマの 姿が、静かに 鍔へ 溶けて いく……");
  if (first) {
    await say(p, "ムサシ", ["待てよ！ 消えちまうのか？ せっかく もどれたのに……！"]);
    await notice(p, "エンマ", ["§4§lエンマ§r§f「消えは せぬ。鍔を 通して、小僧と 力を 分け合おう。」", "", "§4§lエンマ§r§f「……覚えて おけ。厄王の 悪意は、厄王が 生んだ ものでは ない。」", "§4§lエンマ§r§f「死者の 国 §5常世§f から 染み出した ものだ。」", "§4§lエンマ§r§f「常世を 知るのは §6終の遺跡§f の 墓守のみ。……いずれ 時が 来れば、墓守が 道を 示そう。」"].join("\n"));
  }
  st.enmaClear = 1; st.enma = (st.enma || 0) + 1;
  const got = [];
  if (first) {   // v3.0: エンマは 仲間に ならない。鍔を ムサシに 使うと エンマの 姿に
    got.push("§c§lムサシが 仲間に もどった！", "§d魔神の鍔が 手元に 戻った。", "§d魔神の鍔: §f戦いの 中で ムサシの HPが 半分 以下の とき 使うと、§4魔神エンマ§f が 顕現する（全回復・全能力 2段階 上昇・3〜4回行動・魔神の闘気・最優先行動 など）");
  } else got.push("§d魔神の鍔が 手元に 戻った。");
  d.gold += 500000; got.push("§e50万G");
  save(p, d);
  try { p.sendMessage(`§4§l★ エンマを 悪意から 解き放ち、ムサシを 取り戻した！ ★`); } catch {} sound(p, "ui.toast.challenge_complete", 1);   // v3.0: ほかの 人には 流さない（ネタバレ）
  try { showTitle(p, "§4§l魔神編 クリア", { subtitle: "§fエンマが 自分を 取りもどした", fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
  await notice(p, "魔神編 クリア！", got.join("\n"));
  return true;
}
// 取り憑かれて いた ムサシを パーティに もどす（ぬけた ときも 読みこみ 直しで もどる）
export function restoreMusashi(p) {
  try {
    const d = load(p); if (!d) return; const s = qs(d); if (!s.possess) return;
    for (const sid of s.possess.subs || []) for (const L of [d.party, d.bench || []]) { const j = L.findIndex((m) => m.id === sid); if (j >= 0) { d.box.push(L.splice(j, 1)[0]); break; } }   /* 第69版: 裏に 入った 助っ人も */   // v3.0: 助っ人は 預かり所へ
    const i = d.box.findIndex((m) => m.id === s.possess.id);
    if (i >= 0 && s.possess.idx >= 0 && !canJoin(d, d.box[i]) && canBench(d, d.box[i])) { const [m] = d.box.splice(i, 1); d.bench = d.bench || []; d.bench.push(m); }   /* 第69版: 表が いっぱいなら 裏へ */
    else if (i >= 0 && s.possess.idx >= 0 && canJoin(d, d.box[i])) { const [m] = d.box.splice(i, 1); d.party.splice(Math.min(s.possess.idx, d.party.length), 0, m); try { fixParty(d); } catch {} }
    else if (i >= 0 && (s.possess.bidx ?? -1) >= 0) { const [m] = d.box.splice(i, 1); d.bench = d.bench || []; d.bench.splice(Math.min(s.possess.bidx, d.bench.length), 0, m); while (benchUse(d) > 4 && d.bench.length > 1) { let j = d.bench.length - 1; while (j >= 0 && d.bench[j] === m) j--; if (j < 0) break; d.box.push(d.bench.splice(j, 1)[0]); } }   // 第69版: 裏に もどす（あふれた 子は 預かり所へ）
    if (!d.party.length) { const src = (d.bench || []).length ? d.bench : d.box; if (src.length) d.party.push(src.shift()); }   /* 第69版 */
    delete s.possess; save(p, d);
  } catch {}
}
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => { if (initialSpawn) system.runTimeout(() => restoreMusashi(p), 40); }); } catch {}

// ---- 戦いの 中の ムサシの ひとこと（チャット）----
const say1 = (B, list, tag = "ムサシ") => { const l = pick(list); for (const x of B.players || []) try { x.p.sendMessage(`§c§l${tag}§r§f「${l}」`); } catch {} };
const isMus = (f) => f && f.m && f.m.sp === "musashi" && f.side === "a" && !f.guest;
export function musashiBattleStart(B) { try { if (B.pvp) return; const f = (B.allies || []).find(isMus); if (f) { B.mSaid = {}; say1(B, M_START); } } catch {} }
export function musashiAct(B, a, fx) {
  try {
    if (!B || B.pvp || !fx) return;
    const me = (B.allies || []).find(isMus); if (!me) return;
    B.mSaid = B.mSaid || {};
    const ko = fx.ko || [], dmg = fx.dmg || [];
    if (ko.includes(me)) { say1(B, M_FAINT); return; }
    if (a.actor === me) {
      if (ko.some((t) => t.side === "e")) { say1(B, M_KILL); return; }
      if (dmg.some((x) => x.crit && x.t.side === "e")) { say1(B, M_CRIT); return; }
      if (Math.random() < 0.55) say1(B, M_ATTACK);
      return;
    }
    if (dmg.some((x) => x.t === me && x.d > 0)) {
      if (me.hp > 0 && me.hp < me.mx.hp * 0.3 && !B.mSaid.pinch) { B.mSaid.pinch = 1; say1(B, M_PINCH); return; }
      if (Math.random() < 0.35) say1(B, M_HURT);
    }
  } catch {}
}
export function musashiWin(B) { try { if (!B.pvp && (B.allies || []).some((f) => isMus(f) && f.hp > 0)) say1(B, M_WIN); } catch {} }
// ---- 戦いの 中で 魔神の鍔を 使う（ムサシ → エンマの 姿）----
export const ENMA_MOVES = ["g_hades6", "xp_dark6", "g_hades3", "du_fire_dark"];
export function tsubaReady(p, d, mine) { try { const s = qs(d); return !!(s.enmaClear && hasTsuba(p) && mine.some((f) => f.m && f.m.sp === "musashi" && f.hp > 0 && f.hp <= f.mx.hp * 0.5 && !f.lookAs)); } catch { return false; } }   // v3.0: ムサシの HPが 半分 以下の とき
export function tsubaTransform(f, log) {
  if (!f || f.hp <= 0 || f.hp > f.mx.hp * 0.5 || f.lookAs) return false;   // v3.0: ムサシの HPが 半分 以下の ときだけ
  f.lookAs = "enma"; f.name = "魔神エンマ（ムサシ）";
  // 顕現: 全回復・全能力 2段階 上昇・特性が かわる
  f.hp = f.mx.hp; f.mp = f.mx.mp; f.dead = false; for (const k of Object.keys(f.ail || {})) f.ail[k] = 0; f.boundT = 0;
  if (f.m) { f.m.hp = hpBack(f); f.m.mp = f.mp; }
  for (const k of ["atk", "wpn", "mat", "def", "mdf", "spd", "brt"]) f.buf[k] = Math.min(6, (f.buf[k] || 0) + 2);
  f.tr = { ...f.tr, acts: [3, 4], majinAura: 0.3, first: true, topPri: true, nocap: true, critguard: true, dealt: { ...(f.tr.dealt || {}), weapon: ((f.tr.dealt || {}).weapon || 0) + 0.3, phys: ((f.tr.dealt || {}).phys || 0) + 0.3 } };
  if (f.tr0) f.tr0 = { ...f.tr0, tr: { ...f.tr } };   // 打ち消されても もどる
  for (const id of [...ENMA_MOVES, "sig_enma"]) if (MOVES_OK(id) && !f.moves.includes(id)) f.moves.push(id);
  log.push("§4§lムサシは 魔神の鍔を 掲げた！", "§4赤黒い 霧が ムサシを 包み……§l魔神エンマが 顕現した！", "§d全回復・全能力 2段階 上昇！", "§5特性: §f3〜4回行動・魔神の闘気（相手を ときどき 動けなく する）・最優先行動・上限なし・会心無効・武系と 物理系 +30%");
}
