// v2.9.14: 魔神編（カゲツに 勝った あと）。ムサシと 魔神の鍔と エンマ
import { world, system } from "@minecraft/server";
import { talk, tell } from "./talk.js";   /* 第108版: 会話は フォームで 止めない */
import { SPECIES, ITEMS, MOVES } from "./data.js";
const MOVES_OK = (id) => !!MOVES[id];
import { makeMonster, addMon, calcStats, STATS, TAL_MAX, canJoin, fixParty, hpBack, canBench, benchUse } from "./core.js";
import { load, save, mark, allMons, allMonsDeep } from "./store.js";
import { busy, ok, notice, confirm, sound, particle, setJob, showTitle, countItem, choose, ICON } from "./ui.js";
import { TOWNS, townPos, getTown } from "./structures.js";
import { scene, act, go, knock, knockP, shake, flash, fx, wave, fade, pause, spot, lookAt, lookUp, camAt, emote, PJ, HAKU_SP, stoneFx } from "./stage2.js";
import { M_START, M_ATTACK, M_CRIT, M_KILL, M_HURT, M_PINCH, M_FAINT, M_WIN, M_MAJIN, M_FIELD } from "./musashi_lines.js";

export const MUSASHI_TOWN = "t42";   /* 第69版: はがねの 村 クロガネ（刀鍛冶の 村）。名前で さがし直す */
const musashiTownId = () => { try { return (TOWNS.find((t) => /クロガネ/.test(t.name)) || { id: MUSASHI_TOWN }).id; } catch { return MUSASHI_TOWN; } };
export const MUSASHI_JOB = 19;
const COL = "§c§l";
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const qs = (d) => d.story || (d.story = {});
export const hasTsuba = (p) => countItem(p, "mrpg:k_hilt") > 0;
export function musashiTownInfo() { const t = TOWNS.find((x) => x.id === musashiTownId()); if (!t) return null; const i = getTown(t.id); return { t, pos: i && i.built ? i : townPos(t), built: !!(i && i.built) }; }
async function say(p, who, lines, c = COL) { await talk(p, who, lines, c); }
const story_mon = (d) => allMons(d).find((m) => m.sp === "musashi" && m.storyMusashi) || allMons(d).find((m) => m.sp === "musashi");
const anyMusashi = (d) => allMonsDeep(d).some((m) => m && m.sp === "musashi");

// ---- 町の ムサシ（仲間に なる 前の プレイヤーが 近くに いる ときだけ 立っている）----
system.runInterval(() => {
  const M = musashiTownInfo(); if (!M || !M.built || typeof M.pos.y !== "number") return;
  const ow = world.getDimension("minecraft:overworld");
  let want = false;
  for (const p of world.getAllPlayers()) {
    if (p.dimension.id !== "minecraft:overworld") continue;
    if (Math.hypot(p.location.x - M.pos.x, p.location.z - M.pos.z) > 72) continue;
    let d = null; try { d = load(p); } catch {}
    if (d && !qs(d).musashiJoin) want = true;
  }
  let have = []; try { have = ow.getEntities({ type: "mrpg:npc", tags: ["mrpg_musashi"] }); } catch {}
  if (!want) { for (const e of have) try { e.remove(); } catch {} return; }
  have = have.filter((e) => ok(e)); for (const e of have.slice(1)) try { e.remove(); } catch {}
  if (have.length) return;
  try {
    // v3.0: 建物の 中や 屋根に ならない 場所（地面の 高さが 町と ほぼ 同じ 所）を さがして 立つ
    let pos = null;
    for (const [dx, dz] of [[7.5, 6.5], [-6.5, 6.5], [6.5, -7.5], [-7.5, -6.5], [0.5, 9.5], [9.5, 0.5], [0.5, -9.5], [-9.5, 0.5], [3.5, 3.5]]) {
      let top = null; try { top = ow.getTopmostBlock({ x: Math.floor(M.pos.x + dx), z: Math.floor(M.pos.z + dz) }); } catch {}
      const ty = top ? top.location.y + 1 : null;
      if (ty === null || M.pos.y === null || M.pos.y === undefined) continue;
      if (Math.abs(ty - M.pos.y) <= 2 && !/water|lava/.test(String(top.typeId))) { pos = { x: M.pos.x + dx, y: ty, z: M.pos.z + dz }; break; }
    }
    if (!pos) pos = { x: M.pos.x + 0.5, y: (M.pos.y ?? 64) + 1, z: M.pos.z + 0.5 };
    const e = ow.spawnEntity("mrpg:npc", pos);
    setJob(e, MUSASHI_JOB); e.addTag("mrpg_npc"); e.addTag("mrpg_musashi");
    e.nameTag = "§7さすらいの 武士";
  } catch {}
}, 100);

// ---- 話しかける ----
export async function musashiTalk(p, ent) {
  let d = load(p); if (!d) return;
  const s = qs(d);
  if (s.musashiJoin) { await notice(p, "ムサシ", "§7（ムサシは もう 仲間だ。ガイドブックの「ストーリー」→「ムサシと 話す」で 話せる）"); return; }
  if (!(s.ending && s.hiltGot && hasTsuba(p))) {
    await say(p, "さすらいの 武士", [pick(["鍔さえ あれば……。この 村の 鍛冶でも 打てねえのか……", "師匠は「まだ 早い」の 一点張りだ。くそっ……。", "……ん？ なんだ、見せもんじゃねえぞ。", "急がねえと……あいつは もう 千年も ひとりなんだ。"])], "§7§l");
    return;
  }
  if (s.musashiMet) { await say(p, "ムサシ", ["よう、来たか。……準備は いいか？ 腕だめしだ！"]); return "spar"; }   // v3.0 第63版: 2回目からは 1行
  // 鍔を 見つける（第121版: 町の 武士が 鍔を 見て 泣き、刀に 手を かけ、名乗る）
  await scene(p, async (C) => {
    const M = ok(ent) ? C.keep(ent) : C.npc("§7さすらいの 武士", MUSASHI_JOB, 3.5);
    const H = C.hero(), hs = async (L) => { if (C.hn) await talk(p, C.hn, L, "§d"); };
    await say(p, "さすらいの 武士", ["{shock,!,jump}……おい、待て！ その 鍔……", "{cry,tears,up}ちくしょう、§eきれいだ§f……！ なんで こんなに きれいなんだよ……！"], "§7§l");
    await hs(["{sweat,汗}え、ちょ…… 泣いてる！？ 大の 大人が！？"]);
    act(M, "raise"); sound(p, "game.player.attack.sweep", 1); shake(p, 0.3, 0.3);
    await say(p, "さすらいの 武士", ["{rage,怒,low}……おい、その 鍔、どこで 手に 入れた！ 答えに よっちゃ 斬るぞ！"], "§7§l");
    if (H) { act(H, "guard"); await go(H, spot(p, 1.4, 0), 6, true); await hs(["{rage,怒,jump}ちょっと！ 刀 しまって！ カゲツさんに 託されたの！ ほんとだって！"]); }
    else await tell(p, "あなた", "§7（カゲツに 託された ことを 話した）");
    if (M) { act(M, "bow"); try { M.nameTag = "§cムサシ"; } catch {} }
    await say(p, "ムサシ", ["{shock,…}師匠が……お前に 託したのか。", "{blush,汗}……悪い、名乗ってなかった。俺は §cムサシ§f。カゲツ師匠の 弟子だ。"]);
    act(H, 0); act(M, "hold");
    await say(p, "ムサシ", ["{closed,up}……この 鍔の 銘、クロガネの 鍛冶の ものだ。千年前、§6うちの 工房の 先祖§f が 打った。", "{sad}親父は 工房の 奥の 部屋を 絶対に 開けねえ。……あそこに 何が あるのか、俺は 知らねえ。", "{closed,…,up}……間違いねえ。打ったのは クロガネ、千年 守って きたのは 師匠の §6剣の 家§f だ。"]);
    act(M, 0);
    await say(p, "ムサシ", ["{sad}その 鍔は、千年前の 剣士 §4エンマ§f の 刀に はまってた ものだ。 ……エンマは、§cうちの 家の 先祖§f なんだ。", "{angry,low}エンマは 石板の王――厄王を 斬って、その 悪意を 自分の 体に 封じた。……そして 魔神に なった。", "{sad,up}鍔は 悪意を 抑える 栓だ。鍔を なくした エンマは、悪意に のまれた まま なんだ。"]);
    if (s.enmaDream) { await hs(["{shock,!,jump}あっ…… それ、神殿で 見た 夢の 人！？"]); await say(p, "ムサシ", ["{shock,!}……お前ら、神殿で 夢を 見たのか？ 鍔の ない 刀を 下げた 男の。", "それが エンマだ。厄王の 残りの 悪意が 鍔に 集まって、あいつを 呼んでる。"]); }
    await say(p, "ムサシ", ["{closed}神殿で 鍔を 捧げれば、刀に 鍔が もどる。悪意から あいつを 引きはがせる かもしれねえ。", "{rage,怒,up}みんな 斬れって 言う。でも 俺は、エンマを 救いたいんだ。"]);
    act(M, "point"); await say(p, "ムサシ", ["{smile,☆,low}……師匠が 認めた 腕、見せてくれ。本気で 行くぞ！"]);
    await hs(["{smile,☆}よーし、やっちゃえ！ ……泣き虫 剣士なんかに 負けないでよ？"]);
  });
  { const d1 = load(p); if (d1) { qs(d1).musashiMet = 1; save(p, d1); } }   // v3.0 第63版: 出会いの 場面は 1回だけ
  return "spar";
}
// 腕だめし（story.js の fight を もらう）→ 仲間に
export async function musashiSpar(p, fight) {
  try { return await musashiSpar0(p, fight); } finally { busy.delete(p.id); }   // v3.0: とちゅうで 終わっても 印を のこさない
}
async function musashiSpar0(p, fight) {
  let res = null;
  try { const d0 = load(p); if (d0 && !qs(d0).musashiJoin) { const { duel } = await import("./cine.js"); await duel(p, "§c§l炉の 前の 一騎打ち", "§fムサシの 子と 火花を 散らす！", { b: "musashi" }); } } catch {}   /* 第106版: 魔3 */
  for (let k = 0; k < 6; k++) {
    const d0 = load(p); if (!d0) return;
    for (const m of d0.party) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; } save(p, d0);
    busy.delete(p.id);
    res = await fight(p, { team: [{ sid: "musashi", lv: 90, q: 1, plus: 15 }] }, { tier: 2, name: "ムサシ", fam: "", npc: null, arena: "ムサシの 腕だめし", theme: "shrine", speaker: "ムサシ", lines: { half: "やるじゃねえか……まだまだ！", low: "へへ……強えな、お前。" } });
    busy.add(p.id);
    if (res === "win") break;
    let again = false; try { again = await confirm(p, "負けて しまった……", "§c§lムサシ§r§f「どうした、そんな もんか？ もう 一回 来い！」\n\n§fもう一度 挑みますか？ §7（仲間は 全回復する）", "もう一度 挑む", "あとで"); } catch {}
    if (!again) { await say(p, "ムサシ", ["準備が できたら また 来い。鍔は お前が 持ってろ。師匠が 選んだのは お前だ。"]); return; }
  }
  if (res !== "win") { try { await say(p, "ムサシ", ["今日は ここまでだ。仲間を 鍛えて また 来い。……待ってるぜ。"]); } catch {} return; }
  const d = load(p); if (!d) return;
  const s = qs(d);
  if (s.musashiJoin) return;   // 2回 仲間に ならない
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  await scene(p, async (C) => {
    const M = C.npc("§cムサシ", MUSASHI_JOB, 3.5), H = C.hero();
    act(M, "kneel"); shake(p, 0.3, 0.3); await pause(10); act(M, 0);
    await say(p, "ムサシ", ["{smile,息}……ははっ、すげえな お前。師匠が 託す わけだ。", "{smile,☆,up}決めた、俺も 行く。エンマを 斬りに じゃねえ、救いに だ。", "{smile}鍔は お前が 持っててくれ。……頼んだぜ。"]);
    if (C.hn) { act(H, "cheer"); await talk(p, C.hn, ["{smile,♪,jump}やったね！ 仲間 ふえた！ ……泣き虫 だけど！"], "§d"); act(M, "recoil"); await say(p, "ムサシ", ["{blush,怒,jump}泣いてねえ！ ……あれは 汗だ！"]); }
  });
  const m = makeMonster("musashi", 60, true);
  m.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(m.tal[k], 20)])); m.storyMusashi = 1;
  const c = calcStats(m); m.hp = c.hp; m.mp = c.mp;
  addMon(d, m); mark(d.own, "musashi"); mark(d.seen, "musashi");
  s.musashiJoin = 1; s.musashiMet = 1;
  save(p, d);
  try { showTitle(p, "§c§lムサシが 仲間に なった！", { subtitle: "§f次は §5閻魔の神殿§f へ", fadeInDuration: 8, stayDuration: 60, fadeOutDuration: 14 }); } catch {}
  sound(p, "random.levelup", 1.2); particle(p, "minecraft:totem_particle", 1.3);
  await notice(p, "魔神編", ["§c§lムサシが 仲間に なった！", "", "§fムサシと §5閻魔の神殿§f へ 行き、§4魔神の鍔§f を 捧げよう。", "§7（神殿の 前で ガイドブックを 使う。場所は 右上の 案内）", "§7（ガイドブック → ストーリー →「ムサシと 話す」）"].join("\n"));
}

// ---- ムサシと 話す（ガイドブック）----
export const MUSASHI_EXTRA = [];   /* 第76版: { label, cond(p,d,s), run(p,d) } を 追加ストーリーが 入れる */
const TOPICS = [
  ["家の こと", (s) => ["俺は クロガネの 刀鍛冶の 家の 生まれだ。親父は 鍔ばかり 打ってた。", "ガキの ころ、師匠の 家で 鍔の ない 刀を 見たんだ。", "なんでか、その 刀が 泣いてる 気が した。……それから ずっと 頭から 離れねえ。"]],
  ["鍔の こと", (s) => ["赤黒く 光ってるだろ。厄王の 残りの 悪意が、こいつに 流れこんでるんだ。", "この 鍔は 千年前、エンマの 刀に はまってた。悪意を 抑える 栓みたいな もんだ。", s.enmaClear ? "今は 鍔を 通して、エンマの 力を 少し 借りられる。いざって ときは 掲げてくれ。" : "鍔が 刀に もどれば、エンマは 正気に もどれる……はずだ。"]],
  ["エンマの こと", (s) => s.enmaClear ? ["魔神なんて 呼ばれてたが、話してみりゃ 無口な 剣士だ。", "千年 ひとりで 悪意を 抱えてたんだぜ。……文句 ひとつ 言わずに な。", "あいつが 言ってた §5常世§f……。悪意の 出どころ、か。"] : ["エンマは 魔神なんて 呼ばれてるが、もとは 人間の 剣士だ。", "千年前、厄王を 斬って……その 悪意を 自分の 体に 封じこめた。", s.enmaDream ? "お前が 夢で 見た 男。あれが 鍔を なくした エンマだ。" : "世界を 救った やつが、千年 ひとりで 悪意と 戦ってる。放って おけるかよ。"]],
  ["厄王の こと", (s) => ["厄王が 倒れて、世界は 静かに なった。……表向きは な。", "悪意って やつは 倒しても 消えねえ。行き場を なくして、鍔に 集まって きた。", "だから 鍔が 光りだした。……エンマを 呼んでるんだ。"]],
  ["カゲツの こと", (s) => s.kagetsuDead ? ["師匠は…… 鍔を 捧げた 日に、釣り竿を 握った まま 眠った。", "千年分の 眠気が いっぺんに 来たんだとよ。……ずっと『眠い』って 言ってたもんな。", "ちくしょう。……いい 寝顔 だったぜ。"] : ["師匠の 家は、千年 エンマの 刀を 守ってきた 家だ。", "普段は 釣りして 昼寝してる くせに、刀を 持つと 別人だ。", "ルミナの オルドじいさんとは、若い ころからの 好敵手 なんだと。……勝ち負けの 数、二人とも 一つも 忘れて ねえらしい。", "師匠は 俺に 鍔を 預けなかった。お前に 託した。……悔しいけど、わかる 気が する。"]],
  ["刀の こと", (s) => ["この 金の 柄の 刀は、親父が 打って くれた。銘は ない。", "「名前を つけると 刀が 驕る」ってのが 親父の 口ぐせだ。", "エンマの 刀を 受け止める ために、毎日 振ってきた。"]],
  ["これから", (s) => s.enmaClear ? ["……変な 気分だぜ。千年前の 英雄と 旅を するなんてな。", "鍔を 掲げれば、俺の 体に エンマの 力が 宿る。いざって ときは 使ってくれ。", "§5常世§f を 知る 者が、いつか 訪ねて くる……か。その時が 来たら 付き合うぜ。"] : ["閻魔の神殿で 鍔を 捧げれば、刀に 鍔が もどる。", "……何が 起きても、エンマを 斬るなよ。救うんだ。", "お前と 一緒なら、きっと 届く。"]],
];
export function canTalkMusashi(d) { const s = qs(d); return !!s.musashiJoin; }
export async function musashiTalkMenu(p, d) {
  let s = qs(d);
  for (;;) {
    const ex = MUSASHI_EXTRA.filter((t) => { try { return t.cond(p, d, s); } catch { return false; } });   /* 第76版: 追加ストーリーの 話題 */
    let i = await choose(p, "ムサシと 話す", `§c§lムサシ§r\n§7${s.enmaClear ? "カゲツの 弟子。今は 鍔を 通して エンマと 旅を している" : "カゲツの 弟子。エンマを 救う ため 仲間に なった"}`, [...ex.map((t) => [t.label, ICON("i_fight")]), ...TOPICS.map(([t]) => [`§l${t}`, ICON("i_help")]), ["§7戻る", ICON("i_back")]]);
    if (i >= 0 && i < ex.length) { await ex[i].run(p, d); const d2 = load(p); if (!d2) return; d = d2; s = qs(d); continue; }
    if (i < 0 || i - ex.length >= TOPICS.length) return;
    i -= ex.length;
    s.mtalk = [...new Set([...(s.mtalk || []), i])]; save(p, d);
    await say(p, "ムサシ", TOPICS[i][1](s));
  }
}
// ときどき チャットで ひとこと（ムサシが パーティに いる とき）
const CHAT = M_FIELD.map((l) => ["ムサシ", l]);
const CHAT_E = [["エンマ", "……人の 世は、騒がしいな。だが 嫌いでは ない。"], ["ムサシ", "おい エンマ、勝手に 鍔から 話しかけるな。びっくりするだろ。"], ["エンマ", "……刀が 鍔を 取り戻した。今は それで 足りる。"]];
system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    try {
      if (busy.has(p.id) || Math.random() > 0.4) continue;
      const d = load(p); if (!d) continue; const s = qs(d);
      if (!s.musashiJoin || !d.party.some((m) => m.sp === "musashi")) continue;
      let pool = s.enmaClear ? CHAT : CHAT.filter(([, l]) => !/エンマ|魔神|鍔|冥府/.test(l));   // v3.0: 先の 話は しない
      if (s.kagetsuDead) pool = pool.map((x) => (/師匠、元気かな/.test(x[1]) ? ["ムサシ", "師匠、向こうでも 釣り してるかな。……してるな、絶対。"] : x));
      const [who, line] = pick(s.enmaClear && d.party.some((m) => m.sp === "enma") ? [...pool, ...CHAT_E] : pool);
      p.sendMessage(`§${who === "エンマ" ? "4" : "c"}${who}§f「${line}」`);
    } catch {}
  }
}, 20 * 60 * 3);

// ---- 神殿: 鍔を 捧げる → ムサシに 取り憑く → 倒すと ムサシに もどる ----
export async function possessionFlow(p, d, fight) {
  const s = qs(d);
  let mus = story_mon(d);
  if (!mus && anyMusashi(d)) { await notice(p, "閻魔の神殿", "§7ムサシは 牧場に いるようだ。§fパーティか 預かり所に もどしてから 来よう。"); return true; }
  if (!mus && s.musashiBack) { await notice(p, "閻魔の神殿", "§7ムサシが いない……。§f（ムサシが 自動で 戻って くるのは 1回だけ。もう 戻って こない。困ったら ガイドブック → 冒険 →「バグを 直す」）"); return true; }
  if (!mus) {   // v2.9.14: ムサシが いない（前の 版で わかれた など）→ 1度だけ 物語の ムサシを もどす
    s.musashiBack = 1;
    mus = makeMonster("musashi", 60, true); mus.tal = Object.fromEntries(STATS.map((k) => [k, Math.max(mus.tal[k], 20)])); mus.storyMusashi = 1;
    const c0 = calcStats(mus); mus.hp = c0.hp; mus.mp = c0.mp; addMon(d, mus); mark(d.own, "musashi"); save(p, d);
    await tell(p, "閻魔の神殿", "§c§lムサシ§r§f「おーい！ 置いてくなよ！ ……神殿だろ？ 俺も 行く！」");
  }
  if (!d.party.some((m) => m !== mus && m.hp > 0)) { await notice(p, "閻魔の神殿", "§cムサシ§f「待て。何が 起きるか わからねえ。ほかの 仲間も 連れて こい！」\n§7ムサシ 以外に 戦える 仲間を 表（パーティ）に 入れてから 来よう。§8（裏の 子は 仲間メニューで 表へ・倒れた 子は 宿屋で）"); return true; }
  /* 第121版: 神殿の 場面。鍔が 燃え、ムサシが 掲げ、霧に 呑まれて エンマに 変わる */
  await scene(p, async (C) => {
    const M = C.npc("§cムサシ", MUSASHI_JOB, 2.5, 1.4), H = C.hero(), hs = async (L) => { if (C.hn) await talk(p, C.hn, L, "§d"); };
    const alt = spot(p, 6, 0);
    if (alt) { camAt(p, spot(p, 3, -2, 1.6) || p.location, alt); fx(p.dimension, "minecraft:basic_flame_particle", alt, 16, 0.6); sound(p, "mob.blaze.shoot", 0.8); shake(p, 0.3, 0.6); await pause(20); }
    await hs(["{shock,!,jump}鍔が 燃えてる！？ ……玉座の 前の 刀も、ふるえてる！"]);
    act(M, "raise"); await say(p, "ムサシ", ["{closed,up}……千年 待たせたな、エンマ。お前の 鍔だ。", "{angry,!,low}来るぞ……！ 構えろ！"]);
    if (!s.kagetsuDead) {   /* 第106版: 魔7 鍔を 捧げた 瞬間、カゲツに 千年分の 寿命が 来る（同じ ころの ルミナへ 切りかえる）*/
      s.kagetsuDead = 1; save(p, d);
      try { p.runCommand("camera @s fade time 0.4 0.6 0.4 color 0 0 0"); } catch {}
      try { p.onScreenDisplay.setTitle(" ", { subtitle: "§7― 同じ ころ、ルミナの 闘技場 ―", fadeInDuration: 8, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
      const K = C.npc("§7カゲツ", PJ("kagetsu", 8), 7, -4); act(K, "hold");
      if (K) { camAt(p, spot(p, 5.5, -2.4, 1.3) || p.location, { x: K.location.x, y: K.location.y + 1.3, z: K.location.z }); await pause(20); }
      await talk(p, "カゲツ", ["{closed,息}……そろそろ、寝させて くれ", "{smile,…}……そうだ。オルドに 伝えて くれ。§e百と 三勝§f。……そう 言えば、わかる"], "§7");
      act(K, "down"); sound(p, "random.fizz", 0.4); await pause(30);
      await tell(p, "ルミナの 闘技場", "§8……千年分の 眠気が、一度に 来た。それは、本当に なった。");
      flash(p, "0 0 0"); try { if (K) K.remove(); } catch {}
      if (alt) camAt(p, spot(p, 3, -2, 1.6) || p.location, alt);
      await hs(["{shock,…,up}……今、鍔から カゲツさんの 声が した。『百と 三勝』って……。", "{sad}……うん。ちゃんと 伝える。村長に。"]);
    }
    for (const q of world.getAllPlayers()) if (q.dimension.id === p.dimension.id && Math.hypot(q.location.x - p.location.x, q.location.z - p.location.z) < 64) { sound(q, "mob.wither.spawn", 0.6); sound(q, "ambient.weather.thunder", 0.8); }
    try { p.runCommand("camera @s fade time 0.3 0.8 0.5 color 60 0 0"); } catch {}
    /* 霧が ムサシを 包む */
    if (M) { lookAt(p, M); for (let k = 0; k < 12; k++) { const l = M.location; fx(p.dimension, k % 2 ? "minecraft:basic_flame_particle" : "minecraft:basic_smoke_particle", { x: l.x + Math.cos(k * 0.9) * 1.3, y: l.y + 0.2 + k * 0.15, z: l.z + Math.sin(k * 0.9) * 1.3 }, 3, 0.2); await pause(2); } act(M, "kneel"); }
    await say(p, "ムサシ", ["{rage,cry,up}ぐっ……！ これが……千年分の 悪意か……！"]);
    act(H, "guard"); await hs(["{rage,怒,jump}ムサシ！ 負けないで！ ……聞こえてる！？"]);
    /* 衝撃波: ムサシが エンマの 姿に 変わり、ヒロインと プレイヤーが はじかれる */
    let E = null; if (M) { const at = { ...M.location }; flash(p, "160 0 0"); shake(p, 0.9, 0.8); await wave(p, at, "minecraft:basic_flame_particle"); knockP(p, at); await knock(H, at, 2.5); try { M.remove(); } catch {} E = C.mon("enma", 0.01, 0); if (E) try { E.teleport(at); } catch {} }
    try { showTitle(p, "§4§l魔神 エンマ", { subtitle: "§7千年の 悪意が ムサシを 呑みこむ", fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 15 }); } catch {}
    if (E) { lookAt(p, E); emote(E, "dots"); }
    await say(p, "エンマ", ["……"], "§4§l");   // v3.0: エンマは 何も 語らない
  });
  // ムサシは この 戦いの あいだ 仲間から はずす（取り憑かれて いる）
  const inParty = d.party.indexOf(mus);
  if (inParty >= 0) { d.party.splice(inParty, 1); d.box.push(mus); }
  const inBench = (d.bench || []).indexOf(mus); if (inBench >= 0) { d.bench.splice(inBench, 1); d.box.push(mus); }   // 第69版: 裏の ムサシも はずす
  // v3.0: あいた 枠には 預かり所の 強い 子が 一時的に 入る（戦いの あとで もどる）
  const subs = [];
  if (inParty >= 0) {
    const pool = d.box.filter((m) => m && m !== mus && m.sp !== "musashi" && m.sp !== "enma" && !m.storyMusashi).sort((a, b) => (b.lv || 0) - (a.lv || 0) || (b.plus || 0) - (a.plus || 0));
    for (const m of pool) { if (subs.length >= 3) break; if (canJoin(d, m)) { d.box.splice(d.box.indexOf(m), 1); d.party.push(m); subs.push(m); } }
    if (subs.length) await notice(p, "閻魔の神殿", `§7ムサシの かわりに、預かり所から §f${subs.map((m) => m.nm || SPECIES[m.sp]?.name).join("・")}§7 が かけつけた！\n（戦いの あとで 預かり所に もどる）`);
  }
  s.possess = { id: mus.id, idx: inParty, bidx: inBench, subs: subs.map((m) => m.id) }; save(p, d);
  let res = null;
  try {
    res = await fight(p, { team: [{ sid: "enma", lv: 100, q: 1, plus: 99 }] }, { tier: 2, name: "エンマ（ムサシの 体）", fam: "", npc: null, arena: "閻魔の 裁き場", theme: "hell", enma: true, enmaN: 0, friends: true, speaker: "エンマ", lines: { win: "……", lose: "……" } });
  } finally { restoreMusashi(p); }
  d = load(p); if (!d) return true;
  const st = qs(d);
  for (const m of [...d.party, ...(d.bench || [])]) { const c = calcStats(m); m.hp = c.hp; m.mp = c.mp; }
  if (res !== "win") {
    save(p, d);
    await scene(p, async (C) => {
      const M = C.npc("§cムサシ", MUSASHI_JOB, 3, 0.8); act(M, "kneel"); if (M) fx(p.dimension, "minecraft:basic_smoke_particle", M.location, 10, 0.6);
      await tell(p, "閻魔の神殿", "§7赤黒い 霧は ムサシの 体から 抜け、鍔の 中へ 戻っていった。§d魔神の鍔が 手元に 戻った。");
      await say(p, "ムサシ", ["{sweat,息,up}はぁ、はぁ……あいつ、泣いてた 気が する。もう一度 行こう。"]);
      await tell(p, "閻魔の神殿", "§7（神殿の 前で もう一度 ガイドブックを 使う）");
    });
    return true;
  }
  // 勝った: ムサシに もどる・エンマが 仲間に
  const first = !st.enmaClear;
  try { p.runCommand("camera @s fade time 0.4 1.0 0.8 color 255 255 255"); } catch {}
  await scene(p, async (C) => {
    const M = C.npc("§cムサシ", MUSASHI_JOB, 3, 0.8), H = C.hero(), hs = async (L) => { if (C.hn) await talk(p, C.hn, L, "§d"); };
    act(M, "down"); if (M) { lookAt(p, M); fx(p.dimension, "minecraft:basic_smoke_particle", M.location, 12, 0.8); }
    await tell(p, "決着", "§f赤黒い 霧が ほどけ、鍔へ 吸いこまれていく……鍔の ない 刀に、千年ぶりに 鍔が おさまった。");
    act(M, "kneel"); await say(p, "ムサシ", ["{closed,息}……っ、はぁ……戻った、のか……？"]);
    if (H) { await go(H, spot(p, 2.4, 0.2), 8, true); await hs(["{rage,怒,jump}戻った のか、じゃ ないよ！ ……もう、びっくり させないで！"]); }
    act(M, 0); await say(p, "ムサシ", ["{smile}……ははっ。やったな、お前。", "{shock,!,jump}……おい、見ろ。刀の 前に 誰か 立ってる。"]);
    const E = C.mon("enma", 9, 0); if (E) { lookAt(p, E); await go(E, spot(p, 4.5, -0.8), 24); emote(E, "dots"); }
    await say(p, "エンマ", ["……負けた。だから、話す。", "千年前、妹が 石に なった。頭の 中で §5やさしい ささやき§f が 言った。『王を 斬れば、妹は 戻る』", "私は 王を 斬った。守り手も 斬った。……妹は、戻らなかった。"], "§4§l");
    sound(p, "mob.wither.ambient", 0.6); flash(p, "40 0 40"); if (E) fx(p.dimension, "minecraft:soul_particle", E.location, 12, 1);
    await hs(["{shock,!,jump}……今、どこかで 笑い声が……！"]);
    await say(p, "エンマ", ["§c……あの ささやきは、まだ 笑って いる。", "工房の 妹の 石像は、本物では ない。本当の 妹は §5常世§f で、今も 石の まま だ。", "ささやきの 主は、§4邪神§f。表の 伝承では §6ラグロア§f。本当の 名は…… §4ヴォルナグ§f。"], "§4§l");
    await say(p, "エンマ", ["私は 消えぬ。……§5常世§f を 知る 者が、いずれ おまえたちを 訪ねて くる。"], "§4§l");
    /* エンマが 粒に なって 鍔へ もどる */
    if (E) { const l = E.location, q = p.location; for (let k = 0; k <= 10; k++) { const t = k / 10; fx(p.dimension, "minecraft:basic_flame_particle", { x: l.x + (q.x - l.x) * t, y: l.y + 1 + (q.y - l.y) * t, z: l.z + (q.z - l.z) * t }, 3, 0.2); await pause(2); } }
    await fade(E, "minecraft:basic_flame_particle");
    if (first) {
      await go(M, spot(p, 3, -0.5), 6, true); act(M, "point");
      await say(p, "ムサシ", ["{shock,cry,jump}待てよ！ 消えちまうのか？ せっかく もどれたのに……！"]);
      sound(p, "block.bell.hit", 0.6); fx(p.dimension, "minecraft:basic_flame_particle", p.location, 10, 0.4);
      await say(p, "エンマ", ["消えは せぬ。鍔を 通して、小僧と 力を 分け合おう。", "……覚えて おけ。厄王の 悪意は、厄王が 生んだ ものでは ない。", "死者の 国 §5常世§f から 染み出した ものだ。", "常世を 知る 者は、まだ 生きて いる。……いずれ 時が 来れば、その 者が おまえたちを 訪ねて くる。"], "§4§l");
      act(M, 0); await say(p, "ムサシ", ["{smile,tears,up}……へっ。勝手な ご先祖さまだぜ。"]);
    }
  });
  if (st.kagetsuDead && !st.kagetsuMsg) { st.kagetsuMsg = 1; save(p, d); try { await kagetsuWord(p); } catch (e) { console.warn(`[MonsterRPG] kagetsuWord: ${e}`); } }   /* 第116版: カゲツの 伝言を ルミナの オルドへ */
  st.enmaClear = 1; st.enma = (st.enma || 0) + 1;
  const got = [];
  if (first) {   // v3.0: エンマは 仲間に ならない。鍔を ムサシに 使うと エンマの 姿に
    got.push("§c§lムサシが 仲間に もどった！", "§d魔神の鍔が 手元に 戻った。", "§d魔神の鍔: §f戦いの 中で ムサシの HPが 半分 以下の とき 使うと、§4魔神エンマ§f が 顕現する（全回復・全能力 2段階 上昇・3〜4回行動・魔神の闘気・最優先行動 など）");
  } else got.push("§d魔神の鍔が 手元に 戻った。");
  d.gold += 500000; got.push("§e50万タヨ");
  save(p, d);
  try { p.sendMessage(`§4§l★ エンマを 悪意から 解き放ち、ムサシを 取り戻した！ ★`); } catch {} sound(p, "ui.toast.challenge_complete", 1);   // v3.0: ほかの 人には 流さない（ネタバレ）
  try { showTitle(p, "§4§l魔神編 クリア", { subtitle: "§fエンマが 自分を 取りもどした", fadeInDuration: 10, stayDuration: 80, fadeOutDuration: 20 }); } catch {}
  await notice(p, "魔神編 クリア！", got.join("\n"));
  return true;
}
/* 第116版: ルミナの 牧場。石の ハクに 手を 置く オルドへ、カゲツの 伝言を 届ける */
export function kagetsuWord(p) {
  return scene(p, async (C) => {
    try { p.runCommand("camera @s fade time 0.4 0.8 0.6 color 0 0 0"); } catch {}
    try { showTitle(p, " ", { subtitle: "§7― ルミナの 牧場 ―", fadeInDuration: 8, stayDuration: 40, fadeOutDuration: 10 }); } catch {}
    const Hk = C.mon(HAKU_SP, 5, 0.9), O = C.npc("§eオルド", PJ("ordo", 8), 4.2, -0.3), H = C.hero();
    if (Hk) try { Hk.nameTag = "§7ハク（石）"; } catch {}
    act(O, "hold"); stoneFx(p, Hk, 8);
    if (O) camAt(p, spot(p, 1.6, 1.4, 1.6) || p.location, { x: O.location.x, y: O.location.y + 1.4, z: O.location.z });
    await pause(16);
    await tell(p, "ルミナの 牧場", ["§7牧場の すみ。石に なった §fハク§7 の 背中に 手を 置いて、§eオルド§7 が 北の 空を 見て いた。"]);
    if (H) { await go(H, spot(p, 3, -1.2), 10); act(H, "sad"); await talk(p, C.hn, ["{sad,…}……おじいちゃん。カゲツさんから、伝言。", "{closed}『オルドに 伝えて くれ。§e百と 三勝§f』……そう 言えば わかるって。"], "§d"); }
    else await tell(p, "ルミナの 牧場", ["§fあなたは カゲツの 言葉を 伝えた。§e『オルドに 伝えて くれ。百と 三勝』"]);
    await pause(20);
    await say(p, "オルド", ["{closed,…}…………。"], "§e");
    sound(p, "random.orb", 0.4); act(O, "up"); lookUp(p, spot(p, 6, -1, 6) || p.location);
    await say(p, "オルド", ["{smile,up}……ばかもん。§e百と 四§f じゃ。", "{smile}最後の 一つは、わしの 不戦勝 じゃろうが。"], "§e");
    if (H) act(H, "up");
    await tell(p, "北の 空", [`§7オルドは 泣かなかった。${C.hn ? `§d${C.hn}§7 も` : "あなたも"} 泣かなかった。`, "§7ただ、しばらく 二人で 北の 空を 見て いた。"]);
    stoneFx(p, Hk, 4); await pause(20);
  });
}
// 取り憑かれて いた ムサシを パーティに もどす（ぬけた ときも 読みこみ 直しで もどる）
export function restoreMusashi(p) {
  try {
    const d = load(p); if (!d) return; const s = qs(d); if (!s.possess) return;
    for (const sid of s.possess.subs || []) for (const L of [d.party, d.bench || []]) { const j = L.findIndex((m) => m.id === sid); if (j >= 0) { d.box.push(L.splice(j, 1)[0]); break; } }   /* 第69版: 裏に 入った 助っ人も */   // v3.0: 助っ人は 預かり所へ
    const i = d.box.findIndex((m) => m.id === s.possess.id);
    if (i >= 0 && s.possess.idx >= 0 && !canJoin(d, d.box[i]) && canBench(d, d.box[i])) { const [m] = d.box.splice(i, 1); d.bench = d.bench || []; d.bench.push(m); }   /* 第69版: 表が いっぱいなら 裏へ */
    else if (i >= 0 && s.possess.idx >= 0 && canJoin(d, d.box[i])) { const [m] = d.box.splice(i, 1); d.party.splice(Math.min(s.possess.idx, d.party.length), 0, m); try { fixParty(d); } catch {} }
    else if (i >= 0 && (s.possess.bidx ?? -1) >= 0) { const [m] = d.box.splice(i, 1); d.bench = d.bench || []; d.bench.splice(Math.min(s.possess.bidx, d.bench.length), 0, m); while (benchUse(d) > 4 && d.bench.length > 1) { let j = d.bench.length - 1; while (j >= 0 && d.bench[j] === m) j--; if (j < 0) break; d.box.push(d.bench.splice(j, 1)[0]); } }   // 第69版: 裏に もどす（あふれた 子は 預かり所へ）
    if (!d.party.length) { const src = (d.bench || []).length ? d.bench : d.box; if (src.length) d.party.push(src.shift()); }   /* 第69版 */
    delete s.possess; save(p, d);
  } catch {}
}
try { world.afterEvents.playerSpawn.subscribe(({ player: p, initialSpawn }) => { if (initialSpawn) system.runTimeout(() => restoreMusashi(p), 40); }); } catch {}

// ---- 戦いの 中の ムサシの ひとこと（チャット）----
const say1 = (B, list, tag = "ムサシ") => { const l = pick(list); for (const x of B.players || []) try { x.p.sendMessage(`§c§l${tag}§r§f「${l}」`); } catch {} };
const isMus = (f) => f && f.m && f.m.sp === "musashi" && f.side === "a" && !f.guest;
export function musashiBattleStart(B) { try { if (B.pvp) return; const f = (B.allies || []).find(isMus); if (f) { B.mSaid = {}; say1(B, M_START); } } catch {} }
export function musashiAct(B, a, fx) {
  try {
    if (!B || B.pvp || !fx) return;
    const me = (B.allies || []).find(isMus); if (!me) return;
    B.mSaid = B.mSaid || {};
    const ko = fx.ko || [], dmg = fx.dmg || [];
    if (ko.includes(me)) { say1(B, M_FAINT); return; }
    if (a.actor === me) {
      if (ko.some((t) => t.side === "e")) { say1(B, M_KILL); return; }
      if (dmg.some((x) => x.crit && x.t.side === "e")) { say1(B, M_CRIT); return; }
      if (Math.random() < 0.3) say1(B, M_ATTACK);   /* 第89版: せりふを 20種類に したので 言う 回数も 減らす */
      return;
    }
    if (dmg.some((x) => x.t === me && x.d > 0)) {
      if (me.hp > 0 && me.hp < me.mx.hp * 0.3 && !B.mSaid.pinch) { B.mSaid.pinch = 1; say1(B, M_PINCH); return; }
      if (Math.random() < 0.35) say1(B, M_HURT);
    }
  } catch {}
}
export function musashiWin(B) { try { if (!B.pvp && (B.allies || []).some((f) => isMus(f) && f.hp > 0)) say1(B, M_WIN); } catch {} }
// ---- 戦いの 中で 魔神の鍔を 使う（ムサシ → エンマの 姿）----
export const ENMA_MOVES = ["g_hades6", "xp_dark6", "g_hades3", "du_fire_dark"];
export function tsubaReady(p, d, mine) { try { const s = qs(d); return !!(s.enmaClear && hasTsuba(p) && mine.some((f) => f.m && f.m.sp === "musashi" && f.hp > 0 && f.hp <= f.mx.hp * 0.5 && !f.lookAs)); } catch { return false; } }   // v3.0: ムサシの HPが 半分 以下の とき
export function tsubaTransform(f, log) {
  if (!f || f.hp <= 0 || f.hp > f.mx.hp * 0.5 || f.lookAs) return false;   // v3.0: ムサシの HPが 半分 以下の ときだけ
  f.lookAs = "enma"; f.name = "魔神エンマ（ムサシ）";
  // 顕現: 全回復・全能力 2段階 上昇・特性が かわる
  f.hp = f.mx.hp; f.mp = f.mx.mp; f.dead = false; for (const k of Object.keys(f.ail || {})) f.ail[k] = 0; f.boundT = 0;
  if (f.m) { f.m.hp = hpBack(f); f.m.mp = f.mp; }
  for (const k of ["atk", "wpn", "mat", "def", "mdf", "spd", "brt"]) f.buf[k] = Math.min(6, (f.buf[k] || 0) + 2);
  f.tr = { ...f.tr, acts: [3, 4], majinAura: 0.3, first: true, topPri: true, nocap: true, critguard: true, dealt: { ...(f.tr.dealt || {}), weapon: ((f.tr.dealt || {}).weapon || 0) + 0.3, phys: ((f.tr.dealt || {}).phys || 0) + 0.3 } };
  if (f.tr0) f.tr0 = { ...f.tr0, tr: { ...f.tr } };   // 打ち消されても もどる
  for (const id of [...ENMA_MOVES, "sig_enma"]) if (MOVES_OK(id) && !f.moves.includes(id)) f.moves.push(id);
  log.push("§4§lムサシは 魔神の鍔を 掲げた！", "§4赤黒い 霧が ムサシを 包み……§l魔神エンマが 顕現した！", "§d全回復・全能力 2段階 上昇！", "§5特性: §f3〜4回行動・魔神の闘気（相手を ときどき 動けなく する）・最優先行動・上限なし・会心無効・武系と 物理系 +30%");
}
