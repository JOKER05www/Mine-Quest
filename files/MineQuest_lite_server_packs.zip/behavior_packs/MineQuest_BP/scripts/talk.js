// 第108版: 物語の 会話を フォームで 止めない。せりふは チャットと 画面下の 文字に 流れる
// 第109版: 会話の あいだは「ムービー」: プレイヤーは その場で 止まり、話す 人が 身ぶり手ぶりで 話す。
//   しゃがむ（短く）= 次の せりふ ／ しゃがんだ まま 1.5秒 = スキップ（その 場面の 会話を ぜんぶ とばす。戦いは とばさない）
import { world, system } from "@minecraft/server";
import { notice, wait, ok, barNote } from "./ui.js";
const plain = (s) => String(s || "");
const SLOW = new Set(), SKIP = new Set(), LOCK = new Map(), LAST = new Map();   /* LAST: 最後に 会話が 終わった 時刻（4秒 あいたら 別の 場面 → スキップを 解く）*/
let FIND = null;   /* (p, who) → 話す 人の エンティティ（saga.js が 決める）*/
export function setSpeakerFinder(f) { FIND = f; }
export function clearSkip(p) { try { SKIP.delete(p.id); } catch {} }
const cmd = (p, c) => { try { p.runCommand(c); return true; } catch { return false; } };
const HUD = ["hotbar", "health", "hunger", "armor", "status_effects", "item_text", "paperdoll", "crosshair", "air_bubbles", "progress_bar"];
/* 第112版: ムービーの カメラ。話す 人に 寄る（肩ごし）・2人を 横から・場面の 始めは 引きの 絵。会話が 終わったら 元に もどす */
const CAM = new Set(), SHOT = new Map();
const GEN = new Map();
export function camHold(p) { try { CAM.delete(p.id); SHOT.delete(p.id); GEN.set(p.id, (GEN.get(p.id) || 0) + 1); } catch {} }   /* 第113版: 予約した カメラの 片づけを とりけす（すぐ 後の 決闘カメラ・暗転を 消さない）*/
const camOn = (p) => { try { return p.getDynamicProperty("mrpg:nocam") !== true; } catch { return false; } };
const f2 = (v) => v.toFixed(2);
function airAt(p, x, y, z) { try { const b = p.dimension.getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) }); return !b || b.isAir || /glass|pane|fence|leaves|flower|grass|torch|lantern|carpet|snow_layer/.test(b.typeId); } catch { return false; } }
function camTo(p, pos, look, ease = 0.8) {
  if (!camOn(p) || !airAt(p, pos.x, pos.y, pos.z)) return false;
  const e = CAM.has(p.id) ? `ease ${ease} in_out_sine ` : "";
  if (!cmd(p, `camera @s set minecraft:free ${e}pos ${f2(pos.x)} ${f2(pos.y)} ${f2(pos.z)} facing ${f2(look.x)} ${f2(look.y)} ${f2(look.z)}`)) return false;
  CAM.add(p.id); return true;
}
function shot(p, sp) {
  try {
    const P = p.location, S = sp.location, dx = S.x - P.x, dz = S.z - P.z, L = Math.hypot(dx, dz) || 1, ux = dx / L, uz = dz / L, rx = -uz, rz = ux;
    const n = (SHOT.get(p.id) || 0) + 1; SHOT.set(p.id, n);
    const head = { x: S.x, y: S.y + 1.55, z: S.z };
    if (n % 3 === 0) { const m = { x: (P.x + S.x) / 2, y: (P.y + S.y) / 2 + 1.4, z: (P.z + S.z) / 2 }, d = L * 0.8 + 3.2;   /* 2人を 横から */
      if (camTo(p, { x: m.x + rx * d, y: m.y + 0.6, z: m.z + rz * d }, m) || camTo(p, { x: m.x - rx * d, y: m.y + 0.6, z: m.z - rz * d }, m)) return; }
    const side = n % 2 ? 1 : -1;   /* 肩ごしに 話す 人の 顔 */
    if (camTo(p, { x: P.x - ux * 2.2 + rx * 0.9 * side, y: P.y + 2.05, z: P.z - uz * 2.2 + rz * 0.9 * side }, head)) return;
    camTo(p, { x: P.x - ux * 0.6, y: P.y + 1.7, z: P.z - uz * 0.6 }, head);
  } catch {}
}
/* 場面の 始めの 引きの 絵（中心の まわりを ゆっくり 回る）。saga.js などから 呼ぶ */
export async function establish(p, c, nm, wide = 16, len = 64) {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) return;
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (!ok(p) || SKIP.has(p.id)) return;
  lock(p);
  try {
    if (nm) try { p.onScreenDisplay.setTitle(" ", { subtitle: `§7― §f${nm} §7―`, fadeInDuration: 10, stayDuration: 40, fadeOutDuration: 15 }); } catch {}
    const a0 = Math.random() * Math.PI * 2, at = (a, r, h) => ({ x: c.x + Math.cos(a) * r, y: c.y + h, z: c.z + Math.sin(a) * r }), look = { x: c.x, y: c.y + 1.5, z: c.z };
    CAM.delete(p.id);
    if (camTo(p, at(a0, wide, wide * 0.55), look)) { await wait(4); camTo(p, at(a0 + 0.9, wide * 0.55, wide * 0.25), look, len / 20); for (let t = 0; t < len; t += 4) { if (!ok(p)) break; let sn = false; try { sn = p.isSneaking || p.isJumping; } catch {} if (sn && t > 8) break; await wait(4); } }
    else await wait(40);
  } finally { unlock(p); LAST.set(p.id, Date.now()); }
}
export function camFade(p) { camHold(p); if (camOn(p)) cmd(p, "camera @s fade time 0.4 0.5 0.5 color 0 0 0"); }
function lock(p) {
  const n = (LOCK.get(p.id) || 0) + 1; LOCK.set(p.id, n); if (n > 1) return;
  if (!cmd(p, "inputpermission set @s lateral_movement disabled")) { SLOW.add(p.id); try { p.addEffect("slowness", 20 * 600, { amplifier: 255, showParticles: false }); } catch {} }   /* 古い 版の マイクラだけ（足を 止める）*/
  for (const h of HUD) cmd(p, `hud @s hide ${h}`);
}
function release(p) {
  if (CAM.has(p.id)) { const g = GEN.get(p.id) || 0; system.runTimeout(() => { if (g !== (GEN.get(p.id) || 0) || LOCK.has(p.id) || !CAM.has(p.id)) return; CAM.delete(p.id); if (globalThis.__MQ_CAMON?.has(p.id)) return; SHOT.delete(p.id); cmd(p, "camera @s clear"); }, 6); }   /* すぐ 次の 会話が 始まれば カメラは そのまま */
  if (SLOW.has(p.id)) { SLOW.delete(p.id); try { p.removeEffect("slowness"); } catch {} }
  cmd(p, "inputpermission set @s lateral_movement enabled"); cmd(p, "inputpermission set @s jump enabled"); cmd(p, "hud @s reset");
}
function unlock(p) { const n = (LOCK.get(p.id) || 1) - 1; if (n > 0) { LOCK.set(p.id, n); return; } LOCK.delete(p.id); release(p); }
/* ワールドに 入りなおした とき: 会話の とちゅうで 抜けても 動けない ままに ならない */
try { world.afterEvents.playerSpawn.subscribe((ev) => { const p = ev.player; if (LOCK.has(p.id)) return; try { if (p.getEffect("slowness")?.amplifier === 255) p.removeEffect("slowness"); } catch {} release(p); }); } catch {}
/* せりふの 中身から しぐさを えらぶ（4 話す 5 手を ふる 6 拍手 9 喜ぶ 10 おじぎ 12 しょんぼり）*/
function gesture(l) {
  const s = plain(l);
  if (/ありがと|よろしく|すまな|ごめん|申し訳/.test(s)) return 10;
  if (/……/.test(s) && !/！/.test(s)) return 12;
  if (/やった|すごい|ほっほ|あはは|おめでとう/.test(s)) return Math.random() < 0.5 ? 9 : 6;
  if (/おーい|やあ|じゃあな|またな|さらば/.test(s)) return 5;
  return 4;
}
function face(e, p) { try { e.teleport(e.location, { facingLocation: p.getHeadLocation() }); } catch {} }
/* 1行ずつ 流す。長さに 合わせて 待つ（2〜7秒）*/
async function flow(p, text, bar, sp, act) {
  if (!ok(p) || SKIP.has(p.id)) return;
  try { p.sendMessage(text); } catch {}
  if (sp) { try { sp.setProperty("mrpg:act", act); sp.setProperty("mrpg:mv", false); } catch {} face(sp, p); shot(p, sp); }
  /* 第111版: 自動で 進む（速さは 設定）。ジャンプか しゃがむで 次へ・しゃがみ 長押しで スキップ */
  let sp0 = 1; try { const v = p.getDynamicProperty("mrpg:tspeed"); if (typeof v === "number") sp0 = v; } catch {}
  const len = plain(bar).replace(/§./g, "").length, T = Math.round(Math.min(120, 24 + len * 1.6) * [1.5, 1, 0.6][sp0]);
  let held = 0, jw = true, rel = false; try { rel = !p.isSneaking; } catch { rel = true; }   /* 前から しゃがんで いたら 一度 はなすまで 長押しを 数えない */
  for (let t = 0; t < T; t += 5) {
    if (!ok(p)) break;
    if (t % 20 === 0) try { barNote(p).setActionBar(`${bar}\n§8ジャンプ: 次へ ／ しゃがみ 長押し: スキップ`); } catch {}
    let sn = false, jp = false; try { sn = p.isSneaking; jp = p.isJumping; } catch {}
    if (jp && !jw && t >= 5) break;   /* ジャンプ（押した とき）→ 次へ */
    jw = jp;
    if (!rel) { if (!sn) rel = true; await wait(5); continue; }
    if (sn) { held += 5; if (held >= 30) { SKIP.add(p.id); try { barNote(p).setActionBar("§7会話を スキップ"); } catch {} break; } }
    else if (held > 0) { if (t >= 10) break; held = 0; }   /* 短く しゃがんで はなした → 次へ */
    await wait(5);
  }
  if (sp) try { const b = sp.getDynamicProperty("mrpg:act0"); sp.setProperty("mrpg:act", typeof b === "number" ? b : 0); } catch {}
}
export async function talk(p, who, lines, col = "§6") {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { for (const l of [].concat(lines)) await notice(p, who, /^§7→/.test(l) ? l : `${col}§l${who}§r\n\n§f「${l}」`); return; }   /* 模擬テスト用 */
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (SKIP.has(p.id)) { LAST.set(p.id, Date.now()); return; }
  let sp = null; try { if (!/手紙|声|心の/.test(plain([].concat(lines)[0]))) sp = FIND ? FIND(p, who) : null; } catch {}
  lock(p);
  try {
    for (const l of [].concat(lines)) {
      if (SKIP.has(p.id)) break;
      if (/^§7→/.test(l)) { await flow(p, l, l, null, 0); continue; }
      await flow(p, `${col}§l${who}§r§f「${l}」`, `${col}${who}§f「${l}」`, sp, gesture(l));
    }
  } finally { unlock(p); LAST.set(p.id, Date.now()); }
}
export async function tell(p, title, lines) {
  if (globalThis.__MQ_TEST && !globalThis.__TALK_LIVE) { await notice(p, title, [].concat(lines).join("\n")); return; }
  if (SKIP.has(p.id) && Date.now() - (LAST.get(p.id) || 0) > 4000) SKIP.delete(p.id);
  if (SKIP.has(p.id)) { LAST.set(p.id, Date.now()); return; }
  lock(p);
  try { for (const l of [].concat(lines).flatMap((x) => String(x).split("\n"))) { if (SKIP.has(p.id)) break; if (!l.replace(/§./g, "").trim()) continue; await flow(p, `§7${l}`, `§f${l}`, null, 0); } }
  finally { unlock(p); LAST.set(p.id, Date.now()); }
}
